import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const DataCatalogNotFound_base: S.TaggedErrorClass<"DataCatalogNotFound", {
    readonly AthenaErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DataCatalogNotFound extends /*@__PURE__*/ DataCatalogNotFound_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly AthenaErrorCode: any;
    readonly message: any;
}>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const MetadataException_base: S.TaggedErrorClass<"MetadataException", {
    readonly message: any;
}>;
export declare class MetadataException extends /*@__PURE__*/ MetadataException_base {
}
declare const NamedQueryNotFound_base: S.TaggedErrorClass<"NamedQueryNotFound", {
    readonly AthenaErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class NamedQueryNotFound extends /*@__PURE__*/ NamedQueryNotFound_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const SessionAlreadyExistsException_base: S.TaggedErrorClass<"SessionAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SessionAlreadyExistsException extends /*@__PURE__*/ SessionAlreadyExistsException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const WorkGroupNotFound_base: S.TaggedErrorClass<"WorkGroupNotFound", {
    readonly AthenaErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class WorkGroupNotFound extends /*@__PURE__*/ WorkGroupNotFound_base {
}
export type NamedQueryId = string;
export type NamedQueryIdList = string[];
export interface BatchGetNamedQueryInput {
    NamedQueryIds: string[];
}
export type NameString = string;
export type DescriptionString = string;
export type DatabaseString = string;
export type QueryString = string;
export type WorkGroupName = string;
export interface NamedQuery {
    Name: string;
    Description?: string | undefined;
    Database: string;
    QueryString: string;
    NamedQueryId?: string | undefined;
    WorkGroup?: string | undefined;
}
export type NamedQueryList = NamedQuery[];
export type ErrorCode = string;
export type ErrorMessage = string;
export interface UnprocessedNamedQueryId {
    NamedQueryId?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type UnprocessedNamedQueryIdList = UnprocessedNamedQueryId[];
export interface BatchGetNamedQueryOutput {
    NamedQueries?: NamedQuery[] | undefined;
    UnprocessedNamedQueryIds?: UnprocessedNamedQueryId[] | undefined;
}
export type StatementName = string;
export type PreparedStatementNameList = string[];
export interface BatchGetPreparedStatementInput {
    PreparedStatementNames: string[];
    WorkGroup: string;
}
export interface PreparedStatement {
    StatementName?: string | undefined;
    QueryStatement?: string | undefined;
    WorkGroupName?: string | undefined;
    Description?: string | undefined;
    LastModifiedTime?: Date | undefined;
}
export type PreparedStatementDetailsList = PreparedStatement[];
export interface UnprocessedPreparedStatementName {
    StatementName?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type UnprocessedPreparedStatementNameList = UnprocessedPreparedStatementName[];
export interface BatchGetPreparedStatementOutput {
    PreparedStatements?: PreparedStatement[] | undefined;
    UnprocessedPreparedStatementNames?: UnprocessedPreparedStatementName[] | undefined;
}
export type QueryExecutionId = string;
export type QueryExecutionIdList = string[];
export interface BatchGetQueryExecutionInput {
    QueryExecutionIds: string[];
}
export type StatementType = "DDL" | "DML" | "UTILITY" | (string & {});
export type KmsKey = string;
export interface ManagedQueryResultsEncryptionConfiguration {
    KmsKey: string;
}
export interface ManagedQueryResultsConfiguration {
    Enabled: boolean;
    EncryptionConfiguration?: ManagedQueryResultsEncryptionConfiguration | undefined;
}
export type ResultOutputLocation = string;
export type EncryptionOption = "SSE_S3" | "SSE_KMS" | "CSE_KMS" | (string & {});
export interface EncryptionConfiguration {
    EncryptionOption: EncryptionOption;
    KmsKey?: string | undefined;
}
export type AwsAccountId = string;
export type S3AclOption = "BUCKET_OWNER_FULL_CONTROL" | (string & {});
export interface AclConfiguration {
    S3AclOption: S3AclOption;
}
export interface ResultConfiguration {
    OutputLocation?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    ExpectedBucketOwner?: string | undefined;
    AclConfiguration?: AclConfiguration | undefined;
}
export type Age = number;
export interface ResultReuseByAgeConfiguration {
    Enabled: boolean;
    MaxAgeInMinutes?: number | undefined;
}
export interface ResultReuseConfiguration {
    ResultReuseByAgeConfiguration?: ResultReuseByAgeConfiguration | undefined;
}
export type CatalogNameString = string;
export interface QueryExecutionContext {
    Database?: string | undefined;
    Catalog?: string | undefined;
}
export type QueryExecutionState = "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLED" | (string & {});
export type ErrorCategory = number;
export type ErrorType = number;
export interface AthenaError {
    ErrorCategory?: number | undefined;
    ErrorType?: number | undefined;
    Retryable?: boolean | undefined;
    ErrorMessage?: string | undefined;
}
export interface QueryExecutionStatus {
    State?: QueryExecutionState | undefined;
    StateChangeReason?: string | undefined;
    SubmissionDateTime?: Date | undefined;
    CompletionDateTime?: Date | undefined;
    AthenaError?: AthenaError | undefined;
}
export interface ResultReuseInformation {
    ReusedPreviousResult: boolean;
}
export type DpuCount = number;
export interface QueryExecutionStatistics {
    EngineExecutionTimeInMillis?: number | undefined;
    DataScannedInBytes?: number | undefined;
    DataManifestLocation?: string | undefined;
    TotalExecutionTimeInMillis?: number | undefined;
    QueryQueueTimeInMillis?: number | undefined;
    ServicePreProcessingTimeInMillis?: number | undefined;
    QueryPlanningTimeInMillis?: number | undefined;
    ServiceProcessingTimeInMillis?: number | undefined;
    ResultReuseInformation?: ResultReuseInformation | undefined;
    DpuCount?: number | undefined;
}
export interface EngineVersion {
    SelectedEngineVersion?: string | undefined;
    EffectiveEngineVersion?: string | undefined;
}
export type ExecutionParameter = string;
export type ExecutionParameters = string[];
export type BoxedBoolean = boolean;
export type AuthenticationType = "DIRECTORY_IDENTITY" | (string & {});
export interface QueryResultsS3AccessGrantsConfiguration {
    EnableS3AccessGrants: boolean;
    CreateUserLevelPrefix?: boolean | undefined;
    AuthenticationType: AuthenticationType;
}
export interface QueryExecution {
    QueryExecutionId?: string | undefined;
    Query?: string | undefined;
    StatementType?: StatementType | undefined;
    ManagedQueryResultsConfiguration?: ManagedQueryResultsConfiguration | undefined;
    ResultConfiguration?: ResultConfiguration | undefined;
    ResultReuseConfiguration?: ResultReuseConfiguration | undefined;
    QueryExecutionContext?: QueryExecutionContext | undefined;
    Status?: QueryExecutionStatus | undefined;
    Statistics?: QueryExecutionStatistics | undefined;
    WorkGroup?: string | undefined;
    EngineVersion?: EngineVersion | undefined;
    ExecutionParameters?: string[] | undefined;
    SubstatementType?: string | undefined;
    QueryResultsS3AccessGrantsConfiguration?: QueryResultsS3AccessGrantsConfiguration | undefined;
}
export type QueryExecutionList = QueryExecution[];
export interface UnprocessedQueryExecutionId {
    QueryExecutionId?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type UnprocessedQueryExecutionIdList = UnprocessedQueryExecutionId[];
export interface BatchGetQueryExecutionOutput {
    QueryExecutions?: QueryExecution[] | undefined;
    UnprocessedQueryExecutionIds?: UnprocessedQueryExecutionId[] | undefined;
}
export type CapacityReservationName = string;
export interface CancelCapacityReservationInput {
    Name: string;
}
export interface CancelCapacityReservationOutput {
}
export type TargetDpusInteger = number;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface CreateCapacityReservationInput {
    TargetDpus: number;
    Name: string;
    Tags?: Tag[] | undefined;
}
export interface CreateCapacityReservationOutput {
}
export type DataCatalogType = "LAMBDA" | "GLUE" | "HIVE" | "FEDERATED" | (string & {});
export type KeyString = string;
export type ParametersMapValue = string;
export type ParametersMap = {
    [key: string]: string | undefined;
};
export interface CreateDataCatalogInput {
    Name: string;
    Type: DataCatalogType;
    Description?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
}
export type DataCatalogStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "CREATE_FAILED_CLEANUP_IN_PROGRESS" | "CREATE_FAILED_CLEANUP_COMPLETE" | "CREATE_FAILED_CLEANUP_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | (string & {});
export type ConnectionType = "DYNAMODB" | "MYSQL" | "POSTGRESQL" | "REDSHIFT" | "ORACLE" | "SYNAPSE" | "SQLSERVER" | "DB2" | "OPENSEARCH" | "BIGQUERY" | "GOOGLECLOUDSTORAGE" | "HBASE" | "DOCUMENTDB" | "CMDB" | "TPCDS" | "TIMESTREAM" | "SAPHANA" | "SNOWFLAKE" | "DATALAKEGEN2" | "DB2AS400" | (string & {});
export interface DataCatalog {
    Name: string;
    Description?: string | undefined;
    Type: DataCatalogType;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    Status?: DataCatalogStatus | undefined;
    ConnectionType?: ConnectionType | undefined;
    Error?: string | undefined;
}
export interface CreateDataCatalogOutput {
    DataCatalog?: DataCatalog | undefined;
}
export type IdempotencyToken = string;
export interface CreateNamedQueryInput {
    Name: string;
    Description?: string | undefined;
    Database: string;
    QueryString: string;
    ClientRequestToken?: string | undefined;
    WorkGroup?: string | undefined;
}
export interface CreateNamedQueryOutput {
    NamedQueryId?: string | undefined;
}
export type NotebookName = string;
export type ClientRequestToken = string;
export interface CreateNotebookInput {
    WorkGroup: string;
    Name: string;
    ClientRequestToken?: string | undefined;
}
export type NotebookId = string;
export interface CreateNotebookOutput {
    NotebookId?: string | undefined;
}
export interface CreatePreparedStatementInput {
    StatementName: string;
    WorkGroup: string;
    QueryStatement: string;
    Description?: string | undefined;
}
export interface CreatePreparedStatementOutput {
}
export type SessionId = string;
export interface CreatePresignedNotebookUrlRequest {
    SessionId: string;
}
export type AuthToken = string;
export interface CreatePresignedNotebookUrlResponse {
    NotebookUrl: string;
    AuthToken: string;
    AuthTokenExpirationTime: number;
}
export type SystemTableName = "ALL" | (string & {});
export type KmsKeyArn = string;
export interface CreateSystemTableConfigurationInput {
    ClientRequestToken?: string | undefined;
    TableName: SystemTableName;
    KmsKeyArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateSystemTableConfigurationOutput {
    TableName?: SystemTableName | undefined;
    KmsKeyArn?: string | undefined;
    CreatedAt?: Date | undefined;
    LastModifiedAt?: Date | undefined;
}
export type BytesScannedCutoffValue = number;
export type RoleArn = string;
export type LogGroupName = string;
export type LogStreamNamePrefix = string;
export type LogTypeKey = string;
export type LogTypeValue = string;
export type LogTypeValuesList = string[];
export type LogTypesMap = {
    [key: string]: string[] | undefined;
};
export interface CloudWatchLoggingConfiguration {
    Enabled: boolean;
    LogGroup?: string | undefined;
    LogStreamNamePrefix?: string | undefined;
    LogTypes?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface ManagedLoggingConfiguration {
    Enabled: boolean;
    KmsKey?: string | undefined;
}
export type S3OutputLocation = string;
export interface S3LoggingConfiguration {
    Enabled: boolean;
    KmsKey?: string | undefined;
    LogLocation?: string | undefined;
}
export interface MonitoringConfiguration {
    CloudWatchLoggingConfiguration?: CloudWatchLoggingConfiguration | undefined;
    ManagedLoggingConfiguration?: ManagedLoggingConfiguration | undefined;
    S3LoggingConfiguration?: S3LoggingConfiguration | undefined;
}
export type CoordinatorDpuSize = number;
export type MaxConcurrentDpus = number;
export type DefaultExecutorDpuSize = number;
export interface Classification {
    Name?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ClassificationList = Classification[];
export interface EngineConfiguration {
    CoordinatorDpuSize?: number | undefined;
    MaxConcurrentDpus?: number | undefined;
    DefaultExecutorDpuSize?: number | undefined;
    AdditionalConfigs?: {
        [key: string]: string | undefined;
    } | undefined;
    SparkProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    Classifications?: Classification[] | undefined;
}
export interface CustomerContentEncryptionConfiguration {
    KmsKey: string;
}
export type IdentityCenterInstanceArn = string;
export interface IdentityCenterConfiguration {
    EnableIdentityCenter?: boolean | undefined;
    IdentityCenterInstanceArn?: string | undefined;
}
export type SystemTableType = "QUERY_EXECUTIONS" | (string & {});
export interface SystemTableStatus {
    TableName: SystemTableType;
    Enabled: boolean;
}
export type SystemTableStatusList = SystemTableStatus[];
export interface WorkGroupConfiguration {
    ResultConfiguration?: ResultConfiguration | undefined;
    ManagedQueryResultsConfiguration?: ManagedQueryResultsConfiguration | undefined;
    EnforceWorkGroupConfiguration?: boolean | undefined;
    PublishCloudWatchMetricsEnabled?: boolean | undefined;
    BytesScannedCutoffPerQuery?: number | undefined;
    RequesterPaysEnabled?: boolean | undefined;
    EngineVersion?: EngineVersion | undefined;
    AdditionalConfiguration?: string | undefined;
    ExecutionRole?: string | undefined;
    MonitoringConfiguration?: MonitoringConfiguration | undefined;
    EngineConfiguration?: EngineConfiguration | undefined;
    CustomerContentEncryptionConfiguration?: CustomerContentEncryptionConfiguration | undefined;
    EnableMinimumEncryptionConfiguration?: boolean | undefined;
    IdentityCenterConfiguration?: IdentityCenterConfiguration | undefined;
    QueryResultsS3AccessGrantsConfiguration?: QueryResultsS3AccessGrantsConfiguration | undefined;
    SystemTableStatuses?: SystemTableStatus[] | undefined;
}
export type WorkGroupDescriptionString = string;
export interface CreateWorkGroupInput {
    Name: string;
    Configuration?: WorkGroupConfiguration | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateWorkGroupOutput {
}
export interface DeleteCapacityReservationInput {
    Name: string;
}
export interface DeleteCapacityReservationOutput {
}
export interface DeleteDataCatalogInput {
    Name: string;
    DeleteCatalogOnly?: boolean | undefined;
}
export interface DeleteDataCatalogOutput {
    DataCatalog?: DataCatalog | undefined;
}
export interface DeleteNamedQueryInput {
    NamedQueryId: string;
}
export interface DeleteNamedQueryOutput {
}
export interface DeleteNotebookInput {
    NotebookId: string;
}
export interface DeleteNotebookOutput {
}
export interface DeletePreparedStatementInput {
    StatementName: string;
    WorkGroup: string;
}
export interface DeletePreparedStatementOutput {
}
export interface DeleteSystemTableConfigurationInput {
    TableName: SystemTableName;
}
export interface DeleteSystemTableConfigurationOutput {
}
export interface DeleteWorkGroupInput {
    WorkGroup: string;
    RecursiveDeleteOption?: boolean | undefined;
}
export interface DeleteWorkGroupOutput {
}
export interface ExportNotebookInput {
    NotebookId: string;
}
export type NotebookType = "IPYNB" | (string & {});
export interface NotebookMetadata {
    NotebookId?: string | undefined;
    Name?: string | undefined;
    WorkGroup?: string | undefined;
    CreationTime?: Date | undefined;
    Type?: NotebookType | undefined;
    LastModifiedTime?: Date | undefined;
}
export type Payload = string;
export interface ExportNotebookOutput {
    NotebookMetadata?: NotebookMetadata | undefined;
    Payload?: string | undefined;
}
export type CalculationExecutionId = string;
export interface GetCalculationExecutionRequest {
    CalculationExecutionId: string;
}
export type S3Uri = string;
export type CalculationExecutionState = "CREATING" | "CREATED" | "QUEUED" | "RUNNING" | "CANCELING" | "CANCELED" | "COMPLETED" | "FAILED" | (string & {});
export interface CalculationStatus {
    SubmissionDateTime?: Date | undefined;
    CompletionDateTime?: Date | undefined;
    State?: CalculationExecutionState | undefined;
    StateChangeReason?: string | undefined;
}
export interface CalculationStatistics {
    DpuExecutionInMillis?: number | undefined;
    Progress?: string | undefined;
}
export type CalculationResultType = string;
export interface CalculationResult {
    StdOutS3Uri?: string | undefined;
    StdErrorS3Uri?: string | undefined;
    ResultS3Uri?: string | undefined;
    ResultType?: string | undefined;
}
export interface GetCalculationExecutionResponse {
    CalculationExecutionId?: string | undefined;
    SessionId?: string | undefined;
    Description?: string | undefined;
    WorkingDirectory?: string | undefined;
    Status?: CalculationStatus | undefined;
    Statistics?: CalculationStatistics | undefined;
    Result?: CalculationResult | undefined;
}
export interface GetCalculationExecutionCodeRequest {
    CalculationExecutionId: string;
}
export type CodeBlock = string;
export interface GetCalculationExecutionCodeResponse {
    CodeBlock?: string | undefined;
}
export interface GetCalculationExecutionStatusRequest {
    CalculationExecutionId: string;
}
export interface GetCalculationExecutionStatusResponse {
    Status?: CalculationStatus | undefined;
    Statistics?: CalculationStatistics | undefined;
}
export interface GetCapacityAssignmentConfigurationInput {
    CapacityReservationName: string;
}
export type WorkGroupNamesList = string[];
export interface CapacityAssignment {
    WorkGroupNames?: string[] | undefined;
}
export type CapacityAssignmentsList = CapacityAssignment[];
export interface CapacityAssignmentConfiguration {
    CapacityReservationName?: string | undefined;
    CapacityAssignments?: CapacityAssignment[] | undefined;
}
export interface GetCapacityAssignmentConfigurationOutput {
    CapacityAssignmentConfiguration: CapacityAssignmentConfiguration;
}
export interface GetCapacityReservationInput {
    Name: string;
}
export type CapacityReservationStatus = "PENDING" | "ACTIVE" | "CANCELLING" | "CANCELLED" | "FAILED" | "UPDATE_PENDING" | (string & {});
export type AllocatedDpusInteger = number;
export type CapacityAllocationStatus = "PENDING" | "SUCCEEDED" | "FAILED" | (string & {});
export interface CapacityAllocation {
    Status: CapacityAllocationStatus;
    StatusMessage?: string | undefined;
    RequestTime: Date;
    RequestCompletionTime?: Date | undefined;
}
export interface CapacityReservation {
    Name: string;
    Status: CapacityReservationStatus;
    TargetDpus: number;
    AllocatedDpus: number;
    LastAllocation?: CapacityAllocation | undefined;
    LastSuccessfulAllocationTime?: Date | undefined;
    CreationTime: Date;
}
export interface GetCapacityReservationOutput {
    CapacityReservation: CapacityReservation;
}
export interface GetDatabaseInput {
    CatalogName: string;
    DatabaseName: string;
    WorkGroup?: string | undefined;
}
export interface Database {
    Name: string;
    Description?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDatabaseOutput {
    Database?: Database | undefined;
}
export interface GetDataCatalogInput {
    Name: string;
    WorkGroup?: string | undefined;
}
export interface GetDataCatalogOutput {
    DataCatalog?: DataCatalog | undefined;
}
export interface GetNamedQueryInput {
    NamedQueryId: string;
}
export interface GetNamedQueryOutput {
    NamedQuery?: NamedQuery | undefined;
}
export interface GetNotebookMetadataInput {
    NotebookId: string;
}
export interface GetNotebookMetadataOutput {
    NotebookMetadata?: NotebookMetadata | undefined;
}
export interface GetPreparedStatementInput {
    StatementName: string;
    WorkGroup: string;
}
export interface GetPreparedStatementOutput {
    PreparedStatement?: PreparedStatement | undefined;
}
export interface GetQueryExecutionInput {
    QueryExecutionId: string;
}
export interface GetQueryExecutionOutput {
    QueryExecution?: QueryExecution | undefined;
}
export type Token = string;
export type MaxQueryResults = number;
export type QueryResultType = "DATA_MANIFEST" | "DATA_ROWS" | (string & {});
export interface GetQueryResultsInput {
    QueryExecutionId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    QueryResultType?: QueryResultType | undefined;
}
export type DatumString = string;
export interface Datum {
    VarCharValue?: string | undefined;
}
export type DatumList = Datum[];
export interface Row {
    Data?: Datum[] | undefined;
}
export type RowList = Row[];
export type ColumnNullable = "NOT_NULL" | "NULLABLE" | "UNKNOWN" | (string & {});
export interface ColumnInfo {
    CatalogName?: string | undefined;
    SchemaName?: string | undefined;
    TableName?: string | undefined;
    Name: string;
    Label?: string | undefined;
    Type: string;
    Precision?: number | undefined;
    Scale?: number | undefined;
    Nullable?: ColumnNullable | undefined;
    CaseSensitive?: boolean | undefined;
}
export type ColumnInfoList = ColumnInfo[];
export interface ResultSetMetadata {
    ColumnInfo?: ColumnInfo[] | undefined;
}
export interface ResultSet {
    Rows?: Row[] | undefined;
    ResultSetMetadata?: ResultSetMetadata | undefined;
}
export interface GetQueryResultsOutput {
    UpdateCount?: number | undefined;
    ResultSet?: ResultSet | undefined;
    NextToken?: string | undefined;
}
export interface GetQueryRuntimeStatisticsInput {
    QueryExecutionId: string;
}
export interface QueryRuntimeStatisticsTimeline {
    QueryQueueTimeInMillis?: number | undefined;
    ServicePreProcessingTimeInMillis?: number | undefined;
    QueryPlanningTimeInMillis?: number | undefined;
    EngineExecutionTimeInMillis?: number | undefined;
    ServiceProcessingTimeInMillis?: number | undefined;
    TotalExecutionTimeInMillis?: number | undefined;
}
export interface QueryRuntimeStatisticsRows {
    InputRows?: number | undefined;
    InputBytes?: number | undefined;
    OutputBytes?: number | undefined;
    OutputRows?: number | undefined;
}
export type QueryStagePlanNodes = QueryStagePlanNode[];
export type StringList = string[];
export interface QueryStagePlanNode {
    Name?: string | undefined;
    Identifier?: string | undefined;
    Children?: QueryStagePlanNode[] | undefined;
    RemoteSources?: string[] | undefined;
}
export type QueryStages = QueryStage[];
export interface QueryStage {
    StageId?: number | undefined;
    State?: string | undefined;
    OutputBytes?: number | undefined;
    OutputRows?: number | undefined;
    InputBytes?: number | undefined;
    InputRows?: number | undefined;
    ExecutionTime?: number | undefined;
    QueryStagePlan?: QueryStagePlanNode | undefined;
    SubStages?: QueryStage[] | undefined;
}
export interface QueryRuntimeStatistics {
    Timeline?: QueryRuntimeStatisticsTimeline | undefined;
    Rows?: QueryRuntimeStatisticsRows | undefined;
    OutputStage?: QueryStage | undefined;
}
export interface GetQueryRuntimeStatisticsOutput {
    QueryRuntimeStatistics?: QueryRuntimeStatistics | undefined;
}
export type AmazonResourceName = string;
export interface GetResourceDashboardRequest {
    ResourceARN: string;
}
export interface GetResourceDashboardResponse {
    Url: string;
}
export interface GetSessionRequest {
    SessionId: string;
}
export type SessionIdleTimeoutInMinutes = number;
export interface SessionConfiguration {
    ExecutionRole?: string | undefined;
    WorkingDirectory?: string | undefined;
    IdleTimeoutSeconds?: number | undefined;
    SessionIdleTimeoutInMinutes?: number | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export type SessionState = "CREATING" | "CREATED" | "IDLE" | "BUSY" | "TERMINATING" | "TERMINATED" | "DEGRADED" | "FAILED" | (string & {});
export interface SessionStatus {
    StartDateTime?: Date | undefined;
    LastModifiedDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
    IdleSinceDateTime?: Date | undefined;
    State?: SessionState | undefined;
    StateChangeReason?: string | undefined;
}
export interface SessionStatistics {
    DpuExecutionInMillis?: number | undefined;
}
export interface GetSessionResponse {
    SessionId?: string | undefined;
    Description?: string | undefined;
    WorkGroup?: string | undefined;
    EngineVersion?: string | undefined;
    EngineConfiguration?: EngineConfiguration | undefined;
    NotebookVersion?: string | undefined;
    MonitoringConfiguration?: MonitoringConfiguration | undefined;
    SessionConfiguration?: SessionConfiguration | undefined;
    Status?: SessionStatus | undefined;
    Statistics?: SessionStatistics | undefined;
}
export interface GetSessionEndpointRequest {
    SessionId: string;
}
export interface GetSessionEndpointResponse {
    EndpointUrl: string;
    AuthToken: string;
    AuthTokenExpirationTime: Date;
}
export interface GetSessionStatusRequest {
    SessionId: string;
}
export interface GetSessionStatusResponse {
    SessionId?: string | undefined;
    Status?: SessionStatus | undefined;
}
export interface GetSystemTableConfigurationInput {
    TableName: SystemTableName;
}
export interface GetSystemTableConfigurationOutput {
    TableName?: SystemTableName | undefined;
    KmsKeyArn?: string | undefined;
    CreatedAt?: Date | undefined;
    LastModifiedAt?: Date | undefined;
}
export interface GetTableMetadataInput {
    CatalogName: string;
    DatabaseName: string;
    TableName: string;
    WorkGroup?: string | undefined;
}
export type TableTypeString = string;
export type TypeString = string;
export type CommentString = string;
export interface Column {
    Name: string;
    Type?: string | undefined;
    Comment?: string | undefined;
}
export type ColumnList = Column[];
export interface TableMetadata {
    Name: string;
    CreateTime?: Date | undefined;
    LastAccessTime?: Date | undefined;
    TableType?: string | undefined;
    Columns?: Column[] | undefined;
    PartitionKeys?: Column[] | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetTableMetadataOutput {
    TableMetadata?: TableMetadata | undefined;
}
export interface GetWorkGroupInput {
    WorkGroup: string;
}
export type WorkGroupState = "ENABLED" | "DISABLED" | (string & {});
export type IdentityCenterApplicationArn = string;
export interface WorkGroup {
    Name: string;
    State?: WorkGroupState | undefined;
    Configuration?: WorkGroupConfiguration | undefined;
    Description?: string | undefined;
    CreationTime?: Date | undefined;
    IdentityCenterApplicationArn?: string | undefined;
}
export interface GetWorkGroupOutput {
    WorkGroup?: WorkGroup | undefined;
}
export interface ImportNotebookInput {
    WorkGroup: string;
    Name: string;
    Payload?: string | undefined;
    Type: NotebookType;
    NotebookS3LocationUri?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface ImportNotebookOutput {
    NotebookId?: string | undefined;
}
export type MaxApplicationDPUSizesCount = number;
export interface ListApplicationDPUSizesInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SupportedDPUSizeList = number[];
export interface ApplicationDPUSizes {
    ApplicationRuntimeId?: string | undefined;
    SupportedDPUSizes?: number[] | undefined;
}
export type ApplicationDPUSizesList = ApplicationDPUSizes[];
export interface ListApplicationDPUSizesOutput {
    ApplicationDPUSizes?: ApplicationDPUSizes[] | undefined;
    NextToken?: string | undefined;
}
export type MaxCalculationsCount = number;
export type SessionManagerToken = string;
export interface ListCalculationExecutionsRequest {
    SessionId: string;
    StateFilter?: CalculationExecutionState | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface CalculationSummary {
    CalculationExecutionId?: string | undefined;
    Description?: string | undefined;
    Status?: CalculationStatus | undefined;
}
export type CalculationsList = CalculationSummary[];
export interface ListCalculationExecutionsResponse {
    NextToken?: string | undefined;
    Calculations?: CalculationSummary[] | undefined;
}
export type MaxCapacityReservationsCount = number;
export interface ListCapacityReservationsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type CapacityReservationsList = CapacityReservation[];
export interface ListCapacityReservationsOutput {
    NextToken?: string | undefined;
    CapacityReservations: CapacityReservation[];
}
export type MaxDatabasesCount = number;
export interface ListDatabasesInput {
    CatalogName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkGroup?: string | undefined;
}
export type DatabaseList = Database[];
export interface ListDatabasesOutput {
    DatabaseList?: Database[] | undefined;
    NextToken?: string | undefined;
}
export type MaxDataCatalogsCount = number;
export interface ListDataCatalogsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkGroup?: string | undefined;
}
export interface DataCatalogSummary {
    CatalogName?: string | undefined;
    Type?: DataCatalogType | undefined;
    Status?: DataCatalogStatus | undefined;
    ConnectionType?: ConnectionType | undefined;
    Error?: string | undefined;
}
export type DataCatalogSummaryList = DataCatalogSummary[];
export interface ListDataCatalogsOutput {
    DataCatalogsSummary?: DataCatalogSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxEngineVersionsCount = number;
export interface ListEngineVersionsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type EngineVersionsList = EngineVersion[];
export interface ListEngineVersionsOutput {
    EngineVersions?: EngineVersion[] | undefined;
    NextToken?: string | undefined;
}
export type ExecutorState = "CREATING" | "CREATED" | "REGISTERED" | "TERMINATING" | "TERMINATED" | "FAILED" | (string & {});
export type MaxListExecutorsCount = number;
export interface ListExecutorsRequest {
    SessionId: string;
    ExecutorStateFilter?: ExecutorState | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ExecutorId = string;
export type ExecutorType = "COORDINATOR" | "GATEWAY" | "WORKER" | (string & {});
export interface ExecutorsSummary {
    ExecutorId: string;
    ExecutorType?: ExecutorType | undefined;
    StartDateTime?: number | undefined;
    TerminationDateTime?: number | undefined;
    ExecutorState?: ExecutorState | undefined;
    ExecutorSize?: number | undefined;
}
export type ExecutorsSummaryList = ExecutorsSummary[];
export interface ListExecutorsResponse {
    SessionId: string;
    NextToken?: string | undefined;
    ExecutorsSummary?: ExecutorsSummary[] | undefined;
}
export type MaxNamedQueriesCount = number;
export interface ListNamedQueriesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkGroup?: string | undefined;
}
export interface ListNamedQueriesOutput {
    NamedQueryIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface FilterDefinition {
    Name?: string | undefined;
}
export type MaxNotebooksCount = number;
export interface ListNotebookMetadataInput {
    Filters?: FilterDefinition | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkGroup: string;
}
export type NotebookMetadataArray = NotebookMetadata[];
export interface ListNotebookMetadataOutput {
    NextToken?: string | undefined;
    NotebookMetadataList?: NotebookMetadata[] | undefined;
}
export type MaxSessionsCount = number;
export interface ListNotebookSessionsRequest {
    NotebookId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface NotebookSessionSummary {
    SessionId?: string | undefined;
    CreationTime?: Date | undefined;
}
export type NotebookSessionsList = NotebookSessionSummary[];
export interface ListNotebookSessionsResponse {
    NotebookSessionsList: NotebookSessionSummary[];
    NextToken?: string | undefined;
}
export type MaxPreparedStatementsCount = number;
export interface ListPreparedStatementsInput {
    WorkGroup: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface PreparedStatementSummary {
    StatementName?: string | undefined;
    LastModifiedTime?: Date | undefined;
}
export type PreparedStatementsList = PreparedStatementSummary[];
export interface ListPreparedStatementsOutput {
    PreparedStatements?: PreparedStatementSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxQueryExecutionsCount = number;
export interface ListQueryExecutionsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkGroup?: string | undefined;
}
export interface ListQueryExecutionsOutput {
    QueryExecutionIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSessionsRequest {
    WorkGroup: string;
    StateFilter?: SessionState | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SessionSummary {
    SessionId?: string | undefined;
    Description?: string | undefined;
    EngineVersion?: EngineVersion | undefined;
    NotebookVersion?: string | undefined;
    Status?: SessionStatus | undefined;
}
export type SessionsList = SessionSummary[];
export interface ListSessionsResponse {
    NextToken?: string | undefined;
    Sessions?: SessionSummary[] | undefined;
}
export type MaxSystemTableStatusesCount = number;
export interface ListSystemTableStatusesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListSystemTableStatusesOutput {
    Items: SystemTableStatus[];
    NextToken?: string | undefined;
}
export type ExpressionString = string;
export type MaxTableMetadataCount = number;
export interface ListTableMetadataInput {
    CatalogName: string;
    DatabaseName: string;
    Expression?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkGroup?: string | undefined;
}
export type TableMetadataList = TableMetadata[];
export interface ListTableMetadataOutput {
    TableMetadataList?: TableMetadata[] | undefined;
    NextToken?: string | undefined;
}
export type MaxTagsCount = number;
export interface ListTagsForResourceInput {
    ResourceARN: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListTagsForResourceOutput {
    Tags?: Tag[] | undefined;
    NextToken?: string | undefined;
}
export type MaxWorkGroupsCount = number;
export interface ListWorkGroupsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface WorkGroupSummary {
    Name?: string | undefined;
    State?: WorkGroupState | undefined;
    Description?: string | undefined;
    CreationTime?: Date | undefined;
    EngineVersion?: EngineVersion | undefined;
    IdentityCenterApplicationArn?: string | undefined;
}
export type WorkGroupsList = WorkGroupSummary[];
export interface ListWorkGroupsOutput {
    WorkGroups?: WorkGroupSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface PutCapacityAssignmentConfigurationInput {
    CapacityReservationName: string;
    CapacityAssignments: CapacityAssignment[];
}
export interface PutCapacityAssignmentConfigurationOutput {
}
export interface CalculationConfiguration {
    CodeBlock?: string | undefined;
}
export interface StartCalculationExecutionRequest {
    SessionId: string;
    Description?: string | undefined;
    CalculationConfiguration?: CalculationConfiguration | undefined;
    CodeBlock?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface StartCalculationExecutionResponse {
    CalculationExecutionId?: string | undefined;
    State?: CalculationExecutionState | undefined;
}
export interface StartQueryExecutionInput {
    QueryString: string;
    ClientRequestToken?: string | undefined;
    QueryExecutionContext?: QueryExecutionContext | undefined;
    ResultConfiguration?: ResultConfiguration | undefined;
    WorkGroup?: string | undefined;
    ExecutionParameters?: string[] | undefined;
    ResultReuseConfiguration?: ResultReuseConfiguration | undefined;
    EngineConfiguration?: EngineConfiguration | undefined;
}
export interface StartQueryExecutionOutput {
    QueryExecutionId?: string | undefined;
}
export interface StartSessionRequest {
    Description?: string | undefined;
    WorkGroup: string;
    EngineConfiguration: EngineConfiguration;
    ExecutionRole?: string | undefined;
    MonitoringConfiguration?: MonitoringConfiguration | undefined;
    NotebookVersion?: string | undefined;
    SessionIdleTimeoutInMinutes?: number | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
    CopyWorkGroupTags?: boolean | undefined;
}
export interface StartSessionResponse {
    SessionId?: string | undefined;
    State?: SessionState | undefined;
}
export interface StopCalculationExecutionRequest {
    CalculationExecutionId: string;
}
export interface StopCalculationExecutionResponse {
    State?: CalculationExecutionState | undefined;
}
export interface StopQueryExecutionInput {
    QueryExecutionId: string;
}
export interface StopQueryExecutionOutput {
}
export interface TagResourceInput {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceOutput {
}
export interface TerminateSessionRequest {
    SessionId: string;
}
export interface TerminateSessionResponse {
    State?: SessionState | undefined;
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateCapacityReservationInput {
    TargetDpus: number;
    Name: string;
}
export interface UpdateCapacityReservationOutput {
}
export interface UpdateDataCatalogInput {
    Name: string;
    Type: DataCatalogType;
    Description?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateDataCatalogOutput {
}
export type NamedQueryDescriptionString = string;
export interface UpdateNamedQueryInput {
    NamedQueryId: string;
    Name: string;
    Description?: string | undefined;
    QueryString: string;
}
export interface UpdateNamedQueryOutput {
}
export interface UpdateNotebookInput {
    NotebookId: string;
    Payload: string;
    Type: NotebookType;
    SessionId?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface UpdateNotebookOutput {
}
export interface UpdateNotebookMetadataInput {
    NotebookId: string;
    ClientRequestToken?: string | undefined;
    Name: string;
}
export interface UpdateNotebookMetadataOutput {
}
export interface UpdatePreparedStatementInput {
    StatementName: string;
    WorkGroup: string;
    QueryStatement: string;
    Description?: string | undefined;
}
export interface UpdatePreparedStatementOutput {
}
export interface UpdateSystemTableConfigurationInput {
    TableName: SystemTableName;
    KmsKeyArn?: string | undefined;
}
export interface UpdateSystemTableConfigurationOutput {
    TableName?: SystemTableName | undefined;
    KmsKeyArn?: string | undefined;
    CreatedAt?: Date | undefined;
    LastModifiedAt?: Date | undefined;
}
export interface ResultConfigurationUpdates {
    OutputLocation?: string | undefined;
    RemoveOutputLocation?: boolean | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    RemoveEncryptionConfiguration?: boolean | undefined;
    ExpectedBucketOwner?: string | undefined;
    RemoveExpectedBucketOwner?: boolean | undefined;
    AclConfiguration?: AclConfiguration | undefined;
    RemoveAclConfiguration?: boolean | undefined;
}
export interface ManagedQueryResultsConfigurationUpdates {
    Enabled?: boolean | undefined;
    EncryptionConfiguration?: ManagedQueryResultsEncryptionConfiguration | undefined;
    RemoveEncryptionConfiguration?: boolean | undefined;
}
export interface WorkGroupConfigurationUpdates {
    EnforceWorkGroupConfiguration?: boolean | undefined;
    ResultConfigurationUpdates?: ResultConfigurationUpdates | undefined;
    ManagedQueryResultsConfigurationUpdates?: ManagedQueryResultsConfigurationUpdates | undefined;
    PublishCloudWatchMetricsEnabled?: boolean | undefined;
    BytesScannedCutoffPerQuery?: number | undefined;
    RemoveBytesScannedCutoffPerQuery?: boolean | undefined;
    RequesterPaysEnabled?: boolean | undefined;
    EngineVersion?: EngineVersion | undefined;
    RemoveCustomerContentEncryptionConfiguration?: boolean | undefined;
    AdditionalConfiguration?: string | undefined;
    ExecutionRole?: string | undefined;
    CustomerContentEncryptionConfiguration?: CustomerContentEncryptionConfiguration | undefined;
    EnableMinimumEncryptionConfiguration?: boolean | undefined;
    QueryResultsS3AccessGrantsConfiguration?: QueryResultsS3AccessGrantsConfiguration | undefined;
    MonitoringConfiguration?: MonitoringConfiguration | undefined;
    EngineConfiguration?: EngineConfiguration | undefined;
}
export interface UpdateWorkGroupInput {
    WorkGroup: string;
    Description?: string | undefined;
    ConfigurationUpdates?: WorkGroupConfigurationUpdates | undefined;
    State?: WorkGroupState | undefined;
}
export interface UpdateWorkGroupOutput {
}
export type ThrottleReason = "CONCURRENT_QUERY_LIMIT_EXCEEDED" | (string & {});
export type BatchGetNamedQueryError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the details of a single named query or a list of up to 50 queries, which you
 * provide as an array of query ID strings. Requires you to have access to the workgroup in
 * which the queries were saved. Use ListNamedQueriesInput to get the
 * list of named query IDs in the specified workgroup. If information could not be
 * retrieved for a submitted query ID, information about the query ID submitted is listed
 * under UnprocessedNamedQueryId. Named queries differ from executed
 * queries. Use BatchGetQueryExecutionInput to get details about each
 * unique query execution, and ListQueryExecutionsInput to get a list of
 * query execution IDs.
 */
export declare const batchGetNamedQuery: API.OperationMethod<BatchGetNamedQueryInput & RegionInput, BatchGetNamedQueryOutput, BatchGetNamedQueryError, Credentials | HttpClient.HttpClient>;
export type BatchGetPreparedStatementError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the details of a single prepared statement or a list of up to 256 prepared
 * statements for the array of prepared statement names that you provide. Requires you to
 * have access to the workgroup to which the prepared statements belong. If a prepared
 * statement cannot be retrieved for the name specified, the statement is listed in
 * `UnprocessedPreparedStatementNames`.
 */
export declare const batchGetPreparedStatement: API.OperationMethod<BatchGetPreparedStatementInput & RegionInput, BatchGetPreparedStatementOutput, BatchGetPreparedStatementError, Credentials | HttpClient.HttpClient>;
export type BatchGetQueryExecutionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the details of a single query execution or a list of up to 50 query
 * executions, which you provide as an array of query execution ID strings. Requires you to
 * have access to the workgroup in which the queries ran. To get a list of query execution
 * IDs, use ListQueryExecutionsInput$WorkGroup. Query executions differ
 * from named (saved) queries. Use BatchGetNamedQueryInput to get details
 * about named queries.
 */
export declare const batchGetQueryExecution: API.OperationMethod<BatchGetQueryExecutionInput & RegionInput, BatchGetQueryExecutionOutput, BatchGetQueryExecutionError, Credentials | HttpClient.HttpClient>;
export type CancelCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Cancels the capacity reservation with the specified name. Cancelled reservations
 * remain in your account and will be deleted 45 days after cancellation. During the 45
 * days, you cannot re-purpose or reuse a reservation that has been cancelled, but you can
 * refer to its tags and view it for historical reference.
 */
export declare const cancelCapacityReservation: API.OperationMethod<CancelCapacityReservationInput & RegionInput, CancelCapacityReservationOutput, CancelCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type CreateCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a capacity reservation with the specified name and number of requested data
 * processing units.
 */
export declare const createCapacityReservation: API.OperationMethod<CreateCapacityReservationInput & RegionInput, CreateCapacityReservationOutput, CreateCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type CreateDataCatalogError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates (registers) a data catalog with the specified name and properties. Catalogs
 * created are visible to all users of the same Amazon Web Services account.
 *
 * For a `FEDERATED` catalog, this API operation creates the following
 * resources.
 *
 * - CFN Stack Name with a maximum length of 128 characters and prefix
 * `athenafederatedcatalog-CATALOG_NAME_SANITIZED` with length 23
 * characters.
 *
 * - Lambda Function Name with a maximum length of 64 characters and prefix
 * `athenafederatedcatalog_CATALOG_NAME_SANITIZED` with length 23
 * characters.
 *
 * - Glue Connection Name with a maximum length of 255 characters and a prefix
 * `athenafederatedcatalog_CATALOG_NAME_SANITIZED` with length 23
 * characters.
 */
export declare const createDataCatalog: API.OperationMethod<CreateDataCatalogInput & RegionInput, CreateDataCatalogOutput, CreateDataCatalogError, Credentials | HttpClient.HttpClient>;
export type CreateNamedQueryError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a named query in the specified workgroup. Requires that you have access to the
 * workgroup.
 */
export declare const createNamedQuery: API.OperationMethod<CreateNamedQueryInput & RegionInput, CreateNamedQueryOutput, CreateNamedQueryError, Credentials | HttpClient.HttpClient>;
export type CreateNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates an empty `ipynb` file in the specified Apache Spark enabled
 * workgroup. Throws an error if a file in the workgroup with the same name already
 * exists.
 */
export declare const createNotebook: API.OperationMethod<CreateNotebookInput & RegionInput, CreateNotebookOutput, CreateNotebookError, Credentials | HttpClient.HttpClient>;
export type CreatePreparedStatementError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a prepared statement for use with SQL queries in Athena.
 */
export declare const createPreparedStatement: API.OperationMethod<CreatePreparedStatementInput & RegionInput, CreatePreparedStatementOutput, CreatePreparedStatementError, Credentials | HttpClient.HttpClient>;
export type CreatePresignedNotebookUrlError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets an authentication token and the URL at which the notebook can be accessed. During
 * programmatic access, `CreatePresignedNotebookUrl` must be called every 10
 * minutes to refresh the authentication token. For information about granting programmatic
 * access, see Grant
 * programmatic access.
 */
export declare const createPresignedNotebookUrl: API.OperationMethod<CreatePresignedNotebookUrlRequest & RegionInput, CreatePresignedNotebookUrlResponse, CreatePresignedNotebookUrlError, Credentials | HttpClient.HttpClient>;
export type CreateSystemTableConfigurationError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Enables system tables for the current account. System tables are enabled or disabled for
 * the entire account: creating this configuration enables them. If a configuration
 * already exists, use UpdateSystemTableConfiguration to update it.
 */
export declare const createSystemTableConfiguration: API.OperationMethod<CreateSystemTableConfigurationInput & RegionInput, CreateSystemTableConfigurationOutput, CreateSystemTableConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateWorkGroupError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a workgroup with the specified name. A workgroup can be an Apache Spark
 * enabled workgroup or an Athena SQL workgroup.
 */
export declare const createWorkGroup: API.OperationMethod<CreateWorkGroupInput & RegionInput, CreateWorkGroupOutput, CreateWorkGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Deletes a cancelled capacity reservation. A reservation must be cancelled before it
 * can be deleted. A deleted reservation is immediately removed from your account and can
 * no longer be referenced, including by its ARN. A deleted reservation cannot be called by
 * `GetCapacityReservation`, and deleted reservations do not appear in the
 * output of `ListCapacityReservations`.
 */
export declare const deleteCapacityReservation: API.OperationMethod<DeleteCapacityReservationInput & RegionInput, DeleteCapacityReservationOutput, DeleteCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataCatalogError = InternalServerException | InvalidRequestException | DataCatalogNotFound | CommonErrors;
/**
 * Deletes a data catalog.
 */
export declare const deleteDataCatalog: API.OperationMethod<DeleteDataCatalogInput & RegionInput, DeleteDataCatalogOutput, DeleteDataCatalogError, Credentials | HttpClient.HttpClient>;
export type DeleteNamedQueryError = InternalServerException | InvalidRequestException | NamedQueryNotFound | CommonErrors;
/**
 * Deletes the named query if you have access to the workgroup in which the query was
 * saved.
 */
export declare const deleteNamedQuery: API.OperationMethod<DeleteNamedQueryInput & RegionInput, DeleteNamedQueryOutput, DeleteNamedQueryError, Credentials | HttpClient.HttpClient>;
export type DeleteNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified notebook.
 */
export declare const deleteNotebook: API.OperationMethod<DeleteNotebookInput & RegionInput, DeleteNotebookOutput, DeleteNotebookError, Credentials | HttpClient.HttpClient>;
export type DeletePreparedStatementError = InternalServerException | InvalidRequestException | ResourceNotFoundException | WorkGroupNotFound | CommonErrors;
/**
 * Deletes the prepared statement with the specified name from the specified
 * workgroup.
 */
export declare const deletePreparedStatement: API.OperationMethod<DeletePreparedStatementInput & RegionInput, DeletePreparedStatementOutput, DeletePreparedStatementError, Credentials | HttpClient.HttpClient>;
export type DeleteSystemTableConfigurationError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Disables system tables for the current account by deleting the account-level
 * configuration. If the configuration doesn't exist, the operation succeeds without making
 * any changes. The system table and previously published data are left intact.
 */
export declare const deleteSystemTableConfiguration: API.OperationMethod<DeleteSystemTableConfigurationInput & RegionInput, DeleteSystemTableConfigurationOutput, DeleteSystemTableConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkGroupError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Deletes the workgroup with the specified name. The primary workgroup cannot be
 * deleted.
 */
export declare const deleteWorkGroup: API.OperationMethod<DeleteWorkGroupInput & RegionInput, DeleteWorkGroupOutput, DeleteWorkGroupError, Credentials | HttpClient.HttpClient>;
export type ExportNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Exports the specified notebook and its metadata.
 */
export declare const exportNotebook: API.OperationMethod<ExportNotebookInput & RegionInput, ExportNotebookOutput, ExportNotebookError, Credentials | HttpClient.HttpClient>;
export type GetCalculationExecutionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a previously submitted calculation execution.
 */
export declare const getCalculationExecution: API.OperationMethod<GetCalculationExecutionRequest & RegionInput, GetCalculationExecutionResponse, GetCalculationExecutionError, Credentials | HttpClient.HttpClient>;
export type GetCalculationExecutionCodeError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the unencrypted code that was executed for the calculation.
 */
export declare const getCalculationExecutionCode: API.OperationMethod<GetCalculationExecutionCodeRequest & RegionInput, GetCalculationExecutionCodeResponse, GetCalculationExecutionCodeError, Credentials | HttpClient.HttpClient>;
export type GetCalculationExecutionStatusError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the status of a current calculation.
 */
export declare const getCalculationExecutionStatus: API.OperationMethod<GetCalculationExecutionStatusRequest & RegionInput, GetCalculationExecutionStatusResponse, GetCalculationExecutionStatusError, Credentials | HttpClient.HttpClient>;
export type GetCapacityAssignmentConfigurationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Gets the capacity assignment configuration for a capacity reservation, if one
 * exists.
 */
export declare const getCapacityAssignmentConfiguration: API.OperationMethod<GetCapacityAssignmentConfigurationInput & RegionInput, GetCapacityAssignmentConfigurationOutput, GetCapacityAssignmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns information about the capacity reservation with the specified name.
 */
export declare const getCapacityReservation: API.OperationMethod<GetCapacityReservationInput & RegionInput, GetCapacityReservationOutput, GetCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type GetDatabaseError = InternalServerException | InvalidRequestException | MetadataException | CommonErrors;
/**
 * Returns a database object for the specified database and data catalog.
 */
export declare const getDatabase: API.OperationMethod<GetDatabaseInput & RegionInput, GetDatabaseOutput, GetDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetDataCatalogError = InternalServerException | InvalidRequestException | DataCatalogNotFound | CommonErrors;
/**
 * Returns the specified data catalog.
 */
export declare const getDataCatalog: API.OperationMethod<GetDataCatalogInput & RegionInput, GetDataCatalogOutput, GetDataCatalogError, Credentials | HttpClient.HttpClient>;
export type GetNamedQueryError = InternalServerException | InvalidRequestException | NamedQueryNotFound | CommonErrors;
/**
 * Returns information about a single query. Requires that you have access to the
 * workgroup in which the query was saved.
 */
export declare const getNamedQuery: API.OperationMethod<GetNamedQueryInput & RegionInput, GetNamedQueryOutput, GetNamedQueryError, Credentials | HttpClient.HttpClient>;
export type GetNotebookMetadataError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves notebook metadata for the specified notebook ID.
 */
export declare const getNotebookMetadata: API.OperationMethod<GetNotebookMetadataInput & RegionInput, GetNotebookMetadataOutput, GetNotebookMetadataError, Credentials | HttpClient.HttpClient>;
export type GetPreparedStatementError = InternalServerException | InvalidRequestException | ResourceNotFoundException | WorkGroupNotFound | CommonErrors;
/**
 * Retrieves the prepared statement with the specified name from the specified
 * workgroup.
 */
export declare const getPreparedStatement: API.OperationMethod<GetPreparedStatementInput & RegionInput, GetPreparedStatementOutput, GetPreparedStatementError, Credentials | HttpClient.HttpClient>;
export type GetQueryExecutionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns information about a single execution of a query if you have access to the
 * workgroup in which the query ran. Each time a query executes, information about the
 * query execution is saved with a unique ID.
 */
export declare const getQueryExecution: API.OperationMethod<GetQueryExecutionInput & RegionInput, GetQueryExecutionOutput, GetQueryExecutionError, Credentials | HttpClient.HttpClient>;
export type GetQueryResultsError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Streams the results of a single query execution specified by
 * `QueryExecutionId` from the Athena query results location in
 * Amazon S3. For more information, see Working with query results, recent queries, and
 * output files in the *Amazon Athena User Guide*.
 * This request does not execute the query but returns results. Use StartQueryExecution to run a query.
 *
 * To stream query results successfully, the IAM principal with permission to call
 * `GetQueryResults` also must have permissions to the Amazon S3
 * `GetObject` action for the Athena query results location.
 *
 * IAM principals with permission to the Amazon S3
 * `GetObject` action for the query results location are able to retrieve
 * query results from Amazon S3 even if permission to the
 * `GetQueryResults` action is denied. To restrict user or role access,
 * ensure that Amazon S3 permissions to the Athena query location
 * are denied.
 */
export declare const getQueryResults: API.PaginatedOperationMethod<GetQueryResultsInput & RegionInput, GetQueryResultsOutput, GetQueryResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetQueryRuntimeStatisticsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns query execution runtime statistics related to a single execution of a query if
 * you have access to the workgroup in which the query ran. Statistics from the
 * `Timeline` section of the response object are available as soon as QueryExecutionStatus$State is in a SUCCEEDED or FAILED state. The
 * remaining non-timeline statistics in the response (like stage-level input and output row
 * count and data size) are updated asynchronously and may not be available immediately
 * after a query completes or, in some cases, may not be returned. The non-timeline
 * statistics are also not included when a query has row-level filters defined in Lake Formation.
 */
export declare const getQueryRuntimeStatistics: API.OperationMethod<GetQueryRuntimeStatisticsInput & RegionInput, GetQueryRuntimeStatisticsOutput, GetQueryRuntimeStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetResourceDashboardError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the Live UI/Persistence UI for a session.
 */
export declare const getResourceDashboard: API.OperationMethod<GetResourceDashboardRequest & RegionInput, GetResourceDashboardResponse, GetResourceDashboardError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the full details of a previously created session, including the session status
 * and configuration.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest & RegionInput, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type GetSessionEndpointError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a connection endpoint and authentication token for a given session Id.
 */
export declare const getSessionEndpoint: API.OperationMethod<GetSessionEndpointRequest & RegionInput, GetSessionEndpointResponse, GetSessionEndpointError, Credentials | HttpClient.HttpClient>;
export type GetSessionStatusError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the current status of a session.
 */
export declare const getSessionStatus: API.OperationMethod<GetSessionStatusRequest & RegionInput, GetSessionStatusResponse, GetSessionStatusError, Credentials | HttpClient.HttpClient>;
export type GetSystemTableConfigurationError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns the account-level system tables configuration. Fails with a
 * `ResourceNotFoundException` if system tables are not enabled for the
 * account.
 */
export declare const getSystemTableConfiguration: API.OperationMethod<GetSystemTableConfigurationInput & RegionInput, GetSystemTableConfigurationOutput, GetSystemTableConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableMetadataError = InternalServerException | InvalidRequestException | MetadataException | CommonErrors;
/**
 * Returns table metadata for the specified catalog, database, and table.
 */
export declare const getTableMetadata: API.OperationMethod<GetTableMetadataInput & RegionInput, GetTableMetadataOutput, GetTableMetadataError, Credentials | HttpClient.HttpClient>;
export type GetWorkGroupError = InternalServerException | InvalidRequestException | WorkGroupNotFound | CommonErrors;
/**
 * Returns information about the workgroup with the specified name.
 */
export declare const getWorkGroup: API.OperationMethod<GetWorkGroupInput & RegionInput, GetWorkGroupOutput, GetWorkGroupError, Credentials | HttpClient.HttpClient>;
export type ImportNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Imports a single `ipynb` file to a Spark enabled workgroup. To import the
 * notebook, the request must specify a value for either `Payload` or
 * `NoteBookS3LocationUri`. If neither is specified or both are specified,
 * an `InvalidRequestException` occurs. The maximum file size that can be
 * imported is 10 megabytes. If an `ipynb` file with the same name already
 * exists in the workgroup, throws an error.
 */
export declare const importNotebook: API.OperationMethod<ImportNotebookInput & RegionInput, ImportNotebookOutput, ImportNotebookError, Credentials | HttpClient.HttpClient>;
export type ListApplicationDPUSizesError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Returns the supported DPU sizes for the supported application runtimes (for example,
 * `Athena notebook version 1`).
 */
export declare const listApplicationDPUSizes: API.PaginatedOperationMethod<ListApplicationDPUSizesInput & RegionInput, ListApplicationDPUSizesOutput, ListApplicationDPUSizesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCalculationExecutionsError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the calculations that have been submitted to a session in descending order.
 * Newer calculations are listed first; older calculations are listed later.
 */
export declare const listCalculationExecutions: API.PaginatedOperationMethod<ListCalculationExecutionsRequest & RegionInput, ListCalculationExecutionsResponse, ListCalculationExecutionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCapacityReservationsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists the capacity reservations for the current account.
 */
export declare const listCapacityReservations: API.PaginatedOperationMethod<ListCapacityReservationsInput & RegionInput, ListCapacityReservationsOutput, ListCapacityReservationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDatabasesError = InternalServerException | InvalidRequestException | MetadataException | CommonErrors;
/**
 * Lists the databases in the specified data catalog.
 */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesInput & RegionInput, ListDatabasesOutput, ListDatabasesError, Credentials | HttpClient.HttpClient, Database>;
export type ListDataCatalogsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists the data catalogs in the current Amazon Web Services account.
 *
 * In the Athena console, data catalogs are listed as "data sources" on
 * the **Data sources** page under the **Data source name** column.
 */
export declare const listDataCatalogs: API.PaginatedOperationMethod<ListDataCatalogsInput & RegionInput, ListDataCatalogsOutput, ListDataCatalogsError, Credentials | HttpClient.HttpClient, DataCatalogSummary>;
export type ListEngineVersionsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of engine versions that are available to choose from, including the
 * Auto option.
 */
export declare const listEngineVersions: API.PaginatedOperationMethod<ListEngineVersionsInput & RegionInput, ListEngineVersionsOutput, ListEngineVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExecutorsError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists, in descending order, the executors that joined a session. Newer executors are
 * listed first; older executors are listed later. The result can be optionally filtered by
 * state.
 */
export declare const listExecutors: API.PaginatedOperationMethod<ListExecutorsRequest & RegionInput, ListExecutorsResponse, ListExecutorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNamedQueriesError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides a list of available query IDs only for queries saved in the specified
 * workgroup. Requires that you have access to the specified workgroup. If a workgroup is
 * not specified, lists the saved queries for the primary workgroup.
 */
export declare const listNamedQueries: API.PaginatedOperationMethod<ListNamedQueriesInput & RegionInput, ListNamedQueriesOutput, ListNamedQueriesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNotebookMetadataError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Displays the notebook files for the specified workgroup in paginated format.
 */
export declare const listNotebookMetadata: API.OperationMethod<ListNotebookMetadataInput & RegionInput, ListNotebookMetadataOutput, ListNotebookMetadataError, Credentials | HttpClient.HttpClient>;
export type ListNotebookSessionsError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists, in descending order, the sessions that have been created in a notebook that are
 * in an active state like `CREATING`, `CREATED`, `IDLE`
 * or `BUSY`. Newer sessions are listed first; older sessions are listed
 * later.
 */
export declare const listNotebookSessions: API.OperationMethod<ListNotebookSessionsRequest & RegionInput, ListNotebookSessionsResponse, ListNotebookSessionsError, Credentials | HttpClient.HttpClient>;
export type ListPreparedStatementsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists the prepared statements in the specified workgroup.
 */
export declare const listPreparedStatements: API.PaginatedOperationMethod<ListPreparedStatementsInput & RegionInput, ListPreparedStatementsOutput, ListPreparedStatementsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListQueryExecutionsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides a list of available query execution IDs for the queries in the specified
 * workgroup. Athena keeps a query history for 45 days. If a workgroup is not
 * specified, returns a list of query execution IDs for the primary workgroup. Requires you
 * to have access to the workgroup in which the queries ran.
 */
export declare const listQueryExecutions: API.PaginatedOperationMethod<ListQueryExecutionsInput & RegionInput, ListQueryExecutionsOutput, ListQueryExecutionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSessionsError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the sessions in a workgroup that are in an active state like
 * `CREATING`, `CREATED`, `IDLE`, or
 * `BUSY`. Newer sessions are listed first; older sessions are listed
 * later.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest & RegionInput, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSystemTableStatusesError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists the system tables that the account-level configuration activates, along with
 * whether each is currently enabled. Because system tables are enabled at the account
 * level, every entry reflects the same account-wide state.
 */
export declare const listSystemTableStatuses: API.PaginatedOperationMethod<ListSystemTableStatusesInput & RegionInput, ListSystemTableStatusesOutput, ListSystemTableStatusesError, Credentials | HttpClient.HttpClient, SystemTableStatus>;
export type ListTableMetadataError = InternalServerException | InvalidRequestException | MetadataException | CommonErrors;
/**
 * Lists the metadata for the tables in the specified data catalog database.
 */
export declare const listTableMetadata: API.PaginatedOperationMethod<ListTableMetadataInput & RegionInput, ListTableMetadataOutput, ListTableMetadataError, Credentials | HttpClient.HttpClient, TableMetadata>;
export type ListTagsForResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags associated with an Athena resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListWorkGroupsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists available workgroups for the account.
 */
export declare const listWorkGroups: API.PaginatedOperationMethod<ListWorkGroupsInput & RegionInput, ListWorkGroupsOutput, ListWorkGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutCapacityAssignmentConfigurationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Puts a new capacity assignment configuration for a specified capacity reservation. If
 * a capacity assignment configuration already exists for the capacity reservation,
 * replaces the existing capacity assignment configuration.
 */
export declare const putCapacityAssignmentConfiguration: API.OperationMethod<PutCapacityAssignmentConfigurationInput & RegionInput, PutCapacityAssignmentConfigurationOutput, PutCapacityAssignmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type StartCalculationExecutionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Submits calculations for execution within a session. You can supply the code to run as
 * an inline code block within the request.
 *
 * The request syntax requires the StartCalculationExecutionRequest$CodeBlock parameter or the CalculationConfiguration$CodeBlock parameter, but not both. Because
 * CalculationConfiguration$CodeBlock is deprecated, use the
 * StartCalculationExecutionRequest$CodeBlock parameter
 * instead.
 */
export declare const startCalculationExecution: API.OperationMethod<StartCalculationExecutionRequest & RegionInput, StartCalculationExecutionResponse, StartCalculationExecutionError, Credentials | HttpClient.HttpClient>;
export type StartQueryExecutionError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Runs the SQL query statements contained in the `Query`. Requires you to
 * have access to the workgroup in which the query ran. Running queries against an external
 * catalog requires GetDataCatalog permission to the catalog. For code
 * samples using the Amazon Web Services SDK for Java, see Examples and
 * Code Samples in the Amazon Athena User
 * Guide.
 */
export declare const startQueryExecution: API.OperationMethod<StartQueryExecutionInput & RegionInput, StartQueryExecutionOutput, StartQueryExecutionError, Credentials | HttpClient.HttpClient>;
export type StartSessionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | SessionAlreadyExistsException | TooManyRequestsException | CommonErrors;
/**
 * Creates a session for running calculations within a workgroup. The session is ready
 * when it reaches an `IDLE` state.
 */
export declare const startSession: API.OperationMethod<StartSessionRequest & RegionInput, StartSessionResponse, StartSessionError, Credentials | HttpClient.HttpClient>;
export type StopCalculationExecutionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Requests the cancellation of a calculation. A `StopCalculationExecution`
 * call on a calculation that is already in a terminal state (for example,
 * `STOPPED`, `FAILED`, or `COMPLETED`) succeeds but
 * has no effect.
 *
 * Cancelling a calculation is done on a best effort basis. If a calculation cannot
 * be cancelled, you can be charged for its completion. If you are concerned about
 * being charged for a calculation that cannot be cancelled, consider terminating the
 * session in which the calculation is running.
 */
export declare const stopCalculationExecution: API.OperationMethod<StopCalculationExecutionRequest & RegionInput, StopCalculationExecutionResponse, StopCalculationExecutionError, Credentials | HttpClient.HttpClient>;
export type StopQueryExecutionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Stops a query execution. Requires you to have access to the workgroup in which the
 * query ran.
 */
export declare const stopQueryExecution: API.OperationMethod<StopQueryExecutionInput & RegionInput, StopQueryExecutionOutput, StopQueryExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more tags to an Athena resource. A tag is a label that you
 * assign to a resource. Each tag consists of a key and an optional value, both of which
 * you define. For example, you can use tags to categorize Athena workgroups,
 * data catalogs, or capacity reservations by purpose, owner, or environment. Use a
 * consistent set of tag keys to make it easier to search and filter the resources in your
 * account. For best practices, see Tagging
 * Best Practices. Tag keys can be from 1 to 128 UTF-8 Unicode characters, and
 * tag values can be from 0 to 256 UTF-8 Unicode characters. Tags can use letters and
 * numbers representable in UTF-8, and the following characters: + - = . _ : / @. Tag keys
 * and values are case-sensitive. Tag keys must be unique per resource. If you specify more
 * than one tag, separate them by commas.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateSessionError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Terminates an active session. A `TerminateSession` call on a session that
 * is already inactive (for example, in a `FAILED`, `TERMINATED` or
 * `TERMINATING` state) succeeds but has no effect. Calculations running in
 * the session when `TerminateSession` is called are forcefully stopped, but may
 * display as `FAILED` instead of `STOPPED`.
 */
export declare const terminateSession: API.OperationMethod<TerminateSessionRequest & RegionInput, TerminateSessionResponse, TerminateSessionError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from an Athena resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCapacityReservationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Updates the number of requested data processing units for the capacity reservation
 * with the specified name.
 */
export declare const updateCapacityReservation: API.OperationMethod<UpdateCapacityReservationInput & RegionInput, UpdateCapacityReservationOutput, UpdateCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataCatalogError = InternalServerException | InvalidRequestException | DataCatalogNotFound | CommonErrors;
/**
 * Updates the data catalog that has the specified name.
 */
export declare const updateDataCatalog: API.OperationMethod<UpdateDataCatalogInput & RegionInput, UpdateDataCatalogOutput, UpdateDataCatalogError, Credentials | HttpClient.HttpClient>;
export type UpdateNamedQueryError = InternalServerException | InvalidRequestException | NamedQueryNotFound | CommonErrors;
/**
 * Updates a NamedQuery object. The database or workgroup cannot be
 * updated.
 */
export declare const updateNamedQuery: API.OperationMethod<UpdateNamedQueryInput & RegionInput, UpdateNamedQueryOutput, UpdateNamedQueryError, Credentials | HttpClient.HttpClient>;
export type UpdateNotebookError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Updates the contents of a Spark notebook.
 */
export declare const updateNotebook: API.OperationMethod<UpdateNotebookInput & RegionInput, UpdateNotebookOutput, UpdateNotebookError, Credentials | HttpClient.HttpClient>;
export type UpdateNotebookMetadataError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Updates the metadata for a notebook.
 */
export declare const updateNotebookMetadata: API.OperationMethod<UpdateNotebookMetadataInput & RegionInput, UpdateNotebookMetadataOutput, UpdateNotebookMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdatePreparedStatementError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a prepared statement.
 */
export declare const updatePreparedStatement: API.OperationMethod<UpdatePreparedStatementInput & RegionInput, UpdatePreparedStatementOutput, UpdatePreparedStatementError, Credentials | HttpClient.HttpClient>;
export type UpdateSystemTableConfigurationError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the account-level system tables configuration. If no configuration exists, use
 * CreateSystemTableConfiguration to create one. Fields that you omit
 * retain their current values.
 */
export declare const updateSystemTableConfiguration: API.OperationMethod<UpdateSystemTableConfigurationInput & RegionInput, UpdateSystemTableConfigurationOutput, UpdateSystemTableConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkGroupError = InternalServerException | InvalidRequestException | WorkGroupNotFound | CommonErrors;
/**
 * Updates the workgroup with the specified name. The workgroup's name cannot be changed.
 * Only `ConfigurationUpdates` can be specified.
 */
export declare const updateWorkGroup: API.OperationMethod<UpdateWorkGroupInput & RegionInput, UpdateWorkGroupOutput, UpdateWorkGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=athena.d.ts.map