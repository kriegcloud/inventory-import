import * as Effect from "effect/Effect";
import type { OnePasswordResolvedCredentials } from "../AuthProvider.ts";
import { OnePasswordRateLimitError, OnePasswordReferenceError, OnePasswordAccountNotFoundError, OnePasswordAuthExpiredError, OnePasswordDesktopSessionExpiredError, OnePasswordSdkError, OnePasswordTimeoutError } from "../Errors.ts";
/**
 * Read every variable of an Environment, or resolve vault references keyed by
 * their config keys. Fetched once; config lookups then read the returned map.
 * Rate limits are not retried: service-account quotas can take hours to reset.
 */
export declare const loadSecrets: (source: {
    readonly environmentId: string;
    readonly references?: undefined;
} | {
    readonly references: Readonly<Record<string, string>>;
    readonly environmentId?: undefined;
}, credentials: OnePasswordResolvedCredentials) => Effect.Effect<Record<string, string>, OnePasswordAccountNotFoundError | OnePasswordAuthExpiredError | OnePasswordDesktopSessionExpiredError | OnePasswordRateLimitError | OnePasswordReferenceError | OnePasswordSdkError | OnePasswordTimeoutError, never>;
//# sourceMappingURL=sdk.d.ts.map