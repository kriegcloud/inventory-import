import * as Layer from "effect/Layer";
import { KeyStore } from "./KeyStore.ts";
import { KeyWrap } from "./KeyWrap.ts";
import { Vault } from "./Vault.ts";
/**
 * A Vault that encrypts with AES-256-GCM under one key per subject. A
 * {@link KeyWrap} makes each key and a {@link KeyStore} keeps it. A box is
 * bound to its subject: under another subject, or under a key the subject
 * got after being shredded, it does not open.
 *
 * ### Giving a model a Vault
 * **Example:** Keys on the model's own host, wrapped under a root key
 * ```typescript
 * export const BankLive = Bank.layer(BankHandlers).pipe(
 *   Layer.provide(Domain.VaultLive),
 *   Layer.provide(Domain.HostKeyStore),
 *   Layer.provide(Domain.RootKeyWrap(Config.Redacted("VAULT_ROOT_KEY"))),
 *   Layer.provide(Platform),
 * );
 * ```
 *
 * @layer
 * @provides Domain.Vault
 */
export declare const VaultLive: Layer.Layer<Vault, never, KeyStore | KeyWrap>;
//# sourceMappingURL=VaultLive.d.ts.map