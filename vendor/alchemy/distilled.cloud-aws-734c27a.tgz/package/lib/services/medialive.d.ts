import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const BadGatewayException_base: S.TaggedErrorClass<"BadGatewayException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class BadGatewayException extends /*@__PURE__*/ BadGatewayException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GatewayTimeoutException_base: S.TaggedErrorClass<"GatewayTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GatewayTimeoutException extends /*@__PURE__*/ GatewayTimeoutException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const MediaLiveRoleNotYetTrusted_base: S.TaggedErrorClass<"MediaLiveRoleNotYetTrusted", {
    readonly message: any;
    readonly ValidationErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class MediaLiveRoleNotYetTrusted extends /*@__PURE__*/ MediaLiveRoleNotYetTrusted_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
    readonly ValidationErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export interface AcceptInputDeviceTransferRequest {
    InputDeviceId: string;
}
export interface AcceptInputDeviceTransferResponse {
}
export type __listOf__string = string[];
export interface BatchDeleteRequest {
    ChannelIds?: string[] | undefined;
    InputIds?: string[] | undefined;
    InputSecurityGroupIds?: string[] | undefined;
    MultiplexIds?: string[] | undefined;
}
export interface BatchFailedResultModel {
    Arn?: string | undefined;
    Code?: string | undefined;
    Id?: string | undefined;
    Message?: string | undefined;
}
export type __listOfBatchFailedResultModel = BatchFailedResultModel[];
export interface BatchSuccessfulResultModel {
    Arn?: string | undefined;
    Id?: string | undefined;
    State?: string | undefined;
}
export type __listOfBatchSuccessfulResultModel = BatchSuccessfulResultModel[];
export interface BatchDeleteResponse {
    Failed?: BatchFailedResultModel[] | undefined;
    Successful?: BatchSuccessfulResultModel[] | undefined;
}
export interface BatchStartRequest {
    ChannelIds?: string[] | undefined;
    MultiplexIds?: string[] | undefined;
}
export interface BatchStartResponse {
    Failed?: BatchFailedResultModel[] | undefined;
    Successful?: BatchSuccessfulResultModel[] | undefined;
}
export interface BatchStopRequest {
    ChannelIds?: string[] | undefined;
    MultiplexIds?: string[] | undefined;
}
export interface BatchStopResponse {
    Failed?: BatchFailedResultModel[] | undefined;
    Successful?: BatchSuccessfulResultModel[] | undefined;
}
export interface HlsId3SegmentTaggingScheduleActionSettings {
    Tag?: string | undefined;
    Id3?: string | undefined;
}
export interface HlsTimedMetadataScheduleActionSettings {
    Id3?: string | undefined;
}
export type InputTimecodeSource = "ZEROBASED" | "EMBEDDED" | (string & {});
export interface StartTimecode {
    Timecode?: string | undefined;
}
export type LastFrameClippingBehavior = "EXCLUDE_LAST_FRAME" | "INCLUDE_LAST_FRAME" | (string & {});
export interface StopTimecode {
    LastFrameClippingBehavior?: LastFrameClippingBehavior | undefined;
    Timecode?: string | undefined;
}
export interface InputClippingSettings {
    InputTimecodeSource?: InputTimecodeSource | undefined;
    StartTimecode?: StartTimecode | undefined;
    StopTimecode?: StopTimecode | undefined;
}
export interface InputPrepareScheduleActionSettings {
    InputAttachmentNameReference?: string | undefined;
    InputClippingSettings?: InputClippingSettings | undefined;
    UrlPath?: string[] | undefined;
}
export interface InputSwitchScheduleActionSettings {
    InputAttachmentNameReference?: string | undefined;
    InputClippingSettings?: InputClippingSettings | undefined;
    UrlPath?: string[] | undefined;
}
export type __longMin0Max86400000 = number;
export interface MotionGraphicsActivateScheduleActionSettings {
    Duration?: number | undefined;
    PasswordParam?: string | undefined;
    Url?: string | undefined;
    Username?: string | undefined;
}
export interface MotionGraphicsDeactivateScheduleActionSettings {
}
export type PipelineId = "PIPELINE_0" | "PIPELINE_1" | (string & {});
export interface PipelinePauseStateSettings {
    PipelineId?: PipelineId | undefined;
}
export type __listOfPipelinePauseStateSettings = PipelinePauseStateSettings[];
export interface PauseStateScheduleActionSettings {
    Pipelines?: PipelinePauseStateSettings[] | undefined;
}
export type Scte35InputMode = "FIXED" | "FOLLOW_ACTIVE" | (string & {});
export interface Scte35InputScheduleActionSettings {
    InputAttachmentNameReference?: string | undefined;
    Mode?: Scte35InputMode | undefined;
}
export type __longMin0Max4294967295 = number;
export interface Scte35ReturnToNetworkScheduleActionSettings {
    SpliceEventId?: number | undefined;
}
export type __longMin0Max8589934591 = number;
export interface Scte35SpliceInsertScheduleActionSettings {
    Duration?: number | undefined;
    SpliceEventId?: number | undefined;
}
export type Scte35ArchiveAllowedFlag = "ARCHIVE_NOT_ALLOWED" | "ARCHIVE_ALLOWED" | (string & {});
export type Scte35DeviceRestrictions = "NONE" | "RESTRICT_GROUP0" | "RESTRICT_GROUP1" | "RESTRICT_GROUP2" | (string & {});
export type Scte35NoRegionalBlackoutFlag = "REGIONAL_BLACKOUT" | "NO_REGIONAL_BLACKOUT" | (string & {});
export type Scte35WebDeliveryAllowedFlag = "WEB_DELIVERY_NOT_ALLOWED" | "WEB_DELIVERY_ALLOWED" | (string & {});
export interface Scte35DeliveryRestrictions {
    ArchiveAllowedFlag?: Scte35ArchiveAllowedFlag | undefined;
    DeviceRestrictions?: Scte35DeviceRestrictions | undefined;
    NoRegionalBlackoutFlag?: Scte35NoRegionalBlackoutFlag | undefined;
    WebDeliveryAllowedFlag?: Scte35WebDeliveryAllowedFlag | undefined;
}
export type __integerMin0Max255 = number;
export type Scte35SegmentationCancelIndicator = "SEGMENTATION_EVENT_NOT_CANCELED" | "SEGMENTATION_EVENT_CANCELED" | (string & {});
export type __longMin0Max1099511627775 = number;
export interface Scte35SegmentationDescriptor {
    DeliveryRestrictions?: Scte35DeliveryRestrictions | undefined;
    SegmentNum?: number | undefined;
    SegmentationCancelIndicator?: Scte35SegmentationCancelIndicator | undefined;
    SegmentationDuration?: number | undefined;
    SegmentationEventId?: number | undefined;
    SegmentationTypeId?: number | undefined;
    SegmentationUpid?: string | undefined;
    SegmentationUpidType?: number | undefined;
    SegmentsExpected?: number | undefined;
    SubSegmentNum?: number | undefined;
    SubSegmentsExpected?: number | undefined;
}
export interface Scte35DescriptorSettings {
    SegmentationDescriptorScte35DescriptorSettings?: Scte35SegmentationDescriptor | undefined;
}
export interface Scte35Descriptor {
    Scte35DescriptorSettings?: Scte35DescriptorSettings | undefined;
}
export type __listOfScte35Descriptor = Scte35Descriptor[];
export interface Scte35TimeSignalScheduleActionSettings {
    Scte35Descriptors?: Scte35Descriptor[] | undefined;
}
export type __integerMin0 = number;
export type __integerMin1 = number;
export type __stringMax2048 = string;
export interface InputLocation {
    PasswordParam?: string | undefined;
    Uri?: string | undefined;
    Username?: string | undefined;
}
export type __integerMin0Max7 = number;
export type __integerMin0Max100 = number;
export interface StaticImageActivateScheduleActionSettings {
    Duration?: number | undefined;
    FadeIn?: number | undefined;
    FadeOut?: number | undefined;
    Height?: number | undefined;
    Image?: InputLocation | undefined;
    ImageX?: number | undefined;
    ImageY?: number | undefined;
    Layer?: number | undefined;
    Opacity?: number | undefined;
    Width?: number | undefined;
}
export interface StaticImageDeactivateScheduleActionSettings {
    FadeOut?: number | undefined;
    Layer?: number | undefined;
}
export interface StaticImageOutputActivateScheduleActionSettings {
    Duration?: number | undefined;
    FadeIn?: number | undefined;
    FadeOut?: number | undefined;
    Height?: number | undefined;
    Image?: InputLocation | undefined;
    ImageX?: number | undefined;
    ImageY?: number | undefined;
    Layer?: number | undefined;
    Opacity?: number | undefined;
    OutputNames?: string[] | undefined;
    Width?: number | undefined;
}
export interface StaticImageOutputDeactivateScheduleActionSettings {
    FadeOut?: number | undefined;
    Layer?: number | undefined;
    OutputNames?: string[] | undefined;
}
export interface Id3SegmentTaggingScheduleActionSettings {
    Id3?: string | undefined;
    Tag?: string | undefined;
}
export interface TimedMetadataScheduleActionSettings {
    Id3?: string | undefined;
}
export interface ScheduleActionSettings {
    HlsId3SegmentTaggingSettings?: HlsId3SegmentTaggingScheduleActionSettings | undefined;
    HlsTimedMetadataSettings?: HlsTimedMetadataScheduleActionSettings | undefined;
    InputPrepareSettings?: InputPrepareScheduleActionSettings | undefined;
    InputSwitchSettings?: InputSwitchScheduleActionSettings | undefined;
    MotionGraphicsImageActivateSettings?: MotionGraphicsActivateScheduleActionSettings | undefined;
    MotionGraphicsImageDeactivateSettings?: MotionGraphicsDeactivateScheduleActionSettings | undefined;
    PauseStateSettings?: PauseStateScheduleActionSettings | undefined;
    Scte35InputSettings?: Scte35InputScheduleActionSettings | undefined;
    Scte35ReturnToNetworkSettings?: Scte35ReturnToNetworkScheduleActionSettings | undefined;
    Scte35SpliceInsertSettings?: Scte35SpliceInsertScheduleActionSettings | undefined;
    Scte35TimeSignalSettings?: Scte35TimeSignalScheduleActionSettings | undefined;
    StaticImageActivateSettings?: StaticImageActivateScheduleActionSettings | undefined;
    StaticImageDeactivateSettings?: StaticImageDeactivateScheduleActionSettings | undefined;
    StaticImageOutputActivateSettings?: StaticImageOutputActivateScheduleActionSettings | undefined;
    StaticImageOutputDeactivateSettings?: StaticImageOutputDeactivateScheduleActionSettings | undefined;
    Id3SegmentTaggingSettings?: Id3SegmentTaggingScheduleActionSettings | undefined;
    TimedMetadataSettings?: TimedMetadataScheduleActionSettings | undefined;
}
export interface FixedModeScheduleActionStartSettings {
    Time?: string | undefined;
}
export type FollowPoint = "END" | "START" | (string & {});
export interface FollowModeScheduleActionStartSettings {
    FollowPoint?: FollowPoint | undefined;
    ReferenceActionName?: string | undefined;
}
export interface ImmediateModeScheduleActionStartSettings {
}
export interface ScheduleActionStartSettings {
    FixedModeScheduleActionStartSettings?: FixedModeScheduleActionStartSettings | undefined;
    FollowModeScheduleActionStartSettings?: FollowModeScheduleActionStartSettings | undefined;
    ImmediateModeScheduleActionStartSettings?: ImmediateModeScheduleActionStartSettings | undefined;
}
export interface ScheduleAction {
    ActionName?: string | undefined;
    ScheduleActionSettings?: ScheduleActionSettings | undefined;
    ScheduleActionStartSettings?: ScheduleActionStartSettings | undefined;
}
export type __listOfScheduleAction = ScheduleAction[];
export interface BatchScheduleActionCreateRequest {
    ScheduleActions?: ScheduleAction[] | undefined;
}
export interface BatchScheduleActionDeleteRequest {
    ActionNames?: string[] | undefined;
}
export interface BatchUpdateScheduleRequest {
    ChannelId: string;
    Creates?: BatchScheduleActionCreateRequest | undefined;
    Deletes?: BatchScheduleActionDeleteRequest | undefined;
}
export interface BatchScheduleActionCreateResult {
    ScheduleActions?: ScheduleAction[] | undefined;
}
export interface BatchScheduleActionDeleteResult {
    ScheduleActions?: ScheduleAction[] | undefined;
}
export interface BatchUpdateScheduleResponse {
    Creates?: (BatchScheduleActionCreateResult & {
        ScheduleActions: (ScheduleAction & {
            ActionName: string;
            ScheduleActionSettings: ScheduleActionSettings & {
                HlsTimedMetadataSettings: HlsTimedMetadataScheduleActionSettings & {
                    Id3: string;
                };
                InputPrepareSettings: InputPrepareScheduleActionSettings & {
                    InputClippingSettings: InputClippingSettings & {
                        InputTimecodeSource: InputTimecodeSource;
                    };
                };
                InputSwitchSettings: InputSwitchScheduleActionSettings & {
                    InputAttachmentNameReference: string;
                    InputClippingSettings: InputClippingSettings & {
                        InputTimecodeSource: InputTimecodeSource;
                    };
                };
                PauseStateSettings: PauseStateScheduleActionSettings & {
                    Pipelines: (PipelinePauseStateSettings & {
                        PipelineId: PipelineId;
                    })[];
                };
                Scte35InputSettings: Scte35InputScheduleActionSettings & {
                    Mode: Scte35InputMode;
                };
                Scte35ReturnToNetworkSettings: Scte35ReturnToNetworkScheduleActionSettings & {
                    SpliceEventId: __longMin0Max4294967295;
                };
                Scte35SpliceInsertSettings: Scte35SpliceInsertScheduleActionSettings & {
                    SpliceEventId: __longMin0Max4294967295;
                };
                Scte35TimeSignalSettings: Scte35TimeSignalScheduleActionSettings & {
                    Scte35Descriptors: (Scte35Descriptor & {
                        Scte35DescriptorSettings: Scte35DescriptorSettings & {
                            SegmentationDescriptorScte35DescriptorSettings: Scte35SegmentationDescriptor & {
                                SegmentationCancelIndicator: Scte35SegmentationCancelIndicator;
                                SegmentationEventId: __longMin0Max4294967295;
                                DeliveryRestrictions: Scte35DeliveryRestrictions & {
                                    ArchiveAllowedFlag: Scte35ArchiveAllowedFlag;
                                    DeviceRestrictions: Scte35DeviceRestrictions;
                                    NoRegionalBlackoutFlag: Scte35NoRegionalBlackoutFlag;
                                    WebDeliveryAllowedFlag: Scte35WebDeliveryAllowedFlag;
                                };
                            };
                        };
                    })[];
                };
                StaticImageActivateSettings: StaticImageActivateScheduleActionSettings & {
                    Image: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                StaticImageOutputActivateSettings: StaticImageOutputActivateScheduleActionSettings & {
                    Image: InputLocation & {
                        Uri: __stringMax2048;
                    };
                    OutputNames: __listOf__string;
                };
                StaticImageOutputDeactivateSettings: StaticImageOutputDeactivateScheduleActionSettings & {
                    OutputNames: __listOf__string;
                };
                TimedMetadataSettings: TimedMetadataScheduleActionSettings & {
                    Id3: string;
                };
            };
            ScheduleActionStartSettings: ScheduleActionStartSettings & {
                FixedModeScheduleActionStartSettings: FixedModeScheduleActionStartSettings & {
                    Time: string;
                };
                FollowModeScheduleActionStartSettings: FollowModeScheduleActionStartSettings & {
                    FollowPoint: FollowPoint;
                    ReferenceActionName: string;
                };
            };
        })[];
    }) | undefined;
    Deletes?: (BatchScheduleActionDeleteResult & {
        ScheduleActions: (ScheduleAction & {
            ActionName: string;
            ScheduleActionSettings: ScheduleActionSettings & {
                HlsTimedMetadataSettings: HlsTimedMetadataScheduleActionSettings & {
                    Id3: string;
                };
                InputPrepareSettings: InputPrepareScheduleActionSettings & {
                    InputClippingSettings: InputClippingSettings & {
                        InputTimecodeSource: InputTimecodeSource;
                    };
                };
                InputSwitchSettings: InputSwitchScheduleActionSettings & {
                    InputAttachmentNameReference: string;
                    InputClippingSettings: InputClippingSettings & {
                        InputTimecodeSource: InputTimecodeSource;
                    };
                };
                PauseStateSettings: PauseStateScheduleActionSettings & {
                    Pipelines: (PipelinePauseStateSettings & {
                        PipelineId: PipelineId;
                    })[];
                };
                Scte35InputSettings: Scte35InputScheduleActionSettings & {
                    Mode: Scte35InputMode;
                };
                Scte35ReturnToNetworkSettings: Scte35ReturnToNetworkScheduleActionSettings & {
                    SpliceEventId: __longMin0Max4294967295;
                };
                Scte35SpliceInsertSettings: Scte35SpliceInsertScheduleActionSettings & {
                    SpliceEventId: __longMin0Max4294967295;
                };
                Scte35TimeSignalSettings: Scte35TimeSignalScheduleActionSettings & {
                    Scte35Descriptors: (Scte35Descriptor & {
                        Scte35DescriptorSettings: Scte35DescriptorSettings & {
                            SegmentationDescriptorScte35DescriptorSettings: Scte35SegmentationDescriptor & {
                                SegmentationCancelIndicator: Scte35SegmentationCancelIndicator;
                                SegmentationEventId: __longMin0Max4294967295;
                                DeliveryRestrictions: Scte35DeliveryRestrictions & {
                                    ArchiveAllowedFlag: Scte35ArchiveAllowedFlag;
                                    DeviceRestrictions: Scte35DeviceRestrictions;
                                    NoRegionalBlackoutFlag: Scte35NoRegionalBlackoutFlag;
                                    WebDeliveryAllowedFlag: Scte35WebDeliveryAllowedFlag;
                                };
                            };
                        };
                    })[];
                };
                StaticImageActivateSettings: StaticImageActivateScheduleActionSettings & {
                    Image: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                StaticImageOutputActivateSettings: StaticImageOutputActivateScheduleActionSettings & {
                    Image: InputLocation & {
                        Uri: __stringMax2048;
                    };
                    OutputNames: __listOf__string;
                };
                StaticImageOutputDeactivateSettings: StaticImageOutputDeactivateScheduleActionSettings & {
                    OutputNames: __listOf__string;
                };
                TimedMetadataSettings: TimedMetadataScheduleActionSettings & {
                    Id3: string;
                };
            };
            ScheduleActionStartSettings: ScheduleActionStartSettings & {
                FixedModeScheduleActionStartSettings: FixedModeScheduleActionStartSettings & {
                    Time: string;
                };
                FollowModeScheduleActionStartSettings: FollowModeScheduleActionStartSettings & {
                    FollowPoint: FollowPoint;
                    ReferenceActionName: string;
                };
            };
        })[];
    }) | undefined;
}
export interface CancelInputDeviceTransferRequest {
    InputDeviceId: string;
}
export interface CancelInputDeviceTransferResponse {
}
export interface ClaimDeviceRequest {
    Id?: string | undefined;
}
export interface ClaimDeviceResponse {
}
export type CdiInputResolution = "SD" | "HD" | "FHD" | "UHD" | (string & {});
export interface CdiInputSpecification {
    Resolution?: CdiInputResolution | undefined;
}
export type ChannelClass = "STANDARD" | "SINGLE_PIPELINE" | (string & {});
export type __stringMin1 = string;
export interface MediaPackageOutputDestinationSettings {
    ChannelId?: string | undefined;
    ChannelGroup?: string | undefined;
    ChannelName?: string | undefined;
    ChannelEndpointId?: string | undefined;
    MediaPackageRegionName?: string | undefined;
}
export type __listOfMediaPackageOutputDestinationSettings = MediaPackageOutputDestinationSettings[];
export interface MultiplexProgramChannelDestinationSettings {
    MultiplexId?: string | undefined;
    ProgramName?: string | undefined;
}
export interface OutputDestinationSettings {
    PasswordParam?: string | undefined;
    StreamName?: string | undefined;
    Url?: string | undefined;
    Username?: string | undefined;
    VirtualSourceAddress?: string | undefined;
}
export type __listOfOutputDestinationSettings = OutputDestinationSettings[];
export type ConnectionMode = "CALLER" | "LISTENER" | (string & {});
export type __integerMin1Max65535 = number;
export interface SrtOutputDestinationSettings {
    EncryptionPassphraseSecretArn?: string | undefined;
    StreamId?: string | undefined;
    Url?: string | undefined;
    ConnectionMode?: ConnectionMode | undefined;
    ListenerPort?: number | undefined;
}
export type __listOfSrtOutputDestinationSettings = SrtOutputDestinationSettings[];
export type MediaConnectRouterOutputEncryptionType = "AUTOMATIC" | "SECRETS_MANAGER" | (string & {});
export interface MediaConnectRouterOutputDestinationSettings {
    EncryptionType?: MediaConnectRouterOutputEncryptionType | undefined;
    SecretArn?: string | undefined;
}
export type __listOfMediaConnectRouterOutputDestinationSettings = MediaConnectRouterOutputDestinationSettings[];
export interface OutputDestination {
    Id?: string | undefined;
    MediaPackageSettings?: MediaPackageOutputDestinationSettings[] | undefined;
    MultiplexSettings?: MultiplexProgramChannelDestinationSettings | undefined;
    Settings?: OutputDestinationSettings[] | undefined;
    SrtSettings?: SrtOutputDestinationSettings[] | undefined;
    LogicalInterfaceNames?: string[] | undefined;
    MediaConnectRouterSettings?: MediaConnectRouterOutputDestinationSettings[] | undefined;
}
export type __listOfOutputDestination = OutputDestination[];
export type AudioNormalizationAlgorithm = "ITU_1770_1" | "ITU_1770_2" | "ITU_1770_3" | "ITU_1770_4" | (string & {});
export type AudioNormalizationAlgorithmControl = "CORRECT_AUDIO" | (string & {});
export type __doubleMinNegative59Max0 = number;
export type AudioNormalizationPeakCalculation = "NONE" | "TRUE_PEAK" | (string & {});
export type __doubleMinNegative8Max0 = number;
export interface AudioNormalizationSettings {
    Algorithm?: AudioNormalizationAlgorithm | undefined;
    AlgorithmControl?: AudioNormalizationAlgorithmControl | undefined;
    TargetLkfs?: number | undefined;
    PeakCalculation?: AudioNormalizationPeakCalculation | undefined;
    PeakLimiterThreshold?: number | undefined;
}
export type AudioType = "CLEAN_EFFECTS" | "HEARING_IMPAIRED" | "UNDEFINED" | "VISUAL_IMPAIRED_COMMENTARY" | (string & {});
export type AudioDescriptionAudioTypeControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type __stringMin2Max2 = string;
export type NielsenWatermarksCbetStepaside = "DISABLED" | "ENABLED" | (string & {});
export type __stringMin1Max7 = string;
export interface NielsenCBET {
    CbetCheckDigitString?: string | undefined;
    CbetStepaside?: NielsenWatermarksCbetStepaside | undefined;
    Csid?: string | undefined;
}
export type NielsenWatermarksDistributionTypes = "FINAL_DISTRIBUTOR" | "PROGRAM_CONTENT" | (string & {});
export type __doubleMin1Max65535 = number;
export type NielsenWatermarkTimezones = "AMERICA_PUERTO_RICO" | "US_ALASKA" | "US_ARIZONA" | "US_CENTRAL" | "US_EASTERN" | "US_HAWAII" | "US_MOUNTAIN" | "US_PACIFIC" | "US_SAMOA" | "UTC" | (string & {});
export interface NielsenNaesIiNw {
    CheckDigitString?: string | undefined;
    Sid?: number | undefined;
    Timezone?: NielsenWatermarkTimezones | undefined;
}
export interface NielsenNwOnly {
    CheckDigitString?: string | undefined;
    Sid?: number | undefined;
    Timezone?: NielsenWatermarkTimezones | undefined;
}
export interface NielsenWatermarksSettings {
    NielsenCbetSettings?: NielsenCBET | undefined;
    NielsenDistributionType?: NielsenWatermarksDistributionTypes | undefined;
    NielsenNaesIiNwSettings?: NielsenNaesIiNw | undefined;
    NielsenNwOnlySettings?: NielsenNwOnly | undefined;
}
export interface AudioWatermarkSettings {
    NielsenWatermarksSettings?: NielsenWatermarksSettings | undefined;
}
export type AacCodingMode = "AD_RECEIVER_MIX" | "CODING_MODE_1_0" | "CODING_MODE_1_1" | "CODING_MODE_2_0" | "CODING_MODE_5_1" | (string & {});
export type AacInputType = "BROADCASTER_MIXED_AD" | "NORMAL" | (string & {});
export type AacProfile = "HEV1" | "HEV2" | "LC" | (string & {});
export type AacRateControlMode = "CBR" | "VBR" | (string & {});
export type AacRawFormat = "LATM_LOAS" | "NONE" | (string & {});
export type AacSpec = "MPEG2" | "MPEG4" | (string & {});
export type AacVbrQuality = "HIGH" | "LOW" | "MEDIUM_HIGH" | "MEDIUM_LOW" | (string & {});
export interface AacSettings {
    Bitrate?: number | undefined;
    CodingMode?: AacCodingMode | undefined;
    InputType?: AacInputType | undefined;
    Profile?: AacProfile | undefined;
    RateControlMode?: AacRateControlMode | undefined;
    RawFormat?: AacRawFormat | undefined;
    SampleRate?: number | undefined;
    Spec?: AacSpec | undefined;
    VbrQuality?: AacVbrQuality | undefined;
}
export type Ac3BitstreamMode = "COMMENTARY" | "COMPLETE_MAIN" | "DIALOGUE" | "EMERGENCY" | "HEARING_IMPAIRED" | "MUSIC_AND_EFFECTS" | "VISUALLY_IMPAIRED" | "VOICE_OVER" | (string & {});
export type Ac3CodingMode = "CODING_MODE_1_0" | "CODING_MODE_1_1" | "CODING_MODE_2_0" | "CODING_MODE_3_2_LFE" | (string & {});
export type __integerMin1Max31 = number;
export type Ac3DrcProfile = "FILM_STANDARD" | "NONE" | (string & {});
export type Ac3LfeFilter = "DISABLED" | "ENABLED" | (string & {});
export type Ac3MetadataControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type Ac3AttenuationControl = "ATTENUATE_3_DB" | "NONE" | (string & {});
export interface Ac3Settings {
    Bitrate?: number | undefined;
    BitstreamMode?: Ac3BitstreamMode | undefined;
    CodingMode?: Ac3CodingMode | undefined;
    Dialnorm?: number | undefined;
    DrcProfile?: Ac3DrcProfile | undefined;
    LfeFilter?: Ac3LfeFilter | undefined;
    MetadataControl?: Ac3MetadataControl | undefined;
    AttenuationControl?: Ac3AttenuationControl | undefined;
}
export type Eac3AtmosCodingMode = "CODING_MODE_5_1_4" | "CODING_MODE_7_1_4" | "CODING_MODE_9_1_6" | (string & {});
export type Eac3AtmosDrcLine = "FILM_LIGHT" | "FILM_STANDARD" | "MUSIC_LIGHT" | "MUSIC_STANDARD" | "NONE" | "SPEECH" | (string & {});
export type Eac3AtmosDrcRf = "FILM_LIGHT" | "FILM_STANDARD" | "MUSIC_LIGHT" | "MUSIC_STANDARD" | "NONE" | "SPEECH" | (string & {});
export interface Eac3AtmosSettings {
    Bitrate?: number | undefined;
    CodingMode?: Eac3AtmosCodingMode | undefined;
    Dialnorm?: number | undefined;
    DrcLine?: Eac3AtmosDrcLine | undefined;
    DrcRf?: Eac3AtmosDrcRf | undefined;
    HeightTrim?: number | undefined;
    SurroundTrim?: number | undefined;
}
export type Eac3AttenuationControl = "ATTENUATE_3_DB" | "NONE" | (string & {});
export type Eac3BitstreamMode = "COMMENTARY" | "COMPLETE_MAIN" | "EMERGENCY" | "HEARING_IMPAIRED" | "VISUALLY_IMPAIRED" | (string & {});
export type Eac3CodingMode = "CODING_MODE_1_0" | "CODING_MODE_2_0" | "CODING_MODE_3_2" | (string & {});
export type Eac3DcFilter = "DISABLED" | "ENABLED" | (string & {});
export type Eac3DrcLine = "FILM_LIGHT" | "FILM_STANDARD" | "MUSIC_LIGHT" | "MUSIC_STANDARD" | "NONE" | "SPEECH" | (string & {});
export type Eac3DrcRf = "FILM_LIGHT" | "FILM_STANDARD" | "MUSIC_LIGHT" | "MUSIC_STANDARD" | "NONE" | "SPEECH" | (string & {});
export type Eac3LfeControl = "LFE" | "NO_LFE" | (string & {});
export type Eac3LfeFilter = "DISABLED" | "ENABLED" | (string & {});
export type Eac3MetadataControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type Eac3PassthroughControl = "NO_PASSTHROUGH" | "WHEN_POSSIBLE" | (string & {});
export type Eac3PhaseControl = "NO_SHIFT" | "SHIFT_90_DEGREES" | (string & {});
export type Eac3StereoDownmix = "DPL2" | "LO_RO" | "LT_RT" | "NOT_INDICATED" | (string & {});
export type Eac3SurroundExMode = "DISABLED" | "ENABLED" | "NOT_INDICATED" | (string & {});
export type Eac3SurroundMode = "DISABLED" | "ENABLED" | "NOT_INDICATED" | (string & {});
export interface Eac3Settings {
    AttenuationControl?: Eac3AttenuationControl | undefined;
    Bitrate?: number | undefined;
    BitstreamMode?: Eac3BitstreamMode | undefined;
    CodingMode?: Eac3CodingMode | undefined;
    DcFilter?: Eac3DcFilter | undefined;
    Dialnorm?: number | undefined;
    DrcLine?: Eac3DrcLine | undefined;
    DrcRf?: Eac3DrcRf | undefined;
    LfeControl?: Eac3LfeControl | undefined;
    LfeFilter?: Eac3LfeFilter | undefined;
    LoRoCenterMixLevel?: number | undefined;
    LoRoSurroundMixLevel?: number | undefined;
    LtRtCenterMixLevel?: number | undefined;
    LtRtSurroundMixLevel?: number | undefined;
    MetadataControl?: Eac3MetadataControl | undefined;
    PassthroughControl?: Eac3PassthroughControl | undefined;
    PhaseControl?: Eac3PhaseControl | undefined;
    StereoDownmix?: Eac3StereoDownmix | undefined;
    SurroundExMode?: Eac3SurroundExMode | undefined;
    SurroundMode?: Eac3SurroundMode | undefined;
}
export type Mp2CodingMode = "CODING_MODE_1_0" | "CODING_MODE_2_0" | (string & {});
export interface Mp2Settings {
    Bitrate?: number | undefined;
    CodingMode?: Mp2CodingMode | undefined;
    SampleRate?: number | undefined;
}
export interface PassThroughSettings {
}
export type WavCodingMode = "CODING_MODE_1_0" | "CODING_MODE_2_0" | "CODING_MODE_4_0" | "CODING_MODE_8_0" | (string & {});
export interface WavSettings {
    BitDepth?: number | undefined;
    CodingMode?: WavCodingMode | undefined;
    SampleRate?: number | undefined;
}
export interface AudioCodecSettings {
    AacSettings?: AacSettings | undefined;
    Ac3Settings?: Ac3Settings | undefined;
    Eac3AtmosSettings?: Eac3AtmosSettings | undefined;
    Eac3Settings?: Eac3Settings | undefined;
    Mp2Settings?: Mp2Settings | undefined;
    PassThroughSettings?: PassThroughSettings | undefined;
    WavSettings?: WavSettings | undefined;
}
export type __stringMin1Max35 = string;
export type AudioDescriptionLanguageCodeControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type __stringMax255 = string;
export type __integerMinNegative60Max6 = number;
export type __integerMin0Max15 = number;
export interface InputChannelLevel {
    Gain?: number | undefined;
    InputChannel?: number | undefined;
}
export type __listOfInputChannelLevel = InputChannelLevel[];
export interface AudioChannelMapping {
    InputChannelLevels?: InputChannelLevel[] | undefined;
    OutputChannel?: number | undefined;
}
export type __listOfAudioChannelMapping = AudioChannelMapping[];
export type __integerMin1Max16 = number;
export type __integerMin1Max8 = number;
export interface RemixSettings {
    ChannelMappings?: AudioChannelMapping[] | undefined;
    ChannelsIn?: number | undefined;
    ChannelsOut?: number | undefined;
}
export type DashRoleAudio = "ALTERNATE" | "COMMENTARY" | "DESCRIPTION" | "DUB" | "EMERGENCY" | "ENHANCED-AUDIO-INTELLIGIBILITY" | "KARAOKE" | "MAIN" | "SUPPLEMENTARY" | (string & {});
export type __listOfDashRoleAudio = DashRoleAudio[];
export type DvbDashAccessibility = "DVBDASH_1_VISUALLY_IMPAIRED" | "DVBDASH_2_HARD_OF_HEARING" | "DVBDASH_3_SUPPLEMENTAL_COMMENTARY" | "DVBDASH_4_DIRECTORS_COMMENTARY" | "DVBDASH_5_EDUCATIONAL_NOTES" | "DVBDASH_6_MAIN_PROGRAM" | "DVBDASH_7_CLEAN_FEED" | (string & {});
export interface AudioDescription {
    AudioNormalizationSettings?: AudioNormalizationSettings | undefined;
    AudioSelectorName?: string | undefined;
    AudioType?: AudioType | undefined;
    AudioTypeControl?: AudioDescriptionAudioTypeControl | undefined;
    AudioWatermarkingSettings?: AudioWatermarkSettings | undefined;
    CodecSettings?: AudioCodecSettings | undefined;
    LanguageCode?: string | undefined;
    LanguageCodeControl?: AudioDescriptionLanguageCodeControl | undefined;
    Name?: string | undefined;
    RemixSettings?: RemixSettings | undefined;
    StreamName?: string | undefined;
    AudioDashRoles?: DashRoleAudio[] | undefined;
    DvbDashAccessibility?: DvbDashAccessibility | undefined;
}
export type __listOfAudioDescription = AudioDescription[];
export type AvailBlankingState = "DISABLED" | "ENABLED" | (string & {});
export interface AvailBlanking {
    AvailBlankingImage?: InputLocation | undefined;
    State?: AvailBlankingState | undefined;
}
export type __stringMax256 = string;
export type __integerMinNegative1000Max1000 = number;
export interface Esam {
    AcquisitionPointId?: string | undefined;
    AdAvailOffset?: number | undefined;
    PasswordParam?: string | undefined;
    PoisEndpoint?: string | undefined;
    Username?: string | undefined;
    ZoneIdentity?: string | undefined;
}
export type Scte35SpliceInsertNoRegionalBlackoutBehavior = "FOLLOW" | "IGNORE" | (string & {});
export type Scte35SpliceInsertWebDeliveryAllowedBehavior = "FOLLOW" | "IGNORE" | (string & {});
export interface Scte35SpliceInsert {
    AdAvailOffset?: number | undefined;
    NoRegionalBlackoutFlag?: Scte35SpliceInsertNoRegionalBlackoutBehavior | undefined;
    WebDeliveryAllowedFlag?: Scte35SpliceInsertWebDeliveryAllowedBehavior | undefined;
}
export type Scte35AposNoRegionalBlackoutBehavior = "FOLLOW" | "IGNORE" | (string & {});
export type Scte35AposWebDeliveryAllowedBehavior = "FOLLOW" | "IGNORE" | (string & {});
export interface Scte35TimeSignalApos {
    AdAvailOffset?: number | undefined;
    NoRegionalBlackoutFlag?: Scte35AposNoRegionalBlackoutBehavior | undefined;
    WebDeliveryAllowedFlag?: Scte35AposWebDeliveryAllowedBehavior | undefined;
}
export interface AvailSettings {
    Esam?: Esam | undefined;
    Scte35SpliceInsert?: Scte35SpliceInsert | undefined;
    Scte35TimeSignalApos?: Scte35TimeSignalApos | undefined;
}
export type Scte35SegmentationScope = "ALL_OUTPUT_GROUPS" | "SCTE35_ENABLED_OUTPUT_GROUPS" | (string & {});
export interface AvailConfiguration {
    AvailSettings?: AvailSettings | undefined;
    Scte35SegmentationScope?: Scte35SegmentationScope | undefined;
}
export type BlackoutSlateNetworkEndBlackout = "DISABLED" | "ENABLED" | (string & {});
export type __stringMin34Max34 = string;
export type BlackoutSlateState = "DISABLED" | "ENABLED" | (string & {});
export interface BlackoutSlate {
    BlackoutSlateImage?: InputLocation | undefined;
    NetworkEndBlackout?: BlackoutSlateNetworkEndBlackout | undefined;
    NetworkEndBlackoutImage?: InputLocation | undefined;
    NetworkId?: string | undefined;
    State?: BlackoutSlateState | undefined;
}
export type AccessibilityType = "DOES_NOT_IMPLEMENT_ACCESSIBILITY_FEATURES" | "IMPLEMENTS_ACCESSIBILITY_FEATURES" | (string & {});
export interface AribDestinationSettings {
}
export type BurnInAlignment = "CENTERED" | "LEFT" | "SMART" | (string & {});
export type BurnInBackgroundColor = "BLACK" | "NONE" | "WHITE" | (string & {});
export type BurnInFontColor = "BLACK" | "BLUE" | "GREEN" | "RED" | "WHITE" | "YELLOW" | (string & {});
export type __integerMin96Max600 = number;
export type BurnInOutlineColor = "BLACK" | "BLUE" | "GREEN" | "RED" | "WHITE" | "YELLOW" | (string & {});
export type __integerMin0Max10 = number;
export type BurnInShadowColor = "BLACK" | "NONE" | "WHITE" | (string & {});
export type BurnInTeletextGridControl = "FIXED" | "SCALED" | (string & {});
export type BurnInDestinationSubtitleRows = "ROWS_16" | "ROWS_20" | "ROWS_24" | (string & {});
export interface BurnInDestinationSettings {
    Alignment?: BurnInAlignment | undefined;
    BackgroundColor?: BurnInBackgroundColor | undefined;
    BackgroundOpacity?: number | undefined;
    Font?: InputLocation | undefined;
    FontColor?: BurnInFontColor | undefined;
    FontOpacity?: number | undefined;
    FontResolution?: number | undefined;
    FontSize?: string | undefined;
    OutlineColor?: BurnInOutlineColor | undefined;
    OutlineSize?: number | undefined;
    ShadowColor?: BurnInShadowColor | undefined;
    ShadowOpacity?: number | undefined;
    ShadowXOffset?: number | undefined;
    ShadowYOffset?: number | undefined;
    TeletextGridControl?: BurnInTeletextGridControl | undefined;
    XPosition?: number | undefined;
    YPosition?: number | undefined;
    SubtitleRows?: BurnInDestinationSubtitleRows | undefined;
}
export type DvbSubDestinationAlignment = "CENTERED" | "LEFT" | "SMART" | (string & {});
export type DvbSubDestinationBackgroundColor = "BLACK" | "NONE" | "WHITE" | (string & {});
export type DvbSubDestinationFontColor = "BLACK" | "BLUE" | "GREEN" | "RED" | "WHITE" | "YELLOW" | (string & {});
export type DvbSubDestinationOutlineColor = "BLACK" | "BLUE" | "GREEN" | "RED" | "WHITE" | "YELLOW" | (string & {});
export type DvbSubDestinationShadowColor = "BLACK" | "NONE" | "WHITE" | (string & {});
export type DvbSubDestinationTeletextGridControl = "FIXED" | "SCALED" | (string & {});
export type DvbSubDestinationSubtitleRows = "ROWS_16" | "ROWS_20" | "ROWS_24" | (string & {});
export interface DvbSubDestinationSettings {
    Alignment?: DvbSubDestinationAlignment | undefined;
    BackgroundColor?: DvbSubDestinationBackgroundColor | undefined;
    BackgroundOpacity?: number | undefined;
    Font?: InputLocation | undefined;
    FontColor?: DvbSubDestinationFontColor | undefined;
    FontOpacity?: number | undefined;
    FontResolution?: number | undefined;
    FontSize?: string | undefined;
    OutlineColor?: DvbSubDestinationOutlineColor | undefined;
    OutlineSize?: number | undefined;
    ShadowColor?: DvbSubDestinationShadowColor | undefined;
    ShadowOpacity?: number | undefined;
    ShadowXOffset?: number | undefined;
    ShadowYOffset?: number | undefined;
    TeletextGridControl?: DvbSubDestinationTeletextGridControl | undefined;
    XPosition?: number | undefined;
    YPosition?: number | undefined;
    SubtitleRows?: DvbSubDestinationSubtitleRows | undefined;
}
export type __stringMax1000 = string;
export type EbuTtDFillLineGapControl = "DISABLED" | "ENABLED" | (string & {});
export type EbuTtDDestinationStyleControl = "EXCLUDE" | "INCLUDE" | (string & {});
export type __integerMin1Max800 = number;
export type __integerMin80Max800 = number;
export interface EbuTtDDestinationSettings {
    CopyrightHolder?: string | undefined;
    FillLineGap?: EbuTtDFillLineGapControl | undefined;
    FontFamily?: string | undefined;
    StyleControl?: EbuTtDDestinationStyleControl | undefined;
    DefaultFontSize?: number | undefined;
    DefaultLineHeight?: number | undefined;
}
export type __integerMin1Max15 = number;
export interface EmbeddedCaptionPositionSettings {
    YPositionLine?: number | undefined;
}
export type EmbeddedDestinationStyleControl = "MANUAL" | "PASSTHROUGH" | (string & {});
export interface EmbeddedDestinationSettings {
    Position?: EmbeddedCaptionPositionSettings | undefined;
    StyleControl?: EmbeddedDestinationStyleControl | undefined;
}
export interface EmbeddedPlusScte20DestinationSettings {
}
export interface RtmpCaptionInfoDestinationSettings {
}
export interface Scte20PlusEmbeddedDestinationSettings {
}
export interface Scte27DestinationSettings {
}
export interface SmpteTtDestinationSettings {
}
export interface TeletextDestinationSettings {
}
export type TtmlDestinationStyleControl = "PASSTHROUGH" | "USE_CONFIGURED" | "MANUAL" | (string & {});
export interface TextCaptionPositionSettings {
    YPositionPercentage?: number | undefined;
}
export interface TtmlDestinationSettings {
    StyleControl?: TtmlDestinationStyleControl | undefined;
    Position?: TextCaptionPositionSettings | undefined;
}
export type WebvttDestinationStyleControl = "NO_STYLE_DATA" | "PASSTHROUGH" | "MANUAL" | (string & {});
export interface WebvttDestinationSettings {
    StyleControl?: WebvttDestinationStyleControl | undefined;
    Position?: TextCaptionPositionSettings | undefined;
}
export interface CaptionDestinationSettings {
    AribDestinationSettings?: AribDestinationSettings | undefined;
    BurnInDestinationSettings?: BurnInDestinationSettings | undefined;
    DvbSubDestinationSettings?: DvbSubDestinationSettings | undefined;
    EbuTtDDestinationSettings?: EbuTtDDestinationSettings | undefined;
    EmbeddedDestinationSettings?: EmbeddedDestinationSettings | undefined;
    EmbeddedPlusScte20DestinationSettings?: EmbeddedPlusScte20DestinationSettings | undefined;
    RtmpCaptionInfoDestinationSettings?: RtmpCaptionInfoDestinationSettings | undefined;
    Scte20PlusEmbeddedDestinationSettings?: Scte20PlusEmbeddedDestinationSettings | undefined;
    Scte27DestinationSettings?: Scte27DestinationSettings | undefined;
    SmpteTtDestinationSettings?: SmpteTtDestinationSettings | undefined;
    TeletextDestinationSettings?: TeletextDestinationSettings | undefined;
    TtmlDestinationSettings?: TtmlDestinationSettings | undefined;
    WebvttDestinationSettings?: WebvttDestinationSettings | undefined;
}
export type DashRoleCaption = "ALTERNATE" | "CAPTION" | "COMMENTARY" | "DESCRIPTION" | "DUB" | "EASYREADER" | "EMERGENCY" | "FORCED-SUBTITLE" | "KARAOKE" | "MAIN" | "METADATA" | "SUBTITLE" | "SUPPLEMENTARY" | (string & {});
export type __listOfDashRoleCaption = DashRoleCaption[];
export interface CaptionDescription {
    Accessibility?: AccessibilityType | undefined;
    CaptionSelectorName?: string | undefined;
    DestinationSettings?: CaptionDestinationSettings | undefined;
    LanguageCode?: string | undefined;
    LanguageDescription?: string | undefined;
    Name?: string | undefined;
    CaptionDashRoles?: DashRoleCaption[] | undefined;
    DvbDashAccessibility?: DvbDashAccessibility | undefined;
}
export type __listOfCaptionDescription = CaptionDescription[];
export type FeatureActivationsInputPrepareScheduleActions = "DISABLED" | "ENABLED" | (string & {});
export type FeatureActivationsOutputStaticImageOverlayScheduleActions = "DISABLED" | "ENABLED" | (string & {});
export interface FeatureActivations {
    InputPrepareScheduleActions?: FeatureActivationsInputPrepareScheduleActions | undefined;
    OutputStaticImageOverlayScheduleActions?: FeatureActivationsOutputStaticImageOverlayScheduleActions | undefined;
}
export type __integerMinNegative60Max60 = number;
export type GlobalConfigurationInputEndAction = "NONE" | "SWITCH_AND_LOOP_INPUTS" | (string & {});
export type __integerMin0Max1000000 = number;
export type __stringMin6Max6 = string;
export type InputLossImageType = "COLOR" | "SLATE" | (string & {});
export interface InputLossBehavior {
    BlackFrameMsec?: number | undefined;
    InputLossImageColor?: string | undefined;
    InputLossImageSlate?: InputLocation | undefined;
    InputLossImageType?: InputLossImageType | undefined;
    RepeatFrameMsec?: number | undefined;
}
export type GlobalConfigurationOutputLockingMode = "EPOCH_LOCKING" | "PIPELINE_LOCKING" | "DISABLED" | (string & {});
export type GlobalConfigurationOutputTimingSource = "INPUT_CLOCK" | "SYSTEM_CLOCK" | (string & {});
export type GlobalConfigurationLowFramerateInputs = "DISABLED" | "ENABLED" | (string & {});
export interface EpochLockingSettings {
    CustomEpoch?: string | undefined;
    JamSyncTime?: string | undefined;
}
export type PipelineLockingMethod = "SOURCE_TIMECODE" | "VIDEO_ALIGNMENT" | (string & {});
export interface PipelineLockingSettings {
    PipelineLockingMethod?: PipelineLockingMethod | undefined;
    CustomEpoch?: string | undefined;
}
export interface DisabledLockingSettings {
    CustomEpoch?: string | undefined;
}
export interface OutputLockingSettings {
    EpochLockingSettings?: EpochLockingSettings | undefined;
    PipelineLockingSettings?: PipelineLockingSettings | undefined;
    DisabledLockingSettings?: DisabledLockingSettings | undefined;
}
export interface GlobalConfiguration {
    InitialAudioGain?: number | undefined;
    InputEndAction?: GlobalConfigurationInputEndAction | undefined;
    InputLossBehavior?: InputLossBehavior | undefined;
    OutputLockingMode?: GlobalConfigurationOutputLockingMode | undefined;
    OutputTimingSource?: GlobalConfigurationOutputTimingSource | undefined;
    SupportLowFramerateInputs?: GlobalConfigurationLowFramerateInputs | undefined;
    OutputLockingSettings?: OutputLockingSettings | undefined;
}
export type MotionGraphicsInsertion = "DISABLED" | "ENABLED" | (string & {});
export interface HtmlMotionGraphicsSettings {
}
export interface MotionGraphicsSettings {
    HtmlMotionGraphicsSettings?: HtmlMotionGraphicsSettings | undefined;
}
export interface MotionGraphicsConfiguration {
    MotionGraphicsInsertion?: MotionGraphicsInsertion | undefined;
    MotionGraphicsSettings?: MotionGraphicsSettings | undefined;
}
export type NielsenPcmToId3TaggingState = "DISABLED" | "ENABLED" | (string & {});
export interface NielsenConfiguration {
    DistributorId?: string | undefined;
    NielsenPcmToId3Tagging?: NielsenPcmToId3TaggingState | undefined;
}
export type __stringMax32 = string;
export type S3CannedAcl = "AUTHENTICATED_READ" | "BUCKET_OWNER_FULL_CONTROL" | "BUCKET_OWNER_READ" | "PUBLIC_READ" | (string & {});
export interface ArchiveS3Settings {
    CannedAcl?: S3CannedAcl | undefined;
}
export interface ArchiveCdnSettings {
    ArchiveS3Settings?: ArchiveS3Settings | undefined;
}
export interface OutputLocationRef {
    DestinationRefId?: string | undefined;
}
export interface ArchiveGroupSettings {
    ArchiveCdnSettings?: ArchiveCdnSettings | undefined;
    Destination?: OutputLocationRef | undefined;
    RolloverInterval?: number | undefined;
}
export interface FrameCaptureS3Settings {
    CannedAcl?: S3CannedAcl | undefined;
}
export interface FrameCaptureCdnSettings {
    FrameCaptureS3Settings?: FrameCaptureS3Settings | undefined;
}
export interface FrameCaptureGroupSettings {
    Destination?: OutputLocationRef | undefined;
    FrameCaptureCdnSettings?: FrameCaptureCdnSettings | undefined;
}
export type HlsAdMarkers = "ADOBE" | "ELEMENTAL" | "ELEMENTAL_SCTE35" | (string & {});
export type __listOfHlsAdMarkers = HlsAdMarkers[];
export type __integerMin1Max4 = number;
export type __stringMin3Max3 = string;
export interface CaptionLanguageMapping {
    CaptionChannel?: number | undefined;
    LanguageCode?: string | undefined;
    LanguageDescription?: string | undefined;
}
export type __listOfCaptionLanguageMapping = CaptionLanguageMapping[];
export type HlsCaptionLanguageSetting = "INSERT" | "NONE" | "OMIT" | (string & {});
export type HlsClientCache = "DISABLED" | "ENABLED" | (string & {});
export type HlsCodecSpecification = "RFC_4281" | "RFC_6381" | (string & {});
export type __stringMin32Max32 = string;
export type HlsDirectoryStructure = "SINGLE_DIRECTORY" | "SUBDIRECTORY_PER_STREAM" | (string & {});
export type HlsDiscontinuityTags = "INSERT" | "NEVER_INSERT" | (string & {});
export type HlsEncryptionType = "AES128" | "SAMPLE_AES" | (string & {});
export type __integerMin0Max600 = number;
export type HlsAkamaiHttpTransferMode = "CHUNKED" | "NON_CHUNKED" | (string & {});
export interface HlsAkamaiSettings {
    ConnectionRetryInterval?: number | undefined;
    FilecacheDuration?: number | undefined;
    HttpTransferMode?: HlsAkamaiHttpTransferMode | undefined;
    NumRetries?: number | undefined;
    RestartDelay?: number | undefined;
    Salt?: string | undefined;
    Token?: string | undefined;
}
export interface HlsBasicPutSettings {
    ConnectionRetryInterval?: number | undefined;
    FilecacheDuration?: number | undefined;
    NumRetries?: number | undefined;
    RestartDelay?: number | undefined;
}
export type HlsMediaStoreStorageClass = "TEMPORAL" | (string & {});
export interface HlsMediaStoreSettings {
    ConnectionRetryInterval?: number | undefined;
    FilecacheDuration?: number | undefined;
    MediaStoreStorageClass?: HlsMediaStoreStorageClass | undefined;
    NumRetries?: number | undefined;
    RestartDelay?: number | undefined;
}
export interface HlsS3Settings {
    CannedAcl?: S3CannedAcl | undefined;
}
export type HlsWebdavHttpTransferMode = "CHUNKED" | "NON_CHUNKED" | (string & {});
export interface HlsWebdavSettings {
    ConnectionRetryInterval?: number | undefined;
    FilecacheDuration?: number | undefined;
    HttpTransferMode?: HlsWebdavHttpTransferMode | undefined;
    NumRetries?: number | undefined;
    RestartDelay?: number | undefined;
}
export interface HlsCdnSettings {
    HlsAkamaiSettings?: HlsAkamaiSettings | undefined;
    HlsBasicPutSettings?: HlsBasicPutSettings | undefined;
    HlsMediaStoreSettings?: HlsMediaStoreSettings | undefined;
    HlsS3Settings?: HlsS3Settings | undefined;
    HlsWebdavSettings?: HlsWebdavSettings | undefined;
}
export type HlsId3SegmentTaggingState = "DISABLED" | "ENABLED" | (string & {});
export type IFrameOnlyPlaylistType = "DISABLED" | "STANDARD" | (string & {});
export type HlsIncompleteSegmentBehavior = "AUTO" | "SUPPRESS" | (string & {});
export type __integerMin3 = number;
export type InputLossActionForHlsOut = "EMIT_OUTPUT" | "PAUSE_OUTPUT" | (string & {});
export type HlsIvInManifest = "EXCLUDE" | "INCLUDE" | (string & {});
export type HlsIvSource = "EXPLICIT" | "FOLLOWS_SEGMENT_NUMBER" | (string & {});
export interface StaticKeySettings {
    KeyProviderServer?: InputLocation | undefined;
    StaticKeyValue?: string | redacted.Redacted<string> | undefined;
}
export interface KeyProviderSettings {
    StaticKeySettings?: StaticKeySettings | undefined;
}
export type HlsManifestCompression = "GZIP" | "NONE" | (string & {});
export type HlsManifestDurationFormat = "FLOATING_POINT" | "INTEGER" | (string & {});
export type HlsMode = "LIVE" | "VOD" | (string & {});
export type HlsOutputSelection = "MANIFESTS_AND_SEGMENTS" | "SEGMENTS_ONLY" | "VARIANT_MANIFESTS_AND_SEGMENTS" | (string & {});
export type HlsProgramDateTime = "EXCLUDE" | "INCLUDE" | (string & {});
export type HlsProgramDateTimeClock = "INITIALIZE_FROM_OUTPUT_TIMECODE" | "SYSTEM_CLOCK" | (string & {});
export type __integerMin0Max3600 = number;
export type HlsRedundantManifest = "DISABLED" | "ENABLED" | (string & {});
export type HlsSegmentationMode = "USE_INPUT_SEGMENTATION" | "USE_SEGMENT_DURATION" | (string & {});
export type HlsStreamInfResolution = "EXCLUDE" | "INCLUDE" | (string & {});
export type HlsTimedMetadataId3Frame = "NONE" | "PRIV" | "TDRL" | (string & {});
export type HlsTsFileMode = "SEGMENTED_FILES" | "SINGLE_FILE" | (string & {});
export interface HlsGroupSettings {
    AdMarkers?: HlsAdMarkers[] | undefined;
    BaseUrlContent?: string | undefined;
    BaseUrlContent1?: string | undefined;
    BaseUrlManifest?: string | undefined;
    BaseUrlManifest1?: string | undefined;
    CaptionLanguageMappings?: CaptionLanguageMapping[] | undefined;
    CaptionLanguageSetting?: HlsCaptionLanguageSetting | undefined;
    ClientCache?: HlsClientCache | undefined;
    CodecSpecification?: HlsCodecSpecification | undefined;
    ConstantIv?: string | undefined;
    Destination?: OutputLocationRef | undefined;
    DirectoryStructure?: HlsDirectoryStructure | undefined;
    DiscontinuityTags?: HlsDiscontinuityTags | undefined;
    EncryptionType?: HlsEncryptionType | undefined;
    HlsCdnSettings?: HlsCdnSettings | undefined;
    HlsId3SegmentTagging?: HlsId3SegmentTaggingState | undefined;
    IFrameOnlyPlaylists?: IFrameOnlyPlaylistType | undefined;
    IncompleteSegmentBehavior?: HlsIncompleteSegmentBehavior | undefined;
    IndexNSegments?: number | undefined;
    InputLossAction?: InputLossActionForHlsOut | undefined;
    IvInManifest?: HlsIvInManifest | undefined;
    IvSource?: HlsIvSource | undefined;
    KeepSegments?: number | undefined;
    KeyFormat?: string | undefined;
    KeyFormatVersions?: string | undefined;
    KeyProviderSettings?: KeyProviderSettings | undefined;
    ManifestCompression?: HlsManifestCompression | undefined;
    ManifestDurationFormat?: HlsManifestDurationFormat | undefined;
    MinSegmentLength?: number | undefined;
    Mode?: HlsMode | undefined;
    OutputSelection?: HlsOutputSelection | undefined;
    ProgramDateTime?: HlsProgramDateTime | undefined;
    ProgramDateTimeClock?: HlsProgramDateTimeClock | undefined;
    ProgramDateTimePeriod?: number | undefined;
    RedundantManifest?: HlsRedundantManifest | undefined;
    SegmentLength?: number | undefined;
    SegmentationMode?: HlsSegmentationMode | undefined;
    SegmentsPerSubdirectory?: number | undefined;
    StreamInfResolution?: HlsStreamInfResolution | undefined;
    TimedMetadataId3Frame?: HlsTimedMetadataId3Frame | undefined;
    TimedMetadataId3Period?: number | undefined;
    TimestampDeltaMilliseconds?: number | undefined;
    TsFileMode?: HlsTsFileMode | undefined;
}
export type CmafId3Behavior = "DISABLED" | "ENABLED" | (string & {});
export type CmafKLVBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type CmafNielsenId3Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type Scte35Type = "NONE" | "SCTE_35_WITHOUT_SEGMENTATION" | "SCTE_35_WITHOUT_IDR" | (string & {});
export type CmafIngestSegmentLengthUnits = "MILLISECONDS" | "SECONDS" | (string & {});
export type CmafTimedMetadataId3Frame = "NONE" | "PRIV" | "TDRL" | (string & {});
export type __integerMin0Max10000 = number;
export type CmafTimedMetadataPassthrough = "DISABLED" | "ENABLED" | (string & {});
export interface MediaPackageAdditionalDestinations {
    Destination?: OutputLocationRef | undefined;
}
export type __listOfMediaPackageAdditionalDestinations = MediaPackageAdditionalDestinations[];
export type __listOfOutputLocationRef = OutputLocationRef[];
export type __doubleMinNegative1Max5 = number;
export type __doubleMin32Max46 = number;
export interface AbWatermarkingCustomProfile {
    EmbeddingFrequency?: number | undefined;
    SceneCut?: number | undefined;
    TargetPsnr?: number | undefined;
}
export type __integerMin1Max511 = number;
export type __integerMin1Max1000 = number;
export type AbWatermarkingProfile = "CAMCORDING" | "CUSTOM" | "DEFAULT" | "HQ" | "MEZZANINE" | "ROBUST" | (string & {});
export type AbWatermarkerIdLength = "ID_2048" | "ID_512" | (string & {});
export interface MediaPackageV2AbWatermarkerIrdetoSettings {
    AdditionalDestinationsAlternateDestinations?: OutputLocationRef[] | undefined;
    AlternateDestination?: OutputLocationRef | undefined;
    CustomProfile?: AbWatermarkingCustomProfile | undefined;
    License?: string | undefined;
    OperatorId?: number | undefined;
    PolyPeriod?: number | undefined;
    Profile?: AbWatermarkingProfile | undefined;
    WatermarkIdLength?: AbWatermarkerIdLength | undefined;
}
export interface MediaPackageV2WatermarkingSettings {
    MediaPackageV2AbWatermarkerIrdetoSettings?: MediaPackageV2AbWatermarkerIrdetoSettings | undefined;
}
export type MediaPackageV2CaptionLanguageSetting = "AUTO" | "NONE" | (string & {});
export interface MediaPackageV2GroupSettings {
    CaptionLanguageMappings?: CaptionLanguageMapping[] | undefined;
    Id3Behavior?: CmafId3Behavior | undefined;
    KlvBehavior?: CmafKLVBehavior | undefined;
    NielsenId3Behavior?: CmafNielsenId3Behavior | undefined;
    Scte35Type?: Scte35Type | undefined;
    SegmentLength?: number | undefined;
    SegmentLengthUnits?: CmafIngestSegmentLengthUnits | undefined;
    TimedMetadataId3Frame?: CmafTimedMetadataId3Frame | undefined;
    TimedMetadataId3Period?: number | undefined;
    TimedMetadataPassthrough?: CmafTimedMetadataPassthrough | undefined;
    AdditionalDestinations?: MediaPackageAdditionalDestinations[] | undefined;
    WatermarkingSettings?: MediaPackageV2WatermarkingSettings | undefined;
    CaptionLanguageSetting?: MediaPackageV2CaptionLanguageSetting | undefined;
}
export interface MediaPackageGroupSettings {
    Destination?: OutputLocationRef | undefined;
    MediapackageV2GroupSettings?: MediaPackageV2GroupSettings | undefined;
}
export type SmoothGroupAudioOnlyTimecodeControl = "PASSTHROUGH" | "USE_CONFIGURED_CLOCK" | (string & {});
export type SmoothGroupCertificateMode = "SELF_SIGNED" | "VERIFY_AUTHENTICITY" | (string & {});
export type SmoothGroupEventIdMode = "NO_EVENT_ID" | "USE_CONFIGURED" | "USE_TIMESTAMP" | (string & {});
export type SmoothGroupEventStopBehavior = "NONE" | "SEND_EOS" | (string & {});
export type InputLossActionForMsSmoothOut = "EMIT_OUTPUT" | "PAUSE_OUTPUT" | (string & {});
export type SmoothGroupSegmentationMode = "USE_INPUT_SEGMENTATION" | "USE_SEGMENT_DURATION" | (string & {});
export type SmoothGroupSparseTrackType = "NONE" | "SCTE_35" | "SCTE_35_WITHOUT_SEGMENTATION" | (string & {});
export type SmoothGroupStreamManifestBehavior = "DO_NOT_SEND" | "SEND" | (string & {});
export type SmoothGroupTimestampOffsetMode = "USE_CONFIGURED_OFFSET" | "USE_EVENT_START_DATE" | (string & {});
export interface MsSmoothGroupSettings {
    AcquisitionPointId?: string | undefined;
    AudioOnlyTimecodeControl?: SmoothGroupAudioOnlyTimecodeControl | undefined;
    CertificateMode?: SmoothGroupCertificateMode | undefined;
    ConnectionRetryInterval?: number | undefined;
    Destination?: OutputLocationRef | undefined;
    EventId?: string | undefined;
    EventIdMode?: SmoothGroupEventIdMode | undefined;
    EventStopBehavior?: SmoothGroupEventStopBehavior | undefined;
    FilecacheDuration?: number | undefined;
    FragmentLength?: number | undefined;
    InputLossAction?: InputLossActionForMsSmoothOut | undefined;
    NumRetries?: number | undefined;
    RestartDelay?: number | undefined;
    SegmentationMode?: SmoothGroupSegmentationMode | undefined;
    SendDelayMs?: number | undefined;
    SparseTrackType?: SmoothGroupSparseTrackType | undefined;
    StreamManifestBehavior?: SmoothGroupStreamManifestBehavior | undefined;
    TimestampOffset?: string | undefined;
    TimestampOffsetMode?: SmoothGroupTimestampOffsetMode | undefined;
}
export interface MultiplexGroupSettings {
}
export type RtmpAdMarkers = "ON_CUE_POINT_SCTE35" | (string & {});
export type __listOfRtmpAdMarkers = RtmpAdMarkers[];
export type AuthenticationScheme = "AKAMAI" | "COMMON" | (string & {});
export type RtmpCacheFullBehavior = "DISCONNECT_IMMEDIATELY" | "WAIT_FOR_SERVER" | (string & {});
export type __integerMin30 = number;
export type RtmpCaptionData = "ALL" | "FIELD1_608" | "FIELD1_AND_FIELD2_608" | (string & {});
export type InputLossActionForRtmpOut = "EMIT_OUTPUT" | "PAUSE_OUTPUT" | (string & {});
export type IncludeFillerNalUnits = "AUTO" | "DROP" | "INCLUDE" | (string & {});
export interface RtmpGroupSettings {
    AdMarkers?: RtmpAdMarkers[] | undefined;
    AuthenticationScheme?: AuthenticationScheme | undefined;
    CacheFullBehavior?: RtmpCacheFullBehavior | undefined;
    CacheLength?: number | undefined;
    CaptionData?: RtmpCaptionData | undefined;
    InputLossAction?: InputLossActionForRtmpOut | undefined;
    RestartDelay?: number | undefined;
    IncludeFillerNalUnits?: IncludeFillerNalUnits | undefined;
}
export type InputLossActionForUdpOut = "DROP_PROGRAM" | "DROP_TS" | "EMIT_PROGRAM" | (string & {});
export type UdpTimedMetadataId3Frame = "NONE" | "PRIV" | "TDRL" | (string & {});
export interface UdpGroupSettings {
    InputLossAction?: InputLossActionForUdpOut | undefined;
    TimedMetadataId3Frame?: UdpTimedMetadataId3Frame | undefined;
    TimedMetadataId3Period?: number | undefined;
}
export type __integerMin0Max2000 = number;
export type __stringMax100 = string;
export interface CmafIngestCaptionLanguageMapping {
    CaptionChannel?: number | undefined;
    LanguageCode?: string | undefined;
}
export type __listOfCmafIngestCaptionLanguageMapping = CmafIngestCaptionLanguageMapping[];
export interface AdditionalDestinations {
    Destination?: OutputLocationRef | undefined;
}
export type __listOfAdditionalDestinations = AdditionalDestinations[];
export interface CmafIngestAbWatermarkerIrdetoSettings {
    AdditionalDestinationsAlternateDestinations?: OutputLocationRef[] | undefined;
    AlternateDestination?: OutputLocationRef | undefined;
    CustomProfile?: AbWatermarkingCustomProfile | undefined;
    License?: string | undefined;
    OperatorId?: number | undefined;
    PolyPeriod?: number | undefined;
    Profile?: AbWatermarkingProfile | undefined;
    WatermarkIdLength?: AbWatermarkerIdLength | undefined;
}
export interface CmafIngestWatermarkingSettings {
    CmafIngestAbWatermarkerIrdetoSettings?: CmafIngestAbWatermarkerIrdetoSettings | undefined;
}
export interface CmafIngestGroupSettings {
    Destination?: OutputLocationRef | undefined;
    NielsenId3Behavior?: CmafNielsenId3Behavior | undefined;
    Scte35Type?: Scte35Type | undefined;
    SegmentLength?: number | undefined;
    SegmentLengthUnits?: CmafIngestSegmentLengthUnits | undefined;
    SendDelayMs?: number | undefined;
    KlvBehavior?: CmafKLVBehavior | undefined;
    KlvNameModifier?: string | undefined;
    NielsenId3NameModifier?: string | undefined;
    Scte35NameModifier?: string | undefined;
    Id3Behavior?: CmafId3Behavior | undefined;
    Id3NameModifier?: string | undefined;
    CaptionLanguageMappings?: CmafIngestCaptionLanguageMapping[] | undefined;
    TimedMetadataId3Frame?: CmafTimedMetadataId3Frame | undefined;
    TimedMetadataId3Period?: number | undefined;
    TimedMetadataPassthrough?: CmafTimedMetadataPassthrough | undefined;
    AdditionalDestinations?: AdditionalDestinations[] | undefined;
    WatermarkingSettings?: CmafIngestWatermarkingSettings | undefined;
}
export interface SrtGroupSettings {
    InputLossAction?: InputLossActionForUdpOut | undefined;
}
export interface MediaConnectRouterGroupSettings {
    AvailabilityZones?: string[] | undefined;
}
export interface OutputGroupSettings {
    ArchiveGroupSettings?: ArchiveGroupSettings | undefined;
    FrameCaptureGroupSettings?: FrameCaptureGroupSettings | undefined;
    HlsGroupSettings?: HlsGroupSettings | undefined;
    MediaPackageGroupSettings?: MediaPackageGroupSettings | undefined;
    MsSmoothGroupSettings?: MsSmoothGroupSettings | undefined;
    MultiplexGroupSettings?: MultiplexGroupSettings | undefined;
    RtmpGroupSettings?: RtmpGroupSettings | undefined;
    UdpGroupSettings?: UdpGroupSettings | undefined;
    CmafIngestGroupSettings?: CmafIngestGroupSettings | undefined;
    SrtGroupSettings?: SrtGroupSettings | undefined;
    MediaConnectRouterGroupSettings?: MediaConnectRouterGroupSettings | undefined;
}
export type __stringMin1Max255 = string;
export type M2tsAbsentInputAudioBehavior = "DROP" | "ENCODE_SILENCE" | (string & {});
export type M2tsArib = "DISABLED" | "ENABLED" | (string & {});
export type M2tsAribCaptionsPidControl = "AUTO" | "USE_CONFIGURED" | (string & {});
export type M2tsAudioBufferModel = "ATSC" | "DVB" | (string & {});
export type M2tsAudioStreamType = "ATSC" | "DVB" | (string & {});
export type M2tsBufferModel = "MULTIPLEX" | "NONE" | (string & {});
export type M2tsCcDescriptor = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin0Max65536 = number;
export type __stringMin1Max256 = string;
export type __integerMin25Max10000 = number;
export interface DvbNitSettings {
    NetworkId?: number | undefined;
    NetworkName?: string | undefined;
    RepInterval?: number | undefined;
}
export type DvbSdtOutputSdt = "SDT_FOLLOW" | "SDT_FOLLOW_IF_PRESENT" | "SDT_MANUAL" | "SDT_NONE" | (string & {});
export type __integerMin25Max2000 = number;
export interface DvbSdtSettings {
    OutputSdt?: DvbSdtOutputSdt | undefined;
    RepInterval?: number | undefined;
    ServiceName?: string | undefined;
    ServiceProviderName?: string | undefined;
}
export type __integerMin1000Max30000 = number;
export interface DvbTdtSettings {
    RepInterval?: number | undefined;
}
export type M2tsEbifControl = "NONE" | "PASSTHROUGH" | (string & {});
export type M2tsAudioInterval = "VIDEO_AND_FIXED_INTERVALS" | "VIDEO_INTERVAL" | (string & {});
export type M2tsEbpPlacement = "VIDEO_AND_AUDIO_PIDS" | "VIDEO_PID" | (string & {});
export type M2tsEsRateInPes = "EXCLUDE" | "INCLUDE" | (string & {});
export type __doubleMin0 = number;
export type M2tsKlv = "NONE" | "PASSTHROUGH" | (string & {});
export type M2tsNielsenId3Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type __integerMin0Max1000 = number;
export type M2tsPcrControl = "CONFIGURED_PCR_PERIOD" | "PCR_EVERY_PES_PACKET" | (string & {});
export type __integerMin0Max500 = number;
export type __integerMin0Max65535 = number;
export type M2tsRateMode = "CBR" | "VBR" | (string & {});
export type M2tsScte35Control = "NONE" | "PASSTHROUGH" | "SCTE_35_WITHOUT_IDR" | (string & {});
export type M2tsSegmentationMarkers = "EBP" | "EBP_LEGACY" | "NONE" | "PSI_SEGSTART" | "RAI_ADAPT" | "RAI_SEGSTART" | (string & {});
export type M2tsSegmentationStyle = "MAINTAIN_CADENCE" | "RESET_CADENCE" | (string & {});
export type __doubleMin1 = number;
export type M2tsTimedMetadataBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type __doubleMin0Max5000 = number;
export interface M2tsSettings {
    AbsentInputAudioBehavior?: M2tsAbsentInputAudioBehavior | undefined;
    Arib?: M2tsArib | undefined;
    AribCaptionsPid?: string | undefined;
    AribCaptionsPidControl?: M2tsAribCaptionsPidControl | undefined;
    AudioBufferModel?: M2tsAudioBufferModel | undefined;
    AudioFramesPerPes?: number | undefined;
    AudioPids?: string | undefined;
    AudioStreamType?: M2tsAudioStreamType | undefined;
    Bitrate?: number | undefined;
    BufferModel?: M2tsBufferModel | undefined;
    CcDescriptor?: M2tsCcDescriptor | undefined;
    DvbNitSettings?: DvbNitSettings | undefined;
    DvbSdtSettings?: DvbSdtSettings | undefined;
    DvbSubPids?: string | undefined;
    DvbTdtSettings?: DvbTdtSettings | undefined;
    DvbTeletextPid?: string | undefined;
    Ebif?: M2tsEbifControl | undefined;
    EbpAudioInterval?: M2tsAudioInterval | undefined;
    EbpLookaheadMs?: number | undefined;
    EbpPlacement?: M2tsEbpPlacement | undefined;
    EcmPid?: string | undefined;
    EsRateInPes?: M2tsEsRateInPes | undefined;
    EtvPlatformPid?: string | undefined;
    EtvSignalPid?: string | undefined;
    FragmentTime?: number | undefined;
    Klv?: M2tsKlv | undefined;
    KlvDataPids?: string | undefined;
    NielsenId3Behavior?: M2tsNielsenId3Behavior | undefined;
    NullPacketBitrate?: number | undefined;
    PatInterval?: number | undefined;
    PcrControl?: M2tsPcrControl | undefined;
    PcrPeriod?: number | undefined;
    PcrPid?: string | undefined;
    PmtInterval?: number | undefined;
    PmtPid?: string | undefined;
    ProgramNum?: number | undefined;
    RateMode?: M2tsRateMode | undefined;
    Scte27Pids?: string | undefined;
    Scte35Control?: M2tsScte35Control | undefined;
    Scte35Pid?: string | undefined;
    SegmentationMarkers?: M2tsSegmentationMarkers | undefined;
    SegmentationStyle?: M2tsSegmentationStyle | undefined;
    SegmentationTime?: number | undefined;
    TimedMetadataBehavior?: M2tsTimedMetadataBehavior | undefined;
    TimedMetadataPid?: string | undefined;
    TransportStreamId?: number | undefined;
    VideoPid?: string | undefined;
    Scte35PrerollPullupMilliseconds?: number | undefined;
}
export interface RawSettings {
}
export interface ArchiveContainerSettings {
    M2tsSettings?: M2tsSettings | undefined;
    RawSettings?: RawSettings | undefined;
}
export interface ArchiveOutputSettings {
    ContainerSettings?: ArchiveContainerSettings | undefined;
    Extension?: string | undefined;
    NameModifier?: string | undefined;
}
export interface FrameCaptureOutputSettings {
    NameModifier?: string | undefined;
}
export type HlsH265PackagingType = "HEV1" | "HVC1" | (string & {});
export type AudioOnlyHlsTrackType = "ALTERNATE_AUDIO_AUTO_SELECT" | "ALTERNATE_AUDIO_AUTO_SELECT_DEFAULT" | "ALTERNATE_AUDIO_NOT_AUTO_SELECT" | "AUDIO_ONLY_VARIANT_STREAM" | (string & {});
export type AudioOnlyHlsSegmentType = "AAC" | "FMP4" | (string & {});
export interface AudioOnlyHlsSettings {
    AudioGroupId?: string | undefined;
    AudioOnlyImage?: InputLocation | undefined;
    AudioTrackType?: AudioOnlyHlsTrackType | undefined;
    SegmentType?: AudioOnlyHlsSegmentType | undefined;
}
export type Fmp4NielsenId3Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type Fmp4TimedMetadataBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export interface Fmp4HlsSettings {
    AudioRenditionSets?: string | undefined;
    NielsenId3Behavior?: Fmp4NielsenId3Behavior | undefined;
    TimedMetadataBehavior?: Fmp4TimedMetadataBehavior | undefined;
}
export interface FrameCaptureHlsSettings {
}
export type M3u8NielsenId3Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type M3u8PcrControl = "CONFIGURED_PCR_PERIOD" | "PCR_EVERY_PES_PACKET" | (string & {});
export type M3u8Scte35Behavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type M3u8TimedMetadataBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export type M3u8KlvBehavior = "NO_PASSTHROUGH" | "PASSTHROUGH" | (string & {});
export interface M3u8Settings {
    AudioFramesPerPes?: number | undefined;
    AudioPids?: string | undefined;
    EcmPid?: string | undefined;
    NielsenId3Behavior?: M3u8NielsenId3Behavior | undefined;
    PatInterval?: number | undefined;
    PcrControl?: M3u8PcrControl | undefined;
    PcrPeriod?: number | undefined;
    PcrPid?: string | undefined;
    PmtInterval?: number | undefined;
    PmtPid?: string | undefined;
    ProgramNum?: number | undefined;
    Scte35Behavior?: M3u8Scte35Behavior | undefined;
    Scte35Pid?: string | undefined;
    TimedMetadataBehavior?: M3u8TimedMetadataBehavior | undefined;
    TimedMetadataPid?: string | undefined;
    TransportStreamId?: number | undefined;
    VideoPid?: string | undefined;
    KlvBehavior?: M3u8KlvBehavior | undefined;
    KlvDataPids?: string | undefined;
}
export interface StandardHlsSettings {
    AudioRenditionSets?: string | undefined;
    M3u8Settings?: M3u8Settings | undefined;
}
export interface HlsSettings {
    AudioOnlyHlsSettings?: AudioOnlyHlsSettings | undefined;
    Fmp4HlsSettings?: Fmp4HlsSettings | undefined;
    FrameCaptureHlsSettings?: FrameCaptureHlsSettings | undefined;
    StandardHlsSettings?: StandardHlsSettings | undefined;
}
export interface HlsOutputSettings {
    H265PackagingType?: HlsH265PackagingType | undefined;
    HlsSettings?: HlsSettings | undefined;
    NameModifier?: string | undefined;
    SegmentModifier?: string | undefined;
}
export type HlsAutoSelect = "NO" | "OMIT" | "YES" | (string & {});
export type HlsDefault = "NO" | "OMIT" | "YES" | (string & {});
export type OutputUsage = "MULTIVIEW_EQUAL_SIZE_VIEW" | "MULTIVIEW_PRIMARY_VIEW" | "MULTIVIEW_SECONDARY_VIEW" | (string & {});
export type __listOfOutputUsage = OutputUsage[];
export interface MediaPackageV2DestinationSettings {
    AudioGroupId?: string | undefined;
    AudioRenditionSets?: string | undefined;
    HlsAutoSelect?: HlsAutoSelect | undefined;
    HlsDefault?: HlsDefault | undefined;
    OutputUsage?: OutputUsage[] | undefined;
}
export interface MediaPackageOutputSettings {
    MediaPackageV2DestinationSettings?: MediaPackageV2DestinationSettings | undefined;
}
export type MsSmoothH265PackagingType = "HEV1" | "HVC1" | (string & {});
export interface MsSmoothOutputSettings {
    H265PackagingType?: MsSmoothH265PackagingType | undefined;
    NameModifier?: string | undefined;
}
export interface MultiplexM2tsSettings {
    AbsentInputAudioBehavior?: M2tsAbsentInputAudioBehavior | undefined;
    Arib?: M2tsArib | undefined;
    AudioBufferModel?: M2tsAudioBufferModel | undefined;
    AudioFramesPerPes?: number | undefined;
    AudioStreamType?: M2tsAudioStreamType | undefined;
    CcDescriptor?: M2tsCcDescriptor | undefined;
    Ebif?: M2tsEbifControl | undefined;
    EsRateInPes?: M2tsEsRateInPes | undefined;
    Klv?: M2tsKlv | undefined;
    NielsenId3Behavior?: M2tsNielsenId3Behavior | undefined;
    PcrControl?: M2tsPcrControl | undefined;
    PcrPeriod?: number | undefined;
    Scte35Control?: M2tsScte35Control | undefined;
    Scte35PrerollPullupMilliseconds?: number | undefined;
}
export interface MultiplexContainerSettings {
    MultiplexM2tsSettings?: MultiplexM2tsSettings | undefined;
}
export interface MultiplexOutputSettings {
    Destination?: OutputLocationRef | undefined;
    ContainerSettings?: MultiplexContainerSettings | undefined;
}
export type RtmpOutputCertificateMode = "SELF_SIGNED" | "VERIFY_AUTHENTICITY" | (string & {});
export interface RtmpOutputSettings {
    CertificateMode?: RtmpOutputCertificateMode | undefined;
    ConnectionRetryInterval?: number | undefined;
    Destination?: OutputLocationRef | undefined;
    NumRetries?: number | undefined;
}
export interface UdpContainerSettings {
    M2tsSettings?: M2tsSettings | undefined;
}
export type __integerMin4Max20 = number;
export type FecOutputIncludeFec = "COLUMN" | "COLUMN_AND_ROW" | (string & {});
export type __integerMin1Max20 = number;
export interface FecOutputSettings {
    ColumnDepth?: number | undefined;
    IncludeFec?: FecOutputIncludeFec | undefined;
    RowLength?: number | undefined;
}
export interface UdpOutputSettings {
    BufferMsec?: number | undefined;
    ContainerSettings?: UdpContainerSettings | undefined;
    Destination?: OutputLocationRef | undefined;
    FecOutputSettings?: FecOutputSettings | undefined;
}
export interface CmafIngestOutputSettings {
    NameModifier?: string | undefined;
}
export type SrtEncryptionType = "AES128" | "AES192" | "AES256" | (string & {});
export type __integerMin40Max16000 = number;
export interface SrtOutputSettings {
    BufferMsec?: number | undefined;
    ContainerSettings?: UdpContainerSettings | undefined;
    Destination?: OutputLocationRef | undefined;
    EncryptionType?: SrtEncryptionType | undefined;
    Latency?: number | undefined;
}
export interface MediaConnectRouterOutputConnectionMap {
    Pipeline0?: string | undefined;
    Pipeline1?: string | undefined;
}
export interface MediaConnectRouterContainerSettings {
    M2tsSettings?: M2tsSettings | undefined;
}
export interface MediaConnectRouterOutputSettings {
    ConnectedRouterInputs?: MediaConnectRouterOutputConnectionMap | undefined;
    ContainerSettings?: MediaConnectRouterContainerSettings | undefined;
    Destination?: OutputLocationRef | undefined;
}
export interface OutputSettings {
    ArchiveOutputSettings?: ArchiveOutputSettings | undefined;
    FrameCaptureOutputSettings?: FrameCaptureOutputSettings | undefined;
    HlsOutputSettings?: HlsOutputSettings | undefined;
    MediaPackageOutputSettings?: MediaPackageOutputSettings | undefined;
    MsSmoothOutputSettings?: MsSmoothOutputSettings | undefined;
    MultiplexOutputSettings?: MultiplexOutputSettings | undefined;
    RtmpOutputSettings?: RtmpOutputSettings | undefined;
    UdpOutputSettings?: UdpOutputSettings | undefined;
    CmafIngestOutputSettings?: CmafIngestOutputSettings | undefined;
    SrtOutputSettings?: SrtOutputSettings | undefined;
    MediaConnectRouterOutputSettings?: MediaConnectRouterOutputSettings | undefined;
}
export interface Output {
    AudioDescriptionNames?: string[] | undefined;
    CaptionDescriptionNames?: string[] | undefined;
    OutputName?: string | undefined;
    OutputSettings?: OutputSettings | undefined;
    VideoDescriptionName?: string | undefined;
}
export type __listOfOutput = Output[];
export interface OutputGroup {
    Name?: string | undefined;
    OutputGroupSettings?: OutputGroupSettings | undefined;
    Outputs?: Output[] | undefined;
}
export type __listOfOutputGroup = OutputGroup[];
export type TimecodeConfigSource = "EMBEDDED" | "SYSTEMCLOCK" | "ZEROBASED" | (string & {});
export type __integerMin1Max1000000 = number;
export interface TimecodeConfig {
    Source?: TimecodeConfigSource | undefined;
    SyncThreshold?: number | undefined;
}
export type __integerMin1Max3600000 = number;
export type FrameCaptureIntervalUnit = "MILLISECONDS" | "SECONDS" | (string & {});
export type TimecodeBurninFontSize = "EXTRA_SMALL_10" | "LARGE_48" | "MEDIUM_32" | "SMALL_16" | (string & {});
export type TimecodeBurninPosition = "BOTTOM_CENTER" | "BOTTOM_LEFT" | "BOTTOM_RIGHT" | "MIDDLE_CENTER" | "MIDDLE_LEFT" | "MIDDLE_RIGHT" | "TOP_CENTER" | "TOP_LEFT" | "TOP_RIGHT" | (string & {});
export interface TimecodeBurninSettings {
    FontSize?: TimecodeBurninFontSize | undefined;
    Position?: TimecodeBurninPosition | undefined;
    Prefix?: string | undefined;
}
export interface FrameCaptureSettings {
    CaptureInterval?: number | undefined;
    CaptureIntervalUnits?: FrameCaptureIntervalUnit | undefined;
    TimecodeBurninSettings?: TimecodeBurninSettings | undefined;
}
export type H264AdaptiveQuantization = "AUTO" | "HIGH" | "HIGHER" | "LOW" | "MAX" | "MEDIUM" | "OFF" | (string & {});
export type AfdSignaling = "AUTO" | "FIXED" | "NONE" | (string & {});
export type __integerMin1000 = number;
export type H264ColorMetadata = "IGNORE" | "INSERT" | (string & {});
export interface ColorSpacePassthroughSettings {
}
export interface Rec601Settings {
}
export interface Rec709Settings {
}
export interface H264ColorSpaceSettings {
    ColorSpacePassthroughSettings?: ColorSpacePassthroughSettings | undefined;
    Rec601Settings?: Rec601Settings | undefined;
    Rec709Settings?: Rec709Settings | undefined;
}
export type H264EntropyEncoding = "CABAC" | "CAVLC" | (string & {});
export type TemporalFilterPostFilterSharpening = "AUTO" | "DISABLED" | "ENABLED" | (string & {});
export type TemporalFilterStrength = "AUTO" | "STRENGTH_1" | "STRENGTH_2" | "STRENGTH_3" | "STRENGTH_4" | "STRENGTH_5" | "STRENGTH_6" | "STRENGTH_7" | "STRENGTH_8" | "STRENGTH_9" | "STRENGTH_10" | "STRENGTH_11" | "STRENGTH_12" | "STRENGTH_13" | "STRENGTH_14" | "STRENGTH_15" | "STRENGTH_16" | (string & {});
export interface TemporalFilterSettings {
    PostFilterSharpening?: TemporalFilterPostFilterSharpening | undefined;
    Strength?: TemporalFilterStrength | undefined;
}
export type BandwidthReductionPostFilterSharpening = "DISABLED" | "SHARPENING_1" | "SHARPENING_2" | "SHARPENING_3" | (string & {});
export type BandwidthReductionFilterStrength = "AUTO" | "STRENGTH_1" | "STRENGTH_2" | "STRENGTH_3" | "STRENGTH_4" | (string & {});
export interface BandwidthReductionFilterSettings {
    PostFilterSharpening?: BandwidthReductionPostFilterSharpening | undefined;
    Strength?: BandwidthReductionFilterStrength | undefined;
}
export interface AutoFilterSettings {
}
export interface NoneFilterSettings {
}
export type PerceptualFilterStrength = "STRENGTH_1" | "STRENGTH_2" | (string & {});
export interface PerceptualFilterSettings {
    Strength?: PerceptualFilterStrength | undefined;
}
export interface H264FilterSettings {
    TemporalFilterSettings?: TemporalFilterSettings | undefined;
    BandwidthReductionFilterSettings?: BandwidthReductionFilterSettings | undefined;
    AutoFilterSettings?: AutoFilterSettings | undefined;
    NoneFilterSettings?: NoneFilterSettings | undefined;
    PerceptualFilterSettings?: PerceptualFilterSettings | undefined;
}
export type FixedAfd = "AFD_0000" | "AFD_0010" | "AFD_0011" | "AFD_0100" | "AFD_1000" | "AFD_1001" | "AFD_1010" | "AFD_1011" | "AFD_1101" | "AFD_1110" | "AFD_1111" | (string & {});
export type H264FlickerAq = "DISABLED" | "ENABLED" | (string & {});
export type H264ForceFieldPictures = "DISABLED" | "ENABLED" | (string & {});
export type H264FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H264GopBReference = "DISABLED" | "ENABLED" | (string & {});
export type H264GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type H264Level = "H264_LEVEL_1" | "H264_LEVEL_1_1" | "H264_LEVEL_1_2" | "H264_LEVEL_1_3" | "H264_LEVEL_2" | "H264_LEVEL_2_1" | "H264_LEVEL_2_2" | "H264_LEVEL_3" | "H264_LEVEL_3_1" | "H264_LEVEL_3_2" | "H264_LEVEL_4" | "H264_LEVEL_4_1" | "H264_LEVEL_4_2" | "H264_LEVEL_5" | "H264_LEVEL_5_1" | "H264_LEVEL_5_2" | "H264_LEVEL_AUTO" | (string & {});
export type H264LookAheadRateControl = "HIGH" | "LOW" | "MEDIUM" | (string & {});
export type __integerMin0Max30 = number;
export type __integerMin1Max6 = number;
export type H264ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H264Profile = "BASELINE" | "HIGH" | "HIGH_10BIT" | "HIGH_422" | "HIGH_422_10BIT" | "MAIN" | (string & {});
export type H264QualityLevel = "ENHANCED_QUALITY" | "STANDARD_QUALITY" | (string & {});
export type __integerMin1Max10 = number;
export type H264RateControlMode = "CBR" | "MULTIPLEX" | "QVBR" | "VBR" | (string & {});
export type H264ScanType = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type H264SceneChangeDetect = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin1Max32 = number;
export type __integerMin0Max128 = number;
export type H264SpatialAq = "DISABLED" | "ENABLED" | (string & {});
export type H264SubGopLength = "DYNAMIC" | "FIXED" | (string & {});
export type H264Syntax = "DEFAULT" | "RP2027" | (string & {});
export type H264TemporalAq = "DISABLED" | "ENABLED" | (string & {});
export type H264TimecodeInsertionBehavior = "DISABLED" | "PIC_TIMING_SEI" | (string & {});
export type __integerMin1Max51 = number;
export type H264AllowExplicitWeightedPrediction = "DISABLED" | "ENABLED" | (string & {});
export interface H264Settings {
    AdaptiveQuantization?: H264AdaptiveQuantization | undefined;
    AfdSignaling?: AfdSignaling | undefined;
    Bitrate?: number | undefined;
    BufFillPct?: number | undefined;
    BufSize?: number | undefined;
    ColorMetadata?: H264ColorMetadata | undefined;
    ColorSpaceSettings?: H264ColorSpaceSettings | undefined;
    EntropyEncoding?: H264EntropyEncoding | undefined;
    FilterSettings?: H264FilterSettings | undefined;
    FixedAfd?: FixedAfd | undefined;
    FlickerAq?: H264FlickerAq | undefined;
    ForceFieldPictures?: H264ForceFieldPictures | undefined;
    FramerateControl?: H264FramerateControl | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopBReference?: H264GopBReference | undefined;
    GopClosedCadence?: number | undefined;
    GopNumBFrames?: number | undefined;
    GopSize?: number | undefined;
    GopSizeUnits?: H264GopSizeUnits | undefined;
    Level?: H264Level | undefined;
    LookAheadRateControl?: H264LookAheadRateControl | undefined;
    MaxBitrate?: number | undefined;
    MinIInterval?: number | undefined;
    NumRefFrames?: number | undefined;
    ParControl?: H264ParControl | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    Profile?: H264Profile | undefined;
    QualityLevel?: H264QualityLevel | undefined;
    QvbrQualityLevel?: number | undefined;
    RateControlMode?: H264RateControlMode | undefined;
    ScanType?: H264ScanType | undefined;
    SceneChangeDetect?: H264SceneChangeDetect | undefined;
    Slices?: number | undefined;
    Softness?: number | undefined;
    SpatialAq?: H264SpatialAq | undefined;
    SubgopLength?: H264SubGopLength | undefined;
    Syntax?: H264Syntax | undefined;
    TemporalAq?: H264TemporalAq | undefined;
    TimecodeInsertion?: H264TimecodeInsertionBehavior | undefined;
    TimecodeBurninSettings?: TimecodeBurninSettings | undefined;
    MinQp?: number | undefined;
    MinBitrate?: number | undefined;
    AllowExplicitWeightedPrediction?: H264AllowExplicitWeightedPrediction | undefined;
}
export type H265AdaptiveQuantization = "AUTO" | "HIGH" | "HIGHER" | "LOW" | "MAX" | "MEDIUM" | "OFF" | (string & {});
export type H265AlternativeTransferFunction = "INSERT" | "OMIT" | (string & {});
export type __integerMin100000Max40000000 = number;
export type __integerMin100000Max80000000 = number;
export type H265ColorMetadata = "IGNORE" | "INSERT" | (string & {});
export interface DolbyVision81Settings {
}
export type __integerMin0Max32768 = number;
export interface Hdr10Settings {
    MaxCll?: number | undefined;
    MaxFall?: number | undefined;
}
export interface Hlg2020Settings {
}
export interface H265ColorSpaceSettings {
    ColorSpacePassthroughSettings?: ColorSpacePassthroughSettings | undefined;
    DolbyVision81Settings?: DolbyVision81Settings | undefined;
    Hdr10Settings?: Hdr10Settings | undefined;
    Rec601Settings?: Rec601Settings | undefined;
    Rec709Settings?: Rec709Settings | undefined;
    Hlg2020Settings?: Hlg2020Settings | undefined;
}
export interface H265FilterSettings {
    TemporalFilterSettings?: TemporalFilterSettings | undefined;
    BandwidthReductionFilterSettings?: BandwidthReductionFilterSettings | undefined;
    AutoFilterSettings?: AutoFilterSettings | undefined;
    NoneFilterSettings?: NoneFilterSettings | undefined;
    PerceptualFilterSettings?: PerceptualFilterSettings | undefined;
}
export type H265FlickerAq = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin1Max3003 = number;
export type H265GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type H265Level = "H265_LEVEL_1" | "H265_LEVEL_2" | "H265_LEVEL_2_1" | "H265_LEVEL_3" | "H265_LEVEL_3_1" | "H265_LEVEL_4" | "H265_LEVEL_4_1" | "H265_LEVEL_5" | "H265_LEVEL_5_1" | "H265_LEVEL_5_2" | "H265_LEVEL_6" | "H265_LEVEL_6_1" | "H265_LEVEL_6_2" | "H265_LEVEL_AUTO" | (string & {});
export type H265LookAheadRateControl = "HIGH" | "LOW" | "MEDIUM" | (string & {});
export type H265Profile = "MAIN" | "MAIN_10BIT" | (string & {});
export type H265RateControlMode = "CBR" | "MULTIPLEX" | "QVBR" | (string & {});
export type H265ScanType = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type H265SceneChangeDetect = "DISABLED" | "ENABLED" | (string & {});
export type H265Tier = "HIGH" | "MAIN" | (string & {});
export type H265TimecodeInsertionBehavior = "DISABLED" | "PIC_TIMING_SEI" | (string & {});
export type H265MvOverPictureBoundaries = "DISABLED" | "ENABLED" | (string & {});
export type H265MvTemporalPredictor = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin64Max2160 = number;
export type H265TilePadding = "NONE" | "PADDED" | (string & {});
export type __integerMin256Max3840 = number;
export type H265TreeblockSize = "AUTO" | "TREE_SIZE_32X32" | (string & {});
export type H265Deblocking = "DISABLED" | "ENABLED" | (string & {});
export type H265GopBReference = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin0Max3 = number;
export type __integerMin0Max40000000 = number;
export type H265SubGopLength = "DYNAMIC" | "FIXED" | (string & {});
export interface H265Settings {
    AdaptiveQuantization?: H265AdaptiveQuantization | undefined;
    AfdSignaling?: AfdSignaling | undefined;
    AlternativeTransferFunction?: H265AlternativeTransferFunction | undefined;
    Bitrate?: number | undefined;
    BufSize?: number | undefined;
    ColorMetadata?: H265ColorMetadata | undefined;
    ColorSpaceSettings?: H265ColorSpaceSettings | undefined;
    FilterSettings?: H265FilterSettings | undefined;
    FixedAfd?: FixedAfd | undefined;
    FlickerAq?: H265FlickerAq | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopClosedCadence?: number | undefined;
    GopSize?: number | undefined;
    GopSizeUnits?: H265GopSizeUnits | undefined;
    Level?: H265Level | undefined;
    LookAheadRateControl?: H265LookAheadRateControl | undefined;
    MaxBitrate?: number | undefined;
    MinIInterval?: number | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    Profile?: H265Profile | undefined;
    QvbrQualityLevel?: number | undefined;
    RateControlMode?: H265RateControlMode | undefined;
    ScanType?: H265ScanType | undefined;
    SceneChangeDetect?: H265SceneChangeDetect | undefined;
    Slices?: number | undefined;
    Tier?: H265Tier | undefined;
    TimecodeInsertion?: H265TimecodeInsertionBehavior | undefined;
    TimecodeBurninSettings?: TimecodeBurninSettings | undefined;
    MvOverPictureBoundaries?: H265MvOverPictureBoundaries | undefined;
    MvTemporalPredictor?: H265MvTemporalPredictor | undefined;
    TileHeight?: number | undefined;
    TilePadding?: H265TilePadding | undefined;
    TileWidth?: number | undefined;
    TreeblockSize?: H265TreeblockSize | undefined;
    MinQp?: number | undefined;
    Deblocking?: H265Deblocking | undefined;
    GopBReference?: H265GopBReference | undefined;
    GopNumBFrames?: number | undefined;
    MinBitrate?: number | undefined;
    SubgopLength?: H265SubGopLength | undefined;
}
export type Mpeg2AdaptiveQuantization = "AUTO" | "HIGH" | "LOW" | "MEDIUM" | "OFF" | (string & {});
export type Mpeg2ColorMetadata = "IGNORE" | "INSERT" | (string & {});
export type Mpeg2ColorSpace = "AUTO" | "PASSTHROUGH" | (string & {});
export type Mpeg2DisplayRatio = "DISPLAYRATIO16X9" | "DISPLAYRATIO4X3" | (string & {});
export interface Mpeg2FilterSettings {
    TemporalFilterSettings?: TemporalFilterSettings | undefined;
}
export type Mpeg2GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type Mpeg2ScanType = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type Mpeg2SubGopLength = "DYNAMIC" | "FIXED" | (string & {});
export type Mpeg2TimecodeInsertionBehavior = "DISABLED" | "GOP_TIMECODE" | (string & {});
export interface Mpeg2Settings {
    AdaptiveQuantization?: Mpeg2AdaptiveQuantization | undefined;
    AfdSignaling?: AfdSignaling | undefined;
    ColorMetadata?: Mpeg2ColorMetadata | undefined;
    ColorSpace?: Mpeg2ColorSpace | undefined;
    DisplayAspectRatio?: Mpeg2DisplayRatio | undefined;
    FilterSettings?: Mpeg2FilterSettings | undefined;
    FixedAfd?: FixedAfd | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopClosedCadence?: number | undefined;
    GopNumBFrames?: number | undefined;
    GopSize?: number | undefined;
    GopSizeUnits?: Mpeg2GopSizeUnits | undefined;
    ScanType?: Mpeg2ScanType | undefined;
    SubgopLength?: Mpeg2SubGopLength | undefined;
    TimecodeInsertion?: Mpeg2TimecodeInsertionBehavior | undefined;
    TimecodeBurninSettings?: TimecodeBurninSettings | undefined;
}
export type __integerMin50000Max24000000 = number;
export interface Av1ColorSpaceSettings {
    ColorSpacePassthroughSettings?: ColorSpacePassthroughSettings | undefined;
    Hdr10Settings?: Hdr10Settings | undefined;
    Rec601Settings?: Rec601Settings | undefined;
    Rec709Settings?: Rec709Settings | undefined;
    Hlg2020Settings?: Hlg2020Settings | undefined;
}
export type Av1GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type Av1Level = "AV1_LEVEL_2" | "AV1_LEVEL_2_1" | "AV1_LEVEL_3" | "AV1_LEVEL_3_1" | "AV1_LEVEL_4" | "AV1_LEVEL_4_1" | "AV1_LEVEL_5" | "AV1_LEVEL_5_1" | "AV1_LEVEL_5_2" | "AV1_LEVEL_5_3" | "AV1_LEVEL_6" | "AV1_LEVEL_6_1" | "AV1_LEVEL_6_2" | "AV1_LEVEL_6_3" | "AV1_LEVEL_AUTO" | (string & {});
export type Av1LookAheadRateControl = "HIGH" | "LOW" | "MEDIUM" | (string & {});
export type __integerMin50000Max12000000 = number;
export type Av1SceneChangeDetect = "DISABLED" | "ENABLED" | (string & {});
export type Av1RateControlMode = "CBR" | "QVBR" | (string & {});
export type __integerMin0Max8000000 = number;
export type Av1SpatialAq = "DISABLED" | "ENABLED" | (string & {});
export type Av1TemporalAq = "DISABLED" | "ENABLED" | (string & {});
export type Av1TimecodeInsertionBehavior = "DISABLED" | "METADATA_OBU" | (string & {});
export type Av1BitDepth = "DEPTH_10" | "DEPTH_8" | (string & {});
export interface Av1FilterSettings {
    AutoFilterSettings?: AutoFilterSettings | undefined;
    NoneFilterSettings?: NoneFilterSettings | undefined;
    PerceptualFilterSettings?: PerceptualFilterSettings | undefined;
}
export interface Av1Settings {
    AfdSignaling?: AfdSignaling | undefined;
    BufSize?: number | undefined;
    ColorSpaceSettings?: Av1ColorSpaceSettings | undefined;
    FixedAfd?: FixedAfd | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopSize?: number | undefined;
    GopSizeUnits?: Av1GopSizeUnits | undefined;
    Level?: Av1Level | undefined;
    LookAheadRateControl?: Av1LookAheadRateControl | undefined;
    MaxBitrate?: number | undefined;
    MinIInterval?: number | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    QvbrQualityLevel?: number | undefined;
    SceneChangeDetect?: Av1SceneChangeDetect | undefined;
    TimecodeBurninSettings?: TimecodeBurninSettings | undefined;
    Bitrate?: number | undefined;
    RateControlMode?: Av1RateControlMode | undefined;
    MinBitrate?: number | undefined;
    SpatialAq?: Av1SpatialAq | undefined;
    TemporalAq?: Av1TemporalAq | undefined;
    TimecodeInsertion?: Av1TimecodeInsertionBehavior | undefined;
    BitDepth?: Av1BitDepth | undefined;
    FilterSettings?: Av1FilterSettings | undefined;
}
export interface VideoCodecSettings {
    FrameCaptureSettings?: FrameCaptureSettings | undefined;
    H264Settings?: H264Settings | undefined;
    H265Settings?: H265Settings | undefined;
    Mpeg2Settings?: Mpeg2Settings | undefined;
    Av1Settings?: Av1Settings | undefined;
}
export type VideoDescriptionRespondToAfd = "NONE" | "PASSTHROUGH" | "RESPOND" | (string & {});
export type VideoDescriptionScalingBehavior = "DEFAULT" | "STRETCH_TO_OUTPUT" | "SMART_CROP" | (string & {});
export type __integerMin2Max8192 = number;
export type __integerMin0Max8190 = number;
export interface VideoPositionRectangle {
    Height?: number | undefined;
    Width?: number | undefined;
    X?: number | undefined;
    Y?: number | undefined;
}
export interface VideoDescription {
    CodecSettings?: VideoCodecSettings | undefined;
    Height?: number | undefined;
    Name?: string | undefined;
    RespondToAfd?: VideoDescriptionRespondToAfd | undefined;
    ScalingBehavior?: VideoDescriptionScalingBehavior | undefined;
    Sharpness?: number | undefined;
    Width?: number | undefined;
    CropRectangle?: VideoPositionRectangle | undefined;
    OutputPositionRectangle?: VideoPositionRectangle | undefined;
    Border?: number | undefined;
}
export type __listOfVideoDescription = VideoDescription[];
export type ThumbnailState = "AUTO" | "DISABLED" | (string & {});
export interface ThumbnailConfiguration {
    State?: ThumbnailState | undefined;
}
export type ColorSpace = "HDR10" | "HLG_2020" | "REC_601" | "REC_709" | (string & {});
export interface ColorCorrection {
    InputColorSpace?: ColorSpace | undefined;
    OutputColorSpace?: ColorSpace | undefined;
    Uri?: string | undefined;
}
export type __listOfColorCorrection = ColorCorrection[];
export interface ColorCorrectionSettings {
    GlobalColorCorrections?: ColorCorrection[] | undefined;
}
export interface EncoderSettings {
    AudioDescriptions?: AudioDescription[] | undefined;
    AvailBlanking?: AvailBlanking | undefined;
    AvailConfiguration?: AvailConfiguration | undefined;
    BlackoutSlate?: BlackoutSlate | undefined;
    CaptionDescriptions?: CaptionDescription[] | undefined;
    FeatureActivations?: FeatureActivations | undefined;
    GlobalConfiguration?: GlobalConfiguration | undefined;
    MotionGraphicsConfiguration?: MotionGraphicsConfiguration | undefined;
    NielsenConfiguration?: NielsenConfiguration | undefined;
    OutputGroups?: OutputGroup[] | undefined;
    TimecodeConfig?: TimecodeConfig | undefined;
    VideoDescriptions?: VideoDescription[] | undefined;
    ThumbnailConfiguration?: ThumbnailConfiguration | undefined;
    ColorCorrectionSettings?: ColorCorrectionSettings | undefined;
}
export interface AudioSilenceFailoverSettings {
    AudioSelectorName?: string | undefined;
    AudioSilenceThresholdMsec?: number | undefined;
}
export type __integerMin100 = number;
export interface InputLossFailoverSettings {
    InputLossThresholdMsec?: number | undefined;
}
export type __doubleMin0Max1 = number;
export interface VideoBlackFailoverSettings {
    BlackDetectThreshold?: number | undefined;
    VideoBlackThresholdMsec?: number | undefined;
}
export interface FailoverConditionSettings {
    AudioSilenceSettings?: AudioSilenceFailoverSettings | undefined;
    InputLossSettings?: InputLossFailoverSettings | undefined;
    VideoBlackSettings?: VideoBlackFailoverSettings | undefined;
}
export interface FailoverCondition {
    FailoverConditionSettings?: FailoverConditionSettings | undefined;
}
export type __listOfFailoverCondition = FailoverCondition[];
export type InputPreference = "EQUAL_INPUT_PREFERENCE" | "PRIMARY_INPUT_PREFERRED" | (string & {});
export interface AutomaticInputFailoverSettings {
    ErrorClearTimeMsec?: number | undefined;
    FailoverConditions?: FailoverCondition[] | undefined;
    InputPreference?: InputPreference | undefined;
    SecondaryInputId?: string | undefined;
}
export interface AudioHlsRenditionSelection {
    GroupId?: string | undefined;
    Name?: string | undefined;
}
export type AudioLanguageSelectionPolicy = "LOOSE" | "STRICT" | (string & {});
export interface AudioLanguageSelection {
    LanguageCode?: string | undefined;
    LanguageSelectionPolicy?: AudioLanguageSelectionPolicy | undefined;
}
export type __integerMin0Max8191 = number;
export type DolbyEProgramSelection = "ALL_CHANNELS" | "PROGRAM_1" | "PROGRAM_2" | "PROGRAM_3" | "PROGRAM_4" | "PROGRAM_5" | "PROGRAM_6" | "PROGRAM_7" | "PROGRAM_8" | (string & {});
export interface AudioDolbyEDecode {
    ProgramSelection?: DolbyEProgramSelection | undefined;
}
export type __doubleMinNegative60Max60 = number;
export interface AudioPreMixerSettings {
    AudioNormalizationSettings?: AudioNormalizationSettings | undefined;
    Channels?: number | undefined;
    GainDb?: number | undefined;
    RemixSettings?: RemixSettings | undefined;
}
export interface AudioPid {
    DolbyEDecode?: AudioDolbyEDecode | undefined;
    Pid?: number | undefined;
    PremixSettings?: AudioPreMixerSettings | undefined;
}
export type __listOfAudioPid = AudioPid[];
export interface AudioPidSelection {
    Pid?: number | undefined;
    Pids?: AudioPid[] | undefined;
}
export interface AudioTrack {
    Track?: number | undefined;
    PremixSettings?: AudioPreMixerSettings | undefined;
}
export type __listOfAudioTrack = AudioTrack[];
export interface AudioTrackSelection {
    Tracks?: AudioTrack[] | undefined;
    DolbyEDecode?: AudioDolbyEDecode | undefined;
}
export interface AudioSelectorSettings {
    AudioHlsRenditionSelection?: AudioHlsRenditionSelection | undefined;
    AudioLanguageSelection?: AudioLanguageSelection | undefined;
    AudioPidSelection?: AudioPidSelection | undefined;
    AudioTrackSelection?: AudioTrackSelection | undefined;
}
export interface AudioSelector {
    Name?: string | undefined;
    SelectorSettings?: AudioSelectorSettings | undefined;
}
export type __listOfAudioSelector = AudioSelector[];
export interface AncillarySourceSettings {
    SourceAncillaryChannelNumber?: number | undefined;
}
export interface AribSourceSettings {
}
export type DvbSubOcrLanguage = "DEU" | "ENG" | "FRA" | "NLD" | "POR" | "SPA" | (string & {});
export interface DvbSubSourceSettings {
    OcrLanguage?: DvbSubOcrLanguage | undefined;
    Pid?: number | undefined;
}
export type EmbeddedConvert608To708 = "DISABLED" | "UPCONVERT" | (string & {});
export type EmbeddedScte20Detection = "AUTO" | "OFF" | (string & {});
export type __integerMin1Max5 = number;
export interface EmbeddedSourceSettings {
    Convert608To708?: EmbeddedConvert608To708 | undefined;
    Scte20Detection?: EmbeddedScte20Detection | undefined;
    Source608ChannelNumber?: number | undefined;
    Source608TrackNumber?: number | undefined;
}
export type Scte20Convert608To708 = "DISABLED" | "UPCONVERT" | (string & {});
export interface Scte20SourceSettings {
    Convert608To708?: Scte20Convert608To708 | undefined;
    Source608ChannelNumber?: number | undefined;
}
export type Scte27OcrLanguage = "DEU" | "ENG" | "FRA" | "NLD" | "POR" | "SPA" | (string & {});
export interface Scte27SourceSettings {
    OcrLanguage?: Scte27OcrLanguage | undefined;
    Pid?: number | undefined;
}
export type __doubleMin0Max100 = number;
export interface CaptionRectangle {
    Height?: number | undefined;
    LeftOffset?: number | undefined;
    TopOffset?: number | undefined;
    Width?: number | undefined;
}
export interface TeletextSourceSettings {
    OutputRectangle?: CaptionRectangle | undefined;
    PageNumber?: string | undefined;
}
export type CaptionSynchronizationMode = "NO_VIDEO_DELAY" | "VIDEO_ALIGNED_CAPTIONS" | (string & {});
export interface SmartSubtitleSourceSettings {
    CaptionSynchronizationMode?: CaptionSynchronizationMode | undefined;
    InferenceFeedOutput?: string | undefined;
}
export interface CaptionSelectorSettings {
    AncillarySourceSettings?: AncillarySourceSettings | undefined;
    AribSourceSettings?: AribSourceSettings | undefined;
    DvbSubSourceSettings?: DvbSubSourceSettings | undefined;
    EmbeddedSourceSettings?: EmbeddedSourceSettings | undefined;
    Scte20SourceSettings?: Scte20SourceSettings | undefined;
    Scte27SourceSettings?: Scte27SourceSettings | undefined;
    TeletextSourceSettings?: TeletextSourceSettings | undefined;
    SmartSubtitleSourceSettings?: SmartSubtitleSourceSettings | undefined;
}
export interface CaptionSelector {
    LanguageCode?: string | undefined;
    Name?: string | undefined;
    SelectorSettings?: CaptionSelectorSettings | undefined;
}
export type __listOfCaptionSelector = CaptionSelector[];
export type InputDeblockFilter = "DISABLED" | "ENABLED" | (string & {});
export type InputDenoiseFilter = "DISABLED" | "ENABLED" | (string & {});
export type InputFilter = "AUTO" | "DISABLED" | "FORCED" | (string & {});
export type HlsScte35SourceType = "MANIFEST" | "SEGMENTS" | (string & {});
export interface HlsInputSettings {
    Bandwidth?: number | undefined;
    BufferSegments?: number | undefined;
    Retries?: number | undefined;
    RetryInterval?: number | undefined;
    Scte35Source?: HlsScte35SourceType | undefined;
}
export type NetworkInputServerValidation = "CHECK_CRYPTOGRAPHY_AND_VALIDATE_NAME" | "CHECK_CRYPTOGRAPHY_ONLY" | (string & {});
export interface MulticastInputSettings {
    SourceIpAddress?: string | undefined;
}
export interface NetworkInputSettings {
    HlsInputSettings?: HlsInputSettings | undefined;
    ServerValidation?: NetworkInputServerValidation | undefined;
    MulticastInputSettings?: MulticastInputSettings | undefined;
}
export type __integerMin32Max8191 = number;
export type Smpte2038DataPreference = "IGNORE" | "PREFER" | (string & {});
export type InputSourceEndBehavior = "CONTINUE" | "LOOP" | (string & {});
export type VideoSelectorColorSpace = "FOLLOW" | "HDR10" | "HLG_2020" | "REC_601" | "REC_709" | (string & {});
export interface VideoSelectorColorSpaceSettings {
    Hdr10Settings?: Hdr10Settings | undefined;
}
export type VideoSelectorColorSpaceUsage = "FALLBACK" | "FORCE" | (string & {});
export interface VideoSelectorPid {
    Pid?: number | undefined;
}
export interface VideoSelectorProgramId {
    ProgramId?: number | undefined;
}
export interface VideoSelectorSettings {
    VideoSelectorPid?: VideoSelectorPid | undefined;
    VideoSelectorProgramId?: VideoSelectorProgramId | undefined;
}
export interface VideoSelector {
    ColorSpace?: VideoSelectorColorSpace | undefined;
    ColorSpaceSettings?: VideoSelectorColorSpaceSettings | undefined;
    ColorSpaceUsage?: VideoSelectorColorSpaceUsage | undefined;
    SelectorSettings?: VideoSelectorSettings | undefined;
}
export interface InputSettings {
    AudioSelectors?: AudioSelector[] | undefined;
    CaptionSelectors?: CaptionSelector[] | undefined;
    DeblockFilter?: InputDeblockFilter | undefined;
    DenoiseFilter?: InputDenoiseFilter | undefined;
    FilterStrength?: number | undefined;
    InputFilter?: InputFilter | undefined;
    NetworkInputSettings?: NetworkInputSettings | undefined;
    Scte35Pid?: number | undefined;
    Smpte2038DataPreference?: Smpte2038DataPreference | undefined;
    SourceEndBehavior?: InputSourceEndBehavior | undefined;
    VideoSelector?: VideoSelector | undefined;
}
export interface InputAttachment {
    AutomaticInputFailoverSettings?: AutomaticInputFailoverSettings | undefined;
    InputAttachmentName?: string | undefined;
    InputId?: string | undefined;
    InputSettings?: InputSettings | undefined;
    LogicalInterfaceNames?: string[] | undefined;
}
export type __listOfInputAttachment = InputAttachment[];
export type InputCodec = "MPEG2" | "AVC" | "HEVC" | (string & {});
export type InputMaximumBitrate = "MAX_10_MBPS" | "MAX_20_MBPS" | "MAX_50_MBPS" | (string & {});
export type InputResolution = "SD" | "HD" | "UHD" | (string & {});
export interface InputSpecification {
    Codec?: InputCodec | undefined;
    MaximumBitrate?: InputMaximumBitrate | undefined;
    Resolution?: InputResolution | undefined;
}
export type LogLevel = "ERROR" | "WARNING" | "INFO" | "DEBUG" | "DISABLED" | (string & {});
export type MaintenanceDay = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export type __stringPattern010920300 = string;
export interface MaintenanceCreateSettings {
    MaintenanceDay?: MaintenanceDay | undefined;
    MaintenanceStartTime?: string | undefined;
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface VpcOutputSettings {
    PublicAddressAllocationIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
}
export interface AnywhereSettings {
    ChannelPlacementGroupId?: string | undefined;
    ClusterId?: string | undefined;
}
export interface ChannelEngineVersionRequest {
    Version?: string | undefined;
}
export type LinkedChannelType = "FOLLOWING_CHANNEL" | "PRIMARY_CHANNEL" | (string & {});
export interface FollowerChannelSettings {
    LinkedChannelType?: LinkedChannelType | undefined;
    PrimaryChannelArn?: string | undefined;
}
export interface PrimaryChannelSettings {
    LinkedChannelType?: LinkedChannelType | undefined;
}
export interface LinkedChannelSettings {
    FollowerChannelSettings?: FollowerChannelSettings | undefined;
    PrimaryChannelSettings?: PrimaryChannelSettings | undefined;
}
export interface AudioFeedInput {
    AudioSelectorName?: string | undefined;
    FeedInput?: string | undefined;
}
export type __listOfAudioFeedInput = AudioFeedInput[];
export type EnrichmentMethod = "SCTE35_ELEMENTAL_INFERENCE_QUERY_PARAMS" | (string & {});
export type __listOfEnrichmentMethod = EnrichmentMethod[];
export interface InferenceSettings {
    FeedArn?: string | undefined;
    AudioFeedInputs?: AudioFeedInput[] | undefined;
    EnrichmentMethods?: EnrichmentMethod[] | undefined;
}
export interface CreateChannelRequest {
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelClass?: ChannelClass | undefined;
    Destinations?: OutputDestination[] | undefined;
    EncoderSettings?: EncoderSettings | undefined;
    InputAttachments?: InputAttachment[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceCreateSettings | undefined;
    Name?: string | undefined;
    RequestId?: string | undefined;
    Reserved?: string | undefined;
    RoleArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Vpc?: VpcOutputSettings | undefined;
    AnywhereSettings?: AnywhereSettings | undefined;
    ChannelEngineVersion?: ChannelEngineVersionRequest | undefined;
    DryRun?: boolean | undefined;
    LinkedChannelSettings?: LinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: InferenceSettings | undefined;
}
export interface ChannelEgressEndpoint {
    SourceIp?: string | undefined;
}
export type __listOfChannelEgressEndpoint = ChannelEgressEndpoint[];
export interface MaintenanceStatus {
    MaintenanceDay?: MaintenanceDay | undefined;
    MaintenanceDeadline?: string | undefined;
    MaintenanceScheduledDate?: string | undefined;
    MaintenanceStartTime?: string | undefined;
}
export type __timestampIso8601 = Date;
export interface ChannelEngineVersionResponse {
    ExpirationDate?: Date | undefined;
    Version?: string | undefined;
}
export interface MediaConnectRouterOutputConnection {
    RouterInputArn?: string | undefined;
}
export type MediaConnectRouterOutputConnections = {
    [key: string]: MediaConnectRouterOutputConnection | undefined;
};
export interface PipelineDetail {
    ActiveInputAttachmentName?: string | undefined;
    ActiveInputSwitchActionName?: string | undefined;
    ActiveMotionGraphicsActionName?: string | undefined;
    ActiveMotionGraphicsUri?: string | undefined;
    PipelineId?: string | undefined;
    ChannelEngineVersion?: ChannelEngineVersionResponse | undefined;
    MediaConnectRouterOutputConnectionMap?: {
        [key: string]: MediaConnectRouterOutputConnection | undefined;
    } | undefined;
}
export type __listOfPipelineDetail = PipelineDetail[];
export type ChannelState = "CREATING" | "CREATE_FAILED" | "IDLE" | "STARTING" | "RUNNING" | "RECOVERING" | "STOPPING" | "DELETING" | "DELETED" | "UPDATING" | "UPDATE_FAILED" | (string & {});
export interface VpcOutputSettingsDescription {
    AvailabilityZones?: string[] | undefined;
    NetworkInterfaceIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
}
export interface DescribeAnywhereSettings {
    ChannelPlacementGroupId?: string | undefined;
    ClusterId?: string | undefined;
}
export interface DescribeFollowerChannelSettings {
    LinkedChannelType?: LinkedChannelType | undefined;
    PrimaryChannelArn?: string | undefined;
}
export interface DescribePrimaryChannelSettings {
    FollowingChannelArns?: string[] | undefined;
    LinkedChannelType?: LinkedChannelType | undefined;
}
export interface DescribeLinkedChannelSettings {
    FollowerChannelSettings?: DescribeFollowerChannelSettings | undefined;
    PrimaryChannelSettings?: DescribePrimaryChannelSettings | undefined;
}
export interface DescribeInferenceSettings {
    FeedArn?: string | undefined;
    AudioFeedInputs?: AudioFeedInput[] | undefined;
    EnrichmentMethods?: EnrichmentMethod[] | undefined;
}
export interface Channel {
    Arn?: string | undefined;
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelClass?: ChannelClass | undefined;
    Destinations?: OutputDestination[] | undefined;
    EgressEndpoints?: ChannelEgressEndpoint[] | undefined;
    EncoderSettings?: EncoderSettings | undefined;
    Id?: string | undefined;
    InputAttachments?: InputAttachment[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceStatus | undefined;
    Name?: string | undefined;
    PipelineDetails?: PipelineDetail[] | undefined;
    PipelinesRunningCount?: number | undefined;
    RoleArn?: string | undefined;
    State?: ChannelState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Vpc?: VpcOutputSettingsDescription | undefined;
    AnywhereSettings?: DescribeAnywhereSettings | undefined;
    ChannelEngineVersion?: ChannelEngineVersionResponse | undefined;
    LinkedChannelSettings?: DescribeLinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: DescribeInferenceSettings | undefined;
}
export interface CreateChannelResponse {
    Channel?: (Channel & {
        EncoderSettings: EncoderSettings & {
            AudioDescriptions: (AudioDescription & {
                AudioSelectorName: string;
                Name: __stringMax255;
                AudioWatermarkingSettings: AudioWatermarkSettings & {
                    NielsenWatermarksSettings: NielsenWatermarksSettings & {
                        NielsenCbetSettings: NielsenCBET & {
                            CbetCheckDigitString: __stringMin2Max2;
                            CbetStepaside: NielsenWatermarksCbetStepaside;
                            Csid: __stringMin1Max7;
                        };
                        NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                        NielsenNwOnlySettings: NielsenNwOnly & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                    };
                };
                RemixSettings: RemixSettings & {
                    ChannelMappings: (AudioChannelMapping & {
                        InputChannelLevels: (InputChannelLevel & {
                            Gain: __integerMinNegative60Max6;
                            InputChannel: __integerMin0Max15;
                        })[];
                        OutputChannel: __integerMin0Max7;
                    })[];
                };
            })[];
            OutputGroups: (OutputGroup & {
                OutputGroupSettings: OutputGroupSettings & {
                    ArchiveGroupSettings: ArchiveGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    HlsGroupSettings: HlsGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        KeyProviderSettings: KeyProviderSettings & {
                            StaticKeySettings: StaticKeySettings & {
                                StaticKeyValue: __stringMin32Max32;
                                KeyProviderServer: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                        };
                    };
                    MediaPackageGroupSettings: MediaPackageGroupSettings & {
                        Destination: OutputLocationRef;
                        MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                            CaptionLanguageMappings: (CaptionLanguageMapping & {
                                CaptionChannel: __integerMin1Max4;
                                LanguageCode: __stringMin3Max3;
                                LanguageDescription: __stringMin1;
                            })[];
                            AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                                Destination: OutputLocationRef;
                            })[];
                            WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                                MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                    AlternateDestination: OutputLocationRef;
                                    OperatorId: __integerMin1Max511;
                                    Profile: AbWatermarkingProfile;
                                    CustomProfile: AbWatermarkingCustomProfile & {
                                        EmbeddingFrequency: number;
                                        SceneCut: __doubleMinNegative1Max5;
                                        TargetPsnr: __doubleMin32Max46;
                                    };
                                };
                            };
                        };
                    };
                    MsSmoothGroupSettings: MsSmoothGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    CmafIngestGroupSettings: CmafIngestGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                        })[];
                        AdditionalDestinations: (AdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: CmafIngestWatermarkingSettings & {
                            CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: number;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                Outputs: (Output & {
                    OutputSettings: OutputSettings & {
                        ArchiveOutputSettings: ArchiveOutputSettings & {
                            ContainerSettings: ArchiveContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                        };
                        HlsOutputSettings: HlsOutputSettings & {
                            HlsSettings: HlsSettings & {
                                AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                    AudioOnlyImage: InputLocation & {
                                        Uri: __stringMax2048;
                                    };
                                };
                                StandardHlsSettings: StandardHlsSettings & {
                                    M3u8Settings: M3u8Settings;
                                };
                            };
                        };
                        MultiplexOutputSettings: MultiplexOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        RtmpOutputSettings: RtmpOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        UdpOutputSettings: UdpOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        SrtOutputSettings: SrtOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                            ContainerSettings: MediaConnectRouterContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                    };
                })[];
            })[];
            TimecodeConfig: TimecodeConfig & {
                Source: TimecodeConfigSource;
            };
            VideoDescriptions: (VideoDescription & {
                Name: string;
                CodecSettings: VideoCodecSettings & {
                    FrameCaptureSettings: FrameCaptureSettings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H264Settings: H264Settings & {
                        FilterSettings: H264FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H265Settings: H265Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        FilterSettings: H265FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Mpeg2Settings: Mpeg2Settings & {
                        FramerateDenominator: __integerMin1;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Av1Settings: Av1Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                        FilterSettings: Av1FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                    };
                };
                CropRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
                OutputPositionRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
            })[];
            AvailBlanking: AvailBlanking & {
                AvailBlankingImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            AvailConfiguration: AvailConfiguration & {
                AvailSettings: AvailSettings & {
                    Esam: Esam & {
                        AcquisitionPointId: __stringMax256;
                        PoisEndpoint: __stringMax2048;
                    };
                };
            };
            BlackoutSlate: BlackoutSlate & {
                BlackoutSlateImage: InputLocation & {
                    Uri: __stringMax2048;
                };
                NetworkEndBlackoutImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            CaptionDescriptions: (CaptionDescription & {
                CaptionSelectorName: string;
                Name: string;
                DestinationSettings: CaptionDestinationSettings & {
                    BurnInDestinationSettings: BurnInDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                    DvbSubDestinationSettings: DvbSubDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                };
            })[];
            GlobalConfiguration: GlobalConfiguration & {
                InputLossBehavior: InputLossBehavior & {
                    InputLossImageSlate: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
            MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
                MotionGraphicsSettings: MotionGraphicsSettings;
            };
            ThumbnailConfiguration: ThumbnailConfiguration & {
                State: ThumbnailState;
            };
            ColorCorrectionSettings: ColorCorrectionSettings & {
                GlobalColorCorrections: (ColorCorrection & {
                    InputColorSpace: ColorSpace;
                    OutputColorSpace: ColorSpace;
                    Uri: string;
                })[];
            };
        };
        InputAttachments: (InputAttachment & {
            AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
                SecondaryInputId: string;
                FailoverConditions: (FailoverCondition & {
                    FailoverConditionSettings: FailoverConditionSettings & {
                        AudioSilenceSettings: AudioSilenceFailoverSettings & {
                            AudioSelectorName: string;
                        };
                    };
                })[];
            };
            InputSettings: InputSettings & {
                AudioSelectors: (AudioSelector & {
                    Name: __stringMin1;
                    SelectorSettings: AudioSelectorSettings & {
                        AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                            GroupId: __stringMin1;
                            Name: __stringMin1;
                        };
                        AudioLanguageSelection: AudioLanguageSelection & {
                            LanguageCode: string;
                        };
                        AudioPidSelection: AudioPidSelection & {
                            Pid: __integerMin0Max8191;
                            Pids: (AudioPid & {
                                Pid: __integerMin0Max8191;
                                DolbyEDecode: AudioDolbyEDecode & {
                                    ProgramSelection: DolbyEProgramSelection;
                                };
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                        };
                        AudioTrackSelection: AudioTrackSelection & {
                            Tracks: (AudioTrack & {
                                Track: __integerMin1;
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                        };
                    };
                })[];
                CaptionSelectors: (CaptionSelector & {
                    Name: __stringMin1;
                    SelectorSettings: CaptionSelectorSettings & {
                        TeletextSourceSettings: TeletextSourceSettings & {
                            OutputRectangle: CaptionRectangle & {
                                Height: __doubleMin0Max100;
                                LeftOffset: __doubleMin0Max100;
                                TopOffset: __doubleMin0Max100;
                                Width: __doubleMin0Max100;
                            };
                        };
                    };
                })[];
            };
        })[];
    }) | undefined;
}
export interface CreateChannelPlacementGroupRequest {
    ClusterId: string;
    Name?: string | undefined;
    Nodes?: string[] | undefined;
    RequestId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ChannelPlacementGroupState = "UNASSIGNED" | "ASSIGNING" | "ASSIGNED" | "DELETING" | "DELETE_FAILED" | "DELETED" | "UNASSIGNING" | (string & {});
export interface CreateChannelPlacementGroupResponse {
    Arn?: string | undefined;
    Channels?: string[] | undefined;
    ClusterId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Nodes?: string[] | undefined;
    State?: ChannelPlacementGroupState | undefined;
}
export type CloudWatchAlarmTemplateComparisonOperator = "GreaterThanOrEqualToThreshold" | "GreaterThanThreshold" | "LessThanThreshold" | "LessThanOrEqualToThreshold" | (string & {});
export type __stringMin0Max1024 = string;
export type __stringPatternS = string;
export type __stringMax64 = string;
export type __stringMin1Max255PatternS = string;
export type __integerMin10Max86400 = number;
export type CloudWatchAlarmTemplateStatistic = "SampleCount" | "Average" | "Sum" | "Minimum" | "Maximum" | (string & {});
export type TagMap = {
    [key: string]: string | undefined;
};
export type CloudWatchAlarmTemplateTargetResourceType = "CLOUDFRONT_DISTRIBUTION" | "MEDIALIVE_MULTIPLEX" | "MEDIALIVE_CHANNEL" | "MEDIALIVE_INPUT_DEVICE" | "MEDIAPACKAGE_CHANNEL" | "MEDIAPACKAGE_ORIGIN_ENDPOINT" | "MEDIACONNECT_FLOW" | "S3_BUCKET" | "MEDIATAILOR_PLAYBACK_CONFIGURATION" | "ELEMENTAL_INFERENCE_FEED" | (string & {});
export type CloudWatchAlarmTemplateTreatMissingData = "notBreaching" | "breaching" | "ignore" | "missing" | (string & {});
export type __stringMin1Max256PatternS = string;
export interface CreateCloudWatchAlarmTemplateRequest {
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator | undefined;
    DatapointsToAlarm?: number | undefined;
    Description?: string | undefined;
    EvaluationPeriods?: number | undefined;
    GroupIdentifier?: string | undefined;
    MetricName?: string | undefined;
    Name?: string | undefined;
    Period?: number | undefined;
    Statistic?: CloudWatchAlarmTemplateStatistic | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType | undefined;
    Threshold?: number | undefined;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData | undefined;
    RequestId?: string | undefined;
}
export type __stringPatternArnMedialiveCloudwatchAlarmTemplate = string;
export type __stringMin7Max11PatternAws097 = string;
export interface CreateCloudWatchAlarmTemplateResponse {
    Arn?: string | undefined;
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator | undefined;
    CreatedAt?: Date | undefined;
    DatapointsToAlarm?: number | undefined;
    Description?: string | undefined;
    EvaluationPeriods?: number | undefined;
    GroupId?: string | undefined;
    Id?: string | undefined;
    MetricName?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Period?: number | undefined;
    Statistic?: CloudWatchAlarmTemplateStatistic | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType | undefined;
    Threshold?: number | undefined;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData | undefined;
}
export interface CreateCloudWatchAlarmTemplateGroupRequest {
    Description?: string | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestId?: string | undefined;
}
export type __stringPatternArnMedialiveCloudwatchAlarmTemplateGroup = string;
export interface CreateCloudWatchAlarmTemplateGroupResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ClusterType = "ON_PREMISES" | (string & {});
export interface InterfaceMappingCreateRequest {
    LogicalInterfaceName?: string | undefined;
    NetworkId?: string | undefined;
}
export type __listOfInterfaceMappingCreateRequest = InterfaceMappingCreateRequest[];
export interface ClusterNetworkSettingsCreateRequest {
    DefaultRoute?: string | undefined;
    InterfaceMappings?: InterfaceMappingCreateRequest[] | undefined;
}
export interface CreateClusterRequest {
    ClusterType?: ClusterType | undefined;
    InstanceRoleArn?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: ClusterNetworkSettingsCreateRequest | undefined;
    RequestId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface InterfaceMapping {
    LogicalInterfaceName?: string | undefined;
    NetworkId?: string | undefined;
}
export type __listOfInterfaceMapping = InterfaceMapping[];
export interface ClusterNetworkSettings {
    DefaultRoute?: string | undefined;
    InterfaceMappings?: InterfaceMapping[] | undefined;
}
export type ClusterState = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "DELETE_FAILED" | "DELETED" | (string & {});
export interface CreateClusterResponse {
    Arn?: string | undefined;
    ChannelIds?: string[] | undefined;
    ClusterType?: ClusterType | undefined;
    Id?: string | undefined;
    InstanceRoleArn?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: ClusterNetworkSettings | undefined;
    State?: ClusterState | undefined;
}
export type __stringMin1Max2048PatternArn = string;
export interface EventBridgeRuleTemplateTarget {
    Arn?: string | undefined;
}
export type __listOfEventBridgeRuleTemplateTarget = EventBridgeRuleTemplateTarget[];
export type EventBridgeRuleTemplateEventType = "MEDIALIVE_MULTIPLEX_ALERT" | "MEDIALIVE_MULTIPLEX_STATE_CHANGE" | "MEDIALIVE_CHANNEL_ALERT" | "MEDIALIVE_CHANNEL_INPUT_CHANGE" | "MEDIALIVE_CHANNEL_STATE_CHANGE" | "MEDIAPACKAGE_INPUT_NOTIFICATION" | "MEDIAPACKAGE_KEY_PROVIDER_NOTIFICATION" | "MEDIAPACKAGE_HARVEST_JOB_NOTIFICATION" | "SIGNAL_MAP_ACTIVE_ALARM" | "MEDIACONNECT_ALERT" | "MEDIACONNECT_SOURCE_HEALTH" | "MEDIACONNECT_OUTPUT_HEALTH" | "MEDIACONNECT_FLOW_STATUS_CHANGE" | (string & {});
export interface CreateEventBridgeRuleTemplateRequest {
    Description?: string | undefined;
    EventTargets?: EventBridgeRuleTemplateTarget[] | undefined;
    EventType?: EventBridgeRuleTemplateEventType | undefined;
    GroupIdentifier?: string | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestId?: string | undefined;
}
export type __stringPatternArnMedialiveEventbridgeRuleTemplate = string;
export interface CreateEventBridgeRuleTemplateResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    EventTargets?: (EventBridgeRuleTemplateTarget & {
        Arn: __stringMin1Max2048PatternArn;
    })[] | undefined;
    EventType?: EventBridgeRuleTemplateEventType | undefined;
    GroupId?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateEventBridgeRuleTemplateGroupRequest {
    Description?: string | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestId?: string | undefined;
}
export type __stringPatternArnMedialiveEventbridgeRuleTemplateGroup = string;
export interface CreateEventBridgeRuleTemplateGroupResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface InputRequestDestinationRoute {
    Cidr?: string | undefined;
    Gateway?: string | undefined;
}
export type __listOfInputRequestDestinationRoute = InputRequestDestinationRoute[];
export interface InputDestinationRequest {
    StreamName?: string | undefined;
    Network?: string | undefined;
    NetworkRoutes?: InputRequestDestinationRoute[] | undefined;
    StaticIpAddress?: string | undefined;
}
export type __listOfInputDestinationRequest = InputDestinationRequest[];
export interface InputDeviceSettings {
    Id?: string | undefined;
}
export type __listOfInputDeviceSettings = InputDeviceSettings[];
export interface MediaConnectFlowRequest {
    FlowArn?: string | undefined;
}
export type __listOfMediaConnectFlowRequest = MediaConnectFlowRequest[];
export interface InputSourceRequest {
    PasswordParam?: string | undefined;
    Url?: string | undefined;
    Username?: string | undefined;
}
export type __listOfInputSourceRequest = InputSourceRequest[];
export type InputType = "UDP_PUSH" | "RTP_PUSH" | "RTMP_PUSH" | "RTMP_PULL" | "URL_PULL" | "MP4_FILE" | "MEDIACONNECT" | "INPUT_DEVICE" | "AWS_CDI" | "TS_FILE" | "SRT_CALLER" | "MULTICAST" | "SMPTE_2110_RECEIVER_GROUP" | "SDI" | "MEDIACONNECT_ROUTER" | "SRT_LISTENER" | (string & {});
export interface InputVpcRequest {
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
}
export type Algorithm = "AES128" | "AES192" | "AES256" | (string & {});
export interface SrtCallerDecryptionRequest {
    Algorithm?: Algorithm | undefined;
    PassphraseSecretArn?: string | undefined;
}
export interface SrtCallerSourceRequest {
    Decryption?: SrtCallerDecryptionRequest | undefined;
    MinimumLatency?: number | undefined;
    SrtListenerAddress?: string | undefined;
    SrtListenerPort?: string | undefined;
    StreamId?: string | undefined;
}
export type __listOfSrtCallerSourceRequest = SrtCallerSourceRequest[];
export interface SrtListenerDecryptionRequest {
    Algorithm?: Algorithm | undefined;
    PassphraseSecretArn?: string | undefined;
}
export interface SrtListenerSettingsRequest {
    Decryption?: SrtListenerDecryptionRequest | undefined;
    MinimumLatency?: number | undefined;
    StreamId?: string | undefined;
}
export interface SrtSettingsRequest {
    SrtCallerSources?: SrtCallerSourceRequest[] | undefined;
    SrtListenerSettings?: SrtListenerSettingsRequest | undefined;
}
export type InputNetworkLocation = "AWS" | "ON_PREMISES" | (string & {});
export interface MulticastSourceCreateRequest {
    SourceIp?: string | undefined;
    Url?: string | undefined;
    SecondarySourceIp?: string | undefined;
    SecondaryUrl?: string | undefined;
}
export type __listOfMulticastSourceCreateRequest = MulticastSourceCreateRequest[];
export interface MulticastSettingsCreateRequest {
    Sources?: MulticastSourceCreateRequest[] | undefined;
}
export interface InputSdpLocation {
    MediaIndex?: number | undefined;
    SdpUrl?: string | undefined;
}
export type __listOfInputSdpLocation = InputSdpLocation[];
export interface Smpte2110ReceiverGroupSdpSettings {
    AncillarySdps?: InputSdpLocation[] | undefined;
    AudioSdps?: InputSdpLocation[] | undefined;
    VideoSdp?: InputSdpLocation | undefined;
}
export interface Smpte2110ReceiverGroup {
    SdpSettings?: Smpte2110ReceiverGroupSdpSettings | undefined;
}
export type __listOfSmpte2110ReceiverGroup = Smpte2110ReceiverGroup[];
export interface Smpte2110ReceiverGroupSettings {
    Smpte2110ReceiverGroups?: Smpte2110ReceiverGroup[] | undefined;
}
export type InputSdiSources = string[];
export interface RouterDestinationSettings {
    AvailabilityZoneName?: string | undefined;
}
export type __listOfRouterDestinationSettings = RouterDestinationSettings[];
export type RouterEncryptionType = "AUTOMATIC" | "SECRETS_MANAGER" | (string & {});
export interface RouterSettings {
    Destinations?: RouterDestinationSettings[] | undefined;
    EncryptionType?: RouterEncryptionType | undefined;
    SecretArn?: string | undefined;
}
export interface CreateInputRequest {
    Destinations?: InputDestinationRequest[] | undefined;
    InputDevices?: InputDeviceSettings[] | undefined;
    InputSecurityGroups?: string[] | undefined;
    MediaConnectFlows?: MediaConnectFlowRequest[] | undefined;
    Name?: string | undefined;
    RequestId?: string | undefined;
    RoleArn?: string | undefined;
    Sources?: InputSourceRequest[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: InputType | undefined;
    Vpc?: InputVpcRequest | undefined;
    SrtSettings?: SrtSettingsRequest | undefined;
    InputNetworkLocation?: InputNetworkLocation | undefined;
    MulticastSettings?: MulticastSettingsCreateRequest | undefined;
    Smpte2110ReceiverGroupSettings?: Smpte2110ReceiverGroupSettings | undefined;
    SdiSources?: string[] | undefined;
    RouterSettings?: RouterSettings | undefined;
}
export interface InputDestinationVpc {
    AvailabilityZone?: string | undefined;
    NetworkInterfaceId?: string | undefined;
}
export interface InputDestinationRoute {
    Cidr?: string | undefined;
    Gateway?: string | undefined;
}
export type __listOfInputDestinationRoute = InputDestinationRoute[];
export interface InputDestination {
    Ip?: string | undefined;
    Port?: string | undefined;
    Url?: string | undefined;
    Vpc?: InputDestinationVpc | undefined;
    Network?: string | undefined;
    NetworkRoutes?: InputDestinationRoute[] | undefined;
}
export type __listOfInputDestination = InputDestination[];
export type InputClass = "STANDARD" | "SINGLE_PIPELINE" | (string & {});
export type InputSourceType = "STATIC" | "DYNAMIC" | (string & {});
export interface MediaConnectFlow {
    FlowArn?: string | undefined;
}
export type __listOfMediaConnectFlow = MediaConnectFlow[];
export interface InputSource {
    PasswordParam?: string | undefined;
    Url?: string | undefined;
    Username?: string | undefined;
}
export type __listOfInputSource = InputSource[];
export type InputState = "CREATING" | "DETACHED" | "ATTACHED" | "DELETING" | "DELETED" | (string & {});
export interface SrtCallerDecryption {
    Algorithm?: Algorithm | undefined;
    PassphraseSecretArn?: string | undefined;
}
export interface SrtCallerSource {
    Decryption?: SrtCallerDecryption | undefined;
    MinimumLatency?: number | undefined;
    SrtListenerAddress?: string | undefined;
    SrtListenerPort?: string | undefined;
    StreamId?: string | undefined;
}
export type __listOfSrtCallerSource = SrtCallerSource[];
export interface SrtListenerDecryption {
    Algorithm?: Algorithm | undefined;
    PassphraseSecretArn?: string | undefined;
}
export interface SrtListenerSettings {
    Decryption?: SrtListenerDecryption | undefined;
    MinimumLatency?: number | undefined;
    StreamId?: string | undefined;
}
export interface SrtSettings {
    SrtCallerSources?: SrtCallerSource[] | undefined;
    SrtListenerSettings?: SrtListenerSettings | undefined;
}
export interface MulticastSource {
    SourceIp?: string | undefined;
    Url?: string | undefined;
    SecondarySourceIp?: string | undefined;
    SecondaryUrl?: string | undefined;
}
export type __listOfMulticastSource = MulticastSource[];
export interface MulticastSettings {
    Sources?: MulticastSource[] | undefined;
}
export interface RouterDestination {
    AvailabilityZoneName?: string | undefined;
    RouterOutputArn?: string | undefined;
}
export type __listOfRouterDestination = RouterDestination[];
export interface RouterInputSettings {
    Destinations?: RouterDestination[] | undefined;
    EncryptionType?: RouterEncryptionType | undefined;
    SecretArn?: string | undefined;
}
export interface Input {
    Arn?: string | undefined;
    AttachedChannels?: string[] | undefined;
    Destinations?: InputDestination[] | undefined;
    Id?: string | undefined;
    InputClass?: InputClass | undefined;
    InputDevices?: InputDeviceSettings[] | undefined;
    InputPartnerIds?: string[] | undefined;
    InputSourceType?: InputSourceType | undefined;
    MediaConnectFlows?: MediaConnectFlow[] | undefined;
    Name?: string | undefined;
    RoleArn?: string | undefined;
    SecurityGroups?: string[] | undefined;
    Sources?: InputSource[] | undefined;
    State?: InputState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: InputType | undefined;
    SrtSettings?: SrtSettings | undefined;
    InputNetworkLocation?: InputNetworkLocation | undefined;
    MulticastSettings?: MulticastSettings | undefined;
    Smpte2110ReceiverGroupSettings?: Smpte2110ReceiverGroupSettings | undefined;
    SdiSources?: string[] | undefined;
    RouterSettings?: RouterInputSettings | undefined;
}
export interface CreateInputResponse {
    Input?: (Input & {
        SrtSettings: SrtSettings & {
            SrtListenerSettings: SrtListenerSettings & {
                Decryption: SrtListenerDecryption & {
                    Algorithm: Algorithm;
                    PassphraseSecretArn: string;
                };
            };
        };
        MulticastSettings: MulticastSettings & {
            Sources: (MulticastSource & {
                Url: string;
            })[];
        };
    }) | undefined;
}
export interface InputWhitelistRuleCidr {
    Cidr?: string | undefined;
}
export type __listOfInputWhitelistRuleCidr = InputWhitelistRuleCidr[];
export interface CreateInputSecurityGroupRequest {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    WhitelistRules?: InputWhitelistRuleCidr[] | undefined;
}
export type InputSecurityGroupState = "IDLE" | "IN_USE" | "UPDATING" | "DELETED" | (string & {});
export interface InputWhitelistRule {
    Cidr?: string | undefined;
}
export type __listOfInputWhitelistRule = InputWhitelistRule[];
export interface InputSecurityGroup {
    Arn?: string | undefined;
    Id?: string | undefined;
    Inputs?: string[] | undefined;
    State?: InputSecurityGroupState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    WhitelistRules?: InputWhitelistRule[] | undefined;
    Channels?: string[] | undefined;
}
export interface CreateInputSecurityGroupResponse {
    SecurityGroup?: InputSecurityGroup | undefined;
}
export type __integerMin800Max3000 = number;
export type __integerMin1000000Max100000000 = number;
export type __integerMin0Max100000000 = number;
export interface MultiplexSettings {
    MaximumVideoBufferDelayMilliseconds?: number | undefined;
    TransportStreamBitrate?: number | undefined;
    TransportStreamId?: number | undefined;
    TransportStreamReservedBitrate?: number | undefined;
}
export interface CreateMultiplexRequest {
    AvailabilityZones?: string[] | undefined;
    MultiplexSettings?: MultiplexSettings | undefined;
    Name?: string | undefined;
    RequestId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface MultiplexMediaConnectOutputDestinationSettings {
    EntitlementArn?: string | undefined;
}
export interface MultiplexOutputDestination {
    MediaConnectSettings?: MultiplexMediaConnectOutputDestinationSettings | undefined;
}
export type __listOfMultiplexOutputDestination = MultiplexOutputDestination[];
export type MultiplexState = "CREATING" | "CREATE_FAILED" | "IDLE" | "STARTING" | "RUNNING" | "RECOVERING" | "STOPPING" | "DELETING" | "DELETED" | (string & {});
export interface Multiplex {
    Arn?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    Destinations?: MultiplexOutputDestination[] | undefined;
    Id?: string | undefined;
    MultiplexSettings?: MultiplexSettings | undefined;
    Name?: string | undefined;
    PipelinesRunningCount?: number | undefined;
    ProgramCount?: number | undefined;
    State?: MultiplexState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateMultiplexResponse {
    Multiplex?: (Multiplex & {
        MultiplexSettings: MultiplexSettings & {
            TransportStreamBitrate: __integerMin1000000Max100000000;
            TransportStreamId: __integerMin0Max65535;
        };
    }) | undefined;
}
export type PreferredChannelPipeline = "CURRENTLY_ACTIVE" | "PIPELINE_0" | "PIPELINE_1" | (string & {});
export interface MultiplexProgramServiceDescriptor {
    ProviderName?: string | undefined;
    ServiceName?: string | undefined;
}
export type __integerMin100000Max100000000 = number;
export type __integerMinNegative5Max5 = number;
export interface MultiplexStatmuxVideoSettings {
    MaximumBitrate?: number | undefined;
    MinimumBitrate?: number | undefined;
    Priority?: number | undefined;
}
export interface MultiplexVideoSettings {
    ConstantBitrate?: number | undefined;
    StatmuxSettings?: MultiplexStatmuxVideoSettings | undefined;
}
export interface MultiplexProgramSettings {
    PreferredChannelPipeline?: PreferredChannelPipeline | undefined;
    ProgramNumber?: number | undefined;
    ServiceDescriptor?: MultiplexProgramServiceDescriptor | undefined;
    VideoSettings?: MultiplexVideoSettings | undefined;
}
export interface CreateMultiplexProgramRequest {
    MultiplexId: string;
    MultiplexProgramSettings?: MultiplexProgramSettings | undefined;
    ProgramName?: string | undefined;
    RequestId?: string | undefined;
}
export type __listOf__integer = number[];
export interface MultiplexProgramPacketIdentifiersMap {
    AudioPids?: number[] | undefined;
    DvbSubPids?: number[] | undefined;
    DvbTeletextPid?: number | undefined;
    EtvPlatformPid?: number | undefined;
    EtvSignalPid?: number | undefined;
    KlvDataPids?: number[] | undefined;
    PcrPid?: number | undefined;
    PmtPid?: number | undefined;
    PrivateMetadataPid?: number | undefined;
    Scte27Pids?: number[] | undefined;
    Scte35Pid?: number | undefined;
    TimedMetadataPid?: number | undefined;
    VideoPid?: number | undefined;
    AribCaptionsPid?: number | undefined;
    DvbTeletextPids?: number[] | undefined;
    EcmPid?: number | undefined;
    Smpte2038Pid?: number | undefined;
}
export interface MultiplexProgramPipelineDetail {
    ActiveChannelPipeline?: string | undefined;
    PipelineId?: string | undefined;
}
export type __listOfMultiplexProgramPipelineDetail = MultiplexProgramPipelineDetail[];
export interface MultiplexProgram {
    ChannelId?: string | undefined;
    MultiplexProgramSettings?: MultiplexProgramSettings | undefined;
    PacketIdentifiersMap?: MultiplexProgramPacketIdentifiersMap | undefined;
    PipelineDetails?: MultiplexProgramPipelineDetail[] | undefined;
    ProgramName?: string | undefined;
}
export interface CreateMultiplexProgramResponse {
    MultiplexProgram?: (MultiplexProgram & {
        MultiplexProgramSettings: MultiplexProgramSettings & {
            ProgramNumber: __integerMin0Max65535;
            ServiceDescriptor: MultiplexProgramServiceDescriptor & {
                ProviderName: __stringMax256;
                ServiceName: __stringMax256;
            };
        };
    }) | undefined;
}
export interface IpPoolCreateRequest {
    Cidr?: string | undefined;
}
export type __listOfIpPoolCreateRequest = IpPoolCreateRequest[];
export interface RouteCreateRequest {
    Cidr?: string | undefined;
    Gateway?: string | undefined;
}
export type __listOfRouteCreateRequest = RouteCreateRequest[];
export interface CreateNetworkRequest {
    IpPools?: IpPoolCreateRequest[] | undefined;
    Name?: string | undefined;
    RequestId?: string | undefined;
    Routes?: RouteCreateRequest[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface IpPool {
    Cidr?: string | undefined;
}
export type __listOfIpPool = IpPool[];
export interface Route {
    Cidr?: string | undefined;
    Gateway?: string | undefined;
}
export type __listOfRoute = Route[];
export type NetworkState = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "IDLE" | "IN_USE" | "UPDATING" | "DELETE_FAILED" | "DELETED" | (string & {});
export interface CreateNetworkResponse {
    Arn?: string | undefined;
    AssociatedClusterIds?: string[] | undefined;
    Id?: string | undefined;
    IpPools?: IpPool[] | undefined;
    Name?: string | undefined;
    Routes?: Route[] | undefined;
    State?: NetworkState | undefined;
}
export type NetworkInterfaceMode = "NAT" | "BRIDGE" | (string & {});
export interface NodeInterfaceMappingCreateRequest {
    LogicalInterfaceName?: string | undefined;
    NetworkInterfaceMode?: NetworkInterfaceMode | undefined;
    PhysicalInterfaceName?: string | undefined;
}
export type __listOfNodeInterfaceMappingCreateRequest = NodeInterfaceMappingCreateRequest[];
export type NodeRole = "BACKUP" | "ACTIVE" | (string & {});
export interface CreateNodeRequest {
    ClusterId: string;
    Name?: string | undefined;
    NodeInterfaceMappings?: NodeInterfaceMappingCreateRequest[] | undefined;
    RequestId?: string | undefined;
    Role?: NodeRole | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NodeConnectionState = "CONNECTED" | "DISCONNECTED" | (string & {});
export interface NodeInterfaceMapping {
    LogicalInterfaceName?: string | undefined;
    NetworkInterfaceMode?: NetworkInterfaceMode | undefined;
    PhysicalInterfaceName?: string | undefined;
    PhysicalInterfaceIpAddresses?: string[] | undefined;
}
export type __listOfNodeInterfaceMapping = NodeInterfaceMapping[];
export type NodeState = "CREATED" | "REGISTERING" | "READY_TO_ACTIVATE" | "REGISTRATION_FAILED" | "ACTIVATION_FAILED" | "ACTIVE" | "READY" | "IN_USE" | "DEREGISTERING" | "DRAINING" | "DEREGISTRATION_FAILED" | "DEREGISTERED" | (string & {});
export interface SdiSourceMapping {
    CardNumber?: number | undefined;
    ChannelNumber?: number | undefined;
    SdiSource?: string | undefined;
}
export type SdiSourceMappings = SdiSourceMapping[];
export interface CreateNodeResponse {
    Arn?: string | undefined;
    ChannelPlacementGroups?: string[] | undefined;
    ClusterId?: string | undefined;
    ConnectionState?: NodeConnectionState | undefined;
    Id?: string | undefined;
    InstanceArn?: string | undefined;
    Name?: string | undefined;
    NodeInterfaceMappings?: NodeInterfaceMapping[] | undefined;
    Role?: NodeRole | undefined;
    State?: NodeState | undefined;
    SdiSourceMappings?: SdiSourceMapping[] | undefined;
}
export interface CreateNodeRegistrationScriptRequest {
    ClusterId: string;
    Id?: string | undefined;
    Name?: string | undefined;
    NodeInterfaceMappings?: NodeInterfaceMapping[] | undefined;
    RequestId?: string | undefined;
    Role?: NodeRole | undefined;
}
export interface CreateNodeRegistrationScriptResponse {
    NodeRegistrationScript?: string | undefined;
}
export interface CreatePartnerInputRequest {
    InputId: string;
    RequestId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreatePartnerInputResponse {
    Input?: (Input & {
        SrtSettings: SrtSettings & {
            SrtListenerSettings: SrtListenerSettings & {
                Decryption: SrtListenerDecryption & {
                    Algorithm: Algorithm;
                    PassphraseSecretArn: string;
                };
            };
        };
        MulticastSettings: MulticastSettings & {
            Sources: (MulticastSource & {
                Url: string;
            })[];
        };
    }) | undefined;
}
export type SdiSourceMode = "QUADRANT" | "INTERLEAVE" | (string & {});
export type SdiSourceType = "SINGLE" | "QUAD" | (string & {});
export interface CreateSdiSourceRequest {
    Mode?: SdiSourceMode | undefined;
    Name?: string | undefined;
    RequestId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: SdiSourceType | undefined;
}
export type SdiSourceState = "IDLE" | "IN_USE" | "DELETED" | (string & {});
export interface SdiSource {
    Arn?: string | undefined;
    Id?: string | undefined;
    Inputs?: string[] | undefined;
    Mode?: SdiSourceMode | undefined;
    Name?: string | undefined;
    State?: SdiSourceState | undefined;
    Type?: SdiSourceType | undefined;
}
export interface CreateSdiSourceResponse {
    SdiSource?: SdiSource | undefined;
}
export type __listOf__stringPatternS = string[];
export type __stringMin1Max2048 = string;
export interface CreateSignalMapRequest {
    CloudWatchAlarmTemplateGroupIdentifiers?: string[] | undefined;
    Description?: string | undefined;
    DiscoveryEntryPointArn?: string | undefined;
    EventBridgeRuleTemplateGroupIdentifiers?: string[] | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestId?: string | undefined;
}
export type __stringPatternArnMedialiveSignalMap = string;
export type __listOf__stringMin7Max11PatternAws097 = string[];
export interface MediaResourceNeighbor {
    Arn?: string | undefined;
    Name?: string | undefined;
}
export type __listOfMediaResourceNeighbor = MediaResourceNeighbor[];
export interface MediaResource {
    Destinations?: MediaResourceNeighbor[] | undefined;
    Name?: string | undefined;
    Sources?: MediaResourceNeighbor[] | undefined;
}
export type FailedMediaResourceMap = {
    [key: string]: MediaResource | undefined;
};
export type SignalMapMonitorDeploymentStatus = "NOT_DEPLOYED" | "DRY_RUN_DEPLOYMENT_COMPLETE" | "DRY_RUN_DEPLOYMENT_FAILED" | "DRY_RUN_DEPLOYMENT_IN_PROGRESS" | "DEPLOYMENT_COMPLETE" | "DEPLOYMENT_FAILED" | "DEPLOYMENT_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | "DELETE_IN_PROGRESS" | (string & {});
export interface SuccessfulMonitorDeployment {
    DetailsUri?: string | undefined;
    Status?: SignalMapMonitorDeploymentStatus | undefined;
}
export type MediaResourceMap = {
    [key: string]: MediaResource | undefined;
};
export interface MonitorDeployment {
    DetailsUri?: string | undefined;
    ErrorMessage?: string | undefined;
    Status?: SignalMapMonitorDeploymentStatus | undefined;
}
export type SignalMapStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE" | "UPDATE_REVERTED" | "UPDATE_FAILED" | "READY" | "NOT_READY" | (string & {});
export interface CreateSignalMapResponse {
    Arn?: string | undefined;
    CloudWatchAlarmTemplateGroupIds?: string[] | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    DiscoveryEntryPointArn?: string | undefined;
    ErrorMessage?: string | undefined;
    EventBridgeRuleTemplateGroupIds?: string[] | undefined;
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    Id?: string | undefined;
    LastDiscoveredAt?: Date | undefined;
    LastSuccessfulMonitorDeployment?: (SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    ModifiedAt?: Date | undefined;
    MonitorChangesPendingDeployment?: boolean | undefined;
    MonitorDeployment?: (MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    Name?: string | undefined;
    Status?: SignalMapStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateTagsRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateTagsResponse {
}
export interface DeleteChannelRequest {
    ChannelId: string;
}
export interface DeleteChannelResponse {
    Arn?: string | undefined;
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelClass?: ChannelClass | undefined;
    Destinations?: OutputDestination[] | undefined;
    EgressEndpoints?: ChannelEgressEndpoint[] | undefined;
    EncoderSettings?: (EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: number;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: number;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    FilterSettings: H264FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    FilterSettings: H265FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                    FilterSettings: Av1FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    }) | undefined;
    Id?: string | undefined;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceStatus | undefined;
    Name?: string | undefined;
    PipelineDetails?: PipelineDetail[] | undefined;
    PipelinesRunningCount?: number | undefined;
    RoleArn?: string | undefined;
    State?: ChannelState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Vpc?: VpcOutputSettingsDescription | undefined;
    AnywhereSettings?: DescribeAnywhereSettings | undefined;
    ChannelEngineVersion?: ChannelEngineVersionResponse | undefined;
    LinkedChannelSettings?: DescribeLinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: DescribeInferenceSettings | undefined;
}
export interface DeleteChannelPlacementGroupRequest {
    ChannelPlacementGroupId: string;
    ClusterId: string;
}
export interface DeleteChannelPlacementGroupResponse {
    Arn?: string | undefined;
    Channels?: string[] | undefined;
    ClusterId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Nodes?: string[] | undefined;
    State?: ChannelPlacementGroupState | undefined;
}
export interface DeleteCloudWatchAlarmTemplateRequest {
    Identifier: string;
}
export interface DeleteCloudWatchAlarmTemplateResponse {
}
export interface DeleteCloudWatchAlarmTemplateGroupRequest {
    Identifier: string;
}
export interface DeleteCloudWatchAlarmTemplateGroupResponse {
}
export interface DeleteClusterRequest {
    ClusterId: string;
}
export interface DeleteClusterResponse {
    Arn?: string | undefined;
    ChannelIds?: string[] | undefined;
    ClusterType?: ClusterType | undefined;
    Id?: string | undefined;
    InstanceRoleArn?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: ClusterNetworkSettings | undefined;
    State?: ClusterState | undefined;
}
export interface DeleteEventBridgeRuleTemplateRequest {
    Identifier: string;
}
export interface DeleteEventBridgeRuleTemplateResponse {
}
export interface DeleteEventBridgeRuleTemplateGroupRequest {
    Identifier: string;
}
export interface DeleteEventBridgeRuleTemplateGroupResponse {
}
export interface DeleteInputRequest {
    InputId: string;
}
export interface DeleteInputResponse {
}
export interface DeleteInputSecurityGroupRequest {
    InputSecurityGroupId: string;
}
export interface DeleteInputSecurityGroupResponse {
}
export interface DeleteMultiplexRequest {
    MultiplexId: string;
}
export interface DeleteMultiplexResponse {
    Arn?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    Destinations?: MultiplexOutputDestination[] | undefined;
    Id?: string | undefined;
    MultiplexSettings?: (MultiplexSettings & {
        TransportStreamBitrate: __integerMin1000000Max100000000;
        TransportStreamId: __integerMin0Max65535;
    }) | undefined;
    Name?: string | undefined;
    PipelinesRunningCount?: number | undefined;
    ProgramCount?: number | undefined;
    State?: MultiplexState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteMultiplexProgramRequest {
    MultiplexId: string;
    ProgramName: string;
}
export interface DeleteMultiplexProgramResponse {
    ChannelId?: string | undefined;
    MultiplexProgramSettings?: (MultiplexProgramSettings & {
        ProgramNumber: __integerMin0Max65535;
        ServiceDescriptor: MultiplexProgramServiceDescriptor & {
            ProviderName: __stringMax256;
            ServiceName: __stringMax256;
        };
    }) | undefined;
    PacketIdentifiersMap?: MultiplexProgramPacketIdentifiersMap | undefined;
    PipelineDetails?: MultiplexProgramPipelineDetail[] | undefined;
    ProgramName?: string | undefined;
}
export interface DeleteNetworkRequest {
    NetworkId: string;
}
export interface DeleteNetworkResponse {
    Arn?: string | undefined;
    AssociatedClusterIds?: string[] | undefined;
    Id?: string | undefined;
    IpPools?: IpPool[] | undefined;
    Name?: string | undefined;
    Routes?: Route[] | undefined;
    State?: NetworkState | undefined;
}
export interface DeleteNodeRequest {
    ClusterId: string;
    NodeId: string;
}
export interface DeleteNodeResponse {
    Arn?: string | undefined;
    ChannelPlacementGroups?: string[] | undefined;
    ClusterId?: string | undefined;
    ConnectionState?: NodeConnectionState | undefined;
    Id?: string | undefined;
    InstanceArn?: string | undefined;
    Name?: string | undefined;
    NodeInterfaceMappings?: NodeInterfaceMapping[] | undefined;
    Role?: NodeRole | undefined;
    State?: NodeState | undefined;
    SdiSourceMappings?: SdiSourceMapping[] | undefined;
}
export interface DeleteReservationRequest {
    ReservationId: string;
}
export type OfferingDurationUnits = "MONTHS" | (string & {});
export type OfferingType = "NO_UPFRONT" | (string & {});
export type ReservationAutomaticRenewal = "DISABLED" | "ENABLED" | "UNAVAILABLE" | (string & {});
export interface RenewalSettings {
    AutomaticRenewal?: ReservationAutomaticRenewal | undefined;
    RenewalCount?: number | undefined;
}
export type ReservationCodec = "MPEG2" | "AVC" | "HEVC" | "AUDIO" | "LINK" | "AV1" | (string & {});
export type ReservationMaximumBitrate = "MAX_10_MBPS" | "MAX_20_MBPS" | "MAX_50_MBPS" | (string & {});
export type ReservationMaximumFramerate = "MAX_30_FPS" | "MAX_60_FPS" | (string & {});
export type ReservationResolution = "SD" | "HD" | "FHD" | "UHD" | (string & {});
export type ReservationResourceType = "INPUT" | "OUTPUT" | "MULTIPLEX" | "CHANNEL" | (string & {});
export type ReservationSpecialFeature = "ADVANCED_AUDIO" | "AUDIO_NORMALIZATION" | "MGHD" | "MGUHD" | (string & {});
export type ReservationVideoQuality = "STANDARD" | "ENHANCED" | "PREMIUM" | (string & {});
export interface ReservationResourceSpecification {
    ChannelClass?: ChannelClass | undefined;
    Codec?: ReservationCodec | undefined;
    MaximumBitrate?: ReservationMaximumBitrate | undefined;
    MaximumFramerate?: ReservationMaximumFramerate | undefined;
    Resolution?: ReservationResolution | undefined;
    ResourceType?: ReservationResourceType | undefined;
    SpecialFeature?: ReservationSpecialFeature | undefined;
    VideoQuality?: ReservationVideoQuality | undefined;
}
export type ReservationState = "ACTIVE" | "EXPIRED" | "CANCELED" | "DELETED" | (string & {});
export interface DeleteReservationResponse {
    Arn?: string | undefined;
    Count?: number | undefined;
    CurrencyCode?: string | undefined;
    Duration?: number | undefined;
    DurationUnits?: OfferingDurationUnits | undefined;
    End?: string | undefined;
    FixedPrice?: number | undefined;
    Name?: string | undefined;
    OfferingDescription?: string | undefined;
    OfferingId?: string | undefined;
    OfferingType?: OfferingType | undefined;
    Region?: string | undefined;
    RenewalSettings?: RenewalSettings | undefined;
    ReservationId?: string | undefined;
    ResourceSpecification?: ReservationResourceSpecification | undefined;
    Start?: string | undefined;
    State?: ReservationState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UsagePrice?: number | undefined;
}
export interface DeleteScheduleRequest {
    ChannelId: string;
}
export interface DeleteScheduleResponse {
}
export interface DeleteSdiSourceRequest {
    SdiSourceId: string;
}
export interface DeleteSdiSourceResponse {
    SdiSource?: SdiSource | undefined;
}
export interface DeleteSignalMapRequest {
    Identifier: string;
}
export interface DeleteSignalMapResponse {
}
export interface DeleteTagsRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface DeleteTagsResponse {
}
export interface DescribeAccountConfigurationRequest {
}
export interface AccountConfiguration {
    KmsKeyId?: string | undefined;
}
export interface DescribeAccountConfigurationResponse {
    AccountConfiguration?: AccountConfiguration | undefined;
}
export interface DescribeChannelRequest {
    ChannelId: string;
}
export interface DescribeChannelResponse {
    Arn?: string | undefined;
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelClass?: ChannelClass | undefined;
    Destinations?: OutputDestination[] | undefined;
    EgressEndpoints?: ChannelEgressEndpoint[] | undefined;
    EncoderSettings?: (EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: number;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: number;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    FilterSettings: H264FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    FilterSettings: H265FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                    FilterSettings: Av1FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    }) | undefined;
    Id?: string | undefined;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceStatus | undefined;
    Name?: string | undefined;
    PipelineDetails?: PipelineDetail[] | undefined;
    PipelinesRunningCount?: number | undefined;
    RoleArn?: string | undefined;
    State?: ChannelState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Vpc?: VpcOutputSettingsDescription | undefined;
    AnywhereSettings?: DescribeAnywhereSettings | undefined;
    ChannelEngineVersion?: ChannelEngineVersionResponse | undefined;
    LinkedChannelSettings?: DescribeLinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: DescribeInferenceSettings | undefined;
}
export interface DescribeChannelPlacementGroupRequest {
    ChannelPlacementGroupId: string;
    ClusterId: string;
}
export interface DescribeChannelPlacementGroupResponse {
    Arn?: string | undefined;
    Channels?: string[] | undefined;
    ClusterId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Nodes?: string[] | undefined;
    State?: ChannelPlacementGroupState | undefined;
}
export interface DescribeClusterRequest {
    ClusterId: string;
}
export interface DescribeClusterResponse {
    Arn?: string | undefined;
    ChannelIds?: string[] | undefined;
    ClusterType?: ClusterType | undefined;
    Id?: string | undefined;
    InstanceRoleArn?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: ClusterNetworkSettings | undefined;
    State?: ClusterState | undefined;
}
export interface DescribeInputRequest {
    InputId: string;
}
export interface DescribeInputResponse {
    Arn?: string | undefined;
    AttachedChannels?: string[] | undefined;
    Destinations?: InputDestination[] | undefined;
    Id?: string | undefined;
    InputClass?: InputClass | undefined;
    InputDevices?: InputDeviceSettings[] | undefined;
    InputPartnerIds?: string[] | undefined;
    InputSourceType?: InputSourceType | undefined;
    MediaConnectFlows?: MediaConnectFlow[] | undefined;
    Name?: string | undefined;
    RoleArn?: string | undefined;
    SecurityGroups?: string[] | undefined;
    Sources?: InputSource[] | undefined;
    State?: InputState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: InputType | undefined;
    SrtSettings?: (SrtSettings & {
        SrtListenerSettings: SrtListenerSettings & {
            Decryption: SrtListenerDecryption & {
                Algorithm: Algorithm;
                PassphraseSecretArn: string;
            };
        };
    }) | undefined;
    InputNetworkLocation?: InputNetworkLocation | undefined;
    MulticastSettings?: (MulticastSettings & {
        Sources: (MulticastSource & {
            Url: string;
        })[];
    }) | undefined;
    Smpte2110ReceiverGroupSettings?: Smpte2110ReceiverGroupSettings | undefined;
    SdiSources?: string[] | undefined;
    RouterSettings?: RouterInputSettings | undefined;
}
export interface DescribeInputDeviceRequest {
    InputDeviceId: string;
}
export type InputDeviceConnectionState = "DISCONNECTED" | "CONNECTED" | (string & {});
export type DeviceSettingsSyncState = "SYNCED" | "SYNCING" | (string & {});
export type DeviceUpdateStatus = "UP_TO_DATE" | "NOT_UP_TO_DATE" | "UPDATING" | (string & {});
export type InputDeviceActiveInput = "HDMI" | "SDI" | (string & {});
export type InputDeviceConfiguredInput = "AUTO" | "HDMI" | "SDI" | (string & {});
export type InputDeviceState = "IDLE" | "STREAMING" | (string & {});
export type InputDeviceScanType = "INTERLACED" | "PROGRESSIVE" | (string & {});
export interface InputDeviceHdSettings {
    ActiveInput?: InputDeviceActiveInput | undefined;
    ConfiguredInput?: InputDeviceConfiguredInput | undefined;
    DeviceState?: InputDeviceState | undefined;
    Framerate?: number | undefined;
    Height?: number | undefined;
    MaxBitrate?: number | undefined;
    ScanType?: InputDeviceScanType | undefined;
    Width?: number | undefined;
    LatencyMs?: number | undefined;
}
export type InputDeviceIpScheme = "STATIC" | "DHCP" | (string & {});
export interface InputDeviceNetworkSettings {
    DnsAddresses?: string[] | undefined;
    Gateway?: string | undefined;
    IpAddress?: string | undefined;
    IpScheme?: InputDeviceIpScheme | undefined;
    SubnetMask?: string | undefined;
}
export type InputDeviceType = "HD" | "UHD" | (string & {});
export type InputDeviceCodec = "HEVC" | "AVC" | (string & {});
export interface InputDeviceMediaConnectSettings {
    FlowArn?: string | undefined;
    RoleArn?: string | undefined;
    SecretArn?: string | undefined;
    SourceName?: string | undefined;
}
export type InputDeviceUhdAudioChannelPairProfile = "DISABLED" | "VBR-AAC_HHE-16000" | "VBR-AAC_HE-64000" | "VBR-AAC_LC-128000" | "CBR-AAC_HQ-192000" | "CBR-AAC_HQ-256000" | "CBR-AAC_HQ-384000" | "CBR-AAC_HQ-512000" | (string & {});
export interface InputDeviceUhdAudioChannelPairConfig {
    Id?: number | undefined;
    Profile?: InputDeviceUhdAudioChannelPairProfile | undefined;
}
export type __listOfInputDeviceUhdAudioChannelPairConfig = InputDeviceUhdAudioChannelPairConfig[];
export interface InputDeviceUhdSettings {
    ActiveInput?: InputDeviceActiveInput | undefined;
    ConfiguredInput?: InputDeviceConfiguredInput | undefined;
    DeviceState?: InputDeviceState | undefined;
    Framerate?: number | undefined;
    Height?: number | undefined;
    MaxBitrate?: number | undefined;
    ScanType?: InputDeviceScanType | undefined;
    Width?: number | undefined;
    LatencyMs?: number | undefined;
    Codec?: InputDeviceCodec | undefined;
    MediaconnectSettings?: InputDeviceMediaConnectSettings | undefined;
    AudioChannelPairs?: InputDeviceUhdAudioChannelPairConfig[] | undefined;
    InputResolution?: string | undefined;
}
export type InputDeviceOutputType = "NONE" | "MEDIALIVE_INPUT" | "MEDIACONNECT_FLOW" | (string & {});
export interface DescribeInputDeviceResponse {
    Arn?: string | undefined;
    ConnectionState?: InputDeviceConnectionState | undefined;
    DeviceSettingsSyncState?: DeviceSettingsSyncState | undefined;
    DeviceUpdateStatus?: DeviceUpdateStatus | undefined;
    HdDeviceSettings?: InputDeviceHdSettings | undefined;
    Id?: string | undefined;
    MacAddress?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: InputDeviceNetworkSettings | undefined;
    SerialNumber?: string | undefined;
    Type?: InputDeviceType | undefined;
    UhdDeviceSettings?: InputDeviceUhdSettings | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    AvailabilityZone?: string | undefined;
    MedialiveInputArns?: string[] | undefined;
    OutputType?: InputDeviceOutputType | undefined;
}
export type AcceptHeader = "image/jpeg" | (string & {});
export interface DescribeInputDeviceThumbnailRequest {
    InputDeviceId: string;
    Accept?: AcceptHeader | undefined;
}
export type ContentType = "image/jpeg" | (string & {});
export type __timestamp = Date;
export interface DescribeInputDeviceThumbnailResponse {
    Body?: T.StreamingOutputBody | undefined;
    ContentType?: ContentType | undefined;
    ContentLength?: number | undefined;
    ETag?: string | undefined;
    LastModified?: Date | undefined;
}
export interface DescribeInputSecurityGroupRequest {
    InputSecurityGroupId: string;
}
export interface DescribeInputSecurityGroupResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
    Inputs?: string[] | undefined;
    State?: InputSecurityGroupState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    WhitelistRules?: InputWhitelistRule[] | undefined;
    Channels?: string[] | undefined;
}
export interface DescribeMultiplexRequest {
    MultiplexId: string;
}
export interface DescribeMultiplexResponse {
    Arn?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    Destinations?: MultiplexOutputDestination[] | undefined;
    Id?: string | undefined;
    MultiplexSettings?: (MultiplexSettings & {
        TransportStreamBitrate: __integerMin1000000Max100000000;
        TransportStreamId: __integerMin0Max65535;
    }) | undefined;
    Name?: string | undefined;
    PipelinesRunningCount?: number | undefined;
    ProgramCount?: number | undefined;
    State?: MultiplexState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeMultiplexProgramRequest {
    MultiplexId: string;
    ProgramName: string;
}
export interface DescribeMultiplexProgramResponse {
    ChannelId?: string | undefined;
    MultiplexProgramSettings?: (MultiplexProgramSettings & {
        ProgramNumber: __integerMin0Max65535;
        ServiceDescriptor: MultiplexProgramServiceDescriptor & {
            ProviderName: __stringMax256;
            ServiceName: __stringMax256;
        };
    }) | undefined;
    PacketIdentifiersMap?: MultiplexProgramPacketIdentifiersMap | undefined;
    PipelineDetails?: MultiplexProgramPipelineDetail[] | undefined;
    ProgramName?: string | undefined;
}
export interface DescribeNetworkRequest {
    NetworkId: string;
}
export interface DescribeNetworkResponse {
    Arn?: string | undefined;
    AssociatedClusterIds?: string[] | undefined;
    Id?: string | undefined;
    IpPools?: IpPool[] | undefined;
    Name?: string | undefined;
    Routes?: Route[] | undefined;
    State?: NetworkState | undefined;
}
export interface DescribeNodeRequest {
    ClusterId: string;
    NodeId: string;
}
export interface DescribeNodeResponse {
    Arn?: string | undefined;
    ChannelPlacementGroups?: string[] | undefined;
    ClusterId?: string | undefined;
    ConnectionState?: NodeConnectionState | undefined;
    Id?: string | undefined;
    InstanceArn?: string | undefined;
    Name?: string | undefined;
    NodeInterfaceMappings?: NodeInterfaceMapping[] | undefined;
    Role?: NodeRole | undefined;
    State?: NodeState | undefined;
    SdiSourceMappings?: SdiSourceMapping[] | undefined;
}
export interface DescribeOfferingRequest {
    OfferingId: string;
}
export interface DescribeOfferingResponse {
    Arn?: string | undefined;
    CurrencyCode?: string | undefined;
    Duration?: number | undefined;
    DurationUnits?: OfferingDurationUnits | undefined;
    FixedPrice?: number | undefined;
    OfferingDescription?: string | undefined;
    OfferingId?: string | undefined;
    OfferingType?: OfferingType | undefined;
    Region?: string | undefined;
    ResourceSpecification?: ReservationResourceSpecification | undefined;
    UsagePrice?: number | undefined;
}
export interface DescribeReservationRequest {
    ReservationId: string;
}
export interface DescribeReservationResponse {
    Arn?: string | undefined;
    Count?: number | undefined;
    CurrencyCode?: string | undefined;
    Duration?: number | undefined;
    DurationUnits?: OfferingDurationUnits | undefined;
    End?: string | undefined;
    FixedPrice?: number | undefined;
    Name?: string | undefined;
    OfferingDescription?: string | undefined;
    OfferingId?: string | undefined;
    OfferingType?: OfferingType | undefined;
    Region?: string | undefined;
    RenewalSettings?: RenewalSettings | undefined;
    ReservationId?: string | undefined;
    ResourceSpecification?: ReservationResourceSpecification | undefined;
    Start?: string | undefined;
    State?: ReservationState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UsagePrice?: number | undefined;
}
export type MaxResults = number;
export interface DescribeScheduleRequest {
    ChannelId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeScheduleResponse {
    NextToken?: string | undefined;
    ScheduleActions?: (ScheduleAction & {
        ActionName: string;
        ScheduleActionSettings: ScheduleActionSettings & {
            HlsTimedMetadataSettings: HlsTimedMetadataScheduleActionSettings & {
                Id3: string;
            };
            InputPrepareSettings: InputPrepareScheduleActionSettings & {
                InputClippingSettings: InputClippingSettings & {
                    InputTimecodeSource: InputTimecodeSource;
                };
            };
            InputSwitchSettings: InputSwitchScheduleActionSettings & {
                InputAttachmentNameReference: string;
                InputClippingSettings: InputClippingSettings & {
                    InputTimecodeSource: InputTimecodeSource;
                };
            };
            PauseStateSettings: PauseStateScheduleActionSettings & {
                Pipelines: (PipelinePauseStateSettings & {
                    PipelineId: PipelineId;
                })[];
            };
            Scte35InputSettings: Scte35InputScheduleActionSettings & {
                Mode: Scte35InputMode;
            };
            Scte35ReturnToNetworkSettings: Scte35ReturnToNetworkScheduleActionSettings & {
                SpliceEventId: __longMin0Max4294967295;
            };
            Scte35SpliceInsertSettings: Scte35SpliceInsertScheduleActionSettings & {
                SpliceEventId: __longMin0Max4294967295;
            };
            Scte35TimeSignalSettings: Scte35TimeSignalScheduleActionSettings & {
                Scte35Descriptors: (Scte35Descriptor & {
                    Scte35DescriptorSettings: Scte35DescriptorSettings & {
                        SegmentationDescriptorScte35DescriptorSettings: Scte35SegmentationDescriptor & {
                            SegmentationCancelIndicator: Scte35SegmentationCancelIndicator;
                            SegmentationEventId: __longMin0Max4294967295;
                            DeliveryRestrictions: Scte35DeliveryRestrictions & {
                                ArchiveAllowedFlag: Scte35ArchiveAllowedFlag;
                                DeviceRestrictions: Scte35DeviceRestrictions;
                                NoRegionalBlackoutFlag: Scte35NoRegionalBlackoutFlag;
                                WebDeliveryAllowedFlag: Scte35WebDeliveryAllowedFlag;
                            };
                        };
                    };
                })[];
            };
            StaticImageActivateSettings: StaticImageActivateScheduleActionSettings & {
                Image: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            StaticImageOutputActivateSettings: StaticImageOutputActivateScheduleActionSettings & {
                Image: InputLocation & {
                    Uri: __stringMax2048;
                };
                OutputNames: __listOf__string;
            };
            StaticImageOutputDeactivateSettings: StaticImageOutputDeactivateScheduleActionSettings & {
                OutputNames: __listOf__string;
            };
            TimedMetadataSettings: TimedMetadataScheduleActionSettings & {
                Id3: string;
            };
        };
        ScheduleActionStartSettings: ScheduleActionStartSettings & {
            FixedModeScheduleActionStartSettings: FixedModeScheduleActionStartSettings & {
                Time: string;
            };
            FollowModeScheduleActionStartSettings: FollowModeScheduleActionStartSettings & {
                FollowPoint: FollowPoint;
                ReferenceActionName: string;
            };
        };
    })[] | undefined;
}
export interface DescribeSdiSourceRequest {
    SdiSourceId: string;
}
export interface DescribeSdiSourceResponse {
    SdiSource?: SdiSource | undefined;
}
export interface DescribeThumbnailsRequest {
    ChannelId: string;
    PipelineId?: string | undefined;
    ThumbnailType?: string | undefined;
}
export type ThumbnailType = "UNSPECIFIED" | "CURRENT_ACTIVE" | (string & {});
export interface Thumbnail {
    Body?: string | undefined;
    ContentType?: string | undefined;
    ThumbnailType?: ThumbnailType | undefined;
    TimeStamp?: Date | undefined;
}
export type __listOfThumbnail = Thumbnail[];
export interface ThumbnailDetail {
    PipelineId?: string | undefined;
    Thumbnails?: Thumbnail[] | undefined;
}
export type __listOfThumbnailDetail = ThumbnailDetail[];
export interface DescribeThumbnailsResponse {
    ThumbnailDetails?: ThumbnailDetail[] | undefined;
}
export interface GetCloudWatchAlarmTemplateRequest {
    Identifier: string;
}
export interface GetCloudWatchAlarmTemplateResponse {
    Arn?: string | undefined;
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator | undefined;
    CreatedAt?: Date | undefined;
    DatapointsToAlarm?: number | undefined;
    Description?: string | undefined;
    EvaluationPeriods?: number | undefined;
    GroupId?: string | undefined;
    Id?: string | undefined;
    MetricName?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Period?: number | undefined;
    Statistic?: CloudWatchAlarmTemplateStatistic | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType | undefined;
    Threshold?: number | undefined;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData | undefined;
}
export interface GetCloudWatchAlarmTemplateGroupRequest {
    Identifier: string;
}
export interface GetCloudWatchAlarmTemplateGroupResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetEventBridgeRuleTemplateRequest {
    Identifier: string;
}
export interface GetEventBridgeRuleTemplateResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    EventTargets?: (EventBridgeRuleTemplateTarget & {
        Arn: __stringMin1Max2048PatternArn;
    })[] | undefined;
    EventType?: EventBridgeRuleTemplateEventType | undefined;
    GroupId?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetEventBridgeRuleTemplateGroupRequest {
    Identifier: string;
}
export interface GetEventBridgeRuleTemplateGroupResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetSignalMapRequest {
    Identifier: string;
}
export interface GetSignalMapResponse {
    Arn?: string | undefined;
    CloudWatchAlarmTemplateGroupIds?: string[] | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    DiscoveryEntryPointArn?: string | undefined;
    ErrorMessage?: string | undefined;
    EventBridgeRuleTemplateGroupIds?: string[] | undefined;
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    Id?: string | undefined;
    LastDiscoveredAt?: Date | undefined;
    LastSuccessfulMonitorDeployment?: (SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    ModifiedAt?: Date | undefined;
    MonitorChangesPendingDeployment?: boolean | undefined;
    MonitorDeployment?: (MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    Name?: string | undefined;
    Status?: SignalMapStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListAlertsRequest {
    ChannelId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    StateFilter?: string | undefined;
}
export type ChannelAlertState = "SET" | "CLEARED" | (string & {});
export interface ChannelAlert {
    AlertType?: string | undefined;
    ClearedTimestamp?: Date | undefined;
    Id?: string | undefined;
    Message?: string | undefined;
    PipelineId?: string | undefined;
    SetTimestamp?: Date | undefined;
    State?: ChannelAlertState | undefined;
}
export type __listOfChannelAlert = ChannelAlert[];
export interface ListAlertsResponse {
    Alerts?: ChannelAlert[] | undefined;
    NextToken?: string | undefined;
}
export interface ListChannelPlacementGroupsRequest {
    ClusterId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeChannelPlacementGroupSummary {
    Arn?: string | undefined;
    Channels?: string[] | undefined;
    ClusterId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Nodes?: string[] | undefined;
    State?: ChannelPlacementGroupState | undefined;
}
export type __listOfDescribeChannelPlacementGroupSummary = DescribeChannelPlacementGroupSummary[];
export interface ListChannelPlacementGroupsResponse {
    ChannelPlacementGroups?: DescribeChannelPlacementGroupSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListChannelsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfChannelEngineVersionResponse = ChannelEngineVersionResponse[];
export interface ChannelSummary {
    Arn?: string | undefined;
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelClass?: ChannelClass | undefined;
    Destinations?: OutputDestination[] | undefined;
    EgressEndpoints?: ChannelEgressEndpoint[] | undefined;
    Id?: string | undefined;
    InputAttachments?: InputAttachment[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceStatus | undefined;
    Name?: string | undefined;
    PipelinesRunningCount?: number | undefined;
    RoleArn?: string | undefined;
    State?: ChannelState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Vpc?: VpcOutputSettingsDescription | undefined;
    AnywhereSettings?: DescribeAnywhereSettings | undefined;
    ChannelEngineVersion?: ChannelEngineVersionResponse | undefined;
    UsedChannelEngineVersions?: ChannelEngineVersionResponse[] | undefined;
    LinkedChannelSettings?: DescribeLinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: DescribeInferenceSettings | undefined;
}
export type __listOfChannelSummary = ChannelSummary[];
export interface ListChannelsResponse {
    Channels?: (ChannelSummary & {
        InputAttachments: (InputAttachment & {
            AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
                SecondaryInputId: string;
                FailoverConditions: (FailoverCondition & {
                    FailoverConditionSettings: FailoverConditionSettings & {
                        AudioSilenceSettings: AudioSilenceFailoverSettings & {
                            AudioSelectorName: string;
                        };
                    };
                })[];
            };
            InputSettings: InputSettings & {
                AudioSelectors: (AudioSelector & {
                    Name: __stringMin1;
                    SelectorSettings: AudioSelectorSettings & {
                        AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                            GroupId: __stringMin1;
                            Name: __stringMin1;
                        };
                        AudioLanguageSelection: AudioLanguageSelection & {
                            LanguageCode: string;
                        };
                        AudioPidSelection: AudioPidSelection & {
                            Pid: __integerMin0Max8191;
                            Pids: (AudioPid & {
                                Pid: __integerMin0Max8191;
                                DolbyEDecode: AudioDolbyEDecode & {
                                    ProgramSelection: DolbyEProgramSelection;
                                };
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                        };
                        AudioTrackSelection: AudioTrackSelection & {
                            Tracks: (AudioTrack & {
                                Track: __integerMin1;
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                        };
                    };
                })[];
                CaptionSelectors: (CaptionSelector & {
                    Name: __stringMin1;
                    SelectorSettings: CaptionSelectorSettings & {
                        TeletextSourceSettings: TeletextSourceSettings & {
                            OutputRectangle: CaptionRectangle & {
                                Height: __doubleMin0Max100;
                                LeftOffset: __doubleMin0Max100;
                                TopOffset: __doubleMin0Max100;
                                Width: __doubleMin0Max100;
                            };
                        };
                    };
                })[];
            };
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCloudWatchAlarmTemplateGroupsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Scope?: string | undefined;
    SignalMapIdentifier?: string | undefined;
}
export interface CloudWatchAlarmTemplateGroupSummary {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateCount?: number | undefined;
}
export type __listOfCloudWatchAlarmTemplateGroupSummary = CloudWatchAlarmTemplateGroupSummary[];
export interface ListCloudWatchAlarmTemplateGroupsResponse {
    CloudWatchAlarmTemplateGroups?: (CloudWatchAlarmTemplateGroupSummary & {
        Arn: __stringPatternArnMedialiveCloudwatchAlarmTemplateGroup;
        CreatedAt: __timestampIso8601;
        Id: __stringMin7Max11PatternAws097;
        Name: __stringMin1Max255PatternS;
        TemplateCount: number;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCloudWatchAlarmTemplatesRequest {
    GroupIdentifier?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Scope?: string | undefined;
    SignalMapIdentifier?: string | undefined;
}
export interface CloudWatchAlarmTemplateSummary {
    Arn?: string | undefined;
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator | undefined;
    CreatedAt?: Date | undefined;
    DatapointsToAlarm?: number | undefined;
    Description?: string | undefined;
    EvaluationPeriods?: number | undefined;
    GroupId?: string | undefined;
    Id?: string | undefined;
    MetricName?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Period?: number | undefined;
    Statistic?: CloudWatchAlarmTemplateStatistic | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType | undefined;
    Threshold?: number | undefined;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData | undefined;
}
export type __listOfCloudWatchAlarmTemplateSummary = CloudWatchAlarmTemplateSummary[];
export interface ListCloudWatchAlarmTemplatesResponse {
    CloudWatchAlarmTemplates?: (CloudWatchAlarmTemplateSummary & {
        Arn: __stringPatternArnMedialiveCloudwatchAlarmTemplate;
        ComparisonOperator: CloudWatchAlarmTemplateComparisonOperator;
        CreatedAt: __timestampIso8601;
        EvaluationPeriods: __integerMin1;
        GroupId: __stringMin7Max11PatternAws097;
        Id: __stringMin7Max11PatternAws097;
        MetricName: __stringMax64;
        Name: __stringMin1Max255PatternS;
        Period: __integerMin10Max86400;
        Statistic: CloudWatchAlarmTemplateStatistic;
        TargetResourceType: CloudWatchAlarmTemplateTargetResourceType;
        Threshold: number;
        TreatMissingData: CloudWatchAlarmTemplateTreatMissingData;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClusterAlertsRequest {
    ClusterId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    StateFilter?: string | undefined;
}
export type ClusterAlertState = "SET" | "CLEARED" | (string & {});
export interface ClusterAlert {
    AlertType?: string | undefined;
    ChannelId?: string | undefined;
    ClearedTimestamp?: Date | undefined;
    Id?: string | undefined;
    Message?: string | undefined;
    NodeId?: string | undefined;
    SetTimestamp?: Date | undefined;
    State?: ClusterAlertState | undefined;
}
export type __listOfClusterAlert = ClusterAlert[];
export interface ListClusterAlertsResponse {
    Alerts?: ClusterAlert[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClustersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeClusterSummary {
    Arn?: string | undefined;
    ChannelIds?: string[] | undefined;
    ClusterType?: ClusterType | undefined;
    Id?: string | undefined;
    InstanceRoleArn?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: ClusterNetworkSettings | undefined;
    State?: ClusterState | undefined;
}
export type __listOfDescribeClusterSummary = DescribeClusterSummary[];
export interface ListClustersResponse {
    Clusters?: DescribeClusterSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventBridgeRuleTemplateGroupsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    SignalMapIdentifier?: string | undefined;
}
export interface EventBridgeRuleTemplateGroupSummary {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateCount?: number | undefined;
}
export type __listOfEventBridgeRuleTemplateGroupSummary = EventBridgeRuleTemplateGroupSummary[];
export interface ListEventBridgeRuleTemplateGroupsResponse {
    EventBridgeRuleTemplateGroups?: (EventBridgeRuleTemplateGroupSummary & {
        Arn: __stringPatternArnMedialiveEventbridgeRuleTemplateGroup;
        CreatedAt: __timestampIso8601;
        Id: __stringMin7Max11PatternAws097;
        Name: __stringMin1Max255PatternS;
        TemplateCount: number;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventBridgeRuleTemplatesRequest {
    GroupIdentifier?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    SignalMapIdentifier?: string | undefined;
}
export type __integerMax5 = number;
export interface EventBridgeRuleTemplateSummary {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    EventTargetCount?: number | undefined;
    EventType?: EventBridgeRuleTemplateEventType | undefined;
    GroupId?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfEventBridgeRuleTemplateSummary = EventBridgeRuleTemplateSummary[];
export interface ListEventBridgeRuleTemplatesResponse {
    EventBridgeRuleTemplates?: (EventBridgeRuleTemplateSummary & {
        Arn: __stringPatternArnMedialiveEventbridgeRuleTemplate;
        CreatedAt: __timestampIso8601;
        EventTargetCount: __integerMax5;
        EventType: EventBridgeRuleTemplateEventType;
        GroupId: __stringMin7Max11PatternAws097;
        Id: __stringMin7Max11PatternAws097;
        Name: __stringMin1Max255PatternS;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListInputDevicesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface InputDeviceSummary {
    Arn?: string | undefined;
    ConnectionState?: InputDeviceConnectionState | undefined;
    DeviceSettingsSyncState?: DeviceSettingsSyncState | undefined;
    DeviceUpdateStatus?: DeviceUpdateStatus | undefined;
    HdDeviceSettings?: InputDeviceHdSettings | undefined;
    Id?: string | undefined;
    MacAddress?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: InputDeviceNetworkSettings | undefined;
    SerialNumber?: string | undefined;
    Type?: InputDeviceType | undefined;
    UhdDeviceSettings?: InputDeviceUhdSettings | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    AvailabilityZone?: string | undefined;
    MedialiveInputArns?: string[] | undefined;
    OutputType?: InputDeviceOutputType | undefined;
}
export type __listOfInputDeviceSummary = InputDeviceSummary[];
export interface ListInputDevicesResponse {
    InputDevices?: InputDeviceSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListInputDeviceTransfersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    TransferType?: string | undefined;
}
export type InputDeviceTransferType = "OUTGOING" | "INCOMING" | (string & {});
export interface TransferringInputDeviceSummary {
    Id?: string | undefined;
    Message?: string | undefined;
    TargetCustomerId?: string | undefined;
    TransferType?: InputDeviceTransferType | undefined;
}
export type __listOfTransferringInputDeviceSummary = TransferringInputDeviceSummary[];
export interface ListInputDeviceTransfersResponse {
    InputDeviceTransfers?: TransferringInputDeviceSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListInputsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfInput = Input[];
export interface ListInputsResponse {
    Inputs?: (Input & {
        SrtSettings: SrtSettings & {
            SrtListenerSettings: SrtListenerSettings & {
                Decryption: SrtListenerDecryption & {
                    Algorithm: Algorithm;
                    PassphraseSecretArn: string;
                };
            };
        };
        MulticastSettings: MulticastSettings & {
            Sources: (MulticastSource & {
                Url: string;
            })[];
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListInputSecurityGroupsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfInputSecurityGroup = InputSecurityGroup[];
export interface ListInputSecurityGroupsResponse {
    InputSecurityGroups?: InputSecurityGroup[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMultiplexAlertsRequest {
    MaxResults?: number | undefined;
    MultiplexId: string;
    NextToken?: string | undefined;
    StateFilter?: string | undefined;
}
export type MultiplexAlertState = "SET" | "CLEARED" | (string & {});
export interface MultiplexAlert {
    AlertType?: string | undefined;
    ClearedTimestamp?: Date | undefined;
    Id?: string | undefined;
    Message?: string | undefined;
    PipelineId?: string | undefined;
    SetTimestamp?: Date | undefined;
    State?: MultiplexAlertState | undefined;
}
export type __listOfMultiplexAlert = MultiplexAlert[];
export interface ListMultiplexAlertsResponse {
    Alerts?: MultiplexAlert[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMultiplexesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface MultiplexSettingsSummary {
    TransportStreamBitrate?: number | undefined;
}
export interface MultiplexSummary {
    Arn?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    Id?: string | undefined;
    MultiplexSettings?: MultiplexSettingsSummary | undefined;
    Name?: string | undefined;
    PipelinesRunningCount?: number | undefined;
    ProgramCount?: number | undefined;
    State?: MultiplexState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfMultiplexSummary = MultiplexSummary[];
export interface ListMultiplexesResponse {
    Multiplexes?: MultiplexSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMultiplexProgramsRequest {
    MaxResults?: number | undefined;
    MultiplexId: string;
    NextToken?: string | undefined;
}
export interface MultiplexProgramSummary {
    ChannelId?: string | undefined;
    ProgramName?: string | undefined;
}
export type __listOfMultiplexProgramSummary = MultiplexProgramSummary[];
export interface ListMultiplexProgramsResponse {
    MultiplexPrograms?: MultiplexProgramSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListNetworksRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeNetworkSummary {
    Arn?: string | undefined;
    AssociatedClusterIds?: string[] | undefined;
    Id?: string | undefined;
    IpPools?: IpPool[] | undefined;
    Name?: string | undefined;
    Routes?: Route[] | undefined;
    State?: NetworkState | undefined;
}
export type __listOfDescribeNetworkSummary = DescribeNetworkSummary[];
export interface ListNetworksResponse {
    Networks?: DescribeNetworkSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListNodesRequest {
    ClusterId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeNodeSummary {
    Arn?: string | undefined;
    ChannelPlacementGroups?: string[] | undefined;
    ClusterId?: string | undefined;
    ConnectionState?: NodeConnectionState | undefined;
    Id?: string | undefined;
    InstanceArn?: string | undefined;
    ManagedInstanceId?: string | undefined;
    Name?: string | undefined;
    NodeInterfaceMappings?: NodeInterfaceMapping[] | undefined;
    Role?: NodeRole | undefined;
    State?: NodeState | undefined;
    SdiSourceMappings?: SdiSourceMapping[] | undefined;
}
export type __listOfDescribeNodeSummary = DescribeNodeSummary[];
export interface ListNodesResponse {
    NextToken?: string | undefined;
    Nodes?: DescribeNodeSummary[] | undefined;
}
export interface ListOfferingsRequest {
    ChannelClass?: string | undefined;
    ChannelConfiguration?: string | undefined;
    Codec?: string | undefined;
    Duration?: string | undefined;
    MaxResults?: number | undefined;
    MaximumBitrate?: string | undefined;
    MaximumFramerate?: string | undefined;
    NextToken?: string | undefined;
    Resolution?: string | undefined;
    ResourceType?: string | undefined;
    SpecialFeature?: string | undefined;
    VideoQuality?: string | undefined;
}
export interface Offering {
    Arn?: string | undefined;
    CurrencyCode?: string | undefined;
    Duration?: number | undefined;
    DurationUnits?: OfferingDurationUnits | undefined;
    FixedPrice?: number | undefined;
    OfferingDescription?: string | undefined;
    OfferingId?: string | undefined;
    OfferingType?: OfferingType | undefined;
    Region?: string | undefined;
    ResourceSpecification?: ReservationResourceSpecification | undefined;
    UsagePrice?: number | undefined;
}
export type __listOfOffering = Offering[];
export interface ListOfferingsResponse {
    NextToken?: string | undefined;
    Offerings?: Offering[] | undefined;
}
export interface ListReservationsRequest {
    ChannelClass?: string | undefined;
    Codec?: string | undefined;
    MaxResults?: number | undefined;
    MaximumBitrate?: string | undefined;
    MaximumFramerate?: string | undefined;
    NextToken?: string | undefined;
    Resolution?: string | undefined;
    ResourceType?: string | undefined;
    SpecialFeature?: string | undefined;
    VideoQuality?: string | undefined;
}
export interface Reservation {
    Arn?: string | undefined;
    Count?: number | undefined;
    CurrencyCode?: string | undefined;
    Duration?: number | undefined;
    DurationUnits?: OfferingDurationUnits | undefined;
    End?: string | undefined;
    FixedPrice?: number | undefined;
    Name?: string | undefined;
    OfferingDescription?: string | undefined;
    OfferingId?: string | undefined;
    OfferingType?: OfferingType | undefined;
    Region?: string | undefined;
    RenewalSettings?: RenewalSettings | undefined;
    ReservationId?: string | undefined;
    ResourceSpecification?: ReservationResourceSpecification | undefined;
    Start?: string | undefined;
    State?: ReservationState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UsagePrice?: number | undefined;
}
export type __listOfReservation = Reservation[];
export interface ListReservationsResponse {
    NextToken?: string | undefined;
    Reservations?: Reservation[] | undefined;
}
export interface ListSdiSourcesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SdiSourceSummary {
    Arn?: string | undefined;
    Id?: string | undefined;
    Inputs?: string[] | undefined;
    Mode?: SdiSourceMode | undefined;
    Name?: string | undefined;
    State?: SdiSourceState | undefined;
    Type?: SdiSourceType | undefined;
}
export type __listOfSdiSourceSummary = SdiSourceSummary[];
export interface ListSdiSourcesResponse {
    NextToken?: string | undefined;
    SdiSources?: SdiSourceSummary[] | undefined;
}
export interface ListSignalMapsRequest {
    CloudWatchAlarmTemplateGroupIdentifier?: string | undefined;
    EventBridgeRuleTemplateGroupIdentifier?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SignalMapSummary {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    MonitorDeploymentStatus?: SignalMapMonitorDeploymentStatus | undefined;
    Name?: string | undefined;
    Status?: SignalMapStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfSignalMapSummary = SignalMapSummary[];
export interface ListSignalMapsResponse {
    NextToken?: string | undefined;
    SignalMaps?: (SignalMapSummary & {
        Arn: __stringPatternArnMedialiveSignalMap;
        CreatedAt: __timestampIso8601;
        Id: __stringMin7Max11PatternAws097;
        MonitorDeploymentStatus: SignalMapMonitorDeploymentStatus;
        Name: __stringMin1Max255PatternS;
        Status: SignalMapStatus;
    })[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListVersionsRequest {
}
export interface ListVersionsResponse {
    Versions?: ChannelEngineVersionResponse[] | undefined;
}
export interface PurchaseOfferingRequest {
    Count?: number | undefined;
    Name?: string | undefined;
    OfferingId: string;
    RenewalSettings?: RenewalSettings | undefined;
    RequestId?: string | undefined;
    Start?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PurchaseOfferingResponse {
    Reservation?: Reservation | undefined;
}
export type RebootInputDeviceForce = "NO" | "YES" | (string & {});
export interface RebootInputDeviceRequest {
    Force?: RebootInputDeviceForce | undefined;
    InputDeviceId: string;
}
export interface RebootInputDeviceResponse {
}
export interface RejectInputDeviceTransferRequest {
    InputDeviceId: string;
}
export interface RejectInputDeviceTransferResponse {
}
export type ChannelPipelineIdToRestart = "PIPELINE_0" | "PIPELINE_1" | (string & {});
export type __listOfChannelPipelineIdToRestart = ChannelPipelineIdToRestart[];
export interface RestartChannelPipelinesRequest {
    ChannelId: string;
    PipelineIds?: ChannelPipelineIdToRestart[] | undefined;
}
export interface RestartChannelPipelinesResponse {
    Arn?: string | undefined;
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelClass?: ChannelClass | undefined;
    Destinations?: OutputDestination[] | undefined;
    EgressEndpoints?: ChannelEgressEndpoint[] | undefined;
    EncoderSettings?: (EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: number;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: number;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    FilterSettings: H264FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    FilterSettings: H265FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                    FilterSettings: Av1FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    }) | undefined;
    Id?: string | undefined;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceStatus | undefined;
    MaintenanceStatus?: string | undefined;
    Name?: string | undefined;
    PipelineDetails?: PipelineDetail[] | undefined;
    PipelinesRunningCount?: number | undefined;
    RoleArn?: string | undefined;
    State?: ChannelState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Vpc?: VpcOutputSettingsDescription | undefined;
    AnywhereSettings?: DescribeAnywhereSettings | undefined;
    ChannelEngineVersion?: ChannelEngineVersionResponse | undefined;
    LinkedChannelSettings?: DescribeLinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: DescribeInferenceSettings | undefined;
}
export interface StartChannelRequest {
    ChannelId: string;
}
export interface StartChannelResponse {
    Arn?: string | undefined;
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelClass?: ChannelClass | undefined;
    Destinations?: OutputDestination[] | undefined;
    EgressEndpoints?: ChannelEgressEndpoint[] | undefined;
    EncoderSettings?: (EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: number;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: number;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    FilterSettings: H264FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    FilterSettings: H265FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                    FilterSettings: Av1FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    }) | undefined;
    Id?: string | undefined;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceStatus | undefined;
    Name?: string | undefined;
    PipelineDetails?: PipelineDetail[] | undefined;
    PipelinesRunningCount?: number | undefined;
    RoleArn?: string | undefined;
    State?: ChannelState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Vpc?: VpcOutputSettingsDescription | undefined;
    AnywhereSettings?: DescribeAnywhereSettings | undefined;
    ChannelEngineVersion?: ChannelEngineVersionResponse | undefined;
    LinkedChannelSettings?: DescribeLinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: DescribeInferenceSettings | undefined;
}
export interface StartDeleteMonitorDeploymentRequest {
    Identifier: string;
}
export interface StartDeleteMonitorDeploymentResponse {
    Arn?: string | undefined;
    CloudWatchAlarmTemplateGroupIds?: string[] | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    DiscoveryEntryPointArn?: string | undefined;
    ErrorMessage?: string | undefined;
    EventBridgeRuleTemplateGroupIds?: string[] | undefined;
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    Id?: string | undefined;
    LastDiscoveredAt?: Date | undefined;
    LastSuccessfulMonitorDeployment?: (SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    ModifiedAt?: Date | undefined;
    MonitorChangesPendingDeployment?: boolean | undefined;
    MonitorDeployment?: (MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    Name?: string | undefined;
    Status?: SignalMapStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartInputDeviceRequest {
    InputDeviceId: string;
}
export interface StartInputDeviceResponse {
}
export interface StartInputDeviceMaintenanceWindowRequest {
    InputDeviceId: string;
}
export interface StartInputDeviceMaintenanceWindowResponse {
}
export interface StartMonitorDeploymentRequest {
    DryRun?: boolean | undefined;
    Identifier: string;
}
export interface StartMonitorDeploymentResponse {
    Arn?: string | undefined;
    CloudWatchAlarmTemplateGroupIds?: string[] | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    DiscoveryEntryPointArn?: string | undefined;
    ErrorMessage?: string | undefined;
    EventBridgeRuleTemplateGroupIds?: string[] | undefined;
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    Id?: string | undefined;
    LastDiscoveredAt?: Date | undefined;
    LastSuccessfulMonitorDeployment?: (SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    ModifiedAt?: Date | undefined;
    MonitorChangesPendingDeployment?: boolean | undefined;
    MonitorDeployment?: (MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    Name?: string | undefined;
    Status?: SignalMapStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartMultiplexRequest {
    MultiplexId: string;
}
export interface StartMultiplexResponse {
    Arn?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    Destinations?: MultiplexOutputDestination[] | undefined;
    Id?: string | undefined;
    MultiplexSettings?: (MultiplexSettings & {
        TransportStreamBitrate: __integerMin1000000Max100000000;
        TransportStreamId: __integerMin0Max65535;
    }) | undefined;
    Name?: string | undefined;
    PipelinesRunningCount?: number | undefined;
    ProgramCount?: number | undefined;
    State?: MultiplexState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartUpdateSignalMapRequest {
    CloudWatchAlarmTemplateGroupIdentifiers?: string[] | undefined;
    Description?: string | undefined;
    DiscoveryEntryPointArn?: string | undefined;
    EventBridgeRuleTemplateGroupIdentifiers?: string[] | undefined;
    ForceRediscovery?: boolean | undefined;
    Identifier: string;
    Name?: string | undefined;
}
export interface StartUpdateSignalMapResponse {
    Arn?: string | undefined;
    CloudWatchAlarmTemplateGroupIds?: string[] | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    DiscoveryEntryPointArn?: string | undefined;
    ErrorMessage?: string | undefined;
    EventBridgeRuleTemplateGroupIds?: string[] | undefined;
    FailedMediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    Id?: string | undefined;
    LastDiscoveredAt?: Date | undefined;
    LastSuccessfulMonitorDeployment?: (SuccessfulMonitorDeployment & {
        DetailsUri: __stringMin1Max2048;
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    MediaResourceMap?: {
        [key: string]: (MediaResource & {
            Destinations: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
            Sources: (MediaResourceNeighbor & {
                Arn: __stringMin1Max2048PatternArn;
            })[];
        }) | undefined;
    } | undefined;
    ModifiedAt?: Date | undefined;
    MonitorChangesPendingDeployment?: boolean | undefined;
    MonitorDeployment?: (MonitorDeployment & {
        Status: SignalMapMonitorDeploymentStatus;
    }) | undefined;
    Name?: string | undefined;
    Status?: SignalMapStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StopChannelRequest {
    ChannelId: string;
}
export interface StopChannelResponse {
    Arn?: string | undefined;
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelClass?: ChannelClass | undefined;
    Destinations?: OutputDestination[] | undefined;
    EgressEndpoints?: ChannelEgressEndpoint[] | undefined;
    EncoderSettings?: (EncoderSettings & {
        AudioDescriptions: (AudioDescription & {
            AudioSelectorName: string;
            Name: __stringMax255;
            AudioWatermarkingSettings: AudioWatermarkSettings & {
                NielsenWatermarksSettings: NielsenWatermarksSettings & {
                    NielsenCbetSettings: NielsenCBET & {
                        CbetCheckDigitString: __stringMin2Max2;
                        CbetStepaside: NielsenWatermarksCbetStepaside;
                        Csid: __stringMin1Max7;
                    };
                    NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                    NielsenNwOnlySettings: NielsenNwOnly & {
                        CheckDigitString: __stringMin2Max2;
                        Sid: __doubleMin1Max65535;
                    };
                };
            };
            RemixSettings: RemixSettings & {
                ChannelMappings: (AudioChannelMapping & {
                    InputChannelLevels: (InputChannelLevel & {
                        Gain: __integerMinNegative60Max6;
                        InputChannel: __integerMin0Max15;
                    })[];
                    OutputChannel: __integerMin0Max7;
                })[];
            };
        })[];
        OutputGroups: (OutputGroup & {
            OutputGroupSettings: OutputGroupSettings & {
                ArchiveGroupSettings: ArchiveGroupSettings & {
                    Destination: OutputLocationRef;
                };
                FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                    Destination: OutputLocationRef;
                };
                HlsGroupSettings: HlsGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                        LanguageDescription: __stringMin1;
                    })[];
                    KeyProviderSettings: KeyProviderSettings & {
                        StaticKeySettings: StaticKeySettings & {
                            StaticKeyValue: __stringMin32Max32;
                            KeyProviderServer: InputLocation & {
                                Uri: __stringMax2048;
                            };
                        };
                    };
                };
                MediaPackageGroupSettings: MediaPackageGroupSettings & {
                    Destination: OutputLocationRef;
                    MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                            MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: number;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                MsSmoothGroupSettings: MsSmoothGroupSettings & {
                    Destination: OutputLocationRef;
                };
                CmafIngestGroupSettings: CmafIngestGroupSettings & {
                    Destination: OutputLocationRef;
                    CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                        CaptionChannel: __integerMin1Max4;
                        LanguageCode: __stringMin3Max3;
                    })[];
                    AdditionalDestinations: (AdditionalDestinations & {
                        Destination: OutputLocationRef;
                    })[];
                    WatermarkingSettings: CmafIngestWatermarkingSettings & {
                        CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                            AlternateDestination: OutputLocationRef;
                            OperatorId: __integerMin1Max511;
                            Profile: AbWatermarkingProfile;
                            CustomProfile: AbWatermarkingCustomProfile & {
                                EmbeddingFrequency: number;
                                SceneCut: __doubleMinNegative1Max5;
                                TargetPsnr: __doubleMin32Max46;
                            };
                        };
                    };
                };
            };
            Outputs: (Output & {
                OutputSettings: OutputSettings & {
                    ArchiveOutputSettings: ArchiveOutputSettings & {
                        ContainerSettings: ArchiveContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                    };
                    HlsOutputSettings: HlsOutputSettings & {
                        HlsSettings: HlsSettings & {
                            AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                AudioOnlyImage: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                            StandardHlsSettings: StandardHlsSettings & {
                                M3u8Settings: M3u8Settings;
                            };
                        };
                    };
                    MultiplexOutputSettings: MultiplexOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    RtmpOutputSettings: RtmpOutputSettings & {
                        Destination: OutputLocationRef;
                    };
                    UdpOutputSettings: UdpOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    SrtOutputSettings: SrtOutputSettings & {
                        ContainerSettings: UdpContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                    MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                        ContainerSettings: MediaConnectRouterContainerSettings & {
                            M2tsSettings: M2tsSettings & {
                                DvbNitSettings: DvbNitSettings & {
                                    NetworkId: __integerMin0Max65536;
                                    NetworkName: __stringMin1Max256;
                                };
                            };
                        };
                        Destination: OutputLocationRef;
                    };
                };
            })[];
        })[];
        TimecodeConfig: TimecodeConfig & {
            Source: TimecodeConfigSource;
        };
        VideoDescriptions: (VideoDescription & {
            Name: string;
            CodecSettings: VideoCodecSettings & {
                FrameCaptureSettings: FrameCaptureSettings & {
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H264Settings: H264Settings & {
                    FilterSettings: H264FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                H265Settings: H265Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    FilterSettings: H265FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Mpeg2Settings: Mpeg2Settings & {
                    FramerateDenominator: __integerMin1;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                };
                Av1Settings: Av1Settings & {
                    FramerateDenominator: __integerMin1Max3003;
                    FramerateNumerator: __integerMin1;
                    TimecodeBurninSettings: TimecodeBurninSettings & {
                        FontSize: TimecodeBurninFontSize;
                        Position: TimecodeBurninPosition;
                    };
                    FilterSettings: Av1FilterSettings & {
                        PerceptualFilterSettings: PerceptualFilterSettings & {
                            Strength: PerceptualFilterStrength;
                        };
                    };
                };
            };
            CropRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
            OutputPositionRectangle: VideoPositionRectangle & {
                Height: __integerMin2Max8192;
                Width: __integerMin2Max8192;
                X: __integerMin0Max8190;
                Y: __integerMin0Max8190;
            };
        })[];
        AvailBlanking: AvailBlanking & {
            AvailBlankingImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        AvailConfiguration: AvailConfiguration & {
            AvailSettings: AvailSettings & {
                Esam: Esam & {
                    AcquisitionPointId: __stringMax256;
                    PoisEndpoint: __stringMax2048;
                };
            };
        };
        BlackoutSlate: BlackoutSlate & {
            BlackoutSlateImage: InputLocation & {
                Uri: __stringMax2048;
            };
            NetworkEndBlackoutImage: InputLocation & {
                Uri: __stringMax2048;
            };
        };
        CaptionDescriptions: (CaptionDescription & {
            CaptionSelectorName: string;
            Name: string;
            DestinationSettings: CaptionDestinationSettings & {
                BurnInDestinationSettings: BurnInDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
                DvbSubDestinationSettings: DvbSubDestinationSettings & {
                    Font: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
        })[];
        GlobalConfiguration: GlobalConfiguration & {
            InputLossBehavior: InputLossBehavior & {
                InputLossImageSlate: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
        };
        MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
            MotionGraphicsSettings: MotionGraphicsSettings;
        };
        ThumbnailConfiguration: ThumbnailConfiguration & {
            State: ThumbnailState;
        };
        ColorCorrectionSettings: ColorCorrectionSettings & {
            GlobalColorCorrections: (ColorCorrection & {
                InputColorSpace: ColorSpace;
                OutputColorSpace: ColorSpace;
                Uri: string;
            })[];
        };
    }) | undefined;
    Id?: string | undefined;
    InputAttachments?: (InputAttachment & {
        AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
            SecondaryInputId: string;
            FailoverConditions: (FailoverCondition & {
                FailoverConditionSettings: FailoverConditionSettings & {
                    AudioSilenceSettings: AudioSilenceFailoverSettings & {
                        AudioSelectorName: string;
                    };
                };
            })[];
        };
        InputSettings: InputSettings & {
            AudioSelectors: (AudioSelector & {
                Name: __stringMin1;
                SelectorSettings: AudioSelectorSettings & {
                    AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                        GroupId: __stringMin1;
                        Name: __stringMin1;
                    };
                    AudioLanguageSelection: AudioLanguageSelection & {
                        LanguageCode: string;
                    };
                    AudioPidSelection: AudioPidSelection & {
                        Pid: __integerMin0Max8191;
                        Pids: (AudioPid & {
                            Pid: __integerMin0Max8191;
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                    };
                    AudioTrackSelection: AudioTrackSelection & {
                        Tracks: (AudioTrack & {
                            Track: __integerMin1;
                            PremixSettings: AudioPreMixerSettings & {
                                RemixSettings: RemixSettings & {
                                    ChannelMappings: (AudioChannelMapping & {
                                        InputChannelLevels: (InputChannelLevel & {
                                            Gain: __integerMinNegative60Max6;
                                            InputChannel: __integerMin0Max15;
                                        })[];
                                        OutputChannel: __integerMin0Max7;
                                    })[];
                                };
                            };
                        })[];
                        DolbyEDecode: AudioDolbyEDecode & {
                            ProgramSelection: DolbyEProgramSelection;
                        };
                    };
                };
            })[];
            CaptionSelectors: (CaptionSelector & {
                Name: __stringMin1;
                SelectorSettings: CaptionSelectorSettings & {
                    TeletextSourceSettings: TeletextSourceSettings & {
                        OutputRectangle: CaptionRectangle & {
                            Height: __doubleMin0Max100;
                            LeftOffset: __doubleMin0Max100;
                            TopOffset: __doubleMin0Max100;
                            Width: __doubleMin0Max100;
                        };
                    };
                };
            })[];
        };
    })[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceStatus | undefined;
    Name?: string | undefined;
    PipelineDetails?: PipelineDetail[] | undefined;
    PipelinesRunningCount?: number | undefined;
    RoleArn?: string | undefined;
    State?: ChannelState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Vpc?: VpcOutputSettingsDescription | undefined;
    AnywhereSettings?: DescribeAnywhereSettings | undefined;
    ChannelEngineVersion?: ChannelEngineVersionResponse | undefined;
    LinkedChannelSettings?: DescribeLinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: DescribeInferenceSettings | undefined;
}
export interface StopInputDeviceRequest {
    InputDeviceId: string;
}
export interface StopInputDeviceResponse {
}
export interface StopMultiplexRequest {
    MultiplexId: string;
}
export interface StopMultiplexResponse {
    Arn?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    Destinations?: MultiplexOutputDestination[] | undefined;
    Id?: string | undefined;
    MultiplexSettings?: (MultiplexSettings & {
        TransportStreamBitrate: __integerMin1000000Max100000000;
        TransportStreamId: __integerMin0Max65535;
    }) | undefined;
    Name?: string | undefined;
    PipelinesRunningCount?: number | undefined;
    ProgramCount?: number | undefined;
    State?: MultiplexState | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TransferInputDeviceRequest {
    InputDeviceId: string;
    TargetCustomerId?: string | undefined;
    TargetRegion?: string | undefined;
    TransferMessage?: string | undefined;
}
export interface TransferInputDeviceResponse {
}
export interface UpdateAccountConfigurationRequest {
    AccountConfiguration?: AccountConfiguration | undefined;
}
export interface UpdateAccountConfigurationResponse {
    AccountConfiguration?: AccountConfiguration | undefined;
}
export interface MaintenanceUpdateSettings {
    MaintenanceDay?: MaintenanceDay | undefined;
    MaintenanceScheduledDate?: string | undefined;
    MaintenanceStartTime?: string | undefined;
}
export interface SpecialRouterSettings {
    RouterArn?: string | undefined;
}
export interface UpdateChannelRequest {
    CdiInputSpecification?: CdiInputSpecification | undefined;
    ChannelId: string;
    Destinations?: OutputDestination[] | undefined;
    EncoderSettings?: EncoderSettings | undefined;
    InputAttachments?: InputAttachment[] | undefined;
    InputSpecification?: InputSpecification | undefined;
    LogLevel?: LogLevel | undefined;
    Maintenance?: MaintenanceUpdateSettings | undefined;
    Name?: string | undefined;
    RoleArn?: string | undefined;
    ChannelEngineVersion?: ChannelEngineVersionRequest | undefined;
    DryRun?: boolean | undefined;
    AnywhereSettings?: AnywhereSettings | undefined;
    LinkedChannelSettings?: LinkedChannelSettings | undefined;
    ChannelSecurityGroups?: string[] | undefined;
    InferenceSettings?: InferenceSettings | undefined;
    SpecialRouterSettings?: SpecialRouterSettings | undefined;
}
export interface UpdateChannelResponse {
    Channel?: (Channel & {
        EncoderSettings: EncoderSettings & {
            AudioDescriptions: (AudioDescription & {
                AudioSelectorName: string;
                Name: __stringMax255;
                AudioWatermarkingSettings: AudioWatermarkSettings & {
                    NielsenWatermarksSettings: NielsenWatermarksSettings & {
                        NielsenCbetSettings: NielsenCBET & {
                            CbetCheckDigitString: __stringMin2Max2;
                            CbetStepaside: NielsenWatermarksCbetStepaside;
                            Csid: __stringMin1Max7;
                        };
                        NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                        NielsenNwOnlySettings: NielsenNwOnly & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                    };
                };
                RemixSettings: RemixSettings & {
                    ChannelMappings: (AudioChannelMapping & {
                        InputChannelLevels: (InputChannelLevel & {
                            Gain: __integerMinNegative60Max6;
                            InputChannel: __integerMin0Max15;
                        })[];
                        OutputChannel: __integerMin0Max7;
                    })[];
                };
            })[];
            OutputGroups: (OutputGroup & {
                OutputGroupSettings: OutputGroupSettings & {
                    ArchiveGroupSettings: ArchiveGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    HlsGroupSettings: HlsGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        KeyProviderSettings: KeyProviderSettings & {
                            StaticKeySettings: StaticKeySettings & {
                                StaticKeyValue: __stringMin32Max32;
                                KeyProviderServer: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                        };
                    };
                    MediaPackageGroupSettings: MediaPackageGroupSettings & {
                        Destination: OutputLocationRef;
                        MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                            CaptionLanguageMappings: (CaptionLanguageMapping & {
                                CaptionChannel: __integerMin1Max4;
                                LanguageCode: __stringMin3Max3;
                                LanguageDescription: __stringMin1;
                            })[];
                            AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                                Destination: OutputLocationRef;
                            })[];
                            WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                                MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                    AlternateDestination: OutputLocationRef;
                                    OperatorId: __integerMin1Max511;
                                    Profile: AbWatermarkingProfile;
                                    CustomProfile: AbWatermarkingCustomProfile & {
                                        EmbeddingFrequency: number;
                                        SceneCut: __doubleMinNegative1Max5;
                                        TargetPsnr: __doubleMin32Max46;
                                    };
                                };
                            };
                        };
                    };
                    MsSmoothGroupSettings: MsSmoothGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    CmafIngestGroupSettings: CmafIngestGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                        })[];
                        AdditionalDestinations: (AdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: CmafIngestWatermarkingSettings & {
                            CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: number;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                Outputs: (Output & {
                    OutputSettings: OutputSettings & {
                        ArchiveOutputSettings: ArchiveOutputSettings & {
                            ContainerSettings: ArchiveContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                        };
                        HlsOutputSettings: HlsOutputSettings & {
                            HlsSettings: HlsSettings & {
                                AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                    AudioOnlyImage: InputLocation & {
                                        Uri: __stringMax2048;
                                    };
                                };
                                StandardHlsSettings: StandardHlsSettings & {
                                    M3u8Settings: M3u8Settings;
                                };
                            };
                        };
                        MultiplexOutputSettings: MultiplexOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        RtmpOutputSettings: RtmpOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        UdpOutputSettings: UdpOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        SrtOutputSettings: SrtOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                            ContainerSettings: MediaConnectRouterContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                    };
                })[];
            })[];
            TimecodeConfig: TimecodeConfig & {
                Source: TimecodeConfigSource;
            };
            VideoDescriptions: (VideoDescription & {
                Name: string;
                CodecSettings: VideoCodecSettings & {
                    FrameCaptureSettings: FrameCaptureSettings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H264Settings: H264Settings & {
                        FilterSettings: H264FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H265Settings: H265Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        FilterSettings: H265FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Mpeg2Settings: Mpeg2Settings & {
                        FramerateDenominator: __integerMin1;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Av1Settings: Av1Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                        FilterSettings: Av1FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                    };
                };
                CropRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
                OutputPositionRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
            })[];
            AvailBlanking: AvailBlanking & {
                AvailBlankingImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            AvailConfiguration: AvailConfiguration & {
                AvailSettings: AvailSettings & {
                    Esam: Esam & {
                        AcquisitionPointId: __stringMax256;
                        PoisEndpoint: __stringMax2048;
                    };
                };
            };
            BlackoutSlate: BlackoutSlate & {
                BlackoutSlateImage: InputLocation & {
                    Uri: __stringMax2048;
                };
                NetworkEndBlackoutImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            CaptionDescriptions: (CaptionDescription & {
                CaptionSelectorName: string;
                Name: string;
                DestinationSettings: CaptionDestinationSettings & {
                    BurnInDestinationSettings: BurnInDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                    DvbSubDestinationSettings: DvbSubDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                };
            })[];
            GlobalConfiguration: GlobalConfiguration & {
                InputLossBehavior: InputLossBehavior & {
                    InputLossImageSlate: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
            MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
                MotionGraphicsSettings: MotionGraphicsSettings;
            };
            ThumbnailConfiguration: ThumbnailConfiguration & {
                State: ThumbnailState;
            };
            ColorCorrectionSettings: ColorCorrectionSettings & {
                GlobalColorCorrections: (ColorCorrection & {
                    InputColorSpace: ColorSpace;
                    OutputColorSpace: ColorSpace;
                    Uri: string;
                })[];
            };
        };
        InputAttachments: (InputAttachment & {
            AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
                SecondaryInputId: string;
                FailoverConditions: (FailoverCondition & {
                    FailoverConditionSettings: FailoverConditionSettings & {
                        AudioSilenceSettings: AudioSilenceFailoverSettings & {
                            AudioSelectorName: string;
                        };
                    };
                })[];
            };
            InputSettings: InputSettings & {
                AudioSelectors: (AudioSelector & {
                    Name: __stringMin1;
                    SelectorSettings: AudioSelectorSettings & {
                        AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                            GroupId: __stringMin1;
                            Name: __stringMin1;
                        };
                        AudioLanguageSelection: AudioLanguageSelection & {
                            LanguageCode: string;
                        };
                        AudioPidSelection: AudioPidSelection & {
                            Pid: __integerMin0Max8191;
                            Pids: (AudioPid & {
                                Pid: __integerMin0Max8191;
                                DolbyEDecode: AudioDolbyEDecode & {
                                    ProgramSelection: DolbyEProgramSelection;
                                };
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                        };
                        AudioTrackSelection: AudioTrackSelection & {
                            Tracks: (AudioTrack & {
                                Track: __integerMin1;
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                        };
                    };
                })[];
                CaptionSelectors: (CaptionSelector & {
                    Name: __stringMin1;
                    SelectorSettings: CaptionSelectorSettings & {
                        TeletextSourceSettings: TeletextSourceSettings & {
                            OutputRectangle: CaptionRectangle & {
                                Height: __doubleMin0Max100;
                                LeftOffset: __doubleMin0Max100;
                                TopOffset: __doubleMin0Max100;
                                Width: __doubleMin0Max100;
                            };
                        };
                    };
                })[];
            };
        })[];
    }) | undefined;
}
export interface UpdateChannelClassRequest {
    ChannelClass?: ChannelClass | undefined;
    ChannelId: string;
    Destinations?: OutputDestination[] | undefined;
}
export interface UpdateChannelClassResponse {
    Channel?: (Channel & {
        EncoderSettings: EncoderSettings & {
            AudioDescriptions: (AudioDescription & {
                AudioSelectorName: string;
                Name: __stringMax255;
                AudioWatermarkingSettings: AudioWatermarkSettings & {
                    NielsenWatermarksSettings: NielsenWatermarksSettings & {
                        NielsenCbetSettings: NielsenCBET & {
                            CbetCheckDigitString: __stringMin2Max2;
                            CbetStepaside: NielsenWatermarksCbetStepaside;
                            Csid: __stringMin1Max7;
                        };
                        NielsenNaesIiNwSettings: NielsenNaesIiNw & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                        NielsenNwOnlySettings: NielsenNwOnly & {
                            CheckDigitString: __stringMin2Max2;
                            Sid: __doubleMin1Max65535;
                        };
                    };
                };
                RemixSettings: RemixSettings & {
                    ChannelMappings: (AudioChannelMapping & {
                        InputChannelLevels: (InputChannelLevel & {
                            Gain: __integerMinNegative60Max6;
                            InputChannel: __integerMin0Max15;
                        })[];
                        OutputChannel: __integerMin0Max7;
                    })[];
                };
            })[];
            OutputGroups: (OutputGroup & {
                OutputGroupSettings: OutputGroupSettings & {
                    ArchiveGroupSettings: ArchiveGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    FrameCaptureGroupSettings: FrameCaptureGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    HlsGroupSettings: HlsGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                            LanguageDescription: __stringMin1;
                        })[];
                        KeyProviderSettings: KeyProviderSettings & {
                            StaticKeySettings: StaticKeySettings & {
                                StaticKeyValue: __stringMin32Max32;
                                KeyProviderServer: InputLocation & {
                                    Uri: __stringMax2048;
                                };
                            };
                        };
                    };
                    MediaPackageGroupSettings: MediaPackageGroupSettings & {
                        Destination: OutputLocationRef;
                        MediapackageV2GroupSettings: MediaPackageV2GroupSettings & {
                            CaptionLanguageMappings: (CaptionLanguageMapping & {
                                CaptionChannel: __integerMin1Max4;
                                LanguageCode: __stringMin3Max3;
                                LanguageDescription: __stringMin1;
                            })[];
                            AdditionalDestinations: (MediaPackageAdditionalDestinations & {
                                Destination: OutputLocationRef;
                            })[];
                            WatermarkingSettings: MediaPackageV2WatermarkingSettings & {
                                MediaPackageV2AbWatermarkerIrdetoSettings: MediaPackageV2AbWatermarkerIrdetoSettings & {
                                    AlternateDestination: OutputLocationRef;
                                    OperatorId: __integerMin1Max511;
                                    Profile: AbWatermarkingProfile;
                                    CustomProfile: AbWatermarkingCustomProfile & {
                                        EmbeddingFrequency: number;
                                        SceneCut: __doubleMinNegative1Max5;
                                        TargetPsnr: __doubleMin32Max46;
                                    };
                                };
                            };
                        };
                    };
                    MsSmoothGroupSettings: MsSmoothGroupSettings & {
                        Destination: OutputLocationRef;
                    };
                    CmafIngestGroupSettings: CmafIngestGroupSettings & {
                        Destination: OutputLocationRef;
                        CaptionLanguageMappings: (CmafIngestCaptionLanguageMapping & {
                            CaptionChannel: __integerMin1Max4;
                            LanguageCode: __stringMin3Max3;
                        })[];
                        AdditionalDestinations: (AdditionalDestinations & {
                            Destination: OutputLocationRef;
                        })[];
                        WatermarkingSettings: CmafIngestWatermarkingSettings & {
                            CmafIngestAbWatermarkerIrdetoSettings: CmafIngestAbWatermarkerIrdetoSettings & {
                                AlternateDestination: OutputLocationRef;
                                OperatorId: __integerMin1Max511;
                                Profile: AbWatermarkingProfile;
                                CustomProfile: AbWatermarkingCustomProfile & {
                                    EmbeddingFrequency: number;
                                    SceneCut: __doubleMinNegative1Max5;
                                    TargetPsnr: __doubleMin32Max46;
                                };
                            };
                        };
                    };
                };
                Outputs: (Output & {
                    OutputSettings: OutputSettings & {
                        ArchiveOutputSettings: ArchiveOutputSettings & {
                            ContainerSettings: ArchiveContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                        };
                        HlsOutputSettings: HlsOutputSettings & {
                            HlsSettings: HlsSettings & {
                                AudioOnlyHlsSettings: AudioOnlyHlsSettings & {
                                    AudioOnlyImage: InputLocation & {
                                        Uri: __stringMax2048;
                                    };
                                };
                                StandardHlsSettings: StandardHlsSettings & {
                                    M3u8Settings: M3u8Settings;
                                };
                            };
                        };
                        MultiplexOutputSettings: MultiplexOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        RtmpOutputSettings: RtmpOutputSettings & {
                            Destination: OutputLocationRef;
                        };
                        UdpOutputSettings: UdpOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        SrtOutputSettings: SrtOutputSettings & {
                            ContainerSettings: UdpContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                        MediaConnectRouterOutputSettings: MediaConnectRouterOutputSettings & {
                            ContainerSettings: MediaConnectRouterContainerSettings & {
                                M2tsSettings: M2tsSettings & {
                                    DvbNitSettings: DvbNitSettings & {
                                        NetworkId: __integerMin0Max65536;
                                        NetworkName: __stringMin1Max256;
                                    };
                                };
                            };
                            Destination: OutputLocationRef;
                        };
                    };
                })[];
            })[];
            TimecodeConfig: TimecodeConfig & {
                Source: TimecodeConfigSource;
            };
            VideoDescriptions: (VideoDescription & {
                Name: string;
                CodecSettings: VideoCodecSettings & {
                    FrameCaptureSettings: FrameCaptureSettings & {
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H264Settings: H264Settings & {
                        FilterSettings: H264FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    H265Settings: H265Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        FilterSettings: H265FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Mpeg2Settings: Mpeg2Settings & {
                        FramerateDenominator: __integerMin1;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                    };
                    Av1Settings: Av1Settings & {
                        FramerateDenominator: __integerMin1Max3003;
                        FramerateNumerator: __integerMin1;
                        TimecodeBurninSettings: TimecodeBurninSettings & {
                            FontSize: TimecodeBurninFontSize;
                            Position: TimecodeBurninPosition;
                        };
                        FilterSettings: Av1FilterSettings & {
                            PerceptualFilterSettings: PerceptualFilterSettings & {
                                Strength: PerceptualFilterStrength;
                            };
                        };
                    };
                };
                CropRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
                OutputPositionRectangle: VideoPositionRectangle & {
                    Height: __integerMin2Max8192;
                    Width: __integerMin2Max8192;
                    X: __integerMin0Max8190;
                    Y: __integerMin0Max8190;
                };
            })[];
            AvailBlanking: AvailBlanking & {
                AvailBlankingImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            AvailConfiguration: AvailConfiguration & {
                AvailSettings: AvailSettings & {
                    Esam: Esam & {
                        AcquisitionPointId: __stringMax256;
                        PoisEndpoint: __stringMax2048;
                    };
                };
            };
            BlackoutSlate: BlackoutSlate & {
                BlackoutSlateImage: InputLocation & {
                    Uri: __stringMax2048;
                };
                NetworkEndBlackoutImage: InputLocation & {
                    Uri: __stringMax2048;
                };
            };
            CaptionDescriptions: (CaptionDescription & {
                CaptionSelectorName: string;
                Name: string;
                DestinationSettings: CaptionDestinationSettings & {
                    BurnInDestinationSettings: BurnInDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                    DvbSubDestinationSettings: DvbSubDestinationSettings & {
                        Font: InputLocation & {
                            Uri: __stringMax2048;
                        };
                    };
                };
            })[];
            GlobalConfiguration: GlobalConfiguration & {
                InputLossBehavior: InputLossBehavior & {
                    InputLossImageSlate: InputLocation & {
                        Uri: __stringMax2048;
                    };
                };
            };
            MotionGraphicsConfiguration: MotionGraphicsConfiguration & {
                MotionGraphicsSettings: MotionGraphicsSettings;
            };
            ThumbnailConfiguration: ThumbnailConfiguration & {
                State: ThumbnailState;
            };
            ColorCorrectionSettings: ColorCorrectionSettings & {
                GlobalColorCorrections: (ColorCorrection & {
                    InputColorSpace: ColorSpace;
                    OutputColorSpace: ColorSpace;
                    Uri: string;
                })[];
            };
        };
        InputAttachments: (InputAttachment & {
            AutomaticInputFailoverSettings: AutomaticInputFailoverSettings & {
                SecondaryInputId: string;
                FailoverConditions: (FailoverCondition & {
                    FailoverConditionSettings: FailoverConditionSettings & {
                        AudioSilenceSettings: AudioSilenceFailoverSettings & {
                            AudioSelectorName: string;
                        };
                    };
                })[];
            };
            InputSettings: InputSettings & {
                AudioSelectors: (AudioSelector & {
                    Name: __stringMin1;
                    SelectorSettings: AudioSelectorSettings & {
                        AudioHlsRenditionSelection: AudioHlsRenditionSelection & {
                            GroupId: __stringMin1;
                            Name: __stringMin1;
                        };
                        AudioLanguageSelection: AudioLanguageSelection & {
                            LanguageCode: string;
                        };
                        AudioPidSelection: AudioPidSelection & {
                            Pid: __integerMin0Max8191;
                            Pids: (AudioPid & {
                                Pid: __integerMin0Max8191;
                                DolbyEDecode: AudioDolbyEDecode & {
                                    ProgramSelection: DolbyEProgramSelection;
                                };
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                        };
                        AudioTrackSelection: AudioTrackSelection & {
                            Tracks: (AudioTrack & {
                                Track: __integerMin1;
                                PremixSettings: AudioPreMixerSettings & {
                                    RemixSettings: RemixSettings & {
                                        ChannelMappings: (AudioChannelMapping & {
                                            InputChannelLevels: (InputChannelLevel & {
                                                Gain: __integerMinNegative60Max6;
                                                InputChannel: __integerMin0Max15;
                                            })[];
                                            OutputChannel: __integerMin0Max7;
                                        })[];
                                    };
                                };
                            })[];
                            DolbyEDecode: AudioDolbyEDecode & {
                                ProgramSelection: DolbyEProgramSelection;
                            };
                        };
                    };
                })[];
                CaptionSelectors: (CaptionSelector & {
                    Name: __stringMin1;
                    SelectorSettings: CaptionSelectorSettings & {
                        TeletextSourceSettings: TeletextSourceSettings & {
                            OutputRectangle: CaptionRectangle & {
                                Height: __doubleMin0Max100;
                                LeftOffset: __doubleMin0Max100;
                                TopOffset: __doubleMin0Max100;
                                Width: __doubleMin0Max100;
                            };
                        };
                    };
                })[];
            };
        })[];
    }) | undefined;
}
export interface UpdateChannelPlacementGroupRequest {
    ChannelPlacementGroupId: string;
    ClusterId: string;
    Name?: string | undefined;
    Nodes?: string[] | undefined;
}
export interface UpdateChannelPlacementGroupResponse {
    Arn?: string | undefined;
    Channels?: string[] | undefined;
    ClusterId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Nodes?: string[] | undefined;
    State?: ChannelPlacementGroupState | undefined;
}
export interface UpdateCloudWatchAlarmTemplateRequest {
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator | undefined;
    DatapointsToAlarm?: number | undefined;
    Description?: string | undefined;
    EvaluationPeriods?: number | undefined;
    GroupIdentifier?: string | undefined;
    Identifier: string;
    MetricName?: string | undefined;
    Name?: string | undefined;
    Period?: number | undefined;
    Statistic?: CloudWatchAlarmTemplateStatistic | undefined;
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType | undefined;
    Threshold?: number | undefined;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData | undefined;
}
export interface UpdateCloudWatchAlarmTemplateResponse {
    Arn?: string | undefined;
    ComparisonOperator?: CloudWatchAlarmTemplateComparisonOperator | undefined;
    CreatedAt?: Date | undefined;
    DatapointsToAlarm?: number | undefined;
    Description?: string | undefined;
    EvaluationPeriods?: number | undefined;
    GroupId?: string | undefined;
    Id?: string | undefined;
    MetricName?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Period?: number | undefined;
    Statistic?: CloudWatchAlarmTemplateStatistic | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TargetResourceType?: CloudWatchAlarmTemplateTargetResourceType | undefined;
    Threshold?: number | undefined;
    TreatMissingData?: CloudWatchAlarmTemplateTreatMissingData | undefined;
}
export interface UpdateCloudWatchAlarmTemplateGroupRequest {
    Description?: string | undefined;
    Identifier: string;
}
export interface UpdateCloudWatchAlarmTemplateGroupResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface InterfaceMappingUpdateRequest {
    LogicalInterfaceName?: string | undefined;
    NetworkId?: string | undefined;
}
export type __listOfInterfaceMappingUpdateRequest = InterfaceMappingUpdateRequest[];
export interface ClusterNetworkSettingsUpdateRequest {
    DefaultRoute?: string | undefined;
    InterfaceMappings?: InterfaceMappingUpdateRequest[] | undefined;
}
export interface UpdateClusterRequest {
    ClusterId: string;
    Name?: string | undefined;
    NetworkSettings?: ClusterNetworkSettingsUpdateRequest | undefined;
}
export interface UpdateClusterResponse {
    Arn?: string | undefined;
    ChannelIds?: string[] | undefined;
    ClusterType?: ClusterType | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: ClusterNetworkSettings | undefined;
    State?: ClusterState | undefined;
}
export interface UpdateEventBridgeRuleTemplateRequest {
    Description?: string | undefined;
    EventTargets?: EventBridgeRuleTemplateTarget[] | undefined;
    EventType?: EventBridgeRuleTemplateEventType | undefined;
    GroupIdentifier?: string | undefined;
    Identifier: string;
    Name?: string | undefined;
}
export interface UpdateEventBridgeRuleTemplateResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    EventTargets?: (EventBridgeRuleTemplateTarget & {
        Arn: __stringMin1Max2048PatternArn;
    })[] | undefined;
    EventType?: EventBridgeRuleTemplateEventType | undefined;
    GroupId?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateEventBridgeRuleTemplateGroupRequest {
    Description?: string | undefined;
    Identifier: string;
}
export interface UpdateEventBridgeRuleTemplateGroupResponse {
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    ModifiedAt?: Date | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface InputDeviceRequest {
    Id?: string | undefined;
}
export type __listOfInputDeviceRequest = InputDeviceRequest[];
export interface MulticastSourceUpdateRequest {
    SourceIp?: string | undefined;
    Url?: string | undefined;
    SecondarySourceIp?: string | undefined;
    SecondaryUrl?: string | undefined;
}
export type __listOfMulticastSourceUpdateRequest = MulticastSourceUpdateRequest[];
export interface MulticastSettingsUpdateRequest {
    Sources?: MulticastSourceUpdateRequest[] | undefined;
}
export interface UpdateInputRequest {
    Destinations?: InputDestinationRequest[] | undefined;
    InputDevices?: InputDeviceRequest[] | undefined;
    InputId: string;
    InputSecurityGroups?: string[] | undefined;
    MediaConnectFlows?: MediaConnectFlowRequest[] | undefined;
    Name?: string | undefined;
    RoleArn?: string | undefined;
    Sources?: InputSourceRequest[] | undefined;
    SrtSettings?: SrtSettingsRequest | undefined;
    MulticastSettings?: MulticastSettingsUpdateRequest | undefined;
    Smpte2110ReceiverGroupSettings?: Smpte2110ReceiverGroupSettings | undefined;
    SdiSources?: string[] | undefined;
    SpecialRouterSettings?: SpecialRouterSettings | undefined;
}
export interface UpdateInputResponse {
    Input?: (Input & {
        SrtSettings: SrtSettings & {
            SrtListenerSettings: SrtListenerSettings & {
                Decryption: SrtListenerDecryption & {
                    Algorithm: Algorithm;
                    PassphraseSecretArn: string;
                };
            };
        };
        MulticastSettings: MulticastSettings & {
            Sources: (MulticastSource & {
                Url: string;
            })[];
        };
    }) | undefined;
}
export interface InputDeviceMediaConnectConfigurableSettings {
    FlowArn?: string | undefined;
    RoleArn?: string | undefined;
    SecretArn?: string | undefined;
    SourceName?: string | undefined;
}
export type InputDeviceConfigurableAudioChannelPairProfile = "DISABLED" | "VBR-AAC_HHE-16000" | "VBR-AAC_HE-64000" | "VBR-AAC_LC-128000" | "CBR-AAC_HQ-192000" | "CBR-AAC_HQ-256000" | "CBR-AAC_HQ-384000" | "CBR-AAC_HQ-512000" | (string & {});
export interface InputDeviceConfigurableAudioChannelPairConfig {
    Id?: number | undefined;
    Profile?: InputDeviceConfigurableAudioChannelPairProfile | undefined;
}
export type __listOfInputDeviceConfigurableAudioChannelPairConfig = InputDeviceConfigurableAudioChannelPairConfig[];
export interface InputDeviceConfigurableSettings {
    ConfiguredInput?: InputDeviceConfiguredInput | undefined;
    MaxBitrate?: number | undefined;
    LatencyMs?: number | undefined;
    Codec?: InputDeviceCodec | undefined;
    MediaconnectSettings?: InputDeviceMediaConnectConfigurableSettings | undefined;
    AudioChannelPairs?: InputDeviceConfigurableAudioChannelPairConfig[] | undefined;
    InputResolution?: string | undefined;
}
export interface UpdateInputDeviceRequest {
    HdDeviceSettings?: InputDeviceConfigurableSettings | undefined;
    InputDeviceId: string;
    Name?: string | undefined;
    UhdDeviceSettings?: InputDeviceConfigurableSettings | undefined;
    AvailabilityZone?: string | undefined;
}
export interface UpdateInputDeviceResponse {
    Arn?: string | undefined;
    ConnectionState?: InputDeviceConnectionState | undefined;
    DeviceSettingsSyncState?: DeviceSettingsSyncState | undefined;
    DeviceUpdateStatus?: DeviceUpdateStatus | undefined;
    HdDeviceSettings?: InputDeviceHdSettings | undefined;
    Id?: string | undefined;
    MacAddress?: string | undefined;
    Name?: string | undefined;
    NetworkSettings?: InputDeviceNetworkSettings | undefined;
    SerialNumber?: string | undefined;
    Type?: InputDeviceType | undefined;
    UhdDeviceSettings?: InputDeviceUhdSettings | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    AvailabilityZone?: string | undefined;
    MedialiveInputArns?: string[] | undefined;
    OutputType?: InputDeviceOutputType | undefined;
}
export interface UpdateInputSecurityGroupRequest {
    InputSecurityGroupId: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    WhitelistRules?: InputWhitelistRuleCidr[] | undefined;
}
export interface UpdateInputSecurityGroupResponse {
    SecurityGroup?: InputSecurityGroup | undefined;
}
export type MultiplexPacketIdentifiersMapping = {
    [key: string]: MultiplexProgramPacketIdentifiersMap | undefined;
};
export interface UpdateMultiplexRequest {
    MultiplexId: string;
    MultiplexSettings?: MultiplexSettings | undefined;
    Name?: string | undefined;
    PacketIdentifiersMapping?: {
        [key: string]: MultiplexProgramPacketIdentifiersMap | undefined;
    } | undefined;
}
export interface UpdateMultiplexResponse {
    Multiplex?: (Multiplex & {
        MultiplexSettings: MultiplexSettings & {
            TransportStreamBitrate: __integerMin1000000Max100000000;
            TransportStreamId: __integerMin0Max65535;
        };
    }) | undefined;
}
export interface UpdateMultiplexProgramRequest {
    MultiplexId: string;
    MultiplexProgramSettings?: MultiplexProgramSettings | undefined;
    ProgramName: string;
}
export interface UpdateMultiplexProgramResponse {
    MultiplexProgram?: (MultiplexProgram & {
        MultiplexProgramSettings: MultiplexProgramSettings & {
            ProgramNumber: __integerMin0Max65535;
            ServiceDescriptor: MultiplexProgramServiceDescriptor & {
                ProviderName: __stringMax256;
                ServiceName: __stringMax256;
            };
        };
    }) | undefined;
}
export interface IpPoolUpdateRequest {
    Cidr?: string | undefined;
}
export type __listOfIpPoolUpdateRequest = IpPoolUpdateRequest[];
export interface RouteUpdateRequest {
    Cidr?: string | undefined;
    Gateway?: string | undefined;
}
export type __listOfRouteUpdateRequest = RouteUpdateRequest[];
export interface UpdateNetworkRequest {
    IpPools?: IpPoolUpdateRequest[] | undefined;
    Name?: string | undefined;
    NetworkId: string;
    Routes?: RouteUpdateRequest[] | undefined;
}
export interface UpdateNetworkResponse {
    Arn?: string | undefined;
    AssociatedClusterIds?: string[] | undefined;
    Id?: string | undefined;
    IpPools?: IpPool[] | undefined;
    Name?: string | undefined;
    Routes?: Route[] | undefined;
    State?: NetworkState | undefined;
}
export interface SdiSourceMappingUpdateRequest {
    CardNumber?: number | undefined;
    ChannelNumber?: number | undefined;
    SdiSource?: string | undefined;
}
export type SdiSourceMappingsUpdateRequest = SdiSourceMappingUpdateRequest[];
export interface UpdateNodeRequest {
    ClusterId: string;
    Name?: string | undefined;
    NodeId: string;
    Role?: NodeRole | undefined;
    SdiSourceMappings?: SdiSourceMappingUpdateRequest[] | undefined;
}
export interface UpdateNodeResponse {
    Arn?: string | undefined;
    ChannelPlacementGroups?: string[] | undefined;
    ClusterId?: string | undefined;
    ConnectionState?: NodeConnectionState | undefined;
    Id?: string | undefined;
    InstanceArn?: string | undefined;
    Name?: string | undefined;
    NodeInterfaceMappings?: NodeInterfaceMapping[] | undefined;
    Role?: NodeRole | undefined;
    State?: NodeState | undefined;
    SdiSourceMappings?: SdiSourceMapping[] | undefined;
}
export type UpdateNodeStateShape = "ACTIVE" | "DRAINING" | (string & {});
export interface UpdateNodeStateRequest {
    ClusterId: string;
    NodeId: string;
    State?: UpdateNodeStateShape | undefined;
}
export interface UpdateNodeStateResponse {
    Arn?: string | undefined;
    ChannelPlacementGroups?: string[] | undefined;
    ClusterId?: string | undefined;
    ConnectionState?: NodeConnectionState | undefined;
    Id?: string | undefined;
    InstanceArn?: string | undefined;
    Name?: string | undefined;
    NodeInterfaceMappings?: NodeInterfaceMapping[] | undefined;
    Role?: NodeRole | undefined;
    State?: NodeState | undefined;
    SdiSourceMappings?: SdiSourceMapping[] | undefined;
}
export interface UpdateReservationRequest {
    Name?: string | undefined;
    RenewalSettings?: RenewalSettings | undefined;
    ReservationId: string;
}
export interface UpdateReservationResponse {
    Reservation?: Reservation | undefined;
}
export interface UpdateSdiSourceRequest {
    Mode?: SdiSourceMode | undefined;
    Name?: string | undefined;
    SdiSourceId: string;
    Type?: SdiSourceType | undefined;
}
export interface UpdateSdiSourceResponse {
    SdiSource?: SdiSource | undefined;
}
export interface ValidationError {
    ElementPath?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type __listOfValidationError = ValidationError[];
export type AcceptInputDeviceTransferError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Accept an incoming input device transfer. The ownership of the device will transfer to your AWS account.
 */
export declare const acceptInputDeviceTransfer: API.OperationMethod<AcceptInputDeviceTransferRequest & RegionInput, AcceptInputDeviceTransferResponse, AcceptInputDeviceTransferError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts delete of resources.
 */
export declare const batchDelete: API.OperationMethod<BatchDeleteRequest & RegionInput, BatchDeleteResponse, BatchDeleteError, Credentials | HttpClient.HttpClient>;
export type BatchStartError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts existing resources
 */
export declare const batchStart: API.OperationMethod<BatchStartRequest & RegionInput, BatchStartResponse, BatchStartError, Credentials | HttpClient.HttpClient>;
export type BatchStopError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops running resources
 */
export declare const batchStop: API.OperationMethod<BatchStopRequest & RegionInput, BatchStopResponse, BatchStopError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateScheduleError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Update a channel schedule
 */
export declare const batchUpdateSchedule: API.OperationMethod<BatchUpdateScheduleRequest & RegionInput, BatchUpdateScheduleResponse, BatchUpdateScheduleError, Credentials | HttpClient.HttpClient>;
export type CancelInputDeviceTransferError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Cancel an input device transfer that you have requested.
 */
export declare const cancelInputDeviceTransfer: API.OperationMethod<CancelInputDeviceTransferRequest & RegionInput, CancelInputDeviceTransferResponse, CancelInputDeviceTransferError, Credentials | HttpClient.HttpClient>;
export type ClaimDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Send a request to claim an AWS Elemental device that you have purchased from a third-party vendor. After the request succeeds, you will own the device.
 */
export declare const claimDevice: API.OperationMethod<ClaimDeviceRequest & RegionInput, ClaimDeviceResponse, ClaimDeviceError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | MediaLiveRoleNotYetTrusted | CommonErrors;
/**
 * Creates a new channel
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest & RegionInput, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateChannelPlacementGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Create a ChannelPlacementGroup in the specified Cluster. As part of the create operation, you specify the Nodes to attach the group to.After you create a ChannelPlacementGroup, you add Channels to the group (you do this by modifying the Channels to add them to a specific group). You now have an association of Channels to ChannelPlacementGroup, and ChannelPlacementGroup to Nodes. This association means that all the Channels in the group are able to run on any of the Nodes associated with the group.
 */
export declare const createChannelPlacementGroup: API.OperationMethod<CreateChannelPlacementGroupRequest & RegionInput, CreateChannelPlacementGroupResponse, CreateChannelPlacementGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCloudWatchAlarmTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a cloudwatch alarm template to dynamically generate cloudwatch metric alarms on targeted resource types.
 */
export declare const createCloudWatchAlarmTemplate: API.OperationMethod<CreateCloudWatchAlarmTemplateRequest & RegionInput, CreateCloudWatchAlarmTemplateResponse, CreateCloudWatchAlarmTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateCloudWatchAlarmTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a cloudwatch alarm template group to group your cloudwatch alarm templates and to attach to signal maps for dynamically creating alarms.
 */
export declare const createCloudWatchAlarmTemplateGroup: API.OperationMethod<CreateCloudWatchAlarmTemplateGroupRequest & RegionInput, CreateCloudWatchAlarmTemplateGroupResponse, CreateCloudWatchAlarmTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create a new Cluster.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest & RegionInput, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateEventBridgeRuleTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an eventbridge rule template to monitor events and send notifications to your targeted resources.
 */
export declare const createEventBridgeRuleTemplate: API.OperationMethod<CreateEventBridgeRuleTemplateRequest & RegionInput, CreateEventBridgeRuleTemplateResponse, CreateEventBridgeRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateEventBridgeRuleTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an eventbridge rule template group to group your eventbridge rule templates and to attach to signal maps for dynamically creating notification rules.
 */
export declare const createEventBridgeRuleTemplateGroup: API.OperationMethod<CreateEventBridgeRuleTemplateGroupRequest & RegionInput, CreateEventBridgeRuleTemplateGroupResponse, CreateEventBridgeRuleTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateInputError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create an input
 */
export declare const createInput: API.OperationMethod<CreateInputRequest & RegionInput, CreateInputResponse, CreateInputError, Credentials | HttpClient.HttpClient>;
export type CreateInputSecurityGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Input Security Group
 */
export declare const createInputSecurityGroup: API.OperationMethod<CreateInputSecurityGroupRequest & RegionInput, CreateInputSecurityGroupResponse, CreateInputSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type CreateMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Create a new multiplex.
 */
export declare const createMultiplex: API.OperationMethod<CreateMultiplexRequest & RegionInput, CreateMultiplexResponse, CreateMultiplexError, Credentials | HttpClient.HttpClient>;
export type CreateMultiplexProgramError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Create a new program in the multiplex.
 */
export declare const createMultiplexProgram: API.OperationMethod<CreateMultiplexProgramRequest & RegionInput, CreateMultiplexProgramResponse, CreateMultiplexProgramError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create as many Networks as you need. You will associate one or more Clusters with each Network.Each Network provides MediaLive Anywhere with required information about the network in your organization that you are using for video encoding using MediaLive.
 */
export declare const createNetwork: API.OperationMethod<CreateNetworkRequest & RegionInput, CreateNetworkResponse, CreateNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateNodeError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Create a Node in the specified Cluster. You can also create Nodes using the CreateNodeRegistrationScript. Note that you can't move a Node to another Cluster.
 */
export declare const createNode: API.OperationMethod<CreateNodeRequest & RegionInput, CreateNodeResponse, CreateNodeError, Credentials | HttpClient.HttpClient>;
export type CreateNodeRegistrationScriptError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create the Register Node script for all the nodes intended for a specific Cluster. You will then run the script on each hardware unit that is intended for that Cluster. The script creates a Node in the specified Cluster. It then binds the Node to this hardware unit, and activates the node hardware for use with MediaLive Anywhere.
 */
export declare const createNodeRegistrationScript: API.OperationMethod<CreateNodeRegistrationScriptRequest & RegionInput, CreateNodeRegistrationScriptResponse, CreateNodeRegistrationScriptError, Credentials | HttpClient.HttpClient>;
export type CreatePartnerInputError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create a partner input
 */
export declare const createPartnerInput: API.OperationMethod<CreatePartnerInputRequest & RegionInput, CreatePartnerInputResponse, CreatePartnerInputError, Credentials | HttpClient.HttpClient>;
export type CreateSdiSourceError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create an SdiSource for each video source that uses the SDI protocol. You will reference the SdiSource when you create an SDI input in MediaLive. You will also reference it in an SdiSourceMapping, in order to create a connection between the logical SdiSource and the physical SDI card and port that the physical SDI source uses.
 */
export declare const createSdiSource: API.OperationMethod<CreateSdiSourceRequest & RegionInput, CreateSdiSourceResponse, CreateSdiSourceError, Credentials | HttpClient.HttpClient>;
export type CreateSignalMapError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Initiates the creation of a new signal map. Will discover a new mediaResourceMap based on the provided discoveryEntryPointArn.
 */
export declare const createSignalMap: API.OperationMethod<CreateSignalMapRequest & RegionInput, CreateSignalMapResponse, CreateSignalMapError, Credentials | HttpClient.HttpClient>;
export type CreateTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Create tags for a resource
 */
export declare const createTags: API.OperationMethod<CreateTagsRequest & RegionInput, CreateTagsResponse, CreateTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts deletion of channel. The associated outputs are also deleted.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest & RegionInput, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelPlacementGroupError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete the specified ChannelPlacementGroup that exists in the specified Cluster.
 */
export declare const deleteChannelPlacementGroup: API.OperationMethod<DeleteChannelPlacementGroupRequest & RegionInput, DeleteChannelPlacementGroupResponse, DeleteChannelPlacementGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudWatchAlarmTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a cloudwatch alarm template.
 */
export declare const deleteCloudWatchAlarmTemplate: API.OperationMethod<DeleteCloudWatchAlarmTemplateRequest & RegionInput, DeleteCloudWatchAlarmTemplateResponse, DeleteCloudWatchAlarmTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudWatchAlarmTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a cloudwatch alarm template group. You must detach this group from all signal maps and ensure its existing templates are moved to another group or deleted.
 */
export declare const deleteCloudWatchAlarmTemplateGroup: API.OperationMethod<DeleteCloudWatchAlarmTemplateGroupRequest & RegionInput, DeleteCloudWatchAlarmTemplateGroupResponse, DeleteCloudWatchAlarmTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a Cluster. The Cluster must be idle.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest & RegionInput, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteEventBridgeRuleTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an eventbridge rule template.
 */
export declare const deleteEventBridgeRuleTemplate: API.OperationMethod<DeleteEventBridgeRuleTemplateRequest & RegionInput, DeleteEventBridgeRuleTemplateResponse, DeleteEventBridgeRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteEventBridgeRuleTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an eventbridge rule template group. You must detach this group from all signal maps and ensure its existing templates are moved to another group or deleted.
 */
export declare const deleteEventBridgeRuleTemplateGroup: API.OperationMethod<DeleteEventBridgeRuleTemplateGroupRequest & RegionInput, DeleteEventBridgeRuleTemplateGroupResponse, DeleteEventBridgeRuleTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteInputError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the input end point
 */
export declare const deleteInput: API.OperationMethod<DeleteInputRequest & RegionInput, DeleteInputResponse, DeleteInputError, Credentials | HttpClient.HttpClient>;
export type DeleteInputSecurityGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Input Security Group
 */
export declare const deleteInputSecurityGroup: API.OperationMethod<DeleteInputSecurityGroupRequest & RegionInput, DeleteInputSecurityGroupResponse, DeleteInputSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a multiplex. The multiplex must be idle.
 */
export declare const deleteMultiplex: API.OperationMethod<DeleteMultiplexRequest & RegionInput, DeleteMultiplexResponse, DeleteMultiplexError, Credentials | HttpClient.HttpClient>;
export type DeleteMultiplexProgramError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a program from a multiplex.
 */
export declare const deleteMultiplexProgram: API.OperationMethod<DeleteMultiplexProgramRequest & RegionInput, DeleteMultiplexProgramResponse, DeleteMultiplexProgramError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a Network. The Network must have no resources associated with it.
 */
export declare const deleteNetwork: API.OperationMethod<DeleteNetworkRequest & RegionInput, DeleteNetworkResponse, DeleteNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteNodeError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a Node. The Node must be IDLE.
 */
export declare const deleteNode: API.OperationMethod<DeleteNodeRequest & RegionInput, DeleteNodeResponse, DeleteNodeError, Credentials | HttpClient.HttpClient>;
export type DeleteReservationError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an expired reservation, or cancel an active reservation during the calendar month (UTC) in which you purchased it. You can't cancel an active reservation that you purchased in an earlier month, including one that renewed automatically. You also can't cancel an active reservation during the last hour of the month, from 23:00 UTC on the last day of the month.
 */
export declare const deleteReservation: API.OperationMethod<DeleteReservationRequest & RegionInput, DeleteReservationResponse, DeleteReservationError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduleError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete all schedule actions on a channel.
 */
export declare const deleteSchedule: API.OperationMethod<DeleteScheduleRequest & RegionInput, DeleteScheduleResponse, DeleteScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteSdiSourceError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an SdiSource. The SdiSource must not be part of any SidSourceMapping and must not be attached to any input.
 */
export declare const deleteSdiSource: API.OperationMethod<DeleteSdiSourceRequest & RegionInput, DeleteSdiSourceResponse, DeleteSdiSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteSignalMapError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified signal map.
 */
export declare const deleteSignalMap: API.OperationMethod<DeleteSignalMapRequest & RegionInput, DeleteSignalMapResponse, DeleteSignalMapError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes tags for a resource
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsRequest & RegionInput, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountConfigurationError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Describe account configuration
 */
export declare const describeAccountConfiguration: API.OperationMethod<DescribeAccountConfigurationRequest & RegionInput, DescribeAccountConfigurationResponse, DescribeAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a channel
 */
export declare const describeChannel: API.OperationMethod<DescribeChannelRequest & RegionInput, DescribeChannelResponse, DescribeChannelError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelPlacementGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details about a ChannelPlacementGroup.
 */
export declare const describeChannelPlacementGroup: API.OperationMethod<DescribeChannelPlacementGroupRequest & RegionInput, DescribeChannelPlacementGroupResponse, DescribeChannelPlacementGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details about a Cluster.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest & RegionInput, DescribeClusterResponse, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeInputError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Produces details about an input
 */
export declare const describeInput: API.OperationMethod<DescribeInputRequest & RegionInput, DescribeInputResponse, DescribeInputError, Credentials | HttpClient.HttpClient>;
export type DescribeInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the details for the input device
 */
export declare const describeInputDevice: API.OperationMethod<DescribeInputDeviceRequest & RegionInput, DescribeInputDeviceResponse, DescribeInputDeviceError, Credentials | HttpClient.HttpClient>;
export type DescribeInputDeviceThumbnailError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get the latest thumbnail data for the input device.
 */
export declare const describeInputDeviceThumbnail: API.OperationMethod<DescribeInputDeviceThumbnailRequest & RegionInput, DescribeInputDeviceThumbnailResponse, DescribeInputDeviceThumbnailError, Credentials | HttpClient.HttpClient>;
export type DescribeInputSecurityGroupError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Produces a summary of an Input Security Group
 */
export declare const describeInputSecurityGroup: API.OperationMethod<DescribeInputSecurityGroupRequest & RegionInput, DescribeInputSecurityGroupResponse, DescribeInputSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeMultiplexError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a multiplex.
 */
export declare const describeMultiplex: API.OperationMethod<DescribeMultiplexRequest & RegionInput, DescribeMultiplexResponse, DescribeMultiplexError, Credentials | HttpClient.HttpClient>;
export type DescribeMultiplexProgramError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get the details for a program in a multiplex.
 */
export declare const describeMultiplexProgram: API.OperationMethod<DescribeMultiplexProgramRequest & RegionInput, DescribeMultiplexProgramResponse, DescribeMultiplexProgramError, Credentials | HttpClient.HttpClient>;
export type DescribeNetworkError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details about a Network.
 */
export declare const describeNetwork: API.OperationMethod<DescribeNetworkRequest & RegionInput, DescribeNetworkResponse, DescribeNetworkError, Credentials | HttpClient.HttpClient>;
export type DescribeNodeError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details about a Node in the specified Cluster.
 */
export declare const describeNode: API.OperationMethod<DescribeNodeRequest & RegionInput, DescribeNodeResponse, DescribeNodeError, Credentials | HttpClient.HttpClient>;
export type DescribeOfferingError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details for an offering.
 */
export declare const describeOffering: API.OperationMethod<DescribeOfferingRequest & RegionInput, DescribeOfferingResponse, DescribeOfferingError, Credentials | HttpClient.HttpClient>;
export type DescribeReservationError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get details for a reservation.
 */
export declare const describeReservation: API.OperationMethod<DescribeReservationRequest & RegionInput, DescribeReservationResponse, DescribeReservationError, Credentials | HttpClient.HttpClient>;
export type DescribeScheduleError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get a channel schedule
 */
export declare const describeSchedule: API.PaginatedOperationMethod<DescribeScheduleRequest & RegionInput, DescribeScheduleResponse, DescribeScheduleError, Credentials | HttpClient.HttpClient, ScheduleAction>;
export type DescribeSdiSourceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a SdiSource.
 */
export declare const describeSdiSource: API.OperationMethod<DescribeSdiSourceRequest & RegionInput, DescribeSdiSourceResponse, DescribeSdiSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeThumbnailsError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Describe the latest thumbnails data.
 */
export declare const describeThumbnails: API.OperationMethod<DescribeThumbnailsRequest & RegionInput, DescribeThumbnailsResponse, DescribeThumbnailsError, Credentials | HttpClient.HttpClient>;
export type GetCloudWatchAlarmTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified cloudwatch alarm template.
 */
export declare const getCloudWatchAlarmTemplate: API.OperationMethod<GetCloudWatchAlarmTemplateRequest & RegionInput, GetCloudWatchAlarmTemplateResponse, GetCloudWatchAlarmTemplateError, Credentials | HttpClient.HttpClient>;
export type GetCloudWatchAlarmTemplateGroupError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified cloudwatch alarm template group.
 */
export declare const getCloudWatchAlarmTemplateGroup: API.OperationMethod<GetCloudWatchAlarmTemplateGroupRequest & RegionInput, GetCloudWatchAlarmTemplateGroupResponse, GetCloudWatchAlarmTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type GetEventBridgeRuleTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified eventbridge rule template.
 */
export declare const getEventBridgeRuleTemplate: API.OperationMethod<GetEventBridgeRuleTemplateRequest & RegionInput, GetEventBridgeRuleTemplateResponse, GetEventBridgeRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type GetEventBridgeRuleTemplateGroupError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified eventbridge rule template group.
 */
export declare const getEventBridgeRuleTemplateGroup: API.OperationMethod<GetEventBridgeRuleTemplateGroupRequest & RegionInput, GetEventBridgeRuleTemplateGroupResponse, GetEventBridgeRuleTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type GetSignalMapError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the specified signal map.
 */
export declare const getSignalMap: API.OperationMethod<GetSignalMapRequest & RegionInput, GetSignalMapResponse, GetSignalMapError, Credentials | HttpClient.HttpClient>;
export type ListAlertsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the alerts for a channel with optional filtering based on alert state.
 */
export declare const listAlerts: API.PaginatedOperationMethod<ListAlertsRequest & RegionInput, ListAlertsResponse, ListAlertsError, Credentials | HttpClient.HttpClient, ChannelAlert>;
export type ListChannelPlacementGroupsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the list of ChannelPlacementGroups in the specified Cluster.
 */
export declare const listChannelPlacementGroups: API.PaginatedOperationMethod<ListChannelPlacementGroupsRequest & RegionInput, ListChannelPlacementGroupsResponse, ListChannelPlacementGroupsError, Credentials | HttpClient.HttpClient, DescribeChannelPlacementGroupSummary>;
export type ListChannelsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Produces list of channels that have been created
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest & RegionInput, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, ChannelSummary>;
export type ListCloudWatchAlarmTemplateGroupsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists cloudwatch alarm template groups.
 */
export declare const listCloudWatchAlarmTemplateGroups: API.PaginatedOperationMethod<ListCloudWatchAlarmTemplateGroupsRequest & RegionInput, ListCloudWatchAlarmTemplateGroupsResponse, ListCloudWatchAlarmTemplateGroupsError, Credentials | HttpClient.HttpClient, CloudWatchAlarmTemplateGroupSummary>;
export type ListCloudWatchAlarmTemplatesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists cloudwatch alarm templates.
 */
export declare const listCloudWatchAlarmTemplates: API.PaginatedOperationMethod<ListCloudWatchAlarmTemplatesRequest & RegionInput, ListCloudWatchAlarmTemplatesResponse, ListCloudWatchAlarmTemplatesError, Credentials | HttpClient.HttpClient, CloudWatchAlarmTemplateSummary>;
export type ListClusterAlertsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the alerts for a cluster with optional filtering based on alert state.
 */
export declare const listClusterAlerts: API.PaginatedOperationMethod<ListClusterAlertsRequest & RegionInput, ListClusterAlertsResponse, ListClusterAlertsError, Credentials | HttpClient.HttpClient, ClusterAlert>;
export type ListClustersError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the list of Clusters.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest & RegionInput, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, DescribeClusterSummary>;
export type ListEventBridgeRuleTemplateGroupsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists eventbridge rule template groups.
 */
export declare const listEventBridgeRuleTemplateGroups: API.PaginatedOperationMethod<ListEventBridgeRuleTemplateGroupsRequest & RegionInput, ListEventBridgeRuleTemplateGroupsResponse, ListEventBridgeRuleTemplateGroupsError, Credentials | HttpClient.HttpClient, EventBridgeRuleTemplateGroupSummary>;
export type ListEventBridgeRuleTemplatesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists eventbridge rule templates.
 */
export declare const listEventBridgeRuleTemplates: API.PaginatedOperationMethod<ListEventBridgeRuleTemplatesRequest & RegionInput, ListEventBridgeRuleTemplatesResponse, ListEventBridgeRuleTemplatesError, Credentials | HttpClient.HttpClient, EventBridgeRuleTemplateSummary>;
export type ListInputDevicesError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * List input devices
 */
export declare const listInputDevices: API.PaginatedOperationMethod<ListInputDevicesRequest & RegionInput, ListInputDevicesResponse, ListInputDevicesError, Credentials | HttpClient.HttpClient, InputDeviceSummary>;
export type ListInputDeviceTransfersError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * List input devices that are currently being transferred. List input devices that you are transferring from your AWS account or input devices that another AWS account is transferring to you.
 */
export declare const listInputDeviceTransfers: API.PaginatedOperationMethod<ListInputDeviceTransfersRequest & RegionInput, ListInputDeviceTransfersResponse, ListInputDeviceTransfersError, Credentials | HttpClient.HttpClient, TransferringInputDeviceSummary>;
export type ListInputsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Produces list of inputs that have been created
 */
export declare const listInputs: API.PaginatedOperationMethod<ListInputsRequest & RegionInput, ListInputsResponse, ListInputsError, Credentials | HttpClient.HttpClient, Input>;
export type ListInputSecurityGroupsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Produces a list of Input Security Groups for an account
 */
export declare const listInputSecurityGroups: API.PaginatedOperationMethod<ListInputSecurityGroupsRequest & RegionInput, ListInputSecurityGroupsResponse, ListInputSecurityGroupsError, Credentials | HttpClient.HttpClient, InputSecurityGroup>;
export type ListMultiplexAlertsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the alerts for a multiplex with optional filtering based on alert state.
 */
export declare const listMultiplexAlerts: API.PaginatedOperationMethod<ListMultiplexAlertsRequest & RegionInput, ListMultiplexAlertsResponse, ListMultiplexAlertsError, Credentials | HttpClient.HttpClient, MultiplexAlert>;
export type ListMultiplexesError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a list of the existing multiplexes.
 */
export declare const listMultiplexes: API.PaginatedOperationMethod<ListMultiplexesRequest & RegionInput, ListMultiplexesResponse, ListMultiplexesError, Credentials | HttpClient.HttpClient, MultiplexSummary>;
export type ListMultiplexProgramsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the programs that currently exist for a specific multiplex.
 */
export declare const listMultiplexPrograms: API.PaginatedOperationMethod<ListMultiplexProgramsRequest & RegionInput, ListMultiplexProgramsResponse, ListMultiplexProgramsError, Credentials | HttpClient.HttpClient, MultiplexProgramSummary>;
export type ListNetworksError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the list of Networks.
 */
export declare const listNetworks: API.PaginatedOperationMethod<ListNetworksRequest & RegionInput, ListNetworksResponse, ListNetworksError, Credentials | HttpClient.HttpClient, DescribeNetworkSummary>;
export type ListNodesError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the list of Nodes.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesRequest & RegionInput, ListNodesResponse, ListNodesError, Credentials | HttpClient.HttpClient, DescribeNodeSummary>;
export type ListOfferingsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * List offerings available for purchase.
 */
export declare const listOfferings: API.PaginatedOperationMethod<ListOfferingsRequest & RegionInput, ListOfferingsResponse, ListOfferingsError, Credentials | HttpClient.HttpClient, Offering>;
export type ListReservationsError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * List purchased reservations.
 */
export declare const listReservations: API.PaginatedOperationMethod<ListReservationsRequest & RegionInput, ListReservationsResponse, ListReservationsError, Credentials | HttpClient.HttpClient, Reservation>;
export type ListSdiSourcesError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * List all the SdiSources in the AWS account.
 */
export declare const listSdiSources: API.PaginatedOperationMethod<ListSdiSourcesRequest & RegionInput, ListSdiSourcesResponse, ListSdiSourcesError, Credentials | HttpClient.HttpClient, SdiSourceSummary>;
export type ListSignalMapsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists signal maps.
 */
export declare const listSignalMaps: API.PaginatedOperationMethod<ListSignalMapsRequest & RegionInput, ListSignalMapsResponse, ListSignalMapsError, Credentials | HttpClient.HttpClient, SignalMapSummary>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Produces list of tags that have been created for a resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVersionsError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves an array of all the encoder engine versions that are available in this AWS account.
 */
export declare const listVersions: API.OperationMethod<ListVersionsRequest & RegionInput, ListVersionsResponse, ListVersionsError, Credentials | HttpClient.HttpClient>;
export type PurchaseOfferingError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Purchase an offering and create a reservation.
 */
export declare const purchaseOffering: API.OperationMethod<PurchaseOfferingRequest & RegionInput, PurchaseOfferingResponse, PurchaseOfferingError, Credentials | HttpClient.HttpClient>;
export type RebootInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Send a reboot command to the specified input device. The device will begin rebooting within a few seconds of sending the command. When the reboot is complete, the device's connection status will change to connected.
 */
export declare const rebootInputDevice: API.OperationMethod<RebootInputDeviceRequest & RegionInput, RebootInputDeviceResponse, RebootInputDeviceError, Credentials | HttpClient.HttpClient>;
export type RejectInputDeviceTransferError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Reject the transfer of the specified input device to your AWS account.
 */
export declare const rejectInputDeviceTransfer: API.OperationMethod<RejectInputDeviceTransferRequest & RegionInput, RejectInputDeviceTransferResponse, RejectInputDeviceTransferError, Credentials | HttpClient.HttpClient>;
export type RestartChannelPipelinesError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Restart pipelines in one channel that is currently running.
 */
export declare const restartChannelPipelines: API.OperationMethod<RestartChannelPipelinesRequest & RegionInput, RestartChannelPipelinesResponse, RestartChannelPipelinesError, Credentials | HttpClient.HttpClient>;
export type StartChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an existing channel
 */
export declare const startChannel: API.OperationMethod<StartChannelRequest & RegionInput, StartChannelResponse, StartChannelError, Credentials | HttpClient.HttpClient>;
export type StartDeleteMonitorDeploymentError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Initiates a deployment to delete the monitor of the specified signal map.
 */
export declare const startDeleteMonitorDeployment: API.OperationMethod<StartDeleteMonitorDeploymentRequest & RegionInput, StartDeleteMonitorDeploymentResponse, StartDeleteMonitorDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Start an input device that is attached to a MediaConnect flow. (There is no need to start a device that is attached to a MediaLive input; MediaLive starts the device when the channel starts.)
 */
export declare const startInputDevice: API.OperationMethod<StartInputDeviceRequest & RegionInput, StartInputDeviceResponse, StartInputDeviceError, Credentials | HttpClient.HttpClient>;
export type StartInputDeviceMaintenanceWindowError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Start a maintenance window for the specified input device. Starting a maintenance window will give the device up to two hours to install software. If the device was streaming prior to the maintenance, it will resume streaming when the software is fully installed. Devices automatically install updates while they are powered on and their MediaLive channels are stopped. A maintenance window allows you to update a device without having to stop MediaLive channels that use the device. The device must remain powered on and connected to the internet for the duration of the maintenance.
 */
export declare const startInputDeviceMaintenanceWindow: API.OperationMethod<StartInputDeviceMaintenanceWindowRequest & RegionInput, StartInputDeviceMaintenanceWindowResponse, StartInputDeviceMaintenanceWindowError, Credentials | HttpClient.HttpClient>;
export type StartMonitorDeploymentError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Initiates a deployment to deploy the latest monitor of the specified signal map.
 */
export declare const startMonitorDeployment: API.OperationMethod<StartMonitorDeploymentRequest & RegionInput, StartMonitorDeploymentResponse, StartMonitorDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Start (run) the multiplex. Starting the multiplex does not start the channels. You must explicitly start each channel.
 */
export declare const startMultiplex: API.OperationMethod<StartMultiplexRequest & RegionInput, StartMultiplexResponse, StartMultiplexError, Credentials | HttpClient.HttpClient>;
export type StartUpdateSignalMapError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Initiates an update for the specified signal map. Will discover a new signal map if a changed discoveryEntryPointArn is provided.
 */
export declare const startUpdateSignalMap: API.OperationMethod<StartUpdateSignalMapRequest & RegionInput, StartUpdateSignalMapResponse, StartUpdateSignalMapError, Credentials | HttpClient.HttpClient>;
export type StopChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops a running channel
 */
export declare const stopChannel: API.OperationMethod<StopChannelRequest & RegionInput, StopChannelResponse, StopChannelError, Credentials | HttpClient.HttpClient>;
export type StopInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Stop an input device that is attached to a MediaConnect flow. (There is no need to stop a device that is attached to a MediaLive input; MediaLive automatically stops the device when the channel stops.)
 */
export declare const stopInputDevice: API.OperationMethod<StopInputDeviceRequest & RegionInput, StopInputDeviceResponse, StopInputDeviceError, Credentials | HttpClient.HttpClient>;
export type StopMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops a running multiplex. If the multiplex isn't running, this action has no effect.
 */
export declare const stopMultiplex: API.OperationMethod<StopMultiplexRequest & RegionInput, StopMultiplexResponse, StopMultiplexError, Credentials | HttpClient.HttpClient>;
export type TransferInputDeviceError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Start an input device transfer to another AWS account. After you make the request, the other account must accept or reject the transfer.
 */
export declare const transferInputDevice: API.OperationMethod<TransferInputDeviceRequest & RegionInput, TransferInputDeviceResponse, TransferInputDeviceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountConfigurationError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Update account configuration
 */
export declare const updateAccountConfiguration: API.OperationMethod<UpdateAccountConfigurationRequest & RegionInput, UpdateAccountConfigurationResponse, UpdateAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | UnprocessableEntityException | CommonErrors;
/**
 * Updates a channel.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest & RegionInput, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelClassError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Changes the class of the channel.
 */
export declare const updateChannelClass: API.OperationMethod<UpdateChannelClassRequest & RegionInput, UpdateChannelClassResponse, UpdateChannelClassError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelPlacementGroupError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Change the settings for a ChannelPlacementGroup.
 */
export declare const updateChannelPlacementGroup: API.OperationMethod<UpdateChannelPlacementGroupRequest & RegionInput, UpdateChannelPlacementGroupResponse, UpdateChannelPlacementGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudWatchAlarmTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified cloudwatch alarm template.
 */
export declare const updateCloudWatchAlarmTemplate: API.OperationMethod<UpdateCloudWatchAlarmTemplateRequest & RegionInput, UpdateCloudWatchAlarmTemplateResponse, UpdateCloudWatchAlarmTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudWatchAlarmTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified cloudwatch alarm template group.
 */
export declare const updateCloudWatchAlarmTemplateGroup: API.OperationMethod<UpdateCloudWatchAlarmTemplateGroupRequest & RegionInput, UpdateCloudWatchAlarmTemplateGroupResponse, UpdateCloudWatchAlarmTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Change the settings for a Cluster.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest & RegionInput, UpdateClusterResponse, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateEventBridgeRuleTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified eventbridge rule template.
 */
export declare const updateEventBridgeRuleTemplate: API.OperationMethod<UpdateEventBridgeRuleTemplateRequest & RegionInput, UpdateEventBridgeRuleTemplateResponse, UpdateEventBridgeRuleTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateEventBridgeRuleTemplateGroupError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified eventbridge rule template group.
 */
export declare const updateEventBridgeRuleTemplateGroup: API.OperationMethod<UpdateEventBridgeRuleTemplateGroupRequest & RegionInput, UpdateEventBridgeRuleTemplateGroupResponse, UpdateEventBridgeRuleTemplateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateInputError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Updates an input.
 */
export declare const updateInput: API.OperationMethod<UpdateInputRequest & RegionInput, UpdateInputResponse, UpdateInputError, Credentials | HttpClient.HttpClient>;
export type UpdateInputDeviceError = BadGatewayException | BadRequestException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Updates the parameters for the input device.
 */
export declare const updateInputDevice: API.OperationMethod<UpdateInputDeviceRequest & RegionInput, UpdateInputDeviceResponse, UpdateInputDeviceError, Credentials | HttpClient.HttpClient>;
export type UpdateInputSecurityGroupError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Update an Input Security Group's Whilelists.
 */
export declare const updateInputSecurityGroup: API.OperationMethod<UpdateInputSecurityGroupRequest & RegionInput, UpdateInputSecurityGroupResponse, UpdateInputSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateMultiplexError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | UnprocessableEntityException | CommonErrors;
/**
 * Updates a multiplex.
 */
export declare const updateMultiplex: API.OperationMethod<UpdateMultiplexRequest & RegionInput, UpdateMultiplexResponse, UpdateMultiplexError, Credentials | HttpClient.HttpClient>;
export type UpdateMultiplexProgramError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | UnprocessableEntityException | CommonErrors;
/**
 * Update a program in a multiplex.
 */
export declare const updateMultiplexProgram: API.OperationMethod<UpdateMultiplexProgramRequest & RegionInput, UpdateMultiplexProgramResponse, UpdateMultiplexProgramError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Change the settings for a Network.
 */
export declare const updateNetwork: API.OperationMethod<UpdateNetworkRequest & RegionInput, UpdateNetworkResponse, UpdateNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateNodeError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Change the settings for a Node.
 */
export declare const updateNode: API.OperationMethod<UpdateNodeRequest & RegionInput, UpdateNodeResponse, UpdateNodeError, Credentials | HttpClient.HttpClient>;
export type UpdateNodeStateError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Update the state of a node.
 */
export declare const updateNodeState: API.OperationMethod<UpdateNodeStateRequest & RegionInput, UpdateNodeStateResponse, UpdateNodeStateError, Credentials | HttpClient.HttpClient>;
export type UpdateReservationError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Update reservation.
 */
export declare const updateReservation: API.OperationMethod<UpdateReservationRequest & RegionInput, UpdateReservationResponse, UpdateReservationError, Credentials | HttpClient.HttpClient>;
export type UpdateSdiSourceError = BadGatewayException | BadRequestException | ConflictException | ForbiddenException | GatewayTimeoutException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Change some of the settings in an SdiSource.
 */
export declare const updateSdiSource: API.OperationMethod<UpdateSdiSourceRequest & RegionInput, UpdateSdiSourceResponse, UpdateSdiSourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=medialive.d.ts.map