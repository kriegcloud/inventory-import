/**
 * `import source from "./hasher.ts?worker"` — the target is bundled into
 * one self-contained ES module (the same Cloudflare-flavored build the
 * parent gets: workerd externals, node builtins, Alchemy defines) and
 * imported as a **string**, ready to hand to a `WorkerLoader`
 * (`modules: { "worker.js": source }`). Nested `?worker` imports inside
 * the target work the same way.
 *
 * Bundling happens at build time, so the string is fixed per deploy; the
 * dynamic worker it becomes is then instantiated at runtime as many times
 * as the caller wants.
 */
import type * as rolldown from "rolldown";
export declare const WORKER_MODULE_RE: RegExp;
export declare const workerModulePlugin: (options: {
    /**
     * The nested build's input options (plugins, externals, cwd) for a given
     * entry; `input` is set by the plugin. Built lazily per import.
     */
    readonly nested: (entry: string) => Promise<rolldown.InputOptions>;
    readonly loadRolldown: () => Promise<typeof import("rolldown")>;
}) => rolldown.Plugin;
//# sourceMappingURL=WorkerModulePlugin.d.ts.map