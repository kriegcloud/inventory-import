import * as Effect from "effect/Effect";
export interface CloneDatabaseOptions {
    accountId: string;
    sourceDatabaseId: string;
    targetDatabaseId: string;
}
/**
 * Clone a D1 database by exporting from the source and importing into the
 * target. Fetches the SQL dump from the export's signed URL and streams the
 * payload through the import flow.
 */
export declare const cloneDatabase: (options: CloneDatabaseOptions) => Effect.Effect<import("./ImportDatabase.ts").ImportDatabaseResult, import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("@distilled.cloud/iceberg").ConfigError | import("./ImportDatabase.ts").D1ImportError | import("@distilled.cloud/cloudflare/d1").DatabaseNotFound | import("@distilled.cloud/iceberg").Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/d1").InvalidObjectIdentifier | import("@distilled.cloud/cloudflare/d1").InvalidRequest | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/core/sdk-error").SdkError | import("@distilled.cloud/iceberg").ServiceUnavailable | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, import("@distilled.cloud/cloudflare/Protocol").CloudflareOpContext>;
//# sourceMappingURL=CloneDatabase.d.ts.map