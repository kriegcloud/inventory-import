import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const AssociatedInstances_base: S.TaggedErrorClass<"AssociatedInstances", {
    readonly message: any;
}>;
export declare class AssociatedInstances extends /*@__PURE__*/ AssociatedInstances_base {
}
declare const AssociationAlreadyExists_base: S.TaggedErrorClass<"AssociationAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AssociationAlreadyExists extends /*@__PURE__*/ AssociationAlreadyExists_base {
}
declare const AssociationDoesNotExist_base: S.TaggedErrorClass<"AssociationDoesNotExist", {
    readonly message: any;
}>;
export declare class AssociationDoesNotExist extends /*@__PURE__*/ AssociationDoesNotExist_base {
}
declare const AssociationExecutionDoesNotExist_base: S.TaggedErrorClass<"AssociationExecutionDoesNotExist", {
    readonly message: any;
}>;
export declare class AssociationExecutionDoesNotExist extends /*@__PURE__*/ AssociationExecutionDoesNotExist_base {
}
declare const AssociationLimitExceeded_base: S.TaggedErrorClass<"AssociationLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class AssociationLimitExceeded extends /*@__PURE__*/ AssociationLimitExceeded_base {
}
declare const AssociationVersionLimitExceeded_base: S.TaggedErrorClass<"AssociationVersionLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class AssociationVersionLimitExceeded extends /*@__PURE__*/ AssociationVersionLimitExceeded_base {
}
declare const AutomationDefinitionNotApprovedException_base: S.TaggedErrorClass<"AutomationDefinitionNotApprovedException", {
    readonly message: any;
}>;
export declare class AutomationDefinitionNotApprovedException extends /*@__PURE__*/ AutomationDefinitionNotApprovedException_base {
}
declare const AutomationDefinitionNotFoundException_base: S.TaggedErrorClass<"AutomationDefinitionNotFoundException", {
    readonly message: any;
}>;
export declare class AutomationDefinitionNotFoundException extends /*@__PURE__*/ AutomationDefinitionNotFoundException_base {
}
declare const AutomationDefinitionVersionNotFoundException_base: S.TaggedErrorClass<"AutomationDefinitionVersionNotFoundException", {
    readonly message: any;
}>;
export declare class AutomationDefinitionVersionNotFoundException extends /*@__PURE__*/ AutomationDefinitionVersionNotFoundException_base {
}
declare const AutomationExecutionLimitExceededException_base: S.TaggedErrorClass<"AutomationExecutionLimitExceededException", {
    readonly message: any;
}>;
export declare class AutomationExecutionLimitExceededException extends /*@__PURE__*/ AutomationExecutionLimitExceededException_base {
}
declare const AutomationExecutionNotFoundException_base: S.TaggedErrorClass<"AutomationExecutionNotFoundException", {
    readonly message: any;
}>;
export declare class AutomationExecutionNotFoundException extends /*@__PURE__*/ AutomationExecutionNotFoundException_base {
}
declare const AutomationStepNotFoundException_base: S.TaggedErrorClass<"AutomationStepNotFoundException", {
    readonly message: any;
}>;
export declare class AutomationStepNotFoundException extends /*@__PURE__*/ AutomationStepNotFoundException_base {
}
declare const ComplianceTypeCountLimitExceededException_base: S.TaggedErrorClass<"ComplianceTypeCountLimitExceededException", {
    readonly message: any;
}>;
export declare class ComplianceTypeCountLimitExceededException extends /*@__PURE__*/ ComplianceTypeCountLimitExceededException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CustomSchemaCountLimitExceededException_base: S.TaggedErrorClass<"CustomSchemaCountLimitExceededException", {
    readonly message: any;
}>;
export declare class CustomSchemaCountLimitExceededException extends /*@__PURE__*/ CustomSchemaCountLimitExceededException_base {
}
declare const DocumentAlreadyExists_base: S.TaggedErrorClass<"DocumentAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DocumentAlreadyExists extends /*@__PURE__*/ DocumentAlreadyExists_base {
}
declare const DocumentLimitExceeded_base: S.TaggedErrorClass<"DocumentLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class DocumentLimitExceeded extends /*@__PURE__*/ DocumentLimitExceeded_base {
}
declare const DocumentPermissionLimit_base: S.TaggedErrorClass<"DocumentPermissionLimit", {
    readonly message: any;
}>;
export declare class DocumentPermissionLimit extends /*@__PURE__*/ DocumentPermissionLimit_base {
}
declare const DocumentVersionLimitExceeded_base: S.TaggedErrorClass<"DocumentVersionLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class DocumentVersionLimitExceeded extends /*@__PURE__*/ DocumentVersionLimitExceeded_base {
}
declare const DoesNotExistException_base: S.TaggedErrorClass<"DoesNotExistException", {
    readonly message: any;
}>;
export declare class DoesNotExistException extends /*@__PURE__*/ DoesNotExistException_base {
}
declare const DuplicateDocumentContent_base: S.TaggedErrorClass<"DuplicateDocumentContent", {
    readonly message: any;
}>;
export declare class DuplicateDocumentContent extends /*@__PURE__*/ DuplicateDocumentContent_base {
}
declare const DuplicateDocumentVersionName_base: S.TaggedErrorClass<"DuplicateDocumentVersionName", {
    readonly message: any;
}>;
export declare class DuplicateDocumentVersionName extends /*@__PURE__*/ DuplicateDocumentVersionName_base {
}
declare const DuplicateInstanceId_base: S.TaggedErrorClass<"DuplicateInstanceId", {
    readonly message: any;
}>;
export declare class DuplicateInstanceId extends /*@__PURE__*/ DuplicateInstanceId_base {
}
declare const FeatureNotAvailableException_base: S.TaggedErrorClass<"FeatureNotAvailableException", {
    readonly message: any;
}>;
export declare class FeatureNotAvailableException extends /*@__PURE__*/ FeatureNotAvailableException_base {
}
declare const HierarchyLevelLimitExceededException_base: S.TaggedErrorClass<"HierarchyLevelLimitExceededException", {
    readonly message: any;
}>;
export declare class HierarchyLevelLimitExceededException extends /*@__PURE__*/ HierarchyLevelLimitExceededException_base {
}
declare const HierarchyTypeMismatchException_base: S.TaggedErrorClass<"HierarchyTypeMismatchException", {
    readonly message: any;
}>;
export declare class HierarchyTypeMismatchException extends /*@__PURE__*/ HierarchyTypeMismatchException_base {
}
declare const IdempotentParameterMismatch_base: S.TaggedErrorClass<"IdempotentParameterMismatch", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotentParameterMismatch extends /*@__PURE__*/ IdempotentParameterMismatch_base {
}
declare const IncompatiblePolicyException_base: S.TaggedErrorClass<"IncompatiblePolicyException", {
    readonly message: any;
}>;
export declare class IncompatiblePolicyException extends /*@__PURE__*/ IncompatiblePolicyException_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InvalidActivation_base: S.TaggedErrorClass<"InvalidActivation", {
    readonly message: any;
}>;
export declare class InvalidActivation extends /*@__PURE__*/ InvalidActivation_base {
}
declare const InvalidActivationId_base: S.TaggedErrorClass<"InvalidActivationId", {
    readonly message: any;
}>;
export declare class InvalidActivationId extends /*@__PURE__*/ InvalidActivationId_base {
}
declare const InvalidAggregatorException_base: S.TaggedErrorClass<"InvalidAggregatorException", {
    readonly message: any;
}>;
export declare class InvalidAggregatorException extends /*@__PURE__*/ InvalidAggregatorException_base {
}
declare const InvalidAllowedPatternException_base: S.TaggedErrorClass<"InvalidAllowedPatternException", {
    readonly message: any;
}>;
export declare class InvalidAllowedPatternException extends /*@__PURE__*/ InvalidAllowedPatternException_base {
}
declare const InvalidAssociation_base: S.TaggedErrorClass<"InvalidAssociation", {
    readonly message: any;
}>;
export declare class InvalidAssociation extends /*@__PURE__*/ InvalidAssociation_base {
}
declare const InvalidAssociationVersion_base: S.TaggedErrorClass<"InvalidAssociationVersion", {
    readonly message: any;
}>;
export declare class InvalidAssociationVersion extends /*@__PURE__*/ InvalidAssociationVersion_base {
}
declare const InvalidAutomationExecutionParametersException_base: S.TaggedErrorClass<"InvalidAutomationExecutionParametersException", {
    readonly message: any;
}>;
export declare class InvalidAutomationExecutionParametersException extends /*@__PURE__*/ InvalidAutomationExecutionParametersException_base {
}
declare const InvalidAutomationSignalException_base: S.TaggedErrorClass<"InvalidAutomationSignalException", {
    readonly message: any;
}>;
export declare class InvalidAutomationSignalException extends /*@__PURE__*/ InvalidAutomationSignalException_base {
}
declare const InvalidAutomationStatusUpdateException_base: S.TaggedErrorClass<"InvalidAutomationStatusUpdateException", {
    readonly message: any;
}>;
export declare class InvalidAutomationStatusUpdateException extends /*@__PURE__*/ InvalidAutomationStatusUpdateException_base {
}
declare const InvalidCommandId_base: S.TaggedErrorClass<"InvalidCommandId", {
    readonly message: any;
}>;
export declare class InvalidCommandId extends /*@__PURE__*/ InvalidCommandId_base {
}
declare const InvalidDeleteInventoryParametersException_base: S.TaggedErrorClass<"InvalidDeleteInventoryParametersException", {
    readonly message: any;
}>;
export declare class InvalidDeleteInventoryParametersException extends /*@__PURE__*/ InvalidDeleteInventoryParametersException_base {
}
declare const InvalidDeletionIdException_base: S.TaggedErrorClass<"InvalidDeletionIdException", {
    readonly message: any;
}>;
export declare class InvalidDeletionIdException extends /*@__PURE__*/ InvalidDeletionIdException_base {
}
declare const InvalidDocument_base: S.TaggedErrorClass<"InvalidDocument", {
    readonly message: any;
}>;
export declare class InvalidDocument extends /*@__PURE__*/ InvalidDocument_base {
}
declare const InvalidDocumentContent_base: S.TaggedErrorClass<"InvalidDocumentContent", {
    readonly message: any;
}>;
export declare class InvalidDocumentContent extends /*@__PURE__*/ InvalidDocumentContent_base {
}
declare const InvalidDocumentOperation_base: S.TaggedErrorClass<"InvalidDocumentOperation", {
    readonly message: any;
}>;
export declare class InvalidDocumentOperation extends /*@__PURE__*/ InvalidDocumentOperation_base {
}
declare const InvalidDocumentSchemaVersion_base: S.TaggedErrorClass<"InvalidDocumentSchemaVersion", {
    readonly message: any;
}>;
export declare class InvalidDocumentSchemaVersion extends /*@__PURE__*/ InvalidDocumentSchemaVersion_base {
}
declare const InvalidDocumentType_base: S.TaggedErrorClass<"InvalidDocumentType", {
    readonly message: any;
}>;
export declare class InvalidDocumentType extends /*@__PURE__*/ InvalidDocumentType_base {
}
declare const InvalidDocumentVersion_base: S.TaggedErrorClass<"InvalidDocumentVersion", {
    readonly message: any;
}>;
export declare class InvalidDocumentVersion extends /*@__PURE__*/ InvalidDocumentVersion_base {
}
declare const InvalidFilter_base: S.TaggedErrorClass<"InvalidFilter", {
    readonly message: any;
}>;
export declare class InvalidFilter extends /*@__PURE__*/ InvalidFilter_base {
}
declare const InvalidFilterKey_base: S.TaggedErrorClass<"InvalidFilterKey", {
    readonly message: any;
}>;
export declare class InvalidFilterKey extends /*@__PURE__*/ InvalidFilterKey_base {
}
declare const InvalidFilterOption_base: S.TaggedErrorClass<"InvalidFilterOption", {
    readonly message: any;
}>;
export declare class InvalidFilterOption extends /*@__PURE__*/ InvalidFilterOption_base {
}
declare const InvalidFilterValue_base: S.TaggedErrorClass<"InvalidFilterValue", {
    readonly message: any;
}>;
export declare class InvalidFilterValue extends /*@__PURE__*/ InvalidFilterValue_base {
}
declare const InvalidInstanceId_base: S.TaggedErrorClass<"InvalidInstanceId", {
    readonly message: any;
}>;
export declare class InvalidInstanceId extends /*@__PURE__*/ InvalidInstanceId_base {
}
declare const InvalidInstanceInformationFilterValue_base: S.TaggedErrorClass<"InvalidInstanceInformationFilterValue", {
    readonly message: any;
}>;
export declare class InvalidInstanceInformationFilterValue extends /*@__PURE__*/ InvalidInstanceInformationFilterValue_base {
}
declare const InvalidInstancePropertyFilterValue_base: S.TaggedErrorClass<"InvalidInstancePropertyFilterValue", {
    readonly message: any;
}>;
export declare class InvalidInstancePropertyFilterValue extends /*@__PURE__*/ InvalidInstancePropertyFilterValue_base {
}
declare const InvalidInventoryGroupException_base: S.TaggedErrorClass<"InvalidInventoryGroupException", {
    readonly message: any;
}>;
export declare class InvalidInventoryGroupException extends /*@__PURE__*/ InvalidInventoryGroupException_base {
}
declare const InvalidInventoryItemContextException_base: S.TaggedErrorClass<"InvalidInventoryItemContextException", {
    readonly message: any;
}>;
export declare class InvalidInventoryItemContextException extends /*@__PURE__*/ InvalidInventoryItemContextException_base {
}
declare const InvalidInventoryRequestException_base: S.TaggedErrorClass<"InvalidInventoryRequestException", {
    readonly message: any;
}>;
export declare class InvalidInventoryRequestException extends /*@__PURE__*/ InvalidInventoryRequestException_base {
}
declare const InvalidItemContentException_base: S.TaggedErrorClass<"InvalidItemContentException", {
    readonly TypeName: any;
    readonly message: any;
}>;
export declare class InvalidItemContentException extends /*@__PURE__*/ InvalidItemContentException_base {
}
declare const InvalidKeyId_base: S.TaggedErrorClass<"InvalidKeyId", {
    readonly message: any;
}>;
export declare class InvalidKeyId extends /*@__PURE__*/ InvalidKeyId_base {
}
declare const InvalidNextToken_base: S.TaggedErrorClass<"InvalidNextToken", {
    readonly message: any;
}>;
export declare class InvalidNextToken extends /*@__PURE__*/ InvalidNextToken_base {
}
declare const InvalidNotificationConfig_base: S.TaggedErrorClass<"InvalidNotificationConfig", {
    readonly message: any;
}>;
export declare class InvalidNotificationConfig extends /*@__PURE__*/ InvalidNotificationConfig_base {
}
declare const InvalidOptionException_base: S.TaggedErrorClass<"InvalidOptionException", {
    readonly message: any;
}>;
export declare class InvalidOptionException extends /*@__PURE__*/ InvalidOptionException_base {
}
declare const InvalidOutputFolder_base: S.TaggedErrorClass<"InvalidOutputFolder", {
    readonly message: any;
}>;
export declare class InvalidOutputFolder extends /*@__PURE__*/ InvalidOutputFolder_base {
}
declare const InvalidOutputLocation_base: S.TaggedErrorClass<"InvalidOutputLocation", {
    readonly message: any;
}>;
export declare class InvalidOutputLocation extends /*@__PURE__*/ InvalidOutputLocation_base {
}
declare const InvalidParameters_base: S.TaggedErrorClass<"InvalidParameters", {
    readonly message: any;
}>;
export declare class InvalidParameters extends /*@__PURE__*/ InvalidParameters_base {
}
declare const InvalidPermissionType_base: S.TaggedErrorClass<"InvalidPermissionType", {
    readonly message: any;
}>;
export declare class InvalidPermissionType extends /*@__PURE__*/ InvalidPermissionType_base {
}
declare const InvalidPluginName_base: S.TaggedErrorClass<"InvalidPluginName", {
    readonly message: any;
}>;
export declare class InvalidPluginName extends /*@__PURE__*/ InvalidPluginName_base {
}
declare const InvalidPolicyAttributeException_base: S.TaggedErrorClass<"InvalidPolicyAttributeException", {
    readonly message: any;
}>;
export declare class InvalidPolicyAttributeException extends /*@__PURE__*/ InvalidPolicyAttributeException_base {
}
declare const InvalidPolicyTypeException_base: S.TaggedErrorClass<"InvalidPolicyTypeException", {
    readonly message: any;
}>;
export declare class InvalidPolicyTypeException extends /*@__PURE__*/ InvalidPolicyTypeException_base {
}
declare const InvalidResourceId_base: S.TaggedErrorClass<"InvalidResourceId", {
    readonly message: any;
}>;
export declare class InvalidResourceId extends /*@__PURE__*/ InvalidResourceId_base {
}
declare const InvalidResourceType_base: S.TaggedErrorClass<"InvalidResourceType", {
    readonly message: any;
}>;
export declare class InvalidResourceType extends /*@__PURE__*/ InvalidResourceType_base {
}
declare const InvalidResultAttributeException_base: S.TaggedErrorClass<"InvalidResultAttributeException", {
    readonly message: any;
}>;
export declare class InvalidResultAttributeException extends /*@__PURE__*/ InvalidResultAttributeException_base {
}
declare const InvalidRole_base: S.TaggedErrorClass<"InvalidRole", {
    readonly message: any;
}>;
export declare class InvalidRole extends /*@__PURE__*/ InvalidRole_base {
}
declare const InvalidSchedule_base: S.TaggedErrorClass<"InvalidSchedule", {
    readonly message: any;
}>;
export declare class InvalidSchedule extends /*@__PURE__*/ InvalidSchedule_base {
}
declare const InvalidTag_base: S.TaggedErrorClass<"InvalidTag", {
    readonly message: any;
}>;
export declare class InvalidTag extends /*@__PURE__*/ InvalidTag_base {
}
declare const InvalidTarget_base: S.TaggedErrorClass<"InvalidTarget", {
    readonly message: any;
}>;
export declare class InvalidTarget extends /*@__PURE__*/ InvalidTarget_base {
}
declare const InvalidTargetMaps_base: S.TaggedErrorClass<"InvalidTargetMaps", {
    readonly message: any;
}>;
export declare class InvalidTargetMaps extends /*@__PURE__*/ InvalidTargetMaps_base {
}
declare const InvalidTypeNameException_base: S.TaggedErrorClass<"InvalidTypeNameException", {
    readonly message: any;
}>;
export declare class InvalidTypeNameException extends /*@__PURE__*/ InvalidTypeNameException_base {
}
declare const InvalidUpdate_base: S.TaggedErrorClass<"InvalidUpdate", {
    readonly message: any;
}>;
export declare class InvalidUpdate extends /*@__PURE__*/ InvalidUpdate_base {
}
declare const InvocationDoesNotExist_base: S.TaggedErrorClass<"InvocationDoesNotExist", {
    readonly message: any;
}>;
export declare class InvocationDoesNotExist extends /*@__PURE__*/ InvocationDoesNotExist_base {
}
declare const ItemContentMismatchException_base: S.TaggedErrorClass<"ItemContentMismatchException", {
    readonly TypeName: any;
    readonly message: any;
}>;
export declare class ItemContentMismatchException extends /*@__PURE__*/ ItemContentMismatchException_base {
}
declare const ItemSizeLimitExceededException_base: S.TaggedErrorClass<"ItemSizeLimitExceededException", {
    readonly TypeName: any;
    readonly message: any;
}>;
export declare class ItemSizeLimitExceededException extends /*@__PURE__*/ ItemSizeLimitExceededException_base {
}
declare const MalformedResourcePolicyDocumentException_base: S.TaggedErrorClass<"MalformedResourcePolicyDocumentException", {
    readonly message: any;
}>;
export declare class MalformedResourcePolicyDocumentException extends /*@__PURE__*/ MalformedResourcePolicyDocumentException_base {
}
declare const MaxDocumentSizeExceeded_base: S.TaggedErrorClass<"MaxDocumentSizeExceeded", {
    readonly message: any;
}>;
export declare class MaxDocumentSizeExceeded extends /*@__PURE__*/ MaxDocumentSizeExceeded_base {
}
declare const NoLongerSupportedException_base: S.TaggedErrorClass<"NoLongerSupportedException", {
    readonly message: any;
}>;
export declare class NoLongerSupportedException extends /*@__PURE__*/ NoLongerSupportedException_base {
}
declare const OpsItemAccessDeniedException_base: S.TaggedErrorClass<"OpsItemAccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OpsItemAccessDeniedException extends /*@__PURE__*/ OpsItemAccessDeniedException_base {
}
declare const OpsItemAlreadyExistsException_base: S.TaggedErrorClass<"OpsItemAlreadyExistsException", {
    readonly message: any;
    readonly OpsItemId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OpsItemAlreadyExistsException extends /*@__PURE__*/ OpsItemAlreadyExistsException_base {
}
declare const OpsItemConflictException_base: S.TaggedErrorClass<"OpsItemConflictException", {
    readonly message: any;
}>;
export declare class OpsItemConflictException extends /*@__PURE__*/ OpsItemConflictException_base {
}
declare const OpsItemInvalidParameterException_base: S.TaggedErrorClass<"OpsItemInvalidParameterException", {
    readonly ParameterNames: any;
    readonly message: any;
}>;
export declare class OpsItemInvalidParameterException extends /*@__PURE__*/ OpsItemInvalidParameterException_base {
}
declare const OpsItemLimitExceededException_base: S.TaggedErrorClass<"OpsItemLimitExceededException", {
    readonly ResourceTypes: any;
    readonly Limit: any;
    readonly LimitType: any;
    readonly message: any;
}>;
export declare class OpsItemLimitExceededException extends /*@__PURE__*/ OpsItemLimitExceededException_base {
}
declare const OpsItemNotFoundException_base: S.TaggedErrorClass<"OpsItemNotFoundException", {
    readonly message: any;
}>;
export declare class OpsItemNotFoundException extends /*@__PURE__*/ OpsItemNotFoundException_base {
}
declare const OpsItemRelatedItemAlreadyExistsException_base: S.TaggedErrorClass<"OpsItemRelatedItemAlreadyExistsException", {
    readonly message: any;
    readonly ResourceUri: any;
    readonly OpsItemId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OpsItemRelatedItemAlreadyExistsException extends /*@__PURE__*/ OpsItemRelatedItemAlreadyExistsException_base {
}
declare const OpsItemRelatedItemAssociationNotFoundException_base: S.TaggedErrorClass<"OpsItemRelatedItemAssociationNotFoundException", {
    readonly message: any;
}>;
export declare class OpsItemRelatedItemAssociationNotFoundException extends /*@__PURE__*/ OpsItemRelatedItemAssociationNotFoundException_base {
}
declare const OpsMetadataAlreadyExistsException_base: S.TaggedErrorClass<"OpsMetadataAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OpsMetadataAlreadyExistsException extends /*@__PURE__*/ OpsMetadataAlreadyExistsException_base {
}
declare const OpsMetadataInvalidArgumentException_base: S.TaggedErrorClass<"OpsMetadataInvalidArgumentException", {
    readonly message: any;
}>;
export declare class OpsMetadataInvalidArgumentException extends /*@__PURE__*/ OpsMetadataInvalidArgumentException_base {
}
declare const OpsMetadataKeyLimitExceededException_base: S.TaggedErrorClass<"OpsMetadataKeyLimitExceededException", {
    readonly message: any;
}>;
export declare class OpsMetadataKeyLimitExceededException extends /*@__PURE__*/ OpsMetadataKeyLimitExceededException_base {
}
declare const OpsMetadataLimitExceededException_base: S.TaggedErrorClass<"OpsMetadataLimitExceededException", {
    readonly message: any;
}>;
export declare class OpsMetadataLimitExceededException extends /*@__PURE__*/ OpsMetadataLimitExceededException_base {
}
declare const OpsMetadataNotFoundException_base: S.TaggedErrorClass<"OpsMetadataNotFoundException", {
    readonly message: any;
}>;
export declare class OpsMetadataNotFoundException extends /*@__PURE__*/ OpsMetadataNotFoundException_base {
}
declare const OpsMetadataTooManyUpdatesException_base: S.TaggedErrorClass<"OpsMetadataTooManyUpdatesException", {
    readonly message: any;
}>;
export declare class OpsMetadataTooManyUpdatesException extends /*@__PURE__*/ OpsMetadataTooManyUpdatesException_base {
}
declare const ParameterAlreadyExists_base: S.TaggedErrorClass<"ParameterAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ParameterAlreadyExists extends /*@__PURE__*/ ParameterAlreadyExists_base {
}
declare const ParameterLimitExceeded_base: S.TaggedErrorClass<"ParameterLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ParameterLimitExceeded extends /*@__PURE__*/ ParameterLimitExceeded_base {
}
declare const ParameterMaxVersionLimitExceeded_base: S.TaggedErrorClass<"ParameterMaxVersionLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ParameterMaxVersionLimitExceeded extends /*@__PURE__*/ ParameterMaxVersionLimitExceeded_base {
}
declare const ParameterNotFound_base: S.TaggedErrorClass<"ParameterNotFound", {
    readonly message: any;
}>;
export declare class ParameterNotFound extends /*@__PURE__*/ ParameterNotFound_base {
}
declare const ParameterPatternMismatchException_base: S.TaggedErrorClass<"ParameterPatternMismatchException", {
    readonly message: any;
}>;
export declare class ParameterPatternMismatchException extends /*@__PURE__*/ ParameterPatternMismatchException_base {
}
declare const ParameterVersionLabelLimitExceeded_base: S.TaggedErrorClass<"ParameterVersionLabelLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ParameterVersionLabelLimitExceeded extends /*@__PURE__*/ ParameterVersionLabelLimitExceeded_base {
}
declare const ParameterVersionNotFound_base: S.TaggedErrorClass<"ParameterVersionNotFound", {
    readonly message: any;
}>;
export declare class ParameterVersionNotFound extends /*@__PURE__*/ ParameterVersionNotFound_base {
}
declare const PoliciesLimitExceededException_base: S.TaggedErrorClass<"PoliciesLimitExceededException", {
    readonly message: any;
}>;
export declare class PoliciesLimitExceededException extends /*@__PURE__*/ PoliciesLimitExceededException_base {
}
declare const ResourceDataSyncAlreadyExistsException_base: S.TaggedErrorClass<"ResourceDataSyncAlreadyExistsException", {
    readonly SyncName: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceDataSyncAlreadyExistsException extends /*@__PURE__*/ ResourceDataSyncAlreadyExistsException_base {
}
declare const ResourceDataSyncConflictException_base: S.TaggedErrorClass<"ResourceDataSyncConflictException", {
    readonly message: any;
}>;
export declare class ResourceDataSyncConflictException extends /*@__PURE__*/ ResourceDataSyncConflictException_base {
}
declare const ResourceDataSyncCountExceededException_base: S.TaggedErrorClass<"ResourceDataSyncCountExceededException", {
    readonly message: any;
}>;
export declare class ResourceDataSyncCountExceededException extends /*@__PURE__*/ ResourceDataSyncCountExceededException_base {
}
declare const ResourceDataSyncInvalidConfigurationException_base: S.TaggedErrorClass<"ResourceDataSyncInvalidConfigurationException", {
    readonly message: any;
}>;
export declare class ResourceDataSyncInvalidConfigurationException extends /*@__PURE__*/ ResourceDataSyncInvalidConfigurationException_base {
}
declare const ResourceDataSyncNotFoundException_base: S.TaggedErrorClass<"ResourceDataSyncNotFoundException", {
    readonly SyncName: any;
    readonly SyncType: any;
    readonly message: any;
}>;
export declare class ResourceDataSyncNotFoundException extends /*@__PURE__*/ ResourceDataSyncNotFoundException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
}>;
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourcePolicyConflictException_base: S.TaggedErrorClass<"ResourcePolicyConflictException", {
    readonly message: any;
}>;
export declare class ResourcePolicyConflictException extends /*@__PURE__*/ ResourcePolicyConflictException_base {
}
declare const ResourcePolicyInvalidParameterException_base: S.TaggedErrorClass<"ResourcePolicyInvalidParameterException", {
    readonly ParameterNames: any;
    readonly message: any;
}>;
export declare class ResourcePolicyInvalidParameterException extends /*@__PURE__*/ ResourcePolicyInvalidParameterException_base {
}
declare const ResourcePolicyLimitExceededException_base: S.TaggedErrorClass<"ResourcePolicyLimitExceededException", {
    readonly Limit: any;
    readonly LimitType: any;
    readonly message: any;
}>;
export declare class ResourcePolicyLimitExceededException extends /*@__PURE__*/ ResourcePolicyLimitExceededException_base {
}
declare const ResourcePolicyNotFoundException_base: S.TaggedErrorClass<"ResourcePolicyNotFoundException", {
    readonly message: any;
}>;
export declare class ResourcePolicyNotFoundException extends /*@__PURE__*/ ResourcePolicyNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}>;
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceSettingNotFound_base: S.TaggedErrorClass<"ServiceSettingNotFound", {
    readonly message: any;
}>;
export declare class ServiceSettingNotFound extends /*@__PURE__*/ ServiceSettingNotFound_base {
}
declare const StatusUnchanged_base: S.TaggedErrorClass<"StatusUnchanged", {
    readonly message: any;
}>;
export declare class StatusUnchanged extends /*@__PURE__*/ StatusUnchanged_base {
}
declare const SubTypeCountLimitExceededException_base: S.TaggedErrorClass<"SubTypeCountLimitExceededException", {
    readonly message: any;
}>;
export declare class SubTypeCountLimitExceededException extends /*@__PURE__*/ SubTypeCountLimitExceededException_base {
}
declare const TargetInUseException_base: S.TaggedErrorClass<"TargetInUseException", {
    readonly message: any;
}>;
export declare class TargetInUseException extends /*@__PURE__*/ TargetInUseException_base {
}
declare const TargetNotConnected_base: S.TaggedErrorClass<"TargetNotConnected", {
    readonly message: any;
}>;
export declare class TargetNotConnected extends /*@__PURE__*/ TargetNotConnected_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsError_base: S.TaggedErrorClass<"TooManyTagsError", {
    readonly message: any;
}>;
export declare class TooManyTagsError extends /*@__PURE__*/ TooManyTagsError_base {
}
declare const TooManyUpdates_base: S.TaggedErrorClass<"TooManyUpdates", {
    readonly message: any;
}>;
export declare class TooManyUpdates extends /*@__PURE__*/ TooManyUpdates_base {
}
declare const TotalSizeLimitExceededException_base: S.TaggedErrorClass<"TotalSizeLimitExceededException", {
    readonly message: any;
}>;
export declare class TotalSizeLimitExceededException extends /*@__PURE__*/ TotalSizeLimitExceededException_base {
}
declare const UnsupportedCalendarException_base: S.TaggedErrorClass<"UnsupportedCalendarException", {
    readonly message: any;
}>;
export declare class UnsupportedCalendarException extends /*@__PURE__*/ UnsupportedCalendarException_base {
}
declare const UnsupportedFeatureRequiredException_base: S.TaggedErrorClass<"UnsupportedFeatureRequiredException", {
    readonly message: any;
}>;
export declare class UnsupportedFeatureRequiredException extends /*@__PURE__*/ UnsupportedFeatureRequiredException_base {
}
declare const UnsupportedInventoryItemContextException_base: S.TaggedErrorClass<"UnsupportedInventoryItemContextException", {
    readonly TypeName: any;
    readonly message: any;
}>;
export declare class UnsupportedInventoryItemContextException extends /*@__PURE__*/ UnsupportedInventoryItemContextException_base {
}
declare const UnsupportedInventorySchemaVersionException_base: S.TaggedErrorClass<"UnsupportedInventorySchemaVersionException", {
    readonly message: any;
}>;
export declare class UnsupportedInventorySchemaVersionException extends /*@__PURE__*/ UnsupportedInventorySchemaVersionException_base {
}
declare const UnsupportedOperatingSystem_base: S.TaggedErrorClass<"UnsupportedOperatingSystem", {
    readonly message: any;
}>;
export declare class UnsupportedOperatingSystem extends /*@__PURE__*/ UnsupportedOperatingSystem_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}>;
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const UnsupportedParameterType_base: S.TaggedErrorClass<"UnsupportedParameterType", {
    readonly message: any;
}>;
export declare class UnsupportedParameterType extends /*@__PURE__*/ UnsupportedParameterType_base {
}
declare const UnsupportedPlatformType_base: S.TaggedErrorClass<"UnsupportedPlatformType", {
    readonly message: any;
}>;
export declare class UnsupportedPlatformType extends /*@__PURE__*/ UnsupportedPlatformType_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly ReasonCode: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceTypeForTagging = "Document" | "ManagedInstance" | "MaintenanceWindow" | "Parameter" | "PatchBaseline" | "OpsItem" | "OpsMetadata" | "Automation" | "Association" | "CloudConnector" | (string & {});
export type ResourceId = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface AddTagsToResourceRequest {
    ResourceType: ResourceTypeForTagging;
    ResourceId: string;
    Tags: Tag[];
}
export interface AddTagsToResourceResult {
}
export type OpsItemId = string;
export type OpsItemRelatedItemAssociationType = string;
export type OpsItemRelatedItemAssociationResourceType = string;
export type OpsItemRelatedItemAssociationResourceUri = string;
export interface AssociateOpsItemRelatedItemRequest {
    OpsItemId: string;
    AssociationType: string;
    ResourceType: string;
    ResourceUri: string;
}
export type OpsItemRelatedItemAssociationId = string;
export interface AssociateOpsItemRelatedItemResponse {
    AssociationId?: string | undefined;
}
export type CommandId = string;
export type InstanceId = string;
export type InstanceIdList = string[];
export interface CancelCommandRequest {
    CommandId: string;
    InstanceIds?: string[] | undefined;
}
export interface CancelCommandResult {
}
export type MaintenanceWindowExecutionId = string;
export interface CancelMaintenanceWindowExecutionRequest {
    WindowExecutionId: string;
}
export interface CancelMaintenanceWindowExecutionResult {
    WindowExecutionId?: string | undefined;
}
export type ActivationDescription = string;
export type DefaultInstanceName = string;
export type IamRole = string;
export type RegistrationLimit = number;
export type ExpirationDate = Date;
export type RegistrationMetadataKey = string;
export type RegistrationMetadataValue = string;
export interface RegistrationMetadataItem {
    Key: string;
    Value: string;
}
export type RegistrationMetadataList = RegistrationMetadataItem[];
export interface CreateActivationRequest {
    Description?: string | undefined;
    DefaultInstanceName?: string | undefined;
    IamRole: string;
    RegistrationLimit?: number | undefined;
    ExpirationDate?: Date | undefined;
    Tags?: Tag[] | undefined;
    RegistrationMetadata?: RegistrationMetadataItem[] | undefined;
}
export type ActivationId = string;
export type ActivationCode = string;
export interface CreateActivationResult {
    ActivationId?: string | undefined;
    ActivationCode?: string | undefined;
}
export type DocumentARN = string;
export type DocumentVersion = string;
export type ParameterName = string;
export type ParameterValue = string;
export type ParameterValueList = string[];
export type Parameters = {
    [key: string]: string[] | undefined;
};
export type TargetKey = string;
export type TargetValue = string;
export type TargetValues = string[];
export interface Target {
    Key?: string | undefined;
    Values?: string[] | undefined;
}
export type Targets = Target[];
export type ScheduleExpression = string;
export type S3Region = string;
export type S3BucketName = string;
export type S3KeyPrefix = string;
export interface S3OutputLocation {
    OutputS3Region?: string | undefined;
    OutputS3BucketName?: string | undefined;
    OutputS3KeyPrefix?: string | undefined;
}
export interface InstanceAssociationOutputLocation {
    S3Location?: S3OutputLocation | undefined;
}
export type AssociationName = string;
export type AutomationTargetParameterName = string;
export type MaxErrors = string;
export type MaxConcurrency = string;
export type AssociationComplianceSeverity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "UNSPECIFIED" | (string & {});
export type AssociationSyncCompliance = "AUTO" | "MANUAL" | (string & {});
export type ApplyOnlyAtCronInterval = boolean;
export type CalendarNameOrARN = string;
export type CalendarNameOrARNList = string[];
export type Account = string;
export type Accounts = string[];
export type Region = string;
export type Regions = string[];
export type ExecutionRoleName = string;
export type AlarmName = string;
export interface Alarm {
    Name: string;
}
export type AlarmList = Alarm[];
export interface AlarmConfiguration {
    IgnorePollAlarmFailure?: boolean | undefined;
    Alarms: Alarm[];
}
export type ExcludeAccount = string;
export type ExcludeAccounts = string[];
export type AutomationTargets = Target[];
export interface TargetLocation {
    Accounts?: string[] | undefined;
    Regions?: string[] | undefined;
    TargetLocationMaxConcurrency?: string | undefined;
    TargetLocationMaxErrors?: string | undefined;
    ExecutionRoleName?: string | undefined;
    TargetLocationAlarmConfiguration?: AlarmConfiguration | undefined;
    IncludeChildOrganizationUnits?: boolean | undefined;
    ExcludeAccounts?: string[] | undefined;
    Targets?: Target[] | undefined;
    TargetsMaxConcurrency?: string | undefined;
    TargetsMaxErrors?: string | undefined;
}
export type TargetLocations = TargetLocation[];
export type ScheduleOffset = number;
export type Duration = number;
export type TargetMapKey = string;
export type TargetMapValue = string;
export type TargetMapValueList = string[];
export type TargetMap = {
    [key: string]: string[] | undefined;
};
export type TargetMaps = {
    [key: string]: string[] | undefined;
}[];
export type AssociationDispatchAssumeRoleArn = string;
export interface CreateAssociationRequest {
    Name: string;
    DocumentVersion?: string | undefined;
    InstanceId?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    Targets?: Target[] | undefined;
    ScheduleExpression?: string | undefined;
    OutputLocation?: InstanceAssociationOutputLocation | undefined;
    AssociationName?: string | undefined;
    AutomationTargetParameterName?: string | undefined;
    MaxErrors?: string | undefined;
    MaxConcurrency?: string | undefined;
    ComplianceSeverity?: AssociationComplianceSeverity | undefined;
    SyncCompliance?: AssociationSyncCompliance | undefined;
    ApplyOnlyAtCronInterval?: boolean | undefined;
    CalendarNames?: string[] | undefined;
    TargetLocations?: TargetLocation[] | undefined;
    ScheduleOffset?: number | undefined;
    Duration?: number | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    Tags?: Tag[] | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    AssociationDispatchAssumeRole?: string | undefined;
}
export type AssociationVersion = string;
export type AssociationStatusName = "Pending" | "Success" | "Failed" | (string & {});
export type StatusMessage = string;
export type StatusAdditionalInfo = string;
export interface AssociationStatus {
    Date: Date;
    Name: AssociationStatusName;
    Message: string;
    AdditionalInfo?: string | undefined;
}
export type StatusName = string;
export type InstanceCount = number;
export type AssociationStatusAggregatedCount = {
    [key: string]: number | undefined;
};
export interface AssociationOverview {
    Status?: string | undefined;
    DetailedStatus?: string | undefined;
    AssociationStatusAggregatedCount?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type AssociationId = string;
export type ExternalAlarmState = "UNKNOWN" | "ALARM" | (string & {});
export interface AlarmStateInformation {
    Name: string;
    State: ExternalAlarmState;
}
export type AlarmStateInformationList = AlarmStateInformation[];
export interface AssociationDescription {
    Name?: string | undefined;
    InstanceId?: string | undefined;
    AssociationVersion?: string | undefined;
    Date?: Date | undefined;
    LastUpdateAssociationDate?: Date | undefined;
    Status?: AssociationStatus | undefined;
    Overview?: AssociationOverview | undefined;
    DocumentVersion?: string | undefined;
    AutomationTargetParameterName?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    AssociationId?: string | undefined;
    Targets?: Target[] | undefined;
    ScheduleExpression?: string | undefined;
    OutputLocation?: InstanceAssociationOutputLocation | undefined;
    LastExecutionDate?: Date | undefined;
    LastSuccessfulExecutionDate?: Date | undefined;
    AssociationName?: string | undefined;
    MaxErrors?: string | undefined;
    MaxConcurrency?: string | undefined;
    ComplianceSeverity?: AssociationComplianceSeverity | undefined;
    SyncCompliance?: AssociationSyncCompliance | undefined;
    ApplyOnlyAtCronInterval?: boolean | undefined;
    CalendarNames?: string[] | undefined;
    TargetLocations?: TargetLocation[] | undefined;
    ScheduleOffset?: number | undefined;
    Duration?: number | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    TriggeredAlarms?: AlarmStateInformation[] | undefined;
    AssociationDispatchAssumeRole?: string | undefined;
}
export interface CreateAssociationResult {
    AssociationDescription?: AssociationDescription | undefined;
}
export interface CreateAssociationBatchRequestEntry {
    Name: string;
    InstanceId?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    AutomationTargetParameterName?: string | undefined;
    DocumentVersion?: string | undefined;
    Targets?: Target[] | undefined;
    ScheduleExpression?: string | undefined;
    OutputLocation?: InstanceAssociationOutputLocation | undefined;
    AssociationName?: string | undefined;
    MaxErrors?: string | undefined;
    MaxConcurrency?: string | undefined;
    ComplianceSeverity?: AssociationComplianceSeverity | undefined;
    SyncCompliance?: AssociationSyncCompliance | undefined;
    ApplyOnlyAtCronInterval?: boolean | undefined;
    CalendarNames?: string[] | undefined;
    TargetLocations?: TargetLocation[] | undefined;
    ScheduleOffset?: number | undefined;
    Duration?: number | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
}
export type CreateAssociationBatchRequestEntries = CreateAssociationBatchRequestEntry[];
export interface CreateAssociationBatchRequest {
    Entries: CreateAssociationBatchRequestEntry[];
    AssociationDispatchAssumeRole?: string | undefined;
}
export type AssociationDescriptionList = AssociationDescription[];
export type BatchErrorMessage = string;
export type Fault = "Client" | "Server" | "Unknown" | (string & {});
export interface FailedCreateAssociation {
    Entry?: CreateAssociationBatchRequestEntry | undefined;
    Message?: string | undefined;
    Fault?: Fault | undefined;
}
export type FailedCreateAssociationList = FailedCreateAssociation[];
export interface CreateAssociationBatchResult {
    Successful?: AssociationDescription[] | undefined;
    Failed?: FailedCreateAssociation[] | undefined;
}
export type DisplayName = string;
export type CloudConnectorIamRoleArn = string;
export type CloudConnectorDescription = string;
export type AzureTenantId = string;
export type AzureTenantDisplayName = string;
export type AzureApplicationId = string;
export type AzureApplicationDisplayName = string;
export type AzureSubscriptionId = string;
export type AzureSubscriptionDisplayName = string;
export interface AzureSubscription {
    Id: string;
    DisplayName?: string | undefined;
}
export type AzureSubscriptionList = AzureSubscription[];
export type ConfigurationTargets = {
    Subscriptions: AzureSubscription[];
};
export interface AzureConfiguration {
    TenantId: string;
    TenantDisplayName?: string | undefined;
    ApplicationId: string;
    ApplicationDisplayName?: string | undefined;
    Targets?: ConfigurationTargets | undefined;
}
export type GcpOrganizationId = string;
export type GcpWorkloadIdentityPoolProvider = string;
export type GcpServiceAccountEmail = string;
export type GcpProjectId = string;
export type GcpProjectDisplayName = string;
export interface GcpProject {
    ProjectId: string;
    ProjectDisplayName?: string | undefined;
}
export type GcpProjectList = GcpProject[];
export type GcpConfigurationTargets = {
    Projects: GcpProject[];
};
export interface GcpConfiguration {
    OrganizationId?: string | undefined;
    WorkloadIdentityPoolProvider: string;
    ServiceAccountEmail: string;
    Targets?: GcpConfigurationTargets | undefined;
}
export type CloudConnectorConfiguration = {
    AzureConfiguration: AzureConfiguration;
    GcpConfiguration?: undefined;
} | {
    AzureConfiguration?: undefined;
    GcpConfiguration: GcpConfiguration;
};
export type ConfigConnectorArn = string;
export interface CreateCloudConnectorRequest {
    DisplayName: string;
    RoleArn: string;
    Description?: string | undefined;
    Configuration: CloudConnectorConfiguration;
    ConfigConnectorArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type CloudConnectorId = string;
export interface CreateCloudConnectorResult {
    CloudConnectorId?: string | undefined;
}
export type DocumentContent = string;
export type RequireType = string;
export type DocumentVersionName = string;
export interface DocumentRequires {
    Name: string;
    Version?: string | undefined;
    RequireType?: string | undefined;
    VersionName?: string | undefined;
}
export type DocumentRequiresList = DocumentRequires[];
export type AttachmentsSourceKey = "SourceUrl" | "S3FileUrl" | "AttachmentReference" | (string & {});
export type AttachmentsSourceValue = string;
export type AttachmentsSourceValues = string[];
export type AttachmentIdentifier = string;
export interface AttachmentsSource {
    Key?: AttachmentsSourceKey | undefined;
    Values?: string[] | undefined;
    Name?: string | undefined;
}
export type AttachmentsSourceList = AttachmentsSource[];
export type DocumentName = string;
export type DocumentDisplayName = string;
export type DocumentType = "Command" | "Policy" | "Automation" | "Session" | "Package" | "ApplicationConfiguration" | "ApplicationConfigurationSchema" | "DeploymentStrategy" | "ChangeCalendar" | "Automation.ChangeTemplate" | "ProblemAnalysis" | "ProblemAnalysisTemplate" | "CloudFormation" | "ConformancePackTemplate" | "QuickSetup" | "ManualApprovalPolicy" | "AutoApprovalPolicy" | (string & {});
export type DocumentFormat = "YAML" | "JSON" | "TEXT" | (string & {});
export type TargetType = string;
export interface CreateDocumentRequest {
    Content: string;
    Requires?: DocumentRequires[] | undefined;
    Attachments?: AttachmentsSource[] | undefined;
    Name: string;
    DisplayName?: string | undefined;
    VersionName?: string | undefined;
    DocumentType?: DocumentType | undefined;
    DocumentFormat?: DocumentFormat | undefined;
    TargetType?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type DocumentSha1 = string;
export type DocumentHash = string;
export type DocumentHashType = "Sha256" | "Sha1" | (string & {});
export type DocumentOwner = string;
export type DocumentStatus = "Creating" | "Active" | "Updating" | "Deleting" | "Failed" | (string & {});
export type DocumentStatusInformation = string;
export type DescriptionInDocument = string;
export type DocumentParameterName = string;
export type DocumentParameterType = "String" | "StringList" | (string & {});
export type DocumentParameterDescrption = string;
export type DocumentParameterDefaultValue = string;
export interface DocumentParameter {
    Name?: string | undefined;
    Type?: DocumentParameterType | undefined;
    Description?: string | undefined;
    DefaultValue?: string | undefined;
}
export type DocumentParameterList = DocumentParameter[];
export type PlatformType = "Windows" | "Linux" | "MacOS" | (string & {});
export type PlatformTypeList = PlatformType[];
export type DocumentSchemaVersion = string;
export type AttachmentName = string;
export interface AttachmentInformation {
    Name?: string | undefined;
}
export type AttachmentInformationList = AttachmentInformation[];
export type DocumentAuthor = string;
export type ReviewStatus = "APPROVED" | "NOT_REVIEWED" | "PENDING" | "REJECTED" | (string & {});
export type Reviewer = string;
export interface ReviewInformation {
    ReviewedTime?: Date | undefined;
    Status?: ReviewStatus | undefined;
    Reviewer?: string | undefined;
}
export type ReviewInformationList = ReviewInformation[];
export type Category = string;
export type CategoryList = string[];
export type CategoryEnumList = string[];
export interface DocumentDescription {
    Sha1?: string | undefined;
    Hash?: string | undefined;
    HashType?: DocumentHashType | undefined;
    Name?: string | undefined;
    DisplayName?: string | undefined;
    VersionName?: string | undefined;
    Owner?: string | undefined;
    CreatedDate?: Date | undefined;
    Status?: DocumentStatus | undefined;
    StatusInformation?: string | undefined;
    DocumentVersion?: string | undefined;
    Description?: string | undefined;
    Parameters?: DocumentParameter[] | undefined;
    PlatformTypes?: PlatformType[] | undefined;
    DocumentType?: DocumentType | undefined;
    SchemaVersion?: string | undefined;
    LatestVersion?: string | undefined;
    DefaultVersion?: string | undefined;
    DocumentFormat?: DocumentFormat | undefined;
    TargetType?: string | undefined;
    Tags?: Tag[] | undefined;
    AttachmentsInformation?: AttachmentInformation[] | undefined;
    Requires?: DocumentRequires[] | undefined;
    Author?: string | undefined;
    ReviewInformation?: ReviewInformation[] | undefined;
    ApprovedVersion?: string | undefined;
    PendingReviewVersion?: string | undefined;
    ReviewStatus?: ReviewStatus | undefined;
    Category?: string[] | undefined;
    CategoryEnum?: string[] | undefined;
}
export interface CreateDocumentResult {
    DocumentDescription?: DocumentDescription | undefined;
}
export type MaintenanceWindowName = string;
export type MaintenanceWindowDescription = string | redacted.Redacted<string>;
export type MaintenanceWindowStringDateTime = string;
export type MaintenanceWindowSchedule = string;
export type MaintenanceWindowTimezone = string;
export type MaintenanceWindowOffset = number;
export type MaintenanceWindowDurationHours = number;
export type MaintenanceWindowCutoff = number;
export type MaintenanceWindowAllowUnassociatedTargets = boolean;
export type ClientToken = string;
export interface CreateMaintenanceWindowRequest {
    Name: string;
    Description?: string | redacted.Redacted<string> | undefined;
    StartDate?: string | undefined;
    EndDate?: string | undefined;
    Schedule: string;
    ScheduleTimezone?: string | undefined;
    ScheduleOffset?: number | undefined;
    Duration: number;
    Cutoff: number;
    AllowUnassociatedTargets: boolean;
    ClientToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type MaintenanceWindowId = string;
export interface CreateMaintenanceWindowResult {
    WindowId?: string | undefined;
}
export type OpsItemDescription = string;
export type OpsItemType = string;
export type OpsItemDataKey = string;
export type OpsItemDataValueString = string;
export type OpsItemDataType = "SearchableString" | "String" | (string & {});
export interface OpsItemDataValue {
    Value?: string | undefined;
    Type?: OpsItemDataType | undefined;
}
export type OpsItemOperationalData = {
    [key: string]: OpsItemDataValue | undefined;
};
export interface OpsItemNotification {
    Arn?: string | undefined;
}
export type OpsItemNotifications = OpsItemNotification[];
export type OpsItemPriority = number;
export interface RelatedOpsItem {
    OpsItemId: string;
}
export type RelatedOpsItems = RelatedOpsItem[];
export type OpsItemSource = string;
export type OpsItemTitle = string;
export type OpsItemCategory = string;
export type OpsItemSeverity = string;
export type OpsItemAccountId = string;
export interface CreateOpsItemRequest {
    Description: string;
    OpsItemType?: string | undefined;
    OperationalData?: {
        [key: string]: OpsItemDataValue | undefined;
    } | undefined;
    Notifications?: OpsItemNotification[] | undefined;
    Priority?: number | undefined;
    RelatedOpsItems?: RelatedOpsItem[] | undefined;
    Source: string;
    Title: string;
    Tags?: Tag[] | undefined;
    Category?: string | undefined;
    Severity?: string | undefined;
    ActualStartTime?: Date | undefined;
    ActualEndTime?: Date | undefined;
    PlannedStartTime?: Date | undefined;
    PlannedEndTime?: Date | undefined;
    AccountId?: string | undefined;
}
export type OpsItemArn = string;
export interface CreateOpsItemResponse {
    OpsItemId?: string | undefined;
    OpsItemArn?: string | undefined;
}
export type OpsMetadataResourceId = string;
export type MetadataKey = string;
export type MetadataValueString = string;
export interface MetadataValue {
    Value?: string | undefined;
}
export type MetadataMap = {
    [key: string]: MetadataValue | undefined;
};
export interface CreateOpsMetadataRequest {
    ResourceId: string;
    Metadata?: {
        [key: string]: MetadataValue | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
}
export type OpsMetadataArn = string;
export interface CreateOpsMetadataResult {
    OpsMetadataArn?: string | undefined;
}
export type OperatingSystem = "WINDOWS" | "AMAZON_LINUX" | "AMAZON_LINUX_2" | "AMAZON_LINUX_2022" | "UBUNTU" | "REDHAT_ENTERPRISE_LINUX" | "SUSE" | "CENTOS" | "ORACLE_LINUX" | "DEBIAN" | "MACOS" | "RASPBIAN" | "ROCKY_LINUX" | "ALMA_LINUX" | "AMAZON_LINUX_2023" | (string & {});
export type BaselineName = string;
export type PatchFilterKey = "ARCH" | "ADVISORY_ID" | "BUGZILLA_ID" | "PATCH_SET" | "PRODUCT" | "PRODUCT_FAMILY" | "CLASSIFICATION" | "CVE_ID" | "EPOCH" | "MSRC_SEVERITY" | "NAME" | "PATCH_ID" | "SECTION" | "PRIORITY" | "REPOSITORY" | "RELEASE" | "SEVERITY" | "SECURITY" | "VERSION" | (string & {});
export type PatchFilterValue = string;
export type PatchFilterValueList = string[];
export interface PatchFilter {
    Key: PatchFilterKey;
    Values: string[];
}
export type PatchFilterList = PatchFilter[];
export interface PatchFilterGroup {
    PatchFilters: PatchFilter[];
}
export type PatchComplianceLevel = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFORMATIONAL" | "UNSPECIFIED" | (string & {});
export type ApproveAfterDays = number;
export type PatchStringDateTime = string;
export interface PatchRule {
    PatchFilterGroup: PatchFilterGroup;
    ComplianceLevel?: PatchComplianceLevel | undefined;
    ApproveAfterDays?: number | undefined;
    ApproveUntilDate?: string | undefined;
    EnableNonSecurity?: boolean | undefined;
}
export type PatchRuleList = PatchRule[];
export interface PatchRuleGroup {
    PatchRules: PatchRule[];
}
export type PatchId = string;
export type PatchIdList = string[];
export type PatchAction = "ALLOW_AS_DEPENDENCY" | "BLOCK" | (string & {});
export type BaselineDescription = string;
export type PatchSourceName = string;
export type PatchSourceProduct = string;
export type PatchSourceProductList = string[];
export type PatchSourceConfiguration = string | redacted.Redacted<string>;
export interface PatchSource {
    Name: string;
    Products: string[];
    Configuration: string | redacted.Redacted<string>;
}
export type PatchSourceList = PatchSource[];
export type PatchComplianceStatus = "COMPLIANT" | "NON_COMPLIANT" | (string & {});
export interface CreatePatchBaselineRequest {
    OperatingSystem?: OperatingSystem | undefined;
    Name: string;
    GlobalFilters?: PatchFilterGroup | undefined;
    ApprovalRules?: PatchRuleGroup | undefined;
    ApprovedPatches?: string[] | undefined;
    ApprovedPatchesComplianceLevel?: PatchComplianceLevel | undefined;
    ApprovedPatchesEnableNonSecurity?: boolean | undefined;
    RejectedPatches?: string[] | undefined;
    RejectedPatchesAction?: PatchAction | undefined;
    Description?: string | undefined;
    Sources?: PatchSource[] | undefined;
    AvailableSecurityUpdatesComplianceStatus?: PatchComplianceStatus | undefined;
    ClientToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type BaselineId = string;
export interface CreatePatchBaselineResult {
    BaselineId?: string | undefined;
}
export type ResourceDataSyncName = string;
export type ResourceDataSyncS3BucketName = string;
export type ResourceDataSyncS3Prefix = string;
export type ResourceDataSyncS3Format = "JsonSerDe" | (string & {});
export type ResourceDataSyncS3Region = string;
export type ResourceDataSyncAWSKMSKeyARN = string;
export type ResourceDataSyncDestinationDataSharingType = string;
export interface ResourceDataSyncDestinationDataSharing {
    DestinationDataSharingType?: string | undefined;
}
export interface ResourceDataSyncS3Destination {
    BucketName: string;
    Prefix?: string | undefined;
    SyncFormat: ResourceDataSyncS3Format;
    Region: string;
    AWSKMSKeyARN?: string | undefined;
    DestinationDataSharing?: ResourceDataSyncDestinationDataSharing | undefined;
}
export type ResourceDataSyncType = string;
export type ResourceDataSyncSourceType = string;
export type ResourceDataSyncOrganizationSourceType = string;
export type ResourceDataSyncOrganizationalUnitId = string;
export interface ResourceDataSyncOrganizationalUnit {
    OrganizationalUnitId?: string | undefined;
}
export type ResourceDataSyncOrganizationalUnitList = ResourceDataSyncOrganizationalUnit[];
export interface ResourceDataSyncAwsOrganizationsSource {
    OrganizationSourceType: string;
    OrganizationalUnits?: ResourceDataSyncOrganizationalUnit[] | undefined;
}
export type ResourceDataSyncSourceRegion = string;
export type ResourceDataSyncSourceRegionList = string[];
export type ResourceDataSyncIncludeFutureRegions = boolean;
export type ResourceDataSyncEnableAllOpsDataSources = boolean;
export interface ResourceDataSyncSource {
    SourceType: string;
    AwsOrganizationsSource?: ResourceDataSyncAwsOrganizationsSource | undefined;
    SourceRegions: string[];
    IncludeFutureRegions?: boolean | undefined;
    EnableAllOpsDataSources?: boolean | undefined;
}
export interface CreateResourceDataSyncRequest {
    SyncName: string;
    S3Destination?: ResourceDataSyncS3Destination | undefined;
    SyncType?: string | undefined;
    SyncSource?: ResourceDataSyncSource | undefined;
}
export interface CreateResourceDataSyncResult {
}
export interface DeleteActivationRequest {
    ActivationId: string;
}
export interface DeleteActivationResult {
}
export interface DeleteAssociationRequest {
    Name?: string | undefined;
    InstanceId?: string | undefined;
    AssociationId?: string | undefined;
}
export interface DeleteAssociationResult {
}
export interface DeleteCloudConnectorRequest {
    CloudConnectorId: string;
}
export interface DeleteCloudConnectorResult {
    CloudConnectorId?: string | undefined;
}
export interface DeleteDocumentRequest {
    Name: string;
    DocumentVersion?: string | undefined;
    VersionName?: string | undefined;
    Force?: boolean | undefined;
}
export interface DeleteDocumentResult {
}
export type InventoryItemTypeName = string;
export type InventorySchemaDeleteOption = "DisableSchema" | "DeleteSchema" | (string & {});
export type DryRun = boolean;
export type UUID = string;
export interface DeleteInventoryRequest {
    TypeName: string;
    SchemaDeleteOption?: InventorySchemaDeleteOption | undefined;
    DryRun?: boolean | undefined;
    ClientToken?: string | undefined;
}
export type TotalCount = number;
export type RemainingCount = number;
export type InventoryItemSchemaVersion = string;
export type ResourceCount = number;
export interface InventoryDeletionSummaryItem {
    Version?: string | undefined;
    Count?: number | undefined;
    RemainingCount?: number | undefined;
}
export type InventoryDeletionSummaryItems = InventoryDeletionSummaryItem[];
export interface InventoryDeletionSummary {
    TotalCount?: number | undefined;
    RemainingCount?: number | undefined;
    SummaryItems?: InventoryDeletionSummaryItem[] | undefined;
}
export interface DeleteInventoryResult {
    DeletionId?: string | undefined;
    TypeName?: string | undefined;
    DeletionSummary?: InventoryDeletionSummary | undefined;
}
export interface DeleteMaintenanceWindowRequest {
    WindowId: string;
}
export interface DeleteMaintenanceWindowResult {
    WindowId?: string | undefined;
}
export interface DeleteOpsItemRequest {
    OpsItemId: string;
}
export interface DeleteOpsItemResponse {
}
export interface DeleteOpsMetadataRequest {
    OpsMetadataArn: string;
}
export interface DeleteOpsMetadataResult {
}
export type PSParameterName = string;
export interface DeleteParameterRequest {
    Name: string;
}
export interface DeleteParameterResult {
}
export type ParameterNameList = string[];
export interface DeleteParametersRequest {
    Names: string[];
}
export interface DeleteParametersResult {
    DeletedParameters?: string[] | undefined;
    InvalidParameters?: string[] | undefined;
}
export interface DeletePatchBaselineRequest {
    BaselineId: string;
}
export interface DeletePatchBaselineResult {
    BaselineId?: string | undefined;
}
export interface DeleteResourceDataSyncRequest {
    SyncName: string;
    SyncType?: string | undefined;
}
export interface DeleteResourceDataSyncResult {
}
export type ResourceArnString = string;
export type PolicyId = string;
export type PolicyHash = string;
export type DeletionMode = "RemoveSharing" | "RollbackMigration" | (string & {});
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
    PolicyId: string;
    PolicyHash: string;
    DeletionMode?: DeletionMode | undefined;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeregisterDefaultHostManagementConfigurationRequest {
}
export interface DeregisterDefaultHostManagementConfigurationResult {
}
export type ManagedInstanceId = string;
export interface DeregisterManagedInstanceRequest {
    InstanceId: string;
}
export interface DeregisterManagedInstanceResult {
}
export type PatchGroup = string;
export interface DeregisterPatchBaselineForPatchGroupRequest {
    BaselineId: string;
    PatchGroup: string;
}
export interface DeregisterPatchBaselineForPatchGroupResult {
    BaselineId?: string | undefined;
    PatchGroup?: string | undefined;
}
export type MaintenanceWindowTargetId = string;
export interface DeregisterTargetFromMaintenanceWindowRequest {
    WindowId: string;
    WindowTargetId: string;
    Safe?: boolean | undefined;
}
export interface DeregisterTargetFromMaintenanceWindowResult {
    WindowId?: string | undefined;
    WindowTargetId?: string | undefined;
}
export type MaintenanceWindowTaskId = string;
export interface DeregisterTaskFromMaintenanceWindowRequest {
    WindowId: string;
    WindowTaskId: string;
}
export interface DeregisterTaskFromMaintenanceWindowResult {
    WindowId?: string | undefined;
    WindowTaskId?: string | undefined;
}
export type DescribeActivationsFilterKeys = "ActivationIds" | "DefaultInstanceName" | "IamRole" | (string & {});
export type StringList = string[];
export interface DescribeActivationsFilter {
    FilterKey?: DescribeActivationsFilterKeys | undefined;
    FilterValues?: string[] | undefined;
}
export type DescribeActivationsFilterList = DescribeActivationsFilter[];
export type MaxResults = number;
export type NextToken = string;
export interface DescribeActivationsRequest {
    Filters?: DescribeActivationsFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type RegistrationsCount = number;
export type CreatedDate = Date;
export interface Activation {
    ActivationId?: string | undefined;
    Description?: string | undefined;
    DefaultInstanceName?: string | undefined;
    IamRole?: string | undefined;
    RegistrationLimit?: number | undefined;
    RegistrationsCount?: number | undefined;
    ExpirationDate?: Date | undefined;
    Expired?: boolean | undefined;
    CreatedDate?: Date | undefined;
    Tags?: Tag[] | undefined;
}
export type ActivationList = Activation[];
export interface DescribeActivationsResult {
    ActivationList?: Activation[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeAssociationRequest {
    Name?: string | undefined;
    InstanceId?: string | undefined;
    AssociationId?: string | undefined;
    AssociationVersion?: string | undefined;
}
export interface DescribeAssociationResult {
    AssociationDescription?: AssociationDescription | undefined;
}
export type AssociationExecutionFilterKey = "ExecutionId" | "Status" | "CreatedTime" | (string & {});
export type AssociationExecutionFilterValue = string;
export type AssociationFilterOperatorType = "EQUAL" | "LESS_THAN" | "GREATER_THAN" | (string & {});
export interface AssociationExecutionFilter {
    Key: AssociationExecutionFilterKey;
    Value: string;
    Type: AssociationFilterOperatorType;
}
export type AssociationExecutionFilterList = AssociationExecutionFilter[];
export interface DescribeAssociationExecutionsRequest {
    AssociationId: string;
    Filters?: AssociationExecutionFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AssociationExecutionId = string;
export type ResourceCountByStatus = string;
export interface AssociationExecution {
    AssociationId?: string | undefined;
    AssociationVersion?: string | undefined;
    ExecutionId?: string | undefined;
    Status?: string | undefined;
    DetailedStatus?: string | undefined;
    CreatedTime?: Date | undefined;
    LastExecutionDate?: Date | undefined;
    ResourceCountByStatus?: string | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    TriggeredAlarms?: AlarmStateInformation[] | undefined;
}
export type AssociationExecutionsList = AssociationExecution[];
export interface DescribeAssociationExecutionsResult {
    AssociationExecutions?: AssociationExecution[] | undefined;
    NextToken?: string | undefined;
}
export type AssociationExecutionTargetsFilterKey = "Status" | "ResourceId" | "ResourceType" | (string & {});
export type AssociationExecutionTargetsFilterValue = string;
export interface AssociationExecutionTargetsFilter {
    Key: AssociationExecutionTargetsFilterKey;
    Value: string;
}
export type AssociationExecutionTargetsFilterList = AssociationExecutionTargetsFilter[];
export interface DescribeAssociationExecutionTargetsRequest {
    AssociationId: string;
    ExecutionId: string;
    Filters?: AssociationExecutionTargetsFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AssociationResourceId = string;
export type AssociationResourceType = string;
export type OutputSourceId = string;
export type OutputSourceType = string;
export interface OutputSource {
    OutputSourceId?: string | undefined;
    OutputSourceType?: string | undefined;
}
export interface AssociationExecutionTarget {
    AssociationId?: string | undefined;
    AssociationVersion?: string | undefined;
    ExecutionId?: string | undefined;
    ResourceId?: string | undefined;
    ResourceType?: string | undefined;
    Status?: string | undefined;
    DetailedStatus?: string | undefined;
    LastExecutionDate?: Date | undefined;
    OutputSource?: OutputSource | undefined;
}
export type AssociationExecutionTargetsList = AssociationExecutionTarget[];
export interface DescribeAssociationExecutionTargetsResult {
    AssociationExecutionTargets?: AssociationExecutionTarget[] | undefined;
    NextToken?: string | undefined;
}
export type AutomationExecutionFilterKey = "DocumentNamePrefix" | "ExecutionStatus" | "ExecutionId" | "ParentExecutionId" | "CurrentAction" | "StartTimeBefore" | "StartTimeAfter" | "AutomationType" | "TagKey" | "TargetResourceGroup" | "AutomationSubtype" | "OpsItemId" | (string & {});
export type AutomationExecutionFilterValue = string;
export type AutomationExecutionFilterValueList = string[];
export interface AutomationExecutionFilter {
    Key: AutomationExecutionFilterKey;
    Values: string[];
}
export type AutomationExecutionFilterList = AutomationExecutionFilter[];
export interface DescribeAutomationExecutionsRequest {
    Filters?: AutomationExecutionFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AutomationExecutionId = string;
export type AutomationExecutionStatus = "Pending" | "InProgress" | "Waiting" | "Success" | "TimedOut" | "Cancelling" | "Cancelled" | "Failed" | "PendingApproval" | "Approved" | "Rejected" | "Scheduled" | "RunbookInProgress" | "PendingChangeCalendarOverride" | "ChangeCalendarOverrideApproved" | "ChangeCalendarOverrideRejected" | "CompletedWithSuccess" | "CompletedWithFailure" | "Exited" | (string & {});
export type AutomationParameterKey = string;
export type AutomationParameterValue = string;
export type AutomationParameterValueList = string[];
export type AutomationParameterMap = {
    [key: string]: string[] | undefined;
};
export type ExecutionMode = "Auto" | "Interactive" | (string & {});
export type TargetParameterList = string[];
export interface ResolvedTargets {
    ParameterValues?: string[] | undefined;
    Truncated?: boolean | undefined;
}
export type AutomationType = "CrossAccount" | "Local" | (string & {});
export type TargetLocationsURL = string;
export type AutomationSubtype = "ChangeRequest" | "AccessRequest" | (string & {});
export interface Runbook {
    DocumentName: string;
    DocumentVersion?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    TargetParameterName?: string | undefined;
    Targets?: Target[] | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    TargetLocations?: TargetLocation[] | undefined;
}
export type Runbooks = Runbook[];
export type ChangeRequestName = string;
export interface AutomationExecutionMetadata {
    AutomationExecutionId?: string | undefined;
    DocumentName?: string | undefined;
    DocumentVersion?: string | undefined;
    AutomationExecutionStatus?: AutomationExecutionStatus | undefined;
    ExecutionStartTime?: Date | undefined;
    ExecutionEndTime?: Date | undefined;
    ExecutedBy?: string | undefined;
    LogFile?: string | undefined;
    Outputs?: {
        [key: string]: string[] | undefined;
    } | undefined;
    Mode?: ExecutionMode | undefined;
    ParentAutomationExecutionId?: string | undefined;
    CurrentStepName?: string | undefined;
    CurrentAction?: string | undefined;
    FailureMessage?: string | undefined;
    WarningMessage?: string | undefined;
    TargetParameterName?: string | undefined;
    Targets?: Target[] | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    ResolvedTargets?: ResolvedTargets | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    Target?: string | undefined;
    AutomationType?: AutomationType | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    TriggeredAlarms?: AlarmStateInformation[] | undefined;
    TargetLocationsURL?: string | undefined;
    AutomationSubtype?: AutomationSubtype | undefined;
    ScheduledTime?: Date | undefined;
    Runbooks?: Runbook[] | undefined;
    OpsItemId?: string | undefined;
    AssociationId?: string | undefined;
    ChangeRequestName?: string | undefined;
}
export type AutomationExecutionMetadataList = AutomationExecutionMetadata[];
export interface DescribeAutomationExecutionsResult {
    AutomationExecutionMetadataList?: AutomationExecutionMetadata[] | undefined;
    NextToken?: string | undefined;
}
export type StepExecutionFilterKey = "StartTimeBefore" | "StartTimeAfter" | "StepExecutionStatus" | "StepExecutionId" | "StepName" | "Action" | "ParentStepExecutionId" | "ParentStepIteration" | "ParentStepIteratorValue" | (string & {});
export type StepExecutionFilterValue = string;
export type StepExecutionFilterValueList = string[];
export interface StepExecutionFilter {
    Key: StepExecutionFilterKey;
    Values: string[];
}
export type StepExecutionFilterList = StepExecutionFilter[];
export interface DescribeAutomationStepExecutionsRequest {
    AutomationExecutionId: string;
    Filters?: StepExecutionFilter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ReverseOrder?: boolean | undefined;
}
export type AutomationActionName = string;
export type NormalStringMap = {
    [key: string]: string | undefined;
};
export interface FailureDetails {
    FailureStage?: string | undefined;
    FailureType?: string | undefined;
    Details?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type ValidNextStep = string;
export type ValidNextStepList = string[];
export interface ParentStepDetails {
    StepExecutionId?: string | undefined;
    StepName?: string | undefined;
    Action?: string | undefined;
    Iteration?: number | undefined;
    IteratorValue?: string | undefined;
}
export interface StepExecution {
    StepName?: string | undefined;
    Action?: string | undefined;
    TimeoutSeconds?: number | undefined;
    OnFailure?: string | undefined;
    MaxAttempts?: number | undefined;
    ExecutionStartTime?: Date | undefined;
    ExecutionEndTime?: Date | undefined;
    StepStatus?: AutomationExecutionStatus | undefined;
    ResponseCode?: string | undefined;
    Inputs?: {
        [key: string]: string | undefined;
    } | undefined;
    Outputs?: {
        [key: string]: string[] | undefined;
    } | undefined;
    Response?: string | undefined;
    FailureMessage?: string | undefined;
    WarningMessage?: string | undefined;
    FailureDetails?: FailureDetails | undefined;
    StepExecutionId?: string | undefined;
    OverriddenParameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    IsEnd?: boolean | undefined;
    NextStep?: string | undefined;
    IsCritical?: boolean | undefined;
    ValidNextSteps?: string[] | undefined;
    Targets?: Target[] | undefined;
    TargetLocation?: TargetLocation | undefined;
    TriggeredAlarms?: AlarmStateInformation[] | undefined;
    ParentStepDetails?: ParentStepDetails | undefined;
}
export type StepExecutionList = StepExecution[];
export interface DescribeAutomationStepExecutionsResult {
    StepExecutions?: StepExecution[] | undefined;
    NextToken?: string | undefined;
}
export type PatchOrchestratorFilterKey = string;
export type PatchOrchestratorFilterValue = string;
export type PatchOrchestratorFilterValues = string[];
export interface PatchOrchestratorFilter {
    Key?: string | undefined;
    Values?: string[] | undefined;
}
export type PatchOrchestratorFilterList = PatchOrchestratorFilter[];
export type PatchBaselineMaxResults = number;
export interface DescribeAvailablePatchesRequest {
    Filters?: PatchOrchestratorFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PatchTitle = string;
export type PatchDescription = string;
export type PatchContentUrl = string;
export type PatchVendor = string;
export type PatchProductFamily = string;
export type PatchProduct = string;
export type PatchClassification = string;
export type PatchMsrcSeverity = string;
export type PatchKbNumber = string;
export type PatchMsrcNumber = string;
export type PatchLanguage = string;
export type PatchAdvisoryId = string;
export type PatchAdvisoryIdList = string[];
export type PatchBugzillaId = string;
export type PatchBugzillaIdList = string[];
export type PatchCVEId = string;
export type PatchCVEIdList = string[];
export type PatchName = string;
export type PatchEpoch = number;
export type PatchVersion = string;
export type PatchRelease = string;
export type PatchArch = string;
export type PatchSeverity = string;
export type PatchRepository = string;
export interface Patch {
    Id?: string | undefined;
    ReleaseDate?: Date | undefined;
    Title?: string | undefined;
    Description?: string | undefined;
    ContentUrl?: string | undefined;
    Vendor?: string | undefined;
    ProductFamily?: string | undefined;
    Product?: string | undefined;
    Classification?: string | undefined;
    MsrcSeverity?: string | undefined;
    KbNumber?: string | undefined;
    MsrcNumber?: string | undefined;
    Language?: string | undefined;
    AdvisoryIds?: string[] | undefined;
    BugzillaIds?: string[] | undefined;
    CVEIds?: string[] | undefined;
    Name?: string | undefined;
    Epoch?: number | undefined;
    Version?: string | undefined;
    Release?: string | undefined;
    Arch?: string | undefined;
    Severity?: string | undefined;
    Repository?: string | undefined;
}
export type PatchList = Patch[];
export interface DescribeAvailablePatchesResult {
    Patches?: Patch[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeDocumentRequest {
    Name: string;
    DocumentVersion?: string | undefined;
    VersionName?: string | undefined;
}
export interface DescribeDocumentResult {
    Document?: DocumentDescription | undefined;
}
export type DocumentPermissionType = "Share" | (string & {});
export type DocumentPermissionMaxResults = number;
export interface DescribeDocumentPermissionRequest {
    Name: string;
    PermissionType: DocumentPermissionType;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AccountId = string;
export type AccountIdList = string[];
export type SharedDocumentVersion = string;
export interface AccountSharingInfo {
    AccountId?: string | undefined;
    SharedDocumentVersion?: string | undefined;
}
export type AccountSharingInfoList = AccountSharingInfo[];
export interface DescribeDocumentPermissionResponse {
    AccountIds?: string[] | undefined;
    AccountSharingInfoList?: AccountSharingInfo[] | undefined;
    NextToken?: string | undefined;
}
export type EffectiveInstanceAssociationMaxResults = number;
export interface DescribeEffectiveInstanceAssociationsRequest {
    InstanceId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface InstanceAssociation {
    AssociationId?: string | undefined;
    InstanceId?: string | undefined;
    Content?: string | undefined;
    AssociationVersion?: string | undefined;
}
export type InstanceAssociationList = InstanceAssociation[];
export interface DescribeEffectiveInstanceAssociationsResult {
    Associations?: InstanceAssociation[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeEffectivePatchesForPatchBaselineRequest {
    BaselineId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PatchDeploymentStatus = "APPROVED" | "PENDING_APPROVAL" | "EXPLICIT_APPROVED" | "EXPLICIT_REJECTED" | (string & {});
export interface PatchStatus {
    DeploymentStatus?: PatchDeploymentStatus | undefined;
    ComplianceLevel?: PatchComplianceLevel | undefined;
    ApprovalDate?: Date | undefined;
}
export interface EffectivePatch {
    Patch?: Patch | undefined;
    PatchStatus?: PatchStatus | undefined;
}
export type EffectivePatchList = EffectivePatch[];
export interface DescribeEffectivePatchesForPatchBaselineResult {
    EffectivePatches?: EffectivePatch[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeInstanceAssociationsStatusRequest {
    InstanceId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InstanceAssociationExecutionSummary = string;
export type AgentErrorCode = string;
export type Url = string;
export interface S3OutputUrl {
    OutputUrl?: string | undefined;
}
export interface InstanceAssociationOutputUrl {
    S3OutputUrl?: S3OutputUrl | undefined;
}
export interface InstanceAssociationStatusInfo {
    AssociationId?: string | undefined;
    Name?: string | undefined;
    DocumentVersion?: string | undefined;
    AssociationVersion?: string | undefined;
    InstanceId?: string | undefined;
    ExecutionDate?: Date | undefined;
    Status?: string | undefined;
    DetailedStatus?: string | undefined;
    ExecutionSummary?: string | undefined;
    ErrorCode?: string | undefined;
    OutputUrl?: InstanceAssociationOutputUrl | undefined;
    AssociationName?: string | undefined;
}
export type InstanceAssociationStatusInfos = InstanceAssociationStatusInfo[];
export interface DescribeInstanceAssociationsStatusResult {
    InstanceAssociationStatusInfos?: InstanceAssociationStatusInfo[] | undefined;
    NextToken?: string | undefined;
}
export type InstanceInformationFilterKey = "InstanceIds" | "AgentVersion" | "PingStatus" | "PlatformTypes" | "ActivationIds" | "IamRole" | "ResourceType" | "AssociationStatus" | (string & {});
export type InstanceInformationFilterValue = string;
export type InstanceInformationFilterValueSet = string[];
export interface InstanceInformationFilter {
    key: InstanceInformationFilterKey;
    valueSet: string[];
}
export type InstanceInformationFilterList = InstanceInformationFilter[];
export type InstanceInformationStringFilterKey = string;
export interface InstanceInformationStringFilter {
    Key: string;
    Values: string[];
}
export type InstanceInformationStringFilterList = InstanceInformationStringFilter[];
export type MaxResultsEC2Compatible = number;
export interface DescribeInstanceInformationRequest {
    InstanceInformationFilterList?: InstanceInformationFilter[] | undefined;
    Filters?: InstanceInformationStringFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PingStatus = "Online" | "ConnectionLost" | "Inactive" | (string & {});
export type Version = string;
export type ResourceType = "ManagedInstance" | "EC2Instance" | (string & {});
export type IPAddress = string | redacted.Redacted<string>;
export type ComputerName = string;
export type InstanceAssociationStatusAggregatedCount = {
    [key: string]: number | undefined;
};
export interface InstanceAggregatedAssociationOverview {
    DetailedStatus?: string | undefined;
    InstanceAssociationStatusAggregatedCount?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type SourceId = string;
export type SourceType = "AWS::EC2::Instance" | "AWS::IoT::Thing" | "AWS::SSM::ManagedInstance" | "Microsoft.Compute/virtualMachines" | "compute.googleapis.com/Instance" | (string & {});
export type SourceLocation = string;
export interface InstanceInformation {
    InstanceId?: string | undefined;
    PingStatus?: PingStatus | undefined;
    LastPingDateTime?: Date | undefined;
    AgentVersion?: string | undefined;
    IsLatestVersion?: boolean | undefined;
    PlatformType?: PlatformType | undefined;
    PlatformName?: string | undefined;
    PlatformVersion?: string | undefined;
    ActivationId?: string | undefined;
    IamRole?: string | undefined;
    RegistrationDate?: Date | undefined;
    ResourceType?: ResourceType | undefined;
    Name?: string | undefined;
    IPAddress?: string | redacted.Redacted<string> | undefined;
    ComputerName?: string | undefined;
    AssociationStatus?: string | undefined;
    LastAssociationExecutionDate?: Date | undefined;
    LastSuccessfulAssociationExecutionDate?: Date | undefined;
    AssociationOverview?: InstanceAggregatedAssociationOverview | undefined;
    SourceId?: string | undefined;
    SourceType?: SourceType | undefined;
    SourceLocation?: string | undefined;
}
export type InstanceInformationList = InstanceInformation[];
export interface DescribeInstanceInformationResult {
    InstanceInformationList?: InstanceInformation[] | undefined;
    NextToken?: string | undefined;
}
export type PatchComplianceMaxResults = number;
export interface DescribeInstancePatchesRequest {
    InstanceId: string;
    Filters?: PatchOrchestratorFilter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type PatchComplianceDataState = "INSTALLED" | "INSTALLED_OTHER" | "INSTALLED_PENDING_REBOOT" | "INSTALLED_REJECTED" | "MISSING" | "NOT_APPLICABLE" | "FAILED" | "AVAILABLE_SECURITY_UPDATE" | (string & {});
export type PatchCVEIds = string;
export interface PatchComplianceData {
    Title: string;
    KBId: string;
    Classification: string;
    Severity: string;
    State: PatchComplianceDataState;
    InstalledTime: Date;
    CVEIds?: string | undefined;
}
export type PatchComplianceDataList = PatchComplianceData[];
export interface DescribeInstancePatchesResult {
    Patches?: PatchComplianceData[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeInstancePatchStatesRequest {
    InstanceIds: string[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type SnapshotId = string;
export type InstallOverrideList = string;
export type OwnerInformation = string | redacted.Redacted<string>;
export type PatchInstalledCount = number;
export type PatchInstalledOtherCount = number;
export type PatchInstalledPendingRebootCount = number;
export type PatchInstalledRejectedCount = number;
export type PatchMissingCount = number;
export type PatchFailedCount = number;
export type PatchUnreportedNotApplicableCount = number;
export type PatchNotApplicableCount = number;
export type PatchAvailableSecurityUpdateCount = number;
export type PatchOperationType = "Scan" | "Install" | (string & {});
export type RebootOption = "RebootIfNeeded" | "NoReboot" | (string & {});
export type PatchCriticalNonCompliantCount = number;
export type PatchSecurityNonCompliantCount = number;
export type PatchOtherNonCompliantCount = number;
export interface InstancePatchState {
    InstanceId: string;
    PatchGroup: string;
    BaselineId: string;
    SnapshotId?: string | undefined;
    InstallOverrideList?: string | undefined;
    OwnerInformation?: string | redacted.Redacted<string> | undefined;
    InstalledCount?: number | undefined;
    InstalledOtherCount?: number | undefined;
    InstalledPendingRebootCount?: number | undefined;
    InstalledRejectedCount?: number | undefined;
    MissingCount?: number | undefined;
    FailedCount?: number | undefined;
    UnreportedNotApplicableCount?: number | undefined;
    NotApplicableCount?: number | undefined;
    AvailableSecurityUpdateCount?: number | undefined;
    OperationStartTime: Date;
    OperationEndTime: Date;
    Operation: PatchOperationType;
    LastNoRebootInstallOperationTime?: Date | undefined;
    RebootOption?: RebootOption | undefined;
    CriticalNonCompliantCount?: number | undefined;
    SecurityNonCompliantCount?: number | undefined;
    OtherNonCompliantCount?: number | undefined;
}
export type InstancePatchStateList = InstancePatchState[];
export interface DescribeInstancePatchStatesResult {
    InstancePatchStates?: InstancePatchState[] | undefined;
    NextToken?: string | undefined;
}
export type InstancePatchStateFilterKey = string;
export type InstancePatchStateFilterValue = string;
export type InstancePatchStateFilterValues = string[];
export type InstancePatchStateOperatorType = "Equal" | "NotEqual" | "LessThan" | "GreaterThan" | (string & {});
export interface InstancePatchStateFilter {
    Key: string;
    Values: string[];
    Type: InstancePatchStateOperatorType;
}
export type InstancePatchStateFilterList = InstancePatchStateFilter[];
export interface DescribeInstancePatchStatesForPatchGroupRequest {
    PatchGroup: string;
    Filters?: InstancePatchStateFilter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type InstancePatchStatesList = InstancePatchState[];
export interface DescribeInstancePatchStatesForPatchGroupResult {
    InstancePatchStates?: InstancePatchState[] | undefined;
    NextToken?: string | undefined;
}
export type InstancePropertyFilterKey = "InstanceIds" | "AgentVersion" | "PingStatus" | "PlatformTypes" | "DocumentName" | "ActivationIds" | "IamRole" | "ResourceType" | "AssociationStatus" | (string & {});
export type InstancePropertyFilterValue = string;
export type InstancePropertyFilterValueSet = string[];
export interface InstancePropertyFilter {
    key: InstancePropertyFilterKey;
    valueSet: string[];
}
export type InstancePropertyFilterList = InstancePropertyFilter[];
export type InstancePropertyStringFilterKey = string;
export type InstancePropertyFilterOperator = "Equal" | "NotEqual" | "BeginWith" | "LessThan" | "GreaterThan" | (string & {});
export interface InstancePropertyStringFilter {
    Key: string;
    Values: string[];
    Operator?: InstancePropertyFilterOperator | undefined;
}
export type InstancePropertyStringFilterList = InstancePropertyStringFilter[];
export type DescribeInstancePropertiesMaxResults = number;
export interface DescribeInstancePropertiesRequest {
    InstancePropertyFilterList?: InstancePropertyFilter[] | undefined;
    FiltersWithOperator?: InstancePropertyStringFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InstanceName = string;
export type InstanceType = string;
export type InstanceRole = string;
export type KeyName = string;
export type InstanceState = string;
export type Architecture = string;
export type PlatformName = string;
export type PlatformVersion = string;
export type AvailabilityZone = string;
export interface InstanceProperty {
    Name?: string | undefined;
    InstanceId?: string | undefined;
    InstanceType?: string | undefined;
    InstanceRole?: string | undefined;
    KeyName?: string | undefined;
    InstanceState?: string | undefined;
    Architecture?: string | undefined;
    IPAddress?: string | redacted.Redacted<string> | undefined;
    LaunchTime?: Date | undefined;
    PingStatus?: PingStatus | undefined;
    LastPingDateTime?: Date | undefined;
    AgentVersion?: string | undefined;
    PlatformType?: PlatformType | undefined;
    PlatformName?: string | undefined;
    PlatformVersion?: string | undefined;
    ActivationId?: string | undefined;
    IamRole?: string | undefined;
    RegistrationDate?: Date | undefined;
    ResourceType?: string | undefined;
    ComputerName?: string | undefined;
    AssociationStatus?: string | undefined;
    LastAssociationExecutionDate?: Date | undefined;
    LastSuccessfulAssociationExecutionDate?: Date | undefined;
    AssociationOverview?: InstanceAggregatedAssociationOverview | undefined;
    SourceId?: string | undefined;
    SourceType?: SourceType | undefined;
    SourceLocation?: string | undefined;
    AvailabilityZone?: string | undefined;
}
export type InstanceProperties = InstanceProperty[];
export interface DescribeInstancePropertiesResult {
    InstanceProperties?: InstanceProperty[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeInventoryDeletionsRequest {
    DeletionId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type InventoryDeletionStartTime = Date;
export type InventoryDeletionStatus = "InProgress" | "Complete" | (string & {});
export type InventoryDeletionLastStatusMessage = string;
export type InventoryDeletionLastStatusUpdateTime = Date;
export interface InventoryDeletionStatusItem {
    DeletionId?: string | undefined;
    TypeName?: string | undefined;
    DeletionStartTime?: Date | undefined;
    LastStatus?: InventoryDeletionStatus | undefined;
    LastStatusMessage?: string | undefined;
    DeletionSummary?: InventoryDeletionSummary | undefined;
    LastStatusUpdateTime?: Date | undefined;
}
export type InventoryDeletionsList = InventoryDeletionStatusItem[];
export interface DescribeInventoryDeletionsResult {
    InventoryDeletions?: InventoryDeletionStatusItem[] | undefined;
    NextToken?: string | undefined;
}
export type MaintenanceWindowFilterKey = string;
export type MaintenanceWindowFilterValue = string;
export type MaintenanceWindowFilterValues = string[];
export interface MaintenanceWindowFilter {
    Key?: string | undefined;
    Values?: string[] | undefined;
}
export type MaintenanceWindowFilterList = MaintenanceWindowFilter[];
export type MaintenanceWindowMaxResults = number;
export interface DescribeMaintenanceWindowExecutionsRequest {
    WindowId: string;
    Filters?: MaintenanceWindowFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type MaintenanceWindowExecutionStatus = "PENDING" | "IN_PROGRESS" | "SUCCESS" | "FAILED" | "TIMED_OUT" | "CANCELLING" | "CANCELLED" | "SKIPPED_OVERLAPPING" | (string & {});
export type MaintenanceWindowExecutionStatusDetails = string;
export interface MaintenanceWindowExecution {
    WindowId?: string | undefined;
    WindowExecutionId?: string | undefined;
    Status?: MaintenanceWindowExecutionStatus | undefined;
    StatusDetails?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type MaintenanceWindowExecutionList = MaintenanceWindowExecution[];
export interface DescribeMaintenanceWindowExecutionsResult {
    WindowExecutions?: MaintenanceWindowExecution[] | undefined;
    NextToken?: string | undefined;
}
export type MaintenanceWindowExecutionTaskId = string;
export interface DescribeMaintenanceWindowExecutionTaskInvocationsRequest {
    WindowExecutionId: string;
    TaskId: string;
    Filters?: MaintenanceWindowFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type MaintenanceWindowExecutionTaskInvocationId = string;
export type MaintenanceWindowExecutionTaskExecutionId = string;
export type MaintenanceWindowTaskType = "RUN_COMMAND" | "AUTOMATION" | "STEP_FUNCTIONS" | "LAMBDA" | (string & {});
export type MaintenanceWindowExecutionTaskInvocationParameters = string | redacted.Redacted<string>;
export type MaintenanceWindowTaskTargetId = string;
export interface MaintenanceWindowExecutionTaskInvocationIdentity {
    WindowExecutionId?: string | undefined;
    TaskExecutionId?: string | undefined;
    InvocationId?: string | undefined;
    ExecutionId?: string | undefined;
    TaskType?: MaintenanceWindowTaskType | undefined;
    Parameters?: string | redacted.Redacted<string> | undefined;
    Status?: MaintenanceWindowExecutionStatus | undefined;
    StatusDetails?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    OwnerInformation?: string | redacted.Redacted<string> | undefined;
    WindowTargetId?: string | undefined;
}
export type MaintenanceWindowExecutionTaskInvocationIdentityList = MaintenanceWindowExecutionTaskInvocationIdentity[];
export interface DescribeMaintenanceWindowExecutionTaskInvocationsResult {
    WindowExecutionTaskInvocationIdentities?: MaintenanceWindowExecutionTaskInvocationIdentity[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeMaintenanceWindowExecutionTasksRequest {
    WindowExecutionId: string;
    Filters?: MaintenanceWindowFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type MaintenanceWindowTaskArn = string;
export interface MaintenanceWindowExecutionTaskIdentity {
    WindowExecutionId?: string | undefined;
    TaskExecutionId?: string | undefined;
    Status?: MaintenanceWindowExecutionStatus | undefined;
    StatusDetails?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    TaskArn?: string | undefined;
    TaskType?: MaintenanceWindowTaskType | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    TriggeredAlarms?: AlarmStateInformation[] | undefined;
}
export type MaintenanceWindowExecutionTaskIdentityList = MaintenanceWindowExecutionTaskIdentity[];
export interface DescribeMaintenanceWindowExecutionTasksResult {
    WindowExecutionTaskIdentities?: MaintenanceWindowExecutionTaskIdentity[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeMaintenanceWindowsRequest {
    Filters?: MaintenanceWindowFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type MaintenanceWindowEnabled = boolean;
export interface MaintenanceWindowIdentity {
    WindowId?: string | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Enabled?: boolean | undefined;
    Duration?: number | undefined;
    Cutoff?: number | undefined;
    Schedule?: string | undefined;
    ScheduleTimezone?: string | undefined;
    ScheduleOffset?: number | undefined;
    EndDate?: string | undefined;
    StartDate?: string | undefined;
    NextExecutionTime?: string | undefined;
}
export type MaintenanceWindowIdentityList = MaintenanceWindowIdentity[];
export interface DescribeMaintenanceWindowsResult {
    WindowIdentities?: MaintenanceWindowIdentity[] | undefined;
    NextToken?: string | undefined;
}
export type MaintenanceWindowResourceType = "INSTANCE" | "RESOURCE_GROUP" | (string & {});
export type MaintenanceWindowSearchMaxResults = number;
export interface DescribeMaintenanceWindowScheduleRequest {
    WindowId?: string | undefined;
    Targets?: Target[] | undefined;
    ResourceType?: MaintenanceWindowResourceType | undefined;
    Filters?: PatchOrchestratorFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ScheduledWindowExecution {
    WindowId?: string | undefined;
    Name?: string | undefined;
    ExecutionTime?: string | undefined;
}
export type ScheduledWindowExecutionList = ScheduledWindowExecution[];
export interface DescribeMaintenanceWindowScheduleResult {
    ScheduledWindowExecutions?: ScheduledWindowExecution[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeMaintenanceWindowsForTargetRequest {
    Targets: Target[];
    ResourceType: MaintenanceWindowResourceType;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface MaintenanceWindowIdentityForTarget {
    WindowId?: string | undefined;
    Name?: string | undefined;
}
export type MaintenanceWindowsForTargetList = MaintenanceWindowIdentityForTarget[];
export interface DescribeMaintenanceWindowsForTargetResult {
    WindowIdentities?: MaintenanceWindowIdentityForTarget[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeMaintenanceWindowTargetsRequest {
    WindowId: string;
    Filters?: MaintenanceWindowFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface MaintenanceWindowTarget {
    WindowId?: string | undefined;
    WindowTargetId?: string | undefined;
    ResourceType?: MaintenanceWindowResourceType | undefined;
    Targets?: Target[] | undefined;
    OwnerInformation?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export type MaintenanceWindowTargetList = MaintenanceWindowTarget[];
export interface DescribeMaintenanceWindowTargetsResult {
    Targets?: MaintenanceWindowTarget[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeMaintenanceWindowTasksRequest {
    WindowId: string;
    Filters?: MaintenanceWindowFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type MaintenanceWindowTaskParameterName = string;
export type MaintenanceWindowTaskParameterValue = string | redacted.Redacted<string>;
export type MaintenanceWindowTaskParameterValueList = (string | redacted.Redacted<string>)[];
export interface MaintenanceWindowTaskParameterValueExpression {
    Values?: (string | redacted.Redacted<string>)[] | undefined;
}
export type MaintenanceWindowTaskParameters = {
    [key: string]: MaintenanceWindowTaskParameterValueExpression | undefined;
};
export type MaintenanceWindowTaskPriority = number;
export interface LoggingInfo {
    S3BucketName: string;
    S3KeyPrefix?: string | undefined;
    S3Region: string;
}
export type ServiceRole = string;
export type MaintenanceWindowTaskCutoffBehavior = "CONTINUE_TASK" | "CANCEL_TASK" | (string & {});
export interface MaintenanceWindowTask {
    WindowId?: string | undefined;
    WindowTaskId?: string | undefined;
    TaskArn?: string | undefined;
    Type?: MaintenanceWindowTaskType | undefined;
    Targets?: Target[] | undefined;
    TaskParameters?: {
        [key: string]: MaintenanceWindowTaskParameterValueExpression | undefined;
    } | undefined;
    Priority?: number | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    ServiceRoleArn?: string | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CutoffBehavior?: MaintenanceWindowTaskCutoffBehavior | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
}
export type MaintenanceWindowTaskList = MaintenanceWindowTask[];
export interface DescribeMaintenanceWindowTasksResult {
    Tasks?: MaintenanceWindowTask[] | undefined;
    NextToken?: string | undefined;
}
export type OpsItemFilterKey = "Status" | "CreatedBy" | "Source" | "Priority" | "Title" | "OpsItemId" | "CreatedTime" | "LastModifiedTime" | "ActualStartTime" | "ActualEndTime" | "PlannedStartTime" | "PlannedEndTime" | "OperationalData" | "OperationalDataKey" | "OperationalDataValue" | "ResourceId" | "AutomationId" | "Category" | "Severity" | "OpsItemType" | "AccessRequestByRequesterArn" | "AccessRequestByRequesterId" | "AccessRequestByApproverArn" | "AccessRequestByApproverId" | "AccessRequestBySourceAccountId" | "AccessRequestBySourceOpsItemId" | "AccessRequestBySourceRegion" | "AccessRequestByIsReplica" | "AccessRequestByTargetResourceId" | "ChangeRequestByRequesterArn" | "ChangeRequestByRequesterName" | "ChangeRequestByApproverArn" | "ChangeRequestByApproverName" | "ChangeRequestByTemplate" | "ChangeRequestByTargetsResourceGroup" | "InsightByType" | "AccountId" | (string & {});
export type OpsItemFilterValue = string;
export type OpsItemFilterValues = string[];
export type OpsItemFilterOperator = "Equal" | "Contains" | "GreaterThan" | "LessThan" | (string & {});
export interface OpsItemFilter {
    Key: OpsItemFilterKey;
    Values: string[];
    Operator: OpsItemFilterOperator;
}
export type OpsItemFilters = OpsItemFilter[];
export type OpsItemMaxResults = number;
export interface DescribeOpsItemsRequest {
    OpsItemFilters?: OpsItemFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type OpsItemStatus = "Open" | "InProgress" | "Resolved" | "Pending" | "TimedOut" | "Cancelling" | "Cancelled" | "Failed" | "CompletedWithSuccess" | "CompletedWithFailure" | "Scheduled" | "RunbookInProgress" | "PendingChangeCalendarOverride" | "ChangeCalendarOverrideApproved" | "ChangeCalendarOverrideRejected" | "PendingApproval" | "Approved" | "Revoked" | "Rejected" | "Closed" | (string & {});
export interface OpsItemSummary {
    CreatedBy?: string | undefined;
    CreatedTime?: Date | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedTime?: Date | undefined;
    Priority?: number | undefined;
    Source?: string | undefined;
    Status?: OpsItemStatus | undefined;
    OpsItemId?: string | undefined;
    Title?: string | undefined;
    OperationalData?: {
        [key: string]: OpsItemDataValue | undefined;
    } | undefined;
    Category?: string | undefined;
    Severity?: string | undefined;
    OpsItemType?: string | undefined;
    ActualStartTime?: Date | undefined;
    ActualEndTime?: Date | undefined;
    PlannedStartTime?: Date | undefined;
    PlannedEndTime?: Date | undefined;
}
export type OpsItemSummaries = OpsItemSummary[];
export interface DescribeOpsItemsResponse {
    NextToken?: string | undefined;
    OpsItemSummaries?: OpsItemSummary[] | undefined;
}
export type ParametersFilterKey = "Name" | "Type" | "KeyId" | (string & {});
export type ParametersFilterValue = string;
export type ParametersFilterValueList = string[];
export interface ParametersFilter {
    Key: ParametersFilterKey;
    Values: string[];
}
export type ParametersFilterList = ParametersFilter[];
export type ParameterStringFilterKey = string;
export type ParameterStringQueryOption = string;
export type ParameterStringFilterValue = string;
export type ParameterStringFilterValueList = string[];
export interface ParameterStringFilter {
    Key: string;
    Option?: string | undefined;
    Values?: string[] | undefined;
}
export type ParameterStringFilterList = ParameterStringFilter[];
export interface DescribeParametersRequest {
    Filters?: ParametersFilter[] | undefined;
    ParameterFilters?: ParameterStringFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Shared?: boolean | undefined;
}
export type ParameterType = "String" | "StringList" | "SecureString" | (string & {});
export type ParameterKeyId = string;
export type ParameterDescription = string;
export type AllowedPattern = string;
export type PSParameterVersion = number;
export type ParameterTier = "Standard" | "Advanced" | "Intelligent-Tiering" | (string & {});
export interface ParameterInlinePolicy {
    PolicyText?: string | undefined;
    PolicyType?: string | undefined;
    PolicyStatus?: string | undefined;
}
export type ParameterPolicyList = ParameterInlinePolicy[];
export type ParameterDataType = string;
export interface ParameterMetadata {
    Name?: string | undefined;
    ARN?: string | undefined;
    Type?: ParameterType | undefined;
    KeyId?: string | undefined;
    LastModifiedDate?: Date | undefined;
    LastModifiedUser?: string | undefined;
    Description?: string | undefined;
    AllowedPattern?: string | undefined;
    Version?: number | undefined;
    Tier?: ParameterTier | undefined;
    Policies?: ParameterInlinePolicy[] | undefined;
    DataType?: string | undefined;
}
export type ParameterMetadataList = ParameterMetadata[];
export interface DescribeParametersResult {
    Parameters?: ParameterMetadata[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribePatchBaselinesRequest {
    Filters?: PatchOrchestratorFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DefaultBaseline = boolean;
export interface PatchBaselineIdentity {
    BaselineId?: string | undefined;
    BaselineName?: string | undefined;
    OperatingSystem?: OperatingSystem | undefined;
    BaselineDescription?: string | undefined;
    DefaultBaseline?: boolean | undefined;
}
export type PatchBaselineIdentityList = PatchBaselineIdentity[];
export interface DescribePatchBaselinesResult {
    BaselineIdentities?: PatchBaselineIdentity[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribePatchGroupsRequest {
    MaxResults?: number | undefined;
    Filters?: PatchOrchestratorFilter[] | undefined;
    NextToken?: string | undefined;
}
export interface PatchGroupPatchBaselineMapping {
    PatchGroup?: string | undefined;
    BaselineIdentity?: PatchBaselineIdentity | undefined;
}
export type PatchGroupPatchBaselineMappingList = PatchGroupPatchBaselineMapping[];
export interface DescribePatchGroupsResult {
    Mappings?: PatchGroupPatchBaselineMapping[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribePatchGroupStateRequest {
    PatchGroup: string;
}
export type InstancesCount = number;
export interface DescribePatchGroupStateResult {
    Instances?: number | undefined;
    InstancesWithInstalledPatches?: number | undefined;
    InstancesWithInstalledOtherPatches?: number | undefined;
    InstancesWithInstalledPendingRebootPatches?: number | undefined;
    InstancesWithInstalledRejectedPatches?: number | undefined;
    InstancesWithMissingPatches?: number | undefined;
    InstancesWithFailedPatches?: number | undefined;
    InstancesWithNotApplicablePatches?: number | undefined;
    InstancesWithUnreportedNotApplicablePatches?: number | undefined;
    InstancesWithCriticalNonCompliantPatches?: number | undefined;
    InstancesWithSecurityNonCompliantPatches?: number | undefined;
    InstancesWithOtherNonCompliantPatches?: number | undefined;
    InstancesWithAvailableSecurityUpdates?: number | undefined;
}
export type PatchProperty = "PRODUCT" | "PRODUCT_FAMILY" | "CLASSIFICATION" | "MSRC_SEVERITY" | "PRIORITY" | "SEVERITY" | (string & {});
export type PatchSet = "OS" | "APPLICATION" | (string & {});
export interface DescribePatchPropertiesRequest {
    OperatingSystem: OperatingSystem;
    Property: PatchProperty;
    PatchSet?: PatchSet | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AttributeName = string;
export type AttributeValue = string;
export type PatchPropertyEntry = {
    [key: string]: string | undefined;
};
export type PatchPropertiesList = {
    [key: string]: string | undefined;
}[];
export interface DescribePatchPropertiesResult {
    Properties?: {
        [key: string]: string | undefined;
    }[] | undefined;
    NextToken?: string | undefined;
}
export type SessionState = "Active" | "History" | (string & {});
export type SessionMaxResults = number;
export type SessionFilterKey = "InvokedAfter" | "InvokedBefore" | "Target" | "Owner" | "Status" | "SessionId" | "AccessType" | (string & {});
export type SessionFilterValue = string;
export interface SessionFilter {
    key: SessionFilterKey;
    value: string;
}
export type SessionFilterList = SessionFilter[];
export interface DescribeSessionsRequest {
    State: SessionState;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: SessionFilter[] | undefined;
}
export type SessionId = string;
export type SessionTarget = string;
export type SessionStatus = "Connected" | "Connecting" | "Disconnected" | "Terminated" | "Terminating" | "Failed" | (string & {});
export type SessionOwner = string;
export type SessionReason = string;
export type SessionDetails = string;
export type SessionManagerS3OutputUrl = string;
export type SessionManagerCloudWatchOutputUrl = string;
export interface SessionManagerOutputUrl {
    S3OutputUrl?: string | undefined;
    CloudWatchOutputUrl?: string | undefined;
}
export type MaxSessionDuration = string;
export type AccessType = "Standard" | "JustInTime" | (string & {});
export interface Session {
    SessionId?: string | undefined;
    Target?: string | undefined;
    Status?: SessionStatus | undefined;
    StartDate?: Date | undefined;
    EndDate?: Date | undefined;
    DocumentName?: string | undefined;
    Owner?: string | undefined;
    Reason?: string | undefined;
    Details?: string | undefined;
    OutputUrl?: SessionManagerOutputUrl | undefined;
    MaxSessionDuration?: string | undefined;
    AccessType?: AccessType | undefined;
}
export type SessionList = Session[];
export interface DescribeSessionsResponse {
    Sessions?: Session[] | undefined;
    NextToken?: string | undefined;
}
export interface DisassociateOpsItemRelatedItemRequest {
    OpsItemId: string;
    AssociationId: string;
}
export interface DisassociateOpsItemRelatedItemResponse {
}
export type AccessRequestId = string;
export interface GetAccessTokenRequest {
    AccessRequestId: string;
}
export type AccessKeyIdType = string;
export type AccessKeySecretType = string | redacted.Redacted<string>;
export type SessionTokenType = string | redacted.Redacted<string>;
export interface Credentials {
    AccessKeyId: string;
    SecretAccessKey: string | redacted.Redacted<string>;
    SessionToken: string | redacted.Redacted<string>;
    ExpirationTime: Date;
}
export type AccessRequestStatus = "Approved" | "Rejected" | "Revoked" | "Expired" | "Pending" | (string & {});
export interface GetAccessTokenResponse {
    Credentials?: Credentials | undefined;
    AccessRequestStatus?: AccessRequestStatus | undefined;
}
export interface GetAutomationExecutionRequest {
    AutomationExecutionId: string;
}
export interface ProgressCounters {
    TotalSteps?: number | undefined;
    SuccessSteps?: number | undefined;
    FailedSteps?: number | undefined;
    CancelledSteps?: number | undefined;
    TimedOutSteps?: number | undefined;
}
export interface TargetsSummary {
    TotalCount?: number | undefined;
    StartedCount?: number | undefined;
    CompletedCount?: number | undefined;
    SuccessfulCount?: number | undefined;
    FailedCount?: number | undefined;
}
export interface AutomationExecution {
    AutomationExecutionId?: string | undefined;
    DocumentName?: string | undefined;
    DocumentVersion?: string | undefined;
    ExecutionStartTime?: Date | undefined;
    ExecutionEndTime?: Date | undefined;
    AutomationExecutionStatus?: AutomationExecutionStatus | undefined;
    StepExecutions?: StepExecution[] | undefined;
    StepExecutionsTruncated?: boolean | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    Outputs?: {
        [key: string]: string[] | undefined;
    } | undefined;
    FailureMessage?: string | undefined;
    WarningMessage?: string | undefined;
    Mode?: ExecutionMode | undefined;
    ParentAutomationExecutionId?: string | undefined;
    ExecutedBy?: string | undefined;
    CurrentStepName?: string | undefined;
    CurrentAction?: string | undefined;
    TargetParameterName?: string | undefined;
    Targets?: Target[] | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    ResolvedTargets?: ResolvedTargets | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    Target?: string | undefined;
    TargetLocations?: TargetLocation[] | undefined;
    ProgressCounters?: ProgressCounters | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    TriggeredAlarms?: AlarmStateInformation[] | undefined;
    TargetLocationsURL?: string | undefined;
    AutomationSubtype?: AutomationSubtype | undefined;
    ScheduledTime?: Date | undefined;
    Runbooks?: Runbook[] | undefined;
    OpsItemId?: string | undefined;
    AssociationId?: string | undefined;
    ChangeRequestName?: string | undefined;
    Variables?: {
        [key: string]: string[] | undefined;
    } | undefined;
    TargetsSummary?: TargetsSummary | undefined;
}
export interface GetAutomationExecutionResult {
    AutomationExecution?: AutomationExecution | undefined;
}
export type ISO8601String = string;
export interface GetCalendarStateRequest {
    CalendarNames: string[];
    AtTime?: string | undefined;
}
export type CalendarState = "OPEN" | "CLOSED" | (string & {});
export interface GetCalendarStateResponse {
    State?: CalendarState | undefined;
    AtTime?: string | undefined;
    NextTransitionTime?: string | undefined;
}
export interface GetCloudConnectorRequest {
    CloudConnectorId: string;
}
export type CloudConnectorArn = string;
export interface GetCloudConnectorResult {
    CloudConnectorArn?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    Configuration?: CloudConnectorConfiguration | undefined;
    ConfigConnectorArn?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type CommandPluginName = string;
export interface GetCommandInvocationRequest {
    CommandId: string;
    InstanceId: string;
    PluginName?: string | undefined;
}
export type Comment = string;
export type ResponseCode = number;
export type StringDateTime = string;
export type CommandInvocationStatus = "Pending" | "InProgress" | "Delayed" | "Success" | "Cancelled" | "TimedOut" | "Failed" | "Cancelling" | (string & {});
export type StatusDetails = string;
export type StandardOutputContent = string;
export type StandardErrorContent = string;
export type CloudWatchLogGroupName = string;
export type CloudWatchOutputEnabled = boolean;
export interface CloudWatchOutputConfig {
    CloudWatchLogGroupName?: string | undefined;
    CloudWatchOutputEnabled?: boolean | undefined;
}
export interface GetCommandInvocationResult {
    CommandId?: string | undefined;
    InstanceId?: string | undefined;
    Comment?: string | undefined;
    DocumentName?: string | undefined;
    DocumentVersion?: string | undefined;
    PluginName?: string | undefined;
    ResponseCode?: number | undefined;
    ExecutionStartDateTime?: string | undefined;
    ExecutionElapsedTime?: string | undefined;
    ExecutionEndDateTime?: string | undefined;
    Status?: CommandInvocationStatus | undefined;
    StatusDetails?: string | undefined;
    StandardOutputContent?: string | undefined;
    StandardOutputUrl?: string | undefined;
    StandardErrorContent?: string | undefined;
    StandardErrorUrl?: string | undefined;
    CloudWatchOutputConfig?: CloudWatchOutputConfig | undefined;
}
export interface GetConnectionStatusRequest {
    Target: string;
}
export type ConnectionStatus = "connected" | "notconnected" | (string & {});
export interface GetConnectionStatusResponse {
    Target?: string | undefined;
    Status?: ConnectionStatus | undefined;
}
export interface GetDefaultPatchBaselineRequest {
    OperatingSystem?: OperatingSystem | undefined;
}
export interface GetDefaultPatchBaselineResult {
    BaselineId?: string | undefined;
    OperatingSystem?: OperatingSystem | undefined;
}
export interface BaselineOverride {
    OperatingSystem?: OperatingSystem | undefined;
    GlobalFilters?: PatchFilterGroup | undefined;
    ApprovalRules?: PatchRuleGroup | undefined;
    ApprovedPatches?: string[] | undefined;
    ApprovedPatchesComplianceLevel?: PatchComplianceLevel | undefined;
    RejectedPatches?: string[] | undefined;
    RejectedPatchesAction?: PatchAction | undefined;
    ApprovedPatchesEnableNonSecurity?: boolean | undefined;
    Sources?: PatchSource[] | undefined;
    AvailableSecurityUpdatesComplianceStatus?: PatchComplianceStatus | undefined;
}
export interface GetDeployablePatchSnapshotForInstanceRequest {
    InstanceId: string;
    SnapshotId: string;
    BaselineOverride?: BaselineOverride | undefined;
    UseS3DualStackEndpoint?: boolean | undefined;
}
export type SnapshotDownloadUrl = string;
export type Product = string;
export interface GetDeployablePatchSnapshotForInstanceResult {
    InstanceId?: string | undefined;
    SnapshotId?: string | undefined;
    SnapshotDownloadUrl?: string | undefined;
    Product?: string | undefined;
}
export interface GetDocumentRequest {
    Name: string;
    VersionName?: string | undefined;
    DocumentVersion?: string | undefined;
    DocumentFormat?: DocumentFormat | undefined;
}
export type ContentLength = number;
export type AttachmentHash = string;
export type AttachmentHashType = "Sha256" | (string & {});
export type AttachmentUrl = string;
export interface AttachmentContent {
    Name?: string | undefined;
    Size?: number | undefined;
    Hash?: string | undefined;
    HashType?: AttachmentHashType | undefined;
    Url?: string | undefined;
}
export type AttachmentContentList = AttachmentContent[];
export interface GetDocumentResult {
    Name?: string | undefined;
    CreatedDate?: Date | undefined;
    DisplayName?: string | undefined;
    VersionName?: string | undefined;
    DocumentVersion?: string | undefined;
    Status?: DocumentStatus | undefined;
    StatusInformation?: string | undefined;
    Content?: string | undefined;
    DocumentType?: DocumentType | undefined;
    DocumentFormat?: DocumentFormat | undefined;
    Requires?: DocumentRequires[] | undefined;
    AttachmentsContent?: AttachmentContent[] | undefined;
    ReviewStatus?: ReviewStatus | undefined;
}
export type ExecutionPreviewId = string;
export interface GetExecutionPreviewRequest {
    ExecutionPreviewId: string;
}
export type ExecutionPreviewStatus = "Pending" | "InProgress" | "Success" | "Failed" | (string & {});
export type ImpactType = "Mutating" | "NonMutating" | "Undetermined" | (string & {});
export type StepPreviewMap = {
    [key in ImpactType]?: number | undefined;
};
export type RegionList = string[];
export interface TargetPreview {
    Count?: number | undefined;
    TargetType?: string | undefined;
}
export type TargetPreviewList = TargetPreview[];
export interface AutomationExecutionPreview {
    StepPreviews?: {
        [key: string]: number | undefined;
    } | undefined;
    Regions?: string[] | undefined;
    TargetPreviews?: TargetPreview[] | undefined;
    TotalAccounts?: number | undefined;
}
export type ExecutionPreview = {
    Automation: AutomationExecutionPreview;
};
export interface GetExecutionPreviewResponse {
    ExecutionPreviewId?: string | undefined;
    EndedAt?: Date | undefined;
    Status?: ExecutionPreviewStatus | undefined;
    StatusMessage?: string | undefined;
    ExecutionPreview?: ExecutionPreview | undefined;
}
export type InventoryFilterKey = string;
export type InventoryFilterValue = string;
export type InventoryFilterValueList = string[];
export type InventoryQueryOperatorType = "Equal" | "NotEqual" | "BeginWith" | "LessThan" | "GreaterThan" | "Exists" | (string & {});
export interface InventoryFilter {
    Key: string;
    Values: string[];
    Type?: InventoryQueryOperatorType | undefined;
}
export type InventoryFilterList = InventoryFilter[];
export type InventoryAggregatorExpression = string;
export type InventoryGroupName = string;
export interface InventoryGroup {
    Name: string;
    Filters: InventoryFilter[];
}
export type InventoryGroupList = InventoryGroup[];
export interface InventoryAggregator {
    Expression?: string | undefined;
    Aggregators?: InventoryAggregator[] | undefined;
    Groups?: InventoryGroup[] | undefined;
}
export type InventoryAggregatorList = InventoryAggregator[];
export interface ResultAttribute {
    TypeName: string;
}
export type ResultAttributeList = ResultAttribute[];
export interface GetInventoryRequest {
    Filters?: InventoryFilter[] | undefined;
    Aggregators?: InventoryAggregator[] | undefined;
    ResultAttributes?: ResultAttribute[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type InventoryResultEntityId = string;
export type InventoryResultItemKey = string;
export type InventoryItemCaptureTime = string;
export type InventoryItemContentHash = string;
export type InventoryItemEntry = {
    [key: string]: string | undefined;
};
export type InventoryItemEntryList = {
    [key: string]: string | undefined;
}[];
export interface InventoryResultItem {
    TypeName: string;
    SchemaVersion: string;
    CaptureTime?: string | undefined;
    ContentHash?: string | undefined;
    Content: {
        [key: string]: string | undefined;
    }[];
}
export type InventoryResultItemMap = {
    [key: string]: InventoryResultItem | undefined;
};
export interface InventoryResultEntity {
    Id?: string | undefined;
    Data?: {
        [key: string]: InventoryResultItem | undefined;
    } | undefined;
}
export type InventoryResultEntityList = InventoryResultEntity[];
export interface GetInventoryResult {
    Entities?: InventoryResultEntity[] | undefined;
    NextToken?: string | undefined;
}
export type InventoryItemTypeNameFilter = string;
export type GetInventorySchemaMaxResults = number;
export type AggregatorSchemaOnly = boolean;
export type IsSubTypeSchema = boolean;
export interface GetInventorySchemaRequest {
    TypeName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Aggregator?: boolean | undefined;
    SubType?: boolean | undefined;
}
export type InventoryItemAttributeName = string;
export type InventoryAttributeDataType = "string" | "number" | (string & {});
export interface InventoryItemAttribute {
    Name: string;
    DataType: InventoryAttributeDataType;
}
export type InventoryItemAttributeList = InventoryItemAttribute[];
export type InventoryTypeDisplayName = string;
export interface InventoryItemSchema {
    TypeName: string;
    Version?: string | undefined;
    Attributes: InventoryItemAttribute[];
    DisplayName?: string | undefined;
}
export type InventoryItemSchemaResultList = InventoryItemSchema[];
export interface GetInventorySchemaResult {
    Schemas?: InventoryItemSchema[] | undefined;
    NextToken?: string | undefined;
}
export interface GetMaintenanceWindowRequest {
    WindowId: string;
}
export interface GetMaintenanceWindowResult {
    WindowId?: string | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    StartDate?: string | undefined;
    EndDate?: string | undefined;
    Schedule?: string | undefined;
    ScheduleTimezone?: string | undefined;
    ScheduleOffset?: number | undefined;
    NextExecutionTime?: string | undefined;
    Duration?: number | undefined;
    Cutoff?: number | undefined;
    AllowUnassociatedTargets?: boolean | undefined;
    Enabled?: boolean | undefined;
    CreatedDate?: Date | undefined;
    ModifiedDate?: Date | undefined;
}
export interface GetMaintenanceWindowExecutionRequest {
    WindowExecutionId: string;
}
export type MaintenanceWindowExecutionTaskIdList = string[];
export interface GetMaintenanceWindowExecutionResult {
    WindowExecutionId?: string | undefined;
    TaskIds?: string[] | undefined;
    Status?: MaintenanceWindowExecutionStatus | undefined;
    StatusDetails?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export interface GetMaintenanceWindowExecutionTaskRequest {
    WindowExecutionId: string;
    TaskId: string;
}
export type MaintenanceWindowTaskParametersList = {
    [key: string]: MaintenanceWindowTaskParameterValueExpression | undefined;
}[];
export interface GetMaintenanceWindowExecutionTaskResult {
    WindowExecutionId?: string | undefined;
    TaskExecutionId?: string | undefined;
    TaskArn?: string | undefined;
    ServiceRole?: string | undefined;
    Type?: MaintenanceWindowTaskType | undefined;
    TaskParameters?: {
        [key: string]: MaintenanceWindowTaskParameterValueExpression | undefined;
    }[] | undefined;
    Priority?: number | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    Status?: MaintenanceWindowExecutionStatus | undefined;
    StatusDetails?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    TriggeredAlarms?: AlarmStateInformation[] | undefined;
}
export interface GetMaintenanceWindowExecutionTaskInvocationRequest {
    WindowExecutionId: string;
    TaskId: string;
    InvocationId: string;
}
export interface GetMaintenanceWindowExecutionTaskInvocationResult {
    WindowExecutionId?: string | undefined;
    TaskExecutionId?: string | undefined;
    InvocationId?: string | undefined;
    ExecutionId?: string | undefined;
    TaskType?: MaintenanceWindowTaskType | undefined;
    Parameters?: string | redacted.Redacted<string> | undefined;
    Status?: MaintenanceWindowExecutionStatus | undefined;
    StatusDetails?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    OwnerInformation?: string | redacted.Redacted<string> | undefined;
    WindowTargetId?: string | undefined;
}
export interface GetMaintenanceWindowTaskRequest {
    WindowId: string;
    WindowTaskId: string;
}
export type NotificationArn = string;
export type NotificationEvent = "All" | "InProgress" | "Success" | "TimedOut" | "Cancelled" | "Failed" | (string & {});
export type NotificationEventList = NotificationEvent[];
export type NotificationType = "Command" | "Invocation" | (string & {});
export interface NotificationConfig {
    NotificationArn?: string | undefined;
    NotificationEvents?: NotificationEvent[] | undefined;
    NotificationType?: NotificationType | undefined;
}
export type TimeoutSeconds = number;
export interface MaintenanceWindowRunCommandParameters {
    Comment?: string | undefined;
    CloudWatchOutputConfig?: CloudWatchOutputConfig | undefined;
    DocumentHash?: string | undefined;
    DocumentHashType?: DocumentHashType | undefined;
    DocumentVersion?: string | undefined;
    NotificationConfig?: NotificationConfig | undefined;
    OutputS3BucketName?: string | undefined;
    OutputS3KeyPrefix?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ServiceRoleArn?: string | undefined;
    TimeoutSeconds?: number | undefined;
}
export interface MaintenanceWindowAutomationParameters {
    DocumentVersion?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type MaintenanceWindowStepFunctionsInput = string | redacted.Redacted<string>;
export type MaintenanceWindowStepFunctionsName = string;
export interface MaintenanceWindowStepFunctionsParameters {
    Input?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
}
export type MaintenanceWindowLambdaClientContext = string;
export type MaintenanceWindowLambdaQualifier = string;
export type MaintenanceWindowLambdaPayload = Uint8Array | redacted.Redacted<Uint8Array>;
export interface MaintenanceWindowLambdaParameters {
    ClientContext?: string | undefined;
    Qualifier?: string | undefined;
    Payload?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export interface MaintenanceWindowTaskInvocationParameters {
    RunCommand?: MaintenanceWindowRunCommandParameters | undefined;
    Automation?: MaintenanceWindowAutomationParameters | undefined;
    StepFunctions?: MaintenanceWindowStepFunctionsParameters | undefined;
    Lambda?: MaintenanceWindowLambdaParameters | undefined;
}
export interface GetMaintenanceWindowTaskResult {
    WindowId?: string | undefined;
    WindowTaskId?: string | undefined;
    Targets?: Target[] | undefined;
    TaskArn?: string | undefined;
    ServiceRoleArn?: string | undefined;
    TaskType?: MaintenanceWindowTaskType | undefined;
    TaskParameters?: {
        [key: string]: MaintenanceWindowTaskParameterValueExpression | undefined;
    } | undefined;
    TaskInvocationParameters?: MaintenanceWindowTaskInvocationParameters | undefined;
    Priority?: number | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CutoffBehavior?: MaintenanceWindowTaskCutoffBehavior | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
}
export interface GetOpsItemRequest {
    OpsItemId: string;
    OpsItemArn?: string | undefined;
}
export interface OpsItem {
    CreatedBy?: string | undefined;
    OpsItemType?: string | undefined;
    CreatedTime?: Date | undefined;
    Description?: string | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedTime?: Date | undefined;
    Notifications?: OpsItemNotification[] | undefined;
    Priority?: number | undefined;
    RelatedOpsItems?: RelatedOpsItem[] | undefined;
    Status?: OpsItemStatus | undefined;
    OpsItemId?: string | undefined;
    Version?: string | undefined;
    Title?: string | undefined;
    Source?: string | undefined;
    OperationalData?: {
        [key: string]: OpsItemDataValue | undefined;
    } | undefined;
    Category?: string | undefined;
    Severity?: string | undefined;
    ActualStartTime?: Date | undefined;
    ActualEndTime?: Date | undefined;
    PlannedStartTime?: Date | undefined;
    PlannedEndTime?: Date | undefined;
    OpsItemArn?: string | undefined;
}
export interface GetOpsItemResponse {
    OpsItem?: OpsItem | undefined;
}
export type GetOpsMetadataMaxResults = number;
export interface GetOpsMetadataRequest {
    OpsMetadataArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface GetOpsMetadataResult {
    ResourceId?: string | undefined;
    Metadata?: {
        [key: string]: MetadataValue | undefined;
    } | undefined;
    NextToken?: string | undefined;
}
export type OpsFilterKey = string;
export type OpsFilterValue = string;
export type OpsFilterValueList = string[];
export type OpsFilterOperatorType = "Equal" | "NotEqual" | "BeginWith" | "LessThan" | "GreaterThan" | "Exists" | (string & {});
export interface OpsFilter {
    Key: string;
    Values: string[];
    Type?: OpsFilterOperatorType | undefined;
}
export type OpsFilterList = OpsFilter[];
export type OpsAggregatorType = string;
export type OpsDataTypeName = string;
export type OpsDataAttributeName = string;
export type OpsAggregatorValueKey = string;
export type OpsAggregatorValue = string;
export type OpsAggregatorValueMap = {
    [key: string]: string | undefined;
};
export interface OpsAggregator {
    AggregatorType?: string | undefined;
    TypeName?: string | undefined;
    AttributeName?: string | undefined;
    Values?: {
        [key: string]: string | undefined;
    } | undefined;
    Filters?: OpsFilter[] | undefined;
    Aggregators?: OpsAggregator[] | undefined;
}
export type OpsAggregatorList = OpsAggregator[];
export interface OpsResultAttribute {
    TypeName: string;
}
export type OpsResultAttributeList = OpsResultAttribute[];
export interface GetOpsSummaryRequest {
    SyncName?: string | undefined;
    Filters?: OpsFilter[] | undefined;
    Aggregators?: OpsAggregator[] | undefined;
    ResultAttributes?: OpsResultAttribute[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type OpsEntityId = string;
export type OpsEntityItemKey = string;
export type OpsEntityItemCaptureTime = string;
export type OpsEntityItemEntry = {
    [key: string]: string | undefined;
};
export type OpsEntityItemEntryList = {
    [key: string]: string | undefined;
}[];
export interface OpsEntityItem {
    CaptureTime?: string | undefined;
    Content?: {
        [key: string]: string | undefined;
    }[] | undefined;
}
export type OpsEntityItemMap = {
    [key: string]: OpsEntityItem | undefined;
};
export interface OpsEntity {
    Id?: string | undefined;
    Data?: {
        [key: string]: OpsEntityItem | undefined;
    } | undefined;
}
export type OpsEntityList = OpsEntity[];
export interface GetOpsSummaryResult {
    Entities?: OpsEntity[] | undefined;
    NextToken?: string | undefined;
}
export interface GetParameterRequest {
    Name: string;
    WithDecryption?: boolean | undefined;
}
export type PSParameterValue = string | redacted.Redacted<string>;
export type PSParameterSelector = string;
export interface Parameter {
    Name?: string | undefined;
    Type?: ParameterType | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
    Version?: number | undefined;
    Selector?: string | undefined;
    SourceResult?: string | undefined;
    LastModifiedDate?: Date | undefined;
    ARN?: string | undefined;
    DataType?: string | undefined;
}
export interface GetParameterResult {
    Parameter?: Parameter | undefined;
}
export interface GetParameterHistoryRequest {
    Name: string;
    WithDecryption?: boolean | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ParameterLabel = string;
export type ParameterLabelList = string[];
export interface ParameterHistory {
    Name?: string | undefined;
    Type?: ParameterType | undefined;
    KeyId?: string | undefined;
    LastModifiedDate?: Date | undefined;
    LastModifiedUser?: string | undefined;
    Description?: string | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
    AllowedPattern?: string | undefined;
    Version?: number | undefined;
    Labels?: string[] | undefined;
    Tier?: ParameterTier | undefined;
    Policies?: ParameterInlinePolicy[] | undefined;
    DataType?: string | undefined;
}
export type ParameterHistoryList = ParameterHistory[];
export interface GetParameterHistoryResult {
    Parameters?: ParameterHistory[] | undefined;
    NextToken?: string | undefined;
}
export interface GetParametersRequest {
    Names: string[];
    WithDecryption?: boolean | undefined;
}
export type ParameterList = Parameter[];
export interface GetParametersResult {
    Parameters?: Parameter[] | undefined;
    InvalidParameters?: string[] | undefined;
}
export type GetParametersByPathMaxResults = number;
export interface GetParametersByPathRequest {
    Path: string;
    Recursive?: boolean | undefined;
    ParameterFilters?: ParameterStringFilter[] | undefined;
    WithDecryption?: boolean | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface GetParametersByPathResult {
    Parameters?: Parameter[] | undefined;
    NextToken?: string | undefined;
}
export interface GetPatchBaselineRequest {
    BaselineId: string;
}
export type PatchGroupList = string[];
export interface GetPatchBaselineResult {
    BaselineId?: string | undefined;
    Name?: string | undefined;
    OperatingSystem?: OperatingSystem | undefined;
    GlobalFilters?: PatchFilterGroup | undefined;
    ApprovalRules?: PatchRuleGroup | undefined;
    ApprovedPatches?: string[] | undefined;
    ApprovedPatchesComplianceLevel?: PatchComplianceLevel | undefined;
    ApprovedPatchesEnableNonSecurity?: boolean | undefined;
    RejectedPatches?: string[] | undefined;
    RejectedPatchesAction?: PatchAction | undefined;
    PatchGroups?: string[] | undefined;
    CreatedDate?: Date | undefined;
    ModifiedDate?: Date | undefined;
    Description?: string | undefined;
    Sources?: PatchSource[] | undefined;
    AvailableSecurityUpdatesComplianceStatus?: PatchComplianceStatus | undefined;
}
export interface GetPatchBaselineForPatchGroupRequest {
    PatchGroup: string;
    OperatingSystem?: OperatingSystem | undefined;
}
export interface GetPatchBaselineForPatchGroupResult {
    BaselineId?: string | undefined;
    PatchGroup?: string | undefined;
    OperatingSystem?: OperatingSystem | undefined;
}
export type ResourcePolicyMaxResults = number;
export interface GetResourcePoliciesRequest {
    ResourceArn: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Policy = string;
export interface GetResourcePoliciesResponseEntry {
    PolicyId?: string | undefined;
    PolicyHash?: string | undefined;
    Policy?: string | undefined;
}
export type GetResourcePoliciesResponseEntries = GetResourcePoliciesResponseEntry[];
export interface GetResourcePoliciesResponse {
    NextToken?: string | undefined;
    Policies?: GetResourcePoliciesResponseEntry[] | undefined;
}
export type ServiceSettingId = string;
export interface GetServiceSettingRequest {
    SettingId: string;
}
export type ServiceSettingValue = string;
export interface ServiceSetting {
    SettingId?: string | undefined;
    SettingValue?: string | undefined;
    LastModifiedDate?: Date | undefined;
    LastModifiedUser?: string | undefined;
    ARN?: string | undefined;
    Status?: string | undefined;
}
export interface GetServiceSettingResult {
    ServiceSetting?: ServiceSetting | undefined;
}
export interface LabelParameterVersionRequest {
    Name: string;
    ParameterVersion?: number | undefined;
    Labels: string[];
}
export interface LabelParameterVersionResult {
    InvalidLabels?: string[] | undefined;
    ParameterVersion?: number | undefined;
}
export type AssociationFilterKey = "InstanceId" | "Name" | "AssociationId" | "AssociationStatusName" | "LastExecutedBefore" | "LastExecutedAfter" | "AssociationName" | "ResourceGroupName" | "CloudConnectorId" | (string & {});
export type AssociationFilterValue = string;
export interface AssociationFilter {
    key: AssociationFilterKey;
    value: string;
}
export type AssociationFilterList = AssociationFilter[];
export interface ListAssociationsRequest {
    AssociationFilterList?: AssociationFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Association {
    Name?: string | undefined;
    InstanceId?: string | undefined;
    AssociationId?: string | undefined;
    AssociationVersion?: string | undefined;
    DocumentVersion?: string | undefined;
    Targets?: Target[] | undefined;
    LastExecutionDate?: Date | undefined;
    Overview?: AssociationOverview | undefined;
    ScheduleExpression?: string | undefined;
    AssociationName?: string | undefined;
    ScheduleOffset?: number | undefined;
    Duration?: number | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
}
export type AssociationList = Association[];
export interface ListAssociationsResult {
    Associations?: Association[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAssociationVersionsRequest {
    AssociationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AssociationVersionInfo {
    AssociationId?: string | undefined;
    AssociationVersion?: string | undefined;
    CreatedDate?: Date | undefined;
    Name?: string | undefined;
    DocumentVersion?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    Targets?: Target[] | undefined;
    ScheduleExpression?: string | undefined;
    OutputLocation?: InstanceAssociationOutputLocation | undefined;
    AssociationName?: string | undefined;
    MaxErrors?: string | undefined;
    MaxConcurrency?: string | undefined;
    ComplianceSeverity?: AssociationComplianceSeverity | undefined;
    SyncCompliance?: AssociationSyncCompliance | undefined;
    ApplyOnlyAtCronInterval?: boolean | undefined;
    CalendarNames?: string[] | undefined;
    TargetLocations?: TargetLocation[] | undefined;
    ScheduleOffset?: number | undefined;
    Duration?: number | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    AssociationDispatchAssumeRole?: string | undefined;
}
export type AssociationVersionList = AssociationVersionInfo[];
export interface ListAssociationVersionsResult {
    AssociationVersions?: AssociationVersionInfo[] | undefined;
    NextToken?: string | undefined;
}
export type CloudConnectorMaxResults = number;
export type CloudConnectorFilterKey = "SubscriptionId" | "TenantId" | "ProjectId" | "OrganizationId" | (string & {});
export type CloudConnectorFilterValue = string;
export type CloudConnectorFilterValues = string[];
export interface CloudConnectorFilter {
    FilterKey?: CloudConnectorFilterKey | undefined;
    FilterValues?: string[] | undefined;
}
export type CloudConnectorFilterList = CloudConnectorFilter[];
export interface ListCloudConnectorsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: CloudConnectorFilter[] | undefined;
}
export type Provider = "Azure" | "GCP" | (string & {});
export interface CloudConnectorSummary {
    CloudConnectorId?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    Provider?: Provider | undefined;
    ConfigConnectorArn?: string | undefined;
}
export type CloudConnectorSummaryList = CloudConnectorSummary[];
export interface ListCloudConnectorsResult {
    CloudConnectors?: CloudConnectorSummary[] | undefined;
    NextToken?: string | undefined;
}
export type CommandMaxResults = number;
export type CommandFilterKey = "InvokedAfter" | "InvokedBefore" | "Status" | "ExecutionStage" | "DocumentName" | (string & {});
export type CommandFilterValue = string;
export interface CommandFilter {
    key: CommandFilterKey;
    value: string;
}
export type CommandFilterList = CommandFilter[];
export interface ListCommandInvocationsRequest {
    CommandId?: string | undefined;
    InstanceId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: CommandFilter[] | undefined;
    Details?: boolean | undefined;
}
export type InstanceTagName = string;
export type InvocationTraceOutput = string;
export type CommandPluginStatus = "Pending" | "InProgress" | "Success" | "TimedOut" | "Cancelled" | "Failed" | (string & {});
export type CommandPluginOutput = string;
export interface CommandPlugin {
    Name?: string | undefined;
    Status?: CommandPluginStatus | undefined;
    StatusDetails?: string | undefined;
    ResponseCode?: number | undefined;
    ResponseStartDateTime?: Date | undefined;
    ResponseFinishDateTime?: Date | undefined;
    Output?: string | undefined;
    StandardOutputUrl?: string | undefined;
    StandardErrorUrl?: string | undefined;
    OutputS3Region?: string | undefined;
    OutputS3BucketName?: string | undefined;
    OutputS3KeyPrefix?: string | undefined;
}
export type CommandPluginList = CommandPlugin[];
export interface CommandInvocation {
    CommandId?: string | undefined;
    InstanceId?: string | undefined;
    InstanceName?: string | undefined;
    Comment?: string | undefined;
    DocumentName?: string | undefined;
    DocumentVersion?: string | undefined;
    RequestedDateTime?: Date | undefined;
    Status?: CommandInvocationStatus | undefined;
    StatusDetails?: string | undefined;
    TraceOutput?: string | undefined;
    StandardOutputUrl?: string | undefined;
    StandardErrorUrl?: string | undefined;
    CommandPlugins?: CommandPlugin[] | undefined;
    ServiceRole?: string | undefined;
    NotificationConfig?: NotificationConfig | undefined;
    CloudWatchOutputConfig?: CloudWatchOutputConfig | undefined;
}
export type CommandInvocationList = CommandInvocation[];
export interface ListCommandInvocationsResult {
    CommandInvocations?: CommandInvocation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCommandsRequest {
    CommandId?: string | undefined;
    InstanceId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: CommandFilter[] | undefined;
}
export type CommandStatus = "Pending" | "InProgress" | "Success" | "Cancelled" | "Failed" | "TimedOut" | "Cancelling" | (string & {});
export type TargetCount = number;
export type CompletedCount = number;
export type ErrorCount = number;
export type DeliveryTimedOutCount = number;
export interface Command {
    CommandId?: string | undefined;
    DocumentName?: string | undefined;
    DocumentVersion?: string | undefined;
    Comment?: string | undefined;
    ExpiresAfter?: Date | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    InstanceIds?: string[] | undefined;
    Targets?: Target[] | undefined;
    RequestedDateTime?: Date | undefined;
    Status?: CommandStatus | undefined;
    StatusDetails?: string | undefined;
    OutputS3Region?: string | undefined;
    OutputS3BucketName?: string | undefined;
    OutputS3KeyPrefix?: string | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    TargetCount?: number | undefined;
    CompletedCount?: number | undefined;
    ErrorCount?: number | undefined;
    DeliveryTimedOutCount?: number | undefined;
    ServiceRole?: string | undefined;
    NotificationConfig?: NotificationConfig | undefined;
    CloudWatchOutputConfig?: CloudWatchOutputConfig | undefined;
    TimeoutSeconds?: number | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    TriggeredAlarms?: AlarmStateInformation[] | undefined;
}
export type CommandList = Command[];
export interface ListCommandsResult {
    Commands?: Command[] | undefined;
    NextToken?: string | undefined;
}
export type ComplianceStringFilterKey = string;
export type ComplianceFilterValue = string;
export type ComplianceStringFilterValueList = string[];
export type ComplianceQueryOperatorType = "EQUAL" | "NOT_EQUAL" | "BEGIN_WITH" | "LESS_THAN" | "GREATER_THAN" | (string & {});
export interface ComplianceStringFilter {
    Key?: string | undefined;
    Values?: string[] | undefined;
    Type?: ComplianceQueryOperatorType | undefined;
}
export type ComplianceStringFilterList = ComplianceStringFilter[];
export type ComplianceResourceId = string;
export type ComplianceResourceIdList = string[];
export type ComplianceResourceType = string;
export type ComplianceResourceTypeList = string[];
export interface ListComplianceItemsRequest {
    Filters?: ComplianceStringFilter[] | undefined;
    ResourceIds?: string[] | undefined;
    ResourceTypes?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ComplianceTypeName = string;
export type ComplianceItemId = string;
export type ComplianceItemTitle = string;
export type ComplianceStatus = "COMPLIANT" | "NON_COMPLIANT" | (string & {});
export type ComplianceSeverity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFORMATIONAL" | "UNSPECIFIED" | (string & {});
export type ComplianceExecutionId = string;
export type ComplianceExecutionType = string;
export interface ComplianceExecutionSummary {
    ExecutionTime: Date;
    ExecutionId?: string | undefined;
    ExecutionType?: string | undefined;
}
export type ComplianceItemDetails = {
    [key: string]: string | undefined;
};
export interface ComplianceItem {
    ComplianceType?: string | undefined;
    ResourceType?: string | undefined;
    ResourceId?: string | undefined;
    Id?: string | undefined;
    Title?: string | undefined;
    Status?: ComplianceStatus | undefined;
    Severity?: ComplianceSeverity | undefined;
    ExecutionSummary?: ComplianceExecutionSummary | undefined;
    Details?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ComplianceItemList = ComplianceItem[];
export interface ListComplianceItemsResult {
    ComplianceItems?: ComplianceItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListComplianceSummariesRequest {
    Filters?: ComplianceStringFilter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ComplianceSummaryCount = number;
export interface SeveritySummary {
    CriticalCount?: number | undefined;
    HighCount?: number | undefined;
    MediumCount?: number | undefined;
    LowCount?: number | undefined;
    InformationalCount?: number | undefined;
    UnspecifiedCount?: number | undefined;
}
export interface CompliantSummary {
    CompliantCount?: number | undefined;
    SeveritySummary?: SeveritySummary | undefined;
}
export interface NonCompliantSummary {
    NonCompliantCount?: number | undefined;
    SeveritySummary?: SeveritySummary | undefined;
}
export interface ComplianceSummaryItem {
    ComplianceType?: string | undefined;
    CompliantSummary?: CompliantSummary | undefined;
    NonCompliantSummary?: NonCompliantSummary | undefined;
}
export type ComplianceSummaryItemList = ComplianceSummaryItem[];
export interface ListComplianceSummariesResult {
    ComplianceSummaryItems?: ComplianceSummaryItem[] | undefined;
    NextToken?: string | undefined;
}
export type DocumentMetadataEnum = "DocumentReviews" | (string & {});
export interface ListDocumentMetadataHistoryRequest {
    Name: string;
    DocumentVersion?: string | undefined;
    Metadata: DocumentMetadataEnum;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type DocumentReviewCommentType = "Comment" | (string & {});
export type DocumentReviewComment = string;
export interface DocumentReviewCommentSource {
    Type?: DocumentReviewCommentType | undefined;
    Content?: string | undefined;
}
export type DocumentReviewCommentList = DocumentReviewCommentSource[];
export interface DocumentReviewerResponseSource {
    CreateTime?: Date | undefined;
    UpdatedTime?: Date | undefined;
    ReviewStatus?: ReviewStatus | undefined;
    Comment?: DocumentReviewCommentSource[] | undefined;
    Reviewer?: string | undefined;
}
export type DocumentReviewerResponseList = DocumentReviewerResponseSource[];
export interface DocumentMetadataResponseInfo {
    ReviewerResponse?: DocumentReviewerResponseSource[] | undefined;
}
export interface ListDocumentMetadataHistoryResponse {
    Name?: string | undefined;
    DocumentVersion?: string | undefined;
    Author?: string | undefined;
    Metadata?: DocumentMetadataResponseInfo | undefined;
    NextToken?: string | undefined;
}
export type DocumentFilterKey = "Name" | "Owner" | "PlatformTypes" | "DocumentType" | (string & {});
export type DocumentFilterValue = string;
export interface DocumentFilter {
    key: DocumentFilterKey;
    value: string;
}
export type DocumentFilterList = DocumentFilter[];
export type DocumentKeyValuesFilterKey = string;
export type DocumentKeyValuesFilterValue = string;
export type DocumentKeyValuesFilterValues = string[];
export interface DocumentKeyValuesFilter {
    Key?: string | undefined;
    Values?: string[] | undefined;
}
export type DocumentKeyValuesFilterList = DocumentKeyValuesFilter[];
export interface ListDocumentsRequest {
    DocumentFilterList?: DocumentFilter[] | undefined;
    Filters?: DocumentKeyValuesFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DocumentIdentifier {
    Name?: string | undefined;
    CreatedDate?: Date | undefined;
    DisplayName?: string | undefined;
    Owner?: string | undefined;
    VersionName?: string | undefined;
    PlatformTypes?: PlatformType[] | undefined;
    DocumentVersion?: string | undefined;
    DocumentType?: DocumentType | undefined;
    SchemaVersion?: string | undefined;
    DocumentFormat?: DocumentFormat | undefined;
    TargetType?: string | undefined;
    Tags?: Tag[] | undefined;
    Requires?: DocumentRequires[] | undefined;
    ReviewStatus?: ReviewStatus | undefined;
    Author?: string | undefined;
}
export type DocumentIdentifierList = DocumentIdentifier[];
export interface ListDocumentsResult {
    DocumentIdentifiers?: DocumentIdentifier[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDocumentVersionsRequest {
    Name: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DocumentVersionInfo {
    Name?: string | undefined;
    DisplayName?: string | undefined;
    DocumentVersion?: string | undefined;
    VersionName?: string | undefined;
    CreatedDate?: Date | undefined;
    IsDefaultVersion?: boolean | undefined;
    DocumentFormat?: DocumentFormat | undefined;
    Status?: DocumentStatus | undefined;
    StatusInformation?: string | undefined;
    ReviewStatus?: ReviewStatus | undefined;
}
export type DocumentVersionList = DocumentVersionInfo[];
export interface ListDocumentVersionsResult {
    DocumentVersions?: DocumentVersionInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface ListInventoryEntriesRequest {
    InstanceId: string;
    TypeName: string;
    Filters?: InventoryFilter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListInventoryEntriesResult {
    TypeName?: string | undefined;
    InstanceId?: string | undefined;
    SchemaVersion?: string | undefined;
    CaptureTime?: string | undefined;
    Entries?: {
        [key: string]: string | undefined;
    }[] | undefined;
    NextToken?: string | undefined;
}
export type NodeFilterKey = "AgentType" | "AgentVersion" | "ComputerName" | "InstanceId" | "InstanceStatus" | "IpAddress" | "ManagedStatus" | "PlatformName" | "PlatformType" | "PlatformVersion" | "ResourceType" | "OrganizationalUnitId" | "OrganizationalUnitPath" | "Region" | "AccountId" | "SourceType" | "SourceId" | "SourceLocation" | "AvailabilityZone" | "AvailabilityZoneId" | (string & {});
export type NodeFilterValue = string;
export type NodeFilterValueList = string[];
export type NodeFilterOperatorType = "Equal" | "NotEqual" | "BeginWith" | (string & {});
export interface NodeFilter {
    Key: NodeFilterKey;
    Values: string[];
    Type?: NodeFilterOperatorType | undefined;
}
export type NodeFilterList = NodeFilter[];
export interface ListNodesRequest {
    SyncName?: string | undefined;
    Filters?: NodeFilter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type NodeCaptureTime = Date;
export type NodeId = string;
export type NodeAccountId = string;
export type NodeOrganizationalUnitId = string;
export type NodeOrganizationalUnitPath = string;
export interface NodeOwnerInfo {
    AccountId?: string | undefined;
    OrganizationalUnitId?: string | undefined;
    OrganizationalUnitPath?: string | undefined;
}
export type NodeRegion = string;
export type AgentType = string;
export type AgentVersion = string;
export type InstanceStatus = string;
export type ManagedStatus = "All" | "Managed" | "Unmanaged" | (string & {});
export type NodeName = string;
export type AvailabilityZoneId = string;
export interface InstanceInfo {
    AgentType?: string | undefined;
    AgentVersion?: string | undefined;
    ComputerName?: string | undefined;
    InstanceStatus?: string | undefined;
    IpAddress?: string | redacted.Redacted<string> | undefined;
    ManagedStatus?: ManagedStatus | undefined;
    Name?: string | undefined;
    PlatformType?: PlatformType | undefined;
    PlatformName?: string | undefined;
    PlatformVersion?: string | undefined;
    ResourceType?: ResourceType | undefined;
    SourceType?: SourceType | undefined;
    SourceId?: string | undefined;
    SourceLocation?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
}
export type NodeType = {
    Instance: InstanceInfo;
};
export interface Node {
    CaptureTime?: Date | undefined;
    Id?: string | undefined;
    Owner?: NodeOwnerInfo | undefined;
    Region?: string | undefined;
    NodeType?: NodeType | undefined;
}
export type NodeList = Node[];
export interface ListNodesResult {
    Nodes?: Node[] | undefined;
    NextToken?: string | undefined;
}
export type NodeAggregatorType = "Count" | (string & {});
export type NodeTypeName = "Instance" | (string & {});
export type NodeAttributeName = "AgentVersion" | "PlatformName" | "PlatformType" | "PlatformVersion" | "Region" | "ResourceType" | "SourceType" | "AvailabilityZone" | (string & {});
export interface NodeAggregator {
    AggregatorType: NodeAggregatorType;
    TypeName: NodeTypeName;
    AttributeName: NodeAttributeName;
    Aggregators?: NodeAggregator[] | undefined;
}
export type NodeAggregatorList = NodeAggregator[];
export interface ListNodesSummaryRequest {
    SyncName?: string | undefined;
    Filters?: NodeFilter[] | undefined;
    Aggregators: NodeAggregator[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type NodeSummary = {
    [key: string]: string | undefined;
};
export type NodeSummaryList = {
    [key: string]: string | undefined;
}[];
export interface ListNodesSummaryResult {
    Summary?: {
        [key: string]: string | undefined;
    }[] | undefined;
    NextToken?: string | undefined;
}
export type OpsItemEventFilterKey = "OpsItemId" | (string & {});
export type OpsItemEventFilterValue = string;
export type OpsItemEventFilterValues = string[];
export type OpsItemEventFilterOperator = "Equal" | (string & {});
export interface OpsItemEventFilter {
    Key: OpsItemEventFilterKey;
    Values: string[];
    Operator: OpsItemEventFilterOperator;
}
export type OpsItemEventFilters = OpsItemEventFilter[];
export type OpsItemEventMaxResults = number;
export interface ListOpsItemEventsRequest {
    Filters?: OpsItemEventFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface OpsItemIdentity {
    Arn?: string | undefined;
}
export interface OpsItemEventSummary {
    OpsItemId?: string | undefined;
    EventId?: string | undefined;
    Source?: string | undefined;
    DetailType?: string | undefined;
    Detail?: string | undefined;
    CreatedBy?: OpsItemIdentity | undefined;
    CreatedTime?: Date | undefined;
}
export type OpsItemEventSummaries = OpsItemEventSummary[];
export interface ListOpsItemEventsResponse {
    NextToken?: string | undefined;
    Summaries?: OpsItemEventSummary[] | undefined;
}
export type OpsItemRelatedItemsFilterKey = "ResourceType" | "AssociationId" | "ResourceUri" | (string & {});
export type OpsItemRelatedItemsFilterValue = string;
export type OpsItemRelatedItemsFilterValues = string[];
export type OpsItemRelatedItemsFilterOperator = "Equal" | (string & {});
export interface OpsItemRelatedItemsFilter {
    Key: OpsItemRelatedItemsFilterKey;
    Values: string[];
    Operator: OpsItemRelatedItemsFilterOperator;
}
export type OpsItemRelatedItemsFilters = OpsItemRelatedItemsFilter[];
export type OpsItemRelatedItemsMaxResults = number;
export interface ListOpsItemRelatedItemsRequest {
    OpsItemId?: string | undefined;
    Filters?: OpsItemRelatedItemsFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface OpsItemRelatedItemSummary {
    OpsItemId?: string | undefined;
    AssociationId?: string | undefined;
    ResourceType?: string | undefined;
    AssociationType?: string | undefined;
    ResourceUri?: string | undefined;
    CreatedBy?: OpsItemIdentity | undefined;
    CreatedTime?: Date | undefined;
    LastModifiedBy?: OpsItemIdentity | undefined;
    LastModifiedTime?: Date | undefined;
}
export type OpsItemRelatedItemSummaries = OpsItemRelatedItemSummary[];
export interface ListOpsItemRelatedItemsResponse {
    NextToken?: string | undefined;
    Summaries?: OpsItemRelatedItemSummary[] | undefined;
}
export type OpsMetadataFilterKey = string;
export type OpsMetadataFilterValue = string;
export type OpsMetadataFilterValueList = string[];
export interface OpsMetadataFilter {
    Key: string;
    Values: string[];
}
export type OpsMetadataFilterList = OpsMetadataFilter[];
export type ListOpsMetadataMaxResults = number;
export interface ListOpsMetadataRequest {
    Filters?: OpsMetadataFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface OpsMetadata {
    ResourceId?: string | undefined;
    OpsMetadataArn?: string | undefined;
    LastModifiedDate?: Date | undefined;
    LastModifiedUser?: string | undefined;
    CreationDate?: Date | undefined;
}
export type OpsMetadataList = OpsMetadata[];
export interface ListOpsMetadataResult {
    OpsMetadataList?: OpsMetadata[] | undefined;
    NextToken?: string | undefined;
}
export interface ListResourceComplianceSummariesRequest {
    Filters?: ComplianceStringFilter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ResourceComplianceSummaryItem {
    ComplianceType?: string | undefined;
    ResourceType?: string | undefined;
    ResourceId?: string | undefined;
    Status?: ComplianceStatus | undefined;
    OverallSeverity?: ComplianceSeverity | undefined;
    ExecutionSummary?: ComplianceExecutionSummary | undefined;
    CompliantSummary?: CompliantSummary | undefined;
    NonCompliantSummary?: NonCompliantSummary | undefined;
}
export type ResourceComplianceSummaryItemList = ResourceComplianceSummaryItem[];
export interface ListResourceComplianceSummariesResult {
    ResourceComplianceSummaryItems?: ResourceComplianceSummaryItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListResourceDataSyncRequest {
    SyncType?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ResourceDataSyncState = string;
export interface ResourceDataSyncSourceWithState {
    SourceType?: string | undefined;
    AwsOrganizationsSource?: ResourceDataSyncAwsOrganizationsSource | undefined;
    SourceRegions?: string[] | undefined;
    IncludeFutureRegions?: boolean | undefined;
    State?: string | undefined;
    EnableAllOpsDataSources?: boolean | undefined;
}
export type LastResourceDataSyncTime = Date;
export type LastSuccessfulResourceDataSyncTime = Date;
export type ResourceDataSyncLastModifiedTime = Date;
export type LastResourceDataSyncStatus = "Successful" | "Failed" | "InProgress" | (string & {});
export type ResourceDataSyncCreatedTime = Date;
export type LastResourceDataSyncMessage = string;
export interface ResourceDataSyncItem {
    SyncName?: string | undefined;
    SyncType?: string | undefined;
    SyncSource?: ResourceDataSyncSourceWithState | undefined;
    S3Destination?: ResourceDataSyncS3Destination | undefined;
    LastSyncTime?: Date | undefined;
    LastSuccessfulSyncTime?: Date | undefined;
    SyncLastModifiedTime?: Date | undefined;
    LastStatus?: LastResourceDataSyncStatus | undefined;
    SyncCreatedTime?: Date | undefined;
    LastSyncStatusMessage?: string | undefined;
}
export type ResourceDataSyncItemList = ResourceDataSyncItem[];
export interface ListResourceDataSyncResult {
    ResourceDataSyncItems?: ResourceDataSyncItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceType: ResourceTypeForTagging;
    ResourceId: string;
}
export interface ListTagsForResourceResult {
    TagList?: Tag[] | undefined;
}
export interface ModifyDocumentPermissionRequest {
    Name: string;
    PermissionType: DocumentPermissionType;
    AccountIdsToAdd?: string[] | undefined;
    AccountIdsToRemove?: string[] | undefined;
    SharedDocumentVersion?: string | undefined;
}
export interface ModifyDocumentPermissionResponse {
}
export interface ComplianceItemEntry {
    Id?: string | undefined;
    Title?: string | undefined;
    Severity: ComplianceSeverity;
    Status: ComplianceStatus;
    Details?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ComplianceItemEntryList = ComplianceItemEntry[];
export type ComplianceItemContentHash = string;
export type ComplianceUploadType = "COMPLETE" | "PARTIAL" | (string & {});
export interface PutComplianceItemsRequest {
    ResourceId: string;
    ResourceType: string;
    ComplianceType: string;
    ExecutionSummary: ComplianceExecutionSummary;
    Items: ComplianceItemEntry[];
    ItemContentHash?: string | undefined;
    UploadType?: ComplianceUploadType | undefined;
}
export interface PutComplianceItemsResult {
}
export type InventoryItemContentContext = {
    [key: string]: string | undefined;
};
export interface InventoryItem {
    TypeName: string;
    SchemaVersion: string;
    CaptureTime: string;
    ContentHash?: string | undefined;
    Content?: {
        [key: string]: string | undefined;
    }[] | undefined;
    Context?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type InventoryItemList = InventoryItem[];
export interface PutInventoryRequest {
    InstanceId: string;
    Items: InventoryItem[];
}
export type PutInventoryMessage = string;
export interface PutInventoryResult {
    Message?: string | undefined;
}
export type ParameterPolicies = string;
export interface PutParameterRequest {
    Name: string;
    Description?: string | undefined;
    Value: string | redacted.Redacted<string>;
    Type?: ParameterType | undefined;
    KeyId?: string | undefined;
    Overwrite?: boolean | undefined;
    AllowedPattern?: string | undefined;
    Tags?: Tag[] | undefined;
    Tier?: ParameterTier | undefined;
    Policies?: string | undefined;
    DataType?: string | undefined;
}
export interface PutParameterResult {
    Version?: number | undefined;
    Tier?: ParameterTier | undefined;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    Policy: string;
    PolicyId?: string | undefined;
    PolicyHash?: string | undefined;
}
export interface PutResourcePolicyResponse {
    PolicyId?: string | undefined;
    PolicyHash?: string | undefined;
}
export type DHMCPermissionModel = "SERVICE_MANAGED" | "SELF_MANAGED" | (string & {});
export type DHMCRoleArn = string;
export interface RegisterDefaultHostManagementConfigurationRequest {
    PermissionModel: DHMCPermissionModel;
    RoleArn?: string | undefined;
    Overwrite?: boolean | undefined;
}
export interface RegisterDefaultHostManagementConfigurationResult {
    RoleArn?: string | undefined;
}
export interface RegisterDefaultPatchBaselineRequest {
    BaselineId: string;
}
export interface RegisterDefaultPatchBaselineResult {
    BaselineId?: string | undefined;
}
export interface RegisterPatchBaselineForPatchGroupRequest {
    BaselineId: string;
    PatchGroup: string;
}
export interface RegisterPatchBaselineForPatchGroupResult {
    BaselineId?: string | undefined;
    PatchGroup?: string | undefined;
}
export interface RegisterTargetWithMaintenanceWindowRequest {
    WindowId: string;
    ResourceType: MaintenanceWindowResourceType;
    Targets: Target[];
    OwnerInformation?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    ClientToken?: string | undefined;
}
export interface RegisterTargetWithMaintenanceWindowResult {
    WindowTargetId?: string | undefined;
}
export interface RegisterTaskWithMaintenanceWindowRequest {
    WindowId: string;
    Targets?: Target[] | undefined;
    TaskArn: string;
    ServiceRoleArn?: string | undefined;
    TaskType: MaintenanceWindowTaskType;
    TaskParameters?: {
        [key: string]: MaintenanceWindowTaskParameterValueExpression | undefined;
    } | undefined;
    TaskInvocationParameters?: MaintenanceWindowTaskInvocationParameters | undefined;
    Priority?: number | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    ClientToken?: string | undefined;
    CutoffBehavior?: MaintenanceWindowTaskCutoffBehavior | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
}
export interface RegisterTaskWithMaintenanceWindowResult {
    WindowTaskId?: string | undefined;
}
export type KeyList = string[];
export interface RemoveTagsFromResourceRequest {
    ResourceType: ResourceTypeForTagging;
    ResourceId: string;
    TagKeys: string[];
}
export interface RemoveTagsFromResourceResult {
}
export interface ResetServiceSettingRequest {
    SettingId: string;
}
export interface ResetServiceSettingResult {
    ServiceSetting?: ServiceSetting | undefined;
}
export interface ResumeSessionRequest {
    SessionId: string;
}
export type TokenValue = string;
export type StreamUrl = string;
export interface ResumeSessionResponse {
    SessionId?: string | undefined;
    TokenValue?: string | undefined;
    StreamUrl?: string | undefined;
}
export type SignalType = "Approve" | "Reject" | "StartStep" | "StopStep" | "Resume" | "Revoke" | (string & {});
export interface SendAutomationSignalRequest {
    AutomationExecutionId: string;
    SignalType: SignalType;
    Payload?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface SendAutomationSignalResult {
}
export interface SendCommandRequest {
    InstanceIds?: string[] | undefined;
    Targets?: Target[] | undefined;
    DocumentName: string;
    DocumentVersion?: string | undefined;
    DocumentHash?: string | undefined;
    DocumentHashType?: DocumentHashType | undefined;
    TimeoutSeconds?: number | undefined;
    Comment?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    OutputS3Region?: string | undefined;
    OutputS3BucketName?: string | undefined;
    OutputS3KeyPrefix?: string | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    ServiceRoleArn?: string | undefined;
    NotificationConfig?: NotificationConfig | undefined;
    CloudWatchOutputConfig?: CloudWatchOutputConfig | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
}
export interface SendCommandResult {
    Command?: Command | undefined;
}
export type String1to256 = string;
export interface StartAccessRequestRequest {
    Reason: string;
    Targets: Target[];
    Tags?: Tag[] | undefined;
}
export interface StartAccessRequestResponse {
    AccessRequestId?: string | undefined;
}
export type AssociationIdList = string[];
export interface StartAssociationsOnceRequest {
    AssociationIds: string[];
}
export interface StartAssociationsOnceResult {
}
export type IdempotencyToken = string;
export interface StartAutomationExecutionRequest {
    DocumentName: string;
    DocumentVersion?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ClientToken?: string | undefined;
    Mode?: ExecutionMode | undefined;
    TargetParameterName?: string | undefined;
    Targets?: Target[] | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    TargetLocations?: TargetLocation[] | undefined;
    Tags?: Tag[] | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    TargetLocationsURL?: string | undefined;
}
export interface StartAutomationExecutionResult {
    AutomationExecutionId?: string | undefined;
}
export type ChangeDetailsValue = string;
export interface StartChangeRequestExecutionRequest {
    ScheduledTime?: Date | undefined;
    DocumentName: string;
    DocumentVersion?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ChangeRequestName?: string | undefined;
    ClientToken?: string | undefined;
    AutoApprove?: boolean | undefined;
    Runbooks: Runbook[];
    Tags?: Tag[] | undefined;
    ScheduledEndTime?: Date | undefined;
    ChangeDetails?: string | undefined;
}
export interface StartChangeRequestExecutionResult {
    AutomationExecutionId?: string | undefined;
}
export interface AutomationExecutionInputs {
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    TargetParameterName?: string | undefined;
    Targets?: Target[] | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    TargetLocations?: TargetLocation[] | undefined;
    TargetLocationsURL?: string | undefined;
}
export type ExecutionInputs = {
    Automation: AutomationExecutionInputs;
};
export interface StartExecutionPreviewRequest {
    DocumentName: string;
    DocumentVersion?: string | undefined;
    ExecutionInputs?: ExecutionInputs | undefined;
}
export interface StartExecutionPreviewResponse {
    ExecutionPreviewId?: string | undefined;
}
export type SessionManagerParameterName = string;
export type SessionManagerParameterValue = string;
export type SessionManagerParameterValueList = string[];
export type SessionManagerParameters = {
    [key: string]: string[] | undefined;
};
export interface StartSessionRequest {
    Target: string;
    DocumentName?: string | undefined;
    Reason?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface StartSessionResponse {
    SessionId?: string | undefined;
    TokenValue?: string | undefined;
    StreamUrl?: string | undefined;
}
export type StopType = "Complete" | "Cancel" | (string & {});
export interface StopAutomationExecutionRequest {
    AutomationExecutionId: string;
    Type?: StopType | undefined;
}
export interface StopAutomationExecutionResult {
}
export interface TerminateSessionRequest {
    SessionId: string;
}
export interface TerminateSessionResponse {
    SessionId?: string | undefined;
}
export interface UnlabelParameterVersionRequest {
    Name: string;
    ParameterVersion: number;
    Labels: string[];
}
export interface UnlabelParameterVersionResult {
    RemovedLabels?: string[] | undefined;
    InvalidLabels?: string[] | undefined;
}
export interface UpdateAssociationRequest {
    AssociationId: string;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    DocumentVersion?: string | undefined;
    ScheduleExpression?: string | undefined;
    OutputLocation?: InstanceAssociationOutputLocation | undefined;
    Name?: string | undefined;
    Targets?: Target[] | undefined;
    AssociationName?: string | undefined;
    AssociationVersion?: string | undefined;
    AutomationTargetParameterName?: string | undefined;
    MaxErrors?: string | undefined;
    MaxConcurrency?: string | undefined;
    ComplianceSeverity?: AssociationComplianceSeverity | undefined;
    SyncCompliance?: AssociationSyncCompliance | undefined;
    ApplyOnlyAtCronInterval?: boolean | undefined;
    CalendarNames?: string[] | undefined;
    TargetLocations?: TargetLocation[] | undefined;
    ScheduleOffset?: number | undefined;
    Duration?: number | undefined;
    TargetMaps?: {
        [key: string]: string[] | undefined;
    }[] | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
    AssociationDispatchAssumeRole?: string | undefined;
}
export interface UpdateAssociationResult {
    AssociationDescription?: AssociationDescription | undefined;
}
export interface UpdateAssociationStatusRequest {
    Name: string;
    InstanceId: string;
    AssociationStatus: AssociationStatus;
}
export interface UpdateAssociationStatusResult {
    AssociationDescription?: AssociationDescription | undefined;
}
export interface UpdateCloudConnectorRequest {
    CloudConnectorId: string;
    DisplayName?: string | undefined;
    Configuration?: CloudConnectorConfiguration | undefined;
    Description?: string | undefined;
}
export interface UpdateCloudConnectorResult {
    CloudConnectorId?: string | undefined;
}
export interface UpdateDocumentRequest {
    Content: string;
    Attachments?: AttachmentsSource[] | undefined;
    Name: string;
    DisplayName?: string | undefined;
    VersionName?: string | undefined;
    DocumentVersion?: string | undefined;
    DocumentFormat?: DocumentFormat | undefined;
    TargetType?: string | undefined;
}
export interface UpdateDocumentResult {
    DocumentDescription?: DocumentDescription | undefined;
}
export type DocumentVersionNumber = string;
export interface UpdateDocumentDefaultVersionRequest {
    Name: string;
    DocumentVersion: string;
}
export interface DocumentDefaultVersionDescription {
    Name?: string | undefined;
    DefaultVersion?: string | undefined;
    DefaultVersionName?: string | undefined;
}
export interface UpdateDocumentDefaultVersionResult {
    Description?: DocumentDefaultVersionDescription | undefined;
}
export type DocumentReviewAction = "SendForReview" | "UpdateReview" | "Approve" | "Reject" | (string & {});
export interface DocumentReviews {
    Action: DocumentReviewAction;
    Comment?: DocumentReviewCommentSource[] | undefined;
}
export interface UpdateDocumentMetadataRequest {
    Name: string;
    DocumentVersion?: string | undefined;
    DocumentReviews: DocumentReviews;
}
export interface UpdateDocumentMetadataResponse {
}
export interface UpdateMaintenanceWindowRequest {
    WindowId: string;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    StartDate?: string | undefined;
    EndDate?: string | undefined;
    Schedule?: string | undefined;
    ScheduleTimezone?: string | undefined;
    ScheduleOffset?: number | undefined;
    Duration?: number | undefined;
    Cutoff?: number | undefined;
    AllowUnassociatedTargets?: boolean | undefined;
    Enabled?: boolean | undefined;
    Replace?: boolean | undefined;
}
export interface UpdateMaintenanceWindowResult {
    WindowId?: string | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    StartDate?: string | undefined;
    EndDate?: string | undefined;
    Schedule?: string | undefined;
    ScheduleTimezone?: string | undefined;
    ScheduleOffset?: number | undefined;
    Duration?: number | undefined;
    Cutoff?: number | undefined;
    AllowUnassociatedTargets?: boolean | undefined;
    Enabled?: boolean | undefined;
}
export interface UpdateMaintenanceWindowTargetRequest {
    WindowId: string;
    WindowTargetId: string;
    Targets?: Target[] | undefined;
    OwnerInformation?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Replace?: boolean | undefined;
}
export interface UpdateMaintenanceWindowTargetResult {
    WindowId?: string | undefined;
    WindowTargetId?: string | undefined;
    Targets?: Target[] | undefined;
    OwnerInformation?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateMaintenanceWindowTaskRequest {
    WindowId: string;
    WindowTaskId: string;
    Targets?: Target[] | undefined;
    TaskArn?: string | undefined;
    ServiceRoleArn?: string | undefined;
    TaskParameters?: {
        [key: string]: MaintenanceWindowTaskParameterValueExpression | undefined;
    } | undefined;
    TaskInvocationParameters?: MaintenanceWindowTaskInvocationParameters | undefined;
    Priority?: number | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Replace?: boolean | undefined;
    CutoffBehavior?: MaintenanceWindowTaskCutoffBehavior | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
}
export interface UpdateMaintenanceWindowTaskResult {
    WindowId?: string | undefined;
    WindowTaskId?: string | undefined;
    Targets?: Target[] | undefined;
    TaskArn?: string | undefined;
    ServiceRoleArn?: string | undefined;
    TaskParameters?: {
        [key: string]: MaintenanceWindowTaskParameterValueExpression | undefined;
    } | undefined;
    TaskInvocationParameters?: MaintenanceWindowTaskInvocationParameters | undefined;
    Priority?: number | undefined;
    MaxConcurrency?: string | undefined;
    MaxErrors?: string | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CutoffBehavior?: MaintenanceWindowTaskCutoffBehavior | undefined;
    AlarmConfiguration?: AlarmConfiguration | undefined;
}
export interface UpdateManagedInstanceRoleRequest {
    InstanceId: string;
    IamRole: string;
}
export interface UpdateManagedInstanceRoleResult {
}
export type OpsItemOpsDataKeysList = string[];
export interface UpdateOpsItemRequest {
    Description?: string | undefined;
    OperationalData?: {
        [key: string]: OpsItemDataValue | undefined;
    } | undefined;
    OperationalDataToDelete?: string[] | undefined;
    Notifications?: OpsItemNotification[] | undefined;
    Priority?: number | undefined;
    RelatedOpsItems?: RelatedOpsItem[] | undefined;
    Status?: OpsItemStatus | undefined;
    OpsItemId: string;
    Title?: string | undefined;
    Category?: string | undefined;
    Severity?: string | undefined;
    ActualStartTime?: Date | undefined;
    ActualEndTime?: Date | undefined;
    PlannedStartTime?: Date | undefined;
    PlannedEndTime?: Date | undefined;
    OpsItemArn?: string | undefined;
}
export interface UpdateOpsItemResponse {
}
export type MetadataKeysToDeleteList = string[];
export interface UpdateOpsMetadataRequest {
    OpsMetadataArn: string;
    MetadataToUpdate?: {
        [key: string]: MetadataValue | undefined;
    } | undefined;
    KeysToDelete?: string[] | undefined;
}
export interface UpdateOpsMetadataResult {
    OpsMetadataArn?: string | undefined;
}
export interface UpdatePatchBaselineRequest {
    BaselineId: string;
    Name?: string | undefined;
    GlobalFilters?: PatchFilterGroup | undefined;
    ApprovalRules?: PatchRuleGroup | undefined;
    ApprovedPatches?: string[] | undefined;
    ApprovedPatchesComplianceLevel?: PatchComplianceLevel | undefined;
    ApprovedPatchesEnableNonSecurity?: boolean | undefined;
    RejectedPatches?: string[] | undefined;
    RejectedPatchesAction?: PatchAction | undefined;
    Description?: string | undefined;
    Sources?: PatchSource[] | undefined;
    AvailableSecurityUpdatesComplianceStatus?: PatchComplianceStatus | undefined;
    Replace?: boolean | undefined;
}
export interface UpdatePatchBaselineResult {
    BaselineId?: string | undefined;
    Name?: string | undefined;
    OperatingSystem?: OperatingSystem | undefined;
    GlobalFilters?: PatchFilterGroup | undefined;
    ApprovalRules?: PatchRuleGroup | undefined;
    ApprovedPatches?: string[] | undefined;
    ApprovedPatchesComplianceLevel?: PatchComplianceLevel | undefined;
    ApprovedPatchesEnableNonSecurity?: boolean | undefined;
    RejectedPatches?: string[] | undefined;
    RejectedPatchesAction?: PatchAction | undefined;
    CreatedDate?: Date | undefined;
    ModifiedDate?: Date | undefined;
    Description?: string | undefined;
    Sources?: PatchSource[] | undefined;
    AvailableSecurityUpdatesComplianceStatus?: PatchComplianceStatus | undefined;
}
export interface UpdateResourceDataSyncRequest {
    SyncName: string;
    SyncType: string;
    SyncSource: ResourceDataSyncSource;
}
export interface UpdateResourceDataSyncResult {
}
export interface UpdateServiceSettingRequest {
    SettingId: string;
    SettingValue: string;
}
export interface UpdateServiceSettingResult {
}
export type ValidateCloudConnectorMaxResults = number;
export interface ValidateCloudConnectorRequest {
    CloudConnectorId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ValidationFindingType = "INFO" | "WARN" | "ERROR" | (string & {});
export type ValidationFindingCode = "TargetInaccessible" | "TargetUnusable" | "TargetMissingPermissions" | "TargetApiDisabled" | "TargetStateWarning" | "AwsRoleAssumptionFailed" | "WebIdentityTokenFailed" | "OutboundWebIdentityFederationDisabled" | "ProviderCredentialCreationFailed" | "TenantSummary" | "SubscriptionAccessible" | (string & {});
export type ValidationFindingScopeType = "azure:tenant" | "azure:subscription" | "gcp:organization" | "gcp:project" | (string & {});
export interface ValidationFindingScope {
    Type?: ValidationFindingScopeType | undefined;
    Id?: string | undefined;
}
export interface ValidationFinding {
    Type?: ValidationFindingType | undefined;
    Code?: ValidationFindingCode | undefined;
    Message?: string | undefined;
    ProviderMessage?: string | undefined;
    Scope?: ValidationFindingScope | undefined;
}
export type ValidationFindingList = ValidationFinding[];
export interface ValidateCloudConnectorResult {
    ValidationFindings?: ValidationFinding[] | undefined;
    NextToken?: string | undefined;
}
export type OpsItemParameterNamesList = string[];
export type ResourcePolicyParameterNamesList = string[];
export type AddTagsToResourceError = InternalServerError | InvalidResourceId | InvalidResourceType | TooManyTagsError | TooManyUpdates | CommonErrors;
/**
 * Adds or overwrites one or more tags for the specified resource. *Tags*
 * are metadata that you can assign to your automations, documents, managed nodes, maintenance
 * windows, Parameter Store parameters, and patch baselines. Tags enable you to categorize your
 * resources in different ways, for example, by purpose, owner, or environment. Each tag consists of
 * a key and an optional value, both of which you define. For example, you could define a set of
 * tags for your account's managed nodes that helps you track each node's owner and stack level. For
 * example:
 *
 * - `Key=Owner,Value=DbAdmin`
 *
 * - `Key=Owner,Value=SysAdmin`
 *
 * - `Key=Owner,Value=Dev`
 *
 * - `Key=Stack,Value=Production`
 *
 * - `Key=Stack,Value=Pre-Production`
 *
 * - `Key=Stack,Value=Test`
 *
 * Most resources can have a maximum of 50 tags. Automations can have a maximum of 5
 * tags.
 *
 * We recommend that you devise a set of tag keys that meets your needs for each resource type.
 * Using a consistent set of tag keys makes it easier for you to manage your resources. You can
 * search and filter the resources based on the tags you add. Tags don't have any semantic meaning
 * to and are interpreted strictly as a string of characters.
 *
 * For more information about using tags with Amazon Elastic Compute Cloud (Amazon EC2) instances, see Tag your Amazon EC2
 * resources in the *Amazon EC2 User Guide*.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceRequest & RegionInput, AddTagsToResourceResult, AddTagsToResourceError, Creds | HttpClient.HttpClient>;
export type AssociateOpsItemRelatedItemError = InternalServerError | OpsItemConflictException | OpsItemInvalidParameterException | OpsItemLimitExceededException | OpsItemNotFoundException | OpsItemRelatedItemAlreadyExistsException | CommonErrors;
/**
 * Associates a related item to a Systems Manager OpsCenter OpsItem. For example, you can associate an
 * Incident Manager incident or analysis with an OpsItem. Incident Manager and OpsCenter are tools in
 * Amazon Web Services Systems Manager.
 */
export declare const associateOpsItemRelatedItem: API.OperationMethod<AssociateOpsItemRelatedItemRequest & RegionInput, AssociateOpsItemRelatedItemResponse, AssociateOpsItemRelatedItemError, Creds | HttpClient.HttpClient>;
export type CancelCommandError = DuplicateInstanceId | InternalServerError | InvalidCommandId | InvalidInstanceId | CommonErrors;
/**
 * Attempts to cancel the command specified by the Command ID. There is no guarantee that the
 * command will be terminated and the underlying process stopped.
 */
export declare const cancelCommand: API.OperationMethod<CancelCommandRequest & RegionInput, CancelCommandResult, CancelCommandError, Creds | HttpClient.HttpClient>;
export type CancelMaintenanceWindowExecutionError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Stops a maintenance window execution that is already in progress and cancels any tasks in
 * the window that haven't already starting running. Tasks already in progress will continue to
 * completion.
 */
export declare const cancelMaintenanceWindowExecution: API.OperationMethod<CancelMaintenanceWindowExecutionRequest & RegionInput, CancelMaintenanceWindowExecutionResult, CancelMaintenanceWindowExecutionError, Creds | HttpClient.HttpClient>;
export type CreateActivationError = InternalServerError | InvalidParameters | CommonErrors;
/**
 * Generates an activation code and activation ID you can use to register your on-premises
 * servers, edge devices, or virtual machine (VM) with Amazon Web Services Systems Manager. Registering these machines with
 * Systems Manager makes it possible to manage them using Systems Manager tools. You use the activation code and ID when
 * installing SSM Agent on machines in your hybrid environment. For more information about
 * requirements for managing on-premises machines using Systems Manager, see Using Amazon Web Services Systems Manager in
 * hybrid and multicloud environments in the *Amazon Web Services Systems Manager User Guide*.
 *
 * Amazon Elastic Compute Cloud (Amazon EC2) instances, edge devices, and on-premises servers and VMs that are
 * configured for Systems Manager are all called *managed nodes*.
 */
export declare const createActivation: API.OperationMethod<CreateActivationRequest & RegionInput, CreateActivationResult, CreateActivationError, Creds | HttpClient.HttpClient>;
export type CreateAssociationError = AssociationAlreadyExists | AssociationLimitExceeded | InternalServerError | InvalidDocument | InvalidDocumentVersion | InvalidInstanceId | InvalidOutputLocation | InvalidParameters | InvalidSchedule | InvalidTag | InvalidTarget | InvalidTargetMaps | UnsupportedPlatformType | CommonErrors;
/**
 * A State Manager association defines the state that you want to maintain on your managed
 * nodes. For example, an association can specify that anti-virus software must be installed and
 * running on your managed nodes, or that certain ports must be closed. For static targets, the
 * association specifies a schedule for when the configuration is reapplied. For dynamic targets,
 * such as an Amazon Web Services resource group or an Amazon Web Services autoscaling group, State Manager, a tool in Amazon Web Services Systems Manager
 * applies the configuration when new managed nodes are added to the group. The association also
 * specifies actions to take when applying the configuration. For example, an association for
 * anti-virus software might run once a day. If the software isn't installed, then State Manager
 * installs it. If the software is installed, but the service isn't running, then the association
 * might instruct State Manager to start the service.
 */
export declare const createAssociation: API.OperationMethod<CreateAssociationRequest & RegionInput, CreateAssociationResult, CreateAssociationError, Creds | HttpClient.HttpClient>;
export type CreateAssociationBatchError = AssociationLimitExceeded | DuplicateInstanceId | InternalServerError | InvalidDocument | InvalidDocumentVersion | InvalidInstanceId | InvalidOutputLocation | InvalidParameters | InvalidSchedule | InvalidTarget | InvalidTargetMaps | UnsupportedPlatformType | CommonErrors;
/**
 * Associates the specified Amazon Web Services Systems Manager document (SSM document) with the specified managed nodes
 * or targets.
 *
 * When you associate a document with one or more managed nodes using IDs or tags, Amazon Web Services Systems Manager
 * Agent (SSM Agent) running on the managed node processes the document and configures the node as
 * specified.
 *
 * If you associate a document with a managed node that already has an associated document, the
 * system returns the AssociationAlreadyExists exception.
 */
export declare const createAssociationBatch: API.OperationMethod<CreateAssociationBatchRequest & RegionInput, CreateAssociationBatchResult, CreateAssociationBatchError, Creds | HttpClient.HttpClient>;
export type CreateCloudConnectorError = ConflictException | InternalServerError | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a cloud connector that establishes a connection between Systems Manager and a third-party
 * cloud environment.
 */
export declare const createCloudConnector: API.OperationMethod<CreateCloudConnectorRequest & RegionInput, CreateCloudConnectorResult, CreateCloudConnectorError, Creds | HttpClient.HttpClient>;
export type CreateDocumentError = DocumentAlreadyExists | DocumentLimitExceeded | InternalServerError | InvalidDocumentContent | InvalidDocumentSchemaVersion | MaxDocumentSizeExceeded | NoLongerSupportedException | TooManyUpdates | CommonErrors;
/**
 * Creates a Amazon Web Services Systems Manager (SSM document). An SSM document defines the actions that Systems Manager performs
 * on your managed nodes. For more information about SSM documents, including information about
 * supported schemas, features, and syntax, see Amazon Web Services Systems Manager Documents in the
 * *Amazon Web Services Systems Manager User Guide*.
 */
export declare const createDocument: API.OperationMethod<CreateDocumentRequest & RegionInput, CreateDocumentResult, CreateDocumentError, Creds | HttpClient.HttpClient>;
export type CreateMaintenanceWindowError = IdempotentParameterMismatch | InternalServerError | ResourceLimitExceededException | CommonErrors;
/**
 * Creates a new maintenance window.
 *
 * The value you specify for `Duration` determines the specific end time for the
 * maintenance window based on the time it begins. No maintenance window tasks are permitted to
 * start after the resulting endtime minus the number of hours you specify for `Cutoff`.
 * For example, if the maintenance window starts at 3 PM, the duration is three hours, and the
 * value you specify for `Cutoff` is one hour, no maintenance window tasks can start
 * after 5 PM.
 */
export declare const createMaintenanceWindow: API.OperationMethod<CreateMaintenanceWindowRequest & RegionInput, CreateMaintenanceWindowResult, CreateMaintenanceWindowError, Creds | HttpClient.HttpClient>;
export type CreateOpsItemError = InternalServerError | OpsItemAccessDeniedException | OpsItemAlreadyExistsException | OpsItemInvalidParameterException | OpsItemLimitExceededException | CommonErrors;
/**
 * Creates a new OpsItem. You must have permission in Identity and Access Management (IAM) to create a new OpsItem. For more information, see Set up OpsCenter in the
 * *Amazon Web Services Systems Manager User Guide*.
 *
 * Operations engineers and IT professionals use Amazon Web Services Systems Manager OpsCenter to view, investigate, and
 * remediate operational issues impacting the performance and health of their Amazon Web Services resources. For
 * more information, see Amazon Web Services Systems Manager OpsCenter in the
 * *Amazon Web Services Systems Manager User Guide*.
 */
export declare const createOpsItem: API.OperationMethod<CreateOpsItemRequest & RegionInput, CreateOpsItemResponse, CreateOpsItemError, Creds | HttpClient.HttpClient>;
export type CreateOpsMetadataError = InternalServerError | OpsMetadataAlreadyExistsException | OpsMetadataInvalidArgumentException | OpsMetadataLimitExceededException | OpsMetadataTooManyUpdatesException | CommonErrors;
/**
 * If you create a new application in Application Manager, Amazon Web Services Systems Manager calls this API operation to specify
 * information about the new application, including the application type.
 */
export declare const createOpsMetadata: API.OperationMethod<CreateOpsMetadataRequest & RegionInput, CreateOpsMetadataResult, CreateOpsMetadataError, Creds | HttpClient.HttpClient>;
export type CreatePatchBaselineError = IdempotentParameterMismatch | InternalServerError | ResourceLimitExceededException | CommonErrors;
/**
 * Creates a patch baseline.
 *
 * For information about valid key-value pairs in `PatchFilters` for each supported
 * operating system type, see PatchFilter.
 */
export declare const createPatchBaseline: API.OperationMethod<CreatePatchBaselineRequest & RegionInput, CreatePatchBaselineResult, CreatePatchBaselineError, Creds | HttpClient.HttpClient>;
export type CreateResourceDataSyncError = InternalServerError | ResourceDataSyncAlreadyExistsException | ResourceDataSyncCountExceededException | ResourceDataSyncInvalidConfigurationException | CommonErrors;
/**
 * A resource data sync helps you view data from multiple sources in a single location.
 * Amazon Web Services Systems Manager offers two types of resource data sync: `SyncToDestination` and
 * `SyncFromSource`.
 *
 * You can configure Systems Manager Inventory to use the `SyncToDestination` type to
 * synchronize Inventory data from multiple Amazon Web Services Regions to a single Amazon Simple Storage Service (Amazon S3) bucket. For more information, see Creating a
 * resource data sync for Inventory in the *Amazon Web Services Systems Manager User Guide*.
 *
 * You can configure Systems Manager Explorer to use the `SyncFromSource` type to synchronize
 * operational work items (OpsItems) and operational data (OpsData) from multiple Amazon Web Services Regions to a
 * single Amazon S3 bucket. This type can synchronize OpsItems and OpsData from multiple
 * Amazon Web Services accounts and Amazon Web Services Regions or `EntireOrganization` by using Organizations. For more
 * information, see Setting up Systems Manager
 * Explorer to display data from multiple accounts and Regions in the
 * *Amazon Web Services Systems Manager User Guide*.
 *
 * A resource data sync is an asynchronous operation that returns immediately. After a
 * successful initial sync is completed, the system continuously syncs data. To check the status of
 * a sync, use the ListResourceDataSync.
 *
 * By default, data isn't encrypted in Amazon S3. We strongly recommend that you
 * enable encryption in Amazon S3 to ensure secure data storage. We also recommend that you
 * secure access to the Amazon S3 bucket by creating a restrictive bucket policy.
 */
export declare const createResourceDataSync: API.OperationMethod<CreateResourceDataSyncRequest & RegionInput, CreateResourceDataSyncResult, CreateResourceDataSyncError, Creds | HttpClient.HttpClient>;
export type DeleteActivationError = InternalServerError | InvalidActivation | InvalidActivationId | TooManyUpdates | CommonErrors;
/**
 * Deletes an activation. You aren't required to delete an activation. If you delete an
 * activation, you can no longer use it to register additional managed nodes. Deleting an activation
 * doesn't de-register managed nodes. You must manually de-register managed nodes.
 */
export declare const deleteActivation: API.OperationMethod<DeleteActivationRequest & RegionInput, DeleteActivationResult, DeleteActivationError, Creds | HttpClient.HttpClient>;
export type DeleteAssociationError = AssociationDoesNotExist | InternalServerError | InvalidDocument | InvalidInstanceId | TooManyUpdates | CommonErrors;
/**
 * Disassociates the specified Amazon Web Services Systems Manager document (SSM document) from the specified managed
 * node. If you created the association by using the `Targets` parameter, then you must
 * delete the association by using the association ID.
 *
 * When you disassociate a document from a managed node, it doesn't change the configuration of
 * the node. To change the configuration state of a managed node after you disassociate a document,
 * you must create a new document with the desired configuration and associate it with the
 * node.
 */
export declare const deleteAssociation: API.OperationMethod<DeleteAssociationRequest & RegionInput, DeleteAssociationResult, DeleteAssociationError, Creds | HttpClient.HttpClient>;
export type DeleteCloudConnectorError = ConflictException | InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a cloud connector.
 */
export declare const deleteCloudConnector: API.OperationMethod<DeleteCloudConnectorRequest & RegionInput, DeleteCloudConnectorResult, DeleteCloudConnectorError, Creds | HttpClient.HttpClient>;
export type DeleteDocumentError = AssociatedInstances | InternalServerError | InvalidDocument | InvalidDocumentOperation | TooManyUpdates | CommonErrors;
/**
 * Deletes the Amazon Web Services Systems Manager document (SSM document) and all managed node associations to the
 * document.
 *
 * Before you delete the document, we recommend that you use DeleteAssociation to disassociate all managed nodes that are associated with the document.
 */
export declare const deleteDocument: API.OperationMethod<DeleteDocumentRequest & RegionInput, DeleteDocumentResult, DeleteDocumentError, Creds | HttpClient.HttpClient>;
export type DeleteInventoryError = InternalServerError | InvalidDeleteInventoryParametersException | InvalidInventoryRequestException | InvalidOptionException | InvalidTypeNameException | CommonErrors;
/**
 * Delete a custom inventory type or the data associated with a custom Inventory type. Deleting
 * a custom inventory type is also referred to as deleting a custom inventory schema.
 */
export declare const deleteInventory: API.OperationMethod<DeleteInventoryRequest & RegionInput, DeleteInventoryResult, DeleteInventoryError, Creds | HttpClient.HttpClient>;
export type DeleteMaintenanceWindowError = InternalServerError | CommonErrors;
/**
 * Deletes a maintenance window.
 */
export declare const deleteMaintenanceWindow: API.OperationMethod<DeleteMaintenanceWindowRequest & RegionInput, DeleteMaintenanceWindowResult, DeleteMaintenanceWindowError, Creds | HttpClient.HttpClient>;
export type DeleteOpsItemError = InternalServerError | OpsItemInvalidParameterException | CommonErrors;
/**
 * Delete an OpsItem. You must have permission in Identity and Access Management (IAM) to
 * delete an OpsItem.
 *
 * Note the following important information about this operation.
 *
 * - Deleting an OpsItem is irreversible. You can't restore a deleted OpsItem.
 *
 * - This operation uses an *eventual consistency model*, which means the
 * system can take a few minutes to complete this operation. If you delete an OpsItem and
 * immediately call, for example, GetOpsItem, the deleted OpsItem might still
 * appear in the response.
 *
 * - This operation is idempotent. The system doesn't throw an exception if you repeatedly
 * call this operation for the same OpsItem. If the first call is successful, all additional calls
 * return the same successful response as the first call.
 *
 * - This operation doesn't support cross-account calls. A delegated administrator or
 * management account can't delete OpsItems in other accounts, even if OpsCenter has been set up for
 * cross-account administration. For more information about cross-account administration, see
 * Setting up
 * OpsCenter to centrally manage OpsItems across accounts in the *Systems Manager User Guide*.
 */
export declare const deleteOpsItem: API.OperationMethod<DeleteOpsItemRequest & RegionInput, DeleteOpsItemResponse, DeleteOpsItemError, Creds | HttpClient.HttpClient>;
export type DeleteOpsMetadataError = InternalServerError | OpsMetadataInvalidArgumentException | OpsMetadataNotFoundException | CommonErrors;
/**
 * Delete OpsMetadata related to an application.
 */
export declare const deleteOpsMetadata: API.OperationMethod<DeleteOpsMetadataRequest & RegionInput, DeleteOpsMetadataResult, DeleteOpsMetadataError, Creds | HttpClient.HttpClient>;
export type DeleteParameterError = InternalServerError | ParameterNotFound | CommonErrors;
/**
 * Delete a parameter from the system. After deleting a parameter, wait for at least 30 seconds
 * to create a parameter with the same name.
 *
 * This operation is authorized against the `ssm:DeleteParameter` action. Denying
 * that action alone doesn't restrict DeleteParameters, which is authorized
 * against its own action. For more information, see Restricting access to
 * specific parameters and paths in the *Amazon Web Services Systems Manager User Guide*.
 */
export declare const deleteParameter: API.OperationMethod<DeleteParameterRequest & RegionInput, DeleteParameterResult, DeleteParameterError, Creds | HttpClient.HttpClient>;
export type DeleteParametersError = InternalServerError | CommonErrors;
/**
 * Delete a list of parameters. After deleting a parameter, wait for at least 30 seconds to
 * create a parameter with the same name.
 *
 * This operation is authorized against the `ssm:DeleteParameters` action, not
 * against `ssm:DeleteParameter`. Denying `ssm:DeleteParameter` for a
 * parameter doesn't prevent a principal from deleting that parameter with this operation. For more
 * information, see Restricting access to
 * specific parameters and paths in the *Amazon Web Services Systems Manager User Guide*.
 */
export declare const deleteParameters: API.OperationMethod<DeleteParametersRequest & RegionInput, DeleteParametersResult, DeleteParametersError, Creds | HttpClient.HttpClient>;
export type DeletePatchBaselineError = InternalServerError | ResourceInUseException | CommonErrors;
/**
 * Deletes a patch baseline.
 */
export declare const deletePatchBaseline: API.OperationMethod<DeletePatchBaselineRequest & RegionInput, DeletePatchBaselineResult, DeletePatchBaselineError, Creds | HttpClient.HttpClient>;
export type DeleteResourceDataSyncError = InternalServerError | ResourceDataSyncInvalidConfigurationException | ResourceDataSyncNotFoundException | CommonErrors;
/**
 * Deletes a resource data sync configuration. After the configuration is deleted, changes to
 * data on managed nodes are no longer synced to or from the target. Deleting a sync configuration
 * doesn't delete data.
 */
export declare const deleteResourceDataSync: API.OperationMethod<DeleteResourceDataSyncRequest & RegionInput, DeleteResourceDataSyncResult, DeleteResourceDataSyncError, Creds | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerError | MalformedResourcePolicyDocumentException | ResourceNotFoundException | ResourcePolicyConflictException | ResourcePolicyInvalidParameterException | ResourcePolicyNotFoundException | CommonErrors;
/**
 * Deletes a Systems Manager resource policy. A resource policy helps you to define the IAM entity (for example, an Amazon Web Services account) that can manage your Systems Manager resources. The following
 * resources support Systems Manager resource policies.
 *
 * - `OpsItemGroup` - The resource policy for `OpsItemGroup` enables
 * Amazon Web Services accounts to view and interact with OpsCenter operational work items (OpsItems).
 *
 * - `Parameter` - The resource policy is used to share a parameter with other
 * accounts using Resource Access Manager (RAM). For more information about
 * cross-account sharing of parameters, see Working with
 * shared parameters in the *Amazon Web Services Systems Manager User Guide*.
 *
 * - `Document` - Shares the document using Resource Access Manager (RAM). For more information about sharing documents, see Sharing
 * Systems Manager documents in the *Amazon Web Services Systems Manager User Guide*.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Creds | HttpClient.HttpClient>;
export type DeregisterDefaultHostManagementConfigurationError = InternalServerError | CommonErrors;
/**
 * Removes the Default Host Management Configuration (DHMC) for an Amazon Web Services account and
 * Amazon Web Services Region. After you deregister DHMC, Amazon EC2 instances are no longer automatically managed as
 * managed nodes by Amazon Web Services Systems Manager.
 *
 * To use this operation, you must have the following permissions:
 *
 * - You need the `ssm:GetServiceSetting` and `ssm:ResetServiceSetting`
 * permissions for the `/ssm/managed-instance/default-ec2-instance-management-role`
 * service setting.
 *
 * If the registered role is service-managed, you also need the `iam:DeleteRole`
 * permission so that Amazon Web Services Systems Manager can remove the role it created.
 */
export declare const deregisterDefaultHostManagementConfiguration: API.OperationMethod<DeregisterDefaultHostManagementConfigurationRequest & RegionInput, DeregisterDefaultHostManagementConfigurationResult, DeregisterDefaultHostManagementConfigurationError, Creds | HttpClient.HttpClient>;
export type DeregisterManagedInstanceError = InternalServerError | InvalidInstanceId | CommonErrors;
/**
 * Removes the server or virtual machine from the list of registered servers.
 *
 * If you want to reregister an on-premises server, edge device, or VM, you must use a
 * different Activation Code and Activation ID than used to register the machine previously. The
 * Activation Code and Activation ID must not have already been used on the maximum number of
 * activations specified when they were created. For more information, see Deregistering
 * managed nodes in a hybrid and multicloud environment in the
 * *Amazon Web Services Systems Manager User Guide*.
 */
export declare const deregisterManagedInstance: API.OperationMethod<DeregisterManagedInstanceRequest & RegionInput, DeregisterManagedInstanceResult, DeregisterManagedInstanceError, Creds | HttpClient.HttpClient>;
export type DeregisterPatchBaselineForPatchGroupError = InternalServerError | InvalidResourceId | CommonErrors;
/**
 * Removes a patch group from a patch baseline.
 */
export declare const deregisterPatchBaselineForPatchGroup: API.OperationMethod<DeregisterPatchBaselineForPatchGroupRequest & RegionInput, DeregisterPatchBaselineForPatchGroupResult, DeregisterPatchBaselineForPatchGroupError, Creds | HttpClient.HttpClient>;
export type DeregisterTargetFromMaintenanceWindowError = DoesNotExistException | InternalServerError | TargetInUseException | CommonErrors;
/**
 * Removes a target from a maintenance window.
 */
export declare const deregisterTargetFromMaintenanceWindow: API.OperationMethod<DeregisterTargetFromMaintenanceWindowRequest & RegionInput, DeregisterTargetFromMaintenanceWindowResult, DeregisterTargetFromMaintenanceWindowError, Creds | HttpClient.HttpClient>;
export type DeregisterTaskFromMaintenanceWindowError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Removes a task from a maintenance window.
 */
export declare const deregisterTaskFromMaintenanceWindow: API.OperationMethod<DeregisterTaskFromMaintenanceWindowRequest & RegionInput, DeregisterTaskFromMaintenanceWindowResult, DeregisterTaskFromMaintenanceWindowError, Creds | HttpClient.HttpClient>;
export type DescribeActivationsError = InternalServerError | InvalidFilter | InvalidNextToken | CommonErrors;
/**
 * Describes details about the activation, such as the date and time the activation was
 * created, its expiration date, the Identity and Access Management (IAM) role assigned to
 * the managed nodes in the activation, and the number of nodes registered by using this
 * activation.
 */
export declare const describeActivations: API.PaginatedOperationMethod<DescribeActivationsRequest & RegionInput, DescribeActivationsResult, DescribeActivationsError, Creds | HttpClient.HttpClient, Activation>;
export type DescribeAssociationError = AssociationDoesNotExist | InternalServerError | InvalidAssociationVersion | InvalidDocument | InvalidInstanceId | CommonErrors;
/**
 * Describes the association for the specified target or managed node. If you created the
 * association by using the `Targets` parameter, then you must retrieve the association
 * by using the association ID.
 */
export declare const describeAssociation: API.OperationMethod<DescribeAssociationRequest & RegionInput, DescribeAssociationResult, DescribeAssociationError, Creds | HttpClient.HttpClient>;
export type DescribeAssociationExecutionsError = AssociationDoesNotExist | InternalServerError | InvalidNextToken | CommonErrors;
/**
 * Views all executions for a specific association ID.
 */
export declare const describeAssociationExecutions: API.PaginatedOperationMethod<DescribeAssociationExecutionsRequest & RegionInput, DescribeAssociationExecutionsResult, DescribeAssociationExecutionsError, Creds | HttpClient.HttpClient, AssociationExecution>;
export type DescribeAssociationExecutionTargetsError = AssociationDoesNotExist | AssociationExecutionDoesNotExist | InternalServerError | InvalidNextToken | CommonErrors;
/**
 * Views information about a specific execution of a specific association.
 */
export declare const describeAssociationExecutionTargets: API.PaginatedOperationMethod<DescribeAssociationExecutionTargetsRequest & RegionInput, DescribeAssociationExecutionTargetsResult, DescribeAssociationExecutionTargetsError, Creds | HttpClient.HttpClient, AssociationExecutionTarget>;
export type DescribeAutomationExecutionsError = InternalServerError | InvalidFilterKey | InvalidFilterValue | InvalidNextToken | CommonErrors;
/**
 * Provides details about all active and terminated Automation executions.
 */
export declare const describeAutomationExecutions: API.PaginatedOperationMethod<DescribeAutomationExecutionsRequest & RegionInput, DescribeAutomationExecutionsResult, DescribeAutomationExecutionsError, Creds | HttpClient.HttpClient, AutomationExecutionMetadata>;
export type DescribeAutomationStepExecutionsError = AutomationExecutionNotFoundException | InternalServerError | InvalidFilterKey | InvalidFilterValue | InvalidNextToken | CommonErrors;
/**
 * Information about all active and terminated step executions in an Automation
 * workflow.
 */
export declare const describeAutomationStepExecutions: API.PaginatedOperationMethod<DescribeAutomationStepExecutionsRequest & RegionInput, DescribeAutomationStepExecutionsResult, DescribeAutomationStepExecutionsError, Creds | HttpClient.HttpClient, StepExecution>;
export type DescribeAvailablePatchesError = InternalServerError | CommonErrors;
/**
 * Lists all patches eligible to be included in a patch baseline.
 *
 * Currently, `DescribeAvailablePatches` supports only the Amazon Linux 1, Amazon
 * Linux 2, and Windows Server operating systems.
 */
export declare const describeAvailablePatches: API.PaginatedOperationMethod<DescribeAvailablePatchesRequest & RegionInput, DescribeAvailablePatchesResult, DescribeAvailablePatchesError, Creds | HttpClient.HttpClient, Patch>;
export type DescribeDocumentError = InternalServerError | InvalidDocument | InvalidDocumentVersion | CommonErrors;
/**
 * Describes the specified Amazon Web Services Systems Manager document (SSM document).
 */
export declare const describeDocument: API.OperationMethod<DescribeDocumentRequest & RegionInput, DescribeDocumentResult, DescribeDocumentError, Creds | HttpClient.HttpClient>;
export type DescribeDocumentPermissionError = InternalServerError | InvalidDocument | InvalidDocumentOperation | InvalidNextToken | InvalidPermissionType | CommonErrors;
/**
 * Describes the permissions for a Amazon Web Services Systems Manager document (SSM document). If you created the
 * document, you are the owner. If a document is shared, it can either be shared privately (by
 * specifying a user's Amazon Web Services account ID) or publicly (*All*).
 */
export declare const describeDocumentPermission: API.OperationMethod<DescribeDocumentPermissionRequest & RegionInput, DescribeDocumentPermissionResponse, DescribeDocumentPermissionError, Creds | HttpClient.HttpClient>;
export type DescribeEffectiveInstanceAssociationsError = InternalServerError | InvalidInstanceId | InvalidNextToken | CommonErrors;
/**
 * All associations for the managed nodes.
 */
export declare const describeEffectiveInstanceAssociations: API.PaginatedOperationMethod<DescribeEffectiveInstanceAssociationsRequest & RegionInput, DescribeEffectiveInstanceAssociationsResult, DescribeEffectiveInstanceAssociationsError, Creds | HttpClient.HttpClient, InstanceAssociation>;
export type DescribeEffectivePatchesForPatchBaselineError = DoesNotExistException | InternalServerError | InvalidResourceId | UnsupportedOperatingSystem | CommonErrors;
/**
 * Retrieves the current effective patches (the patch and the approval state) for the specified
 * patch baseline. Applies to patch baselines for Windows only.
 */
export declare const describeEffectivePatchesForPatchBaseline: API.PaginatedOperationMethod<DescribeEffectivePatchesForPatchBaselineRequest & RegionInput, DescribeEffectivePatchesForPatchBaselineResult, DescribeEffectivePatchesForPatchBaselineError, Creds | HttpClient.HttpClient, EffectivePatch>;
export type DescribeInstanceAssociationsStatusError = InternalServerError | InvalidInstanceId | InvalidNextToken | CommonErrors;
/**
 * The status of the associations for the managed nodes.
 */
export declare const describeInstanceAssociationsStatus: API.PaginatedOperationMethod<DescribeInstanceAssociationsStatusRequest & RegionInput, DescribeInstanceAssociationsStatusResult, DescribeInstanceAssociationsStatusError, Creds | HttpClient.HttpClient, InstanceAssociationStatusInfo>;
export type DescribeInstanceInformationError = InternalServerError | InvalidFilterKey | InvalidInstanceId | InvalidInstanceInformationFilterValue | InvalidNextToken | CommonErrors;
/**
 * Provides information about one or more of your managed nodes, including the operating system
 * platform, SSM Agent version, association status, and IP address. This operation does not return
 * information for nodes that are either Stopped or Terminated.
 *
 * If you specify one or more node IDs, the operation returns information for those managed
 * nodes. If you don't specify node IDs, it returns information for all your managed nodes. If you
 * specify a node ID that isn't valid or a node that you don't own, you receive an error.
 *
 * The `IamRole` field returned for this API operation is the role assigned to an
 * Amazon EC2 instance configured with a Systems Manager Quick Setup host management configuration or
 * the role assigned to an on-premises managed node.
 */
export declare const describeInstanceInformation: API.PaginatedOperationMethod<DescribeInstanceInformationRequest & RegionInput, DescribeInstanceInformationResult, DescribeInstanceInformationError, Creds | HttpClient.HttpClient, InstanceInformation>;
export type DescribeInstancePatchesError = InternalServerError | InvalidFilter | InvalidInstanceId | InvalidNextToken | CommonErrors;
/**
 * Retrieves information about the patches on the specified managed node and their state
 * relative to the patch baseline being used for the node.
 */
export declare const describeInstancePatches: API.PaginatedOperationMethod<DescribeInstancePatchesRequest & RegionInput, DescribeInstancePatchesResult, DescribeInstancePatchesError, Creds | HttpClient.HttpClient, PatchComplianceData>;
export type DescribeInstancePatchStatesError = InternalServerError | InvalidNextToken | CommonErrors;
/**
 * Retrieves the high-level patch state of one or more managed nodes.
 */
export declare const describeInstancePatchStates: API.PaginatedOperationMethod<DescribeInstancePatchStatesRequest & RegionInput, DescribeInstancePatchStatesResult, DescribeInstancePatchStatesError, Creds | HttpClient.HttpClient, InstancePatchState>;
export type DescribeInstancePatchStatesForPatchGroupError = InternalServerError | InvalidFilter | InvalidNextToken | CommonErrors;
/**
 * Retrieves the high-level patch state for the managed nodes in the specified patch
 * group.
 */
export declare const describeInstancePatchStatesForPatchGroup: API.PaginatedOperationMethod<DescribeInstancePatchStatesForPatchGroupRequest & RegionInput, DescribeInstancePatchStatesForPatchGroupResult, DescribeInstancePatchStatesForPatchGroupError, Creds | HttpClient.HttpClient, InstancePatchState>;
export type DescribeInstancePropertiesError = InternalServerError | InvalidActivationId | InvalidDocument | InvalidFilterKey | InvalidInstanceId | InvalidInstancePropertyFilterValue | InvalidNextToken | CommonErrors;
/**
 * An API operation used by the Systems Manager console to display information about Systems Manager managed
 * nodes.
 */
export declare const describeInstanceProperties: API.PaginatedOperationMethod<DescribeInstancePropertiesRequest & RegionInput, DescribeInstancePropertiesResult, DescribeInstancePropertiesError, Creds | HttpClient.HttpClient, InstanceProperty>;
export type DescribeInventoryDeletionsError = InternalServerError | InvalidDeletionIdException | InvalidNextToken | CommonErrors;
/**
 * Describes a specific delete inventory operation.
 */
export declare const describeInventoryDeletions: API.PaginatedOperationMethod<DescribeInventoryDeletionsRequest & RegionInput, DescribeInventoryDeletionsResult, DescribeInventoryDeletionsError, Creds | HttpClient.HttpClient, InventoryDeletionStatusItem>;
export type DescribeMaintenanceWindowExecutionsError = InternalServerError | CommonErrors;
/**
 * Lists the executions of a maintenance window. This includes information about when the
 * maintenance window was scheduled to be active, and information about tasks registered and run
 * with the maintenance window.
 */
export declare const describeMaintenanceWindowExecutions: API.PaginatedOperationMethod<DescribeMaintenanceWindowExecutionsRequest & RegionInput, DescribeMaintenanceWindowExecutionsResult, DescribeMaintenanceWindowExecutionsError, Creds | HttpClient.HttpClient, MaintenanceWindowExecution>;
export type DescribeMaintenanceWindowExecutionTaskInvocationsError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Retrieves the individual task executions (one per target) for a particular task run as part
 * of a maintenance window execution.
 */
export declare const describeMaintenanceWindowExecutionTaskInvocations: API.PaginatedOperationMethod<DescribeMaintenanceWindowExecutionTaskInvocationsRequest & RegionInput, DescribeMaintenanceWindowExecutionTaskInvocationsResult, DescribeMaintenanceWindowExecutionTaskInvocationsError, Creds | HttpClient.HttpClient, MaintenanceWindowExecutionTaskInvocationIdentity>;
export type DescribeMaintenanceWindowExecutionTasksError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * For a given maintenance window execution, lists the tasks that were run.
 */
export declare const describeMaintenanceWindowExecutionTasks: API.PaginatedOperationMethod<DescribeMaintenanceWindowExecutionTasksRequest & RegionInput, DescribeMaintenanceWindowExecutionTasksResult, DescribeMaintenanceWindowExecutionTasksError, Creds | HttpClient.HttpClient, MaintenanceWindowExecutionTaskIdentity>;
export type DescribeMaintenanceWindowsError = InternalServerError | CommonErrors;
/**
 * Retrieves the maintenance windows in an Amazon Web Services account.
 */
export declare const describeMaintenanceWindows: API.PaginatedOperationMethod<DescribeMaintenanceWindowsRequest & RegionInput, DescribeMaintenanceWindowsResult, DescribeMaintenanceWindowsError, Creds | HttpClient.HttpClient, MaintenanceWindowIdentity>;
export type DescribeMaintenanceWindowScheduleError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Retrieves information about upcoming executions of a maintenance window.
 */
export declare const describeMaintenanceWindowSchedule: API.PaginatedOperationMethod<DescribeMaintenanceWindowScheduleRequest & RegionInput, DescribeMaintenanceWindowScheduleResult, DescribeMaintenanceWindowScheduleError, Creds | HttpClient.HttpClient, ScheduledWindowExecution>;
export type DescribeMaintenanceWindowsForTargetError = InternalServerError | CommonErrors;
/**
 * Retrieves information about the maintenance window targets or tasks that a managed node is
 * associated with.
 */
export declare const describeMaintenanceWindowsForTarget: API.PaginatedOperationMethod<DescribeMaintenanceWindowsForTargetRequest & RegionInput, DescribeMaintenanceWindowsForTargetResult, DescribeMaintenanceWindowsForTargetError, Creds | HttpClient.HttpClient, MaintenanceWindowIdentityForTarget>;
export type DescribeMaintenanceWindowTargetsError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Lists the targets registered with the maintenance window.
 */
export declare const describeMaintenanceWindowTargets: API.PaginatedOperationMethod<DescribeMaintenanceWindowTargetsRequest & RegionInput, DescribeMaintenanceWindowTargetsResult, DescribeMaintenanceWindowTargetsError, Creds | HttpClient.HttpClient, MaintenanceWindowTarget>;
export type DescribeMaintenanceWindowTasksError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Lists the tasks in a maintenance window.
 *
 * For maintenance window tasks without a specified target, you can't supply values for
 * `--max-errors` and `--max-concurrency`. Instead, the system inserts a
 * placeholder value of `1`, which may be reported in the response to this command.
 * These values don't affect the running of your task and can be ignored.
 */
export declare const describeMaintenanceWindowTasks: API.PaginatedOperationMethod<DescribeMaintenanceWindowTasksRequest & RegionInput, DescribeMaintenanceWindowTasksResult, DescribeMaintenanceWindowTasksError, Creds | HttpClient.HttpClient, MaintenanceWindowTask>;
export type DescribeOpsItemsError = InternalServerError | CommonErrors;
/**
 * Query a set of OpsItems. You must have permission in Identity and Access Management (IAM) to query a list of OpsItems. For more information, see Set up OpsCenter in the
 * *Amazon Web Services Systems Manager User Guide*.
 *
 * Operations engineers and IT professionals use Amazon Web Services Systems Manager OpsCenter to view, investigate, and
 * remediate operational issues impacting the performance and health of their Amazon Web Services resources. For
 * more information, see Amazon Web Services Systems Manager OpsCenter in the
 * *Amazon Web Services Systems Manager User Guide*.
 */
export declare const describeOpsItems: API.PaginatedOperationMethod<DescribeOpsItemsRequest & RegionInput, DescribeOpsItemsResponse, DescribeOpsItemsError, Creds | HttpClient.HttpClient, OpsItemSummary>;
export type DescribeParametersError = InternalServerError | InvalidFilterKey | InvalidFilterOption | InvalidFilterValue | InvalidNextToken | CommonErrors;
/**
 * Lists the parameters in your Amazon Web Services account or the parameters shared with you when you enable
 * the Shared option.
 *
 * Request results are returned on a best-effort basis. If you specify `MaxResults`
 * in the request, the response includes information up to the limit specified. The number of items
 * returned, however, can be between zero and the value of `MaxResults`. If the service
 * reaches an internal limit while processing the results, it stops the operation and returns the
 * matching values up to that point and a `NextToken`. You can specify the
 * `NextToken` in a subsequent call to get the next set of results.
 *
 * Parameter names can't contain spaces. The service removes any spaces specified for the
 * beginning or end of a parameter name. If the specified name for a parameter contains spaces
 * between characters, the request fails with a `ValidationException` error.
 *
 * If you change the KMS key alias for the KMS key used to encrypt a parameter,
 * then you must also update the key alias the parameter uses to reference KMS. Otherwise,
 * `DescribeParameters` retrieves whatever the original key alias was
 * referencing.
 */
export declare const describeParameters: API.PaginatedOperationMethod<DescribeParametersRequest & RegionInput, DescribeParametersResult, DescribeParametersError, Creds | HttpClient.HttpClient, unknown>;
export type DescribePatchBaselinesError = InternalServerError | CommonErrors;
/**
 * Lists the patch baselines in your Amazon Web Services account.
 */
export declare const describePatchBaselines: API.PaginatedOperationMethod<DescribePatchBaselinesRequest & RegionInput, DescribePatchBaselinesResult, DescribePatchBaselinesError, Creds | HttpClient.HttpClient, PatchBaselineIdentity>;
export type DescribePatchGroupsError = InternalServerError | CommonErrors;
/**
 * Lists all patch groups that have been registered with patch baselines.
 */
export declare const describePatchGroups: API.PaginatedOperationMethod<DescribePatchGroupsRequest & RegionInput, DescribePatchGroupsResult, DescribePatchGroupsError, Creds | HttpClient.HttpClient, PatchGroupPatchBaselineMapping>;
export type DescribePatchGroupStateError = InternalServerError | InvalidNextToken | CommonErrors;
/**
 * Returns high-level aggregated patch compliance state information for a patch group.
 */
export declare const describePatchGroupState: API.OperationMethod<DescribePatchGroupStateRequest & RegionInput, DescribePatchGroupStateResult, DescribePatchGroupStateError, Creds | HttpClient.HttpClient>;
export type DescribePatchPropertiesError = InternalServerError | CommonErrors;
/**
 * Lists the properties of available patches organized by product, product family,
 * classification, severity, and other properties of available patches. You can use the reported
 * properties in the filters you specify in requests for operations such as CreatePatchBaseline, UpdatePatchBaseline, DescribeAvailablePatches, and DescribePatchBaselines.
 *
 * The following section lists the properties that can be used in filters for each major
 * operating system type:
 *
 * ### AMAZON_LINUX
 *
 * Valid properties: `PRODUCT` | `CLASSIFICATION` |
 * `SEVERITY`
 *
 * ### AMAZON_LINUX_2
 *
 * Valid properties: `PRODUCT` | `CLASSIFICATION` |
 * `SEVERITY`
 *
 * ### AMAZON_LINUX_2023
 *
 * Valid properties: `PRODUCT` | `CLASSIFICATION` |
 * `SEVERITY`
 *
 * ### CENTOS
 *
 * Valid properties: `PRODUCT` | `CLASSIFICATION` |
 * `SEVERITY`
 *
 * ### DEBIAN
 *
 * Valid properties: `PRODUCT` | `PRIORITY`
 *
 * ### MACOS
 *
 * Valid properties: `PRODUCT` | `CLASSIFICATION`
 *
 * ### ORACLE_LINUX
 *
 * Valid properties: `PRODUCT` | `CLASSIFICATION` |
 * `SEVERITY`
 *
 * ### REDHAT_ENTERPRISE_LINUX
 *
 * Valid properties: `PRODUCT` | `CLASSIFICATION` |
 * `SEVERITY`
 *
 * ### SUSE
 *
 * Valid properties: `PRODUCT` | `CLASSIFICATION` |
 * `SEVERITY`
 *
 * ### UBUNTU
 *
 * Valid properties: `PRODUCT` | `PRIORITY`
 *
 * ### WINDOWS
 *
 * Valid properties: `PRODUCT` | `PRODUCT_FAMILY` |
 * `CLASSIFICATION` | `MSRC_SEVERITY`
 */
export declare const describePatchProperties: API.PaginatedOperationMethod<DescribePatchPropertiesRequest & RegionInput, DescribePatchPropertiesResult, DescribePatchPropertiesError, Creds | HttpClient.HttpClient, {
    [key: string]: string | undefined;
}>;
export type DescribeSessionsError = InternalServerError | InvalidFilterKey | InvalidNextToken | CommonErrors;
/**
 * Retrieves a list of all active sessions (both connected and disconnected) or terminated
 * sessions from the past 30 days.
 */
export declare const describeSessions: API.PaginatedOperationMethod<DescribeSessionsRequest & RegionInput, DescribeSessionsResponse, DescribeSessionsError, Creds | HttpClient.HttpClient, Session>;
export type DisassociateOpsItemRelatedItemError = InternalServerError | OpsItemConflictException | OpsItemInvalidParameterException | OpsItemNotFoundException | OpsItemRelatedItemAssociationNotFoundException | CommonErrors;
/**
 * Deletes the association between an OpsItem and a related item. For example, this API
 * operation can delete an Incident Manager incident from an OpsItem. Incident Manager is a tool in
 * Amazon Web Services Systems Manager.
 */
export declare const disassociateOpsItemRelatedItem: API.OperationMethod<DisassociateOpsItemRelatedItemRequest & RegionInput, DisassociateOpsItemRelatedItemResponse, DisassociateOpsItemRelatedItemError, Creds | HttpClient.HttpClient>;
export type GetAccessTokenError = AccessDeniedException | InternalServerError | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a credentials set to be used with just-in-time node access.
 */
export declare const getAccessToken: API.OperationMethod<GetAccessTokenRequest & RegionInput, GetAccessTokenResponse, GetAccessTokenError, Creds | HttpClient.HttpClient>;
export type GetAutomationExecutionError = AutomationExecutionNotFoundException | InternalServerError | CommonErrors;
/**
 * Get detailed information about a particular Automation execution.
 */
export declare const getAutomationExecution: API.OperationMethod<GetAutomationExecutionRequest & RegionInput, GetAutomationExecutionResult, GetAutomationExecutionError, Creds | HttpClient.HttpClient>;
export type GetCalendarStateError = InternalServerError | InvalidDocument | InvalidDocumentType | UnsupportedCalendarException | CommonErrors;
/**
 * Gets the state of a Amazon Web Services Systems Manager change calendar at the current time or a specified time. If
 * you specify a time, `GetCalendarState` returns the state of the calendar at that
 * specific time, and returns the next time that the change calendar state will transition. If you
 * don't specify a time, `GetCalendarState` uses the current time. Change Calendar
 * entries have two possible states: `OPEN` or `CLOSED`.
 *
 * If you specify more than one calendar in a request, the command returns the status of
 * `OPEN` only if all calendars in the request are open. If one or more calendars in the
 * request are closed, the status returned is `CLOSED`.
 *
 * For more information about Change Calendar, a tool in Amazon Web Services Systems Manager, see Amazon Web Services Systems Manager Change Calendar in the *Amazon Web Services Systems Manager User Guide*.
 */
export declare const getCalendarState: API.OperationMethod<GetCalendarStateRequest & RegionInput, GetCalendarStateResponse, GetCalendarStateError, Creds | HttpClient.HttpClient>;
export type GetCloudConnectorError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns detailed information about a cloud connector.
 */
export declare const getCloudConnector: API.OperationMethod<GetCloudConnectorRequest & RegionInput, GetCloudConnectorResult, GetCloudConnectorError, Creds | HttpClient.HttpClient>;
export type GetCommandInvocationError = InternalServerError | InvalidCommandId | InvalidInstanceId | InvalidPluginName | InvocationDoesNotExist | CommonErrors;
/**
 * Returns detailed information about command execution for an invocation or plugin. The Run
 * Command API follows an eventual consistency model, due to the distributed nature of the system
 * supporting the API. This means that the result of an API command you run that affects your
 * resources might not be immediately visible to all subsequent commands you run. You should keep
 * this in mind when you carry out an API command that immediately follows a previous API
 * command.
 *
 * `GetCommandInvocation` only gives the execution status of a plugin in a document.
 * To get the command execution status on a specific managed node, use ListCommandInvocations. To get the command execution status across managed nodes,
 * use ListCommands.
 */
export declare const getCommandInvocation: API.OperationMethod<GetCommandInvocationRequest & RegionInput, GetCommandInvocationResult, GetCommandInvocationError, Creds | HttpClient.HttpClient>;
export type GetConnectionStatusError = InternalServerError | CommonErrors;
/**
 * Retrieves the Session Manager connection status for a managed node to determine whether it is running
 * and ready to receive Session Manager connections.
 */
export declare const getConnectionStatus: API.OperationMethod<GetConnectionStatusRequest & RegionInput, GetConnectionStatusResponse, GetConnectionStatusError, Creds | HttpClient.HttpClient>;
export type GetDefaultPatchBaselineError = InternalServerError | CommonErrors;
/**
 * Retrieves the default patch baseline. Amazon Web Services Systems Manager supports creating multiple default patch
 * baselines. For example, you can create a default patch baseline for each operating system.
 *
 * If you don't specify an operating system value, the default patch baseline for Windows is
 * returned.
 */
export declare const getDefaultPatchBaseline: API.OperationMethod<GetDefaultPatchBaselineRequest & RegionInput, GetDefaultPatchBaselineResult, GetDefaultPatchBaselineError, Creds | HttpClient.HttpClient>;
export type GetDeployablePatchSnapshotForInstanceError = InternalServerError | UnsupportedFeatureRequiredException | UnsupportedOperatingSystem | CommonErrors;
/**
 * Retrieves the current snapshot for the patch baseline the managed node uses. This API is
 * primarily used by the `AWS-RunPatchBaseline` Systems Manager document (SSM document).
 *
 * If you run the command locally, such as with the Command Line Interface (CLI), the system attempts to use your local Amazon Web Services credentials and the operation fails. To avoid
 * this, you can run the command in the Amazon Web Services Systems Manager console. Use Run Command, a tool in Amazon Web Services Systems Manager,
 * with an SSM document that enables you to target a managed node with a script or command. For
 * example, run the command using the `AWS-RunShellScript` document or the
 * `AWS-RunPowerShellScript` document.
 */
export declare const getDeployablePatchSnapshotForInstance: API.OperationMethod<GetDeployablePatchSnapshotForInstanceRequest & RegionInput, GetDeployablePatchSnapshotForInstanceResult, GetDeployablePatchSnapshotForInstanceError, Creds | HttpClient.HttpClient>;
export type GetDocumentError = InternalServerError | InvalidDocument | InvalidDocumentVersion | CommonErrors;
/**
 * Gets the contents of the specified Amazon Web Services Systems Manager document (SSM document).
 */
export declare const getDocument: API.OperationMethod<GetDocumentRequest & RegionInput, GetDocumentResult, GetDocumentError, Creds | HttpClient.HttpClient>;
export type GetExecutionPreviewError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Initiates the process of retrieving an existing preview that shows the effects that running
 * a specified Automation runbook would have on the targeted resources.
 */
export declare const getExecutionPreview: API.OperationMethod<GetExecutionPreviewRequest & RegionInput, GetExecutionPreviewResponse, GetExecutionPreviewError, Creds | HttpClient.HttpClient>;
export type GetInventoryError = InternalServerError | InvalidAggregatorException | InvalidFilter | InvalidInventoryGroupException | InvalidNextToken | InvalidResultAttributeException | InvalidTypeNameException | CommonErrors;
/**
 * Query inventory information. This includes managed node status, such as `Stopped`
 * or `Terminated`.
 */
export declare const getInventory: API.PaginatedOperationMethod<GetInventoryRequest & RegionInput, GetInventoryResult, GetInventoryError, Creds | HttpClient.HttpClient, InventoryResultEntity>;
export type GetInventorySchemaError = InternalServerError | InvalidNextToken | InvalidTypeNameException | CommonErrors;
/**
 * Return a list of inventory type names for the account, or return a list of attribute names
 * for a specific Inventory item type.
 */
export declare const getInventorySchema: API.PaginatedOperationMethod<GetInventorySchemaRequest & RegionInput, GetInventorySchemaResult, GetInventorySchemaError, Creds | HttpClient.HttpClient, InventoryItemSchema>;
export type GetMaintenanceWindowError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Retrieves a maintenance window.
 */
export declare const getMaintenanceWindow: API.OperationMethod<GetMaintenanceWindowRequest & RegionInput, GetMaintenanceWindowResult, GetMaintenanceWindowError, Creds | HttpClient.HttpClient>;
export type GetMaintenanceWindowExecutionError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Retrieves details about a specific a maintenance window execution.
 */
export declare const getMaintenanceWindowExecution: API.OperationMethod<GetMaintenanceWindowExecutionRequest & RegionInput, GetMaintenanceWindowExecutionResult, GetMaintenanceWindowExecutionError, Creds | HttpClient.HttpClient>;
export type GetMaintenanceWindowExecutionTaskError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Retrieves the details about a specific task run as part of a maintenance window
 * execution.
 */
export declare const getMaintenanceWindowExecutionTask: API.OperationMethod<GetMaintenanceWindowExecutionTaskRequest & RegionInput, GetMaintenanceWindowExecutionTaskResult, GetMaintenanceWindowExecutionTaskError, Creds | HttpClient.HttpClient>;
export type GetMaintenanceWindowExecutionTaskInvocationError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Retrieves information about a specific task running on a specific target.
 */
export declare const getMaintenanceWindowExecutionTaskInvocation: API.OperationMethod<GetMaintenanceWindowExecutionTaskInvocationRequest & RegionInput, GetMaintenanceWindowExecutionTaskInvocationResult, GetMaintenanceWindowExecutionTaskInvocationError, Creds | HttpClient.HttpClient>;
export type GetMaintenanceWindowTaskError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Retrieves the details of a maintenance window task.
 *
 * For maintenance window tasks without a specified target, you can't supply values for
 * `--max-errors` and `--max-concurrency`. Instead, the system inserts a
 * placeholder value of `1`, which may be reported in the response to this command.
 * These values don't affect the running of your task and can be ignored.
 *
 * To retrieve a list of tasks in a maintenance window, instead use the DescribeMaintenanceWindowTasks command.
 */
export declare const getMaintenanceWindowTask: API.OperationMethod<GetMaintenanceWindowTaskRequest & RegionInput, GetMaintenanceWindowTaskResult, GetMaintenanceWindowTaskError, Creds | HttpClient.HttpClient>;
export type GetOpsItemError = InternalServerError | OpsItemAccessDeniedException | OpsItemNotFoundException | CommonErrors;
/**
 * Get information about an OpsItem by using the ID. You must have permission in Identity and Access Management (IAM) to view information about an OpsItem. For more information,
 * see Set
 * up OpsCenter in the *Amazon Web Services Systems Manager User Guide*.
 *
 * Operations engineers and IT professionals use Amazon Web Services Systems Manager OpsCenter to view, investigate, and
 * remediate operational issues impacting the performance and health of their Amazon Web Services resources. For
 * more information, see Amazon Web Services Systems Manager OpsCenter in the
 * *Amazon Web Services Systems Manager User Guide*.
 */
export declare const getOpsItem: API.OperationMethod<GetOpsItemRequest & RegionInput, GetOpsItemResponse, GetOpsItemError, Creds | HttpClient.HttpClient>;
export type GetOpsMetadataError = InternalServerError | OpsMetadataInvalidArgumentException | OpsMetadataNotFoundException | CommonErrors;
/**
 * View operational metadata related to an application in Application Manager.
 */
export declare const getOpsMetadata: API.OperationMethod<GetOpsMetadataRequest & RegionInput, GetOpsMetadataResult, GetOpsMetadataError, Creds | HttpClient.HttpClient>;
export type GetOpsSummaryError = InternalServerError | InvalidAggregatorException | InvalidFilter | InvalidNextToken | InvalidTypeNameException | ResourceDataSyncNotFoundException | CommonErrors;
/**
 * View a summary of operations metadata (OpsData) based on specified filters and aggregators.
 * OpsData can include information about Amazon Web Services Systems Manager OpsCenter operational workitems (OpsItems) as
 * well as information about any Amazon Web Services resource or service configured to report OpsData to Amazon Web Services Systems Manager
 * Explorer.
 */
export declare const getOpsSummary: API.PaginatedOperationMethod<GetOpsSummaryRequest & RegionInput, GetOpsSummaryResult, GetOpsSummaryError, Creds | HttpClient.HttpClient, OpsEntity>;
export type GetParameterError = InternalServerError | InvalidKeyId | ParameterNotFound | ParameterVersionNotFound | CommonErrors;
/**
 * Get information about a single parameter by specifying the parameter name.
 *
 * Parameter names can't contain spaces. The service removes any spaces specified for the
 * beginning or end of a parameter name. If the specified name for a parameter contains spaces
 * between characters, the request fails with a `ValidationException` error.
 *
 * To get information about more than one parameter at a time, use the GetParameters operation.
 *
 * This operation is authorized against the `ssm:GetParameter` action. Denying that
 * action alone doesn't restrict GetParameters, GetParameterHistory, or GetParametersByPath, each of which is
 * authorized against its own action. For more information, see How Parameter Store
 * authorizes parameter retrieval in the *Amazon Web Services Systems Manager User Guide*.
 *
 * Parameter Store throughput defines the number of API transactions per second (TPS) that
 * Systems Manager can process. This applies to `GetParameter`,
 * `GetParameters`, and `PutParameter` API calls for your Amazon Web Services account and
 * Amazon Web Services Region. By default, Parameter Store is configured with a standard throughput quota suitable
 * for low- to moderate-volume workloads. Applications that retrieve configuration data infrequently
 * or operate at smaller scale can use this default setting without additional cost.
 *
 * For higher-volume workloads, you can enable higher throughput. This increases the maximum
 * number of supported transactions per second for your account and Region. Increased throughput
 * supports applications and workloads that need concurrent access to multiple parameters. If you
 * experience `ThrottlingException: Rate exceeded` errors, enable higher throughput. For
 * more information, see Changing Parameter Store
 * throughput.
 */
export declare const getParameter: API.OperationMethod<GetParameterRequest & RegionInput, GetParameterResult, GetParameterError, Creds | HttpClient.HttpClient>;
export type GetParameterHistoryError = InternalServerError | InvalidKeyId | InvalidNextToken | ParameterNotFound | CommonErrors;
/**
 * Retrieves the history of all changes to a parameter.
 *
 * Parameter names can't contain spaces. The service removes any spaces specified for the
 * beginning or end of a parameter name. If the specified name for a parameter contains spaces
 * between characters, the request fails with a `ValidationException` error.
 *
 * If you change the KMS key alias for the KMS key used to encrypt a parameter,
 * then you must also update the key alias the parameter uses to reference KMS. Otherwise,
 * `GetParameterHistory` retrieves whatever the original key alias was
 * referencing.
 *
 * This operation is authorized against the `ssm:GetParameterHistory` action, not
 * against `ssm:GetParameter`. Because parameter history includes every version of a
 * parameter, including the current one, a principal who is denied
 * `ssm:GetParameter`, `ssm:GetParameters`, and
 * `ssm:GetParametersByPath` but allowed `ssm:GetParameterHistory` can still
 * read the current value. To restrict access to a parameter value, deny every action that can
 * return it. For more information, see
 * How Parameter Store
 * authorizes parameter retrieval in the *Amazon Web Services Systems Manager User Guide*.
 */
export declare const getParameterHistory: API.PaginatedOperationMethod<GetParameterHistoryRequest & RegionInput, GetParameterHistoryResult, GetParameterHistoryError, Creds | HttpClient.HttpClient, unknown>;
export type GetParametersError = InternalServerError | InvalidKeyId | CommonErrors;
/**
 * Get information about one or more parameters by specifying multiple parameter names.
 *
 * To get information about a single parameter, you can use the GetParameter
 * operation instead.
 *
 * This operation is authorized against the `ssm:GetParameters` action, not against
 * `ssm:GetParameter`. Denying `ssm:GetParameter` for a parameter doesn't
 * prevent a principal from retrieving that parameter with this operation. To restrict access to a
 * parameter value, deny every action that can return it. For more information, see How Parameter Store
 * authorizes parameter retrieval in the *Amazon Web Services Systems Manager User Guide*.
 *
 * Parameter names can't contain spaces. The service removes any spaces specified for the
 * beginning or end of a parameter name. If the specified name for a parameter contains spaces
 * between characters, the request fails with a `ValidationException` error.
 *
 * Parameter Store throughput defines the number of API transactions per second (TPS) that
 * Systems Manager can process. This applies to `GetParameter`,
 * `GetParameters`, and `PutParameter` API calls for your Amazon Web Services account and
 * Amazon Web Services Region. By default, Parameter Store is configured with a standard throughput quota suitable
 * for low- to moderate-volume workloads. Applications that retrieve configuration data infrequently
 * or operate at smaller scale can use this default setting without additional cost.
 *
 * For higher-volume workloads, you can enable higher throughput. This increases the maximum
 * number of supported transactions per second for your account and Region. Increased throughput
 * supports applications and workloads that need concurrent access to multiple parameters. If you
 * experience `ThrottlingException: Rate exceeded` errors, enable higher throughput. For
 * more information, see Changing Parameter Store
 * throughput.
 */
export declare const getParameters: API.OperationMethod<GetParametersRequest & RegionInput, GetParametersResult, GetParametersError, Creds | HttpClient.HttpClient>;
export type GetParametersByPathError = InternalServerError | InvalidFilterKey | InvalidFilterOption | InvalidFilterValue | InvalidKeyId | InvalidNextToken | CommonErrors;
/**
 * Retrieve information about one or more parameters under a specified level in a hierarchy.
 *
 * This operation is authorized against the `ssm:GetParametersByPath` action for
 * the path that you specify in the request. It isn't authorized against the individual parameters
 * that it returns, and it isn't authorized against `ssm:GetParameter`. A principal who
 * is allowed to call this operation for the path `/a` with `Recursive` set
 * to `true` receives every parameter under that path, including `/a/b`,
 * even if a policy explicitly denies access to `/a/b`.
 *
 * To prevent a parameter from being returned by this operation, deny the
 * `ssm:GetParametersByPath` action on every ancestor path that could include the
 * parameter in its results. For more information, see Restricting access to
 * specific parameters and paths in the *Amazon Web Services Systems Manager User Guide*.
 *
 * Request results are returned on a best-effort basis. If you specify `MaxResults`
 * in the request, the response includes information up to the limit specified. The number of items
 * returned, however, can be between zero and the value of `MaxResults`. If the service
 * reaches an internal limit while processing the results, it stops the operation and returns the
 * matching values up to that point and a `NextToken`. You can specify the
 * `NextToken` in a subsequent call to get the next set of results.
 *
 * Parameter names can't contain spaces. The service removes any spaces specified for the
 * beginning or end of a parameter name. If the specified name for a parameter contains spaces
 * between characters, the request fails with a `ValidationException` error.
 */
export declare const getParametersByPath: API.PaginatedOperationMethod<GetParametersByPathRequest & RegionInput, GetParametersByPathResult, GetParametersByPathError, Creds | HttpClient.HttpClient, unknown>;
export type GetPatchBaselineError = DoesNotExistException | InternalServerError | InvalidResourceId | CommonErrors;
/**
 * Retrieves information about a patch baseline.
 */
export declare const getPatchBaseline: API.OperationMethod<GetPatchBaselineRequest & RegionInput, GetPatchBaselineResult, GetPatchBaselineError, Creds | HttpClient.HttpClient>;
export type GetPatchBaselineForPatchGroupError = InternalServerError | CommonErrors;
/**
 * Retrieves the patch baseline that should be used for the specified patch group.
 */
export declare const getPatchBaselineForPatchGroup: API.OperationMethod<GetPatchBaselineForPatchGroupRequest & RegionInput, GetPatchBaselineForPatchGroupResult, GetPatchBaselineForPatchGroupError, Creds | HttpClient.HttpClient>;
export type GetResourcePoliciesError = InternalServerError | ResourceNotFoundException | ResourcePolicyInvalidParameterException | CommonErrors;
/**
 * Returns an array of the `Policy` object.
 */
export declare const getResourcePolicies: API.PaginatedOperationMethod<GetResourcePoliciesRequest & RegionInput, GetResourcePoliciesResponse, GetResourcePoliciesError, Creds | HttpClient.HttpClient, GetResourcePoliciesResponseEntry>;
export type GetServiceSettingError = InternalServerError | ServiceSettingNotFound | CommonErrors;
/**
 * `ServiceSetting` is an account-level setting for an Amazon Web Services service. This setting
 * defines how a user interacts with or uses a service or a feature of a service. For example, if an
 * Amazon Web Services service charges money to the account based on feature or service usage, then the Amazon Web Services
 * service team might create a default setting of `false`. This means the user can't use
 * this feature unless they change the setting to `true` and intentionally opt in for a
 * paid feature.
 *
 * Services map a `SettingId` object to a setting value. Amazon Web Services services teams define
 * the default value for a `SettingId`. You can't create a new `SettingId`,
 * but you can overwrite the default value if you have the `ssm:UpdateServiceSetting`
 * permission for the setting. Use the UpdateServiceSetting API operation to
 * change the default setting. Or use the ResetServiceSetting to change the value
 * back to the original value defined by the Amazon Web Services service team.
 *
 * Query the current service setting for the Amazon Web Services account.
 */
export declare const getServiceSetting: API.OperationMethod<GetServiceSettingRequest & RegionInput, GetServiceSettingResult, GetServiceSettingError, Creds | HttpClient.HttpClient>;
export type LabelParameterVersionError = InternalServerError | ParameterNotFound | ParameterVersionLabelLimitExceeded | ParameterVersionNotFound | TooManyUpdates | CommonErrors;
/**
 * A parameter label is a user-defined alias to help you manage different versions of a
 * parameter. When you modify a parameter, Amazon Web Services Systems Manager automatically saves a new version and
 * increments the version number by one. A label can help you remember the purpose of a parameter
 * when there are multiple versions.
 *
 * Parameter labels have the following requirements and restrictions.
 *
 * - A version of a parameter can have a maximum of 10 labels.
 *
 * - You can't attach the same label to different versions of the same parameter. For example,
 * if version 1 has the label Production, then you can't attach Production to version 2.
 *
 * - You can move a label from one version of a parameter to another.
 *
 * - You can't create a label when you create a new parameter. You must attach a label to a
 * specific version of a parameter.
 *
 * - If you no longer want to use a parameter label, then you can either delete it or move it
 * to a different version of a parameter.
 *
 * - A label can have a maximum of 100 characters.
 *
 * - Labels can contain letters (case sensitive), numbers, periods (.), hyphens (-), or
 * underscores (_).
 *
 * - Labels can't begin with a number, "`aws`" or "`ssm`" (not case
 * sensitive). If a label fails to meet these requirements, then the label isn't associated with a
 * parameter and the system displays it in the list of InvalidLabels.
 *
 * - Parameter names can't contain spaces. The service removes any spaces specified for
 * the beginning or end of a parameter name. If the specified name for a parameter contains spaces
 * between characters, the request fails with a `ValidationException` error.
 */
export declare const labelParameterVersion: API.OperationMethod<LabelParameterVersionRequest & RegionInput, LabelParameterVersionResult, LabelParameterVersionError, Creds | HttpClient.HttpClient>;
export type ListAssociationsError = InternalServerError | InvalidNextToken | CommonErrors;
/**
 * Returns all State Manager associations in the current Amazon Web Services account and Amazon Web Services Region. You
 * can limit the results to a specific State Manager association document or managed node by
 * specifying a filter. State Manager is a tool in Amazon Web Services Systems Manager.
 */
export declare const listAssociations: API.PaginatedOperationMethod<ListAssociationsRequest & RegionInput, ListAssociationsResult, ListAssociationsError, Creds | HttpClient.HttpClient, Association>;
export type ListAssociationVersionsError = AssociationDoesNotExist | InternalServerError | InvalidNextToken | CommonErrors;
/**
 * Retrieves all versions of an association for a specific association ID.
 */
export declare const listAssociationVersions: API.PaginatedOperationMethod<ListAssociationVersionsRequest & RegionInput, ListAssociationVersionsResult, ListAssociationVersionsError, Creds | HttpClient.HttpClient, AssociationVersionInfo>;
export type ListCloudConnectorsError = InternalServerError | CommonErrors;
/**
 * Returns a list of cloud connectors in the current Amazon Web Services account and Amazon Web Services Region.
 */
export declare const listCloudConnectors: API.PaginatedOperationMethod<ListCloudConnectorsRequest & RegionInput, ListCloudConnectorsResult, ListCloudConnectorsError, Creds | HttpClient.HttpClient, CloudConnectorSummary>;
export type ListCommandInvocationsError = InternalServerError | InvalidCommandId | InvalidFilterKey | InvalidInstanceId | InvalidNextToken | CommonErrors;
/**
 * An invocation is copy of a command sent to a specific managed node. A command can apply to
 * one or more managed nodes. A command invocation applies to one managed node. For example, if a
 * user runs `SendCommand` against three managed nodes, then a command invocation is
 * created for each requested managed node ID. `ListCommandInvocations` provide status
 * about command execution.
 */
export declare const listCommandInvocations: API.PaginatedOperationMethod<ListCommandInvocationsRequest & RegionInput, ListCommandInvocationsResult, ListCommandInvocationsError, Creds | HttpClient.HttpClient, CommandInvocation>;
export type ListCommandsError = InternalServerError | InvalidCommandId | InvalidFilterKey | InvalidInstanceId | InvalidNextToken | CommonErrors;
/**
 * Lists the commands requested by users of the Amazon Web Services account.
 */
export declare const listCommands: API.PaginatedOperationMethod<ListCommandsRequest & RegionInput, ListCommandsResult, ListCommandsError, Creds | HttpClient.HttpClient, Command>;
export type ListComplianceItemsError = InternalServerError | InvalidFilter | InvalidNextToken | InvalidResourceId | InvalidResourceType | CommonErrors;
/**
 * For a specified resource ID, this API operation returns a list of compliance statuses for
 * different resource types. Currently, you can only specify one resource ID per call. List results
 * depend on the criteria specified in the filter.
 */
export declare const listComplianceItems: API.PaginatedOperationMethod<ListComplianceItemsRequest & RegionInput, ListComplianceItemsResult, ListComplianceItemsError, Creds | HttpClient.HttpClient, ComplianceItem>;
export type ListComplianceSummariesError = InternalServerError | InvalidFilter | InvalidNextToken | CommonErrors;
/**
 * Returns a summary count of compliant and non-compliant resources for a compliance type. For
 * example, this call can return State Manager associations, patches, or custom compliance types
 * according to the filter criteria that you specify.
 */
export declare const listComplianceSummaries: API.PaginatedOperationMethod<ListComplianceSummariesRequest & RegionInput, ListComplianceSummariesResult, ListComplianceSummariesError, Creds | HttpClient.HttpClient, ComplianceSummaryItem>;
export type ListDocumentMetadataHistoryError = InternalServerError | InvalidDocument | InvalidDocumentVersion | InvalidNextToken | CommonErrors;
/**
 * Amazon Web Services Systems Manager Change Manager is no longer open to new customers. Existing customers can
 * continue to use the service as normal. For more information, see
 * Amazon Web Services Systems Manager Change Manager availability change.
 *
 * Information about approval reviews for a version of a change template in Change Manager.
 */
export declare const listDocumentMetadataHistory: API.OperationMethod<ListDocumentMetadataHistoryRequest & RegionInput, ListDocumentMetadataHistoryResponse, ListDocumentMetadataHistoryError, Creds | HttpClient.HttpClient>;
export type ListDocumentsError = InternalServerError | InvalidFilterKey | InvalidNextToken | CommonErrors;
/**
 * Returns all Systems Manager (SSM) documents in the current Amazon Web Services account and Amazon Web Services Region. You can
 * limit the results of this request by using a filter.
 */
export declare const listDocuments: API.PaginatedOperationMethod<ListDocumentsRequest & RegionInput, ListDocumentsResult, ListDocumentsError, Creds | HttpClient.HttpClient, DocumentIdentifier>;
export type ListDocumentVersionsError = InternalServerError | InvalidDocument | InvalidNextToken | CommonErrors;
/**
 * List all versions for a document.
 */
export declare const listDocumentVersions: API.PaginatedOperationMethod<ListDocumentVersionsRequest & RegionInput, ListDocumentVersionsResult, ListDocumentVersionsError, Creds | HttpClient.HttpClient, DocumentVersionInfo>;
export type ListInventoryEntriesError = InternalServerError | InvalidFilter | InvalidInstanceId | InvalidNextToken | InvalidTypeNameException | CommonErrors;
/**
 * A list of inventory items returned by the request.
 */
export declare const listInventoryEntries: API.OperationMethod<ListInventoryEntriesRequest & RegionInput, ListInventoryEntriesResult, ListInventoryEntriesError, Creds | HttpClient.HttpClient>;
export type ListNodesError = InternalServerError | InvalidFilter | InvalidNextToken | ResourceDataSyncNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Takes in filters and returns a list of managed nodes matching the filter criteria.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesRequest & RegionInput, ListNodesResult, ListNodesError, Creds | HttpClient.HttpClient, Node>;
export type ListNodesSummaryError = InternalServerError | InvalidAggregatorException | InvalidFilter | InvalidNextToken | ResourceDataSyncNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Generates a summary of managed instance/node metadata based on the filters and aggregators
 * you specify. Results are grouped by the input aggregator you specify.
 */
export declare const listNodesSummary: API.PaginatedOperationMethod<ListNodesSummaryRequest & RegionInput, ListNodesSummaryResult, ListNodesSummaryError, Creds | HttpClient.HttpClient, {
    [key: string]: string | undefined;
}>;
export type ListOpsItemEventsError = InternalServerError | OpsItemInvalidParameterException | OpsItemLimitExceededException | OpsItemNotFoundException | CommonErrors;
/**
 * Returns a list of all OpsItem events in the current Amazon Web Services Region and Amazon Web Services account. You can
 * limit the results to events associated with specific OpsItems by specifying a filter.
 */
export declare const listOpsItemEvents: API.PaginatedOperationMethod<ListOpsItemEventsRequest & RegionInput, ListOpsItemEventsResponse, ListOpsItemEventsError, Creds | HttpClient.HttpClient, OpsItemEventSummary>;
export type ListOpsItemRelatedItemsError = InternalServerError | OpsItemInvalidParameterException | CommonErrors;
/**
 * Lists all related-item resources associated with a Systems Manager OpsCenter OpsItem. OpsCenter is a
 * tool in Amazon Web Services Systems Manager.
 */
export declare const listOpsItemRelatedItems: API.PaginatedOperationMethod<ListOpsItemRelatedItemsRequest & RegionInput, ListOpsItemRelatedItemsResponse, ListOpsItemRelatedItemsError, Creds | HttpClient.HttpClient, OpsItemRelatedItemSummary>;
export type ListOpsMetadataError = InternalServerError | OpsMetadataInvalidArgumentException | CommonErrors;
/**
 * Amazon Web Services Systems Manager calls this API operation when displaying all Application Manager OpsMetadata objects or
 * blobs.
 */
export declare const listOpsMetadata: API.PaginatedOperationMethod<ListOpsMetadataRequest & RegionInput, ListOpsMetadataResult, ListOpsMetadataError, Creds | HttpClient.HttpClient, OpsMetadata>;
export type ListResourceComplianceSummariesError = InternalServerError | InvalidFilter | InvalidNextToken | CommonErrors;
/**
 * Returns a resource-level summary count. The summary includes information about compliant and
 * non-compliant statuses and detailed compliance-item severity counts, according to the filter
 * criteria you specify.
 */
export declare const listResourceComplianceSummaries: API.PaginatedOperationMethod<ListResourceComplianceSummariesRequest & RegionInput, ListResourceComplianceSummariesResult, ListResourceComplianceSummariesError, Creds | HttpClient.HttpClient, ResourceComplianceSummaryItem>;
export type ListResourceDataSyncError = InternalServerError | InvalidNextToken | ResourceDataSyncInvalidConfigurationException | CommonErrors;
/**
 * Lists your resource data sync configurations. Includes information about the last time a
 * sync attempted to start, the last sync status, and the last time a sync successfully
 * completed.
 *
 * The number of sync configurations might be too large to return using a single call to
 * `ListResourceDataSync`. You can limit the number of sync configurations returned by
 * using the `MaxResults` parameter. To determine whether there are more sync
 * configurations to list, check the value of `NextToken` in the output. If there are
 * more sync configurations to list, you can request them by specifying the `NextToken`
 * returned in the call to the parameter of a subsequent call.
 */
export declare const listResourceDataSync: API.PaginatedOperationMethod<ListResourceDataSyncRequest & RegionInput, ListResourceDataSyncResult, ListResourceDataSyncError, Creds | HttpClient.HttpClient, ResourceDataSyncItem>;
export type ListTagsForResourceError = InternalServerError | InvalidResourceId | InvalidResourceType | CommonErrors;
/**
 * Returns a list of the tags assigned to the specified resource.
 *
 * For information about the ID format for each supported resource type, see AddTagsToResource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResult, ListTagsForResourceError, Creds | HttpClient.HttpClient>;
export type ModifyDocumentPermissionError = DocumentLimitExceeded | DocumentPermissionLimit | InternalServerError | InvalidDocument | InvalidPermissionType | CommonErrors;
/**
 * Shares a Amazon Web Services Systems Manager document (SSM document)publicly or privately. If you share a document
 * privately, you must specify the Amazon Web Services user IDs for those people who can use the document. If
 * you share a document publicly, you must specify *All* as the account
 * ID.
 */
export declare const modifyDocumentPermission: API.OperationMethod<ModifyDocumentPermissionRequest & RegionInput, ModifyDocumentPermissionResponse, ModifyDocumentPermissionError, Creds | HttpClient.HttpClient>;
export type PutComplianceItemsError = ComplianceTypeCountLimitExceededException | InternalServerError | InvalidItemContentException | InvalidResourceId | InvalidResourceType | ItemSizeLimitExceededException | TotalSizeLimitExceededException | CommonErrors;
/**
 * Registers a compliance type and other compliance details on a designated resource. This
 * operation lets you register custom compliance details with a resource. This call overwrites
 * existing compliance information on the resource, so you must provide a full list of compliance
 * items each time that you send the request.
 *
 * ComplianceType can be one of the following:
 *
 * - ExecutionId: The execution ID when the patch, association, or custom compliance item was
 * applied.
 *
 * - ExecutionType: Specify patch, association, or Custom:`string`.
 *
 * - ExecutionTime. The time the patch, association, or custom compliance item was applied to
 * the managed node.
 *
 * For State Manager associations, this represents the time when compliance status was
 * captured by the Systems Manager service during its internal compliance aggregation workflow, not
 * necessarily when the association was executed on the managed node. State Manager updates
 * compliance information for all associations on an instance whenever any association executes,
 * which may result in multiple associations showing the same execution time.
 *
 * - Id: The patch, association, or custom compliance ID.
 *
 * - Title: A title.
 *
 * - Status: The status of the compliance item. For example, `approved` for patches,
 * or `Failed` for associations.
 *
 * - Severity: A patch severity. For example, `Critical`.
 *
 * - DocumentName: An SSM document name. For example, `AWS-RunPatchBaseline`.
 *
 * - DocumentVersion: An SSM document version number. For example, 4.
 *
 * - Classification: A patch classification. For example, `security updates`.
 *
 * - PatchBaselineId: A patch baseline ID.
 *
 * - PatchSeverity: A patch severity. For example, `Critical`.
 *
 * - PatchState: A patch state. For example, `InstancesWithFailedPatches`.
 *
 * - PatchGroup: The name of a patch group.
 *
 * - InstalledTime: The time the association, patch, or custom compliance item was applied to
 * the resource. Specify the time by using the following format:
 * `yyyy-MM-dd'T'HH:mm:ss'Z'`
 */
export declare const putComplianceItems: API.OperationMethod<PutComplianceItemsRequest & RegionInput, PutComplianceItemsResult, PutComplianceItemsError, Creds | HttpClient.HttpClient>;
export type PutInventoryError = CustomSchemaCountLimitExceededException | InternalServerError | InvalidInstanceId | InvalidInventoryItemContextException | InvalidItemContentException | InvalidTypeNameException | ItemContentMismatchException | ItemSizeLimitExceededException | SubTypeCountLimitExceededException | TotalSizeLimitExceededException | UnsupportedInventoryItemContextException | UnsupportedInventorySchemaVersionException | CommonErrors;
/**
 * Bulk update custom inventory items on one or more managed nodes. The request adds an
 * inventory item, if it doesn't already exist, or updates an inventory item, if it does
 * exist.
 */
export declare const putInventory: API.OperationMethod<PutInventoryRequest & RegionInput, PutInventoryResult, PutInventoryError, Creds | HttpClient.HttpClient>;
export type PutParameterError = HierarchyLevelLimitExceededException | HierarchyTypeMismatchException | IncompatiblePolicyException | InternalServerError | InvalidAllowedPatternException | InvalidKeyId | InvalidPolicyAttributeException | InvalidPolicyTypeException | ParameterAlreadyExists | ParameterLimitExceeded | ParameterMaxVersionLimitExceeded | ParameterPatternMismatchException | PoliciesLimitExceededException | TooManyUpdates | UnsupportedParameterType | CommonErrors;
/**
 * Create or update a parameter in Parameter Store.
 *
 * Parameter Store throughput defines the number of API transactions per second (TPS) that
 * Systems Manager can process. This applies to `GetParameter`,
 * `GetParameters`, and `PutParameter` API calls for your Amazon Web Services account and
 * Amazon Web Services Region. By default, Parameter Store is configured with a standard throughput quota suitable
 * for low- to moderate-volume workloads. Applications that retrieve configuration data infrequently
 * or operate at smaller scale can use this default setting without additional cost.
 *
 * For higher-volume workloads, you can enable higher throughput. This increases the maximum
 * number of supported transactions per second for your account and Region. Increased throughput
 * supports applications and workloads that need concurrent access to multiple parameters. If you
 * experience `ThrottlingException: Rate exceeded` errors, enable higher throughput. For
 * more information, see Changing Parameter Store
 * throughput.
 */
export declare const putParameter: API.OperationMethod<PutParameterRequest & RegionInput, PutParameterResult, PutParameterError, Creds | HttpClient.HttpClient>;
export type PutResourcePolicyError = InternalServerError | MalformedResourcePolicyDocumentException | ResourceNotFoundException | ResourcePolicyConflictException | ResourcePolicyInvalidParameterException | ResourcePolicyLimitExceededException | ResourcePolicyNotFoundException | CommonErrors;
/**
 * Creates or updates a Systems Manager resource policy. A resource policy helps you to define the
 * IAM entity (for example, an Amazon Web Services account) that can manage your Systems Manager resources.
 * The following resources support Systems Manager resource policies.
 *
 * - `OpsItemGroup` - The resource policy for `OpsItemGroup` enables
 * Amazon Web Services accounts to view and interact with OpsCenter operational work items (OpsItems).
 *
 * - `Parameter` - The resource policy is used to share a parameter with other
 * accounts using Resource Access Manager (RAM).
 *
 * To share a parameter, it must be in the advanced parameter tier. For information about
 * parameter tiers, see Managing
 * parameter tiers. For information about changing an existing standard parameter to an
 * advanced parameter, see Changing a standard parameter to an advanced parameter.
 *
 * To share a `SecureString` parameter, it must be encrypted with a customer managed key, and you must share the key separately through Key Management Service. Amazon Web Services managed keys cannot be shared. Parameters encrypted with the default Amazon Web Services managed key can be updated to use a customer managed key instead. For KMS key definitions, see KMS concepts in the
 * *Key Management Service Developer Guide*.
 *
 * While you can share a parameter using the Systems Manager `PutResourcePolicy` operation,
 * we recommend using Resource Access Manager (RAM) instead. This is because using
 * `PutResourcePolicy` requires the extra step of promoting the parameter to a
 * standard RAM Resource Share using the RAM
 * PromoteResourceShareCreatedFromPolicy API operation. Otherwise, the parameter won't
 * be returned by the Systems Manager DescribeParameters API operation using the `--shared` option.
 *
 * For more information, see Sharing a
 * parameter in the *Amazon Web Services Systems Manager User Guide*
 *
 * - `Document` - Shares the document using Resource Access Manager (RAM). For more information about sharing documents, see Sharing
 * Systems Manager documents in the *Amazon Web Services Systems Manager User Guide*.
 *
 * While you can share a document using the Systems Manager `PutResourcePolicy` operation, we
 * recommend using Resource Access Manager (RAM) instead. Using
 * `PutResourcePolicy` requires an extra step. You must promote the document to a
 * standard RAM Resource Share using the RAM PromoteResourceShareCreatedFromPolicy API operation. Otherwise, the Systems Manager ListDocuments API operation won't return the document when filtering for shared
 * documents. The Amazon Web Services Config PutRemediationConfigurations API operation also can't use the document.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Creds | HttpClient.HttpClient>;
export type RegisterDefaultHostManagementConfigurationError = InternalServerError | CommonErrors;
/**
 * Enables Default Host Management Configuration (DHMC) for the current Amazon Web Services account and
 * Amazon Web Services Region. With DHMC enabled, you don't need to configure additional resources, such as an
 * instance profile, to use your Amazon EC2 instances as managed nodes in Amazon Web Services Systems Manager.
 *
 * To use this operation, you must have the following permissions:
 *
 * - You need the `ssm:GetServiceSetting` and `ssm:UpdateServiceSetting`
 * permissions for the `/ssm/managed-instance/default-ec2-instance-management-role`
 * service setting.
 *
 * - You need the `iam:GetRole` and `iam:PassRole` permissions for the
 * role used for Default Host Management Configuration.
 *
 * If `PermissionModel` is `SERVICE_MANAGED`, you also need the
 * `iam:CreateRole` and `iam:AttachRolePolicy` permissions so that Amazon Web Services Systems Manager
 * can create and configure the role on your behalf.
 */
export declare const registerDefaultHostManagementConfiguration: API.OperationMethod<RegisterDefaultHostManagementConfigurationRequest & RegionInput, RegisterDefaultHostManagementConfigurationResult, RegisterDefaultHostManagementConfigurationError, Creds | HttpClient.HttpClient>;
export type RegisterDefaultPatchBaselineError = DoesNotExistException | InternalServerError | InvalidResourceId | CommonErrors;
/**
 * Defines the default patch baseline for the relevant operating system.
 *
 * To reset the Amazon Web Services-predefined patch baseline as the default, specify the full patch baseline
 * Amazon Resource Name (ARN) as the baseline ID value. For example, for CentOS, specify
 * `arn:aws:ssm:us-east-2:733109147000:patchbaseline/pb-0574b43a65ea646ed` instead of
 * `pb-0574b43a65ea646ed`.
 */
export declare const registerDefaultPatchBaseline: API.OperationMethod<RegisterDefaultPatchBaselineRequest & RegionInput, RegisterDefaultPatchBaselineResult, RegisterDefaultPatchBaselineError, Creds | HttpClient.HttpClient>;
export type RegisterPatchBaselineForPatchGroupError = AlreadyExistsException | DoesNotExistException | InternalServerError | InvalidResourceId | ResourceLimitExceededException | CommonErrors;
/**
 * Registers a patch baseline for a patch group.
 */
export declare const registerPatchBaselineForPatchGroup: API.OperationMethod<RegisterPatchBaselineForPatchGroupRequest & RegionInput, RegisterPatchBaselineForPatchGroupResult, RegisterPatchBaselineForPatchGroupError, Creds | HttpClient.HttpClient>;
export type RegisterTargetWithMaintenanceWindowError = DoesNotExistException | IdempotentParameterMismatch | InternalServerError | ResourceLimitExceededException | CommonErrors;
/**
 * Registers a target with a maintenance window.
 */
export declare const registerTargetWithMaintenanceWindow: API.OperationMethod<RegisterTargetWithMaintenanceWindowRequest & RegionInput, RegisterTargetWithMaintenanceWindowResult, RegisterTargetWithMaintenanceWindowError, Creds | HttpClient.HttpClient>;
export type RegisterTaskWithMaintenanceWindowError = DoesNotExistException | FeatureNotAvailableException | IdempotentParameterMismatch | InternalServerError | ResourceLimitExceededException | CommonErrors;
/**
 * Adds a new task to a maintenance window.
 */
export declare const registerTaskWithMaintenanceWindow: API.OperationMethod<RegisterTaskWithMaintenanceWindowRequest & RegionInput, RegisterTaskWithMaintenanceWindowResult, RegisterTaskWithMaintenanceWindowError, Creds | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = InternalServerError | InvalidResourceId | InvalidResourceType | TooManyUpdates | CommonErrors;
/**
 * Removes tag keys from the specified resource.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceRequest & RegionInput, RemoveTagsFromResourceResult, RemoveTagsFromResourceError, Creds | HttpClient.HttpClient>;
export type ResetServiceSettingError = InternalServerError | ServiceSettingNotFound | TooManyUpdates | CommonErrors;
/**
 * `ServiceSetting` is an account-level setting for an Amazon Web Services service. This setting
 * defines how a user interacts with or uses a service or a feature of a service. For example, if an
 * Amazon Web Services service charges money to the account based on feature or service usage, then the Amazon Web Services
 * service team might create a default setting of "false". This means the user can't use this
 * feature unless they change the setting to "true" and intentionally opt in for a paid
 * feature.
 *
 * Services map a `SettingId` object to a setting value. Amazon Web Services services teams define
 * the default value for a `SettingId`. You can't create a new `SettingId`,
 * but you can overwrite the default value if you have the `ssm:UpdateServiceSetting`
 * permission for the setting. Use the GetServiceSetting API operation to view the
 * current value. Use the UpdateServiceSetting API operation to change the default
 * setting.
 *
 * Reset the service setting for the account to the default value as provisioned by the Amazon Web Services
 * service team.
 */
export declare const resetServiceSetting: API.OperationMethod<ResetServiceSettingRequest & RegionInput, ResetServiceSettingResult, ResetServiceSettingError, Creds | HttpClient.HttpClient>;
export type ResumeSessionError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Reconnects a session to a managed node after it has been disconnected. Connections can be
 * resumed for disconnected sessions, but not terminated sessions.
 *
 * This command is primarily for use by client machines to automatically reconnect during
 * intermittent network issues. It isn't intended for any other use.
 */
export declare const resumeSession: API.OperationMethod<ResumeSessionRequest & RegionInput, ResumeSessionResponse, ResumeSessionError, Creds | HttpClient.HttpClient>;
export type SendAutomationSignalError = AutomationExecutionNotFoundException | AutomationStepNotFoundException | InternalServerError | InvalidAutomationSignalException | CommonErrors;
/**
 * Sends a signal to an Automation execution to change the current behavior or status of the
 * execution.
 */
export declare const sendAutomationSignal: API.OperationMethod<SendAutomationSignalRequest & RegionInput, SendAutomationSignalResult, SendAutomationSignalError, Creds | HttpClient.HttpClient>;
export type SendCommandError = DuplicateInstanceId | InternalServerError | InvalidDocument | InvalidDocumentVersion | InvalidInstanceId | InvalidNotificationConfig | InvalidOutputFolder | InvalidParameters | InvalidRole | MaxDocumentSizeExceeded | UnsupportedPlatformType | CommonErrors;
/**
 * Runs commands on one or more managed nodes.
 */
export declare const sendCommand: API.OperationMethod<SendCommandRequest & RegionInput, SendCommandResult, SendCommandError, Creds | HttpClient.HttpClient>;
export type StartAccessRequestError = AccessDeniedException | InternalServerError | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the workflow for just-in-time node access sessions.
 */
export declare const startAccessRequest: API.OperationMethod<StartAccessRequestRequest & RegionInput, StartAccessRequestResponse, StartAccessRequestError, Creds | HttpClient.HttpClient>;
export type StartAssociationsOnceError = AssociationDoesNotExist | InvalidAssociation | CommonErrors;
/**
 * Runs an association immediately and only one time. This operation can be helpful when
 * troubleshooting associations.
 */
export declare const startAssociationsOnce: API.OperationMethod<StartAssociationsOnceRequest & RegionInput, StartAssociationsOnceResult, StartAssociationsOnceError, Creds | HttpClient.HttpClient>;
export type StartAutomationExecutionError = AutomationDefinitionNotFoundException | AutomationDefinitionVersionNotFoundException | AutomationExecutionLimitExceededException | IdempotentParameterMismatch | InternalServerError | InvalidAutomationExecutionParametersException | InvalidTarget | CommonErrors;
/**
 * Initiates execution of an Automation runbook.
 */
export declare const startAutomationExecution: API.OperationMethod<StartAutomationExecutionRequest & RegionInput, StartAutomationExecutionResult, StartAutomationExecutionError, Creds | HttpClient.HttpClient>;
export type StartChangeRequestExecutionError = AutomationDefinitionNotApprovedException | AutomationDefinitionNotFoundException | AutomationDefinitionVersionNotFoundException | AutomationExecutionLimitExceededException | IdempotentParameterMismatch | InternalServerError | InvalidAutomationExecutionParametersException | NoLongerSupportedException | CommonErrors;
/**
 * Amazon Web Services Systems Manager Change Manager is no longer open to new customers. Existing customers can
 * continue to use the service as normal. For more information, see
 * Amazon Web Services Systems Manager Change Manager availability change.
 *
 * Creates a change request for Change Manager. The Automation runbooks specified in the
 * change request run only after all required approvals for the change request have been
 * received.
 */
export declare const startChangeRequestExecution: API.OperationMethod<StartChangeRequestExecutionRequest & RegionInput, StartChangeRequestExecutionResult, StartChangeRequestExecutionError, Creds | HttpClient.HttpClient>;
export type StartExecutionPreviewError = InternalServerError | ValidationException | CommonErrors;
/**
 * Initiates the process of creating a preview showing the effects that running a specified
 * Automation runbook would have on the targeted resources.
 */
export declare const startExecutionPreview: API.OperationMethod<StartExecutionPreviewRequest & RegionInput, StartExecutionPreviewResponse, StartExecutionPreviewError, Creds | HttpClient.HttpClient>;
export type StartSessionError = InternalServerError | InvalidDocument | TargetNotConnected | CommonErrors;
/**
 * Initiates a connection to a target (for example, a managed node) for a Session Manager session.
 * Returns a URL and token that can be used to open a WebSocket connection for sending input and
 * receiving outputs.
 *
 * Amazon Web Services CLI usage: `start-session` is an interactive command that requires the Session Manager
 * plugin to be installed on the client machine making the call. For information, see Install
 * the Session Manager plugin for the Amazon Web Services CLI in the *Amazon Web Services Systems Manager User Guide*.
 *
 * Amazon Web Services Tools for PowerShell usage: Start-SSMSession isn't currently supported by Amazon Web Services Tools
 * for PowerShell on Windows local machines.
 */
export declare const startSession: API.OperationMethod<StartSessionRequest & RegionInput, StartSessionResponse, StartSessionError, Creds | HttpClient.HttpClient>;
export type StopAutomationExecutionError = AutomationExecutionNotFoundException | InternalServerError | InvalidAutomationStatusUpdateException | CommonErrors;
/**
 * Stop an Automation that is currently running.
 */
export declare const stopAutomationExecution: API.OperationMethod<StopAutomationExecutionRequest & RegionInput, StopAutomationExecutionResult, StopAutomationExecutionError, Creds | HttpClient.HttpClient>;
export type TerminateSessionError = InternalServerError | CommonErrors;
/**
 * Permanently ends a session and closes the data connection between the Session Manager client and
 * SSM Agent on the managed node. A terminated session can't be resumed.
 */
export declare const terminateSession: API.OperationMethod<TerminateSessionRequest & RegionInput, TerminateSessionResponse, TerminateSessionError, Creds | HttpClient.HttpClient>;
export type UnlabelParameterVersionError = InternalServerError | ParameterNotFound | ParameterVersionNotFound | TooManyUpdates | CommonErrors;
/**
 * Remove a label or labels from a parameter.
 *
 * Parameter names can't contain spaces. The service removes any spaces specified for the
 * beginning or end of a parameter name. If the specified name for a parameter contains spaces
 * between characters, the request fails with a `ValidationException` error.
 */
export declare const unlabelParameterVersion: API.OperationMethod<UnlabelParameterVersionRequest & RegionInput, UnlabelParameterVersionResult, UnlabelParameterVersionError, Creds | HttpClient.HttpClient>;
export type UpdateAssociationError = AssociationDoesNotExist | AssociationVersionLimitExceeded | InternalServerError | InvalidAssociationVersion | InvalidDocument | InvalidDocumentVersion | InvalidOutputLocation | InvalidParameters | InvalidSchedule | InvalidTarget | InvalidTargetMaps | InvalidUpdate | TooManyUpdates | CommonErrors;
/**
 * Updates an association. You can update the association name and version, the document
 * version, schedule, parameters, and Amazon Simple Storage Service (Amazon S3) output. When you
 * call `UpdateAssociation`, the system removes all optional parameters from the request
 * and overwrites the association with null values for those parameters. This is by design. You must
 * specify all optional parameters in the call, even if you are not changing the parameters. This
 * includes the `Name` parameter. Before calling this API action, we recommend that you
 * call the DescribeAssociation API operation and make a note of all optional
 * parameters required for your `UpdateAssociation` call.
 *
 * In order to call this API operation, a user, group, or role must be granted permission to
 * call the DescribeAssociation API operation. If you don't have permission to
 * call `DescribeAssociation`, then you receive the following error: An error
 * occurred (AccessDeniedException) when calling the UpdateAssociation operation: User:
 * isn't authorized to perform: ssm:DescribeAssociation on resource:
 *
 * When you update an association, the association immediately runs against the specified
 * targets. You can add the `ApplyOnlyAtCronInterval` parameter to run the association
 * during the next schedule run.
 */
export declare const updateAssociation: API.OperationMethod<UpdateAssociationRequest & RegionInput, UpdateAssociationResult, UpdateAssociationError, Creds | HttpClient.HttpClient>;
export type UpdateAssociationStatusError = AssociationDoesNotExist | InternalServerError | InvalidDocument | InvalidInstanceId | StatusUnchanged | TooManyUpdates | CommonErrors;
/**
 * Updates the status of the Amazon Web Services Systems Manager document (SSM document) associated with the specified
 * managed node.
 *
 * `UpdateAssociationStatus` is primarily used by the Amazon Web Services Systems Manager Agent (SSM Agent) to
 * report status updates about your associations and is only used for associations created with the
 * `InstanceId` legacy parameter.
 */
export declare const updateAssociationStatus: API.OperationMethod<UpdateAssociationStatusRequest & RegionInput, UpdateAssociationStatusResult, UpdateAssociationStatusError, Creds | HttpClient.HttpClient>;
export type UpdateCloudConnectorError = ConflictException | InternalServerError | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates an existing cloud connector with new configuration details.
 */
export declare const updateCloudConnector: API.OperationMethod<UpdateCloudConnectorRequest & RegionInput, UpdateCloudConnectorResult, UpdateCloudConnectorError, Creds | HttpClient.HttpClient>;
export type UpdateDocumentError = DocumentVersionLimitExceeded | DuplicateDocumentContent | DuplicateDocumentVersionName | InternalServerError | InvalidDocument | InvalidDocumentContent | InvalidDocumentOperation | InvalidDocumentSchemaVersion | InvalidDocumentVersion | MaxDocumentSizeExceeded | CommonErrors;
/**
 * Updates one or more values for an SSM document.
 */
export declare const updateDocument: API.OperationMethod<UpdateDocumentRequest & RegionInput, UpdateDocumentResult, UpdateDocumentError, Creds | HttpClient.HttpClient>;
export type UpdateDocumentDefaultVersionError = InternalServerError | InvalidDocument | InvalidDocumentSchemaVersion | InvalidDocumentVersion | CommonErrors;
/**
 * Set the default version of a document.
 *
 * If you change a document version for a State Manager association, Systems Manager immediately runs
 * the association unless you previously specifed the `apply-only-at-cron-interval`
 * parameter.
 */
export declare const updateDocumentDefaultVersion: API.OperationMethod<UpdateDocumentDefaultVersionRequest & RegionInput, UpdateDocumentDefaultVersionResult, UpdateDocumentDefaultVersionError, Creds | HttpClient.HttpClient>;
export type UpdateDocumentMetadataError = InternalServerError | InvalidDocument | InvalidDocumentOperation | InvalidDocumentVersion | TooManyUpdates | CommonErrors;
/**
 * Amazon Web Services Systems Manager Change Manager is no longer open to new customers. Existing customers can
 * continue to use the service as normal. For more information, see
 * Amazon Web Services Systems Manager Change Manager availability change.
 *
 * Updates information related to approval reviews for a specific version of a change template
 * in Change Manager.
 */
export declare const updateDocumentMetadata: API.OperationMethod<UpdateDocumentMetadataRequest & RegionInput, UpdateDocumentMetadataResponse, UpdateDocumentMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateMaintenanceWindowError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Updates an existing maintenance window. Only specified parameters are modified.
 *
 * The value you specify for `Duration` determines the specific end time for the
 * maintenance window based on the time it begins. No maintenance window tasks are permitted to
 * start after the resulting endtime minus the number of hours you specify for `Cutoff`.
 * For example, if the maintenance window starts at 3 PM, the duration is three hours, and the
 * value you specify for `Cutoff` is one hour, no maintenance window tasks can start
 * after 5 PM.
 */
export declare const updateMaintenanceWindow: API.OperationMethod<UpdateMaintenanceWindowRequest & RegionInput, UpdateMaintenanceWindowResult, UpdateMaintenanceWindowError, Creds | HttpClient.HttpClient>;
export type UpdateMaintenanceWindowTargetError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Modifies the target of an existing maintenance window. You
 * can change the following:
 *
 * - Name
 *
 * - Description
 *
 * - Owner
 *
 * - IDs for an ID target
 *
 * - Tags for a Tag target
 *
 * - From any supported tag type to another. The three supported tag types are ID target, Tag
 * target, and resource group. For more information, see Target.
 *
 * If a parameter is null, then the corresponding field isn't modified.
 */
export declare const updateMaintenanceWindowTarget: API.OperationMethod<UpdateMaintenanceWindowTargetRequest & RegionInput, UpdateMaintenanceWindowTargetResult, UpdateMaintenanceWindowTargetError, Creds | HttpClient.HttpClient>;
export type UpdateMaintenanceWindowTaskError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Modifies a task assigned to a maintenance window. You can't change the task type, but you
 * can change the following values:
 *
 * - `TaskARN`. For example, you can change a `RUN_COMMAND` task from
 * `AWS-RunPowerShellScript` to `AWS-RunShellScript`.
 *
 * - `ServiceRoleArn`
 *
 * - `TaskInvocationParameters`
 *
 * - `Priority`
 *
 * - `MaxConcurrency`
 *
 * - `MaxErrors`
 *
 * One or more targets must be specified for maintenance window Run Command-type tasks.
 * Depending on the task, targets are optional for other maintenance window task types (Automation,
 * Lambda, and Step Functions). For more information about running tasks
 * that don't specify targets, see Registering
 * maintenance window tasks without targets in the
 * *Amazon Web Services Systems Manager User Guide*.
 *
 * If the value for a parameter in `UpdateMaintenanceWindowTask` is null, then the
 * corresponding field isn't modified. If you set `Replace` to true, then all fields
 * required by the RegisterTaskWithMaintenanceWindow operation are required for
 * this request. Optional fields that aren't specified are set to null.
 *
 * When you update a maintenance window task that has options specified in
 * `TaskInvocationParameters`, you must provide again all the
 * `TaskInvocationParameters` values that you want to retain. The values you don't
 * specify again are removed. For example, suppose that when you registered a Run Command task, you
 * specified `TaskInvocationParameters` values for `Comment`,
 * `NotificationConfig`, and `OutputS3BucketName`. If you update the
 * maintenance window task and specify only a different `OutputS3BucketName` value, the
 * values for `Comment` and `NotificationConfig` are removed.
 */
export declare const updateMaintenanceWindowTask: API.OperationMethod<UpdateMaintenanceWindowTaskRequest & RegionInput, UpdateMaintenanceWindowTaskResult, UpdateMaintenanceWindowTaskError, Creds | HttpClient.HttpClient>;
export type UpdateManagedInstanceRoleError = InternalServerError | InvalidInstanceId | CommonErrors;
/**
 * Changes the Identity and Access Management (IAM) role that is assigned to the
 * on-premises server, edge device, or virtual machines (VM). IAM roles are first
 * assigned to these hybrid nodes during the activation process. For more information, see CreateActivation.
 */
export declare const updateManagedInstanceRole: API.OperationMethod<UpdateManagedInstanceRoleRequest & RegionInput, UpdateManagedInstanceRoleResult, UpdateManagedInstanceRoleError, Creds | HttpClient.HttpClient>;
export type UpdateOpsItemError = InternalServerError | OpsItemAccessDeniedException | OpsItemAlreadyExistsException | OpsItemConflictException | OpsItemInvalidParameterException | OpsItemLimitExceededException | OpsItemNotFoundException | CommonErrors;
/**
 * Edit or change an OpsItem. You must have permission in Identity and Access Management (IAM) to update an OpsItem. For more information, see Set up OpsCenter in the
 * *Amazon Web Services Systems Manager User Guide*.
 *
 * Operations engineers and IT professionals use Amazon Web Services Systems Manager OpsCenter to view, investigate, and
 * remediate operational issues impacting the performance and health of their Amazon Web Services resources. For
 * more information, see Amazon Web Services Systems Manager OpsCenter in the
 * *Amazon Web Services Systems Manager User Guide*.
 */
export declare const updateOpsItem: API.OperationMethod<UpdateOpsItemRequest & RegionInput, UpdateOpsItemResponse, UpdateOpsItemError, Creds | HttpClient.HttpClient>;
export type UpdateOpsMetadataError = InternalServerError | OpsMetadataInvalidArgumentException | OpsMetadataKeyLimitExceededException | OpsMetadataNotFoundException | OpsMetadataTooManyUpdatesException | CommonErrors;
/**
 * Amazon Web Services Systems Manager calls this API operation when you edit OpsMetadata in Application Manager.
 */
export declare const updateOpsMetadata: API.OperationMethod<UpdateOpsMetadataRequest & RegionInput, UpdateOpsMetadataResult, UpdateOpsMetadataError, Creds | HttpClient.HttpClient>;
export type UpdatePatchBaselineError = DoesNotExistException | InternalServerError | CommonErrors;
/**
 * Modifies an existing patch baseline. Fields not specified in the request are left
 * unchanged.
 *
 * For information about valid key-value pairs in `PatchFilters` for each supported
 * operating system type, see PatchFilter.
 */
export declare const updatePatchBaseline: API.OperationMethod<UpdatePatchBaselineRequest & RegionInput, UpdatePatchBaselineResult, UpdatePatchBaselineError, Creds | HttpClient.HttpClient>;
export type UpdateResourceDataSyncError = InternalServerError | ResourceDataSyncConflictException | ResourceDataSyncInvalidConfigurationException | ResourceDataSyncNotFoundException | CommonErrors;
/**
 * Update a resource data sync. After you create a resource data sync for a Region, you can't
 * change the account options for that sync. For example, if you create a sync in the us-east-2
 * (Ohio) Region and you choose the `Include only the current account` option, you can't
 * edit that sync later and choose the Include all accounts from my Organizations
 * configuration option. Instead, you must delete the first resource data sync, and create a
 * new one.
 *
 * This API operation only supports a resource data sync that was created with a
 * SyncFromSource `SyncType`.
 */
export declare const updateResourceDataSync: API.OperationMethod<UpdateResourceDataSyncRequest & RegionInput, UpdateResourceDataSyncResult, UpdateResourceDataSyncError, Creds | HttpClient.HttpClient>;
export type UpdateServiceSettingError = InternalServerError | ServiceSettingNotFound | TooManyUpdates | CommonErrors;
/**
 * `ServiceSetting` is an account-level setting for an Amazon Web Services service. This setting
 * defines how a user interacts with or uses a service or a feature of a service. For example, if an
 * Amazon Web Services service charges money to the account based on feature or service usage, then the Amazon Web Services
 * service team might create a default setting of "false". This means the user can't use this
 * feature unless they change the setting to "true" and intentionally opt in for a paid
 * feature.
 *
 * Services map a `SettingId` object to a setting value. Amazon Web Services services teams define
 * the default value for a `SettingId`. You can't create a new `SettingId`,
 * but you can overwrite the default value if you have the `ssm:UpdateServiceSetting`
 * permission for the setting. Use the GetServiceSetting API operation to view the
 * current value. Or, use the ResetServiceSetting to change the value back to the
 * original value defined by the Amazon Web Services service team.
 *
 * Update the service setting for the account.
 */
export declare const updateServiceSetting: API.OperationMethod<UpdateServiceSettingRequest & RegionInput, UpdateServiceSettingResult, UpdateServiceSettingError, Creds | HttpClient.HttpClient>;
export type ValidateCloudConnectorError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Validates the configuration and connectivity of a cloud connector.
 */
export declare const validateCloudConnector: API.PaginatedOperationMethod<ValidateCloudConnectorRequest & RegionInput, ValidateCloudConnectorResult, ValidateCloudConnectorError, Creds | HttpClient.HttpClient, ValidationFinding>;
export {};
//# sourceMappingURL=ssm.d.ts.map