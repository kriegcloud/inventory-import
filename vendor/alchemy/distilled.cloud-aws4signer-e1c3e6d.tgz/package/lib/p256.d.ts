/**
 * Encodings for SigV4A's ECDSA P-256 keys and signatures.
 *
 * Curve arithmetic stays in the platform's crypto wherever it can: a private
 * key is imported as PKCS#8 without its public point, which `node:crypto`
 * (OpenSSL), Bun and workerd's WebCrypto (BoringSSL) derive on import.
 * {@link publicPoint}, plucked from @noble/curves, is the fallback for a
 * WebCrypto that insists on the point (it only accepts a JWK carrying `x`/`y`).
 */
/** The P-256 group order. */
export declare const N = 115792089210356248762697446949407573529996955224135760342422259061068512044369n;
export declare const toBigInt: (bytes: Uint8Array) => bigint;
/** Big-endian, left-padded to 32 bytes. */
export declare const toBytes32: (n: bigint) => Uint8Array<ArrayBuffer>;
/** The PKCS#8 DER of the P-256 private key with scalar `d` (no public point). */
export declare const pkcs8: (d: bigint) => Uint8Array<ArrayBuffer>;
/**
 * `d * G` for a private scalar `d` in [1, n-1], as noble's
 * `p256.getPublicKey`: every window performs one addition, into the real
 * accumulator or into a fake one, so the sequence of point operations does
 * not depend on the scalar's bits.
 */
export declare const publicPoint: (d: bigint) => {
    x: bigint;
    y: bigint;
};
export declare const base64Url: (bytes: Uint8Array) => string;
export declare const fromBase64Url: (s: string) => Uint8Array;
/** A 64-byte `r || s` (IEEE P1363) ECDSA signature as an ASN.1 DER `SEQUENCE { r, s }`. */
export declare const p1363ToDer: (signature: Uint8Array) => Uint8Array;
//# sourceMappingURL=p256.d.ts.map