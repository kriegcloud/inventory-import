import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ConfigurationParametersMap = {
    [key: string]: string | undefined;
};
export type IAMRoleArn = string;
export interface ConfigurationDefinitionInput {
    Type: string;
    Parameters: {
        [key: string]: string | undefined;
    };
    TypeVersion?: string | undefined;
    LocalDeploymentExecutionRoleName?: string | undefined;
    LocalDeploymentAdministrationRoleArn?: string | undefined;
}
export type ConfigurationDefinitionsInputList = ConfigurationDefinitionInput[];
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateConfigurationManagerInput {
    Name?: string | undefined;
    Description?: string | undefined;
    ConfigurationDefinitions: ConfigurationDefinitionInput[];
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateConfigurationManagerOutput {
    ManagerArn: string;
}
export interface DeleteConfigurationManagerInput {
    ManagerArn: string;
}
export interface DeleteConfigurationManagerResponse {
}
export interface GetConfigurationInput {
    ConfigurationId: string;
}
export type StatusType = "Deployment" | "AsyncExecutions" | (string & {});
export type Status = "INITIALIZING" | "DEPLOYING" | "SUCCEEDED" | "DELETING" | "STOPPING" | "FAILED" | "STOPPED" | "DELETE_FAILED" | "STOP_FAILED" | "NONE" | (string & {});
export type StatusDetails = {
    [key: string]: string | undefined;
};
export interface StatusSummary {
    StatusType: StatusType;
    Status?: Status | undefined;
    StatusMessage?: string | undefined;
    LastUpdatedAt: Date;
    StatusDetails?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StatusSummariesList = StatusSummary[];
export interface GetConfigurationOutput {
    Id?: string | undefined;
    ManagerArn?: string | undefined;
    ConfigurationDefinitionId?: string | undefined;
    Type?: string | undefined;
    TypeVersion?: string | undefined;
    Account?: string | undefined;
    Region?: string | undefined;
    CreatedAt?: Date | undefined;
    LastModifiedAt?: Date | undefined;
    StatusSummaries?: StatusSummary[] | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetConfigurationManagerInput {
    ManagerArn: string;
}
export interface ConfigurationDefinition {
    Type: string;
    Parameters: {
        [key: string]: string | undefined;
    };
    TypeVersion?: string | undefined;
    LocalDeploymentExecutionRoleName?: string | undefined;
    LocalDeploymentAdministrationRoleArn?: string | undefined;
    Id?: string | undefined;
}
export type ConfigurationDefinitionsList = ConfigurationDefinition[];
export interface GetConfigurationManagerOutput {
    ManagerArn: string;
    Description?: string | undefined;
    Name?: string | undefined;
    CreatedAt?: Date | undefined;
    LastModifiedAt?: Date | undefined;
    StatusSummaries?: StatusSummary[] | undefined;
    ConfigurationDefinitions?: ConfigurationDefinition[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetServiceSettingsRequest {
}
export interface ServiceSettings {
    ExplorerEnablingRoleArn?: string | undefined;
}
export interface GetServiceSettingsOutput {
    ServiceSettings?: ServiceSettings | undefined;
}
export type FilterValues = string[];
export interface Filter {
    Key: string;
    Values: string[];
}
export type FiltersList = Filter[];
export interface ListConfigurationManagersInput {
    StartingToken?: string | undefined;
    MaxItems?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface ConfigurationDefinitionSummary {
    Id?: string | undefined;
    Type?: string | undefined;
    TypeVersion?: string | undefined;
    FirstClassParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConfigurationDefinitionSummariesList = ConfigurationDefinitionSummary[];
export interface ConfigurationManagerSummary {
    ManagerArn: string;
    Description?: string | undefined;
    Name?: string | undefined;
    StatusSummaries?: StatusSummary[] | undefined;
    ConfigurationDefinitionSummaries?: ConfigurationDefinitionSummary[] | undefined;
}
export type ConfigurationManagerList = ConfigurationManagerSummary[];
export interface ListConfigurationManagersOutput {
    ConfigurationManagersList?: ConfigurationManagerSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConfigurationsInput {
    StartingToken?: string | undefined;
    MaxItems?: number | undefined;
    Filters?: Filter[] | undefined;
    ManagerArn?: string | undefined;
    ConfigurationDefinitionId?: string | undefined;
}
export interface ConfigurationSummary {
    Id?: string | undefined;
    ManagerArn?: string | undefined;
    ConfigurationDefinitionId?: string | undefined;
    Type?: string | undefined;
    TypeVersion?: string | undefined;
    Region?: string | undefined;
    Account?: string | undefined;
    CreatedAt?: Date | undefined;
    FirstClassParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    StatusSummaries?: StatusSummary[] | undefined;
}
export type ConfigurationsList = ConfigurationSummary[];
export interface ListConfigurationsOutput {
    ConfigurationsList?: ConfigurationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListQuickSetupTypesRequest {
}
export interface QuickSetupTypeOutput {
    Type?: string | undefined;
    LatestVersion?: string | undefined;
}
export type QuickSetupTypeList = QuickSetupTypeOutput[];
export interface ListQuickSetupTypesOutput {
    QuickSetupTypeList?: QuickSetupTypeOutput[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface TagEntry {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type Tags = TagEntry[];
export interface ListTagsForResourceResponse {
    Tags?: TagEntry[] | undefined;
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateConfigurationDefinitionInput {
    ManagerArn: string;
    Id: string;
    TypeVersion?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    LocalDeploymentExecutionRoleName?: string | undefined;
    LocalDeploymentAdministrationRoleArn?: string | undefined;
}
export interface UpdateConfigurationDefinitionResponse {
}
export interface UpdateConfigurationManagerInput {
    ManagerArn: string;
    Name?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateConfigurationManagerResponse {
}
export interface UpdateServiceSettingsInput {
    ExplorerEnablingRoleArn?: string | undefined;
}
export interface UpdateServiceSettingsResponse {
}
export type CreateConfigurationManagerError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Quick Setup configuration manager resource. This object is a collection
 * of desired state configurations for multiple configuration definitions and
 * summaries describing the deployments of those definitions.
 */
export declare const createConfigurationManager: API.OperationMethod<CreateConfigurationManagerInput & RegionInput, CreateConfigurationManagerOutput, CreateConfigurationManagerError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationManagerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configuration manager.
 */
export declare const deleteConfigurationManager: API.OperationMethod<DeleteConfigurationManagerInput & RegionInput, DeleteConfigurationManagerResponse, DeleteConfigurationManagerError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about the specified configuration.
 */
export declare const getConfiguration: API.OperationMethod<GetConfigurationInput & RegionInput, GetConfigurationOutput, GetConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationManagerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a configuration manager.
 */
export declare const getConfigurationManager: API.OperationMethod<GetConfigurationManagerInput & RegionInput, GetConfigurationManagerOutput, GetConfigurationManagerError, Credentials | HttpClient.HttpClient>;
export type GetServiceSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns settings configured for Quick Setup in the requesting Amazon Web Services account and Amazon Web Services Region.
 */
export declare const getServiceSettings: API.OperationMethod<GetServiceSettingsRequest & RegionInput, GetServiceSettingsOutput, GetServiceSettingsError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationManagersError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Quick Setup configuration managers.
 */
export declare const listConfigurationManagers: API.PaginatedOperationMethod<ListConfigurationManagersInput & RegionInput, ListConfigurationManagersOutput, ListConfigurationManagersError, Credentials | HttpClient.HttpClient, ConfigurationManagerSummary>;
export type ListConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns configurations deployed by Quick Setup in the requesting Amazon Web Services account and Amazon Web Services Region.
 */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsInput & RegionInput, ListConfigurationsOutput, ListConfigurationsError, Credentials | HttpClient.HttpClient, ConfigurationSummary>;
export type ListQuickSetupTypesError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns the available Quick Setup types.
 */
export declare const listQuickSetupTypes: API.OperationMethod<ListQuickSetupTypesRequest & RegionInput, ListQuickSetupTypesOutput, ListQuickSetupTypesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns tags assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns key-value pairs of metadata to Amazon Web Services resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationDefinitionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Quick Setup configuration definition.
 */
export declare const updateConfigurationDefinition: API.OperationMethod<UpdateConfigurationDefinitionInput & RegionInput, UpdateConfigurationDefinitionResponse, UpdateConfigurationDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationManagerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Quick Setup configuration manager.
 */
export declare const updateConfigurationManager: API.OperationMethod<UpdateConfigurationManagerInput & RegionInput, UpdateConfigurationManagerResponse, UpdateConfigurationManagerError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates settings configured for Quick Setup.
 */
export declare const updateServiceSettings: API.OperationMethod<UpdateServiceSettingsInput & RegionInput, UpdateServiceSettingsResponse, UpdateServiceSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ssm-quicksetup.d.ts.map