import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AiSearchInstanceNotFound_base: S.TaggedErrorClass<"AiSearchInstanceNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class AiSearchInstanceNotFound extends /*@__PURE__*/ AiSearchInstanceNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InstanceAlreadyExists_base: S.TaggedErrorClass<"InstanceAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InstanceAlreadyExists extends /*@__PURE__*/ InstanceAlreadyExists_base {
}
declare const InstanceDeletionInProgress_base: S.TaggedErrorClass<"InstanceDeletionInProgress", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InstanceDeletionInProgress extends /*@__PURE__*/ InstanceDeletionInProgress_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenCredentials_base: S.TaggedErrorClass<"InvalidTokenCredentials", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidTokenCredentials extends /*@__PURE__*/ InvalidTokenCredentials_base {
}
declare const MissingSitemap_base: S.TaggedErrorClass<"MissingSitemap", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MissingSitemap extends /*@__PURE__*/ MissingSitemap_base {
}
declare const NamespaceAlreadyExists_base: S.TaggedErrorClass<"NamespaceAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NamespaceAlreadyExists extends /*@__PURE__*/ NamespaceAlreadyExists_base {
}
declare const NamespaceNotFound_base: S.TaggedErrorClass<"NamespaceNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NamespaceNotFound extends /*@__PURE__*/ NamespaceNotFound_base {
}
declare const NotFound_base: S.TaggedErrorClass<"NotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const SyncInCooldown_base: S.TaggedErrorClass<"SyncInCooldown", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SyncInCooldown extends /*@__PURE__*/ SyncInCooldown_base {
}
declare const TokenInUseByInstances_base: S.TaggedErrorClass<"TokenInUseByInstances", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class TokenInUseByInstances extends /*@__PURE__*/ TokenInUseByInstances_base {
}
declare const TokenNotFound_base: S.TaggedErrorClass<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
declare const UnableToConnect_base: S.TaggedErrorClass<"UnableToConnect", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class UnableToConnect extends /*@__PURE__*/ UnableToConnect_base {
}
declare const ValidationError_base: S.TaggedErrorClass<"ValidationError", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
declare const WebCrawlerDomainNotOwned_base: S.TaggedErrorClass<"WebCrawlerDomainNotOwned", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class WebCrawlerDomainNotOwned extends /*@__PURE__*/ WebCrawlerDomainNotOwned_base {
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl {
    url: string;
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File {
    filename: string;
    fileData?: string | undefined;
    fileId?: string | undefined;
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type;
}
export type InstancesChatCompletionsRequestMessagesItemContentCase1Item = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 | InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2;
export type InstancesChatCompletionsRequestMessagesItemContentCase1List = Array<InstancesChatCompletionsRequestMessagesItemContentCase1Item>;
export type InstancesChatCompletionsRequestMessagesItemContent = string | InstancesChatCompletionsRequestMessagesItemContentCase1List;
export type InstancesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface InstancesChatCompletionsRequestMessagesItem {
    content?: InstancesChatCompletionsRequestMessagesItemContent | null | undefined;
    role: InstancesChatCompletionsRequestMessagesItemRole | (string & {});
}
export type InstancesChatCompletionsRequestMessagesList = Array<InstancesChatCompletionsRequestMessagesItem>;
export type InstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface InstancesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: InstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {}) | undefined;
    enabled?: boolean | undefined;
}
export type InstancesChatCompletionsRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type InstancesChatCompletionsRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: InstancesChatCompletionsRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export interface InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite {
    enabled?: boolean | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    model?: string | undefined;
    rewritePrompt?: string | undefined;
}
export interface InstancesChatCompletionsRequestAiSearchOptionsReranking {
    enabled?: boolean | undefined;
    matchThreshold?: number | undefined;
    model?: string | undefined;
}
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {}) | undefined;
}
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type InstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface InstancesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList | undefined;
    contextExpansion?: number | undefined;
    filters?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap | undefined;
    fusionMethod?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {}) | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {}) | undefined;
    /** Minimum similarity score a chunk must reach to be returned. When omitted, falls back to the instance-level score_threshold, then to 0.4. */
    matchThreshold?: number | undefined;
    /** Maximum number of results to return. When omitted, falls back to the instance-level max_num_results, then to 10. */
    maxNumResults?: number | undefined;
    retrievalType?: InstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {}) | undefined;
    returnOnFailure?: boolean | undefined;
}
export interface InstancesChatCompletionsRequestAiSearchOptions {
    cache?: InstancesChatCompletionsRequestAiSearchOptionsCache | undefined;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: InstancesChatCompletionsRequestAiSearchOptionsCustomMetadataMap | undefined;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite | undefined;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking | undefined;
    retrieval?: InstancesChatCompletionsRequestAiSearchOptionsRetrieval | undefined;
}
export interface ChatCompletionsInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    messages: InstancesChatCompletionsRequestMessagesList;
    aiSearchOptions?: InstancesChatCompletionsRequestAiSearchOptions | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    model?: string | undefined;
    stream?: boolean | undefined;
}
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File {
    filename: string;
    fileData?: string | null | undefined;
    fileId?: string | null | undefined;
}
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type = "file";
export interface InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2 {
    file: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
    type: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type;
}
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1Item = InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 | InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2;
export type InstancesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<InstancesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export type InstancesChatCompletionsResponseChoicesItemMessageContent = string | InstancesChatCompletionsResponseChoicesItemMessageContentCase1List;
export type InstancesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface InstancesChatCompletionsResponseChoicesItemMessage {
    content: InstancesChatCompletionsResponseChoicesItemMessageContent;
    role: InstancesChatCompletionsResponseChoicesItemMessageRole;
}
export interface InstancesChatCompletionsResponseChoicesItem {
    message: InstancesChatCompletionsResponseChoicesItemMessage;
    index?: number | null | undefined;
}
export type InstancesChatCompletionsResponseChoicesList = Array<InstancesChatCompletionsResponseChoicesItem>;
export type InstancesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface InstancesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: InstancesChatCompletionsResponseChunksItemItemMetadataMap | null | undefined;
    timestamp?: number | null | undefined;
}
export type InstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface InstancesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: InstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null | undefined;
    keywordRank?: number | null | undefined;
    keywordScore?: number | null | undefined;
    rerankingScore?: number | null | undefined;
    vectorRank?: number | null | undefined;
    vectorScore?: number | null | undefined;
}
export type InstancesChatCompletionsResponseChunksItemSourceMediaType = "audio" | "video";
export interface InstancesChatCompletionsResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: InstancesChatCompletionsResponseChunksItemItem | null | undefined;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null | undefined;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null | undefined;
    scoringDetails?: InstancesChatCompletionsResponseChunksItemScoringDetails | null | undefined;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: InstancesChatCompletionsResponseChunksItemSourceMediaType | null | undefined;
}
export type InstancesChatCompletionsResponseChunksList = Array<InstancesChatCompletionsResponseChunksItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsInstanceResponse {
    choices: InstancesChatCompletionsResponseChoicesList;
    chunks: InstancesChatCompletionsResponseChunksList;
    id?: string | null | undefined;
    model?: string | null | undefined;
    object?: string | null | undefined;
}
export type NamespacesChatCompletionsRequestAiSearchOptionsInstanceIdsList = Array<string>;
export type NamespacesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface NamespacesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {}) | undefined;
    enabled?: boolean | undefined;
}
export type NamespacesChatCompletionsRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type NamespacesChatCompletionsRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: NamespacesChatCompletionsRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type NamespacesChatCompletionsRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type NamespacesChatCompletionsRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {}) | undefined;
}
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type NamespacesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface NamespacesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList | undefined;
    contextExpansion?: number | undefined;
    filters?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap | undefined;
    fusionMethod?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {}) | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {}) | undefined;
    /** Minimum score a chunk must reach to be returned. When omitted, each instance's chunks are filtered by that instance's score_threshold, capped at the lower of the first instance's score_threshold and 0.4. */
    matchThreshold?: number | undefined;
    /** Maximum number of merged results to return. When omitted, defaults to the first instance's max_num_results, then 10. */
    maxNumResults?: number | undefined;
    retrievalType?: NamespacesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {}) | undefined;
    returnOnFailure?: boolean | undefined;
}
export interface NamespacesChatCompletionsRequestAiSearchOptions {
    instanceIds: NamespacesChatCompletionsRequestAiSearchOptionsInstanceIdsList;
    cache?: NamespacesChatCompletionsRequestAiSearchOptionsCache | undefined;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: NamespacesChatCompletionsRequestAiSearchOptionsCustomMetadataMap | undefined;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite | undefined;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking | undefined;
    retrieval?: NamespacesChatCompletionsRequestAiSearchOptionsRetrieval | undefined;
}
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type;
}
export type NamespacesChatCompletionsRequestMessagesItemContentCase1Item = NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase1 | NamespacesChatCompletionsRequestMessagesItemContentCase1ItemCase2;
export type NamespacesChatCompletionsRequestMessagesItemContentCase1List = Array<NamespacesChatCompletionsRequestMessagesItemContentCase1Item>;
export type NamespacesChatCompletionsRequestMessagesItemContent = string | NamespacesChatCompletionsRequestMessagesItemContentCase1List;
export type NamespacesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesChatCompletionsRequestMessagesItem {
    content?: NamespacesChatCompletionsRequestMessagesItemContent | null | undefined;
    role: NamespacesChatCompletionsRequestMessagesItemRole | (string & {});
}
export type NamespacesChatCompletionsRequestMessagesList = Array<NamespacesChatCompletionsRequestMessagesItem>;
export interface ChatCompletionsNamespaceRequest {
    accountId: string;
    name: string;
    aiSearchOptions: NamespacesChatCompletionsRequestAiSearchOptions;
    messages: NamespacesChatCompletionsRequestMessagesList;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    model?: string | undefined;
    stream?: boolean | undefined;
}
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export interface NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export interface NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File = InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type = "file";
export interface NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2 {
    file: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
    type: NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type;
}
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1Item = NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 | NamespacesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2;
export type NamespacesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<NamespacesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export type NamespacesChatCompletionsResponseChoicesItemMessageContent = string | NamespacesChatCompletionsResponseChoicesItemMessageContentCase1List;
export type NamespacesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesChatCompletionsResponseChoicesItemMessage {
    content: NamespacesChatCompletionsResponseChoicesItemMessageContent;
    role: NamespacesChatCompletionsResponseChoicesItemMessageRole;
}
export interface NamespacesChatCompletionsResponseChoicesItem {
    message: NamespacesChatCompletionsResponseChoicesItemMessage;
    index?: number | null | undefined;
}
export type NamespacesChatCompletionsResponseChoicesList = Array<NamespacesChatCompletionsResponseChoicesItem>;
export type NamespacesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: NamespacesChatCompletionsResponseChunksItemItemMetadataMap | null | undefined;
    timestamp?: number | null | undefined;
}
export type NamespacesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface NamespacesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null | undefined;
    keywordRank?: number | null | undefined;
    keywordScore?: number | null | undefined;
    rerankingScore?: number | null | undefined;
    vectorRank?: number | null | undefined;
    vectorScore?: number | null | undefined;
}
export type NamespacesChatCompletionsResponseChunksItemSourceMediaType = "audio" | "video";
export interface NamespacesChatCompletionsResponseChunksItem {
    id: string;
    instanceId: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesChatCompletionsResponseChunksItemItem | null | undefined;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null | undefined;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null | undefined;
    scoringDetails?: NamespacesChatCompletionsResponseChunksItemScoringDetails | null | undefined;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesChatCompletionsResponseChunksItemSourceMediaType | null | undefined;
}
export type NamespacesChatCompletionsResponseChunksList = Array<NamespacesChatCompletionsResponseChunksItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsNamespaceResponse {
    choices: NamespacesChatCompletionsResponseChoicesList;
    chunks: NamespacesChatCompletionsResponseChunksList;
    id?: string | null | undefined;
    model?: string | null | undefined;
    object?: string | null | undefined;
}
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0Type;
}
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1Type;
}
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2Type;
}
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1Item = NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase0 | NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1 | NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1List = Array<NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1Item>;
export type NamespacesInstancesChatCompletionsRequestMessagesItemContent = string | NamespacesInstancesChatCompletionsRequestMessagesItemContentCase1List;
export type NamespacesInstancesChatCompletionsRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesInstancesChatCompletionsRequestMessagesItem {
    content?: NamespacesInstancesChatCompletionsRequestMessagesItemContent | null | undefined;
    role: NamespacesInstancesChatCompletionsRequestMessagesItemRole | (string & {});
}
export type NamespacesInstancesChatCompletionsRequestMessagesList = Array<NamespacesInstancesChatCompletionsRequestMessagesItem>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCacheCacheThreshold | (string & {}) | undefined;
    enabled?: boolean | undefined;
}
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {}) | undefined;
}
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalBoostByList | undefined;
    contextExpansion?: number | undefined;
    filters?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFiltersMap | undefined;
    fusionMethod?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalFusionMethod | (string & {}) | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {}) | undefined;
    /** Minimum similarity score a chunk must reach to be returned. When omitted, falls back to the instance-level score_threshold, then to 0.4. */
    matchThreshold?: number | undefined;
    /** Maximum number of results to return. When omitted, falls back to the instance-level max_num_results, then to 10. */
    maxNumResults?: number | undefined;
    retrievalType?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrievalRetrievalType | (string & {}) | undefined;
    returnOnFailure?: boolean | undefined;
}
export interface NamespacesInstancesChatCompletionsRequestAiSearchOptions {
    cache?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCache | undefined;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsCustomMetadataMap | undefined;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite | undefined;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking | undefined;
    retrieval?: NamespacesInstancesChatCompletionsRequestAiSearchOptionsRetrieval | undefined;
}
export interface ChatCompletionsNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    messages: NamespacesInstancesChatCompletionsRequestMessagesList;
    aiSearchOptions?: NamespacesInstancesChatCompletionsRequestAiSearchOptions | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    model?: string | undefined;
    stream?: boolean | undefined;
}
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type = "text";
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0Type;
}
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type = "image_url";
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1Type;
}
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File = InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type = "file";
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2 {
    file: InstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2File;
    type: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2Type;
}
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1Item = NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase0 | NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase1 | NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1ItemCase2;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1List = Array<NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1Item>;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageContent = string | NamespacesInstancesChatCompletionsResponseChoicesItemMessageContentCase1List;
export type NamespacesInstancesChatCompletionsResponseChoicesItemMessageRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesInstancesChatCompletionsResponseChoicesItemMessage {
    content: NamespacesInstancesChatCompletionsResponseChoicesItemMessageContent;
    role: NamespacesInstancesChatCompletionsResponseChoicesItemMessageRole;
}
export interface NamespacesInstancesChatCompletionsResponseChoicesItem {
    message: NamespacesInstancesChatCompletionsResponseChoicesItemMessage;
    index?: number | null | undefined;
}
export type NamespacesInstancesChatCompletionsResponseChoicesList = Array<NamespacesInstancesChatCompletionsResponseChoicesItem>;
export type NamespacesInstancesChatCompletionsResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesInstancesChatCompletionsResponseChunksItemItem {
    key: string;
    metadata?: NamespacesInstancesChatCompletionsResponseChunksItemItemMetadataMap | null | undefined;
    timestamp?: number | null | undefined;
}
export type NamespacesInstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface NamespacesInstancesChatCompletionsResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesInstancesChatCompletionsResponseChunksItemScoringDetailsFusionMethod | null | undefined;
    keywordRank?: number | null | undefined;
    keywordScore?: number | null | undefined;
    rerankingScore?: number | null | undefined;
    vectorRank?: number | null | undefined;
    vectorScore?: number | null | undefined;
}
export type NamespacesInstancesChatCompletionsResponseChunksItemSourceMediaType = "audio" | "video";
export interface NamespacesInstancesChatCompletionsResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesInstancesChatCompletionsResponseChunksItemItem | null | undefined;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null | undefined;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null | undefined;
    scoringDetails?: NamespacesInstancesChatCompletionsResponseChunksItemScoringDetails | null | undefined;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesInstancesChatCompletionsResponseChunksItemSourceMediaType | null | undefined;
}
export type NamespacesInstancesChatCompletionsResponseChunksList = Array<NamespacesInstancesChatCompletionsResponseChunksItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ChatCompletionsNamespaceInstanceResponse {
    choices: NamespacesInstancesChatCompletionsResponseChoicesList;
    chunks: NamespacesInstancesChatCompletionsResponseChunksList;
    id?: string | null | undefined;
    model?: string | null | undefined;
    object?: string | null | undefined;
}
export interface ChunksNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    limit?: number | undefined;
    offset?: number | undefined;
}
export type NamespacesInstancesItemsChunksResultItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesInstancesItemsChunksResultItemItem {
    key: string;
    metadata?: NamespacesInstancesItemsChunksResultItemItemMetadataMap | null | undefined;
    timestamp?: number | null | undefined;
}
export type NamespacesInstancesItemsChunksResultItemSourceMediaType = "audio" | "video";
export interface NamespacesInstancesItemsChunksResultItem {
    id: string;
    item: NamespacesInstancesItemsChunksResultItemItem;
    text: string;
    endByte?: number | null | undefined;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the chunk covers. */
    mediaEndMs?: number | null | undefined;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the chunk begins in. */
    mediaStartMs?: number | null | undefined;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesInstancesItemsChunksResultItemSourceMediaType | null | undefined;
    startByte?: number | null | undefined;
}
export type NamespacesInstancesItemsChunksResultList = Array<NamespacesInstancesItemsChunksResultItem>;
export type ChunksNamespaceInstanceItemResponse = NamespacesInstancesItemsChunksResultList;
export type InstancesCreateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesCreateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesCreateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesCreateRequestCustomMetadataItem {
    dataType: InstancesCreateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export type InstancesCreateRequestCustomMetadataList = Array<InstancesCreateRequestCustomMetadataItem>;
export type InstancesCreateRequestFusionMethod = "max" | "rrf";
export interface InstancesCreateRequestIndexMethod {
    /** Enable keyword (BM25) storage backend. */
    keyword: boolean;
    /** Enable vector (embedding) storage backend. */
    vector: boolean;
}
export type InstancesCreateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesCreateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesCreateRequestIndexingOptionsKeywordTokenizer | (string & {}) | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | undefined;
}
export type InstancesCreateRequestMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesCreateRequestMetadataCreatedFromEmdashPlugin {
    type: InstancesCreateRequestMetadataCreatedFromEmdashPluginType | (string & {});
    version: string;
}
export interface InstancesCreateRequestMetadata {
    createdFromAisearchWizard?: boolean | undefined;
    createdFromEmdashPlugin?: InstancesCreateRequestMetadataCreatedFromEmdashPlugin | undefined;
    workerDomain?: string | undefined;
}
export type InstancesCreateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export interface InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint {
    /** Disable chat completions endpoint for this public endpoint. */
    disabled?: boolean | undefined;
}
export type InstancesCreateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export interface InstancesCreateRequestPublicEndpointParamsMcp {
    description?: string | undefined;
    /** Disable MCP endpoint for this public endpoint. */
    disabled?: boolean | undefined;
}
export type InstancesCreateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesCreateRequestPublicEndpointParamsRateLimit {
    periodMs?: number | undefined;
    requests?: number | undefined;
    technique?: InstancesCreateRequestPublicEndpointParamsRateLimitTechnique | (string & {}) | undefined;
}
export interface InstancesCreateRequestPublicEndpointParamsSearchEndpoint {
    /** Disable search endpoint for this public endpoint. */
    disabled?: boolean | undefined;
}
export interface InstancesCreateRequestPublicEndpointParams {
    authorizedHosts?: InstancesCreateRequestPublicEndpointParamsAuthorizedHostsList | undefined;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesCreateRequestPublicEndpointParamsCustomDomainsList | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | undefined;
    enabled?: boolean | undefined;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp | undefined;
    rateLimit?: InstancesCreateRequestPublicEndpointParamsRateLimit | undefined;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint | undefined;
}
export type InstancesCreateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesCreateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesCreateRequestRetrievalOptionsBoostByItemDirection | (string & {}) | undefined;
}
export type InstancesCreateRequestRetrievalOptionsBoostByList = Array<InstancesCreateRequestRetrievalOptionsBoostByItem>;
export type InstancesCreateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesCreateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesCreateRequestRetrievalOptionsBoostByList | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesCreateRequestRetrievalOptionsKeywordMatchMode | (string & {}) | undefined;
}
export type InstancesCreateRequestSourceParamsExcludeItemsList = Array<string>;
export type InstancesCreateRequestSourceParamsIncludeItemsList = Array<string>;
export type InstancesCreateRequestSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesCreateRequestSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesCreateRequestSourceParamsWebCrawlerDiscoverOptionsSource | (string & {}) | undefined;
}
export interface InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem {
    /** Glob pattern to match against the page URL path. Uses standard glob syntax: * matches within a segment, ** crosses directories. */
    path: string;
    /** CSS selector to extract content from pages matching the path pattern. Disallowed characters: ;, `, $, {, }, . Must target a single element; if multiple elements match, the crawler ignores the selector and uses the full page. */
    selector: string;
}
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesCreateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | undefined;
    includeImages?: boolean | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | undefined;
    useBrowserRendering?: boolean | undefined;
}
export type InstancesCreateRequestSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export type WebCrawlerCrawlOptionsSource = "all" | "sitemaps" | "links";
export interface WebCrawlerCrawlOptions {
    /** Maximum crawl depth from the seed URL. */
    depth?: number | null | undefined;
    includeExternalLinks?: boolean | null | undefined;
    includeSubdomains?: boolean | null | undefined;
    maxAge?: number | null | undefined;
    /** Where the crawler discovers URLs: sitemaps, page links, or both. Use links for sitemap-less seeds (avoids missing_sitemap rejections). */
    source?: WebCrawlerCrawlOptionsSource | (string & {}) | null | undefined;
}
export interface InstancesCreateRequestSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesCreateRequestSourceParamsWebCrawlerDiscoverOptions | undefined;
    parseOptions?: InstancesCreateRequestSourceParamsWebCrawlerParseOptions | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesCreateRequestSourceParamsWebCrawlerParseType | (string & {}) | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | undefined;
}
export interface InstancesCreateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesCreateRequestSourceParamsExcludeItemsList | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesCreateRequestSourceParamsIncludeItemsList | undefined;
    prefix?: string | undefined;
    r2Jurisdiction?: string | undefined;
    webCrawler?: InstancesCreateRequestSourceParamsWebCrawler | undefined;
}
export type InstancesCreateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesCreateRequestType = "r2" | "web-crawler";
export interface CreateInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiGatewayId?: string | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | undefined;
    cache?: boolean | undefined;
    cacheThreshold?: InstancesCreateRequestCacheThreshold | (string & {}) | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesCreateRequestCacheTtl | (number & {}) | undefined;
    chunk?: boolean | undefined;
    chunkOverlap?: number | undefined;
    chunkSize?: number | undefined;
    customMetadata?: InstancesCreateRequestCustomMetadataList | undefined;
    embeddingModel?: string | undefined;
    fusionMethod?: InstancesCreateRequestFusionMethod | (string & {}) | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | undefined;
    indexingOptions?: InstancesCreateRequestIndexingOptions | undefined;
    maxNumResults?: number | undefined;
    metadata?: InstancesCreateRequestMetadata | undefined;
    publicEndpointParams?: InstancesCreateRequestPublicEndpointParams | undefined;
    reranking?: boolean | undefined;
    rerankingModel?: string | undefined;
    retrievalOptions?: InstancesCreateRequestRetrievalOptions | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | undefined;
    rewriteQuery?: boolean | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | undefined;
    source?: string | undefined;
    sourceParams?: InstancesCreateRequestSourceParams | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: InstancesCreateRequestSyncInterval | (number & {}) | undefined;
    tokenId?: string | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesCreateRequestType | (string & {}) | undefined;
}
export type InstancesCreateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesCreateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesCreateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesCreateResponseCustomMetadataItem {
    dataType: InstancesCreateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesCreateResponseCustomMetadataList = Array<InstancesCreateResponseCustomMetadataItem>;
export type InstancesCreateResponseFusionMethod = "max" | "rrf";
export type InstancesCreateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesCreateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesCreateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesCreateResponseIndexingOptionsKeywordTokenizer | null | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null | undefined;
}
export type InstancesCreateResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesCreateResponseMetadataCreatedFromEmdashPlugin {
    type: InstancesCreateResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesCreateResponseMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: InstancesCreateResponseMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type InstancesCreateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export interface InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint {
    /** Disable chat completions endpoint for this public endpoint. */
    disabled?: boolean | null | undefined;
}
export type InstancesCreateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export interface InstancesCreateResponsePublicEndpointParamsMcp {
    description?: string | null | undefined;
    /** Disable MCP endpoint for this public endpoint. */
    disabled?: boolean | null | undefined;
}
export type InstancesCreateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesCreateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: InstancesCreateResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export interface InstancesCreateResponsePublicEndpointParamsSearchEndpoint {
    /** Disable search endpoint for this public endpoint. */
    disabled?: boolean | null | undefined;
}
export interface InstancesCreateResponsePublicEndpointParams {
    authorizedHosts?: InstancesCreateResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesCreateResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: InstancesCreateResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export type InstancesCreateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesCreateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesCreateResponseRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type InstancesCreateResponseRetrievalOptionsBoostByList = Array<InstancesCreateResponseRetrievalOptionsBoostByItem>;
export type InstancesCreateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesCreateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesCreateResponseRetrievalOptionsBoostByList | null | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesCreateResponseRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type InstancesCreateResponseSourceParamsExcludeItemsList = Array<string>;
export type InstancesCreateResponseSourceParamsIncludeItemsList = Array<string>;
export type InstancesCreateResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesCreateResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesCreateResponseSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesCreateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type InstancesCreateResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesCreateResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesCreateResponseSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: InstancesCreateResponseSourceParamsWebCrawlerParseOptions | null | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesCreateResponseSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface InstancesCreateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesCreateResponseSourceParamsExcludeItemsList | null | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesCreateResponseSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: InstancesCreateResponseSourceParamsWebCrawler | null | undefined;
}
export type InstancesCreateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesCreateResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null | undefined;
    cache?: boolean | null | undefined;
    cacheThreshold?: InstancesCreateResponseCacheThreshold | null | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesCreateResponseCacheTtl | null | undefined;
    chunkOverlap?: number | null | undefined;
    chunkSize?: number | null | undefined;
    createdBy?: string | null | undefined;
    customMetadata?: InstancesCreateResponseCustomMetadataList | null | undefined;
    embeddingModel?: string | null | undefined;
    enable?: boolean | null | undefined;
    engineVersion?: number | null | undefined;
    fusionMethod?: InstancesCreateResponseFusionMethod | null | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null | undefined;
    indexingOptions?: InstancesCreateResponseIndexingOptions | null | undefined;
    lastActivity?: string | null | undefined;
    maxNumResults?: number | null | undefined;
    metadata?: InstancesCreateResponseMetadata | null | undefined;
    modifiedBy?: string | null | undefined;
    namespace?: string | null | undefined;
    paused?: boolean | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: InstancesCreateResponsePublicEndpointParams | null | undefined;
    reranking?: boolean | null | undefined;
    rerankingModel?: string | null | undefined;
    retrievalOptions?: InstancesCreateResponseRetrievalOptions | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null | undefined;
    rewriteQuery?: boolean | null | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null | undefined;
    source?: string | null | undefined;
    sourceParams?: InstancesCreateResponseSourceParams | null | undefined;
    status?: string | null | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: InstancesCreateResponseSyncInterval | null | undefined;
    tokenId?: string | null | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesCreateResponseType | null | undefined;
}
export interface CreateInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    description?: string | undefined;
}
export type InstancesJobsCreateResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceJobResponse {
    id: string;
    source: InstancesJobsCreateResponseSource;
    description?: string | null | undefined;
    endReason?: string | null | undefined;
    endedAt?: string | null | undefined;
    lastSeenAt?: string | null | undefined;
    startedAt?: string | null | undefined;
}
export type NamespacesCreateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesCreateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesCreateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesCreateRequestPublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesCreateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type NamespacesCreateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesCreateRequestPublicEndpointParamsRateLimit {
    periodMs?: number | undefined;
    requests?: number | undefined;
    technique?: NamespacesCreateRequestPublicEndpointParamsRateLimitTechnique | (string & {}) | undefined;
}
export type NamespacesCreateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface NamespacesCreateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesCreateRequestPublicEndpointParamsAuthorizedHostsList | undefined;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesCreateRequestPublicEndpointParamsCustomDomainsList | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | undefined;
    enabled?: boolean | undefined;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesCreateRequestPublicEndpointParamsInstancesAllowedList | undefined;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp | undefined;
    rateLimit?: NamespacesCreateRequestPublicEndpointParamsRateLimit | undefined;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint | undefined;
}
export interface CreateNamespaceRequest {
    accountId: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | undefined;
    publicEndpointParams?: NamespacesCreateRequestPublicEndpointParams | undefined;
}
export type NamespacesCreateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesCreateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesCreateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesCreateResponsePublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesCreateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesCreateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesCreateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesCreateResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesCreateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesCreateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesCreateResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesCreateResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesCreateResponsePublicEndpointParamsInstancesAllowedList | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesCreateResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: NamespacesCreateResponsePublicEndpointParams | null | undefined;
}
export type NamespacesInstancesCreateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesCreateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesCreateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesCreateRequestCustomMetadataItem {
    dataType: NamespacesInstancesCreateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export type NamespacesInstancesCreateRequestCustomMetadataList = Array<NamespacesInstancesCreateRequestCustomMetadataItem>;
export type NamespacesInstancesCreateRequestFusionMethod = "max" | "rrf";
export type NamespacesInstancesCreateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesCreateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesCreateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesCreateRequestIndexingOptionsKeywordTokenizer | (string & {}) | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | undefined;
}
export type NamespacesInstancesCreateRequestMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesCreateRequestMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesCreateRequestMetadataCreatedFromEmdashPluginType | (string & {});
    version: string;
}
export interface NamespacesInstancesCreateRequestMetadata {
    createdFromAisearchWizard?: boolean | undefined;
    createdFromEmdashPlugin?: NamespacesInstancesCreateRequestMetadataCreatedFromEmdashPlugin | undefined;
    workerDomain?: string | undefined;
}
export type NamespacesInstancesCreateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesCreateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesCreateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type NamespacesInstancesCreateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesCreateRequestPublicEndpointParamsRateLimit {
    periodMs?: number | undefined;
    requests?: number | undefined;
    technique?: NamespacesInstancesCreateRequestPublicEndpointParamsRateLimitTechnique | (string & {}) | undefined;
}
export type NamespacesInstancesCreateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesCreateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesCreateRequestPublicEndpointParamsAuthorizedHostsList | undefined;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesCreateRequestPublicEndpointParamsCustomDomainsList | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | undefined;
    enabled?: boolean | undefined;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp | undefined;
    rateLimit?: NamespacesInstancesCreateRequestPublicEndpointParamsRateLimit | undefined;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint | undefined;
}
export type NamespacesInstancesCreateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesCreateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesCreateRequestRetrievalOptionsBoostByItemDirection | (string & {}) | undefined;
}
export type NamespacesInstancesCreateRequestRetrievalOptionsBoostByList = Array<NamespacesInstancesCreateRequestRetrievalOptionsBoostByItem>;
export type NamespacesInstancesCreateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesCreateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesCreateRequestRetrievalOptionsBoostByList | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesCreateRequestRetrievalOptionsKeywordMatchMode | (string & {}) | undefined;
}
export type NamespacesInstancesCreateRequestSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesCreateRequestSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesCreateRequestSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerDiscoverOptionsSource | (string & {}) | undefined;
}
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | undefined;
    includeImages?: boolean | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | undefined;
    useBrowserRendering?: boolean | undefined;
}
export type NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesCreateRequestSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerDiscoverOptions | undefined;
    parseOptions?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseOptions | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesCreateRequestSourceParamsWebCrawlerParseType | (string & {}) | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | undefined;
}
export interface NamespacesInstancesCreateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesCreateRequestSourceParamsExcludeItemsList | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesCreateRequestSourceParamsIncludeItemsList | undefined;
    prefix?: string | undefined;
    r2Jurisdiction?: string | undefined;
    webCrawler?: NamespacesInstancesCreateRequestSourceParamsWebCrawler | undefined;
}
export type NamespacesInstancesCreateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesCreateRequestType = "r2" | "web-crawler";
export interface CreateNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiGatewayId?: string | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | undefined;
    cache?: boolean | undefined;
    cacheThreshold?: NamespacesInstancesCreateRequestCacheThreshold | (string & {}) | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesCreateRequestCacheTtl | (number & {}) | undefined;
    chunk?: boolean | undefined;
    chunkOverlap?: number | undefined;
    chunkSize?: number | undefined;
    customMetadata?: NamespacesInstancesCreateRequestCustomMetadataList | undefined;
    embeddingModel?: string | undefined;
    fusionMethod?: NamespacesInstancesCreateRequestFusionMethod | (string & {}) | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | undefined;
    indexingOptions?: NamespacesInstancesCreateRequestIndexingOptions | undefined;
    maxNumResults?: number | undefined;
    metadata?: NamespacesInstancesCreateRequestMetadata | undefined;
    publicEndpointParams?: NamespacesInstancesCreateRequestPublicEndpointParams | undefined;
    reranking?: boolean | undefined;
    rerankingModel?: string | undefined;
    retrievalOptions?: NamespacesInstancesCreateRequestRetrievalOptions | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | undefined;
    rewriteQuery?: boolean | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | undefined;
    source?: string | undefined;
    sourceParams?: NamespacesInstancesCreateRequestSourceParams | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: NamespacesInstancesCreateRequestSyncInterval | (number & {}) | undefined;
    tokenId?: string | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesCreateRequestType | (string & {}) | undefined;
}
export type NamespacesInstancesCreateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesCreateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesCreateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesCreateResponseCustomMetadataItem {
    dataType: NamespacesInstancesCreateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesCreateResponseCustomMetadataList = Array<NamespacesInstancesCreateResponseCustomMetadataItem>;
export type NamespacesInstancesCreateResponseFusionMethod = "max" | "rrf";
export type NamespacesInstancesCreateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesCreateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesCreateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesCreateResponseIndexingOptionsKeywordTokenizer | null | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null | undefined;
}
export type NamespacesInstancesCreateResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesCreateResponseMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesCreateResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesCreateResponseMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: NamespacesInstancesCreateResponseMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type NamespacesInstancesCreateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesCreateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesCreateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesInstancesCreateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesCreateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesInstancesCreateResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesInstancesCreateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesCreateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesCreateResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesCreateResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesInstancesCreateResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export type NamespacesInstancesCreateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesCreateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesCreateResponseRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type NamespacesInstancesCreateResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesCreateResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesCreateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesCreateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesCreateResponseRetrievalOptionsBoostByList | null | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesCreateResponseRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type NamespacesInstancesCreateResponseSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesCreateResponseSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesCreateResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesCreateResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseOptions | null | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesCreateResponseSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface NamespacesInstancesCreateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesCreateResponseSourceParamsExcludeItemsList | null | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesCreateResponseSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: NamespacesInstancesCreateResponseSourceParamsWebCrawler | null | undefined;
}
export type NamespacesInstancesCreateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesCreateResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null | undefined;
    cache?: boolean | null | undefined;
    cacheThreshold?: NamespacesInstancesCreateResponseCacheThreshold | null | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesCreateResponseCacheTtl | null | undefined;
    chunkOverlap?: number | null | undefined;
    chunkSize?: number | null | undefined;
    createdBy?: string | null | undefined;
    customMetadata?: NamespacesInstancesCreateResponseCustomMetadataList | null | undefined;
    embeddingModel?: string | null | undefined;
    enable?: boolean | null | undefined;
    engineVersion?: number | null | undefined;
    fusionMethod?: NamespacesInstancesCreateResponseFusionMethod | null | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null | undefined;
    indexingOptions?: NamespacesInstancesCreateResponseIndexingOptions | null | undefined;
    lastActivity?: string | null | undefined;
    maxNumResults?: number | null | undefined;
    metadata?: NamespacesInstancesCreateResponseMetadata | null | undefined;
    modifiedBy?: string | null | undefined;
    namespace?: string | null | undefined;
    paused?: boolean | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: NamespacesInstancesCreateResponsePublicEndpointParams | null | undefined;
    reranking?: boolean | null | undefined;
    rerankingModel?: string | null | undefined;
    retrievalOptions?: NamespacesInstancesCreateResponseRetrievalOptions | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null | undefined;
    rewriteQuery?: boolean | null | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null | undefined;
    source?: string | null | undefined;
    sourceParams?: NamespacesInstancesCreateResponseSourceParams | null | undefined;
    status?: string | null | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: NamespacesInstancesCreateResponseSyncInterval | null | undefined;
    tokenId?: string | null | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesCreateResponseType | null | undefined;
}
export interface CreateNamespaceInstanceJobRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    description?: string | undefined;
}
export type NamespacesInstancesJobsCreateResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsCreateResponseSource;
    description?: string | null | undefined;
    endReason?: string | null | undefined;
    endedAt?: string | null | undefined;
    lastSeenAt?: string | null | undefined;
    startedAt?: string | null | undefined;
}
export type NamespacesInstancesItemsCreateOrUpdateRequestNextAction = "INDEX";
export interface CreateOrUpdateNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    /** Item key / filename. Must not exceed 128 characters. */
    key: string;
    nextAction: NamespacesInstancesItemsCreateOrUpdateRequestNextAction | (string & {});
    /** Wait for indexing before responding. After processing, vector-indexed instances use any time remaining in a 25s wait budget to confirm Vectorize ingestion. Processing itself continues uninterrupted and can exceed that budget. If confirmation times out, the response returns the current item state and background indexing continues. Defaults to false. */
    waitForCompletion?: boolean | undefined;
}
export type NamespacesInstancesItemsCreateOrUpdateResponseMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsCreateOrUpdateResponseMetadataMap = {
    [key: string]: NamespacesInstancesItemsCreateOrUpdateResponseMetadataValue | undefined;
};
export type NamespacesInstancesItemsCreateOrUpdateResponseNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsCreateOrUpdateResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOrUpdateNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsCreateOrUpdateResponseMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsCreateOrUpdateResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsCreateOrUpdateResponseStatus;
    error?: string | null | undefined;
}
export interface CreateTokenRequest {
    accountId: string;
    cfApiId: string;
    cfApiKey: string;
    name: string;
    legacy?: boolean | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null | undefined;
    enabled?: boolean | null | undefined;
    legacy?: boolean | null | undefined;
    modifiedBy?: string | null | undefined;
}
export interface DeleteInstanceRequest {
    accountId: string;
    id: string;
}
export type InstancesDeleteResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesDeleteResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesDeleteResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesDeleteResponseCustomMetadataItem {
    dataType: InstancesDeleteResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesDeleteResponseCustomMetadataList = Array<InstancesDeleteResponseCustomMetadataItem>;
export type InstancesDeleteResponseFusionMethod = "max" | "rrf";
export type InstancesDeleteResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesDeleteResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesDeleteResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesDeleteResponseIndexingOptionsKeywordTokenizer | null | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null | undefined;
}
export type InstancesDeleteResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesDeleteResponseMetadataCreatedFromEmdashPlugin {
    type: InstancesDeleteResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesDeleteResponseMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: InstancesDeleteResponseMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type InstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type InstancesDeleteResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type InstancesDeleteResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type InstancesDeleteResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type InstancesDeleteResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesDeleteResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: InstancesDeleteResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type InstancesDeleteResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface InstancesDeleteResponsePublicEndpointParams {
    authorizedHosts?: InstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesDeleteResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: InstancesDeleteResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export type InstancesDeleteResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesDeleteResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesDeleteResponseRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type InstancesDeleteResponseRetrievalOptionsBoostByList = Array<InstancesDeleteResponseRetrievalOptionsBoostByItem>;
export type InstancesDeleteResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesDeleteResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesDeleteResponseRetrievalOptionsBoostByList | null | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesDeleteResponseRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type InstancesDeleteResponseSourceParamsExcludeItemsList = Array<string>;
export type InstancesDeleteResponseSourceParamsIncludeItemsList = Array<string>;
export type InstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesDeleteResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type InstancesDeleteResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesDeleteResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: InstancesDeleteResponseSourceParamsWebCrawlerParseOptions | null | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesDeleteResponseSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface InstancesDeleteResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesDeleteResponseSourceParamsExcludeItemsList | null | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesDeleteResponseSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: InstancesDeleteResponseSourceParamsWebCrawler | null | undefined;
}
export type InstancesDeleteResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesDeleteResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null | undefined;
    cache?: boolean | null | undefined;
    cacheThreshold?: InstancesDeleteResponseCacheThreshold | null | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesDeleteResponseCacheTtl | null | undefined;
    chunkOverlap?: number | null | undefined;
    chunkSize?: number | null | undefined;
    createdBy?: string | null | undefined;
    customMetadata?: InstancesDeleteResponseCustomMetadataList | null | undefined;
    embeddingModel?: string | null | undefined;
    enable?: boolean | null | undefined;
    engineVersion?: number | null | undefined;
    fusionMethod?: InstancesDeleteResponseFusionMethod | null | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null | undefined;
    indexingOptions?: InstancesDeleteResponseIndexingOptions | null | undefined;
    lastActivity?: string | null | undefined;
    maxNumResults?: number | null | undefined;
    metadata?: InstancesDeleteResponseMetadata | null | undefined;
    modifiedBy?: string | null | undefined;
    namespace?: string | null | undefined;
    paused?: boolean | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: InstancesDeleteResponsePublicEndpointParams | null | undefined;
    reranking?: boolean | null | undefined;
    rerankingModel?: string | null | undefined;
    retrievalOptions?: InstancesDeleteResponseRetrievalOptions | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null | undefined;
    rewriteQuery?: boolean | null | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null | undefined;
    source?: string | null | undefined;
    sourceParams?: InstancesDeleteResponseSourceParams | null | undefined;
    status?: string | null | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: InstancesDeleteResponseSyncInterval | null | undefined;
    tokenId?: string | null | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesDeleteResponseType | null | undefined;
}
export interface DeleteNamespaceRequest {
    accountId: string;
    name: string;
}
export type DeleteNamespaceResponse = unknown;
export interface DeleteNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    id: string;
}
export type NamespacesInstancesDeleteResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesDeleteResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesDeleteResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesDeleteResponseCustomMetadataItem {
    dataType: NamespacesInstancesDeleteResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesDeleteResponseCustomMetadataList = Array<NamespacesInstancesDeleteResponseCustomMetadataItem>;
export type NamespacesInstancesDeleteResponseFusionMethod = "max" | "rrf";
export type NamespacesInstancesDeleteResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesDeleteResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesDeleteResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesDeleteResponseIndexingOptionsKeywordTokenizer | null | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null | undefined;
}
export type NamespacesInstancesDeleteResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesDeleteResponseMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesDeleteResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesDeleteResponseMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: NamespacesInstancesDeleteResponseMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type NamespacesInstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesInstancesDeleteResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesDeleteResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesDeleteResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesDeleteResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesInstancesDeleteResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export type NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type NamespacesInstancesDeleteResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesDeleteResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesDeleteResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesDeleteResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesDeleteResponseRetrievalOptionsBoostByList | null | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesDeleteResponseRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type NamespacesInstancesDeleteResponseSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesDeleteResponseSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesDeleteResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseOptions | null | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesDeleteResponseSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface NamespacesInstancesDeleteResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesDeleteResponseSourceParamsExcludeItemsList | null | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesDeleteResponseSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: NamespacesInstancesDeleteResponseSourceParamsWebCrawler | null | undefined;
}
export type NamespacesInstancesDeleteResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesDeleteResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null | undefined;
    cache?: boolean | null | undefined;
    cacheThreshold?: NamespacesInstancesDeleteResponseCacheThreshold | null | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesDeleteResponseCacheTtl | null | undefined;
    chunkOverlap?: number | null | undefined;
    chunkSize?: number | null | undefined;
    createdBy?: string | null | undefined;
    customMetadata?: NamespacesInstancesDeleteResponseCustomMetadataList | null | undefined;
    embeddingModel?: string | null | undefined;
    enable?: boolean | null | undefined;
    engineVersion?: number | null | undefined;
    fusionMethod?: NamespacesInstancesDeleteResponseFusionMethod | null | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null | undefined;
    indexingOptions?: NamespacesInstancesDeleteResponseIndexingOptions | null | undefined;
    lastActivity?: string | null | undefined;
    maxNumResults?: number | null | undefined;
    metadata?: NamespacesInstancesDeleteResponseMetadata | null | undefined;
    modifiedBy?: string | null | undefined;
    namespace?: string | null | undefined;
    paused?: boolean | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: NamespacesInstancesDeleteResponsePublicEndpointParams | null | undefined;
    reranking?: boolean | null | undefined;
    rerankingModel?: string | null | undefined;
    retrievalOptions?: NamespacesInstancesDeleteResponseRetrievalOptions | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null | undefined;
    rewriteQuery?: boolean | null | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null | undefined;
    source?: string | null | undefined;
    sourceParams?: NamespacesInstancesDeleteResponseSourceParams | null | undefined;
    status?: string | null | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: NamespacesInstancesDeleteResponseSyncInterval | null | undefined;
    tokenId?: string | null | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesDeleteResponseType | null | undefined;
}
export interface DeleteNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteNamespaceInstanceItemResponse {
    key: string;
}
export interface DeleteTokenRequest {
    accountId: string;
    id: string;
}
export type DeleteTokenResponse = unknown;
export interface DownloadNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
export interface DownloadNamespaceInstanceItemResponse {
}
export interface GetInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
}
export type InstancesJobsGetResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInstanceJobResponse {
    id: string;
    source: InstancesJobsGetResponseSource;
    description?: string | null | undefined;
    endReason?: string | null | undefined;
    endedAt?: string | null | undefined;
    lastSeenAt?: string | null | undefined;
    startedAt?: string | null | undefined;
}
export interface GetNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
}
export type NamespacesInstancesItemsGetResponseMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsGetResponseMetadataMap = {
    [key: string]: NamespacesInstancesItemsGetResponseMetadataValue | undefined;
};
export type NamespacesInstancesItemsGetResponseNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsGetResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsGetResponseMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsGetResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsGetResponseStatus;
    error?: string | null | undefined;
}
export interface GetNamespaceInstanceJobRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
}
export type NamespacesInstancesJobsGetResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsGetResponseSource;
    description?: string | null | undefined;
    endReason?: string | null | undefined;
    endedAt?: string | null | undefined;
    lastSeenAt?: string | null | undefined;
    startedAt?: string | null | undefined;
}
export interface ListInstanceJobsRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    page?: number | undefined;
    perPage?: number | undefined;
}
export type InstancesJobsListResultItemSource = "user" | "schedule";
export interface InstancesJobsListResultItem {
    id: string;
    source: InstancesJobsListResultItemSource;
    description?: string | null | undefined;
    endReason?: string | null | undefined;
    endedAt?: string | null | undefined;
    lastSeenAt?: string | null | undefined;
    startedAt?: string | null | undefined;
}
export type InstancesJobsListResultList = Array<InstancesJobsListResultItem>;
export interface ListInstanceJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesJobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type InstancesListRequestOrderBy = "created_at";
export type InstancesListRequestOrderByDirection = "asc" | "desc";
export interface ListInstancesRequest {
    accountId: string;
    /** Return only instances with this exact Search for Agents hostname (case-insensitive). */
    hostname?: string | undefined;
    /** Return only instances in this namespace. */
    namespace?: string | undefined;
    /** Field to order results by. */
    orderBy?: InstancesListRequestOrderBy | (string & {}) | undefined;
    /** Order direction. */
    orderByDirection?: InstancesListRequestOrderByDirection | (string & {}) | undefined;
    /** Page number (1-indexed). */
    page?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Filter instances whose id contains this string (case-insensitive). */
    search?: string | undefined;
}
export type InstancesListResultItemCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesListResultItemCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesListResultItemCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesListResultItemCustomMetadataItem {
    dataType: InstancesListResultItemCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesListResultItemCustomMetadataList = Array<InstancesListResultItemCustomMetadataItem>;
export type InstancesListResultItemFusionMethod = "max" | "rrf";
export interface InstancesListResultItemIndexMethod {
    keyword: boolean;
    vector: boolean;
}
export type InstancesListResultItemIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesListResultItemIndexingOptions {
    keywordTokenizer?: InstancesListResultItemIndexingOptionsKeywordTokenizer | null | undefined;
    useOcr?: boolean | null | undefined;
}
export type InstancesListResultItemMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesListResultItemMetadataCreatedFromEmdashPlugin {
    type: InstancesListResultItemMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesListResultItemMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: InstancesListResultItemMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type InstancesListResultItemPublicEndpointParamsAuthorizedHostsList = Array<string>;
export interface InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint {
    disabled?: boolean | null | undefined;
}
export type InstancesListResultItemPublicEndpointParamsCustomDomainsList = Array<string>;
export interface InstancesListResultItemPublicEndpointParamsMcp {
    description?: string | null | undefined;
    disabled?: boolean | null | undefined;
}
export type InstancesListResultItemPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesListResultItemPublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: InstancesListResultItemPublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type InstancesListResultItemPublicEndpointParamsSearchEndpoint = InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint;
export interface InstancesListResultItemPublicEndpointParams {
    authorizedHosts?: InstancesListResultItemPublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    customDomains?: InstancesListResultItemPublicEndpointParamsCustomDomainsList | null | undefined;
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesListResultItemPublicEndpointParamsMcp | null | undefined;
    rateLimit?: InstancesListResultItemPublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint | null | undefined;
}
export type InstancesListResultItemRetrievalOptionsBoostByItemDataType = "number" | "datetime" | "text" | "boolean";
export type InstancesListResultItemRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesListResultItemRetrievalOptionsBoostByItem {
    field: string;
    dataType?: InstancesListResultItemRetrievalOptionsBoostByItemDataType | null | undefined;
    direction?: InstancesListResultItemRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type InstancesListResultItemRetrievalOptionsBoostByList = Array<InstancesListResultItemRetrievalOptionsBoostByItem>;
export type InstancesListResultItemRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesListResultItemRetrievalOptions {
    boostBy?: InstancesListResultItemRetrievalOptionsBoostByList | null | undefined;
    keywordMatchMode?: InstancesListResultItemRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type InstancesListResultItemSourceParamsExcludeItemsList = Array<string>;
export type InstancesListResultItemSourceParamsIncludeItemsList = Array<string>;
export type InstancesListResultItemSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesListResultItemSourceParamsWebCrawlerDiscoverOptions {
    depth?: number | null | undefined;
    includeExternalLinks?: boolean | null | undefined;
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl. New values have a maximum of 100000; instances configured before that cap may report a higher stored value, which the crawler clamps at run time. */
    limit?: number | null | undefined;
    maxAge?: number | null | undefined;
    source?: InstancesListResultItemSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export interface InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem {
    path: string;
    selector: string;
}
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesListResultItemSourceParamsWebCrawlerParseOptions {
    contentSelector?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    includeHeaders?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    specificSitemaps?: InstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type InstancesListResultItemSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesListResultItemSourceParamsWebCrawler {
    discoverOptions?: InstancesListResultItemSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: InstancesListResultItemSourceParamsWebCrawlerParseOptions | null | undefined;
    parseType?: InstancesListResultItemSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface InstancesListResultItemSourceParams {
    excludeItems?: InstancesListResultItemSourceParamsExcludeItemsList | null | undefined;
    includeItems?: InstancesListResultItemSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: InstancesListResultItemSourceParamsWebCrawler | null | undefined;
}
export type InstancesListResultItemSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesListResultItemType = "r2" | "web-crawler";
export interface InstancesListResultItem {
    id: string;
    aiGatewayId: string;
    aiSearchModel: string;
    cache: boolean;
    cacheThreshold: InstancesListResultItemCacheThreshold;
    cacheTtl: InstancesListResultItemCacheTtl;
    chunk: boolean;
    chunkOverlap: number;
    chunkSize: number;
    createdAt: string;
    createdBy: string;
    customMetadata: InstancesListResultItemCustomMetadataList;
    embeddingModel: string;
    enable: boolean;
    engineVersion: number;
    fusionMethod: InstancesListResultItemFusionMethod;
    hybridSearchEnabled: boolean;
    indexMethod: InstancesListResultItemIndexMethod;
    indexingOptions: InstancesListResultItemIndexingOptions;
    lastActivity: string;
    maxNumResults: number;
    metadata: InstancesListResultItemMetadata;
    modifiedAt: string;
    modifiedBy: string;
    namespace: string;
    paused: boolean;
    publicEndpointId: string;
    publicEndpointParams: InstancesListResultItemPublicEndpointParams;
    reranking: boolean;
    rerankingModel: string;
    retrievalOptions: InstancesListResultItemRetrievalOptions;
    rewriteModel: string;
    rewriteQuery: boolean;
    scoreThreshold: number;
    source: string;
    sourceParams: InstancesListResultItemSourceParams;
    status: string;
    summarization: boolean;
    summarizationModel: string;
    syncInterval: InstancesListResultItemSyncInterval;
    systemPromptAiSearch: string;
    systemPromptIndexSummarization: string;
    systemPromptRewriteQuery: string;
    tokenId: string;
    type: InstancesListResultItemType;
}
export type InstancesListResultList = Array<InstancesListResultItem>;
export interface ListInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type NamespacesInstancesItemsListRequestSortBy = "status" | "modified_at";
export type NamespacesInstancesItemsListRequestStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export interface ListNamespaceInstanceItemsRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    /** Return only the item with this unique ID. Returns at most one item. */
    itemId?: string | undefined;
    /** Return only items with this exact key (object key / filename). Each key is unique within a source, so combine with `source` to disambiguate across data sources. */
    key?: string | undefined;
    /** JSON-encoded metadata filter using Vectorize filter syntax. Examples: {"folder":"reports/"}, {"timestamp":{"$gte":1700000000000}}, {"folder":{"$in":["docs/","reports/"]}}. */
    metadataFilter?: string | undefined;
    page?: number | undefined;
    perPage?: number | undefined;
    search?: string | undefined;
    /** Sort order for items. "status" (default) sorts items according to status priority, then last_seen_at. "modified_at" sorts items according to file modification time (most recent first), falling back to created_at. */
    sortBy?: NamespacesInstancesItemsListRequestSortBy | (string & {}) | undefined;
    /** Return only items with this source_id. Use "builtin" for uploaded files, or a source identifier like "web-crawler: https://example.com". */
    source?: string | undefined;
    status?: NamespacesInstancesItemsListRequestStatus | (string & {}) | undefined;
}
export type NamespacesInstancesItemsListResultItemMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsListResultItemMetadataMap = {
    [key: string]: NamespacesInstancesItemsListResultItemMetadataValue | undefined;
};
export type NamespacesInstancesItemsListResultItemNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsListResultItemStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export interface NamespacesInstancesItemsListResultItem {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsListResultItemMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsListResultItemNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsListResultItemStatus;
    error?: string | null | undefined;
}
export type NamespacesInstancesItemsListResultList = Array<NamespacesInstancesItemsListResultItem>;
export interface ListNamespaceInstanceItemsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesItemsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListNamespaceInstanceJobsRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    page?: number | undefined;
    perPage?: number | undefined;
}
export type NamespacesInstancesJobsListResultItemSource = "user" | "schedule";
export interface NamespacesInstancesJobsListResultItem {
    id: string;
    source: NamespacesInstancesJobsListResultItemSource;
    description?: string | null | undefined;
    endReason?: string | null | undefined;
    endedAt?: string | null | undefined;
    lastSeenAt?: string | null | undefined;
    startedAt?: string | null | undefined;
}
export type NamespacesInstancesJobsListResultList = Array<NamespacesInstancesJobsListResultItem>;
export interface ListNamespaceInstanceJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesJobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type NamespacesInstancesListRequestOrderBy = "created_at";
export type NamespacesInstancesListRequestOrderByDirection = "asc" | "desc";
export interface ListNamespaceInstancesRequest {
    accountId: string;
    namespace: string;
    /** Return only instances with this exact Search for Agents hostname (case-insensitive). */
    hostname?: string | undefined;
    /** Field to order results by. */
    orderBy?: NamespacesInstancesListRequestOrderBy | (string & {}) | undefined;
    /** Order direction. */
    orderByDirection?: NamespacesInstancesListRequestOrderByDirection | (string & {}) | undefined;
    /** Page number (1-indexed). */
    page?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Filter instances whose id contains this string (case-insensitive). */
    search?: string | undefined;
}
export type NamespacesInstancesListResultItemCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesListResultItemCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesListResultItemCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesListResultItemCustomMetadataItem {
    dataType: NamespacesInstancesListResultItemCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesListResultItemCustomMetadataList = Array<NamespacesInstancesListResultItemCustomMetadataItem>;
export type NamespacesInstancesListResultItemFusionMethod = "max" | "rrf";
export type NamespacesInstancesListResultItemIndexMethod = InstancesListResultItemIndexMethod;
export type NamespacesInstancesListResultItemIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesListResultItemIndexingOptions {
    keywordTokenizer?: NamespacesInstancesListResultItemIndexingOptionsKeywordTokenizer | null | undefined;
    useOcr?: boolean | null | undefined;
}
export type NamespacesInstancesListResultItemMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesListResultItemMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesListResultItemMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesListResultItemMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: NamespacesInstancesListResultItemMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type NamespacesInstancesListResultItemPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint = InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesListResultItemPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesListResultItemPublicEndpointParamsMcp = InstancesListResultItemPublicEndpointParamsMcp;
export type NamespacesInstancesListResultItemPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesListResultItemPublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesInstancesListResultItemPublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesInstancesListResultItemPublicEndpointParamsSearchEndpoint = InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint;
export interface NamespacesInstancesListResultItemPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesListResultItemPublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    customDomains?: NamespacesInstancesListResultItemPublicEndpointParamsCustomDomainsList | null | undefined;
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesListResultItemPublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesInstancesListResultItemPublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesListResultItemPublicEndpointParamsChatCompletionsEndpoint | null | undefined;
}
export type NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDataType = "number" | "datetime" | "text" | "boolean";
export type NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesListResultItemRetrievalOptionsBoostByItem {
    field: string;
    dataType?: NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDataType | null | undefined;
    direction?: NamespacesInstancesListResultItemRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type NamespacesInstancesListResultItemRetrievalOptionsBoostByList = Array<NamespacesInstancesListResultItemRetrievalOptionsBoostByItem>;
export type NamespacesInstancesListResultItemRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesListResultItemRetrievalOptions {
    boostBy?: NamespacesInstancesListResultItemRetrievalOptionsBoostByList | null | undefined;
    keywordMatchMode?: NamespacesInstancesListResultItemRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type NamespacesInstancesListResultItemSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesListResultItemSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesListResultItemSourceParamsWebCrawlerDiscoverOptions {
    depth?: number | null | undefined;
    includeExternalLinks?: boolean | null | undefined;
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl. New values have a maximum of 100000; instances configured before that cap may report a higher stored value, which the crawler clamps at run time. */
    limit?: number | null | undefined;
    maxAge?: number | null | undefined;
    source?: NamespacesInstancesListResultItemSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptions {
    contentSelector?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    includeHeaders?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    specificSitemaps?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type NamespacesInstancesListResultItemSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesListResultItemSourceParamsWebCrawler {
    discoverOptions?: NamespacesInstancesListResultItemSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseOptions | null | undefined;
    parseType?: NamespacesInstancesListResultItemSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface NamespacesInstancesListResultItemSourceParams {
    excludeItems?: NamespacesInstancesListResultItemSourceParamsExcludeItemsList | null | undefined;
    includeItems?: NamespacesInstancesListResultItemSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: NamespacesInstancesListResultItemSourceParamsWebCrawler | null | undefined;
}
export type NamespacesInstancesListResultItemSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesListResultItemType = "r2" | "web-crawler";
export interface NamespacesInstancesListResultItem {
    id: string;
    aiGatewayId: string;
    aiSearchModel: string;
    cache: boolean;
    cacheThreshold: NamespacesInstancesListResultItemCacheThreshold;
    cacheTtl: NamespacesInstancesListResultItemCacheTtl;
    chunk: boolean;
    chunkOverlap: number;
    chunkSize: number;
    createdAt: string;
    createdBy: string;
    customMetadata: NamespacesInstancesListResultItemCustomMetadataList;
    embeddingModel: string;
    enable: boolean;
    engineVersion: number;
    fusionMethod: NamespacesInstancesListResultItemFusionMethod;
    hybridSearchEnabled: boolean;
    indexMethod: InstancesListResultItemIndexMethod;
    indexingOptions: NamespacesInstancesListResultItemIndexingOptions;
    lastActivity: string;
    maxNumResults: number;
    metadata: NamespacesInstancesListResultItemMetadata;
    modifiedAt: string;
    modifiedBy: string;
    namespace: string;
    paused: boolean;
    publicEndpointId: string;
    publicEndpointParams: NamespacesInstancesListResultItemPublicEndpointParams;
    reranking: boolean;
    rerankingModel: string;
    retrievalOptions: NamespacesInstancesListResultItemRetrievalOptions;
    rewriteModel: string;
    rewriteQuery: boolean;
    scoreThreshold: number;
    source: string;
    sourceParams: NamespacesInstancesListResultItemSourceParams;
    status: string;
    summarization: boolean;
    summarizationModel: string;
    syncInterval: NamespacesInstancesListResultItemSyncInterval;
    systemPromptAiSearch: string;
    systemPromptIndexSummarization: string;
    systemPromptRewriteQuery: string;
    tokenId: string;
    type: NamespacesInstancesListResultItemType;
}
export type NamespacesInstancesListResultList = Array<NamespacesInstancesListResultItem>;
export interface ListNamespaceInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesInstancesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListNamespacesRequest {
    accountId: string;
    /** Page number (1-indexed). */
    page?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Filter namespaces whose name or description contains this string (case-insensitive). */
    search?: string | undefined;
}
export type NamespacesListResultItemPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesListResultItemPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesListResultItemPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesListResultItemPublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesListResultItemPublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesListResultItemPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesListResultItemPublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesListResultItemPublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesListResultItemPublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesListResultItemPublicEndpointParams {
    authorizedHosts?: NamespacesListResultItemPublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesListResultItemPublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesListResultItemPublicEndpointParamsInstancesAllowedList | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesListResultItemPublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export interface NamespacesListResultItem {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: NamespacesListResultItemPublicEndpointParams | null | undefined;
}
export type NamespacesListResultList = Array<NamespacesListResultItem>;
export interface ListNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListTokensRequest {
    accountId: string;
    /** Page number (1-indexed). */
    page?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Filter tokens whose name contains this string (case-insensitive). */
    search?: string | undefined;
}
export interface TokensListResultItem {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null | undefined;
    enabled?: boolean | null | undefined;
    legacy?: boolean | null | undefined;
    modifiedBy?: string | null | undefined;
}
export type TokensListResultList = Array<TokensListResultItem>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface LogsInstanceJobRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    page?: number | undefined;
    perPage?: number | undefined;
}
export interface InstancesJobsLogsResultItem {
    id: number;
    createdAt: number;
    message: string;
    messageType: number;
}
export type InstancesJobsLogsResultList = Array<InstancesJobsLogsResultItem>;
export type LogsInstanceJobResponse = InstancesJobsLogsResultList;
export interface LogsNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    cursor?: string | undefined;
    limit?: number | undefined;
}
export interface NamespacesInstancesItemsLogsResultItem {
    action: string;
    chunkCount: number;
    errorType: string;
    fileKey: string;
    message: string;
    processingTimeMs: number;
    timestamp: string;
}
export type NamespacesInstancesItemsLogsResultList = Array<NamespacesInstancesItemsLogsResultItem>;
export type LogsNamespaceInstanceItemResponse = NamespacesInstancesItemsLogsResultList;
export interface LogsNamespaceInstanceJobRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    page?: number | undefined;
    perPage?: number | undefined;
}
export type NamespacesInstancesJobsLogsResultItem = InstancesJobsLogsResultItem;
export type NamespacesInstancesJobsLogsResultList = Array<InstancesJobsLogsResultItem>;
export type LogsNamespaceInstanceJobResponse = NamespacesInstancesJobsLogsResultList;
export interface MoveNamespacesInstanceRequest {
    accountId: string;
    /** Current namespace of the instance. */
    namespace: string;
    /** Instance id. */
    id: string;
    /** Target namespace to move the instance into. */
    newNamespace: string;
}
export type MoveNamespacesInstanceResponse = unknown;
export type NamespacesInstancesJobsUpdateRequestAction = "cancel";
export interface PatchNamespaceInstanceJobRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    jobId: string;
    action: NamespacesInstancesJobsUpdateRequestAction | (string & {});
}
export type NamespacesInstancesJobsUpdateResponseSource = "user" | "schedule";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchNamespaceInstanceJobResponse {
    id: string;
    source: NamespacesInstancesJobsUpdateResponseSource;
    description?: string | null | undefined;
    endReason?: string | null | undefined;
    endedAt?: string | null | undefined;
    lastSeenAt?: string | null | undefined;
    startedAt?: string | null | undefined;
}
export interface ReadInstanceRequest {
    accountId: string;
    id: string;
}
export type InstancesReadResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesReadResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesReadResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesReadResponseCustomMetadataItem {
    dataType: InstancesReadResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesReadResponseCustomMetadataList = Array<InstancesReadResponseCustomMetadataItem>;
export type InstancesReadResponseFusionMethod = "max" | "rrf";
export type InstancesReadResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesReadResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesReadResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesReadResponseIndexingOptionsKeywordTokenizer | null | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null | undefined;
}
export type InstancesReadResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesReadResponseMetadataCreatedFromEmdashPlugin {
    type: InstancesReadResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesReadResponseMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: InstancesReadResponseMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type InstancesReadResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type InstancesReadResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type InstancesReadResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type InstancesReadResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type InstancesReadResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesReadResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: InstancesReadResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type InstancesReadResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface InstancesReadResponsePublicEndpointParams {
    authorizedHosts?: InstancesReadResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesReadResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: InstancesReadResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export type InstancesReadResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesReadResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesReadResponseRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type InstancesReadResponseRetrievalOptionsBoostByList = Array<InstancesReadResponseRetrievalOptionsBoostByItem>;
export type InstancesReadResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesReadResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesReadResponseRetrievalOptionsBoostByList | null | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesReadResponseRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type InstancesReadResponseSourceParamsExcludeItemsList = Array<string>;
export type InstancesReadResponseSourceParamsIncludeItemsList = Array<string>;
export type InstancesReadResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesReadResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesReadResponseSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesReadResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type InstancesReadResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesReadResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesReadResponseSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: InstancesReadResponseSourceParamsWebCrawlerParseOptions | null | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesReadResponseSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface InstancesReadResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesReadResponseSourceParamsExcludeItemsList | null | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesReadResponseSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: InstancesReadResponseSourceParamsWebCrawler | null | undefined;
}
export type InstancesReadResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesReadResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null | undefined;
    cache?: boolean | null | undefined;
    cacheThreshold?: InstancesReadResponseCacheThreshold | null | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesReadResponseCacheTtl | null | undefined;
    chunkOverlap?: number | null | undefined;
    chunkSize?: number | null | undefined;
    createdBy?: string | null | undefined;
    customMetadata?: InstancesReadResponseCustomMetadataList | null | undefined;
    embeddingModel?: string | null | undefined;
    enable?: boolean | null | undefined;
    engineVersion?: number | null | undefined;
    fusionMethod?: InstancesReadResponseFusionMethod | null | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null | undefined;
    indexingOptions?: InstancesReadResponseIndexingOptions | null | undefined;
    lastActivity?: string | null | undefined;
    maxNumResults?: number | null | undefined;
    metadata?: InstancesReadResponseMetadata | null | undefined;
    modifiedBy?: string | null | undefined;
    namespace?: string | null | undefined;
    paused?: boolean | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: InstancesReadResponsePublicEndpointParams | null | undefined;
    reranking?: boolean | null | undefined;
    rerankingModel?: string | null | undefined;
    retrievalOptions?: InstancesReadResponseRetrievalOptions | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null | undefined;
    rewriteQuery?: boolean | null | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null | undefined;
    source?: string | null | undefined;
    sourceParams?: InstancesReadResponseSourceParams | null | undefined;
    status?: string | null | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: InstancesReadResponseSyncInterval | null | undefined;
    tokenId?: string | null | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesReadResponseType | null | undefined;
}
export interface ReadNamespaceRequest {
    accountId: string;
    name: string;
}
export type NamespacesReadResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesReadResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesReadResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesReadResponsePublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesReadResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesReadResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesReadResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesReadResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesReadResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesReadResponsePublicEndpointParams {
    authorizedHosts?: NamespacesReadResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesReadResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesReadResponsePublicEndpointParamsInstancesAllowedList | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesReadResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: NamespacesReadResponsePublicEndpointParams | null | undefined;
}
export interface ReadNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    id: string;
}
export type NamespacesInstancesReadResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesReadResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesReadResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesReadResponseCustomMetadataItem {
    dataType: NamespacesInstancesReadResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesReadResponseCustomMetadataList = Array<NamespacesInstancesReadResponseCustomMetadataItem>;
export type NamespacesInstancesReadResponseFusionMethod = "max" | "rrf";
export type NamespacesInstancesReadResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesReadResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesReadResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesReadResponseIndexingOptionsKeywordTokenizer | null | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null | undefined;
}
export type NamespacesInstancesReadResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesReadResponseMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesReadResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesReadResponseMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: NamespacesInstancesReadResponseMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type NamespacesInstancesReadResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesReadResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesReadResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesReadResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesInstancesReadResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesReadResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesInstancesReadResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesInstancesReadResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesReadResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesReadResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesReadResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesInstancesReadResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export type NamespacesInstancesReadResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesReadResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesReadResponseRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type NamespacesInstancesReadResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesReadResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesReadResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesReadResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesReadResponseRetrievalOptionsBoostByList | null | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesReadResponseRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type NamespacesInstancesReadResponseSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesReadResponseSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesReadResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesReadResponseSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type NamespacesInstancesReadResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesReadResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesReadResponseSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseOptions | null | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesReadResponseSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface NamespacesInstancesReadResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesReadResponseSourceParamsExcludeItemsList | null | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesReadResponseSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: NamespacesInstancesReadResponseSourceParamsWebCrawler | null | undefined;
}
export type NamespacesInstancesReadResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesReadResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null | undefined;
    cache?: boolean | null | undefined;
    cacheThreshold?: NamespacesInstancesReadResponseCacheThreshold | null | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesReadResponseCacheTtl | null | undefined;
    chunkOverlap?: number | null | undefined;
    chunkSize?: number | null | undefined;
    createdBy?: string | null | undefined;
    customMetadata?: NamespacesInstancesReadResponseCustomMetadataList | null | undefined;
    embeddingModel?: string | null | undefined;
    enable?: boolean | null | undefined;
    engineVersion?: number | null | undefined;
    fusionMethod?: NamespacesInstancesReadResponseFusionMethod | null | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null | undefined;
    indexingOptions?: NamespacesInstancesReadResponseIndexingOptions | null | undefined;
    lastActivity?: string | null | undefined;
    maxNumResults?: number | null | undefined;
    metadata?: NamespacesInstancesReadResponseMetadata | null | undefined;
    modifiedBy?: string | null | undefined;
    namespace?: string | null | undefined;
    paused?: boolean | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: NamespacesInstancesReadResponsePublicEndpointParams | null | undefined;
    reranking?: boolean | null | undefined;
    rerankingModel?: string | null | undefined;
    retrievalOptions?: NamespacesInstancesReadResponseRetrievalOptions | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null | undefined;
    rewriteQuery?: boolean | null | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null | undefined;
    source?: string | null | undefined;
    sourceParams?: NamespacesInstancesReadResponseSourceParams | null | undefined;
    status?: string | null | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: NamespacesInstancesReadResponseSyncInterval | null | undefined;
    tokenId?: string | null | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesReadResponseType | null | undefined;
}
export interface ReadTokenRequest {
    accountId: string;
    id: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ReadTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null | undefined;
    enabled?: boolean | null | undefined;
    legacy?: boolean | null | undefined;
    modifiedBy?: string | null | undefined;
}
export type InstancesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface InstancesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: InstancesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {}) | undefined;
    enabled?: boolean | undefined;
}
export type InstancesSearchRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type InstancesSearchRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: InstancesSearchRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type InstancesSearchRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type InstancesSearchRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type InstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {}) | undefined;
}
export type InstancesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<InstancesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type InstancesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type InstancesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type InstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type InstancesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface InstancesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesSearchRequestAiSearchOptionsRetrievalBoostByList | undefined;
    contextExpansion?: number | undefined;
    filters?: InstancesSearchRequestAiSearchOptionsRetrievalFiltersMap | undefined;
    fusionMethod?: InstancesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {}) | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: InstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {}) | undefined;
    /** Minimum similarity score a chunk must reach to be returned. When omitted, falls back to the instance-level score_threshold, then to 0.4. */
    matchThreshold?: number | undefined;
    /** Maximum number of results to return. When omitted, falls back to the instance-level max_num_results, then to 10. */
    maxNumResults?: number | undefined;
    retrievalType?: InstancesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {}) | undefined;
    returnOnFailure?: boolean | undefined;
}
export interface InstancesSearchRequestAiSearchOptions {
    cache?: InstancesSearchRequestAiSearchOptionsCache | undefined;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: InstancesSearchRequestAiSearchOptionsCustomMetadataMap | undefined;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite | undefined;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking | undefined;
    retrieval?: InstancesSearchRequestAiSearchOptionsRetrieval | undefined;
}
export type InstancesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface InstancesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: InstancesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export type InstancesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type InstancesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface InstancesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: InstancesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export type InstancesSearchRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type InstancesSearchRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface InstancesSearchRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: InstancesSearchRequestMessagesItemContentCase1ItemCase2Type;
}
export type InstancesSearchRequestMessagesItemContentCase1Item = InstancesSearchRequestMessagesItemContentCase1ItemCase0 | InstancesSearchRequestMessagesItemContentCase1ItemCase1 | InstancesSearchRequestMessagesItemContentCase1ItemCase2;
export type InstancesSearchRequestMessagesItemContentCase1List = Array<InstancesSearchRequestMessagesItemContentCase1Item>;
export type InstancesSearchRequestMessagesItemContent = string | InstancesSearchRequestMessagesItemContentCase1List;
export type InstancesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface InstancesSearchRequestMessagesItem {
    content: InstancesSearchRequestMessagesItemContent;
    role: InstancesSearchRequestMessagesItemRole | (string & {});
}
export type InstancesSearchRequestMessagesList = Array<InstancesSearchRequestMessagesItem>;
export interface SearchInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiSearchOptions?: InstancesSearchRequestAiSearchOptions | undefined;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'...'}, {type:'image_url', image_url:{url:'...'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: InstancesSearchRequestMessagesList | undefined;
    /** A simple text query string. Alternative to 'messages' -- provide either this or 'messages', not both. */
    query?: string | undefined;
}
export type InstancesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface InstancesSearchResponseChunksItemItem {
    key: string;
    metadata?: InstancesSearchResponseChunksItemItemMetadataMap | null | undefined;
    timestamp?: number | null | undefined;
}
export type InstancesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface InstancesSearchResponseChunksItemScoringDetails {
    fusionMethod?: InstancesSearchResponseChunksItemScoringDetailsFusionMethod | null | undefined;
    keywordRank?: number | null | undefined;
    keywordScore?: number | null | undefined;
    rerankingScore?: number | null | undefined;
    vectorRank?: number | null | undefined;
    vectorScore?: number | null | undefined;
}
export type InstancesSearchResponseChunksItemSourceMediaType = "audio" | "video";
export interface InstancesSearchResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: InstancesSearchResponseChunksItemItem | null | undefined;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null | undefined;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null | undefined;
    scoringDetails?: InstancesSearchResponseChunksItemScoringDetails | null | undefined;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: InstancesSearchResponseChunksItemSourceMediaType | null | undefined;
}
export type InstancesSearchResponseChunksList = Array<InstancesSearchResponseChunksItem>;
export type InstancesSearchResponseQueryKind = "text" | "image" | "multimodal";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchInstanceResponse {
    chunks: InstancesSearchResponseChunksList;
    queryKind: InstancesSearchResponseQueryKind;
    searchQuery?: string | null | undefined;
}
export type NamespacesSearchRequestAiSearchOptionsInstanceIdsList = Array<string>;
export type NamespacesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface NamespacesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {}) | undefined;
    enabled?: boolean | undefined;
}
export type NamespacesSearchRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type NamespacesSearchRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: NamespacesSearchRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type NamespacesSearchRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type NamespacesSearchRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {}) | undefined;
}
export type NamespacesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type NamespacesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type NamespacesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface NamespacesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesSearchRequestAiSearchOptionsRetrievalBoostByList | undefined;
    contextExpansion?: number | undefined;
    filters?: NamespacesSearchRequestAiSearchOptionsRetrievalFiltersMap | undefined;
    fusionMethod?: NamespacesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {}) | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {}) | undefined;
    /** Minimum score a chunk must reach to be returned. When omitted, each instance's chunks are filtered by that instance's score_threshold, capped at 0.4. */
    matchThreshold?: number | undefined;
    /** Maximum number of merged results to return. When omitted, defaults to the sum of the searched instances' max_num_results (each falling back to 10), up to 50. */
    maxNumResults?: number | undefined;
    retrievalType?: NamespacesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {}) | undefined;
    returnOnFailure?: boolean | undefined;
}
export interface NamespacesSearchRequestAiSearchOptions {
    instanceIds: NamespacesSearchRequestAiSearchOptionsInstanceIdsList;
    cache?: NamespacesSearchRequestAiSearchOptionsCache | undefined;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: NamespacesSearchRequestAiSearchOptionsCustomMetadataMap | undefined;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite | undefined;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking | undefined;
    retrieval?: NamespacesSearchRequestAiSearchOptionsRetrieval | undefined;
}
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface NamespacesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface NamespacesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type NamespacesSearchRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface NamespacesSearchRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: NamespacesSearchRequestMessagesItemContentCase1ItemCase2Type;
}
export type NamespacesSearchRequestMessagesItemContentCase1Item = NamespacesSearchRequestMessagesItemContentCase1ItemCase0 | NamespacesSearchRequestMessagesItemContentCase1ItemCase1 | NamespacesSearchRequestMessagesItemContentCase1ItemCase2;
export type NamespacesSearchRequestMessagesItemContentCase1List = Array<NamespacesSearchRequestMessagesItemContentCase1Item>;
export type NamespacesSearchRequestMessagesItemContent = string | NamespacesSearchRequestMessagesItemContentCase1List;
export type NamespacesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesSearchRequestMessagesItem {
    content: NamespacesSearchRequestMessagesItemContent;
    role: NamespacesSearchRequestMessagesItemRole | (string & {});
}
export type NamespacesSearchRequestMessagesList = Array<NamespacesSearchRequestMessagesItem>;
export interface SearchNamespaceRequest {
    accountId: string;
    name: string;
    aiSearchOptions: NamespacesSearchRequestAiSearchOptions;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'...'}, {type:'image_url', image_url:{url:'...'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: NamespacesSearchRequestMessagesList | undefined;
    /** A simple text query string. Alternative to 'messages' -- provide either this or 'messages', not both. */
    query?: string | undefined;
}
export type NamespacesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesSearchResponseChunksItemItem {
    key: string;
    metadata?: NamespacesSearchResponseChunksItemItemMetadataMap | null | undefined;
    timestamp?: number | null | undefined;
}
export type NamespacesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface NamespacesSearchResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesSearchResponseChunksItemScoringDetailsFusionMethod | null | undefined;
    keywordRank?: number | null | undefined;
    keywordScore?: number | null | undefined;
    rerankingScore?: number | null | undefined;
    vectorRank?: number | null | undefined;
    vectorScore?: number | null | undefined;
}
export type NamespacesSearchResponseChunksItemSourceMediaType = "audio" | "video";
export interface NamespacesSearchResponseChunksItem {
    id: string;
    instanceId: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesSearchResponseChunksItemItem | null | undefined;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null | undefined;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null | undefined;
    scoringDetails?: NamespacesSearchResponseChunksItemScoringDetails | null | undefined;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesSearchResponseChunksItemSourceMediaType | null | undefined;
}
export type NamespacesSearchResponseChunksList = Array<NamespacesSearchResponseChunksItem>;
export type NamespacesSearchResponseQueryKind = "text" | "image" | "multimodal";
export interface NamespacesSearchResponseErrorsItem {
    instanceId: string;
    message: string;
}
export type NamespacesSearchResponseErrorsList = Array<NamespacesSearchResponseErrorsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchNamespaceResponse {
    chunks: NamespacesSearchResponseChunksList;
    queryKind: NamespacesSearchResponseQueryKind;
    errors?: NamespacesSearchResponseErrorsList | null | undefined;
    searchQuery?: string | null | undefined;
}
export type NamespacesInstancesSearchRequestAiSearchOptionsCacheCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export interface NamespacesInstancesSearchRequestAiSearchOptionsCache {
    cacheThreshold?: NamespacesInstancesSearchRequestAiSearchOptionsCacheCacheThreshold | (string & {}) | undefined;
    enabled?: boolean | undefined;
}
export type NamespacesInstancesSearchRequestAiSearchOptionsCustomMetadataValue = string | number | boolean;
export type NamespacesInstancesSearchRequestAiSearchOptionsCustomMetadataMap = {
    [key: string]: NamespacesInstancesSearchRequestAiSearchOptionsCustomMetadataValue | undefined;
};
export type NamespacesInstancesSearchRequestAiSearchOptionsQueryRewrite = InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite;
export type NamespacesInstancesSearchRequestAiSearchOptionsReranking = InstancesChatCompletionsRequestAiSearchOptionsReranking;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItemDirection | (string & {}) | undefined;
}
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByList = Array<NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByItem>;
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFiltersMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFusionMethod = "max" | "rrf";
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode = "and" | "or";
export type NamespacesInstancesSearchRequestAiSearchOptionsRetrievalRetrievalType = "vector" | "keyword" | "hybrid";
export interface NamespacesInstancesSearchRequestAiSearchOptionsRetrieval {
    /** Metadata fields to boost search results by. Overrides the instance-level boost_by config. Direction defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalBoostByList | undefined;
    contextExpansion?: number | undefined;
    filters?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFiltersMap | undefined;
    fusionMethod?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalFusionMethod | (string & {}) | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted, falls back to the instance-level retrieval_options.keyword_match_mode, then to 'and'. */
    keywordMatchMode?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalKeywordMatchMode | (string & {}) | undefined;
    /** Minimum similarity score a chunk must reach to be returned. When omitted, falls back to the instance-level score_threshold, then to 0.4. */
    matchThreshold?: number | undefined;
    /** Maximum number of results to return. When omitted, falls back to the instance-level max_num_results, then to 10. */
    maxNumResults?: number | undefined;
    retrievalType?: NamespacesInstancesSearchRequestAiSearchOptionsRetrievalRetrievalType | (string & {}) | undefined;
    returnOnFailure?: boolean | undefined;
}
export interface NamespacesInstancesSearchRequestAiSearchOptions {
    cache?: NamespacesInstancesSearchRequestAiSearchOptionsCache | undefined;
    /** Metadata added to AI Gateway logs for requests this operation triggers. Accepts up to 2 string, number, or boolean entries. Reserved keys: 'ai-search', 'task', 'origin', and any key beginning with 'cf.'. */
    customMetadata?: NamespacesInstancesSearchRequestAiSearchOptionsCustomMetadataMap | undefined;
    queryRewrite?: InstancesChatCompletionsRequestAiSearchOptionsQueryRewrite | undefined;
    reranking?: InstancesChatCompletionsRequestAiSearchOptionsReranking | undefined;
    retrieval?: NamespacesInstancesSearchRequestAiSearchOptionsRetrieval | undefined;
}
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0Type = "text";
export interface NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0 {
    text: string;
    type: NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0Type;
}
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1ImageUrl = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1Type = "image_url";
export interface NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1 {
    imageUrl: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase1ImageUrl;
    type: NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1Type;
}
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2File = InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2Type = "file";
export interface NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2 {
    file: InstancesChatCompletionsRequestMessagesItemContentCase1ItemCase2File;
    type: NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2Type;
}
export type NamespacesInstancesSearchRequestMessagesItemContentCase1Item = NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase0 | NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase1 | NamespacesInstancesSearchRequestMessagesItemContentCase1ItemCase2;
export type NamespacesInstancesSearchRequestMessagesItemContentCase1List = Array<NamespacesInstancesSearchRequestMessagesItemContentCase1Item>;
export type NamespacesInstancesSearchRequestMessagesItemContent = string | NamespacesInstancesSearchRequestMessagesItemContentCase1List;
export type NamespacesInstancesSearchRequestMessagesItemRole = "system" | "developer" | "user" | "assistant" | "tool";
export interface NamespacesInstancesSearchRequestMessagesItem {
    content: NamespacesInstancesSearchRequestMessagesItemContent;
    role: NamespacesInstancesSearchRequestMessagesItemRole | (string & {});
}
export type NamespacesInstancesSearchRequestMessagesList = Array<NamespacesInstancesSearchRequestMessagesItem>;
export interface SearchNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    aiSearchOptions?: NamespacesInstancesSearchRequestAiSearchOptions | undefined;
    /** OpenAI-compatible message array. For multimodal queries, set the last user message's `content` to an array of typed parts: `[{type:'text', text:'...'}, {type:'image_url', image_url:{url:'...'}}]`. Image inputs require the RAG's embedding_model to declare 'image' in supported_modalities. */
    messages?: NamespacesInstancesSearchRequestMessagesList | undefined;
    /** A simple text query string. Alternative to 'messages' -- provide either this or 'messages', not both. */
    query?: string | undefined;
}
export type NamespacesInstancesSearchResponseChunksItemItemMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface NamespacesInstancesSearchResponseChunksItemItem {
    key: string;
    metadata?: NamespacesInstancesSearchResponseChunksItemItemMetadataMap | null | undefined;
    timestamp?: number | null | undefined;
}
export type NamespacesInstancesSearchResponseChunksItemScoringDetailsFusionMethod = "rrf" | "max";
export interface NamespacesInstancesSearchResponseChunksItemScoringDetails {
    fusionMethod?: NamespacesInstancesSearchResponseChunksItemScoringDetailsFusionMethod | null | undefined;
    keywordRank?: number | null | undefined;
    keywordScore?: number | null | undefined;
    rerankingScore?: number | null | undefined;
    vectorRank?: number | null | undefined;
    vectorScore?: number | null | undefined;
}
export type NamespacesInstancesSearchResponseChunksItemSourceMediaType = "audio" | "video";
export interface NamespacesInstancesSearchResponseChunksItem {
    id: string;
    score: number;
    text: string;
    type: string;
    item?: NamespacesInstancesSearchResponseChunksItemItem | null | undefined;
    /** Audio/video transcript chunks only: end, in milliseconds from the start of the media (whole seconds), of the last transcript section the matched chunk covers. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaEndMs?: number | null | undefined;
    /** Audio/video transcript chunks only: start, in milliseconds from the start of the media (whole seconds), of the transcript section the matched chunk begins in. Describes the matched chunk before any context expansion, not the expanded `text`. */
    mediaStartMs?: number | null | undefined;
    scoringDetails?: NamespacesInstancesSearchResponseChunksItemScoringDetails | null | undefined;
    /** Audio/video transcript chunks only: type of the source media file. Omitted for all other chunks. */
    sourceMediaType?: NamespacesInstancesSearchResponseChunksItemSourceMediaType | null | undefined;
}
export type NamespacesInstancesSearchResponseChunksList = Array<NamespacesInstancesSearchResponseChunksItem>;
export type NamespacesInstancesSearchResponseQueryKind = "text" | "image" | "multimodal";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SearchNamespaceInstanceResponse {
    chunks: NamespacesInstancesSearchResponseChunksList;
    queryKind: NamespacesInstancesSearchResponseQueryKind;
    searchQuery?: string | null | undefined;
}
export interface StatsInstanceRequest {
    accountId: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
}
export interface InstancesStatsResponseEngineR2 {
    metadataSizeBytes: number;
    objectCount: number;
    payloadSizeBytes: number;
}
export interface InstancesStatsResponseEngineVectorize {
    dimensions: number;
    vectorsCount: number;
}
export interface InstancesStatsResponseEngine {
    /** R2 bucket storage usage in bytes. */
    r2?: InstancesStatsResponseEngineR2 | null | undefined;
    /** Vectorize index metadata (dimensions, vector count). */
    vectorize?: InstancesStatsResponseEngineVectorize | null | undefined;
}
export type InstancesStatsResponseFileEmbedErrorsMap = {
    [key: string]: unknown | undefined;
};
export type InstancesStatsResponseIndexSourceErrorsMap = {
    [key: string]: unknown | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatsInstanceResponse {
    completed?: number | null | undefined;
    /** True when the API cannot compute status counts (e.g. the legacy stats query exceeded the D1 statement-size limit). The response omits counts in this case. */
    degraded?: boolean | null | undefined;
    /** Engine-specific metadata. Present only for managed (v3) instances. */
    engine?: InstancesStatsResponseEngine | null | undefined;
    error?: number | null | undefined;
    fileEmbedErrors?: InstancesStatsResponseFileEmbedErrorsMap | null | undefined;
    indexSourceErrors?: InstancesStatsResponseIndexSourceErrorsMap | null | undefined;
    lastActivity?: string | null | undefined;
    outdated?: number | null | undefined;
    queued?: number | null | undefined;
    running?: number | null | undefined;
    skipped?: number | null | undefined;
}
export interface StatsNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
}
export type NamespacesInstancesStatsResponseEngineR2 = InstancesStatsResponseEngineR2;
export type NamespacesInstancesStatsResponseEngineVectorize = InstancesStatsResponseEngineVectorize;
export type NamespacesInstancesStatsResponseEngine = InstancesStatsResponseEngine;
export type NamespacesInstancesStatsResponseFileEmbedErrorsMap = {
    [key: string]: unknown | undefined;
};
export type NamespacesInstancesStatsResponseIndexSourceErrorsMap = {
    [key: string]: unknown | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatsNamespaceInstanceResponse {
    completed?: number | null | undefined;
    /** True when the API cannot compute status counts (e.g. the legacy stats query exceeded the D1 statement-size limit). The response omits counts in this case. */
    degraded?: boolean | null | undefined;
    /** Engine-specific metadata. Present only for managed (v3) instances. */
    engine?: InstancesStatsResponseEngine | null | undefined;
    error?: number | null | undefined;
    fileEmbedErrors?: NamespacesInstancesStatsResponseFileEmbedErrorsMap | null | undefined;
    indexSourceErrors?: NamespacesInstancesStatsResponseIndexSourceErrorsMap | null | undefined;
    lastActivity?: string | null | undefined;
    outdated?: number | null | undefined;
    queued?: number | null | undefined;
    running?: number | null | undefined;
    skipped?: number | null | undefined;
}
export type NamespacesInstancesItemsSyncRequestNextAction = "INDEX";
export interface SyncNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    itemId: string;
    nextAction: NamespacesInstancesItemsSyncRequestNextAction | (string & {});
    /** Wait for indexing before responding. After processing, vector-indexed instances use any time remaining in a 25s wait budget to confirm Vectorize ingestion. Processing itself continues uninterrupted and can exceed that budget. If confirmation times out, the response returns the current item state and background indexing continues. Defaults to false. */
    waitForCompletion?: boolean | undefined;
}
export type NamespacesInstancesItemsSyncResponseMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsSyncResponseMetadataMap = {
    [key: string]: NamespacesInstancesItemsSyncResponseMetadataValue | undefined;
};
export type NamespacesInstancesItemsSyncResponseNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsSyncResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SyncNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsSyncResponseMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsSyncResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsSyncResponseStatus;
    error?: string | null | undefined;
}
export type InstancesUpdateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesUpdateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesUpdateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesUpdateRequestCustomMetadataItem {
    dataType: InstancesUpdateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export type InstancesUpdateRequestCustomMetadataList = Array<InstancesUpdateRequestCustomMetadataItem>;
export type InstancesUpdateRequestFusionMethod = "max" | "rrf";
export type InstancesUpdateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesUpdateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesUpdateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesUpdateRequestIndexingOptionsKeywordTokenizer | (string & {}) | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | undefined;
}
export type InstancesUpdateRequestMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesUpdateRequestMetadataCreatedFromEmdashPlugin {
    type: InstancesUpdateRequestMetadataCreatedFromEmdashPluginType | (string & {});
    version: string;
}
export interface InstancesUpdateRequestMetadata {
    createdFromAisearchWizard?: boolean | undefined;
    createdFromEmdashPlugin?: InstancesUpdateRequestMetadataCreatedFromEmdashPlugin | undefined;
    workerDomain?: string | undefined;
}
export type InstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type InstancesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type InstancesUpdateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type InstancesUpdateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type InstancesUpdateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesUpdateRequestPublicEndpointParamsRateLimit {
    periodMs?: number | undefined;
    requests?: number | undefined;
    technique?: InstancesUpdateRequestPublicEndpointParamsRateLimitTechnique | (string & {}) | undefined;
}
export type InstancesUpdateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface InstancesUpdateRequestPublicEndpointParams {
    authorizedHosts?: InstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList | undefined;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesUpdateRequestPublicEndpointParamsCustomDomainsList | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | undefined;
    enabled?: boolean | undefined;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp | undefined;
    rateLimit?: InstancesUpdateRequestPublicEndpointParamsRateLimit | undefined;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint | undefined;
}
export type InstancesUpdateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesUpdateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesUpdateRequestRetrievalOptionsBoostByItemDirection | (string & {}) | undefined;
}
export type InstancesUpdateRequestRetrievalOptionsBoostByList = Array<InstancesUpdateRequestRetrievalOptionsBoostByItem>;
export type InstancesUpdateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesUpdateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesUpdateRequestRetrievalOptionsBoostByList | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesUpdateRequestRetrievalOptionsKeywordMatchMode | (string & {}) | undefined;
}
export type InstancesUpdateRequestSourceParamsExcludeItemsList = Array<string>;
export type InstancesUpdateRequestSourceParamsIncludeItemsList = Array<string>;
export type InstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptionsSource | (string & {}) | undefined;
}
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesUpdateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | undefined;
    includeImages?: boolean | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | undefined;
    useBrowserRendering?: boolean | undefined;
}
export type InstancesUpdateRequestSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesUpdateRequestSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptions | undefined;
    parseOptions?: InstancesUpdateRequestSourceParamsWebCrawlerParseOptions | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesUpdateRequestSourceParamsWebCrawlerParseType | (string & {}) | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | undefined;
}
export interface InstancesUpdateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesUpdateRequestSourceParamsExcludeItemsList | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesUpdateRequestSourceParamsIncludeItemsList | undefined;
    prefix?: string | undefined;
    r2Jurisdiction?: string | undefined;
    webCrawler?: InstancesUpdateRequestSourceParamsWebCrawler | undefined;
}
export type InstancesUpdateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export interface UpdateInstanceRequest {
    accountId: string;
    id: string;
    aiGatewayId?: string | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | undefined;
    cache?: boolean | undefined;
    cacheThreshold?: InstancesUpdateRequestCacheThreshold | (string & {}) | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesUpdateRequestCacheTtl | (number & {}) | undefined;
    chunk?: boolean | undefined;
    chunkOverlap?: number | undefined;
    chunkSize?: number | undefined;
    customMetadata?: InstancesUpdateRequestCustomMetadataList | undefined;
    embeddingModel?: string | undefined;
    fusionMethod?: InstancesUpdateRequestFusionMethod | (string & {}) | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | undefined;
    indexingOptions?: InstancesUpdateRequestIndexingOptions | undefined;
    maxNumResults?: number | undefined;
    metadata?: InstancesUpdateRequestMetadata | undefined;
    paused?: boolean | undefined;
    publicEndpointParams?: InstancesUpdateRequestPublicEndpointParams | undefined;
    reranking?: boolean | undefined;
    rerankingModel?: string | undefined;
    retrievalOptions?: InstancesUpdateRequestRetrievalOptions | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | undefined;
    rewriteQuery?: boolean | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | undefined;
    source?: string | undefined;
    sourceParams?: InstancesUpdateRequestSourceParams | undefined;
    summarization?: boolean | undefined;
    summarizationModel?: string | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: InstancesUpdateRequestSyncInterval | (number & {}) | undefined;
    systemPromptAiSearch?: string | undefined;
    systemPromptIndexSummarization?: string | undefined;
    systemPromptRewriteQuery?: string | undefined;
    tokenId?: string | undefined;
}
export type InstancesUpdateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type InstancesUpdateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type InstancesUpdateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface InstancesUpdateResponseCustomMetadataItem {
    dataType: InstancesUpdateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type InstancesUpdateResponseCustomMetadataList = Array<InstancesUpdateResponseCustomMetadataItem>;
export type InstancesUpdateResponseFusionMethod = "max" | "rrf";
export type InstancesUpdateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type InstancesUpdateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface InstancesUpdateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: InstancesUpdateResponseIndexingOptionsKeywordTokenizer | null | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null | undefined;
}
export type InstancesUpdateResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface InstancesUpdateResponseMetadataCreatedFromEmdashPlugin {
    type: InstancesUpdateResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface InstancesUpdateResponseMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: InstancesUpdateResponseMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type InstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type InstancesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type InstancesUpdateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type InstancesUpdateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type InstancesUpdateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface InstancesUpdateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: InstancesUpdateResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type InstancesUpdateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface InstancesUpdateResponsePublicEndpointParams {
    authorizedHosts?: InstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: InstancesUpdateResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: InstancesUpdateResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export type InstancesUpdateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface InstancesUpdateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: InstancesUpdateResponseRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type InstancesUpdateResponseRetrievalOptionsBoostByList = Array<InstancesUpdateResponseRetrievalOptionsBoostByItem>;
export type InstancesUpdateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface InstancesUpdateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: InstancesUpdateResponseRetrievalOptionsBoostByList | null | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: InstancesUpdateResponseRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type InstancesUpdateResponseSourceParamsExcludeItemsList = Array<string>;
export type InstancesUpdateResponseSourceParamsIncludeItemsList = Array<string>;
export type InstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface InstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: InstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface InstancesUpdateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type InstancesUpdateResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface InstancesUpdateResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: InstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: InstancesUpdateResponseSourceParamsWebCrawlerParseOptions | null | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: InstancesUpdateResponseSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface InstancesUpdateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: InstancesUpdateResponseSourceParamsExcludeItemsList | null | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: InstancesUpdateResponseSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: InstancesUpdateResponseSourceParamsWebCrawler | null | undefined;
}
export type InstancesUpdateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type InstancesUpdateResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null | undefined;
    cache?: boolean | null | undefined;
    cacheThreshold?: InstancesUpdateResponseCacheThreshold | null | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: InstancesUpdateResponseCacheTtl | null | undefined;
    chunkOverlap?: number | null | undefined;
    chunkSize?: number | null | undefined;
    createdBy?: string | null | undefined;
    customMetadata?: InstancesUpdateResponseCustomMetadataList | null | undefined;
    embeddingModel?: string | null | undefined;
    enable?: boolean | null | undefined;
    engineVersion?: number | null | undefined;
    fusionMethod?: InstancesUpdateResponseFusionMethod | null | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null | undefined;
    indexingOptions?: InstancesUpdateResponseIndexingOptions | null | undefined;
    lastActivity?: string | null | undefined;
    maxNumResults?: number | null | undefined;
    metadata?: InstancesUpdateResponseMetadata | null | undefined;
    modifiedBy?: string | null | undefined;
    namespace?: string | null | undefined;
    paused?: boolean | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: InstancesUpdateResponsePublicEndpointParams | null | undefined;
    reranking?: boolean | null | undefined;
    rerankingModel?: string | null | undefined;
    retrievalOptions?: InstancesUpdateResponseRetrievalOptions | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null | undefined;
    rewriteQuery?: boolean | null | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null | undefined;
    source?: string | null | undefined;
    sourceParams?: InstancesUpdateResponseSourceParams | null | undefined;
    status?: string | null | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: InstancesUpdateResponseSyncInterval | null | undefined;
    tokenId?: string | null | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: InstancesUpdateResponseType | null | undefined;
}
export type NamespacesUpdateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesUpdateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesUpdateRequestPublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesUpdateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type NamespacesUpdateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesUpdateRequestPublicEndpointParamsRateLimit {
    periodMs?: number | undefined;
    requests?: number | undefined;
    technique?: NamespacesUpdateRequestPublicEndpointParamsRateLimitTechnique | (string & {}) | undefined;
}
export type NamespacesUpdateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface NamespacesUpdateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesUpdateRequestPublicEndpointParamsAuthorizedHostsList | undefined;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesUpdateRequestPublicEndpointParamsCustomDomainsList | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | undefined;
    enabled?: boolean | undefined;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesUpdateRequestPublicEndpointParamsInstancesAllowedList | undefined;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp | undefined;
    rateLimit?: NamespacesUpdateRequestPublicEndpointParamsRateLimit | undefined;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint | undefined;
}
export interface UpdateNamespaceRequest {
    accountId: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null | undefined;
    publicEndpointParams?: NamespacesUpdateRequestPublicEndpointParams | undefined;
}
export type NamespacesUpdateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesUpdateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesUpdateResponsePublicEndpointParamsInstancesAllowedList = Array<string>;
export type NamespacesUpdateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesUpdateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesUpdateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesUpdateResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesUpdateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesUpdateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesUpdateResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesUpdateResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    /** Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must reference an existing instance in this namespace, and the list must stay within the account's multi-instance search limit. */
    instancesAllowed?: NamespacesUpdateResponsePublicEndpointParamsInstancesAllowedList | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesUpdateResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceResponse {
    createdAt: string;
    name: string;
    /** Optional description for the namespace. Max 256 characters. */
    description?: string | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: NamespacesUpdateResponsePublicEndpointParams | null | undefined;
}
export type NamespacesInstancesUpdateRequestCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesUpdateRequestCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesUpdateRequestCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesUpdateRequestCustomMetadataItem {
    dataType: NamespacesInstancesUpdateRequestCustomMetadataItemDataType | (string & {});
    fieldName: string;
}
export type NamespacesInstancesUpdateRequestCustomMetadataList = Array<NamespacesInstancesUpdateRequestCustomMetadataItem>;
export type NamespacesInstancesUpdateRequestFusionMethod = "max" | "rrf";
export type NamespacesInstancesUpdateRequestIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesUpdateRequestIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesUpdateRequestIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesUpdateRequestIndexingOptionsKeywordTokenizer | (string & {}) | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | undefined;
}
export type NamespacesInstancesUpdateRequestMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesUpdateRequestMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesUpdateRequestMetadataCreatedFromEmdashPluginType | (string & {});
    version: string;
}
export interface NamespacesInstancesUpdateRequestMetadata {
    createdFromAisearchWizard?: boolean | undefined;
    createdFromEmdashPlugin?: NamespacesInstancesUpdateRequestMetadataCreatedFromEmdashPlugin | undefined;
    workerDomain?: string | undefined;
}
export type NamespacesInstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsChatCompletionsEndpoint = InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsMcp = InstancesCreateRequestPublicEndpointParamsMcp;
export type NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimit {
    periodMs?: number | undefined;
    requests?: number | undefined;
    technique?: NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimitTechnique | (string & {}) | undefined;
}
export type NamespacesInstancesUpdateRequestPublicEndpointParamsSearchEndpoint = InstancesCreateRequestPublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesUpdateRequestPublicEndpointParams {
    authorizedHosts?: NamespacesInstancesUpdateRequestPublicEndpointParamsAuthorizedHostsList | undefined;
    chatCompletionsEndpoint?: InstancesCreateRequestPublicEndpointParamsChatCompletionsEndpoint | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesUpdateRequestPublicEndpointParamsCustomDomainsList | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | undefined;
    enabled?: boolean | undefined;
    mcp?: InstancesCreateRequestPublicEndpointParamsMcp | undefined;
    rateLimit?: NamespacesInstancesUpdateRequestPublicEndpointParamsRateLimit | undefined;
    searchEndpoint?: InstancesCreateRequestPublicEndpointParamsSearchEndpoint | undefined;
}
export type NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItemDirection | (string & {}) | undefined;
}
export type NamespacesInstancesUpdateRequestRetrievalOptionsBoostByList = Array<NamespacesInstancesUpdateRequestRetrievalOptionsBoostByItem>;
export type NamespacesInstancesUpdateRequestRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesUpdateRequestRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesUpdateRequestRetrievalOptionsBoostByList | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesUpdateRequestRetrievalOptionsKeywordMatchMode | (string & {}) | undefined;
}
export type NamespacesInstancesUpdateRequestSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesUpdateRequestSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptionsSource | (string & {}) | undefined;
}
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsContentSelectorList | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | undefined;
    includeImages?: boolean | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | undefined;
    useBrowserRendering?: boolean | undefined;
}
export type NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesUpdateRequestSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerDiscoverOptions | undefined;
    parseOptions?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseOptions | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesUpdateRequestSourceParamsWebCrawlerParseType | (string & {}) | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | undefined;
}
export interface NamespacesInstancesUpdateRequestSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesUpdateRequestSourceParamsExcludeItemsList | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesUpdateRequestSourceParamsIncludeItemsList | undefined;
    prefix?: string | undefined;
    r2Jurisdiction?: string | undefined;
    webCrawler?: NamespacesInstancesUpdateRequestSourceParamsWebCrawler | undefined;
}
export type NamespacesInstancesUpdateRequestSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export interface UpdateNamespaceInstanceRequest {
    accountId: string;
    namespace: string;
    id: string;
    aiGatewayId?: string | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | undefined;
    cache?: boolean | undefined;
    cacheThreshold?: NamespacesInstancesUpdateRequestCacheThreshold | (string & {}) | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesUpdateRequestCacheTtl | (number & {}) | undefined;
    chunk?: boolean | undefined;
    chunkOverlap?: number | undefined;
    chunkSize?: number | undefined;
    customMetadata?: NamespacesInstancesUpdateRequestCustomMetadataList | undefined;
    embeddingModel?: string | undefined;
    fusionMethod?: NamespacesInstancesUpdateRequestFusionMethod | (string & {}) | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | undefined;
    indexingOptions?: NamespacesInstancesUpdateRequestIndexingOptions | undefined;
    maxNumResults?: number | undefined;
    metadata?: NamespacesInstancesUpdateRequestMetadata | undefined;
    paused?: boolean | undefined;
    publicEndpointParams?: NamespacesInstancesUpdateRequestPublicEndpointParams | undefined;
    reranking?: boolean | undefined;
    rerankingModel?: string | undefined;
    retrievalOptions?: NamespacesInstancesUpdateRequestRetrievalOptions | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | undefined;
    rewriteQuery?: boolean | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | undefined;
    source?: string | undefined;
    sourceParams?: NamespacesInstancesUpdateRequestSourceParams | undefined;
    summarization?: boolean | undefined;
    summarizationModel?: string | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: NamespacesInstancesUpdateRequestSyncInterval | (number & {}) | undefined;
    systemPromptAiSearch?: string | undefined;
    systemPromptIndexSummarization?: string | undefined;
    systemPromptRewriteQuery?: string | undefined;
    tokenId?: string | undefined;
}
export type NamespacesInstancesUpdateResponseCacheThreshold = "super_strict_match" | "close_enough" | "flexible_friend" | "anything_goes";
export type NamespacesInstancesUpdateResponseCacheTtl = 600 | 1800 | 3600 | 7200 | 21600 | 43200 | 86400 | 172800 | 259200 | 518400;
export type NamespacesInstancesUpdateResponseCustomMetadataItemDataType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesUpdateResponseCustomMetadataItem {
    dataType: NamespacesInstancesUpdateResponseCustomMetadataItemDataType;
    fieldName: string;
}
export type NamespacesInstancesUpdateResponseCustomMetadataList = Array<NamespacesInstancesUpdateResponseCustomMetadataItem>;
export type NamespacesInstancesUpdateResponseFusionMethod = "max" | "rrf";
export type NamespacesInstancesUpdateResponseIndexMethod = InstancesCreateRequestIndexMethod;
export type NamespacesInstancesUpdateResponseIndexingOptionsKeywordTokenizer = "porter" | "trigram";
export interface NamespacesInstancesUpdateResponseIndexingOptions {
    /** Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter. */
    keywordTokenizer?: NamespacesInstancesUpdateResponseIndexingOptionsKeywordTokenizer | null | undefined;
    /** Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false. */
    useOcr?: boolean | null | undefined;
}
export type NamespacesInstancesUpdateResponseMetadataCreatedFromEmdashPluginType = "native" | "rest";
export interface NamespacesInstancesUpdateResponseMetadataCreatedFromEmdashPlugin {
    type: NamespacesInstancesUpdateResponseMetadataCreatedFromEmdashPluginType;
    version: string;
}
export interface NamespacesInstancesUpdateResponseMetadata {
    createdFromAisearchWizard?: boolean | null | undefined;
    createdFromEmdashPlugin?: NamespacesInstancesUpdateResponseMetadataCreatedFromEmdashPlugin | null | undefined;
    workerDomain?: string | null | undefined;
}
export type NamespacesInstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList = Array<string>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsChatCompletionsEndpoint = InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsCustomDomainsList = Array<string>;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsMcp = InstancesCreateResponsePublicEndpointParamsMcp;
export type NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimitTechnique = "fixed" | "sliding";
export interface NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimit {
    periodMs?: number | null | undefined;
    requests?: number | null | undefined;
    technique?: NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimitTechnique | null | undefined;
}
export type NamespacesInstancesUpdateResponsePublicEndpointParamsSearchEndpoint = InstancesCreateResponsePublicEndpointParamsSearchEndpoint;
export interface NamespacesInstancesUpdateResponsePublicEndpointParams {
    authorizedHosts?: NamespacesInstancesUpdateResponsePublicEndpointParamsAuthorizedHostsList | null | undefined;
    chatCompletionsEndpoint?: InstancesCreateResponsePublicEndpointParamsChatCompletionsEndpoint | null | undefined;
    /** Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged). */
    customDomains?: NamespacesInstancesUpdateResponsePublicEndpointParamsCustomDomainsList | null | undefined;
    /** When false, the instance is reachable only via a registered custom domain and the default &lt;public_endpoint_id&gt;.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off -- omitting it resets to true. */
    defaultDomainEnabled?: boolean | null | undefined;
    enabled?: boolean | null | undefined;
    mcp?: InstancesCreateResponsePublicEndpointParamsMcp | null | undefined;
    rateLimit?: NamespacesInstancesUpdateResponsePublicEndpointParamsRateLimit | null | undefined;
    searchEndpoint?: InstancesCreateResponsePublicEndpointParamsSearchEndpoint | null | undefined;
}
export type NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItemDirection = "asc" | "desc" | "exists" | "not_exists";
export interface NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItem {
    /** Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists. */
    field: string;
    /** Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional -- defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields. */
    direction?: NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItemDirection | null | undefined;
}
export type NamespacesInstancesUpdateResponseRetrievalOptionsBoostByList = Array<NamespacesInstancesUpdateResponseRetrievalOptionsBoostByItem>;
export type NamespacesInstancesUpdateResponseRetrievalOptionsKeywordMatchMode = "and" | "or";
export interface NamespacesInstancesUpdateResponseRetrievalOptions {
    /** Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field. */
    boostBy?: NamespacesInstancesUpdateResponseRetrievalOptionsBoostByList | null | undefined;
    /** Controls which documents become candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term and ranks results according to BM25 relevance. When omitted on an update, the existing stored value stays unchanged; when never set, search falls back to 'and'. */
    keywordMatchMode?: NamespacesInstancesUpdateResponseRetrievalOptionsKeywordMatchMode | null | undefined;
}
export type NamespacesInstancesUpdateResponseSourceParamsExcludeItemsList = Array<string>;
export type NamespacesInstancesUpdateResponseSourceParamsIncludeItemsList = Array<string>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptionsSource = "all" | "sitemaps" | "links";
export interface NamespacesInstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptions {
    /** Maximum link-follow depth from the seed URL. */
    depth?: number | null | undefined;
    /** Follow links that point outside the source domain. Must stay `false` because discover crawls only cover the zone you own. */
    includeExternalLinks?: boolean | null | undefined;
    /** Follow links to subdomains of the source host. */
    includeSubdomains?: boolean | null | undefined;
    /** Maximum number of pages to crawl (1-100000). */
    limit?: number | null | undefined;
    /** Maximum content age in seconds to accept (0-604800). */
    maxAge?: number | null | undefined;
    /** Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both. */
    source?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptionsSource | null | undefined;
}
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorItem = InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList = Array<InstancesCreateRequestSourceParamsWebCrawlerParseOptionsContentSelectorItem>;
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap = {
    [key: string]: string | undefined;
};
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList = Array<string>;
export interface NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptions {
    /** List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. The crawler stores and indexes only the matched HTML fragment. Omit the field to disable content selection; the API rejects empty arrays. */
    contentSelector?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsContentSelectorList | null | undefined;
    /** Up to 5 custom HTTP headers sent with each crawl request. Names must use RFC-7230 token characters, excluding spaces, colons, and control characters. Values must use HTAB and printable ASCII only, excluding CR and LF. */
    includeHeaders?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsIncludeHeadersMap | null | undefined;
    includeImages?: boolean | null | undefined;
    /** List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'. */
    specificSitemaps?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptionsSpecificSitemapsList | null | undefined;
    useBrowserRendering?: boolean | null | undefined;
}
export type NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseType = "sitemap" | "discover";
export interface NamespacesInstancesUpdateResponseSourceParamsWebCrawler {
    /** Options for parse_type 'discover', where Browser Run discovers URLs through link following and sitemaps. Ignored for 'sitemap'. */
    discoverOptions?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerDiscoverOptions | null | undefined;
    parseOptions?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseOptions | null | undefined;
    /** How the crawler finds URLs. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to belong to a Verified zone on this account. */
    parseType?: NamespacesInstancesUpdateResponseSourceParamsWebCrawlerParseType | null | undefined;
    /** Options controlling crawl discovery (e.g. { source: "links" }). */
    crawlOptions?: WebCrawlerCrawlOptions | null | undefined;
}
export interface NamespacesInstancesUpdateResponseSourceParams {
    /** List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts have a limit of 10 rules; contact support to raise it. */
    excludeItems?: NamespacesInstancesUpdateResponseSourceParamsExcludeItemsList | null | undefined;
    /** List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts have a limit of 10 rules; contact support to raise it. */
    includeItems?: NamespacesInstancesUpdateResponseSourceParamsIncludeItemsList | null | undefined;
    prefix?: string | null | undefined;
    r2Jurisdiction?: string | null | undefined;
    webCrawler?: NamespacesInstancesUpdateResponseSourceParamsWebCrawler | null | undefined;
}
export type NamespacesInstancesUpdateResponseSyncInterval = 900 | 1800 | 3600 | 7200 | 14400 | 21600 | 43200 | 86400;
export type NamespacesInstancesUpdateResponseType = "r2" | "web-crawler";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceInstanceResponse {
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    createdAt: string;
    modifiedAt: string;
    aiGatewayId?: string | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    aiSearchModel?: string | null | undefined;
    cache?: boolean | null | undefined;
    cacheThreshold?: NamespacesInstancesUpdateResponseCacheThreshold | null | undefined;
    /** Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d). */
    cacheTtl?: NamespacesInstancesUpdateResponseCacheTtl | null | undefined;
    chunkOverlap?: number | null | undefined;
    chunkSize?: number | null | undefined;
    createdBy?: string | null | undefined;
    customMetadata?: NamespacesInstancesUpdateResponseCustomMetadataList | null | undefined;
    embeddingModel?: string | null | undefined;
    enable?: boolean | null | undefined;
    engineVersion?: number | null | undefined;
    fusionMethod?: NamespacesInstancesUpdateResponseFusionMethod | null | undefined;
    /** Deprecated -- use index_method instead. Defaults to true for new instances; set false to create a vector-only instance. */
    hybridSearchEnabled?: boolean | null | undefined;
    /** Controls which storage backends indexing uses. Defaults to vector and keyword indexing for new instances. When set, both vector and keyword are required. */
    indexMethod?: InstancesCreateRequestIndexMethod | null | undefined;
    indexingOptions?: NamespacesInstancesUpdateResponseIndexingOptions | null | undefined;
    lastActivity?: string | null | undefined;
    maxNumResults?: number | null | undefined;
    metadata?: NamespacesInstancesUpdateResponseMetadata | null | undefined;
    modifiedBy?: string | null | undefined;
    namespace?: string | null | undefined;
    paused?: boolean | null | undefined;
    publicEndpointId?: string | null | undefined;
    publicEndpointParams?: NamespacesInstancesUpdateResponsePublicEndpointParams | null | undefined;
    reranking?: boolean | null | undefined;
    rerankingModel?: string | null | undefined;
    retrievalOptions?: NamespacesInstancesUpdateResponseRetrievalOptions | null | undefined;
    /** A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model. */
    rewriteModel?: string | null | undefined;
    rewriteQuery?: boolean | null | undefined;
    /** Minimum similarity score a chunk must reach to be returned. Defaults to 0.4. */
    scoreThreshold?: number | null | undefined;
    source?: string | null | undefined;
    sourceParams?: NamespacesInstancesUpdateResponseSourceParams | null | undefined;
    status?: string | null | undefined;
    /** Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h). Defaults to 86400 (24h). */
    syncInterval?: NamespacesInstancesUpdateResponseSyncInterval | null | undefined;
    tokenId?: string | null | undefined;
    /** Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage. */
    type?: NamespacesInstancesUpdateResponseType | null | undefined;
}
export interface UpdateTokenRequest {
    accountId: string;
    id: string;
    cfApiId: string;
    cfApiKey: string;
    name: string;
    legacy?: boolean | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    id: string;
    cfApiId: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    createdBy?: string | null | undefined;
    enabled?: boolean | null | undefined;
    legacy?: boolean | null | undefined;
    modifiedBy?: string | null | undefined;
}
export interface NamespacesInstancesItemsUploadRequestFile {
    /** The file to upload. Filename must not exceed 128 characters. */
    file: string;
    /** JSON string of custom metadata key-value pairs. */
    metadata?: string | undefined;
    /** Wait for indexing before responding. After processing, vector-indexed instances use any time remaining in a 25s wait budget to confirm Vectorize ingestion. Processing itself continues uninterrupted and can exceed that budget. If confirmation times out, the response returns the current item state and background indexing continues. Defaults to false. */
    waitForCompletion?: boolean | undefined;
}
export interface UploadNamespaceInstanceItemRequest {
    accountId: string;
    namespace: string;
    /** AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores. */
    id: string;
    file: NamespacesInstancesItemsUploadRequestFile;
}
export type NamespacesInstancesItemsUploadResponseMetadataValue = string | number | boolean;
export type NamespacesInstancesItemsUploadResponseMetadataMap = {
    [key: string]: NamespacesInstancesItemsUploadResponseMetadataValue | undefined;
};
export type NamespacesInstancesItemsUploadResponseNextAction = "INDEX" | "DELETE";
export type NamespacesInstancesItemsUploadResponseStatus = "queued" | "running" | "completed" | "error" | "skipped" | "outdated";
export type NamespacesInstancesItemsUploadResponseWarningsItemCase0Code = "custom_metadata_value_not_indexed";
export type NamespacesInstancesItemsUploadResponseWarningsItemCase0ExpectedType = "text" | "number" | "boolean" | "datetime";
export interface NamespacesInstancesItemsUploadResponseWarningsItemCase0 {
    code: NamespacesInstancesItemsUploadResponseWarningsItemCase0Code;
    expectedType: NamespacesInstancesItemsUploadResponseWarningsItemCase0ExpectedType;
    field: string;
}
export type NamespacesInstancesItemsUploadResponseWarningsItemCase1Code = "custom_metadata_field_not_filterable";
export interface NamespacesInstancesItemsUploadResponseWarningsItemCase1 {
    code: NamespacesInstancesItemsUploadResponseWarningsItemCase1Code;
    field: string;
}
export type NamespacesInstancesItemsUploadResponseWarningsItem = NamespacesInstancesItemsUploadResponseWarningsItemCase0 | NamespacesInstancesItemsUploadResponseWarningsItemCase1;
export type NamespacesInstancesItemsUploadResponseWarningsList = Array<NamespacesInstancesItemsUploadResponseWarningsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UploadNamespaceInstanceItemResponse {
    id: string;
    checksum: string;
    chunksCount: number;
    createdAt: string;
    fileSize: number;
    key: string;
    lastSeenAt: string;
    /** Built-in, configured filterable, and retained source metadata for the item. */
    metadata: NamespacesInstancesItemsUploadResponseMetadataMap;
    namespace: string;
    nextAction: NamespacesInstancesItemsUploadResponseNextAction;
    /** Identifies which data source this item belongs to. "builtin" for uploaded files, "{type}:{source}" for external sources, null for legacy items. */
    sourceId: string;
    status: NamespacesInstancesItemsUploadResponseStatus;
    error?: string | null | undefined;
    warnings?: NamespacesInstancesItemsUploadResponseWarningsList | null | undefined;
}
export type ChatCompletionsInstanceError = CloudflareOpError;
/** Performs a chat completion request against an AI Search instance, using indexed content as context for generating responses. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const chatCompletionsInstance: API.OperationMethod<ChatCompletionsInstanceRequest, ChatCompletionsInstanceResponse, ChatCompletionsInstanceError, CloudflareOpContext>;
export type ChatCompletionsNamespaceError = CloudflareOpError;
/** Performs a chat completion request against multiple AI Search instances in parallel, merging retrieved content as context for generating a response. */
export declare const chatCompletionsNamespace: API.OperationMethod<ChatCompletionsNamespaceRequest, ChatCompletionsNamespaceResponse, ChatCompletionsNamespaceError, CloudflareOpContext>;
export type ChatCompletionsNamespaceInstanceError = CloudflareOpError;
/** Performs a chat completion request against an AI Search instance, using indexed content as context for generating responses. */
export declare const chatCompletionsNamespaceInstance: API.OperationMethod<ChatCompletionsNamespaceInstanceRequest, ChatCompletionsNamespaceInstanceResponse, ChatCompletionsNamespaceInstanceError, CloudflareOpContext>;
export type ChunksNamespaceInstanceItemError = CloudflareOpError;
/** Lists chunks for a specific item in an AI Search instance, including their text content. */
export declare const chunksNamespaceInstanceItem: API.OperationMethod<ChunksNamespaceInstanceItemRequest, ChunksNamespaceInstanceItemResponse, ChunksNamespaceInstanceItemError, CloudflareOpContext>;
export type CreateInstanceError = ValidationError | NotFound | InvalidRoute | InstanceAlreadyExists | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Create a new AI Search instance with the given configuration. If type is omitted or null, a non-blank HTTP(S) source infers web-crawler and any other source infers r2; r2 sources must name an existing bucket. A missing or blank source without a type creates a managed upload-only instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const createInstance: API.OperationMethod<CreateInstanceRequest, CreateInstanceResponse, CreateInstanceError, CloudflareOpContext>;
export type CreateInstanceJobError = ValidationError | NotFound | InvalidRoute | UnableToConnect | SyncInCooldown | CloudflareOpError;
/** Creates a new indexing job for an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const createInstanceJob: API.OperationMethod<CreateInstanceJobRequest, CreateInstanceJobResponse, CreateInstanceJobError, CloudflareOpContext>;
export type CreateNamespaceError = NamespaceAlreadyExists | Forbidden | CloudflareOpError;
/** Create a namespace for organizing AI Search instances. */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest, CreateNamespaceResponse, CreateNamespaceError, CloudflareOpContext>;
export type CreateNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | InstanceAlreadyExists | InvalidTokenCredentials | WebCrawlerDomainNotOwned | MissingSitemap | Forbidden | InstanceDeletionInProgress | CloudflareOpError;
/** Create a new AI Search instance with the given configuration. If type is omitted or null, a non-blank HTTP(S) source infers web-crawler and any other source infers r2; r2 sources must name an existing bucket. A missing or blank source without a type creates a managed upload-only instance. */
export declare const createNamespaceInstance: API.OperationMethod<CreateNamespaceInstanceRequest, CreateNamespaceInstanceResponse, CreateNamespaceInstanceError, CloudflareOpContext>;
export type CreateNamespaceInstanceJobError = CloudflareOpError;
/** Creates a new indexing job for an AI Search instance. */
export declare const createNamespaceInstanceJob: API.OperationMethod<CreateNamespaceInstanceJobRequest, CreateNamespaceInstanceJobResponse, CreateNamespaceInstanceJobError, CloudflareOpContext>;
export type CreateOrUpdateNamespaceInstanceItemError = CloudflareOpError;
/** Creates or updates an indexed item in an AI Search instance. */
export declare const createOrUpdateNamespaceInstanceItem: API.OperationMethod<CreateOrUpdateNamespaceInstanceItemRequest, CreateOrUpdateNamespaceInstanceItemResponse, CreateOrUpdateNamespaceInstanceItemError, CloudflareOpContext>;
export type CreateTokenError = ValidationError | NotFound | InvalidRoute | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Create a stored Cloudflare credential for an AI Search instance to access its data source. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteInstanceError = ValidationError | NotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Deletes an AI Search instance and all its indexed data permanently. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const deleteInstance: API.OperationMethod<DeleteInstanceRequest, DeleteInstanceResponse, DeleteInstanceError, CloudflareOpContext>;
export type DeleteNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Deletes a namespace permanently. The namespace must not contain any instances (instances whose deletion is still in progress do not count), and the default namespace cannot be deleted. */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest, DeleteNamespaceResponse, DeleteNamespaceError, CloudflareOpContext>;
export type DeleteNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Deletes an AI Search instance and all its indexed data permanently. */
export declare const deleteNamespaceInstance: API.OperationMethod<DeleteNamespaceInstanceRequest, DeleteNamespaceInstanceResponse, DeleteNamespaceInstanceError, CloudflareOpContext>;
export type DeleteNamespaceInstanceItemError = CloudflareOpError;
/** Deletes a file from a managed AI Search instance and removes its indexed data. */
export declare const deleteNamespaceInstanceItem: API.OperationMethod<DeleteNamespaceInstanceItemRequest, DeleteNamespaceInstanceItemResponse, DeleteNamespaceInstanceItemError, CloudflareOpContext>;
export type DeleteTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | TokenInUseByInstances | Forbidden | CloudflareOpError;
/** Deletes a stored AI Search credential permanently. Credentials in use by an instance cannot be deleted. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type DownloadNamespaceInstanceItemError = CloudflareOpError;
/** Downloads the raw file content for a specific item from the managed AI Search instance storage. */
export declare const downloadNamespaceInstanceItem: API.OperationMethod<DownloadNamespaceInstanceItemRequest, DownloadNamespaceInstanceItemResponse, DownloadNamespaceInstanceItemError, CloudflareOpContext>;
export type GetInstanceJobError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Retrieves details for a specific AI Search indexing job. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const getInstanceJob: API.OperationMethod<GetInstanceJobRequest, GetInstanceJobResponse, GetInstanceJobError, CloudflareOpContext>;
export type GetNamespaceInstanceItemError = CloudflareOpError;
/** Retrieves a specific indexed item from an AI Search instance. */
export declare const getNamespaceInstanceItem: API.OperationMethod<GetNamespaceInstanceItemRequest, GetNamespaceInstanceItemResponse, GetNamespaceInstanceItemError, CloudflareOpContext>;
export type GetNamespaceInstanceJobError = CloudflareOpError;
/** Retrieves details for a specific AI Search indexing job. */
export declare const getNamespaceInstanceJob: API.OperationMethod<GetNamespaceInstanceJobRequest, GetNamespaceInstanceJobResponse, GetNamespaceInstanceJobError, CloudflareOpContext>;
export type ListInstanceJobsError = CloudflareOpError;
/** Lists indexing jobs for an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const listInstanceJobs: API.PaginatedOperationMethod<ListInstanceJobsRequest, ListInstanceJobsResponse, ListInstanceJobsError, CloudflareOpContext, InstancesJobsListResultItem>;
export type ListInstancesError = InvalidRoute | Forbidden | CloudflareOpError;
/** Lists all AI Search instances in the account. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, CloudflareOpContext, InstancesListResultItem>;
export type ListNamespaceInstanceItemsError = CloudflareOpError;
/** Lists indexed items in an AI Search instance. */
export declare const listNamespaceInstanceItems: API.PaginatedOperationMethod<ListNamespaceInstanceItemsRequest, ListNamespaceInstanceItemsResponse, ListNamespaceInstanceItemsError, CloudflareOpContext, NamespacesInstancesItemsListResultItem>;
export type ListNamespaceInstanceJobsError = CloudflareOpError;
/** Lists indexing jobs for an AI Search instance. */
export declare const listNamespaceInstanceJobs: API.PaginatedOperationMethod<ListNamespaceInstanceJobsRequest, ListNamespaceInstanceJobsResponse, ListNamespaceInstanceJobsError, CloudflareOpContext, NamespacesInstancesJobsListResultItem>;
export type ListNamespaceInstancesError = NamespaceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Lists all AI Search instances in the account. */
export declare const listNamespaceInstances: API.PaginatedOperationMethod<ListNamespaceInstancesRequest, ListNamespaceInstancesResponse, ListNamespaceInstancesError, CloudflareOpContext, NamespacesInstancesListResultItem>;
export type ListNamespacesError = CloudflareOpError;
/** Lists namespaces in the account, including their descriptions and creation times. */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext, NamespacesListResultItem>;
export type ListTokensError = InvalidRoute | Forbidden | CloudflareOpError;
/** Lists stored AI Search credentials in the account without exposing their secrets. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type LogsInstanceJobError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Lists log entries for an AI Search indexing job. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const logsInstanceJob: API.OperationMethod<LogsInstanceJobRequest, LogsInstanceJobResponse, LogsInstanceJobError, CloudflareOpContext>;
export type LogsNamespaceInstanceItemError = CloudflareOpError;
/** Lists processing logs for a specific item in an AI Search instance. */
export declare const logsNamespaceInstanceItem: API.OperationMethod<LogsNamespaceInstanceItemRequest, LogsNamespaceInstanceItemResponse, LogsNamespaceInstanceItemError, CloudflareOpContext>;
export type LogsNamespaceInstanceJobError = CloudflareOpError;
/** Lists log entries for an AI Search indexing job. */
export declare const logsNamespaceInstanceJob: API.OperationMethod<LogsNamespaceInstanceJobRequest, LogsNamespaceInstanceJobResponse, LogsNamespaceInstanceJobError, CloudflareOpContext>;
export type MoveNamespacesInstanceError = CloudflareOpError;
/** Moves an instance from its current namespace to the specified target namespace. Use 'default' with --destination-namespace to move the instance back to the default namespace. Fails with 400 if the target namespace already has an instance with the same id (ids must be unique within a namespace -- the same id can exist in different namespaces). */
export declare const moveNamespacesInstance: API.OperationMethod<MoveNamespacesInstanceRequest, MoveNamespacesInstanceResponse, MoveNamespacesInstanceError, CloudflareOpContext>;
export type PatchNamespaceInstanceJobError = CloudflareOpError;
/** Cancels an in-progress indexing job for an AI Search instance. */
export declare const patchNamespaceInstanceJob: API.OperationMethod<PatchNamespaceInstanceJobRequest, PatchNamespaceInstanceJobResponse, PatchNamespaceInstanceJobError, CloudflareOpContext>;
export type ReadInstanceError = ValidationError | AiSearchInstanceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Retrieve the configuration and status of an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const readInstance: API.OperationMethod<ReadInstanceRequest, ReadInstanceResponse, ReadInstanceError, CloudflareOpContext>;
export type ReadNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Retrieve a namespace and its description. */
export declare const readNamespace: API.OperationMethod<ReadNamespaceRequest, ReadNamespaceResponse, ReadNamespaceError, CloudflareOpContext>;
export type ReadNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Retrieve the configuration and status of an AI Search instance. */
export declare const readNamespaceInstance: API.OperationMethod<ReadNamespaceInstanceRequest, ReadNamespaceInstanceResponse, ReadNamespaceInstanceError, CloudflareOpContext>;
export type ReadTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | Forbidden | CloudflareOpError;
/** Retrieve a stored AI Search credential without exposing its secret. */
export declare const readToken: API.OperationMethod<ReadTokenRequest, ReadTokenResponse, ReadTokenError, CloudflareOpContext>;
export type SearchInstanceError = CloudflareOpError;
/** Executes a semantic search query against an AI Search instance to find relevant indexed content. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const searchInstance: API.OperationMethod<SearchInstanceRequest, SearchInstanceResponse, SearchInstanceError, CloudflareOpContext>;
export type SearchNamespaceError = CloudflareOpError;
/** Performs a semantic search query against multiple AI Search instances in parallel, merging the retrieved results into a single ranked response. */
export declare const searchNamespace: API.OperationMethod<SearchNamespaceRequest, SearchNamespaceResponse, SearchNamespaceError, CloudflareOpContext>;
export type SearchNamespaceInstanceError = CloudflareOpError;
/** Executes a semantic search query against an AI Search instance to find relevant indexed content. */
export declare const searchNamespaceInstance: API.OperationMethod<SearchNamespaceInstanceRequest, SearchNamespaceInstanceResponse, SearchNamespaceInstanceError, CloudflareOpContext>;
export type StatsInstanceError = ValidationError | NotFound | InvalidRoute | CloudflareOpError;
/** Retrieve usage and indexing statistics for an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const statsInstance: API.OperationMethod<StatsInstanceRequest, StatsInstanceResponse, StatsInstanceError, CloudflareOpContext>;
export type StatsNamespaceInstanceError = CloudflareOpError;
/** Retrieve usage and indexing statistics for an AI Search instance. */
export declare const statsNamespaceInstance: API.OperationMethod<StatsNamespaceInstanceRequest, StatsNamespaceInstanceResponse, StatsNamespaceInstanceError, CloudflareOpContext>;
export type SyncNamespaceInstanceItemError = CloudflareOpError;
/** Synchronizes an item to an AI Search instance index. */
export declare const syncNamespaceInstanceItem: API.OperationMethod<SyncNamespaceInstanceItemRequest, SyncNamespaceInstanceItemResponse, SyncNamespaceInstanceItemError, CloudflareOpContext>;
export type UpdateInstanceError = ValidationError | NotFound | InvalidRoute | InvalidTokenCredentials | Forbidden | CloudflareOpError;
/** Updates the configuration of an AI Search instance. Deprecated: use /accounts/{account_id}/ai-search/namespaces/{namespace}/instances (and descendant paths) instead. */
export declare const updateInstance: API.OperationMethod<UpdateInstanceRequest, UpdateInstanceResponse, UpdateInstanceError, CloudflareOpContext>;
export type UpdateNamespaceError = NamespaceNotFound | Forbidden | CloudflareOpError;
/** Updates the description and/or the public endpoint configuration of an existing namespace. The default namespace's description cannot be modified, but its public endpoint can. */
export declare const updateNamespace: API.OperationMethod<UpdateNamespaceRequest, UpdateNamespaceResponse, UpdateNamespaceError, CloudflareOpContext>;
export type UpdateNamespaceInstanceError = ValidationError | NamespaceNotFound | AiSearchInstanceNotFound | InvalidRoute | InvalidTokenCredentials | WebCrawlerDomainNotOwned | Forbidden | CloudflareOpError;
/** Updates the configuration of an AI Search instance. */
export declare const updateNamespaceInstance: API.OperationMethod<UpdateNamespaceInstanceRequest, UpdateNamespaceInstanceResponse, UpdateNamespaceInstanceError, CloudflareOpContext>;
export type UpdateTokenError = ValidationError | NotFound | InvalidRoute | TokenNotFound | Forbidden | InvalidTokenCredentials | CloudflareOpError;
/** Replace a stored AI Search credential and invalidate cached credentials for instances that use it. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type UploadNamespaceInstanceItemError = CloudflareOpError;
/** Uploads a file to a managed AI Search instance via multipart/form-data. */
export declare const uploadNamespaceInstanceItem: API.OperationMethod<UploadNamespaceInstanceItemRequest, UploadNamespaceInstanceItemResponse, UploadNamespaceInstanceItemError, CloudflareOpContext>;
//# sourceMappingURL=ai_search.d.ts.map