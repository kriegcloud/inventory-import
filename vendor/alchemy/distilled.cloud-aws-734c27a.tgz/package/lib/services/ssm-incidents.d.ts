import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceIdentifier: any;
    readonly resourceType: any;
    readonly retryAfter: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceIdentifier: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceIdentifier: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export type FindingId = string;
export type FindingIdList = string[];
export interface BatchGetIncidentFindingsInput {
    incidentRecordArn: string;
    findingIds: string[];
}
export interface CodeDeployDeployment {
    startTime: Date;
    endTime?: Date | undefined;
    deploymentGroupArn: string;
    deploymentId: string;
}
export interface CloudFormationStackUpdate {
    startTime: Date;
    endTime?: Date | undefined;
    stackArn: string;
}
export type FindingDetails = {
    codeDeployDeployment: CodeDeployDeployment;
    cloudFormationStackUpdate?: undefined;
} | {
    codeDeployDeployment?: undefined;
    cloudFormationStackUpdate: CloudFormationStackUpdate;
};
export interface Finding {
    id: string;
    creationTime: Date;
    lastModifiedTime: Date;
    details?: FindingDetails | undefined;
}
export type FindingList = Finding[];
export interface BatchGetIncidentFindingsError_ {
    findingId: string;
    code: string;
    message: string;
}
export type BatchGetIncidentFindingsErrorList = BatchGetIncidentFindingsError_[];
export interface BatchGetIncidentFindingsOutput {
    findings: Finding[];
    errors: BatchGetIncidentFindingsError_[];
}
export type RegionName = string;
export type SseKmsKey = string;
export interface RegionMapInputValue {
    sseKmsKeyId?: string | undefined;
}
export type RegionMapInput = {
    [key: string]: RegionMapInputValue | undefined;
};
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateReplicationSetInput {
    regions: {
        [key: string]: RegionMapInputValue | undefined;
    };
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateReplicationSetOutput {
    arn: string;
}
export type ResponsePlanName = string;
export type ResponsePlanDisplayName = string;
export type IncidentTitle = string;
export type Impact = number;
export type IncidentSummary = string;
export type DedupeString = string;
export type NotificationTargetItem = {
    snsTopicArn: string;
};
export type NotificationTargetSet = NotificationTargetItem[];
export interface IncidentTemplate {
    title: string;
    impact: number;
    summary?: string | undefined;
    dedupeString?: string | undefined;
    notificationTargets?: NotificationTargetItem[] | undefined;
    incidentTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface EmptyChatChannel {
}
export type SnsArn = string;
export type ChatbotSnsConfigurationSet = string[];
export type ChatChannel = {
    empty: EmptyChatChannel;
    chatbotSns?: undefined;
} | {
    empty?: undefined;
    chatbotSns: string[];
};
export type SsmContactsArn = string;
export type EngagementSet = string[];
export type RoleArn = string;
export type SsmTargetAccount = string;
export type SsmParameterValues = string[];
export type SsmParameters = {
    [key: string]: string[] | undefined;
};
export type VariableType = string;
export type DynamicSsmParameterValue = {
    variable: string;
};
export type DynamicSsmParameters = {
    [key: string]: DynamicSsmParameterValue | undefined;
};
export interface SsmAutomation {
    roleArn: string;
    documentName: string;
    documentVersion?: string | undefined;
    targetAccount?: string | undefined;
    parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    dynamicParameters?: {
        [key: string]: DynamicSsmParameterValue | undefined;
    } | undefined;
}
export type Action = {
    ssmAutomation: SsmAutomation;
};
export type ActionsList = Action[];
export interface PagerDutyIncidentConfiguration {
    serviceId: string;
}
export interface PagerDutyConfiguration {
    name: string;
    secretId: string;
    pagerDutyIncidentConfiguration: PagerDutyIncidentConfiguration;
}
export type Integration = {
    pagerDutyConfiguration: PagerDutyConfiguration;
};
export type Integrations = Integration[];
export interface CreateResponsePlanInput {
    clientToken?: string | undefined;
    name: string;
    displayName?: string | undefined;
    incidentTemplate: IncidentTemplate;
    chatChannel?: ChatChannel | undefined;
    engagements?: string[] | undefined;
    actions?: Action[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    integrations?: Integration[] | undefined;
}
export interface CreateResponsePlanOutput {
    arn: string;
}
export type TimelineEventType = string;
export type EventData = string;
export type GeneratedId = string;
export type EventReference = {
    resource: string;
    relatedItemId?: undefined;
} | {
    resource?: undefined;
    relatedItemId: string;
};
export type EventReferenceList = EventReference[];
export interface CreateTimelineEventInput {
    clientToken?: string | undefined;
    incidentRecordArn: string;
    eventTime: Date;
    eventType: string;
    eventData: string;
    eventReferences?: EventReference[] | undefined;
}
export type UUID = string;
export interface CreateTimelineEventOutput {
    incidentRecordArn: string;
    eventId: string;
}
export interface DeleteIncidentRecordInput {
    arn: string;
}
export interface DeleteIncidentRecordOutput {
}
export interface DeleteReplicationSetInput {
    arn: string;
}
export interface DeleteReplicationSetOutput {
}
export type PolicyId = string;
export interface DeleteResourcePolicyInput {
    resourceArn: string;
    policyId: string;
}
export interface DeleteResourcePolicyOutput {
}
export interface DeleteResponsePlanInput {
    arn: string;
}
export interface DeleteResponsePlanOutput {
}
export interface DeleteTimelineEventInput {
    incidentRecordArn: string;
    eventId: string;
}
export interface DeleteTimelineEventOutput {
}
export interface GetIncidentRecordInput {
    arn: string;
}
export type IncidentRecordStatus = string;
export type AutomationExecution = {
    ssmExecutionArn: string;
};
export type AutomationExecutionSet = AutomationExecution[];
export type ServicePrincipal = string;
export type IncidentSource = string;
export interface IncidentRecordSource {
    createdBy: string;
    invokedBy?: string | undefined;
    resourceArn?: string | undefined;
    source: string;
}
export interface IncidentRecord {
    arn: string;
    title: string;
    summary?: string | undefined;
    status: string;
    impact: number;
    creationTime: Date;
    resolvedTime?: Date | undefined;
    lastModifiedTime: Date;
    lastModifiedBy: string;
    automationExecutions?: AutomationExecution[] | undefined;
    incidentRecordSource: IncidentRecordSource;
    dedupeString: string;
    chatChannel?: ChatChannel | undefined;
    notificationTargets?: NotificationTargetItem[] | undefined;
}
export interface GetIncidentRecordOutput {
    incidentRecord: IncidentRecord;
}
export interface GetReplicationSetInput {
    arn: string;
}
export type RegionStatus = string;
export interface RegionInfo {
    sseKmsKeyId?: string | undefined;
    status: string;
    statusMessage?: string | undefined;
    statusUpdateDateTime: Date;
}
export type RegionInfoMap = {
    [key: string]: RegionInfo | undefined;
};
export type ReplicationSetStatus = string;
export interface ReplicationSet {
    arn?: string | undefined;
    regionMap: {
        [key: string]: RegionInfo | undefined;
    };
    status: string;
    deletionProtected: boolean;
    createdTime: Date;
    createdBy: string;
    lastModifiedTime: Date;
    lastModifiedBy: string;
}
export interface GetReplicationSetOutput {
    replicationSet: ReplicationSet;
}
export type MaxResults = number;
export type NextToken = string;
export interface GetResourcePoliciesInput {
    resourceArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type Policy = string;
export interface ResourcePolicy {
    policyDocument: string;
    policyId: string;
    ramResourceShareRegion: string;
}
export type ResourcePolicyList = ResourcePolicy[];
export interface GetResourcePoliciesOutput {
    resourcePolicies: ResourcePolicy[];
    nextToken?: string | undefined;
}
export interface GetResponsePlanInput {
    arn: string;
}
export interface GetResponsePlanOutput {
    arn: string;
    name: string;
    displayName?: string | undefined;
    incidentTemplate: IncidentTemplate;
    chatChannel?: ChatChannel | undefined;
    engagements?: string[] | undefined;
    actions?: Action[] | undefined;
    integrations?: Integration[] | undefined;
}
export interface GetTimelineEventInput {
    incidentRecordArn: string;
    eventId: string;
}
export interface TimelineEvent {
    incidentRecordArn: string;
    eventId: string;
    eventTime: Date;
    eventUpdatedTime: Date;
    eventType: string;
    eventData: string;
    eventReferences?: EventReference[] | undefined;
}
export interface GetTimelineEventOutput {
    event: TimelineEvent;
}
export interface ListIncidentFindingsInput {
    incidentRecordArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FindingSummary {
    id: string;
    lastModifiedTime: Date;
}
export type FindingSummaryList = FindingSummary[];
export interface ListIncidentFindingsOutput {
    findings: FindingSummary[];
    nextToken?: string | undefined;
}
export type StringList = string[];
export type IntegerList = number[];
export type AttributeValueList = {
    stringValues: string[];
    integerValues?: undefined;
} | {
    stringValues?: undefined;
    integerValues: number[];
};
export type Condition = {
    before: Date;
    after?: undefined;
    equals?: undefined;
} | {
    before?: undefined;
    after: Date;
    equals?: undefined;
} | {
    before?: undefined;
    after?: undefined;
    equals: AttributeValueList;
};
export interface Filter {
    key: string;
    condition: Condition;
}
export type FilterList = Filter[];
export interface ListIncidentRecordsInput {
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface IncidentRecordSummary {
    arn: string;
    title: string;
    status: string;
    impact: number;
    creationTime: Date;
    resolvedTime?: Date | undefined;
    incidentRecordSource: IncidentRecordSource;
}
export type IncidentRecordSummaryList = IncidentRecordSummary[];
export interface ListIncidentRecordsOutput {
    incidentRecordSummaries: IncidentRecordSummary[];
    nextToken?: string | undefined;
}
export interface ListRelatedItemsInput {
    incidentRecordArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type Url = string;
export type MetricDefinition = string;
export interface PagerDutyIncidentDetail {
    id: string;
    autoResolve?: boolean | undefined;
    secretId?: string | undefined;
}
export type ItemValue = {
    arn: string;
    url?: undefined;
    metricDefinition?: undefined;
    pagerDutyIncidentDetail?: undefined;
} | {
    arn?: undefined;
    url: string;
    metricDefinition?: undefined;
    pagerDutyIncidentDetail?: undefined;
} | {
    arn?: undefined;
    url?: undefined;
    metricDefinition: string;
    pagerDutyIncidentDetail?: undefined;
} | {
    arn?: undefined;
    url?: undefined;
    metricDefinition?: undefined;
    pagerDutyIncidentDetail: PagerDutyIncidentDetail;
};
export type ItemType = string;
export interface ItemIdentifier {
    value: ItemValue;
    type: string;
}
export interface RelatedItem {
    identifier: ItemIdentifier;
    title?: string | undefined;
    generatedId?: string | undefined;
}
export type RelatedItemList = RelatedItem[];
export interface ListRelatedItemsOutput {
    relatedItems: RelatedItem[];
    nextToken?: string | undefined;
}
export interface ListReplicationSetsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ReplicationSetArnList = string[];
export interface ListReplicationSetsOutput {
    replicationSetArns: string[];
    nextToken?: string | undefined;
}
export interface ListResponsePlansInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ResponsePlanSummary {
    arn: string;
    name: string;
    displayName?: string | undefined;
}
export type ResponsePlanSummaryList = ResponsePlanSummary[];
export interface ListResponsePlansOutput {
    responsePlanSummaries: ResponsePlanSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export type TimelineEventSort = string;
export type SortOrder = string;
export interface ListTimelineEventsInput {
    incidentRecordArn: string;
    filters?: Filter[] | undefined;
    sortBy?: string | undefined;
    sortOrder?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface EventSummary {
    incidentRecordArn: string;
    eventId: string;
    eventTime: Date;
    eventUpdatedTime: Date;
    eventType: string;
    eventReferences?: EventReference[] | undefined;
}
export type EventSummaryList = EventSummary[];
export interface ListTimelineEventsOutput {
    eventSummaries: EventSummary[];
    nextToken?: string | undefined;
}
export interface PutResourcePolicyInput {
    resourceArn: string;
    policy: string;
}
export interface PutResourcePolicyOutput {
    policyId: string;
}
export type RawData = string;
export interface TriggerDetails {
    source: string;
    triggerArn?: string | undefined;
    timestamp: Date;
    rawData?: string | undefined;
}
export interface StartIncidentInput {
    clientToken?: string | undefined;
    responsePlanArn: string;
    title?: string | undefined;
    impact?: number | undefined;
    triggerDetails?: TriggerDetails | undefined;
    relatedItems?: RelatedItem[] | undefined;
}
export interface StartIncidentOutput {
    incidentRecordArn: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDeletionProtectionInput {
    arn: string;
    deletionProtected: boolean;
    clientToken?: string | undefined;
}
export interface UpdateDeletionProtectionOutput {
}
export interface UpdateIncidentRecordInput {
    clientToken?: string | undefined;
    arn: string;
    title?: string | undefined;
    summary?: string | undefined;
    impact?: number | undefined;
    status?: string | undefined;
    chatChannel?: ChatChannel | undefined;
    notificationTargets?: NotificationTargetItem[] | undefined;
}
export interface UpdateIncidentRecordOutput {
}
export type RelatedItemsUpdate = {
    itemToAdd: RelatedItem;
    itemToRemove?: undefined;
} | {
    itemToAdd?: undefined;
    itemToRemove: ItemIdentifier;
};
export interface UpdateRelatedItemsInput {
    clientToken?: string | undefined;
    incidentRecordArn: string;
    relatedItemsUpdate: RelatedItemsUpdate;
}
export interface UpdateRelatedItemsOutput {
}
export interface AddRegionAction {
    regionName: string;
    sseKmsKeyId?: string | undefined;
}
export interface DeleteRegionAction {
    regionName: string;
}
export type UpdateReplicationSetAction = {
    addRegionAction: AddRegionAction;
    deleteRegionAction?: undefined;
} | {
    addRegionAction?: undefined;
    deleteRegionAction: DeleteRegionAction;
};
export type UpdateActionList = UpdateReplicationSetAction[];
export interface UpdateReplicationSetInput {
    arn: string;
    actions: UpdateReplicationSetAction[];
    clientToken?: string | undefined;
}
export interface UpdateReplicationSetOutput {
}
export type TagMapUpdate = {
    [key: string]: string | undefined;
};
export interface UpdateResponsePlanInput {
    clientToken?: string | undefined;
    arn: string;
    displayName?: string | undefined;
    incidentTemplateTitle?: string | undefined;
    incidentTemplateImpact?: number | undefined;
    incidentTemplateSummary?: string | undefined;
    incidentTemplateDedupeString?: string | undefined;
    incidentTemplateNotificationTargets?: NotificationTargetItem[] | undefined;
    chatChannel?: ChatChannel | undefined;
    engagements?: string[] | undefined;
    actions?: Action[] | undefined;
    incidentTemplateTags?: {
        [key: string]: string | undefined;
    } | undefined;
    integrations?: Integration[] | undefined;
}
export interface UpdateResponsePlanOutput {
}
export interface UpdateTimelineEventInput {
    clientToken?: string | undefined;
    incidentRecordArn: string;
    eventId: string;
    eventTime?: Date | undefined;
    eventType?: string | undefined;
    eventData?: string | undefined;
    eventReferences?: EventReference[] | undefined;
}
export interface UpdateTimelineEventOutput {
}
export type ExceptionMessage = string;
export type ResourceType = string;
export type ServiceCode = string;
export type BatchGetIncidentFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about all specified findings for an incident, including descriptive details about each finding. A finding
 * represents a recent application environment change made by an CodeDeploy
 * deployment or an CloudFormation stack creation or update that can be investigated as a
 * potential cause of the incident.
 */
export declare const batchGetIncidentFindings: API.OperationMethod<BatchGetIncidentFindingsInput & RegionInput, BatchGetIncidentFindingsOutput, BatchGetIncidentFindingsError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationSetError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnsupportedOperationException | CommonErrors;
/**
 * A replication set replicates and encrypts your data to the provided Regions with the
 * provided KMS key.
 */
export declare const createReplicationSet: API.OperationMethod<CreateReplicationSetInput & RegionInput, CreateReplicationSetOutput, CreateReplicationSetError, Credentials | HttpClient.HttpClient>;
export type CreateResponsePlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a response plan that automates the initial response to incidents. A response plan
 * engages contacts, starts chat channel collaboration, and initiates runbooks at the beginning
 * of an incident.
 */
export declare const createResponsePlan: API.OperationMethod<CreateResponsePlanInput & RegionInput, CreateResponsePlanOutput, CreateResponsePlanError, Credentials | HttpClient.HttpClient>;
export type CreateTimelineEventError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom timeline event on the incident details page of an incident record.
 * Incident Manager automatically creates timeline events that mark key moments during an incident.
 * You can create custom timeline events to mark important events that Incident Manager can detect
 * automatically.
 */
export declare const createTimelineEvent: API.OperationMethod<CreateTimelineEventInput & RegionInput, CreateTimelineEventOutput, CreateTimelineEventError, Credentials | HttpClient.HttpClient>;
export type DeleteIncidentRecordError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an incident record from Incident Manager.
 */
export declare const deleteIncidentRecord: API.OperationMethod<DeleteIncidentRecordInput & RegionInput, DeleteIncidentRecordOutput, DeleteIncidentRecordError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes all Regions in your replication set. Deleting the replication set deletes all
 * Incident Manager data.
 */
export declare const deleteReplicationSet: API.OperationMethod<DeleteReplicationSetInput & RegionInput, DeleteReplicationSetOutput, DeleteReplicationSetError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource policy that Resource Access Manager uses to share your Incident Manager
 * resource.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyInput & RegionInput, DeleteResourcePolicyOutput, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteResponsePlanError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified response plan. Deleting a response plan stops all linked CloudWatch alarms and EventBridge events from creating an incident with this response
 * plan.
 */
export declare const deleteResponsePlan: API.OperationMethod<DeleteResponsePlanInput & RegionInput, DeleteResponsePlanOutput, DeleteResponsePlanError, Credentials | HttpClient.HttpClient>;
export type DeleteTimelineEventError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a timeline event from an incident.
 */
export declare const deleteTimelineEvent: API.OperationMethod<DeleteTimelineEventInput & RegionInput, DeleteTimelineEventOutput, DeleteTimelineEventError, Credentials | HttpClient.HttpClient>;
export type GetIncidentRecordError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details for the specified incident record.
 */
export declare const getIncidentRecord: API.OperationMethod<GetIncidentRecordInput & RegionInput, GetIncidentRecordOutput, GetIncidentRecordError, Credentials | HttpClient.HttpClient>;
export type GetReplicationSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve your Incident Manager replication set.
 */
export declare const getReplicationSet: API.OperationMethod<GetReplicationSetInput & RegionInput, GetReplicationSetOutput, GetReplicationSetError, Credentials | HttpClient.HttpClient>;
export type GetResourcePoliciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource policies attached to the specified response plan.
 */
export declare const getResourcePolicies: API.PaginatedOperationMethod<GetResourcePoliciesInput & RegionInput, GetResourcePoliciesOutput, GetResourcePoliciesError, Credentials | HttpClient.HttpClient, ResourcePolicy>;
export type GetResponsePlanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of the specified response plan.
 */
export declare const getResponsePlan: API.OperationMethod<GetResponsePlanInput & RegionInput, GetResponsePlanOutput, GetResponsePlanError, Credentials | HttpClient.HttpClient>;
export type GetTimelineEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a timeline event based on its ID and incident record.
 */
export declare const getTimelineEvent: API.OperationMethod<GetTimelineEventInput & RegionInput, GetTimelineEventOutput, GetTimelineEventError, Credentials | HttpClient.HttpClient>;
export type ListIncidentFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of the IDs of findings, plus their last modified times, that have been
 * identified for a specified incident. A finding represents a recent application environment
 * change made by an CloudFormation stack creation or update or an CodeDeploy
 * deployment that can be investigated as a potential cause of the incident.
 */
export declare const listIncidentFindings: API.PaginatedOperationMethod<ListIncidentFindingsInput & RegionInput, ListIncidentFindingsOutput, ListIncidentFindingsError, Credentials | HttpClient.HttpClient, FindingSummary>;
export type ListIncidentRecordsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all incident records in your account. Use this command to retrieve the Amazon
 * Resource Name (ARN) of the incident record you want to update.
 */
export declare const listIncidentRecords: API.PaginatedOperationMethod<ListIncidentRecordsInput & RegionInput, ListIncidentRecordsOutput, ListIncidentRecordsError, Credentials | HttpClient.HttpClient, IncidentRecordSummary>;
export type ListRelatedItemsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all related items for an incident record.
 */
export declare const listRelatedItems: API.PaginatedOperationMethod<ListRelatedItemsInput & RegionInput, ListRelatedItemsOutput, ListRelatedItemsError, Credentials | HttpClient.HttpClient, RelatedItem>;
export type ListReplicationSetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists details about the replication set configured in your account.
 */
export declare const listReplicationSets: API.PaginatedOperationMethod<ListReplicationSetsInput & RegionInput, ListReplicationSetsOutput, ListReplicationSetsError, Credentials | HttpClient.HttpClient, Arn>;
export type ListResponsePlansError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all response plans in your account.
 */
export declare const listResponsePlans: API.PaginatedOperationMethod<ListResponsePlansInput & RegionInput, ListResponsePlansOutput, ListResponsePlansError, Credentials | HttpClient.HttpClient, ResponsePlanSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags that are attached to the specified response plan or incident.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTimelineEventsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists timeline events for the specified incident record.
 */
export declare const listTimelineEvents: API.PaginatedOperationMethod<ListTimelineEventsInput & RegionInput, ListTimelineEventsOutput, ListTimelineEventsError, Credentials | HttpClient.HttpClient, EventSummary>;
export type PutResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a resource policy to the specified response plan. The resource policy is used to
 * share the response plan using Resource Access Manager (RAM). For more
 * information about cross-account sharing, see Cross-Region and cross-account incident management.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyInput & RegionInput, PutResourcePolicyOutput, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type StartIncidentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Used to start an incident from CloudWatch alarms, EventBridge events, or
 * manually.
 */
export declare const startIncident: API.OperationMethod<StartIncidentInput & RegionInput, StartIncidentOutput, StartIncidentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a tag to a response plan.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDeletionProtectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update deletion protection to either allow or deny deletion of the final Region in a
 * replication set.
 */
export declare const updateDeletionProtection: API.OperationMethod<UpdateDeletionProtectionInput & RegionInput, UpdateDeletionProtectionOutput, UpdateDeletionProtectionError, Credentials | HttpClient.HttpClient>;
export type UpdateIncidentRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the details of an incident record. You can use this operation to update an incident
 * record from the defined chat channel. For more information about using actions in chat
 * channels, see Interacting through chat.
 */
export declare const updateIncidentRecord: API.OperationMethod<UpdateIncidentRecordInput & RegionInput, UpdateIncidentRecordOutput, UpdateIncidentRecordError, Credentials | HttpClient.HttpClient>;
export type UpdateRelatedItemsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add or remove related items from the related items tab of an incident record.
 */
export declare const updateRelatedItems: API.OperationMethod<UpdateRelatedItemsInput & RegionInput, UpdateRelatedItemsOutput, UpdateRelatedItemsError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add or delete Regions from your replication set.
 */
export declare const updateReplicationSet: API.OperationMethod<UpdateReplicationSetInput & RegionInput, UpdateReplicationSetOutput, UpdateReplicationSetError, Credentials | HttpClient.HttpClient>;
export type UpdateResponsePlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified response plan.
 */
export declare const updateResponsePlan: API.OperationMethod<UpdateResponsePlanInput & RegionInput, UpdateResponsePlanOutput, UpdateResponsePlanError, Credentials | HttpClient.HttpClient>;
export type UpdateTimelineEventError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a timeline event. You can update events of type `Custom Event`.
 */
export declare const updateTimelineEvent: API.OperationMethod<UpdateTimelineEventInput & RegionInput, UpdateTimelineEventOutput, UpdateTimelineEventError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ssm-incidents.d.ts.map