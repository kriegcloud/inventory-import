import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AppNotFound_base: S.TaggedErrorClass<"AppNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class AppNotFound extends /*@__PURE__*/ AppNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const GreTunnelNotFound_base: S.TaggedErrorClass<"GreTunnelNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class GreTunnelNotFound extends /*@__PURE__*/ GreTunnelNotFound_base {
}
declare const IpsecTunnelNotFound_base: S.TaggedErrorClass<"IpsecTunnelNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class IpsecTunnelNotFound extends /*@__PURE__*/ IpsecTunnelNotFound_base {
}
declare const MagicTransitNotOnboarded_base: S.TaggedErrorClass<"MagicTransitNotOnboarded", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MagicTransitNotOnboarded extends /*@__PURE__*/ MagicTransitNotOnboarded_base {
}
declare const MagicWanNotEnabled_base: S.TaggedErrorClass<"MagicWanNotEnabled", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MagicWanNotEnabled extends /*@__PURE__*/ MagicWanNotEnabled_base {
}
declare const MagicWanUnauthorized_base: S.TaggedErrorClass<"MagicWanUnauthorized", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MagicWanUnauthorized extends /*@__PURE__*/ MagicWanUnauthorized_base {
}
declare const RouteNotFound_base: S.TaggedErrorClass<"RouteNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class RouteNotFound extends /*@__PURE__*/ RouteNotFound_base {
}
declare const SiteAclNotFound_base: S.TaggedErrorClass<"SiteAclNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SiteAclNotFound extends /*@__PURE__*/ SiteAclNotFound_base {
}
declare const SiteLanNotFound_base: S.TaggedErrorClass<"SiteLanNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SiteLanNotFound extends /*@__PURE__*/ SiteLanNotFound_base {
}
declare const SiteNotFound_base: S.TaggedErrorClass<"SiteNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SiteNotFound extends /*@__PURE__*/ SiteNotFound_base {
}
declare const SiteWanNotFound_base: S.TaggedErrorClass<"SiteWanNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SiteWanNotFound extends /*@__PURE__*/ SiteWanNotFound_base {
}
export interface BulkPutCfInterconnectsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemBgpExtraPrefixesList = Array<string>;
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemBgp {
    /** Deprecated. Use customer_asn. */
    asNo?: number | null | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    cloudflareEndpoint?: string | null | undefined;
    /** ASN used on the customer end of the BGP session. */
    customerAsn?: number | null | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    customerEndpoint?: string | null | undefined;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** IPv4 prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. */
    extraPrefixes?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre {
    /** The IP address assigned to the Cloudflare side of the GRE tunnel created as part of the Interconnect. */
    cloudflareEndpoint?: string | null | undefined;
}
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckRate = "low" | "mid" | "high";
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget {
    /** The effective health check target. If 'saved' is empty, then this field will be populated with the calculated default value on GET requests. Ignored in POST, PUT, and PATCH requests. */
    effective?: string | null | undefined;
    /** The saved health check target. Setting the value to the empty string indicates that the calculated default value will be used. */
    saved?: string | null | undefined;
}
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckType = "reply" | "request";
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the interconnect and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the interconnect. */
    direction?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckRate | null | undefined;
    /** The source IPv4 address used for bidirectional health checks. Supported only for version 1.5 interconnects. It is required when `direction` is `bidirectional` and must be omitted (and is cleared) when `direction` is `unidirectional`. The address must be within RFC1918 space, the approved link-local range 169.254.240.0/20, or the Cloudflare reserved range 198.41.199.224/27. */
    source?: string | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckType | null | undefined;
}
export interface CfInterconnectsBulkUpdateResponseModifiedInterconnectsItem {
    /** Identifier */
    id?: string | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemBgp | null | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    coloName?: string | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the interconnect. */
    description?: string | null | undefined;
    /** Omitted in responses for version 1.5 interconnects. */
    gre?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre | null | undefined;
    healthCheck?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheck | null | undefined;
    /** The IPv4 interface address for the interconnect. For MPLS Interconnects, use a /30 or /31 prefix. For GRE Interconnects, a /30 or /31 prefix may be used. Version 1.5 interconnects require a /31 prefix and may also use a prefix from the account's authorized prefixes; otherwise, select the subnet from RFC 1918 or the approved link-local ranges. */
    interfaceAddress?: string | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | null | undefined;
    /** Immutable interconnect version configured at creation time. One of: */
    version?: string | null | undefined;
    /** An identifier that correlates this interconnect with the corresponding V2 CNI interconnect resource. */
    virtualPortReservationId?: string | null | undefined;
}
export type CfInterconnectsBulkUpdateResponseModifiedInterconnectsList = Array<CfInterconnectsBulkUpdateResponseModifiedInterconnectsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutCfInterconnectsResponse {
    modified?: boolean | null | undefined;
    modifiedInterconnects?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsList | null | undefined;
}
export interface BulkPutGreTunnelsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpExtraPrefixesList = Array<string>;
export interface GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatus {
    state: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckRate = "low" | "mid" | "high";
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckType = "reply" | "request";
export interface GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheckType | null | undefined;
}
export interface GreTunnelsBulkUpdateResponseModifiedGreTunnelsItem {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgp | null | undefined;
    bgpStatus?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the GRE tunnel. */
    description?: string | null | undefined;
    healthCheck?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsItemHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null | undefined;
}
export type GreTunnelsBulkUpdateResponseModifiedGreTunnelsList = Array<GreTunnelsBulkUpdateResponseModifiedGreTunnelsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutGreTunnelsResponse {
    modified?: boolean | null | undefined;
    modifiedGreTunnels?: GreTunnelsBulkUpdateResponseModifiedGreTunnelsList | null | undefined;
}
export interface BulkPutIpsecTunnelsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpExtraPrefixesList = Array<string>;
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatus {
    state: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities {
    /** A custom IKE ID of type FQDN that may be used to identity the IPsec tunnel. The generated IKE IDs can still be used even if this custom value is specified. */
    fqdnId?: string | null | undefined;
}
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckRate = "low" | "mid" | "high";
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckType = "reply" | "request";
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheckType | null | undefined;
}
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata {
    /** The date and time the tunnel was last modified. */
    lastGeneratedOn?: string | null | undefined;
}
export interface IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItem {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgp | null | undefined;
    bgpStatus?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null | undefined;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null | undefined;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null | undefined;
    healthCheck?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null | undefined;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null | undefined;
}
export type IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsList = Array<IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutIpsecTunnelsResponse {
    modified?: boolean | null | undefined;
    modifiedIpsecTunnels?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsList | null | undefined;
}
export type RoutesBulkUpdateRequestRoutesItemScopeColoNamesList = Array<string>;
export type RoutesBulkUpdateRequestRoutesItemScopeColoRegionsList = Array<string>;
export interface RoutesBulkUpdateRequestRoutesItemScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesBulkUpdateRequestRoutesItemScopeColoNamesList | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesBulkUpdateRequestRoutesItemScopeColoRegionsList | undefined;
}
export interface RoutesBulkUpdateRequestRoutesItem {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** An optional human provided description of the static route. */
    description?: string | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesBulkUpdateRequestRoutesItemScope | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | undefined;
}
export type RoutesBulkUpdateRequestRoutesList = Array<RoutesBulkUpdateRequestRoutesItem>;
export interface BulkPutRoutesRequest {
    /** Identifier */
    accountId: string;
    routes: RoutesBulkUpdateRequestRoutesList;
}
export type RoutesBulkUpdateResponseModifiedRoutesItemScopeColoNamesList = Array<string>;
export type RoutesBulkUpdateResponseModifiedRoutesItemScopeColoRegionsList = Array<string>;
export interface RoutesBulkUpdateResponseModifiedRoutesItemScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesBulkUpdateResponseModifiedRoutesItemScopeColoNamesList | null | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesBulkUpdateResponseModifiedRoutesItemScopeColoRegionsList | null | undefined;
}
export interface RoutesBulkUpdateResponseModifiedRoutesItem {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null | undefined;
    /** An optional human provided description of the static route. */
    description?: string | null | undefined;
    /** When the route was last modified. */
    modifiedOn?: string | null | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesBulkUpdateResponseModifiedRoutesItemScope | null | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null | undefined;
}
export type RoutesBulkUpdateResponseModifiedRoutesList = Array<RoutesBulkUpdateResponseModifiedRoutesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutRoutesResponse {
    modified?: boolean | null | undefined;
    modifiedRoutes?: RoutesBulkUpdateResponseModifiedRoutesList | null | undefined;
}
export type AppsCreateRequestHostnamesList = Array<string>;
export type AppsCreateRequestIpSubnetsList = Array<string>;
export type AppsCreateRequestSourceSubnetsList = Array<string>;
export interface CreateAppRequest {
    /** Identifier */
    accountId: string;
    /** Display name for the app. */
    name: string;
    /** Category of the app. */
    type: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsCreateRequestHostnamesList | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsCreateRequestIpSubnetsList | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsCreateRequestSourceSubnetsList | undefined;
}
export type AppsCreateResponseHostnamesList = Array<string>;
export type AppsCreateResponseIpSubnetsList = Array<string>;
export type AppsCreateResponseSourceSubnetsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAppResponse {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsCreateResponseHostnamesList | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsCreateResponseIpSubnetsList | null | undefined;
    /** Display name for the app. */
    name?: string | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsCreateResponseSourceSubnetsList | null | undefined;
    /** Category of the app. */
    type?: string | null | undefined;
}
export type CreateBgpFilterProfileRequestMatchAction = "allow" | "deny";
export type CreateBgpFilterProfileRequestTargetsList = Array<string>;
export interface CreateBgpFilterProfileRequest {
    /** Identifier */
    accountId: string;
    /** Action to take when a route matches one of the targets in this profile */
    matchAction: CreateBgpFilterProfileRequestMatchAction | (string & {});
    /** Friendly name for the filter profile */
    name: string;
    /** List of CIDR prefixes. Each entry may carry an optional suffix that specifies which prefix lengths to match relative to the prefix length N: '{X,Y}' matches prefix lengths in the inclusive range [X, Y] where N <= X <= Y <= max (max is 32 for IPv4, 128 for IPv6), '{X}' matches exactly length X (equivalent to {X,X}), '+' is shorthand for {N, max} (the prefix and all more-specific subnets, including at length N itself; valid even when N is the maximum length). Omit the suffix to match the prefix exactly at length N. */
    targets: CreateBgpFilterProfileRequestTargetsList;
    /** Description of the filter profile */
    description?: string | undefined;
}
export type CreateBgpFilterProfileResponseMatchAction = "allow" | "deny";
export type CreateBgpFilterProfileResponseTargetsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBgpFilterProfileResponse {
    /** Identifier */
    id: string;
    /** Description of the filter profile */
    description: string;
    /** Action to take when a route matches one of the targets in this profile */
    matchAction: CreateBgpFilterProfileResponseMatchAction;
    /** Friendly name for the filter profile */
    name: string;
    /** List of CIDR prefixes. Each entry may carry an optional suffix that specifies which prefix lengths to match relative to the prefix length N: '{X,Y}' matches prefix lengths in the inclusive range [X, Y] where N &lt;= X &lt;= Y &lt;= max (max is 32 for IPv4, 128 for IPv6), '{X}' matches exactly length X (equivalent to {X,X}), '+' is shorthand for {N, max} (the prefix and all more-specific subnets, including at length N itself; valid even when N is the maximum length). Omit the suffix to match the prefix exactly at length N. */
    targets: CreateBgpFilterProfileResponseTargetsList;
    createdOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
}
export interface Cf1SitesCreateRequestBodyItemLocation {
    /** Latitude of the CF1 Site. */
    lat?: number | undefined;
    /** Longitude of the CF1 Site. */
    long?: number | undefined;
    /** Name of nearest town, city, or village. */
    name?: string | undefined;
}
export interface Cf1SitesCreateRequestBodyItem {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | undefined;
    createdOn?: string | undefined;
    /** A human-provided description of the CF1 Site. */
    description?: string | undefined;
    location?: Cf1SitesCreateRequestBodyItemLocation | undefined;
    modifiedOn?: string | undefined;
}
export type Cf1SitesCreateRequestBodyList = Array<Cf1SitesCreateRequestBodyItem>;
export interface CreateCf1SiteRequest {
    /** Identifier */
    accountId: string;
    body: Cf1SitesCreateRequestBodyList;
}
export interface Cf1SitesCreateResultItemLocation {
    /** Latitude of the CF1 Site. */
    lat?: number | null | undefined;
    /** Longitude of the CF1 Site. */
    long?: number | null | undefined;
    /** Name of nearest town, city, or village. */
    name?: string | null | undefined;
}
export interface Cf1SitesCreateResultItem {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-provided description of the CF1 Site. */
    description?: string | null | undefined;
    location?: Cf1SitesCreateResultItemLocation | null | undefined;
    modifiedOn?: string | null | undefined;
}
export type Cf1SitesCreateResultList = Array<Cf1SitesCreateResultItem>;
export interface CreateCf1SiteResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: Cf1SitesCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type Cf1SitesRampsCreateRequestBodyItemType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export interface Cf1SitesRampsCreateRequestBodyItem {
    /** Identifier of the source network resource to associate as a ramp. */
    sourceRampId: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsCreateRequestBodyItemType | (string & {});
}
export type Cf1SitesRampsCreateRequestBodyList = Array<Cf1SitesRampsCreateRequestBodyItem>;
export interface CreateCf1SiteRampRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
    body: Cf1SitesRampsCreateRequestBodyList;
}
export type Cf1SitesRampsCreateResultItemType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export interface Cf1SitesRampsCreateResultItemGre {
    /** URL reference to the source network resource that this ramp is managed by. */
    managedBy?: string | null | undefined;
}
export type Cf1SitesRampsCreateResultItemGreInterconnect = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsCreateResultItemIpsec = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsCreateResultItemMconn = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsCreateResultItemMplsInterconnect = Cf1SitesRampsCreateResultItemGre;
export interface Cf1SitesRampsCreateResultItem {
    /** Identifier */
    id: string;
    createdOn: string;
    modifiedOn: string;
    /** A human-provided name describing the ramp that should be unique within the CF1 Site. */
    name: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsCreateResultItemType;
    /** A human-provided description of the ramp. */
    description?: string | null | undefined;
    gre?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    greInterconnect?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    ipsec?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    mconn?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    mplsInterconnect?: Cf1SitesRampsCreateResultItemGre | null | undefined;
}
export type Cf1SitesRampsCreateResultList = Array<Cf1SitesRampsCreateResultItem>;
export interface CreateCf1SiteRampResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: Cf1SitesRampsCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ConnectorsCreateRequestDevice {
    id?: string | undefined;
    /** When true, create and provision a new licence key for the connector. */
    provisionLicense?: boolean | undefined;
    serialNumber?: string | undefined;
}
export type ConnectorsCreateRequestInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsCreateRequestInterruptWindowDaysOfWeekList = Array<ConnectorsCreateRequestInterruptWindowDaysOfWeekItem | (string & {})>;
export type ConnectorsCreateRequestInterruptWindowEmbargoDatesList = Array<string>;
export interface CreateConnectorRequest {
    accountId: string;
    /** Exactly one of id, serial_number, or provision_license must be provided. */
    device: ConnectorsCreateRequestDevice;
    activated?: boolean | undefined;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek?: ConnectorsCreateRequestInterruptWindowDaysOfWeekList | undefined;
    interruptWindowDurationHours?: number | undefined;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates?: ConnectorsCreateRequestInterruptWindowEmbargoDatesList | undefined;
    interruptWindowHourOfDay?: number | undefined;
    notes?: string | undefined;
    timezone?: string | undefined;
}
export type ConnectorsCreateResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsCreateResponseInterruptWindowDaysOfWeekList = Array<ConnectorsCreateResponseInterruptWindowDaysOfWeekItem>;
export type ConnectorsCreateResponseInterruptWindowEmbargoDatesList = Array<string>;
export type ConnectorsCreateResponseDeviceType = "MANAGED" | "LICENSED";
export interface ConnectorsCreateResponseDevice {
    id: string;
    serialNumber?: string | null | undefined;
    type?: ConnectorsCreateResponseDeviceType | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsCreateResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsCreateResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    timezone: string;
    device?: ConnectorsCreateResponseDevice | null | undefined;
    lastHeartbeat?: string | null | undefined;
    lastSeenVersion?: string | null | undefined;
    licenseKey?: string | null | undefined;
}
export interface CreateConnectorsInterruptRequestReboot {
    /** Purge connector state. */
    purge?: boolean | undefined;
}
export type CreateConnectorsInterruptRequestRestart = CreateConnectorsInterruptRequestReboot;
export type CreateConnectorsInterruptRequestShutdown = CreateConnectorsInterruptRequestReboot;
export interface CreateConnectorsInterruptRequest {
    accountId: string;
    connectorId: string;
    reboot?: CreateConnectorsInterruptRequestReboot | undefined;
    restart?: CreateConnectorsInterruptRequestReboot | undefined;
    shutdown?: CreateConnectorsInterruptRequestReboot | undefined;
}
export interface CreateConnectorsInterruptResponseReboot {
    /** Purge connector state. */
    purge?: boolean | null | undefined;
}
export type CreateConnectorsInterruptResponseRestart = CreateConnectorsInterruptResponseReboot;
export type CreateConnectorsInterruptResponseShutdown = CreateConnectorsInterruptResponseReboot;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateConnectorsInterruptResponse {
    submittedAt: string;
    reboot?: CreateConnectorsInterruptResponseReboot | null | undefined;
    restart?: CreateConnectorsInterruptResponseReboot | null | undefined;
    shutdown?: CreateConnectorsInterruptResponseReboot | null | undefined;
    triggeredAt?: string | null | undefined;
}
export type GreTunnelsCreateRequestBgpExtraPrefixesList = Array<string>;
export interface GreTunnelsCreateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: GreTunnelsCreateRequestBgpExtraPrefixesList | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | undefined;
}
export type GreTunnelsCreateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export type GreTunnelsCreateRequestHealthCheckRate = "low" | "mid" | "high";
export interface GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget {
    /** The effective health check target. If 'saved' is empty, then this field will be populated with the calculated default value on GET requests. Ignored in POST, PUT, and PATCH requests. */
    effective?: string | undefined;
    /** The saved health check target. Setting the value to the empty string indicates that the calculated default value will be used. */
    saved?: string | undefined;
}
export type GreTunnelsCreateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsCreateRequestHealthCheckType = "reply" | "request";
export interface GreTunnelsCreateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsCreateRequestHealthCheckDirection | (string & {}) | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsCreateRequestHealthCheckRate | (string & {}) | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsCreateRequestHealthCheckTarget | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsCreateRequestHealthCheckType | (string & {}) | undefined;
}
export interface CreateGreTunnelRequest {
    /** Identifier */
    accountId: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | undefined;
    bgp?: GreTunnelsCreateRequestBgp | undefined;
    /** An optional description of the GRE tunnel. */
    description?: string | undefined;
    healthCheck?: GreTunnelsCreateRequestHealthCheck | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | undefined;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | undefined;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | undefined;
    xMagicNewHcTarget?: boolean | undefined;
}
export type GreTunnelsCreateResponseBgpExtraPrefixesList = Array<string>;
export interface GreTunnelsCreateResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: GreTunnelsCreateResponseBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type GreTunnelsCreateResponseBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface GreTunnelsCreateResponseBgpStatus {
    state: GreTunnelsCreateResponseBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type GreTunnelsCreateResponseHealthCheckDirection = "unidirectional" | "bidirectional";
export type GreTunnelsCreateResponseHealthCheckRate = "low" | "mid" | "high";
export type GreTunnelsCreateResponseHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsCreateResponseHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsCreateResponseHealthCheckType = "reply" | "request";
export interface GreTunnelsCreateResponseHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsCreateResponseHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsCreateResponseHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsCreateResponseHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsCreateResponseHealthCheckType | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateGreTunnelResponse {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: GreTunnelsCreateResponseBgp | null | undefined;
    bgpStatus?: GreTunnelsCreateResponseBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the GRE tunnel. */
    description?: string | null | undefined;
    healthCheck?: GreTunnelsCreateResponseHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null | undefined;
}
export type IpsecTunnelsCreateRequestBgpExtraPrefixesList = Array<string>;
export interface IpsecTunnelsCreateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: IpsecTunnelsCreateRequestBgpExtraPrefixesList | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | undefined;
}
export interface IpsecTunnelsCreateRequestCustomRemoteIdentities {
    /** A custom IKE ID of type FQDN that may be used to identity the IPsec tunnel. The generated IKE IDs can still be used even if this custom value is specified. */
    fqdnId?: string | undefined;
}
export type IpsecTunnelsCreateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export type IpsecTunnelsCreateRequestHealthCheckRate = "low" | "mid" | "high";
export type IpsecTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget = GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsCreateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsCreateRequestHealthCheckType = "reply" | "request";
export interface IpsecTunnelsCreateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsCreateRequestHealthCheckDirection | (string & {}) | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsCreateRequestHealthCheckRate | (string & {}) | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsCreateRequestHealthCheckTarget | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsCreateRequestHealthCheckType | (string & {}) | undefined;
}
export interface CreateIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | undefined;
    bgp?: IpsecTunnelsCreateRequestBgp | undefined;
    customRemoteIdentities?: IpsecTunnelsCreateRequestCustomRemoteIdentities | undefined;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | undefined;
    /** An optional description forthe IPsec tunnel. */
    description?: string | undefined;
    healthCheck?: IpsecTunnelsCreateRequestHealthCheck | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | undefined;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk?: string | undefined;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | undefined;
    xMagicNewHcTarget?: boolean | undefined;
}
export type IpsecTunnelsCreateResponseBgpExtraPrefixesList = Array<string>;
export interface IpsecTunnelsCreateResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: IpsecTunnelsCreateResponseBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type IpsecTunnelsCreateResponseBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface IpsecTunnelsCreateResponseBgpStatus {
    state: IpsecTunnelsCreateResponseBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type IpsecTunnelsCreateResponseCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export type IpsecTunnelsCreateResponseHealthCheckDirection = "unidirectional" | "bidirectional";
export type IpsecTunnelsCreateResponseHealthCheckRate = "low" | "mid" | "high";
export type IpsecTunnelsCreateResponseHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsCreateResponseHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsCreateResponseHealthCheckType = "reply" | "request";
export interface IpsecTunnelsCreateResponseHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsCreateResponseHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsCreateResponseHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsCreateResponseHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsCreateResponseHealthCheckType | null | undefined;
}
export type IpsecTunnelsCreateResponsePskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIpsecTunnelResponse {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: IpsecTunnelsCreateResponseBgp | null | undefined;
    bgpStatus?: IpsecTunnelsCreateResponseBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null | undefined;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null | undefined;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null | undefined;
    healthCheck?: IpsecTunnelsCreateResponseHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null | undefined;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null | undefined;
}
export type PcapsCreateRequestSystem = "magic-transit";
export type PcapsCreateRequestType = "simple" | "full";
export interface PcapsCreateRequestFilterV1 {
    /** The destination IP address of the packet. */
    destinationAddress?: string | undefined;
    /** The destination port of the packet. */
    destinationPort?: number | undefined;
    /** The protocol number of the packet. */
    protocol?: number | undefined;
    /** The source IP address of the packet. */
    sourceAddress?: string | undefined;
    /** The source port of the packet. */
    sourcePort?: number | undefined;
}
export interface CreatePcapRequest {
    /** Identifier. */
    accountId: string;
    /** The limit of packets contained in a packet capture. */
    packetLimit?: number | undefined;
    /** The system used to collect packet captures. */
    system: PcapsCreateRequestSystem | (string & {});
    /** The packet capture duration in seconds. */
    timeLimit: number;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type: PcapsCreateRequestType | (string & {});
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateRequestFilterV1 | undefined;
    /** The RFC 3339 offset timestamp from which to query backwards for packets. Must be within the last 24h. When this field is empty, defaults to time of request. */
    offsetTime?: string | undefined;
    /** The name of the data center used for the packet capture. This can be a specific colo (ord02) or a multi-colo name (ORD). This field only applies to `full` packet captures. */
    coloName?: string | undefined;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf?: string | undefined;
    /** The maximum number of bytes to capture. This field only applies to `full` packet captures. */
    byteLimit?: number | undefined;
}
export interface PcapsCreateResultPCAPFilterV1 {
    /** The destination IP address of the packet. */
    destinationAddress?: string | null | undefined;
    /** The destination port of the packet. */
    destinationPort?: number | null | undefined;
    /** The protocol number of the packet. */
    protocol?: number | null | undefined;
    /** The source IP address of the packet. */
    sourceAddress?: string | null | undefined;
    /** The source port of the packet. */
    sourcePort?: number | null | undefined;
}
export type PcapsCreateResultPCAPStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export type PcapsCreateResultPCAPSystem = "magic-transit";
export type PcapsCreateResultPCAPType = "simple" | "full";
export interface PcapsCreateResultPCAP {
    /** The ID for the packet capture. */
    id?: string | null | undefined;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null | undefined;
    /** The RFC 3339 offset timestamp from which to query backwards for packets. Must be within the last 24h. When this field is empty, defaults to time of request. */
    offsetTime?: string | null | undefined;
    /** The status of the packet capture request. */
    status?: PcapsCreateResultPCAPStatus | null | undefined;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null | undefined;
    /** The system used to collect packet captures. */
    system?: PcapsCreateResultPCAPSystem | null | undefined;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null | undefined;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsCreateResultPCAPType | null | undefined;
}
export type PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullFilterV1 = PcapsCreateResultPCAPFilterV1;
export type PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export type PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullSystem = "magic-transit";
export type PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullType = "simple" | "full";
export interface PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFull {
    /** The ID for the packet capture. */
    id?: string | null | undefined;
    /** The maximum number of bytes to capture. This field only applies to `full` packet captures. */
    byteLimit?: number | null | undefined;
    /** The name of the data center used for the packet capture. This can be a specific colo (ord02) or a multi-colo name (ORD). This field only applies to `full` packet captures. */
    coloName?: string | null | undefined;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf?: string | null | undefined;
    /** An error message that describes why the packet capture failed. This field only applies to `full` packet captures. */
    errorMessage?: string | null | undefined;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null | undefined;
    /** The number of packets captured. */
    packetsCaptured?: number | null | undefined;
    /** The status of the packet capture request. */
    status?: PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullStatus | null | undefined;
    /** The RFC 3339 timestamp when stopping the packet capture was requested. This field only applies to `full` packet captures. */
    stopRequested?: string | null | undefined;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null | undefined;
    /** The system used to collect packet captures. */
    system?: PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullSystem | null | undefined;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null | undefined;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFullType | null | undefined;
}
export type PcapsCreateResult = PcapsCreateResultPCAP | PcapsCreateResultMagicVisibilityPCAPsPCAPsResponseFull;
export type CreatePcapResponse = PcapsCreateResult;
export interface CreatePcapOwnershipRequest {
    /** Identifier. */
    accountId: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
}
export type PcapsOwnershipCreateResponseStatus = "pending" | "success" | "failed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePcapOwnershipResponse {
    /** The bucket ID associated with the packet captures API. */
    id: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
    /** The ownership challenge filename stored in the bucket. */
    filename: string;
    /** The status of the ownership challenge. Can be pending, success or failed. */
    status: PcapsOwnershipCreateResponseStatus;
    /** The RFC 3339 timestamp when the bucket was added to packet captures API. */
    submitted: string;
    /** The RFC 3339 timestamp when the bucket was validated. */
    validated?: string | null | undefined;
}
export type RoutesCreateRequestScopeColoNamesList = Array<string>;
export type RoutesCreateRequestScopeColoRegionsList = Array<string>;
export interface RoutesCreateRequestScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesCreateRequestScopeColoNamesList | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesCreateRequestScopeColoRegionsList | undefined;
}
export interface CreateRouteRequest {
    /** Identifier */
    accountId: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** An optional human provided description of the static route. */
    description?: string | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesCreateRequestScope | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | undefined;
}
export type RoutesCreateResponseScopeColoNamesList = Array<string>;
export type RoutesCreateResponseScopeColoRegionsList = Array<string>;
export interface RoutesCreateResponseScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesCreateResponseScopeColoNamesList | null | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesCreateResponseScopeColoRegionsList | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRouteResponse {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null | undefined;
    /** An optional human provided description of the static route. */
    description?: string | null | undefined;
    /** When the route was last modified. */
    modifiedOn?: string | null | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesCreateResponseScope | null | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null | undefined;
}
export interface SitesCreateRequestLocation {
    /** Latitude */
    lat?: string | undefined;
    /** Longitude */
    lon?: string | undefined;
}
export interface CreateSiteRequest {
    /** Identifier */
    accountId: string;
    /** The name of the site. */
    name: string;
    /** Magic Connector identifier tag. */
    connectorId?: string | undefined;
    description?: string | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateRequestLocation | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | undefined;
}
export interface SitesCreateResponseLocation {
    /** Latitude */
    lat?: string | null | undefined;
    /** Longitude */
    lon?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSiteResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic Connector identifier tag. */
    connectorId?: string | null | undefined;
    description?: string | null | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null | undefined;
    /** The name of the site. */
    name?: string | null | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null | undefined;
}
export type SitesAclsCreateRequestLan1PortRangesList = Array<string>;
export type SitesAclsCreateRequestLan1PortsList = Array<number>;
export type SitesAclsCreateRequestLan1SubnetsList = Array<string>;
export interface SitesAclsCreateRequestLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsCreateRequestLan1PortRangesList | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsCreateRequestLan1PortsList | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsCreateRequestLan1SubnetsList | undefined;
}
export type SitesAclsCreateRequestLan2PortRangesList = Array<string>;
export type SitesAclsCreateRequestLan2PortsList = Array<number>;
export type SitesAclsCreateRequestLan2SubnetsList = Array<string>;
export interface SitesAclsCreateRequestLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsCreateRequestLan2PortRangesList | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsCreateRequestLan2PortsList | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsCreateRequestLan2SubnetsList | undefined;
}
export type SitesAclsCreateRequestProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsCreateRequestProtocolsList = Array<SitesAclsCreateRequestProtocolsItem | (string & {})>;
export interface CreateSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    lan_1: SitesAclsCreateRequestLan1;
    lan_2: SitesAclsCreateRequestLan2;
    /** The name of the ACL. */
    name: string;
    /** Description for the ACL. */
    description?: string | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | undefined;
    protocols?: SitesAclsCreateRequestProtocolsList | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | undefined;
}
export type SitesAclsCreateResponseLan1PortRangesList = Array<string>;
export type SitesAclsCreateResponseLan1PortsList = Array<number>;
export type SitesAclsCreateResponseLan1SubnetsList = Array<string>;
export interface SitesAclsCreateResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsCreateResponseLan1PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsCreateResponseLan1PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsCreateResponseLan1SubnetsList | null | undefined;
}
export type SitesAclsCreateResponseLan2PortRangesList = Array<string>;
export type SitesAclsCreateResponseLan2PortsList = Array<number>;
export type SitesAclsCreateResponseLan2SubnetsList = Array<string>;
export interface SitesAclsCreateResponseLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsCreateResponseLan2PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsCreateResponseLan2PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsCreateResponseLan2SubnetsList | null | undefined;
}
export type SitesAclsCreateResponseProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsCreateResponseProtocolsList = Array<SitesAclsCreateResponseProtocolsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSiteAclResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Description for the ACL. */
    description?: string | null | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null | undefined;
    lan_1?: SitesAclsCreateResponseLan1 | null | undefined;
    lan_2?: SitesAclsCreateResponseLan2 | null | undefined;
    /** The name of the ACL. */
    name?: string | null | undefined;
    protocols?: SitesAclsCreateResponseProtocolsList | null | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null | undefined;
}
export interface SitesLansCreateRequestNat {
    /** A valid CIDR notation representing an IP range. */
    staticPrefix?: string | undefined;
}
export interface SitesLansCreateRequestRemoteSubnetsItem {
    /** A valid CIDR notation representing an IP range. */
    localAliasPrefix: string;
    /** A valid CIDR notation representing an IP range. */
    remotePrefix: string;
}
export type SitesLansCreateRequestRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansCreateRequestRoutedSubnetsItemNat = SitesLansCreateRequestNat;
export interface SitesLansCreateRequestRoutedSubnetsItem {
    /** A valid IPv4 address. */
    nextHop: string;
    /** A valid CIDR notation representing an IP range. */
    prefix: string;
    nat?: SitesLansCreateRequestNat | undefined;
}
export type SitesLansCreateRequestRoutedSubnetsList = Array<SitesLansCreateRequestRoutedSubnetsItem>;
export type SitesLansCreateRequestStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansCreateRequestStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansCreateRequestStaticAddressingDhcpRelayServerAddressesList | undefined;
}
export type SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItemType | (string & {});
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansCreateRequestStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansCreateRequestStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansCreateRequestStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansCreateRequestStaticAddressingDhcpServerDhcpOptionsList | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | undefined;
    dnsServers?: SitesLansCreateRequestStaticAddressingDhcpServerDnsServersList | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansCreateRequestStaticAddressingDhcpServerReservationsMap | undefined;
}
export interface SitesLansCreateRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansCreateRequestStaticAddressingDhcpRelay | undefined;
    dhcpServer?: SitesLansCreateRequestStaticAddressingDhcpServer | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | undefined;
}
export interface CreateSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    bondId?: number | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | undefined;
    name?: string | undefined;
    nat?: SitesLansCreateRequestNat | undefined;
    physport?: number | undefined;
    remoteSubnets?: SitesLansCreateRequestRemoteSubnetsList | undefined;
    routedSubnets?: SitesLansCreateRequestRoutedSubnetsList | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansCreateRequestStaticAddressing | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | undefined;
}
export interface SitesLansCreateResultItemNat {
    /** A valid CIDR notation representing an IP range. */
    staticPrefix?: string | null | undefined;
}
export type SitesLansCreateResultItemRemoteSubnetsItem = SitesLansCreateRequestRemoteSubnetsItem;
export type SitesLansCreateResultItemRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansCreateResultItemRoutedSubnetsItemNat = SitesLansCreateResultItemNat;
export interface SitesLansCreateResultItemRoutedSubnetsItem {
    /** A valid IPv4 address. */
    nextHop: string;
    /** A valid CIDR notation representing an IP range. */
    prefix: string;
    nat?: SitesLansCreateResultItemNat | null | undefined;
}
export type SitesLansCreateResultItemRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansCreateResultItemStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansCreateResultItemStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansCreateResultItemStaticAddressingDhcpRelayServerAddressesList | null | undefined;
}
export type SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansCreateResultItemStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansCreateResultItemStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansCreateResultItemStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansCreateResultItemStaticAddressingDhcpServerDhcpOptionsList | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | null | undefined;
    dnsServers?: SitesLansCreateResultItemStaticAddressingDhcpServerDnsServersList | null | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansCreateResultItemStaticAddressingDhcpServerReservationsMap | null | undefined;
}
export interface SitesLansCreateResultItemStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansCreateResultItemStaticAddressingDhcpRelay | null | undefined;
    dhcpServer?: SitesLansCreateResultItemStaticAddressingDhcpServer | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null | undefined;
}
export interface SitesLansCreateResultItem {
    /** Identifier */
    id?: string | null | undefined;
    bondId?: number | null | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null | undefined;
    name?: string | null | undefined;
    nat?: SitesLansCreateResultItemNat | null | undefined;
    physport?: number | null | undefined;
    remoteSubnets?: SitesLansCreateResultItemRemoteSubnetsList | null | undefined;
    routedSubnets?: SitesLansCreateResultItemRoutedSubnetsList | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansCreateResultItemStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export type SitesLansCreateResultList = Array<SitesLansCreateResultItem>;
export interface CreateSiteLanResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesLansCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type CreateSitesAppConfigurationRequestPreferredWansList = Array<string>;
export interface CreateSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Magic account app ID. */
    accountAppId?: string | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: CreateSitesAppConfigurationRequestPreferredWansList | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | undefined;
    /** Managed app ID. */
    managedAppId?: string | undefined;
}
export type CreateSitesAppConfigurationResultAccountAppPreferredWansList = Array<string>;
export interface CreateSitesAppConfigurationResultAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: CreateSitesAppConfigurationResultAccountAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type CreateSitesAppConfigurationResultManagedAppPreferredWansList = Array<string>;
export interface CreateSitesAppConfigurationResultManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: CreateSitesAppConfigurationResultManagedAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type CreateSitesAppConfigurationResult = CreateSitesAppConfigurationResultAccountApp | CreateSitesAppConfigurationResultManagedApp;
export type CreateSitesAppConfigurationResponse = CreateSitesAppConfigurationResult;
export type SitesWansCreateRequestHealthCheckRate = "low" | "mid" | "high";
export interface SitesWansCreateRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    /** A valid IPv4 address. */
    gatewayAddress: string;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | undefined;
    /** Gateway address for the secondary connector of a high availability site. */
    secondaryGatewayAddress?: string | undefined;
}
export interface CreateSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    physport: number;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansCreateRequestHealthCheckRate | (string & {}) | undefined;
    loadBalanceInnerFlows?: boolean | undefined;
    name?: string | undefined;
    priority?: number | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. */
    provisionedDownloadKbps?: number | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. */
    provisionedUploadKbps?: number | undefined;
    /** Static addressing configuration for a WAN. Omit to use DHCP. Submit secondary_address when the site is in high availability mode. */
    staticAddressing?: SitesWansCreateRequestStaticAddressing | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | undefined;
}
export type SitesWansCreateResultItemHealthCheckRate = "low" | "mid" | "high";
export interface SitesWansCreateResultItemStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    /** A valid IPv4 address. */
    gatewayAddress: string;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null | undefined;
    /** Gateway address for the secondary connector of a high availability site. */
    secondaryGatewayAddress?: string | null | undefined;
}
export interface SitesWansCreateResultItem {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansCreateResultItemHealthCheckRate | null | undefined;
    loadBalanceInnerFlows?: boolean | null | undefined;
    name?: string | null | undefined;
    physport?: number | null | undefined;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. */
    provisionedDownloadKbps?: number | null | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. */
    provisionedUploadKbps?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export type SitesWansCreateResultList = Array<SitesWansCreateResultItem>;
export interface CreateSiteWanResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesWansCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface DeleteAppRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    accountAppId: string;
}
export type AppsDeleteResponseHostnamesList = Array<string>;
export type AppsDeleteResponseIpSubnetsList = Array<string>;
export type AppsDeleteResponseSourceSubnetsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAppResponse {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsDeleteResponseHostnamesList | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsDeleteResponseIpSubnetsList | null | undefined;
    /** Display name for the app. */
    name?: string | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsDeleteResponseSourceSubnetsList | null | undefined;
    /** Category of the app. */
    type?: string | null | undefined;
}
export interface DeleteBgpFilterProfileRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    profileId: string;
}
export type DeleteBgpFilterProfileResponseMatchAction = "allow" | "deny";
export type DeleteBgpFilterProfileResponseTargetsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteBgpFilterProfileResponse {
    /** Identifier */
    id: string;
    /** Description of the filter profile */
    description: string;
    /** Action to take when a route matches one of the targets in this profile */
    matchAction: DeleteBgpFilterProfileResponseMatchAction;
    /** Friendly name for the filter profile */
    name: string;
    /** List of CIDR prefixes. Each entry may carry an optional suffix that specifies which prefix lengths to match relative to the prefix length N: '{X,Y}' matches prefix lengths in the inclusive range [X, Y] where N &lt;= X &lt;= Y &lt;= max (max is 32 for IPv4, 128 for IPv6), '{X}' matches exactly length X (equivalent to {X,X}), '+' is shorthand for {N, max} (the prefix and all more-specific subnets, including at length N itself; valid even when N is the maximum length). Omit the suffix to match the prefix exactly at length N. */
    targets: DeleteBgpFilterProfileResponseTargetsList;
    createdOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
}
export interface DeleteCf1SiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
}
export type Cf1SitesDeleteResponseLocation = Cf1SitesCreateResultItemLocation;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCf1SiteResponse {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-provided description of the CF1 Site. */
    description?: string | null | undefined;
    location?: Cf1SitesCreateResultItemLocation | null | undefined;
    modifiedOn?: string | null | undefined;
}
export interface DeleteCf1SiteRampRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
    /** Identifier */
    rampId: string;
}
export type Cf1SitesRampsDeleteResponseType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export type Cf1SitesRampsDeleteResponseGre = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsDeleteResponseGreInterconnect = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsDeleteResponseIpsec = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsDeleteResponseMconn = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsDeleteResponseMplsInterconnect = Cf1SitesRampsCreateResultItemGre;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCf1SiteRampResponse {
    /** Identifier */
    id: string;
    createdOn: string;
    modifiedOn: string;
    /** A human-provided name describing the ramp that should be unique within the CF1 Site. */
    name: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsDeleteResponseType;
    /** A human-provided description of the ramp. */
    description?: string | null | undefined;
    gre?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    greInterconnect?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    ipsec?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    mconn?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    mplsInterconnect?: Cf1SitesRampsCreateResultItemGre | null | undefined;
}
export interface DeleteConnectorRequest {
    accountId: string;
    connectorId: string;
}
export type ConnectorsDeleteResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsDeleteResponseInterruptWindowDaysOfWeekList = Array<ConnectorsDeleteResponseInterruptWindowDaysOfWeekItem>;
export type ConnectorsDeleteResponseInterruptWindowEmbargoDatesList = Array<string>;
export type ConnectorsDeleteResponseDeviceType = "MANAGED" | "LICENSED";
export interface ConnectorsDeleteResponseDevice {
    id: string;
    serialNumber?: string | null | undefined;
    type?: ConnectorsDeleteResponseDeviceType | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsDeleteResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsDeleteResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    timezone: string;
    device?: ConnectorsDeleteResponseDevice | null | undefined;
    lastHeartbeat?: string | null | undefined;
    lastSeenVersion?: string | null | undefined;
    licenseKey?: string | null | undefined;
}
export interface DeleteGreTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    greTunnelId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type GreTunnelsDeleteResponseDeletedGreTunnelBgpExtraPrefixesList = Array<string>;
export interface GreTunnelsDeleteResponseDeletedGreTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: GreTunnelsDeleteResponseDeletedGreTunnelBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type GreTunnelsDeleteResponseDeletedGreTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface GreTunnelsDeleteResponseDeletedGreTunnelBgpStatus {
    state: GreTunnelsDeleteResponseDeletedGreTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckRate = "low" | "mid" | "high";
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckType = "reply" | "request";
export interface GreTunnelsDeleteResponseDeletedGreTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheckType | null | undefined;
}
export interface GreTunnelsDeleteResponseDeletedGreTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: GreTunnelsDeleteResponseDeletedGreTunnelBgp | null | undefined;
    bgpStatus?: GreTunnelsDeleteResponseDeletedGreTunnelBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the GRE tunnel. */
    description?: string | null | undefined;
    healthCheck?: GreTunnelsDeleteResponseDeletedGreTunnelHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteGreTunnelResponse {
    deleted?: boolean | null | undefined;
    deletedGreTunnel?: GreTunnelsDeleteResponseDeletedGreTunnel | null | undefined;
}
export interface DeleteIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    ipsecTunnelId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpExtraPrefixesList = Array<string>;
export interface IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatus {
    state: IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckRate = "low" | "mid" | "high";
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckType = "reply" | "request";
export interface IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheckType | null | undefined;
}
export type IpsecTunnelsDeleteResponseDeletedIpsecTunnelPskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export interface IpsecTunnelsDeleteResponseDeletedIpsecTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgp | null | undefined;
    bgpStatus?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null | undefined;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null | undefined;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null | undefined;
    healthCheck?: IpsecTunnelsDeleteResponseDeletedIpsecTunnelHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null | undefined;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteIpsecTunnelResponse {
    deleted?: boolean | null | undefined;
    deletedIpsecTunnel?: IpsecTunnelsDeleteResponseDeletedIpsecTunnel | null | undefined;
}
export interface DeletePcapOwnershipRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    ownershipId: string;
}
export interface DeletePcapOwnershipResponse {
}
export interface DeleteRouteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    routeId: string;
}
export type RoutesDeleteResponseDeletedRouteScopeColoNamesList = Array<string>;
export type RoutesDeleteResponseDeletedRouteScopeColoRegionsList = Array<string>;
export interface RoutesDeleteResponseDeletedRouteScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesDeleteResponseDeletedRouteScopeColoNamesList | null | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesDeleteResponseDeletedRouteScopeColoRegionsList | null | undefined;
}
export interface RoutesDeleteResponseDeletedRoute {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null | undefined;
    /** An optional human provided description of the static route. */
    description?: string | null | undefined;
    /** When the route was last modified. */
    modifiedOn?: string | null | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesDeleteResponseDeletedRouteScope | null | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRouteResponse {
    deleted?: boolean | null | undefined;
    deletedRoute?: RoutesDeleteResponseDeletedRoute | null | undefined;
}
export interface DeleteSiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export type SitesDeleteResponseLocation = SitesCreateResponseLocation;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic Connector identifier tag. */
    connectorId?: string | null | undefined;
    description?: string | null | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null | undefined;
    /** The name of the site. */
    name?: string | null | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null | undefined;
}
export interface DeleteSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    aclId: string;
}
export type SitesAclsDeleteResponseLan1PortRangesList = Array<string>;
export type SitesAclsDeleteResponseLan1PortsList = Array<number>;
export type SitesAclsDeleteResponseLan1SubnetsList = Array<string>;
export interface SitesAclsDeleteResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsDeleteResponseLan1PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsDeleteResponseLan1PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsDeleteResponseLan1SubnetsList | null | undefined;
}
export type SitesAclsDeleteResponseLan2PortRangesList = Array<string>;
export type SitesAclsDeleteResponseLan2PortsList = Array<number>;
export type SitesAclsDeleteResponseLan2SubnetsList = Array<string>;
export interface SitesAclsDeleteResponseLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsDeleteResponseLan2PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsDeleteResponseLan2PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsDeleteResponseLan2SubnetsList | null | undefined;
}
export type SitesAclsDeleteResponseProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsDeleteResponseProtocolsList = Array<SitesAclsDeleteResponseProtocolsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteAclResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Description for the ACL. */
    description?: string | null | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null | undefined;
    lan_1?: SitesAclsDeleteResponseLan1 | null | undefined;
    lan_2?: SitesAclsDeleteResponseLan2 | null | undefined;
    /** The name of the ACL. */
    name?: string | null | undefined;
    protocols?: SitesAclsDeleteResponseProtocolsList | null | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null | undefined;
}
export interface DeleteSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    lanId: string;
}
export type SitesLansDeleteResponseNat = SitesLansCreateResultItemNat;
export type SitesLansDeleteResponseRemoteSubnetsItem = SitesLansCreateRequestRemoteSubnetsItem;
export type SitesLansDeleteResponseRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansDeleteResponseRoutedSubnetsItemNat = SitesLansCreateResultItemNat;
export type SitesLansDeleteResponseRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export type SitesLansDeleteResponseRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansDeleteResponseStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansDeleteResponseStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansDeleteResponseStaticAddressingDhcpRelayServerAddressesList | null | undefined;
}
export type SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansDeleteResponseStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansDeleteResponseStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansDeleteResponseStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansDeleteResponseStaticAddressingDhcpServerDhcpOptionsList | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | null | undefined;
    dnsServers?: SitesLansDeleteResponseStaticAddressingDhcpServerDnsServersList | null | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansDeleteResponseStaticAddressingDhcpServerReservationsMap | null | undefined;
}
export interface SitesLansDeleteResponseStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansDeleteResponseStaticAddressingDhcpRelay | null | undefined;
    dhcpServer?: SitesLansDeleteResponseStaticAddressingDhcpServer | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteLanResponse {
    /** Identifier */
    id?: string | null | undefined;
    bondId?: number | null | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null | undefined;
    name?: string | null | undefined;
    nat?: SitesLansCreateResultItemNat | null | undefined;
    physport?: number | null | undefined;
    remoteSubnets?: SitesLansDeleteResponseRemoteSubnetsList | null | undefined;
    routedSubnets?: SitesLansDeleteResponseRoutedSubnetsList | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansDeleteResponseStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export interface DeleteSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    appConfigId: string;
}
export type DeleteSitesAppConfigurationResultAccountAppPreferredWansList = Array<string>;
export interface DeleteSitesAppConfigurationResultAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: DeleteSitesAppConfigurationResultAccountAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type DeleteSitesAppConfigurationResultManagedAppPreferredWansList = Array<string>;
export interface DeleteSitesAppConfigurationResultManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: DeleteSitesAppConfigurationResultManagedAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type DeleteSitesAppConfigurationResult = DeleteSitesAppConfigurationResultAccountApp | DeleteSitesAppConfigurationResultManagedApp;
export type DeleteSitesAppConfigurationResponse = DeleteSitesAppConfigurationResult;
export interface DeleteSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    wanId: string;
}
export type SitesWansDeleteResponseHealthCheckRate = "low" | "mid" | "high";
export type SitesWansDeleteResponseStaticAddressing = SitesWansCreateResultItemStaticAddressing;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteWanResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansDeleteResponseHealthCheckRate | null | undefined;
    loadBalanceInnerFlows?: boolean | null | undefined;
    name?: string | null | undefined;
    physport?: number | null | undefined;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. */
    provisionedDownloadKbps?: number | null | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. */
    provisionedUploadKbps?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export type EditSitesAppConfigurationRequestPreferredWansList = Array<string>;
export interface EditSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    appConfigId: string;
    /** Magic account app ID. */
    accountAppId?: string | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | undefined;
    /** Managed app ID. */
    managedAppId?: string | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: EditSitesAppConfigurationRequestPreferredWansList | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | undefined;
}
export type EditSitesAppConfigurationResultAccountAppPreferredWansList = Array<string>;
export interface EditSitesAppConfigurationResultAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: EditSitesAppConfigurationResultAccountAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type EditSitesAppConfigurationResultManagedAppPreferredWansList = Array<string>;
export interface EditSitesAppConfigurationResultManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: EditSitesAppConfigurationResultManagedAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type EditSitesAppConfigurationResult = EditSitesAppConfigurationResultAccountApp | EditSitesAppConfigurationResultManagedApp;
export type EditSitesAppConfigurationResponse = EditSitesAppConfigurationResult;
export interface EmptyRouteRequest {
    /** Identifier */
    accountId: string;
}
export type RoutesEmptyResponseDeletedRoutesItemScopeColoNamesList = Array<string>;
export type RoutesEmptyResponseDeletedRoutesItemScopeColoRegionsList = Array<string>;
export interface RoutesEmptyResponseDeletedRoutesItemScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesEmptyResponseDeletedRoutesItemScopeColoNamesList | null | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesEmptyResponseDeletedRoutesItemScopeColoRegionsList | null | undefined;
}
export interface RoutesEmptyResponseDeletedRoutesItem {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null | undefined;
    /** An optional human provided description of the static route. */
    description?: string | null | undefined;
    /** When the route was last modified. */
    modifiedOn?: string | null | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesEmptyResponseDeletedRoutesItemScope | null | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null | undefined;
}
export type RoutesEmptyResponseDeletedRoutesList = Array<RoutesEmptyResponseDeletedRoutesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EmptyRouteResponse {
    deleted?: boolean | null | undefined;
    deletedRoutes?: RoutesEmptyResponseDeletedRoutesList | null | undefined;
}
export interface GetBgpFilterProfileRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    profileId: string;
}
export type GetBgpFilterProfileResponseMatchAction = "allow" | "deny";
export type GetBgpFilterProfileResponseTargetsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBgpFilterProfileResponse {
    /** Identifier */
    id: string;
    /** Description of the filter profile */
    description: string;
    /** Action to take when a route matches one of the targets in this profile */
    matchAction: GetBgpFilterProfileResponseMatchAction;
    /** Friendly name for the filter profile */
    name: string;
    /** List of CIDR prefixes. Each entry may carry an optional suffix that specifies which prefix lengths to match relative to the prefix length N: '{X,Y}' matches prefix lengths in the inclusive range [X, Y] where N &lt;= X &lt;= Y &lt;= max (max is 32 for IPv4, 128 for IPv6), '{X}' matches exactly length X (equivalent to {X,X}), '+' is shorthand for {N, max} (the prefix and all more-specific subnets, including at length N itself; valid even when N is the maximum length). Omit the suffix to match the prefix exactly at length N. */
    targets: GetBgpFilterProfileResponseTargetsList;
    createdOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
}
export interface GetCf1SiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
}
export type Cf1SitesGetResponseLocation = Cf1SitesCreateResultItemLocation;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCf1SiteResponse {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-provided description of the CF1 Site. */
    description?: string | null | undefined;
    location?: Cf1SitesCreateResultItemLocation | null | undefined;
    modifiedOn?: string | null | undefined;
}
export interface GetCf1SiteRampRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
    /** Identifier */
    rampId: string;
}
export type Cf1SitesRampsGetResponseType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export type Cf1SitesRampsGetResponseGre = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsGetResponseGreInterconnect = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsGetResponseIpsec = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsGetResponseMconn = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsGetResponseMplsInterconnect = Cf1SitesRampsCreateResultItemGre;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCf1SiteRampResponse {
    /** Identifier */
    id: string;
    createdOn: string;
    modifiedOn: string;
    /** A human-provided name describing the ramp that should be unique within the CF1 Site. */
    name: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsGetResponseType;
    /** A human-provided description of the ramp. */
    description?: string | null | undefined;
    gre?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    greInterconnect?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    ipsec?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    mconn?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    mplsInterconnect?: Cf1SitesRampsCreateResultItemGre | null | undefined;
}
export interface GetCfInterconnectRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cfInterconnectId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type CfInterconnectsGetResponseInterconnectBgpExtraPrefixesList = Array<string>;
export interface CfInterconnectsGetResponseInterconnectBgp {
    /** Deprecated. Use customer_asn. */
    asNo?: number | null | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    cloudflareEndpoint?: string | null | undefined;
    /** ASN used on the customer end of the BGP session. */
    customerAsn?: number | null | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    customerEndpoint?: string | null | undefined;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** IPv4 prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. */
    extraPrefixes?: CfInterconnectsGetResponseInterconnectBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type CfInterconnectsGetResponseInterconnectGre = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre;
export type CfInterconnectsGetResponseInterconnectHealthCheckDirection = "unidirectional" | "bidirectional";
export type CfInterconnectsGetResponseInterconnectHealthCheckRate = "low" | "mid" | "high";
export type CfInterconnectsGetResponseInterconnectHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsGetResponseInterconnectHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsGetResponseInterconnectHealthCheckType = "reply" | "request";
export interface CfInterconnectsGetResponseInterconnectHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the interconnect and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the interconnect. */
    direction?: CfInterconnectsGetResponseInterconnectHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsGetResponseInterconnectHealthCheckRate | null | undefined;
    /** The source IPv4 address used for bidirectional health checks. Supported only for version 1.5 interconnects. It is required when `direction` is `bidirectional` and must be omitted (and is cleared) when `direction` is `unidirectional`. The address must be within RFC1918 space, the approved link-local range 169.254.240.0/20, or the Cloudflare reserved range 198.41.199.224/27. */
    source?: string | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsGetResponseInterconnectHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsGetResponseInterconnectHealthCheckType | null | undefined;
}
export interface CfInterconnectsGetResponseInterconnect {
    /** Identifier */
    id?: string | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: CfInterconnectsGetResponseInterconnectBgp | null | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    coloName?: string | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the interconnect. */
    description?: string | null | undefined;
    /** Omitted in responses for version 1.5 interconnects. */
    gre?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre | null | undefined;
    healthCheck?: CfInterconnectsGetResponseInterconnectHealthCheck | null | undefined;
    /** The IPv4 interface address for the interconnect. For MPLS Interconnects, use a /30 or /31 prefix. For GRE Interconnects, a /30 or /31 prefix may be used. Version 1.5 interconnects require a /31 prefix and may also use a prefix from the account's authorized prefixes; otherwise, select the subnet from RFC 1918 or the approved link-local ranges. */
    interfaceAddress?: string | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | null | undefined;
    /** Immutable interconnect version configured at creation time. One of: */
    version?: string | null | undefined;
    /** An identifier that correlates this interconnect with the corresponding V2 CNI interconnect resource. */
    virtualPortReservationId?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCfInterconnectResponse {
    interconnect?: CfInterconnectsGetResponseInterconnect | null | undefined;
}
export interface GetConnectorRequest {
    accountId: string;
    connectorId: string;
}
export type ConnectorsGetResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsGetResponseInterruptWindowDaysOfWeekList = Array<ConnectorsGetResponseInterruptWindowDaysOfWeekItem>;
export type ConnectorsGetResponseInterruptWindowEmbargoDatesList = Array<string>;
export type ConnectorsGetResponseDeviceType = "MANAGED" | "LICENSED";
export interface ConnectorsGetResponseDevice {
    id: string;
    serialNumber?: string | null | undefined;
    type?: ConnectorsGetResponseDeviceType | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsGetResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsGetResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    timezone: string;
    device?: ConnectorsGetResponseDevice | null | undefined;
    lastHeartbeat?: string | null | undefined;
    lastSeenVersion?: string | null | undefined;
    licenseKey?: string | null | undefined;
}
export interface GetConnectorEventRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    eventT: number;
    eventN: number;
}
export type ConnectorsEventsGetResponseEK = "Init" | "Leave" | "StartAttestation" | "FinishAttestationSuccess" | "FinishAttestationFailure" | "StartRotateCryptKey" | "FinishRotateCryptKeySuccess" | "FinishRotateCryptKeyFailure" | "StartRotatePki" | "FinishRotatePkiSuccess" | "FinishRotatePkiFailure" | "StartUpgrade" | "FinishUpgradeSuccess" | "FinishUpgradeFailure" | "BlessSlotSuccess" | "BlessSlotPending" | "BlessSlotFailure" | "Reconcile" | "ConfigureCloudflaredTunnel" | "RekeyInstallBoth" | "RekeyStart" | "RekeyRestart" | "RekeyAdvance" | "RekeyComplete" | "RekeyReset" | "HaTransition" | "HaError" | "HaInit" | "HaLeave";
export interface ConnectorsEventsGetResponseE {
    /** Event kind */
    k: ConnectorsEventsGetResponseEK;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConnectorEventResponse {
    /** Event kind plus event-specific payload fields. */
    e: ConnectorsEventsGetResponseE;
    /** Sequence number, used to order events with the same timestamp */
    n: number;
    /** Time the Event was recorded (seconds since the Unix epoch) */
    t: number;
    /** Version */
    v?: string | null | undefined;
}
export interface GetConnectorSnapshotRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    snapshotT: number;
}
export interface ConnectorsSnapshotsGetResponseBondsItem {
    /** Name of the network interface */
    name: string;
    /** Current status of the network interface */
    status: string;
}
export type ConnectorsSnapshotsGetResponseBondsList = Array<ConnectorsSnapshotsGetResponseBondsItem>;
export interface ConnectorsSnapshotsGetResponseDhcpLeasesItem {
    /** Client ID of the device the IP Address was leased to */
    clientId: string;
    /** Expiry time of the DHCP lease (seconds since the Unix epoch) */
    expiryTime: number;
    /** Hostname of the device the IP Address was leased to */
    hostname: string;
    /** Name of the network interface */
    interfaceName: string;
    /** IP Address that was leased */
    ipAddress: string;
    /** MAC Address of the device the IP Address was leased to */
    macAddress: string;
}
export type ConnectorsSnapshotsGetResponseDhcpLeasesList = Array<ConnectorsSnapshotsGetResponseDhcpLeasesItem>;
export interface ConnectorsSnapshotsGetResponseDisksItem {
    /** I/Os currently in progress */
    inProgress: number;
    /** Device major number */
    major: number;
    /** Reads merged */
    merged: number;
    /** Device minor number */
    minor: number;
    /** Device name */
    name: string;
    /** Reads completed successfully */
    reads: number;
    /** Sectors read successfully */
    sectorsRead: number;
    /** Sectors written successfully */
    sectorsWritten: number;
    /** Time spent doing I/Os (milliseconds) */
    timeInProgressMs: number;
    /** Time spent reading (milliseconds) */
    timeReadingMs: number;
    /** Time spent writing (milliseconds) */
    timeWritingMs: number;
    /** Weighted time spent doing I/Os (milliseconds) */
    weightedTimeInProgressMs: number;
    /** Writes completed */
    writes: number;
    /** Writes merged */
    writesMerged: number;
    /** Discards completed successfully */
    discards?: number | null | undefined;
    /** Discards merged */
    discardsMerged?: number | null | undefined;
    /** Flushes completed successfully */
    flushes?: number | null | undefined;
    /** Sectors discarded */
    sectorsDiscarded?: number | null | undefined;
    /** Time spent discarding (milliseconds) */
    timeDiscardingMs?: number | null | undefined;
    /** Time spent flushing (milliseconds) */
    timeFlushingMs?: number | null | undefined;
}
export type ConnectorsSnapshotsGetResponseDisksList = Array<ConnectorsSnapshotsGetResponseDisksItem>;
export interface ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem {
    /** Name of the network interface */
    interfaceName: string;
    /** IP address of the network interface */
    ipAddress: string;
}
export type ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesList = Array<ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem>;
export interface ConnectorsSnapshotsGetResponseInterfacesItem {
    /** Name of the network interface */
    name: string;
    /** UP/DOWN state of the network interface */
    operstate: string;
    /** Comma-separated list of reasons for health score */
    healthReason?: string | null | undefined;
    /** Aggregate health score (0-100) */
    healthScore?: number | null | undefined;
    ipAddresses?: ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesList | null | undefined;
    /** Speed of the network interface (bits per second) */
    speed?: number | null | undefined;
}
export type ConnectorsSnapshotsGetResponseInterfacesList = Array<ConnectorsSnapshotsGetResponseInterfacesItem>;
export interface ConnectorsSnapshotsGetResponseMountsItem {
    /** File system on disk (EXT4, NTFS, etc.) */
    fileSystem: string;
    /** Kind of disk (HDD, SSD, etc.) */
    kind: string;
    /** Path where disk is mounted */
    mountPoint: string;
    /** Name of the disk mount */
    name: string;
    /** Available disk size (bytes) */
    availableBytes?: number | null | undefined;
    /** Available inodes on filesystem */
    availableInodes?: number | null | undefined;
    /** Determines whether the disk is read-only */
    isReadOnly?: boolean | null | undefined;
    /** Determines whether the disk is removable */
    isRemovable?: boolean | null | undefined;
    /** Total disk size (bytes) */
    totalBytes?: number | null | undefined;
    /** Total inodes on filesystem */
    totalInodes?: number | null | undefined;
}
export type ConnectorsSnapshotsGetResponseMountsList = Array<ConnectorsSnapshotsGetResponseMountsItem>;
export interface ConnectorsSnapshotsGetResponseNetdevsItem {
    /** Name of the network device */
    name: string;
    /** Total bytes received */
    recvBytes: number;
    /** Compressed packets received */
    recvCompressed: number;
    /** Packets dropped */
    recvDrop: number;
    /** Bad packets received */
    recvErrs: number;
    /** FIFO overruns */
    recvFifo: number;
    /** Frame alignment errors */
    recvFrame: number;
    /** Multicast packets received */
    recvMulticast: number;
    /** Total packets received */
    recvPackets: number;
    /** Total bytes transmitted */
    sentBytes: number;
    /** Number of packets not sent due to carrier errors */
    sentCarrier: number;
    /** Number of collisions */
    sentColls: number;
    /** Number of compressed packets transmitted */
    sentCompressed: number;
    /** Number of packets dropped during transmission */
    sentDrop: number;
    /** Number of transmission errors */
    sentErrs: number;
    /** FIFO overruns */
    sentFifo: number;
    /** Total packets transmitted */
    sentPackets: number;
}
export type ConnectorsSnapshotsGetResponseNetdevsList = Array<ConnectorsSnapshotsGetResponseNetdevsItem>;
export interface ConnectorsSnapshotsGetResponseRoutesItem {
    /** Route destination as default or an IPv4 CIDR */
    destination: string;
    /** Interface used by the next hop */
    interfaceName: string;
    /** Routing decision type: tunnel, breakout, or lan */
    kind: string;
    /** Route metric; lower metrics are preferred */
    metric: number;
    /** Gateway address for the next hop */
    gateway?: string | null | undefined;
    /** Relative weight within an equal-cost route */
    weight?: number | null | undefined;
}
export type ConnectorsSnapshotsGetResponseRoutesList = Array<ConnectorsSnapshotsGetResponseRoutesItem>;
export interface ConnectorsSnapshotsGetResponseThermalsItem {
    /** Sensor identifier for the component */
    label: string;
    /** Critical failure temperature of the component (degrees Celsius) */
    criticalCelcius?: number | null | undefined;
    /** Current temperature of the component (degrees Celsius) */
    currentCelcius?: number | null | undefined;
    /** Maximum temperature of the component (degrees Celsius) */
    maxCelcius?: number | null | undefined;
}
export type ConnectorsSnapshotsGetResponseThermalsList = Array<ConnectorsSnapshotsGetResponseThermalsItem>;
export interface ConnectorsSnapshotsGetResponseTunnelsItem {
    /** Name of tunnel health state (unknown, healthy, degraded, down) */
    healthState: string;
    /** Numeric value associated with tunnel state (0 = unknown, 1 = healthy, 2 = degraded, 3 = down) */
    healthValue: number;
    /** The tunnel interface name (i.e. xfrm1, xfrm3.99, etc.) */
    interfaceName: string;
    /** Tunnel identifier */
    tunnelId: string;
    /** Tunnel round-trip latency variation in milliseconds */
    jitterMs?: number | null | undefined;
    /** 50th percentile tunnel round-trip latency in milliseconds */
    latencyMs?: number | null | undefined;
    /** Public socket address returned by the NAT detector */
    natdResult?: string | null | undefined;
    /** Numeric NAT detector state (0 = detected, 1 = missing result, 2 = stale result) */
    natdState?: number | null | undefined;
    /** Target socket address probed by the NAT detector, using the detector source port */
    natdTarget?: string | null | undefined;
    /** MTU as measured between the two ends of the tunnel */
    probedMtu?: number | null | undefined;
    /** Number of recent healthy pings for this tunnel */
    recentHealthyPings?: number | null | undefined;
    /** Number of recent unhealthy pings for this tunnel */
    recentUnhealthyPings?: number | null | undefined;
}
export type ConnectorsSnapshotsGetResponseTunnelsList = Array<ConnectorsSnapshotsGetResponseTunnelsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetConnectorSnapshotResponse {
    /** Count of failures to reclaim space */
    countReclaimFailures: number;
    /** Count of reclaimed paths */
    countReclaimedPaths: number;
    /** Count of failed snapshot recordings */
    countRecordFailed: number;
    /** Count of failed snapshot transmissions */
    countTransmitFailures: number;
    /** Time the Snapshot was recorded (seconds since the Unix epoch) */
    t: number;
    /** Version */
    v: string;
    bonds?: ConnectorsSnapshotsGetResponseBondsList | null | undefined;
    /** Count of processors/cores */
    cpuCount?: number | null | undefined;
    /** Percentage of time over a 10 second window that tasks were stalled */
    cpu_pressure_10s?: number | null | undefined;
    /** Percentage of time over a 5 minute window that tasks were stalled */
    cpu_pressure_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that tasks were stalled */
    cpu_pressure_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    cpuPressureTotalUs?: number | null | undefined;
    /** Time spent running a virtual CPU or guest OS (milliseconds) */
    cpuTimeGuestMs?: number | null | undefined;
    /** Time spent running a niced guest (milliseconds) */
    cpuTimeGuestNiceMs?: number | null | undefined;
    /** Time spent in idle state (milliseconds) */
    cpuTimeIdleMs?: number | null | undefined;
    /** Time spent wait for I/O to complete (milliseconds) */
    cpuTimeIowaitMs?: number | null | undefined;
    /** Time spent servicing interrupts (milliseconds) */
    cpuTimeIrqMs?: number | null | undefined;
    /** Time spent in low-priority user mode (milliseconds) */
    cpuTimeNiceMs?: number | null | undefined;
    /** Time spent servicing softirqs (milliseconds) */
    cpuTimeSoftirqMs?: number | null | undefined;
    /** Time stolen (milliseconds) */
    cpuTimeStealMs?: number | null | undefined;
    /** Time spent in system mode (milliseconds) */
    cpuTimeSystemMs?: number | null | undefined;
    /** Time spent in user mode (milliseconds) */
    cpuTimeUserMs?: number | null | undefined;
    /** Number of network operations applied during state transition */
    delta?: number | null | undefined;
    dhcpLeases?: ConnectorsSnapshotsGetResponseDhcpLeasesList | null | undefined;
    disks?: ConnectorsSnapshotsGetResponseDisksList | null | undefined;
    /** Simulated number of network operations applied during state transition */
    epsilon?: number | null | undefined;
    /** Name of high availability state */
    haState?: string | null | undefined;
    /** Numeric value associated with high availability state (0 = disabled, 1 = active, 2 = standby, 3 = stopped, 4 = fault) */
    haValue?: number | null | undefined;
    interfaces?: ConnectorsSnapshotsGetResponseInterfacesList | null | undefined;
    /** Percentage of time over a 10 second window that all tasks were stalled */
    io_pressure_full_10s?: number | null | undefined;
    /** Percentage of time over a 5 minute window that all tasks were stalled */
    io_pressure_full_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that all tasks were stalled */
    io_pressure_full_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    ioPressureFullTotalUs?: number | null | undefined;
    /** Percentage of time over a 10 second window that some tasks were stalled */
    io_pressure_some_10s?: number | null | undefined;
    /** Percentage of time over a 3 minute window that some tasks were stalled */
    io_pressure_some_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that some tasks were stalled */
    io_pressure_some_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    ioPressureSomeTotalUs?: number | null | undefined;
    /** Boot time (seconds since Unix epoch) */
    kernelBtime?: number | null | undefined;
    /** Number of context switches that the system underwent */
    kernelCtxt?: number | null | undefined;
    /** Number of forks since boot */
    kernelProcesses?: number | null | undefined;
    /** Number of processes blocked waiting for I/O */
    kernelProcessesBlocked?: number | null | undefined;
    /** Number of processes in runnable state */
    kernelProcessesRunning?: number | null | undefined;
    /** The fifteen-minute load average */
    load_average_15m?: number | null | undefined;
    /** The one-minute load average */
    load_average_1m?: number | null | undefined;
    /** The five-minute load average */
    load_average_5m?: number | null | undefined;
    /** Number of currently runnable kernel scheduling entities */
    loadAverageCur?: number | null | undefined;
    /** Number of kernel scheduling entities that currently exist on the system */
    loadAverageMax?: number | null | undefined;
    /** Memory that has been used more recently */
    memoryActiveBytes?: number | null | undefined;
    /** Non-file backed huge pages mapped into user-space page tables */
    memoryAnonHugepagesBytes?: number | null | undefined;
    /** Non-file backed pages mapped into user-space page tables */
    memoryAnonPagesBytes?: number | null | undefined;
    /** Estimate of how much memory is available for starting new applications */
    memoryAvailableBytes?: number | null | undefined;
    /** Memory used for block device bounce buffers */
    memoryBounceBytes?: number | null | undefined;
    /** Relatively temporary storage for raw disk blocks */
    memoryBuffersBytes?: number | null | undefined;
    /** In-memory cache for files read from the disk */
    memoryCachedBytes?: number | null | undefined;
    /** Free CMA (Contiguous Memory Allocator) pages */
    memoryCmaFreeBytes?: number | null | undefined;
    /** Total CMA (Contiguous Memory Allocator) pages */
    memoryCmaTotalBytes?: number | null | undefined;
    /** Total amount of memory currently available to be allocated on the system */
    memoryCommitLimitBytes?: number | null | undefined;
    /** Amount of memory presently allocated on the system */
    memoryCommittedAsBytes?: number | null | undefined;
    /** Memory which is waiting to get written back to the disk */
    memoryDirtyBytes?: number | null | undefined;
    /** The sum of LowFree and HighFree */
    memoryFreeBytes?: number | null | undefined;
    /** Amount of free highmem */
    memoryHighFreeBytes?: number | null | undefined;
    /** Total amount of highmem */
    memoryHighTotalBytes?: number | null | undefined;
    /** The number of huge pages in the pool that are not yet allocated */
    memoryHugepagesFree?: number | null | undefined;
    /** Number of huge pages for which a commitment has been made, but no allocation has yet been made */
    memoryHugepagesRsvd?: number | null | undefined;
    /** Number of huge pages in the pool above the threshold */
    memoryHugepagesSurp?: number | null | undefined;
    /** The size of the pool of huge pages */
    memoryHugepagesTotal?: number | null | undefined;
    /** The size of huge pages */
    memoryHugepagesizeBytes?: number | null | undefined;
    /** Memory which has been less recently used */
    memoryInactiveBytes?: number | null | undefined;
    /** Kernel allocations that the kernel will attempt to reclaim under memory pressure */
    memoryKReclaimableBytes?: number | null | undefined;
    /** Amount of memory allocated to kernel stacks */
    memoryKernelStackBytes?: number | null | undefined;
    /** Amount of free lowmem */
    memoryLowFreeBytes?: number | null | undefined;
    /** Total amount of lowmem */
    memoryLowTotalBytes?: number | null | undefined;
    /** Files which have been mapped into memory */
    memoryMappedBytes?: number | null | undefined;
    /** Amount of memory dedicated to the lowest level of page tables */
    memoryPageTablesBytes?: number | null | undefined;
    /** Memory allocated to the per-cpu alloctor used to back per-cpu allocations */
    memoryPerCpuBytes?: number | null | undefined;
    /** Percentage of time over a 10 second window that all tasks were stalled */
    memory_pressure_full_10s?: number | null | undefined;
    /** Percentage of time over a 5 minute window that all tasks were stalled */
    memory_pressure_full_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that all tasks were stalled */
    memory_pressure_full_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    memoryPressureFullTotalUs?: number | null | undefined;
    /** Percentage of time over a 10 second window that some tasks were stalled */
    memory_pressure_some_10s?: number | null | undefined;
    /** Percentage of time over a 5 minute window that some tasks were stalled */
    memory_pressure_some_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that some tasks were stalled */
    memory_pressure_some_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    memoryPressureSomeTotalUs?: number | null | undefined;
    /** Part of slab that can be reclaimed on memory pressure */
    memorySReclaimableBytes?: number | null | undefined;
    /** Part of slab that cannot be reclaimed on memory pressure */
    memorySUnreclaimBytes?: number | null | undefined;
    /** Amount of memory dedicated to the lowest level of page tables */
    memorySecondaryPageTablesBytes?: number | null | undefined;
    /** Amount of memory consumed by tmpfs */
    memoryShmemBytes?: number | null | undefined;
    /** Memory used by shmem and tmpfs, allocated with huge pages */
    memoryShmemHugepagesBytes?: number | null | undefined;
    /** Shared memory mapped into user space with huge pages */
    memoryShmemPmdMappedBytes?: number | null | undefined;
    /** In-kernel data structures cache */
    memorySlabBytes?: number | null | undefined;
    /** Memory swapped out and back in while still in swap file */
    memorySwapCachedBytes?: number | null | undefined;
    /** Amount of swap space that is currently unused */
    memorySwapFreeBytes?: number | null | undefined;
    /** Total amount of swap space available */
    memorySwapTotalBytes?: number | null | undefined;
    /** Total usable RAM */
    memoryTotalBytes?: number | null | undefined;
    /** Largest contiguous block of vmalloc area which is free */
    memoryVmallocChunkBytes?: number | null | undefined;
    /** Total size of vmalloc memory area */
    memoryVmallocTotalBytes?: number | null | undefined;
    /** Amount of vmalloc area which is used */
    memoryVmallocUsedBytes?: number | null | undefined;
    /** Memory which is actively being written back to the disk */
    memoryWritebackBytes?: number | null | undefined;
    /** Memory used by FUSE for temporary writeback buffers */
    memoryWritebackTmpBytes?: number | null | undefined;
    /** Memory consumed by the zswap backend, compressed */
    memoryZSwapBytes?: number | null | undefined;
    /** Amount of anonymous memory stored in zswap, uncompressed */
    memoryZSwappedBytes?: number | null | undefined;
    mounts?: ConnectorsSnapshotsGetResponseMountsList | null | undefined;
    netdevs?: ConnectorsSnapshotsGetResponseNetdevsList | null | undefined;
    /** Platform identifier */
    platform?: string | null | undefined;
    routes?: ConnectorsSnapshotsGetResponseRoutesList | null | undefined;
    /** Site identifier */
    siteId?: string | null | undefined;
    /** Number of ICMP Address Mask Reply messages received */
    snmpIcmpInAddrMaskReps?: number | null | undefined;
    /** Number of ICMP Address Mask Request messages received */
    snmpIcmpInAddrMasks?: number | null | undefined;
    /** Number of ICMP messages received with bad checksums */
    snmpIcmpInCsumErrors?: number | null | undefined;
    /** Number of ICMP Destination Unreachable messages received */
    snmpIcmpInDestUnreachs?: number | null | undefined;
    /** Number of ICMP Echo Reply messages received */
    snmpIcmpInEchoReps?: number | null | undefined;
    /** Number of ICMP Echo (request) messages received */
    snmpIcmpInEchos?: number | null | undefined;
    /** Number of ICMP messages received with ICMP-specific errors */
    snmpIcmpInErrors?: number | null | undefined;
    /** Number of ICMP messages received */
    snmpIcmpInMsgs?: number | null | undefined;
    /** Number of ICMP Parameter Problem messages received */
    snmpIcmpInParmProbs?: number | null | undefined;
    /** Number of ICMP Redirect messages received */
    snmpIcmpInRedirects?: number | null | undefined;
    /** Number of ICMP Source Quench messages received */
    snmpIcmpInSrcQuenchs?: number | null | undefined;
    /** Number of ICMP Time Exceeded messages received */
    snmpIcmpInTimeExcds?: number | null | undefined;
    /** Number of ICMP Address Mask Request messages received */
    snmpIcmpInTimestampReps?: number | null | undefined;
    /** Number of ICMP Timestamp (request) messages received */
    snmpIcmpInTimestamps?: number | null | undefined;
    /** Number of ICMP Address Mask Reply messages sent */
    snmpIcmpOutAddrMaskReps?: number | null | undefined;
    /** Number of ICMP Address Mask Request messages sent */
    snmpIcmpOutAddrMasks?: number | null | undefined;
    /** Number of ICMP Destination Unreachable messages sent */
    snmpIcmpOutDestUnreachs?: number | null | undefined;
    /** Number of ICMP Echo Reply messages sent */
    snmpIcmpOutEchoReps?: number | null | undefined;
    /** Number of ICMP Echo (request) messages sent */
    snmpIcmpOutEchos?: number | null | undefined;
    /** Number of ICMP messages which this entity did not send due to ICMP-specific errors */
    snmpIcmpOutErrors?: number | null | undefined;
    /** Number of ICMP messages attempted to send */
    snmpIcmpOutMsgs?: number | null | undefined;
    /** Number of ICMP Parameter Problem messages sent */
    snmpIcmpOutParmProbs?: number | null | undefined;
    /** Number of ICMP Redirect messages sent */
    snmpIcmpOutRedirects?: number | null | undefined;
    /** Number of ICMP Source Quench messages sent */
    snmpIcmpOutSrcQuenchs?: number | null | undefined;
    /** Number of ICMP Time Exceeded messages sent */
    snmpIcmpOutTimeExcds?: number | null | undefined;
    /** Number of ICMP Timestamp Reply messages sent */
    snmpIcmpOutTimestampReps?: number | null | undefined;
    /** Number of ICMP Timestamp (request) messages sent */
    snmpIcmpOutTimestamps?: number | null | undefined;
    /** Default value of the Time-To-Live field of the IP header */
    snmpIpDefaultTtl?: number | null | undefined;
    /** Number of datagrams forwarded to their final destination */
    snmpIpForwDatagrams?: number | null | undefined;
    /** Set when acting as an IP gateway */
    snmpIpForwardingEnabled?: boolean | null | undefined;
    /** Number of datagrams generated by fragmentation */
    snmpIpFragCreates?: number | null | undefined;
    /** Number of datagrams discarded because fragmentation failed */
    snmpIpFragFails?: number | null | undefined;
    /** Number of datagrams successfully fragmented */
    snmpIpFragOks?: number | null | undefined;
    /** Number of input datagrams discarded due to errors in the IP address */
    snmpIpInAddrErrors?: number | null | undefined;
    /** Number of input datagrams successfully delivered to IP user-protocols */
    snmpIpInDelivers?: number | null | undefined;
    /** Number of input datagrams otherwise discarded */
    snmpIpInDiscards?: number | null | undefined;
    /** Number of input datagrams discarded due to errors in the IP header */
    snmpIpInHdrErrors?: number | null | undefined;
    /** Number of input datagrams received from interfaces */
    snmpIpInReceives?: number | null | undefined;
    /** Number of input datagrams discarded due unknown or unsupported protocol */
    snmpIpInUnknownProtos?: number | null | undefined;
    /** Number of output datagrams otherwise discarded */
    snmpIpOutDiscards?: number | null | undefined;
    /** Number of output datagrams discarded because no route matched */
    snmpIpOutNoRoutes?: number | null | undefined;
    /** Number of datagrams supplied for transmission */
    snmpIpOutRequests?: number | null | undefined;
    /** Number of failures detected by the reassembly algorithm */
    snmpIpReasmFails?: number | null | undefined;
    /** Number of datagrams successfully reassembled */
    snmpIpReasmOks?: number | null | undefined;
    /** Number of fragments received which needed to be reassembled */
    snmpIpReasmReqds?: number | null | undefined;
    /** Number of seconds fragments are held while awaiting reassembly */
    snmpIpReasmTimeout?: number | null | undefined;
    /** Number of times TCP transitions to SYN-SENT from CLOSED */
    snmpTcpActiveOpens?: number | null | undefined;
    /** Number of times TCP transitions to CLOSED from SYN-SENT or SYN-RCVD, plus transitions to LISTEN from SYN-RCVD */
    snmpTcpAttemptFails?: number | null | undefined;
    /** Number of TCP connections in ESTABLISHED or CLOSE-WAIT */
    snmpTcpCurrEstab?: number | null | undefined;
    /** Number of times TCP transitions to CLOSED from ESTABLISHED or CLOSE-WAIT */
    snmpTcpEstabResets?: number | null | undefined;
    /** Number of TCP segments received with checksum errors */
    snmpTcpInCsumErrors?: number | null | undefined;
    /** Number of TCP segments received in error */
    snmpTcpInErrs?: number | null | undefined;
    /** Number of TCP segments received */
    snmpTcpInSegs?: number | null | undefined;
    /** Limit on the total number of TCP connections */
    snmpTcpMaxConn?: number | null | undefined;
    /** Number of TCP segments sent with RST flag */
    snmpTcpOutRsts?: number | null | undefined;
    /** Number of TCP segments sent */
    snmpTcpOutSegs?: number | null | undefined;
    /** Number of times TCP transitions to SYN-RCVD from LISTEN */
    snmpTcpPassiveOpens?: number | null | undefined;
    /** Number of TCP segments retransmitted */
    snmpTcpRetransSegs?: number | null | undefined;
    /** Maximum value permitted by a TCP implementation for the retransmission timeout (milliseconds) */
    snmpTcpRtoMax?: number | null | undefined;
    /** Minimum value permitted by a TCP implementation for the retransmission timeout (milliseconds) */
    snmpTcpRtoMin?: number | null | undefined;
    /** Number of UDP datagrams delivered to UDP applications */
    snmpUdpInDatagrams?: number | null | undefined;
    /** Number of UDP datagrams failed to be delivered for reasons other than lack of application at the destination port */
    snmpUdpInErrors?: number | null | undefined;
    /** Number of UDP datagrams received for which there was not application at the destination port */
    snmpUdpNoPorts?: number | null | undefined;
    /** Number of UDP datagrams sent */
    snmpUdpOutDatagrams?: number | null | undefined;
    /** Boottime of the system (seconds since the Unix epoch) */
    systemBootTimeS?: number | null | undefined;
    thermals?: ConnectorsSnapshotsGetResponseThermalsList | null | undefined;
    tunnels?: ConnectorsSnapshotsGetResponseTunnelsList | null | undefined;
    /** Sum of how much time each core has spent idle */
    uptimeIdleMs?: number | null | undefined;
    /** Uptime of the system, including time spent in suspend */
    uptimeTotalMs?: number | null | undefined;
}
export interface GetGreTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    greTunnelId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type GreTunnelsGetResponseGreTunnelBgpExtraPrefixesList = Array<string>;
export interface GreTunnelsGetResponseGreTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: GreTunnelsGetResponseGreTunnelBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type GreTunnelsGetResponseGreTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface GreTunnelsGetResponseGreTunnelBgpStatus {
    state: GreTunnelsGetResponseGreTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type GreTunnelsGetResponseGreTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export type GreTunnelsGetResponseGreTunnelHealthCheckRate = "low" | "mid" | "high";
export type GreTunnelsGetResponseGreTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsGetResponseGreTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsGetResponseGreTunnelHealthCheckType = "reply" | "request";
export interface GreTunnelsGetResponseGreTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsGetResponseGreTunnelHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsGetResponseGreTunnelHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsGetResponseGreTunnelHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsGetResponseGreTunnelHealthCheckType | null | undefined;
}
export interface GreTunnelsGetResponseGreTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: GreTunnelsGetResponseGreTunnelBgp | null | undefined;
    bgpStatus?: GreTunnelsGetResponseGreTunnelBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the GRE tunnel. */
    description?: string | null | undefined;
    healthCheck?: GreTunnelsGetResponseGreTunnelHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetGreTunnelResponse {
    greTunnel?: GreTunnelsGetResponseGreTunnel | null | undefined;
}
export interface GetIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    ipsecTunnelId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type IpsecTunnelsGetResponseIpsecTunnelBgpExtraPrefixesList = Array<string>;
export interface IpsecTunnelsGetResponseIpsecTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: IpsecTunnelsGetResponseIpsecTunnelBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type IpsecTunnelsGetResponseIpsecTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface IpsecTunnelsGetResponseIpsecTunnelBgpStatus {
    state: IpsecTunnelsGetResponseIpsecTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type IpsecTunnelsGetResponseIpsecTunnelCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckRate = "low" | "mid" | "high";
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsGetResponseIpsecTunnelHealthCheckType = "reply" | "request";
export interface IpsecTunnelsGetResponseIpsecTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsGetResponseIpsecTunnelHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsGetResponseIpsecTunnelHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsGetResponseIpsecTunnelHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsGetResponseIpsecTunnelHealthCheckType | null | undefined;
}
export type IpsecTunnelsGetResponseIpsecTunnelPskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export interface IpsecTunnelsGetResponseIpsecTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: IpsecTunnelsGetResponseIpsecTunnelBgp | null | undefined;
    bgpStatus?: IpsecTunnelsGetResponseIpsecTunnelBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null | undefined;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null | undefined;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null | undefined;
    healthCheck?: IpsecTunnelsGetResponseIpsecTunnelHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null | undefined;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetIpsecTunnelResponse {
    ipsecTunnel?: IpsecTunnelsGetResponseIpsecTunnel | null | undefined;
}
export interface GetPcapRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    pcapId: string;
}
export type PcapsGetResultPCAPFilterV1 = PcapsCreateResultPCAPFilterV1;
export type PcapsGetResultPCAPStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export type PcapsGetResultPCAPSystem = "magic-transit";
export type PcapsGetResultPCAPType = "simple" | "full";
export interface PcapsGetResultPCAP {
    /** The ID for the packet capture. */
    id?: string | null | undefined;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null | undefined;
    /** The RFC 3339 offset timestamp from which to query backwards for packets. Must be within the last 24h. When this field is empty, defaults to time of request. */
    offsetTime?: string | null | undefined;
    /** The status of the packet capture request. */
    status?: PcapsGetResultPCAPStatus | null | undefined;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null | undefined;
    /** The system used to collect packet captures. */
    system?: PcapsGetResultPCAPSystem | null | undefined;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null | undefined;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsGetResultPCAPType | null | undefined;
}
export type PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullFilterV1 = PcapsCreateResultPCAPFilterV1;
export type PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export type PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullSystem = "magic-transit";
export type PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullType = "simple" | "full";
export interface PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFull {
    /** The ID for the packet capture. */
    id?: string | null | undefined;
    /** The maximum number of bytes to capture. This field only applies to `full` packet captures. */
    byteLimit?: number | null | undefined;
    /** The name of the data center used for the packet capture. This can be a specific colo (ord02) or a multi-colo name (ORD). This field only applies to `full` packet captures. */
    coloName?: string | null | undefined;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf?: string | null | undefined;
    /** An error message that describes why the packet capture failed. This field only applies to `full` packet captures. */
    errorMessage?: string | null | undefined;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null | undefined;
    /** The number of packets captured. */
    packetsCaptured?: number | null | undefined;
    /** The status of the packet capture request. */
    status?: PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullStatus | null | undefined;
    /** The RFC 3339 timestamp when stopping the packet capture was requested. This field only applies to `full` packet captures. */
    stopRequested?: string | null | undefined;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null | undefined;
    /** The system used to collect packet captures. */
    system?: PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullSystem | null | undefined;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null | undefined;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFullType | null | undefined;
}
export type PcapsGetResult = PcapsGetResultPCAP | PcapsGetResultMagicVisibilityPCAPsPCAPsResponseFull;
export type GetPcapResponse = PcapsGetResult;
export interface GetPcapDownloadRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    pcapId: string;
}
export interface GetPcapDownloadResponse {
}
export interface GetPcapOwnershipRequest {
    /** Identifier. */
    accountId: string;
}
export type PcapsOwnershipGetResultItemStatus = "pending" | "success" | "failed";
export interface PcapsOwnershipGetResultItem {
    /** The bucket ID associated with the packet captures API. */
    id: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
    /** The ownership challenge filename stored in the bucket. */
    filename: string;
    /** The status of the ownership challenge. Can be pending, success or failed. */
    status: PcapsOwnershipGetResultItemStatus;
    /** The RFC 3339 timestamp when the bucket was added to packet captures API. */
    submitted: string;
    /** The RFC 3339 timestamp when the bucket was validated. */
    validated?: string | null | undefined;
}
export type PcapsOwnershipGetResultList = Array<PcapsOwnershipGetResultItem>;
export interface GetPcapOwnershipResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PcapsOwnershipGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface GetRouteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    routeId: string;
}
export type RoutesGetResponseRouteScopeColoNamesList = Array<string>;
export type RoutesGetResponseRouteScopeColoRegionsList = Array<string>;
export interface RoutesGetResponseRouteScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesGetResponseRouteScopeColoNamesList | null | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesGetResponseRouteScopeColoRegionsList | null | undefined;
}
export interface RoutesGetResponseRoute {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null | undefined;
    /** An optional human provided description of the static route. */
    description?: string | null | undefined;
    /** When the route was last modified. */
    modifiedOn?: string | null | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesGetResponseRouteScope | null | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRouteResponse {
    route?: RoutesGetResponseRoute | null | undefined;
}
export interface GetSiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type SitesGetResponseLocation = SitesCreateResponseLocation;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic Connector identifier tag. */
    connectorId?: string | null | undefined;
    description?: string | null | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null | undefined;
    /** The name of the site. */
    name?: string | null | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null | undefined;
}
export interface GetSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    aclId: string;
}
export type SitesAclsGetResponseLan1PortRangesList = Array<string>;
export type SitesAclsGetResponseLan1PortsList = Array<number>;
export type SitesAclsGetResponseLan1SubnetsList = Array<string>;
export interface SitesAclsGetResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsGetResponseLan1PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsGetResponseLan1PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsGetResponseLan1SubnetsList | null | undefined;
}
export type SitesAclsGetResponseLan2PortRangesList = Array<string>;
export type SitesAclsGetResponseLan2PortsList = Array<number>;
export type SitesAclsGetResponseLan2SubnetsList = Array<string>;
export interface SitesAclsGetResponseLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsGetResponseLan2PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsGetResponseLan2PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsGetResponseLan2SubnetsList | null | undefined;
}
export type SitesAclsGetResponseProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsGetResponseProtocolsList = Array<SitesAclsGetResponseProtocolsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteAclResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Description for the ACL. */
    description?: string | null | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null | undefined;
    lan_1?: SitesAclsGetResponseLan1 | null | undefined;
    lan_2?: SitesAclsGetResponseLan2 | null | undefined;
    /** The name of the ACL. */
    name?: string | null | undefined;
    protocols?: SitesAclsGetResponseProtocolsList | null | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null | undefined;
}
export interface GetSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    lanId: string;
}
export type SitesLansGetResponseNat = SitesLansCreateResultItemNat;
export type SitesLansGetResponseRemoteSubnetsItem = SitesLansCreateRequestRemoteSubnetsItem;
export type SitesLansGetResponseRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansGetResponseRoutedSubnetsItemNat = SitesLansCreateResultItemNat;
export type SitesLansGetResponseRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export type SitesLansGetResponseRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansGetResponseStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansGetResponseStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansGetResponseStaticAddressingDhcpRelayServerAddressesList | null | undefined;
}
export type SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansGetResponseStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansGetResponseStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansGetResponseStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansGetResponseStaticAddressingDhcpServerDhcpOptionsList | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | null | undefined;
    dnsServers?: SitesLansGetResponseStaticAddressingDhcpServerDnsServersList | null | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansGetResponseStaticAddressingDhcpServerReservationsMap | null | undefined;
}
export interface SitesLansGetResponseStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansGetResponseStaticAddressingDhcpRelay | null | undefined;
    dhcpServer?: SitesLansGetResponseStaticAddressingDhcpServer | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteLanResponse {
    /** Identifier */
    id?: string | null | undefined;
    bondId?: number | null | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null | undefined;
    name?: string | null | undefined;
    nat?: SitesLansCreateResultItemNat | null | undefined;
    physport?: number | null | undefined;
    remoteSubnets?: SitesLansGetResponseRemoteSubnetsList | null | undefined;
    routedSubnets?: SitesLansGetResponseRoutedSubnetsList | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansGetResponseStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export interface GetSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    wanId: string;
}
export type SitesWansGetResponseHealthCheckRate = "low" | "mid" | "high";
export type SitesWansGetResponseStaticAddressing = SitesWansCreateResultItemStaticAddressing;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteWanResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansGetResponseHealthCheckRate | null | undefined;
    loadBalanceInnerFlows?: boolean | null | undefined;
    name?: string | null | undefined;
    physport?: number | null | undefined;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. */
    provisionedDownloadKbps?: number | null | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. */
    provisionedUploadKbps?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export interface ListAppsRequest {
    /** Identifier */
    accountId: string;
}
export type AppsListResultItemMagicAccountAppHostnamesList = Array<string>;
export type AppsListResultItemMagicAccountAppIpSubnetsList = Array<string>;
export type AppsListResultItemMagicAccountAppSourceSubnetsList = Array<string>;
export interface AppsListResultItemMagicAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsListResultItemMagicAccountAppHostnamesList | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsListResultItemMagicAccountAppIpSubnetsList | null | undefined;
    /** Display name for the app. */
    name?: string | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsListResultItemMagicAccountAppSourceSubnetsList | null | undefined;
    /** Category of the app. */
    type?: string | null | undefined;
}
export type AppsListResultItemMagicManagedAppHostnamesList = Array<string>;
export type AppsListResultItemMagicManagedAppIpSubnetsList = Array<string>;
export type AppsListResultItemMagicManagedAppSourceSubnetsList = Array<string>;
export interface AppsListResultItemMagicManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsListResultItemMagicManagedAppHostnamesList | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsListResultItemMagicManagedAppIpSubnetsList | null | undefined;
    /** Display name for the app. */
    name?: string | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsListResultItemMagicManagedAppSourceSubnetsList | null | undefined;
    /** Category of the app. */
    type?: string | null | undefined;
}
export type AppsListResultItem = AppsListResultItemMagicAccountApp | AppsListResultItemMagicManagedApp;
export type AppsListResultList = Array<AppsListResultItem>;
export interface ListAppsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AppsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListBgpFilterProfilesRequest {
    /** Identifier */
    accountId: string;
}
export type ListBgpFilterProfilesResultItemMatchAction = "allow" | "deny";
export type ListBgpFilterProfilesResultItemTargetsList = Array<string>;
export interface ListBgpFilterProfilesResultItem {
    /** Identifier */
    id: string;
    /** Description of the filter profile */
    description: string;
    /** Action to take when a route matches one of the targets in this profile */
    matchAction: ListBgpFilterProfilesResultItemMatchAction;
    /** Friendly name for the filter profile */
    name: string;
    /** List of CIDR prefixes. Each entry may carry an optional suffix that specifies which prefix lengths to match relative to the prefix length N: '{X,Y}' matches prefix lengths in the inclusive range [X, Y] where N &lt;= X &lt;= Y &lt;= max (max is 32 for IPv4, 128 for IPv6), '{X}' matches exactly length X (equivalent to {X,X}), '+' is shorthand for {N, max} (the prefix and all more-specific subnets, including at length N itself; valid even when N is the maximum length). Omit the suffix to match the prefix exactly at length N. */
    targets: ListBgpFilterProfilesResultItemTargetsList;
    createdOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
}
export type ListBgpFilterProfilesResultList = Array<ListBgpFilterProfilesResultItem>;
export type ListBgpFilterProfilesResponse = ListBgpFilterProfilesResultList;
export interface ListCf1SiteRampsRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
}
export type Cf1SitesRampsListResultItemType = "gre" | "gre_interconnect" | "mpls_interconnect" | "mconn" | "ipsec";
export type Cf1SitesRampsListResultItemGre = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsListResultItemGreInterconnect = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsListResultItemIpsec = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsListResultItemMconn = Cf1SitesRampsCreateResultItemGre;
export type Cf1SitesRampsListResultItemMplsInterconnect = Cf1SitesRampsCreateResultItemGre;
export interface Cf1SitesRampsListResultItem {
    /** Identifier */
    id: string;
    createdOn: string;
    modifiedOn: string;
    /** A human-provided name describing the ramp that should be unique within the CF1 Site. */
    name: string;
    /** The type of network connection (ramp) linking a CF1 Site to Cloudflare's network. */
    type: Cf1SitesRampsListResultItemType;
    /** A human-provided description of the ramp. */
    description?: string | null | undefined;
    gre?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    greInterconnect?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    ipsec?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    mconn?: Cf1SitesRampsCreateResultItemGre | null | undefined;
    mplsInterconnect?: Cf1SitesRampsCreateResultItemGre | null | undefined;
}
export type Cf1SitesRampsListResultList = Array<Cf1SitesRampsListResultItem>;
export interface ListCf1SiteRampsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: Cf1SitesRampsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListCf1SitesRequest {
    /** Identifier */
    accountId: string;
}
export type Cf1SitesListResultItemLocation = Cf1SitesCreateResultItemLocation;
export type Cf1SitesListResultItem = Cf1SitesCreateResultItem;
export type Cf1SitesListResultList = Array<Cf1SitesCreateResultItem>;
export interface ListCf1SitesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: Cf1SitesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListCfInterconnectsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type CfInterconnectsListResponseInterconnectsItemBgpExtraPrefixesList = Array<string>;
export interface CfInterconnectsListResponseInterconnectsItemBgp {
    /** Deprecated. Use customer_asn. */
    asNo?: number | null | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    cloudflareEndpoint?: string | null | undefined;
    /** ASN used on the customer end of the BGP session. */
    customerAsn?: number | null | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    customerEndpoint?: string | null | undefined;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** IPv4 prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. */
    extraPrefixes?: CfInterconnectsListResponseInterconnectsItemBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type CfInterconnectsListResponseInterconnectsItemGre = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre;
export type CfInterconnectsListResponseInterconnectsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export type CfInterconnectsListResponseInterconnectsItemHealthCheckRate = "low" | "mid" | "high";
export type CfInterconnectsListResponseInterconnectsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsListResponseInterconnectsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsListResponseInterconnectsItemHealthCheckType = "reply" | "request";
export interface CfInterconnectsListResponseInterconnectsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the interconnect and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the interconnect. */
    direction?: CfInterconnectsListResponseInterconnectsItemHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsListResponseInterconnectsItemHealthCheckRate | null | undefined;
    /** The source IPv4 address used for bidirectional health checks. Supported only for version 1.5 interconnects. It is required when `direction` is `bidirectional` and must be omitted (and is cleared) when `direction` is `unidirectional`. The address must be within RFC1918 space, the approved link-local range 169.254.240.0/20, or the Cloudflare reserved range 198.41.199.224/27. */
    source?: string | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsListResponseInterconnectsItemHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsListResponseInterconnectsItemHealthCheckType | null | undefined;
}
export interface CfInterconnectsListResponseInterconnectsItem {
    /** Identifier */
    id?: string | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: CfInterconnectsListResponseInterconnectsItemBgp | null | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    coloName?: string | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the interconnect. */
    description?: string | null | undefined;
    /** Omitted in responses for version 1.5 interconnects. */
    gre?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre | null | undefined;
    healthCheck?: CfInterconnectsListResponseInterconnectsItemHealthCheck | null | undefined;
    /** The IPv4 interface address for the interconnect. For MPLS Interconnects, use a /30 or /31 prefix. For GRE Interconnects, a /30 or /31 prefix may be used. Version 1.5 interconnects require a /31 prefix and may also use a prefix from the account's authorized prefixes; otherwise, select the subnet from RFC 1918 or the approved link-local ranges. */
    interfaceAddress?: string | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | null | undefined;
    /** Immutable interconnect version configured at creation time. One of: */
    version?: string | null | undefined;
    /** An identifier that correlates this interconnect with the corresponding V2 CNI interconnect resource. */
    virtualPortReservationId?: string | null | undefined;
}
export type CfInterconnectsListResponseInterconnectsList = Array<CfInterconnectsListResponseInterconnectsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListCfInterconnectsResponse {
    interconnects?: CfInterconnectsListResponseInterconnectsList | null | undefined;
}
export interface ListConnectorEventLatestsRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
}
export type ConnectorsEventsLatestListResponseItemsItemEK = "Init" | "Leave" | "StartAttestation" | "FinishAttestationSuccess" | "FinishAttestationFailure" | "StartRotateCryptKey" | "FinishRotateCryptKeySuccess" | "FinishRotateCryptKeyFailure" | "StartRotatePki" | "FinishRotatePkiSuccess" | "FinishRotatePkiFailure" | "StartUpgrade" | "FinishUpgradeSuccess" | "FinishUpgradeFailure" | "BlessSlotSuccess" | "BlessSlotPending" | "BlessSlotFailure" | "Reconcile" | "ConfigureCloudflaredTunnel" | "RekeyInstallBoth" | "RekeyStart" | "RekeyRestart" | "RekeyAdvance" | "RekeyComplete" | "RekeyReset" | "HaTransition" | "HaError" | "HaInit" | "HaLeave";
export interface ConnectorsEventsLatestListResponseItemsItemE {
    /** Event kind */
    k: ConnectorsEventsLatestListResponseItemsItemEK;
}
export interface ConnectorsEventsLatestListResponseItemsItem {
    /** Event kind plus event-specific payload fields. */
    e: ConnectorsEventsLatestListResponseItemsItemE;
    /** Sequence number, used to order events with the same timestamp */
    n: number;
    /** Time the Event was recorded (seconds since the Unix epoch) */
    t: number;
    /** Version */
    v?: string | null | undefined;
}
export type ConnectorsEventsLatestListResponseItemsList = Array<ConnectorsEventsLatestListResponseItemsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListConnectorEventLatestsResponse {
    count: number;
    items: ConnectorsEventsLatestListResponseItemsList;
}
export interface ListConnectorEventsRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    from: number;
    to: number;
    cursor?: string | undefined;
    /** Filter by event kind */
    k?: string | undefined;
    limit?: number | undefined;
}
export interface ConnectorsEventsListResponseItemsItem {
    /** Time the Event was collected (seconds since the Unix epoch) */
    a: number;
    /** Kind */
    k: string;
    /** Sequence number, used to order events with the same timestamp */
    n: number;
    /** Time the Event was recorded (seconds since the Unix epoch) */
    t: number;
}
export type ConnectorsEventsListResponseItemsList = Array<ConnectorsEventsListResponseItemsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListConnectorEventsResponse {
    count: number;
    items: ConnectorsEventsListResponseItemsList;
    cursor?: string | null | undefined;
}
export type ConnectorsListRequestDeviceType = "MANAGED" | "LICENSED";
export interface ListConnectorsRequest {
    accountId: string;
    /** Filter connectors by device type. */
    deviceType?: ConnectorsListRequestDeviceType | (string & {}) | undefined;
}
export type ConnectorsListResultItemInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsListResultItemInterruptWindowDaysOfWeekList = Array<ConnectorsListResultItemInterruptWindowDaysOfWeekItem>;
export type ConnectorsListResultItemInterruptWindowEmbargoDatesList = Array<string>;
export type ConnectorsListResultItemDeviceType = "MANAGED" | "LICENSED";
export interface ConnectorsListResultItemDevice {
    id: string;
    serialNumber?: string | null | undefined;
    type?: ConnectorsListResultItemDeviceType | null | undefined;
}
export interface ConnectorsListResultItem {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsListResultItemInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsListResultItemInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    timezone: string;
    device?: ConnectorsListResultItemDevice | null | undefined;
    lastHeartbeat?: string | null | undefined;
    lastSeenVersion?: string | null | undefined;
    licenseKey?: string | null | undefined;
}
export type ConnectorsListResultList = Array<ConnectorsListResultItem>;
export interface ListConnectorsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConnectorsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListConnectorsInterruptsRequest {
    accountId: string;
    connectorId: string;
}
export type ListConnectorsInterruptsResultItemReboot = CreateConnectorsInterruptResponseReboot;
export type ListConnectorsInterruptsResultItemRestart = CreateConnectorsInterruptResponseReboot;
export type ListConnectorsInterruptsResultItemShutdown = CreateConnectorsInterruptResponseReboot;
export interface ListConnectorsInterruptsResultItem {
    submittedAt: string;
    reboot?: CreateConnectorsInterruptResponseReboot | null | undefined;
    restart?: CreateConnectorsInterruptResponseReboot | null | undefined;
    shutdown?: CreateConnectorsInterruptResponseReboot | null | undefined;
    triggeredAt?: string | null | undefined;
}
export type ListConnectorsInterruptsResultList = Array<ListConnectorsInterruptsResultItem>;
export type ListConnectorsInterruptsResponse = ListConnectorsInterruptsResultList;
export interface ListConnectorSnapshotLatestsRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
}
export type ConnectorsSnapshotsLatestListResponseItemsItemBondsItem = ConnectorsSnapshotsGetResponseBondsItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemBondsList = Array<ConnectorsSnapshotsGetResponseBondsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesItem = ConnectorsSnapshotsGetResponseDhcpLeasesItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesList = Array<ConnectorsSnapshotsGetResponseDhcpLeasesItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemDisksItem = ConnectorsSnapshotsGetResponseDisksItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemDisksList = Array<ConnectorsSnapshotsGetResponseDisksItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesItem = ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesList = Array<ConnectorsSnapshotsGetResponseInterfacesItemIpAddressesItem>;
export interface ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItem {
    /** Name of the network interface */
    name: string;
    /** UP/DOWN state of the network interface */
    operstate: string;
    /** Comma-separated list of reasons for health score */
    healthReason?: string | null | undefined;
    /** Aggregate health score (0-100) */
    healthScore?: number | null | undefined;
    ipAddresses?: ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItemIpAddressesList | null | undefined;
    /** Speed of the network interface (bits per second) */
    speed?: number | null | undefined;
}
export type ConnectorsSnapshotsLatestListResponseItemsItemInterfacesList = Array<ConnectorsSnapshotsLatestListResponseItemsItemInterfacesItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemMountsItem = ConnectorsSnapshotsGetResponseMountsItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemMountsList = Array<ConnectorsSnapshotsGetResponseMountsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemNetdevsItem = ConnectorsSnapshotsGetResponseNetdevsItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemNetdevsList = Array<ConnectorsSnapshotsGetResponseNetdevsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemRoutesItem = ConnectorsSnapshotsGetResponseRoutesItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemRoutesList = Array<ConnectorsSnapshotsGetResponseRoutesItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemThermalsItem = ConnectorsSnapshotsGetResponseThermalsItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemThermalsList = Array<ConnectorsSnapshotsGetResponseThermalsItem>;
export type ConnectorsSnapshotsLatestListResponseItemsItemTunnelsItem = ConnectorsSnapshotsGetResponseTunnelsItem;
export type ConnectorsSnapshotsLatestListResponseItemsItemTunnelsList = Array<ConnectorsSnapshotsGetResponseTunnelsItem>;
export interface ConnectorsSnapshotsLatestListResponseItemsItem {
    /** Count of failures to reclaim space */
    countReclaimFailures: number;
    /** Count of reclaimed paths */
    countReclaimedPaths: number;
    /** Count of failed snapshot recordings */
    countRecordFailed: number;
    /** Count of failed snapshot transmissions */
    countTransmitFailures: number;
    /** Time the Snapshot was recorded (seconds since the Unix epoch) */
    t: number;
    /** Version */
    v: string;
    bonds?: ConnectorsSnapshotsLatestListResponseItemsItemBondsList | null | undefined;
    /** Count of processors/cores */
    cpuCount?: number | null | undefined;
    /** Percentage of time over a 10 second window that tasks were stalled */
    cpu_pressure_10s?: number | null | undefined;
    /** Percentage of time over a 5 minute window that tasks were stalled */
    cpu_pressure_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that tasks were stalled */
    cpu_pressure_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    cpuPressureTotalUs?: number | null | undefined;
    /** Time spent running a virtual CPU or guest OS (milliseconds) */
    cpuTimeGuestMs?: number | null | undefined;
    /** Time spent running a niced guest (milliseconds) */
    cpuTimeGuestNiceMs?: number | null | undefined;
    /** Time spent in idle state (milliseconds) */
    cpuTimeIdleMs?: number | null | undefined;
    /** Time spent wait for I/O to complete (milliseconds) */
    cpuTimeIowaitMs?: number | null | undefined;
    /** Time spent servicing interrupts (milliseconds) */
    cpuTimeIrqMs?: number | null | undefined;
    /** Time spent in low-priority user mode (milliseconds) */
    cpuTimeNiceMs?: number | null | undefined;
    /** Time spent servicing softirqs (milliseconds) */
    cpuTimeSoftirqMs?: number | null | undefined;
    /** Time stolen (milliseconds) */
    cpuTimeStealMs?: number | null | undefined;
    /** Time spent in system mode (milliseconds) */
    cpuTimeSystemMs?: number | null | undefined;
    /** Time spent in user mode (milliseconds) */
    cpuTimeUserMs?: number | null | undefined;
    /** Number of network operations applied during state transition */
    delta?: number | null | undefined;
    dhcpLeases?: ConnectorsSnapshotsLatestListResponseItemsItemDhcpLeasesList | null | undefined;
    disks?: ConnectorsSnapshotsLatestListResponseItemsItemDisksList | null | undefined;
    /** Simulated number of network operations applied during state transition */
    epsilon?: number | null | undefined;
    /** Name of high availability state */
    haState?: string | null | undefined;
    /** Numeric value associated with high availability state (0 = disabled, 1 = active, 2 = standby, 3 = stopped, 4 = fault) */
    haValue?: number | null | undefined;
    interfaces?: ConnectorsSnapshotsLatestListResponseItemsItemInterfacesList | null | undefined;
    /** Percentage of time over a 10 second window that all tasks were stalled */
    io_pressure_full_10s?: number | null | undefined;
    /** Percentage of time over a 5 minute window that all tasks were stalled */
    io_pressure_full_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that all tasks were stalled */
    io_pressure_full_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    ioPressureFullTotalUs?: number | null | undefined;
    /** Percentage of time over a 10 second window that some tasks were stalled */
    io_pressure_some_10s?: number | null | undefined;
    /** Percentage of time over a 3 minute window that some tasks were stalled */
    io_pressure_some_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that some tasks were stalled */
    io_pressure_some_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    ioPressureSomeTotalUs?: number | null | undefined;
    /** Boot time (seconds since Unix epoch) */
    kernelBtime?: number | null | undefined;
    /** Number of context switches that the system underwent */
    kernelCtxt?: number | null | undefined;
    /** Number of forks since boot */
    kernelProcesses?: number | null | undefined;
    /** Number of processes blocked waiting for I/O */
    kernelProcessesBlocked?: number | null | undefined;
    /** Number of processes in runnable state */
    kernelProcessesRunning?: number | null | undefined;
    /** The fifteen-minute load average */
    load_average_15m?: number | null | undefined;
    /** The one-minute load average */
    load_average_1m?: number | null | undefined;
    /** The five-minute load average */
    load_average_5m?: number | null | undefined;
    /** Number of currently runnable kernel scheduling entities */
    loadAverageCur?: number | null | undefined;
    /** Number of kernel scheduling entities that currently exist on the system */
    loadAverageMax?: number | null | undefined;
    /** Memory that has been used more recently */
    memoryActiveBytes?: number | null | undefined;
    /** Non-file backed huge pages mapped into user-space page tables */
    memoryAnonHugepagesBytes?: number | null | undefined;
    /** Non-file backed pages mapped into user-space page tables */
    memoryAnonPagesBytes?: number | null | undefined;
    /** Estimate of how much memory is available for starting new applications */
    memoryAvailableBytes?: number | null | undefined;
    /** Memory used for block device bounce buffers */
    memoryBounceBytes?: number | null | undefined;
    /** Relatively temporary storage for raw disk blocks */
    memoryBuffersBytes?: number | null | undefined;
    /** In-memory cache for files read from the disk */
    memoryCachedBytes?: number | null | undefined;
    /** Free CMA (Contiguous Memory Allocator) pages */
    memoryCmaFreeBytes?: number | null | undefined;
    /** Total CMA (Contiguous Memory Allocator) pages */
    memoryCmaTotalBytes?: number | null | undefined;
    /** Total amount of memory currently available to be allocated on the system */
    memoryCommitLimitBytes?: number | null | undefined;
    /** Amount of memory presently allocated on the system */
    memoryCommittedAsBytes?: number | null | undefined;
    /** Memory which is waiting to get written back to the disk */
    memoryDirtyBytes?: number | null | undefined;
    /** The sum of LowFree and HighFree */
    memoryFreeBytes?: number | null | undefined;
    /** Amount of free highmem */
    memoryHighFreeBytes?: number | null | undefined;
    /** Total amount of highmem */
    memoryHighTotalBytes?: number | null | undefined;
    /** The number of huge pages in the pool that are not yet allocated */
    memoryHugepagesFree?: number | null | undefined;
    /** Number of huge pages for which a commitment has been made, but no allocation has yet been made */
    memoryHugepagesRsvd?: number | null | undefined;
    /** Number of huge pages in the pool above the threshold */
    memoryHugepagesSurp?: number | null | undefined;
    /** The size of the pool of huge pages */
    memoryHugepagesTotal?: number | null | undefined;
    /** The size of huge pages */
    memoryHugepagesizeBytes?: number | null | undefined;
    /** Memory which has been less recently used */
    memoryInactiveBytes?: number | null | undefined;
    /** Kernel allocations that the kernel will attempt to reclaim under memory pressure */
    memoryKReclaimableBytes?: number | null | undefined;
    /** Amount of memory allocated to kernel stacks */
    memoryKernelStackBytes?: number | null | undefined;
    /** Amount of free lowmem */
    memoryLowFreeBytes?: number | null | undefined;
    /** Total amount of lowmem */
    memoryLowTotalBytes?: number | null | undefined;
    /** Files which have been mapped into memory */
    memoryMappedBytes?: number | null | undefined;
    /** Amount of memory dedicated to the lowest level of page tables */
    memoryPageTablesBytes?: number | null | undefined;
    /** Memory allocated to the per-cpu alloctor used to back per-cpu allocations */
    memoryPerCpuBytes?: number | null | undefined;
    /** Percentage of time over a 10 second window that all tasks were stalled */
    memory_pressure_full_10s?: number | null | undefined;
    /** Percentage of time over a 5 minute window that all tasks were stalled */
    memory_pressure_full_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that all tasks were stalled */
    memory_pressure_full_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    memoryPressureFullTotalUs?: number | null | undefined;
    /** Percentage of time over a 10 second window that some tasks were stalled */
    memory_pressure_some_10s?: number | null | undefined;
    /** Percentage of time over a 5 minute window that some tasks were stalled */
    memory_pressure_some_300s?: number | null | undefined;
    /** Percentage of time over a 1 minute window that some tasks were stalled */
    memory_pressure_some_60s?: number | null | undefined;
    /** Total stall time (microseconds) */
    memoryPressureSomeTotalUs?: number | null | undefined;
    /** Part of slab that can be reclaimed on memory pressure */
    memorySReclaimableBytes?: number | null | undefined;
    /** Part of slab that cannot be reclaimed on memory pressure */
    memorySUnreclaimBytes?: number | null | undefined;
    /** Amount of memory dedicated to the lowest level of page tables */
    memorySecondaryPageTablesBytes?: number | null | undefined;
    /** Amount of memory consumed by tmpfs */
    memoryShmemBytes?: number | null | undefined;
    /** Memory used by shmem and tmpfs, allocated with huge pages */
    memoryShmemHugepagesBytes?: number | null | undefined;
    /** Shared memory mapped into user space with huge pages */
    memoryShmemPmdMappedBytes?: number | null | undefined;
    /** In-kernel data structures cache */
    memorySlabBytes?: number | null | undefined;
    /** Memory swapped out and back in while still in swap file */
    memorySwapCachedBytes?: number | null | undefined;
    /** Amount of swap space that is currently unused */
    memorySwapFreeBytes?: number | null | undefined;
    /** Total amount of swap space available */
    memorySwapTotalBytes?: number | null | undefined;
    /** Total usable RAM */
    memoryTotalBytes?: number | null | undefined;
    /** Largest contiguous block of vmalloc area which is free */
    memoryVmallocChunkBytes?: number | null | undefined;
    /** Total size of vmalloc memory area */
    memoryVmallocTotalBytes?: number | null | undefined;
    /** Amount of vmalloc area which is used */
    memoryVmallocUsedBytes?: number | null | undefined;
    /** Memory which is actively being written back to the disk */
    memoryWritebackBytes?: number | null | undefined;
    /** Memory used by FUSE for temporary writeback buffers */
    memoryWritebackTmpBytes?: number | null | undefined;
    /** Memory consumed by the zswap backend, compressed */
    memoryZSwapBytes?: number | null | undefined;
    /** Amount of anonymous memory stored in zswap, uncompressed */
    memoryZSwappedBytes?: number | null | undefined;
    mounts?: ConnectorsSnapshotsLatestListResponseItemsItemMountsList | null | undefined;
    netdevs?: ConnectorsSnapshotsLatestListResponseItemsItemNetdevsList | null | undefined;
    /** Platform identifier */
    platform?: string | null | undefined;
    routes?: ConnectorsSnapshotsLatestListResponseItemsItemRoutesList | null | undefined;
    /** Site identifier */
    siteId?: string | null | undefined;
    /** Number of ICMP Address Mask Reply messages received */
    snmpIcmpInAddrMaskReps?: number | null | undefined;
    /** Number of ICMP Address Mask Request messages received */
    snmpIcmpInAddrMasks?: number | null | undefined;
    /** Number of ICMP messages received with bad checksums */
    snmpIcmpInCsumErrors?: number | null | undefined;
    /** Number of ICMP Destination Unreachable messages received */
    snmpIcmpInDestUnreachs?: number | null | undefined;
    /** Number of ICMP Echo Reply messages received */
    snmpIcmpInEchoReps?: number | null | undefined;
    /** Number of ICMP Echo (request) messages received */
    snmpIcmpInEchos?: number | null | undefined;
    /** Number of ICMP messages received with ICMP-specific errors */
    snmpIcmpInErrors?: number | null | undefined;
    /** Number of ICMP messages received */
    snmpIcmpInMsgs?: number | null | undefined;
    /** Number of ICMP Parameter Problem messages received */
    snmpIcmpInParmProbs?: number | null | undefined;
    /** Number of ICMP Redirect messages received */
    snmpIcmpInRedirects?: number | null | undefined;
    /** Number of ICMP Source Quench messages received */
    snmpIcmpInSrcQuenchs?: number | null | undefined;
    /** Number of ICMP Time Exceeded messages received */
    snmpIcmpInTimeExcds?: number | null | undefined;
    /** Number of ICMP Address Mask Request messages received */
    snmpIcmpInTimestampReps?: number | null | undefined;
    /** Number of ICMP Timestamp (request) messages received */
    snmpIcmpInTimestamps?: number | null | undefined;
    /** Number of ICMP Address Mask Reply messages sent */
    snmpIcmpOutAddrMaskReps?: number | null | undefined;
    /** Number of ICMP Address Mask Request messages sent */
    snmpIcmpOutAddrMasks?: number | null | undefined;
    /** Number of ICMP Destination Unreachable messages sent */
    snmpIcmpOutDestUnreachs?: number | null | undefined;
    /** Number of ICMP Echo Reply messages sent */
    snmpIcmpOutEchoReps?: number | null | undefined;
    /** Number of ICMP Echo (request) messages sent */
    snmpIcmpOutEchos?: number | null | undefined;
    /** Number of ICMP messages which this entity did not send due to ICMP-specific errors */
    snmpIcmpOutErrors?: number | null | undefined;
    /** Number of ICMP messages attempted to send */
    snmpIcmpOutMsgs?: number | null | undefined;
    /** Number of ICMP Parameter Problem messages sent */
    snmpIcmpOutParmProbs?: number | null | undefined;
    /** Number of ICMP Redirect messages sent */
    snmpIcmpOutRedirects?: number | null | undefined;
    /** Number of ICMP Source Quench messages sent */
    snmpIcmpOutSrcQuenchs?: number | null | undefined;
    /** Number of ICMP Time Exceeded messages sent */
    snmpIcmpOutTimeExcds?: number | null | undefined;
    /** Number of ICMP Timestamp Reply messages sent */
    snmpIcmpOutTimestampReps?: number | null | undefined;
    /** Number of ICMP Timestamp (request) messages sent */
    snmpIcmpOutTimestamps?: number | null | undefined;
    /** Default value of the Time-To-Live field of the IP header */
    snmpIpDefaultTtl?: number | null | undefined;
    /** Number of datagrams forwarded to their final destination */
    snmpIpForwDatagrams?: number | null | undefined;
    /** Set when acting as an IP gateway */
    snmpIpForwardingEnabled?: boolean | null | undefined;
    /** Number of datagrams generated by fragmentation */
    snmpIpFragCreates?: number | null | undefined;
    /** Number of datagrams discarded because fragmentation failed */
    snmpIpFragFails?: number | null | undefined;
    /** Number of datagrams successfully fragmented */
    snmpIpFragOks?: number | null | undefined;
    /** Number of input datagrams discarded due to errors in the IP address */
    snmpIpInAddrErrors?: number | null | undefined;
    /** Number of input datagrams successfully delivered to IP user-protocols */
    snmpIpInDelivers?: number | null | undefined;
    /** Number of input datagrams otherwise discarded */
    snmpIpInDiscards?: number | null | undefined;
    /** Number of input datagrams discarded due to errors in the IP header */
    snmpIpInHdrErrors?: number | null | undefined;
    /** Number of input datagrams received from interfaces */
    snmpIpInReceives?: number | null | undefined;
    /** Number of input datagrams discarded due unknown or unsupported protocol */
    snmpIpInUnknownProtos?: number | null | undefined;
    /** Number of output datagrams otherwise discarded */
    snmpIpOutDiscards?: number | null | undefined;
    /** Number of output datagrams discarded because no route matched */
    snmpIpOutNoRoutes?: number | null | undefined;
    /** Number of datagrams supplied for transmission */
    snmpIpOutRequests?: number | null | undefined;
    /** Number of failures detected by the reassembly algorithm */
    snmpIpReasmFails?: number | null | undefined;
    /** Number of datagrams successfully reassembled */
    snmpIpReasmOks?: number | null | undefined;
    /** Number of fragments received which needed to be reassembled */
    snmpIpReasmReqds?: number | null | undefined;
    /** Number of seconds fragments are held while awaiting reassembly */
    snmpIpReasmTimeout?: number | null | undefined;
    /** Number of times TCP transitions to SYN-SENT from CLOSED */
    snmpTcpActiveOpens?: number | null | undefined;
    /** Number of times TCP transitions to CLOSED from SYN-SENT or SYN-RCVD, plus transitions to LISTEN from SYN-RCVD */
    snmpTcpAttemptFails?: number | null | undefined;
    /** Number of TCP connections in ESTABLISHED or CLOSE-WAIT */
    snmpTcpCurrEstab?: number | null | undefined;
    /** Number of times TCP transitions to CLOSED from ESTABLISHED or CLOSE-WAIT */
    snmpTcpEstabResets?: number | null | undefined;
    /** Number of TCP segments received with checksum errors */
    snmpTcpInCsumErrors?: number | null | undefined;
    /** Number of TCP segments received in error */
    snmpTcpInErrs?: number | null | undefined;
    /** Number of TCP segments received */
    snmpTcpInSegs?: number | null | undefined;
    /** Limit on the total number of TCP connections */
    snmpTcpMaxConn?: number | null | undefined;
    /** Number of TCP segments sent with RST flag */
    snmpTcpOutRsts?: number | null | undefined;
    /** Number of TCP segments sent */
    snmpTcpOutSegs?: number | null | undefined;
    /** Number of times TCP transitions to SYN-RCVD from LISTEN */
    snmpTcpPassiveOpens?: number | null | undefined;
    /** Number of TCP segments retransmitted */
    snmpTcpRetransSegs?: number | null | undefined;
    /** Maximum value permitted by a TCP implementation for the retransmission timeout (milliseconds) */
    snmpTcpRtoMax?: number | null | undefined;
    /** Minimum value permitted by a TCP implementation for the retransmission timeout (milliseconds) */
    snmpTcpRtoMin?: number | null | undefined;
    /** Number of UDP datagrams delivered to UDP applications */
    snmpUdpInDatagrams?: number | null | undefined;
    /** Number of UDP datagrams failed to be delivered for reasons other than lack of application at the destination port */
    snmpUdpInErrors?: number | null | undefined;
    /** Number of UDP datagrams received for which there was not application at the destination port */
    snmpUdpNoPorts?: number | null | undefined;
    /** Number of UDP datagrams sent */
    snmpUdpOutDatagrams?: number | null | undefined;
    /** Boottime of the system (seconds since the Unix epoch) */
    systemBootTimeS?: number | null | undefined;
    thermals?: ConnectorsSnapshotsLatestListResponseItemsItemThermalsList | null | undefined;
    tunnels?: ConnectorsSnapshotsLatestListResponseItemsItemTunnelsList | null | undefined;
    /** Sum of how much time each core has spent idle */
    uptimeIdleMs?: number | null | undefined;
    /** Uptime of the system, including time spent in suspend */
    uptimeTotalMs?: number | null | undefined;
}
export type ConnectorsSnapshotsLatestListResponseItemsList = Array<ConnectorsSnapshotsLatestListResponseItemsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListConnectorSnapshotLatestsResponse {
    count: number;
    items: ConnectorsSnapshotsLatestListResponseItemsList;
}
export interface ListConnectorSnapshotsRequest {
    /** Account identifier */
    accountId: string;
    connectorId: string;
    from: number;
    to: number;
    cursor?: string | undefined;
    limit?: number | undefined;
}
export interface ConnectorsSnapshotsListResponseItemsItem {
    /** Time the Snapshot was collected (seconds since the Unix epoch) */
    a: number;
    /** Time the Snapshot was recorded (seconds since the Unix epoch) */
    t: number;
}
export type ConnectorsSnapshotsListResponseItemsList = Array<ConnectorsSnapshotsListResponseItemsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListConnectorSnapshotsResponse {
    count: number;
    items: ConnectorsSnapshotsListResponseItemsList;
    cursor?: string | null | undefined;
}
export interface ListGreTunnelsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type GreTunnelsListResponseGreTunnelsItemBgpExtraPrefixesList = Array<string>;
export interface GreTunnelsListResponseGreTunnelsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: GreTunnelsListResponseGreTunnelsItemBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type GreTunnelsListResponseGreTunnelsItemBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface GreTunnelsListResponseGreTunnelsItemBgpStatus {
    state: GreTunnelsListResponseGreTunnelsItemBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type GreTunnelsListResponseGreTunnelsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export type GreTunnelsListResponseGreTunnelsItemHealthCheckRate = "low" | "mid" | "high";
export type GreTunnelsListResponseGreTunnelsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsListResponseGreTunnelsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsListResponseGreTunnelsItemHealthCheckType = "reply" | "request";
export interface GreTunnelsListResponseGreTunnelsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsListResponseGreTunnelsItemHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsListResponseGreTunnelsItemHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsListResponseGreTunnelsItemHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsListResponseGreTunnelsItemHealthCheckType | null | undefined;
}
export interface GreTunnelsListResponseGreTunnelsItem {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: GreTunnelsListResponseGreTunnelsItemBgp | null | undefined;
    bgpStatus?: GreTunnelsListResponseGreTunnelsItemBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the GRE tunnel. */
    description?: string | null | undefined;
    healthCheck?: GreTunnelsListResponseGreTunnelsItemHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null | undefined;
}
export type GreTunnelsListResponseGreTunnelsList = Array<GreTunnelsListResponseGreTunnelsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListGreTunnelsResponse {
    greTunnels?: GreTunnelsListResponseGreTunnelsList | null | undefined;
}
export interface ListIpsecTunnelsRequest {
    /** Identifier */
    accountId: string;
    xMagicNewHcTarget?: boolean | undefined;
}
export type IpsecTunnelsListResponseIpsecTunnelsItemBgpExtraPrefixesList = Array<string>;
export interface IpsecTunnelsListResponseIpsecTunnelsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: IpsecTunnelsListResponseIpsecTunnelsItemBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type IpsecTunnelsListResponseIpsecTunnelsItemBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface IpsecTunnelsListResponseIpsecTunnelsItemBgpStatus {
    state: IpsecTunnelsListResponseIpsecTunnelsItemBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type IpsecTunnelsListResponseIpsecTunnelsItemCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckDirection = "unidirectional" | "bidirectional";
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckRate = "low" | "mid" | "high";
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckType = "reply" | "request";
export interface IpsecTunnelsListResponseIpsecTunnelsItemHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheckType | null | undefined;
}
export type IpsecTunnelsListResponseIpsecTunnelsItemPskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export interface IpsecTunnelsListResponseIpsecTunnelsItem {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: IpsecTunnelsListResponseIpsecTunnelsItemBgp | null | undefined;
    bgpStatus?: IpsecTunnelsListResponseIpsecTunnelsItemBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null | undefined;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null | undefined;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null | undefined;
    healthCheck?: IpsecTunnelsListResponseIpsecTunnelsItemHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null | undefined;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null | undefined;
}
export type IpsecTunnelsListResponseIpsecTunnelsList = Array<IpsecTunnelsListResponseIpsecTunnelsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListIpsecTunnelsResponse {
    ipsecTunnels?: IpsecTunnelsListResponseIpsecTunnelsList | null | undefined;
}
export interface ListPcapsRequest {
    /** Identifier. */
    accountId: string;
}
export type PcapsListResultItemPCAPFilterV1 = PcapsCreateResultPCAPFilterV1;
export type PcapsListResultItemPCAPStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export type PcapsListResultItemPCAPSystem = "magic-transit";
export type PcapsListResultItemPCAPType = "simple" | "full";
export interface PcapsListResultItemPCAP {
    /** The ID for the packet capture. */
    id?: string | null | undefined;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null | undefined;
    /** The RFC 3339 offset timestamp from which to query backwards for packets. Must be within the last 24h. When this field is empty, defaults to time of request. */
    offsetTime?: string | null | undefined;
    /** The status of the packet capture request. */
    status?: PcapsListResultItemPCAPStatus | null | undefined;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null | undefined;
    /** The system used to collect packet captures. */
    system?: PcapsListResultItemPCAPSystem | null | undefined;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null | undefined;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsListResultItemPCAPType | null | undefined;
}
export type PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullFilterV1 = PcapsCreateResultPCAPFilterV1;
export type PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullStatus = "unknown" | "success" | "pending" | "running" | "conversion_pending" | "conversion_running" | "complete" | "failed";
export type PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullSystem = "magic-transit";
export type PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullType = "simple" | "full";
export interface PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFull {
    /** The ID for the packet capture. */
    id?: string | null | undefined;
    /** The maximum number of bytes to capture. This field only applies to `full` packet captures. */
    byteLimit?: number | null | undefined;
    /** The name of the data center used for the packet capture. This can be a specific colo (ord02) or a multi-colo name (ORD). This field only applies to `full` packet captures. */
    coloName?: string | null | undefined;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf?: string | null | undefined;
    /** An error message that describes why the packet capture failed. This field only applies to `full` packet captures. */
    errorMessage?: string | null | undefined;
    /** The packet capture filter. When this field is empty, all packets are captured. */
    filterV1?: PcapsCreateResultPCAPFilterV1 | null | undefined;
    /** The number of packets captured. */
    packetsCaptured?: number | null | undefined;
    /** The status of the packet capture request. */
    status?: PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullStatus | null | undefined;
    /** The RFC 3339 timestamp when stopping the packet capture was requested. This field only applies to `full` packet captures. */
    stopRequested?: string | null | undefined;
    /** The RFC 3339 timestamp when the packet capture was created. */
    submitted?: string | null | undefined;
    /** The system used to collect packet captures. */
    system?: PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullSystem | null | undefined;
    /** The packet capture duration in seconds. */
    timeLimit?: number | null | undefined;
    /** The type of packet capture. `Simple` captures sampled packets, and `full` captures entire payloads and non-sampled packets. */
    type?: PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFullType | null | undefined;
}
export type PcapsListResultItem = PcapsListResultItemPCAP | PcapsListResultItemMagicVisibilityPCAPsPCAPsResponseFull;
export type PcapsListResultList = Array<PcapsListResultItem>;
export interface ListPcapsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PcapsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListRoutesRequest {
    /** Identifier */
    accountId: string;
}
export type RoutesListResponseRoutesItemScopeColoNamesList = Array<string>;
export type RoutesListResponseRoutesItemScopeColoRegionsList = Array<string>;
export interface RoutesListResponseRoutesItemScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesListResponseRoutesItemScopeColoNamesList | null | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesListResponseRoutesItemScopeColoRegionsList | null | undefined;
}
export interface RoutesListResponseRoutesItem {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null | undefined;
    /** An optional human provided description of the static route. */
    description?: string | null | undefined;
    /** When the route was last modified. */
    modifiedOn?: string | null | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesListResponseRoutesItemScope | null | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null | undefined;
}
export type RoutesListResponseRoutesList = Array<RoutesListResponseRoutesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListRoutesResponse {
    routes?: RoutesListResponseRoutesList | null | undefined;
}
export interface ListSiteAclsRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export type SitesAclsListResultItemLan1PortRangesList = Array<string>;
export type SitesAclsListResultItemLan1PortsList = Array<number>;
export type SitesAclsListResultItemLan1SubnetsList = Array<string>;
export interface SitesAclsListResultItemLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsListResultItemLan1PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsListResultItemLan1PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsListResultItemLan1SubnetsList | null | undefined;
}
export type SitesAclsListResultItemLan2PortRangesList = Array<string>;
export type SitesAclsListResultItemLan2PortsList = Array<number>;
export type SitesAclsListResultItemLan2SubnetsList = Array<string>;
export interface SitesAclsListResultItemLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsListResultItemLan2PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsListResultItemLan2PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsListResultItemLan2SubnetsList | null | undefined;
}
export type SitesAclsListResultItemProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsListResultItemProtocolsList = Array<SitesAclsListResultItemProtocolsItem>;
export interface SitesAclsListResultItem {
    /** Identifier */
    id?: string | null | undefined;
    /** Description for the ACL. */
    description?: string | null | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null | undefined;
    lan_1?: SitesAclsListResultItemLan1 | null | undefined;
    lan_2?: SitesAclsListResultItemLan2 | null | undefined;
    /** The name of the ACL. */
    name?: string | null | undefined;
    protocols?: SitesAclsListResultItemProtocolsList | null | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null | undefined;
}
export type SitesAclsListResultList = Array<SitesAclsListResultItem>;
export interface ListSiteAclsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesAclsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListSiteLansRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export type SitesLansListResultItemNat = SitesLansCreateResultItemNat;
export type SitesLansListResultItemRemoteSubnetsItem = SitesLansCreateRequestRemoteSubnetsItem;
export type SitesLansListResultItemRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansListResultItemRoutedSubnetsItemNat = SitesLansCreateResultItemNat;
export type SitesLansListResultItemRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export type SitesLansListResultItemRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansListResultItemStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansListResultItemStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansListResultItemStaticAddressingDhcpRelayServerAddressesList | null | undefined;
}
export type SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansListResultItemStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansListResultItemStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansListResultItemStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansListResultItemStaticAddressingDhcpServerDhcpOptionsList | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | null | undefined;
    dnsServers?: SitesLansListResultItemStaticAddressingDhcpServerDnsServersList | null | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansListResultItemStaticAddressingDhcpServerReservationsMap | null | undefined;
}
export interface SitesLansListResultItemStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansListResultItemStaticAddressingDhcpRelay | null | undefined;
    dhcpServer?: SitesLansListResultItemStaticAddressingDhcpServer | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null | undefined;
}
export interface SitesLansListResultItem {
    /** Identifier */
    id?: string | null | undefined;
    bondId?: number | null | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null | undefined;
    name?: string | null | undefined;
    nat?: SitesLansCreateResultItemNat | null | undefined;
    physport?: number | null | undefined;
    remoteSubnets?: SitesLansListResultItemRemoteSubnetsList | null | undefined;
    routedSubnets?: SitesLansListResultItemRoutedSubnetsList | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansListResultItemStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export type SitesLansListResultList = Array<SitesLansListResultItem>;
export interface ListSiteLansResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesLansListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListSitesRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    connectorid?: string | undefined;
}
export type SitesListResultItemLocation = SitesCreateResponseLocation;
export interface SitesListResultItem {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic Connector identifier tag. */
    connectorId?: string | null | undefined;
    description?: string | null | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null | undefined;
    /** The name of the site. */
    name?: string | null | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null | undefined;
}
export type SitesListResultList = Array<SitesListResultItem>;
export interface ListSitesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export type ListSitesAppConfigurationResultItemAccountAppPreferredWansList = Array<string>;
export interface ListSitesAppConfigurationResultItemAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: ListSitesAppConfigurationResultItemAccountAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type ListSitesAppConfigurationResultItemManagedAppPreferredWansList = Array<string>;
export interface ListSitesAppConfigurationResultItemManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: ListSitesAppConfigurationResultItemManagedAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type ListSitesAppConfigurationResultItem = ListSitesAppConfigurationResultItemAccountApp | ListSitesAppConfigurationResultItemManagedApp;
export type ListSitesAppConfigurationResultList = Array<ListSitesAppConfigurationResultItem>;
export type ListSitesAppConfigurationResponse = ListSitesAppConfigurationResultList;
export interface ListSiteWansRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
}
export type SitesWansListResultItemHealthCheckRate = "low" | "mid" | "high";
export type SitesWansListResultItemStaticAddressing = SitesWansCreateResultItemStaticAddressing;
export interface SitesWansListResultItem {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansListResultItemHealthCheckRate | null | undefined;
    loadBalanceInnerFlows?: boolean | null | undefined;
    name?: string | null | undefined;
    physport?: number | null | undefined;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. */
    provisionedDownloadKbps?: number | null | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. */
    provisionedUploadKbps?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export type SitesWansListResultList = Array<SitesWansListResultItem>;
export interface ListSiteWansResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SitesWansListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type AppsEditRequestHostnamesList = Array<string>;
export type AppsEditRequestIpSubnetsList = Array<string>;
export type AppsEditRequestSourceSubnetsList = Array<string>;
export interface PatchAppRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsEditRequestHostnamesList | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsEditRequestIpSubnetsList | undefined;
    /** Display name for the app. */
    name?: string | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsEditRequestSourceSubnetsList | undefined;
    /** Category of the app. */
    type?: string | undefined;
}
export type AppsEditResponseHostnamesList = Array<string>;
export type AppsEditResponseIpSubnetsList = Array<string>;
export type AppsEditResponseSourceSubnetsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAppResponse {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsEditResponseHostnamesList | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsEditResponseIpSubnetsList | null | undefined;
    /** Display name for the app. */
    name?: string | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsEditResponseSourceSubnetsList | null | undefined;
    /** Category of the app. */
    type?: string | null | undefined;
}
export type Cf1SitesUpdateRequestLocation = Cf1SitesCreateRequestBodyItemLocation;
export interface PatchCf1SiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cf1SiteId: string;
    /** A human-provided description of the CF1 Site. */
    description?: string | undefined;
    location?: Cf1SitesCreateRequestBodyItemLocation | undefined;
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name?: string | undefined;
}
export type Cf1SitesUpdateResponseLocation = Cf1SitesCreateResultItemLocation;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCf1SiteResponse {
    /** A human-provided name describing the CF1 Site that should be unique within the account. */
    name: string;
    /** Identifier */
    id?: string | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-provided description of the CF1 Site. */
    description?: string | null | undefined;
    location?: Cf1SitesCreateResultItemLocation | null | undefined;
    modifiedOn?: string | null | undefined;
}
export type ConnectorsEditRequestInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsEditRequestInterruptWindowDaysOfWeekList = Array<ConnectorsEditRequestInterruptWindowDaysOfWeekItem | (string & {})>;
export type ConnectorsEditRequestInterruptWindowEmbargoDatesList = Array<string>;
export interface PatchConnectorRequest {
    accountId: string;
    connectorId: string;
    activated?: boolean | undefined;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek?: ConnectorsEditRequestInterruptWindowDaysOfWeekList | undefined;
    interruptWindowDurationHours?: number | undefined;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates?: ConnectorsEditRequestInterruptWindowEmbargoDatesList | undefined;
    interruptWindowHourOfDay?: number | undefined;
    notes?: string | undefined;
    /** When true, regenerate license key for the connector. */
    provisionLicense?: boolean | undefined;
    timezone?: string | undefined;
}
export type ConnectorsEditResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsEditResponseInterruptWindowDaysOfWeekList = Array<ConnectorsEditResponseInterruptWindowDaysOfWeekItem>;
export type ConnectorsEditResponseInterruptWindowEmbargoDatesList = Array<string>;
export type ConnectorsEditResponseDeviceType = "MANAGED" | "LICENSED";
export interface ConnectorsEditResponseDevice {
    id: string;
    serialNumber?: string | null | undefined;
    type?: ConnectorsEditResponseDeviceType | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsEditResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsEditResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    timezone: string;
    device?: ConnectorsEditResponseDevice | null | undefined;
    lastHeartbeat?: string | null | undefined;
    lastSeenVersion?: string | null | undefined;
    licenseKey?: string | null | undefined;
}
export type SitesEditRequestLocation = SitesCreateRequestLocation;
export interface PatchSiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Magic Connector identifier tag. */
    connectorId?: string | undefined;
    description?: string | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateRequestLocation | undefined;
    /** The name of the site. */
    name?: string | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | undefined;
}
export type SitesEditResponseLocation = SitesCreateResponseLocation;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSiteResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic Connector identifier tag. */
    connectorId?: string | null | undefined;
    description?: string | null | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null | undefined;
    /** The name of the site. */
    name?: string | null | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null | undefined;
}
export type SitesAclsEditRequestLan1PortRangesList = Array<string>;
export type SitesAclsEditRequestLan1PortsList = Array<number>;
export type SitesAclsEditRequestLan1SubnetsList = Array<string>;
export interface SitesAclsEditRequestLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsEditRequestLan1PortRangesList | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsEditRequestLan1PortsList | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsEditRequestLan1SubnetsList | undefined;
}
export type SitesAclsEditRequestLan2PortRangesList = Array<string>;
export type SitesAclsEditRequestLan2PortsList = Array<number>;
export type SitesAclsEditRequestLan2SubnetsList = Array<string>;
export interface SitesAclsEditRequestLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsEditRequestLan2PortRangesList | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsEditRequestLan2PortsList | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsEditRequestLan2SubnetsList | undefined;
}
export type SitesAclsEditRequestProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsEditRequestProtocolsList = Array<SitesAclsEditRequestProtocolsItem | (string & {})>;
export interface PatchSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    aclId: string;
    /** Description for the ACL. */
    description?: string | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | undefined;
    lan_1?: SitesAclsEditRequestLan1 | undefined;
    lan_2?: SitesAclsEditRequestLan2 | undefined;
    /** The name of the ACL. */
    name?: string | undefined;
    protocols?: SitesAclsEditRequestProtocolsList | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | undefined;
}
export type SitesAclsEditResponseLan1PortRangesList = Array<string>;
export type SitesAclsEditResponseLan1PortsList = Array<number>;
export type SitesAclsEditResponseLan1SubnetsList = Array<string>;
export interface SitesAclsEditResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsEditResponseLan1PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsEditResponseLan1PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsEditResponseLan1SubnetsList | null | undefined;
}
export type SitesAclsEditResponseLan2PortRangesList = Array<string>;
export type SitesAclsEditResponseLan2PortsList = Array<number>;
export type SitesAclsEditResponseLan2SubnetsList = Array<string>;
export interface SitesAclsEditResponseLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsEditResponseLan2PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsEditResponseLan2PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsEditResponseLan2SubnetsList | null | undefined;
}
export type SitesAclsEditResponseProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsEditResponseProtocolsList = Array<SitesAclsEditResponseProtocolsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSiteAclResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Description for the ACL. */
    description?: string | null | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null | undefined;
    lan_1?: SitesAclsEditResponseLan1 | null | undefined;
    lan_2?: SitesAclsEditResponseLan2 | null | undefined;
    /** The name of the ACL. */
    name?: string | null | undefined;
    protocols?: SitesAclsEditResponseProtocolsList | null | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null | undefined;
}
export type SitesLansEditRequestNat = SitesLansCreateRequestNat;
export type SitesLansEditRequestRemoteSubnetsItem = SitesLansCreateRequestRemoteSubnetsItem;
export type SitesLansEditRequestRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansEditRequestRoutedSubnetsItemNat = SitesLansCreateRequestNat;
export type SitesLansEditRequestRoutedSubnetsItem = SitesLansCreateRequestRoutedSubnetsItem;
export type SitesLansEditRequestRoutedSubnetsList = Array<SitesLansCreateRequestRoutedSubnetsItem>;
export type SitesLansEditRequestStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansEditRequestStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansEditRequestStaticAddressingDhcpRelayServerAddressesList | undefined;
}
export type SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItemType | (string & {});
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansEditRequestStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansEditRequestStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansEditRequestStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansEditRequestStaticAddressingDhcpServerDhcpOptionsList | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | undefined;
    dnsServers?: SitesLansEditRequestStaticAddressingDhcpServerDnsServersList | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansEditRequestStaticAddressingDhcpServerReservationsMap | undefined;
}
export interface SitesLansEditRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansEditRequestStaticAddressingDhcpRelay | undefined;
    dhcpServer?: SitesLansEditRequestStaticAddressingDhcpServer | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | undefined;
}
export interface PatchSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    lanId: string;
    bondId?: number | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | undefined;
    name?: string | undefined;
    nat?: SitesLansCreateRequestNat | undefined;
    physport?: number | undefined;
    remoteSubnets?: SitesLansEditRequestRemoteSubnetsList | undefined;
    routedSubnets?: SitesLansEditRequestRoutedSubnetsList | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansEditRequestStaticAddressing | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | undefined;
}
export type SitesLansEditResponseNat = SitesLansCreateResultItemNat;
export type SitesLansEditResponseRemoteSubnetsItem = SitesLansCreateRequestRemoteSubnetsItem;
export type SitesLansEditResponseRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansEditResponseRoutedSubnetsItemNat = SitesLansCreateResultItemNat;
export type SitesLansEditResponseRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export type SitesLansEditResponseRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansEditResponseStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansEditResponseStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansEditResponseStaticAddressingDhcpRelayServerAddressesList | null | undefined;
}
export type SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansEditResponseStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansEditResponseStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansEditResponseStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansEditResponseStaticAddressingDhcpServerDhcpOptionsList | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | null | undefined;
    dnsServers?: SitesLansEditResponseStaticAddressingDhcpServerDnsServersList | null | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansEditResponseStaticAddressingDhcpServerReservationsMap | null | undefined;
}
export interface SitesLansEditResponseStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansEditResponseStaticAddressingDhcpRelay | null | undefined;
    dhcpServer?: SitesLansEditResponseStaticAddressingDhcpServer | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSiteLanResponse {
    /** Identifier */
    id?: string | null | undefined;
    bondId?: number | null | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null | undefined;
    name?: string | null | undefined;
    nat?: SitesLansCreateResultItemNat | null | undefined;
    physport?: number | null | undefined;
    remoteSubnets?: SitesLansEditResponseRemoteSubnetsList | null | undefined;
    routedSubnets?: SitesLansEditResponseRoutedSubnetsList | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansEditResponseStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export type SitesWansEditRequestHealthCheckRate = "low" | "mid" | "high";
export interface SitesWansEditRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address?: string | undefined;
    /** A valid IPv4 address. */
    gatewayAddress?: string | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | undefined;
    /** Gateway address for the secondary connector of a high availability site. Set to null to remove it. */
    secondaryGatewayAddress?: string | undefined;
}
export interface PatchSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    wanId: string;
    /** Magic WAN health check rate for tunnels created on this link. */
    healthCheckRate?: SitesWansEditRequestHealthCheckRate | (string & {}) | undefined;
    loadBalanceInnerFlows?: boolean | undefined;
    name?: string | undefined;
    physport?: number | undefined;
    priority?: number | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. Set to null to remove it. */
    provisionedDownloadKbps?: number | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. Set to null to remove it. */
    provisionedUploadKbps?: number | undefined;
    /** Static addressing configuration. PATCH updates only the fields provided, and PUT replaces the configuration. */
    staticAddressing?: SitesWansEditRequestStaticAddressing | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | undefined;
}
export type SitesWansEditResponseHealthCheckRate = "low" | "mid" | "high";
export type SitesWansEditResponseStaticAddressing = SitesWansCreateResultItemStaticAddressing;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSiteWanResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansEditResponseHealthCheckRate | null | undefined;
    loadBalanceInnerFlows?: boolean | null | undefined;
    name?: string | null | undefined;
    physport?: number | null | undefined;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. */
    provisionedDownloadKbps?: number | null | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. */
    provisionedUploadKbps?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export interface PskGenerateIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    ipsecTunnelId: string;
}
export type IpsecTunnelsPskGenerateResponsePskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PskGenerateIpsecTunnelResponse {
    /** Identifier */
    ipsecTunnelId?: string | null | undefined;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk?: string | null | undefined;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null | undefined;
}
export interface IpsecTunnelsPskSetRequestPsksItem {
    /** The ID of the IPsec tunnel. */
    id: string;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk: string;
}
export type IpsecTunnelsPskSetRequestPsksList = Array<IpsecTunnelsPskSetRequestPsksItem>;
export interface PskSetIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** If `true`, only run validation without persisting changes. */
    validateOnly?: boolean | undefined;
    /** List of tunnel ID and PSK pairs. */
    psks: IpsecTunnelsPskSetRequestPsksList;
}
export type IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValuePskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export interface IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValue {
    /** The IKE identifier used for this tunnel on the Cloudflare edge. */
    ipsecId: string;
    /** Identifier */
    ipsecTunnelId: string;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk: string;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
}
export type IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksMap = {
    [key: string]: IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksValue | undefined;
};
export type IpsecTunnelsPskSetResponseUnappliedPsksMap = {
    [key: string]: string | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PskSetIpsecTunnelResponse {
    /** Map of tunnel IDs to successfully applied PSK details. */
    successfullyAppliedPsks?: IpsecTunnelsPskSetResponseSuccessfullyAppliedPsksMap | null | undefined;
    /** Map of tunnel IDs to failure reasons for PSKs that could not be applied. */
    unappliedPsks?: IpsecTunnelsPskSetResponseUnappliedPsksMap | null | undefined;
}
export type CfInterconnectsUpdateRequestBgpExtraPrefixesList = Array<string>;
export interface CfInterconnectsUpdateRequestBgp {
    /** Deprecated. Use customer_asn. */
    asNo?: number | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    cloudflareEndpoint?: string | undefined;
    /** ASN used on the customer end of the BGP session. */
    customerAsn?: number | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    customerEndpoint?: string | undefined;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | undefined;
    /** IPv4 prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. */
    extraPrefixes?: CfInterconnectsUpdateRequestBgpExtraPrefixesList | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | undefined;
}
export interface CfInterconnectsUpdateRequestGre {
    /** The IP address assigned to the Cloudflare side of the GRE tunnel created as part of the Interconnect. */
    cloudflareEndpoint?: string | undefined;
}
export type CfInterconnectsUpdateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export type CfInterconnectsUpdateRequestHealthCheckRate = "low" | "mid" | "high";
export type CfInterconnectsUpdateRequestHealthCheckTargetMagicHealthCheckTarget = GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsUpdateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsUpdateRequestHealthCheckType = "reply" | "request";
export interface CfInterconnectsUpdateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the interconnect and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the interconnect. */
    direction?: CfInterconnectsUpdateRequestHealthCheckDirection | (string & {}) | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsUpdateRequestHealthCheckRate | (string & {}) | undefined;
    /** The source IPv4 address used for bidirectional health checks. Supported only for version 1.5 interconnects. It is required when `direction` is `bidirectional` and must be omitted (and is cleared) when `direction` is `unidirectional`. The address must be within RFC1918 space, the approved link-local range 169.254.240.0/20, or the Cloudflare reserved range 198.41.199.224/27. */
    source?: string | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsUpdateRequestHealthCheckTarget | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsUpdateRequestHealthCheckType | (string & {}) | undefined;
}
export interface PutCfInterconnectRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    cfInterconnectId: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | undefined;
    bgp?: CfInterconnectsUpdateRequestBgp | undefined;
    /** An optional description of the interconnect. */
    description?: string | undefined;
    /** Not configurable for version 1.5 interconnects; supplying it returns an error. */
    gre?: CfInterconnectsUpdateRequestGre | undefined;
    healthCheck?: CfInterconnectsUpdateRequestHealthCheck | undefined;
    /** The IPv4 interface address for the interconnect. For MPLS Interconnects, use a /30 or /31 prefix. For GRE Interconnects, a /30 or /31 prefix may be used. Version 1.5 interconnects require a /31 prefix and may also use a prefix from the account's authorized prefixes; otherwise, select the subnet from RFC 1918 or the approved link-local ranges. */
    interfaceAddress?: string | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | undefined;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | undefined;
    xMagicNewHcTarget?: boolean | undefined;
}
export type CfInterconnectsUpdateResponseModifiedInterconnectBgpExtraPrefixesList = Array<string>;
export interface CfInterconnectsUpdateResponseModifiedInterconnectBgp {
    /** Deprecated. Use customer_asn. */
    asNo?: number | null | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    cloudflareEndpoint?: string | null | undefined;
    /** ASN used on the customer end of the BGP session. */
    customerAsn?: number | null | undefined;
    /** Read-only for v1.5; derived from interface_address. */
    customerEndpoint?: string | null | undefined;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** IPv4 prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. */
    extraPrefixes?: CfInterconnectsUpdateResponseModifiedInterconnectBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type CfInterconnectsUpdateResponseModifiedInterconnectGre = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre;
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckDirection = "unidirectional" | "bidirectional";
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckRate = "low" | "mid" | "high";
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckType = "reply" | "request";
export interface CfInterconnectsUpdateResponseModifiedInterconnectHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the interconnect and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the interconnect. */
    direction?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckRate | null | undefined;
    /** The source IPv4 address used for bidirectional health checks. Supported only for version 1.5 interconnects. It is required when `direction` is `bidirectional` and must be omitted (and is cleared) when `direction` is `unidirectional`. The address must be within RFC1918 space, the approved link-local range 169.254.240.0/20, or the Cloudflare reserved range 198.41.199.224/27. */
    source?: string | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheckType | null | undefined;
}
export interface CfInterconnectsUpdateResponseModifiedInterconnect {
    /** Identifier */
    id?: string | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: CfInterconnectsUpdateResponseModifiedInterconnectBgp | null | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    coloName?: string | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the interconnect. */
    description?: string | null | undefined;
    /** Omitted in responses for version 1.5 interconnects. */
    gre?: CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemGre | null | undefined;
    healthCheck?: CfInterconnectsUpdateResponseModifiedInterconnectHealthCheck | null | undefined;
    /** The IPv4 interface address for the interconnect. For MPLS Interconnects, use a /30 or /31 prefix. For GRE Interconnects, a /30 or /31 prefix may be used. Version 1.5 interconnects require a /31 prefix and may also use a prefix from the account's authorized prefixes; otherwise, select the subnet from RFC 1918 or the approved link-local ranges. */
    interfaceAddress?: string | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The Maximum Transmission Unit (MTU) in bytes for the interconnect. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** The name of the interconnect. The name cannot share a name with other tunnels. */
    name?: string | null | undefined;
    /** Immutable interconnect version configured at creation time. One of: */
    version?: string | null | undefined;
    /** An identifier that correlates this interconnect with the corresponding V2 CNI interconnect resource. */
    virtualPortReservationId?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutCfInterconnectResponse {
    modified?: boolean | null | undefined;
    modifiedInterconnect?: CfInterconnectsUpdateResponseModifiedInterconnect | null | undefined;
}
export interface StopPcapRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    pcapId: string;
}
export interface StopPcapResponse {
}
export type AppsUpdateRequestHostnamesList = Array<string>;
export type AppsUpdateRequestIpSubnetsList = Array<string>;
export type AppsUpdateRequestSourceSubnetsList = Array<string>;
export interface UpdateAppRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsUpdateRequestHostnamesList | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsUpdateRequestIpSubnetsList | undefined;
    /** Display name for the app. */
    name?: string | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsUpdateRequestSourceSubnetsList | undefined;
    /** Category of the app. */
    type?: string | undefined;
}
export type AppsUpdateResponseHostnamesList = Array<string>;
export type AppsUpdateResponseIpSubnetsList = Array<string>;
export type AppsUpdateResponseSourceSubnetsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAppResponse {
    /** Magic account app ID. */
    accountAppId: string;
    /** FQDNs to associate with traffic decisions. */
    hostnames?: AppsUpdateResponseHostnamesList | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    ipSubnets?: AppsUpdateResponseIpSubnetsList | null | undefined;
    /** Display name for the app. */
    name?: string | null | undefined;
    /** IPv4 CIDRs to associate with traffic decisions. (IPv6 CIDRs are currently unsupported) */
    sourceSubnets?: AppsUpdateResponseSourceSubnetsList | null | undefined;
    /** Category of the app. */
    type?: string | null | undefined;
}
export type UpdateBgpFilterProfileRequestMatchAction = "allow" | "deny";
export type UpdateBgpFilterProfileRequestTargetsList = Array<string>;
export interface UpdateBgpFilterProfileRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    profileId: string;
    /** Description of the filter profile */
    description?: string | undefined;
    /** Action to take when a route matches one of the targets in this profile */
    matchAction?: UpdateBgpFilterProfileRequestMatchAction | (string & {}) | undefined;
    /** Friendly name for the filter profile */
    name?: string | undefined;
    /** List of CIDR prefixes. Each entry may carry an optional suffix that specifies which prefix lengths to match relative to the prefix length N: '{X,Y}' matches prefix lengths in the inclusive range [X, Y] where N <= X <= Y <= max (max is 32 for IPv4, 128 for IPv6), '{X}' matches exactly length X (equivalent to {X,X}), '+' is shorthand for {N, max} (the prefix and all more-specific subnets, including at length N itself; valid even when N is the maximum length). Omit the suffix to match the prefix exactly at length N. */
    targets?: UpdateBgpFilterProfileRequestTargetsList | undefined;
}
export type UpdateBgpFilterProfileResponseMatchAction = "allow" | "deny";
export type UpdateBgpFilterProfileResponseTargetsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateBgpFilterProfileResponse {
    /** Identifier */
    id: string;
    /** Description of the filter profile */
    description: string;
    /** Action to take when a route matches one of the targets in this profile */
    matchAction: UpdateBgpFilterProfileResponseMatchAction;
    /** Friendly name for the filter profile */
    name: string;
    /** List of CIDR prefixes. Each entry may carry an optional suffix that specifies which prefix lengths to match relative to the prefix length N: '{X,Y}' matches prefix lengths in the inclusive range [X, Y] where N &lt;= X &lt;= Y &lt;= max (max is 32 for IPv4, 128 for IPv6), '{X}' matches exactly length X (equivalent to {X,X}), '+' is shorthand for {N, max} (the prefix and all more-specific subnets, including at length N itself; valid even when N is the maximum length). Omit the suffix to match the prefix exactly at length N. */
    targets: UpdateBgpFilterProfileResponseTargetsList;
    createdOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
}
export type ConnectorsUpdateRequestInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsUpdateRequestInterruptWindowDaysOfWeekList = Array<ConnectorsUpdateRequestInterruptWindowDaysOfWeekItem | (string & {})>;
export type ConnectorsUpdateRequestInterruptWindowEmbargoDatesList = Array<string>;
export interface UpdateConnectorRequest {
    accountId: string;
    connectorId: string;
    activated?: boolean | undefined;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek?: ConnectorsUpdateRequestInterruptWindowDaysOfWeekList | undefined;
    interruptWindowDurationHours?: number | undefined;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates?: ConnectorsUpdateRequestInterruptWindowEmbargoDatesList | undefined;
    interruptWindowHourOfDay?: number | undefined;
    notes?: string | undefined;
    /** When true, regenerate license key for the connector. */
    provisionLicense?: boolean | undefined;
    timezone?: string | undefined;
}
export type ConnectorsUpdateResponseInterruptWindowDaysOfWeekItem = "Sunday" | "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
export type ConnectorsUpdateResponseInterruptWindowDaysOfWeekList = Array<ConnectorsUpdateResponseInterruptWindowDaysOfWeekItem>;
export type ConnectorsUpdateResponseInterruptWindowEmbargoDatesList = Array<string>;
export type ConnectorsUpdateResponseDeviceType = "MANAGED" | "LICENSED";
export interface ConnectorsUpdateResponseDevice {
    id: string;
    serialNumber?: string | null | undefined;
    type?: ConnectorsUpdateResponseDeviceType | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateConnectorResponse {
    id: string;
    activated: boolean;
    /** Allowed days of the week for upgrades. Default is all days. */
    interruptWindowDaysOfWeek: ConnectorsUpdateResponseInterruptWindowDaysOfWeekList;
    interruptWindowDurationHours: number;
    /** List of dates (YYYY-MM-DD) when upgrades are blocked. */
    interruptWindowEmbargoDates: ConnectorsUpdateResponseInterruptWindowEmbargoDatesList;
    interruptWindowHourOfDay: number;
    lastUpdated: string;
    notes: string;
    timezone: string;
    device?: ConnectorsUpdateResponseDevice | null | undefined;
    lastHeartbeat?: string | null | undefined;
    lastSeenVersion?: string | null | undefined;
    licenseKey?: string | null | undefined;
}
export type GreTunnelsUpdateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export type GreTunnelsUpdateRequestHealthCheckRate = "low" | "mid" | "high";
export type GreTunnelsUpdateRequestHealthCheckTargetMagicHealthCheckTarget = GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsUpdateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsUpdateRequestHealthCheckType = "reply" | "request";
export interface GreTunnelsUpdateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsUpdateRequestHealthCheckDirection | (string & {}) | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsUpdateRequestHealthCheckRate | (string & {}) | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsUpdateRequestHealthCheckTarget | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsUpdateRequestHealthCheckType | (string & {}) | undefined;
}
export interface UpdateGreTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    greTunnelId: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | undefined;
    /** An optional description of the GRE tunnel. */
    description?: string | undefined;
    healthCheck?: GreTunnelsUpdateRequestHealthCheck | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | undefined;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | undefined;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | undefined;
    xMagicNewHcTarget?: boolean | undefined;
}
export type GreTunnelsUpdateResponseModifiedGreTunnelBgpExtraPrefixesList = Array<string>;
export interface GreTunnelsUpdateResponseModifiedGreTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: GreTunnelsUpdateResponseModifiedGreTunnelBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type GreTunnelsUpdateResponseModifiedGreTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface GreTunnelsUpdateResponseModifiedGreTunnelBgpStatus {
    state: GreTunnelsUpdateResponseModifiedGreTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckRate = "low" | "mid" | "high";
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckType = "reply" | "request";
export interface GreTunnelsUpdateResponseModifiedGreTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheckType | null | undefined;
}
export interface GreTunnelsUpdateResponseModifiedGreTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the GRE tunnel. */
    cloudflareGreEndpoint: string;
    /** The IP address assigned to the customer side of the GRE tunnel. */
    customerGreEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the tunnel. The name cannot contain spaces or special characters, must be 15 characters or less, and cannot share a name with another GRE tunnel. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: GreTunnelsUpdateResponseModifiedGreTunnelBgp | null | undefined;
    bgpStatus?: GreTunnelsUpdateResponseModifiedGreTunnelBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    /** An optional description of the GRE tunnel. */
    description?: string | null | undefined;
    healthCheck?: GreTunnelsUpdateResponseModifiedGreTunnelHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** Maximum Transmission Unit (MTU) in bytes for the GRE tunnel. The minimum value is 576. */
    mtu?: number | null | undefined;
    /** Time To Live (TTL) in number of hops of the GRE tunnel. */
    ttl?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateGreTunnelResponse {
    modified?: boolean | null | undefined;
    modifiedGreTunnel?: GreTunnelsUpdateResponseModifiedGreTunnel | null | undefined;
}
export type IpsecTunnelsUpdateRequestBgpExtraPrefixesList = Array<string>;
export interface IpsecTunnelsUpdateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: IpsecTunnelsUpdateRequestBgpExtraPrefixesList | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | undefined;
}
export type IpsecTunnelsUpdateRequestCustomRemoteIdentities = IpsecTunnelsCreateRequestCustomRemoteIdentities;
export type IpsecTunnelsUpdateRequestHealthCheckDirection = "unidirectional" | "bidirectional";
export type IpsecTunnelsUpdateRequestHealthCheckRate = "low" | "mid" | "high";
export type IpsecTunnelsUpdateRequestHealthCheckTargetMagicHealthCheckTarget = GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsUpdateRequestHealthCheckTarget = string | GreTunnelsCreateRequestHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsUpdateRequestHealthCheckType = "reply" | "request";
export interface IpsecTunnelsUpdateRequestHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsUpdateRequestHealthCheckDirection | (string & {}) | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsUpdateRequestHealthCheckRate | (string & {}) | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsUpdateRequestHealthCheckTarget | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsUpdateRequestHealthCheckType | (string & {}) | undefined;
}
export interface UpdateIpsecTunnelRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    ipsecTunnelId: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | undefined;
    bgp?: IpsecTunnelsUpdateRequestBgp | undefined;
    customRemoteIdentities?: IpsecTunnelsCreateRequestCustomRemoteIdentities | undefined;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | undefined;
    /** An optional description forthe IPsec tunnel. */
    description?: string | undefined;
    healthCheck?: IpsecTunnelsUpdateRequestHealthCheck | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | undefined;
    /** A randomly generated or provided string for use in the IPsec tunnel. */
    psk?: string | undefined;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | undefined;
    xMagicNewHcTarget?: boolean | undefined;
}
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpExtraPrefixesList = Array<string>;
export interface IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** ID of the BGP filter profile applied to routes advertised to the customer. */
    exportFilterId?: string | null | undefined;
    /** Prefixes in this list will be advertised to the customer device, in addition to the routes in the Magic routing table. Each entry must be a network address in CIDR notation with no host bits set (for example `192.0.2.0/24`, not `192.0.2.1/24`) and must not repeat another entry. IPv6 prefixes are accepted only when the tunnel has an `interface_address6`. */
    extraPrefixes?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpExtraPrefixesList | null | undefined;
    /** ID of the BGP filter profile applied to routes received from the customer. */
    importFilterId?: string | null | undefined;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null | undefined;
}
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatusState = "BGP_DOWN" | "BGP_UP" | "BGP_ESTABLISHING";
export interface IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatus {
    state: IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatusState;
    tcpEstablished: boolean;
    updatedAt: string;
    bgpState?: string | null | undefined;
    cfSpeakerIp?: string | null | undefined;
    cfSpeakerPort?: number | null | undefined;
    customerSpeakerIp?: string | null | undefined;
    customerSpeakerPort?: number | null | undefined;
}
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelCustomRemoteIdentities = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckDirection = "unidirectional" | "bidirectional";
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckRate = "low" | "mid" | "high";
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckTargetMagicHealthCheckTarget = CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckTarget = string | CfInterconnectsBulkUpdateResponseModifiedInterconnectsItemHealthCheckTargetMagicHealthCheckTarget;
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckType = "reply" | "request";
export interface IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheck {
    /** The direction of the flow of the healthcheck. Either unidirectional, where the probe comes to you via the tunnel and the result comes back to Cloudflare via the open Internet, or bidirectional where both the probe and result come and go via the tunnel. */
    direction?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckDirection | null | undefined;
    /** Determines whether to run healthchecks for a tunnel. */
    enabled?: boolean | null | undefined;
    /** How frequent the health check is run. The default value is `mid`. */
    rate?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckRate | null | undefined;
    /** The destination address in a request type health check. After the healthcheck is decapsulated at the customer end of the tunnel, the ICMP echo will be forwarded to this address. This field defaults to `customer_gre_endpoint address`. This field is ignored for bidirectional healthchecks as the interface_address (not assigned to the Cloudflare side of the tunnel) is used as the target. Must be in object form if the x-magic-new-hc-target header is set to true and string form if x-magic-new-hc-target is absent or set to false. */
    target?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckTarget | null | undefined;
    /** The type of healthcheck to run, reply or request. The default value is `reply`. */
    type?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheckType | null | undefined;
}
export type IpsecTunnelsUpdateResponseModifiedIpsecTunnelPskMetadata = IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata;
export interface IpsecTunnelsUpdateResponseModifiedIpsecTunnel {
    /** Identifier */
    id: string;
    /** The IP address assigned to the Cloudflare side of the IPsec tunnel. */
    cloudflareEndpoint: string;
    /** A 31-bit prefix (/31 in CIDR notation) supporting two hosts, one for each side of the tunnel. Select the subnet from the following private IP space: 10.0.0.0-10.255.255.255, 172.16.0.0-172.31.255.255, 192.168.0.0-192.168.255.255. */
    interfaceAddress: string;
    /** The name of the IPsec tunnel. The name cannot share a name with other tunnels. */
    name: string;
    /** When `true`, the tunnel can use a null-cipher (`ENCR_NULL`) in the ESP tunnel (Phase 2). */
    allowNullCipher?: boolean | null | undefined;
    /** True if automatic stateful return routing should be enabled for a tunnel, false otherwise. Requires the `coupler_integration` account flag to be enabled; requests setting this to `true` without that flag will be rejected. */
    automaticReturnRouting?: boolean | null | undefined;
    bgp?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgp | null | undefined;
    bgpStatus?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelBgpStatus | null | undefined;
    /** The date and time the tunnel was created. */
    createdOn?: string | null | undefined;
    customRemoteIdentities?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemCustomRemoteIdentities | null | undefined;
    /** The IP address assigned to the customer side of the IPsec tunnel. Not required, but must be set for proactive traceroutes to work. */
    customerEndpoint?: string | null | undefined;
    /** An optional description forthe IPsec tunnel. */
    description?: string | null | undefined;
    healthCheck?: IpsecTunnelsUpdateResponseModifiedIpsecTunnelHealthCheck | null | undefined;
    /** A 127 bit IPV6 prefix from within the virtual_subnet6 prefix space with the address being the first IP of the subnet and not same as the address of virtual_subnet6. Eg if virtual_subnet6 is 2606:54c1:7:0:a9fe:12d2::/127 , interface_address6 could be 2606:54c1:7:0:a9fe:12d2:1:200/127 */
    interfaceAddress6?: string | null | undefined;
    /** The date and time the tunnel was last modified. */
    modifiedOn?: string | null | undefined;
    /** The PSK metadata that includes when the PSK was generated. */
    pskMetadata?: IpsecTunnelsBulkUpdateResponseModifiedIpsecTunnelsItemPskMetadata | null | undefined;
    /** If `true`, then IPsec replay protection will be supported in the Cloudflare-to-customer direction. */
    replayProtection?: boolean | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateIpsecTunnelResponse {
    modified?: boolean | null | undefined;
    modifiedIpsecTunnel?: IpsecTunnelsUpdateResponseModifiedIpsecTunnel | null | undefined;
}
export type RoutesUpdateRequestScopeColoNamesList = Array<string>;
export type RoutesUpdateRequestScopeColoRegionsList = Array<string>;
export interface RoutesUpdateRequestScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesUpdateRequestScopeColoNamesList | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesUpdateRequestScopeColoRegionsList | undefined;
}
export interface UpdateRouteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    routeId: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** An optional human provided description of the static route. */
    description?: string | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesUpdateRequestScope | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | undefined;
}
export type RoutesUpdateResponseModifiedRouteScopeColoNamesList = Array<string>;
export type RoutesUpdateResponseModifiedRouteScopeColoRegionsList = Array<string>;
export interface RoutesUpdateResponseModifiedRouteScope {
    /** List of colo names for the ECMP scope. */
    coloNames?: RoutesUpdateResponseModifiedRouteScopeColoNamesList | null | undefined;
    /** List of colo regions for the ECMP scope. */
    coloRegions?: RoutesUpdateResponseModifiedRouteScopeColoRegionsList | null | undefined;
}
export interface RoutesUpdateResponseModifiedRoute {
    /** Identifier */
    id: string;
    /** The next-hop IP Address for the static route. */
    nexthop: string;
    /** IP Prefix in Classless Inter-Domain Routing format. */
    prefix: string;
    /** Priority of the static route. */
    priority: number;
    /** When the route was created. */
    createdOn?: string | null | undefined;
    /** An optional human provided description of the static route. */
    description?: string | null | undefined;
    /** When the route was last modified. */
    modifiedOn?: string | null | undefined;
    /** Used only for ECMP routes. */
    scope?: RoutesUpdateResponseModifiedRouteScope | null | undefined;
    /** Optional weight of the ECMP scope - if provided. */
    weight?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRouteResponse {
    modified?: boolean | null | undefined;
    modifiedRoute?: RoutesUpdateResponseModifiedRoute | null | undefined;
}
export type SitesUpdateRequestLocation = SitesCreateRequestLocation;
export interface UpdateSiteRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Magic Connector identifier tag. */
    connectorId?: string | undefined;
    description?: string | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateRequestLocation | undefined;
    /** The name of the site. */
    name?: string | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | undefined;
}
export type SitesUpdateResponseLocation = SitesCreateResponseLocation;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic Connector identifier tag. */
    connectorId?: string | null | undefined;
    description?: string | null | undefined;
    /** Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode. */
    haMode?: boolean | null | undefined;
    /** Location of site in latitude and longitude. */
    location?: SitesCreateResponseLocation | null | undefined;
    /** The name of the site. */
    name?: string | null | undefined;
    /** Magic Connector identifier tag. Used when high availability mode is on. */
    secondaryConnectorId?: string | null | undefined;
}
export type SitesAclsUpdateRequestLan1PortRangesList = Array<string>;
export type SitesAclsUpdateRequestLan1PortsList = Array<number>;
export type SitesAclsUpdateRequestLan1SubnetsList = Array<string>;
export interface SitesAclsUpdateRequestLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsUpdateRequestLan1PortRangesList | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsUpdateRequestLan1PortsList | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsUpdateRequestLan1SubnetsList | undefined;
}
export type SitesAclsUpdateRequestLan2PortRangesList = Array<string>;
export type SitesAclsUpdateRequestLan2PortsList = Array<number>;
export type SitesAclsUpdateRequestLan2SubnetsList = Array<string>;
export interface SitesAclsUpdateRequestLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsUpdateRequestLan2PortRangesList | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsUpdateRequestLan2PortsList | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsUpdateRequestLan2SubnetsList | undefined;
}
export type SitesAclsUpdateRequestProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsUpdateRequestProtocolsList = Array<SitesAclsUpdateRequestProtocolsItem | (string & {})>;
export interface UpdateSiteAclRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    aclId: string;
    /** Description for the ACL. */
    description?: string | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | undefined;
    lan_1?: SitesAclsUpdateRequestLan1 | undefined;
    lan_2?: SitesAclsUpdateRequestLan2 | undefined;
    /** The name of the ACL. */
    name?: string | undefined;
    protocols?: SitesAclsUpdateRequestProtocolsList | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | undefined;
}
export type SitesAclsUpdateResponseLan1PortRangesList = Array<string>;
export type SitesAclsUpdateResponseLan1PortsList = Array<number>;
export type SitesAclsUpdateResponseLan1SubnetsList = Array<string>;
export interface SitesAclsUpdateResponseLan1 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsUpdateResponseLan1PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsUpdateResponseLan1PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsUpdateResponseLan1SubnetsList | null | undefined;
}
export type SitesAclsUpdateResponseLan2PortRangesList = Array<string>;
export type SitesAclsUpdateResponseLan2PortsList = Array<number>;
export type SitesAclsUpdateResponseLan2SubnetsList = Array<string>;
export interface SitesAclsUpdateResponseLan2 {
    /** The identifier for the LAN you want to create an ACL policy with. */
    lanId: string;
    /** The name of the LAN based on the provided lan_id. */
    lanName?: string | null | undefined;
    /** Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed. */
    portRanges?: SitesAclsUpdateResponseLan2PortRangesList | null | undefined;
    /** Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed. */
    ports?: SitesAclsUpdateResponseLan2PortsList | null | undefined;
    /** Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed. */
    subnets?: SitesAclsUpdateResponseLan2SubnetsList | null | undefined;
}
export type SitesAclsUpdateResponseProtocolsItem = "tcp" | "udp" | "icmp";
export type SitesAclsUpdateResponseProtocolsList = Array<SitesAclsUpdateResponseProtocolsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteAclResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Description for the ACL. */
    description?: string | null | undefined;
    /** The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false. */
    forwardLocally?: boolean | null | undefined;
    lan_1?: SitesAclsUpdateResponseLan1 | null | undefined;
    lan_2?: SitesAclsUpdateResponseLan2 | null | undefined;
    /** The name of the ACL. */
    name?: string | null | undefined;
    protocols?: SitesAclsUpdateResponseProtocolsList | null | undefined;
    /** The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false. */
    unidirectional?: boolean | null | undefined;
}
export type SitesLansUpdateRequestNat = SitesLansCreateRequestNat;
export type SitesLansUpdateRequestRemoteSubnetsItem = SitesLansCreateRequestRemoteSubnetsItem;
export type SitesLansUpdateRequestRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansUpdateRequestRoutedSubnetsItemNat = SitesLansCreateRequestNat;
export type SitesLansUpdateRequestRoutedSubnetsItem = SitesLansCreateRequestRoutedSubnetsItem;
export type SitesLansUpdateRequestRoutedSubnetsList = Array<SitesLansCreateRequestRoutedSubnetsItem>;
export type SitesLansUpdateRequestStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansUpdateRequestStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansUpdateRequestStaticAddressingDhcpRelayServerAddressesList | undefined;
}
export type SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItemType | (string & {});
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansUpdateRequestStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansUpdateRequestStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansUpdateRequestStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansUpdateRequestStaticAddressingDhcpServerDhcpOptionsList | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | undefined;
    dnsServers?: SitesLansUpdateRequestStaticAddressingDhcpServerDnsServersList | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansUpdateRequestStaticAddressingDhcpServerReservationsMap | undefined;
}
export interface SitesLansUpdateRequestStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansUpdateRequestStaticAddressingDhcpRelay | undefined;
    dhcpServer?: SitesLansUpdateRequestStaticAddressingDhcpServer | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | undefined;
}
export interface UpdateSiteLanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    lanId: string;
    bondId?: number | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | undefined;
    name?: string | undefined;
    nat?: SitesLansCreateRequestNat | undefined;
    physport?: number | undefined;
    remoteSubnets?: SitesLansUpdateRequestRemoteSubnetsList | undefined;
    routedSubnets?: SitesLansUpdateRequestRoutedSubnetsList | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansUpdateRequestStaticAddressing | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | undefined;
}
export type SitesLansUpdateResponseNat = SitesLansCreateResultItemNat;
export type SitesLansUpdateResponseRemoteSubnetsItem = SitesLansCreateRequestRemoteSubnetsItem;
export type SitesLansUpdateResponseRemoteSubnetsList = Array<SitesLansCreateRequestRemoteSubnetsItem>;
export type SitesLansUpdateResponseRoutedSubnetsItemNat = SitesLansCreateResultItemNat;
export type SitesLansUpdateResponseRoutedSubnetsItem = SitesLansCreateResultItemRoutedSubnetsItem;
export type SitesLansUpdateResponseRoutedSubnetsList = Array<SitesLansCreateResultItemRoutedSubnetsItem>;
export type SitesLansUpdateResponseStaticAddressingDhcpRelayServerAddressesList = Array<string>;
export interface SitesLansUpdateResponseStaticAddressingDhcpRelay {
    /** List of DHCP server IPs. */
    serverAddresses?: SitesLansUpdateResponseStaticAddressingDhcpRelayServerAddressesList | null | undefined;
}
export type SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItemType = "text" | "hex" | "ip" | "byte" | "short" | "integer";
export interface SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItem {
    /** DHCP option number (1-254). Options 0 and 255 are reserved by RFC 2132. Options 3, 6, and 51 are not allowed because they conflict with connector-managed configuration. */
    code: number;
    /** The type of the option value. text: a string (max 255 bytes). hex: colon-separated hex bytes (e.g. "01:04:aa:bb:cc", max 255 bytes). ip: an IPv4 address (e.g. "10.20.30.40"). byte: an unsigned integer 0-255 (1 byte). short: an unsigned integer 0-65535 (2 bytes). integer: an unsigned integer 0-4294967295 (4 bytes). */
    type: SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItemType;
    /** The option value, interpreted according to the type field. */
    value: string;
}
export type SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsList = Array<SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsItem>;
export type SitesLansUpdateResponseStaticAddressingDhcpServerDnsServersList = Array<string>;
export type SitesLansUpdateResponseStaticAddressingDhcpServerReservationsMap = {
    [key: string]: unknown | undefined;
};
export interface SitesLansUpdateResponseStaticAddressingDhcpServer {
    /** Optional list of custom DHCP options to include in DHCP responses. Only valid when DHCP server is enabled. */
    dhcpOptions?: SitesLansUpdateResponseStaticAddressingDhcpServerDhcpOptionsList | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolEnd?: string | null | undefined;
    /** A valid IPv4 address. */
    dhcpPoolStart?: string | null | undefined;
    /** A valid IPv4 address. */
    dnsServer?: string | null | undefined;
    dnsServers?: SitesLansUpdateResponseStaticAddressingDhcpServerDnsServersList | null | undefined;
    /** Mapping of MAC addresses to IP addresses */
    reservations?: SitesLansUpdateResponseStaticAddressingDhcpServerReservationsMap | null | undefined;
}
export interface SitesLansUpdateResponseStaticAddressing {
    /** A valid CIDR notation representing an IP range. */
    address: string;
    dhcpRelay?: SitesLansUpdateResponseStaticAddressingDhcpRelay | null | undefined;
    dhcpServer?: SitesLansUpdateResponseStaticAddressingDhcpServer | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    secondaryAddress?: string | null | undefined;
    /** A valid CIDR notation representing an IP range. */
    virtualAddress?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteLanResponse {
    /** Identifier */
    id?: string | null | undefined;
    bondId?: number | null | undefined;
    /** mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link. */
    haLink?: boolean | null | undefined;
    /** mark true to use this LAN for source-based breakout traffic */
    isBreakout?: boolean | null | undefined;
    /** mark true to use this LAN for source-based prioritized traffic */
    isPrioritized?: boolean | null | undefined;
    name?: string | null | undefined;
    nat?: SitesLansCreateResultItemNat | null | undefined;
    physport?: number | null | undefined;
    remoteSubnets?: SitesLansUpdateResponseRemoteSubnetsList | null | undefined;
    routedSubnets?: SitesLansUpdateResponseRoutedSubnetsList | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address. */
    staticAddressing?: SitesLansUpdateResponseStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export type UpdateSitesAppConfigurationRequestPreferredWansList = Array<string>;
export interface UpdateSitesAppConfigurationRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    appConfigId: string;
    /** Magic account app ID. */
    accountAppId?: string | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | undefined;
    /** Managed app ID. */
    managedAppId?: string | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: UpdateSitesAppConfigurationRequestPreferredWansList | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | undefined;
}
export type UpdateSitesAppConfigurationResultAccountAppPreferredWansList = Array<string>;
export interface UpdateSitesAppConfigurationResultAccountApp {
    /** Magic account app ID. */
    accountAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: UpdateSitesAppConfigurationResultAccountAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type UpdateSitesAppConfigurationResultManagedAppPreferredWansList = Array<string>;
export interface UpdateSitesAppConfigurationResultManagedApp {
    /** Managed app ID. */
    managedAppId: string;
    /** Identifier */
    id?: string | null | undefined;
    /** Whether to breakout traffic to the app's endpoints directly. Null preserves default behavior. */
    breakout?: boolean | null | undefined;
    /** WAN interfaces to prefer over default WANs, highest-priority first. Can only be specified for breakout rules (breakout must be true). */
    preferredWans?: UpdateSitesAppConfigurationResultManagedAppPreferredWansList | null | undefined;
    /** Priority of traffic. 0 is default, anything greater is prioritized. (Currently only 0 and 1 are supported) */
    priority?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
}
export type UpdateSitesAppConfigurationResult = UpdateSitesAppConfigurationResultAccountApp | UpdateSitesAppConfigurationResultManagedApp;
export type UpdateSitesAppConfigurationResponse = UpdateSitesAppConfigurationResult;
export type SitesWansUpdateRequestHealthCheckRate = "low" | "mid" | "high";
export type SitesWansUpdateRequestStaticAddressing = SitesWansEditRequestStaticAddressing;
export interface UpdateSiteWanRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    siteId: string;
    /** Identifier */
    wanId: string;
    /** Magic WAN health check rate for tunnels created on this link. */
    healthCheckRate?: SitesWansUpdateRequestHealthCheckRate | (string & {}) | undefined;
    loadBalanceInnerFlows?: boolean | undefined;
    name?: string | undefined;
    physport?: number | undefined;
    priority?: number | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. Set to null to remove it. */
    provisionedDownloadKbps?: number | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. Set to null to remove it. */
    provisionedUploadKbps?: number | undefined;
    /** Static addressing configuration. PATCH updates only the fields provided, and PUT replaces the configuration. */
    staticAddressing?: SitesWansEditRequestStaticAddressing | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | undefined;
}
export type SitesWansUpdateResponseHealthCheckRate = "low" | "mid" | "high";
export type SitesWansUpdateResponseStaticAddressing = SitesWansCreateResultItemStaticAddressing;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteWanResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** Magic WAN health check rate for tunnels created on this link. The default value is `mid`. */
    healthCheckRate?: SitesWansUpdateResponseHealthCheckRate | null | undefined;
    loadBalanceInnerFlows?: boolean | null | undefined;
    name?: string | null | undefined;
    physport?: number | null | undefined;
    /** Priority of WAN for traffic loadbalancing. */
    priority?: number | null | undefined;
    /** Provisioned download rate of the WAN circuit in kilobits per second. */
    provisionedDownloadKbps?: number | null | undefined;
    /** Provisioned upload rate of the WAN circuit in kilobits per second. */
    provisionedUploadKbps?: number | null | undefined;
    /** Identifier */
    siteId?: string | null | undefined;
    /** (optional) if omitted, use DHCP. Submit secondary_address when site is in high availability mode. */
    staticAddressing?: SitesWansCreateResultItemStaticAddressing | null | undefined;
    /** VLAN ID. Use zero for untagged. */
    vlanTag?: number | null | undefined;
}
export interface ValidatePcapOwnershipRequest {
    /** Identifier. */
    accountId: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
    /** The ownership challenge filename stored in the bucket. */
    ownershipChallenge: string;
}
export type PcapsOwnershipValidateResponseStatus = "pending" | "success" | "failed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ValidatePcapOwnershipResponse {
    /** The bucket ID associated with the packet captures API. */
    id: string;
    /** The full URI for the bucket. This field only applies to `full` packet captures. */
    destinationConf: string;
    /** The ownership challenge filename stored in the bucket. */
    filename: string;
    /** The status of the ownership challenge. Can be pending, success or failed. */
    status: PcapsOwnershipValidateResponseStatus;
    /** The RFC 3339 timestamp when the bucket was added to packet captures API. */
    submitted: string;
    /** The RFC 3339 timestamp when the bucket was validated. */
    validated?: string | null | undefined;
}
export type BulkPutCfInterconnectsError = CloudflareOpError;
/** Updates multiple interconnects associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const bulkPutCfInterconnects: API.OperationMethod<BulkPutCfInterconnectsRequest, BulkPutCfInterconnectsResponse, BulkPutCfInterconnectsError, CloudflareOpContext>;
export type BulkPutGreTunnelsError = CloudflareOpError;
/** Updates multiple GRE tunnels. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const bulkPutGreTunnels: API.OperationMethod<BulkPutGreTunnelsRequest, BulkPutGreTunnelsResponse, BulkPutGreTunnelsError, CloudflareOpContext>;
export type BulkPutIpsecTunnelsError = CloudflareOpError;
/** Update multiple IPsec tunnels associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const bulkPutIpsecTunnels: API.OperationMethod<BulkPutIpsecTunnelsRequest, BulkPutIpsecTunnelsResponse, BulkPutIpsecTunnelsError, CloudflareOpContext>;
export type BulkPutRoutesError = CloudflareOpError;
/** Update multiple Magic static routes. Use `?validate_only=true` as an optional query parameter to run validation only without persisting changes. Only fields for a route that need to be changed need be provided. */
export declare const bulkPutRoutes: API.OperationMethod<BulkPutRoutesRequest, BulkPutRoutesResponse, BulkPutRoutesError, CloudflareOpContext>;
export type CreateAppError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Creates a new App for an account */
export declare const createApp: API.OperationMethod<CreateAppRequest, CreateAppResponse, CreateAppError, CloudflareOpContext>;
export type CreateBgpFilterProfileError = CloudflareOpError;
/** Creates a new BGP filter profile for an account. */
export declare const createBgpFilterProfile: API.OperationMethod<CreateBgpFilterProfileRequest, CreateBgpFilterProfileResponse, CreateBgpFilterProfileError, CloudflareOpContext>;
export type CreateCf1SiteError = CloudflareOpError;
/** Creates new CF1 Sites for an account. Each site must have a unique name within the account. */
export declare const createCf1Site: API.PaginatedOperationMethod<CreateCf1SiteRequest, CreateCf1SiteResponse, CreateCf1SiteError, CloudflareOpContext, Cf1SitesCreateResultItem>;
export type CreateCf1SiteRampError = CloudflareOpError;
/** Creates ramps (network connections) for a CF1 Site. */
export declare const createCf1SiteRamp: API.PaginatedOperationMethod<CreateCf1SiteRampRequest, CreateCf1SiteRampResponse, CreateCf1SiteRampError, CloudflareOpContext, Cf1SitesRampsCreateResultItem>;
export type CreateConnectorError = CloudflareOpError;
/** Creates a Magic WAN Connector. */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest, CreateConnectorResponse, CreateConnectorError, CloudflareOpContext>;
export type CreateConnectorsInterruptError = CloudflareOpError;
/** Creates an interrupt for a Magic WAN Connector. */
export declare const createConnectorsInterrupt: API.OperationMethod<CreateConnectorsInterruptRequest, CreateConnectorsInterruptResponse, CreateConnectorsInterruptError, CloudflareOpContext>;
export type CreateGreTunnelError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Creates a new GRE tunnel. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const createGreTunnel: API.OperationMethod<CreateGreTunnelRequest, CreateGreTunnelResponse, CreateGreTunnelError, CloudflareOpContext>;
export type CreateIpsecTunnelError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Creates a new IPsec tunnel associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const createIpsecTunnel: API.OperationMethod<CreateIpsecTunnelRequest, CreateIpsecTunnelResponse, CreateIpsecTunnelError, CloudflareOpContext>;
export type CreatePcapError = CloudflareOpError;
/** Create new PCAP request for account. */
export declare const createPcap: API.OperationMethod<CreatePcapRequest, CreatePcapResponse, CreatePcapError, CloudflareOpContext>;
export type CreatePcapOwnershipError = CloudflareOpError;
/** Adds an AWS or GCP bucket to use with full packet captures. */
export declare const createPcapOwnership: API.OperationMethod<CreatePcapOwnershipRequest, CreatePcapOwnershipResponse, CreatePcapOwnershipError, CloudflareOpContext>;
export type CreateRouteError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Creates a new Magic static route. Use `?validate_only=true` as an optional query parameter to run validation only without persisting changes. */
export declare const createRoute: API.OperationMethod<CreateRouteRequest, CreateRouteResponse, CreateRouteError, CloudflareOpContext>;
export type CreateSiteError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Creates a new Site */
export declare const createSite: API.OperationMethod<CreateSiteRequest, CreateSiteResponse, CreateSiteError, CloudflareOpContext>;
export type CreateSiteAclError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Creates a new Site ACL. */
export declare const createSiteAcl: API.OperationMethod<CreateSiteAclRequest, CreateSiteAclResponse, CreateSiteAclError, CloudflareOpContext>;
export type CreateSiteLanError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Creates a new Site LAN. If the site is in high availability mode, static_addressing is required along with secondary and virtual address. */
export declare const createSiteLan: API.PaginatedOperationMethod<CreateSiteLanRequest, CreateSiteLanResponse, CreateSiteLanError, CloudflareOpContext, SitesLansCreateResultItem>;
export type CreateSitesAppConfigurationError = CloudflareOpError;
/** Creates a new App Config for a site */
export declare const createSitesAppConfiguration: API.OperationMethod<CreateSitesAppConfigurationRequest, CreateSitesAppConfigurationResponse, CreateSitesAppConfigurationError, CloudflareOpContext>;
export type CreateSiteWanError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Creates a new Site WAN. */
export declare const createSiteWan: API.PaginatedOperationMethod<CreateSiteWanRequest, CreateSiteWanResponse, CreateSiteWanError, CloudflareOpContext, SitesWansCreateResultItem>;
export type DeleteAppError = AppNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Deletes specific Account App. */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest, DeleteAppResponse, DeleteAppError, CloudflareOpContext>;
export type DeleteBgpFilterProfileError = CloudflareOpError;
/** Deletes a BGP filter profile. */
export declare const deleteBgpFilterProfile: API.OperationMethod<DeleteBgpFilterProfileRequest, DeleteBgpFilterProfileResponse, DeleteBgpFilterProfileError, CloudflareOpContext>;
export type DeleteCf1SiteError = CloudflareOpError;
/** Deletes a specific CF1 Site for an account. */
export declare const deleteCf1Site: API.OperationMethod<DeleteCf1SiteRequest, DeleteCf1SiteResponse, DeleteCf1SiteError, CloudflareOpContext>;
export type DeleteCf1SiteRampError = CloudflareOpError;
/** Deletes a specific ramp from a CF1 Site. */
export declare const deleteCf1SiteRamp: API.OperationMethod<DeleteCf1SiteRampRequest, DeleteCf1SiteRampResponse, DeleteCf1SiteRampError, CloudflareOpContext>;
export type DeleteConnectorError = CloudflareOpError;
/** Deletes a Magic WAN Connector. */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest, DeleteConnectorResponse, DeleteConnectorError, CloudflareOpContext>;
export type DeleteGreTunnelError = GreTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Disables and removes a specific static GRE tunnel. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const deleteGreTunnel: API.OperationMethod<DeleteGreTunnelRequest, DeleteGreTunnelResponse, DeleteGreTunnelError, CloudflareOpContext>;
export type DeleteIpsecTunnelError = IpsecTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Disables and removes a specific static IPsec Tunnel associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const deleteIpsecTunnel: API.OperationMethod<DeleteIpsecTunnelRequest, DeleteIpsecTunnelResponse, DeleteIpsecTunnelError, CloudflareOpContext>;
export type DeletePcapOwnershipError = CloudflareOpError;
/** Deletes buckets added to the packet captures API. */
export declare const deletePcapOwnership: API.OperationMethod<DeletePcapOwnershipRequest, DeletePcapOwnershipResponse, DeletePcapOwnershipError, CloudflareOpContext>;
export type DeleteRouteError = RouteNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Disable and remove a specific Magic static route. */
export declare const deleteRoute: API.OperationMethod<DeleteRouteRequest, DeleteRouteResponse, DeleteRouteError, CloudflareOpContext>;
export type DeleteSiteError = SiteNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Remove a specific Site. */
export declare const deleteSite: API.OperationMethod<DeleteSiteRequest, DeleteSiteResponse, DeleteSiteError, CloudflareOpContext>;
export type DeleteSiteAclError = SiteAclNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Remove a specific Site ACL. */
export declare const deleteSiteAcl: API.OperationMethod<DeleteSiteAclRequest, DeleteSiteAclResponse, DeleteSiteAclError, CloudflareOpContext>;
export type DeleteSiteLanError = SiteLanNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Remove a specific Site LAN. */
export declare const deleteSiteLan: API.OperationMethod<DeleteSiteLanRequest, DeleteSiteLanResponse, DeleteSiteLanError, CloudflareOpContext>;
export type DeleteSitesAppConfigurationError = CloudflareOpError;
/** Deletes specific App Config associated with a site. */
export declare const deleteSitesAppConfiguration: API.OperationMethod<DeleteSitesAppConfigurationRequest, DeleteSitesAppConfigurationResponse, DeleteSitesAppConfigurationError, CloudflareOpContext>;
export type DeleteSiteWanError = SiteWanNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Remove a specific Site WAN. */
export declare const deleteSiteWan: API.OperationMethod<DeleteSiteWanRequest, DeleteSiteWanResponse, DeleteSiteWanError, CloudflareOpContext>;
export type EditSitesAppConfigurationError = CloudflareOpError;
/** Updates an App Config for a site */
export declare const editSitesAppConfiguration: API.OperationMethod<EditSitesAppConfigurationRequest, EditSitesAppConfigurationResponse, EditSitesAppConfigurationError, CloudflareOpContext>;
export type EmptyRouteError = CloudflareOpError;
/** Delete multiple Magic static routes. */
export declare const emptyRoute: API.OperationMethod<EmptyRouteRequest, EmptyRouteResponse, EmptyRouteError, CloudflareOpContext>;
export type GetBgpFilterProfileError = CloudflareOpError;
/** Gets a specific BGP filter profile for an account. */
export declare const getBgpFilterProfile: API.OperationMethod<GetBgpFilterProfileRequest, GetBgpFilterProfileResponse, GetBgpFilterProfileError, CloudflareOpContext>;
export type GetCf1SiteError = CloudflareOpError;
/** Gets a specific CF1 Site for an account. */
export declare const getCf1Site: API.OperationMethod<GetCf1SiteRequest, GetCf1SiteResponse, GetCf1SiteError, CloudflareOpContext>;
export type GetCf1SiteRampError = CloudflareOpError;
/** Gets a specific ramp for a CF1 Site. */
export declare const getCf1SiteRamp: API.OperationMethod<GetCf1SiteRampRequest, GetCf1SiteRampResponse, GetCf1SiteRampError, CloudflareOpContext>;
export type GetCfInterconnectError = CloudflareOpError;
/** Lists details for a specific interconnect. */
export declare const getCfInterconnect: API.OperationMethod<GetCfInterconnectRequest, GetCfInterconnectResponse, GetCfInterconnectError, CloudflareOpContext>;
export type GetConnectorError = CloudflareOpError;
/** Gets a Magic WAN Connector. */
export declare const getConnector: API.OperationMethod<GetConnectorRequest, GetConnectorResponse, GetConnectorError, CloudflareOpContext>;
export type GetConnectorEventError = CloudflareOpError;
/** Gets Magic WAN Connector Telemetry Event */
export declare const getConnectorEvent: API.OperationMethod<GetConnectorEventRequest, GetConnectorEventResponse, GetConnectorEventError, CloudflareOpContext>;
export type GetConnectorSnapshotError = CloudflareOpError;
/** Gets Magic WAN Connector Telemetry Snapshot */
export declare const getConnectorSnapshot: API.OperationMethod<GetConnectorSnapshotRequest, GetConnectorSnapshotResponse, GetConnectorSnapshotError, CloudflareOpContext>;
export type GetGreTunnelError = GreTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Lists informtion for a specific GRE tunnel. */
export declare const getGreTunnel: API.OperationMethod<GetGreTunnelRequest, GetGreTunnelResponse, GetGreTunnelError, CloudflareOpContext>;
export type GetIpsecTunnelError = IpsecTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Lists details for a specific IPsec tunnel. */
export declare const getIpsecTunnel: API.OperationMethod<GetIpsecTunnelRequest, GetIpsecTunnelResponse, GetIpsecTunnelError, CloudflareOpContext>;
export type GetPcapError = CloudflareOpError;
/** Get information for a PCAP request by id. */
export declare const getPcap: API.OperationMethod<GetPcapRequest, GetPcapResponse, GetPcapError, CloudflareOpContext>;
export type GetPcapDownloadError = CloudflareOpError;
/** Download PCAP information into a file. Response is a binary PCAP file. */
export declare const getPcapDownload: API.OperationMethod<GetPcapDownloadRequest, GetPcapDownloadResponse, GetPcapDownloadError, CloudflareOpContext>;
export type GetPcapOwnershipError = CloudflareOpError;
/** List all buckets configured for use with PCAPs API. */
export declare const getPcapOwnership: API.PaginatedOperationMethod<GetPcapOwnershipRequest, GetPcapOwnershipResponse, GetPcapOwnershipError, CloudflareOpContext, PcapsOwnershipGetResultItem>;
export type GetRouteError = RouteNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Get a specific Magic static route. */
export declare const getRoute: API.OperationMethod<GetRouteRequest, GetRouteResponse, GetRouteError, CloudflareOpContext>;
export type GetSiteError = SiteNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Get a specific Site. */
export declare const getSite: API.OperationMethod<GetSiteRequest, GetSiteResponse, GetSiteError, CloudflareOpContext>;
export type GetSiteAclError = SiteAclNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Get a specific Site ACL. */
export declare const getSiteAcl: API.OperationMethod<GetSiteAclRequest, GetSiteAclResponse, GetSiteAclError, CloudflareOpContext>;
export type GetSiteLanError = SiteLanNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Get a specific Site LAN. */
export declare const getSiteLan: API.OperationMethod<GetSiteLanRequest, GetSiteLanResponse, GetSiteLanError, CloudflareOpContext>;
export type GetSiteWanError = SiteWanNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Get a specific Site WAN. */
export declare const getSiteWan: API.OperationMethod<GetSiteWanRequest, GetSiteWanResponse, GetSiteWanError, CloudflareOpContext>;
export type ListAppsError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Lists Apps associated with an account. */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest, ListAppsResponse, ListAppsError, CloudflareOpContext, AppsListResultItem>;
export type ListBgpFilterProfilesError = CloudflareOpError;
/** Lists all BGP filter profiles for an account. */
export declare const listBgpFilterProfiles: API.OperationMethod<ListBgpFilterProfilesRequest, ListBgpFilterProfilesResponse, ListBgpFilterProfilesError, CloudflareOpContext>;
export type ListCf1SiteRampsError = CloudflareOpError;
/** Lists ramps (network connections) associated with a CF1 Site. Ramps represent GRE tunnels, IPsec tunnels, interconnects, or MCONN links. */
export declare const listCf1SiteRamps: API.PaginatedOperationMethod<ListCf1SiteRampsRequest, ListCf1SiteRampsResponse, ListCf1SiteRampsError, CloudflareOpContext, Cf1SitesRampsListResultItem>;
export type ListCf1SitesError = CloudflareOpError;
/** Lists CF1 Sites associated with an account. A CF1 Site represents a physical customer network location with optional geographic coordinates. */
export declare const listCf1Sites: API.PaginatedOperationMethod<ListCf1SitesRequest, ListCf1SitesResponse, ListCf1SitesError, CloudflareOpContext, Cf1SitesCreateResultItem>;
export type ListCfInterconnectsError = CloudflareOpError;
/** Lists interconnects associated with an account. */
export declare const listCfInterconnects: API.OperationMethod<ListCfInterconnectsRequest, ListCfInterconnectsResponse, ListCfInterconnectsError, CloudflareOpContext>;
export type ListConnectorEventLatestsError = CloudflareOpError;
/** Gets latest Magic WAN Connector Telemetry Events */
export declare const listConnectorEventLatests: API.OperationMethod<ListConnectorEventLatestsRequest, ListConnectorEventLatestsResponse, ListConnectorEventLatestsError, CloudflareOpContext>;
export type ListConnectorEventsError = CloudflareOpError;
/** Lists Magic WAN Connector Telemetry Events */
export declare const listConnectorEvents: API.OperationMethod<ListConnectorEventsRequest, ListConnectorEventsResponse, ListConnectorEventsError, CloudflareOpContext>;
export type ListConnectorsError = CloudflareOpError;
/** Lists Magic WAN Connectors. */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, CloudflareOpContext, ConnectorsListResultItem>;
export type ListConnectorsInterruptsError = CloudflareOpError;
/** Lists interrupts for a Magic WAN Connector. */
export declare const listConnectorsInterrupts: API.OperationMethod<ListConnectorsInterruptsRequest, ListConnectorsInterruptsResponse, ListConnectorsInterruptsError, CloudflareOpContext>;
export type ListConnectorSnapshotLatestsError = CloudflareOpError;
/** Gets latest Magic WAN Connector Telemetry Snapshots */
export declare const listConnectorSnapshotLatests: API.OperationMethod<ListConnectorSnapshotLatestsRequest, ListConnectorSnapshotLatestsResponse, ListConnectorSnapshotLatestsError, CloudflareOpContext>;
export type ListConnectorSnapshotsError = CloudflareOpError;
/** Lists Magic WAN Connector Telemetry Snapshots */
export declare const listConnectorSnapshots: API.OperationMethod<ListConnectorSnapshotsRequest, ListConnectorSnapshotsResponse, ListConnectorSnapshotsError, CloudflareOpContext>;
export type ListGreTunnelsError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Lists GRE tunnels associated with an account. */
export declare const listGreTunnels: API.OperationMethod<ListGreTunnelsRequest, ListGreTunnelsResponse, ListGreTunnelsError, CloudflareOpContext>;
export type ListIpsecTunnelsError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Lists IPsec tunnels associated with an account. */
export declare const listIpsecTunnels: API.OperationMethod<ListIpsecTunnelsRequest, ListIpsecTunnelsResponse, ListIpsecTunnelsError, CloudflareOpContext>;
export type ListPcapsError = CloudflareOpError;
/** Lists all packet capture requests for an account. */
export declare const listPcaps: API.PaginatedOperationMethod<ListPcapsRequest, ListPcapsResponse, ListPcapsError, CloudflareOpContext, PcapsListResultItem>;
export type ListRoutesError = MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** List all Magic static routes. */
export declare const listRoutes: API.OperationMethod<ListRoutesRequest, ListRoutesResponse, ListRoutesError, CloudflareOpContext>;
export type ListSiteAclsError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Lists Site ACLs associated with an account. */
export declare const listSiteAcls: API.PaginatedOperationMethod<ListSiteAclsRequest, ListSiteAclsResponse, ListSiteAclsError, CloudflareOpContext, SitesAclsListResultItem>;
export type ListSiteLansError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Lists Site LANs associated with an account. */
export declare const listSiteLans: API.PaginatedOperationMethod<ListSiteLansRequest, ListSiteLansResponse, ListSiteLansError, CloudflareOpContext, SitesLansListResultItem>;
export type ListSitesError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Lists Sites associated with an account. Use connectorid query param to return sites where connectorid matches either site.ConnectorID or site.SecondaryConnectorID. */
export declare const listSites: API.PaginatedOperationMethod<ListSitesRequest, ListSitesResponse, ListSitesError, CloudflareOpContext, SitesListResultItem>;
export type ListSitesAppConfigurationError = CloudflareOpError;
/** Lists App Configs associated with a site. */
export declare const listSitesAppConfiguration: API.OperationMethod<ListSitesAppConfigurationRequest, ListSitesAppConfigurationResponse, ListSitesAppConfigurationError, CloudflareOpContext>;
export type ListSiteWansError = MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Lists Site WANs associated with an account. */
export declare const listSiteWans: API.PaginatedOperationMethod<ListSiteWansRequest, ListSiteWansResponse, ListSiteWansError, CloudflareOpContext, SitesWansListResultItem>;
export type PatchAppError = AppNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Updates an Account App */
export declare const patchApp: API.OperationMethod<PatchAppRequest, PatchAppResponse, PatchAppError, CloudflareOpContext>;
export type PatchCf1SiteError = CloudflareOpError;
/** Partially updates a specific CF1 Site for an account. Only the fields included in the request body are modified; omitted fields retain their existing values. */
export declare const patchCf1Site: API.OperationMethod<PatchCf1SiteRequest, PatchCf1SiteResponse, PatchCf1SiteError, CloudflareOpContext>;
export type PatchConnectorError = CloudflareOpError;
/** Edits properties of a Magic WAN Connector. May be used to re-provision a license key. */
export declare const patchConnector: API.OperationMethod<PatchConnectorRequest, PatchConnectorResponse, PatchConnectorError, CloudflareOpContext>;
export type PatchSiteError = SiteNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Patch a specific Site. */
export declare const patchSite: API.OperationMethod<PatchSiteRequest, PatchSiteResponse, PatchSiteError, CloudflareOpContext>;
export type PatchSiteAclError = SiteAclNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Patch a specific Site ACL. */
export declare const patchSiteAcl: API.OperationMethod<PatchSiteAclRequest, PatchSiteAclResponse, PatchSiteAclError, CloudflareOpContext>;
export type PatchSiteLanError = SiteLanNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Patch a specific Site LAN. */
export declare const patchSiteLan: API.OperationMethod<PatchSiteLanRequest, PatchSiteLanResponse, PatchSiteLanError, CloudflareOpContext>;
export type PatchSiteWanError = SiteWanNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Patch a specific Site WAN. */
export declare const patchSiteWan: API.OperationMethod<PatchSiteWanRequest, PatchSiteWanResponse, PatchSiteWanError, CloudflareOpContext>;
export type PskGenerateIpsecTunnelError = CloudflareOpError;
/** Generates a Pre-Shared Key for a specific IPsec tunnel used in the IKE session. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. After a PSK is generated, the PSK is immediately persisted to Cloudflare's edge and cannot be retrieved later. Store the PSK in a safe place. */
export declare const pskGenerateIpsecTunnel: API.OperationMethod<PskGenerateIpsecTunnelRequest, PskGenerateIpsecTunnelResponse, PskGenerateIpsecTunnelError, CloudflareOpContext>;
export type PskSetIpsecTunnelError = CloudflareOpError;
/** Sets Pre-Shared Keys for multiple IPsec tunnels associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. After PSKs are applied, they are immediately persisted to Cloudflare's edge and cannot be retrieved later. Store the PSKs in a safe place. */
export declare const pskSetIpsecTunnel: API.OperationMethod<PskSetIpsecTunnelRequest, PskSetIpsecTunnelResponse, PskSetIpsecTunnelError, CloudflareOpContext>;
export type PutCfInterconnectError = CloudflareOpError;
/** Updates a specific interconnect associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const putCfInterconnect: API.OperationMethod<PutCfInterconnectRequest, PutCfInterconnectResponse, PutCfInterconnectError, CloudflareOpContext>;
export type StopPcapError = CloudflareOpError;
/** Stop full PCAP. */
export declare const stopPcap: API.OperationMethod<StopPcapRequest, StopPcapResponse, StopPcapError, CloudflareOpContext>;
export type UpdateAppError = AppNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Updates an Account App */
export declare const updateApp: API.OperationMethod<UpdateAppRequest, UpdateAppResponse, UpdateAppError, CloudflareOpContext>;
export type UpdateBgpFilterProfileError = CloudflareOpError;
/** Updates a BGP filter profile. Omitted properties are left unchanged. To clear an existing description send `description: ""`. */
export declare const updateBgpFilterProfile: API.OperationMethod<UpdateBgpFilterProfileRequest, UpdateBgpFilterProfileResponse, UpdateBgpFilterProfileError, CloudflareOpContext>;
export type UpdateConnectorError = CloudflareOpError;
/** Updates properties of a Magic WAN Connector. May be used to re-provision a license key. */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest, UpdateConnectorResponse, UpdateConnectorError, CloudflareOpContext>;
export type UpdateGreTunnelError = GreTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Updates a specific GRE tunnel. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const updateGreTunnel: API.OperationMethod<UpdateGreTunnelRequest, UpdateGreTunnelResponse, UpdateGreTunnelError, CloudflareOpContext>;
export type UpdateIpsecTunnelError = IpsecTunnelNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Updates a specific IPsec tunnel associated with an account. Use `?validate_only=true` as an optional query parameter to only run validation without persisting changes. */
export declare const updateIpsecTunnel: API.OperationMethod<UpdateIpsecTunnelRequest, UpdateIpsecTunnelResponse, UpdateIpsecTunnelError, CloudflareOpContext>;
export type UpdateRouteError = RouteNotFound | MagicTransitNotOnboarded | Forbidden | CloudflareOpError;
/** Update a specific Magic static route. Use `?validate_only=true` as an optional query parameter to run validation only without persisting changes. */
export declare const updateRoute: API.OperationMethod<UpdateRouteRequest, UpdateRouteResponse, UpdateRouteError, CloudflareOpContext>;
export type UpdateSiteError = SiteNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Update a specific Site. */
export declare const updateSite: API.OperationMethod<UpdateSiteRequest, UpdateSiteResponse, UpdateSiteError, CloudflareOpContext>;
export type UpdateSiteAclError = SiteAclNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Update a specific Site ACL. */
export declare const updateSiteAcl: API.OperationMethod<UpdateSiteAclRequest, UpdateSiteAclResponse, UpdateSiteAclError, CloudflareOpContext>;
export type UpdateSiteLanError = SiteLanNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Update a specific Site LAN. */
export declare const updateSiteLan: API.OperationMethod<UpdateSiteLanRequest, UpdateSiteLanResponse, UpdateSiteLanError, CloudflareOpContext>;
export type UpdateSitesAppConfigurationError = CloudflareOpError;
/** Updates an App Config for a site */
export declare const updateSitesAppConfiguration: API.OperationMethod<UpdateSitesAppConfigurationRequest, UpdateSitesAppConfigurationResponse, UpdateSitesAppConfigurationError, CloudflareOpContext>;
export type UpdateSiteWanError = SiteWanNotFound | MagicWanUnauthorized | Forbidden | MagicWanNotEnabled | CloudflareOpError;
/** Update a specific Site WAN. */
export declare const updateSiteWan: API.OperationMethod<UpdateSiteWanRequest, UpdateSiteWanResponse, UpdateSiteWanError, CloudflareOpContext>;
export type ValidatePcapOwnershipError = CloudflareOpError;
/** Validates buckets added to the packet captures API. */
export declare const validatePcapOwnership: API.OperationMethod<ValidatePcapOwnershipRequest, ValidatePcapOwnershipResponse, ValidatePcapOwnershipError, CloudflareOpContext>;
//# sourceMappingURL=magic_transit.d.ts.map