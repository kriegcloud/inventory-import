import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface VariableEntry {
    name?: string | undefined;
    dataType?: string | undefined;
    dataSource?: string | undefined;
    defaultValue?: string | undefined;
    description?: string | undefined;
    variableType?: string | undefined;
}
export type VariableEntryList = VariableEntry[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface BatchCreateVariableRequest {
    variableEntries: VariableEntry[];
    tags?: Tag[] | undefined;
}
export type Integer2 = number;
export interface BatchCreateVariableError_ {
    name?: string | undefined;
    code?: number | undefined;
    message?: string | undefined;
}
export type BatchCreateVariableErrorList = BatchCreateVariableError_[];
export interface BatchCreateVariableResult {
    errors?: BatchCreateVariableError_[] | undefined;
}
export type NameList = string[];
export interface BatchGetVariableRequest {
    names: string[];
}
export type DataType = "STRING" | "INTEGER" | "FLOAT" | "BOOLEAN" | "DATETIME" | (string & {});
export type DataSource = "EVENT" | "MODEL_SCORE" | "EXTERNAL_MODEL_SCORE" | (string & {});
export type FraudDetectorArn = string;
export interface Variable {
    name?: string | undefined;
    dataType?: DataType | undefined;
    dataSource?: DataSource | undefined;
    defaultValue?: string | undefined;
    description?: string | undefined;
    variableType?: string | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
}
export type VariableList = Variable[];
export interface BatchGetVariableError_ {
    name?: string | undefined;
    code?: number | undefined;
    message?: string | undefined;
}
export type BatchGetVariableErrorList = BatchGetVariableError_[];
export interface BatchGetVariableResult {
    variables?: Variable[] | undefined;
    errors?: BatchGetVariableError_[] | undefined;
}
export type Identifier = string;
export interface CancelBatchImportJobRequest {
    jobId: string;
}
export interface CancelBatchImportJobResult {
}
export interface CancelBatchPredictionJobRequest {
    jobId: string;
}
export interface CancelBatchPredictionJobResult {
}
export type S3BucketLocation = string;
export type IamRoleArn = string;
export interface CreateBatchImportJobRequest {
    jobId: string;
    inputPath: string;
    outputPath: string;
    eventTypeName: string;
    iamRoleArn: string;
    tags?: Tag[] | undefined;
}
export interface CreateBatchImportJobResult {
}
export type WholeNumberVersionString = string;
export interface CreateBatchPredictionJobRequest {
    jobId: string;
    inputPath: string;
    outputPath: string;
    eventTypeName: string;
    detectorName: string;
    detectorVersion?: string | undefined;
    iamRoleArn: string;
    tags?: Tag[] | undefined;
}
export interface CreateBatchPredictionJobResult {
}
export type Description = string;
export type ListOfStrings = string[];
export interface Rule {
    detectorId: string;
    ruleId: string;
    ruleVersion: string;
}
export type RuleList = Rule[];
export type ModelIdentifier = string;
export type ModelTypeEnum = "ONLINE_FRAUD_INSIGHTS" | "TRANSACTION_FRAUD_INSIGHTS" | "ACCOUNT_TAKEOVER_INSIGHTS" | (string & {});
export type FloatVersionString = string;
export interface ModelVersion {
    modelId: string;
    modelType: ModelTypeEnum;
    modelVersionNumber: string;
    arn?: string | undefined;
}
export type ListOfModelVersions = ModelVersion[];
export type RuleExecutionMode = "ALL_MATCHED" | "FIRST_MATCHED" | (string & {});
export interface CreateDetectorVersionRequest {
    detectorId: string;
    description?: string | undefined;
    externalModelEndpoints?: string[] | undefined;
    rules: Rule[];
    modelVersions?: ModelVersion[] | undefined;
    ruleExecutionMode?: RuleExecutionMode | undefined;
    tags?: Tag[] | undefined;
}
export type DetectorVersionStatus = "DRAFT" | "ACTIVE" | "INACTIVE" | (string & {});
export interface CreateDetectorVersionResult {
    detectorId?: string | undefined;
    detectorVersionId?: string | undefined;
    status?: DetectorVersionStatus | undefined;
}
export type NoDashIdentifier = string;
export type Elements = string | redacted.Redacted<string>;
export type ElementsList = (string | redacted.Redacted<string>)[];
export type VariableType = string;
export interface CreateListRequest {
    name: string;
    elements?: (string | redacted.Redacted<string>)[] | undefined;
    variableType?: string | undefined;
    description?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateListResult {
}
export interface CreateModelRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    description?: string | undefined;
    eventTypeName: string;
    tags?: Tag[] | undefined;
}
export interface CreateModelResult {
}
export type TrainingDataSourceEnum = "EXTERNAL_EVENTS" | "INGESTED_EVENTS" | (string & {});
export type LabelMapper = {
    [key: string]: string[] | undefined;
};
export type UnlabeledEventsTreatment = "IGNORE" | "FRAUD" | "LEGIT" | "AUTO" | (string & {});
export interface LabelSchema {
    labelMapper?: {
        [key: string]: string[] | undefined;
    } | undefined;
    unlabeledEventsTreatment?: UnlabeledEventsTreatment | undefined;
}
export interface TrainingDataSchema {
    modelVariables: string[];
    labelSchema?: LabelSchema | undefined;
}
export interface ExternalEventsDetail {
    dataLocation: string;
    dataAccessRoleArn: string;
}
export interface IngestedEventsTimeWindow {
    startTime: string;
    endTime: string;
}
export interface IngestedEventsDetail {
    ingestedEventsTimeWindow: IngestedEventsTimeWindow;
}
export interface CreateModelVersionRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    trainingDataSource: TrainingDataSourceEnum;
    trainingDataSchema: TrainingDataSchema;
    externalEventsDetail?: ExternalEventsDetail | undefined;
    ingestedEventsDetail?: IngestedEventsDetail | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateModelVersionResult {
    modelId?: string | undefined;
    modelType?: ModelTypeEnum | undefined;
    modelVersionNumber?: string | undefined;
    status?: string | undefined;
}
export type RuleExpression = string | redacted.Redacted<string>;
export type Language = "DETECTORPL" | (string & {});
export type NonEmptyListOfStrings = string[];
export interface CreateRuleRequest {
    ruleId: string;
    detectorId: string;
    description?: string | undefined;
    expression: string | redacted.Redacted<string>;
    language: Language;
    outcomes: string[];
    tags?: Tag[] | undefined;
}
export interface CreateRuleResult {
    rule?: Rule | undefined;
}
export interface CreateVariableRequest {
    name: string;
    dataType: DataType;
    dataSource: DataSource;
    defaultValue: string;
    description?: string | undefined;
    variableType?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateVariableResult {
}
export interface DeleteBatchImportJobRequest {
    jobId: string;
}
export interface DeleteBatchImportJobResult {
}
export interface DeleteBatchPredictionJobRequest {
    jobId: string;
}
export interface DeleteBatchPredictionJobResult {
}
export interface DeleteDetectorRequest {
    detectorId: string;
}
export interface DeleteDetectorResult {
}
export interface DeleteDetectorVersionRequest {
    detectorId: string;
    detectorVersionId: string;
}
export interface DeleteDetectorVersionResult {
}
export interface DeleteEntityTypeRequest {
    name: string;
}
export interface DeleteEntityTypeResult {
}
export type DeleteAuditHistory = boolean;
export interface DeleteEventRequest {
    eventId: string;
    eventTypeName: string;
    deleteAuditHistory?: boolean | undefined;
}
export interface DeleteEventResult {
}
export interface DeleteEventsByEventTypeRequest {
    eventTypeName: string;
}
export interface DeleteEventsByEventTypeResult {
    eventTypeName?: string | undefined;
    eventsDeletionStatus?: string | undefined;
}
export interface DeleteEventTypeRequest {
    name: string;
}
export interface DeleteEventTypeResult {
}
export type SageMakerEndpointIdentifier = string;
export interface DeleteExternalModelRequest {
    modelEndpoint: string;
}
export interface DeleteExternalModelResult {
}
export interface DeleteLabelRequest {
    name: string;
}
export interface DeleteLabelResult {
}
export interface DeleteListRequest {
    name: string;
}
export interface DeleteListResult {
}
export interface DeleteModelRequest {
    modelId: string;
    modelType: ModelTypeEnum;
}
export interface DeleteModelResult {
}
export interface DeleteModelVersionRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    modelVersionNumber: string;
}
export interface DeleteModelVersionResult {
}
export interface DeleteOutcomeRequest {
    name: string;
}
export interface DeleteOutcomeResult {
}
export interface DeleteRuleRequest {
    rule: Rule;
}
export interface DeleteRuleResult {
}
export interface DeleteVariableRequest {
    name: string;
}
export interface DeleteVariableResult {
}
export type DetectorVersionMaxResults = number;
export interface DescribeDetectorRequest {
    detectorId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DetectorVersionSummary {
    detectorVersionId?: string | undefined;
    status?: DetectorVersionStatus | undefined;
    description?: string | undefined;
    lastUpdatedTime?: string | undefined;
}
export type DetectorVersionSummaryList = DetectorVersionSummary[];
export interface DescribeDetectorResult {
    detectorId?: string | undefined;
    detectorVersionSummaries?: DetectorVersionSummary[] | undefined;
    nextToken?: string | undefined;
    arn?: string | undefined;
}
export type ModelsMaxPageSize = number;
export interface DescribeModelVersionsRequest {
    modelId?: string | undefined;
    modelVersionNumber?: string | undefined;
    modelType?: ModelTypeEnum | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface FileValidationMessage {
    title?: string | undefined;
    content?: string | undefined;
    type?: string | undefined;
}
export type FileValidationMessageList = FileValidationMessage[];
export interface FieldValidationMessage {
    fieldName?: string | undefined;
    identifier?: string | undefined;
    title?: string | undefined;
    content?: string | undefined;
    type?: string | undefined;
}
export type FieldValidationMessageList = FieldValidationMessage[];
export interface DataValidationMetrics {
    fileLevelMessages?: FileValidationMessage[] | undefined;
    fieldLevelMessages?: FieldValidationMessage[] | undefined;
}
export interface MetricDataPoint {
    fpr?: number | undefined;
    precision?: number | undefined;
    tpr?: number | undefined;
    threshold?: number | undefined;
}
export type MetricDataPointsList = MetricDataPoint[];
export interface TrainingMetrics {
    auc?: number | undefined;
    metricDataPoints?: MetricDataPoint[] | undefined;
}
export interface LogOddsMetric {
    variableName: string;
    variableType: string;
    variableImportance: number;
}
export type ListOfLogOddsMetrics = LogOddsMetric[];
export interface VariableImportanceMetrics {
    logOddsMetrics?: LogOddsMetric[] | undefined;
}
export interface TrainingResult {
    dataValidationMetrics?: DataValidationMetrics | undefined;
    trainingMetrics?: TrainingMetrics | undefined;
    variableImportanceMetrics?: VariableImportanceMetrics | undefined;
}
export interface OFIMetricDataPoint {
    fpr?: number | undefined;
    precision?: number | undefined;
    tpr?: number | undefined;
    threshold?: number | undefined;
}
export type OFIMetricDataPointsList = OFIMetricDataPoint[];
export interface UncertaintyRange {
    lowerBoundValue: number;
    upperBoundValue: number;
}
export interface OFIModelPerformance {
    auc?: number | undefined;
    uncertaintyRange?: UncertaintyRange | undefined;
}
export interface OFITrainingMetricsValue {
    metricDataPoints?: OFIMetricDataPoint[] | undefined;
    modelPerformance?: OFIModelPerformance | undefined;
}
export interface TFIMetricDataPoint {
    fpr?: number | undefined;
    precision?: number | undefined;
    tpr?: number | undefined;
    threshold?: number | undefined;
}
export type TFIMetricDataPointsList = TFIMetricDataPoint[];
export interface TFIModelPerformance {
    auc?: number | undefined;
    uncertaintyRange?: UncertaintyRange | undefined;
}
export interface TFITrainingMetricsValue {
    metricDataPoints?: TFIMetricDataPoint[] | undefined;
    modelPerformance?: TFIModelPerformance | undefined;
}
export interface ATIMetricDataPoint {
    cr?: number | undefined;
    adr?: number | undefined;
    threshold?: number | undefined;
    atodr?: number | undefined;
}
export type ATIMetricDataPointsList = ATIMetricDataPoint[];
export interface ATIModelPerformance {
    asi?: number | undefined;
}
export interface ATITrainingMetricsValue {
    metricDataPoints?: ATIMetricDataPoint[] | undefined;
    modelPerformance?: ATIModelPerformance | undefined;
}
export interface TrainingMetricsV2 {
    ofi?: OFITrainingMetricsValue | undefined;
    tfi?: TFITrainingMetricsValue | undefined;
    ati?: ATITrainingMetricsValue | undefined;
}
export interface AggregatedLogOddsMetric {
    variableNames: string[];
    aggregatedVariablesImportance: number;
}
export type ListOfAggregatedLogOddsMetrics = AggregatedLogOddsMetric[];
export interface AggregatedVariablesImportanceMetrics {
    logOddsMetrics?: AggregatedLogOddsMetric[] | undefined;
}
export interface TrainingResultV2 {
    dataValidationMetrics?: DataValidationMetrics | undefined;
    trainingMetricsV2?: TrainingMetricsV2 | undefined;
    variableImportanceMetrics?: VariableImportanceMetrics | undefined;
    aggregatedVariablesImportanceMetrics?: AggregatedVariablesImportanceMetrics | undefined;
}
export interface ModelVersionDetail {
    modelId?: string | undefined;
    modelType?: ModelTypeEnum | undefined;
    modelVersionNumber?: string | undefined;
    status?: string | undefined;
    trainingDataSource?: TrainingDataSourceEnum | undefined;
    trainingDataSchema?: TrainingDataSchema | undefined;
    externalEventsDetail?: ExternalEventsDetail | undefined;
    ingestedEventsDetail?: IngestedEventsDetail | undefined;
    trainingResult?: TrainingResult | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
    trainingResultV2?: TrainingResultV2 | undefined;
}
export type ModelVersionDetailList = ModelVersionDetail[];
export interface DescribeModelVersionsResult {
    modelVersionDetails?: ModelVersionDetail[] | undefined;
    nextToken?: string | undefined;
}
export type BatchImportsMaxPageSize = number;
export interface GetBatchImportJobsRequest {
    jobId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AsyncJobStatus = "IN_PROGRESS_INITIALIZING" | "IN_PROGRESS" | "CANCEL_IN_PROGRESS" | "CANCELED" | "COMPLETE" | "FAILED" | (string & {});
export interface BatchImport {
    jobId?: string | undefined;
    status?: AsyncJobStatus | undefined;
    failureReason?: string | undefined;
    startTime?: string | undefined;
    completionTime?: string | undefined;
    inputPath?: string | undefined;
    outputPath?: string | undefined;
    eventTypeName?: string | undefined;
    iamRoleArn?: string | undefined;
    arn?: string | undefined;
    processedRecordsCount?: number | undefined;
    failedRecordsCount?: number | undefined;
    totalRecordsCount?: number | undefined;
}
export type BatchImportList = BatchImport[];
export interface GetBatchImportJobsResult {
    batchImports?: BatchImport[] | undefined;
    nextToken?: string | undefined;
}
export type BatchPredictionsMaxPageSize = number;
export interface GetBatchPredictionJobsRequest {
    jobId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BatchPrediction {
    jobId?: string | undefined;
    status?: AsyncJobStatus | undefined;
    failureReason?: string | undefined;
    startTime?: string | undefined;
    completionTime?: string | undefined;
    lastHeartbeatTime?: string | undefined;
    inputPath?: string | undefined;
    outputPath?: string | undefined;
    eventTypeName?: string | undefined;
    detectorName?: string | undefined;
    detectorVersion?: string | undefined;
    iamRoleArn?: string | undefined;
    arn?: string | undefined;
    processedRecordsCount?: number | undefined;
    totalRecordsCount?: number | undefined;
}
export type BatchPredictionList = BatchPrediction[];
export interface GetBatchPredictionJobsResult {
    batchPredictions?: BatchPrediction[] | undefined;
    nextToken?: string | undefined;
}
export interface GetDeleteEventsByEventTypeStatusRequest {
    eventTypeName: string;
}
export interface GetDeleteEventsByEventTypeStatusResult {
    eventTypeName?: string | undefined;
    eventsDeletionStatus?: AsyncJobStatus | undefined;
}
export type DetectorsMaxResults = number;
export interface GetDetectorsRequest {
    detectorId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Detector {
    detectorId?: string | undefined;
    description?: string | undefined;
    eventTypeName?: string | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
}
export type DetectorList = Detector[];
export interface GetDetectorsResult {
    detectors?: Detector[] | undefined;
    nextToken?: string | undefined;
}
export interface GetDetectorVersionRequest {
    detectorId: string;
    detectorVersionId: string;
}
export interface GetDetectorVersionResult {
    detectorId?: string | undefined;
    detectorVersionId?: string | undefined;
    description?: string | undefined;
    externalModelEndpoints?: string[] | undefined;
    modelVersions?: ModelVersion[] | undefined;
    rules?: Rule[] | undefined;
    status?: DetectorVersionStatus | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    ruleExecutionMode?: RuleExecutionMode | undefined;
    arn?: string | undefined;
}
export type EntityTypesMaxResults = number;
export interface GetEntityTypesRequest {
    name?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface EntityType {
    name?: string | undefined;
    description?: string | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
}
export type EntityTypeList = EntityType[];
export interface GetEntityTypesResult {
    entityTypes?: EntityType[] | undefined;
    nextToken?: string | undefined;
}
export interface GetEventRequest {
    eventId: string;
    eventTypeName: string;
}
export type AttributeKey = string;
export type AttributeValue = string | redacted.Redacted<string>;
export type EventAttributeMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type EntityRestrictedString = string;
export interface Entity {
    entityType: string;
    entityId: string;
}
export type ListOfEntities = Entity[];
export interface Event {
    eventId?: string | undefined;
    eventTypeName?: string | undefined;
    eventTimestamp?: string | undefined;
    eventVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    currentLabel?: string | undefined;
    labelTimestamp?: string | undefined;
    entities?: Entity[] | undefined;
}
export interface GetEventResult {
    event?: Event | undefined;
}
export type UtcTimestampISO8601 = string;
export type VariableName = string;
export type VariableValue = string | redacted.Redacted<string>;
export type EventVariableMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type ContentType = string;
export interface ModelEndpointDataBlob {
    byteBuffer?: Uint8Array | undefined;
    contentType?: string | undefined;
}
export type ExternalModelEndpointDataBlobMap = {
    [key: string]: ModelEndpointDataBlob | undefined;
};
export interface GetEventPredictionRequest {
    detectorId: string;
    detectorVersionId?: string | undefined;
    eventId: string;
    eventTypeName: string;
    entities: Entity[];
    eventTimestamp: string;
    eventVariables: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    externalModelEndpointDataBlobs?: {
        [key: string]: ModelEndpointDataBlob | undefined;
    } | undefined;
}
export type ModelPredictionMap = {
    [key: string]: number | undefined;
};
export interface ModelScores {
    modelVersion?: ModelVersion | undefined;
    scores?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type ListOfModelScores = ModelScores[];
export interface RuleResult {
    ruleId?: string | undefined;
    outcomes?: string[] | undefined;
}
export type ListOfRuleResults = RuleResult[];
export type ModelSource = "SAGEMAKER" | (string & {});
export interface ExternalModelSummary {
    modelEndpoint?: string | undefined;
    modelSource?: ModelSource | undefined;
}
export type ExternalModelPredictionMap = {
    [key: string]: string | undefined;
};
export interface ExternalModelOutputs {
    externalModel?: ExternalModelSummary | undefined;
    outputs?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListOfExternalModelOutputs = ExternalModelOutputs[];
export interface GetEventPredictionResult {
    modelScores?: ModelScores[] | undefined;
    ruleResults?: RuleResult[] | undefined;
    externalModelOutputs?: ExternalModelOutputs[] | undefined;
}
export interface GetEventPredictionMetadataRequest {
    eventId: string;
    eventTypeName: string;
    detectorId: string;
    detectorVersionId: string;
    predictionTimestamp: string;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface EventVariableSummary {
    name?: string | redacted.Redacted<string> | undefined;
    value?: string | redacted.Redacted<string> | undefined;
    source?: string | redacted.Redacted<string> | undefined;
}
export type ListOfEventVariableSummaries = EventVariableSummary[];
export interface EvaluatedRule {
    ruleId?: string | undefined;
    ruleVersion?: string | undefined;
    expression?: string | redacted.Redacted<string> | undefined;
    expressionWithValues?: string | redacted.Redacted<string> | undefined;
    outcomes?: string[] | undefined;
    evaluated?: boolean | undefined;
    matched?: boolean | undefined;
}
export type EvaluatedRuleList = EvaluatedRule[];
export interface VariableImpactExplanation {
    eventVariableName?: string | undefined;
    relativeImpact?: string | undefined;
    logOddsImpact?: number | undefined;
}
export type ListOfVariableImpactExplanations = VariableImpactExplanation[];
export interface AggregatedVariablesImpactExplanation {
    eventVariableNames?: string[] | undefined;
    relativeImpact?: string | undefined;
    logOddsImpact?: number | undefined;
}
export type ListOfAggregatedVariablesImpactExplanations = AggregatedVariablesImpactExplanation[];
export interface PredictionExplanations {
    variableImpactExplanations?: VariableImpactExplanation[] | undefined;
    aggregatedVariablesImpactExplanations?: AggregatedVariablesImpactExplanation[] | undefined;
}
export interface ModelVersionEvaluation {
    outputVariableName?: string | undefined;
    evaluationScore?: string | undefined;
    predictionExplanations?: PredictionExplanations | undefined;
}
export type ListOfModelVersionEvaluations = ModelVersionEvaluation[];
export interface EvaluatedModelVersion {
    modelId?: string | undefined;
    modelVersion?: string | undefined;
    modelType?: string | undefined;
    evaluations?: ModelVersionEvaluation[] | undefined;
}
export type ListOfEvaluatedModelVersions = EvaluatedModelVersion[];
export type MapOfStrings = {
    [key: string]: string | undefined;
};
export interface EvaluatedExternalModel {
    modelEndpoint?: string | undefined;
    useEventVariables?: boolean | undefined;
    inputVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    outputVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListOfEvaluatedExternalModels = EvaluatedExternalModel[];
export interface GetEventPredictionMetadataResult {
    eventId?: string | undefined;
    eventTypeName?: string | undefined;
    entityId?: string | undefined;
    entityType?: string | undefined;
    eventTimestamp?: string | undefined;
    detectorId?: string | undefined;
    detectorVersionId?: string | undefined;
    detectorVersionStatus?: string | undefined;
    eventVariables?: EventVariableSummary[] | undefined;
    rules?: EvaluatedRule[] | undefined;
    ruleExecutionMode?: RuleExecutionMode | undefined;
    outcomes?: string[] | undefined;
    evaluatedModelVersions?: EvaluatedModelVersion[] | undefined;
    evaluatedExternalModels?: EvaluatedExternalModel[] | undefined;
    predictionTimestamp?: string | undefined;
}
export type EventTypesMaxResults = number;
export interface GetEventTypesRequest {
    name?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type EventIngestion = "ENABLED" | "DISABLED" | (string & {});
export interface IngestedEventStatistics {
    numberOfEvents?: number | undefined;
    eventDataSizeInBytes?: number | undefined;
    leastRecentEvent?: string | undefined;
    mostRecentEvent?: string | undefined;
    lastUpdatedTime?: string | undefined;
}
export interface EventOrchestration {
    eventBridgeEnabled: boolean;
}
export interface EventType {
    name?: string | undefined;
    description?: string | undefined;
    eventVariables?: string[] | undefined;
    labels?: string[] | undefined;
    entityTypes?: string[] | undefined;
    eventIngestion?: EventIngestion | undefined;
    ingestedEventStatistics?: IngestedEventStatistics | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
    eventOrchestration?: EventOrchestration | undefined;
}
export type EventTypeList = EventType[];
export interface GetEventTypesResult {
    eventTypes?: EventType[] | undefined;
    nextToken?: string | undefined;
}
export type ExternalModelsMaxResults = number;
export interface GetExternalModelsRequest {
    modelEndpoint?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ModelInputDataFormat = "TEXT_CSV" | "APPLICATION_JSON" | (string & {});
export type UseEventVariables = boolean;
export type ModelInputTemplate = string;
export interface ModelInputConfiguration {
    eventTypeName?: string | undefined;
    format?: ModelInputDataFormat | undefined;
    useEventVariables: boolean;
    jsonInputTemplate?: string | undefined;
    csvInputTemplate?: string | undefined;
}
export type ModelOutputDataFormat = "TEXT_CSV" | "APPLICATION_JSONLINES" | (string & {});
export type JsonKeyToVariableMap = {
    [key: string]: string | undefined;
};
export type CsvIndexToVariableMap = {
    [key: string]: string | undefined;
};
export interface ModelOutputConfiguration {
    format: ModelOutputDataFormat;
    jsonKeyToVariableMap?: {
        [key: string]: string | undefined;
    } | undefined;
    csvIndexToVariableMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ModelEndpointStatus = "ASSOCIATED" | "DISSOCIATED" | (string & {});
export interface ExternalModel {
    modelEndpoint?: string | undefined;
    modelSource?: ModelSource | undefined;
    invokeModelEndpointRoleArn?: string | undefined;
    inputConfiguration?: ModelInputConfiguration | undefined;
    outputConfiguration?: ModelOutputConfiguration | undefined;
    modelEndpointStatus?: ModelEndpointStatus | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
}
export type ExternalModelList = ExternalModel[];
export interface GetExternalModelsResult {
    externalModels?: ExternalModel[] | undefined;
    nextToken?: string | undefined;
}
export interface GetKMSEncryptionKeyRequest {
}
export type KmsEncryptionKeyArn = string;
export interface KMSKey {
    kmsEncryptionKeyArn?: string | undefined;
}
export interface GetKMSEncryptionKeyResult {
    kmsKey?: KMSKey | undefined;
}
export type LabelsMaxResults = number;
export interface GetLabelsRequest {
    name?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Label {
    name?: string | undefined;
    description?: string | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
}
export type LabelList = Label[];
export interface GetLabelsResult {
    labels?: Label[] | undefined;
    nextToken?: string | undefined;
}
export type NextToken = string;
export type ListsElementsMaxResults = number;
export interface GetListElementsRequest {
    name: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface GetListElementsResult {
    elements?: (string | redacted.Redacted<string>)[] | undefined;
    nextToken?: string | undefined;
}
export type ListsMetadataMaxResults = number;
export interface GetListsMetadataRequest {
    name?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AllowDenyList {
    name: string;
    description?: string | undefined;
    variableType?: string | undefined;
    createdTime?: string | undefined;
    updatedTime?: string | undefined;
    arn?: string | undefined;
}
export type AllowDenyLists = AllowDenyList[];
export interface GetListsMetadataResult {
    lists?: AllowDenyList[] | undefined;
    nextToken?: string | undefined;
}
export interface GetModelsRequest {
    modelId?: string | undefined;
    modelType?: ModelTypeEnum | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Model {
    modelId?: string | undefined;
    modelType?: ModelTypeEnum | undefined;
    description?: string | undefined;
    eventTypeName?: string | undefined;
    createdTime?: string | undefined;
    lastUpdatedTime?: string | undefined;
    arn?: string | undefined;
}
export type ModelList = Model[];
export interface GetModelsResult {
    nextToken?: string | undefined;
    models?: Model[] | undefined;
}
export interface GetModelVersionRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    modelVersionNumber: string;
}
export interface GetModelVersionResult {
    modelId?: string | undefined;
    modelType?: ModelTypeEnum | undefined;
    modelVersionNumber?: string | undefined;
    trainingDataSource?: TrainingDataSourceEnum | undefined;
    trainingDataSchema?: TrainingDataSchema | undefined;
    externalEventsDetail?: ExternalEventsDetail | undefined;
    ingestedEventsDetail?: IngestedEventsDetail | undefined;
    status?: string | undefined;
    arn?: string | undefined;
}
export type OutcomesMaxResults = number;
export interface GetOutcomesRequest {
    name?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Outcome {
    name?: string | undefined;
    description?: string | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
}
export type OutcomeList = Outcome[];
export interface GetOutcomesResult {
    outcomes?: Outcome[] | undefined;
    nextToken?: string | undefined;
}
export type RulesMaxResults = number;
export interface GetRulesRequest {
    ruleId?: string | undefined;
    detectorId: string;
    ruleVersion?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface RuleDetail {
    ruleId?: string | undefined;
    description?: string | undefined;
    detectorId?: string | undefined;
    ruleVersion?: string | undefined;
    expression?: string | redacted.Redacted<string> | undefined;
    language?: Language | undefined;
    outcomes?: string[] | undefined;
    lastUpdatedTime?: string | undefined;
    createdTime?: string | undefined;
    arn?: string | undefined;
}
export type RuleDetailList = RuleDetail[];
export interface GetRulesResult {
    ruleDetails?: RuleDetail[] | undefined;
    nextToken?: string | undefined;
}
export type VariablesMaxResults = number;
export interface GetVariablesRequest {
    name?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface GetVariablesResult {
    variables?: Variable[] | undefined;
    nextToken?: string | undefined;
}
export type FilterString = string;
export interface FilterCondition {
    value?: string | undefined;
}
export interface PredictionTimeRange {
    startTime: string;
    endTime: string;
}
export type EventPredictionsMaxResults = number;
export interface ListEventPredictionsRequest {
    eventId?: FilterCondition | undefined;
    eventType?: FilterCondition | undefined;
    detectorId?: FilterCondition | undefined;
    detectorVersionId?: FilterCondition | undefined;
    predictionTimeRange?: PredictionTimeRange | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface EventPredictionSummary {
    eventId?: string | undefined;
    eventTypeName?: string | undefined;
    eventTimestamp?: string | undefined;
    predictionTimestamp?: string | undefined;
    detectorId?: string | undefined;
    detectorVersionId?: string | undefined;
}
export type ListOfEventPredictionSummaries = EventPredictionSummary[];
export interface ListEventPredictionsResult {
    eventPredictionSummaries?: EventPredictionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type TagsMaxResults = number;
export interface ListTagsForResourceRequest {
    resourceARN: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListTagsForResourceResult {
    tags?: Tag[] | undefined;
    nextToken?: string | undefined;
}
export interface PutDetectorRequest {
    detectorId: string;
    description?: string | undefined;
    eventTypeName: string;
    tags?: Tag[] | undefined;
}
export interface PutDetectorResult {
}
export interface PutEntityTypeRequest {
    name: string;
    description?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface PutEntityTypeResult {
}
export interface PutEventTypeRequest {
    name: string;
    description?: string | undefined;
    eventVariables: string[];
    labels?: string[] | undefined;
    entityTypes: string[];
    eventIngestion?: EventIngestion | undefined;
    tags?: Tag[] | undefined;
    eventOrchestration?: EventOrchestration | undefined;
}
export interface PutEventTypeResult {
}
export interface PutExternalModelRequest {
    modelEndpoint: string;
    modelSource: ModelSource;
    invokeModelEndpointRoleArn: string;
    inputConfiguration: ModelInputConfiguration;
    outputConfiguration: ModelOutputConfiguration;
    modelEndpointStatus: ModelEndpointStatus;
    tags?: Tag[] | undefined;
}
export interface PutExternalModelResult {
}
export interface PutKMSEncryptionKeyRequest {
    kmsEncryptionKeyArn: string;
}
export interface PutKMSEncryptionKeyResult {
}
export interface PutLabelRequest {
    name: string;
    description?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface PutLabelResult {
}
export interface PutOutcomeRequest {
    name: string;
    description?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface PutOutcomeResult {
}
export interface SendEventRequest {
    eventId: string;
    eventTypeName: string;
    eventTimestamp: string;
    eventVariables: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    assignedLabel?: string | undefined;
    labelTimestamp?: string | undefined;
    entities: Entity[];
}
export interface SendEventResult {
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export interface TagResourceResult {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResult {
}
export interface UpdateDetectorVersionRequest {
    detectorId: string;
    detectorVersionId: string;
    externalModelEndpoints: string[];
    rules: Rule[];
    description?: string | undefined;
    modelVersions?: ModelVersion[] | undefined;
    ruleExecutionMode?: RuleExecutionMode | undefined;
}
export interface UpdateDetectorVersionResult {
}
export interface UpdateDetectorVersionMetadataRequest {
    detectorId: string;
    detectorVersionId: string;
    description: string;
}
export interface UpdateDetectorVersionMetadataResult {
}
export interface UpdateDetectorVersionStatusRequest {
    detectorId: string;
    detectorVersionId: string;
    status: DetectorVersionStatus;
}
export interface UpdateDetectorVersionStatusResult {
}
export interface UpdateEventLabelRequest {
    eventId: string;
    eventTypeName: string;
    assignedLabel: string;
    labelTimestamp: string;
}
export interface UpdateEventLabelResult {
}
export type ListUpdateMode = "REPLACE" | "APPEND" | "REMOVE" | (string & {});
export interface UpdateListRequest {
    name: string;
    elements?: (string | redacted.Redacted<string>)[] | undefined;
    description?: string | undefined;
    updateMode?: ListUpdateMode | undefined;
    variableType?: string | undefined;
}
export interface UpdateListResult {
}
export interface UpdateModelRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    description?: string | undefined;
}
export interface UpdateModelResult {
}
export interface UpdateModelVersionRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    majorVersionNumber: string;
    externalEventsDetail?: ExternalEventsDetail | undefined;
    ingestedEventsDetail?: IngestedEventsDetail | undefined;
    tags?: Tag[] | undefined;
}
export interface UpdateModelVersionResult {
    modelId?: string | undefined;
    modelType?: ModelTypeEnum | undefined;
    modelVersionNumber?: string | undefined;
    status?: string | undefined;
}
export type ModelVersionStatus = "ACTIVE" | "INACTIVE" | "TRAINING_CANCELLED" | (string & {});
export interface UpdateModelVersionStatusRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    modelVersionNumber: string;
    status: ModelVersionStatus;
}
export interface UpdateModelVersionStatusResult {
}
export interface UpdateRuleMetadataRequest {
    rule: Rule;
    description: string;
}
export interface UpdateRuleMetadataResult {
}
export interface UpdateRuleVersionRequest {
    rule: Rule;
    description?: string | undefined;
    expression: string | redacted.Redacted<string>;
    language: Language;
    outcomes: string[];
    tags?: Tag[] | undefined;
}
export interface UpdateRuleVersionResult {
    rule?: Rule | undefined;
}
export interface UpdateVariableRequest {
    name: string;
    defaultValue?: string | undefined;
    description?: string | undefined;
    variableType?: string | undefined;
}
export interface UpdateVariableResult {
}
export type BatchCreateVariableError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a batch of variables.
 */
export declare const batchCreateVariable: API.OperationMethod<BatchCreateVariableRequest & RegionInput, BatchCreateVariableResult, BatchCreateVariableError, Credentials | HttpClient.HttpClient>;
export type BatchGetVariableError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a batch of variables.
 */
export declare const batchGetVariable: API.OperationMethod<BatchGetVariableRequest & RegionInput, BatchGetVariableResult, BatchGetVariableError, Credentials | HttpClient.HttpClient>;
export type CancelBatchImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels an in-progress batch import job.
 */
export declare const cancelBatchImportJob: API.OperationMethod<CancelBatchImportJobRequest & RegionInput, CancelBatchImportJobResult, CancelBatchImportJobError, Credentials | HttpClient.HttpClient>;
export type CancelBatchPredictionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the specified batch prediction job.
 */
export declare const cancelBatchPredictionJob: API.OperationMethod<CancelBatchPredictionJobRequest & RegionInput, CancelBatchPredictionJobResult, CancelBatchPredictionJobError, Credentials | HttpClient.HttpClient>;
export type CreateBatchImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a batch import job.
 */
export declare const createBatchImportJob: API.OperationMethod<CreateBatchImportJobRequest & RegionInput, CreateBatchImportJobResult, CreateBatchImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateBatchPredictionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a batch prediction job.
 */
export declare const createBatchPredictionJob: API.OperationMethod<CreateBatchPredictionJobRequest & RegionInput, CreateBatchPredictionJobResult, CreateBatchPredictionJobError, Credentials | HttpClient.HttpClient>;
export type CreateDetectorVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a detector version. The detector version starts in a `DRAFT` status.
 */
export declare const createDetectorVersion: API.OperationMethod<CreateDetectorVersionRequest & RegionInput, CreateDetectorVersionResult, CreateDetectorVersionError, Credentials | HttpClient.HttpClient>;
export type CreateListError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a list.
 *
 * List is a set of input data for a variable in your event dataset. You use the input data in a rule that's associated with your detector.
 * For more information, see Lists.
 */
export declare const createList: API.OperationMethod<CreateListRequest & RegionInput, CreateListResult, CreateListError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a model using the specified model type.
 */
export declare const createModel: API.OperationMethod<CreateModelRequest & RegionInput, CreateModelResult, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreateModelVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a version of the model using the specified model type and model id.
 */
export declare const createModelVersion: API.OperationMethod<CreateModelVersionRequest & RegionInput, CreateModelVersionResult, CreateModelVersionError, Credentials | HttpClient.HttpClient>;
export type CreateRuleError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a rule for use with the specified detector.
 */
export declare const createRule: API.OperationMethod<CreateRuleRequest & RegionInput, CreateRuleResult, CreateRuleError, Credentials | HttpClient.HttpClient>;
export type CreateVariableError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a variable.
 */
export declare const createVariable: API.OperationMethod<CreateVariableRequest & RegionInput, CreateVariableResult, CreateVariableError, Credentials | HttpClient.HttpClient>;
export type DeleteBatchImportJobError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified batch import job ID record. This action does not delete the data that was batch imported.
 */
export declare const deleteBatchImportJob: API.OperationMethod<DeleteBatchImportJobRequest & RegionInput, DeleteBatchImportJobResult, DeleteBatchImportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteBatchPredictionJobError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a batch prediction job.
 */
export declare const deleteBatchPredictionJob: API.OperationMethod<DeleteBatchPredictionJobRequest & RegionInput, DeleteBatchPredictionJobResult, DeleteBatchPredictionJobError, Credentials | HttpClient.HttpClient>;
export type DeleteDetectorError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the detector. Before deleting a detector, you must first delete all detector versions and rule versions associated with the detector.
 *
 * When you delete a detector, Amazon Fraud Detector permanently deletes the detector and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteDetector: API.OperationMethod<DeleteDetectorRequest & RegionInput, DeleteDetectorResult, DeleteDetectorError, Credentials | HttpClient.HttpClient>;
export type DeleteDetectorVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the detector version. You cannot delete detector versions that are in `ACTIVE` status.
 *
 * When you delete a detector version, Amazon Fraud Detector permanently deletes the detector and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteDetectorVersion: API.OperationMethod<DeleteDetectorVersionRequest & RegionInput, DeleteDetectorVersionResult, DeleteDetectorVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteEntityTypeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an entity type.
 *
 * You cannot delete an entity type that is included in an event type.
 *
 * When you delete an entity type, Amazon Fraud Detector permanently deletes that entity type and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteEntityType: API.OperationMethod<DeleteEntityTypeRequest & RegionInput, DeleteEntityTypeResult, DeleteEntityTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteEventError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified event.
 *
 * When you delete an event, Amazon Fraud Detector permanently deletes that event and the event data is no longer stored in Amazon Fraud Detector.
 * If `deleteAuditHistory` is `True`, event data is available through search for up to 30 seconds after the delete operation is completed.
 */
export declare const deleteEvent: API.OperationMethod<DeleteEventRequest & RegionInput, DeleteEventResult, DeleteEventError, Credentials | HttpClient.HttpClient>;
export type DeleteEventsByEventTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes all events of a particular event type.
 */
export declare const deleteEventsByEventType: API.OperationMethod<DeleteEventsByEventTypeRequest & RegionInput, DeleteEventsByEventTypeResult, DeleteEventsByEventTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteEventTypeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an event type.
 *
 * You cannot delete an event type that is used in a detector or a model.
 *
 * When you delete an event type, Amazon Fraud Detector permanently deletes that event type and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteEventType: API.OperationMethod<DeleteEventTypeRequest & RegionInput, DeleteEventTypeResult, DeleteEventTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteExternalModelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a SageMaker model from Amazon Fraud Detector.
 *
 * You can remove an Amazon SageMaker model if it is not associated with a detector version. Removing a SageMaker model disconnects it from Amazon Fraud Detector, but the model remains available in SageMaker.
 */
export declare const deleteExternalModel: API.OperationMethod<DeleteExternalModelRequest & RegionInput, DeleteExternalModelResult, DeleteExternalModelError, Credentials | HttpClient.HttpClient>;
export type DeleteLabelError = ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a label.
 *
 * You cannot delete labels that are included in an event type in Amazon Fraud Detector.
 *
 * You cannot delete a label assigned to an event ID. You must first delete the relevant event ID.
 *
 * When you delete a label, Amazon Fraud Detector permanently deletes that label and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteLabel: API.OperationMethod<DeleteLabelRequest & RegionInput, DeleteLabelResult, DeleteLabelError, Credentials | HttpClient.HttpClient>;
export type DeleteListError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the list, provided it is not used in a rule.
 *
 * When you delete a list, Amazon Fraud Detector permanently deletes that list and the elements in the list.
 */
export declare const deleteList: API.OperationMethod<DeleteListRequest & RegionInput, DeleteListResult, DeleteListError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a model.
 *
 * You can delete models and model versions in Amazon Fraud Detector, provided that they are not associated with a detector version.
 *
 * When you delete a model, Amazon Fraud Detector permanently deletes that model and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelRequest & RegionInput, DeleteModelResult, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeleteModelVersionError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a model version.
 *
 * You can delete models and model versions in Amazon Fraud Detector, provided that they are not associated with a detector version.
 *
 * When you delete a model version, Amazon Fraud Detector permanently deletes that model version and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteModelVersion: API.OperationMethod<DeleteModelVersionRequest & RegionInput, DeleteModelVersionResult, DeleteModelVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteOutcomeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an outcome.
 *
 * You cannot delete an outcome that is used in a rule version.
 *
 * When you delete an outcome, Amazon Fraud Detector permanently deletes that outcome and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteOutcome: API.OperationMethod<DeleteOutcomeRequest & RegionInput, DeleteOutcomeResult, DeleteOutcomeError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the rule. You cannot delete a rule if it is used by an `ACTIVE` or `INACTIVE` detector version.
 *
 * When you delete a rule, Amazon Fraud Detector permanently deletes that rule and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest & RegionInput, DeleteRuleResult, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteVariableError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a variable.
 *
 * You can't delete variables that are included in an event type in Amazon Fraud Detector.
 *
 * Amazon Fraud Detector automatically deletes model output variables and SageMaker model output variables when you delete the model. You can't delete these variables manually.
 *
 * When you delete a variable, Amazon Fraud Detector permanently deletes that variable and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteVariable: API.OperationMethod<DeleteVariableRequest & RegionInput, DeleteVariableResult, DeleteVariableError, Credentials | HttpClient.HttpClient>;
export type DescribeDetectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all versions for a specified detector.
 */
export declare const describeDetector: API.OperationMethod<DescribeDetectorRequest & RegionInput, DescribeDetectorResult, DescribeDetectorError, Credentials | HttpClient.HttpClient>;
export type DescribeModelVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all of the model versions for the specified model type or for the specified model type and model ID. You can also get details for a single, specified model version.
 */
export declare const describeModelVersions: API.PaginatedOperationMethod<DescribeModelVersionsRequest & RegionInput, DescribeModelVersionsResult, DescribeModelVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBatchImportJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all batch import jobs or a specific job of the specified ID. This is a paginated API. If you provide a null `maxResults`,
 * this action retrieves a maximum of 50 records per page. If you provide a `maxResults`, the value must be between 1 and 50.
 * To get the next page results, provide the pagination token from the `GetBatchImportJobsResponse` as part of your request.
 * A null pagination token fetches the records from the beginning.
 */
export declare const getBatchImportJobs: API.PaginatedOperationMethod<GetBatchImportJobsRequest & RegionInput, GetBatchImportJobsResult, GetBatchImportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBatchPredictionJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all batch prediction jobs or a specific job if you specify a job ID. This is a paginated API. If you provide a null maxResults, this action retrieves a maximum of 50 records per page. If you provide a maxResults, the value must be between 1 and 50. To get the next page results, provide the pagination token from the GetBatchPredictionJobsResponse as part of your request. A null pagination token fetches the records from the beginning.
 */
export declare const getBatchPredictionJobs: API.PaginatedOperationMethod<GetBatchPredictionJobsRequest & RegionInput, GetBatchPredictionJobsResult, GetBatchPredictionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDeleteEventsByEventTypeStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status of a `DeleteEventsByEventType` action.
 */
export declare const getDeleteEventsByEventTypeStatus: API.OperationMethod<GetDeleteEventsByEventTypeStatusRequest & RegionInput, GetDeleteEventsByEventTypeStatusResult, GetDeleteEventsByEventTypeStatusError, Credentials | HttpClient.HttpClient>;
export type GetDetectorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all detectors or a single detector if a `detectorId` is specified. This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 10 records
 * per page. If you provide a `maxResults`, the value must be between 5 and 10.
 * To get the next page results, provide the pagination token from the
 * `GetDetectorsResponse` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getDetectors: API.PaginatedOperationMethod<GetDetectorsRequest & RegionInput, GetDetectorsResult, GetDetectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDetectorVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a particular detector version.
 */
export declare const getDetectorVersion: API.OperationMethod<GetDetectorVersionRequest & RegionInput, GetDetectorVersionResult, GetDetectorVersionError, Credentials | HttpClient.HttpClient>;
export type GetEntityTypesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all entity types or a specific entity type if a name is specified. This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 10 records
 * per page. If you provide a `maxResults`, the value must be between 5 and 10.
 * To get the next page results, provide the pagination token from the
 * `GetEntityTypesResponse` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getEntityTypes: API.PaginatedOperationMethod<GetEntityTypesRequest & RegionInput, GetEntityTypesResult, GetEntityTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of events stored with Amazon Fraud Detector. This action does not retrieve prediction results.
 */
export declare const getEvent: API.OperationMethod<GetEventRequest & RegionInput, GetEventResult, GetEventError, Credentials | HttpClient.HttpClient>;
export type GetEventPredictionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Evaluates an event against a detector version. If a version ID is not provided, the detector's (`ACTIVE`) version is used.
 */
export declare const getEventPrediction: API.OperationMethod<GetEventPredictionRequest & RegionInput, GetEventPredictionResult, GetEventPredictionError, Credentials | HttpClient.HttpClient>;
export type GetEventPredictionMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details of the past fraud predictions for the specified event ID, event type, detector ID, and detector version ID that was generated in the specified time period.
 */
export declare const getEventPredictionMetadata: API.OperationMethod<GetEventPredictionMetadataRequest & RegionInput, GetEventPredictionMetadataResult, GetEventPredictionMetadataError, Credentials | HttpClient.HttpClient>;
export type GetEventTypesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all event types or a specific event type if name is provided. This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 10 records
 * per page. If you provide a `maxResults`, the value must be between 5 and 10.
 * To get the next page results, provide the pagination token from the
 * `GetEventTypesResponse` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getEventTypes: API.PaginatedOperationMethod<GetEventTypesRequest & RegionInput, GetEventTypesResult, GetEventTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetExternalModelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details for one or more Amazon SageMaker models that have been imported into the
 * service. This is a paginated API. If you provide a null `maxResults`, this
 * actions retrieves a maximum of 10 records per page. If you provide a
 * `maxResults`, the value must be between 5 and 10. To get the next page
 * results, provide the pagination token from the `GetExternalModelsResult` as part
 * of your request. A null pagination token fetches the records from the beginning.
 */
export declare const getExternalModels: API.PaginatedOperationMethod<GetExternalModelsRequest & RegionInput, GetExternalModelsResult, GetExternalModelsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetKMSEncryptionKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the encryption key if a KMS key has been specified to be used to encrypt content in Amazon Fraud Detector.
 */
export declare const getKMSEncryptionKey: API.OperationMethod<GetKMSEncryptionKeyRequest & RegionInput, GetKMSEncryptionKeyResult, GetKMSEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type GetLabelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all labels or a specific label if name is provided. This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 50 records
 * per page. If you provide a `maxResults`, the value must be between 10 and 50.
 * To get the next page results, provide the pagination token from the
 * `GetGetLabelsResponse` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getLabels: API.PaginatedOperationMethod<GetLabelsRequest & RegionInput, GetLabelsResult, GetLabelsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetListElementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all the elements in the specified list.
 */
export declare const getListElements: API.PaginatedOperationMethod<GetListElementsRequest & RegionInput, GetListElementsResult, GetListElementsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetListsMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the metadata of either all the lists under the account or the specified list.
 */
export declare const getListsMetadata: API.PaginatedOperationMethod<GetListsMetadataRequest & RegionInput, GetListsMetadataResult, GetListsMetadataError, Credentials | HttpClient.HttpClient, unknown>;
export type GetModelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets one or more models. Gets all models for the Amazon Web Services account if no model type and no model id provided. Gets all models for the Amazon Web Services account and model type, if the model type is specified but model id is not provided. Gets a specific model if (model type, model id) tuple is specified.
 *
 * This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 10 records
 * per page. If you provide a `maxResults`, the value must be between 1 and 10.
 * To get the next page results, provide the pagination token from the
 * response as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getModels: API.PaginatedOperationMethod<GetModelsRequest & RegionInput, GetModelsResult, GetModelsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetModelVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of the specified model version.
 */
export declare const getModelVersion: API.OperationMethod<GetModelVersionRequest & RegionInput, GetModelVersionResult, GetModelVersionError, Credentials | HttpClient.HttpClient>;
export type GetOutcomesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets one or more outcomes. This is a paginated
 * API. If you provide a null `maxResults`, this actions retrieves a maximum of
 * 100 records per page. If you provide a `maxResults`, the value must be
 * between 50 and 100. To get the next page results, provide the pagination token from the
 * `GetOutcomesResult` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getOutcomes: API.PaginatedOperationMethod<GetOutcomesRequest & RegionInput, GetOutcomesResult, GetOutcomesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get all rules for a detector (paginated) if `ruleId` and `ruleVersion` are not specified. Gets all rules for the detector and the `ruleId` if present (paginated). Gets a specific rule if both the `ruleId` and the `ruleVersion` are specified.
 *
 * This is a paginated API. Providing null maxResults results in retrieving maximum of 100 records per page. If you provide maxResults the value must be between 50 and 100. To get the next page result, a provide a pagination token from GetRulesResult as part of your request. Null pagination token fetches the records from the beginning.
 */
export declare const getRules: API.PaginatedOperationMethod<GetRulesRequest & RegionInput, GetRulesResult, GetRulesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetVariablesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all of the variables or the specific variable. This is a
 * paginated API. Providing null `maxSizePerPage` results in retrieving maximum of
 * 100 records per page. If you provide `maxSizePerPage` the value must be between
 * 50 and 100. To get the next page result, a provide a pagination token from
 * `GetVariablesResult` as part of your request. Null pagination token
 * fetches the records from the beginning.
 */
export declare const getVariables: API.PaginatedOperationMethod<GetVariablesRequest & RegionInput, GetVariablesResult, GetVariablesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEventPredictionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of past predictions. The list can be filtered by detector ID, detector version ID, event ID, event type, or by specifying a time period.
 * If filter is not specified, the most recent prediction is returned.
 *
 * For example, the following filter lists all past predictions for `xyz` event type -
 * {
 * "eventType":{
 * "value": "xyz" }"
 * }
 *
 * This is a paginated API. If you provide a null `maxResults`, this action will retrieve a maximum of 10 records per page.
 * If you provide a `maxResults`, the value must be between 50 and 100. To get the next page results, provide
 * the `nextToken` from the response as part of your request. A null `nextToken` fetches the records from the beginning.
 */
export declare const listEventPredictions: API.PaginatedOperationMethod<ListEventPredictionsRequest & RegionInput, ListEventPredictionsResult, ListEventPredictionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags associated with the resource. This is a paginated API. To get the next page results, provide the pagination token from the
 * response as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient, unknown>;
export type PutDetectorError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates a detector.
 */
export declare const putDetector: API.OperationMethod<PutDetectorRequest & RegionInput, PutDetectorResult, PutDetectorError, Credentials | HttpClient.HttpClient>;
export type PutEntityTypeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates an entity type. An entity represents who is performing the event. As part of a fraud prediction, you pass the entity ID to indicate the specific entity who performed the event. An entity type classifies the entity. Example classifications include customer, merchant, or account.
 */
export declare const putEntityType: API.OperationMethod<PutEntityTypeRequest & RegionInput, PutEntityTypeResult, PutEntityTypeError, Credentials | HttpClient.HttpClient>;
export type PutEventTypeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates an event type. An event is a business activity that is evaluated for fraud risk. With Amazon Fraud Detector, you generate fraud predictions for events. An event type defines the structure for an event sent to Amazon Fraud Detector. This includes the variables sent as part of the event, the entity performing the event (such as a customer), and the labels that classify the event. Example event types include online payment transactions, account registrations, and authentications.
 */
export declare const putEventType: API.OperationMethod<PutEventTypeRequest & RegionInput, PutEventTypeResult, PutEventTypeError, Credentials | HttpClient.HttpClient>;
export type PutExternalModelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates an Amazon SageMaker model endpoint. You can also use this action to update the configuration of the model endpoint, including the IAM role and/or the mapped variables.
 */
export declare const putExternalModel: API.OperationMethod<PutExternalModelRequest & RegionInput, PutExternalModelResult, PutExternalModelError, Credentials | HttpClient.HttpClient>;
export type PutKMSEncryptionKeyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Specifies the KMS key to be used to encrypt content in Amazon Fraud Detector.
 */
export declare const putKMSEncryptionKey: API.OperationMethod<PutKMSEncryptionKeyRequest & RegionInput, PutKMSEncryptionKeyResult, PutKMSEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type PutLabelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates label. A label classifies an event as fraudulent or legitimate. Labels are associated with event types and used to train supervised machine learning models in Amazon Fraud Detector.
 */
export declare const putLabel: API.OperationMethod<PutLabelRequest & RegionInput, PutLabelResult, PutLabelError, Credentials | HttpClient.HttpClient>;
export type PutOutcomeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates an outcome.
 */
export declare const putOutcome: API.OperationMethod<PutOutcomeRequest & RegionInput, PutOutcomeResult, PutOutcomeError, Credentials | HttpClient.HttpClient>;
export type SendEventError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stores events in Amazon Fraud Detector without generating fraud predictions for those events. For example, you can use `SendEvent` to upload a historical dataset, which you can then later use to train a model.
 */
export declare const sendEvent: API.OperationMethod<SendEventRequest & RegionInput, SendEventResult, SendEventError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResult, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResult, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a detector version. The detector version attributes that you can update include models, external model endpoints, rules, rule execution mode, and description. You can only update a `DRAFT` detector version.
 */
export declare const updateDetectorVersion: API.OperationMethod<UpdateDetectorVersionRequest & RegionInput, UpdateDetectorVersionResult, UpdateDetectorVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorVersionMetadataError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the detector version's description. You can update the metadata for any detector version (`DRAFT, ACTIVE,` or
 * `INACTIVE`).
 */
export declare const updateDetectorVersionMetadata: API.OperationMethod<UpdateDetectorVersionMetadataRequest & RegionInput, UpdateDetectorVersionMetadataResult, UpdateDetectorVersionMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorVersionStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the detector version's status. You can perform the following promotions or
 * demotions using `UpdateDetectorVersionStatus`: `DRAFT` to `ACTIVE`, `ACTIVE` to `INACTIVE`, and `INACTIVE` to `ACTIVE`.
 */
export declare const updateDetectorVersionStatus: API.OperationMethod<UpdateDetectorVersionStatusRequest & RegionInput, UpdateDetectorVersionStatusResult, UpdateDetectorVersionStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateEventLabelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified event with a new label.
 */
export declare const updateEventLabel: API.OperationMethod<UpdateEventLabelRequest & RegionInput, UpdateEventLabelResult, UpdateEventLabelError, Credentials | HttpClient.HttpClient>;
export type UpdateListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a list.
 */
export declare const updateList: API.OperationMethod<UpdateListRequest & RegionInput, UpdateListResult, UpdateListError, Credentials | HttpClient.HttpClient>;
export type UpdateModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates model description.
 */
export declare const updateModel: API.OperationMethod<UpdateModelRequest & RegionInput, UpdateModelResult, UpdateModelError, Credentials | HttpClient.HttpClient>;
export type UpdateModelVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a model version. Updating a model version retrains an existing model version using updated training data and produces a new minor version of the model. You can update the training data set location and data access role attributes using this action. This action creates and trains a new minor version of the model, for example version 1.01, 1.02, 1.03.
 */
export declare const updateModelVersion: API.OperationMethod<UpdateModelVersionRequest & RegionInput, UpdateModelVersionResult, UpdateModelVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateModelVersionStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of a model version.
 *
 * You can perform the following status updates:
 *
 * - Change the `TRAINING_IN_PROGRESS` status to `TRAINING_CANCELLED`.
 *
 * - Change the `TRAINING_COMPLETE` status to `ACTIVE`.
 *
 * - Change `ACTIVE` to `INACTIVE`.
 */
export declare const updateModelVersionStatus: API.OperationMethod<UpdateModelVersionStatusRequest & RegionInput, UpdateModelVersionStatusResult, UpdateModelVersionStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleMetadataError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a rule's metadata. The description attribute can be updated.
 */
export declare const updateRuleMetadata: API.OperationMethod<UpdateRuleMetadataRequest & RegionInput, UpdateRuleMetadataResult, UpdateRuleMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a rule version resulting in a new rule version. Updates a rule version resulting in a new rule version (version 1, 2, 3 ...).
 */
export declare const updateRuleVersion: API.OperationMethod<UpdateRuleVersionRequest & RegionInput, UpdateRuleVersionResult, UpdateRuleVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateVariableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a variable.
 */
export declare const updateVariable: API.OperationMethod<UpdateVariableRequest & RegionInput, UpdateVariableResult, UpdateVariableError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=frauddetector.d.ts.map