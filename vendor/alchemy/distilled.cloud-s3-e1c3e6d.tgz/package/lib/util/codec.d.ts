/**
 * Value conversion between the types a generated AWS schema declares and
 * their wire form, by walking the schema's lite AST.
 *
 * `encode` turns an operation input into its wire form before a protocol
 * serializes it: struct keys renamed by `encodeKeys`, timestamps to the
 * format their `codecSymbol` names, blobs to base64, `Redacted` values
 * unwrapped. It checks what it walks the way Effect Schema's encoder did
 * (required members present, primitives of the declared type, a union
 * member that fits), and throws {@link CodecError} otherwise.
 *
 * `decode` is the reverse, for values a protocol read off the wire. Lenient
 * decoding never fails: a value that does not fit its schema is kept as
 * read (wrapped in `Redacted` whole when its type can hold a sensitive
 * value), and the rest of the response still converts. Exact decoding throws
 * on the first mismatch instead; `"closed"` exact decoding also throws on a
 * key the schema does not model (`ResponseValidation.strict`). Only members
 * the schema declares are kept.
 *
 * Which types hold a secret, and how logs and error messages show them, is
 * core's rule (`@distilled.cloud/core/sensitive`).
 */
import { type Node } from "@distilled.cloud/core/schema-lite-impl";
import * as Effect from "effect/Effect";
import type { Operation } from "../client/operation.ts";
import { ParseError } from "../errors.ts";
/** A value that does not fit its schema. */
export declare class CodecError extends Error {
    /** What the schema expected, e.g. `string`. */
    readonly expected: string;
    /** The ` at [key]` suffixes the failure gained on the way out, innermost first. */
    path: string;
    constructor(
    /** What the schema expected, e.g. `string`. */
    expected: string, actual: unknown);
    /** The message without the value found, for a type that can hold a secret. */
    get withheld(): string;
}
/** Whether a value of the type `n` can hold a `sensitive` value (core's rule). */
export declare const holdsSensitive: (n: Node) => boolean;
/**
 * Whether a wire value has the shape of `n` (for a union, of one of its
 * members): the members it requires are present. Event-stream decoding uses
 * it to tell a modeled event that does not match from an unmodeled one.
 */
export declare const fitsWire: (n: Node, v: unknown) => boolean;
/** The wire form of `v`, a value of the type `n` declares. Throws {@link CodecError}. */
export declare const encode: (n: Node, v: unknown) => unknown;
/**
 * How {@link decode} treats a mismatch: `false` keeps the value as read,
 * `true` throws, `"closed"` also throws on a key the schema does not model.
 */
export type Exactness = boolean | "closed";
/**
 * The typed form of `v`, a value read off the wire for the type `n`
 * declares. Lenient by default: a value that does not fit is kept as read.
 * With `exact`, a mismatch throws {@link CodecError} instead.
 */
export declare const decode: (n: Node, v: unknown, exact?: Exactness) => unknown;
/** The message of a failed encode or decode, without the value it found when `withhold`. */
export declare const decodeFailure: (e: unknown, withhold: boolean) => string;
/** A 2xx body to quote in an error message: `[REDACTED]` when the output can hold a secret. */
export declare const outputBody: (operation: Operation<any, any, any>, body: string) => string;
/**
 * An error body to quote in an error message: `[REDACTED]` when one of the
 * operation's declared errors can hold a secret.
 */
export declare const errorBody: (operation: Operation<any, any, any>, body: string) => string;
/**
 * An operation input encoder for protocols: encode failures become
 * `ParseError`, without the value found when the input can hold a secret.
 */
export declare const inputEncoder: (ast: Node) => (input: unknown) => Effect.Effect<unknown, ParseError>;
/** {@link inputEncoder} as a plain function: encode failures throw `ParseError`. */
export declare const inputEncoderSync: (ast: Node) => (input: unknown) => unknown;
//# sourceMappingURL=codec.d.ts.map