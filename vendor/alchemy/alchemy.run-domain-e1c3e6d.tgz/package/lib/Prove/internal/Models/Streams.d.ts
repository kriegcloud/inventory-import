import type { Kit, Models } from "../Kit.ts";
import type { V } from "../Value.ts";
/**
 * `Stream`, as far as a stream is a list worked through in order: made from
 * values the code has, changed one item at a time, and run to a value.
 *
 * A stream is modelled as the library runs one. Opening it gives a pull, and
 * each pull gives the next chunk. A step that maps or filters works on a
 * whole chunk; a step that runs an effect for each item gives the items one
 * at a time. So a stream that stops early runs the effects the real one
 * runs, and no others. A stream of time, of a queue or of several fibers is
 * not read.
 */
export declare const make: (kit: Kit) => {
    readonly models: Models;
    readonly values: Record<string, V>;
};
//# sourceMappingURL=Streams.d.ts.map