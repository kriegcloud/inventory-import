import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ApplicationNotSupportedException_base: S.TaggedErrorClass<"ApplicationNotSupportedException", {
    readonly message: any;
}>;
export declare class ApplicationNotSupportedException extends /*@__PURE__*/ ApplicationNotSupportedException_base {
}
declare const ComputeNotCompatibleException_base: S.TaggedErrorClass<"ComputeNotCompatibleException", {
    readonly message: any;
}>;
export declare class ComputeNotCompatibleException extends /*@__PURE__*/ ComputeNotCompatibleException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const IncompatibleApplicationsException_base: S.TaggedErrorClass<"IncompatibleApplicationsException", {
    readonly message: any;
}>;
export declare class IncompatibleApplicationsException extends /*@__PURE__*/ IncompatibleApplicationsException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}>;
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterValuesException_base: S.TaggedErrorClass<"InvalidParameterValuesException", {
    readonly message: any;
}>;
export declare class InvalidParameterValuesException extends /*@__PURE__*/ InvalidParameterValuesException_base {
}
declare const InvalidResourceStateException_base: S.TaggedErrorClass<"InvalidResourceStateException", {
    readonly message: any;
}>;
export declare class InvalidResourceStateException extends /*@__PURE__*/ InvalidResourceStateException_base {
}
declare const OperatingSystemNotCompatibleException_base: S.TaggedErrorClass<"OperatingSystemNotCompatibleException", {
    readonly message: any;
}>;
export declare class OperatingSystemNotCompatibleException extends /*@__PURE__*/ OperatingSystemNotCompatibleException_base {
}
declare const OperationInProgressException_base: S.TaggedErrorClass<"OperationInProgressException", {
    readonly message: any;
}>;
export declare class OperationInProgressException extends /*@__PURE__*/ OperationInProgressException_base {
}
declare const OperationNotSupportedException_base: S.TaggedErrorClass<"OperationNotSupportedException", {
    readonly message: any;
    readonly reason: any;
}>;
export declare class OperationNotSupportedException extends /*@__PURE__*/ OperationNotSupportedException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceAssociatedException_base: S.TaggedErrorClass<"ResourceAssociatedException", {
    readonly message: any;
}>;
export declare class ResourceAssociatedException extends /*@__PURE__*/ ResourceAssociatedException_base {
}
declare const ResourceCreationFailedException_base: S.TaggedErrorClass<"ResourceCreationFailedException", {
    readonly message: any;
}>;
export declare class ResourceCreationFailedException extends /*@__PURE__*/ ResourceCreationFailedException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
    readonly ResourceId: any;
}>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
}>;
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
    readonly ResourceId: any;
}>;
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const UnsupportedNetworkConfigurationException_base: S.TaggedErrorClass<"UnsupportedNetworkConfigurationException", {
    readonly message: any;
}>;
export declare class UnsupportedNetworkConfigurationException extends /*@__PURE__*/ UnsupportedNetworkConfigurationException_base {
}
declare const UnsupportedWorkspaceConfigurationException_base: S.TaggedErrorClass<"UnsupportedWorkspaceConfigurationException", {
    readonly message: any;
}>;
export declare class UnsupportedWorkspaceConfigurationException extends /*@__PURE__*/ UnsupportedWorkspaceConfigurationException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
declare const WorkspacesDefaultRoleNotFoundException_base: S.TaggedErrorClass<"WorkspacesDefaultRoleNotFoundException", {
    readonly message: any;
}>;
export declare class WorkspacesDefaultRoleNotFoundException extends /*@__PURE__*/ WorkspacesDefaultRoleNotFoundException_base {
}
export type LinkId = string;
export type ClientToken = string;
export interface AcceptAccountLinkInvitationRequest {
    LinkId: string;
    ClientToken?: string | undefined;
}
export type AccountLinkStatusEnum = "LINKED" | "LINKING_FAILED" | "LINK_NOT_FOUND" | "PENDING_ACCEPTANCE_BY_TARGET_ACCOUNT" | "REJECTED" | (string & {});
export type AwsAccount = string;
export interface AccountLink {
    AccountLinkId?: string | undefined;
    AccountLinkStatus?: AccountLinkStatusEnum | undefined;
    SourceAccountId?: string | undefined;
    TargetAccountId?: string | undefined;
}
export interface AcceptAccountLinkInvitationResult {
    AccountLink?: AccountLink | undefined;
}
export type ConnectionAliasId = string;
export type NonEmptyString = string;
export interface AssociateConnectionAliasRequest {
    AliasId: string;
    ResourceId: string;
}
export type ConnectionIdentifier = string;
export interface AssociateConnectionAliasResult {
    ConnectionIdentifier?: string | undefined;
}
export type DirectoryId = string;
export type IpGroupId = string;
export type IpGroupIdList = string[];
export interface AssociateIpGroupsRequest {
    DirectoryId: string;
    GroupIds: string[];
}
export interface AssociateIpGroupsResult {
}
export type WorkspaceId = string;
export type WorkSpaceApplicationId = string;
export interface AssociateWorkspaceApplicationRequest {
    WorkspaceId: string;
    ApplicationId: string;
}
export type WorkSpaceAssociatedResourceType = "APPLICATION" | (string & {});
export type AssociationState = "PENDING_INSTALL" | "PENDING_INSTALL_DEPLOYMENT" | "PENDING_UNINSTALL" | "PENDING_UNINSTALL_DEPLOYMENT" | "INSTALLING" | "UNINSTALLING" | "ERROR" | "COMPLETED" | "REMOVED" | (string & {});
export type AssociationErrorCode = "ValidationError.InsufficientDiskSpace" | "ValidationError.InsufficientMemory" | "ValidationError.UnsupportedOperatingSystem" | "DeploymentError.InternalServerError" | "DeploymentError.WorkspaceUnreachable" | "ValidationError.ApplicationOldVersionExists" | (string & {});
export type String2048 = string;
export interface AssociationStateReason {
    ErrorCode?: AssociationErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export interface WorkspaceResourceAssociation {
    AssociatedResourceId?: string | undefined;
    AssociatedResourceType?: WorkSpaceAssociatedResourceType | undefined;
    Created?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    State?: AssociationState | undefined;
    StateReason?: AssociationStateReason | undefined;
    WorkspaceId?: string | undefined;
}
export interface AssociateWorkspaceApplicationResult {
    Association?: WorkspaceResourceAssociation | undefined;
}
export type IpRule = string;
export type IpRuleDesc = string;
export interface IpRuleItem {
    ipRule?: string | undefined;
    ruleDesc?: string | undefined;
}
export type IpRuleList = IpRuleItem[];
export interface AuthorizeIpRulesRequest {
    GroupId: string;
    UserRules: IpRuleItem[];
}
export interface AuthorizeIpRulesResult {
}
export type WorkspaceImageName = string;
export type WorkspaceImageDescription = string;
export type WorkspaceImageId = string;
export type Region = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface CopyWorkspaceImageRequest {
    Name: string;
    Description?: string | undefined;
    SourceImageId: string;
    SourceRegion: string;
    Tags?: Tag[] | undefined;
}
export interface CopyWorkspaceImageResult {
    ImageId?: string | undefined;
}
export interface CreateAccountLinkInvitationRequest {
    TargetAccountId: string;
    ClientToken?: string | undefined;
}
export interface CreateAccountLinkInvitationResult {
    AccountLink?: AccountLink | undefined;
}
export type AddInName = string;
export type AddInUrl = string;
export interface CreateConnectClientAddInRequest {
    ResourceId: string;
    Name: string;
    URL: string;
}
export type AmazonUuid = string;
export interface CreateConnectClientAddInResult {
    AddInId?: string | undefined;
}
export type ConnectionString = string;
export interface CreateConnectionAliasRequest {
    ConnectionString: string;
    Tags?: Tag[] | undefined;
}
export interface CreateConnectionAliasResult {
    AliasId?: string | undefined;
}
export type IpGroupName = string;
export type IpGroupDesc = string;
export interface CreateIpGroupRequest {
    GroupName: string;
    GroupDesc?: string | undefined;
    UserRules?: IpRuleItem[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateIpGroupResult {
    GroupId?: string | undefined;
}
export type VolumeEncryptionKey = string;
export type DataReplication = "NO_REPLICATION" | "PRIMARY_AS_SOURCE" | (string & {});
export interface StandbyWorkspace {
    PrimaryWorkspaceId: string;
    VolumeEncryptionKey?: string | undefined;
    DirectoryId: string;
    Tags?: Tag[] | undefined;
    DataReplication?: DataReplication | undefined;
}
export type StandbyWorkspacesList = StandbyWorkspace[];
export interface CreateStandbyWorkspacesRequest {
    PrimaryRegion: string;
    StandbyWorkspaces: StandbyWorkspace[];
}
export type WorkspaceErrorCode = string;
export type Description = string;
export interface FailedCreateStandbyWorkspacesRequest {
    StandbyWorkspaceRequest?: StandbyWorkspace | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type FailedCreateStandbyWorkspacesRequestList = FailedCreateStandbyWorkspacesRequest[];
export type UserName = string;
export type WorkspaceState = "PENDING" | "AVAILABLE" | "IMPAIRED" | "UNHEALTHY" | "REBOOTING" | "STARTING" | "REBUILDING" | "RESTORING" | "MAINTENANCE" | "ADMIN_MAINTENANCE" | "TERMINATING" | "TERMINATED" | "SUSPENDED" | "UPDATING" | "STOPPING" | "STOPPED" | "ERROR" | (string & {});
export interface PendingCreateStandbyWorkspacesRequest {
    UserName?: string | undefined;
    DirectoryId?: string | undefined;
    State?: WorkspaceState | undefined;
    WorkspaceId?: string | undefined;
}
export type PendingCreateStandbyWorkspacesRequestList = PendingCreateStandbyWorkspacesRequest[];
export interface CreateStandbyWorkspacesResult {
    FailedStandbyRequests?: FailedCreateStandbyWorkspacesRequest[] | undefined;
    PendingStandbyRequests?: PendingCreateStandbyWorkspacesRequest[] | undefined;
}
export interface CreateTagsRequest {
    ResourceId: string;
    Tags: Tag[];
}
export interface CreateTagsResult {
}
export interface CreateUpdatedWorkspaceImageRequest {
    Name: string;
    Description: string;
    SourceImageId: string;
    Tags?: Tag[] | undefined;
}
export interface CreateUpdatedWorkspaceImageResult {
    ImageId?: string | undefined;
}
export type WorkspaceBundleName = string;
export type WorkspaceBundleDescription = string;
export type Compute = "VALUE" | "STANDARD" | "PERFORMANCE" | "POWER" | "GRAPHICS" | "POWERPRO" | "GENERALPURPOSE_4XLARGE" | "GENERALPURPOSE_8XLARGE" | "GRAPHICSPRO" | "GRAPHICS_G4DN" | "GRAPHICSPRO_G4DN" | "GRAPHICS_G6_XLARGE" | "GRAPHICS_G6_2XLARGE" | "GRAPHICS_G6_4XLARGE" | "GRAPHICS_G6_8XLARGE" | "GRAPHICS_G6_16XLARGE" | "GRAPHICS_GR6_4XLARGE" | "GRAPHICS_GR6_8XLARGE" | "GRAPHICS_G6F_LARGE" | "GRAPHICS_G6F_XLARGE" | "GRAPHICS_G6F_2XLARGE" | "GRAPHICS_G6F_4XLARGE" | "GRAPHICS_GR6F_4XLARGE" | "GRAPHICS_G7_2XLARGE" | "GRAPHICS_G7_4XLARGE" | "GRAPHICS_G7_8XLARGE" | "GRAPHICS_G7_12XLARGE" | (string & {});
export interface ComputeType {
    Name?: Compute | undefined;
}
export interface UserStorage {
    Capacity: string;
}
export interface RootStorage {
    Capacity: string;
}
export interface CreateWorkspaceBundleRequest {
    BundleName: string;
    BundleDescription: string;
    ImageId: string;
    ComputeType: ComputeType;
    UserStorage: UserStorage;
    RootStorage?: RootStorage | undefined;
    Tags?: Tag[] | undefined;
}
export type BundleId = string;
export type BundleOwner = string;
export type WorkspaceBundleState = "AVAILABLE" | "PENDING" | "ERROR" | (string & {});
export type BundleType = "REGULAR" | "STANDBY" | (string & {});
export interface WorkspaceBundle {
    BundleId?: string | undefined;
    Name?: string | undefined;
    Owner?: string | undefined;
    Description?: string | undefined;
    ImageId?: string | undefined;
    RootStorage?: RootStorage | undefined;
    UserStorage?: UserStorage | undefined;
    ComputeType?: ComputeType | undefined;
    LastUpdatedTime?: Date | undefined;
    CreationTime?: Date | undefined;
    State?: WorkspaceBundleState | undefined;
    BundleType?: BundleType | undefined;
}
export interface CreateWorkspaceBundleResult {
    WorkspaceBundle?: WorkspaceBundle | undefined;
}
export interface CreateWorkspaceImageRequest {
    Name: string;
    Description: string;
    WorkspaceId: string;
    Tags?: Tag[] | undefined;
}
export type OperatingSystemType = "WINDOWS" | "LINUX" | (string & {});
export interface OperatingSystem {
    Type?: OperatingSystemType | undefined;
}
export type WorkspaceImageState = "AVAILABLE" | "PENDING" | "ERROR" | (string & {});
export type WorkspaceImageRequiredTenancy = "DEFAULT" | "DEDICATED" | (string & {});
export interface CreateWorkspaceImageResult {
    ImageId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    OperatingSystem?: OperatingSystem | undefined;
    State?: WorkspaceImageState | undefined;
    RequiredTenancy?: WorkspaceImageRequiredTenancy | undefined;
    Created?: Date | undefined;
    OwnerAccountId?: string | undefined;
}
export type RunningMode = "AUTO_STOP" | "ALWAYS_ON" | "MANUAL" | (string & {});
export type RunningModeAutoStopTimeoutInMinutes = number;
export type RootVolumeSizeGib = number;
export type UserVolumeSizeGib = number;
export type Protocol = "PCOIP" | "WSP" | (string & {});
export type ProtocolList = Protocol[];
export type OperatingSystemName = "AMAZON_LINUX_2" | "UBUNTU_18_04" | "UBUNTU_20_04" | "UBUNTU_22_04" | "UNKNOWN" | "WINDOWS_10" | "WINDOWS_11" | "WINDOWS_7" | "WINDOWS_SERVER_2016" | "WINDOWS_SERVER_2019" | "WINDOWS_SERVER_2022" | "WINDOWS_SERVER_2025" | "RHEL_8" | "ROCKY_8" | "UBUNTU_24_04" | "RHEL_9" | "ROCKY_9" | "UBUNTU_26_04" | "RHEL_10" | "ROCKY_10" | (string & {});
export type AGAModeForWorkSpaceEnum = "ENABLED_AUTO" | "DISABLED" | "INHERITED" | (string & {});
export type AGAPreferredProtocolForWorkSpace = "TCP" | "NONE" | "INHERITED" | (string & {});
export interface GlobalAcceleratorForWorkSpace {
    Mode: AGAModeForWorkSpaceEnum;
    PreferredProtocol?: AGAPreferredProtocolForWorkSpace | undefined;
}
export interface WorkspaceProperties {
    RunningMode?: RunningMode | undefined;
    RunningModeAutoStopTimeoutInMinutes?: number | undefined;
    RootVolumeSizeGib?: number | undefined;
    UserVolumeSizeGib?: number | undefined;
    ComputeTypeName?: Compute | undefined;
    Protocols?: Protocol[] | undefined;
    OperatingSystemName?: OperatingSystemName | undefined;
    GlobalAccelerator?: GlobalAcceleratorForWorkSpace | undefined;
    NestedVirtualizationEnabled?: boolean | undefined;
}
export type WorkspaceName = string;
export type Ipv6Address = string;
export interface WorkspaceRequest {
    DirectoryId: string;
    UserName: string;
    BundleId: string;
    VolumeEncryptionKey?: string | undefined;
    UserVolumeEncryptionEnabled?: boolean | undefined;
    RootVolumeEncryptionEnabled?: boolean | undefined;
    WorkspaceProperties?: WorkspaceProperties | undefined;
    Tags?: Tag[] | undefined;
    WorkspaceName?: string | undefined;
    Ipv6Address?: string | undefined;
}
export type WorkspaceRequestList = WorkspaceRequest[];
export interface CreateWorkspacesRequest {
    Workspaces: WorkspaceRequest[];
}
export type ErrorType = string;
export interface FailedCreateWorkspaceRequest {
    WorkspaceRequest?: WorkspaceRequest | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type FailedCreateWorkspaceRequests = FailedCreateWorkspaceRequest[];
export type IpAddress = string;
export type SubnetId = string;
export type ComputerName = string;
export type ModificationResourceEnum = "ROOT_VOLUME" | "USER_VOLUME" | "COMPUTE_TYPE" | "PROTOCOL" | "NESTED_VIRTUALIZATION" | (string & {});
export type ModificationStateEnum = "UPDATE_INITIATED" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export interface ModificationState {
    Resource?: ModificationResourceEnum | undefined;
    State?: ModificationStateEnum | undefined;
}
export type ModificationStateList = ModificationState[];
export type StandbyWorkspaceRelationshipType = "PRIMARY" | "STANDBY" | (string & {});
export interface RelatedWorkspaceProperties {
    WorkspaceId?: string | undefined;
    Region?: string | undefined;
    State?: WorkspaceState | undefined;
    Type?: StandbyWorkspaceRelationshipType | undefined;
}
export type RelatedWorkspaces = RelatedWorkspaceProperties[];
export interface DataReplicationSettings {
    DataReplication?: DataReplication | undefined;
    RecoverySnapshotTime?: Date | undefined;
}
export interface StandbyWorkspacesProperties {
    StandbyWorkspaceId?: string | undefined;
    DataReplication?: DataReplication | undefined;
    RecoverySnapshotTime?: Date | undefined;
}
export type StandbyWorkspacesPropertiesList = StandbyWorkspacesProperties[];
export interface Workspace {
    WorkspaceId?: string | undefined;
    DirectoryId?: string | undefined;
    UserName?: string | undefined;
    IpAddress?: string | undefined;
    Ipv6Address?: string | undefined;
    State?: WorkspaceState | undefined;
    BundleId?: string | undefined;
    SubnetId?: string | undefined;
    ErrorMessage?: string | undefined;
    ErrorCode?: string | undefined;
    ComputerName?: string | undefined;
    VolumeEncryptionKey?: string | undefined;
    UserVolumeEncryptionEnabled?: boolean | undefined;
    RootVolumeEncryptionEnabled?: boolean | undefined;
    WorkspaceName?: string | undefined;
    WorkspaceProperties?: WorkspaceProperties | undefined;
    ModificationStates?: ModificationState[] | undefined;
    RelatedWorkspaces?: RelatedWorkspaceProperties[] | undefined;
    DataReplicationSettings?: DataReplicationSettings | undefined;
    StandbyWorkspacesProperties?: StandbyWorkspacesProperties[] | undefined;
}
export type WorkspaceList = Workspace[];
export interface CreateWorkspacesResult {
    FailedRequests?: FailedCreateWorkspaceRequest[] | undefined;
    PendingRequests?: Workspace[] | undefined;
}
export type WorkspacesPoolName = string;
export type UpdateDescription = string;
export type DesiredUserSessions = number;
export interface Capacity {
    DesiredUserSessions: number;
}
export type ApplicationSettingsStatusEnum = "DISABLED" | "ENABLED" | (string & {});
export type SettingsGroup = string;
export interface ApplicationSettingsRequest {
    Status: ApplicationSettingsStatusEnum;
    SettingsGroup?: string | undefined;
}
export type DisconnectTimeoutInSeconds = number;
export type IdleDisconnectTimeoutInSeconds = number;
export type MaxUserDurationInSeconds = number;
export interface TimeoutSettings {
    DisconnectTimeoutInSeconds?: number | undefined;
    IdleDisconnectTimeoutInSeconds?: number | undefined;
    MaxUserDurationInSeconds?: number | undefined;
}
export type PoolsRunningMode = "AUTO_STOP" | "ALWAYS_ON" | (string & {});
export interface CreateWorkspacesPoolRequest {
    PoolName: string;
    Description: string;
    BundleId: string;
    DirectoryId: string;
    Capacity: Capacity;
    Tags?: Tag[] | undefined;
    ApplicationSettings?: ApplicationSettingsRequest | undefined;
    TimeoutSettings?: TimeoutSettings | undefined;
    RunningMode?: PoolsRunningMode | undefined;
}
export type WorkspacesPoolId = string;
export type ARN = string;
export type AvailableUserSessions = number;
export type ActualUserSessions = number;
export type ActiveUserSessions = number;
export interface CapacityStatus {
    AvailableUserSessions: number;
    DesiredUserSessions: number;
    ActualUserSessions: number;
    ActiveUserSessions: number;
}
export type WorkspacesPoolState = "CREATING" | "DELETING" | "RUNNING" | "STARTING" | "STOPPED" | "STOPPING" | "UPDATING" | (string & {});
export type WorkspacesPoolErrorCode = "IAM_SERVICE_ROLE_IS_MISSING" | "IAM_SERVICE_ROLE_MISSING_ENI_DESCRIBE_ACTION" | "IAM_SERVICE_ROLE_MISSING_ENI_CREATE_ACTION" | "IAM_SERVICE_ROLE_MISSING_ENI_DELETE_ACTION" | "NETWORK_INTERFACE_LIMIT_EXCEEDED" | "INTERNAL_SERVICE_ERROR" | "MACHINE_ROLE_IS_MISSING" | "STS_DISABLED_IN_REGION" | "SUBNET_HAS_INSUFFICIENT_IP_ADDRESSES" | "IAM_SERVICE_ROLE_MISSING_DESCRIBE_SUBNET_ACTION" | "SUBNET_NOT_FOUND" | "IMAGE_NOT_FOUND" | "INVALID_SUBNET_CONFIGURATION" | "SECURITY_GROUPS_NOT_FOUND" | "IGW_NOT_ATTACHED" | "IAM_SERVICE_ROLE_MISSING_DESCRIBE_SECURITY_GROUPS_ACTION" | "WORKSPACES_POOL_STOPPED" | "WORKSPACES_POOL_INSTANCE_PROVISIONING_FAILURE" | "DOMAIN_JOIN_ERROR_FILE_NOT_FOUND" | "DOMAIN_JOIN_ERROR_ACCESS_DENIED" | "DOMAIN_JOIN_ERROR_LOGON_FAILURE" | "DOMAIN_JOIN_ERROR_INVALID_PARAMETER" | "DOMAIN_JOIN_ERROR_MORE_DATA" | "DOMAIN_JOIN_ERROR_NO_SUCH_DOMAIN" | "DOMAIN_JOIN_ERROR_NOT_SUPPORTED" | "DOMAIN_JOIN_NERR_INVALID_WORKGROUP_NAME" | "DOMAIN_JOIN_NERR_WORKSTATION_NOT_STARTED" | "DOMAIN_JOIN_ERROR_DS_MACHINE_ACCOUNT_QUOTA_EXCEEDED" | "DOMAIN_JOIN_NERR_PASSWORD_EXPIRED" | "DOMAIN_JOIN_INTERNAL_SERVICE_ERROR" | "DOMAIN_JOIN_ERROR_SECRET_ACTION_PERMISSION_IS_MISSING" | "DOMAIN_JOIN_ERROR_SECRET_DECRYPTION_FAILURE" | "DOMAIN_JOIN_ERROR_SECRET_STATE_INVALID" | "DOMAIN_JOIN_ERROR_SECRET_NOT_FOUND" | "DOMAIN_JOIN_ERROR_SECRET_VALUE_KEY_NOT_FOUND" | "DOMAIN_JOIN_ERROR_SECRET_INVALID" | "BUNDLE_NOT_FOUND" | "DIRECTORY_NOT_FOUND" | "INSUFFICIENT_PERMISSIONS_ERROR" | "DEFAULT_OU_IS_MISSING" | (string & {});
export type ErrorMessage = string;
export interface WorkspacesPoolError {
    ErrorCode?: WorkspacesPoolErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type WorkspacesPoolErrors = WorkspacesPoolError[];
export type S3BucketName = string;
export interface ApplicationSettingsResponse {
    Status: ApplicationSettingsStatusEnum;
    SettingsGroup?: string | undefined;
    S3BucketName?: string | undefined;
}
export interface WorkspacesPool {
    PoolId: string;
    PoolArn: string;
    CapacityStatus: CapacityStatus;
    PoolName: string;
    Description?: string | undefined;
    State: WorkspacesPoolState;
    CreatedAt: Date;
    BundleId: string;
    DirectoryId: string;
    Errors?: WorkspacesPoolError[] | undefined;
    ApplicationSettings?: ApplicationSettingsResponse | undefined;
    TimeoutSettings?: TimeoutSettings | undefined;
    RunningMode: PoolsRunningMode;
}
export interface CreateWorkspacesPoolResult {
    WorkspacesPool?: WorkspacesPool | undefined;
}
export interface DeleteAccountLinkInvitationRequest {
    LinkId: string;
    ClientToken?: string | undefined;
}
export interface DeleteAccountLinkInvitationResult {
    AccountLink?: AccountLink | undefined;
}
export type ClientDeviceType = "DeviceTypeWindows" | "DeviceTypeOsx" | "DeviceTypeAndroid" | "DeviceTypeIos" | "DeviceTypeLinux" | "DeviceTypeWeb" | (string & {});
export type ClientDeviceTypeList = ClientDeviceType[];
export interface DeleteClientBrandingRequest {
    ResourceId: string;
    Platforms: ClientDeviceType[];
}
export interface DeleteClientBrandingResult {
}
export interface DeleteConnectClientAddInRequest {
    AddInId: string;
    ResourceId: string;
}
export interface DeleteConnectClientAddInResult {
}
export interface DeleteConnectionAliasRequest {
    AliasId: string;
}
export interface DeleteConnectionAliasResult {
}
export interface DeleteIpGroupRequest {
    GroupId: string;
}
export interface DeleteIpGroupResult {
}
export type TagKeyList = string[];
export interface DeleteTagsRequest {
    ResourceId: string;
    TagKeys: string[];
}
export interface DeleteTagsResult {
}
export interface DeleteWorkspaceBundleRequest {
    BundleId?: string | undefined;
}
export interface DeleteWorkspaceBundleResult {
}
export interface DeleteWorkspaceImageRequest {
    ImageId: string;
}
export interface DeleteWorkspaceImageResult {
}
export interface DeployWorkspaceApplicationsRequest {
    WorkspaceId: string;
    Force?: boolean | undefined;
}
export type WorkspaceResourceAssociationList = WorkspaceResourceAssociation[];
export interface WorkSpaceApplicationDeployment {
    Associations?: WorkspaceResourceAssociation[] | undefined;
}
export interface DeployWorkspaceApplicationsResult {
    Deployment?: WorkSpaceApplicationDeployment | undefined;
}
export interface DeregisterWorkspaceDirectoryRequest {
    DirectoryId: string;
}
export interface DeregisterWorkspaceDirectoryResult {
}
export interface DescribeAccountRequest {
}
export type DedicatedTenancySupportResultEnum = "ENABLED" | "DISABLED" | (string & {});
export type DedicatedTenancyManagementCidrRange = string;
export type DedicatedTenancyAccountType = "SOURCE_ACCOUNT" | "TARGET_ACCOUNT" | (string & {});
export type Message = string;
export interface DescribeAccountResult {
    DedicatedTenancySupport?: DedicatedTenancySupportResultEnum | undefined;
    DedicatedTenancyManagementCidrRange?: string | undefined;
    DedicatedTenancyAccountType?: DedicatedTenancyAccountType | undefined;
    Message?: string | undefined;
}
export type PaginationToken = string;
export interface DescribeAccountModificationsRequest {
    NextToken?: string | undefined;
}
export type DedicatedTenancyModificationStateEnum = "PENDING" | "COMPLETED" | "FAILED" | (string & {});
export interface AccountModification {
    ModificationState?: DedicatedTenancyModificationStateEnum | undefined;
    DedicatedTenancySupport?: DedicatedTenancySupportResultEnum | undefined;
    DedicatedTenancyManagementCidrRange?: string | undefined;
    StartTime?: Date | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type AccountModificationList = AccountModification[];
export interface DescribeAccountModificationsResult {
    AccountModifications?: AccountModification[] | undefined;
    NextToken?: string | undefined;
}
export type Limit = number;
export type ApplicationAssociatedResourceType = "WORKSPACE" | "BUNDLE" | "IMAGE" | (string & {});
export type ApplicationAssociatedResourceTypeList = ApplicationAssociatedResourceType[];
export interface DescribeApplicationAssociationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ApplicationId: string;
    AssociatedResourceTypes: ApplicationAssociatedResourceType[];
}
export interface ApplicationResourceAssociation {
    ApplicationId?: string | undefined;
    AssociatedResourceId?: string | undefined;
    AssociatedResourceType?: ApplicationAssociatedResourceType | undefined;
    Created?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    State?: AssociationState | undefined;
    StateReason?: AssociationStateReason | undefined;
}
export type ApplicationResourceAssociationList = ApplicationResourceAssociation[];
export interface DescribeApplicationAssociationsResult {
    Associations?: ApplicationResourceAssociation[] | undefined;
    NextToken?: string | undefined;
}
export type WorkSpaceApplicationIdList = string[];
export type ComputeList = Compute[];
export type WorkSpaceApplicationLicenseType = "LICENSED" | "UNLICENSED" | (string & {});
export type OperatingSystemNameList = OperatingSystemName[];
export type WorkSpaceApplicationOwner = string;
export interface DescribeApplicationsRequest {
    ApplicationIds?: string[] | undefined;
    ComputeTypeNames?: Compute[] | undefined;
    LicenseType?: WorkSpaceApplicationLicenseType | undefined;
    OperatingSystemNames?: OperatingSystemName[] | undefined;
    Owner?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type WorkSpaceApplicationState = "PENDING" | "ERROR" | "AVAILABLE" | "UNINSTALL_ONLY" | (string & {});
export interface WorkSpaceApplication {
    ApplicationId?: string | undefined;
    Created?: Date | undefined;
    Description?: string | undefined;
    LicenseType?: WorkSpaceApplicationLicenseType | undefined;
    Name?: string | undefined;
    Owner?: string | undefined;
    State?: WorkSpaceApplicationState | undefined;
    SupportedComputeTypeNames?: Compute[] | undefined;
    SupportedOperatingSystemNames?: OperatingSystemName[] | undefined;
}
export type WorkSpaceApplicationList = WorkSpaceApplication[];
export interface DescribeApplicationsResult {
    Applications?: WorkSpaceApplication[] | undefined;
    NextToken?: string | undefined;
}
export type BundleAssociatedResourceType = "APPLICATION" | (string & {});
export type BundleAssociatedResourceTypeList = BundleAssociatedResourceType[];
export interface DescribeBundleAssociationsRequest {
    BundleId: string;
    AssociatedResourceTypes: BundleAssociatedResourceType[];
}
export interface BundleResourceAssociation {
    AssociatedResourceId?: string | undefined;
    AssociatedResourceType?: BundleAssociatedResourceType | undefined;
    BundleId?: string | undefined;
    Created?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    State?: AssociationState | undefined;
    StateReason?: AssociationStateReason | undefined;
}
export type BundleResourceAssociationList = BundleResourceAssociation[];
export interface DescribeBundleAssociationsResult {
    Associations?: BundleResourceAssociation[] | undefined;
}
export interface DescribeClientBrandingRequest {
    ResourceId: string;
}
export type ClientUrl = string;
export type ClientEmail = string;
export type ClientLocale = string;
export type ClientLoginMessage = string;
export type LoginMessage = {
    [key: string]: string | undefined;
};
export interface DefaultClientBrandingAttributes {
    LogoUrl?: string | undefined;
    SupportEmail?: string | undefined;
    SupportLink?: string | undefined;
    ForgotPasswordLink?: string | undefined;
    LoginMessage?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface IosClientBrandingAttributes {
    LogoUrl?: string | undefined;
    Logo2xUrl?: string | undefined;
    Logo3xUrl?: string | undefined;
    SupportEmail?: string | undefined;
    SupportLink?: string | undefined;
    ForgotPasswordLink?: string | undefined;
    LoginMessage?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeClientBrandingResult {
    DeviceTypeWindows?: DefaultClientBrandingAttributes | undefined;
    DeviceTypeOsx?: DefaultClientBrandingAttributes | undefined;
    DeviceTypeAndroid?: DefaultClientBrandingAttributes | undefined;
    DeviceTypeIos?: IosClientBrandingAttributes | undefined;
    DeviceTypeLinux?: DefaultClientBrandingAttributes | undefined;
    DeviceTypeWeb?: DefaultClientBrandingAttributes | undefined;
}
export type ResourceIdList = string[];
export interface DescribeClientPropertiesRequest {
    ResourceIds: string[];
}
export type ReconnectEnum = "ENABLED" | "DISABLED" | (string & {});
export type LogUploadEnum = "ENABLED" | "DISABLED" | (string & {});
export type ClientExperiencePolicy = string;
export interface ClientProperties {
    ReconnectEnabled?: ReconnectEnum | undefined;
    LogUploadEnabled?: LogUploadEnum | undefined;
    ClientExperiencePolicy?: string | undefined;
}
export interface ClientPropertiesResult {
    ResourceId?: string | undefined;
    ClientProperties?: ClientProperties | undefined;
}
export type ClientPropertiesList = ClientPropertiesResult[];
export interface DescribeClientPropertiesResult {
    ClientPropertiesList?: ClientPropertiesResult[] | undefined;
}
export interface DescribeConnectClientAddInsRequest {
    ResourceId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ConnectClientAddIn {
    AddInId?: string | undefined;
    ResourceId?: string | undefined;
    Name?: string | undefined;
    URL?: string | undefined;
}
export type ConnectClientAddInList = ConnectClientAddIn[];
export interface DescribeConnectClientAddInsResult {
    AddIns?: ConnectClientAddIn[] | undefined;
    NextToken?: string | undefined;
}
export type ConnectionAliasIdList = string[];
export interface DescribeConnectionAliasesRequest {
    AliasIds?: string[] | undefined;
    ResourceId?: string | undefined;
    Limit?: number | undefined;
    NextToken?: string | undefined;
}
export type ConnectionAliasState = "CREATING" | "CREATED" | "DELETING" | (string & {});
export type AssociationStatus = "NOT_ASSOCIATED" | "ASSOCIATED_WITH_OWNER_ACCOUNT" | "ASSOCIATED_WITH_SHARED_ACCOUNT" | "PENDING_ASSOCIATION" | "PENDING_DISASSOCIATION" | (string & {});
export interface ConnectionAliasAssociation {
    AssociationStatus?: AssociationStatus | undefined;
    AssociatedAccountId?: string | undefined;
    ResourceId?: string | undefined;
    ConnectionIdentifier?: string | undefined;
}
export type ConnectionAliasAssociationList = ConnectionAliasAssociation[];
export interface ConnectionAlias {
    ConnectionString?: string | undefined;
    AliasId?: string | undefined;
    State?: ConnectionAliasState | undefined;
    OwnerAccountId?: string | undefined;
    Associations?: ConnectionAliasAssociation[] | undefined;
}
export type ConnectionAliasList = ConnectionAlias[];
export interface DescribeConnectionAliasesResult {
    ConnectionAliases?: ConnectionAlias[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeConnectionAliasPermissionsRequest {
    AliasId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ConnectionAliasPermission {
    SharedAccountId: string;
    AllowAssociation: boolean;
}
export type ConnectionAliasPermissions = ConnectionAliasPermission[];
export interface DescribeConnectionAliasPermissionsResult {
    AliasId?: string | undefined;
    ConnectionAliasPermissions?: ConnectionAliasPermission[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeCustomWorkspaceImageImportRequest {
    ImageId: string;
}
export type InfrastructureConfigurationArn = string;
export type CustomWorkspaceImageImportState = "PENDING" | "IN_PROGRESS" | "PROCESSING_SOURCE_IMAGE" | "IMAGE_TESTING_START" | "UPDATING_OPERATING_SYSTEM" | "IMAGE_COMPATIBILITY_CHECKING" | "IMAGE_TESTING_GENERALIZATION" | "CREATING_TEST_INSTANCE" | "INSTALLING_COMPONENTS" | "GENERALIZING" | "VALIDATING" | "PUBLISHING" | "COMPLETED" | "ERROR" | (string & {});
export type WorkflowStateMessage = string;
export type Percentage = number;
export type Ec2ImportTaskId = string;
export type ImageBuildVersionArn = string;
export type Ec2ImageId = string;
export type ImageSourceIdentifier = {
    Ec2ImportTaskId: string;
    ImageBuildVersionArn?: undefined;
    Ec2ImageId?: undefined;
} | {
    Ec2ImportTaskId?: undefined;
    ImageBuildVersionArn: string;
    Ec2ImageId?: undefined;
} | {
    Ec2ImportTaskId?: undefined;
    ImageBuildVersionArn?: undefined;
    Ec2ImageId: string;
};
export type ErrorCode = string;
export type ImageErrorMessage = string;
export interface CustomWorkspaceImageImportErrorDetails {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type CustomWorkspaceImageImportErrorDetailsList = CustomWorkspaceImageImportErrorDetails[];
export interface DescribeCustomWorkspaceImageImportResult {
    ImageId?: string | undefined;
    InfrastructureConfigurationArn?: string | undefined;
    State?: CustomWorkspaceImageImportState | undefined;
    StateMessage?: string | undefined;
    ProgressPercentage?: number | undefined;
    Created?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    ImageSource?: ImageSourceIdentifier | undefined;
    ImageBuilderInstanceId?: string | undefined;
    ErrorDetails?: CustomWorkspaceImageImportErrorDetails[] | undefined;
}
export type ImageAssociatedResourceType = "APPLICATION" | (string & {});
export type ImageAssociatedResourceTypeList = ImageAssociatedResourceType[];
export interface DescribeImageAssociationsRequest {
    ImageId: string;
    AssociatedResourceTypes: ImageAssociatedResourceType[];
}
export interface ImageResourceAssociation {
    AssociatedResourceId?: string | undefined;
    AssociatedResourceType?: ImageAssociatedResourceType | undefined;
    Created?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    ImageId?: string | undefined;
    State?: AssociationState | undefined;
    StateReason?: AssociationStateReason | undefined;
}
export type ImageResourceAssociationList = ImageResourceAssociation[];
export interface DescribeImageAssociationsResult {
    Associations?: ImageResourceAssociation[] | undefined;
}
export interface DescribeIpGroupsRequest {
    GroupIds?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface WorkspacesIpGroup {
    groupId?: string | undefined;
    groupName?: string | undefined;
    groupDesc?: string | undefined;
    userRules?: IpRuleItem[] | undefined;
}
export type WorkspacesIpGroupsList = WorkspacesIpGroup[];
export interface DescribeIpGroupsResult {
    Result?: WorkspacesIpGroup[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeTagsRequest {
    ResourceId: string;
}
export interface DescribeTagsResult {
    TagList?: Tag[] | undefined;
}
export type WorkSpaceAssociatedResourceTypeList = WorkSpaceAssociatedResourceType[];
export interface DescribeWorkspaceAssociationsRequest {
    WorkspaceId: string;
    AssociatedResourceTypes: WorkSpaceAssociatedResourceType[];
}
export interface DescribeWorkspaceAssociationsResult {
    Associations?: WorkspaceResourceAssociation[] | undefined;
}
export type BundleIdList = string[];
export interface DescribeWorkspaceBundlesRequest {
    BundleIds?: string[] | undefined;
    Owner?: string | undefined;
    NextToken?: string | undefined;
}
export type BundleList = WorkspaceBundle[];
export interface DescribeWorkspaceBundlesResult {
    Bundles?: WorkspaceBundle[] | undefined;
    NextToken?: string | undefined;
}
export type DirectoryIdList = string[];
export type WorkspaceDirectoryName = string;
export type WorkspaceDirectoryNameList = string[];
export type DescribeWorkspaceDirectoriesFilterName = "USER_IDENTITY_TYPE" | "WORKSPACE_TYPE" | (string & {});
export type DescribeWorkspaceDirectoriesFilterValue = string;
export type DescribeWorkspaceDirectoriesFilterValues = string[];
export interface DescribeWorkspaceDirectoriesFilter {
    Name: DescribeWorkspaceDirectoriesFilterName;
    Values: string[];
}
export type DescribeWorkspaceDirectoriesFilterList = DescribeWorkspaceDirectoriesFilter[];
export interface DescribeWorkspaceDirectoriesRequest {
    DirectoryIds?: string[] | undefined;
    WorkspaceDirectoryNames?: string[] | undefined;
    Limit?: number | undefined;
    NextToken?: string | undefined;
    Filters?: DescribeWorkspaceDirectoriesFilter[] | undefined;
}
export type Alias = string;
export type DirectoryName = string;
export type RegistrationCode = string;
export type SubnetIds = string[];
export type DnsIpAddresses = string[];
export type DnsIpv6Addresses = string[];
export type WorkspaceDirectoryType = "SIMPLE_AD" | "AD_CONNECTOR" | "CUSTOMER_MANAGED" | "AWS_IAM_IDENTITY_CENTER" | (string & {});
export type SecurityGroupId = string;
export type WorkspaceDirectoryState = "REGISTERING" | "REGISTERED" | "DEREGISTERING" | "DEREGISTERED" | "ERROR" | (string & {});
export type DefaultOu = string;
export interface DefaultWorkspaceCreationProperties {
    EnableInternetAccess?: boolean | undefined;
    DefaultOu?: string | undefined;
    CustomSecurityGroupId?: string | undefined;
    UserEnabledAsLocalAdministrator?: boolean | undefined;
    EnableMaintenanceMode?: boolean | undefined;
    InstanceIamRoleArn?: string | undefined;
}
export type AccessPropertyValue = "ALLOW" | "DENY" | (string & {});
export type AccessEndpointType = "STREAMING_WSP" | (string & {});
export type AlphanumericDashUnderscoreNonEmptyString = string;
export interface AccessEndpoint {
    AccessEndpointType?: AccessEndpointType | undefined;
    VpcEndpointId?: string | undefined;
}
export type AccessEndpointList = AccessEndpoint[];
export type InternetFallbackProtocol = "PCOIP" | (string & {});
export type InternetFallbackProtocolList = InternetFallbackProtocol[];
export interface AccessEndpointConfig {
    AccessEndpoints: AccessEndpoint[];
    InternetFallbackProtocols?: InternetFallbackProtocol[] | undefined;
}
export interface WorkspaceAccessProperties {
    DeviceTypeWindows?: AccessPropertyValue | undefined;
    DeviceTypeOsx?: AccessPropertyValue | undefined;
    DeviceTypeWeb?: AccessPropertyValue | undefined;
    DeviceTypeIos?: AccessPropertyValue | undefined;
    DeviceTypeAndroid?: AccessPropertyValue | undefined;
    DeviceTypeChromeOs?: AccessPropertyValue | undefined;
    DeviceTypeZeroClient?: AccessPropertyValue | undefined;
    DeviceTypeLinux?: AccessPropertyValue | undefined;
    DeviceTypeWorkSpacesThinClient?: AccessPropertyValue | undefined;
    AccessEndpointConfig?: AccessEndpointConfig | undefined;
}
export type Tenancy = "DEDICATED" | "SHARED" | (string & {});
export interface SelfservicePermissions {
    RestartWorkspace?: ReconnectEnum | undefined;
    IncreaseVolumeSize?: ReconnectEnum | undefined;
    ChangeComputeType?: ReconnectEnum | undefined;
    SwitchRunningMode?: ReconnectEnum | undefined;
    RebuildWorkspace?: ReconnectEnum | undefined;
}
export type SamlStatusEnum = "DISABLED" | "ENABLED" | "ENABLED_WITH_DIRECTORY_LOGIN_FALLBACK" | (string & {});
export type SamlUserAccessUrl = string;
export interface SamlProperties {
    Status?: SamlStatusEnum | undefined;
    UserAccessUrl?: string | undefined;
    RelayStateParameterName?: string | undefined;
}
export type CertificateBasedAuthStatusEnum = "DISABLED" | "ENABLED" | (string & {});
export type CertificateAuthorityArn = string;
export interface CertificateBasedAuthProperties {
    Status?: CertificateBasedAuthStatusEnum | undefined;
    CertificateAuthorityArn?: string | undefined;
}
export type EndpointEncryptionMode = "STANDARD_TLS" | "FIPS_VALIDATED" | (string & {});
export type MicrosoftEntraConfigTenantId = string;
export type SecretsManagerArn = string;
export interface MicrosoftEntraConfig {
    TenantId?: string | undefined;
    ApplicationConfigSecretArn?: string | undefined;
}
export type WorkspaceDirectoryDescription = string;
export type UserIdentityType = "CUSTOMER_MANAGED" | "AWS_DIRECTORY_SERVICE" | "AWS_IAM_IDENTITY_CENTER" | (string & {});
export type WorkspaceType = "PERSONAL" | "POOLS" | (string & {});
export interface IDCConfig {
    InstanceArn?: string | undefined;
    ApplicationArn?: string | undefined;
}
export type DomainName = string;
export interface ActiveDirectoryConfig {
    DomainName: string;
    ServiceAccountSecretArn: string;
}
export type StreamingExperiencePreferredProtocolEnum = "TCP" | "UDP" | (string & {});
export type UserSettingActionEnum = "CLIPBOARD_COPY_FROM_LOCAL_DEVICE" | "CLIPBOARD_COPY_TO_LOCAL_DEVICE" | "PRINTING_TO_LOCAL_DEVICE" | "SMART_CARD" | (string & {});
export type UserSettingPermissionEnum = "ENABLED" | "DISABLED" | (string & {});
export type MaximumLength = number;
export interface UserSetting {
    Action: UserSettingActionEnum;
    Permission: UserSettingPermissionEnum;
    MaximumLength?: number | undefined;
}
export type UserSettings = UserSetting[];
export type StorageConnectorTypeEnum = "HOME_FOLDER" | (string & {});
export type StorageConnectorStatusEnum = "ENABLED" | "DISABLED" | (string & {});
export interface StorageConnector {
    ConnectorType: StorageConnectorTypeEnum;
    Status: StorageConnectorStatusEnum;
}
export type StorageConnectors = StorageConnector[];
export type AGAModeForDirectoryEnum = "ENABLED_AUTO" | "DISABLED" | (string & {});
export type AGAPreferredProtocolForDirectory = "TCP" | "NONE" | (string & {});
export interface GlobalAcceleratorForDirectory {
    Mode: AGAModeForDirectoryEnum;
    PreferredProtocol?: AGAPreferredProtocolForDirectory | undefined;
}
export interface StreamingProperties {
    StreamingExperiencePreferredProtocol?: StreamingExperiencePreferredProtocolEnum | undefined;
    UserSettings?: UserSetting[] | undefined;
    StorageConnectors?: StorageConnector[] | undefined;
    GlobalAccelerator?: GlobalAcceleratorForDirectory | undefined;
}
export interface WorkspaceDirectory {
    DirectoryId?: string | undefined;
    Alias?: string | undefined;
    DirectoryName?: string | undefined;
    RegistrationCode?: string | undefined;
    SubnetIds?: string[] | undefined;
    DnsIpAddresses?: string[] | undefined;
    DnsIpv6Addresses?: string[] | undefined;
    CustomerUserName?: string | undefined;
    IamRoleId?: string | undefined;
    DirectoryType?: WorkspaceDirectoryType | undefined;
    WorkspaceSecurityGroupId?: string | undefined;
    State?: WorkspaceDirectoryState | undefined;
    WorkspaceCreationProperties?: DefaultWorkspaceCreationProperties | undefined;
    ipGroupIds?: string[] | undefined;
    WorkspaceAccessProperties?: WorkspaceAccessProperties | undefined;
    Tenancy?: Tenancy | undefined;
    SelfservicePermissions?: SelfservicePermissions | undefined;
    SamlProperties?: SamlProperties | undefined;
    CertificateBasedAuthProperties?: CertificateBasedAuthProperties | undefined;
    EndpointEncryptionMode?: EndpointEncryptionMode | undefined;
    MicrosoftEntraConfig?: MicrosoftEntraConfig | undefined;
    WorkspaceDirectoryName?: string | undefined;
    WorkspaceDirectoryDescription?: string | undefined;
    UserIdentityType?: UserIdentityType | undefined;
    WorkspaceType?: WorkspaceType | undefined;
    IDCConfig?: IDCConfig | undefined;
    ActiveDirectoryConfig?: ActiveDirectoryConfig | undefined;
    StreamingProperties?: StreamingProperties | undefined;
    ErrorMessage?: string | undefined;
}
export type DirectoryList = WorkspaceDirectory[];
export interface DescribeWorkspaceDirectoriesResult {
    Directories?: WorkspaceDirectory[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeWorkspaceImagePermissionsRequest {
    ImageId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ImagePermission {
    SharedAccountId?: string | undefined;
}
export type ImagePermissions = ImagePermission[];
export interface DescribeWorkspaceImagePermissionsResult {
    ImageId?: string | undefined;
    ImagePermissions?: ImagePermission[] | undefined;
    NextToken?: string | undefined;
}
export type WorkspaceImageIdList = string[];
export type ImageType = "OWNED" | "SHARED" | (string & {});
export interface DescribeWorkspaceImagesRequest {
    ImageIds?: string[] | undefined;
    ImageType?: ImageType | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type WorkspaceImageErrorCode = string;
export interface UpdateResult {
    UpdateAvailable?: boolean | undefined;
    Description?: string | undefined;
}
export type WorkspaceImageErrorDetailCode = "OutdatedPowershellVersion" | "OfficeInstalled" | "PCoIPAgentInstalled" | "WindowsUpdatesEnabled" | "AutoMountDisabled" | "WorkspacesBYOLAccountNotFound" | "WorkspacesBYOLAccountDisabled" | "DHCPDisabled" | "DiskFreeSpace" | "AdditionalDrivesAttached" | "OSNotSupported" | "DomainJoined" | "AzureDomainJoined" | "FirewallEnabled" | "VMWareToolsInstalled" | "DiskSizeExceeded" | "IncompatiblePartitioning" | "PendingReboot" | "AutoLogonEnabled" | "RealTimeUniversalDisabled" | "MultipleBootPartition" | "Requires64BitOS" | "ZeroRearmCount" | "InPlaceUpgrade" | "AntiVirusInstalled" | "UEFINotSupported" | "UnknownError" | "AppXPackagesInstalled" | "ReservedStorageInUse" | "AdditionalDrivesPresent" | "WindowsUpdatesRequired" | "SysPrepFileMissing" | "UserProfileMissing" | "InsufficientDiskSpace" | "EnvironmentVariablesPathMissingEntries" | "DomainAccountServicesFound" | "InvalidIp" | "RemoteDesktopServicesDisabled" | "WindowsModulesInstallerDisabled" | "AmazonSsmAgentEnabled" | "UnsupportedSecurityProtocol" | "MultipleUserProfiles" | "StagedAppxPackage" | "UnsupportedOsUpgrade" | "InsufficientRearmCount" | "ProtocolOSIncompatibility" | "MemoryIntegrityIncompatibility" | "RestrictedDriveLetterInUse" | (string & {});
export interface ErrorDetails {
    ErrorCode?: WorkspaceImageErrorDetailCode | undefined;
    ErrorMessage?: string | undefined;
}
export type ErrorDetailsList = ErrorDetails[];
export interface WorkspaceImage {
    ImageId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    OperatingSystem?: OperatingSystem | undefined;
    State?: WorkspaceImageState | undefined;
    RequiredTenancy?: WorkspaceImageRequiredTenancy | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
    Created?: Date | undefined;
    OwnerAccountId?: string | undefined;
    Updates?: UpdateResult | undefined;
    ErrorDetails?: ErrorDetails[] | undefined;
}
export type WorkspaceImageList = WorkspaceImage[];
export interface DescribeWorkspaceImagesResult {
    Images?: WorkspaceImage[] | undefined;
    NextToken?: string | undefined;
}
export type WorkspaceIdList = string[];
export interface DescribeWorkspacesRequest {
    WorkspaceIds?: string[] | undefined;
    DirectoryId?: string | undefined;
    UserName?: string | undefined;
    BundleId?: string | undefined;
    Limit?: number | undefined;
    NextToken?: string | undefined;
    WorkspaceName?: string | undefined;
}
export interface DescribeWorkspacesResult {
    Workspaces?: Workspace[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeWorkspacesConnectionStatusRequest {
    WorkspaceIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export type ConnectionState = "CONNECTED" | "DISCONNECTED" | "UNKNOWN" | (string & {});
export interface WorkspaceConnectionStatus {
    WorkspaceId?: string | undefined;
    ConnectionState?: ConnectionState | undefined;
    ConnectionStateCheckTimestamp?: Date | undefined;
    LastKnownUserConnectionTimestamp?: Date | undefined;
}
export type WorkspaceConnectionStatusList = WorkspaceConnectionStatus[];
export interface DescribeWorkspacesConnectionStatusResult {
    WorkspacesConnectionStatus?: WorkspaceConnectionStatus[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeWorkspaceSnapshotsRequest {
    WorkspaceId: string;
}
export interface Snapshot {
    SnapshotTime?: Date | undefined;
}
export type SnapshotList = Snapshot[];
export interface DescribeWorkspaceSnapshotsResult {
    RebuildSnapshots?: Snapshot[] | undefined;
    RestoreSnapshots?: Snapshot[] | undefined;
}
export type WorkspacesPoolIds = string[];
export type DescribeWorkspacesPoolsFilterName = "PoolName" | (string & {});
export type DescribeWorkspacesPoolsFilterValue = string;
export type DescribeWorkspacesPoolsFilterValues = string[];
export type DescribeWorkspacesPoolsFilterOperator = "EQUALS" | "NOTEQUALS" | "CONTAINS" | "NOTCONTAINS" | (string & {});
export interface DescribeWorkspacesPoolsFilter {
    Name: DescribeWorkspacesPoolsFilterName;
    Values: string[];
    Operator: DescribeWorkspacesPoolsFilterOperator;
}
export type DescribeWorkspacesPoolsFilters = DescribeWorkspacesPoolsFilter[];
export interface DescribeWorkspacesPoolsRequest {
    PoolIds?: string[] | undefined;
    Filters?: DescribeWorkspacesPoolsFilter[] | undefined;
    Limit?: number | undefined;
    NextToken?: string | undefined;
}
export type WorkspacesPools = WorkspacesPool[];
export interface DescribeWorkspacesPoolsResult {
    WorkspacesPools?: WorkspacesPool[] | undefined;
    NextToken?: string | undefined;
}
export type WorkspacesPoolUserId = string;
export type Limit50 = number;
export interface DescribeWorkspacesPoolSessionsRequest {
    PoolId: string;
    UserId?: string | undefined;
    Limit?: number | undefined;
    NextToken?: string | undefined;
}
export type AuthenticationType = "SAML" | (string & {});
export type SessionConnectionState = "CONNECTED" | "NOT_CONNECTED" | (string & {});
export type SessionInstanceId = string;
export interface NetworkAccessConfiguration {
    EniPrivateIpAddress?: string | undefined;
    EniId?: string | undefined;
}
export interface WorkspacesPoolSession {
    AuthenticationType?: AuthenticationType | undefined;
    ConnectionState?: SessionConnectionState | undefined;
    SessionId: string;
    InstanceId?: string | undefined;
    PoolId: string;
    ExpirationTime?: Date | undefined;
    NetworkAccessConfiguration?: NetworkAccessConfiguration | undefined;
    StartTime?: Date | undefined;
    UserId: string;
}
export type WorkspacesPoolSessions = WorkspacesPoolSession[];
export interface DescribeWorkspacesPoolSessionsResult {
    Sessions?: WorkspacesPoolSession[] | undefined;
    NextToken?: string | undefined;
}
export interface DisassociateConnectionAliasRequest {
    AliasId: string;
}
export interface DisassociateConnectionAliasResult {
}
export interface DisassociateIpGroupsRequest {
    DirectoryId: string;
    GroupIds: string[];
}
export interface DisassociateIpGroupsResult {
}
export interface DisassociateWorkspaceApplicationRequest {
    WorkspaceId: string;
    ApplicationId: string;
}
export interface DisassociateWorkspaceApplicationResult {
    Association?: WorkspaceResourceAssociation | undefined;
}
export interface GetAccountLinkRequest {
    LinkId?: string | undefined;
    LinkedAccountId?: string | undefined;
}
export interface GetAccountLinkResult {
    AccountLink?: AccountLink | undefined;
}
export type DefaultLogo = Uint8Array;
export interface DefaultImportClientBrandingAttributes {
    Logo?: Uint8Array | undefined;
    SupportEmail?: string | undefined;
    SupportLink?: string | undefined;
    ForgotPasswordLink?: string | undefined;
    LoginMessage?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type IosLogo = Uint8Array;
export type Ios2XLogo = Uint8Array;
export type Ios3XLogo = Uint8Array;
export interface IosImportClientBrandingAttributes {
    Logo?: Uint8Array | undefined;
    Logo2x?: Uint8Array | undefined;
    Logo3x?: Uint8Array | undefined;
    SupportEmail?: string | undefined;
    SupportLink?: string | undefined;
    ForgotPasswordLink?: string | undefined;
    LoginMessage?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ImportClientBrandingRequest {
    ResourceId: string;
    DeviceTypeWindows?: DefaultImportClientBrandingAttributes | undefined;
    DeviceTypeOsx?: DefaultImportClientBrandingAttributes | undefined;
    DeviceTypeAndroid?: DefaultImportClientBrandingAttributes | undefined;
    DeviceTypeIos?: IosImportClientBrandingAttributes | undefined;
    DeviceTypeLinux?: DefaultImportClientBrandingAttributes | undefined;
    DeviceTypeWeb?: DefaultImportClientBrandingAttributes | undefined;
}
export interface ImportClientBrandingResult {
    DeviceTypeWindows?: DefaultClientBrandingAttributes | undefined;
    DeviceTypeOsx?: DefaultClientBrandingAttributes | undefined;
    DeviceTypeAndroid?: DefaultClientBrandingAttributes | undefined;
    DeviceTypeIos?: IosClientBrandingAttributes | undefined;
    DeviceTypeLinux?: DefaultClientBrandingAttributes | undefined;
    DeviceTypeWeb?: DefaultClientBrandingAttributes | undefined;
}
export type ImageComputeType = "BASE" | "GRAPHICS_G4DN" | "GRAPHICS_G6" | "GRAPHICS_G7" | (string & {});
export type CustomImageProtocol = "PCOIP" | "DCV" | "BYOP" | (string & {});
export type Platform = "WINDOWS" | (string & {});
export type OSVersion = "Windows_10" | "Windows_11" | (string & {});
export type ImageValidationMode = "CUSTOMER_MANAGED" | "SERVICE_MANAGED" | (string & {});
export interface ImportCustomWorkspaceImageRequest {
    ImageName: string;
    ImageDescription: string;
    ComputeType: ImageComputeType;
    Protocol: CustomImageProtocol;
    ImageSource: ImageSourceIdentifier;
    InfrastructureConfigurationArn: string;
    Platform: Platform;
    OsVersion: OSVersion;
    Tags?: Tag[] | undefined;
    ImageValidationMode?: ImageValidationMode | undefined;
}
export interface ImportCustomWorkspaceImageResult {
    ImageId?: string | undefined;
    State?: CustomWorkspaceImageImportState | undefined;
}
export type WorkspaceImageIngestionProcess = "BYOL_REGULAR" | "BYOL_GRAPHICS" | "BYOL_GRAPHICSPRO" | "BYOL_GRAPHICS_G4DN" | "BYOL_REGULAR_WSP" | "BYOL_GRAPHICS_G4DN_WSP" | "BYOL_REGULAR_BYOP" | "BYOL_GRAPHICS_G4DN_BYOP" | (string & {});
export type Application = "Microsoft_Office_2016" | "Microsoft_Office_2019" | (string & {});
export type ApplicationList = Application[];
export interface ImportWorkspaceImageRequest {
    Ec2ImageId: string;
    IngestionProcess: WorkspaceImageIngestionProcess;
    ImageName: string;
    ImageDescription: string;
    Tags?: Tag[] | undefined;
    Applications?: Application[] | undefined;
}
export interface ImportWorkspaceImageResult {
    ImageId?: string | undefined;
}
export type LinkStatusFilterList = AccountLinkStatusEnum[];
export interface ListAccountLinksRequest {
    LinkStatusFilter?: AccountLinkStatusEnum[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type AccountLinkList = AccountLink[];
export interface ListAccountLinksResult {
    AccountLinks?: AccountLink[] | undefined;
    NextToken?: string | undefined;
}
export type ManagementCidrRangeConstraint = string;
export type ManagementCidrRangeMaxResults = number;
export interface ListAvailableManagementCidrRangesRequest {
    ManagementCidrRangeConstraint: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DedicatedTenancyCidrRangeList = string[];
export interface ListAvailableManagementCidrRangesResult {
    ManagementCidrRanges?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface MigrateWorkspaceRequest {
    SourceWorkspaceId: string;
    BundleId: string;
}
export interface MigrateWorkspaceResult {
    SourceWorkspaceId?: string | undefined;
    TargetWorkspaceId?: string | undefined;
}
export type DedicatedTenancySupportEnum = "ENABLED" | (string & {});
export interface ModifyAccountRequest {
    DedicatedTenancySupport?: DedicatedTenancySupportEnum | undefined;
    DedicatedTenancyManagementCidrRange?: string | undefined;
}
export interface ModifyAccountResult {
    Message?: string | undefined;
}
export type DeletableCertificateBasedAuthProperty = "CERTIFICATE_BASED_AUTH_PROPERTIES_CERTIFICATE_AUTHORITY_ARN" | (string & {});
export type DeletableCertificateBasedAuthPropertiesList = DeletableCertificateBasedAuthProperty[];
export interface ModifyCertificateBasedAuthPropertiesRequest {
    ResourceId: string;
    CertificateBasedAuthProperties?: CertificateBasedAuthProperties | undefined;
    PropertiesToDelete?: DeletableCertificateBasedAuthProperty[] | undefined;
}
export interface ModifyCertificateBasedAuthPropertiesResult {
}
export interface ModifyClientPropertiesRequest {
    ResourceId: string;
    ClientProperties: ClientProperties;
}
export interface ModifyClientPropertiesResult {
}
export interface ModifyEndpointEncryptionModeRequest {
    DirectoryId: string;
    EndpointEncryptionMode: EndpointEncryptionMode;
}
export interface ModifyEndpointEncryptionModeResponse {
}
export type DeletableSamlProperty = "SAML_PROPERTIES_USER_ACCESS_URL" | "SAML_PROPERTIES_RELAY_STATE_PARAMETER_NAME" | (string & {});
export type DeletableSamlPropertiesList = DeletableSamlProperty[];
export interface ModifySamlPropertiesRequest {
    ResourceId: string;
    SamlProperties?: SamlProperties | undefined;
    PropertiesToDelete?: DeletableSamlProperty[] | undefined;
}
export interface ModifySamlPropertiesResult {
}
export interface ModifySelfservicePermissionsRequest {
    ResourceId: string;
    SelfservicePermissions: SelfservicePermissions;
}
export interface ModifySelfservicePermissionsResult {
}
export interface ModifyStreamingPropertiesRequest {
    ResourceId: string;
    StreamingProperties?: StreamingProperties | undefined;
}
export interface ModifyStreamingPropertiesResult {
}
export interface ModifyWorkspaceAccessPropertiesRequest {
    ResourceId: string;
    WorkspaceAccessProperties: WorkspaceAccessProperties;
}
export interface ModifyWorkspaceAccessPropertiesResult {
}
export interface WorkspaceCreationProperties {
    EnableInternetAccess?: boolean | undefined;
    DefaultOu?: string | undefined;
    CustomSecurityGroupId?: string | undefined;
    UserEnabledAsLocalAdministrator?: boolean | undefined;
    EnableMaintenanceMode?: boolean | undefined;
    InstanceIamRoleArn?: string | undefined;
}
export interface ModifyWorkspaceCreationPropertiesRequest {
    ResourceId: string;
    WorkspaceCreationProperties: WorkspaceCreationProperties;
}
export interface ModifyWorkspaceCreationPropertiesResult {
}
export interface ModifyWorkspacePropertiesRequest {
    WorkspaceId: string;
    WorkspaceProperties?: WorkspaceProperties | undefined;
    DataReplication?: DataReplication | undefined;
}
export interface ModifyWorkspacePropertiesResult {
}
export type TargetWorkspaceState = "AVAILABLE" | "ADMIN_MAINTENANCE" | (string & {});
export interface ModifyWorkspaceStateRequest {
    WorkspaceId: string;
    WorkspaceState: TargetWorkspaceState;
}
export interface ModifyWorkspaceStateResult {
}
export interface RebootRequest {
    WorkspaceId: string;
}
export type RebootWorkspaceRequests = RebootRequest[];
export interface RebootWorkspacesRequest {
    RebootWorkspaceRequests: RebootRequest[];
}
export interface FailedWorkspaceChangeRequest {
    WorkspaceId?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type FailedRebootWorkspaceRequests = FailedWorkspaceChangeRequest[];
export interface RebootWorkspacesResult {
    FailedRequests?: FailedWorkspaceChangeRequest[] | undefined;
}
export interface RebuildRequest {
    WorkspaceId: string;
}
export type RebuildWorkspaceRequests = RebuildRequest[];
export interface RebuildWorkspacesRequest {
    RebuildWorkspaceRequests: RebuildRequest[];
}
export type FailedRebuildWorkspaceRequests = FailedWorkspaceChangeRequest[];
export interface RebuildWorkspacesResult {
    FailedRequests?: FailedWorkspaceChangeRequest[] | undefined;
}
export interface RegisterWorkspaceDirectoryRequest {
    DirectoryId?: string | undefined;
    SubnetIds?: string[] | undefined;
    EnableSelfService?: boolean | undefined;
    Tenancy?: Tenancy | undefined;
    Tags?: Tag[] | undefined;
    WorkspaceDirectoryName?: string | undefined;
    WorkspaceDirectoryDescription?: string | undefined;
    UserIdentityType?: UserIdentityType | undefined;
    IdcInstanceArn?: string | undefined;
    MicrosoftEntraConfig?: MicrosoftEntraConfig | undefined;
    WorkspaceType?: WorkspaceType | undefined;
    ActiveDirectoryConfig?: ActiveDirectoryConfig | undefined;
}
export interface RegisterWorkspaceDirectoryResult {
    DirectoryId?: string | undefined;
    State?: WorkspaceDirectoryState | undefined;
}
export interface RejectAccountLinkInvitationRequest {
    LinkId: string;
    ClientToken?: string | undefined;
}
export interface RejectAccountLinkInvitationResult {
    AccountLink?: AccountLink | undefined;
}
export interface RestoreWorkspaceRequest {
    WorkspaceId: string;
}
export interface RestoreWorkspaceResult {
}
export type IpRevokedRuleList = string[];
export interface RevokeIpRulesRequest {
    GroupId: string;
    UserRules: string[];
}
export interface RevokeIpRulesResult {
}
export interface StartRequest {
    WorkspaceId?: string | undefined;
}
export type StartWorkspaceRequests = StartRequest[];
export interface StartWorkspacesRequest {
    StartWorkspaceRequests: StartRequest[];
}
export type FailedStartWorkspaceRequests = FailedWorkspaceChangeRequest[];
export interface StartWorkspacesResult {
    FailedRequests?: FailedWorkspaceChangeRequest[] | undefined;
}
export interface StartWorkspacesPoolRequest {
    PoolId: string;
}
export interface StartWorkspacesPoolResult {
}
export interface StopRequest {
    WorkspaceId?: string | undefined;
}
export type StopWorkspaceRequests = StopRequest[];
export interface StopWorkspacesRequest {
    StopWorkspaceRequests: StopRequest[];
}
export type FailedStopWorkspaceRequests = FailedWorkspaceChangeRequest[];
export interface StopWorkspacesResult {
    FailedRequests?: FailedWorkspaceChangeRequest[] | undefined;
}
export interface StopWorkspacesPoolRequest {
    PoolId: string;
}
export interface StopWorkspacesPoolResult {
}
export interface TerminateRequest {
    WorkspaceId: string;
}
export type TerminateWorkspaceRequests = TerminateRequest[];
export interface TerminateWorkspacesRequest {
    TerminateWorkspaceRequests: TerminateRequest[];
}
export type FailedTerminateWorkspaceRequests = FailedWorkspaceChangeRequest[];
export interface TerminateWorkspacesResult {
    FailedRequests?: FailedWorkspaceChangeRequest[] | undefined;
}
export interface TerminateWorkspacesPoolRequest {
    PoolId: string;
}
export interface TerminateWorkspacesPoolResult {
}
export interface TerminateWorkspacesPoolSessionRequest {
    SessionId: string;
}
export interface TerminateWorkspacesPoolSessionResult {
}
export interface UpdateConnectClientAddInRequest {
    AddInId: string;
    ResourceId: string;
    Name?: string | undefined;
    URL?: string | undefined;
}
export interface UpdateConnectClientAddInResult {
}
export interface UpdateConnectionAliasPermissionRequest {
    AliasId: string;
    ConnectionAliasPermission: ConnectionAliasPermission;
}
export interface UpdateConnectionAliasPermissionResult {
}
export interface UpdateRulesOfIpGroupRequest {
    GroupId: string;
    UserRules: IpRuleItem[];
}
export interface UpdateRulesOfIpGroupResult {
}
export interface UpdateWorkspaceBundleRequest {
    BundleId?: string | undefined;
    ImageId?: string | undefined;
}
export interface UpdateWorkspaceBundleResult {
}
export interface UpdateWorkspaceImagePermissionRequest {
    ImageId: string;
    AllowCopyImage: boolean;
    SharedAccountId: string;
}
export interface UpdateWorkspaceImagePermissionResult {
}
export interface UpdateWorkspacesPoolRequest {
    PoolId: string;
    Description?: string | undefined;
    BundleId?: string | undefined;
    DirectoryId?: string | undefined;
    Capacity?: Capacity | undefined;
    ApplicationSettings?: ApplicationSettingsRequest | undefined;
    TimeoutSettings?: TimeoutSettings | undefined;
    RunningMode?: PoolsRunningMode | undefined;
}
export interface UpdateWorkspacesPoolResult {
    WorkspacesPool?: WorkspacesPool | undefined;
}
export type ExceptionMessage = string;
export type ExceptionErrorCode = string;
export type AcceptAccountLinkInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Accepts the account link invitation.
 *
 * There's currently no unlinking capability after you accept the account linking invitation.
 */
export declare const acceptAccountLinkInvitation: API.OperationMethod<AcceptAccountLinkInvitationRequest & RegionInput, AcceptAccountLinkInvitationResult, AcceptAccountLinkInvitationError, Credentials | HttpClient.HttpClient>;
export type AssociateConnectionAliasError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceAssociatedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified connection alias with the specified directory to enable
 * cross-Region redirection. For more information, see Cross-Region
 * Redirection for Amazon WorkSpaces.
 *
 * Before performing this operation, call
 * DescribeConnectionAliases to make sure that the current state of the
 * connection alias is `CREATED`.
 */
export declare const associateConnectionAlias: API.OperationMethod<AssociateConnectionAliasRequest & RegionInput, AssociateConnectionAliasResult, AssociateConnectionAliasError, Credentials | HttpClient.HttpClient>;
export type AssociateIpGroupsError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified IP access control group with the specified directory.
 */
export declare const associateIpGroups: API.OperationMethod<AssociateIpGroupsRequest & RegionInput, AssociateIpGroupsResult, AssociateIpGroupsError, Credentials | HttpClient.HttpClient>;
export type AssociateWorkspaceApplicationError = AccessDeniedException | ApplicationNotSupportedException | ComputeNotCompatibleException | IncompatibleApplicationsException | InvalidParameterValuesException | OperatingSystemNotCompatibleException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified application to the specified WorkSpace.
 */
export declare const associateWorkspaceApplication: API.OperationMethod<AssociateWorkspaceApplicationRequest & RegionInput, AssociateWorkspaceApplicationResult, AssociateWorkspaceApplicationError, Credentials | HttpClient.HttpClient>;
export type AuthorizeIpRulesError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more rules to the specified IP access control group.
 *
 * This action gives users permission to access their WorkSpaces from the CIDR address
 * ranges specified in the rules.
 */
export declare const authorizeIpRules: API.OperationMethod<AuthorizeIpRulesRequest & RegionInput, AuthorizeIpRulesResult, AuthorizeIpRulesError, Credentials | HttpClient.HttpClient>;
export type CopyWorkspaceImageError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Copies the specified image from the specified Region to the current Region. For more
 * information about copying images, see Copy a Custom WorkSpaces
 * Image.
 *
 * In the China (Ningxia) Region, you can copy images only within the same Region.
 *
 * In Amazon Web Services GovCloud (US), to copy images to and from other Regions, contact Amazon Web Services Support.
 *
 * Before copying a shared image, be sure to verify that it has been shared from the
 * correct Amazon Web Services account. To determine if an image has been shared and to see
 * the ID of the Amazon Web Services account that owns an image, use the DescribeWorkSpaceImages and DescribeWorkspaceImagePermissions API operations.
 */
export declare const copyWorkspaceImage: API.OperationMethod<CopyWorkspaceImageRequest & RegionInput, CopyWorkspaceImageResult, CopyWorkspaceImageError, Credentials | HttpClient.HttpClient>;
export type CreateAccountLinkInvitationError = AccessDeniedException | ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Creates the account link invitation.
 */
export declare const createAccountLinkInvitation: API.OperationMethod<CreateAccountLinkInvitationRequest & RegionInput, CreateAccountLinkInvitationResult, CreateAccountLinkInvitationError, Credentials | HttpClient.HttpClient>;
export type CreateConnectClientAddInError = AccessDeniedException | InvalidParameterValuesException | ResourceAlreadyExistsException | ResourceCreationFailedException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a client-add-in for Connect Customer within a directory. You can create only
 * one Connect Customer client add-in within a directory.
 *
 * This client add-in allows WorkSpaces users to seamlessly connect to Connect Customer.
 */
export declare const createConnectClientAddIn: API.OperationMethod<CreateConnectClientAddInRequest & RegionInput, CreateConnectClientAddInResult, CreateConnectClientAddInError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionAliasError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceLimitExceededException | CommonErrors;
/**
 * Creates the specified connection alias for use with cross-Region redirection. For more
 * information, see Cross-Region
 * Redirection for Amazon WorkSpaces.
 */
export declare const createConnectionAlias: API.OperationMethod<CreateConnectionAliasRequest & RegionInput, CreateConnectionAliasResult, CreateConnectionAliasError, Credentials | HttpClient.HttpClient>;
export type CreateIpGroupError = AccessDeniedException | InvalidParameterValuesException | ResourceAlreadyExistsException | ResourceCreationFailedException | ResourceLimitExceededException | CommonErrors;
/**
 * Creates an IP access control group.
 *
 * An IP access control group provides you with the ability to control the IP addresses
 * from which users are allowed to access their WorkSpaces. To specify the CIDR address
 * ranges, add rules to your IP access control group and then associate the group with your
 * directory. You can add rules when you create the group or at any time using AuthorizeIpRules.
 *
 * There is a default IP access control group associated with your directory. If you don't
 * associate an IP access control group with your directory, the default group is used. The
 * default group includes a default rule that allows users to access their WorkSpaces from
 * anywhere. You cannot modify the default IP access control group for your directory.
 */
export declare const createIpGroup: API.OperationMethod<CreateIpGroupRequest & RegionInput, CreateIpGroupResult, CreateIpGroupError, Credentials | HttpClient.HttpClient>;
export type CreateStandbyWorkspacesError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a standby WorkSpace in a secondary Region.
 */
export declare const createStandbyWorkspaces: API.OperationMethod<CreateStandbyWorkspacesRequest & RegionInput, CreateStandbyWorkspacesResult, CreateStandbyWorkspacesError, Credentials | HttpClient.HttpClient>;
export type CreateTagsError = InvalidParameterValuesException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates the specified tags for the specified WorkSpaces resource.
 */
export declare const createTags: API.OperationMethod<CreateTagsRequest & RegionInput, CreateTagsResult, CreateTagsError, Credentials | HttpClient.HttpClient>;
export type CreateUpdatedWorkspaceImageError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new updated WorkSpace image based on the specified source image. The new
 * updated WorkSpace image has the latest drivers and other updates required by the
 * Amazon WorkSpaces components.
 *
 * To determine which WorkSpace images need to be updated with the latest Amazon WorkSpaces
 * requirements, use
 * DescribeWorkspaceImages.
 *
 * - Only Windows 10, Windows Server 2016, and Windows Server 2019 WorkSpace images
 * can be programmatically updated at this time.
 *
 * - Microsoft Windows updates and other application updates are not included in the
 * update process.
 *
 * - The source WorkSpace image is not deleted. You can delete the source image
 * after you've verified your new updated image and created a new bundle.
 */
export declare const createUpdatedWorkspaceImage: API.OperationMethod<CreateUpdatedWorkspaceImageRequest & RegionInput, CreateUpdatedWorkspaceImageResult, CreateUpdatedWorkspaceImageError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceBundleError = AccessDeniedException | InvalidParameterValuesException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Creates the specified WorkSpace bundle. For more information about creating WorkSpace bundles, see
 *
 * Create a Custom WorkSpaces Image and Bundle.
 */
export declare const createWorkspaceBundle: API.OperationMethod<CreateWorkspaceBundleRequest & RegionInput, CreateWorkspaceBundleResult, CreateWorkspaceBundleError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceImageError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new WorkSpace image from an existing WorkSpace.
 */
export declare const createWorkspaceImage: API.OperationMethod<CreateWorkspaceImageRequest & RegionInput, CreateWorkspaceImageResult, CreateWorkspaceImageError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspacesError = InvalidParameterValuesException | ResourceLimitExceededException | CommonErrors;
/**
 * Creates one or more WorkSpaces.
 *
 * This operation is asynchronous and returns before the WorkSpaces are created.
 *
 * - The `MANUAL` running mode value is only supported by Amazon WorkSpaces
 * Core. Contact your account team to be allow-listed to use this value. For more
 * information, see Amazon WorkSpaces
 * Core.
 *
 * - You don't need to specify the `PCOIP` protocol for Linux bundles
 * because DCV (formerly WSP) is the default protocol for those bundles.
 *
 * - User-decoupled WorkSpaces are only supported by Amazon WorkSpaces
 * Core.
 *
 * - Review your running mode to ensure you are using one that is optimal for your needs and budget.
 * For more information on switching running modes, see
 *
 * Can I switch between hourly and monthly billing?
 */
export declare const createWorkspaces: API.OperationMethod<CreateWorkspacesRequest & RegionInput, CreateWorkspacesResult, CreateWorkspacesError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspacesPoolError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * End of support notice: On December 31, 2027, Amazon Web Services will end support for Amazon WorkSpaces Pools. After December 31, 2027,
 * you will no longer be able to access the Amazon WorkSpaces Pools console or Amazon WorkSpaces Pools resources. For more information, see
 * Amazon WorkSpaces Pools end of support.
 *
 * Creates a pool of WorkSpaces.
 */
export declare const createWorkspacesPool: API.OperationMethod<CreateWorkspacesPoolRequest & RegionInput, CreateWorkspacesPoolResult, CreateWorkspacesPoolError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountLinkInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the account link invitation.
 */
export declare const deleteAccountLinkInvitation: API.OperationMethod<DeleteAccountLinkInvitationRequest & RegionInput, DeleteAccountLinkInvitationResult, DeleteAccountLinkInvitationError, Credentials | HttpClient.HttpClient>;
export type DeleteClientBrandingError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes customized client branding. Client branding allows you to customize your
 * WorkSpace's client login portal. You can tailor your login portal company logo, the support
 * email address, support link, link to reset password, and a custom message for users trying
 * to sign in.
 *
 * After you delete your customized client branding, your login portal reverts to the
 * default client branding.
 */
export declare const deleteClientBranding: API.OperationMethod<DeleteClientBrandingRequest & RegionInput, DeleteClientBrandingResult, DeleteClientBrandingError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectClientAddInError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a client-add-in for Connect Customer that is configured within a
 * directory.
 */
export declare const deleteConnectClientAddIn: API.OperationMethod<DeleteConnectClientAddInRequest & RegionInput, DeleteConnectClientAddInResult, DeleteConnectClientAddInError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionAliasError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceAssociatedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified connection alias. For more information, see
 * Cross-Region Redirection for Amazon WorkSpaces.
 *
 * If you will no longer be using a fully qualified domain name
 * (FQDN) as the registration code for your WorkSpaces users, you must take certain
 * precautions to prevent potential security issues. For more information,
 * see Security Considerations if You Stop Using Cross-Region Redirection.
 *
 * To delete a connection alias that has been shared, the shared account must first
 * disassociate the connection alias from any directories it has been associated with. Then
 * you must unshare the connection alias from the account it has been shared with. You can
 * delete a connection alias only after it is no longer shared with any accounts or
 * associated with any directories.
 */
export declare const deleteConnectionAlias: API.OperationMethod<DeleteConnectionAliasRequest & RegionInput, DeleteConnectionAliasResult, DeleteConnectionAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteIpGroupError = AccessDeniedException | InvalidParameterValuesException | ResourceAssociatedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified IP access control group.
 *
 * You cannot delete an IP access control group that is associated with a directory.
 */
export declare const deleteIpGroup: API.OperationMethod<DeleteIpGroupRequest & RegionInput, DeleteIpGroupResult, DeleteIpGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified tags from the specified WorkSpaces resource.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsRequest & RegionInput, DeleteTagsResult, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceBundleError = AccessDeniedException | InvalidParameterValuesException | ResourceAssociatedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified WorkSpace bundle. For more information about deleting WorkSpace bundles, see
 *
 * Delete a Custom WorkSpaces Bundle or Image.
 */
export declare const deleteWorkspaceBundle: API.OperationMethod<DeleteWorkspaceBundleRequest & RegionInput, DeleteWorkspaceBundleResult, DeleteWorkspaceBundleError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceImageError = AccessDeniedException | InvalidResourceStateException | ResourceAssociatedException | CommonErrors;
/**
 * Deletes the specified image from your account. To delete an image, you must first delete
 * any bundles that are associated with the image and unshare the image if it is shared with
 * other accounts.
 */
export declare const deleteWorkspaceImage: API.OperationMethod<DeleteWorkspaceImageRequest & RegionInput, DeleteWorkspaceImageResult, DeleteWorkspaceImageError, Credentials | HttpClient.HttpClient>;
export type DeployWorkspaceApplicationsError = AccessDeniedException | IncompatibleApplicationsException | InvalidParameterValuesException | OperationNotSupportedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deploys associated applications to the specified WorkSpace
 */
export declare const deployWorkspaceApplications: API.OperationMethod<DeployWorkspaceApplicationsRequest & RegionInput, DeployWorkspaceApplicationsResult, DeployWorkspaceApplicationsError, Credentials | HttpClient.HttpClient>;
export type DeregisterWorkspaceDirectoryError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Deregisters the specified directory. This operation is asynchronous and returns before
 * the WorkSpace directory is deregistered. If any WorkSpaces are registered to this
 * directory, you must remove them before you can deregister the directory.
 *
 * Simple AD and AD Connector are made available to you free of charge to use with
 * WorkSpaces. If there are no WorkSpaces being used with your Simple AD or AD Connector
 * directory for 30 consecutive days, this directory will be automatically deregistered for
 * use with Amazon WorkSpaces, and you will be charged for this directory as per the Directory Service pricing
 * terms.
 *
 * To delete empty directories, see Delete the
 * Directory for Your WorkSpaces. If you delete your Simple AD or AD Connector
 * directory, you can always create a new one when you want to start using WorkSpaces
 * again.
 */
export declare const deregisterWorkspaceDirectory: API.OperationMethod<DeregisterWorkspaceDirectoryRequest & RegionInput, DeregisterWorkspaceDirectoryResult, DeregisterWorkspaceDirectoryError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountError = AccessDeniedException | CommonErrors;
/**
 * Retrieves a list that describes the configuration of Bring Your Own License (BYOL) for
 * the specified account.
 */
export declare const describeAccount: API.OperationMethod<DescribeAccountRequest & RegionInput, DescribeAccountResult, DescribeAccountError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountModificationsError = AccessDeniedException | CommonErrors;
/**
 * Retrieves a list that describes modifications to the configuration of Bring Your Own
 * License (BYOL) for the specified account.
 */
export declare const describeAccountModifications: API.OperationMethod<DescribeAccountModificationsRequest & RegionInput, DescribeAccountModificationsResult, DescribeAccountModificationsError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationAssociationsError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the associations between the application and the specified associated resources.
 */
export declare const describeApplicationAssociations: API.PaginatedOperationMethod<DescribeApplicationAssociationsRequest & RegionInput, DescribeApplicationAssociationsResult, DescribeApplicationAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeApplicationsError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the specified applications by filtering based on their compute types, license availability, operating systems, and owners.
 */
export declare const describeApplications: API.PaginatedOperationMethod<DescribeApplicationsRequest & RegionInput, DescribeApplicationsResult, DescribeApplicationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeBundleAssociationsError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the associations between the applications and the specified bundle.
 */
export declare const describeBundleAssociations: API.OperationMethod<DescribeBundleAssociationsRequest & RegionInput, DescribeBundleAssociationsResult, DescribeBundleAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeClientBrandingError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the specified client branding. Client branding allows you to customize the log
 * in page of various device types for your users. You can add your company logo, the support
 * email address, support link, link to reset password, and a custom message for users trying
 * to sign in.
 *
 * Only device types that have branding information configured will be shown in the
 * response.
 */
export declare const describeClientBranding: API.OperationMethod<DescribeClientBrandingRequest & RegionInput, DescribeClientBrandingResult, DescribeClientBrandingError, Credentials | HttpClient.HttpClient>;
export type DescribeClientPropertiesError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified Amazon WorkSpaces clients.
 */
export declare const describeClientProperties: API.OperationMethod<DescribeClientPropertiesRequest & RegionInput, DescribeClientPropertiesResult, DescribeClientPropertiesError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectClientAddInsError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of Connect Customer client add-ins that have been created.
 */
export declare const describeConnectClientAddIns: API.OperationMethod<DescribeConnectClientAddInsRequest & RegionInput, DescribeConnectClientAddInsResult, DescribeConnectClientAddInsError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionAliasesError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | CommonErrors;
/**
 * Retrieves a list that describes the connection aliases used for cross-Region
 * redirection. For more information, see Cross-Region
 * Redirection for Amazon WorkSpaces.
 */
export declare const describeConnectionAliases: API.OperationMethod<DescribeConnectionAliasesRequest & RegionInput, DescribeConnectionAliasesResult, DescribeConnectionAliasesError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionAliasPermissionsError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the permissions that the owner of a connection alias has granted to another
 * Amazon Web Services account for the specified connection alias. For more information, see
 * Cross-Region
 * Redirection for Amazon WorkSpaces.
 */
export declare const describeConnectionAliasPermissions: API.OperationMethod<DescribeConnectionAliasPermissionsRequest & RegionInput, DescribeConnectionAliasPermissionsResult, DescribeConnectionAliasPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomWorkspaceImageImportError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a WorkSpace BYOL image being imported via ImportCustomWorkspaceImage.
 */
export declare const describeCustomWorkspaceImageImport: API.OperationMethod<DescribeCustomWorkspaceImageImportRequest & RegionInput, DescribeCustomWorkspaceImageImportResult, DescribeCustomWorkspaceImageImportError, Credentials | HttpClient.HttpClient>;
export type DescribeImageAssociationsError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the associations between the applications and the specified image.
 */
export declare const describeImageAssociations: API.OperationMethod<DescribeImageAssociationsRequest & RegionInput, DescribeImageAssociationsResult, DescribeImageAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeIpGroupsError = AccessDeniedException | InvalidParameterValuesException | CommonErrors;
/**
 * Describes one or more of your IP access control groups.
 */
export declare const describeIpGroups: API.OperationMethod<DescribeIpGroupsRequest & RegionInput, DescribeIpGroupsResult, DescribeIpGroupsError, Credentials | HttpClient.HttpClient>;
export type DescribeTagsError = ResourceNotFoundException | CommonErrors;
/**
 * Describes the specified tags for the specified WorkSpaces resource.
 */
export declare const describeTags: API.OperationMethod<DescribeTagsRequest & RegionInput, DescribeTagsResult, DescribeTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceAssociationsError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the associations betweens applications and the specified WorkSpace.
 */
export declare const describeWorkspaceAssociations: API.OperationMethod<DescribeWorkspaceAssociationsRequest & RegionInput, DescribeWorkspaceAssociationsResult, DescribeWorkspaceAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceBundlesError = InvalidParameterValuesException | CommonErrors;
/**
 * Retrieves a list that describes the available WorkSpace bundles.
 *
 * You can filter the results using either bundle ID or owner, but not both.
 */
export declare const describeWorkspaceBundles: API.PaginatedOperationMethod<DescribeWorkspaceBundlesRequest & RegionInput, DescribeWorkspaceBundlesResult, DescribeWorkspaceBundlesError, Credentials | HttpClient.HttpClient, WorkspaceBundle>;
export type DescribeWorkspaceDirectoriesError = InvalidParameterValuesException | CommonErrors;
/**
 * Describes the available directories that are registered with Amazon WorkSpaces.
 */
export declare const describeWorkspaceDirectories: API.PaginatedOperationMethod<DescribeWorkspaceDirectoriesRequest & RegionInput, DescribeWorkspaceDirectoriesResult, DescribeWorkspaceDirectoriesError, Credentials | HttpClient.HttpClient, WorkspaceDirectory>;
export type DescribeWorkspaceImagePermissionsError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the permissions that the owner of an image has granted to other Amazon Web Services accounts for an image.
 */
export declare const describeWorkspaceImagePermissions: API.OperationMethod<DescribeWorkspaceImagePermissionsRequest & RegionInput, DescribeWorkspaceImagePermissionsResult, DescribeWorkspaceImagePermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceImagesError = AccessDeniedException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified images, if the image identifiers
 * are provided. Otherwise, all images in the account are described.
 */
export declare const describeWorkspaceImages: API.OperationMethod<DescribeWorkspaceImagesRequest & RegionInput, DescribeWorkspaceImagesResult, DescribeWorkspaceImagesError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspacesError = InvalidParameterValuesException | ResourceUnavailableException | CommonErrors;
/**
 * Describes the specified WorkSpaces.
 *
 * You can filter the results by using the bundle identifier, directory identifier, or
 * owner, but you can specify only one filter at a time.
 */
export declare const describeWorkspaces: API.PaginatedOperationMethod<DescribeWorkspacesRequest & RegionInput, DescribeWorkspacesResult, DescribeWorkspacesError, Credentials | HttpClient.HttpClient, Workspace>;
export type DescribeWorkspacesConnectionStatusError = InvalidParameterValuesException | CommonErrors;
/**
 * Describes the connection status of the specified WorkSpaces.
 */
export declare const describeWorkspacesConnectionStatus: API.OperationMethod<DescribeWorkspacesConnectionStatusRequest & RegionInput, DescribeWorkspacesConnectionStatusResult, DescribeWorkspacesConnectionStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceSnapshotsError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the snapshots for the specified WorkSpace.
 */
export declare const describeWorkspaceSnapshots: API.OperationMethod<DescribeWorkspaceSnapshotsRequest & RegionInput, DescribeWorkspaceSnapshotsResult, DescribeWorkspaceSnapshotsError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspacesPoolsError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * End of support notice: On December 31, 2027, Amazon Web Services will end support for Amazon WorkSpaces Pools. After December 31, 2027,
 * you will no longer be able to access the Amazon WorkSpaces Pools console or Amazon WorkSpaces Pools resources. For more information, see
 * Amazon WorkSpaces Pools end of support.
 *
 * Describes the specified WorkSpaces Pools.
 */
export declare const describeWorkspacesPools: API.OperationMethod<DescribeWorkspacesPoolsRequest & RegionInput, DescribeWorkspacesPoolsResult, DescribeWorkspacesPoolsError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspacesPoolSessionsError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * End of support notice: On December 31, 2027, Amazon Web Services will end support for Amazon WorkSpaces Pools. After December 31, 2027,
 * you will no longer be able to access the Amazon WorkSpaces Pools console or Amazon WorkSpaces Pools resources. For more information, see
 * Amazon WorkSpaces Pools end of support.
 *
 * Retrieves a list that describes the streaming sessions for a specified pool.
 */
export declare const describeWorkspacesPoolSessions: API.OperationMethod<DescribeWorkspacesPoolSessionsRequest & RegionInput, DescribeWorkspacesPoolSessionsResult, DescribeWorkspacesPoolSessionsError, Credentials | HttpClient.HttpClient>;
export type DisassociateConnectionAliasError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a connection alias from a directory. Disassociating a connection alias
 * disables cross-Region redirection between two directories in different Regions. For more
 * information, see Cross-Region
 * Redirection for Amazon WorkSpaces.
 *
 * Before performing this operation, call
 * DescribeConnectionAliases to make sure that the current state of the
 * connection alias is `CREATED`.
 */
export declare const disassociateConnectionAlias: API.OperationMethod<DisassociateConnectionAliasRequest & RegionInput, DisassociateConnectionAliasResult, DisassociateConnectionAliasError, Credentials | HttpClient.HttpClient>;
export type DisassociateIpGroupsError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified IP access control group from the specified directory.
 */
export declare const disassociateIpGroups: API.OperationMethod<DisassociateIpGroupsRequest & RegionInput, DisassociateIpGroupsResult, DisassociateIpGroupsError, Credentials | HttpClient.HttpClient>;
export type DisassociateWorkspaceApplicationError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified application from a WorkSpace.
 */
export declare const disassociateWorkspaceApplication: API.OperationMethod<DisassociateWorkspaceApplicationRequest & RegionInput, DisassociateWorkspaceApplicationResult, DisassociateWorkspaceApplicationError, Credentials | HttpClient.HttpClient>;
export type GetAccountLinkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves account link information.
 */
export declare const getAccountLink: API.OperationMethod<GetAccountLinkRequest & RegionInput, GetAccountLinkResult, GetAccountLinkError, Credentials | HttpClient.HttpClient>;
export type ImportClientBrandingError = AccessDeniedException | InvalidParameterValuesException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Imports client branding. Client branding allows you to customize your WorkSpace's client
 * login portal. You can tailor your login portal company logo, the support email address,
 * support link, link to reset password, and a custom message for users trying to sign
 * in.
 *
 * After you import client branding, the default branding experience for the specified
 * platform type is replaced with the imported experience
 *
 * - You must specify at least one platform type when importing client
 * branding.
 *
 * - You can import up to 6 MB of data with each request. If your request exceeds
 * this limit, you can import client branding for different platform types using
 * separate requests.
 *
 * - In each platform type, the `SupportEmail` and
 * `SupportLink` parameters are mutually exclusive. You can specify
 * only one parameter for each platform type, but not both.
 *
 * - Imported data can take up to a minute to appear in the WorkSpaces
 * client.
 */
export declare const importClientBranding: API.OperationMethod<ImportClientBrandingRequest & RegionInput, ImportClientBrandingResult, ImportClientBrandingError, Credentials | HttpClient.HttpClient>;
export type ImportCustomWorkspaceImageError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Imports the specified Windows 10 or 11 Bring Your Own License (BYOL)
 * image into Amazon WorkSpaces using EC2 Image Builder. The image must be an already licensed image that is
 * in your Amazon Web Services account, and you must own the image. For more information about
 * creating BYOL images, see Bring Your Own Windows
 * Desktop Licenses.
 */
export declare const importCustomWorkspaceImage: API.OperationMethod<ImportCustomWorkspaceImageRequest & RegionInput, ImportCustomWorkspaceImageResult, ImportCustomWorkspaceImageError, Credentials | HttpClient.HttpClient>;
export type ImportWorkspaceImageError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Imports the specified Windows 10 or 11 Bring Your Own License (BYOL)
 * image into Amazon WorkSpaces. The image must be an already licensed Amazon EC2 image that is
 * in your Amazon Web Services account, and you must own the image. For more information about
 * creating BYOL images, see Bring Your Own Windows
 * Desktop Licenses.
 */
export declare const importWorkspaceImage: API.OperationMethod<ImportWorkspaceImageRequest & RegionInput, ImportWorkspaceImageResult, ImportWorkspaceImageError, Credentials | HttpClient.HttpClient>;
export type ListAccountLinksError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all account links.
 */
export declare const listAccountLinks: API.PaginatedOperationMethod<ListAccountLinksRequest & RegionInput, ListAccountLinksResult, ListAccountLinksError, Credentials | HttpClient.HttpClient, AccountLink>;
export type ListAvailableManagementCidrRangesError = AccessDeniedException | InvalidParameterValuesException | CommonErrors;
/**
 * Retrieves a list of IP address ranges, specified as IPv4 CIDR blocks, that you can use
 * for the network management interface when you enable Bring Your Own License (BYOL).
 *
 * This operation can be run only by Amazon Web Services accounts that are enabled for BYOL.
 * If your account isn't enabled for BYOL, you'll receive an
 * `AccessDeniedException` error.
 *
 * The management network interface is connected to a secure Amazon WorkSpaces management
 * network. It is used for interactive streaming of the WorkSpace desktop to Amazon WorkSpaces
 * clients, and to allow Amazon WorkSpaces to manage the WorkSpace.
 */
export declare const listAvailableManagementCidrRanges: API.OperationMethod<ListAvailableManagementCidrRangesRequest & RegionInput, ListAvailableManagementCidrRangesResult, ListAvailableManagementCidrRangesError, Credentials | HttpClient.HttpClient>;
export type MigrateWorkspaceError = AccessDeniedException | InvalidParameterValuesException | OperationInProgressException | OperationNotSupportedException | ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Migrates a WorkSpace from one operating system or bundle type to another, while
 * retaining the data on the user volume.
 *
 * The migration process recreates the WorkSpace by using a new root volume from the target
 * bundle image and the user volume from the last available snapshot of the original
 * WorkSpace. During migration, the original `D:\Users\%USERNAME%` user profile
 * folder is renamed to `D:\Users\%USERNAME%MMddyyTHHmmss%.NotMigrated`. A new
 * `D:\Users\%USERNAME%\` folder is generated by the new OS. Certain files in
 * the old user profile are moved to the new user profile.
 *
 * For available migration scenarios, details about what happens during migration, and best
 * practices, see Migrate a
 * WorkSpace.
 *
 * If the source WorkSpace has nested virtualization enabled and the target bundle does
 * not support nested virtualization, the migration fails.
 */
export declare const migrateWorkspace: API.OperationMethod<MigrateWorkspaceRequest & RegionInput, MigrateWorkspaceResult, MigrateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type ModifyAccountError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Modifies the configuration of Bring Your Own License (BYOL) for the specified
 * account.
 */
export declare const modifyAccount: API.OperationMethod<ModifyAccountRequest & RegionInput, ModifyAccountResult, ModifyAccountError, Credentials | HttpClient.HttpClient>;
export type ModifyCertificateBasedAuthPropertiesError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the properties of the certificate-based authentication you want
 * to use with your WorkSpaces.
 */
export declare const modifyCertificateBasedAuthProperties: API.OperationMethod<ModifyCertificateBasedAuthPropertiesRequest & RegionInput, ModifyCertificateBasedAuthPropertiesResult, ModifyCertificateBasedAuthPropertiesError, Credentials | HttpClient.HttpClient>;
export type ModifyClientPropertiesError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the properties of the specified Amazon WorkSpaces clients.
 */
export declare const modifyClientProperties: API.OperationMethod<ModifyClientPropertiesRequest & RegionInput, ModifyClientPropertiesResult, ModifyClientPropertiesError, Credentials | HttpClient.HttpClient>;
export type ModifyEndpointEncryptionModeError = AccessDeniedException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the endpoint encryption mode that allows you to configure the specified
 * directory between Standard TLS and FIPS 140-2 validated mode.
 */
export declare const modifyEndpointEncryptionMode: API.OperationMethod<ModifyEndpointEncryptionModeRequest & RegionInput, ModifyEndpointEncryptionModeResponse, ModifyEndpointEncryptionModeError, Credentials | HttpClient.HttpClient>;
export type ModifySamlPropertiesError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies multiple properties related to SAML 2.0 authentication, including the enablement status,
 * user access URL, and relay state parameter name that are used for configuring federation with an
 * SAML 2.0 identity provider.
 */
export declare const modifySamlProperties: API.OperationMethod<ModifySamlPropertiesRequest & RegionInput, ModifySamlPropertiesResult, ModifySamlPropertiesError, Credentials | HttpClient.HttpClient>;
export type ModifySelfservicePermissionsError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the self-service WorkSpace management capabilities for your users. For more
 * information, see Enable Self-Service WorkSpace Management Capabilities for Your Users.
 */
export declare const modifySelfservicePermissions: API.OperationMethod<ModifySelfservicePermissionsRequest & RegionInput, ModifySelfservicePermissionsResult, ModifySelfservicePermissionsError, Credentials | HttpClient.HttpClient>;
export type ModifyStreamingPropertiesError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the specified streaming properties.
 */
export declare const modifyStreamingProperties: API.OperationMethod<ModifyStreamingPropertiesRequest & RegionInput, ModifyStreamingPropertiesResult, ModifyStreamingPropertiesError, Credentials | HttpClient.HttpClient>;
export type ModifyWorkspaceAccessPropertiesError = AccessDeniedException | InvalidParameterCombinationException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Specifies which devices and operating systems users can use to access their WorkSpaces.
 * For more information, see
 * Control Device Access.
 */
export declare const modifyWorkspaceAccessProperties: API.OperationMethod<ModifyWorkspaceAccessPropertiesRequest & RegionInput, ModifyWorkspaceAccessPropertiesResult, ModifyWorkspaceAccessPropertiesError, Credentials | HttpClient.HttpClient>;
export type ModifyWorkspaceCreationPropertiesError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Modify the default properties used to create WorkSpaces.
 */
export declare const modifyWorkspaceCreationProperties: API.OperationMethod<ModifyWorkspaceCreationPropertiesRequest & RegionInput, ModifyWorkspaceCreationPropertiesResult, ModifyWorkspaceCreationPropertiesError, Credentials | HttpClient.HttpClient>;
export type ModifyWorkspacePropertiesError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationInProgressException | ResourceNotFoundException | ResourceUnavailableException | UnsupportedWorkspaceConfigurationException | CommonErrors;
/**
 * Modifies the specified WorkSpace properties. For important information about how to
 * modify the size of the root and user volumes, see Modify a WorkSpace.
 *
 * The `MANUAL` running mode value is only supported by Amazon WorkSpaces
 * Core. Contact your account team to be allow-listed to use this value. For more
 * information, see Amazon WorkSpaces
 * Core.
 */
export declare const modifyWorkspaceProperties: API.OperationMethod<ModifyWorkspacePropertiesRequest & RegionInput, ModifyWorkspacePropertiesResult, ModifyWorkspacePropertiesError, Credentials | HttpClient.HttpClient>;
export type ModifyWorkspaceStateError = InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Sets the state of the specified WorkSpace.
 *
 * To maintain a WorkSpace without being interrupted, set the WorkSpace state to
 * `ADMIN_MAINTENANCE`. WorkSpaces in this state do not respond to requests to
 * reboot, stop, start, rebuild, or restore. An AutoStop WorkSpace in this state is not
 * stopped. Users cannot log into a WorkSpace in the `ADMIN_MAINTENANCE`
 * state.
 */
export declare const modifyWorkspaceState: API.OperationMethod<ModifyWorkspaceStateRequest & RegionInput, ModifyWorkspaceStateResult, ModifyWorkspaceStateError, Credentials | HttpClient.HttpClient>;
export type RebootWorkspacesError = OperationNotSupportedException | CommonErrors;
/**
 * Reboots the specified WorkSpaces.
 *
 * You cannot reboot a WorkSpace unless its state is `AVAILABLE`,
 * `UNHEALTHY`, or `REBOOTING`. Reboot a WorkSpace in the `REBOOTING`
 * state only if your WorkSpace has been stuck in the `REBOOTING` state for over 20 minutes.
 *
 * This operation is asynchronous and returns before the WorkSpaces have rebooted.
 */
export declare const rebootWorkspaces: API.OperationMethod<RebootWorkspacesRequest & RegionInput, RebootWorkspacesResult, RebootWorkspacesError, Credentials | HttpClient.HttpClient>;
export type RebuildWorkspacesError = OperationNotSupportedException | CommonErrors;
/**
 * Rebuilds the specified WorkSpace.
 *
 * You cannot rebuild a WorkSpace unless its state is `AVAILABLE`,
 * `ERROR`, `UNHEALTHY`, `STOPPED`, or
 * `REBOOTING`.
 *
 * Rebuilding a WorkSpace is a potentially destructive action that can result in the loss
 * of data. For more information, see Rebuild a
 * WorkSpace.
 *
 * This operation is asynchronous and returns before the WorkSpaces have been completely
 * rebuilt.
 */
export declare const rebuildWorkspaces: API.OperationMethod<RebuildWorkspacesRequest & RegionInput, RebuildWorkspacesResult, RebuildWorkspacesError, Credentials | HttpClient.HttpClient>;
export type RegisterWorkspaceDirectoryError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | UnsupportedNetworkConfigurationException | WorkspacesDefaultRoleNotFoundException | CommonErrors;
/**
 * Registers the specified directory. This operation is asynchronous and returns before the
 * WorkSpace directory is registered. If this is the first time you are registering a
 * directory, you will need to create the workspaces_DefaultRole role before you can register
 * a directory. For more information, see
 * Creating the workspaces_DefaultRole Role.
 */
export declare const registerWorkspaceDirectory: API.OperationMethod<RegisterWorkspaceDirectoryRequest & RegionInput, RegisterWorkspaceDirectoryResult, RegisterWorkspaceDirectoryError, Credentials | HttpClient.HttpClient>;
export type RejectAccountLinkInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Rejects the account link invitation.
 */
export declare const rejectAccountLinkInvitation: API.OperationMethod<RejectAccountLinkInvitationRequest & RegionInput, RejectAccountLinkInvitationResult, RejectAccountLinkInvitationError, Credentials | HttpClient.HttpClient>;
export type RestoreWorkspaceError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Restores the specified WorkSpace to its last known healthy state.
 *
 * You cannot restore a WorkSpace unless its state is ` AVAILABLE`,
 * `ERROR`, `UNHEALTHY`, or `STOPPED`.
 *
 * Restoring a WorkSpace is a potentially destructive action that can result in the loss of
 * data. For more information, see Restore a
 * WorkSpace.
 *
 * This operation is asynchronous and returns before the WorkSpace is completely
 * restored.
 */
export declare const restoreWorkspace: API.OperationMethod<RestoreWorkspaceRequest & RegionInput, RestoreWorkspaceResult, RestoreWorkspaceError, Credentials | HttpClient.HttpClient>;
export type RevokeIpRulesError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more rules from the specified IP access control group.
 */
export declare const revokeIpRules: API.OperationMethod<RevokeIpRulesRequest & RegionInput, RevokeIpRulesResult, RevokeIpRulesError, Credentials | HttpClient.HttpClient>;
export type StartWorkspacesError = CommonErrors;
/**
 * Starts the specified WorkSpaces.
 *
 * You cannot start a WorkSpace unless it has a running mode of `AutoStop` or
 * `Manual` and a state of `STOPPED`.
 */
export declare const startWorkspaces: API.OperationMethod<StartWorkspacesRequest & RegionInput, StartWorkspacesResult, StartWorkspacesError, Credentials | HttpClient.HttpClient>;
export type StartWorkspacesPoolError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationInProgressException | OperationNotSupportedException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * End of support notice: On December 31, 2027, Amazon Web Services will end support for Amazon WorkSpaces Pools. After December 31, 2027,
 * you will no longer be able to access the Amazon WorkSpaces Pools console or Amazon WorkSpaces Pools resources. For more information, see
 * Amazon WorkSpaces Pools end of support.
 *
 * Starts the specified pool.
 *
 * You cannot start a pool unless it has a running mode of
 * `AutoStop` and a state of `STOPPED`.
 */
export declare const startWorkspacesPool: API.OperationMethod<StartWorkspacesPoolRequest & RegionInput, StartWorkspacesPoolResult, StartWorkspacesPoolError, Credentials | HttpClient.HttpClient>;
export type StopWorkspacesError = CommonErrors;
/**
 * Stops the specified WorkSpaces.
 *
 * You cannot stop a WorkSpace unless it has a running mode of `AutoStop` or
 * `Manual` and a state of `AVAILABLE`, `IMPAIRED`,
 * `UNHEALTHY`, or `ERROR`.
 */
export declare const stopWorkspaces: API.OperationMethod<StopWorkspacesRequest & RegionInput, StopWorkspacesResult, StopWorkspacesError, Credentials | HttpClient.HttpClient>;
export type StopWorkspacesPoolError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationInProgressException | ResourceNotFoundException | CommonErrors;
/**
 * End of support notice: On December 31, 2027, Amazon Web Services will end support for Amazon WorkSpaces Pools. After December 31, 2027,
 * you will no longer be able to access the Amazon WorkSpaces Pools console or Amazon WorkSpaces Pools resources. For more information, see
 * Amazon WorkSpaces Pools end of support.
 *
 * Stops the specified pool.
 *
 * You cannot stop a WorkSpace pool unless it has a running mode of `AutoStop`
 * and a state of `AVAILABLE`, `IMPAIRED`, `UNHEALTHY`, or `ERROR`.
 */
export declare const stopWorkspacesPool: API.OperationMethod<StopWorkspacesPoolRequest & RegionInput, StopWorkspacesPoolResult, StopWorkspacesPoolError, Credentials | HttpClient.HttpClient>;
export type TerminateWorkspacesError = CommonErrors;
/**
 * Terminates the specified WorkSpaces.
 *
 * Terminating a WorkSpace is a permanent action and cannot be undone. The user's data
 * is destroyed. If you need to archive any user data, contact Amazon Web Services Support before
 * terminating the WorkSpace.
 *
 * You can terminate a WorkSpace that is in any state except `SUSPENDED`.
 *
 * This operation is asynchronous and returns before the WorkSpaces have been completely
 * terminated. After a WorkSpace is terminated, the `TERMINATED` state is returned
 * only briefly before the WorkSpace directory metadata is cleaned up, so this state is rarely
 * returned. To confirm that a WorkSpace is terminated, check for the WorkSpace ID by using
 *
 * DescribeWorkSpaces. If the WorkSpace ID isn't returned, then the WorkSpace has
 * been successfully terminated.
 *
 * Simple AD and AD Connector are made available to you free of charge to use with
 * WorkSpaces. If there are no WorkSpaces being used with your Simple AD or AD Connector
 * directory for 30 consecutive days, this directory will be automatically deregistered for
 * use with Amazon WorkSpaces, and you will be charged for this directory as per the Directory Service pricing
 * terms.
 *
 * To delete empty directories, see Delete the
 * Directory for Your WorkSpaces. If you delete your Simple AD or AD Connector
 * directory, you can always create a new one when you want to start using WorkSpaces
 * again.
 */
export declare const terminateWorkspaces: API.OperationMethod<TerminateWorkspacesRequest & RegionInput, TerminateWorkspacesResult, TerminateWorkspacesError, Credentials | HttpClient.HttpClient>;
export type TerminateWorkspacesPoolError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationInProgressException | ResourceNotFoundException | CommonErrors;
/**
 * End of support notice: On December 31, 2027, Amazon Web Services will end support for Amazon WorkSpaces Pools. After December 31, 2027,
 * you will no longer be able to access the Amazon WorkSpaces Pools console or Amazon WorkSpaces Pools resources. For more information, see
 * Amazon WorkSpaces Pools end of support.
 *
 * Terminates the specified pool.
 */
export declare const terminateWorkspacesPool: API.OperationMethod<TerminateWorkspacesPoolRequest & RegionInput, TerminateWorkspacesPoolResult, TerminateWorkspacesPoolError, Credentials | HttpClient.HttpClient>;
export type TerminateWorkspacesPoolSessionError = AccessDeniedException | InvalidParameterValuesException | OperationInProgressException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * End of support notice: On December 31, 2027, Amazon Web Services will end support for Amazon WorkSpaces Pools. After December 31, 2027,
 * you will no longer be able to access the Amazon WorkSpaces Pools console or Amazon WorkSpaces Pools resources. For more information, see
 * Amazon WorkSpaces Pools end of support.
 *
 * Terminates the pool session.
 */
export declare const terminateWorkspacesPoolSession: API.OperationMethod<TerminateWorkspacesPoolSessionRequest & RegionInput, TerminateWorkspacesPoolSessionResult, TerminateWorkspacesPoolSessionError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectClientAddInError = AccessDeniedException | InvalidParameterValuesException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a Connect Customer client add-in. Use this action to update the name and
 * endpoint URL of a Connect Customer client add-in.
 */
export declare const updateConnectClientAddIn: API.OperationMethod<UpdateConnectClientAddInRequest & RegionInput, UpdateConnectClientAddInResult, UpdateConnectClientAddInError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionAliasPermissionError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationNotSupportedException | ResourceAssociatedException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Shares or unshares a connection alias with one account by specifying whether that
 * account has permission to associate the connection alias with a directory. If the
 * association permission is granted, the connection alias is shared with that account. If the
 * association permission is revoked, the connection alias is unshared with the account. For
 * more information, see Cross-Region
 * Redirection for Amazon WorkSpaces.
 *
 * - Before performing this operation, call
 * DescribeConnectionAliases to make sure that the current state of the
 * connection alias is `CREATED`.
 *
 * - To delete a connection alias that has been shared, the shared account must
 * first disassociate the connection alias from any directories it has been
 * associated with. Then you must unshare the connection alias from the account it
 * has been shared with. You can delete a connection alias only after it is no longer
 * shared with any accounts or associated with any directories.
 */
export declare const updateConnectionAliasPermission: API.OperationMethod<UpdateConnectionAliasPermissionRequest & RegionInput, UpdateConnectionAliasPermissionResult, UpdateConnectionAliasPermissionError, Credentials | HttpClient.HttpClient>;
export type UpdateRulesOfIpGroupError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Replaces the current rules of the specified IP access control group with the specified
 * rules.
 */
export declare const updateRulesOfIpGroup: API.OperationMethod<UpdateRulesOfIpGroupRequest & RegionInput, UpdateRulesOfIpGroupResult, UpdateRulesOfIpGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceBundleError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Updates a WorkSpace bundle with a new image. For more information about updating WorkSpace bundles, see
 *
 * Update a Custom WorkSpaces Bundle.
 *
 * Existing WorkSpaces aren't automatically updated when you update the bundle that they're
 * based on. To update existing WorkSpaces that are based on a bundle that you've updated, you
 * must either rebuild the WorkSpaces or delete and recreate them.
 */
export declare const updateWorkspaceBundle: API.OperationMethod<UpdateWorkspaceBundleRequest & RegionInput, UpdateWorkspaceBundleResult, UpdateWorkspaceBundleError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceImagePermissionError = AccessDeniedException | InvalidParameterValuesException | OperationNotSupportedException | ResourceNotFoundException | ResourceUnavailableException | CommonErrors;
/**
 * Shares or unshares an image with one account in the same Amazon Web Services Region by
 * specifying whether that account has permission to copy the image. If the copy image
 * permission is granted, the image is shared with that account. If the copy image permission
 * is revoked, the image is unshared with the account.
 *
 * After an image has been shared, the recipient account can copy the image to other
 * Regions as needed.
 *
 * In the China (Ningxia) Region, you can copy images only within the same Region.
 *
 * In Amazon Web Services GovCloud (US), to copy images to and from other Regions, contact Amazon Web Services Support.
 *
 * For more information about sharing images, see Share or Unshare a Custom
 * WorkSpaces Image.
 *
 * - To delete an image that has been shared, you must unshare the image before you
 * delete it.
 *
 * - Sharing Bring Your Own License (BYOL) images across Amazon Web Services accounts
 * isn't supported at this time in Amazon Web Services GovCloud (US). To share BYOL images
 * across accounts in Amazon Web Services GovCloud (US), contact Amazon Web Services Support.
 */
export declare const updateWorkspaceImagePermission: API.OperationMethod<UpdateWorkspaceImagePermissionRequest & RegionInput, UpdateWorkspaceImagePermissionResult, UpdateWorkspaceImagePermissionError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspacesPoolError = AccessDeniedException | InvalidParameterValuesException | InvalidResourceStateException | OperationInProgressException | OperationNotSupportedException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * End of support notice: On December 31, 2027, Amazon Web Services will end support for Amazon WorkSpaces Pools. After December 31, 2027,
 * you will no longer be able to access the Amazon WorkSpaces Pools console or Amazon WorkSpaces Pools resources. For more information, see
 * Amazon WorkSpaces Pools end of support.
 *
 * Updates the specified pool.
 */
export declare const updateWorkspacesPool: API.OperationMethod<UpdateWorkspacesPoolRequest & RegionInput, UpdateWorkspacesPoolResult, UpdateWorkspacesPoolError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=workspaces.d.ts.map