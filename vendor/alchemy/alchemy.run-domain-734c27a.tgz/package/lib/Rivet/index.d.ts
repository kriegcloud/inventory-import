import { type PoolHost } from "@alchemy.run/rivet/Host";
import type { Providers } from "@alchemy.run/rivet/Providers";
import * as SecureRandom from "effect/crypto/SecureRandom";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type { WorkflowEngine } from "effect/workflow";
import type { Platform } from "../Platform.ts";
/** What a Domain host class's instance returns. */
export interface DomainShape {
    readonly alarm: () => Effect.Effect<void>;
    readonly [method: string]: unknown;
}
declare const DomainClassNotHosted_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Rivet.DomainClassNotHosted";
} & Readonly<A>;
/** A Domain host class was asked for an object of a class it doesn't host. */
export declare class DomainClassNotHosted extends DomainClassNotHosted_base<{
    readonly message: string;
}> {
}
/** Options for {@link layerDurableObjects}. */
export interface DurableObjectsOptions<PoolReq> {
    /** The Rivet Durable Object class that hosts the model: its actors' name. */
    readonly name: string;
    /**
     * The module that exports the model's Layer (the one this platform is
     * provided to), usually `import.meta.url`. The pool's nodes load it to run
     * the model.
     */
    readonly main: string;
    /**
     * The export of {@link main} that holds the model's Layer.
     * @default "default"
     */
    readonly handler?: string;
    /** The pool whose nodes run the model, e.g. `RivetDocker.SwarmPool("Default")`. */
    readonly pool: Layer.Layer<PoolHost, never, PoolReq>;
}
/**
 * Host a domain model on Rivet Durable Objects. Provide it to the model's
 * Layer, as `Domain.InMemory` or `DomainCloudflare.layerDurableObjects()` would be, in
 * every runtime that serves the model: a Worker, a Lambda, a container.
 *
 * The model's aggregate instances, view keys, policies and saga runs are
 * instances of one Durable Object class, `name`, each named after what it
 * holds (`Bank.AccountAggregate/a-1`). Built in a caller, the Layer deploys
 * that class to `pool` and reaches it through the control plane's gateway.
 * The pool's nodes load the model's Layer from `main`, and there the same
 * Layer hosts the class.
 *
 * Commands to one aggregate instance run one at a time. Events, state and
 * the outbox commit together in the instance's SQLite, and deliveries to
 * views, projections and policies are at least once and in order per source.
 * Scheduled commands and retries are the instance's alarm. Over
 * `Domain.protocolWebSocket`, a live read's WebSocket travels through the
 * control plane's gateway to the instance that owns the key, which pushes
 * every commit down it. Over `Domain.protocolHttp`, live reads are streamed
 * responses that poll the owning instance.
 *
 * ### Hosting a model on Rivet
 * **Example:** The model's Layer, served from a Worker
 * ```typescript
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 * import * as RivetDocker from "@alchemy.run/rivet/Docker";
 * import * as DomainRivet from "@alchemy.run/domain/Rivet";
 * import * as Effect from "effect/Effect";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankHandlers } from "./Bank.model.ts";
 * import { CustomerApi } from "./CustomerApi.api.ts";
 *
 * const ControlPlane = RivetDocker.SwarmControlPlane("Rivet");
 * const Default = RivetDocker.SwarmPool("Default").pipe(Layer.provide(ControlPlane));
 *
 * export const BankLive = Bank.layer(BankHandlers).pipe(
 *   Layer.provide(
 *     DomainRivet.layerDurableObjects({
 *       name: "Bank",
 *       main: import.meta.url,
 *       handler: "BankLive",
 *       pool: Default,
 *     }),
 *   ),
 * );
 *
 * export default class BankWorker extends Cloudflare.Worker<BankWorker>()(
 *   "BankWorker",
 *   { main: import.meta.url },
 *   Effect.gen(function* () {
 *     const api = yield* CustomerApi;
 *     return { fetch: api.fetch };
 *   }).pipe(Effect.provide(BankLive)),
 * ) {}
 * ```
 *
 * @layer
 * @provides Domain.Platform
 * @provides WorkflowEngine
 */
export declare const layerDurableObjects: <PoolReq>(options: DurableObjectsOptions<PoolReq>) => Layer.Layer<Platform | WorkflowEngine.WorkflowEngine | SecureRandom.SecureRandom, never, PoolReq | Providers>;
export {};
//# sourceMappingURL=index.d.ts.map