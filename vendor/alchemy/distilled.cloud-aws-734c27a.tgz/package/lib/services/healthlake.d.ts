import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const FailedDependencyException_base: S.TaggedErrorClass<"FailedDependencyException", {
    readonly message: any;
}>;
export declare class FailedDependencyException extends /*@__PURE__*/ FailedDependencyException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SourceFormat = "CCDA" | "CSV" | (string & {});
export interface StarterProfileSource {
    StarterProfileName: string;
}
export interface ExistingVersionedProfileSource {
    ProfileId: string;
    Version: number;
}
export type StringMap = {
    [key: string]: string | undefined;
};
export interface ProfileMappingSource {
    ProfileMapping: {
        [key: string]: string | undefined;
    };
}
export type SampleDataS3Uri = string;
export interface SampleDataSource {
    S3Uri: string;
}
export type CreateDataTransformationProfileSource = {
    StarterProfile: StarterProfileSource;
    ExistingVersionedProfileId?: undefined;
    ProfileMapping?: undefined;
    SampleData?: undefined;
} | {
    StarterProfile?: undefined;
    ExistingVersionedProfileId: ExistingVersionedProfileSource;
    ProfileMapping?: undefined;
    SampleData?: undefined;
} | {
    StarterProfile?: undefined;
    ExistingVersionedProfileId?: undefined;
    ProfileMapping: ProfileMappingSource;
    SampleData?: undefined;
} | {
    StarterProfile?: undefined;
    ExistingVersionedProfileId?: undefined;
    ProfileMapping?: undefined;
    SampleData: SampleDataSource;
};
export type KmsKeyId = string;
export type ProfileDescription = string;
export type ProfileNameString = string;
export type DataTransformationTagKey = string;
export type DataTransformationTagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type ClientToken = string;
export interface CreateDataTransformationProfileRequest {
    SourceFormat: SourceFormat;
    Source: CreateDataTransformationProfileSource;
    KmsKeyId?: string | undefined;
    ProfileDescription?: string | undefined;
    ProfileName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export type ProfileIdString = string;
export type ProfileVersion = number;
export type TargetFormat = "FHIR_R4" | (string & {});
export interface CreateDataTransformationProfileResponse {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName: string;
    LastUpdatedAt: Date;
}
export type DatastoreName = string;
export type FHIRVersion = "R4" | (string & {});
export type CmkType = "CUSTOMER_MANAGED_KMS_KEY" | "AWS_OWNED_KMS_KEY" | (string & {});
export type EncryptionKeyID = string;
export interface KmsEncryptionConfig {
    CmkType: CmkType;
    KmsKeyId?: string | undefined;
}
export interface SseConfiguration {
    KmsEncryptionConfig: KmsEncryptionConfig;
}
export type PreloadDataType = "SYNTHEA" | (string & {});
export interface PreloadDataConfig {
    PreloadDataType: PreloadDataType;
}
export type ClientTokenString = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type AuthorizationStrategy = "SMART_ON_FHIR_V1" | "SMART_ON_FHIR" | "AWS_AUTH" | (string & {});
export type HealthLakeBoolean = boolean;
export type ConfigurationMetadata = string;
export type LambdaArn = string;
export interface IdentityProviderConfiguration {
    AuthorizationStrategy: AuthorizationStrategy;
    FineGrainedAuthorizationEnabled?: boolean | undefined;
    Metadata?: string | undefined;
    IdpLambdaArn?: string | undefined;
}
export type AnalyticsStatus = "ENABLED" | "ENABLING" | "DISABLED" | "DISABLING" | "PAUSING" | "PAUSED" | (string & {});
export interface AnalyticsConfiguration {
    Status?: AnalyticsStatus | undefined;
}
export type NlpStatus = "ENABLED" | "ENABLING" | "DISABLED" | "DISABLING" | (string & {});
export interface NlpConfiguration {
    Status?: NlpStatus | undefined;
}
export type HealthLakeString = string;
export type DefaultProfiles = string[];
export interface ProfileConfiguration {
    DefaultProfiles?: string[] | undefined;
}
export type BackupStatus = "ENABLED" | "DISABLED" | (string & {});
export type BackupType = "CONTINUOUS" | (string & {});
export type BackupRetentionPeriodInDays = number;
export interface BackupConfiguration {
    Status?: BackupStatus | undefined;
    BackupType?: BackupType | undefined;
    RetentionPeriodInDays?: number | undefined;
    BackupTagsEnabled?: boolean | undefined;
}
export interface CreateFHIRDatastoreRequest {
    DatastoreName?: string | undefined;
    DatastoreTypeVersion: FHIRVersion;
    SseConfiguration?: SseConfiguration | undefined;
    PreloadDataConfig?: PreloadDataConfig | undefined;
    ClientToken?: string | undefined;
    Tags?: Tag[] | undefined;
    IdentityProviderConfiguration?: IdentityProviderConfiguration | undefined;
    AnalyticsConfiguration?: AnalyticsConfiguration | undefined;
    NlpConfiguration?: NlpConfiguration | undefined;
    ProfileConfiguration?: ProfileConfiguration | undefined;
    BackupConfiguration?: BackupConfiguration | undefined;
}
export type DatastoreId = string;
export type DatastoreArn = string;
export type DatastoreStatus = "CREATING" | "ACTIVE" | "DELETING" | "DELETED" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | (string & {});
export type BoundedLengthString = string;
export interface CreateFHIRDatastoreResponse {
    DatastoreId: string;
    DatastoreArn: string;
    DatastoreStatus: DatastoreStatus;
    DatastoreEndpoint: string;
}
export interface DeleteDataTransformationProfileRequest {
    ProfileId: string;
}
export interface DeleteDataTransformationProfileResponse {
    ProfileId: string;
    ProfileName?: string | undefined;
    DeletionTime: Date;
}
export interface DeleteFHIRDatastoreRequest {
    DatastoreId: string;
}
export interface DeleteFHIRDatastoreResponse {
    DatastoreId: string;
    DatastoreArn: string;
    DatastoreStatus: DatastoreStatus;
    DatastoreEndpoint: string;
}
export type DataTransformationJobId = string;
export interface DescribeDataTransformationJobRequest {
    JobId: string;
}
export type TransformationJobStatus = "SUBMITTED" | "QUEUED" | "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export type DataTransformationS3Uri = string;
export interface TransformationInputDataConfig {
    S3Uri: string;
    SourceFormat?: SourceFormat | undefined;
}
export interface DataTransformationS3Configuration {
    S3Uri: string;
    KmsKeyId: string;
}
export interface TransformationOutputDataConfig {
    S3Configuration: DataTransformationS3Configuration;
}
export type DataTransformationIamRoleArn = string;
export type DataTransformationJobName = string;
export type BoundedString = string;
export interface TransformationJobProgressReport {
    TotalFilesScanned: number;
    TotalFilesConverted: number;
    TotalFilesFailed: number;
    TotalResourcesGenerated: number;
}
export interface TransformationJobProperties {
    JobId: string;
    JobStatus: TransformationJobStatus;
    InputDataConfig: TransformationInputDataConfig;
    OutputDataConfig: TransformationOutputDataConfig;
    DataAccessRoleArn: string;
    SubmitTime: Date;
    JobName?: string | undefined;
    ProfileId?: string | undefined;
    ProfileName?: string | undefined;
    ProfileVersion?: number | undefined;
    EndTime?: Date | undefined;
    DriftDetectionEnabled?: boolean | undefined;
    ProvenanceEnabled?: boolean | undefined;
    Message?: string | undefined;
    JobProgressReport?: TransformationJobProgressReport | undefined;
}
export interface DescribeDataTransformationJobResponse {
    TransformationJobProperties: TransformationJobProperties;
}
export interface DescribeFHIRDatastoreRequest {
    DatastoreId: string;
}
export type HealthLakeTimestamp = Date;
export type ErrorMessage = string;
export type ErrorCategory = "RETRYABLE_ERROR" | "NON_RETRYABLE_ERROR" | (string & {});
export interface ErrorCause {
    ErrorMessage?: string | undefined;
    ErrorCategory?: ErrorCategory | undefined;
}
export interface DatastoreBackupStatus {
    Configuration?: BackupConfiguration | undefined;
    BackupEnabledAt?: Date | undefined;
    EarliestRestorePoint?: Date | undefined;
    LatestRestorePoint?: Date | undefined;
    ScheduledPermanentDeletionTime?: Date | undefined;
}
export interface DatastoreProperties {
    DatastoreId: string;
    DatastoreArn: string;
    DatastoreName?: string | undefined;
    DatastoreStatus: DatastoreStatus;
    CreatedAt?: Date | undefined;
    DatastoreTypeVersion: FHIRVersion;
    DatastoreEndpoint: string;
    SseConfiguration?: SseConfiguration | undefined;
    PreloadDataConfig?: PreloadDataConfig | undefined;
    IdentityProviderConfiguration?: IdentityProviderConfiguration | undefined;
    ErrorCause?: ErrorCause | undefined;
    NlpConfiguration?: NlpConfiguration | undefined;
    AnalyticsConfiguration?: AnalyticsConfiguration | undefined;
    ProfileConfiguration?: ProfileConfiguration | undefined;
    BackupStatusInfo?: DatastoreBackupStatus | undefined;
}
export interface DescribeFHIRDatastoreResponse {
    DatastoreProperties: DatastoreProperties;
}
export type JobId = string;
export interface DescribeFHIRExportJobRequest {
    DatastoreId: string;
    JobId: string;
}
export type JobName = string;
export type JobStatus = "SUBMITTED" | "QUEUED" | "IN_PROGRESS" | "COMPLETED_WITH_ERRORS" | "COMPLETED" | "FAILED" | "CANCEL_SUBMITTED" | "CANCEL_IN_PROGRESS" | "CANCEL_COMPLETED" | "CANCEL_FAILED" | (string & {});
export type S3Uri = string;
export interface S3Configuration {
    S3Uri: string;
    KmsKeyId: string;
}
export type OutputDataConfig = {
    S3Configuration: S3Configuration;
};
export type IamRoleArn = string;
export type Message = string;
export interface ExportJobProperties {
    JobId: string;
    JobName?: string | undefined;
    JobStatus: JobStatus;
    SubmitTime: Date;
    EndTime?: Date | undefined;
    DatastoreId: string;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn?: string | undefined;
    Message?: string | undefined;
}
export interface DescribeFHIRExportJobResponse {
    ExportJobProperties: ExportJobProperties;
}
export interface DescribeFHIRImportJobRequest {
    DatastoreId: string;
    JobId: string;
}
export type InputDataConfig = {
    S3Uri: string;
};
export interface JobProgressReport {
    TotalNumberOfScannedFiles?: number | undefined;
    TotalSizeOfScannedFilesInMB?: number | undefined;
    TotalNumberOfImportedFiles?: number | undefined;
    TotalNumberOfResourcesScanned?: number | undefined;
    TotalNumberOfResourcesImported?: number | undefined;
    TotalNumberOfResourcesWithCustomerError?: number | undefined;
    TotalNumberOfFilesReadWithCustomerError?: number | undefined;
    TotalNumberOfScannedNonFhirFiles?: number | undefined;
    TotalSizeOfScannedNonFhirFilesInMB?: number | undefined;
    TotalNumberOfImportedNonFhirFiles?: number | undefined;
    TotalNumberOfNonFhirResourcesScanned?: number | undefined;
    TotalNumberOfNonFhirResourcesImported?: number | undefined;
    TotalNumberOfNonFhirResourcesWithCustomerError?: number | undefined;
    TotalNumberOfNonFhirFilesReadWithCustomerError?: number | undefined;
    Throughput?: number | undefined;
    TotalFilesConverted?: number | undefined;
    TotalResourcesGenerated?: number | undefined;
}
export type ValidationLevel = "strict" | "structure-only" | "minimal" | (string & {});
export interface ImportJobProperties {
    JobId: string;
    JobName?: string | undefined;
    JobStatus: JobStatus;
    SubmitTime: Date;
    EndTime?: Date | undefined;
    DatastoreId: string;
    InputDataConfig: InputDataConfig;
    JobOutputDataConfig?: OutputDataConfig | undefined;
    JobProgressReport?: JobProgressReport | undefined;
    DataAccessRoleArn?: string | undefined;
    Message?: string | undefined;
    ValidationLevel?: ValidationLevel | undefined;
}
export interface DescribeFHIRImportJobResponse {
    ImportJobProperties: ImportJobProperties;
}
export interface GetDataTransformationProfileRequest {
    ProfileId: string;
    ProfileVersion?: number | undefined;
}
export type ProfileMappingKey = string;
export type ProfileMappingValue = string;
export type ProfileMapping = {
    [key: string]: string | undefined;
};
export type ChangeDescription = string;
export interface GetDataTransformationProfileResponse {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileMapping: {
        [key: string]: string | undefined;
    };
    ProfileName?: string | undefined;
    ProfileDescription?: string | undefined;
    ChangeDescription?: string | undefined;
    LastUpdatedAt: Date;
}
export type MaxResults = number;
export type DataTransformationNextToken = string;
export interface ListDataTransformationJobsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    JobStatus?: TransformationJobStatus | undefined;
    JobName?: string | undefined;
    SubmittedAfter?: Date | undefined;
    SubmittedBefore?: Date | undefined;
}
export interface TransformationJobSummary {
    JobId: string;
    JobStatus: TransformationJobStatus;
    SubmitTime: Date;
    JobName?: string | undefined;
    EndTime?: Date | undefined;
    SourceFormat?: SourceFormat | undefined;
}
export type TransformationJobSummaryList = TransformationJobSummary[];
export interface ListDataTransformationJobsResponse {
    Items: TransformationJobSummary[];
    NextToken?: string | undefined;
}
export interface ListDataTransformationProfilesRequest {
    SourceFormat: SourceFormat;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DataTransformationProfileSummary {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName?: string | undefined;
    ProfileDescription?: string | undefined;
    LastUpdatedAt?: Date | undefined;
}
export type DataTransformationProfileSummaryList = DataTransformationProfileSummary[];
export interface ListDataTransformationProfilesResponse {
    Items: DataTransformationProfileSummary[];
    NextToken?: string | undefined;
}
export interface ListDataTransformationProfileVersionsRequest {
    ProfileId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DataTransformationProfileVersionSummary {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName?: string | undefined;
    ChangeDescription?: string | undefined;
    LastUpdatedAt?: Date | undefined;
}
export type DataTransformationProfileVersionSummaryList = DataTransformationProfileVersionSummary[];
export interface ListDataTransformationProfileVersionsResponse {
    Items: DataTransformationProfileVersionSummary[];
    NextToken?: string | undefined;
}
export interface DatastoreFilter {
    DatastoreName?: string | undefined;
    DatastoreStatus?: DatastoreStatus | undefined;
    CreatedBefore?: Date | undefined;
    CreatedAfter?: Date | undefined;
}
export type NextToken = string;
export type MaxResultsInteger = number;
export interface ListFHIRDatastoresRequest {
    Filter?: DatastoreFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type DatastorePropertiesList = DatastoreProperties[];
export interface ListFHIRDatastoresResponse {
    DatastorePropertiesList: DatastoreProperties[];
    NextToken?: string | undefined;
}
export interface ListFHIRExportJobsRequest {
    DatastoreId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmittedBefore?: Date | undefined;
    SubmittedAfter?: Date | undefined;
}
export type ExportJobPropertiesList = ExportJobProperties[];
export interface ListFHIRExportJobsResponse {
    ExportJobPropertiesList: ExportJobProperties[];
    NextToken?: string | undefined;
}
export interface ListFHIRImportJobsRequest {
    DatastoreId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmittedBefore?: Date | undefined;
    SubmittedAfter?: Date | undefined;
}
export type ImportJobPropertiesList = ImportJobProperties[];
export interface ListFHIRImportJobsResponse {
    ImportJobPropertiesList: ImportJobProperties[];
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface PublishDataTransformationProfileRequest {
    ProfileId: string;
    SourceFormat: SourceFormat;
    FromExistingVersion?: number | undefined;
    ChangeDescription?: string | undefined;
}
export interface PublishDataTransformationProfileResponse {
    ProfileId: string;
    Version: number;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName?: string | undefined;
    LastUpdatedAt: Date;
}
export interface ContinuousBackupRestoreConfiguration {
    RestorePointTime?: Date | undefined;
}
export type RestoreConfiguration = {
    ContinuousBackupRestoreConfiguration: ContinuousBackupRestoreConfiguration;
};
export interface RestoreFHIRDatastoreRequest {
    SourceDatastoreId: string;
    RestoreConfiguration: RestoreConfiguration;
    DatastoreName?: string | undefined;
    SseConfiguration?: SseConfiguration | undefined;
    ClientToken?: string | undefined;
    Tags?: Tag[] | undefined;
    IdentityProviderConfiguration?: IdentityProviderConfiguration | undefined;
    AnalyticsConfiguration?: AnalyticsConfiguration | undefined;
    NlpConfiguration?: NlpConfiguration | undefined;
    ProfileConfiguration?: ProfileConfiguration | undefined;
}
export interface RestoreFHIRDatastoreResponse {
    DatastoreId: string;
    DatastoreArn: string;
    DatastoreStatus: DatastoreStatus;
    DatastoreEndpoint: string;
}
export interface StartDataTransformationJobRequest {
    InputDataConfig: TransformationInputDataConfig;
    OutputDataConfig: TransformationOutputDataConfig;
    DataAccessRoleArn: string;
    ClientToken: string;
    JobName?: string | undefined;
    ProfileId: string;
    DriftDetectionEnabled?: boolean | undefined;
    ProvenanceEnabled?: boolean | undefined;
}
export interface StartDataTransformationJobResponse {
    JobId: string;
    JobStatus: TransformationJobStatus;
}
export interface StartFHIRExportJobRequest {
    JobName?: string | undefined;
    OutputDataConfig: OutputDataConfig;
    DatastoreId: string;
    DataAccessRoleArn: string;
    ClientToken?: string | undefined;
}
export interface StartFHIRExportJobResponse {
    JobId: string;
    JobStatus: JobStatus;
    DatastoreId?: string | undefined;
}
export type DefaultEnabledBoolean = boolean;
export interface StartFHIRImportJobRequest {
    JobName?: string | undefined;
    InputDataConfig: InputDataConfig;
    JobOutputDataConfig: OutputDataConfig;
    DatastoreId: string;
    DataAccessRoleArn: string;
    ClientToken?: string | undefined;
    ValidationLevel?: ValidationLevel | undefined;
    ProfileId?: string | undefined;
    InputFormat?: string | undefined;
    DriftDetectionEnabled?: boolean | undefined;
    ProvenanceEnabled?: boolean | undefined;
}
export interface StartFHIRImportJobResponse {
    JobId: string;
    JobStatus: JobStatus;
    DatastoreId?: string | undefined;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDataTransformationProfileRequest {
    ProfileId: string;
    ProfileMapping: {
        [key: string]: string | undefined;
    };
    ChangeDescription?: string | undefined;
}
export interface UpdateDataTransformationProfileResponse {
    ProfileId: string;
    SourceFormat: SourceFormat;
    TargetFormat: TargetFormat;
    ProfileName?: string | undefined;
    LastUpdatedAt: Date;
}
export interface UpdateFHIRDatastoreRequest {
    DatastoreId: string;
    DatastoreName?: string | undefined;
    AnalyticsConfiguration?: AnalyticsConfiguration | undefined;
    NlpConfiguration?: NlpConfiguration | undefined;
    ProfileConfiguration?: ProfileConfiguration | undefined;
    IdentityProviderConfiguration?: IdentityProviderConfiguration | undefined;
    BackupConfiguration?: BackupConfiguration | undefined;
}
export interface UpdateFHIRDatastoreResponse {
    DatastoreProperties: DatastoreProperties;
}
export type AgentMessageString = string | redacted.Redacted<string>;
export type AgentInputMessageType = "normal" | "confirmation_response" | (string & {});
export interface AgentInputMessage {
    Body: string | redacted.Redacted<string>;
    Type: AgentInputMessageType;
}
export type ConversationIdString = string;
export interface UpdateProfileWithAgentRequest {
    ProfileId: string;
    InputMessage: AgentInputMessage;
    ConversationId?: string | undefined;
}
export interface TextMessageEvent {
    Message: string | redacted.Redacted<string>;
}
export interface ProgressEvent {
    Message: string | redacted.Redacted<string>;
}
export interface HeartbeatEvent {
}
export type AgentErrorType = "InternalServerException" | "ResourceNotFoundException" | "ValidationException" | "AccessDeniedException" | "ThrottlingException" | (string & {});
export interface ErrorEvent {
    Error: AgentErrorType;
    Message: string | redacted.Redacted<string>;
}
export type DataTransformationChatOptionString = string | redacted.Redacted<string>;
export type DataTransformationChatOptionsList = (string | redacted.Redacted<string>)[];
export interface EndOfOutputEvent {
    FinalResponseMessage: string | redacted.Redacted<string>;
    Options?: (string | redacted.Redacted<string>)[] | undefined;
    ConversationId?: string | undefined;
}
export type AgentOutputMessageStream = {
    TextMessageEvent: TextMessageEvent;
    ProgressEvent?: undefined;
    HeartbeatEvent?: undefined;
    ErrorEvent?: undefined;
    EndOfOutputEvent?: undefined;
} | {
    TextMessageEvent?: undefined;
    ProgressEvent: ProgressEvent;
    HeartbeatEvent?: undefined;
    ErrorEvent?: undefined;
    EndOfOutputEvent?: undefined;
} | {
    TextMessageEvent?: undefined;
    ProgressEvent?: undefined;
    HeartbeatEvent: HeartbeatEvent;
    ErrorEvent?: undefined;
    EndOfOutputEvent?: undefined;
} | {
    TextMessageEvent?: undefined;
    ProgressEvent?: undefined;
    HeartbeatEvent?: undefined;
    ErrorEvent: ErrorEvent;
    EndOfOutputEvent?: undefined;
} | {
    TextMessageEvent?: undefined;
    ProgressEvent?: undefined;
    HeartbeatEvent?: undefined;
    ErrorEvent?: undefined;
    EndOfOutputEvent: EndOfOutputEvent;
};
export interface UpdateProfileWithAgentResponse {
    AgentResponse: stream.Stream<AgentOutputMessageStream, Error, never>;
}
export type CreateDataTransformationProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data transformation profile in DRAFT state. Specify a built-in starter profile, an existing profile version, raw profile content, or a sample data file as the source.
 */
export declare const createDataTransformationProfile: API.OperationMethod<CreateDataTransformationProfileRequest & RegionInput, CreateDataTransformationProfileResponse, CreateDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFHIRDatastoreError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a FHIR-enabled data store.
 */
export declare const createFHIRDatastore: API.OperationMethod<CreateFHIRDatastoreRequest & RegionInput, CreateFHIRDatastoreResponse, CreateFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type DeleteDataTransformationProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a data transformation profile and all its versions, including the DRAFT and all published versions.
 */
export declare const deleteDataTransformationProfile: API.OperationMethod<DeleteDataTransformationProfileRequest & RegionInput, DeleteDataTransformationProfileResponse, DeleteDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFHIRDatastoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a FHIR-enabled data store.
 */
export declare const deleteFHIRDatastore: API.OperationMethod<DeleteFHIRDatastoreRequest & RegionInput, DeleteFHIRDatastoreResponse, DeleteFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type DescribeDataTransformationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes a data transformation job, including its current status, configuration, and progress information.
 */
export declare const describeDataTransformationJob: API.OperationMethod<DescribeDataTransformationJobRequest & RegionInput, DescribeDataTransformationJobResponse, DescribeDataTransformationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeFHIRDatastoreError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get properties for a FHIR-enabled data store.
 */
export declare const describeFHIRDatastore: API.OperationMethod<DescribeFHIRDatastoreRequest & RegionInput, DescribeFHIRDatastoreResponse, DescribeFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type DescribeFHIRExportJobError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get FHIR export job properties.
 */
export declare const describeFHIRExportJob: API.OperationMethod<DescribeFHIRExportJobRequest & RegionInput, DescribeFHIRExportJobResponse, DescribeFHIRExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeFHIRImportJobError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the import job properties to learn more about the job or job progress.
 */
export declare const describeFHIRImportJob: API.OperationMethod<DescribeFHIRImportJobRequest & RegionInput, DescribeFHIRImportJobResponse, DescribeFHIRImportJobError, Credentials | HttpClient.HttpClient>;
export type GetDataTransformationProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a data transformation profile's metadata and profile content at a specific version. Specify version 0 to retrieve the DRAFT, a version number between 1 and 99 to retrieve a specific published version, or omit the version to retrieve the latest published version.
 */
export declare const getDataTransformationProfile: API.OperationMethod<GetDataTransformationProfileRequest & RegionInput, GetDataTransformationProfileResponse, GetDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type ListDataTransformationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists data transformation jobs for your Amazon Web Services account. Results can be filtered by status, job name, and submit time window. Results are paginated. Use the `NextToken` parameter to retrieve additional results.
 */
export declare const listDataTransformationJobs: API.PaginatedOperationMethod<ListDataTransformationJobsRequest & RegionInput, ListDataTransformationJobsResponse, ListDataTransformationJobsError, Credentials | HttpClient.HttpClient, TransformationJobSummary>;
export type ListDataTransformationProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all data transformation profiles in your account, returning the latest version summary for each. Use `GetDataTransformationProfile` to retrieve profile content. Results are paginated. Use the `NextToken` parameter to retrieve additional results.
 */
export declare const listDataTransformationProfiles: API.PaginatedOperationMethod<ListDataTransformationProfilesRequest & RegionInput, ListDataTransformationProfilesResponse, ListDataTransformationProfilesError, Credentials | HttpClient.HttpClient, DataTransformationProfileSummary>;
export type ListDataTransformationProfileVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all versions of a specific data transformation profile (DRAFT and published), in reverse chronological order (newest first). Use `GetDataTransformationProfile` to retrieve profile content. Results are paginated. Use the `NextToken` parameter to retrieve additional results.
 */
export declare const listDataTransformationProfileVersions: API.PaginatedOperationMethod<ListDataTransformationProfileVersionsRequest & RegionInput, ListDataTransformationProfileVersionsResponse, ListDataTransformationProfileVersionsError, Credentials | HttpClient.HttpClient, DataTransformationProfileVersionSummary>;
export type ListFHIRDatastoresError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all FHIR-enabled data stores in a user's account, regardless of data store status.
 */
export declare const listFHIRDatastores: API.PaginatedOperationMethod<ListFHIRDatastoresRequest & RegionInput, ListFHIRDatastoresResponse, ListFHIRDatastoresError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFHIRExportJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all FHIR export jobs associated with an account and their statuses.
 */
export declare const listFHIRExportJobs: API.PaginatedOperationMethod<ListFHIRExportJobsRequest & RegionInput, ListFHIRExportJobsResponse, ListFHIRExportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFHIRImportJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all FHIR import jobs associated with an account and their statuses.
 */
export declare const listFHIRImportJobs: API.PaginatedOperationMethod<ListFHIRImportJobsRequest & RegionInput, ListFHIRImportJobsResponse, ListFHIRImportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of all existing tags associated with a data store.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PublishDataTransformationProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Promotes the current DRAFT version of a data transformation profile to a new immutable published version. Also supports rollback by publishing from a previously published version.
 */
export declare const publishDataTransformationProfile: API.OperationMethod<PublishDataTransformationProfileRequest & RegionInput, PublishDataTransformationProfileResponse, PublishDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type RestoreFHIRDatastoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restore a backup-enabled data store to a point in time. Creates a new data store from the backup.
 */
export declare const restoreFHIRDatastore: API.OperationMethod<RestoreFHIRDatastoreRequest & RegionInput, RestoreFHIRDatastoreResponse, RestoreFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type StartDataTransformationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an asynchronous data transformation job that converts source files from Amazon Simple Storage Service (Amazon S3) and writes the output to Amazon S3 or HealthLake.
 */
export declare const startDataTransformationJob: API.OperationMethod<StartDataTransformationJobRequest & RegionInput, StartDataTransformationJobResponse, StartDataTransformationJobError, Credentials | HttpClient.HttpClient>;
export type StartFHIRExportJobError = AccessDeniedException | FailedDependencyException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start a FHIR export job.
 */
export declare const startFHIRExportJob: API.OperationMethod<StartFHIRExportJobRequest & RegionInput, StartFHIRExportJobResponse, StartFHIRExportJobError, Credentials | HttpClient.HttpClient>;
export type StartFHIRImportJobError = AccessDeniedException | FailedDependencyException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start importing bulk FHIR data into an ACTIVE data store. The import job imports FHIR data found in the `InputDataConfig` object and stores processing results in the `JobOutputDataConfig` object.
 */
export declare const startFHIRImportJob: API.OperationMethod<StartFHIRImportJobRequest & RegionInput, StartFHIRImportJobResponse, StartFHIRImportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Add a user-specifed key and value tag to a data store.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Remove a user-specifed key and value tag from a data store.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDataTransformationProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the DRAFT version (version 0) of a data transformation profile with new profile content. The update replaces all existing DRAFT content.
 */
export declare const updateDataTransformationProfile: API.OperationMethod<UpdateDataTransformationProfileRequest & RegionInput, UpdateDataTransformationProfileResponse, UpdateDataTransformationProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateFHIRDatastoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the properties of a FHIR-enabled data store.
 */
export declare const updateFHIRDatastore: API.OperationMethod<UpdateFHIRDatastoreRequest & RegionInput, UpdateFHIRDatastoreResponse, UpdateFHIRDatastoreError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileWithAgentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a data transformation profile using chat-based interaction with an agent. Supports multi-turn conversations for iteratively customizing profiles.
 */
export declare const updateProfileWithAgent: API.OperationMethod<UpdateProfileWithAgentRequest & RegionInput, UpdateProfileWithAgentResponse, UpdateProfileWithAgentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=healthlake.d.ts.map