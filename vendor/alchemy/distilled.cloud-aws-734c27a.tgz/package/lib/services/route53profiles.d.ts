import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
    readonly FieldName: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceExistsException_base: S.TaggedErrorClass<"ResourceExistsException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class ResourceExistsException extends /*@__PURE__*/ ResourceExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceId = string;
export type Name = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type Priority = number;
export interface AssociateProfileRequest {
    ProfileId: string;
    ResourceId: string;
    Name: string;
    Tags?: Tag[] | undefined;
    Priority?: number | undefined;
}
export type AccountId = string;
export type ProfileStatus = "COMPLETE" | "DELETING" | "UPDATING" | "CREATING" | "DELETED" | "FAILED" | (string & {});
export type Rfc3339Timestamp = Date;
export interface ProfileAssociation {
    Id?: string | undefined;
    Name?: string | undefined;
    OwnerId?: string | undefined;
    ProfileId?: string | undefined;
    ResourceId?: string | undefined;
    Status?: ProfileStatus | undefined;
    StatusMessage?: string | undefined;
    CreationTime?: Date | undefined;
    ModificationTime?: Date | undefined;
    Priority?: number | undefined;
}
export interface AssociateProfileResponse {
    ProfileAssociation?: ProfileAssociation | undefined;
}
export type Arn = string;
export type ResourceProperties = string;
export interface AssociateResourceToProfileRequest {
    ProfileId: string;
    ResourceArn: string;
    Name: string;
    ResourceProperties?: string | undefined;
}
export interface ProfileResourceAssociation {
    Id?: string | undefined;
    Name?: string | undefined;
    OwnerId?: string | undefined;
    ProfileId?: string | undefined;
    ResourceArn?: string | undefined;
    ResourceType?: string | undefined;
    ResourceProperties?: string | undefined;
    Status?: ProfileStatus | undefined;
    StatusMessage?: string | undefined;
    CreationTime?: Date | undefined;
    ModificationTime?: Date | undefined;
}
export interface AssociateResourceToProfileResponse {
    ProfileResourceAssociation?: ProfileResourceAssociation | undefined;
}
export type CreatorRequestId = string;
export interface CreateProfileRequest {
    Name: string;
    ClientToken: string;
    Tags?: Tag[] | undefined;
}
export type ShareStatus = "NOT_SHARED" | "SHARED_WITH_ME" | "SHARED_BY_ME" | (string & {});
export interface Profile {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    OwnerId?: string | undefined;
    Status?: ProfileStatus | undefined;
    StatusMessage?: string | undefined;
    ShareStatus?: ShareStatus | undefined;
    CreationTime?: Date | undefined;
    ModificationTime?: Date | undefined;
    ClientToken?: string | undefined;
}
export interface CreateProfileResponse {
    Profile?: Profile | undefined;
}
export interface DeleteProfileRequest {
    ProfileId: string;
}
export interface DeleteProfileResponse {
    Profile?: Profile | undefined;
}
export interface DisassociateProfileRequest {
    ProfileId: string;
    ResourceId: string;
}
export interface DisassociateProfileResponse {
    ProfileAssociation?: ProfileAssociation | undefined;
}
export interface DisassociateResourceFromProfileRequest {
    ProfileId: string;
    ResourceArn: string;
}
export interface DisassociateResourceFromProfileResponse {
    ProfileResourceAssociation?: ProfileResourceAssociation | undefined;
}
export interface GetProfileRequest {
    ProfileId: string;
}
export interface GetProfileResponse {
    Profile?: Profile | undefined;
}
export interface GetProfileAssociationRequest {
    ProfileAssociationId: string;
}
export interface GetProfileAssociationResponse {
    ProfileAssociation?: ProfileAssociation | undefined;
}
export interface GetProfileResourceAssociationRequest {
    ProfileResourceAssociationId: string;
}
export interface GetProfileResourceAssociationResponse {
    ProfileResourceAssociation?: ProfileResourceAssociation | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListProfileAssociationsRequest {
    ResourceId?: string | undefined;
    ProfileId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ProfileAssociations = ProfileAssociation[];
export interface ListProfileAssociationsResponse {
    ProfileAssociations?: ProfileAssociation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProfileResourceAssociationsRequest {
    ProfileId: string;
    ResourceType?: string | undefined;
    ResourceArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ProfileResourceAssociations = ProfileResourceAssociation[];
export interface ListProfileResourceAssociationsResponse {
    ProfileResourceAssociations?: ProfileResourceAssociation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProfilesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ProfileSummary {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    ShareStatus?: ShareStatus | undefined;
}
export type ProfileSummaryList = ProfileSummary[];
export interface ListProfilesResponse {
    ProfileSummaries?: ProfileSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export type TagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateProfileAssociationRequest {
    ProfileAssociationId: string;
    Name?: string | undefined;
    Priority?: number | undefined;
}
export interface UpdateProfileAssociationResponse {
    ProfileAssociation: ProfileAssociation;
}
export interface UpdateProfileResourceAssociationRequest {
    ProfileResourceAssociationId: string;
    Name?: string | undefined;
    ResourceProperties?: string | undefined;
}
export interface UpdateProfileResourceAssociationResponse {
    ProfileResourceAssociation?: ProfileResourceAssociation | undefined;
}
export type ExceptionMessage = string;
export type AssociateProfileError = AccessDeniedException | ConflictException | InvalidParameterException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a Route 53 Profiles profile with a VPC. A VPC can have up to two Profile associations. A Profile can be associated with up to 1,000 VPCs, and you can request a higher quota for the number of VPCs. For more information, see Quotas on Route 53 Profiles.
 *
 * Route 53 VPC Resolver evaluates the Profile associations for a VPC in priority order, starting with the lowest `Priority` value. If the VPC has no other Profile associations, you can omit `Priority`, and the association gets priority 100. When the VPC already has a Profile association, you must specify a `Priority`, and each Profile association for the VPC must have a unique priority. To change the priority of an existing association, use `UpdateProfileAssociation`.
 *
 * The request fails with a `ValidationException` in these cases:
 *
 * - You omit `Priority`, and the VPC already has a Profile association.
 *
 * - Another Profile association for the VPC already uses the priority that you specify.
 *
 * - The priority is outside the range 100-9900.
 *
 * - The Profile is already associated with the VPC, and you specify a different `Name` or `Priority`. To change the priority, use UpdateProfileAssociation.
 *
 * The request fails with a `LimitExceededException` if the VPC already has the maximum number of Profile associations.
 */
export declare const associateProfile: API.OperationMethod<AssociateProfileRequest & RegionInput, AssociateProfileResponse, AssociateProfileError, Credentials | HttpClient.HttpClient>;
export type AssociateResourceToProfileError = AccessDeniedException | ConflictException | InternalServiceErrorException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a DNS resource configuration to a Route 53 Profile.
 */
export declare const associateResourceToProfile: API.OperationMethod<AssociateResourceToProfileRequest & RegionInput, AssociateResourceToProfileResponse, AssociateResourceToProfileError, Credentials | HttpClient.HttpClient>;
export type CreateProfileError = AccessDeniedException | InvalidParameterException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an empty Route 53 Profile.
 */
export declare const createProfile: API.OperationMethod<CreateProfileRequest & RegionInput, CreateProfileResponse, CreateProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Route 53 Profile. Before you can delete a profile, you must first disassociate it from all VPCs.
 */
export declare const deleteProfile: API.OperationMethod<DeleteProfileRequest & RegionInput, DeleteProfileResponse, DeleteProfileError, Credentials | HttpClient.HttpClient>;
export type DisassociateProfileError = AccessDeniedException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Dissociates a specified Route 53 Profile from the specified VPC.
 */
export declare const disassociateProfile: API.OperationMethod<DisassociateProfileRequest & RegionInput, DisassociateProfileResponse, DisassociateProfileError, Credentials | HttpClient.HttpClient>;
export type DisassociateResourceFromProfileError = AccessDeniedException | ConflictException | InternalServiceErrorException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Dissoaciated a specified resource, from the Route 53 Profile.
 */
export declare const disassociateResourceFromProfile: API.OperationMethod<DisassociateResourceFromProfileRequest & RegionInput, DisassociateResourceFromProfileResponse, DisassociateResourceFromProfileError, Credentials | HttpClient.HttpClient>;
export type GetProfileError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specified Route 53 Profile, such as whether whether the Profile is shared, and the current status of the Profile.
 */
export declare const getProfile: API.OperationMethod<GetProfileRequest & RegionInput, GetProfileResponse, GetProfileError, Credentials | HttpClient.HttpClient>;
export type GetProfileAssociationError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a Route 53 Profile association for a VPC. A VPC can have up to two Profile associations, and a Profile can be associated with up to 1,000 VPCs.
 */
export declare const getProfileAssociation: API.OperationMethod<GetProfileAssociationRequest & RegionInput, GetProfileAssociationResponse, GetProfileAssociationError, Credentials | HttpClient.HttpClient>;
export type GetProfileResourceAssociationError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specified Route 53 Profile resource association.
 */
export declare const getProfileResourceAssociation: API.OperationMethod<GetProfileResourceAssociationRequest & RegionInput, GetProfileResourceAssociationResponse, GetProfileResourceAssociationError, Credentials | HttpClient.HttpClient>;
export type ListProfileAssociationsError = AccessDeniedException | InvalidNextTokenException | InvalidParameterException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the VPCs that the specified Route 53 Profile is associated with.
 */
export declare const listProfileAssociations: API.PaginatedOperationMethod<ListProfileAssociationsRequest & RegionInput, ListProfileAssociationsResponse, ListProfileAssociationsError, Credentials | HttpClient.HttpClient, ProfileAssociation>;
export type ListProfileResourceAssociationsError = AccessDeniedException | InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the resource associations for the specified Route 53 Profile.
 */
export declare const listProfileResourceAssociations: API.PaginatedOperationMethod<ListProfileResourceAssociationsRequest & RegionInput, ListProfileResourceAssociationsResponse, ListProfileResourceAssociationsError, Credentials | HttpClient.HttpClient, ProfileResourceAssociation>;
export type ListProfilesError = AccessDeniedException | InvalidNextTokenException | InvalidParameterException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the Route 53 Profiles associated with your Amazon Web Services account.
 */
export declare const listProfiles: API.PaginatedOperationMethod<ListProfilesRequest & RegionInput, ListProfilesResponse, ListProfilesError, Credentials | HttpClient.HttpClient, ProfileSummary>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags that you associated with the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileAssociationError = AccessDeniedException | ConflictException | InternalServiceErrorException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the name or priority of the specified Route 53 Profile association with a VPC. Route 53 VPC Resolver evaluates the Profile associations for a VPC in priority order, starting with the lowest value. Only the account that created the association can update it.
 *
 * When you change the priority, the association status is `UPDATING` until the change propagates, and then `COMPLETE`. While the status is `UPDATING`, Route 53 VPC Resolver might still use the previous priority for some queries. When the status is `COMPLETE`, the new priority applies to all queries from the VPC.
 *
 * The request fails with a `ValidationException` if another Profile association for the VPC already uses the priority that you specify, or if the priority is outside the range 100-9900.
 *
 * You can update an association whose status is `CREATING`, `UPDATING`, or `COMPLETE`. The request fails with a `ConflictException` if the association status is `DELETING`, `DELETED`, or `FAILED`, or if the account that owns the association is inactive.
 */
export declare const updateProfileAssociation: API.OperationMethod<UpdateProfileAssociationRequest & RegionInput, UpdateProfileAssociationResponse, UpdateProfileAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileResourceAssociationError = AccessDeniedException | ConflictException | InternalServiceErrorException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified Route 53 Profile resourse association.
 */
export declare const updateProfileResourceAssociation: API.OperationMethod<UpdateProfileResourceAssociationRequest & RegionInput, UpdateProfileResourceAssociationResponse, UpdateProfileResourceAssociationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=route53profiles.d.ts.map