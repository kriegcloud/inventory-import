import * as Issues from "@distilled.cloud/github/issues";
import * as Layer from "effect/Layer";
import * as BindingHttp from "./BindingHttp.ts";
import { IssueNotFound } from "./Errors.ts";
import { GetIssue, type GetIssueRequest } from "./GetIssue.ts";
export declare const getIssueOperation: BindingHttp.Operation<[request: GetIssueRequest], Issues.Issue, import("@distilled.cloud/github").BadRequest | import("@distilled.cloud/github").ConfigError | import("@distilled.cloud/github").Conflict | import("@distilled.cloud/github").Forbidden | import("@distilled.cloud/github").GithubAppAuthError | import("@distilled.cloud/github").GithubParseError | import("@distilled.cloud/github").Gone | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/github").InvalidInput | IssueNotFound | import("@distilled.cloud/github").Locked | import("@distilled.cloud/core/sdk-error").SdkError | import("@distilled.cloud/github").UnknownGithubError | import("@distilled.cloud/github").UnprocessableEntity | import("@distilled.cloud/core/errors").DefaultErrors>;
/**
 * Token-backed implementation of {@link GetIssue}. Provide it on a Worker or
 * Function: it captures a `GitHub.PersonalAccessToken` for the host and binds
 * the token and the repository into it.
 *
 * @layer
 * @product Issue
 * @provides GitHub.GetIssue
 */
export declare const GetIssueHttp: Layer.Layer<GetIssue, never, import("alchemy/Self").Self<{
    Type: string;
    LogicalId: string;
}>>;
//# sourceMappingURL=GetIssueHttp.d.ts.map