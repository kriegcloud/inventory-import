import type { Kit, Model } from "../Kit.ts";
/**
 * `Exit` and `Cause`: how an effect ended, as data. An exit is a success
 * with its value, or a failure with its cause; a cause here has one reason,
 * a failure the code can handle or a defect.
 */
export declare const make: (kit: Kit) => {
    models: Readonly<Record<string, Model>>;
};
//# sourceMappingURL=Exits.d.ts.map