import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { Docker } from "./Docker.ts";
import type { Providers } from "./Providers.ts";
export interface VolumeLabel {
    /** Label name. */
    name: string;
    /** Label value. */
    value: string;
}
export interface VolumeProps {
    /**
     * Docker volume name.
     *
     * With the default `local` driver, the name must start with an ASCII
     * letter or digit and contain only letters, digits, `_`, `.`, and `-`.
     * Invalid local names fail at plan time, before deleting an old volume.
     * Third-party drivers may support different name formats.
     *
     * @default Generated from stack, stage, logical id, and instance id.
     */
    name?: string;
    /**
     * Volume driver. Changing it replaces a managed volume.
     * @default "local"
     */
    driver?: string;
    /** Driver-specific options. Changing them replaces a managed volume. */
    driverOpts?: Record<string, string>;
    /**
     * Custom metadata labels. Changing them replaces a managed volume.
     * Keys beginning with `alchemy::` are reserved for Alchemy's identity metadata.
     */
    labels?: Record<string, string>;
    /** Docker context name or context resource. */
    context?: Docker.ContextRef;
}
export interface Volume extends Resource<"Docker.Volume", VolumeProps, {
    /** Docker volume name. */
    id: string;
    /** Docker volume name. */
    name: string;
    /** Volume driver. */
    driver: string;
    /** Driver-specific options reported by Docker. */
    driverOpts: Record<string, string>;
    /** Labels reported by Docker. */
    labels: Record<string, string>;
    /** Host mountpoint path. */
    mountpoint?: string;
    /** Creation timestamp in milliseconds since epoch, or 0 if Docker returned an invalid time. */
    createdAt: number;
    /** Creation timestamp exactly as returned by Docker, for identity and compatibility checks. */
    createdAtRaw?: string;
}, never, Providers, VolumeLookup> {
}
/**
 * Props for {@link Volume.lookup}: find a volume this stack
 * doesn't manage by its name.
 */
export interface VolumeLookup {
    /** Volume name. */
    name: string;
    /**
     * Docker context the engine is reached through.
     * @default the current context
     */
    context?: string;
}
/**
 * A Docker volume managed through the active Docker context.
 *
 * Pre-existing same-name volumes are treated as foreign until the engine is
 * allowed to adopt them with `--adopt` or `adopt(true)`. This includes volumes
 * bearing this stack's labels but a different `alchemy::volume-instance`
 * generation after state loss. The previous generation is trusted only when
 * the engine supplies its persisted attributes.
 *
 * Each newly created volume receives an internal `alchemy::volume-instance`
 * label that identifies its resource generation. Alchemy verifies this identity,
 * the creation timestamp and the recorded Docker metadata before updating,
 * replacing or removing a tracked volume. Volumes adopted without this label
 * are checked against their previously observed identity instead.
 *
 * An explicitly adopted volume that originated outside the current resource
 * generation is not automatically deleted to apply changed immutable settings.
 * Alchemy fails the plan instead, so data migration is a deliberate operation.
 *
 * Docker removes volumes **by name**, not an immutable object ID: inspection
 * followed by removal is not atomic. Some Docker Engines report creation times
 * only to the second; a same-second replacement with copied labels may be
 * indistinguishable. Use `RemovalPolicy.protect()`, `retain()` and separate
 * backups for irreplaceable data.
 *
 *
 * ### Creating Volumes
 * **Example:** Basic volume
 * ```typescript
 * const data = yield* Docker.Volume("data", {
 *   name: "app-data",
 * });
 * ```
 *
 * **Example:** PostgreSQL data volume
 * ```typescript
 * const data = yield* Docker.Volume("postgres-data");
 * ```
 *
 * **Example:** Driver options and labels
 * ```typescript
 * const data = yield* Docker.Volume("db-data", {
 *   driver: "local",
 *   driverOpts: {
 *     type: "nfs",
 *     o: "addr=10.0.0.1,rw",
 *     device: ":/path/to/dir",
 *   },
 *   labels: {
 *     "com.example.usage": "database",
 *   },
 * });
 * ```
 *
 * ### Docker Context
 * **Example:** Create a volume in a named Docker context
 * ```typescript
 * const data = yield* Docker.Volume("data", {
 *   name: "app-data",
 *   context: "remote-build",
 * });
 * ```
 *
 * ### Looking up an existing volume
 * `Volume.lookup` references a volume Alchemy doesn't manage (created with
 * the Docker CLI, Compose or another stack). It is read during plan/deploy,
 * never created, updated or removed.
 *
 * **Example:** Reference an existing volume
 * ```typescript
 * const data = Docker.Volume.lookup({ name: "pgdata" });
 * ```
 *
 * ### Adopting an existing volume
 * A managed `Docker.Volume` with an existing name requires explicit adoption
 * when it belongs to another owner. Its existing labels, driver and contents
 * are preserved; adopting does not make immutable configuration changes safe.
 *
 * **Example:** Adopt an existing volume
 * ```typescript
 * import { adopt } from "alchemy/AdoptPolicy";
 *
 * const data = yield* Docker.Volume("imported-data", {
 *   name: "legacy-data",
 * }).pipe(adopt(true));
 * ```
 *
 * ### Protecting data volumes
 * Changing the name, driver, driver options or labels of a volume created by
 * Alchemy normally replaces the volume. The default removal policy deletes
 * the previous physical volume. `protect()` blocks replacement or destruction;
 * `retain()` leaves the physical volume in place when its state is removed.
 *
 * **Example:** Prevent accidental volume replacement or deletion
 * ```typescript
 * import * as RemovalPolicy from "alchemy/RemovalPolicy";
 *
 * const data = yield* Docker.Volume("critical-data").pipe(
 *   RemovalPolicy.protect(),
 * );
 * ```
 *
 * ### Validation and ownership conflicts
 * User-defined labels cannot start with `alchemy::`. Empty names/drivers and
 * invalid label or driver-option keys fail with `InvalidVolumeOptions`, which
 * reports the offending property path. For the built-in `local` driver, volume
 * names must begin with a letter or digit and contain only letters, digits,
 * `_`, `.` or `-`; invalid names fail during planning before delete-first
 * replacement. Third-party drivers may support other name formats.
 * When the observed volume no longer matches its recorded generation, Alchemy
 * reports `OwnedBySomeoneElse` instead of modifying or removing it.
 *
 * @resource
 * @product Volume
 */
export declare const Volume: import("alchemy/Resource").ResourceClass<Volume>;
export declare const VolumeProvider: () => import("effect/Layer").Layer<Provider.Provider<Volume>, never, Docker | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
declare const InvalidVolumeOptions_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvalidVolumeOptions";
} & Readonly<A>;
/** Invalid volume configuration, rejected before any destructive replacement. */
export declare class InvalidVolumeOptions extends InvalidVolumeOptions_base<{
    /** Property path in the Docker.Volume declaration. */
    readonly path: string;
    /** Explanation of the rejected value. */
    readonly message: string;
}> {
}
export declare const toVolumeAttributes: (info: Docker.Volume) => Volume["Attributes"];
export {};
//# sourceMappingURL=Volume.d.ts.map