/**
 * The dev sidecar entry: ONE process hosting every RPC-backed local
 * provider — Cloudflare's workerd-backed providers, the floci-backed AWS
 * providers, `Command.Dev` processes, framework dev servers — so their
 * long-lived state survives exec-child hot reloads during `alchemy dev`.
 *
 * Providers arrive in groups: each `RpcProvider.effect` names the URL of a
 * module whose default export is its group's provider layer (see
 * `Cloudflare/Local.ts`, `AWS/Local/Local.ts`, `Command/Local.ts`,
 * `Website/ServerLocal.ts`). A group is imported and built the first time
 * a session asks for one of its types, so a Cloudflare-only stack never
 * loads the AWS providers or starts the emulator they need. The spawner
 * (`RpcSpawner`) forks this entry once per run; `RpcProviderProxy` points
 * every provider at it.
 */
declare const SidecarInvalidProps_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "SidecarInvalidProps";
} & Readonly<A>;
export declare class SidecarInvalidProps extends SidecarInvalidProps_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
export {};
//# sourceMappingURL=Sidecar.d.ts.map