import * as NodeCrypto from "node:crypto";
import * as SecureRandom from "effect/crypto/SecureRandom";
import * as Effect from "effect/Effect";
import * as HttpBody from "effect/http/HttpBody";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Stream from "effect/Stream";
import { loadInternalWorker } from "../internal/internal-worker.ts";
const RegistryProxyWorker = {
  worker: () => loadInternalWorker("#cloudflare-runtime-core-worker/registry/RegistryProxy.worker"),
};
import {
  defaultDurableObjectUniqueKey,
  DEFAULT_COMPATIBILITY_DATE,
  SERVICE_USER_WORKER,
} from "../internal/constants.ts";
import { formatInternalWorkerModules } from "../internal/internal-modules.ts";
import * as Plugin from "../Plugin.ts";
import { PluginContext } from "../PluginContext.ts";
import { SystemError } from "../RuntimeError.shared.ts";
import * as WorkerdConfig from "../workerd/Config.ts";
import * as Registry from "./Registry.ts";
import {
  HEADER_REGISTRY_UPDATE_SECRET,
  type ResolvedTargetMap,
  type Subscriber,
} from "./RegistryTypes.shared.ts";

export class RegistryProxy extends Plugin.Service<
  RegistryProxy,
  {
    /**
     * Declares a service, belonging to the current worker, that will be published to the registry proxy.
     */
    readonly publish: (service: PublishedService) => Effect.Effect<void>;
    /**
     * Declares an external service that will be consumed by the current worker.
     * Returns a service designator that proxies to the external target.
     */
    readonly subscribe: <T extends Subscriber>(
      subscriber: T,
    ) => Effect.Effect<ServiceDesignatorFromSubscriber<T>>;
  }
>()("cloudflare-runtime/plugin/RegistryProxy") {}

type PublishedService =
  | Subscriber.DurableObject
  | (Subscriber.QueueConsumer & { service: string })
  | (Omit<Subscriber.Workflow, "scriptName"> & { service: string });

type ServiceDesignatorFromSubscriber<T extends Subscriber> = T extends {
  kind: "durable-object";
}
  ? WorkerdConfig.Worker_DurableObjectNamespace
  : WorkerdConfig.ServiceDesignator;

const SERVICE_REGISTRY_PROXY = "cloudflare-runtime:registry-proxy";

const SOCKET_REGISTRY_PROXY = "registry-proxy-socket";
const SOCKET_DEBUG_PORT = "debug-port";

export const RegistryProxyLive = Layer.effect(
  RegistryProxy,
  Effect.gen(function* () {
    const registry = yield* Registry.Registry;
    const http = yield* HttpClient.HttpClient;
    const random = yield* SecureRandom.SecureRandom;

    return RegistryProxy.of(
      Effect.gen(function* () {
        const { worker } = yield* PluginContext;

        const published: Array<PublishedService> =
          worker.durableObjectNamespaces?.map((namespace) => ({
            kind: "durable-object",
            scriptName: worker.name,
            className: namespace.className,
            uniqueKey:
              namespace.uniqueKey ??
              defaultDurableObjectUniqueKey(worker.name, namespace.className),
          })) ?? [];
        const subscribed: Array<Subscriber> = [];
        // The proxy's update socket is reachable by any local process, so
        // pushes must prove they came from the process that owns the proxy.
        const updateSecret = NodeCrypto.randomBytes(32).toString("hex");

        return {
          defer: Effect.gen(function* () {
            if (subscribed.length === 0) {
              return {};
            }
            const durableObjects = subscribed.filter(
              (subscriber) => subscriber.kind === "durable-object",
            );
            const service: WorkerdConfig.Service = {
              name: SERVICE_REGISTRY_PROXY,
              worker: {
                compatibilityDate: DEFAULT_COMPATIBILITY_DATE,
                compatibilityFlags: ["service_binding_extra_handlers"],
                modules: yield* registry
                  .read(subscribed)
                  .pipe(
                    Effect.flatMap((targets) =>
                      Effect.promise(() => buildWorkerModules(targets, durableObjects)),
                    ),
                  ),
                bindings: [
                  {
                    name: "REGISTRY_DEBUG_PORT",
                    workerdDebugPort: WorkerdConfig.kVoid,
                  },
                  {
                    name: "REGISTRY_UPDATE_SECRET",
                    data: new TextEncoder().encode(updateSecret),
                  },
                ],
                durableObjectStorage: { inMemory: WorkerdConfig.kVoid },
                durableObjectNamespaces: durableObjects.map((subscriber) => ({
                  className: externalDurableObjectClassName(
                    subscriber.scriptName,
                    subscriber.className,
                  ),
                  uniqueKey: subscriber.uniqueKey,
                })),
              },
            };
            const socket: WorkerdConfig.Socket = {
              name: SOCKET_REGISTRY_PROXY,
              address: "127.0.0.1:0",
              service: { name: SERVICE_REGISTRY_PROXY },
            };
            return { sockets: [socket], services: [service] };
          }),
          start: (ports) =>
            // When the worker starts, publish it to the registry.
            // If we have external services, subscribe to the registry and push updates to the proxy.
            Effect.all(
              [
                Effect.gen(function* () {
                  const debugPort = ports[SOCKET_DEBUG_PORT];
                  if (!debugPort) {
                    return yield* SystemError.make({
                      subtag: "RegistryProxyDebugPort",
                      message: "Debug port not found.",
                      detail: { debugPort },
                    });
                  }
                  yield* registry.write({
                    scriptName: worker.name,
                    debugPortAddress: `127.0.0.1:${debugPort}`,
                    // `start` runs again for a replacement process on the same ports.
                    instanceId: yield* random.uuidV4(),
                    services: [
                      {
                        kind: "worker",
                        // TODO: The fetch service should be the service name for the top of the middleware chain.
                        fetchService: SERVICE_USER_WORKER,
                        rpcService: SERVICE_USER_WORKER,
                      },
                      ...published.map((service) => ({
                        ...service,
                        service: "service" in service ? service.service : SERVICE_USER_WORKER,
                      })),
                    ],
                  });
                }),
                Effect.gen(function* () {
                  if (subscribed.length === 0) {
                    return;
                  }
                  const proxyPort = ports[SOCKET_REGISTRY_PROXY];
                  if (!proxyPort) {
                    return yield* SystemError.make({
                      subtag: "RegistryProxyPort",
                      message: "Registry proxy port not found.",
                      detail: { proxyPort },
                    });
                  }
                  // A replacement process starts with the original module
                  // snapshot. Restore current targets before announcing it as
                  // ready, then subscribe afresh for subsequent changes.
                  const update = (targets: ResolvedTargetMap) =>
                    HttpClient.filterStatusOk(http)
                      .post(`http://127.0.0.1:${proxyPort}/`, {
                        headers: { [HEADER_REGISTRY_UPDATE_SECRET]: updateSecret },
                        body: HttpBody.jsonUnsafe(targets),
                      })
                      .pipe(
                        Effect.mapError((cause) =>
                          SystemError.make({
                            subtag: "RegistryProxyUpdate",
                            message: "Failed to update the registry proxy targets.",
                            cause,
                          }),
                        ),
                      );
                  yield* registry.read(subscribed).pipe(Effect.flatMap(update));
                  yield* registry
                    .subscribe(subscribed)
                    .pipe(Stream.runForEach(update), Effect.forkScoped);
                }),
              ],
              { concurrency: "unbounded", discard: true },
            ),
          api: {
            publish: (entry) =>
              Effect.sync(() => {
                published.push(entry);
              }),
            subscribe: <T extends Subscriber>(subscriber: T) =>
              Effect.sync<ServiceDesignatorFromSubscriber<T>>(() => {
                subscribed.push(subscriber);
                switch (subscriber.kind) {
                  case "worker":
                    return {
                      name: SERVICE_REGISTRY_PROXY,
                      entrypoint: "ExternalService",
                      props: {
                        json: JSON.stringify(subscriber),
                      },
                    };
                  case "durable-object":
                    return {
                      serviceName: SERVICE_REGISTRY_PROXY,
                      className: externalDurableObjectClassName(
                        subscriber.scriptName,
                        subscriber.className,
                      ),
                    };
                  case "queue-consumer":
                    return {
                      name: SERVICE_REGISTRY_PROXY,
                      entrypoint: "ExternalQueueConsumer",
                      props: {
                        json: JSON.stringify(subscriber),
                      },
                    };
                  case "workflow":
                    return {
                      name: SERVICE_REGISTRY_PROXY,
                      entrypoint: "ExternalWorkflow",
                      props: {
                        json: JSON.stringify(subscriber),
                      },
                    };
                }
              }),
          },
        };
      }),
    );
  }),
);

/** Generates a stable, variable-safe class name for an external Durable Object. */
const externalDurableObjectClassName = (scriptName: string, className: string) =>
  `ExternalDurableObject_${NodeCrypto.createHash("sha256").update(scriptName).update(className).digest("hex").slice(0, 16)}`;

/** Builds the worker modules for the registry proxy, including a pre-populated registry and proxy classes for each external Durable Object. */
const buildWorkerModules = async (
  targets: ResolvedTargetMap,
  durableObjects: ReadonlyArray<Subscriber.DurableObject>,
) => {
  const worker = await RegistryProxyWorker.worker();
  const main = [
    `import { makeExternalDurableObject, Target } from "./${worker.main}";`,
    `export { default, ExternalService, ExternalWorkflow, ExternalQueueConsumer } from "./${worker.main}";`,
    `Target.set(${JSON.stringify(targets)});`,
    ...durableObjects.map(
      (subscriber) =>
        `export const ${externalDurableObjectClassName(subscriber.scriptName, subscriber.className)} = makeExternalDurableObject(${JSON.stringify(subscriber)});`,
    ),
  ].join("\n");
  return formatInternalWorkerModules({
    modules: {
      "index.worker.mjs": main,
      ...worker.modules,
    },
  });
};
