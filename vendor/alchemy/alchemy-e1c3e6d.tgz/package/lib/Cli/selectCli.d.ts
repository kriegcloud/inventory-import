import type * as Prompt from "effect/cli/Prompt";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Interaction from "../Interaction.ts";
import type { Cli } from "../Report.ts";
/** Whether the console is JSON: the parsed `--log-format`, else `ALCHEMY_LOG_FORMAT`. */
export declare const jsonConsole: Effect.Effect<boolean, never, never>;
/**
 * The CLI's renderer and its Interaction:
 *
 * - `--log-format json`: messages become log records on stdout, views print
 *   nothing, no prompts, and no shutdown or exit lines after the command;
 * - an interactive terminal: the Sigil UI;
 * - otherwise: plain log lines.
 */
export declare const selectRenderer: () => Layer.Layer<Cli | Interaction.Interaction, never, Prompt.Environment>;
//# sourceMappingURL=selectCli.d.ts.map