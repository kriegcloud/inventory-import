import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ExpiredIteratorException_base: S.TaggedErrorClass<"ExpiredIteratorException", {
    readonly message: any;
}>;
export declare class ExpiredIteratorException extends /*@__PURE__*/ ExpiredIteratorException_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}>;
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TrimmedDataAccessException_base: S.TaggedErrorClass<"TrimmedDataAccessException", {
    readonly message: any;
}>;
export declare class TrimmedDataAccessException extends /*@__PURE__*/ TrimmedDataAccessException_base {
}
export type StreamArn = string;
export type PositiveIntegerObject = number;
export type ShardId = string;
export type ShardFilterType = "CHILD_SHARDS" | (string & {});
export interface ShardFilter {
    Type?: ShardFilterType | undefined;
    ShardId?: string | undefined;
}
export interface DescribeStreamInput {
    StreamArn: string;
    Limit?: number | undefined;
    ExclusiveStartShardId?: string | undefined;
    ShardFilter?: ShardFilter | undefined;
}
export type StreamStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | (string & {});
export type StreamViewType = "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY" | (string & {});
export type TableName = string;
export type KeySchemaAttributeName = string;
export type KeyType = "HASH" | "RANGE" | (string & {});
export interface KeySchemaElement {
    AttributeName: string;
    KeyType: KeyType;
}
export type KeySchema = KeySchemaElement[];
export type SequenceNumber = string;
export interface SequenceNumberRange {
    StartingSequenceNumber?: string | undefined;
    EndingSequenceNumber?: string | undefined;
}
export interface Shard {
    ShardId?: string | undefined;
    SequenceNumberRange?: SequenceNumberRange | undefined;
    ParentShardId?: string | undefined;
}
export type ShardDescriptionList = Shard[];
export interface StreamDescription {
    StreamArn?: string | undefined;
    StreamLabel?: string | undefined;
    StreamStatus?: StreamStatus | undefined;
    StreamViewType?: StreamViewType | undefined;
    CreationRequestDateTime?: Date | undefined;
    TableName?: string | undefined;
    KeySchema?: KeySchemaElement[] | undefined;
    Shards?: Shard[] | undefined;
    LastEvaluatedShardId?: string | undefined;
}
export interface DescribeStreamOutput {
    StreamDescription?: StreamDescription | undefined;
}
export type ShardIterator = string;
export interface GetRecordsInput {
    ShardIterator: string;
    Limit?: number | undefined;
}
export type OperationType = "INSERT" | "MODIFY" | "REMOVE" | (string & {});
export type AttributeName = string;
export type StringAttributeValue = string;
export type NumberAttributeValue = string;
export type BinaryAttributeValue = Uint8Array;
export type StringSetAttributeValue = string[];
export type NumberSetAttributeValue = string[];
export type BinarySetAttributeValue = Uint8Array[];
export type MapAttributeValue = {
    [key: string]: AttributeValue | undefined;
};
export type ListAttributeValue = AttributeValue[];
export type NullAttributeValue = boolean;
export type BooleanAttributeValue = boolean;
export type AttributeValue = {
    S: string;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N: string;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B: Uint8Array;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS: string[];
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS: string[];
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS: Uint8Array[];
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M: {
        [key: string]: AttributeValue | undefined;
    };
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L: AttributeValue[];
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL: boolean;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL: boolean;
};
export type AttributeMap = {
    [key: string]: AttributeValue | undefined;
};
export type PositiveLongObject = number;
export interface StreamRecord {
    ApproximateCreationDateTime?: Date | undefined;
    Keys?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    NewImage?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    OldImage?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    SequenceNumber?: string | undefined;
    SizeBytes?: number | undefined;
    StreamViewType?: StreamViewType | undefined;
}
export interface Identity {
    PrincipalId?: string | undefined;
    Type?: string | undefined;
}
export interface Record {
    eventID?: string | undefined;
    eventName?: OperationType | undefined;
    eventVersion?: string | undefined;
    eventSource?: string | undefined;
    awsRegion?: string | undefined;
    dynamodb?: StreamRecord | undefined;
    userIdentity?: Identity | undefined;
}
export type RecordList = Record[];
export interface GetRecordsOutput {
    Records?: Record[] | undefined;
    NextShardIterator?: string | undefined;
}
export type ShardIteratorType = "TRIM_HORIZON" | "LATEST" | "AT_SEQUENCE_NUMBER" | "AFTER_SEQUENCE_NUMBER" | "AT_TIMESTAMP" | (string & {});
export interface GetShardIteratorInput {
    StreamArn: string;
    ShardId: string;
    ShardIteratorType: ShardIteratorType;
    SequenceNumber?: string | undefined;
    Timestamp?: Date | undefined;
}
export interface GetShardIteratorOutput {
    ShardIterator?: string | undefined;
}
export interface ListStreamsInput {
    TableName?: string | undefined;
    Limit?: number | undefined;
    ExclusiveStartStreamArn?: string | undefined;
}
export interface Stream {
    StreamArn?: string | undefined;
    TableName?: string | undefined;
    StreamLabel?: string | undefined;
}
export type StreamList = Stream[];
export interface ListStreamsOutput {
    Streams?: Stream[] | undefined;
    LastEvaluatedStreamArn?: string | undefined;
}
export type ErrorMessage = string;
export type DescribeStreamError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about a stream, including the current status of the stream, its Amazon Resource Name (ARN), the composition of its shards, and its corresponding DynamoDB table.
 *
 * You can call `DescribeStream` at a maximum rate of 10 times per second.
 *
 * Each shard in the stream has a `SequenceNumberRange` associated with it. If the
 * `SequenceNumberRange` has a `StartingSequenceNumber` but no
 * `EndingSequenceNumber`, then the shard is still open (able to receive more stream
 * records). If both `StartingSequenceNumber` and `EndingSequenceNumber`
 * are present, then that shard is closed and can no longer receive more data.
 */
export declare const describeStream: API.OperationMethod<DescribeStreamInput & RegionInput, DescribeStreamOutput, DescribeStreamError, Credentials | HttpClient.HttpClient>;
export type GetRecordsError = ExpiredIteratorException | InternalServerError | LimitExceededException | ResourceNotFoundException | TrimmedDataAccessException | CommonErrors;
/**
 * Retrieves the stream records from a given shard.
 *
 * Specify a shard iterator using the `ShardIterator` parameter. The shard iterator
 * specifies the position in the shard from which you want to start reading stream records
 * sequentially. If there are no stream records available in the portion of the shard that the
 * iterator points to, `GetRecords` returns an empty list. Note that it might take
 * multiple calls to get to a portion of the shard that contains stream records.
 *
 * `GetRecords` can retrieve a maximum of 1 MB of data or 1000 stream records,
 * whichever comes first.
 */
export declare const getRecords: API.OperationMethod<GetRecordsInput & RegionInput, GetRecordsOutput, GetRecordsError, Credentials | HttpClient.HttpClient>;
export type GetShardIteratorError = InternalServerError | ResourceNotFoundException | TrimmedDataAccessException | CommonErrors;
/**
 * Returns a shard iterator. A shard iterator provides information
 * about how to retrieve the stream records from within a shard. Use
 * the shard iterator in a subsequent
 * `GetRecords` request to read the stream records
 * from the shard.
 *
 * A shard iterator expires 15 minutes after it is returned to the requester.
 */
export declare const getShardIterator: API.OperationMethod<GetShardIteratorInput & RegionInput, GetShardIteratorOutput, GetShardIteratorError, Credentials | HttpClient.HttpClient>;
export type ListStreamsError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of stream ARNs associated with the current account and endpoint. If the
 * `TableName` parameter is present, then `ListStreams` will return only the
 * streams ARNs for that table.
 *
 * You can call `ListStreams` at a maximum rate of 5 times per second.
 */
export declare const listStreams: API.OperationMethod<ListStreamsInput & RegionInput, ListStreamsOutput, ListStreamsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dynamodb-streams.d.ts.map