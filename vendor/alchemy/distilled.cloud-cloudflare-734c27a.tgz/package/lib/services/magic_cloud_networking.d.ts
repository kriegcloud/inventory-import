import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CatalogSyncNotFound_base: S.TaggedErrorClass<"CatalogSyncNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CatalogSyncNotFound extends /*@__PURE__*/ CatalogSyncNotFound_base {
}
declare const CloudIntegrationNotFound_base: S.TaggedErrorClass<"CloudIntegrationNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CloudIntegrationNotFound extends /*@__PURE__*/ CloudIntegrationNotFound_base {
}
declare const FeatureNotEnabled_base: S.TaggedErrorClass<"FeatureNotEnabled", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class FeatureNotEnabled extends /*@__PURE__*/ FeatureNotEnabled_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const OnRampNotFound_base: S.TaggedErrorClass<"OnRampNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class OnRampNotFound extends /*@__PURE__*/ OnRampNotFound_base {
}
export interface ApplyOnRampRequest {
    accountId: string;
    onrampId: string;
}
export interface ApplyOnRampResponse {
}
export type CatalogSyncsCreateRequestDestinationType = "NONE" | "ZERO_TRUST_LIST";
export type CatalogSyncsCreateRequestUpdateMode = "AUTO" | "MANUAL";
export interface CreateCatalogSyncRequest {
    accountId: string;
    forwarded?: string | undefined;
    destinationType: CatalogSyncsCreateRequestDestinationType | (string & {});
    name: string;
    updateMode: CatalogSyncsCreateRequestUpdateMode | (string & {});
    description?: string | undefined;
    policy?: string | undefined;
}
export type CatalogSyncsCreateResponseDestinationType = "NONE" | "ZERO_TRUST_LIST";
export type CatalogSyncsCreateResponseUpdateMode = "AUTO" | "MANUAL";
export type CatalogSyncsCreateResponseErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export interface CatalogSyncsCreateResponseErrorsValueMeta {
    l10nKey?: string | null | undefined;
    loggableError?: string | null | undefined;
    templateData?: unknown | null | undefined;
    traceId?: string | null | undefined;
}
export interface CatalogSyncsCreateResponseErrorsValueSource {
    parameter?: string | null | undefined;
    parameterValueIndex?: number | null | undefined;
    pointer?: string | null | undefined;
}
export interface CatalogSyncsCreateResponseErrorsValue {
    code: CatalogSyncsCreateResponseErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type CatalogSyncsCreateResponseErrorsMap = {
    [key: string]: CatalogSyncsCreateResponseErrorsValue | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCatalogSyncResponse {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsCreateResponseDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsCreateResponseUpdateMode;
    errors?: CatalogSyncsCreateResponseErrorsMap | null | undefined;
    includesDiscoveriesUntil?: string | null | undefined;
    lastAttemptedUpdateAt?: string | null | undefined;
    lastSuccessfulUpdateAt?: string | null | undefined;
}
export type CloudIntegrationsCreateRequestCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export interface CreateCloudIntegrationRequest {
    accountId: string;
    forwarded?: string | undefined;
    cloudType: CloudIntegrationsCreateRequestCloudType | (string & {});
    friendlyName: string;
    description?: string | undefined;
}
export type CloudIntegrationsCreateResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type CloudIntegrationsCreateResponseLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export type CloudIntegrationsCreateResponseState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsCreateResponseStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export interface CloudIntegrationsCreateResponseStatusDiscoveryProgress {
    done: number;
    total: number;
    unit: string;
}
export type CloudIntegrationsCreateResponseStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsCreateResponseStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsCreateResponseStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsCreateResponseStatusRegionsList = Array<string>;
export type CloudIntegrationsCreateResponseStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface CloudIntegrationsCreateResponseStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsCreateResponseStatusInUseByItemClientType;
    name: string;
}
export type CloudIntegrationsCreateResponseStatusInUseByList = Array<CloudIntegrationsCreateResponseStatusInUseByItem>;
export interface CloudIntegrationsCreateResponseStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsCreateResponseStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsCreateResponseStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsCreateResponseStatusRegionsList;
    credentialsGoodSince?: string | null | undefined;
    credentialsMissingSince?: string | null | undefined;
    credentialsRejectedSince?: string | null | undefined;
    discoveryMessage?: string | null | undefined;
    discoveryMessageV2?: string | null | undefined;
    inUseBy?: CloudIntegrationsCreateResponseStatusInUseByList | null | undefined;
    lastDiscoveryCompletedAt?: string | null | undefined;
    lastDiscoveryCompletedAtV2?: string | null | undefined;
    lastDiscoveryStartedAt?: string | null | undefined;
    lastDiscoveryStartedAtV2?: string | null | undefined;
    lastUpdated?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCloudIntegrationResponse {
    id: string;
    cloudType: CloudIntegrationsCreateResponseCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsCreateResponseLifecycleState;
    state: CloudIntegrationsCreateResponseState;
    stateV2: CloudIntegrationsCreateResponseStateV2;
    awsArn?: string | null | undefined;
    azureSubscriptionId?: string | null | undefined;
    azureTenantId?: string | null | undefined;
    description?: string | null | undefined;
    gcpProjectId?: string | null | undefined;
    gcpServiceAccountEmail?: string | null | undefined;
    status?: CloudIntegrationsCreateResponseStatus | null | undefined;
}
export type OnRampsCreateRequestCloudType = "AWS" | "AZURE" | "GOOGLE";
export type OnRampsCreateRequestType = "OnrampTypeSingle" | "OnrampTypeHub";
export type OnRampsCreateRequestAttachedHubsList = Array<string>;
export type OnRampsCreateRequestAttachedVpcsList = Array<string>;
export interface CreateOnRampRequest {
    accountId: string;
    forwarded?: string | undefined;
    cloudType: OnRampsCreateRequestCloudType | (string & {});
    /** Enables BGP routing. When enabling this feature, set both install_routes_in_cloud and install_routes_in_magic_wan to false. */
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsCreateRequestType | (string & {});
    adoptedHubId?: string | undefined;
    attachedHubs?: OnRampsCreateRequestAttachedHubsList | undefined;
    attachedVpcs?: OnRampsCreateRequestAttachedVpcsList | undefined;
    /** Sets the cloud-side ASN. If unset or zero, the cloud's default ASN takes effect. */
    cloudAsn?: number | undefined;
    description?: string | undefined;
    hubProviderId?: string | undefined;
    manageHubToHubAttachments?: boolean | undefined;
    manageVpcToHubAttachments?: boolean | undefined;
    region?: string | undefined;
    vpc?: string | undefined;
}
export type OnRampsCreateResponseCloudType = "AWS" | "AZURE" | "GOOGLE";
export type OnRampsCreateResponseType = "OnrampTypeSingle" | "OnrampTypeHub";
export type OnRampsCreateResponseAttachedHubsList = Array<string>;
export type OnRampsCreateResponseAttachedVpcsList = Array<string>;
export interface OnRampsCreateResponsePlannedMonthlyCostEstimate {
    currency: string;
    currentMonthlyCost: number;
    diff: number;
    proposedMonthlyCost: number;
}
export interface OnRampsCreateResponsePlannedResourcesItemDiff {
    diff: string;
    leftDescription: string;
    leftYaml: string;
    rightDescription: string;
    rightYaml: string;
}
export type OnRampsCreateResponsePlannedResourcesItemKeysRequireReplaceList = Array<string>;
export type OnRampsCreateResponsePlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsCreateResponsePlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export type OnRampsCreateResponsePlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponsePlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponsePlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsCreateResponsePlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePlannedResourcesItemResourceResourceType;
    title: string;
}
export interface OnRampsCreateResponsePlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsCreateResponsePlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsCreateResponsePlannedResourcesItemPlannedAction;
    resource: OnRampsCreateResponsePlannedResourcesItemResource;
}
export type OnRampsCreateResponsePlannedResourcesList = Array<OnRampsCreateResponsePlannedResourcesItem>;
export interface OnRampsCreateResponsePostApplyMonthlyCostEstimate {
    currency: string;
    monthlyCost: number;
}
export type OnRampsCreateResponsePostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponsePostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsCreateResponsePostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export interface OnRampsCreateResponsePostApplyResourcesValueObservationsValue {
    firstObservedAt: string;
    lastObservedAt: string;
    providerId: string;
    resourceId: string;
}
export type OnRampsCreateResponsePostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsCreateResponsePostApplyResourcesValueProviderIdsList = Array<string>;
export type OnRampsCreateResponsePostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsCreateResponsePostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem {
    itemType: string;
    string: string;
}
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem {
    itemType: string;
    yaml: string;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem {
    itemType: string;
    yamlDiff: OnRampsCreateResponsePlannedResourcesItemDiff;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsCreateResponsePostApplyResourcesValueSectionsList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItem>;
export type OnRampsCreateResponsePostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsCreateResponsePostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsCreateResponsePostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsCreateResponsePostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsCreateResponsePostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export type OnRampsCreateResponsePostApplyResourcesValueManagedByList = Array<OnRampsCreateResponsePostApplyResourcesValueManagedByItem>;
export interface OnRampsCreateResponsePostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueCloudType;
    config: OnRampsCreateResponsePostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsCreateResponsePostApplyResourcesValueObservationsMap;
    providerIds: OnRampsCreateResponsePostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsCreateResponsePostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueResourceType;
    sections: OnRampsCreateResponsePostApplyResourcesValueSectionsList;
    state: OnRampsCreateResponsePostApplyResourcesValueStateMap;
    tags: OnRampsCreateResponsePostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsCreateResponsePostApplyResourcesValueManagedByList | null | undefined;
}
export type OnRampsCreateResponsePostApplyResourcesMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValue | undefined;
};
export interface OnRampsCreateResponseStatusApplyProgress {
    done: number;
    total: number;
}
export type OnRampsCreateResponseStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export type OnRampsCreateResponseStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsCreateResponseStatusRoutesList = Array<string>;
export type OnRampsCreateResponseStatusTunnelsList = Array<string>;
export type OnRampsCreateResponseStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type OnRampsCreateResponseStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type OnRampsCreateResponseStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface OnRampsCreateResponseStatusLifecycleErrorsValue {
    code: OnRampsCreateResponseStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type OnRampsCreateResponseStatusLifecycleErrorsMap = {
    [key: string]: OnRampsCreateResponseStatusLifecycleErrorsValue | undefined;
};
export interface OnRampsCreateResponseStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsCreateResponseStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsCreateResponseStatusRoutesList;
    tunnels: OnRampsCreateResponseStatusTunnelsList;
    lifecycleErrors?: OnRampsCreateResponseStatusLifecycleErrorsMap | null | undefined;
}
export type OnRampsCreateResponseVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponseVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsCreateResponseVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsCreateResponseVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsCreateResponseVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsCreateResponseVpcsByIdValueProviderIdsList = Array<string>;
export type OnRampsCreateResponseVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsCreateResponseVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsCreateResponseVpcsByIdValueSectionsList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItem>;
export type OnRampsCreateResponseVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsCreateResponseVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsCreateResponseVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsCreateResponseVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsCreateResponseVpcsByIdValueManagedByItemClientType;
    name: string;
}
export type OnRampsCreateResponseVpcsByIdValueManagedByList = Array<OnRampsCreateResponseVpcsByIdValueManagedByItem>;
export interface OnRampsCreateResponseVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueCloudType;
    config: OnRampsCreateResponseVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsCreateResponseVpcsByIdValueObservationsMap;
    providerIds: OnRampsCreateResponseVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsCreateResponseVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueResourceType;
    sections: OnRampsCreateResponseVpcsByIdValueSectionsList;
    state: OnRampsCreateResponseVpcsByIdValueStateMap;
    tags: OnRampsCreateResponseVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsCreateResponseVpcsByIdValueManagedByList | null | undefined;
}
export type OnRampsCreateResponseVpcsByIdMap = {
    [key: string]: OnRampsCreateResponseVpcsByIdValue | undefined;
};
export type OnRampsCreateResponseVpcsByIdUnavailableList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOnRampResponse {
    id: string;
    cloudType: OnRampsCreateResponseCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsCreateResponseType;
    updatedAt: string;
    attachedHubs?: OnRampsCreateResponseAttachedHubsList | null | undefined;
    attachedVpcs?: OnRampsCreateResponseAttachedVpcsList | null | undefined;
    cloudAsn?: number | null | undefined;
    description?: string | null | undefined;
    hub?: string | null | undefined;
    lastAppliedAt?: string | null | undefined;
    lastExportedAt?: string | null | undefined;
    lastPlannedAt?: string | null | undefined;
    manageHubToHubAttachments?: boolean | null | undefined;
    manageVpcToHubAttachments?: boolean | null | undefined;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null | undefined;
    plannedResources?: OnRampsCreateResponsePlannedResourcesList | null | undefined;
    plannedResourcesUnavailable?: boolean | null | undefined;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null | undefined;
    postApplyResources?: OnRampsCreateResponsePostApplyResourcesMap | null | undefined;
    postApplyResourcesUnavailable?: boolean | null | undefined;
    region?: string | null | undefined;
    status?: OnRampsCreateResponseStatus | null | undefined;
    vpc?: string | null | undefined;
    vpcsById?: OnRampsCreateResponseVpcsByIdMap | null | undefined;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsCreateResponseVpcsByIdUnavailableList | null | undefined;
}
export interface DeleteCatalogSyncRequest {
    accountId: string;
    syncId: string;
    deleteDestination?: boolean | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCatalogSyncResponse {
    id: string;
}
export interface DeleteCloudIntegrationRequest {
    accountId: string;
    providerId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCloudIntegrationResponse {
    id: string;
}
export interface DeleteOnRampRequest {
    accountId: string;
    onrampId: string;
    destroy?: boolean | undefined;
    force?: boolean | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOnRampResponse {
    id: string;
}
export interface DiscoverAllCloudIntegrationRequest {
    accountId: string;
}
export interface DiscoverAllCloudIntegrationResponse {
}
export interface DiscoverCloudIntegrationRequest {
    accountId: string;
    providerId: string;
    v2?: boolean | undefined;
}
export interface DiscoverCloudIntegrationResponse {
}
export interface ExportOnRampRequest {
    accountId: string;
    onrampId: string;
}
export interface ExportOnRampResponse {
}
export type ResourcesExportRequestResourceIdList = Array<string>;
export type ResourcesExportRequestResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type ResourcesExportRequestResourceTypeList = Array<ResourcesExportRequestResourceType | (string & {})>;
export type ResourcesExportRequestSearchList = Array<string>;
export interface ExportResourceRequest {
    accountId: string;
    desc?: boolean | undefined;
    /** One of ["id", "resource_type", "region"]. */
    orderBy?: string | undefined;
    providerId?: string | undefined;
    region?: string | undefined;
    resourceGroup?: string | undefined;
    resourceId?: ResourcesExportRequestResourceIdList | undefined;
    resourceType?: ResourcesExportRequestResourceTypeList | undefined;
    search?: ResourcesExportRequestSearchList | undefined;
    v2?: boolean | undefined;
}
export interface ExportResourceResponse {
}
export interface GetCatalogSyncRequest {
    accountId: string;
    syncId: string;
}
export type CatalogSyncsGetResponseDestinationType = "NONE" | "ZERO_TRUST_LIST";
export type CatalogSyncsGetResponseUpdateMode = "AUTO" | "MANUAL";
export type CatalogSyncsGetResponseErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type CatalogSyncsGetResponseErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type CatalogSyncsGetResponseErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface CatalogSyncsGetResponseErrorsValue {
    code: CatalogSyncsGetResponseErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type CatalogSyncsGetResponseErrorsMap = {
    [key: string]: CatalogSyncsGetResponseErrorsValue | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCatalogSyncResponse {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsGetResponseDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsGetResponseUpdateMode;
    errors?: CatalogSyncsGetResponseErrorsMap | null | undefined;
    includesDiscoveriesUntil?: string | null | undefined;
    lastAttemptedUpdateAt?: string | null | undefined;
    lastSuccessfulUpdateAt?: string | null | undefined;
}
export interface GetCloudIntegrationRequest {
    accountId: string;
    providerId: string;
    status?: boolean | undefined;
}
export type CloudIntegrationsGetResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type CloudIntegrationsGetResponseLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export type CloudIntegrationsGetResponseState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsGetResponseStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsGetResponseStatusDiscoveryProgress = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsGetResponseStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsGetResponseStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsGetResponseStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsGetResponseStatusRegionsList = Array<string>;
export type CloudIntegrationsGetResponseStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface CloudIntegrationsGetResponseStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsGetResponseStatusInUseByItemClientType;
    name: string;
}
export type CloudIntegrationsGetResponseStatusInUseByList = Array<CloudIntegrationsGetResponseStatusInUseByItem>;
export interface CloudIntegrationsGetResponseStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsGetResponseStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsGetResponseStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsGetResponseStatusRegionsList;
    credentialsGoodSince?: string | null | undefined;
    credentialsMissingSince?: string | null | undefined;
    credentialsRejectedSince?: string | null | undefined;
    discoveryMessage?: string | null | undefined;
    discoveryMessageV2?: string | null | undefined;
    inUseBy?: CloudIntegrationsGetResponseStatusInUseByList | null | undefined;
    lastDiscoveryCompletedAt?: string | null | undefined;
    lastDiscoveryCompletedAtV2?: string | null | undefined;
    lastDiscoveryStartedAt?: string | null | undefined;
    lastDiscoveryStartedAtV2?: string | null | undefined;
    lastUpdated?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCloudIntegrationResponse {
    id: string;
    cloudType: CloudIntegrationsGetResponseCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsGetResponseLifecycleState;
    state: CloudIntegrationsGetResponseState;
    stateV2: CloudIntegrationsGetResponseStateV2;
    awsArn?: string | null | undefined;
    azureSubscriptionId?: string | null | undefined;
    azureTenantId?: string | null | undefined;
    description?: string | null | undefined;
    gcpProjectId?: string | null | undefined;
    gcpServiceAccountEmail?: string | null | undefined;
    status?: CloudIntegrationsGetResponseStatus | null | undefined;
}
export interface GetOnRampRequest {
    accountId: string;
    onrampId: string;
    plannedResources?: boolean | undefined;
    postApplyResources?: boolean | undefined;
    status?: boolean | undefined;
    vpcs?: boolean | undefined;
}
export type OnRampsGetResponseCloudType = "AWS" | "AZURE" | "GOOGLE";
export type OnRampsGetResponseType = "OnrampTypeSingle" | "OnrampTypeHub";
export type OnRampsGetResponseAttachedHubsList = Array<string>;
export type OnRampsGetResponseAttachedVpcsList = Array<string>;
export type OnRampsGetResponsePlannedMonthlyCostEstimate = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsGetResponsePlannedResourcesItemDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsGetResponsePlannedResourcesItemKeysRequireReplaceList = Array<string>;
export type OnRampsGetResponsePlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsGetResponsePlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export type OnRampsGetResponsePlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponsePlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponsePlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsGetResponsePlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePlannedResourcesItemResourceResourceType;
    title: string;
}
export interface OnRampsGetResponsePlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsGetResponsePlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsGetResponsePlannedResourcesItemPlannedAction;
    resource: OnRampsGetResponsePlannedResourcesItemResource;
}
export type OnRampsGetResponsePlannedResourcesList = Array<OnRampsGetResponsePlannedResourcesItem>;
export type OnRampsGetResponsePostApplyMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsGetResponsePostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponsePostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsGetResponsePostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsGetResponsePostApplyResourcesValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsGetResponsePostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsGetResponsePostApplyResourcesValueProviderIdsList = Array<string>;
export type OnRampsGetResponsePostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsGetResponsePostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsGetResponsePostApplyResourcesValueSectionsList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItem>;
export type OnRampsGetResponsePostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsGetResponsePostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsGetResponsePostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsGetResponsePostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsGetResponsePostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export type OnRampsGetResponsePostApplyResourcesValueManagedByList = Array<OnRampsGetResponsePostApplyResourcesValueManagedByItem>;
export interface OnRampsGetResponsePostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueCloudType;
    config: OnRampsGetResponsePostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsGetResponsePostApplyResourcesValueObservationsMap;
    providerIds: OnRampsGetResponsePostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsGetResponsePostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueResourceType;
    sections: OnRampsGetResponsePostApplyResourcesValueSectionsList;
    state: OnRampsGetResponsePostApplyResourcesValueStateMap;
    tags: OnRampsGetResponsePostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsGetResponsePostApplyResourcesValueManagedByList | null | undefined;
}
export type OnRampsGetResponsePostApplyResourcesMap = {
    [key: string]: OnRampsGetResponsePostApplyResourcesValue | undefined;
};
export type OnRampsGetResponseStatusApplyProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsGetResponseStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export type OnRampsGetResponseStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsGetResponseStatusRoutesList = Array<string>;
export type OnRampsGetResponseStatusTunnelsList = Array<string>;
export type OnRampsGetResponseStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type OnRampsGetResponseStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type OnRampsGetResponseStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface OnRampsGetResponseStatusLifecycleErrorsValue {
    code: OnRampsGetResponseStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type OnRampsGetResponseStatusLifecycleErrorsMap = {
    [key: string]: OnRampsGetResponseStatusLifecycleErrorsValue | undefined;
};
export interface OnRampsGetResponseStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsGetResponseStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsGetResponseStatusRoutesList;
    tunnels: OnRampsGetResponseStatusTunnelsList;
    lifecycleErrors?: OnRampsGetResponseStatusLifecycleErrorsMap | null | undefined;
}
export type OnRampsGetResponseVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponseVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsGetResponseVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsGetResponseVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsGetResponseVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsGetResponseVpcsByIdValueProviderIdsList = Array<string>;
export type OnRampsGetResponseVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsGetResponseVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsGetResponseVpcsByIdValueSectionsList = Array<OnRampsGetResponseVpcsByIdValueSectionsItem>;
export type OnRampsGetResponseVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsGetResponseVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsGetResponseVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsGetResponseVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsGetResponseVpcsByIdValueManagedByItemClientType;
    name: string;
}
export type OnRampsGetResponseVpcsByIdValueManagedByList = Array<OnRampsGetResponseVpcsByIdValueManagedByItem>;
export interface OnRampsGetResponseVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsGetResponseVpcsByIdValueCloudType;
    config: OnRampsGetResponseVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsGetResponseVpcsByIdValueObservationsMap;
    providerIds: OnRampsGetResponseVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsGetResponseVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsGetResponseVpcsByIdValueResourceType;
    sections: OnRampsGetResponseVpcsByIdValueSectionsList;
    state: OnRampsGetResponseVpcsByIdValueStateMap;
    tags: OnRampsGetResponseVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsGetResponseVpcsByIdValueManagedByList | null | undefined;
}
export type OnRampsGetResponseVpcsByIdMap = {
    [key: string]: OnRampsGetResponseVpcsByIdValue | undefined;
};
export type OnRampsGetResponseVpcsByIdUnavailableList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOnRampResponse {
    id: string;
    cloudType: OnRampsGetResponseCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsGetResponseType;
    updatedAt: string;
    attachedHubs?: OnRampsGetResponseAttachedHubsList | null | undefined;
    attachedVpcs?: OnRampsGetResponseAttachedVpcsList | null | undefined;
    cloudAsn?: number | null | undefined;
    description?: string | null | undefined;
    hub?: string | null | undefined;
    lastAppliedAt?: string | null | undefined;
    lastExportedAt?: string | null | undefined;
    lastPlannedAt?: string | null | undefined;
    manageHubToHubAttachments?: boolean | null | undefined;
    manageVpcToHubAttachments?: boolean | null | undefined;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null | undefined;
    plannedResources?: OnRampsGetResponsePlannedResourcesList | null | undefined;
    plannedResourcesUnavailable?: boolean | null | undefined;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null | undefined;
    postApplyResources?: OnRampsGetResponsePostApplyResourcesMap | null | undefined;
    postApplyResourcesUnavailable?: boolean | null | undefined;
    region?: string | null | undefined;
    status?: OnRampsGetResponseStatus | null | undefined;
    vpc?: string | null | undefined;
    vpcsById?: OnRampsGetResponseVpcsByIdMap | null | undefined;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsGetResponseVpcsByIdUnavailableList | null | undefined;
}
export interface GetResourceRequest {
    accountId: string;
    resourceId: string;
    v2?: boolean | undefined;
}
export type ResourcesGetResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesGetResponseConfigMap = {
    [key: string]: unknown | undefined;
};
export type ResourcesGetResponseMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type ResourcesGetResponseObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type ResourcesGetResponseObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type ResourcesGetResponseProviderIdsList = Array<string>;
export type ResourcesGetResponseProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type ResourcesGetResponseResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListList = Array<ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type ResourcesGetResponseSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItem;
export interface ResourcesGetResponseSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: ResourcesGetResponseSectionsItemHiddenItemsItemValue | null | undefined;
}
export type ResourcesGetResponseSectionsItemHiddenItemsList = Array<ResourcesGetResponseSectionsItemHiddenItemsItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListList = Array<ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type ResourcesGetResponseSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItem;
export interface ResourcesGetResponseSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: ResourcesGetResponseSectionsItemVisibleItemsItemValue | null | undefined;
}
export type ResourcesGetResponseSectionsItemVisibleItemsList = Array<ResourcesGetResponseSectionsItemVisibleItemsItem>;
export interface ResourcesGetResponseSectionsItem {
    hiddenItems: ResourcesGetResponseSectionsItemHiddenItemsList;
    name: string;
    visibleItems: ResourcesGetResponseSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type ResourcesGetResponseSectionsList = Array<ResourcesGetResponseSectionsItem>;
export type ResourcesGetResponseStateMap = {
    [key: string]: unknown | undefined;
};
export type ResourcesGetResponseTagsMap = {
    [key: string]: string | undefined;
};
export type ResourcesGetResponseManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface ResourcesGetResponseManagedByItem {
    id: string;
    clientType: ResourcesGetResponseManagedByItemClientType;
    name: string;
}
export type ResourcesGetResponseManagedByList = Array<ResourcesGetResponseManagedByItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResourceResponse {
    id: string;
    accountId: string;
    cloudType: ResourcesGetResponseCloudType;
    config: ResourcesGetResponseConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: ResourcesGetResponseObservationsMap;
    providerIds: ResourcesGetResponseProviderIdsList;
    providerNamesById: ResourcesGetResponseProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: ResourcesGetResponseResourceType;
    sections: ResourcesGetResponseSectionsList;
    state: ResourcesGetResponseStateMap;
    tags: ResourcesGetResponseTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: ResourcesGetResponseManagedByList | null | undefined;
}
export interface InitialSetupCloudIntegrationRequest {
    accountId: string;
    providerId: string;
}
export interface CloudIntegrationsInitialSetupResultMcnAwsTrustPolicy {
    awsTrustPolicy: string;
    itemType: string;
}
export interface CloudIntegrationsInitialSetupResultMcnAzureSetup {
    azureConsentUrl: string;
    integrationIdentityTag: string;
    itemType: string;
    tagCliCommand: string;
}
export interface CloudIntegrationsInitialSetupResultMcnGcpSetup {
    integrationIdentityTag: string;
    itemType: string;
    tagCliCommand: string;
}
export type CloudIntegrationsInitialSetupResult = CloudIntegrationsInitialSetupResultMcnAwsTrustPolicy | CloudIntegrationsInitialSetupResultMcnAzureSetup | CloudIntegrationsInitialSetupResultMcnGcpSetup;
export type InitialSetupCloudIntegrationResponse = CloudIntegrationsInitialSetupResult;
export type CatalogSyncsPrebuiltPoliciesListRequestDestinationType = "NONE" | "ZERO_TRUST_LIST";
export interface ListCatalogSyncPrebuiltPoliciesRequest {
    accountId: string;
    /** Specify type of destination, omit to return all. */
    destinationType?: CatalogSyncsPrebuiltPoliciesListRequestDestinationType | (string & {}) | undefined;
}
export type CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsItem = "NONE" | "ZERO_TRUST_LIST";
export type CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsList = Array<CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsItem>;
export interface CatalogSyncsPrebuiltPoliciesListResultItem {
    applicableDestinations: CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsList;
    policyDescription: string;
    policyName: string;
    policyString: string;
}
export type CatalogSyncsPrebuiltPoliciesListResultList = Array<CatalogSyncsPrebuiltPoliciesListResultItem>;
export interface ListCatalogSyncPrebuiltPoliciesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CatalogSyncsPrebuiltPoliciesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListCatalogSyncsRequest {
    accountId: string;
}
export type CatalogSyncsListResultItemDestinationType = "NONE" | "ZERO_TRUST_LIST";
export type CatalogSyncsListResultItemUpdateMode = "AUTO" | "MANUAL";
export type CatalogSyncsListResultItemErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type CatalogSyncsListResultItemErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type CatalogSyncsListResultItemErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface CatalogSyncsListResultItemErrorsValue {
    code: CatalogSyncsListResultItemErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type CatalogSyncsListResultItemErrorsMap = {
    [key: string]: CatalogSyncsListResultItemErrorsValue | undefined;
};
export interface CatalogSyncsListResultItem {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsListResultItemDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsListResultItemUpdateMode;
    errors?: CatalogSyncsListResultItemErrorsMap | null | undefined;
    includesDiscoveriesUntil?: string | null | undefined;
    lastAttemptedUpdateAt?: string | null | undefined;
    lastSuccessfulUpdateAt?: string | null | undefined;
}
export type CatalogSyncsListResultList = Array<CatalogSyncsListResultItem>;
export interface ListCatalogSyncsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CatalogSyncsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListCloudIntegrationsRequest {
    accountId: string;
    cloudflare?: boolean | undefined;
    desc?: boolean | undefined;
    /** One of ["updated_at", "id", "cloud_type", "name"]. */
    orderBy?: string | undefined;
    status?: boolean | undefined;
}
export type CloudIntegrationsListResultItemCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type CloudIntegrationsListResultItemLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export type CloudIntegrationsListResultItemState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsListResultItemStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsListResultItemStatusDiscoveryProgress = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsListResultItemStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsListResultItemStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsListResultItemStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsListResultItemStatusRegionsList = Array<string>;
export type CloudIntegrationsListResultItemStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface CloudIntegrationsListResultItemStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsListResultItemStatusInUseByItemClientType;
    name: string;
}
export type CloudIntegrationsListResultItemStatusInUseByList = Array<CloudIntegrationsListResultItemStatusInUseByItem>;
export interface CloudIntegrationsListResultItemStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsListResultItemStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsListResultItemStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsListResultItemStatusRegionsList;
    credentialsGoodSince?: string | null | undefined;
    credentialsMissingSince?: string | null | undefined;
    credentialsRejectedSince?: string | null | undefined;
    discoveryMessage?: string | null | undefined;
    discoveryMessageV2?: string | null | undefined;
    inUseBy?: CloudIntegrationsListResultItemStatusInUseByList | null | undefined;
    lastDiscoveryCompletedAt?: string | null | undefined;
    lastDiscoveryCompletedAtV2?: string | null | undefined;
    lastDiscoveryStartedAt?: string | null | undefined;
    lastDiscoveryStartedAtV2?: string | null | undefined;
    lastUpdated?: string | null | undefined;
}
export interface CloudIntegrationsListResultItem {
    id: string;
    cloudType: CloudIntegrationsListResultItemCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsListResultItemLifecycleState;
    state: CloudIntegrationsListResultItemState;
    stateV2: CloudIntegrationsListResultItemStateV2;
    awsArn?: string | null | undefined;
    azureSubscriptionId?: string | null | undefined;
    azureTenantId?: string | null | undefined;
    description?: string | null | undefined;
    gcpProjectId?: string | null | undefined;
    gcpServiceAccountEmail?: string | null | undefined;
    status?: CloudIntegrationsListResultItemStatus | null | undefined;
}
export type CloudIntegrationsListResultList = Array<CloudIntegrationsListResultItem>;
export interface ListCloudIntegrationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CloudIntegrationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListOnRampAddressSpacesRequest {
    accountId: string;
}
export type OnRampsAddressSpacesListResponsePrefixesList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListOnRampAddressSpacesResponse {
    prefixes: OnRampsAddressSpacesListResponsePrefixesList;
}
export interface ListOnRampsRequest {
    accountId: string;
    desc?: boolean | undefined;
    /** One of ["updated_at", "id", "cloud_type", "name"]. */
    orderBy?: string | undefined;
    status?: boolean | undefined;
    vpcs?: boolean | undefined;
}
export type OnRampsListResultItemCloudType = "AWS" | "AZURE" | "GOOGLE";
export type OnRampsListResultItemType = "OnrampTypeSingle" | "OnrampTypeHub";
export type OnRampsListResultItemAttachedHubsList = Array<string>;
export type OnRampsListResultItemAttachedVpcsList = Array<string>;
export type OnRampsListResultItemPlannedMonthlyCostEstimate = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsListResultItemPlannedResourcesItemDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsListResultItemPlannedResourcesItemKeysRequireReplaceList = Array<string>;
export type OnRampsListResultItemPlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsListResultItemPlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export type OnRampsListResultItemPlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemPlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemPlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsListResultItemPlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPlannedResourcesItemResourceResourceType;
    title: string;
}
export interface OnRampsListResultItemPlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsListResultItemPlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsListResultItemPlannedResourcesItemPlannedAction;
    resource: OnRampsListResultItemPlannedResourcesItemResource;
}
export type OnRampsListResultItemPlannedResourcesList = Array<OnRampsListResultItemPlannedResourcesItem>;
export type OnRampsListResultItemPostApplyMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsListResultItemPostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemPostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsListResultItemPostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsListResultItemPostApplyResourcesValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsListResultItemPostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsListResultItemPostApplyResourcesValueProviderIdsList = Array<string>;
export type OnRampsListResultItemPostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsListResultItemPostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItem>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsListResultItemPostApplyResourcesValueSectionsList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItem>;
export type OnRampsListResultItemPostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsListResultItemPostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsListResultItemPostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsListResultItemPostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsListResultItemPostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export type OnRampsListResultItemPostApplyResourcesValueManagedByList = Array<OnRampsListResultItemPostApplyResourcesValueManagedByItem>;
export interface OnRampsListResultItemPostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueCloudType;
    config: OnRampsListResultItemPostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsListResultItemPostApplyResourcesValueObservationsMap;
    providerIds: OnRampsListResultItemPostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsListResultItemPostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueResourceType;
    sections: OnRampsListResultItemPostApplyResourcesValueSectionsList;
    state: OnRampsListResultItemPostApplyResourcesValueStateMap;
    tags: OnRampsListResultItemPostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsListResultItemPostApplyResourcesValueManagedByList | null | undefined;
}
export type OnRampsListResultItemPostApplyResourcesMap = {
    [key: string]: OnRampsListResultItemPostApplyResourcesValue | undefined;
};
export type OnRampsListResultItemStatusApplyProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsListResultItemStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export type OnRampsListResultItemStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsListResultItemStatusRoutesList = Array<string>;
export type OnRampsListResultItemStatusTunnelsList = Array<string>;
export type OnRampsListResultItemStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type OnRampsListResultItemStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type OnRampsListResultItemStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface OnRampsListResultItemStatusLifecycleErrorsValue {
    code: OnRampsListResultItemStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type OnRampsListResultItemStatusLifecycleErrorsMap = {
    [key: string]: OnRampsListResultItemStatusLifecycleErrorsValue | undefined;
};
export interface OnRampsListResultItemStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsListResultItemStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsListResultItemStatusRoutesList;
    tunnels: OnRampsListResultItemStatusTunnelsList;
    lifecycleErrors?: OnRampsListResultItemStatusLifecycleErrorsMap | null | undefined;
}
export type OnRampsListResultItemVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsListResultItemVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsListResultItemVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsListResultItemVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsListResultItemVpcsByIdValueProviderIdsList = Array<string>;
export type OnRampsListResultItemVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsListResultItemVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItem>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsListResultItemVpcsByIdValueSectionsList = Array<OnRampsListResultItemVpcsByIdValueSectionsItem>;
export type OnRampsListResultItemVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsListResultItemVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsListResultItemVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsListResultItemVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsListResultItemVpcsByIdValueManagedByItemClientType;
    name: string;
}
export type OnRampsListResultItemVpcsByIdValueManagedByList = Array<OnRampsListResultItemVpcsByIdValueManagedByItem>;
export interface OnRampsListResultItemVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsListResultItemVpcsByIdValueCloudType;
    config: OnRampsListResultItemVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsListResultItemVpcsByIdValueObservationsMap;
    providerIds: OnRampsListResultItemVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsListResultItemVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsListResultItemVpcsByIdValueResourceType;
    sections: OnRampsListResultItemVpcsByIdValueSectionsList;
    state: OnRampsListResultItemVpcsByIdValueStateMap;
    tags: OnRampsListResultItemVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsListResultItemVpcsByIdValueManagedByList | null | undefined;
}
export type OnRampsListResultItemVpcsByIdMap = {
    [key: string]: OnRampsListResultItemVpcsByIdValue | undefined;
};
export type OnRampsListResultItemVpcsByIdUnavailableList = Array<string>;
export interface OnRampsListResultItem {
    id: string;
    cloudType: OnRampsListResultItemCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsListResultItemType;
    updatedAt: string;
    attachedHubs?: OnRampsListResultItemAttachedHubsList | null | undefined;
    attachedVpcs?: OnRampsListResultItemAttachedVpcsList | null | undefined;
    cloudAsn?: number | null | undefined;
    description?: string | null | undefined;
    hub?: string | null | undefined;
    lastAppliedAt?: string | null | undefined;
    lastExportedAt?: string | null | undefined;
    lastPlannedAt?: string | null | undefined;
    manageHubToHubAttachments?: boolean | null | undefined;
    manageVpcToHubAttachments?: boolean | null | undefined;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null | undefined;
    plannedResources?: OnRampsListResultItemPlannedResourcesList | null | undefined;
    plannedResourcesUnavailable?: boolean | null | undefined;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null | undefined;
    postApplyResources?: OnRampsListResultItemPostApplyResourcesMap | null | undefined;
    postApplyResourcesUnavailable?: boolean | null | undefined;
    region?: string | null | undefined;
    status?: OnRampsListResultItemStatus | null | undefined;
    vpc?: string | null | undefined;
    vpcsById?: OnRampsListResultItemVpcsByIdMap | null | undefined;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsListResultItemVpcsByIdUnavailableList | null | undefined;
}
export type OnRampsListResultList = Array<OnRampsListResultItem>;
export interface ListOnRampsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OnRampsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type ResourcesListRequestResourceIdList = Array<string>;
export type ResourcesListRequestResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type ResourcesListRequestResourceTypeList = Array<ResourcesListRequestResourceType | (string & {})>;
export type ResourcesListRequestSearchList = Array<string>;
export interface ListResourcesRequest {
    accountId: string;
    cloudflare?: boolean | undefined;
    desc?: boolean | undefined;
    managed?: boolean | undefined;
    /** One of ["id", "resource_type", "region"]. */
    orderBy?: string | undefined;
    page?: number | undefined;
    perPage?: number | undefined;
    providerId?: string | undefined;
    region?: string | undefined;
    resourceGroup?: string | undefined;
    resourceId?: ResourcesListRequestResourceIdList | undefined;
    resourceType?: ResourcesListRequestResourceTypeList | undefined;
    search?: ResourcesListRequestSearchList | undefined;
    v2?: boolean | undefined;
}
export type ResourcesListResultItemCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesListResultItemConfigMap = {
    [key: string]: unknown | undefined;
};
export type ResourcesListResultItemMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type ResourcesListResultItemObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type ResourcesListResultItemObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type ResourcesListResultItemProviderIdsList = Array<string>;
export type ResourcesListResultItemProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type ResourcesListResultItemResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListList = Array<ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type ResourcesListResultItemSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItem;
export interface ResourcesListResultItemSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: ResourcesListResultItemSectionsItemHiddenItemsItemValue | null | undefined;
}
export type ResourcesListResultItemSectionsItemHiddenItemsList = Array<ResourcesListResultItemSectionsItemHiddenItemsItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListList = Array<ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type ResourcesListResultItemSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItem;
export interface ResourcesListResultItemSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: ResourcesListResultItemSectionsItemVisibleItemsItemValue | null | undefined;
}
export type ResourcesListResultItemSectionsItemVisibleItemsList = Array<ResourcesListResultItemSectionsItemVisibleItemsItem>;
export interface ResourcesListResultItemSectionsItem {
    hiddenItems: ResourcesListResultItemSectionsItemHiddenItemsList;
    name: string;
    visibleItems: ResourcesListResultItemSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type ResourcesListResultItemSectionsList = Array<ResourcesListResultItemSectionsItem>;
export type ResourcesListResultItemStateMap = {
    [key: string]: unknown | undefined;
};
export type ResourcesListResultItemTagsMap = {
    [key: string]: string | undefined;
};
export type ResourcesListResultItemManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface ResourcesListResultItemManagedByItem {
    id: string;
    clientType: ResourcesListResultItemManagedByItemClientType;
    name: string;
}
export type ResourcesListResultItemManagedByList = Array<ResourcesListResultItemManagedByItem>;
export interface ResourcesListResultItem {
    id: string;
    accountId: string;
    cloudType: ResourcesListResultItemCloudType;
    config: ResourcesListResultItemConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: ResourcesListResultItemObservationsMap;
    providerIds: ResourcesListResultItemProviderIdsList;
    providerNamesById: ResourcesListResultItemProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: ResourcesListResultItemResourceType;
    sections: ResourcesListResultItemSectionsList;
    state: ResourcesListResultItemStateMap;
    tags: ResourcesListResultItemTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: ResourcesListResultItemManagedByList | null | undefined;
}
export type ResourcesListResultList = Array<ResourcesListResultItem>;
export interface ListResourcesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ResourcesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type CatalogSyncsEditRequestUpdateMode = "AUTO" | "MANUAL";
export interface PatchCatalogSyncRequest {
    accountId: string;
    syncId: string;
    description?: string | undefined;
    name?: string | undefined;
    policy?: string | undefined;
    updateMode?: CatalogSyncsEditRequestUpdateMode | (string & {}) | undefined;
}
export type CatalogSyncsEditResponseDestinationType = "NONE" | "ZERO_TRUST_LIST";
export type CatalogSyncsEditResponseUpdateMode = "AUTO" | "MANUAL";
export type CatalogSyncsEditResponseErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type CatalogSyncsEditResponseErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type CatalogSyncsEditResponseErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface CatalogSyncsEditResponseErrorsValue {
    code: CatalogSyncsEditResponseErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type CatalogSyncsEditResponseErrorsMap = {
    [key: string]: CatalogSyncsEditResponseErrorsValue | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCatalogSyncResponse {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsEditResponseDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsEditResponseUpdateMode;
    errors?: CatalogSyncsEditResponseErrorsMap | null | undefined;
    includesDiscoveriesUntil?: string | null | undefined;
    lastAttemptedUpdateAt?: string | null | undefined;
    lastSuccessfulUpdateAt?: string | null | undefined;
}
export interface PatchCloudIntegrationRequest {
    accountId: string;
    providerId: string;
    awsArn?: string | undefined;
    azureSubscriptionId?: string | undefined;
    azureTenantId?: string | undefined;
    description?: string | undefined;
    friendlyName?: string | undefined;
    gcpProjectId?: string | undefined;
    gcpServiceAccountEmail?: string | undefined;
}
export type CloudIntegrationsEditResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type CloudIntegrationsEditResponseLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export type CloudIntegrationsEditResponseState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsEditResponseStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsEditResponseStatusDiscoveryProgress = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsEditResponseStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsEditResponseStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsEditResponseStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsEditResponseStatusRegionsList = Array<string>;
export type CloudIntegrationsEditResponseStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface CloudIntegrationsEditResponseStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsEditResponseStatusInUseByItemClientType;
    name: string;
}
export type CloudIntegrationsEditResponseStatusInUseByList = Array<CloudIntegrationsEditResponseStatusInUseByItem>;
export interface CloudIntegrationsEditResponseStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsEditResponseStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsEditResponseStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsEditResponseStatusRegionsList;
    credentialsGoodSince?: string | null | undefined;
    credentialsMissingSince?: string | null | undefined;
    credentialsRejectedSince?: string | null | undefined;
    discoveryMessage?: string | null | undefined;
    discoveryMessageV2?: string | null | undefined;
    inUseBy?: CloudIntegrationsEditResponseStatusInUseByList | null | undefined;
    lastDiscoveryCompletedAt?: string | null | undefined;
    lastDiscoveryCompletedAtV2?: string | null | undefined;
    lastDiscoveryStartedAt?: string | null | undefined;
    lastDiscoveryStartedAtV2?: string | null | undefined;
    lastUpdated?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCloudIntegrationResponse {
    id: string;
    cloudType: CloudIntegrationsEditResponseCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsEditResponseLifecycleState;
    state: CloudIntegrationsEditResponseState;
    stateV2: CloudIntegrationsEditResponseStateV2;
    awsArn?: string | null | undefined;
    azureSubscriptionId?: string | null | undefined;
    azureTenantId?: string | null | undefined;
    description?: string | null | undefined;
    gcpProjectId?: string | null | undefined;
    gcpServiceAccountEmail?: string | null | undefined;
    status?: CloudIntegrationsEditResponseStatus | null | undefined;
}
export type OnRampsEditRequestAttachedHubsList = Array<string>;
export type OnRampsEditRequestAttachedVpcsList = Array<string>;
export interface PatchOnRampRequest {
    accountId: string;
    onrampId: string;
    attachedHubs?: OnRampsEditRequestAttachedHubsList | undefined;
    attachedVpcs?: OnRampsEditRequestAttachedVpcsList | undefined;
    description?: string | undefined;
    installRoutesInCloud?: boolean | undefined;
    installRoutesInMagicWan?: boolean | undefined;
    manageHubToHubAttachments?: boolean | undefined;
    manageVpcToHubAttachments?: boolean | undefined;
    name?: string | undefined;
    vpc?: string | undefined;
}
export type OnRampsEditResponseCloudType = "AWS" | "AZURE" | "GOOGLE";
export type OnRampsEditResponseType = "OnrampTypeSingle" | "OnrampTypeHub";
export type OnRampsEditResponseAttachedHubsList = Array<string>;
export type OnRampsEditResponseAttachedVpcsList = Array<string>;
export type OnRampsEditResponsePlannedMonthlyCostEstimate = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsEditResponsePlannedResourcesItemDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsEditResponsePlannedResourcesItemKeysRequireReplaceList = Array<string>;
export type OnRampsEditResponsePlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsEditResponsePlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export type OnRampsEditResponsePlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponsePlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponsePlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsEditResponsePlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePlannedResourcesItemResourceResourceType;
    title: string;
}
export interface OnRampsEditResponsePlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsEditResponsePlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsEditResponsePlannedResourcesItemPlannedAction;
    resource: OnRampsEditResponsePlannedResourcesItemResource;
}
export type OnRampsEditResponsePlannedResourcesList = Array<OnRampsEditResponsePlannedResourcesItem>;
export type OnRampsEditResponsePostApplyMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsEditResponsePostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponsePostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsEditResponsePostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsEditResponsePostApplyResourcesValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsEditResponsePostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsEditResponsePostApplyResourcesValueProviderIdsList = Array<string>;
export type OnRampsEditResponsePostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsEditResponsePostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsEditResponsePostApplyResourcesValueSectionsList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItem>;
export type OnRampsEditResponsePostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsEditResponsePostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsEditResponsePostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsEditResponsePostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsEditResponsePostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export type OnRampsEditResponsePostApplyResourcesValueManagedByList = Array<OnRampsEditResponsePostApplyResourcesValueManagedByItem>;
export interface OnRampsEditResponsePostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueCloudType;
    config: OnRampsEditResponsePostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsEditResponsePostApplyResourcesValueObservationsMap;
    providerIds: OnRampsEditResponsePostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsEditResponsePostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueResourceType;
    sections: OnRampsEditResponsePostApplyResourcesValueSectionsList;
    state: OnRampsEditResponsePostApplyResourcesValueStateMap;
    tags: OnRampsEditResponsePostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsEditResponsePostApplyResourcesValueManagedByList | null | undefined;
}
export type OnRampsEditResponsePostApplyResourcesMap = {
    [key: string]: OnRampsEditResponsePostApplyResourcesValue | undefined;
};
export type OnRampsEditResponseStatusApplyProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsEditResponseStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export type OnRampsEditResponseStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsEditResponseStatusRoutesList = Array<string>;
export type OnRampsEditResponseStatusTunnelsList = Array<string>;
export type OnRampsEditResponseStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type OnRampsEditResponseStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type OnRampsEditResponseStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface OnRampsEditResponseStatusLifecycleErrorsValue {
    code: OnRampsEditResponseStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type OnRampsEditResponseStatusLifecycleErrorsMap = {
    [key: string]: OnRampsEditResponseStatusLifecycleErrorsValue | undefined;
};
export interface OnRampsEditResponseStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsEditResponseStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsEditResponseStatusRoutesList;
    tunnels: OnRampsEditResponseStatusTunnelsList;
    lifecycleErrors?: OnRampsEditResponseStatusLifecycleErrorsMap | null | undefined;
}
export type OnRampsEditResponseVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponseVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsEditResponseVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsEditResponseVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsEditResponseVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsEditResponseVpcsByIdValueProviderIdsList = Array<string>;
export type OnRampsEditResponseVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsEditResponseVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsEditResponseVpcsByIdValueSectionsList = Array<OnRampsEditResponseVpcsByIdValueSectionsItem>;
export type OnRampsEditResponseVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsEditResponseVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsEditResponseVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsEditResponseVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsEditResponseVpcsByIdValueManagedByItemClientType;
    name: string;
}
export type OnRampsEditResponseVpcsByIdValueManagedByList = Array<OnRampsEditResponseVpcsByIdValueManagedByItem>;
export interface OnRampsEditResponseVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsEditResponseVpcsByIdValueCloudType;
    config: OnRampsEditResponseVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsEditResponseVpcsByIdValueObservationsMap;
    providerIds: OnRampsEditResponseVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsEditResponseVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsEditResponseVpcsByIdValueResourceType;
    sections: OnRampsEditResponseVpcsByIdValueSectionsList;
    state: OnRampsEditResponseVpcsByIdValueStateMap;
    tags: OnRampsEditResponseVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsEditResponseVpcsByIdValueManagedByList | null | undefined;
}
export type OnRampsEditResponseVpcsByIdMap = {
    [key: string]: OnRampsEditResponseVpcsByIdValue | undefined;
};
export type OnRampsEditResponseVpcsByIdUnavailableList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOnRampResponse {
    id: string;
    cloudType: OnRampsEditResponseCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsEditResponseType;
    updatedAt: string;
    attachedHubs?: OnRampsEditResponseAttachedHubsList | null | undefined;
    attachedVpcs?: OnRampsEditResponseAttachedVpcsList | null | undefined;
    cloudAsn?: number | null | undefined;
    description?: string | null | undefined;
    hub?: string | null | undefined;
    lastAppliedAt?: string | null | undefined;
    lastExportedAt?: string | null | undefined;
    lastPlannedAt?: string | null | undefined;
    manageHubToHubAttachments?: boolean | null | undefined;
    manageVpcToHubAttachments?: boolean | null | undefined;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null | undefined;
    plannedResources?: OnRampsEditResponsePlannedResourcesList | null | undefined;
    plannedResourcesUnavailable?: boolean | null | undefined;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null | undefined;
    postApplyResources?: OnRampsEditResponsePostApplyResourcesMap | null | undefined;
    postApplyResourcesUnavailable?: boolean | null | undefined;
    region?: string | null | undefined;
    status?: OnRampsEditResponseStatus | null | undefined;
    vpc?: string | null | undefined;
    vpcsById?: OnRampsEditResponseVpcsByIdMap | null | undefined;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsEditResponseVpcsByIdUnavailableList | null | undefined;
}
export type OnRampsAddressSpacesEditRequestPrefixesList = Array<string>;
export interface PatchOnRampAddressSpaceRequest {
    accountId: string;
    prefixes: OnRampsAddressSpacesEditRequestPrefixesList;
}
export type OnRampsAddressSpacesEditResponsePrefixesList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOnRampAddressSpaceResponse {
    prefixes: OnRampsAddressSpacesEditResponsePrefixesList;
}
export interface PlanOnRampRequest {
    accountId: string;
    onrampId: string;
}
export interface PlanOnRampResponse {
}
export interface PolicyPreviewResourceRequest {
    accountId: string;
    policy: string;
}
export type PolicyPreviewResourceResponse = string;
export type OnRampsAddressSpacesUpdateRequestPrefixesList = Array<string>;
export interface PutOnRampAddressSpaceRequest {
    accountId: string;
    prefixes: OnRampsAddressSpacesUpdateRequestPrefixesList;
}
export type OnRampsAddressSpacesUpdateResponsePrefixesList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutOnRampAddressSpaceResponse {
    prefixes: OnRampsAddressSpacesUpdateResponsePrefixesList;
}
export interface RefreshCatalogSyncRequest {
    accountId: string;
    syncId: string;
}
export type RefreshCatalogSyncResponse = string;
export type CatalogSyncsUpdateRequestUpdateMode = "AUTO" | "MANUAL";
export interface UpdateCatalogSyncRequest {
    accountId: string;
    syncId: string;
    description?: string | undefined;
    name?: string | undefined;
    policy?: string | undefined;
    updateMode?: CatalogSyncsUpdateRequestUpdateMode | (string & {}) | undefined;
}
export type CatalogSyncsUpdateResponseDestinationType = "NONE" | "ZERO_TRUST_LIST";
export type CatalogSyncsUpdateResponseUpdateMode = "AUTO" | "MANUAL";
export type CatalogSyncsUpdateResponseErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type CatalogSyncsUpdateResponseErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type CatalogSyncsUpdateResponseErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface CatalogSyncsUpdateResponseErrorsValue {
    code: CatalogSyncsUpdateResponseErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type CatalogSyncsUpdateResponseErrorsMap = {
    [key: string]: CatalogSyncsUpdateResponseErrorsValue | undefined;
};
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateCatalogSyncResponse {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsUpdateResponseDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsUpdateResponseUpdateMode;
    errors?: CatalogSyncsUpdateResponseErrorsMap | null | undefined;
    includesDiscoveriesUntil?: string | null | undefined;
    lastAttemptedUpdateAt?: string | null | undefined;
    lastSuccessfulUpdateAt?: string | null | undefined;
}
export interface UpdateCloudIntegrationRequest {
    accountId: string;
    providerId: string;
    awsArn?: string | undefined;
    azureSubscriptionId?: string | undefined;
    azureTenantId?: string | undefined;
    description?: string | undefined;
    friendlyName?: string | undefined;
    gcpProjectId?: string | undefined;
    gcpServiceAccountEmail?: string | undefined;
}
export type CloudIntegrationsUpdateResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type CloudIntegrationsUpdateResponseLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export type CloudIntegrationsUpdateResponseState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsUpdateResponseStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsUpdateResponseStatusDiscoveryProgress = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsUpdateResponseStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export type CloudIntegrationsUpdateResponseStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsUpdateResponseStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export type CloudIntegrationsUpdateResponseStatusRegionsList = Array<string>;
export type CloudIntegrationsUpdateResponseStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface CloudIntegrationsUpdateResponseStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsUpdateResponseStatusInUseByItemClientType;
    name: string;
}
export type CloudIntegrationsUpdateResponseStatusInUseByList = Array<CloudIntegrationsUpdateResponseStatusInUseByItem>;
export interface CloudIntegrationsUpdateResponseStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsUpdateResponseStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsUpdateResponseStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsUpdateResponseStatusRegionsList;
    credentialsGoodSince?: string | null | undefined;
    credentialsMissingSince?: string | null | undefined;
    credentialsRejectedSince?: string | null | undefined;
    discoveryMessage?: string | null | undefined;
    discoveryMessageV2?: string | null | undefined;
    inUseBy?: CloudIntegrationsUpdateResponseStatusInUseByList | null | undefined;
    lastDiscoveryCompletedAt?: string | null | undefined;
    lastDiscoveryCompletedAtV2?: string | null | undefined;
    lastDiscoveryStartedAt?: string | null | undefined;
    lastDiscoveryStartedAtV2?: string | null | undefined;
    lastUpdated?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateCloudIntegrationResponse {
    id: string;
    cloudType: CloudIntegrationsUpdateResponseCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsUpdateResponseLifecycleState;
    state: CloudIntegrationsUpdateResponseState;
    stateV2: CloudIntegrationsUpdateResponseStateV2;
    awsArn?: string | null | undefined;
    azureSubscriptionId?: string | null | undefined;
    azureTenantId?: string | null | undefined;
    description?: string | null | undefined;
    gcpProjectId?: string | null | undefined;
    gcpServiceAccountEmail?: string | null | undefined;
    status?: CloudIntegrationsUpdateResponseStatus | null | undefined;
}
export type OnRampsUpdateRequestAttachedHubsList = Array<string>;
export type OnRampsUpdateRequestAttachedVpcsList = Array<string>;
export interface UpdateOnRampRequest {
    accountId: string;
    onrampId: string;
    attachedHubs?: OnRampsUpdateRequestAttachedHubsList | undefined;
    attachedVpcs?: OnRampsUpdateRequestAttachedVpcsList | undefined;
    description?: string | undefined;
    installRoutesInCloud?: boolean | undefined;
    installRoutesInMagicWan?: boolean | undefined;
    manageHubToHubAttachments?: boolean | undefined;
    manageVpcToHubAttachments?: boolean | undefined;
    name?: string | undefined;
    vpc?: string | undefined;
}
export type OnRampsUpdateResponseCloudType = "AWS" | "AZURE" | "GOOGLE";
export type OnRampsUpdateResponseType = "OnrampTypeSingle" | "OnrampTypeHub";
export type OnRampsUpdateResponseAttachedHubsList = Array<string>;
export type OnRampsUpdateResponseAttachedVpcsList = Array<string>;
export type OnRampsUpdateResponsePlannedMonthlyCostEstimate = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsUpdateResponsePlannedResourcesItemDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsUpdateResponsePlannedResourcesItemKeysRequireReplaceList = Array<string>;
export type OnRampsUpdateResponsePlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export type OnRampsUpdateResponsePlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export type OnRampsUpdateResponsePlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponsePlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponsePlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsUpdateResponsePlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePlannedResourcesItemResourceResourceType;
    title: string;
}
export interface OnRampsUpdateResponsePlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsUpdateResponsePlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsUpdateResponsePlannedResourcesItemPlannedAction;
    resource: OnRampsUpdateResponsePlannedResourcesItemResource;
}
export type OnRampsUpdateResponsePlannedResourcesList = Array<OnRampsUpdateResponsePlannedResourcesItem>;
export type OnRampsUpdateResponsePostApplyMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsUpdateResponsePostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponsePostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsUpdateResponsePostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsUpdateResponsePostApplyResourcesValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsUpdateResponsePostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsUpdateResponsePostApplyResourcesValueProviderIdsList = Array<string>;
export type OnRampsUpdateResponsePostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsUpdateResponsePostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsUpdateResponsePostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsUpdateResponsePostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsUpdateResponsePostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsUpdateResponsePostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export type OnRampsUpdateResponsePostApplyResourcesValueManagedByList = Array<OnRampsUpdateResponsePostApplyResourcesValueManagedByItem>;
export interface OnRampsUpdateResponsePostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueCloudType;
    config: OnRampsUpdateResponsePostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsUpdateResponsePostApplyResourcesValueObservationsMap;
    providerIds: OnRampsUpdateResponsePostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsUpdateResponsePostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueResourceType;
    sections: OnRampsUpdateResponsePostApplyResourcesValueSectionsList;
    state: OnRampsUpdateResponsePostApplyResourcesValueStateMap;
    tags: OnRampsUpdateResponsePostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsUpdateResponsePostApplyResourcesValueManagedByList | null | undefined;
}
export type OnRampsUpdateResponsePostApplyResourcesMap = {
    [key: string]: OnRampsUpdateResponsePostApplyResourcesValue | undefined;
};
export type OnRampsUpdateResponseStatusApplyProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsUpdateResponseStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export type OnRampsUpdateResponseStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export type OnRampsUpdateResponseStatusRoutesList = Array<string>;
export type OnRampsUpdateResponseStatusTunnelsList = Array<string>;
export type OnRampsUpdateResponseStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export type OnRampsUpdateResponseStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export type OnRampsUpdateResponseStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export interface OnRampsUpdateResponseStatusLifecycleErrorsValue {
    code: OnRampsUpdateResponseStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null | undefined;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null | undefined;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null | undefined;
}
export type OnRampsUpdateResponseStatusLifecycleErrorsMap = {
    [key: string]: OnRampsUpdateResponseStatusLifecycleErrorsValue | undefined;
};
export interface OnRampsUpdateResponseStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsUpdateResponseStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsUpdateResponseStatusRoutesList;
    tunnels: OnRampsUpdateResponseStatusTunnelsList;
    lifecycleErrors?: OnRampsUpdateResponseStatusLifecycleErrorsMap | null | undefined;
}
export type OnRampsUpdateResponseVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponseVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsUpdateResponseVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export type OnRampsUpdateResponseVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export type OnRampsUpdateResponseVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export type OnRampsUpdateResponseVpcsByIdValueProviderIdsList = Array<string>;
export type OnRampsUpdateResponseVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export type OnRampsUpdateResponseVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue | null | undefined;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null | undefined;
    name?: string | null | undefined;
    value?: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue | null | undefined;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null | undefined;
}
export type OnRampsUpdateResponseVpcsByIdValueSectionsList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItem>;
export type OnRampsUpdateResponseVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export type OnRampsUpdateResponseVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export type OnRampsUpdateResponseVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export interface OnRampsUpdateResponseVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsUpdateResponseVpcsByIdValueManagedByItemClientType;
    name: string;
}
export type OnRampsUpdateResponseVpcsByIdValueManagedByList = Array<OnRampsUpdateResponseVpcsByIdValueManagedByItem>;
export interface OnRampsUpdateResponseVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueCloudType;
    config: OnRampsUpdateResponseVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsUpdateResponseVpcsByIdValueObservationsMap;
    providerIds: OnRampsUpdateResponseVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsUpdateResponseVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueResourceType;
    sections: OnRampsUpdateResponseVpcsByIdValueSectionsList;
    state: OnRampsUpdateResponseVpcsByIdValueStateMap;
    tags: OnRampsUpdateResponseVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsUpdateResponseVpcsByIdValueManagedByList | null | undefined;
}
export type OnRampsUpdateResponseVpcsByIdMap = {
    [key: string]: OnRampsUpdateResponseVpcsByIdValue | undefined;
};
export type OnRampsUpdateResponseVpcsByIdUnavailableList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateOnRampResponse {
    id: string;
    cloudType: OnRampsUpdateResponseCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsUpdateResponseType;
    updatedAt: string;
    attachedHubs?: OnRampsUpdateResponseAttachedHubsList | null | undefined;
    attachedVpcs?: OnRampsUpdateResponseAttachedVpcsList | null | undefined;
    cloudAsn?: number | null | undefined;
    description?: string | null | undefined;
    hub?: string | null | undefined;
    lastAppliedAt?: string | null | undefined;
    lastExportedAt?: string | null | undefined;
    lastPlannedAt?: string | null | undefined;
    manageHubToHubAttachments?: boolean | null | undefined;
    manageVpcToHubAttachments?: boolean | null | undefined;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null | undefined;
    plannedResources?: OnRampsUpdateResponsePlannedResourcesList | null | undefined;
    plannedResourcesUnavailable?: boolean | null | undefined;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null | undefined;
    postApplyResources?: OnRampsUpdateResponsePostApplyResourcesMap | null | undefined;
    postApplyResourcesUnavailable?: boolean | null | undefined;
    region?: string | null | undefined;
    status?: OnRampsUpdateResponseStatus | null | undefined;
    vpc?: string | null | undefined;
    vpcsById?: OnRampsUpdateResponseVpcsByIdMap | null | undefined;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsUpdateResponseVpcsByIdUnavailableList | null | undefined;
}
export type ApplyOnRampError = CloudflareOpError;
/** Apply an On-ramp (Closed Beta). */
export declare const applyOnRamp: API.OperationMethod<ApplyOnRampRequest, ApplyOnRampResponse, ApplyOnRampError, CloudflareOpContext>;
export type CreateCatalogSyncError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** Create a new Catalog Sync (Closed Beta). */
export declare const createCatalogSync: API.OperationMethod<CreateCatalogSyncRequest, CreateCatalogSyncResponse, CreateCatalogSyncError, CloudflareOpContext>;
export type CreateCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** Create a new Cloud Integration (Closed Beta). */
export declare const createCloudIntegration: API.OperationMethod<CreateCloudIntegrationRequest, CreateCloudIntegrationResponse, CreateCloudIntegrationError, CloudflareOpContext>;
export type CreateOnRampError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** Create a new On-ramp (Closed Beta). */
export declare const createOnRamp: API.OperationMethod<CreateOnRampRequest, CreateOnRampResponse, CreateOnRampError, CloudflareOpContext>;
export type DeleteCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Delete a Catalog Sync (Closed Beta). */
export declare const deleteCatalogSync: API.OperationMethod<DeleteCatalogSyncRequest, DeleteCatalogSyncResponse, DeleteCatalogSyncError, CloudflareOpContext>;
export type DeleteCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudIntegrationNotFound | CloudflareOpError;
/** Delete a Cloud Integration (Closed Beta). */
export declare const deleteCloudIntegration: API.OperationMethod<DeleteCloudIntegrationRequest, DeleteCloudIntegrationResponse, DeleteCloudIntegrationError, CloudflareOpContext>;
export type DeleteOnRampError = FeatureNotEnabled | Forbidden | OnRampNotFound | CloudflareOpError;
/** Delete an On-ramp (Closed Beta). */
export declare const deleteOnRamp: API.OperationMethod<DeleteOnRampRequest, DeleteOnRampResponse, DeleteOnRampError, CloudflareOpContext>;
export type DiscoverAllCloudIntegrationError = CloudflareOpError;
/** Run discovery for all Cloud Integrations in an account (Closed Beta). */
export declare const discoverAllCloudIntegration: API.OperationMethod<DiscoverAllCloudIntegrationRequest, DiscoverAllCloudIntegrationResponse, DiscoverAllCloudIntegrationError, CloudflareOpContext>;
export type DiscoverCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** Run discovery for a Cloud Integration (Closed Beta). */
export declare const discoverCloudIntegration: API.OperationMethod<DiscoverCloudIntegrationRequest, DiscoverCloudIntegrationResponse, DiscoverCloudIntegrationError, CloudflareOpContext>;
export type ExportOnRampError = CloudflareOpError;
/** Export an On-ramp to terraform ready file(s) (Closed Beta). */
export declare const exportOnRamp: API.OperationMethod<ExportOnRampRequest, ExportOnRampResponse, ExportOnRampError, CloudflareOpContext>;
export type ExportResourceError = CloudflareOpError;
/** Export resources in the Resource Catalog as a JSON file (Closed Beta). */
export declare const exportResource: API.OperationMethod<ExportResourceRequest, ExportResourceResponse, ExportResourceError, CloudflareOpContext>;
export type GetCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Read a Catalog Sync (Closed Beta). */
export declare const getCatalogSync: API.OperationMethod<GetCatalogSyncRequest, GetCatalogSyncResponse, GetCatalogSyncError, CloudflareOpContext>;
export type GetCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudIntegrationNotFound | CloudflareOpError;
/** Read a Cloud Integration (Closed Beta). */
export declare const getCloudIntegration: API.OperationMethod<GetCloudIntegrationRequest, GetCloudIntegrationResponse, GetCloudIntegrationError, CloudflareOpContext>;
export type GetOnRampError = FeatureNotEnabled | Forbidden | OnRampNotFound | CloudflareOpError;
/** Read an On-ramp (Closed Beta). */
export declare const getOnRamp: API.OperationMethod<GetOnRampRequest, GetOnRampResponse, GetOnRampError, CloudflareOpContext>;
export type GetResourceError = CloudflareOpError;
/** Read an resource from the Resource Catalog (Closed Beta). */
export declare const getResource: API.OperationMethod<GetResourceRequest, GetResourceResponse, GetResourceError, CloudflareOpContext>;
export type InitialSetupCloudIntegrationError = CloudflareOpError;
/** Get initial configuration to complete Cloud Integration setup (Closed Beta). */
export declare const initialSetupCloudIntegration: API.OperationMethod<InitialSetupCloudIntegrationRequest, InitialSetupCloudIntegrationResponse, InitialSetupCloudIntegrationError, CloudflareOpContext>;
export type ListCatalogSyncPrebuiltPoliciesError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** List prebuilt catalog sync policies (Closed Beta). */
export declare const listCatalogSyncPrebuiltPolicies: API.PaginatedOperationMethod<ListCatalogSyncPrebuiltPoliciesRequest, ListCatalogSyncPrebuiltPoliciesResponse, ListCatalogSyncPrebuiltPoliciesError, CloudflareOpContext, CatalogSyncsPrebuiltPoliciesListResultItem>;
export type ListCatalogSyncsError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** List Catalog Syncs (Closed Beta). */
export declare const listCatalogSyncs: API.PaginatedOperationMethod<ListCatalogSyncsRequest, ListCatalogSyncsResponse, ListCatalogSyncsError, CloudflareOpContext, CatalogSyncsListResultItem>;
export type ListCloudIntegrationsError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** List Cloud Integrations (Closed Beta). */
export declare const listCloudIntegrations: API.PaginatedOperationMethod<ListCloudIntegrationsRequest, ListCloudIntegrationsResponse, ListCloudIntegrationsError, CloudflareOpContext, CloudIntegrationsListResultItem>;
export type ListOnRampAddressSpacesError = CloudflareOpError;
/** Read the Magic WAN Address Space (Closed Beta). */
export declare const listOnRampAddressSpaces: API.OperationMethod<ListOnRampAddressSpacesRequest, ListOnRampAddressSpacesResponse, ListOnRampAddressSpacesError, CloudflareOpContext>;
export type ListOnRampsError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** List On-ramps (Closed Beta). */
export declare const listOnRamps: API.PaginatedOperationMethod<ListOnRampsRequest, ListOnRampsResponse, ListOnRampsError, CloudflareOpContext, OnRampsListResultItem>;
export type ListResourcesError = CloudflareOpError;
/** List resources in the Resource Catalog (Closed Beta). */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest, ListResourcesResponse, ListResourcesError, CloudflareOpContext, ResourcesListResultItem>;
export type PatchCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Update a Catalog Sync (Closed Beta). */
export declare const patchCatalogSync: API.OperationMethod<PatchCatalogSyncRequest, PatchCatalogSyncResponse, PatchCatalogSyncError, CloudflareOpContext>;
export type PatchCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudIntegrationNotFound | CloudflareOpError;
/** Update a Cloud Integration (Closed Beta). */
export declare const patchCloudIntegration: API.OperationMethod<PatchCloudIntegrationRequest, PatchCloudIntegrationResponse, PatchCloudIntegrationError, CloudflareOpContext>;
export type PatchOnRampError = FeatureNotEnabled | Forbidden | OnRampNotFound | CloudflareOpError;
/** Update an On-ramp (Closed Beta). */
export declare const patchOnRamp: API.OperationMethod<PatchOnRampRequest, PatchOnRampResponse, PatchOnRampError, CloudflareOpContext>;
export type PatchOnRampAddressSpaceError = CloudflareOpError;
/** Update the Magic WAN Address Space (Closed Beta). */
export declare const patchOnRampAddressSpace: API.OperationMethod<PatchOnRampAddressSpaceRequest, PatchOnRampAddressSpaceResponse, PatchOnRampAddressSpaceError, CloudflareOpContext>;
export type PlanOnRampError = CloudflareOpError;
/** Plan an On-ramp (Closed Beta). */
export declare const planOnRamp: API.OperationMethod<PlanOnRampRequest, PlanOnRampResponse, PlanOnRampError, CloudflareOpContext>;
export type PolicyPreviewResourceError = CloudflareOpError;
/** Preview Rego query result against the latest resource catalog (Closed Beta). */
export declare const policyPreviewResource: API.OperationMethod<PolicyPreviewResourceRequest, PolicyPreviewResourceResponse, PolicyPreviewResourceError, CloudflareOpContext>;
export type PutOnRampAddressSpaceError = CloudflareOpError;
/** Update the Magic WAN Address Space (Closed Beta). */
export declare const putOnRampAddressSpace: API.OperationMethod<PutOnRampAddressSpaceRequest, PutOnRampAddressSpaceResponse, PutOnRampAddressSpaceError, CloudflareOpContext>;
export type RefreshCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Refresh a Catalog Sync's destination by running the sync policy against latest resource catalog (Closed Beta). */
export declare const refreshCatalogSync: API.OperationMethod<RefreshCatalogSyncRequest, RefreshCatalogSyncResponse, RefreshCatalogSyncError, CloudflareOpContext>;
export type UpdateCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Update a Catalog Sync (Closed Beta). */
export declare const updateCatalogSync: API.OperationMethod<UpdateCatalogSyncRequest, UpdateCatalogSyncResponse, UpdateCatalogSyncError, CloudflareOpContext>;
export type UpdateCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudIntegrationNotFound | CloudflareOpError;
/** Update a Cloud Integration (Closed Beta). */
export declare const updateCloudIntegration: API.OperationMethod<UpdateCloudIntegrationRequest, UpdateCloudIntegrationResponse, UpdateCloudIntegrationError, CloudflareOpContext>;
export type UpdateOnRampError = FeatureNotEnabled | Forbidden | OnRampNotFound | CloudflareOpError;
/** Update an On-ramp (Closed Beta). */
export declare const updateOnRamp: API.OperationMethod<UpdateOnRampRequest, UpdateOnRampResponse, UpdateOnRampError, CloudflareOpContext>;
//# sourceMappingURL=magic_cloud_networking.d.ts.map