import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AllocationIdNotFoundException_base: S.TaggedErrorClass<"AllocationIdNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AllocationIdNotFoundException extends /*@__PURE__*/ AllocationIdNotFoundException_base {
}
declare const ALPNPolicyNotSupportedException_base: S.TaggedErrorClass<"ALPNPolicyNotSupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ALPNPolicyNotSupportedException extends /*@__PURE__*/ ALPNPolicyNotSupportedException_base {
}
declare const AvailabilityZoneNotSupportedException_base: S.TaggedErrorClass<"AvailabilityZoneNotSupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AvailabilityZoneNotSupportedException extends /*@__PURE__*/ AvailabilityZoneNotSupportedException_base {
}
declare const CaCertificatesBundleNotFoundException_base: S.TaggedErrorClass<"CaCertificatesBundleNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CaCertificatesBundleNotFoundException extends /*@__PURE__*/ CaCertificatesBundleNotFoundException_base {
}
declare const CapacityDecreaseRequestsLimitExceededException_base: S.TaggedErrorClass<"CapacityDecreaseRequestsLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CapacityDecreaseRequestsLimitExceededException extends /*@__PURE__*/ CapacityDecreaseRequestsLimitExceededException_base {
}
declare const CapacityReservationPendingException_base: S.TaggedErrorClass<"CapacityReservationPendingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CapacityReservationPendingException extends /*@__PURE__*/ CapacityReservationPendingException_base {
}
declare const CapacityUnitsLimitExceededException_base: S.TaggedErrorClass<"CapacityUnitsLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CapacityUnitsLimitExceededException extends /*@__PURE__*/ CapacityUnitsLimitExceededException_base {
}
declare const CertificateNotFoundException_base: S.TaggedErrorClass<"CertificateNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CertificateNotFoundException extends /*@__PURE__*/ CertificateNotFoundException_base {
}
declare const DeleteAssociationSameAccountException_base: S.TaggedErrorClass<"DeleteAssociationSameAccountException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DeleteAssociationSameAccountException extends /*@__PURE__*/ DeleteAssociationSameAccountException_base {
}
declare const DuplicateListenerException_base: S.TaggedErrorClass<"DuplicateListenerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateListenerException extends /*@__PURE__*/ DuplicateListenerException_base {
}
declare const DuplicateLoadBalancerNameException_base: S.TaggedErrorClass<"DuplicateLoadBalancerNameException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateLoadBalancerNameException extends /*@__PURE__*/ DuplicateLoadBalancerNameException_base {
}
declare const DuplicateTagKeysException_base: S.TaggedErrorClass<"DuplicateTagKeysException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateTagKeysException extends /*@__PURE__*/ DuplicateTagKeysException_base {
}
declare const DuplicateTargetGroupNameException_base: S.TaggedErrorClass<"DuplicateTargetGroupNameException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateTargetGroupNameException extends /*@__PURE__*/ DuplicateTargetGroupNameException_base {
}
declare const DuplicateTrustStoreNameException_base: S.TaggedErrorClass<"DuplicateTrustStoreNameException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateTrustStoreNameException extends /*@__PURE__*/ DuplicateTrustStoreNameException_base {
}
declare const HealthUnavailableException_base: S.TaggedErrorClass<"HealthUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class HealthUnavailableException extends /*@__PURE__*/ HealthUnavailableException_base {
}
declare const IncompatibleProtocolsException_base: S.TaggedErrorClass<"IncompatibleProtocolsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncompatibleProtocolsException extends /*@__PURE__*/ IncompatibleProtocolsException_base {
}
declare const InsufficientCapacityException_base: S.TaggedErrorClass<"InsufficientCapacityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InsufficientCapacityException extends /*@__PURE__*/ InsufficientCapacityException_base {
}
declare const InvalidCaCertificatesBundleException_base: S.TaggedErrorClass<"InvalidCaCertificatesBundleException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCaCertificatesBundleException extends /*@__PURE__*/ InvalidCaCertificatesBundleException_base {
}
declare const InvalidConfigurationRequestException_base: S.TaggedErrorClass<"InvalidConfigurationRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidConfigurationRequestException extends /*@__PURE__*/ InvalidConfigurationRequestException_base {
}
declare const InvalidLoadBalancerActionException_base: S.TaggedErrorClass<"InvalidLoadBalancerActionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLoadBalancerActionException extends /*@__PURE__*/ InvalidLoadBalancerActionException_base {
}
declare const InvalidRevocationContentException_base: S.TaggedErrorClass<"InvalidRevocationContentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRevocationContentException extends /*@__PURE__*/ InvalidRevocationContentException_base {
}
declare const InvalidSchemeException_base: S.TaggedErrorClass<"InvalidSchemeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSchemeException extends /*@__PURE__*/ InvalidSchemeException_base {
}
declare const InvalidSecurityGroupException_base: S.TaggedErrorClass<"InvalidSecurityGroupException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSecurityGroupException extends /*@__PURE__*/ InvalidSecurityGroupException_base {
}
declare const InvalidSubnetException_base: S.TaggedErrorClass<"InvalidSubnetException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnetException extends /*@__PURE__*/ InvalidSubnetException_base {
}
declare const InvalidTargetException_base: S.TaggedErrorClass<"InvalidTargetException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTargetException extends /*@__PURE__*/ InvalidTargetException_base {
}
declare const ListenerNotFoundException_base: S.TaggedErrorClass<"ListenerNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ListenerNotFoundException extends /*@__PURE__*/ ListenerNotFoundException_base {
}
declare const LoadBalancerNotFoundException_base: S.TaggedErrorClass<"LoadBalancerNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LoadBalancerNotFoundException extends /*@__PURE__*/ LoadBalancerNotFoundException_base {
}
declare const OperationNotPermittedException_base: S.TaggedErrorClass<"OperationNotPermittedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const PriorityInUseException_base: S.TaggedErrorClass<"PriorityInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PriorityInUseException extends /*@__PURE__*/ PriorityInUseException_base {
}
declare const PriorRequestNotCompleteException_base: S.TaggedErrorClass<"PriorRequestNotCompleteException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class PriorRequestNotCompleteException extends /*@__PURE__*/ PriorRequestNotCompleteException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RevocationContentNotFoundException_base: S.TaggedErrorClass<"RevocationContentNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RevocationContentNotFoundException extends /*@__PURE__*/ RevocationContentNotFoundException_base {
}
declare const RevocationIdNotFoundException_base: S.TaggedErrorClass<"RevocationIdNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RevocationIdNotFoundException extends /*@__PURE__*/ RevocationIdNotFoundException_base {
}
declare const RuleNotFoundException_base: S.TaggedErrorClass<"RuleNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RuleNotFoundException extends /*@__PURE__*/ RuleNotFoundException_base {
}
declare const SSLPolicyNotFoundException_base: S.TaggedErrorClass<"SSLPolicyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SSLPolicyNotFoundException extends /*@__PURE__*/ SSLPolicyNotFoundException_base {
}
declare const SubnetNotFoundException_base: S.TaggedErrorClass<"SubnetNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetNotFoundException extends /*@__PURE__*/ SubnetNotFoundException_base {
}
declare const TargetGroupAssociationLimitException_base: S.TaggedErrorClass<"TargetGroupAssociationLimitException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TargetGroupAssociationLimitException extends /*@__PURE__*/ TargetGroupAssociationLimitException_base {
}
declare const TargetGroupNotFoundException_base: S.TaggedErrorClass<"TargetGroupNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TargetGroupNotFoundException extends /*@__PURE__*/ TargetGroupNotFoundException_base {
}
declare const TooManyActionsException_base: S.TaggedErrorClass<"TooManyActionsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyActionsException extends /*@__PURE__*/ TooManyActionsException_base {
}
declare const TooManyCertificatesException_base: S.TaggedErrorClass<"TooManyCertificatesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCertificatesException extends /*@__PURE__*/ TooManyCertificatesException_base {
}
declare const TooManyListenersException_base: S.TaggedErrorClass<"TooManyListenersException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyListenersException extends /*@__PURE__*/ TooManyListenersException_base {
}
declare const TooManyLoadBalancersException_base: S.TaggedErrorClass<"TooManyLoadBalancersException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyLoadBalancersException extends /*@__PURE__*/ TooManyLoadBalancersException_base {
}
declare const TooManyRegistrationsForTargetIdException_base: S.TaggedErrorClass<"TooManyRegistrationsForTargetIdException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyRegistrationsForTargetIdException extends /*@__PURE__*/ TooManyRegistrationsForTargetIdException_base {
}
declare const TooManyRulesException_base: S.TaggedErrorClass<"TooManyRulesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyRulesException extends /*@__PURE__*/ TooManyRulesException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const TooManyTargetGroupsException_base: S.TaggedErrorClass<"TooManyTargetGroupsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTargetGroupsException extends /*@__PURE__*/ TooManyTargetGroupsException_base {
}
declare const TooManyTargetsException_base: S.TaggedErrorClass<"TooManyTargetsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTargetsException extends /*@__PURE__*/ TooManyTargetsException_base {
}
declare const TooManyTrustStoreRevocationEntriesException_base: S.TaggedErrorClass<"TooManyTrustStoreRevocationEntriesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTrustStoreRevocationEntriesException extends /*@__PURE__*/ TooManyTrustStoreRevocationEntriesException_base {
}
declare const TooManyTrustStoresException_base: S.TaggedErrorClass<"TooManyTrustStoresException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTrustStoresException extends /*@__PURE__*/ TooManyTrustStoresException_base {
}
declare const TooManyUniqueTargetGroupsPerLoadBalancerException_base: S.TaggedErrorClass<"TooManyUniqueTargetGroupsPerLoadBalancerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyUniqueTargetGroupsPerLoadBalancerException extends /*@__PURE__*/ TooManyUniqueTargetGroupsPerLoadBalancerException_base {
}
declare const TrustStoreAssociationNotFoundException_base: S.TaggedErrorClass<"TrustStoreAssociationNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrustStoreAssociationNotFoundException extends /*@__PURE__*/ TrustStoreAssociationNotFoundException_base {
}
declare const TrustStoreInUseException_base: S.TaggedErrorClass<"TrustStoreInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrustStoreInUseException extends /*@__PURE__*/ TrustStoreInUseException_base {
}
declare const TrustStoreNotFoundException_base: S.TaggedErrorClass<"TrustStoreNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrustStoreNotFoundException extends /*@__PURE__*/ TrustStoreNotFoundException_base {
}
declare const TrustStoreNotReadyException_base: S.TaggedErrorClass<"TrustStoreNotReadyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrustStoreNotReadyException extends /*@__PURE__*/ TrustStoreNotReadyException_base {
}
declare const UnsupportedProtocolException_base: S.TaggedErrorClass<"UnsupportedProtocolException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedProtocolException extends /*@__PURE__*/ UnsupportedProtocolException_base {
}
export type ListenerArn = string;
export type CertificateArn = string;
export type Default = boolean;
export interface Certificate {
    CertificateArn?: string | undefined;
    IsDefault?: boolean | undefined;
}
export type CertificateList = Certificate[];
export interface AddListenerCertificatesInput {
    ListenerArn?: string | undefined;
    Certificates?: Certificate[] | undefined;
}
export interface AddListenerCertificatesOutput {
    Certificates?: Certificate[] | undefined;
}
export type ResourceArn = string;
export type ResourceArns = string[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface AddTagsInput {
    ResourceArns?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface AddTagsOutput {
}
export type TrustStoreArn = string;
export type S3Bucket = string;
export type S3Key = string;
export type S3ObjectVersion = string;
export type RevocationType = "CRL" | (string & {});
export interface RevocationContent {
    S3Bucket?: string | undefined;
    S3Key?: string | undefined;
    S3ObjectVersion?: string | undefined;
    RevocationType?: RevocationType | undefined;
}
export type RevocationContents = RevocationContent[];
export interface AddTrustStoreRevocationsInput {
    TrustStoreArn?: string | undefined;
    RevocationContents?: RevocationContent[] | undefined;
}
export type RevocationId = number;
export type NumberOfRevokedEntries = number;
export interface TrustStoreRevocation {
    TrustStoreArn?: string | undefined;
    RevocationId?: number | undefined;
    RevocationType?: RevocationType | undefined;
    NumberOfRevokedEntries?: number | undefined;
}
export type TrustStoreRevocations = TrustStoreRevocation[];
export interface AddTrustStoreRevocationsOutput {
    TrustStoreRevocations?: TrustStoreRevocation[] | undefined;
}
export type LoadBalancerArn = string;
export type ProtocolEnum = "HTTP" | "HTTPS" | "TCP" | "TLS" | "UDP" | "TCP_UDP" | "GENEVE" | "QUIC" | "TCP_QUIC" | (string & {});
export type Port = number;
export type SslPolicyName = string;
export type ActionTypeEnum = "forward" | "authenticate-oidc" | "authenticate-cognito" | "redirect" | "fixed-response" | "jwt-validation" | (string & {});
export type TargetGroupArn = string;
export type AuthenticateOidcActionIssuer = string;
export type AuthenticateOidcActionAuthorizationEndpoint = string;
export type AuthenticateOidcActionTokenEndpoint = string;
export type AuthenticateOidcActionUserInfoEndpoint = string;
export type AuthenticateOidcActionClientId = string;
export type AuthenticateOidcActionClientSecret = string;
export type AuthenticateOidcActionSessionCookieName = string;
export type AuthenticateOidcActionScope = string;
export type AuthenticateOidcActionSessionTimeout = number;
export type AuthenticateOidcActionAuthenticationRequestParamName = string;
export type AuthenticateOidcActionAuthenticationRequestParamValue = string;
export type AuthenticateOidcActionAuthenticationRequestExtraParams = {
    [key: string]: string | undefined;
};
export type AuthenticateOidcActionConditionalBehaviorEnum = "deny" | "allow" | "authenticate" | (string & {});
export type AuthenticateOidcActionUseExistingClientSecret = boolean;
export interface AuthenticateOidcActionConfig {
    Issuer?: string | undefined;
    AuthorizationEndpoint?: string | undefined;
    TokenEndpoint?: string | undefined;
    UserInfoEndpoint?: string | undefined;
    ClientId?: string | undefined;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
    SessionCookieName?: string | undefined;
    Scope?: string | undefined;
    SessionTimeout?: number | undefined;
    AuthenticationRequestExtraParams?: {
        [key: string]: string | undefined;
    } | undefined;
    OnUnauthenticatedRequest?: AuthenticateOidcActionConditionalBehaviorEnum | undefined;
    UseExistingClientSecret?: boolean | undefined;
}
export type AuthenticateCognitoActionUserPoolArn = string;
export type AuthenticateCognitoActionUserPoolClientId = string;
export type AuthenticateCognitoActionUserPoolDomain = string;
export type AuthenticateCognitoActionSessionCookieName = string;
export type AuthenticateCognitoActionScope = string;
export type AuthenticateCognitoActionSessionTimeout = number;
export type AuthenticateCognitoActionAuthenticationRequestParamName = string;
export type AuthenticateCognitoActionAuthenticationRequestParamValue = string;
export type AuthenticateCognitoActionAuthenticationRequestExtraParams = {
    [key: string]: string | undefined;
};
export type AuthenticateCognitoActionConditionalBehaviorEnum = "deny" | "allow" | "authenticate" | (string & {});
export interface AuthenticateCognitoActionConfig {
    UserPoolArn?: string | undefined;
    UserPoolClientId?: string | undefined;
    UserPoolDomain?: string | undefined;
    SessionCookieName?: string | undefined;
    Scope?: string | undefined;
    SessionTimeout?: number | undefined;
    AuthenticationRequestExtraParams?: {
        [key: string]: string | undefined;
    } | undefined;
    OnUnauthenticatedRequest?: AuthenticateCognitoActionConditionalBehaviorEnum | undefined;
}
export type ActionOrder = number;
export type RedirectActionProtocol = string;
export type RedirectActionPort = string;
export type RedirectActionHost = string;
export type RedirectActionPath = string;
export type RedirectActionQuery = string;
export type RedirectActionStatusCodeEnum = "HTTP_301" | "HTTP_302" | (string & {});
export interface RedirectActionConfig {
    Protocol?: string | undefined;
    Port?: string | undefined;
    Host?: string | undefined;
    Path?: string | undefined;
    Query?: string | undefined;
    StatusCode?: RedirectActionStatusCodeEnum | undefined;
}
export type FixedResponseActionMessage = string;
export type FixedResponseActionStatusCode = string;
export type FixedResponseActionContentType = string;
export interface FixedResponseActionConfig {
    MessageBody?: string | undefined;
    StatusCode?: string | undefined;
    ContentType?: string | undefined;
}
export type TargetGroupWeight = number;
export interface TargetGroupTuple {
    TargetGroupArn?: string | undefined;
    Weight?: number | undefined;
}
export type TargetGroupList = TargetGroupTuple[];
export type TargetGroupStickinessEnabled = boolean;
export type TargetGroupStickinessDurationSeconds = number;
export interface TargetGroupStickinessConfig {
    Enabled?: boolean | undefined;
    DurationSeconds?: number | undefined;
}
export interface ForwardActionConfig {
    TargetGroups?: TargetGroupTuple[] | undefined;
    TargetGroupStickinessConfig?: TargetGroupStickinessConfig | undefined;
}
export type JwtValidationActionJwksEndpoint = string;
export type JwtValidationActionIssuer = string;
export type JwtValidationActionAdditionalClaimFormatEnum = "single-string" | "string-array" | "space-separated-values" | (string & {});
export type JwtValidationActionAdditionalClaimName = string;
export type JwtValidationActionAdditionalClaimValue = string;
export type JwtValidationActionAdditionalClaimValues = string[];
export interface JwtValidationActionAdditionalClaim {
    Format?: JwtValidationActionAdditionalClaimFormatEnum | undefined;
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type JwtValidationActionAdditionalClaims = JwtValidationActionAdditionalClaim[];
export interface JwtValidationActionConfig {
    JwksEndpoint?: string | undefined;
    Issuer?: string | undefined;
    AdditionalClaims?: JwtValidationActionAdditionalClaim[] | undefined;
}
export interface Action {
    Type?: ActionTypeEnum | undefined;
    TargetGroupArn?: string | undefined;
    AuthenticateOidcConfig?: AuthenticateOidcActionConfig | undefined;
    AuthenticateCognitoConfig?: AuthenticateCognitoActionConfig | undefined;
    Order?: number | undefined;
    RedirectConfig?: RedirectActionConfig | undefined;
    FixedResponseConfig?: FixedResponseActionConfig | undefined;
    ForwardConfig?: ForwardActionConfig | undefined;
    JwtValidationConfig?: JwtValidationActionConfig | undefined;
}
export type Actions = Action[];
export type AlpnPolicyValue = string;
export type AlpnPolicyName = string[];
export type Mode = string;
export type IgnoreClientCertificateExpiry = boolean;
export type TrustStoreAssociationStatusEnum = "active" | "removed" | (string & {});
export type AdvertiseTrustStoreCaNamesEnum = "on" | "off" | (string & {});
export interface MutualAuthenticationAttributes {
    Mode?: string | undefined;
    TrustStoreArn?: string | undefined;
    IgnoreClientCertificateExpiry?: boolean | undefined;
    TrustStoreAssociationStatus?: TrustStoreAssociationStatusEnum | undefined;
    AdvertiseTrustStoreCaNames?: AdvertiseTrustStoreCaNamesEnum | undefined;
}
export interface CreateListenerInput {
    LoadBalancerArn?: string | undefined;
    Protocol?: ProtocolEnum | undefined;
    Port?: number | undefined;
    SslPolicy?: string | undefined;
    Certificates?: Certificate[] | undefined;
    DefaultActions?: Action[] | undefined;
    AlpnPolicy?: string[] | undefined;
    Tags?: Tag[] | undefined;
    MutualAuthentication?: MutualAuthenticationAttributes | undefined;
}
export interface Listener {
    ListenerArn?: string | undefined;
    LoadBalancerArn?: string | undefined;
    Port?: number | undefined;
    Protocol?: ProtocolEnum | undefined;
    Certificates?: Certificate[] | undefined;
    SslPolicy?: string | undefined;
    DefaultActions?: Action[] | undefined;
    AlpnPolicy?: string[] | undefined;
    MutualAuthentication?: MutualAuthenticationAttributes | undefined;
}
export type Listeners = Listener[];
export interface CreateListenerOutput {
    Listeners?: (Listener & {
        DefaultActions: (Action & {
            Type: ActionTypeEnum;
            AuthenticateOidcConfig: AuthenticateOidcActionConfig & {
                Issuer: AuthenticateOidcActionIssuer;
                AuthorizationEndpoint: AuthenticateOidcActionAuthorizationEndpoint;
                TokenEndpoint: AuthenticateOidcActionTokenEndpoint;
                UserInfoEndpoint: AuthenticateOidcActionUserInfoEndpoint;
                ClientId: AuthenticateOidcActionClientId;
            };
            AuthenticateCognitoConfig: AuthenticateCognitoActionConfig & {
                UserPoolArn: AuthenticateCognitoActionUserPoolArn;
                UserPoolClientId: AuthenticateCognitoActionUserPoolClientId;
                UserPoolDomain: AuthenticateCognitoActionUserPoolDomain;
            };
            RedirectConfig: RedirectActionConfig & {
                StatusCode: RedirectActionStatusCodeEnum;
            };
            FixedResponseConfig: FixedResponseActionConfig & {
                StatusCode: FixedResponseActionStatusCode;
            };
            JwtValidationConfig: JwtValidationActionConfig & {
                JwksEndpoint: JwtValidationActionJwksEndpoint;
                Issuer: JwtValidationActionIssuer;
                AdditionalClaims: (JwtValidationActionAdditionalClaim & {
                    Format: JwtValidationActionAdditionalClaimFormatEnum;
                    Name: JwtValidationActionAdditionalClaimName;
                    Values: JwtValidationActionAdditionalClaimValues;
                })[];
            };
        })[];
    })[] | undefined;
}
export type LoadBalancerName = string;
export type SubnetId = string;
export type Subnets = string[];
export type AllocationId = string;
export type PrivateIPv4Address = string;
export type IPv6Address = string;
export type SourceNatIpv6Prefix = string;
export interface SubnetMapping {
    SubnetId?: string | undefined;
    AllocationId?: string | undefined;
    PrivateIPv4Address?: string | undefined;
    IPv6Address?: string | undefined;
    SourceNatIpv6Prefix?: string | undefined;
}
export type SubnetMappings = SubnetMapping[];
export type SecurityGroupId = string;
export type SecurityGroups = string[];
export type LoadBalancerSchemeEnum = "internet-facing" | "internal" | (string & {});
export type LoadBalancerTypeEnum = "application" | "network" | "gateway" | (string & {});
export type IpAddressType = "ipv4" | "dualstack" | "dualstack-without-public-ipv4" | (string & {});
export type CustomerOwnedIpv4Pool = string;
export type EnablePrefixForIpv6SourceNatEnum = "on" | "off" | (string & {});
export type IpamPoolId = string;
export interface IpamPools {
    Ipv4IpamPoolId?: string | undefined;
}
export interface CreateLoadBalancerInput {
    Name?: string | undefined;
    Subnets?: string[] | undefined;
    SubnetMappings?: SubnetMapping[] | undefined;
    SecurityGroups?: string[] | undefined;
    Scheme?: LoadBalancerSchemeEnum | undefined;
    Tags?: Tag[] | undefined;
    Type?: LoadBalancerTypeEnum | undefined;
    IpAddressType?: IpAddressType | undefined;
    CustomerOwnedIpv4Pool?: string | undefined;
    EnablePrefixForIpv6SourceNat?: EnablePrefixForIpv6SourceNatEnum | undefined;
    IpamPools?: IpamPools | undefined;
}
export type DNSName = string;
export type CanonicalHostedZoneId = string;
export type CreatedTime = Date;
export type VpcId = string;
export type LoadBalancerStateEnum = "active" | "provisioning" | "active_impaired" | "failed" | (string & {});
export type StateReason = string;
export interface LoadBalancerState {
    Code?: LoadBalancerStateEnum | undefined;
    Reason?: string | undefined;
}
export type ZoneName = string;
export type OutpostId = string;
export type IpAddress = string;
export interface LoadBalancerAddress {
    IpAddress?: string | undefined;
    AllocationId?: string | undefined;
    PrivateIPv4Address?: string | undefined;
    IPv6Address?: string | undefined;
}
export type LoadBalancerAddresses = LoadBalancerAddress[];
export type SourceNatIpv6Prefixes = string[];
export interface AvailabilityZone {
    ZoneName?: string | undefined;
    SubnetId?: string | undefined;
    OutpostId?: string | undefined;
    LoadBalancerAddresses?: LoadBalancerAddress[] | undefined;
    SourceNatIpv6Prefixes?: string[] | undefined;
}
export type AvailabilityZones = AvailabilityZone[];
export type EnforceSecurityGroupInboundRulesOnPrivateLinkTraffic = string;
export interface LoadBalancer {
    LoadBalancerArn?: string | undefined;
    DNSName?: string | undefined;
    CanonicalHostedZoneId?: string | undefined;
    CreatedTime?: Date | undefined;
    LoadBalancerName?: string | undefined;
    Scheme?: LoadBalancerSchemeEnum | undefined;
    VpcId?: string | undefined;
    State?: LoadBalancerState | undefined;
    Type?: LoadBalancerTypeEnum | undefined;
    AvailabilityZones?: AvailabilityZone[] | undefined;
    SecurityGroups?: string[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    CustomerOwnedIpv4Pool?: string | undefined;
    EnforceSecurityGroupInboundRulesOnPrivateLinkTraffic?: string | undefined;
    EnablePrefixForIpv6SourceNat?: EnablePrefixForIpv6SourceNatEnum | undefined;
    IpamPools?: IpamPools | undefined;
}
export type LoadBalancers = LoadBalancer[];
export interface CreateLoadBalancerOutput {
    LoadBalancers?: LoadBalancer[] | undefined;
}
export type ConditionFieldName = string;
export type StringValue = string;
export type ListOfString = string[];
export interface HostHeaderConditionConfig {
    Values?: string[] | undefined;
    RegexValues?: string[] | undefined;
}
export interface PathPatternConditionConfig {
    Values?: string[] | undefined;
    RegexValues?: string[] | undefined;
}
export type HttpHeaderConditionName = string;
export interface HttpHeaderConditionConfig {
    HttpHeaderName?: string | undefined;
    Values?: string[] | undefined;
    RegexValues?: string[] | undefined;
}
export interface QueryStringKeyValuePair {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type QueryStringKeyValuePairList = QueryStringKeyValuePair[];
export interface QueryStringConditionConfig {
    Values?: QueryStringKeyValuePair[] | undefined;
}
export interface HttpRequestMethodConditionConfig {
    Values?: string[] | undefined;
}
export type SourceIpAddressTypeEnum = "ipv4" | "ipv6" | (string & {});
export interface SourceIpConditionConfig {
    Values?: string[] | undefined;
    IpAddressType?: SourceIpAddressTypeEnum | undefined;
}
export interface RuleCondition {
    Field?: string | undefined;
    Values?: string[] | undefined;
    HostHeaderConfig?: HostHeaderConditionConfig | undefined;
    PathPatternConfig?: PathPatternConditionConfig | undefined;
    HttpHeaderConfig?: HttpHeaderConditionConfig | undefined;
    QueryStringConfig?: QueryStringConditionConfig | undefined;
    HttpRequestMethodConfig?: HttpRequestMethodConditionConfig | undefined;
    SourceIpConfig?: SourceIpConditionConfig | undefined;
    RegexValues?: string[] | undefined;
}
export type RuleConditionList = RuleCondition[];
export type RulePriority = number;
export type TransformTypeEnum = "host-header-rewrite" | "url-rewrite" | (string & {});
export interface RewriteConfig {
    Regex?: string | undefined;
    Replace?: string | undefined;
}
export type RewriteConfigList = RewriteConfig[];
export interface HostHeaderRewriteConfig {
    Rewrites?: RewriteConfig[] | undefined;
}
export interface UrlRewriteConfig {
    Rewrites?: RewriteConfig[] | undefined;
}
export interface RuleTransform {
    Type?: TransformTypeEnum | undefined;
    HostHeaderRewriteConfig?: HostHeaderRewriteConfig | undefined;
    UrlRewriteConfig?: UrlRewriteConfig | undefined;
}
export type RuleTransformList = RuleTransform[];
export interface CreateRuleInput {
    ListenerArn?: string | undefined;
    Conditions?: RuleCondition[] | undefined;
    Priority?: number | undefined;
    Actions?: Action[] | undefined;
    Tags?: Tag[] | undefined;
    Transforms?: RuleTransform[] | undefined;
}
export type RuleArn = string;
export type IsDefault = boolean;
export interface Rule {
    RuleArn?: string | undefined;
    Priority?: string | undefined;
    Conditions?: RuleCondition[] | undefined;
    Actions?: Action[] | undefined;
    IsDefault?: boolean | undefined;
    Transforms?: RuleTransform[] | undefined;
}
export type Rules = Rule[];
export interface CreateRuleOutput {
    Rules?: (Rule & {
        Actions: (Action & {
            Type: ActionTypeEnum;
            AuthenticateOidcConfig: AuthenticateOidcActionConfig & {
                Issuer: AuthenticateOidcActionIssuer;
                AuthorizationEndpoint: AuthenticateOidcActionAuthorizationEndpoint;
                TokenEndpoint: AuthenticateOidcActionTokenEndpoint;
                UserInfoEndpoint: AuthenticateOidcActionUserInfoEndpoint;
                ClientId: AuthenticateOidcActionClientId;
            };
            AuthenticateCognitoConfig: AuthenticateCognitoActionConfig & {
                UserPoolArn: AuthenticateCognitoActionUserPoolArn;
                UserPoolClientId: AuthenticateCognitoActionUserPoolClientId;
                UserPoolDomain: AuthenticateCognitoActionUserPoolDomain;
            };
            RedirectConfig: RedirectActionConfig & {
                StatusCode: RedirectActionStatusCodeEnum;
            };
            FixedResponseConfig: FixedResponseActionConfig & {
                StatusCode: FixedResponseActionStatusCode;
            };
            JwtValidationConfig: JwtValidationActionConfig & {
                JwksEndpoint: JwtValidationActionJwksEndpoint;
                Issuer: JwtValidationActionIssuer;
                AdditionalClaims: (JwtValidationActionAdditionalClaim & {
                    Format: JwtValidationActionAdditionalClaimFormatEnum;
                    Name: JwtValidationActionAdditionalClaimName;
                    Values: JwtValidationActionAdditionalClaimValues;
                })[];
            };
        })[];
        Transforms: (RuleTransform & {
            Type: TransformTypeEnum;
            HostHeaderRewriteConfig: HostHeaderRewriteConfig & {
                Rewrites: (RewriteConfig & {
                    Regex: StringValue;
                    Replace: StringValue;
                })[];
            };
            UrlRewriteConfig: UrlRewriteConfig & {
                Rewrites: (RewriteConfig & {
                    Regex: StringValue;
                    Replace: StringValue;
                })[];
            };
        })[];
    })[] | undefined;
}
export type TargetGroupName = string;
export type ProtocolVersion = string;
export type HealthCheckPort = string;
export type HealthCheckEnabled = boolean;
export type Path = string;
export type HealthCheckIntervalSeconds = number;
export type HealthCheckTimeoutSeconds = number;
export type HealthCheckThresholdCount = number;
export type HttpCode = string;
export type GrpcCode = string;
export interface Matcher {
    HttpCode?: string | undefined;
    GrpcCode?: string | undefined;
}
export type TargetTypeEnum = "instance" | "ip" | "lambda" | "alb" | (string & {});
export type TargetGroupIpAddressTypeEnum = "ipv4" | "ipv6" | (string & {});
export type TargetControlPort = number;
export interface CreateTargetGroupInput {
    Name?: string | undefined;
    Protocol?: ProtocolEnum | undefined;
    ProtocolVersion?: string | undefined;
    Port?: number | undefined;
    VpcId?: string | undefined;
    HealthCheckProtocol?: ProtocolEnum | undefined;
    HealthCheckPort?: string | undefined;
    HealthCheckEnabled?: boolean | undefined;
    HealthCheckPath?: string | undefined;
    HealthCheckIntervalSeconds?: number | undefined;
    HealthCheckTimeoutSeconds?: number | undefined;
    HealthyThresholdCount?: number | undefined;
    UnhealthyThresholdCount?: number | undefined;
    Matcher?: Matcher | undefined;
    TargetType?: TargetTypeEnum | undefined;
    Tags?: Tag[] | undefined;
    IpAddressType?: TargetGroupIpAddressTypeEnum | undefined;
    TargetControlPort?: number | undefined;
}
export type LoadBalancerArns = string[];
export interface TargetGroup {
    TargetGroupArn?: string | undefined;
    TargetGroupName?: string | undefined;
    Protocol?: ProtocolEnum | undefined;
    Port?: number | undefined;
    VpcId?: string | undefined;
    HealthCheckProtocol?: ProtocolEnum | undefined;
    HealthCheckPort?: string | undefined;
    HealthCheckEnabled?: boolean | undefined;
    HealthCheckIntervalSeconds?: number | undefined;
    HealthCheckTimeoutSeconds?: number | undefined;
    HealthyThresholdCount?: number | undefined;
    UnhealthyThresholdCount?: number | undefined;
    HealthCheckPath?: string | undefined;
    Matcher?: Matcher | undefined;
    LoadBalancerArns?: string[] | undefined;
    TargetType?: TargetTypeEnum | undefined;
    ProtocolVersion?: string | undefined;
    IpAddressType?: TargetGroupIpAddressTypeEnum | undefined;
    TargetControlPort?: number | undefined;
}
export type TargetGroups = TargetGroup[];
export interface CreateTargetGroupOutput {
    TargetGroups?: TargetGroup[] | undefined;
}
export type TrustStoreName = string;
export interface CreateTrustStoreInput {
    Name?: string | undefined;
    CaCertificatesBundleS3Bucket?: string | undefined;
    CaCertificatesBundleS3Key?: string | undefined;
    CaCertificatesBundleS3ObjectVersion?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type TrustStoreStatus = "ACTIVE" | "CREATING" | (string & {});
export type NumberOfCaCertificates = number;
export type TotalRevokedEntries = number;
export interface TrustStore {
    Name?: string | undefined;
    TrustStoreArn?: string | undefined;
    Status?: TrustStoreStatus | undefined;
    NumberOfCaCertificates?: number | undefined;
    TotalRevokedEntries?: number | undefined;
}
export type TrustStores = TrustStore[];
export interface CreateTrustStoreOutput {
    TrustStores?: TrustStore[] | undefined;
}
export interface DeleteListenerInput {
    ListenerArn?: string | undefined;
}
export interface DeleteListenerOutput {
}
export interface DeleteLoadBalancerInput {
    LoadBalancerArn?: string | undefined;
}
export interface DeleteLoadBalancerOutput {
}
export interface DeleteRuleInput {
    RuleArn?: string | undefined;
}
export interface DeleteRuleOutput {
}
export interface DeleteSharedTrustStoreAssociationInput {
    TrustStoreArn?: string | undefined;
    ResourceArn?: string | undefined;
}
export interface DeleteSharedTrustStoreAssociationOutput {
}
export interface DeleteTargetGroupInput {
    TargetGroupArn?: string | undefined;
}
export interface DeleteTargetGroupOutput {
}
export interface DeleteTrustStoreInput {
    TrustStoreArn?: string | undefined;
}
export interface DeleteTrustStoreOutput {
}
export type TargetId = string;
export type QuicServerId = string;
export interface TargetDescription {
    Id?: string | undefined;
    Port?: number | undefined;
    AvailabilityZone?: string | undefined;
    QuicServerId?: string | undefined;
}
export type TargetDescriptions = TargetDescription[];
export interface DeregisterTargetsInput {
    TargetGroupArn?: string | undefined;
    Targets?: TargetDescription[] | undefined;
}
export interface DeregisterTargetsOutput {
}
export type Marker = string;
export type PageSize = number;
export interface DescribeAccountLimitsInput {
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export type Name = string;
export type Max = string;
export interface Limit {
    Name?: string | undefined;
    Max?: string | undefined;
}
export type Limits = Limit[];
export interface DescribeAccountLimitsOutput {
    Limits?: Limit[] | undefined;
    NextMarker?: string | undefined;
}
export interface DescribeCapacityReservationInput {
    LoadBalancerArn?: string | undefined;
}
export type LastModifiedTime = Date;
export type DecreaseRequestsRemaining = number;
export type CapacityUnits = number;
export interface MinimumLoadBalancerCapacity {
    CapacityUnits?: number | undefined;
}
export type CapacityReservationStateEnum = "provisioned" | "pending" | "rebalancing" | "failed" | (string & {});
export interface CapacityReservationStatus {
    Code?: CapacityReservationStateEnum | undefined;
    Reason?: string | undefined;
}
export type CapacityUnitsDouble = number;
export interface ZonalCapacityReservationState {
    State?: CapacityReservationStatus | undefined;
    AvailabilityZone?: string | undefined;
    EffectiveCapacityUnits?: number | undefined;
}
export type ZonalCapacityReservationStates = ZonalCapacityReservationState[];
export interface DescribeCapacityReservationOutput {
    LastModifiedTime?: Date | undefined;
    DecreaseRequestsRemaining?: number | undefined;
    MinimumLoadBalancerCapacity?: MinimumLoadBalancerCapacity | undefined;
    CapacityReservationState?: ZonalCapacityReservationState[] | undefined;
}
export interface DescribeListenerAttributesInput {
    ListenerArn?: string | undefined;
}
export type ListenerAttributeKey = string;
export type ListenerAttributeValue = string;
export interface ListenerAttribute {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type ListenerAttributes = ListenerAttribute[];
export interface DescribeListenerAttributesOutput {
    Attributes?: ListenerAttribute[] | undefined;
}
export interface DescribeListenerCertificatesInput {
    ListenerArn?: string | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export interface DescribeListenerCertificatesOutput {
    Certificates?: Certificate[] | undefined;
    NextMarker?: string | undefined;
}
export type ListenerArns = string[];
export interface DescribeListenersInput {
    LoadBalancerArn?: string | undefined;
    ListenerArns?: string[] | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export interface DescribeListenersOutput {
    Listeners?: (Listener & {
        DefaultActions: (Action & {
            Type: ActionTypeEnum;
            AuthenticateOidcConfig: AuthenticateOidcActionConfig & {
                Issuer: AuthenticateOidcActionIssuer;
                AuthorizationEndpoint: AuthenticateOidcActionAuthorizationEndpoint;
                TokenEndpoint: AuthenticateOidcActionTokenEndpoint;
                UserInfoEndpoint: AuthenticateOidcActionUserInfoEndpoint;
                ClientId: AuthenticateOidcActionClientId;
            };
            AuthenticateCognitoConfig: AuthenticateCognitoActionConfig & {
                UserPoolArn: AuthenticateCognitoActionUserPoolArn;
                UserPoolClientId: AuthenticateCognitoActionUserPoolClientId;
                UserPoolDomain: AuthenticateCognitoActionUserPoolDomain;
            };
            RedirectConfig: RedirectActionConfig & {
                StatusCode: RedirectActionStatusCodeEnum;
            };
            FixedResponseConfig: FixedResponseActionConfig & {
                StatusCode: FixedResponseActionStatusCode;
            };
            JwtValidationConfig: JwtValidationActionConfig & {
                JwksEndpoint: JwtValidationActionJwksEndpoint;
                Issuer: JwtValidationActionIssuer;
                AdditionalClaims: (JwtValidationActionAdditionalClaim & {
                    Format: JwtValidationActionAdditionalClaimFormatEnum;
                    Name: JwtValidationActionAdditionalClaimName;
                    Values: JwtValidationActionAdditionalClaimValues;
                })[];
            };
        })[];
    })[] | undefined;
    NextMarker?: string | undefined;
}
export interface DescribeLoadBalancerAttributesInput {
    LoadBalancerArn?: string | undefined;
}
export type LoadBalancerAttributeKey = string;
export type LoadBalancerAttributeValue = string;
export interface LoadBalancerAttribute {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type LoadBalancerAttributes = LoadBalancerAttribute[];
export interface DescribeLoadBalancerAttributesOutput {
    Attributes?: LoadBalancerAttribute[] | undefined;
}
export type LoadBalancerNames = string[];
export interface DescribeLoadBalancersInput {
    LoadBalancerArns?: string[] | undefined;
    Names?: string[] | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export interface DescribeLoadBalancersOutput {
    LoadBalancers?: LoadBalancer[] | undefined;
    NextMarker?: string | undefined;
}
export type RuleArns = string[];
export interface DescribeRulesInput {
    ListenerArn?: string | undefined;
    RuleArns?: string[] | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export interface DescribeRulesOutput {
    Rules?: (Rule & {
        Actions: (Action & {
            Type: ActionTypeEnum;
            AuthenticateOidcConfig: AuthenticateOidcActionConfig & {
                Issuer: AuthenticateOidcActionIssuer;
                AuthorizationEndpoint: AuthenticateOidcActionAuthorizationEndpoint;
                TokenEndpoint: AuthenticateOidcActionTokenEndpoint;
                UserInfoEndpoint: AuthenticateOidcActionUserInfoEndpoint;
                ClientId: AuthenticateOidcActionClientId;
            };
            AuthenticateCognitoConfig: AuthenticateCognitoActionConfig & {
                UserPoolArn: AuthenticateCognitoActionUserPoolArn;
                UserPoolClientId: AuthenticateCognitoActionUserPoolClientId;
                UserPoolDomain: AuthenticateCognitoActionUserPoolDomain;
            };
            RedirectConfig: RedirectActionConfig & {
                StatusCode: RedirectActionStatusCodeEnum;
            };
            FixedResponseConfig: FixedResponseActionConfig & {
                StatusCode: FixedResponseActionStatusCode;
            };
            JwtValidationConfig: JwtValidationActionConfig & {
                JwksEndpoint: JwtValidationActionJwksEndpoint;
                Issuer: JwtValidationActionIssuer;
                AdditionalClaims: (JwtValidationActionAdditionalClaim & {
                    Format: JwtValidationActionAdditionalClaimFormatEnum;
                    Name: JwtValidationActionAdditionalClaimName;
                    Values: JwtValidationActionAdditionalClaimValues;
                })[];
            };
        })[];
        Transforms: (RuleTransform & {
            Type: TransformTypeEnum;
            HostHeaderRewriteConfig: HostHeaderRewriteConfig & {
                Rewrites: (RewriteConfig & {
                    Regex: StringValue;
                    Replace: StringValue;
                })[];
            };
            UrlRewriteConfig: UrlRewriteConfig & {
                Rewrites: (RewriteConfig & {
                    Regex: StringValue;
                    Replace: StringValue;
                })[];
            };
        })[];
    })[] | undefined;
    NextMarker?: string | undefined;
}
export type SslPolicyNames = string[];
export interface DescribeSSLPoliciesInput {
    Names?: string[] | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
    LoadBalancerType?: LoadBalancerTypeEnum | undefined;
}
export type SslProtocol = string;
export type SslProtocols = string[];
export type CipherName = string;
export type CipherPriority = number;
export interface Cipher {
    Name?: string | undefined;
    Priority?: number | undefined;
}
export type Ciphers = Cipher[];
export interface SslPolicy {
    SslProtocols?: string[] | undefined;
    Ciphers?: Cipher[] | undefined;
    Name?: string | undefined;
    SupportedLoadBalancerTypes?: string[] | undefined;
}
export type SslPolicies = SslPolicy[];
export interface DescribeSSLPoliciesOutput {
    SslPolicies?: SslPolicy[] | undefined;
    NextMarker?: string | undefined;
}
export interface DescribeTagsInput {
    ResourceArns?: string[] | undefined;
}
export interface TagDescription {
    ResourceArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type TagDescriptions = TagDescription[];
export interface DescribeTagsOutput {
    TagDescriptions?: (TagDescription & {
        Tags: (Tag & {
            Key: TagKey;
        })[];
    })[] | undefined;
}
export interface DescribeTargetGroupAttributesInput {
    TargetGroupArn?: string | undefined;
}
export type TargetGroupAttributeKey = string;
export type TargetGroupAttributeValue = string;
export interface TargetGroupAttribute {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TargetGroupAttributes = TargetGroupAttribute[];
export interface DescribeTargetGroupAttributesOutput {
    Attributes?: TargetGroupAttribute[] | undefined;
}
export type TargetGroupArns = string[];
export type TargetGroupNames = string[];
export interface DescribeTargetGroupsInput {
    LoadBalancerArn?: string | undefined;
    TargetGroupArns?: string[] | undefined;
    Names?: string[] | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export interface DescribeTargetGroupsOutput {
    TargetGroups?: TargetGroup[] | undefined;
    NextMarker?: string | undefined;
}
export type DescribeTargetHealthInputIncludeEnum = "AnomalyDetection" | "All" | (string & {});
export type ListOfDescribeTargetHealthIncludeOptions = DescribeTargetHealthInputIncludeEnum[];
export interface DescribeTargetHealthInput {
    TargetGroupArn?: string | undefined;
    Targets?: TargetDescription[] | undefined;
    Include?: DescribeTargetHealthInputIncludeEnum[] | undefined;
}
export type TargetHealthStateEnum = "initial" | "healthy" | "unhealthy" | "unhealthy.draining" | "unused" | "draining" | "unavailable" | (string & {});
export type TargetHealthReasonEnum = "Elb.RegistrationInProgress" | "Elb.InitialHealthChecking" | "Target.ResponseCodeMismatch" | "Target.Timeout" | "Target.FailedHealthChecks" | "Target.NotRegistered" | "Target.NotInUse" | "Target.DeregistrationInProgress" | "Target.InvalidState" | "Target.IpUnusable" | "Target.HealthCheckDisabled" | "Elb.InternalError" | (string & {});
export type Description = string;
export interface TargetHealth {
    State?: TargetHealthStateEnum | undefined;
    Reason?: TargetHealthReasonEnum | undefined;
    Description?: string | undefined;
}
export type AnomalyResultEnum = "anomalous" | "normal" | (string & {});
export type MitigationInEffectEnum = "yes" | "no" | (string & {});
export interface AnomalyDetection {
    Result?: AnomalyResultEnum | undefined;
    MitigationInEffect?: MitigationInEffectEnum | undefined;
}
export type TargetAdministrativeOverrideStateEnum = "unknown" | "no_override" | "zonal_shift_active" | "zonal_shift_delegated_to_dns" | (string & {});
export type TargetAdministrativeOverrideReasonEnum = "AdministrativeOverride.Unknown" | "AdministrativeOverride.NoOverride" | "AdministrativeOverride.ZonalShiftActive" | "AdministrativeOverride.ZonalShiftDelegatedToDns" | (string & {});
export interface AdministrativeOverride {
    State?: TargetAdministrativeOverrideStateEnum | undefined;
    Reason?: TargetAdministrativeOverrideReasonEnum | undefined;
    Description?: string | undefined;
}
export interface TargetHealthDescription {
    Target?: TargetDescription | undefined;
    HealthCheckPort?: string | undefined;
    TargetHealth?: TargetHealth | undefined;
    AnomalyDetection?: AnomalyDetection | undefined;
    AdministrativeOverride?: AdministrativeOverride | undefined;
}
export type TargetHealthDescriptions = TargetHealthDescription[];
export interface DescribeTargetHealthOutput {
    TargetHealthDescriptions?: (TargetHealthDescription & {
        Target: TargetDescription & {
            Id: TargetId;
        };
    })[] | undefined;
}
export interface DescribeTrustStoreAssociationsInput {
    TrustStoreArn?: string | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export type TrustStoreAssociationResourceArn = string;
export interface TrustStoreAssociation {
    ResourceArn?: string | undefined;
}
export type TrustStoreAssociations = TrustStoreAssociation[];
export interface DescribeTrustStoreAssociationsOutput {
    TrustStoreAssociations?: TrustStoreAssociation[] | undefined;
    NextMarker?: string | undefined;
}
export type RevocationIds = number[];
export interface DescribeTrustStoreRevocationsInput {
    TrustStoreArn?: string | undefined;
    RevocationIds?: number[] | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export interface DescribeTrustStoreRevocation {
    TrustStoreArn?: string | undefined;
    RevocationId?: number | undefined;
    RevocationType?: RevocationType | undefined;
    NumberOfRevokedEntries?: number | undefined;
}
export type DescribeTrustStoreRevocationResponse = DescribeTrustStoreRevocation[];
export interface DescribeTrustStoreRevocationsOutput {
    TrustStoreRevocations?: DescribeTrustStoreRevocation[] | undefined;
    NextMarker?: string | undefined;
}
export type TrustStoreArns = string[];
export type TrustStoreNames = string[];
export interface DescribeTrustStoresInput {
    TrustStoreArns?: string[] | undefined;
    Names?: string[] | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export interface DescribeTrustStoresOutput {
    TrustStores?: TrustStore[] | undefined;
    NextMarker?: string | undefined;
}
export interface GetResourcePolicyInput {
    ResourceArn?: string | undefined;
}
export type Policy = string;
export interface GetResourcePolicyOutput {
    Policy?: string | undefined;
}
export interface GetTrustStoreCaCertificatesBundleInput {
    TrustStoreArn?: string | undefined;
}
export type Location = string;
export interface GetTrustStoreCaCertificatesBundleOutput {
    Location?: string | undefined;
}
export interface GetTrustStoreRevocationContentInput {
    TrustStoreArn?: string | undefined;
    RevocationId?: number | undefined;
}
export interface GetTrustStoreRevocationContentOutput {
    Location?: string | undefined;
}
export type ResetCapacityReservation = boolean;
export interface ModifyCapacityReservationInput {
    LoadBalancerArn?: string | undefined;
    MinimumLoadBalancerCapacity?: MinimumLoadBalancerCapacity | undefined;
    ResetCapacityReservation?: boolean | undefined;
}
export interface ModifyCapacityReservationOutput {
    LastModifiedTime?: Date | undefined;
    DecreaseRequestsRemaining?: number | undefined;
    MinimumLoadBalancerCapacity?: MinimumLoadBalancerCapacity | undefined;
    CapacityReservationState?: ZonalCapacityReservationState[] | undefined;
}
export type RemoveIpamPoolEnum = "ipv4" | (string & {});
export type RemoveIpamPools = RemoveIpamPoolEnum[];
export interface ModifyIpPoolsInput {
    LoadBalancerArn?: string | undefined;
    IpamPools?: IpamPools | undefined;
    RemoveIpamPools?: RemoveIpamPoolEnum[] | undefined;
}
export interface ModifyIpPoolsOutput {
    IpamPools?: IpamPools | undefined;
}
export interface ModifyListenerInput {
    ListenerArn?: string | undefined;
    Port?: number | undefined;
    Protocol?: ProtocolEnum | undefined;
    SslPolicy?: string | undefined;
    Certificates?: Certificate[] | undefined;
    DefaultActions?: Action[] | undefined;
    AlpnPolicy?: string[] | undefined;
    MutualAuthentication?: MutualAuthenticationAttributes | undefined;
}
export interface ModifyListenerOutput {
    Listeners?: (Listener & {
        DefaultActions: (Action & {
            Type: ActionTypeEnum;
            AuthenticateOidcConfig: AuthenticateOidcActionConfig & {
                Issuer: AuthenticateOidcActionIssuer;
                AuthorizationEndpoint: AuthenticateOidcActionAuthorizationEndpoint;
                TokenEndpoint: AuthenticateOidcActionTokenEndpoint;
                UserInfoEndpoint: AuthenticateOidcActionUserInfoEndpoint;
                ClientId: AuthenticateOidcActionClientId;
            };
            AuthenticateCognitoConfig: AuthenticateCognitoActionConfig & {
                UserPoolArn: AuthenticateCognitoActionUserPoolArn;
                UserPoolClientId: AuthenticateCognitoActionUserPoolClientId;
                UserPoolDomain: AuthenticateCognitoActionUserPoolDomain;
            };
            RedirectConfig: RedirectActionConfig & {
                StatusCode: RedirectActionStatusCodeEnum;
            };
            FixedResponseConfig: FixedResponseActionConfig & {
                StatusCode: FixedResponseActionStatusCode;
            };
            JwtValidationConfig: JwtValidationActionConfig & {
                JwksEndpoint: JwtValidationActionJwksEndpoint;
                Issuer: JwtValidationActionIssuer;
                AdditionalClaims: (JwtValidationActionAdditionalClaim & {
                    Format: JwtValidationActionAdditionalClaimFormatEnum;
                    Name: JwtValidationActionAdditionalClaimName;
                    Values: JwtValidationActionAdditionalClaimValues;
                })[];
            };
        })[];
    })[] | undefined;
}
export interface ModifyListenerAttributesInput {
    ListenerArn?: string | undefined;
    Attributes?: ListenerAttribute[] | undefined;
}
export interface ModifyListenerAttributesOutput {
    Attributes?: ListenerAttribute[] | undefined;
}
export interface ModifyLoadBalancerAttributesInput {
    LoadBalancerArn?: string | undefined;
    Attributes?: LoadBalancerAttribute[] | undefined;
}
export interface ModifyLoadBalancerAttributesOutput {
    Attributes?: LoadBalancerAttribute[] | undefined;
}
export type ResetTransforms = boolean;
export interface ModifyRuleInput {
    RuleArn?: string | undefined;
    Conditions?: RuleCondition[] | undefined;
    Actions?: Action[] | undefined;
    Transforms?: RuleTransform[] | undefined;
    ResetTransforms?: boolean | undefined;
}
export interface ModifyRuleOutput {
    Rules?: (Rule & {
        Actions: (Action & {
            Type: ActionTypeEnum;
            AuthenticateOidcConfig: AuthenticateOidcActionConfig & {
                Issuer: AuthenticateOidcActionIssuer;
                AuthorizationEndpoint: AuthenticateOidcActionAuthorizationEndpoint;
                TokenEndpoint: AuthenticateOidcActionTokenEndpoint;
                UserInfoEndpoint: AuthenticateOidcActionUserInfoEndpoint;
                ClientId: AuthenticateOidcActionClientId;
            };
            AuthenticateCognitoConfig: AuthenticateCognitoActionConfig & {
                UserPoolArn: AuthenticateCognitoActionUserPoolArn;
                UserPoolClientId: AuthenticateCognitoActionUserPoolClientId;
                UserPoolDomain: AuthenticateCognitoActionUserPoolDomain;
            };
            RedirectConfig: RedirectActionConfig & {
                StatusCode: RedirectActionStatusCodeEnum;
            };
            FixedResponseConfig: FixedResponseActionConfig & {
                StatusCode: FixedResponseActionStatusCode;
            };
            JwtValidationConfig: JwtValidationActionConfig & {
                JwksEndpoint: JwtValidationActionJwksEndpoint;
                Issuer: JwtValidationActionIssuer;
                AdditionalClaims: (JwtValidationActionAdditionalClaim & {
                    Format: JwtValidationActionAdditionalClaimFormatEnum;
                    Name: JwtValidationActionAdditionalClaimName;
                    Values: JwtValidationActionAdditionalClaimValues;
                })[];
            };
        })[];
        Transforms: (RuleTransform & {
            Type: TransformTypeEnum;
            HostHeaderRewriteConfig: HostHeaderRewriteConfig & {
                Rewrites: (RewriteConfig & {
                    Regex: StringValue;
                    Replace: StringValue;
                })[];
            };
            UrlRewriteConfig: UrlRewriteConfig & {
                Rewrites: (RewriteConfig & {
                    Regex: StringValue;
                    Replace: StringValue;
                })[];
            };
        })[];
    })[] | undefined;
}
export interface ModifyTargetGroupInput {
    TargetGroupArn?: string | undefined;
    HealthCheckProtocol?: ProtocolEnum | undefined;
    HealthCheckPort?: string | undefined;
    HealthCheckPath?: string | undefined;
    HealthCheckEnabled?: boolean | undefined;
    HealthCheckIntervalSeconds?: number | undefined;
    HealthCheckTimeoutSeconds?: number | undefined;
    HealthyThresholdCount?: number | undefined;
    UnhealthyThresholdCount?: number | undefined;
    Matcher?: Matcher | undefined;
}
export interface ModifyTargetGroupOutput {
    TargetGroups?: TargetGroup[] | undefined;
}
export interface ModifyTargetGroupAttributesInput {
    TargetGroupArn?: string | undefined;
    Attributes?: TargetGroupAttribute[] | undefined;
}
export interface ModifyTargetGroupAttributesOutput {
    Attributes?: TargetGroupAttribute[] | undefined;
}
export interface ModifyTrustStoreInput {
    TrustStoreArn?: string | undefined;
    CaCertificatesBundleS3Bucket?: string | undefined;
    CaCertificatesBundleS3Key?: string | undefined;
    CaCertificatesBundleS3ObjectVersion?: string | undefined;
}
export interface ModifyTrustStoreOutput {
    TrustStores?: TrustStore[] | undefined;
}
export interface RegisterTargetsInput {
    TargetGroupArn?: string | undefined;
    Targets?: TargetDescription[] | undefined;
}
export interface RegisterTargetsOutput {
}
export interface RemoveListenerCertificatesInput {
    ListenerArn?: string | undefined;
    Certificates?: Certificate[] | undefined;
}
export interface RemoveListenerCertificatesOutput {
}
export type TagKeys = string[];
export interface RemoveTagsInput {
    ResourceArns?: string[] | undefined;
    TagKeys?: string[] | undefined;
}
export interface RemoveTagsOutput {
}
export interface RemoveTrustStoreRevocationsInput {
    TrustStoreArn?: string | undefined;
    RevocationIds?: number[] | undefined;
}
export interface RemoveTrustStoreRevocationsOutput {
}
export interface SetIpAddressTypeInput {
    LoadBalancerArn?: string | undefined;
    IpAddressType?: IpAddressType | undefined;
}
export interface SetIpAddressTypeOutput {
    IpAddressType?: IpAddressType | undefined;
}
export interface RulePriorityPair {
    RuleArn?: string | undefined;
    Priority?: number | undefined;
}
export type RulePriorityList = RulePriorityPair[];
export interface SetRulePrioritiesInput {
    RulePriorities?: RulePriorityPair[] | undefined;
}
export interface SetRulePrioritiesOutput {
    Rules?: (Rule & {
        Actions: (Action & {
            Type: ActionTypeEnum;
            AuthenticateOidcConfig: AuthenticateOidcActionConfig & {
                Issuer: AuthenticateOidcActionIssuer;
                AuthorizationEndpoint: AuthenticateOidcActionAuthorizationEndpoint;
                TokenEndpoint: AuthenticateOidcActionTokenEndpoint;
                UserInfoEndpoint: AuthenticateOidcActionUserInfoEndpoint;
                ClientId: AuthenticateOidcActionClientId;
            };
            AuthenticateCognitoConfig: AuthenticateCognitoActionConfig & {
                UserPoolArn: AuthenticateCognitoActionUserPoolArn;
                UserPoolClientId: AuthenticateCognitoActionUserPoolClientId;
                UserPoolDomain: AuthenticateCognitoActionUserPoolDomain;
            };
            RedirectConfig: RedirectActionConfig & {
                StatusCode: RedirectActionStatusCodeEnum;
            };
            FixedResponseConfig: FixedResponseActionConfig & {
                StatusCode: FixedResponseActionStatusCode;
            };
            JwtValidationConfig: JwtValidationActionConfig & {
                JwksEndpoint: JwtValidationActionJwksEndpoint;
                Issuer: JwtValidationActionIssuer;
                AdditionalClaims: (JwtValidationActionAdditionalClaim & {
                    Format: JwtValidationActionAdditionalClaimFormatEnum;
                    Name: JwtValidationActionAdditionalClaimName;
                    Values: JwtValidationActionAdditionalClaimValues;
                })[];
            };
        })[];
        Transforms: (RuleTransform & {
            Type: TransformTypeEnum;
            HostHeaderRewriteConfig: HostHeaderRewriteConfig & {
                Rewrites: (RewriteConfig & {
                    Regex: StringValue;
                    Replace: StringValue;
                })[];
            };
            UrlRewriteConfig: UrlRewriteConfig & {
                Rewrites: (RewriteConfig & {
                    Regex: StringValue;
                    Replace: StringValue;
                })[];
            };
        })[];
    })[] | undefined;
}
export type EnforceSecurityGroupInboundRulesOnPrivateLinkTrafficEnum = "on" | "off" | (string & {});
export interface SetSecurityGroupsInput {
    LoadBalancerArn?: string | undefined;
    SecurityGroups?: string[] | undefined;
    EnforceSecurityGroupInboundRulesOnPrivateLinkTraffic?: EnforceSecurityGroupInboundRulesOnPrivateLinkTrafficEnum | undefined;
}
export interface SetSecurityGroupsOutput {
    SecurityGroupIds?: string[] | undefined;
    EnforceSecurityGroupInboundRulesOnPrivateLinkTraffic?: EnforceSecurityGroupInboundRulesOnPrivateLinkTrafficEnum | undefined;
}
export interface SetSubnetsInput {
    LoadBalancerArn?: string | undefined;
    Subnets?: string[] | undefined;
    SubnetMappings?: SubnetMapping[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    EnablePrefixForIpv6SourceNat?: EnablePrefixForIpv6SourceNatEnum | undefined;
}
export interface SetSubnetsOutput {
    AvailabilityZones?: AvailabilityZone[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    EnablePrefixForIpv6SourceNat?: EnablePrefixForIpv6SourceNatEnum | undefined;
}
export type ErrorDescription = string;
export type AddListenerCertificatesError = CertificateNotFoundException | ListenerNotFoundException | TooManyCertificatesException | CommonErrors;
/**
 * Adds the specified SSL server certificate to the certificate list for the specified HTTPS
 * or TLS listener.
 *
 * If the certificate in already in the certificate list, the call is successful but the
 * certificate is not added again.
 *
 * For more information, see SSL
 * certificates in the *Application Load Balancers Guide* or Server
 * certificates in the *Network Load Balancers Guide*.
 */
export declare const addListenerCertificates: API.OperationMethod<AddListenerCertificatesInput & RegionInput, AddListenerCertificatesOutput, AddListenerCertificatesError, Credentials | HttpClient.HttpClient>;
export type AddTagsError = DuplicateTagKeysException | ListenerNotFoundException | LoadBalancerNotFoundException | RuleNotFoundException | TargetGroupNotFoundException | TooManyTagsException | TrustStoreNotFoundException | CommonErrors;
/**
 * Adds the specified tags to the specified Elastic Load Balancing resource. You can tag your
 * Application Load Balancers, Network Load Balancers, Gateway Load Balancers, target groups,
 * trust stores, listeners, and rules.
 *
 * Each tag consists of a key and an optional value. If a resource already has a tag with the
 * same key, `AddTags` updates its value.
 */
export declare const addTags: API.OperationMethod<AddTagsInput & RegionInput, AddTagsOutput, AddTagsError, Credentials | HttpClient.HttpClient>;
export type AddTrustStoreRevocationsError = InvalidRevocationContentException | RevocationContentNotFoundException | TooManyTrustStoreRevocationEntriesException | TrustStoreNotFoundException | CommonErrors;
/**
 * Adds the specified revocation file to the specified trust store.
 */
export declare const addTrustStoreRevocations: API.OperationMethod<AddTrustStoreRevocationsInput & RegionInput, AddTrustStoreRevocationsOutput, AddTrustStoreRevocationsError, Credentials | HttpClient.HttpClient>;
export type CreateListenerError = ALPNPolicyNotSupportedException | CertificateNotFoundException | DuplicateListenerException | IncompatibleProtocolsException | InvalidConfigurationRequestException | InvalidLoadBalancerActionException | LoadBalancerNotFoundException | SSLPolicyNotFoundException | TargetGroupAssociationLimitException | TargetGroupNotFoundException | TooManyActionsException | TooManyCertificatesException | TooManyListenersException | TooManyRegistrationsForTargetIdException | TooManyTagsException | TooManyTargetsException | TooManyUniqueTargetGroupsPerLoadBalancerException | TrustStoreNotFoundException | TrustStoreNotReadyException | UnsupportedProtocolException | CommonErrors;
/**
 * Creates a listener for the specified Application Load Balancer, Network Load Balancer, or
 * Gateway Load Balancer.
 *
 * For more information, see the following:
 *
 * - Listeners for
 * your Application Load Balancers
 *
 * - Listeners for
 * your Network Load Balancers
 *
 * - Listeners for your
 * Gateway Load Balancers
 *
 * This operation is idempotent, which means that it completes at most one time. If you
 * attempt to create multiple listeners with the same settings, each call succeeds.
 */
export declare const createListener: API.OperationMethod<CreateListenerInput & RegionInput, CreateListenerOutput, CreateListenerError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerError = AllocationIdNotFoundException | AvailabilityZoneNotSupportedException | DuplicateLoadBalancerNameException | DuplicateTagKeysException | InvalidConfigurationRequestException | InvalidSchemeException | InvalidSecurityGroupException | InvalidSubnetException | OperationNotPermittedException | ResourceInUseException | SubnetNotFoundException | TooManyLoadBalancersException | TooManyTagsException | CommonErrors;
/**
 * Creates an Application Load Balancer, Network Load Balancer, or Gateway Load
 * Balancer.
 *
 * For more information, see the following:
 *
 * - Application Load Balancers
 *
 * - Network Load
 * Balancers
 *
 * - Gateway Load
 * Balancers
 *
 * This operation is idempotent, which means that it completes at most one time. If you
 * attempt to create multiple load balancers with the same settings, each call succeeds.
 */
export declare const createLoadBalancer: API.OperationMethod<CreateLoadBalancerInput & RegionInput, CreateLoadBalancerOutput, CreateLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type CreateRuleError = IncompatibleProtocolsException | InvalidConfigurationRequestException | InvalidLoadBalancerActionException | ListenerNotFoundException | PriorityInUseException | TargetGroupAssociationLimitException | TargetGroupNotFoundException | TooManyActionsException | TooManyRegistrationsForTargetIdException | TooManyRulesException | TooManyTagsException | TooManyTargetGroupsException | TooManyTargetsException | TooManyUniqueTargetGroupsPerLoadBalancerException | UnsupportedProtocolException | CommonErrors;
/**
 * Creates a rule for the specified listener. The listener must be associated with an
 * Application Load Balancer or a dual-stack Network Load Balancer.
 *
 * Each rule consists of a priority, one or more actions, and one or more conditions. Rules
 * are evaluated in priority order, from the lowest value to the highest value. When the
 * conditions for a rule are met, its actions are performed. If the conditions for no rules are
 * met, the actions for the default rule are performed. For more information, see Listener rules in the *Application Load Balancers Guide* or
 * Listener rules in the *Network Load Balancers Guide*.
 */
export declare const createRule: API.OperationMethod<CreateRuleInput & RegionInput, CreateRuleOutput, CreateRuleError, Credentials | HttpClient.HttpClient>;
export type CreateTargetGroupError = DuplicateTargetGroupNameException | InvalidConfigurationRequestException | TooManyTagsException | TooManyTargetGroupsException | CommonErrors;
/**
 * Creates a target group.
 *
 * For more information, see the following:
 *
 * - Target
 * groups for your Application Load Balancers
 *
 * - Target groups
 * for your Network Load Balancers
 *
 * - Target groups for your
 * Gateway Load Balancers
 *
 * This operation is idempotent, which means that it completes at most one time. If you
 * attempt to create multiple target groups with the same settings, each call succeeds.
 */
export declare const createTargetGroup: API.OperationMethod<CreateTargetGroupInput & RegionInput, CreateTargetGroupOutput, CreateTargetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateTrustStoreError = CaCertificatesBundleNotFoundException | DuplicateTagKeysException | DuplicateTrustStoreNameException | InvalidCaCertificatesBundleException | TooManyTagsException | TooManyTrustStoresException | CommonErrors;
/**
 * Creates a trust store.
 *
 * For more information, see Mutual TLS for Application Load Balancers.
 */
export declare const createTrustStore: API.OperationMethod<CreateTrustStoreInput & RegionInput, CreateTrustStoreOutput, CreateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteListenerError = ListenerNotFoundException | ResourceInUseException | CommonErrors;
/**
 * Deletes the specified listener.
 *
 * Alternatively, your listener is deleted when you delete the load balancer to which it is
 * attached.
 */
export declare const deleteListener: API.OperationMethod<DeleteListenerInput & RegionInput, DeleteListenerOutput, DeleteListenerError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerError = LoadBalancerNotFoundException | OperationNotPermittedException | ResourceInUseException | CommonErrors;
/**
 * Deletes the specified Application Load Balancer, Network Load Balancer, or Gateway Load
 * Balancer. Deleting a load balancer also deletes its listeners.
 *
 * You can't delete a load balancer if deletion protection is enabled. If the load balancer
 * does not exist or has already been deleted, the call succeeds.
 *
 * Deleting a load balancer does not affect its registered targets. For example, your EC2
 * instances continue to run and are still registered to their target groups. If you no longer
 * need these EC2 instances, you can stop or terminate them.
 */
export declare const deleteLoadBalancer: API.OperationMethod<DeleteLoadBalancerInput & RegionInput, DeleteLoadBalancerOutput, DeleteLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = OperationNotPermittedException | RuleNotFoundException | CommonErrors;
/**
 * Deletes the specified rule.
 *
 * You can't delete the default rule.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleInput & RegionInput, DeleteRuleOutput, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteSharedTrustStoreAssociationError = DeleteAssociationSameAccountException | TrustStoreAssociationNotFoundException | TrustStoreNotFoundException | CommonErrors;
/**
 * Deletes a shared trust store association.
 */
export declare const deleteSharedTrustStoreAssociation: API.OperationMethod<DeleteSharedTrustStoreAssociationInput & RegionInput, DeleteSharedTrustStoreAssociationOutput, DeleteSharedTrustStoreAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteTargetGroupError = ResourceInUseException | CommonErrors;
/**
 * Deletes the specified target group.
 *
 * You can delete a target group if it is not referenced by any actions. Deleting a target
 * group also deletes any associated health checks. Deleting a target group does not affect its
 * registered targets. For example, any EC2 instances continue to run until you stop or terminate
 * them.
 */
export declare const deleteTargetGroup: API.OperationMethod<DeleteTargetGroupInput & RegionInput, DeleteTargetGroupOutput, DeleteTargetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustStoreError = TrustStoreInUseException | TrustStoreNotFoundException | CommonErrors;
/**
 * Deletes a trust store.
 */
export declare const deleteTrustStore: API.OperationMethod<DeleteTrustStoreInput & RegionInput, DeleteTrustStoreOutput, DeleteTrustStoreError, Credentials | HttpClient.HttpClient>;
export type DeregisterTargetsError = InvalidTargetException | TargetGroupNotFoundException | CommonErrors;
/**
 * Deregisters the specified targets from the specified target group. After the targets are
 * deregistered, they no longer receive traffic from the load balancer.
 *
 * The load balancer stops sending requests to targets that are deregistering, but uses
 * connection draining to ensure that in-flight traffic completes on the existing connections.
 * This deregistration delay is configured by default but can be updated for each target group.
 *
 * For more information, see the following:
 *
 * -
 * Deregistration delay in the *Application Load Balancers User Guide*
 *
 * -
 * Deregistration delay in the *Network Load Balancers User Guide*
 *
 * -
 * Deregistration delay in the *Gateway Load Balancers User Guide*
 *
 * Note: If the specified target does not exist, the action returns successfully.
 */
export declare const deregisterTargets: API.OperationMethod<DeregisterTargetsInput & RegionInput, DeregisterTargetsOutput, DeregisterTargetsError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountLimitsError = CommonErrors;
/**
 * Describes the current Elastic Load Balancing resource limits for your Amazon Web Services
 * account.
 *
 * For more information, see the following:
 *
 * - Quotas for your
 * Application Load Balancers
 *
 * - Quotas for your
 * Network Load Balancers
 *
 * - Quotas for your Gateway
 * Load Balancers
 */
export declare const describeAccountLimits: API.PaginatedOperationMethod<DescribeAccountLimitsInput & RegionInput, DescribeAccountLimitsOutput, DescribeAccountLimitsError, Credentials | HttpClient.HttpClient, Limit>;
export type DescribeCapacityReservationError = LoadBalancerNotFoundException | CommonErrors;
/**
 * Describes the capacity reservation status for the specified load balancer.
 */
export declare const describeCapacityReservation: API.OperationMethod<DescribeCapacityReservationInput & RegionInput, DescribeCapacityReservationOutput, DescribeCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type DescribeListenerAttributesError = ListenerNotFoundException | CommonErrors;
/**
 * Describes the attributes for the specified listener.
 */
export declare const describeListenerAttributes: API.OperationMethod<DescribeListenerAttributesInput & RegionInput, DescribeListenerAttributesOutput, DescribeListenerAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeListenerCertificatesError = ListenerNotFoundException | CommonErrors;
/**
 * Describes the default certificate and the certificate list for the specified HTTPS or TLS
 * listener.
 *
 * If the default certificate is also in the certificate list, it appears twice in the
 * results (once with `IsDefault` set to true and once with `IsDefault` set
 * to false).
 *
 * For more information, see SSL certificates in the *Application Load Balancers Guide* or
 * Server certificates in the Network Load Balancers
 * Guide.
 */
export declare const describeListenerCertificates: API.PaginatedOperationMethod<DescribeListenerCertificatesInput & RegionInput, DescribeListenerCertificatesOutput, DescribeListenerCertificatesError, Credentials | HttpClient.HttpClient, Certificate>;
export type DescribeListenersError = ListenerNotFoundException | LoadBalancerNotFoundException | UnsupportedProtocolException | CommonErrors;
/**
 * Describes the specified listeners or the listeners for the specified Application Load
 * Balancer, Network Load Balancer, or Gateway Load Balancer. You must specify either a load
 * balancer or one or more listeners.
 */
export declare const describeListeners: API.PaginatedOperationMethod<DescribeListenersInput & RegionInput, DescribeListenersOutput, DescribeListenersError, Credentials | HttpClient.HttpClient, Listener>;
export type DescribeLoadBalancerAttributesError = LoadBalancerNotFoundException | CommonErrors;
/**
 * Describes the attributes for the specified Application Load Balancer, Network Load
 * Balancer, or Gateway Load Balancer.
 *
 * For more information, see the following:
 *
 * - Load balancer attributes in the Application Load Balancers
 * Guide
 *
 * - Load balancer attributes in the Network Load Balancers
 * Guide
 *
 * - Load balancer attributes in the Gateway Load Balancers
 * Guide
 */
export declare const describeLoadBalancerAttributes: API.OperationMethod<DescribeLoadBalancerAttributesInput & RegionInput, DescribeLoadBalancerAttributesOutput, DescribeLoadBalancerAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancersError = LoadBalancerNotFoundException | CommonErrors;
/**
 * Describes the specified load balancers or all of your load balancers.
 */
export declare const describeLoadBalancers: API.PaginatedOperationMethod<DescribeLoadBalancersInput & RegionInput, DescribeLoadBalancersOutput, DescribeLoadBalancersError, Credentials | HttpClient.HttpClient, LoadBalancer>;
export type DescribeRulesError = ListenerNotFoundException | RuleNotFoundException | UnsupportedProtocolException | CommonErrors;
/**
 * Describes the specified rules or the rules for the specified listener. You must specify
 * either a listener or rules.
 */
export declare const describeRules: API.PaginatedOperationMethod<DescribeRulesInput & RegionInput, DescribeRulesOutput, DescribeRulesError, Credentials | HttpClient.HttpClient, Rule>;
export type DescribeSSLPoliciesError = SSLPolicyNotFoundException | CommonErrors;
/**
 * Describes the specified policies or all policies used for SSL negotiation.
 *
 * For more information, see Security policies in the *Application Load Balancers Guide* and
 * Security policies in the *Network Load Balancers Guide*.
 */
export declare const describeSSLPolicies: API.OperationMethod<DescribeSSLPoliciesInput & RegionInput, DescribeSSLPoliciesOutput, DescribeSSLPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeTagsError = ListenerNotFoundException | LoadBalancerNotFoundException | RuleNotFoundException | TargetGroupNotFoundException | TrustStoreNotFoundException | CommonErrors;
/**
 * Describes the tags for the specified Elastic Load Balancing resources. You can describe
 * the tags for one or more Application Load Balancers, Network Load Balancers, Gateway Load
 * Balancers, target groups, listeners, or rules.
 */
export declare const describeTags: API.OperationMethod<DescribeTagsInput & RegionInput, DescribeTagsOutput, DescribeTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeTargetGroupAttributesError = TargetGroupNotFoundException | CommonErrors;
/**
 * Describes the attributes for the specified target group.
 *
 * For more information, see the following:
 *
 * - Target group attributes in the Application Load Balancers
 * Guide
 *
 * - Target group attributes in the Network Load Balancers
 * Guide
 *
 * - Target group attributes in the Gateway Load Balancers
 * Guide
 */
export declare const describeTargetGroupAttributes: API.OperationMethod<DescribeTargetGroupAttributesInput & RegionInput, DescribeTargetGroupAttributesOutput, DescribeTargetGroupAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeTargetGroupsError = LoadBalancerNotFoundException | TargetGroupNotFoundException | CommonErrors;
/**
 * Describes the specified target groups or all of your target groups. By default, all target
 * groups are described. Alternatively, you can specify one of the following to filter the
 * results: the ARN of the load balancer, the names of one or more target groups, or the ARNs of
 * one or more target groups.
 */
export declare const describeTargetGroups: API.PaginatedOperationMethod<DescribeTargetGroupsInput & RegionInput, DescribeTargetGroupsOutput, DescribeTargetGroupsError, Credentials | HttpClient.HttpClient, TargetGroup>;
export type DescribeTargetHealthError = HealthUnavailableException | InvalidTargetException | TargetGroupNotFoundException | CommonErrors;
/**
 * Describes the health of the specified targets or all of your targets.
 */
export declare const describeTargetHealth: API.OperationMethod<DescribeTargetHealthInput & RegionInput, DescribeTargetHealthOutput, DescribeTargetHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeTrustStoreAssociationsError = TrustStoreNotFoundException | CommonErrors;
/**
 * Describes all resources associated with the specified trust store.
 */
export declare const describeTrustStoreAssociations: API.PaginatedOperationMethod<DescribeTrustStoreAssociationsInput & RegionInput, DescribeTrustStoreAssociationsOutput, DescribeTrustStoreAssociationsError, Credentials | HttpClient.HttpClient, TrustStoreAssociation>;
export type DescribeTrustStoreRevocationsError = RevocationIdNotFoundException | TrustStoreNotFoundException | CommonErrors;
/**
 * Describes the revocation files in use by the specified trust store or revocation
 * files.
 */
export declare const describeTrustStoreRevocations: API.PaginatedOperationMethod<DescribeTrustStoreRevocationsInput & RegionInput, DescribeTrustStoreRevocationsOutput, DescribeTrustStoreRevocationsError, Credentials | HttpClient.HttpClient, DescribeTrustStoreRevocation>;
export type DescribeTrustStoresError = TrustStoreNotFoundException | CommonErrors;
/**
 * Describes all trust stores for the specified account.
 */
export declare const describeTrustStores: API.PaginatedOperationMethod<DescribeTrustStoresInput & RegionInput, DescribeTrustStoresOutput, DescribeTrustStoresError, Credentials | HttpClient.HttpClient, TrustStore>;
export type GetResourcePolicyError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the resource policy for a specified resource.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyInput & RegionInput, GetResourcePolicyOutput, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetTrustStoreCaCertificatesBundleError = TrustStoreNotFoundException | CommonErrors;
/**
 * Retrieves the ca certificate bundle.
 *
 * This action returns a pre-signed S3 URI which is
 * active for ten minutes.
 */
export declare const getTrustStoreCaCertificatesBundle: API.OperationMethod<GetTrustStoreCaCertificatesBundleInput & RegionInput, GetTrustStoreCaCertificatesBundleOutput, GetTrustStoreCaCertificatesBundleError, Credentials | HttpClient.HttpClient>;
export type GetTrustStoreRevocationContentError = RevocationIdNotFoundException | TrustStoreNotFoundException | CommonErrors;
/**
 * Retrieves the specified revocation file.
 *
 * This action returns a pre-signed S3 URI which is
 * active for ten minutes.
 */
export declare const getTrustStoreRevocationContent: API.OperationMethod<GetTrustStoreRevocationContentInput & RegionInput, GetTrustStoreRevocationContentOutput, GetTrustStoreRevocationContentError, Credentials | HttpClient.HttpClient>;
export type ModifyCapacityReservationError = CapacityDecreaseRequestsLimitExceededException | CapacityReservationPendingException | CapacityUnitsLimitExceededException | InsufficientCapacityException | InvalidConfigurationRequestException | LoadBalancerNotFoundException | OperationNotPermittedException | PriorRequestNotCompleteException | CommonErrors;
/**
 * Modifies the capacity reservation of the specified load balancer.
 *
 * When modifying capacity reservation, you must include at least one `MinimumLoadBalancerCapacity`
 * or `ResetCapacityReservation`.
 */
export declare const modifyCapacityReservation: API.OperationMethod<ModifyCapacityReservationInput & RegionInput, ModifyCapacityReservationOutput, ModifyCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type ModifyIpPoolsError = LoadBalancerNotFoundException | CommonErrors;
/**
 * [Application Load Balancers] Modify the IP pool associated to a load balancer.
 */
export declare const modifyIpPools: API.OperationMethod<ModifyIpPoolsInput & RegionInput, ModifyIpPoolsOutput, ModifyIpPoolsError, Credentials | HttpClient.HttpClient>;
export type ModifyListenerError = ALPNPolicyNotSupportedException | CertificateNotFoundException | DuplicateListenerException | IncompatibleProtocolsException | InvalidConfigurationRequestException | InvalidLoadBalancerActionException | ListenerNotFoundException | SSLPolicyNotFoundException | TargetGroupAssociationLimitException | TargetGroupNotFoundException | TooManyActionsException | TooManyCertificatesException | TooManyListenersException | TooManyRegistrationsForTargetIdException | TooManyTargetsException | TooManyUniqueTargetGroupsPerLoadBalancerException | TrustStoreNotFoundException | TrustStoreNotReadyException | UnsupportedProtocolException | CommonErrors;
/**
 * Replaces the specified properties of the specified listener. Any properties that you do
 * not specify remain unchanged.
 *
 * Changing the protocol from HTTPS to HTTP, or from TLS to TCP, removes the security policy
 * and default certificate properties. If you change the protocol from HTTP to HTTPS, or from TCP
 * to TLS, you must add the security policy and default certificate properties.
 *
 * To add an item to a list, remove an item from a list, or update an item in a list, you
 * must provide the entire list. For example, to add an action, specify a list with the current
 * actions plus the new action.
 */
export declare const modifyListener: API.OperationMethod<ModifyListenerInput & RegionInput, ModifyListenerOutput, ModifyListenerError, Credentials | HttpClient.HttpClient>;
export type ModifyListenerAttributesError = InvalidConfigurationRequestException | ListenerNotFoundException | CommonErrors;
/**
 * Modifies the specified attributes of the specified listener.
 */
export declare const modifyListenerAttributes: API.OperationMethod<ModifyListenerAttributesInput & RegionInput, ModifyListenerAttributesOutput, ModifyListenerAttributesError, Credentials | HttpClient.HttpClient>;
export type ModifyLoadBalancerAttributesError = InvalidConfigurationRequestException | LoadBalancerNotFoundException | CommonErrors;
/**
 * Modifies the specified attributes of the specified Application Load Balancer, Network Load
 * Balancer, or Gateway Load Balancer.
 *
 * If any of the specified attributes can't be modified as requested, the call fails. Any
 * existing attributes that you do not modify retain their current values.
 */
export declare const modifyLoadBalancerAttributes: API.OperationMethod<ModifyLoadBalancerAttributesInput & RegionInput, ModifyLoadBalancerAttributesOutput, ModifyLoadBalancerAttributesError, Credentials | HttpClient.HttpClient>;
export type ModifyRuleError = IncompatibleProtocolsException | InvalidLoadBalancerActionException | OperationNotPermittedException | RuleNotFoundException | TargetGroupAssociationLimitException | TargetGroupNotFoundException | TooManyActionsException | TooManyRegistrationsForTargetIdException | TooManyTargetsException | TooManyUniqueTargetGroupsPerLoadBalancerException | UnsupportedProtocolException | CommonErrors;
/**
 * Replaces the specified properties of the specified rule. Any properties that you do not
 * specify are unchanged.
 *
 * To add an item to a list, remove an item from a list, or update an item in a list, you
 * must provide the entire list. For example, to add an action, specify a list with the current
 * actions plus the new action.
 */
export declare const modifyRule: API.OperationMethod<ModifyRuleInput & RegionInput, ModifyRuleOutput, ModifyRuleError, Credentials | HttpClient.HttpClient>;
export type ModifyTargetGroupError = InvalidConfigurationRequestException | TargetGroupNotFoundException | CommonErrors;
/**
 * Modifies the health checks used when evaluating the health state of the targets in the
 * specified target group.
 */
export declare const modifyTargetGroup: API.OperationMethod<ModifyTargetGroupInput & RegionInput, ModifyTargetGroupOutput, ModifyTargetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyTargetGroupAttributesError = InvalidConfigurationRequestException | TargetGroupNotFoundException | CommonErrors;
/**
 * Modifies the specified attributes of the specified target group.
 */
export declare const modifyTargetGroupAttributes: API.OperationMethod<ModifyTargetGroupAttributesInput & RegionInput, ModifyTargetGroupAttributesOutput, ModifyTargetGroupAttributesError, Credentials | HttpClient.HttpClient>;
export type ModifyTrustStoreError = CaCertificatesBundleNotFoundException | InvalidCaCertificatesBundleException | TrustStoreNotFoundException | CommonErrors;
/**
 * Update the ca certificate bundle for the specified trust store.
 */
export declare const modifyTrustStore: API.OperationMethod<ModifyTrustStoreInput & RegionInput, ModifyTrustStoreOutput, ModifyTrustStoreError, Credentials | HttpClient.HttpClient>;
export type RegisterTargetsError = InvalidTargetException | TargetGroupNotFoundException | TooManyRegistrationsForTargetIdException | TooManyTargetsException | CommonErrors;
/**
 * Registers the specified targets with the specified target group.
 *
 * If the target is an EC2 instance, it must be in the `running` state when you
 * register it.
 *
 * By default, the load balancer routes requests to registered targets using the protocol and
 * port for the target group. Alternatively, you can override the port for a target when you
 * register it. You can register each EC2 instance or IP address with the same target group
 * multiple times using different ports.
 *
 * For more information, see the following:
 *
 * - Register
 * targets for your Application Load Balancer
 *
 * - Register targets
 * for your Network Load Balancer
 *
 * - Register targets for your
 * Gateway Load Balancer
 */
export declare const registerTargets: API.OperationMethod<RegisterTargetsInput & RegionInput, RegisterTargetsOutput, RegisterTargetsError, Credentials | HttpClient.HttpClient>;
export type RemoveListenerCertificatesError = ListenerNotFoundException | OperationNotPermittedException | CommonErrors;
/**
 * Removes the specified certificate from the certificate list for the specified HTTPS or TLS
 * listener.
 */
export declare const removeListenerCertificates: API.OperationMethod<RemoveListenerCertificatesInput & RegionInput, RemoveListenerCertificatesOutput, RemoveListenerCertificatesError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = ListenerNotFoundException | LoadBalancerNotFoundException | RuleNotFoundException | TargetGroupNotFoundException | TooManyTagsException | TrustStoreNotFoundException | CommonErrors;
/**
 * Removes the specified tags from the specified Elastic Load Balancing resources. You can
 * remove the tags for one or more Application Load Balancers, Network Load Balancers, Gateway
 * Load Balancers, target groups, listeners, or rules.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsInput & RegionInput, RemoveTagsOutput, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type RemoveTrustStoreRevocationsError = RevocationIdNotFoundException | TrustStoreNotFoundException | CommonErrors;
/**
 * Removes the specified revocation file from the specified trust store.
 */
export declare const removeTrustStoreRevocations: API.OperationMethod<RemoveTrustStoreRevocationsInput & RegionInput, RemoveTrustStoreRevocationsOutput, RemoveTrustStoreRevocationsError, Credentials | HttpClient.HttpClient>;
export type SetIpAddressTypeError = InvalidConfigurationRequestException | InvalidSubnetException | LoadBalancerNotFoundException | CommonErrors;
/**
 * Sets the type of IP addresses used by the subnets of the specified load balancer.
 */
export declare const setIpAddressType: API.OperationMethod<SetIpAddressTypeInput & RegionInput, SetIpAddressTypeOutput, SetIpAddressTypeError, Credentials | HttpClient.HttpClient>;
export type SetRulePrioritiesError = OperationNotPermittedException | PriorityInUseException | RuleNotFoundException | CommonErrors;
/**
 * Sets the priorities of the specified rules.
 *
 * You can reorder the rules as long as there are no priority conflicts in the new order. Any
 * existing rules that you do not specify retain their current priority.
 */
export declare const setRulePriorities: API.OperationMethod<SetRulePrioritiesInput & RegionInput, SetRulePrioritiesOutput, SetRulePrioritiesError, Credentials | HttpClient.HttpClient>;
export type SetSecurityGroupsError = InvalidConfigurationRequestException | InvalidSecurityGroupException | LoadBalancerNotFoundException | CommonErrors;
/**
 * Associates the specified security groups with the specified Application Load Balancer or
 * Network Load Balancer. The specified security groups override the previously associated
 * security groups.
 *
 * You can't perform this operation on a Network Load Balancer unless you specified a
 * security group for the load balancer when you created it.
 *
 * You can't associate a security group with a Gateway Load Balancer.
 */
export declare const setSecurityGroups: API.OperationMethod<SetSecurityGroupsInput & RegionInput, SetSecurityGroupsOutput, SetSecurityGroupsError, Credentials | HttpClient.HttpClient>;
export type SetSubnetsError = AllocationIdNotFoundException | AvailabilityZoneNotSupportedException | CapacityReservationPendingException | InvalidConfigurationRequestException | InvalidSubnetException | LoadBalancerNotFoundException | SubnetNotFoundException | CommonErrors;
/**
 * Enables the Availability Zones for the specified public subnets for the specified
 * Application Load Balancer, Network Load Balancer or Gateway Load Balancer. The specified subnets
 * replace the previously enabled subnets.
 */
export declare const setSubnets: API.OperationMethod<SetSubnetsInput & RegionInput, SetSubnetsOutput, SetSubnetsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elastic-load-balancing-v2.d.ts.map