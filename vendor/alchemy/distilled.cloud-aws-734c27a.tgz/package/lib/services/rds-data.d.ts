import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const DatabaseErrorException_base: S.TaggedErrorClass<"DatabaseErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DatabaseErrorException extends /*@__PURE__*/ DatabaseErrorException_base {
}
declare const DatabaseNotFoundException_base: S.TaggedErrorClass<"DatabaseNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DatabaseNotFoundException extends /*@__PURE__*/ DatabaseNotFoundException_base {
}
declare const DatabaseResumingException_base: S.TaggedErrorClass<"DatabaseResumingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DatabaseResumingException extends /*@__PURE__*/ DatabaseResumingException_base {
}
declare const DatabaseUnavailableException_base: S.TaggedErrorClass<"DatabaseUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DatabaseUnavailableException extends /*@__PURE__*/ DatabaseUnavailableException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const HttpEndpointNotEnabledException_base: S.TaggedErrorClass<"HttpEndpointNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HttpEndpointNotEnabledException extends /*@__PURE__*/ HttpEndpointNotEnabledException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const InvalidResourceStateException_base: S.TaggedErrorClass<"InvalidResourceStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourceStateException extends /*@__PURE__*/ InvalidResourceStateException_base {
}
declare const InvalidSecretException_base: S.TaggedErrorClass<"InvalidSecretException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSecretException extends /*@__PURE__*/ InvalidSecretException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const SecretsErrorException_base: S.TaggedErrorClass<"SecretsErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SecretsErrorException extends /*@__PURE__*/ SecretsErrorException_base {
}
declare const ServiceUnavailableError_base: S.TaggedErrorClass<"ServiceUnavailableError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableError extends /*@__PURE__*/ ServiceUnavailableError_base {
}
declare const StatementTimeoutException_base: S.TaggedErrorClass<"StatementTimeoutException", {
    readonly message: any;
    readonly dbConnectionId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StatementTimeoutException extends /*@__PURE__*/ StatementTimeoutException_base {
}
declare const TransactionNotFoundException_base: S.TaggedErrorClass<"TransactionNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TransactionNotFoundException extends /*@__PURE__*/ TransactionNotFoundException_base {
}
declare const UnsupportedResultException_base: S.TaggedErrorClass<"UnsupportedResultException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedResultException extends /*@__PURE__*/ UnsupportedResultException_base {
}
export type Arn = string;
export type SqlStatement = string;
export type DbName = string;
export type ParameterName = string;
export type BoxedBoolean = boolean;
export type BoxedLong = number;
export type BoxedDouble = number;
export type BooleanArray = (boolean | null)[];
export type LongArray = (number | null)[];
export type DoubleArray = (number | null)[];
export type StringArray = (string | null)[];
export type ArrayOfArray = (ArrayValue | null)[];
export type ArrayValue = {
    booleanValues: (boolean | null)[];
    longValues?: undefined;
    doubleValues?: undefined;
    stringValues?: undefined;
    arrayValues?: undefined;
} | {
    booleanValues?: undefined;
    longValues: (number | null)[];
    doubleValues?: undefined;
    stringValues?: undefined;
    arrayValues?: undefined;
} | {
    booleanValues?: undefined;
    longValues?: undefined;
    doubleValues: (number | null)[];
    stringValues?: undefined;
    arrayValues?: undefined;
} | {
    booleanValues?: undefined;
    longValues?: undefined;
    doubleValues?: undefined;
    stringValues: (string | null)[];
    arrayValues?: undefined;
} | {
    booleanValues?: undefined;
    longValues?: undefined;
    doubleValues?: undefined;
    stringValues?: undefined;
    arrayValues: (ArrayValue | null)[];
};
export type Field = {
    isNull: boolean;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue: boolean;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue: number;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue: number;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue: string;
    blobValue?: undefined;
    arrayValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue: Uint8Array;
    arrayValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValue: ArrayValue;
};
export type TypeHint = "JSON" | "UUID" | "TIMESTAMP" | "DATE" | "TIME" | "DECIMAL" | (string & {});
export interface SqlParameter {
    name?: string | undefined;
    value?: Field | undefined;
    typeHint?: TypeHint | undefined;
}
export type SqlParametersList = SqlParameter[];
export type SqlParameterSets = SqlParameter[][];
export type Id = string;
export interface BatchExecuteStatementRequest {
    resourceArn: string;
    secretArn: string;
    sql: string;
    database?: string | undefined;
    schema?: string | undefined;
    parameterSets?: SqlParameter[][] | undefined;
    transactionId?: string | undefined;
}
export type FieldList = Field[];
export interface UpdateResult {
    generatedFields?: Field[] | undefined;
}
export type UpdateResults = UpdateResult[];
export interface BatchExecuteStatementResponse {
    updateResults?: UpdateResult[] | undefined;
}
export interface BeginTransactionRequest {
    resourceArn: string;
    secretArn: string;
    database?: string | undefined;
    schema?: string | undefined;
}
export interface BeginTransactionResponse {
    transactionId?: string | undefined;
}
export interface CommitTransactionRequest {
    resourceArn: string;
    secretArn: string;
    transactionId: string;
}
export type TransactionStatus = string;
export interface CommitTransactionResponse {
    transactionStatus?: string | undefined;
}
export interface ExecuteSqlRequest {
    dbClusterOrInstanceArn: string;
    awsSecretStoreArn: string;
    sqlStatements: string;
    database?: string | undefined;
    schema?: string | undefined;
}
export interface ColumnMetadata {
    name?: string | undefined;
    type?: number | undefined;
    typeName?: string | undefined;
    label?: string | undefined;
    schemaName?: string | undefined;
    tableName?: string | undefined;
    isAutoIncrement?: boolean | undefined;
    isSigned?: boolean | undefined;
    isCurrency?: boolean | undefined;
    isCaseSensitive?: boolean | undefined;
    nullable?: number | undefined;
    precision?: number | undefined;
    scale?: number | undefined;
    arrayBaseColumnType?: number | undefined;
}
export type Metadata = ColumnMetadata[];
export interface ResultSetMetadata {
    columnCount?: number | undefined;
    columnMetadata?: ColumnMetadata[] | undefined;
}
export type BoxedInteger = number;
export type BoxedFloat = number;
export type ArrayValueList = Value[];
export interface StructValue {
    attributes?: Value[] | undefined;
}
export type Value = {
    isNull: boolean;
    bitValue?: undefined;
    bigIntValue?: undefined;
    intValue?: undefined;
    doubleValue?: undefined;
    realValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValues?: undefined;
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue: boolean;
    bigIntValue?: undefined;
    intValue?: undefined;
    doubleValue?: undefined;
    realValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValues?: undefined;
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue?: undefined;
    bigIntValue: number;
    intValue?: undefined;
    doubleValue?: undefined;
    realValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValues?: undefined;
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue?: undefined;
    bigIntValue?: undefined;
    intValue: number;
    doubleValue?: undefined;
    realValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValues?: undefined;
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue?: undefined;
    bigIntValue?: undefined;
    intValue?: undefined;
    doubleValue: number;
    realValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValues?: undefined;
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue?: undefined;
    bigIntValue?: undefined;
    intValue?: undefined;
    doubleValue?: undefined;
    realValue: number;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValues?: undefined;
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue?: undefined;
    bigIntValue?: undefined;
    intValue?: undefined;
    doubleValue?: undefined;
    realValue?: undefined;
    stringValue: string;
    blobValue?: undefined;
    arrayValues?: undefined;
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue?: undefined;
    bigIntValue?: undefined;
    intValue?: undefined;
    doubleValue?: undefined;
    realValue?: undefined;
    stringValue?: undefined;
    blobValue: Uint8Array;
    arrayValues?: undefined;
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue?: undefined;
    bigIntValue?: undefined;
    intValue?: undefined;
    doubleValue?: undefined;
    realValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValues: Value[];
    structValue?: undefined;
} | {
    isNull?: undefined;
    bitValue?: undefined;
    bigIntValue?: undefined;
    intValue?: undefined;
    doubleValue?: undefined;
    realValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
    arrayValues?: undefined;
    structValue: StructValue;
};
export type Row = Value[];
export interface Record {
    values?: Value[] | undefined;
}
export type Records = Record[];
export interface ResultFrame {
    resultSetMetadata?: ResultSetMetadata | undefined;
    records?: Record[] | undefined;
}
export type RecordsUpdated = number;
export interface SqlStatementResult {
    resultFrame?: ResultFrame | undefined;
    numberOfRecordsUpdated?: number | undefined;
}
export type SqlStatementResults = SqlStatementResult[];
export interface ExecuteSqlResponse {
    sqlStatementResults?: SqlStatementResult[] | undefined;
}
export type DecimalReturnType = "STRING" | "DOUBLE_OR_LONG" | (string & {});
export type LongReturnType = "STRING" | "LONG" | (string & {});
export interface ResultSetOptions {
    decimalReturnType?: DecimalReturnType | undefined;
    longReturnType?: LongReturnType | undefined;
}
export type RecordsFormatType = "NONE" | "JSON" | (string & {});
export interface ExecuteStatementRequest {
    resourceArn: string;
    secretArn: string;
    sql: string;
    database?: string | undefined;
    schema?: string | undefined;
    parameters?: SqlParameter[] | undefined;
    transactionId?: string | undefined;
    includeResultMetadata?: boolean | undefined;
    continueAfterTimeout?: boolean | undefined;
    resultSetOptions?: ResultSetOptions | undefined;
    formatRecordsAs?: RecordsFormatType | undefined;
}
export type SqlRecords = Field[][];
export type FormattedSqlRecords = string;
export interface ExecuteStatementResponse {
    records?: Field[][] | undefined;
    columnMetadata?: ColumnMetadata[] | undefined;
    numberOfRecordsUpdated?: number | undefined;
    generatedFields?: Field[] | undefined;
    formattedRecords?: string | undefined;
}
export interface RollbackTransactionRequest {
    resourceArn: string;
    secretArn: string;
    transactionId: string;
}
export interface RollbackTransactionResponse {
    transactionStatus?: string | undefined;
}
export type ErrorMessage = string;
export type BatchExecuteStatementError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseResumingException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | CommonErrors;
/**
 * Runs a batch SQL statement over an array of data.
 *
 * You can run bulk update and insert operations for multiple records using a DML statement with different parameter sets. Bulk operations can provide a significant performance improvement over individual insert and update operations.
 *
 * If a call isn't part of a transaction because it doesn't include the `transactionID` parameter, changes that result from the call are committed automatically.
 *
 * There isn't a fixed upper limit on the number of parameter sets. However, the maximum size of the HTTP request submitted through the Data API is 4 MiB. If the request exceeds this limit, the Data API returns an error and doesn't process the request. This 4-MiB limit includes the size of the HTTP headers and the JSON notation in the request. Thus, the number of parameter sets that you can include depends on a combination of factors, such as the size of the SQL statement and the size of each parameter set.
 *
 * The response size limit is 1 MiB. If the call returns more than 1 MiB of response data, the call is terminated.
 */
export declare const batchExecuteStatement: API.OperationMethod<BatchExecuteStatementRequest & RegionInput, BatchExecuteStatementResponse, BatchExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type BeginTransactionError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseResumingException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | CommonErrors;
/**
 * Starts a SQL transaction.
 *
 * A transaction can run for a maximum of 24 hours. A transaction is terminated and rolled back automatically after 24 hours.
 *
 * A transaction times out if no calls use its transaction ID in three minutes. If a transaction times out before it's committed, it's rolled back automatically.
 *
 * For Aurora MySQL, DDL statements inside a transaction cause an implicit commit. We recommend that you run each MySQL DDL statement in a separate `ExecuteStatement` call with `continueAfterTimeout` enabled.
 */
export declare const beginTransaction: API.OperationMethod<BeginTransactionRequest & RegionInput, BeginTransactionResponse, BeginTransactionError, Credentials | HttpClient.HttpClient>;
export type CommitTransactionError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | NotFoundException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | CommonErrors;
/**
 * Ends a SQL transaction started with the `BeginTransaction` operation and commits the changes.
 */
export declare const commitTransaction: API.OperationMethod<CommitTransactionRequest & RegionInput, CommitTransactionResponse, CommitTransactionError, Credentials | HttpClient.HttpClient>;
export type ExecuteSqlError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableError | CommonErrors;
/**
 * Runs one or more SQL statements.
 *
 * This operation is deprecated. Please use the `BatchExecuteStatement` or `ExecuteStatement` operation.
 */
export declare const executeSql: API.OperationMethod<ExecuteSqlRequest & RegionInput, ExecuteSqlResponse, ExecuteSqlError, Credentials | HttpClient.HttpClient>;
export type ExecuteStatementError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseResumingException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | UnsupportedResultException | CommonErrors;
/**
 * Runs a SQL statement against a database.
 *
 * If a call isn't part of a transaction because it doesn't include the `transactionID` parameter, changes that result from the call are committed automatically.
 *
 * If the binary response data from the database is more than 1 MB, the call is terminated.
 */
export declare const executeStatement: API.OperationMethod<ExecuteStatementRequest & RegionInput, ExecuteStatementResponse, ExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type RollbackTransactionError = AccessDeniedException | BadRequestException | DatabaseErrorException | DatabaseNotFoundException | DatabaseUnavailableException | ForbiddenException | HttpEndpointNotEnabledException | InternalServerErrorException | InvalidResourceStateException | InvalidSecretException | NotFoundException | SecretsErrorException | ServiceUnavailableError | StatementTimeoutException | TransactionNotFoundException | CommonErrors;
/**
 * Performs a rollback of a transaction. Rolling back a transaction cancels its changes.
 */
export declare const rollbackTransaction: API.OperationMethod<RollbackTransactionRequest & RegionInput, RollbackTransactionResponse, RollbackTransactionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=rds-data.d.ts.map