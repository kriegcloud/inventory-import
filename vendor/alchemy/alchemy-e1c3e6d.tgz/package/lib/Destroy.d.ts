import { Effect } from "effect";
import type * as Scope from "effect/Scope";
import type { StackDefinition } from "./Stack.ts";
export declare const destroy: <ROut>({ stack, stage, dev, scope, include, exclude, }: {
    /** The stack to tear down; its program is never run. */
    stack: StackDefinition<ROut>;
    stage: string;
    dev?: boolean;
    /** See {@link evalStack} — when set, scoped resources outlive `destroy`. */
    scope?: Scope.Scope;
    /** Destroy always operates on the full stack. */
    include?: never;
    exclude?: never;
}) => Effect.Effect<undefined, import("./Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("./Auth/Demand.ts").CredentialsRequired | import("./Apply.ts").DestroyError | import("./Output.ts").InvalidReferenceError | import("./Output.ts").MissingSourceError | import("./Auth/AuthProvider.ts").NeedsReauth | import("effect/PlatformError").PlatformError | import("./State/State.ts").StateStoreError, import("./Artifacts.ts").ArtifactStore | import("./index.ts").AuthProviders | import("./Interaction.ts").Interaction | import("./State/State.ts").State>;
//# sourceMappingURL=Destroy.d.ts.map