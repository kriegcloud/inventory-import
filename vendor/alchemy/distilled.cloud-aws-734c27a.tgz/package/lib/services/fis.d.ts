import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type ExperimentTemplateDescription = string;
export type StopConditionSource = string;
export type StopConditionValue = string;
export interface CreateExperimentTemplateStopConditionInput {
    source: string;
    value?: string | undefined;
}
export type CreateExperimentTemplateStopConditionInputList = CreateExperimentTemplateStopConditionInput[];
export type ExperimentTemplateTargetName = string;
export type TargetResourceTypeId = string;
export type ResourceArn = string;
export type ResourceArnList = string[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type ExperimentTemplateTargetFilterPath = string;
export type ExperimentTemplateTargetFilterValue = string;
export type ExperimentTemplateTargetFilterValues = string[];
export interface ExperimentTemplateTargetInputFilter {
    path: string;
    values: string[];
}
export type ExperimentTemplateTargetFilterInputList = ExperimentTemplateTargetInputFilter[];
export type ExperimentTemplateTargetSelectionMode = string;
export type ExperimentTemplateTargetParameterName = string;
export type ExperimentTemplateTargetParameterValue = string;
export type ExperimentTemplateTargetParameterMap = {
    [key: string]: string | undefined;
};
export interface CreateExperimentTemplateTargetInput {
    resourceType: string;
    resourceArns?: string[] | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    filters?: ExperimentTemplateTargetInputFilter[] | undefined;
    selectionMode: string;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CreateExperimentTemplateTargetInputMap = {
    [key: string]: CreateExperimentTemplateTargetInput | undefined;
};
export type ExperimentTemplateActionName = string;
export type ActionId = string;
export type ExperimentTemplateActionDescription = string;
export type ExperimentTemplateActionParameterName = string;
export type ExperimentTemplateActionParameter = string;
export type ExperimentTemplateActionParameterMap = {
    [key: string]: string | undefined;
};
export type ExperimentTemplateActionTargetName = string;
export type ExperimentTemplateActionTargetMap = {
    [key: string]: string | undefined;
};
export type ExperimentTemplateActionStartAfter = string;
export type ExperimentTemplateActionStartAfterList = string[];
export interface CreateExperimentTemplateActionInput {
    actionId: string;
    description?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    targets?: {
        [key: string]: string | undefined;
    } | undefined;
    startAfter?: string[] | undefined;
}
export type CreateExperimentTemplateActionInputMap = {
    [key: string]: CreateExperimentTemplateActionInput | undefined;
};
export type RoleArn = string;
export type CloudWatchLogGroupArn = string;
export interface ExperimentTemplateCloudWatchLogsLogConfigurationInput {
    logGroupArn: string;
}
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface ExperimentTemplateS3LogConfigurationInput {
    bucketName: string;
    prefix?: string | undefined;
}
export type LogSchemaVersion = number;
export interface CreateExperimentTemplateLogConfigurationInput {
    cloudWatchLogsConfiguration?: ExperimentTemplateCloudWatchLogsLogConfigurationInput | undefined;
    s3Configuration?: ExperimentTemplateS3LogConfigurationInput | undefined;
    logSchemaVersion: number;
}
export type AccountTargeting = "single-account" | "multi-account" | (string & {});
export type EmptyTargetResolutionMode = "fail" | "skip" | (string & {});
export interface CreateExperimentTemplateExperimentOptionsInput {
    accountTargeting?: AccountTargeting | undefined;
    emptyTargetResolutionMode?: EmptyTargetResolutionMode | undefined;
}
export type ReportConfigurationS3OutputPrefix = string;
export interface ReportConfigurationS3OutputInput {
    bucketName?: string | undefined;
    prefix?: string | undefined;
}
export interface ExperimentTemplateReportConfigurationOutputsInput {
    s3Configuration?: ReportConfigurationS3OutputInput | undefined;
}
export type ReportConfigurationCloudWatchDashboardIdentifier = string;
export interface ReportConfigurationCloudWatchDashboardInput {
    dashboardIdentifier?: string | undefined;
}
export type ReportConfigurationCloudWatchDashboardInputList = ReportConfigurationCloudWatchDashboardInput[];
export interface ExperimentTemplateReportConfigurationDataSourcesInput {
    cloudWatchDashboards?: ReportConfigurationCloudWatchDashboardInput[] | undefined;
}
export type ReportConfigurationDuration = string;
export interface CreateExperimentTemplateReportConfigurationInput {
    outputs?: ExperimentTemplateReportConfigurationOutputsInput | undefined;
    dataSources?: ExperimentTemplateReportConfigurationDataSourcesInput | undefined;
    preExperimentDuration?: string | undefined;
    postExperimentDuration?: string | undefined;
}
export interface CreateExperimentTemplateRequest {
    clientToken: string;
    description: string;
    stopConditions: CreateExperimentTemplateStopConditionInput[];
    targets?: {
        [key: string]: CreateExperimentTemplateTargetInput | undefined;
    } | undefined;
    actions: {
        [key: string]: CreateExperimentTemplateActionInput | undefined;
    };
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    logConfiguration?: CreateExperimentTemplateLogConfigurationInput | undefined;
    experimentOptions?: CreateExperimentTemplateExperimentOptionsInput | undefined;
    experimentReportConfiguration?: CreateExperimentTemplateReportConfigurationInput | undefined;
}
export type ExperimentTemplateId = string;
export interface ExperimentTemplateTargetFilter {
    path?: string | undefined;
    values?: string[] | undefined;
}
export type ExperimentTemplateTargetFilterList = ExperimentTemplateTargetFilter[];
export interface ExperimentTemplateTarget {
    resourceType?: string | undefined;
    resourceArns?: string[] | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    filters?: ExperimentTemplateTargetFilter[] | undefined;
    selectionMode?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ExperimentTemplateTargetMap = {
    [key: string]: ExperimentTemplateTarget | undefined;
};
export interface ExperimentTemplateAction {
    actionId?: string | undefined;
    description?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    targets?: {
        [key: string]: string | undefined;
    } | undefined;
    startAfter?: string[] | undefined;
}
export type ExperimentTemplateActionMap = {
    [key: string]: ExperimentTemplateAction | undefined;
};
export interface ExperimentTemplateStopCondition {
    source?: string | undefined;
    value?: string | undefined;
}
export type ExperimentTemplateStopConditionList = ExperimentTemplateStopCondition[];
export type CreationTime = Date;
export type LastUpdateTime = Date;
export interface ExperimentTemplateCloudWatchLogsLogConfiguration {
    logGroupArn?: string | undefined;
}
export interface ExperimentTemplateS3LogConfiguration {
    bucketName?: string | undefined;
    prefix?: string | undefined;
}
export interface ExperimentTemplateLogConfiguration {
    cloudWatchLogsConfiguration?: ExperimentTemplateCloudWatchLogsLogConfiguration | undefined;
    s3Configuration?: ExperimentTemplateS3LogConfiguration | undefined;
    logSchemaVersion?: number | undefined;
}
export interface ExperimentTemplateExperimentOptions {
    accountTargeting?: AccountTargeting | undefined;
    emptyTargetResolutionMode?: EmptyTargetResolutionMode | undefined;
}
export type TargetAccountConfigurationsCount = number;
export interface ReportConfigurationS3Output {
    bucketName?: string | undefined;
    prefix?: string | undefined;
}
export interface ExperimentTemplateReportConfigurationOutputs {
    s3Configuration?: ReportConfigurationS3Output | undefined;
}
export interface ExperimentTemplateReportConfigurationCloudWatchDashboard {
    dashboardIdentifier?: string | undefined;
}
export type ExperimentTemplateReportConfigurationCloudWatchDashboardList = ExperimentTemplateReportConfigurationCloudWatchDashboard[];
export interface ExperimentTemplateReportConfigurationDataSources {
    cloudWatchDashboards?: ExperimentTemplateReportConfigurationCloudWatchDashboard[] | undefined;
}
export interface ExperimentTemplateReportConfiguration {
    outputs?: ExperimentTemplateReportConfigurationOutputs | undefined;
    dataSources?: ExperimentTemplateReportConfigurationDataSources | undefined;
    preExperimentDuration?: string | undefined;
    postExperimentDuration?: string | undefined;
}
export interface ExperimentTemplate {
    id?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    targets?: {
        [key: string]: ExperimentTemplateTarget | undefined;
    } | undefined;
    actions?: {
        [key: string]: ExperimentTemplateAction | undefined;
    } | undefined;
    stopConditions?: ExperimentTemplateStopCondition[] | undefined;
    creationTime?: Date | undefined;
    lastUpdateTime?: Date | undefined;
    roleArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    logConfiguration?: ExperimentTemplateLogConfiguration | undefined;
    experimentOptions?: ExperimentTemplateExperimentOptions | undefined;
    targetAccountConfigurationsCount?: number | undefined;
    experimentReportConfiguration?: ExperimentTemplateReportConfiguration | undefined;
}
export interface CreateExperimentTemplateResponse {
    experimentTemplate?: ExperimentTemplate | undefined;
}
export type TargetAccountId = string;
export type TargetAccountConfigurationDescription = string;
export interface CreateTargetAccountConfigurationRequest {
    clientToken?: string | undefined;
    experimentTemplateId: string;
    accountId: string;
    roleArn: string;
    description?: string | undefined;
}
export interface TargetAccountConfiguration {
    roleArn?: string | undefined;
    accountId?: string | undefined;
    description?: string | undefined;
}
export interface CreateTargetAccountConfigurationResponse {
    targetAccountConfiguration?: TargetAccountConfiguration | undefined;
}
export interface DeleteExperimentTemplateRequest {
    id: string;
}
export interface DeleteExperimentTemplateResponse {
    experimentTemplate?: ExperimentTemplate | undefined;
}
export interface DeleteTargetAccountConfigurationRequest {
    experimentTemplateId: string;
    accountId: string;
}
export interface DeleteTargetAccountConfigurationResponse {
    targetAccountConfiguration?: TargetAccountConfiguration | undefined;
}
export interface GetActionRequest {
    id: string;
}
export type ActionDescription = string;
export type ActionParameterName = string;
export type ActionParameterDescription = string;
export type ActionParameterRequired = boolean;
export interface ActionParameter {
    description?: string | undefined;
    required?: boolean | undefined;
}
export type ActionParameterMap = {
    [key: string]: ActionParameter | undefined;
};
export type ActionTargetName = string;
export interface ActionTarget {
    resourceType?: string | undefined;
}
export type ActionTargetMap = {
    [key: string]: ActionTarget | undefined;
};
export interface Action {
    id?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    parameters?: {
        [key: string]: ActionParameter | undefined;
    } | undefined;
    targets?: {
        [key: string]: ActionTarget | undefined;
    } | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetActionResponse {
    action?: Action | undefined;
}
export type ExperimentId = string;
export interface GetExperimentRequest {
    id: string;
}
export type ExperimentStatus = "pending" | "initiating" | "running" | "completed" | "stopping" | "stopped" | "failed" | "cancelled" | (string & {});
export type ExperimentStatusReason = string;
export type ExperimentErrorAccountId = string;
export type ExperimentErrorCode = string;
export type ExperimentErrorLocation = string;
export interface ExperimentError {
    accountId?: string | undefined;
    code?: string | undefined;
    location?: string | undefined;
}
export interface ExperimentState {
    status?: ExperimentStatus | undefined;
    reason?: string | undefined;
    error?: ExperimentError | undefined;
}
export type ExperimentTargetName = string;
export type ExperimentTargetFilterPath = string;
export type ExperimentTargetFilterValue = string;
export type ExperimentTargetFilterValues = string[];
export interface ExperimentTargetFilter {
    path?: string | undefined;
    values?: string[] | undefined;
}
export type ExperimentTargetFilterList = ExperimentTargetFilter[];
export type ExperimentTargetSelectionMode = string;
export type ExperimentTargetParameterName = string;
export type ExperimentTargetParameterValue = string;
export type ExperimentTargetParameterMap = {
    [key: string]: string | undefined;
};
export interface ExperimentTarget {
    resourceType?: string | undefined;
    resourceArns?: string[] | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    filters?: ExperimentTargetFilter[] | undefined;
    selectionMode?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ExperimentTargetMap = {
    [key: string]: ExperimentTarget | undefined;
};
export type ExperimentActionName = string;
export type ExperimentActionDescription = string;
export type ExperimentActionParameterName = string;
export type ExperimentActionParameter = string;
export type ExperimentActionParameterMap = {
    [key: string]: string | undefined;
};
export type ExperimentActionTargetName = string;
export type ExperimentActionTargetMap = {
    [key: string]: string | undefined;
};
export type ExperimentActionStartAfter = string;
export type ExperimentActionStartAfterList = string[];
export type ExperimentActionStatus = "pending" | "initiating" | "running" | "completed" | "cancelled" | "stopping" | "stopped" | "failed" | "skipped" | (string & {});
export type ExperimentActionStatusReason = string;
export interface ExperimentActionState {
    status?: ExperimentActionStatus | undefined;
    reason?: string | undefined;
}
export type ExperimentActionStartTime = Date;
export type ExperimentActionEndTime = Date;
export interface ExperimentAction {
    actionId?: string | undefined;
    description?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    targets?: {
        [key: string]: string | undefined;
    } | undefined;
    startAfter?: string[] | undefined;
    state?: ExperimentActionState | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type ExperimentActionMap = {
    [key: string]: ExperimentAction | undefined;
};
export interface ExperimentStopCondition {
    source?: string | undefined;
    value?: string | undefined;
}
export type ExperimentStopConditionList = ExperimentStopCondition[];
export type ExperimentStartTime = Date;
export type ExperimentEndTime = Date;
export interface ExperimentCloudWatchLogsLogConfiguration {
    logGroupArn?: string | undefined;
}
export interface ExperimentS3LogConfiguration {
    bucketName?: string | undefined;
    prefix?: string | undefined;
}
export interface ExperimentLogConfiguration {
    cloudWatchLogsConfiguration?: ExperimentCloudWatchLogsLogConfiguration | undefined;
    s3Configuration?: ExperimentS3LogConfiguration | undefined;
    logSchemaVersion?: number | undefined;
}
export type ActionsMode = "skip-all" | "run-all" | (string & {});
export interface ExperimentOptions {
    accountTargeting?: AccountTargeting | undefined;
    emptyTargetResolutionMode?: EmptyTargetResolutionMode | undefined;
    actionsMode?: ActionsMode | undefined;
}
export interface ExperimentReportConfigurationOutputsS3Configuration {
    bucketName?: string | undefined;
    prefix?: string | undefined;
}
export interface ExperimentReportConfigurationOutputs {
    s3Configuration?: ExperimentReportConfigurationOutputsS3Configuration | undefined;
}
export interface ExperimentReportConfigurationCloudWatchDashboard {
    dashboardIdentifier?: string | undefined;
}
export type ExperimentReportConfigurationCloudWatchDashboardList = ExperimentReportConfigurationCloudWatchDashboard[];
export interface ExperimentReportConfigurationDataSources {
    cloudWatchDashboards?: ExperimentReportConfigurationCloudWatchDashboard[] | undefined;
}
export interface ExperimentReportConfiguration {
    outputs?: ExperimentReportConfigurationOutputs | undefined;
    dataSources?: ExperimentReportConfigurationDataSources | undefined;
    preExperimentDuration?: string | undefined;
    postExperimentDuration?: string | undefined;
}
export type ExperimentReportStatus = "pending" | "running" | "completed" | "cancelled" | "failed" | (string & {});
export type ExperimentReportReason = string;
export type ExperimentReportErrorCode = string;
export interface ExperimentReportError {
    code?: string | undefined;
}
export interface ExperimentReportState {
    status?: ExperimentReportStatus | undefined;
    reason?: string | undefined;
    error?: ExperimentReportError | undefined;
}
export type ExperimentReportS3ReportArn = string;
export type ExperimentReportS3ReportType = string;
export interface ExperimentReportS3Report {
    arn?: string | undefined;
    reportType?: string | undefined;
}
export type ExperimentReportS3ReportList = ExperimentReportS3Report[];
export interface ExperimentReport {
    state?: ExperimentReportState | undefined;
    s3Reports?: ExperimentReportS3Report[] | undefined;
}
export interface Experiment {
    id?: string | undefined;
    arn?: string | undefined;
    experimentTemplateId?: string | undefined;
    roleArn?: string | undefined;
    state?: ExperimentState | undefined;
    targets?: {
        [key: string]: ExperimentTarget | undefined;
    } | undefined;
    actions?: {
        [key: string]: ExperimentAction | undefined;
    } | undefined;
    stopConditions?: ExperimentStopCondition[] | undefined;
    creationTime?: Date | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    logConfiguration?: ExperimentLogConfiguration | undefined;
    experimentOptions?: ExperimentOptions | undefined;
    targetAccountConfigurationsCount?: number | undefined;
    experimentReportConfiguration?: ExperimentReportConfiguration | undefined;
    experimentReport?: ExperimentReport | undefined;
}
export interface GetExperimentResponse {
    experiment?: Experiment | undefined;
}
export interface GetExperimentTargetAccountConfigurationRequest {
    experimentId: string;
    accountId: string;
}
export interface ExperimentTargetAccountConfiguration {
    roleArn?: string | undefined;
    accountId?: string | undefined;
    description?: string | undefined;
}
export interface GetExperimentTargetAccountConfigurationResponse {
    targetAccountConfiguration?: ExperimentTargetAccountConfiguration | undefined;
}
export interface GetExperimentTemplateRequest {
    id: string;
}
export interface GetExperimentTemplateResponse {
    experimentTemplate?: ExperimentTemplate | undefined;
}
export type SafetyLeverId = string;
export interface GetSafetyLeverRequest {
    id: string;
}
export type SafetyLeverStatus = "disengaged" | "engaged" | "engaging" | (string & {});
export type SafetyLeverStatusReason = string;
export interface SafetyLeverState {
    status?: SafetyLeverStatus | undefined;
    reason?: string | undefined;
}
export interface SafetyLever {
    id?: string | undefined;
    arn?: string | undefined;
    state?: SafetyLeverState | undefined;
}
export interface GetSafetyLeverResponse {
    safetyLever?: SafetyLever | undefined;
}
export interface GetTargetAccountConfigurationRequest {
    experimentTemplateId: string;
    accountId: string;
}
export interface GetTargetAccountConfigurationResponse {
    targetAccountConfiguration?: TargetAccountConfiguration | undefined;
}
export interface GetTargetResourceTypeRequest {
    resourceType: string;
}
export type TargetResourceTypeDescription = string;
export type TargetResourceTypeParameterName = string;
export type TargetResourceTypeParameterDescription = string;
export type TargetResourceTypeParameterRequired = boolean;
export interface TargetResourceTypeParameter {
    description?: string | undefined;
    required?: boolean | undefined;
}
export type TargetResourceTypeParameterMap = {
    [key: string]: TargetResourceTypeParameter | undefined;
};
export interface TargetResourceType {
    resourceType?: string | undefined;
    description?: string | undefined;
    parameters?: {
        [key: string]: TargetResourceTypeParameter | undefined;
    } | undefined;
}
export interface GetTargetResourceTypeResponse {
    targetResourceType?: TargetResourceType | undefined;
}
export type ListActionsMaxResults = number;
export type NextToken = string;
export interface ListActionsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ActionSummary {
    id?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    targets?: {
        [key: string]: ActionTarget | undefined;
    } | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ActionSummaryList = ActionSummary[];
export interface ListActionsResponse {
    actions?: ActionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListExperimentResolvedTargetsMaxResults = number;
export type TargetName = string;
export interface ListExperimentResolvedTargetsRequest {
    experimentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    targetName?: string | undefined;
}
export type TargetInformationKey = string;
export type TargetInformationValue = string;
export type TargetInformationMap = {
    [key: string]: string | undefined;
};
export interface ResolvedTarget {
    resourceType?: string | undefined;
    targetName?: string | undefined;
    targetInformation?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ResolvedTargetList = ResolvedTarget[];
export interface ListExperimentResolvedTargetsResponse {
    resolvedTargets?: ResolvedTarget[] | undefined;
    nextToken?: string | undefined;
}
export type ListExperimentsMaxResults = number;
export interface ListExperimentsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    experimentTemplateId?: string | undefined;
}
export interface ExperimentSummary {
    id?: string | undefined;
    arn?: string | undefined;
    experimentTemplateId?: string | undefined;
    state?: ExperimentState | undefined;
    creationTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    experimentOptions?: ExperimentOptions | undefined;
}
export type ExperimentSummaryList = ExperimentSummary[];
export interface ListExperimentsResponse {
    experiments?: ExperimentSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListExperimentTargetAccountConfigurationsRequest {
    experimentId: string;
    nextToken?: string | undefined;
}
export interface ExperimentTargetAccountConfigurationSummary {
    roleArn?: string | undefined;
    accountId?: string | undefined;
    description?: string | undefined;
}
export type ExperimentTargetAccountConfigurationList = ExperimentTargetAccountConfigurationSummary[];
export interface ListExperimentTargetAccountConfigurationsResponse {
    targetAccountConfigurations?: ExperimentTargetAccountConfigurationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListExperimentTemplatesMaxResults = number;
export interface ListExperimentTemplatesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ExperimentTemplateSummary {
    id?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    creationTime?: Date | undefined;
    lastUpdateTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ExperimentTemplateSummaryList = ExperimentTemplateSummary[];
export interface ListExperimentTemplatesResponse {
    experimentTemplates?: ExperimentTemplateSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListTargetAccountConfigurationsMaxResults = number;
export interface ListTargetAccountConfigurationsRequest {
    experimentTemplateId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface TargetAccountConfigurationSummary {
    roleArn?: string | undefined;
    accountId?: string | undefined;
    description?: string | undefined;
}
export type TargetAccountConfigurationList = TargetAccountConfigurationSummary[];
export interface ListTargetAccountConfigurationsResponse {
    targetAccountConfigurations?: TargetAccountConfigurationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListTargetResourceTypesMaxResults = number;
export interface ListTargetResourceTypesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface TargetResourceTypeSummary {
    resourceType?: string | undefined;
    description?: string | undefined;
}
export type TargetResourceTypeSummaryList = TargetResourceTypeSummary[];
export interface ListTargetResourceTypesResponse {
    targetResourceTypes?: TargetResourceTypeSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface StartExperimentExperimentOptionsInput {
    actionsMode?: ActionsMode | undefined;
}
export interface StartExperimentRequest {
    clientToken: string;
    experimentTemplateId: string;
    experimentOptions?: StartExperimentExperimentOptionsInput | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartExperimentResponse {
    experiment?: Experiment | undefined;
}
export interface StopExperimentRequest {
    id: string;
}
export interface StopExperimentResponse {
    experiment?: Experiment | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateExperimentTemplateStopConditionInput {
    source: string;
    value?: string | undefined;
}
export type UpdateExperimentTemplateStopConditionInputList = UpdateExperimentTemplateStopConditionInput[];
export interface UpdateExperimentTemplateTargetInput {
    resourceType: string;
    resourceArns?: string[] | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    filters?: ExperimentTemplateTargetInputFilter[] | undefined;
    selectionMode: string;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type UpdateExperimentTemplateTargetInputMap = {
    [key: string]: UpdateExperimentTemplateTargetInput | undefined;
};
export interface UpdateExperimentTemplateActionInputItem {
    actionId?: string | undefined;
    description?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    targets?: {
        [key: string]: string | undefined;
    } | undefined;
    startAfter?: string[] | undefined;
}
export type UpdateExperimentTemplateActionInputMap = {
    [key: string]: UpdateExperimentTemplateActionInputItem | undefined;
};
export interface UpdateExperimentTemplateLogConfigurationInput {
    cloudWatchLogsConfiguration?: ExperimentTemplateCloudWatchLogsLogConfigurationInput | undefined;
    s3Configuration?: ExperimentTemplateS3LogConfigurationInput | undefined;
    logSchemaVersion?: number | undefined;
}
export interface UpdateExperimentTemplateExperimentOptionsInput {
    emptyTargetResolutionMode?: EmptyTargetResolutionMode | undefined;
}
export interface UpdateExperimentTemplateReportConfigurationInput {
    outputs?: ExperimentTemplateReportConfigurationOutputsInput | undefined;
    dataSources?: ExperimentTemplateReportConfigurationDataSourcesInput | undefined;
    preExperimentDuration?: string | undefined;
    postExperimentDuration?: string | undefined;
}
export interface UpdateExperimentTemplateRequest {
    id: string;
    description?: string | undefined;
    stopConditions?: UpdateExperimentTemplateStopConditionInput[] | undefined;
    targets?: {
        [key: string]: UpdateExperimentTemplateTargetInput | undefined;
    } | undefined;
    actions?: {
        [key: string]: UpdateExperimentTemplateActionInputItem | undefined;
    } | undefined;
    roleArn?: string | undefined;
    logConfiguration?: UpdateExperimentTemplateLogConfigurationInput | undefined;
    experimentOptions?: UpdateExperimentTemplateExperimentOptionsInput | undefined;
    experimentReportConfiguration?: UpdateExperimentTemplateReportConfigurationInput | undefined;
}
export interface UpdateExperimentTemplateResponse {
    experimentTemplate?: ExperimentTemplate | undefined;
}
export type SafetyLeverStatusInput = "disengaged" | "engaged" | (string & {});
export interface UpdateSafetyLeverStateInput {
    status: SafetyLeverStatusInput;
    reason: string;
}
export interface UpdateSafetyLeverStateRequest {
    id: string;
    state: UpdateSafetyLeverStateInput;
}
export interface UpdateSafetyLeverStateResponse {
    safetyLever?: SafetyLever | undefined;
}
export interface UpdateTargetAccountConfigurationRequest {
    experimentTemplateId: string;
    accountId: string;
    roleArn?: string | undefined;
    description?: string | undefined;
}
export interface UpdateTargetAccountConfigurationResponse {
    targetAccountConfiguration?: TargetAccountConfiguration | undefined;
}
export type ExceptionMessage = string;
export type CreateExperimentTemplateError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an experiment template.
 *
 * An experiment template includes the following components:
 *
 * - **Targets**: A target can be a specific resource in
 * your Amazon Web Services environment, or one or more resources that match criteria that you
 * specify, for example, resources that have specific tags.
 *
 * - **Actions**: The actions to carry out on the
 * target. You can specify multiple actions, the duration of each action, and when to start each action during an experiment.
 *
 * - **Stop conditions**: If a stop condition is
 * triggered while an experiment is running, the experiment is automatically
 * stopped. You can define a stop condition as a CloudWatch alarm.
 *
 * For more information, see experiment templates
 * in the *Fault Injection Service User Guide*.
 */
export declare const createExperimentTemplate: API.OperationMethod<CreateExperimentTemplateRequest & RegionInput, CreateExperimentTemplateResponse, CreateExperimentTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateTargetAccountConfigurationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a target account configuration for the experiment template. A target account configuration
 * is required when `accountTargeting` of `experimentOptions` is set to `multi-account`.
 * For more information, see experiment options
 * in the *Fault Injection Service User Guide*.
 */
export declare const createTargetAccountConfiguration: API.OperationMethod<CreateTargetAccountConfigurationRequest & RegionInput, CreateTargetAccountConfigurationResponse, CreateTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteExperimentTemplateError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified experiment template.
 */
export declare const deleteExperimentTemplate: API.OperationMethod<DeleteExperimentTemplateRequest & RegionInput, DeleteExperimentTemplateResponse, DeleteExperimentTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteTargetAccountConfigurationError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified target account configuration of the experiment template.
 */
export declare const deleteTargetAccountConfiguration: API.OperationMethod<DeleteTargetAccountConfigurationRequest & RegionInput, DeleteTargetAccountConfigurationResponse, DeleteTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetActionError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified FIS action.
 */
export declare const getAction: API.OperationMethod<GetActionRequest & RegionInput, GetActionResponse, GetActionError, Credentials | HttpClient.HttpClient>;
export type GetExperimentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified experiment.
 */
export declare const getExperiment: API.OperationMethod<GetExperimentRequest & RegionInput, GetExperimentResponse, GetExperimentError, Credentials | HttpClient.HttpClient>;
export type GetExperimentTargetAccountConfigurationError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified target account configuration of the experiment.
 */
export declare const getExperimentTargetAccountConfiguration: API.OperationMethod<GetExperimentTargetAccountConfigurationRequest & RegionInput, GetExperimentTargetAccountConfigurationResponse, GetExperimentTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetExperimentTemplateError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified experiment template.
 */
export declare const getExperimentTemplate: API.OperationMethod<GetExperimentTemplateRequest & RegionInput, GetExperimentTemplateResponse, GetExperimentTemplateError, Credentials | HttpClient.HttpClient>;
export type GetSafetyLeverError = ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified safety lever.
 */
export declare const getSafetyLever: API.OperationMethod<GetSafetyLeverRequest & RegionInput, GetSafetyLeverResponse, GetSafetyLeverError, Credentials | HttpClient.HttpClient>;
export type GetTargetAccountConfigurationError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified target account configuration of the experiment template.
 */
export declare const getTargetAccountConfiguration: API.OperationMethod<GetTargetAccountConfigurationRequest & RegionInput, GetTargetAccountConfigurationResponse, GetTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTargetResourceTypeError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified resource type.
 */
export declare const getTargetResourceType: API.OperationMethod<GetTargetResourceTypeRequest & RegionInput, GetTargetResourceTypeResponse, GetTargetResourceTypeError, Credentials | HttpClient.HttpClient>;
export type ListActionsError = ValidationException | CommonErrors;
/**
 * Lists the available FIS actions.
 */
export declare const listActions: API.PaginatedOperationMethod<ListActionsRequest & RegionInput, ListActionsResponse, ListActionsError, Credentials | HttpClient.HttpClient, ActionSummary>;
export type ListExperimentResolvedTargetsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the resolved targets information of the specified experiment.
 */
export declare const listExperimentResolvedTargets: API.PaginatedOperationMethod<ListExperimentResolvedTargetsRequest & RegionInput, ListExperimentResolvedTargetsResponse, ListExperimentResolvedTargetsError, Credentials | HttpClient.HttpClient, ResolvedTarget>;
export type ListExperimentsError = ValidationException | CommonErrors;
/**
 * Lists your experiments.
 */
export declare const listExperiments: API.PaginatedOperationMethod<ListExperimentsRequest & RegionInput, ListExperimentsResponse, ListExperimentsError, Credentials | HttpClient.HttpClient, ExperimentSummary>;
export type ListExperimentTargetAccountConfigurationsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the target account configurations of the specified experiment.
 */
export declare const listExperimentTargetAccountConfigurations: API.OperationMethod<ListExperimentTargetAccountConfigurationsRequest & RegionInput, ListExperimentTargetAccountConfigurationsResponse, ListExperimentTargetAccountConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListExperimentTemplatesError = ValidationException | CommonErrors;
/**
 * Lists your experiment templates.
 */
export declare const listExperimentTemplates: API.PaginatedOperationMethod<ListExperimentTemplatesRequest & RegionInput, ListExperimentTemplatesResponse, ListExperimentTemplatesError, Credentials | HttpClient.HttpClient, ExperimentTemplateSummary>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetAccountConfigurationsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the target account configurations of the specified experiment template.
 */
export declare const listTargetAccountConfigurations: API.PaginatedOperationMethod<ListTargetAccountConfigurationsRequest & RegionInput, ListTargetAccountConfigurationsResponse, ListTargetAccountConfigurationsError, Credentials | HttpClient.HttpClient, TargetAccountConfigurationSummary>;
export type ListTargetResourceTypesError = ValidationException | CommonErrors;
/**
 * Lists the target resource types.
 */
export declare const listTargetResourceTypes: API.PaginatedOperationMethod<ListTargetResourceTypesRequest & RegionInput, ListTargetResourceTypesResponse, ListTargetResourceTypesError, Credentials | HttpClient.HttpClient, TargetResourceTypeSummary>;
export type StartExperimentError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Starts running an experiment from the specified experiment template.
 */
export declare const startExperiment: API.OperationMethod<StartExperimentRequest & RegionInput, StartExperimentResponse, StartExperimentError, Credentials | HttpClient.HttpClient>;
export type StopExperimentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the specified experiment.
 */
export declare const stopExperiment: API.OperationMethod<StopExperimentRequest & RegionInput, StopExperimentResponse, StopExperimentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Applies the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateExperimentTemplateError = ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates the specified experiment template.
 */
export declare const updateExperimentTemplate: API.OperationMethod<UpdateExperimentTemplateRequest & RegionInput, UpdateExperimentTemplateResponse, UpdateExperimentTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateSafetyLeverStateError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the specified safety lever state.
 */
export declare const updateSafetyLeverState: API.OperationMethod<UpdateSafetyLeverStateRequest & RegionInput, UpdateSafetyLeverStateResponse, UpdateSafetyLeverStateError, Credentials | HttpClient.HttpClient>;
export type UpdateTargetAccountConfigurationError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the target account configuration for the specified experiment template.
 */
export declare const updateTargetAccountConfiguration: API.OperationMethod<UpdateTargetAccountConfigurationRequest & RegionInput, UpdateTargetAccountConfigurationResponse, UpdateTargetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=fis.d.ts.map