import type { Kit, Model } from "../Kit.ts";
import type { V } from "../Value.ts";
/**
 * `BigDecimal`: a decimal number held exactly, which is what money is counted
 * in. The solver's real numbers are exact too, so a sum, a difference, a
 * product and a comparison are read as they are. A division is not: the
 * library rounds one that does not end.
 */
export declare const make: (kit: Kit) => {
    models: Readonly<Record<string, Model>>;
    values: Record<string, V>;
};
//# sourceMappingURL=Decimals.d.ts.map