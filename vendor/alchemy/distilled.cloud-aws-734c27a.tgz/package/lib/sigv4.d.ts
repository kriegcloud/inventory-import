export * from "@distilled.cloud/s3/SigV4";
//# sourceMappingURL=sigv4.d.ts.map