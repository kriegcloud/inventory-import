import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly ResourceId: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
declare const VerificationFailedException_base: S.TaggedErrorClass<"VerificationFailedException", {
    readonly Reason: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class VerificationFailedException extends /*@__PURE__*/ VerificationFailedException_base {
}
export type KeyArnOrKeyAliasType = string;
export type CipherTextType = string | redacted.Redacted<string>;
export type EncryptionMode = "ECB" | "CBC" | "CFB" | "CFB1" | "CFB8" | "CFB64" | "CFB128" | "OFB" | (string & {});
export type InitializationVectorType = string | redacted.Redacted<string>;
export type PaddingType = "PKCS1" | "OAEP_SHA1" | "OAEP_SHA256" | "OAEP_SHA512" | (string & {});
export interface SymmetricEncryptionAttributes {
    Mode: EncryptionMode;
    InitializationVector?: string | redacted.Redacted<string> | undefined;
    PaddingType?: PaddingType | undefined;
}
export interface AsymmetricEncryptionAttributes {
    PaddingType?: PaddingType | undefined;
}
export type HexLength16Or20Or24 = string;
export type DukptEncryptionMode = "ECB" | "CBC" | (string & {});
export type DukptDerivationType = "TDES_2KEY" | "TDES_3KEY" | "AES_128" | "AES_192" | "AES_256" | (string & {});
export type DukptKeyVariant = "BIDIRECTIONAL" | "REQUEST" | "RESPONSE" | (string & {});
export interface DukptEncryptionAttributes {
    KeySerialNumber: string;
    Mode?: DukptEncryptionMode | undefined;
    DukptKeyDerivationType?: DukptDerivationType | undefined;
    DukptKeyVariant?: DukptKeyVariant | undefined;
    InitializationVector?: string | redacted.Redacted<string> | undefined;
}
export type EmvMajorKeyDerivationMode = "EMV_OPTION_A" | "EMV_OPTION_B" | (string & {});
export type PrimaryAccountNumberType = string | redacted.Redacted<string>;
export type NumberLengthEquals2 = string;
export type SessionDerivationDataType = string | redacted.Redacted<string>;
export type EmvEncryptionMode = "ECB" | "CBC" | (string & {});
export interface EmvEncryptionAttributes {
    MajorKeyDerivationMode: EmvMajorKeyDerivationMode;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    SessionDerivationData: string | redacted.Redacted<string>;
    Mode?: EmvEncryptionMode | undefined;
    InitializationVector?: string | redacted.Redacted<string> | undefined;
}
export type EncryptionDecryptionAttributes = {
    Symmetric: SymmetricEncryptionAttributes;
    Asymmetric?: undefined;
    Dukpt?: undefined;
    Emv?: undefined;
} | {
    Symmetric?: undefined;
    Asymmetric: AsymmetricEncryptionAttributes;
    Dukpt?: undefined;
    Emv?: undefined;
} | {
    Symmetric?: undefined;
    Asymmetric?: undefined;
    Dukpt: DukptEncryptionAttributes;
    Emv?: undefined;
} | {
    Symmetric?: undefined;
    Asymmetric?: undefined;
    Dukpt?: undefined;
    Emv: EmvEncryptionAttributes;
};
export type Tr31WrappedKeyBlock = string | redacted.Redacted<string>;
export type CertificateType = string;
export type SymmetricKeyAlgorithm = "TDES_2KEY" | "TDES_3KEY" | "AES_128" | "AES_192" | "AES_256" | "HMAC_SHA256" | "HMAC_SHA384" | "HMAC_SHA512" | "HMAC_SHA224" | (string & {});
export type KeyDerivationFunction = "NIST_SP800" | "ANSI_X963" | (string & {});
export type KeyDerivationHashAlgorithm = "SHA_256" | "SHA_384" | "SHA_512" | (string & {});
export type SharedInformation = string;
export interface EcdhDerivationAttributes {
    CertificateAuthorityPublicKeyIdentifier: string;
    PublicKeyCertificate: string;
    KeyAlgorithm: SymmetricKeyAlgorithm;
    KeyDerivationFunction: KeyDerivationFunction;
    KeyDerivationHashAlgorithm: KeyDerivationHashAlgorithm;
    SharedInformation: string;
}
export type WrappedKeyMaterial = {
    Tr31KeyBlock: string | redacted.Redacted<string>;
    DiffieHellmanSymmetricKey?: undefined;
} | {
    Tr31KeyBlock?: undefined;
    DiffieHellmanSymmetricKey: EcdhDerivationAttributes;
};
export type KeyCheckValueAlgorithm = string;
export interface WrappedKey {
    WrappedKeyMaterial: WrappedKeyMaterial;
    KeyCheckValueAlgorithm?: string | undefined;
}
export interface DecryptDataInput {
    KeyIdentifier: string;
    CipherText: string | redacted.Redacted<string>;
    DecryptionAttributes: EncryptionDecryptionAttributes;
    WrappedKey?: WrappedKey | undefined;
}
export type KeyArn = string;
export type KeyCheckValue = string;
export type PlainTextOutputType = string | redacted.Redacted<string>;
export interface DecryptDataOutput {
    KeyArn: string;
    KeyCheckValue: string;
    PlainText: string | redacted.Redacted<string>;
}
export type PlainTextType = string | redacted.Redacted<string>;
export interface EncryptDataInput {
    KeyIdentifier: string;
    PlainText: string | redacted.Redacted<string>;
    EncryptionAttributes: EncryptionDecryptionAttributes;
    WrappedKey?: WrappedKey | undefined;
}
export interface EncryptDataOutput {
    KeyArn: string;
    KeyCheckValue?: string | undefined;
    CipherText: string | redacted.Redacted<string>;
}
export type RandomKeyMaxLength = "BYTES_8" | "BYTES_16" | "BYTES_24" | (string & {});
export interface KekValidationRequest {
    DeriveKeyAlgorithm: SymmetricKeyAlgorithm;
    RandomKeyMaxLength?: RandomKeyMaxLength | undefined;
}
export type As2805RandomKeyMaterial = string | redacted.Redacted<string>;
export interface KekValidationResponse {
    RandomKeySend: string | redacted.Redacted<string>;
}
export type As2805KekValidationType = {
    KekValidationRequest: KekValidationRequest;
    KekValidationResponse?: undefined;
} | {
    KekValidationRequest?: undefined;
    KekValidationResponse: KekValidationResponse;
};
export type RandomKeySendVariantMask = "VARIANT_MASK_82C0" | "VARIANT_MASK_82" | (string & {});
export interface GenerateAs2805KekValidationInput {
    KeyIdentifier: string;
    KekValidationType: As2805KekValidationType;
    RandomKeySendVariantMask: RandomKeySendVariantMask;
}
export interface GenerateAs2805KekValidationOutput {
    KeyArn: string;
    KeyCheckValue: string;
    RandomKeySend: string | redacted.Redacted<string>;
    RandomKeyReceive: string | redacted.Redacted<string>;
}
export type TransactionDataType = string | redacted.Redacted<string>;
export type MajorKeyDerivationMode = "EMV_OPTION_A" | "EMV_OPTION_B" | (string & {});
export type HexLengthEquals4 = string;
export interface SessionKeyEmvCommon {
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
}
export type HexLengthEquals8 = string;
export interface SessionKeyMastercard {
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
    UnpredictableNumber: string;
}
export interface SessionKeyEmv2000 {
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
}
export interface SessionKeyAmex {
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
}
export interface SessionKeyVisa {
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
}
export interface SessionKeyUnionPay {
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
}
export type SessionKeyDerivation = {
    EmvCommon: SessionKeyEmvCommon;
    Mastercard?: undefined;
    Emv2000?: undefined;
    Amex?: undefined;
    Visa?: undefined;
    UnionPay?: undefined;
} | {
    EmvCommon?: undefined;
    Mastercard: SessionKeyMastercard;
    Emv2000?: undefined;
    Amex?: undefined;
    Visa?: undefined;
    UnionPay?: undefined;
} | {
    EmvCommon?: undefined;
    Mastercard?: undefined;
    Emv2000: SessionKeyEmv2000;
    Amex?: undefined;
    Visa?: undefined;
    UnionPay?: undefined;
} | {
    EmvCommon?: undefined;
    Mastercard?: undefined;
    Emv2000?: undefined;
    Amex: SessionKeyAmex;
    Visa?: undefined;
    UnionPay?: undefined;
} | {
    EmvCommon?: undefined;
    Mastercard?: undefined;
    Emv2000?: undefined;
    Amex?: undefined;
    Visa: SessionKeyVisa;
    UnionPay?: undefined;
} | {
    EmvCommon?: undefined;
    Mastercard?: undefined;
    Emv2000?: undefined;
    Amex?: undefined;
    Visa?: undefined;
    UnionPay: SessionKeyUnionPay;
};
export interface GenerateAuthRequestCryptogramInput {
    KeyIdentifier: string;
    TransactionData: string | redacted.Redacted<string>;
    MajorKeyDerivationMode: MajorKeyDerivationMode;
    SessionKeyDerivationAttributes: SessionKeyDerivation;
}
export type AuthRequestCryptogramType = string | redacted.Redacted<string>;
export interface GenerateAuthRequestCryptogramOutput {
    KeyArn: string;
    KeyCheckValue: string;
    AuthRequestCryptogram: string | redacted.Redacted<string>;
}
export type CardExpiryDateType = string | redacted.Redacted<string>;
export interface AmexCardSecurityCodeVersion1 {
    CardExpiryDate: string | redacted.Redacted<string>;
}
export type ServiceCodeType = string | redacted.Redacted<string>;
export interface AmexCardSecurityCodeVersion2 {
    CardExpiryDate: string | redacted.Redacted<string>;
    ServiceCode: string | redacted.Redacted<string>;
}
export interface CardVerificationValue1 {
    CardExpiryDate: string | redacted.Redacted<string>;
    ServiceCode: string | redacted.Redacted<string>;
}
export interface CardVerificationValue2 {
    CardExpiryDate: string | redacted.Redacted<string>;
}
export type HexLengthBetween2And8 = string;
export type HexLengthBetween2And4 = string;
export interface CardHolderVerificationValue {
    UnpredictableNumber: string;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
}
export type TrackDataType = string | redacted.Redacted<string>;
export interface DynamicCardVerificationCode {
    UnpredictableNumber: string;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
    TrackData: string | redacted.Redacted<string>;
}
export interface DynamicCardVerificationValue {
    PanSequenceNumber: string;
    CardExpiryDate: string | redacted.Redacted<string>;
    ServiceCode: string | redacted.Redacted<string>;
    ApplicationTransactionCounter: string;
}
export type CardGenerationAttributes = {
    AmexCardSecurityCodeVersion1: AmexCardSecurityCodeVersion1;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2: AmexCardSecurityCodeVersion2;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1: CardVerificationValue1;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2: CardVerificationValue2;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue: CardHolderVerificationValue;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode: DynamicCardVerificationCode;
    DynamicCardVerificationValue?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue: DynamicCardVerificationValue;
};
export type IntegerRangeBetween3And5Type = number;
export interface GenerateCardValidationDataInput {
    KeyIdentifier: string;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    GenerationAttributes: CardGenerationAttributes;
    ValidationDataLength?: number | undefined;
}
export type ValidationDataType = string | redacted.Redacted<string>;
export interface GenerateCardValidationDataOutput {
    KeyArn: string;
    KeyCheckValue: string;
    ValidationData: string | redacted.Redacted<string>;
}
export type MessageDataType = string | redacted.Redacted<string>;
export type MacAlgorithm = "ISO9797_ALGORITHM1" | "ISO9797_ALGORITHM3" | "CMAC" | "HMAC" | "HMAC_SHA224" | "HMAC_SHA256" | "HMAC_SHA384" | "HMAC_SHA512" | "AS2805_4_1" | (string & {});
export type SessionKeyDerivationMode = "EMV_COMMON_SESSION_KEY" | "EMV2000" | "AMEX" | "MASTERCARD_SESSION_KEY" | "VISA" | "UNION_PAY" | (string & {});
export type ApplicationCryptogramType = string | redacted.Redacted<string>;
export type SessionKeyDerivationValue = {
    ApplicationCryptogram: string | redacted.Redacted<string>;
    ApplicationTransactionCounter?: undefined;
} | {
    ApplicationCryptogram?: undefined;
    ApplicationTransactionCounter: string;
};
export interface MacAlgorithmEmv {
    MajorKeyDerivationMode: MajorKeyDerivationMode;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    SessionKeyDerivationMode: SessionKeyDerivationMode;
    SessionKeyDerivationValue: SessionKeyDerivationValue;
}
export interface MacAlgorithmDukpt {
    KeySerialNumber: string;
    DukptKeyVariant: DukptKeyVariant;
    DukptDerivationType?: DukptDerivationType | undefined;
}
export type MacAttributes = {
    Algorithm: MacAlgorithm;
    EmvMac?: undefined;
    DukptIso9797Algorithm1?: undefined;
    DukptIso9797Algorithm3?: undefined;
    DukptCmac?: undefined;
} | {
    Algorithm?: undefined;
    EmvMac: MacAlgorithmEmv;
    DukptIso9797Algorithm1?: undefined;
    DukptIso9797Algorithm3?: undefined;
    DukptCmac?: undefined;
} | {
    Algorithm?: undefined;
    EmvMac?: undefined;
    DukptIso9797Algorithm1: MacAlgorithmDukpt;
    DukptIso9797Algorithm3?: undefined;
    DukptCmac?: undefined;
} | {
    Algorithm?: undefined;
    EmvMac?: undefined;
    DukptIso9797Algorithm1?: undefined;
    DukptIso9797Algorithm3: MacAlgorithmDukpt;
    DukptCmac?: undefined;
} | {
    Algorithm?: undefined;
    EmvMac?: undefined;
    DukptIso9797Algorithm1?: undefined;
    DukptIso9797Algorithm3?: undefined;
    DukptCmac: MacAlgorithmDukpt;
};
export type IntegerRangeBetween4And32 = number;
export interface GenerateMacInput {
    KeyIdentifier: string;
    MessageData: string | redacted.Redacted<string>;
    GenerationAttributes: MacAttributes;
    MacLength?: number | undefined;
}
export type MacOutputType = string | redacted.Redacted<string>;
export interface GenerateMacOutput {
    KeyArn: string;
    KeyCheckValue: string;
    Mac: string | redacted.Redacted<string>;
}
export type PinBlockLengthEquals16 = string | redacted.Redacted<string>;
export type PinBlockFormatForEmvPinChange = "ISO_FORMAT_0" | "ISO_FORMAT_1" | "ISO_FORMAT_3" | (string & {});
export type CommandMessageDataType = string | redacted.Redacted<string>;
export type PinBlockPaddingType = "NO_PADDING" | "ISO_IEC_7816_4" | (string & {});
export type PinBlockLengthPosition = "NONE" | "FRONT_OF_PIN_BLOCK" | (string & {});
export interface EmvCommonAttributes {
    MajorKeyDerivationMode: MajorKeyDerivationMode;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationCryptogram: string | redacted.Redacted<string>;
    Mode: EmvEncryptionMode;
    PinBlockPaddingType: PinBlockPaddingType;
    PinBlockLengthPosition: PinBlockLengthPosition;
}
export interface CurrentPinAttributes {
    CurrentPinPekIdentifier: string;
    CurrentEncryptedPinBlock: string | redacted.Redacted<string>;
}
export interface AmexAttributes {
    MajorKeyDerivationMode: MajorKeyDerivationMode;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
    AuthorizationRequestKeyIdentifier: string;
    CurrentPinAttributes?: CurrentPinAttributes | undefined;
}
export interface VisaAttributes {
    MajorKeyDerivationMode: MajorKeyDerivationMode;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
    AuthorizationRequestKeyIdentifier: string;
    CurrentPinAttributes?: CurrentPinAttributes | undefined;
}
export interface Emv2000Attributes {
    MajorKeyDerivationMode: MajorKeyDerivationMode;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationTransactionCounter: string;
}
export interface MasterCardAttributes {
    MajorKeyDerivationMode: MajorKeyDerivationMode;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    PanSequenceNumber: string;
    ApplicationCryptogram: string | redacted.Redacted<string>;
}
export type DerivationMethodAttributes = {
    EmvCommon: EmvCommonAttributes;
    Amex?: undefined;
    Visa?: undefined;
    Emv2000?: undefined;
    Mastercard?: undefined;
} | {
    EmvCommon?: undefined;
    Amex: AmexAttributes;
    Visa?: undefined;
    Emv2000?: undefined;
    Mastercard?: undefined;
} | {
    EmvCommon?: undefined;
    Amex?: undefined;
    Visa: VisaAttributes;
    Emv2000?: undefined;
    Mastercard?: undefined;
} | {
    EmvCommon?: undefined;
    Amex?: undefined;
    Visa?: undefined;
    Emv2000: Emv2000Attributes;
    Mastercard?: undefined;
} | {
    EmvCommon?: undefined;
    Amex?: undefined;
    Visa?: undefined;
    Emv2000?: undefined;
    Mastercard: MasterCardAttributes;
};
export interface GenerateMacEmvPinChangeInput {
    NewPinPekIdentifier: string;
    NewEncryptedPinBlock: string | redacted.Redacted<string>;
    PinBlockFormat: PinBlockFormatForEmvPinChange;
    SecureMessagingIntegrityKeyIdentifier: string;
    SecureMessagingConfidentialityKeyIdentifier: string;
    MessageData: string | redacted.Redacted<string>;
    DerivationMethodAttributes: DerivationMethodAttributes;
}
export type PinChangeMacOutputType = string | redacted.Redacted<string>;
export type EncryptedPinBlockType = string | redacted.Redacted<string>;
export interface VisaAmexDerivationOutputs {
    AuthorizationRequestKeyArn: string;
    AuthorizationRequestKeyCheckValue: string;
    CurrentPinPekArn?: string | undefined;
    CurrentPinPekKeyCheckValue?: string | undefined;
}
export interface GenerateMacEmvPinChangeOutput {
    NewPinPekArn: string;
    SecureMessagingIntegrityKeyArn: string;
    SecureMessagingConfidentialityKeyArn: string;
    Mac: string | redacted.Redacted<string>;
    EncryptedPinBlock: string | redacted.Redacted<string>;
    NewPinPekKeyCheckValue: string;
    SecureMessagingIntegrityKeyCheckValue: string;
    SecureMessagingConfidentialityKeyCheckValue: string;
    VisaAmexDerivationOutputs?: VisaAmexDerivationOutputs | undefined;
}
export type IntegerRangeBetween0And6 = number;
export interface VisaPin {
    PinVerificationKeyIndex: number;
}
export interface VisaPinVerificationValue {
    EncryptedPinBlock: string | redacted.Redacted<string>;
    PinVerificationKeyIndex: number;
}
export type DecimalizationTableType = string | redacted.Redacted<string>;
export type HexLengthEquals1 = string;
export type PinValidationDataType = string | redacted.Redacted<string>;
export interface Ibm3624PinOffset {
    EncryptedPinBlock: string | redacted.Redacted<string>;
    DecimalizationTable: string | redacted.Redacted<string>;
    PinValidationDataPadCharacter: string;
    PinValidationData: string | redacted.Redacted<string>;
}
export interface Ibm3624NaturalPin {
    DecimalizationTable: string | redacted.Redacted<string>;
    PinValidationDataPadCharacter: string;
    PinValidationData: string | redacted.Redacted<string>;
}
export interface Ibm3624RandomPin {
    DecimalizationTable: string | redacted.Redacted<string>;
    PinValidationDataPadCharacter: string;
    PinValidationData: string | redacted.Redacted<string>;
}
export type PinOffsetType = string | redacted.Redacted<string>;
export interface Ibm3624PinFromOffset {
    DecimalizationTable: string | redacted.Redacted<string>;
    PinValidationDataPadCharacter: string;
    PinValidationData: string | redacted.Redacted<string>;
    PinOffset: string | redacted.Redacted<string>;
}
export type PinGenerationAttributes = {
    VisaPin: VisaPin;
    VisaPinVerificationValue?: undefined;
    Ibm3624PinOffset?: undefined;
    Ibm3624NaturalPin?: undefined;
    Ibm3624RandomPin?: undefined;
    Ibm3624PinFromOffset?: undefined;
} | {
    VisaPin?: undefined;
    VisaPinVerificationValue: VisaPinVerificationValue;
    Ibm3624PinOffset?: undefined;
    Ibm3624NaturalPin?: undefined;
    Ibm3624RandomPin?: undefined;
    Ibm3624PinFromOffset?: undefined;
} | {
    VisaPin?: undefined;
    VisaPinVerificationValue?: undefined;
    Ibm3624PinOffset: Ibm3624PinOffset;
    Ibm3624NaturalPin?: undefined;
    Ibm3624RandomPin?: undefined;
    Ibm3624PinFromOffset?: undefined;
} | {
    VisaPin?: undefined;
    VisaPinVerificationValue?: undefined;
    Ibm3624PinOffset?: undefined;
    Ibm3624NaturalPin: Ibm3624NaturalPin;
    Ibm3624RandomPin?: undefined;
    Ibm3624PinFromOffset?: undefined;
} | {
    VisaPin?: undefined;
    VisaPinVerificationValue?: undefined;
    Ibm3624PinOffset?: undefined;
    Ibm3624NaturalPin?: undefined;
    Ibm3624RandomPin: Ibm3624RandomPin;
    Ibm3624PinFromOffset?: undefined;
} | {
    VisaPin?: undefined;
    VisaPinVerificationValue?: undefined;
    Ibm3624PinOffset?: undefined;
    Ibm3624NaturalPin?: undefined;
    Ibm3624RandomPin?: undefined;
    Ibm3624PinFromOffset: Ibm3624PinFromOffset;
};
export type IntegerRangeBetween4And12 = number;
export type PinBlockFormatForPinData = "ISO_FORMAT_0" | "ISO_FORMAT_1" | "ISO_FORMAT_3" | "ISO_FORMAT_4" | (string & {});
export interface GeneratePinDataInput {
    GenerationKeyIdentifier: string;
    EncryptionKeyIdentifier: string;
    GenerationAttributes: PinGenerationAttributes;
    PinDataLength?: number | undefined;
    PrimaryAccountNumber?: string | redacted.Redacted<string> | undefined;
    PinBlockFormat: PinBlockFormatForPinData;
    EncryptionWrappedKey?: WrappedKey | undefined;
}
export type VerificationValueType = string | redacted.Redacted<string>;
export type PinData = {
    PinOffset: string | redacted.Redacted<string>;
    VerificationValue?: undefined;
} | {
    PinOffset?: undefined;
    VerificationValue: string | redacted.Redacted<string>;
};
export interface GeneratePinDataOutput {
    GenerationKeyArn: string;
    GenerationKeyCheckValue: string;
    EncryptionKeyArn: string;
    EncryptionKeyCheckValue: string;
    EncryptedPinBlock: string | redacted.Redacted<string>;
    PinData: PinData;
}
export type ReEncryptionAttributes = {
    Symmetric: SymmetricEncryptionAttributes;
    Asymmetric?: undefined;
    Dukpt?: undefined;
} | {
    Symmetric?: undefined;
    Asymmetric: AsymmetricEncryptionAttributes;
    Dukpt?: undefined;
} | {
    Symmetric?: undefined;
    Asymmetric?: undefined;
    Dukpt: DukptEncryptionAttributes;
};
export interface ReEncryptDataInput {
    IncomingKeyIdentifier: string;
    OutgoingKeyIdentifier: string;
    CipherText: string | redacted.Redacted<string>;
    IncomingEncryptionAttributes: ReEncryptionAttributes;
    OutgoingEncryptionAttributes: ReEncryptionAttributes;
    IncomingWrappedKey?: WrappedKey | undefined;
    OutgoingWrappedKey?: WrappedKey | undefined;
}
export interface ReEncryptDataOutput {
    KeyArn: string;
    KeyCheckValue: string;
    CipherText: string | redacted.Redacted<string>;
}
export type DiffieHellmanDerivationData = {
    SharedInformation: string;
};
export interface IncomingDiffieHellmanTr31KeyBlock {
    PrivateKeyIdentifier: string;
    CertificateAuthorityPublicKeyIdentifier: string;
    PublicKeyCertificate: string;
    DeriveKeyAlgorithm: SymmetricKeyAlgorithm;
    KeyDerivationFunction: KeyDerivationFunction;
    KeyDerivationHashAlgorithm: KeyDerivationHashAlgorithm;
    DerivationData: DiffieHellmanDerivationData;
    WrappedKeyBlock: string | redacted.Redacted<string>;
}
export type IncomingKeyMaterial = {
    DiffieHellmanTr31KeyBlock: IncomingDiffieHellmanTr31KeyBlock;
};
export interface OutgoingTr31KeyBlock {
    WrappingKeyIdentifier: string;
}
export type OutgoingKeyMaterial = {
    Tr31KeyBlock: OutgoingTr31KeyBlock;
};
export interface TranslateKeyMaterialInput {
    IncomingKeyMaterial: IncomingKeyMaterial;
    OutgoingKeyMaterial: OutgoingKeyMaterial;
    KeyCheckValueAlgorithm?: string | undefined;
}
export type KeyMaterial = string | redacted.Redacted<string>;
export type WrappedKeyMaterialFormat = string;
export interface WrappedWorkingKey {
    WrappedKeyMaterial: string | redacted.Redacted<string>;
    KeyCheckValue: string;
    WrappedKeyMaterialFormat: string;
}
export interface TranslateKeyMaterialOutput {
    WrappedKey: WrappedWorkingKey;
}
export interface TranslationPinDataIsoFormat034 {
    PrimaryAccountNumber: string | redacted.Redacted<string>;
}
export interface TranslationPinDataIsoFormat1 {
}
export interface TranslationPinDataAs2805Format0 {
    PrimaryAccountNumber: string | redacted.Redacted<string>;
}
export type TranslationIsoFormats = {
    IsoFormat0: TranslationPinDataIsoFormat034;
    IsoFormat1?: undefined;
    IsoFormat3?: undefined;
    IsoFormat4?: undefined;
    As2805Format0?: undefined;
} | {
    IsoFormat0?: undefined;
    IsoFormat1: TranslationPinDataIsoFormat1;
    IsoFormat3?: undefined;
    IsoFormat4?: undefined;
    As2805Format0?: undefined;
} | {
    IsoFormat0?: undefined;
    IsoFormat1?: undefined;
    IsoFormat3: TranslationPinDataIsoFormat034;
    IsoFormat4?: undefined;
    As2805Format0?: undefined;
} | {
    IsoFormat0?: undefined;
    IsoFormat1?: undefined;
    IsoFormat3?: undefined;
    IsoFormat4: TranslationPinDataIsoFormat034;
    As2805Format0?: undefined;
} | {
    IsoFormat0?: undefined;
    IsoFormat1?: undefined;
    IsoFormat3?: undefined;
    IsoFormat4?: undefined;
    As2805Format0: TranslationPinDataAs2805Format0;
};
export type HexEvenLengthBetween16And32 = string | redacted.Redacted<string>;
export interface DukptDerivationAttributes {
    KeySerialNumber: string;
    DukptKeyDerivationType?: DukptDerivationType | undefined;
    DukptKeyVariant?: DukptKeyVariant | undefined;
}
export type SystemTraceAuditNumberType = string;
export type TransactionAmountType = string;
export interface As2805PekDerivationAttributes {
    SystemTraceAuditNumber: string;
    TransactionAmount: string;
}
export interface TranslatePinDataInput {
    IncomingKeyIdentifier: string;
    OutgoingKeyIdentifier: string;
    IncomingTranslationAttributes: TranslationIsoFormats;
    OutgoingTranslationAttributes: TranslationIsoFormats;
    EncryptedPinBlock: string | redacted.Redacted<string>;
    IncomingDukptAttributes?: DukptDerivationAttributes | undefined;
    OutgoingDukptAttributes?: DukptDerivationAttributes | undefined;
    IncomingWrappedKey?: WrappedKey | undefined;
    OutgoingWrappedKey?: WrappedKey | undefined;
    IncomingAs2805Attributes?: As2805PekDerivationAttributes | undefined;
}
export interface TranslatePinDataOutput {
    PinBlock: string | redacted.Redacted<string>;
    KeyArn: string;
    KeyCheckValue: string;
}
export interface CryptogramVerificationArpcMethod1 {
    AuthResponseCode: string;
}
export type ProprietaryAuthenticationDataType = string | redacted.Redacted<string>;
export interface CryptogramVerificationArpcMethod2 {
    CardStatusUpdate: string;
    ProprietaryAuthenticationData?: string | redacted.Redacted<string> | undefined;
}
export type CryptogramAuthResponse = {
    ArpcMethod1: CryptogramVerificationArpcMethod1;
    ArpcMethod2?: undefined;
} | {
    ArpcMethod1?: undefined;
    ArpcMethod2: CryptogramVerificationArpcMethod2;
};
export interface VerifyAuthRequestCryptogramInput {
    KeyIdentifier: string;
    TransactionData: string | redacted.Redacted<string>;
    AuthRequestCryptogram: string | redacted.Redacted<string>;
    MajorKeyDerivationMode: MajorKeyDerivationMode;
    SessionKeyDerivationAttributes: SessionKeyDerivation;
    AuthResponseAttributes?: CryptogramAuthResponse | undefined;
}
export type AuthResponseValueType = string | redacted.Redacted<string>;
export interface VerifyAuthRequestCryptogramOutput {
    KeyArn: string;
    KeyCheckValue: string;
    AuthResponseValue?: string | redacted.Redacted<string> | undefined;
}
export interface DiscoverDynamicCardVerificationCode {
    CardExpiryDate: string | redacted.Redacted<string>;
    UnpredictableNumber: string;
    ApplicationTransactionCounter: string;
}
export type CardVerificationAttributes = {
    AmexCardSecurityCodeVersion1: AmexCardSecurityCodeVersion1;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
    DiscoverDynamicCardVerificationCode?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2: AmexCardSecurityCodeVersion2;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
    DiscoverDynamicCardVerificationCode?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1: CardVerificationValue1;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
    DiscoverDynamicCardVerificationCode?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2: CardVerificationValue2;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
    DiscoverDynamicCardVerificationCode?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue: CardHolderVerificationValue;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
    DiscoverDynamicCardVerificationCode?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode: DynamicCardVerificationCode;
    DynamicCardVerificationValue?: undefined;
    DiscoverDynamicCardVerificationCode?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue: DynamicCardVerificationValue;
    DiscoverDynamicCardVerificationCode?: undefined;
} | {
    AmexCardSecurityCodeVersion1?: undefined;
    AmexCardSecurityCodeVersion2?: undefined;
    CardVerificationValue1?: undefined;
    CardVerificationValue2?: undefined;
    CardHolderVerificationValue?: undefined;
    DynamicCardVerificationCode?: undefined;
    DynamicCardVerificationValue?: undefined;
    DiscoverDynamicCardVerificationCode: DiscoverDynamicCardVerificationCode;
};
export interface VerifyCardValidationDataInput {
    KeyIdentifier: string;
    PrimaryAccountNumber: string | redacted.Redacted<string>;
    VerificationAttributes: CardVerificationAttributes;
    ValidationData: string | redacted.Redacted<string>;
}
export interface VerifyCardValidationDataOutput {
    KeyArn: string;
    KeyCheckValue: string;
}
export type MacType = string | redacted.Redacted<string>;
export interface VerifyMacInput {
    KeyIdentifier: string;
    MessageData: string | redacted.Redacted<string>;
    Mac: string | redacted.Redacted<string>;
    VerificationAttributes: MacAttributes;
    MacLength?: number | undefined;
}
export interface VerifyMacOutput {
    KeyArn: string;
    KeyCheckValue: string;
}
export interface VisaPinVerification {
    PinVerificationKeyIndex: number;
    VerificationValue: string | redacted.Redacted<string>;
}
export interface Ibm3624PinVerification {
    DecimalizationTable: string | redacted.Redacted<string>;
    PinValidationDataPadCharacter: string;
    PinValidationData: string | redacted.Redacted<string>;
    PinOffset: string | redacted.Redacted<string>;
}
export type PinVerificationAttributes = {
    VisaPin: VisaPinVerification;
    Ibm3624Pin?: undefined;
} | {
    VisaPin?: undefined;
    Ibm3624Pin: Ibm3624PinVerification;
};
export interface DukptAttributes {
    KeySerialNumber: string;
    DukptDerivationType: DukptDerivationType;
}
export interface VerifyPinDataInput {
    VerificationKeyIdentifier: string;
    EncryptionKeyIdentifier: string;
    VerificationAttributes: PinVerificationAttributes;
    EncryptedPinBlock: string | redacted.Redacted<string>;
    PrimaryAccountNumber?: string | redacted.Redacted<string> | undefined;
    PinBlockFormat: PinBlockFormatForPinData;
    PinDataLength?: number | undefined;
    DukptAttributes?: DukptAttributes | undefined;
    EncryptionWrappedKey?: WrappedKey | undefined;
}
export interface VerifyPinDataOutput {
    VerificationKeyArn: string;
    VerificationKeyCheckValue: string;
    EncryptionKeyArn: string;
    EncryptionKeyCheckValue: string;
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type VerificationFailedReason = string;
export type DecryptDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Decrypts ciphertext data to plaintext using a symmetric (TDES, AES), asymmetric (RSA), or derived (DUKPT or EMV) encryption key scheme. For more information, see Decrypt data in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * You can use an decryption key generated within Amazon Web Services Payment Cryptography, or you can import your own decryption key by calling ImportKey. For this operation, the key must have `KeyModesOfUse` set to `Decrypt`. In asymmetric decryption, Amazon Web Services Payment Cryptography decrypts the ciphertext using the private component of the asymmetric encryption key pair. For data encryption outside of Amazon Web Services Payment Cryptography, you can export the public component of the asymmetric key pair by calling GetPublicCertificate.
 *
 * This operation also supports dynamic keys, allowing you to pass a dynamic decryption key as a TR-31 WrappedKeyBlock. This can be used when key material is frequently rotated, such as during every card transaction, and there is need to avoid importing short-lived keys into Amazon Web Services Payment Cryptography. To decrypt using dynamic keys, the `keyARN` is the Key Encryption Key (KEK) of the TR-31 wrapped decryption key material. The incoming wrapped key shall have a key purpose of D0 with a mode of use of B or D. For more information, see Using Dynamic Keys in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * For symmetric and DUKPT decryption, Amazon Web Services Payment Cryptography supports `TDES` and `AES` algorithms. For EMV decryption, Amazon Web Services Payment Cryptography supports `TDES` algorithms. For asymmetric decryption, Amazon Web Services Payment Cryptography supports `RSA`.
 *
 * When you use TDES or TDES DUKPT, the ciphertext data length must be a multiple of 8 bytes. For AES or AES DUKPT, the ciphertext data length must be a multiple of 16 bytes. For RSA, it sould be equal to the key size unless padding is enabled.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - EncryptData
 *
 * - GetPublicCertificate
 *
 * - ImportKey
 */
export declare const decryptData: API.OperationMethod<DecryptDataInput & RegionInput, DecryptDataOutput, DecryptDataError, Credentials | HttpClient.HttpClient>;
export type EncryptDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Encrypts plaintext data to ciphertext using a symmetric (TDES, AES), asymmetric (RSA), or derived (DUKPT or EMV) encryption key scheme. For more information, see Encrypt data in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * You can generate an encryption key within Amazon Web Services Payment Cryptography by calling CreateKey. You can import your own encryption key by calling ImportKey.
 *
 * For this operation, the key must have `KeyModesOfUse` set to `Encrypt`. In asymmetric encryption, plaintext is encrypted using public component. You can import the public component of an asymmetric key pair created outside Amazon Web Services Payment Cryptography by calling ImportKey.
 *
 * This operation also supports dynamic keys, allowing you to pass a dynamic encryption key as a TR-31 WrappedKeyBlock. This can be used when key material is frequently rotated, such as during every card transaction, and there is need to avoid importing short-lived keys into Amazon Web Services Payment Cryptography. To encrypt using dynamic keys, the `keyARN` is the Key Encryption Key (KEK) of the TR-31 wrapped encryption key material. The incoming wrapped key shall have a key purpose of D0 with a mode of use of B or D. For more information, see Using Dynamic Keys in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * For symmetric and DUKPT encryption, Amazon Web Services Payment Cryptography supports `TDES` and `AES` algorithms. For EMV encryption, Amazon Web Services Payment Cryptography supports `TDES` algorithms.For asymmetric encryption, Amazon Web Services Payment Cryptography supports `RSA`.
 *
 * When you use TDES or TDES DUKPT, the plaintext data length must be a multiple of 8 bytes. For AES or AES DUKPT, the plaintext data length must be a multiple of 16 bytes. For RSA, it sould be equal to the key size unless padding is enabled.
 *
 * To encrypt using DUKPT, you must already have a BDK (Base Derivation Key) key in your account with `KeyModesOfUse` set to `DeriveKey`, or you can generate a new DUKPT key by calling CreateKey. To encrypt using EMV, you must already have an IMK (Issuer Master Key) key in your account with `KeyModesOfUse` set to `DeriveKey`.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - DecryptData
 *
 * - GetPublicCertificate
 *
 * - ImportKey
 *
 * - ReEncryptData
 */
export declare const encryptData: API.OperationMethod<EncryptDataInput & RegionInput, EncryptDataOutput, EncryptDataError, Credentials | HttpClient.HttpClient>;
export type GenerateAs2805KekValidationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a `KekValidationRequest` or a `KekValidationResponse` for node-to-node initialization between payment processing nodes using Australian Standard 2805 (AS2805).
 *
 * During node-to-node initialization, both communicating nodes must validate that they possess the correct Key Encrypting Keys (KEKs) before proceeding with session key exchange. In AS2805, the sending KEK (KEKs) of one node corresponds to the receiving KEK (KEKr) of its partner node. Each node uses its KEK to encrypt and decrypt session keys exchanged between the nodes. A KEK can be created or imported into Amazon Web Services Payment Cryptography using either the CreateKey or ImportKey operations.
 *
 * To use `GenerateAs2805KekValidation` to generate a KEK validation request, set `KekValidationType` to `KekValidationRequest`. This operation returns both `RandomKeySend` (KRs) and `RandomKeyReceive` (KRr) as response values. The partnering node receives the KRs, uses its KEKr to decrypt it, and generates a KRr which is an inverted value of KRs. The node receiving the KRr validates it against its own KRr generated during KEK validation request outside of Amazon Web Services Payment Cryptography.
 *
 * You can also use this operation to generate a KEK validation response, by setting `KekValidationType` to `KekValidationResponse` and providing the incoming KRs. This operation then calculates a KRr. To learn more about more about node-to-node initialization, see Validation of KEK in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 */
export declare const generateAs2805KekValidation: API.OperationMethod<GenerateAs2805KekValidationInput & RegionInput, GenerateAs2805KekValidationOutput, GenerateAs2805KekValidationError, Credentials | HttpClient.HttpClient>;
export type GenerateAuthRequestCryptogramError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates an Authorization Request Cryptogram (ARQC) for an EMV chip payment card authorization. For more information, see Generate auth request cryptogram in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * ARQC generation uses an Issuer Master Key (IMK) for application cryptograms (TR31_E0_EMV_MKEY_APP_CRYPTOGRAMS) to derive a session key, which is then used to generate the cryptogram from the provided transaction data (when applicable). To use this operation, you must first create or import an IMK-AC key by calling CreateKey or ImportKey. The `KeyModesOfUse` should be set to `DeriveKey` for the IMK-AC encryption key.
 *
 * This operation is intended for development and testing scenarios only. It is not recommended to use this operation as a substitute for card-based cryptogram generation in production payment flows.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - VerifyAuthRequestCryptogram
 */
export declare const generateAuthRequestCryptogram: API.OperationMethod<GenerateAuthRequestCryptogramInput & RegionInput, GenerateAuthRequestCryptogramOutput, GenerateAuthRequestCryptogramError, Credentials | HttpClient.HttpClient>;
export type GenerateCardValidationDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates card-related validation data using algorithms such as Card Verification Values (CVV/CVV2), Dynamic Card Verification Values (dCVV/dCVV2), or Card Security Codes (CSC). For more information, see Generate card data in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * This operation generates a CVV or CSC value that is printed on a payment credit or debit card during card production. The CVV or CSC, PAN (Primary Account Number) and expiration date of the card are required to check its validity during transaction processing. To begin this operation, a CVK (Card Verification Key) encryption key is required. You can use CreateKey or ImportKey to establish a CVK within Amazon Web Services Payment Cryptography. The `KeyModesOfUse` should be set to `Generate` and `Verify` for a CVK encryption key.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - ImportKey
 *
 * - VerifyCardValidationData
 */
export declare const generateCardValidationData: API.OperationMethod<GenerateCardValidationDataInput & RegionInput, GenerateCardValidationDataOutput, GenerateCardValidationDataError, Credentials | HttpClient.HttpClient>;
export type GenerateMacError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a Message Authentication Code (MAC) cryptogram within Amazon Web Services Payment Cryptography.
 *
 * You can use this operation to authenticate card-related data by using known data values to generate MAC for data validation between the sending and receiving parties. This operation uses message data, a secret encryption key and MAC algorithm to generate a unique MAC value for transmission. The receiving party of the MAC must use the same message data, secret encryption key and MAC algorithm to reproduce another MAC value for comparision.
 *
 * You can use this operation to generate a DUPKT, CMAC, HMAC or EMV MAC by setting generation attributes and algorithm to the associated values. The MAC generation encryption key must have valid values for `KeyUsage` such as `TR31_M7_HMAC_KEY` for HMAC generation, and the key must have `KeyModesOfUse` set to `Generate`.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - VerifyMac
 */
export declare const generateMac: API.OperationMethod<GenerateMacInput & RegionInput, GenerateMacOutput, GenerateMacError, Credentials | HttpClient.HttpClient>;
export type GenerateMacEmvPinChangeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates an issuer script mac for EMV payment cards that use offline PINs as the cardholder verification method (CVM).
 *
 * This operation generates an authenticated issuer script response by appending the incoming message data (APDU command) with the target encrypted PIN block in ISO2 format. The command structure and method to send the issuer script update to the card is not defined by this operation and is typically determined by the applicable payment card scheme.
 *
 * The primary inputs to this operation include the incoming new encrypted pinblock, PIN encryption key (PEK), issuer master key (IMK), primary account number (PAN), and the payment card derivation method.
 *
 * The operation uses two issuer master keys - secure messaging for confidentiality (IMK-SMC) and secure messaging for integrity (IMK-SMI). The SMC key is used to internally derive a key to secure the pin, while SMI key is used to internally derive a key to authenticate the script reponse as per the EMV 4.4 - Book 2 - Security and Key Management specification.
 *
 * This operation supports Amex, EMV2000, EMVCommon, Mastercard and Visa derivation methods, each requiring specific input parameters. Users must follow the specific derivation method and input parameters defined by the respective payment card scheme.
 *
 * Use GenerateMac operation when sending a script update to an EMV card that does not involve PIN change. When assigning IAM permissions, it is important to understand that EncryptData using EMV keys and GenerateMac perform similar functions to this command.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - EncryptData
 *
 * - GenerateMac
 */
export declare const generateMacEmvPinChange: API.OperationMethod<GenerateMacEmvPinChangeInput & RegionInput, GenerateMacEmvPinChangeOutput, GenerateMacEmvPinChangeError, Credentials | HttpClient.HttpClient>;
export type GeneratePinDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates pin-related data such as PIN, PIN Verification Value (PVV), PIN Block, and PIN Offset during new card issuance or reissuance. For more information, see Generate PIN data in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * PIN data is never transmitted in clear to or from Amazon Web Services Payment Cryptography. This operation generates PIN, PVV, or PIN Offset and then encrypts it using Pin Encryption Key (PEK) to create an `EncryptedPinBlock` for transmission from Amazon Web Services Payment Cryptography. This operation uses a separate Pin Verification Key (PVK) for VISA PVV generation.
 *
 * Using ECDH key exchange, you can receive cardholder selectable PINs into Amazon Web Services Payment Cryptography. The ECDH derived key protects the incoming PIN block. You can also use it for reveal PIN, wherein the generated PIN block is protected by the ECDH derived key before transmission from Amazon Web Services Payment Cryptography. For more information on establishing ECDH derived keys, see the Generating keys in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - GenerateCardValidationData
 *
 * - TranslatePinData
 *
 * - VerifyPinData
 */
export declare const generatePinData: API.OperationMethod<GeneratePinDataInput & RegionInput, GeneratePinDataOutput, GeneratePinDataError, Credentials | HttpClient.HttpClient>;
export type ReEncryptDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Re-encrypts ciphertext using DUKPT, symmetric, or asymmetric data encryption keys.
 *
 * You can either generate an encryption key within Amazon Web Services Payment Cryptography by calling CreateKey or import your own encryption key by calling ImportKey. The `KeyArn` for use with this operation must be in a compatible key state with `KeyModesOfUse` set to `Encrypt`.
 *
 * This operation also supports dynamic keys, allowing you to pass a dynamic encryption key as a TR-31 WrappedKeyBlock. This can be used when key material is frequently rotated, such as during every card transaction, and there is need to avoid importing short-lived keys into Amazon Web Services Payment Cryptography. To re-encrypt using dynamic keys, the `keyARN` is the Key Encryption Key (KEK) of the TR-31 wrapped encryption key material. The incoming wrapped key shall have a key purpose of D0 with a mode of use of B or D. For more information, see Using Dynamic Keys in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * Amazon Web Services Payment Cryptography supports the following encryption key schemes:
 *
 * - **DUKPT**: `TDES` and `AES` algorithms. To encrypt using DUKPT, a DUKPT key must already exist within your account with `KeyModesOfUse` set to `DeriveKey` or a new DUKPT can be generated by calling CreateKey.
 *
 * - **Symmetric**: `TDES` and `AES` algorithms.
 *
 * - **Asymmetric**: `RSA`. You can use an `RSA` key on either the incoming or the outgoing side, paired with a symmetric key on the other side.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - DecryptData
 *
 * - EncryptData
 *
 * - GetPublicCertificate
 *
 * - ImportKey
 */
export declare const reEncryptData: API.OperationMethod<ReEncryptDataInput & RegionInput, ReEncryptDataOutput, ReEncryptDataError, Credentials | HttpClient.HttpClient>;
export type TranslateKeyMaterialError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Translates an cryptographic key between different wrapping keys without importing the key into Amazon Web Services Payment Cryptography.
 *
 * This operation can be used when key material is frequently rotated, such as during every card transaction, and there is a need to avoid importing short-lived keys into Amazon Web Services Payment Cryptography. It translates short-lived transaction keys such as PEK generated for each transaction and wrapped with an ECDH derived wrapping key to another KEK wrapping key.
 *
 * Before using this operation, you must first request the public key certificate of the ECC key pair generated within Amazon Web Services Payment Cryptography to establish an ECDH key agreement. In `TranslateKeyData`, the service uses its own ECC key pair, public certificate of receiving ECC key pair, and the key derivation parameters to generate a derived key. The service uses this derived key to unwrap the incoming transaction key received as a TR31WrappedKeyBlock and re-wrap using a user provided KEK to generate an outgoing Tr31WrappedKeyBlock.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - CreateKey
 *
 * - GetPublicCertificate
 *
 * - ImportKey
 */
export declare const translateKeyMaterial: API.OperationMethod<TranslateKeyMaterialInput & RegionInput, TranslateKeyMaterialOutput, TranslateKeyMaterialError, Credentials | HttpClient.HttpClient>;
export type TranslatePinDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Translates encrypted PIN block from and to ISO 9564 formats 0,1,3,4. For more information, see Translate PIN data in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * PIN block translation involves changing a PIN block from one encryption key to another and optionally change its format. PIN block translation occurs entirely within the HSM boundary and PIN data never enters or leaves Amazon Web Services Payment Cryptography in clear text. The encryption key transformation can be from PEK (Pin Encryption Key) to BDK (Base Derivation Key) for DUKPT or from BDK for DUKPT to PEK.
 *
 * Amazon Web Services Payment Cryptography also supports use of dynamic keys and ECDH (Elliptic Curve Diffie-Hellman) based key exchange for this operation.
 *
 * Dynamic keys allow you to pass a PEK as a TR-31 WrappedKeyBlock. They can be used when key material is frequently rotated, such as during every card transaction, and there is need to avoid importing short-lived keys into Amazon Web Services Payment Cryptography. To translate PIN block using dynamic keys, the `keyARN` is the Key Encryption Key (KEK) of the TR-31 wrapped PEK. The incoming wrapped key shall have a key purpose of P0 with a mode of use of B or D. For more information, see Using Dynamic Keys in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * Using ECDH key exchange, you can receive cardholder selectable PINs into Amazon Web Services Payment Cryptography. The ECDH derived key protects the incoming PIN block, which is translated to a PEK encrypted PIN block for use within the service. You can also use ECDH for reveal PIN, wherein the service translates the PIN block from PEK to a ECDH derived encryption key. For more information on establishing ECDH derived keys, see the Creating keys in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * The allowed combinations of PIN block format translations are guided by PCI. It is important to note that not all encrypted PIN block formats (example, format 1) require PAN (Primary Account Number) as input. And as such, PIN block format that requires PAN (example, formats 0,3,4) cannot be translated to a format (format 1) that does not require a PAN for generation.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * Amazon Web Services Payment Cryptography currently supports ISO PIN block 4 translation for PIN block built using legacy PAN length. That is, PAN is the right most 12 digits excluding the check digits.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - GeneratePinData
 *
 * - VerifyPinData
 */
export declare const translatePinData: API.OperationMethod<TranslatePinDataInput & RegionInput, TranslatePinDataOutput, TranslatePinDataError, Credentials | HttpClient.HttpClient>;
export type VerifyAuthRequestCryptogramError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | VerificationFailedException | CommonErrors;
/**
 * Verifies Authorization Request Cryptogram (ARQC) for a EMV chip payment card authorization. For more information, see Verify auth request cryptogram in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * ARQC generation is done outside of Amazon Web Services Payment Cryptography and is typically generated on a point of sale terminal for an EMV chip card to obtain payment authorization during transaction time. For ARQC verification, you must first import the ARQC generated outside of Amazon Web Services Payment Cryptography by calling ImportKey. This operation uses the imported ARQC and an major encryption key (DUKPT) created by calling CreateKey to either provide a boolean ARQC verification result or provide an APRC (Authorization Response Cryptogram) response using Method 1 or Method 2. The `ARPC_METHOD_1` uses `AuthResponseCode` to generate ARPC and `ARPC_METHOD_2` uses `CardStatusUpdate` to generate ARPC.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - VerifyCardValidationData
 *
 * - VerifyPinData
 */
export declare const verifyAuthRequestCryptogram: API.OperationMethod<VerifyAuthRequestCryptogramInput & RegionInput, VerifyAuthRequestCryptogramOutput, VerifyAuthRequestCryptogramError, Credentials | HttpClient.HttpClient>;
export type VerifyCardValidationDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | VerificationFailedException | CommonErrors;
/**
 * Verifies card-related validation data using algorithms such as Card Verification Values (CVV/CVV2), Dynamic Card Verification Values (dCVV/dCVV2) and Card Security Codes (CSC). For more information, see Verify card data in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * This operation validates the CVV or CSC codes that is printed on a payment credit or debit card during card payment transaction. The input values are typically provided as part of an inbound transaction to an issuer or supporting platform partner. Amazon Web Services Payment Cryptography uses CVV or CSC, PAN (Primary Account Number) and expiration date of the card to check its validity during transaction processing. In this operation, the CVK (Card Verification Key) encryption key for use with card data verification is same as the one in used for GenerateCardValidationData.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - GenerateCardValidationData
 *
 * - VerifyAuthRequestCryptogram
 *
 * - VerifyPinData
 */
export declare const verifyCardValidationData: API.OperationMethod<VerifyCardValidationDataInput & RegionInput, VerifyCardValidationDataOutput, VerifyCardValidationDataError, Credentials | HttpClient.HttpClient>;
export type VerifyMacError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | VerificationFailedException | CommonErrors;
/**
 * Verifies a Message Authentication Code (MAC).
 *
 * You can use this operation to verify MAC for message data authentication such as . In this operation, you must use the same message data, secret encryption key and MAC algorithm that was used to generate MAC. You can use this operation to verify a DUPKT, CMAC, HMAC or EMV MAC by setting generation attributes and algorithm to the associated values.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - GenerateMac
 */
export declare const verifyMac: API.OperationMethod<VerifyMacInput & RegionInput, VerifyMacOutput, VerifyMacError, Credentials | HttpClient.HttpClient>;
export type VerifyPinDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | VerificationFailedException | CommonErrors;
/**
 * Verifies pin-related data such as PIN and PIN Offset using algorithms including VISA PVV and IBM3624. For more information, see Verify PIN data in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * This operation verifies PIN data for user payment card. A card holder PIN data is never transmitted in clear to or from Amazon Web Services Payment Cryptography. This operation uses PIN Verification Key (PVK) for PIN or PIN Offset generation and then encrypts it using PIN Encryption Key (PEK) to create an `EncryptedPinBlock` for transmission from Amazon Web Services Payment Cryptography.
 *
 * For information about valid keys for this operation, see Understanding key attributes and Key types for specific data operations in the *Amazon Web Services Payment Cryptography User Guide*.
 *
 * **Cross-account use**: This operation supports cross-account use when the key has a resource-based policy that grants access. For more information, see Resource-based policies.
 *
 * **Related operations:**
 *
 * - GeneratePinData
 *
 * - TranslatePinData
 */
export declare const verifyPinData: API.OperationMethod<VerifyPinDataInput & RegionInput, VerifyPinDataOutput, VerifyPinDataError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=payment-cryptography-data.d.ts.map