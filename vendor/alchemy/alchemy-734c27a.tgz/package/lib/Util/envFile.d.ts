import * as Effect from "effect/Effect";
/**
 * The variable a {@link containerEnvFile} lists `-e NAME` for each key in.
 * A unit passes it to `docker run` as `$ALCHEMY_DOCKER_ENV`: systemd splits
 * an unbraced variable into one argument per word.
 */
export declare const DOCKER_ENV = "ALCHEMY_DOCKER_ENV";
declare const InvalidEnvKey_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvalidEnvKey";
} & Readonly<A>;
/** An `env` key a systemd `EnvironmentFile=` can't hold. */
export declare class InvalidEnvKey extends InvalidEnvKey_base<{
    readonly key: string;
}> {
    get message(): string;
}
/**
 * A systemd `EnvironmentFile=`, sorted so its hash is stable. Each value is
 * double-quoted: systemd keeps everything inside, newlines included, and
 * unescapes `\"`, `\\`, `\$` and `` \` ``. A quote only opens at the start of
 * a value, so single quotes can't carry a `'`. A key systemd can't hold
 * (`MY.KEY`) fails with {@link InvalidEnvKey} instead of being dropped.
 */
export declare const systemdEnvFile: (env: Record<string, unknown>) => Effect.Effect<string, InvalidEnvKey, never>;
/**
 * {@link systemdEnvFile} for a unit that runs a container. It also sets
 * {@link DOCKER_ENV} to `-e NAME` for each key, so `docker run` copies every
 * value from its own environment. Docker's `--env-file` can't hold a newline;
 * a value systemd loads can.
 */
export declare const containerEnvFile: (env: Record<string, unknown>) => Effect.Effect<string, InvalidEnvKey, never>;
export {};
//# sourceMappingURL=envFile.d.ts.map