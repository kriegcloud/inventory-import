import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LiveInputNotFound_base: S.TaggedErrorClass<"LiveInputNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class LiveInputNotFound extends /*@__PURE__*/ LiveInputNotFound_base {
}
declare const OutputNotFound_base: S.TaggedErrorClass<"OutputNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class OutputNotFound extends /*@__PURE__*/ OutputNotFound_base {
}
declare const SigningKeyNotFound_base: S.TaggedErrorClass<"SigningKeyNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SigningKeyNotFound extends /*@__PURE__*/ SigningKeyNotFound_base {
}
declare const WatermarkImageInvalid_base: S.TaggedErrorClass<"WatermarkImageInvalid", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class WatermarkImageInvalid extends /*@__PURE__*/ WatermarkImageInvalid_base {
}
declare const WatermarkNotFound_base: S.TaggedErrorClass<"WatermarkNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class WatermarkNotFound extends /*@__PURE__*/ WatermarkNotFound_base {
}
declare const WebhookNotFound_base: S.TaggedErrorClass<"WebhookNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class WebhookNotFound extends /*@__PURE__*/ WebhookNotFound_base {
}
export interface CopyAudioTrackRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label: string;
    /** An audio track URL. The server must be publicly routable and support `HTTP HEAD` requests and `HTTP GET` range requests. The server should respond to `HTTP HEAD` requests with a `content-range` header that includes the size of the file. */
    url?: string | undefined;
}
export type AudioTracksCopyResponseStatus = "queued" | "ready" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CopyAudioTrackResponse {
    /** Denotes whether the audio track will be played by default in a player. */
    default?: boolean | null | undefined;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label?: string | null | undefined;
    /** Specifies the processing status of the video. */
    status?: AudioTracksCopyResponseStatus | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
}
export interface CreateCaptionLanguageRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export type CaptionsLanguageCreateResponseStatus = "ready" | "inprogress" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCaptionLanguageResponse {
    /** Whether the caption was generated via AI. */
    generated?: boolean | null | undefined;
    /** The language label displayed in the native language to users. */
    label?: string | null | undefined;
    /** The language tag in BCP 47 format. */
    language?: string | null | undefined;
    /** The status of a generated caption. */
    status?: CaptionsLanguageCreateResponseStatus | null | undefined;
}
export type ClipCreateRequestAllowedOriginsList = Array<string>;
export interface ClipCreateRequestWatermark {
    /** The unique identifier for the watermark profile. */
    uid?: string | undefined;
}
export interface CreateClipRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The unique video identifier (UID). */
    clippedFromVideoUID: string;
    /** Specifies the end time for the video clip in seconds. */
    endTimeSeconds: number;
    /** Specifies the start time for the video clip in seconds. */
    startTimeSeconds: number;
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: ClipCreateRequestAllowedOriginsList | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | undefined;
    /** A video's URL. Preferred over 'url'. */
    input?: string | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | undefined;
    /** A name for the video. */
    name?: string | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | undefined;
    /** A video's URL (legacy field, use 'input' instead). */
    url?: string | undefined;
    watermark?: ClipCreateRequestWatermark | undefined;
}
export type ClipCreateResponseAllowedOriginsList = Array<string>;
export interface ClipCreateResponseInput {
    /** The video height in pixels. A value of `-1` means the height is unknown. The value becomes available after the upload and before the video is ready. */
    height?: number | null | undefined;
    /** The video width in pixels. A value of `-1` means the width is unknown. The value becomes available after the upload and before the video is ready. */
    width?: number | null | undefined;
}
export interface ClipCreateResponsePlayback {
    /** DASH Media Presentation Description for the video. */
    dash?: string | null | undefined;
    /** The HLS manifest for the video. */
    hls?: string | null | undefined;
}
export interface ClipCreateResponsePublicDetails {
    channelLink?: string | null | undefined;
    logo?: string | null | undefined;
    mediaId?: number | null | undefined;
    shareLink?: string | null | undefined;
    title?: string | null | undefined;
}
export type ClipCreateResponseStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export interface ClipCreateResponseStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null | undefined;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null | undefined;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null | undefined;
    /** Specifies the processing status for all quality levels for a video. */
    state?: ClipCreateResponseStatusState | null | undefined;
}
export interface ClipCreateResponseWatermark {
    /** The date and a time a watermark profile was created. */
    created?: string | null | undefined;
    /** The source URL for a downloaded image. If the watermark profile was created via direct upload, this field is null. */
    downloadedFrom?: string | null | undefined;
    /** The height of the image in pixels. */
    height?: number | null | undefined;
    /** A short description of the watermark profile. */
    name?: string | null | undefined;
    /** The translucency of the image. A value of `0.0` makes the image completely transparent, and `1.0` makes the image completely opaque. Note that if the image is already semi-transparent, setting this to `1.0` will not make the image completely opaque. */
    opacity?: number | null | undefined;
    /** The whitespace between the adjacent edges (determined by position) of the video and the image. `0.0` indicates no padding, and `1.0` indicates a fully padded video width or length, as determined by the algorithm. */
    padding?: number | null | undefined;
    /** The location of the image. Valid positions are: `upperRight`, `upperLeft`, `lowerLeft`, `lowerRight`, and `center`. Note that `center` ignores the `padding` parameter. */
    position?: string | null | undefined;
    /** The size of the image relative to the overall size of the video. This parameter will adapt to horizontal and vertical videos automatically. `0.0` indicates no scaling (use the size of the image as-is), and `1.0` fills the entire video. */
    scale?: number | null | undefined;
    /** The size of the image in bytes. */
    size?: number | null | undefined;
    /** The unique identifier for a watermark profile. */
    uid?: string | null | undefined;
    /** The width of the image in pixels. */
    width?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateClipResponse {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: ClipCreateResponseAllowedOriginsList | null | undefined;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null | undefined;
    /** The date and time the media item was created. */
    created?: string | null | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | null | undefined;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null | undefined;
    input?: ClipCreateResponseInput | null | undefined;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null | undefined;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null | undefined;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null | undefined;
    /** The date and time the media item was last modified. */
    modified?: string | null | undefined;
    playback?: ClipCreateResponsePlayback | null | undefined;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null | undefined;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null | undefined;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null | undefined;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null | undefined;
    /** The size of the media item in bytes. */
    size?: number | null | undefined;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: ClipCreateResponseStatus | null | undefined;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null | undefined;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null | undefined;
    watermark?: ClipCreateResponseWatermark | null | undefined;
}
export type CopyCreateRequestAllowedOriginsList = Array<string>;
export type CopyCreateRequestWatermark = ClipCreateRequestWatermark;
export interface CreateCopyRequest {
    /** The account identifier tag. */
    accountId: string;
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: CopyCreateRequestAllowedOriginsList | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | undefined;
    /** A video's URL. The server must be publicly routable and support `HTTP HEAD` requests and `HTTP GET` range requests. The server should respond to `HTTP HEAD` requests with a `content-range` header that includes the size of the file. This is the preferred field over `url`. */
    input?: string | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | undefined;
    /** A video's name. Used for legacy compatibility. */
    name?: string | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | undefined;
    /** A video's URL. The server must be publicly routable and support `HTTP HEAD` requests and `HTTP GET` range requests. The server should respond to `HTTP HEAD` requests with a `content-range` header that includes the size of the file. This field is deprecated in favor of `input`. */
    url?: string | undefined;
    watermark?: ClipCreateRequestWatermark | undefined;
    /** A user-defined identifier for the media creator. */
    uploadCreator?: string | undefined;
}
export type CopyCreateResponseAllowedOriginsList = Array<string>;
export type CopyCreateResponseInput = ClipCreateResponseInput;
export type CopyCreateResponsePlayback = ClipCreateResponsePlayback;
export type CopyCreateResponsePublicDetails = ClipCreateResponsePublicDetails;
export type CopyCreateResponseStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export interface CopyCreateResponseStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null | undefined;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null | undefined;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null | undefined;
    /** Specifies the processing status for all quality levels for a video. */
    state?: CopyCreateResponseStatusState | null | undefined;
}
export type CopyCreateResponseWatermark = ClipCreateResponseWatermark;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCopyResponse {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: CopyCreateResponseAllowedOriginsList | null | undefined;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null | undefined;
    /** The date and time the media item was created. */
    created?: string | null | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | null | undefined;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null | undefined;
    input?: ClipCreateResponseInput | null | undefined;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null | undefined;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null | undefined;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null | undefined;
    /** The date and time the media item was last modified. */
    modified?: string | null | undefined;
    playback?: ClipCreateResponsePlayback | null | undefined;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null | undefined;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null | undefined;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null | undefined;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null | undefined;
    /** The size of the media item in bytes. */
    size?: number | null | undefined;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: CopyCreateResponseStatus | null | undefined;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null | undefined;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null | undefined;
    watermark?: ClipCreateResponseWatermark | null | undefined;
}
export type DirectUploadCreateRequestAllowedOriginsList = Array<string>;
export type DirectUploadCreateRequestWatermark = ClipCreateRequestWatermark;
export interface CreateDirectUploadRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds: number;
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: DirectUploadCreateRequestAllowedOriginsList | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | undefined;
    /** The date and time after upload when videos will not be accepted. */
    expiry?: string | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | undefined;
    watermark?: ClipCreateRequestWatermark | undefined;
    /** A user-defined identifier for the media creator. */
    uploadCreator?: string | undefined;
}
export type DirectUploadCreateResponseWatermark = ClipCreateResponseWatermark;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDirectUploadResponse {
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
    /** The URL an unauthenticated upload can use for a single `HTTP POST multipart/form-data` request. */
    uploadURL?: string | null | undefined;
    watermark?: ClipCreateResponseWatermark | null | undefined;
}
export interface CreateDownloadRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export type DownloadsCreateResponseAudioStatus = "ready" | "inprogress" | "error";
export interface DownloadsCreateResponseAudio {
    /** Indicates the progress as a percentage between 0 and 100. */
    percentComplete: number;
    /** The status of a generated download. */
    status: DownloadsCreateResponseAudioStatus;
    /** The URL to access the generated download. */
    url?: string | null | undefined;
}
export type DownloadsCreateResponseDefaultStatus = "ready" | "inprogress" | "error";
export interface DownloadsCreateResponseDefault {
    /** Indicates the progress as a percentage between 0 and 100. */
    percentComplete: number;
    /** The status of a generated download. */
    status: DownloadsCreateResponseDefaultStatus;
    /** The URL to access the generated download. */
    url?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDownloadResponse {
    /** The audio-only download. Only present if this download type has been created. */
    audio?: DownloadsCreateResponseAudio | null | undefined;
    /** The default video download. Only present if this download type has been created. */
    default?: DownloadsCreateResponseDefault | null | undefined;
}
export interface CreateKeyRequest {
    /** Identifier. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateKeyResponse {
    /** Identifier. */
    id?: string | null | undefined;
    /** The date and time a signing key was created. */
    created?: string | null | undefined;
    /** The signing key in JWK format. */
    jwk?: string | null | undefined;
    /** The signing key in PEM format. */
    pem?: string | null | undefined;
}
export type LiveInputsCreateRequestRecordingAllowedOriginsList = Array<string>;
export type LiveInputsCreateRequestRecordingMode = "off" | "automatic";
export interface LiveInputsCreateRequestRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsCreateRequestRecordingAllowedOriginsList | undefined;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean | undefined;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsCreateRequestRecordingMode | (string & {}) | undefined;
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean | undefined;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number | undefined;
}
export interface CreateLiveInputRequest {
    /** Identifier. */
    accountId: string;
    idempotencyKey?: string | undefined;
    /** Sets the creator ID asssociated with this live input. */
    defaultCreator?: string | undefined;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | undefined;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | undefined;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean | undefined;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsCreateRequestRecording | undefined;
}
export interface LiveInputsCreateResponsePlayback {
    /** The DASH manifest URL used to play live video, referencing the live input ID. */
    dash: string;
    /** The HLS manifest URL used to play live video, referencing the live input ID. */
    hls: string;
}
export type LiveInputsCreateResponseRecordingAllowedOriginsList = Array<string>;
export type LiveInputsCreateResponseRecordingMode = "off" | "automatic";
export interface LiveInputsCreateResponseRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsCreateResponseRecordingAllowedOriginsList | null | undefined;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean | null | undefined;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsCreateResponseRecordingMode | null | undefined;
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean | null | undefined;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number | null | undefined;
}
export interface LiveInputsCreateResponseRtmps {
    /** The secret key to use when streaming via RTMPS to a live input. */
    streamKey?: string | null | undefined;
    /** The RTMPS URL you provide to the broadcaster, which they stream live video to. */
    url?: string | null | undefined;
}
export interface LiveInputsCreateResponseRtmpsPlayback {
    /** The secret key to use for playback via RTMPS. */
    streamKey?: string | null | undefined;
    /** The URL used to play live video over RTMPS. */
    url?: string | null | undefined;
}
export interface LiveInputsCreateResponseSrt {
    /** The secret key to use when streaming via SRT to a live input. */
    passphrase?: string | null | undefined;
    /** The identifier of the live input to use when streaming via SRT. */
    streamId?: string | null | undefined;
    /** The SRT URL you provide to the broadcaster, which they stream live video to. */
    url?: string | null | undefined;
}
export interface LiveInputsCreateResponseSrtPlayback {
    /** The secret key to use for playback via SRT. */
    passphrase?: string | null | undefined;
    /** The identifier of the live input to use for playback via SRT. */
    streamId?: string | null | undefined;
    /** The URL used to play live video over SRT. */
    url?: string | null | undefined;
}
export type LiveInputsCreateResponseStatus = "connected" | "reconnected" | "reconnecting" | "client_disconnect" | "ttl_exceeded" | "failed_to_connect" | "failed_to_reconnect" | "new_configuration_accepted";
export interface LiveInputsCreateResponseWebRTC {
    /** The WebRTC URL you provide to the broadcaster, which they stream live video to. */
    url?: string | null | undefined;
}
export interface LiveInputsCreateResponseWebRTCPlayback {
    /** The URL used to play live video over WebRTC. */
    url?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLiveInputResponse {
    /** The date and time the live input was created. */
    created?: string | null | undefined;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | null | undefined;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | null | undefined;
    /** The date and time the live input keys were last rotated. Omitted for live inputs that have never had their keys rotated. */
    keysRotatedAt?: string | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | null | undefined;
    /** The date and time the live input was last modified. */
    modified?: string | null | undefined;
    /** Details for playing a live input's broadcast using the HLS or DASH manifests. URLs reference the live input ID. */
    playback?: LiveInputsCreateResponsePlayback | null | undefined;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean | null | undefined;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsCreateResponseRecording | null | undefined;
    /** Details for streaming to an live input using RTMPS. */
    rtmps?: LiveInputsCreateResponseRtmps | null | undefined;
    /** Details for playback from an live input using RTMPS. */
    rtmpsPlayback?: LiveInputsCreateResponseRtmpsPlayback | null | undefined;
    /** Details for streaming to a live input using SRT. */
    srt?: LiveInputsCreateResponseSrt | null | undefined;
    /** Details for playback from an live input using SRT. */
    srtPlayback?: LiveInputsCreateResponseSrtPlayback | null | undefined;
    /** The connection status of a live input. */
    status?: LiveInputsCreateResponseStatus | null | undefined;
    /** A unique identifier for a live input. */
    uid?: string | null | undefined;
    /** Details for streaming to a live input using WebRTC. */
    webRTC?: LiveInputsCreateResponseWebRTC | null | undefined;
    /** Details for playback from a live input using WebRTC. */
    webRTCPlayback?: LiveInputsCreateResponseWebRTCPlayback | null | undefined;
}
export interface CreateLiveInputOutputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
    /** The streamKey used to authenticate against an output's target. */
    streamKey: string;
    /** The URL an output uses to restream. */
    url: string;
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled?: boolean | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLiveInputOutputResponse {
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled?: boolean | null | undefined;
    /** The streamKey used to authenticate against an output's target. */
    streamKey?: string | null | undefined;
    /** A unique identifier for the output. */
    uid?: string | null | undefined;
    /** The URL an output uses to restream. */
    url?: string | null | undefined;
}
export type CreateRequestTusResumable = "1.0.0";
export interface CreateStreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** Provisions a URL to let your end users upload videos directly to Cloudflare Stream without exposing your API token to clients. */
    directUser?: boolean | undefined;
    /** Specifies the TUS protocol version. This value must be included in every upload request. Notes: The only supported version of TUS protocol is 1.0.0. */
    tusResumable: CreateRequestTusResumable | (string & {});
    /** Indicates the size of the entire upload in bytes. The value must be a non-negative integer. */
    uploadLength: number;
    /** A user-defined identifier for the media creator. */
    uploadCreator?: string | undefined;
    /** Comma-separated key-value pairs following the TUS protocol specification. Values are Base-64 encoded. Supported keys: `name`, `requiresignedurls`, `allowedorigins`, `thumbnailtimestamppct`, `watermark`, `scheduleddeletion`, `maxdurationseconds`. */
    uploadMetadata?: string | undefined;
}
export interface CreateStreamResponse {
}
export type TokenCreateRequestAccessRulesItemAction = "allow" | "block";
export type TokenCreateRequestAccessRulesItemCountryList = Array<string>;
export type TokenCreateRequestAccessRulesItemIpList = Array<string>;
export type TokenCreateRequestAccessRulesItemType = "any" | "ip.src" | "ip.geoip.country";
export interface TokenCreateRequestAccessRulesItem {
    /** The action to take when a request matches a rule. If the action is `block`, the signed token blocks views for viewers matching the rule. */
    action?: TokenCreateRequestAccessRulesItemAction | (string & {}) | undefined;
    /** An array of 2-letter country codes in ISO 3166-1 Alpha-2 format used to match requests. */
    country?: TokenCreateRequestAccessRulesItemCountryList | undefined;
    /** An array of IPv4 or IPV6 addresses or CIDRs used to match requests. */
    ip?: TokenCreateRequestAccessRulesItemIpList | undefined;
    /** Lists available rule types to match for requests. An `any` type matches all requests and can be used as a wildcard to apply default actions after other rules. */
    type?: TokenCreateRequestAccessRulesItemType | (string & {}) | undefined;
}
export type TokenCreateRequestAccessRulesList = Array<TokenCreateRequestAccessRulesItem>;
export interface TokenCreateRequestFlags {
    /** Whether to return the original video without transformations. */
    original?: boolean | undefined;
}
export interface CreateTokenRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The optional ID of a Stream signing key. If present, the `pem` field is also required. */
    id?: string | undefined;
    /** The optional list of access rule constraints on the token. Access can be blocked or allowed based on an IP, IP range, or by country. Access rules are evaluated from first to last. If a rule matches, the associated action is applied and no further rules are evaluated. */
    accessRules?: TokenCreateRequestAccessRulesList | undefined;
    /** The optional boolean value that enables using signed tokens to access MP4 download links for a video. */
    downloadable?: boolean | undefined;
    /** The optional unix epoch timestamp that specficies the time after a token is not accepted. The maximum time specification is 24 hours from issuing time. If this field is not set, the default is one hour after issuing. */
    exp?: number | undefined;
    /** Optional flags for the signed token. */
    flags?: TokenCreateRequestFlags | undefined;
    /** The optional unix epoch timestamp that specifies the time before a the token is not accepted. If this field is not set, the default is one hour before issuing. */
    nbf?: number | undefined;
    /** The optional base64 encoded private key in PEM format associated with a Stream signing key. If present, the `id` field is also required. */
    pem?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    /** The signed token used with the signed URLs feature. */
    token?: string | null | undefined;
}
export interface CreateWatermarkRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A short description of the watermark profile. */
    name?: string | undefined;
    /** The translucency of the image. A value of `0.0` makes the image completely transparent, and `1.0` makes the image completely opaque. Note that if the image is already semi-transparent, setting this to `1.0` will not make the image completely opaque. */
    opacity?: number | undefined;
    /** The whitespace between the adjacent edges (determined by position) of the video and the image. `0.0` indicates no padding, and `1.0` indicates a fully padded video width or length, as determined by the algorithm. */
    padding?: number | undefined;
    /** The location of the image. Valid positions are: `upperRight`, `upperLeft`, `lowerLeft`, `lowerRight`, and `center`. Note that `center` ignores the `padding` parameter. */
    position?: string | undefined;
    /** The size of the image relative to the overall size of the video. This parameter will adapt to horizontal and vertical videos automatically. `0.0` indicates no scaling (use the size of the image as-is), and `1.0` fills the entire video. */
    scale?: number | undefined;
    /** URL of the watermark image to copy. */
    url?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateWatermarkResponse {
    /** The date and a time a watermark profile was created. */
    created?: string | null | undefined;
    /** The source URL for a downloaded image. If the watermark profile was created via direct upload, this field is null. */
    downloadedFrom?: string | null | undefined;
    /** The height of the image in pixels. */
    height?: number | null | undefined;
    /** A short description of the watermark profile. */
    name?: string | null | undefined;
    /** The translucency of the image. A value of `0.0` makes the image completely transparent, and `1.0` makes the image completely opaque. Note that if the image is already semi-transparent, setting this to `1.0` will not make the image completely opaque. */
    opacity?: number | null | undefined;
    /** The whitespace between the adjacent edges (determined by position) of the video and the image. `0.0` indicates no padding, and `1.0` indicates a fully padded video width or length, as determined by the algorithm. */
    padding?: number | null | undefined;
    /** The location of the image. Valid positions are: `upperRight`, `upperLeft`, `lowerLeft`, `lowerRight`, and `center`. Note that `center` ignores the `padding` parameter. */
    position?: string | null | undefined;
    /** The size of the image relative to the overall size of the video. This parameter will adapt to horizontal and vertical videos automatically. `0.0` indicates no scaling (use the size of the image as-is), and `1.0` fills the entire video. */
    scale?: number | null | undefined;
    /** The size of the image in bytes. */
    size?: number | null | undefined;
    /** The unique identifier for a watermark profile. */
    uid?: string | null | undefined;
    /** The width of the image in pixels. */
    width?: number | null | undefined;
}
export interface DeleteAudioTrackRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The unique identifier for an additional audio track. */
    audioIdentifier: string;
}
export type DeleteAudioTrackResponse = string;
export interface DeleteCaptionLanguageRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export type DeleteCaptionLanguageResponse = string;
export interface DeleteDownloadRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export type DeleteDownloadResponse = string;
export interface DeleteKeyRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    identifier: string;
}
export type DeleteKeyResponse = string;
export interface DeleteLiveInputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
}
export interface DeleteLiveInputResponse {
}
export interface DeleteLiveInputOutputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
    /** A unique identifier for the output. */
    outputIdentifier: string;
}
export interface DeleteLiveInputOutputResponse {
}
export interface DeleteStreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export interface DeleteStreamResponse {
}
export interface DeleteWatermarkRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The unique identifier for a watermark profile. */
    identifier: string;
}
export type DeleteWatermarkResponse = string;
export interface DeleteWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
}
export type DeleteWebhookResponse = string;
export type EditRequestAllowedOriginsList = Array<string>;
export interface EditRequestPublicDetails {
    channelLink?: string | undefined;
    logo?: string | undefined;
    shareLink?: string | undefined;
    title?: string | undefined;
}
export interface EditStreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: EditRequestAllowedOriginsList | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | undefined;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | undefined;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: EditRequestPublicDetails | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | undefined;
    /** The unique identifier for the video. Can be used to verify the video being updated. */
    uid?: string | undefined;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | undefined;
}
export type EditResponseAllowedOriginsList = Array<string>;
export type EditResponseInput = ClipCreateResponseInput;
export type EditResponsePlayback = ClipCreateResponsePlayback;
export type EditResponsePublicDetails = ClipCreateResponsePublicDetails;
export type EditResponseStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export interface EditResponseStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null | undefined;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null | undefined;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null | undefined;
    /** Specifies the processing status for all quality levels for a video. */
    state?: EditResponseStatusState | null | undefined;
}
export type EditResponseWatermark = ClipCreateResponseWatermark;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditStreamResponse {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: EditResponseAllowedOriginsList | null | undefined;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null | undefined;
    /** The date and time the media item was created. */
    created?: string | null | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | null | undefined;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null | undefined;
    input?: ClipCreateResponseInput | null | undefined;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null | undefined;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null | undefined;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null | undefined;
    /** The date and time the media item was last modified. */
    modified?: string | null | undefined;
    playback?: ClipCreateResponsePlayback | null | undefined;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null | undefined;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null | undefined;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null | undefined;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null | undefined;
    /** The size of the media item in bytes. */
    size?: number | null | undefined;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: EditResponseStatus | null | undefined;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null | undefined;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null | undefined;
    watermark?: ClipCreateResponseWatermark | null | undefined;
}
export interface GetAudioTrackRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export type AudioTracksGetResponseAudioItemStatus = "queued" | "ready" | "error";
export interface AudioTracksGetResponseAudioItem {
    /** Denotes whether the audio track will be played by default in a player. */
    default?: boolean | null | undefined;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label?: string | null | undefined;
    /** Specifies the processing status of the video. */
    status?: AudioTracksGetResponseAudioItemStatus | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
}
export type AudioTracksGetResponseAudioList = Array<AudioTracksGetResponseAudioItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAudioTrackResponse {
    /** Array of audio tracks for the video. */
    audio?: AudioTracksGetResponseAudioList | null | undefined;
}
export interface GetCaptionRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export type CaptionsGetResultItemStatus = "ready" | "inprogress" | "error";
export interface CaptionsGetResultItem {
    /** Whether the caption was generated via AI. */
    generated?: boolean | null | undefined;
    /** The language label displayed in the native language to users. */
    label?: string | null | undefined;
    /** The language tag in BCP 47 format. */
    language?: string | null | undefined;
    /** The status of a generated caption. */
    status?: CaptionsGetResultItemStatus | null | undefined;
}
export type CaptionsGetResultList = Array<CaptionsGetResultItem>;
export interface GetCaptionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CaptionsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface GetCaptionLanguageRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export type CaptionsLanguageGetResponseStatus = "ready" | "inprogress" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCaptionLanguageResponse {
    /** Whether the caption was generated via AI. */
    generated?: boolean | null | undefined;
    /** The language label displayed in the native language to users. */
    label?: string | null | undefined;
    /** The language tag in BCP 47 format. */
    language?: string | null | undefined;
    /** The status of a generated caption. */
    status?: CaptionsLanguageGetResponseStatus | null | undefined;
}
export interface GetCaptionLanguageVttRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export interface GetCaptionLanguageVttResponse {
}
export interface GetDownloadRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export type DownloadsGetResponseAudioStatus = "ready" | "inprogress" | "error";
export interface DownloadsGetResponseAudio {
    /** Indicates the progress as a percentage between 0 and 100. */
    percentComplete: number;
    /** The status of a generated download. */
    status: DownloadsGetResponseAudioStatus;
    /** The URL to access the generated download. */
    url?: string | null | undefined;
}
export type DownloadsGetResponseDefaultStatus = "ready" | "inprogress" | "error";
export interface DownloadsGetResponseDefault {
    /** Indicates the progress as a percentage between 0 and 100. */
    percentComplete: number;
    /** The status of a generated download. */
    status: DownloadsGetResponseDefaultStatus;
    /** The URL to access the generated download. */
    url?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDownloadResponse {
    /** The audio-only download. Only present if this download type has been created. */
    audio?: DownloadsGetResponseAudio | null | undefined;
    /** The default video download. Only present if this download type has been created. */
    default?: DownloadsGetResponseDefault | null | undefined;
}
export interface GetEmbedRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export interface GetEmbedResponse {
}
export interface GetKeyRequest {
    /** Identifier. */
    accountId: string;
}
export interface KeysGetResultItem {
    /** Identifier. */
    id?: string | null | undefined;
    /** The date and time a signing key was created. */
    created?: string | null | undefined;
    /** The unique identifier for the signing key. */
    keyId?: string | null | undefined;
}
export type KeysGetResultList = Array<KeysGetResultItem>;
export interface GetKeyResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: KeysGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface GetLiveInputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
}
export type LiveInputsGetResponsePlayback = LiveInputsCreateResponsePlayback;
export type LiveInputsGetResponseRecordingAllowedOriginsList = Array<string>;
export type LiveInputsGetResponseRecordingMode = "off" | "automatic";
export interface LiveInputsGetResponseRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsGetResponseRecordingAllowedOriginsList | null | undefined;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean | null | undefined;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsGetResponseRecordingMode | null | undefined;
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean | null | undefined;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number | null | undefined;
}
export type LiveInputsGetResponseRtmps = LiveInputsCreateResponseRtmps;
export type LiveInputsGetResponseRtmpsPlayback = LiveInputsCreateResponseRtmpsPlayback;
export type LiveInputsGetResponseSrt = LiveInputsCreateResponseSrt;
export type LiveInputsGetResponseSrtPlayback = LiveInputsCreateResponseSrtPlayback;
export type LiveInputsGetResponseStatus = "connected" | "reconnected" | "reconnecting" | "client_disconnect" | "ttl_exceeded" | "failed_to_connect" | "failed_to_reconnect" | "new_configuration_accepted";
export type LiveInputsGetResponseWebRTC = LiveInputsCreateResponseWebRTC;
export type LiveInputsGetResponseWebRTCPlayback = LiveInputsCreateResponseWebRTCPlayback;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLiveInputResponse {
    /** The date and time the live input was created. */
    created?: string | null | undefined;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | null | undefined;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | null | undefined;
    /** The date and time the live input keys were last rotated. Omitted for live inputs that have never had their keys rotated. */
    keysRotatedAt?: string | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | null | undefined;
    /** The date and time the live input was last modified. */
    modified?: string | null | undefined;
    /** Details for playing a live input's broadcast using the HLS or DASH manifests. URLs reference the live input ID. */
    playback?: LiveInputsCreateResponsePlayback | null | undefined;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean | null | undefined;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsGetResponseRecording | null | undefined;
    /** Details for streaming to an live input using RTMPS. */
    rtmps?: LiveInputsCreateResponseRtmps | null | undefined;
    /** Details for playback from an live input using RTMPS. */
    rtmpsPlayback?: LiveInputsCreateResponseRtmpsPlayback | null | undefined;
    /** Details for streaming to a live input using SRT. */
    srt?: LiveInputsCreateResponseSrt | null | undefined;
    /** Details for playback from an live input using SRT. */
    srtPlayback?: LiveInputsCreateResponseSrtPlayback | null | undefined;
    /** The connection status of a live input. */
    status?: LiveInputsGetResponseStatus | null | undefined;
    /** A unique identifier for a live input. */
    uid?: string | null | undefined;
    /** Details for streaming to a live input using WebRTC. */
    webRTC?: LiveInputsCreateResponseWebRTC | null | undefined;
    /** Details for playback from a live input using WebRTC. */
    webRTCPlayback?: LiveInputsCreateResponseWebRTCPlayback | null | undefined;
}
export interface GetStreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export type GetResponseAllowedOriginsList = Array<string>;
export type GetResponseInput = ClipCreateResponseInput;
export type GetResponsePlayback = ClipCreateResponsePlayback;
export type GetResponsePublicDetails = ClipCreateResponsePublicDetails;
export type GetResponseStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export interface GetResponseStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null | undefined;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null | undefined;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null | undefined;
    /** Specifies the processing status for all quality levels for a video. */
    state?: GetResponseStatusState | null | undefined;
}
export type GetResponseWatermark = ClipCreateResponseWatermark;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStreamResponse {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: GetResponseAllowedOriginsList | null | undefined;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null | undefined;
    /** The date and time the media item was created. */
    created?: string | null | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | null | undefined;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null | undefined;
    input?: ClipCreateResponseInput | null | undefined;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null | undefined;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null | undefined;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null | undefined;
    /** The date and time the media item was last modified. */
    modified?: string | null | undefined;
    playback?: ClipCreateResponsePlayback | null | undefined;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null | undefined;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null | undefined;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null | undefined;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null | undefined;
    /** The size of the media item in bytes. */
    size?: number | null | undefined;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: GetResponseStatus | null | undefined;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null | undefined;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null | undefined;
    watermark?: ClipCreateResponseWatermark | null | undefined;
}
export interface GetWatermarkRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The unique identifier for a watermark profile. */
    identifier: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWatermarkResponse {
    /** The date and a time a watermark profile was created. */
    created?: string | null | undefined;
    /** The source URL for a downloaded image. If the watermark profile was created via direct upload, this field is null. */
    downloadedFrom?: string | null | undefined;
    /** The height of the image in pixels. */
    height?: number | null | undefined;
    /** A short description of the watermark profile. */
    name?: string | null | undefined;
    /** The translucency of the image. A value of `0.0` makes the image completely transparent, and `1.0` makes the image completely opaque. Note that if the image is already semi-transparent, setting this to `1.0` will not make the image completely opaque. */
    opacity?: number | null | undefined;
    /** The whitespace between the adjacent edges (determined by position) of the video and the image. `0.0` indicates no padding, and `1.0` indicates a fully padded video width or length, as determined by the algorithm. */
    padding?: number | null | undefined;
    /** The location of the image. Valid positions are: `upperRight`, `upperLeft`, `lowerLeft`, `lowerRight`, and `center`. Note that `center` ignores the `padding` parameter. */
    position?: string | null | undefined;
    /** The size of the image relative to the overall size of the video. This parameter will adapt to horizontal and vertical videos automatically. `0.0` indicates no scaling (use the size of the image as-is), and `1.0` fills the entire video. */
    scale?: number | null | undefined;
    /** The size of the image in bytes. */
    size?: number | null | undefined;
    /** The unique identifier for a watermark profile. */
    uid?: string | null | undefined;
    /** The width of the image in pixels. */
    width?: number | null | undefined;
}
export interface GetWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWebhookResponse {
    /** The date and time the webhook was last modified. */
    modified?: string | null | undefined;
    /** The URL where webhooks will be sent. */
    notificationUrl?: string | null | undefined;
    /** The secret used to verify webhook signatures. */
    secret?: string | null | undefined;
}
export interface ListLiveInputOutputsRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
}
export interface LiveInputsOutputsListResultItem {
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled?: boolean | null | undefined;
    /** The streamKey used to authenticate against an output's target. */
    streamKey?: string | null | undefined;
    /** A unique identifier for the output. */
    uid?: string | null | undefined;
    /** The URL an output uses to restream. */
    url?: string | null | undefined;
}
export type LiveInputsOutputsListResultList = Array<LiveInputsOutputsListResultItem>;
export interface ListLiveInputOutputsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LiveInputsOutputsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListLiveInputsRequest {
    /** Identifier. */
    accountId: string;
    /** Includes the total number of videos associated with the submitted query parameters. */
    includeCounts?: boolean | undefined;
}
export interface LiveInputsListResponseLiveInputsItem {
    /** The date and time the live input was created. */
    created?: string | null | undefined;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | null | undefined;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | null | undefined;
    /** The date and time the live input was last modified. */
    modified?: string | null | undefined;
    /** A unique identifier for a live input. */
    uid?: string | null | undefined;
}
export type LiveInputsListResponseLiveInputsList = Array<LiveInputsListResponseLiveInputsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export type ListLiveInputsResponse = LiveInputsListResponseLiveInputsList;
export type ListRequestStatus = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export interface ListStreamsRequest {
    /** The account identifier tag. */
    accountId: string;
    /** Filter by video ID(s). Can be a single ID or a comma-separated list of IDs. */
    id?: string | undefined;
    /** Alias for 'start'. Returns videos created after this date/time (RFC 3339 format). */
    after?: string | undefined;
    /** Lists videos in ascending order of creation. */
    asc?: boolean | undefined;
    /** Alias for 'end'. Returns videos created before this date/time (RFC 3339 format). */
    before?: string | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | undefined;
    /** Lists videos created before the specified date. */
    end?: string | undefined;
    /** Includes the total number of videos associated with the submitted query parameters. */
    includeCounts?: boolean | undefined;
    /** Maximum number of videos to return (default 1000, max 1000). */
    limit?: number | undefined;
    /** Filter by live input ID to find videos associated with a specific live stream. */
    liveInputId?: string | undefined;
    /** Filter by video name/UID(s). Can be a single name or a comma-separated list. */
    name?: string | undefined;
    /** Provides a partial word match of the `name` key in the `meta` field. Slow for medium to large video libraries. May be unavailable for very large libraries. */
    search?: string | undefined;
    /** Lists videos created after the specified date. */
    start?: string | undefined;
    /** Specifies the processing status for all quality levels for a video. */
    status?: ListRequestStatus | (string & {}) | undefined;
    /** Specifies whether the video is `vod` or `live`. */
    type?: string | undefined;
    /** Provides a fast, exact string match on the `name` key in the `meta` field. */
    videoName?: string | undefined;
}
export type ListResultItemAllowedOriginsList = Array<string>;
export type ListResultItemInput = ClipCreateResponseInput;
export type ListResultItemPlayback = ClipCreateResponsePlayback;
export type ListResultItemPublicDetails = ClipCreateResponsePublicDetails;
export type ListResultItemStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export interface ListResultItemStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null | undefined;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null | undefined;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null | undefined;
    /** Specifies the processing status for all quality levels for a video. */
    state?: ListResultItemStatusState | null | undefined;
}
export type ListResultItemWatermark = ClipCreateResponseWatermark;
export interface ListResultItem {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: ListResultItemAllowedOriginsList | null | undefined;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null | undefined;
    /** The date and time the media item was created. */
    created?: string | null | undefined;
    /** A user-defined identifier for the media creator. */
    creator?: string | null | undefined;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null | undefined;
    input?: ClipCreateResponseInput | null | undefined;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null | undefined;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null | undefined;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null | undefined;
    /** The date and time the media item was last modified. */
    modified?: string | null | undefined;
    playback?: ClipCreateResponsePlayback | null | undefined;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null | undefined;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null | undefined;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null | undefined;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null | undefined;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null | undefined;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null | undefined;
    /** The size of the media item in bytes. */
    size?: number | null | undefined;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: ListResultItemStatus | null | undefined;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null | undefined;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null | undefined;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null | undefined;
    watermark?: ClipCreateResponseWatermark | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListStreamsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListWatermarksRequest {
    /** The account identifier tag. */
    accountId: string;
}
export type WatermarksListResultItem = ClipCreateResponseWatermark;
export type WatermarksListResultList = Array<ClipCreateResponseWatermark>;
export interface ListWatermarksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WatermarksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface PatchAudioTrackRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The unique identifier for an additional audio track. */
    audioIdentifier: string;
    /** Denotes whether the audio track will be played by default in a player. */
    default?: boolean | undefined;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label?: string | undefined;
}
export type AudioTracksEditResponseStatus = "queued" | "ready" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAudioTrackResponse {
    /** Denotes whether the audio track will be played by default in a player. */
    default?: boolean | null | undefined;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label?: string | null | undefined;
    /** Specifies the processing status of the video. */
    status?: AudioTracksEditResponseStatus | null | undefined;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null | undefined;
}
export interface PutWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The URL where webhooks will be sent. */
    notificationUrl?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutWebhookResponse {
    /** The date and time the webhook was last modified. */
    modified?: string | null | undefined;
    /** The URL where webhooks will be sent. */
    notificationUrl?: string | null | undefined;
    /** The secret used to verify webhook signatures. */
    secret?: string | null | undefined;
}
export interface StorageUsageVideoRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A user-defined identifier for the media creator. */
    creator?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StorageUsageVideoResponse {
    /** A user-defined identifier for the media creator. */
    creator?: string | null | undefined;
    /** The total minutes of video content stored in the account. May contain decimal values. */
    totalStorageMinutes?: number | null | undefined;
    /** The storage capacity alloted for the account. */
    totalStorageMinutesLimit?: number | null | undefined;
    /** The total count of videos associated with the account. */
    videoCount?: number | null | undefined;
}
export interface UpdateCaptionLanguageRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
    /** The WebVTT file containing the caption or subtitle content. */
    file: string;
}
export type CaptionsLanguageUpdateResponseStatus = "ready" | "inprogress" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateCaptionLanguageResponse {
    /** Whether the caption was generated via AI. */
    generated?: boolean | null | undefined;
    /** The language label displayed in the native language to users. */
    label?: string | null | undefined;
    /** The language tag in BCP 47 format. */
    language?: string | null | undefined;
    /** The status of a generated caption. */
    status?: CaptionsLanguageUpdateResponseStatus | null | undefined;
}
export type LiveInputsUpdateRequestRecordingAllowedOriginsList = Array<string>;
export type LiveInputsUpdateRequestRecordingMode = "off" | "automatic";
export interface LiveInputsUpdateRequestRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsUpdateRequestRecordingAllowedOriginsList | undefined;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean | undefined;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsUpdateRequestRecordingMode | (string & {}) | undefined;
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean | undefined;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number | undefined;
}
export interface UpdateLiveInputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
    /** Sets the creator ID asssociated with this live input. */
    defaultCreator?: string | undefined;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | undefined;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | undefined;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean | undefined;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsUpdateRequestRecording | undefined;
}
export type LiveInputsUpdateResponsePlayback = LiveInputsCreateResponsePlayback;
export type LiveInputsUpdateResponseRecordingAllowedOriginsList = Array<string>;
export type LiveInputsUpdateResponseRecordingMode = "off" | "automatic";
export interface LiveInputsUpdateResponseRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsUpdateResponseRecordingAllowedOriginsList | null | undefined;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean | null | undefined;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsUpdateResponseRecordingMode | null | undefined;
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean | null | undefined;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number | null | undefined;
}
export type LiveInputsUpdateResponseRtmps = LiveInputsCreateResponseRtmps;
export type LiveInputsUpdateResponseRtmpsPlayback = LiveInputsCreateResponseRtmpsPlayback;
export type LiveInputsUpdateResponseSrt = LiveInputsCreateResponseSrt;
export type LiveInputsUpdateResponseSrtPlayback = LiveInputsCreateResponseSrtPlayback;
export type LiveInputsUpdateResponseStatus = "connected" | "reconnected" | "reconnecting" | "client_disconnect" | "ttl_exceeded" | "failed_to_connect" | "failed_to_reconnect" | "new_configuration_accepted";
export type LiveInputsUpdateResponseWebRTC = LiveInputsCreateResponseWebRTC;
export type LiveInputsUpdateResponseWebRTCPlayback = LiveInputsCreateResponseWebRTCPlayback;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLiveInputResponse {
    /** The date and time the live input was created. */
    created?: string | null | undefined;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | null | undefined;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | null | undefined;
    /** The date and time the live input keys were last rotated. Omitted for live inputs that have never had their keys rotated. */
    keysRotatedAt?: string | null | undefined;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | null | undefined;
    /** The date and time the live input was last modified. */
    modified?: string | null | undefined;
    /** Details for playing a live input's broadcast using the HLS or DASH manifests. URLs reference the live input ID. */
    playback?: LiveInputsCreateResponsePlayback | null | undefined;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean | null | undefined;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsUpdateResponseRecording | null | undefined;
    /** Details for streaming to an live input using RTMPS. */
    rtmps?: LiveInputsCreateResponseRtmps | null | undefined;
    /** Details for playback from an live input using RTMPS. */
    rtmpsPlayback?: LiveInputsCreateResponseRtmpsPlayback | null | undefined;
    /** Details for streaming to a live input using SRT. */
    srt?: LiveInputsCreateResponseSrt | null | undefined;
    /** Details for playback from an live input using SRT. */
    srtPlayback?: LiveInputsCreateResponseSrtPlayback | null | undefined;
    /** The connection status of a live input. */
    status?: LiveInputsUpdateResponseStatus | null | undefined;
    /** A unique identifier for a live input. */
    uid?: string | null | undefined;
    /** Details for streaming to a live input using WebRTC. */
    webRTC?: LiveInputsCreateResponseWebRTC | null | undefined;
    /** Details for playback from a live input using WebRTC. */
    webRTCPlayback?: LiveInputsCreateResponseWebRTCPlayback | null | undefined;
}
export interface UpdateLiveInputOutputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
    /** A unique identifier for the output. */
    outputIdentifier: string;
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLiveInputOutputResponse {
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled?: boolean | null | undefined;
    /** The streamKey used to authenticate against an output's target. */
    streamKey?: string | null | undefined;
    /** A unique identifier for the output. */
    uid?: string | null | undefined;
    /** The URL an output uses to restream. */
    url?: string | null | undefined;
}
export type CopyAudioTrackError = CloudflareOpError;
/** Adds an additional audio track to a video using the provided audio track URL. */
export declare const copyAudioTrack: API.OperationMethod<CopyAudioTrackRequest, CopyAudioTrackResponse, CopyAudioTrackError, CloudflareOpContext>;
export type CreateCaptionLanguageError = CloudflareOpError;
/** Generate captions or subtitles for provided language via AI. */
export declare const createCaptionLanguage: API.OperationMethod<CreateCaptionLanguageRequest, CreateCaptionLanguageResponse, CreateCaptionLanguageError, CloudflareOpContext>;
export type CreateClipError = CloudflareOpError;
/** Clips a video based on the specified start and end times provided in seconds. */
export declare const createClip: API.OperationMethod<CreateClipRequest, CreateClipResponse, CreateClipError, CloudflareOpContext>;
export type CreateCopyError = CloudflareOpError;
/** Uploads a video to Stream from a provided URL. */
export declare const createCopy: API.OperationMethod<CreateCopyRequest, CreateCopyResponse, CreateCopyError, CloudflareOpContext>;
export type CreateDirectUploadError = CloudflareOpError;
/** Creates a direct upload endpoint that allows an end-user to upload a video without an API key. */
export declare const createDirectUpload: API.OperationMethod<CreateDirectUploadRequest, CreateDirectUploadResponse, CreateDirectUploadError, CloudflareOpContext>;
export type CreateDownloadError = CloudflareOpError;
/** Creates a download for a video when a video is ready to view. Use `/downloads/{download_type}` instead for type-specific downloads. Available types are `default` and `audio`. */
export declare const createDownload: API.OperationMethod<CreateDownloadRequest, CreateDownloadResponse, CreateDownloadError, CloudflareOpContext>;
export type CreateKeyError = CloudflareOpError;
/** Creates an RSA private key in PEM and JWK formats. Key files are only displayed once after creation. Keys are created, used, and deleted independently of videos, and every key can sign any video. */
export declare const createKey: API.OperationMethod<CreateKeyRequest, CreateKeyResponse, CreateKeyError, CloudflareOpContext>;
export type CreateLiveInputError = CloudflareOpError;
/** Creates a live input, and returns credentials that you or your users can use to stream live video to Cloudflare Stream. */
export declare const createLiveInput: API.OperationMethod<CreateLiveInputRequest, CreateLiveInputResponse, CreateLiveInputError, CloudflareOpContext>;
export type CreateLiveInputOutputError = LiveInputNotFound | Forbidden | CloudflareOpError;
/** Creates a new output that can be used to simulcast or restream live video to other RTMP or SRT destinations. Outputs are always linked to a specific live input -- one live input can have many outputs. */
export declare const createLiveInputOutput: API.OperationMethod<CreateLiveInputOutputRequest, CreateLiveInputOutputResponse, CreateLiveInputOutputError, CloudflareOpContext>;
export type CreateStreamError = CloudflareOpError;
/** Initiates a video upload using the TUS protocol. On success, the server responds with a status code 201 (created) and includes a `location` header to indicate where the content should be uploaded. Refer to https://tus.io for protocol details. */
export declare const createStream: API.OperationMethod<CreateStreamRequest, CreateStreamResponse, CreateStreamError, CloudflareOpContext>;
export type CreateTokenError = CloudflareOpError;
/** Creates a signed URL token for a video. If a body is not provided in the request, a token is created with default values. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type CreateWatermarkError = WatermarkImageInvalid | Forbidden | CloudflareOpError;
/** Creates watermark profiles using a single `HTTP POST multipart/form-data` request. */
export declare const createWatermark: API.OperationMethod<CreateWatermarkRequest, CreateWatermarkResponse, CreateWatermarkError, CloudflareOpContext>;
export type DeleteAudioTrackError = CloudflareOpError;
/** Deletes additional audio tracks on a video. Deleting a default audio track is not allowed. You must assign another audio track as default prior to deletion. */
export declare const deleteAudioTrack: API.OperationMethod<DeleteAudioTrackRequest, DeleteAudioTrackResponse, DeleteAudioTrackError, CloudflareOpContext>;
export type DeleteCaptionLanguageError = CloudflareOpError;
/** Removes the captions or subtitles from a video. */
export declare const deleteCaptionLanguage: API.OperationMethod<DeleteCaptionLanguageRequest, DeleteCaptionLanguageResponse, DeleteCaptionLanguageError, CloudflareOpContext>;
export type DeleteDownloadError = CloudflareOpError;
/** Delete the downloads for a video. Use `/downloads/{download_type}` instead for type-specific downloads. Available types are `default` and `audio`. */
export declare const deleteDownload: API.OperationMethod<DeleteDownloadRequest, DeleteDownloadResponse, DeleteDownloadError, CloudflareOpContext>;
export type DeleteKeyError = SigningKeyNotFound | Forbidden | CloudflareOpError;
/** Deletes signing keys and revokes all signed URLs generated with the key. */
export declare const deleteKey: API.OperationMethod<DeleteKeyRequest, DeleteKeyResponse, DeleteKeyError, CloudflareOpContext>;
export type DeleteLiveInputError = LiveInputNotFound | Forbidden | CloudflareOpError;
/** Permanently delete a live input, making it inaccessible and blocking current and future broadcasts to it. Existing recordings will be retained. */
export declare const deleteLiveInput: API.OperationMethod<DeleteLiveInputRequest, DeleteLiveInputResponse, DeleteLiveInputError, CloudflareOpContext>;
export type DeleteLiveInputOutputError = OutputNotFound | Forbidden | CloudflareOpError;
/** Deletes an output and removes it from the associated live input. */
export declare const deleteLiveInputOutput: API.OperationMethod<DeleteLiveInputOutputRequest, DeleteLiveInputOutputResponse, DeleteLiveInputOutputError, CloudflareOpContext>;
export type DeleteStreamError = CloudflareOpError;
/** Deletes a video and its copies from Cloudflare Stream. */
export declare const deleteStream: API.OperationMethod<DeleteStreamRequest, DeleteStreamResponse, DeleteStreamError, CloudflareOpContext>;
export type DeleteWatermarkError = WatermarkNotFound | Forbidden | CloudflareOpError;
/** Deletes a watermark profile. */
export declare const deleteWatermark: API.OperationMethod<DeleteWatermarkRequest, DeleteWatermarkResponse, DeleteWatermarkError, CloudflareOpContext>;
export type DeleteWebhookError = WebhookNotFound | Forbidden | CloudflareOpError;
/** Deletes the on-demand video webhook. */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookRequest, DeleteWebhookResponse, DeleteWebhookError, CloudflareOpContext>;
export type EditStreamError = CloudflareOpError;
/** Edit details for a single video. */
export declare const editStream: API.OperationMethod<EditStreamRequest, EditStreamResponse, EditStreamError, CloudflareOpContext>;
export type GetAudioTrackError = CloudflareOpError;
/** Lists additional audio tracks on a video. Note this API will not return information for audio attached to the video upload. */
export declare const getAudioTrack: API.OperationMethod<GetAudioTrackRequest, GetAudioTrackResponse, GetAudioTrackError, CloudflareOpContext>;
export type GetCaptionError = CloudflareOpError;
/** Lists the available captions or subtitles for a specific video. */
export declare const getCaption: API.PaginatedOperationMethod<GetCaptionRequest, GetCaptionResponse, GetCaptionError, CloudflareOpContext, CaptionsGetResultItem>;
export type GetCaptionLanguageError = CloudflareOpError;
/** Lists the captions or subtitles for provided language. */
export declare const getCaptionLanguage: API.OperationMethod<GetCaptionLanguageRequest, GetCaptionLanguageResponse, GetCaptionLanguageError, CloudflareOpContext>;
export type GetCaptionLanguageVttError = CloudflareOpError;
/** Return WebVTT captions for a provided language. */
export declare const getCaptionLanguageVtt: API.OperationMethod<GetCaptionLanguageVttRequest, GetCaptionLanguageVttResponse, GetCaptionLanguageVttError, CloudflareOpContext>;
export type GetDownloadError = CloudflareOpError;
/** Lists the downloads created for a video. */
export declare const getDownload: API.OperationMethod<GetDownloadRequest, GetDownloadResponse, GetDownloadError, CloudflareOpContext>;
export type GetEmbedError = CloudflareOpError;
/** Fetches the legacy HTML code snippet to embed a video in a web page delivered through Cloudflare. On success, returns an HTML fragment for use on web pages to display a video. On failure, returns a JSON response body. */
export declare const getEmbed: API.OperationMethod<GetEmbedRequest, GetEmbedResponse, GetEmbedError, CloudflareOpContext>;
export type GetKeyError = Forbidden | CloudflareOpError;
/** Lists the video ID and creation date and time when a signing key was created. */
export declare const getKey: API.PaginatedOperationMethod<GetKeyRequest, GetKeyResponse, GetKeyError, CloudflareOpContext, KeysGetResultItem>;
export type GetLiveInputError = LiveInputNotFound | Forbidden | CloudflareOpError;
/** Retrieves details of an existing live input. */
export declare const getLiveInput: API.OperationMethod<GetLiveInputRequest, GetLiveInputResponse, GetLiveInputError, CloudflareOpContext>;
export type GetStreamError = CloudflareOpError;
/** Fetches details for a single video. */
export declare const getStream: API.OperationMethod<GetStreamRequest, GetStreamResponse, GetStreamError, CloudflareOpContext>;
export type GetWatermarkError = WatermarkNotFound | Forbidden | CloudflareOpError;
/** Retrieves details for a single watermark profile. */
export declare const getWatermark: API.OperationMethod<GetWatermarkRequest, GetWatermarkResponse, GetWatermarkError, CloudflareOpContext>;
export type GetWebhookError = WebhookNotFound | Forbidden | CloudflareOpError;
/** Retrieve current on-demand webhook information. */
export declare const getWebhook: API.OperationMethod<GetWebhookRequest, GetWebhookResponse, GetWebhookError, CloudflareOpContext>;
export type ListLiveInputOutputsError = LiveInputNotFound | Forbidden | CloudflareOpError;
/** Retrieves all outputs associated with a specified live input. */
export declare const listLiveInputOutputs: API.PaginatedOperationMethod<ListLiveInputOutputsRequest, ListLiveInputOutputsResponse, ListLiveInputOutputsError, CloudflareOpContext, LiveInputsOutputsListResultItem>;
export type ListLiveInputsError = CloudflareOpError;
/** Lists the live inputs created for an account. To get the credentials needed to stream to a specific live input, request a single live input. */
export declare const listLiveInputs: API.OperationMethod<ListLiveInputsRequest, ListLiveInputsResponse, ListLiveInputsError, CloudflareOpContext>;
export type ListStreamsError = CloudflareOpError;
/** Lists up to 1000 videos from a single request. For a specific range, refer to the optional parameters. */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsRequest, ListStreamsResponse, ListStreamsError, CloudflareOpContext, ListResultItem>;
export type ListWatermarksError = CloudflareOpError;
/** Lists all watermark profiles for an account. */
export declare const listWatermarks: API.PaginatedOperationMethod<ListWatermarksRequest, ListWatermarksResponse, ListWatermarksError, CloudflareOpContext, ClipCreateResponseWatermark>;
export type PatchAudioTrackError = CloudflareOpError;
/** Edits additional audio tracks on a video. Editing the default status of an audio track to `true` will mark all other audio tracks on the video default status to `false`. */
export declare const patchAudioTrack: API.OperationMethod<PatchAudioTrackRequest, PatchAudioTrackResponse, PatchAudioTrackError, CloudflareOpContext>;
export type PutWebhookError = CloudflareOpError;
/** Create a webhook for notifications about on-demand video uploads. */
export declare const putWebhook: API.OperationMethod<PutWebhookRequest, PutWebhookResponse, PutWebhookError, CloudflareOpContext>;
export type StorageUsageVideoError = CloudflareOpError;
/** Returns information about an account's storage use. */
export declare const storageUsageVideo: API.OperationMethod<StorageUsageVideoRequest, StorageUsageVideoResponse, StorageUsageVideoError, CloudflareOpContext>;
export type UpdateCaptionLanguageError = CloudflareOpError;
/** Uploads the caption or subtitle file to the endpoint for a specific BCP47 language. One caption or subtitle file per language is allowed. */
export declare const updateCaptionLanguage: API.OperationMethod<UpdateCaptionLanguageRequest, UpdateCaptionLanguageResponse, UpdateCaptionLanguageError, CloudflareOpContext>;
export type UpdateLiveInputError = CloudflareOpError;
/** Updates a specified live input. */
export declare const updateLiveInput: API.OperationMethod<UpdateLiveInputRequest, UpdateLiveInputResponse, UpdateLiveInputError, CloudflareOpContext>;
export type UpdateLiveInputOutputError = OutputNotFound | Forbidden | CloudflareOpError;
/** Updates the state of an output. */
export declare const updateLiveInputOutput: API.OperationMethod<UpdateLiveInputOutputRequest, UpdateLiveInputOutputResponse, UpdateLiveInputOutputError, CloudflareOpContext>;
//# sourceMappingURL=stream.d.ts.map