import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const OrganizationNotFound_base: S.TaggedErrorClass<"OrganizationNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class OrganizationNotFound extends /*@__PURE__*/ OrganizationNotFound_base {
}
export interface CreateMemberRequestMemberUser {
    email: string;
}
export interface CreateMemberRequestMember {
    user: CreateMemberRequestMemberUser;
}
export interface CreateMemberRequest {
    organizationId: string;
    member: CreateMemberRequestMember;
}
export type CreateMemberResponseMetaMap = {
    [key: string]: unknown | undefined;
};
export type CreateMemberResponseStatus = "active" | "pending" | "rejected" | "canceled";
export interface CreateMemberResponseUser {
    id: string;
    email: string;
    name: string;
    twoFactorAuthenticationEnabled: boolean;
}
export interface CreateMemberResponsePoliciesItemRolesItem {
    id: string;
}
export type CreateMemberResponsePoliciesItemRolesList = Array<CreateMemberResponsePoliciesItemRolesItem>;
export type CreateMemberResponsePoliciesItemScopesItemSubsetOfList = Array<unknown>;
export interface CreateMemberResponsePoliciesItemScopesItem {
    /** An Organization (`com.cloudflare.api.tenant.unit.&lt;tag&gt;`) or Account (`com.cloudflare.api.account.&lt;tag&gt;`) key. */
    key: string;
    /** The route Organization for Account scopes. Optional in requests and always returned for Account scopes. */
    subsetOf?: CreateMemberResponsePoliciesItemScopesItemSubsetOfList | null | undefined;
}
export type CreateMemberResponsePoliciesItemScopesList = Array<CreateMemberResponsePoliciesItemScopesItem>;
export interface CreateMemberResponsePoliciesItem {
    roles: CreateMemberResponsePoliciesItemRolesList;
    scopes: CreateMemberResponsePoliciesItemScopesList;
    /** Omit to create a policy. An unchanged policy keeps its ID; a changed policy is replaced under a new ID. */
    id?: string | null | undefined;
}
export type CreateMemberResponsePoliciesList = Array<CreateMemberResponsePoliciesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMemberResponse {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: CreateMemberResponseMetaMap;
    status: CreateMemberResponseStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
    /** Direct policies of the membership. Present only for DSR members enrolled in Organization Roles. */
    policies?: CreateMemberResponsePoliciesList | null | undefined;
}
export type CreateRequestParent = CreateMemberResponsePoliciesItemRolesItem;
export interface CreateRequestProfile {
    businessAddress?: string | undefined;
    businessEmail?: string | undefined;
    businessName?: string | undefined;
    businessPhone?: string | undefined;
    externalMetadata?: string | undefined;
}
export interface CreateOrganizationRequest {
    /** The Organization name, limited to 65 UTF-8 bytes. */
    name: string;
    parent?: CreateMemberResponsePoliciesItemRolesItem | undefined;
    /** Optional profile fields, each limited to 1,000 UTF-8 bytes. An empty profile is ignored. */
    profile?: CreateRequestProfile | undefined;
}
export type CreateResponseMetaHierarchyTagsList = Array<string>;
export interface CreateResponseMetaTenantFlags {
    accountCreation: string;
    accountCreationAppliesTenantDefaults: string;
    accountDeletion: string;
    accountMigration: string;
    accountMobility: string;
    enterpriseCapability: string;
    memberManagement: string;
    subOrgCreation: string;
}
export interface CreateResponseMeta {
    areChildAccountsAccessibleByOrgMembers?: boolean | null | undefined;
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: CreateResponseMetaHierarchyTagsList | null | undefined;
    managedBy?: string | null | undefined;
    /** Enable features for Organizations. */
    tenantFlags?: CreateResponseMetaTenantFlags | null | undefined;
    tenantType?: string | null | undefined;
}
export interface CreateResponseParent {
    id: string;
    name: string;
}
export interface CreateResponseProfile {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOrganizationResponse {
    id: string;
    createTime: string;
    meta: CreateResponseMeta;
    name: string;
    parent?: CreateResponseParent | null | undefined;
    profile?: CreateResponseProfile | null | undefined;
}
export interface DeleteMemberRequest {
    organizationId: string;
    /** Organization Member ID */
    memberId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMemberResponse {
    id: string;
}
export interface DeleteOrganizationRequest {
    organizationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOrganizationResponse {
    id: string;
}
export interface GetBillingUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    organizationId: string;
    /** Start date for the usage query (ISO 8601). Required if `to` is set. When omitted along with `to`, defaults to the start of the current month. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    from?: string | undefined;
    /** End date for the usage query (ISO 8601). Required if `from` is set. When omitted along with `from`, defaults to today. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    to?: string | undefined;
}
export type BillingUsageGetResultItemChargeCategory = "Usage";
export type BillingUsageGetResultItemChargeFrequency = "Usage-Based";
export type BillingUsageGetResultItemChargeClass = "Correction";
export type BillingUsageGetResultItemTagsValue = string | boolean;
export type BillingUsageGetResultItemTagsMap = {
    [key: string]: BillingUsageGetResultItemTagsValue | undefined;
};
export interface BillingUsageGetResultItem {
    /** Highest-level classification of a charge based on the nature of how it gets billed. Currently only "Usage" is supported. */
    chargeCategory: BillingUsageGetResultItemChargeCategory;
    /** Self-contained summary of the charge's purpose and price. */
    chargeDescription: string;
    /** Indicates how often a charge occurs. Currently only "Usage-Based" is supported. */
    chargeFrequency: BillingUsageGetResultItemChargeFrequency;
    /** Exclusive end of the time interval during which the usage was consumed. */
    chargePeriodEnd: string;
    /** Inclusive start of the time interval during which the usage was consumed. */
    chargePeriodStart: string;
    /** Unit of measure for the consumed quantity (e.g., "GB", "Requests", "vCPU-Hours"). */
    consumedUnit: string;
    /** Name of the entity providing the underlying infrastructure or platform. */
    hostProviderName: string;
    /** Name of the entity responsible for invoicing for the services consumed. */
    invoiceIssuerName: string;
    /** Name of the entity that made the services available for purchase. */
    serviceProviderName: string;
    /** The unique identifier for the billable metric in the Cloudflare catalog. Cloudflare extension; replaces FOCUS SkuId. */
    xBillableMetricId: string;
    /** A charge serving as the basis for invoicing, inclusive of all reduced rates and discounts while excluding the amortization of upfront charges (one-time or recurring). */
    billedCost?: number | null | undefined;
    /** Public identifier of the Cloudflare account (account tag). Omitted when account is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by account: that usage is returned as its own record with no account. */
    billingAccountId?: string | null | undefined;
    /** Display name of the Cloudflare account. Omitted when account is not part of the requested grouping, and for usage measured at contract level. */
    billingAccountName?: string | null | undefined;
    /** Currency that a charge was billed in (ISO 4217). */
    billingCurrency?: string | null | undefined;
    /** Exclusive end of the billing cycle that contains this usage record. */
    billingPeriodEnd?: string | null | undefined;
    /** Inclusive start of the billing cycle that contains this usage record. */
    billingPeriodStart?: string | null | undefined;
    /** Indicates whether the row represents a correction to one or more charges invoiced in a previous billing period. */
    chargeClass?: BillingUsageGetResultItemChargeClass | null | undefined;
    /** Measured usage amount within the charge period. Reflects raw metered consumption before pricing transformations. */
    consumedQuantity?: number | null | undefined;
    /** Cost calculated by multiplying ContractedUnitPrice and the corresponding PricingQuantity. */
    contractedCost?: number | null | undefined;
    /** The agreed-upon unit price for a single PricingUnit of the associated billable metric, inclusive of negotiated discounts, if present, while excluding any other discounts. */
    contractedUnitPrice?: number | null | undefined;
    /** The amortized cost of the charge after applying all reduced rates, discounts, and the applicable portion of relevant, prepaid purchases (one-time or recurring) that covered the charge. */
    effectiveCost?: number | null | undefined;
    /** Cost calculated by multiplying ListUnitPrice and the corresponding PricingQuantity. */
    listCost?: number | null | undefined;
    /** Suggested provider-published unit price for a single PricingUnit of the associated billable metric, exclusive of any discounts. */
    listUnitPrice?: number | null | undefined;
    /** Volume of a given service used or purchased, based on the PricingUnit. */
    pricingQuantity?: number | null | undefined;
    /** Provider-specified measurement unit for determining unit prices, indicating how the provider rates measured usage after applying pricing rules like block pricing. */
    pricingUnit?: string | null | undefined;
    /** Provider-assigned identifier for an isolated geographic area where a service is provided. */
    regionId?: string | null | undefined;
    /** Name of an isolated geographic area where a service is provided. */
    regionName?: string | null | undefined;
    /** Unique identifier assigned to a grouping of services. For Cloudflare, this is the subscription or contract ID. */
    subAccountId?: string | null | undefined;
    /** Name assigned to a grouping of services. For Cloudflare, this is the subscription or contract display name. */
    subAccountName?: string | null | undefined;
    /** Tag values for the requested `GroupBy` keys. Omitted when `GroupBy` is not provided. Missing keys are omitted, and key-only tags are returned as boolean `true`. All other tag values are strings. */
    tags?: BillingUsageGetResultItemTagsMap | null | undefined;
    /** The display name of the billable metric. Cloudflare extension; replaces FOCUS SkuMeter. */
    xBillableMetricName?: string | null | undefined;
    /** The product category the charge belongs to (e.g., "Developer", "Cloudflare One"). Cloudflare extension; replaces FOCUS ServiceCategory. */
    xProductCategoryName?: string | null | undefined;
    /** The unique identifier for the product family in the Cloudflare catalog. Cloudflare extension; replaces FOCUS ServiceId. */
    xProductFamilyId?: string | null | undefined;
    /** The product family the charge belongs to (e.g., "R2", "Workers"). Cloudflare extension; replaces FOCUS ServiceName. */
    xProductFamilyName?: string | null | undefined;
    /** The identifier for the Cloudflare zone (zone tag). Omitted when zone is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by zone. Cloudflare extension. */
    xZoneId?: string | null | undefined;
    /** The display name of the Cloudflare zone. Omitted when zone is not part of the requested grouping, and for usage measured at contract level. Cloudflare extension. */
    xZoneName?: string | null | undefined;
}
export type BillingUsageGetResultList = Array<BillingUsageGetResultItem>;
export type GetBillingUsageResponse = BillingUsageGetResultList;
export interface GetMemberRequest {
    organizationId: string;
    /** Organization Member ID */
    memberId: string;
}
export type GetMemberResponseMetaMap = {
    [key: string]: unknown | undefined;
};
export type GetMemberResponseStatus = "active" | "pending" | "rejected" | "canceled";
export type GetMemberResponseUser = CreateMemberResponseUser;
export type GetMemberResponsePoliciesItemRolesItem = CreateMemberResponsePoliciesItemRolesItem;
export type GetMemberResponsePoliciesItemRolesList = Array<CreateMemberResponsePoliciesItemRolesItem>;
export type GetMemberResponsePoliciesItemScopesItemSubsetOfList = Array<unknown>;
export interface GetMemberResponsePoliciesItemScopesItem {
    /** An Organization (`com.cloudflare.api.tenant.unit.&lt;tag&gt;`) or Account (`com.cloudflare.api.account.&lt;tag&gt;`) key. */
    key: string;
    /** The route Organization for Account scopes. Optional in requests and always returned for Account scopes. */
    subsetOf?: GetMemberResponsePoliciesItemScopesItemSubsetOfList | null | undefined;
}
export type GetMemberResponsePoliciesItemScopesList = Array<GetMemberResponsePoliciesItemScopesItem>;
export interface GetMemberResponsePoliciesItem {
    roles: GetMemberResponsePoliciesItemRolesList;
    scopes: GetMemberResponsePoliciesItemScopesList;
    /** Omit to create a policy. An unchanged policy keeps its ID; a changed policy is replaced under a new ID. */
    id?: string | null | undefined;
}
export type GetMemberResponsePoliciesList = Array<GetMemberResponsePoliciesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMemberResponse {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: GetMemberResponseMetaMap;
    status: GetMemberResponseStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
    /** Direct policies of the membership. Present only for DSR members enrolled in Organization Roles. */
    policies?: GetMemberResponsePoliciesList | null | undefined;
}
export interface GetOrganizationRequest {
    organizationId: string;
}
export type GetResponseMetaHierarchyTagsList = Array<string>;
export type GetResponseMetaTenantFlags = CreateResponseMetaTenantFlags;
export interface GetResponseMeta {
    areChildAccountsAccessibleByOrgMembers?: boolean | null | undefined;
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: GetResponseMetaHierarchyTagsList | null | undefined;
    managedBy?: string | null | undefined;
    /** Enable features for Organizations. */
    tenantFlags?: CreateResponseMetaTenantFlags | null | undefined;
    tenantType?: string | null | undefined;
}
export type GetResponseParent = CreateResponseParent;
export type GetResponseProfile = CreateResponseProfile;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOrganizationResponse {
    id: string;
    createTime: string;
    meta: GetResponseMeta;
    name: string;
    parent?: CreateResponseParent | null | undefined;
    profile?: CreateResponseProfile | null | undefined;
}
export interface GetOrganizationAccountRequestAccountPubname {
    /** (case-insensitive) Filter the list of accounts to where the account_pubname contains a particular string. */
    contains?: string | undefined;
    /** (case-insensitive) Filter the list of accounts to where the account_pubname ends with a particular string. */
    endsWith?: string | undefined;
    /** (case-insensitive) Filter the list of accounts to where the account_pubname starts with a particular string. */
    startsWith?: string | undefined;
}
export type GetOrganizationAccountRequestDirection = "asc" | "desc";
export interface GetOrganizationAccountRequestName {
    /** (case-insensitive) Filter the list of accounts to where the name contains a particular string. */
    contains?: string | undefined;
    /** (case-insensitive) Filter the list of accounts to where the name ends with a particular string. */
    endsWith?: string | undefined;
    /** (case-insensitive) Filter the list of accounts to where the name starts with a particular string. */
    startsWith?: string | undefined;
}
export type GetOrganizationAccountRequestOrderBy = "account_name";
export type GetOrganizationAccountRequestStatus = "active" | "deleted";
export interface GetOrganizationAccountRequest {
    organizationId: string;
    accountPubname?: GetOrganizationAccountRequestAccountPubname | undefined;
    /** Sort direction for the order_by field. Valid values: `asc`, `desc`. Defaults to `asc` when order_by is specified. */
    direction?: GetOrganizationAccountRequestDirection | (string & {}) | undefined;
    /** Include Account tags from the resource tag mirror. Omit this parameter to preserve the existing Account response shape. */
    includeTags?: boolean | undefined;
    /** Whether to calculate and return the exact result_info.total_size for cursor pagination. Defaults to true. When false, total_size is omitted. page_size and include_total may change between pages; next_page_token remains the authoritative continuation signal. */
    includeTotal?: boolean | undefined;
    name?: GetOrganizationAccountRequestName | undefined;
    /** Field to order results by. Currently supported values: `account_name`. */
    orderBy?: GetOrganizationAccountRequestOrderBy | (string & {}) | undefined;
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number | undefined;
    /** An opaque token returned from the last list response that when provided will retrieve the next page. */
    pageToken?: string | undefined;
    /** Filter accounts by lifecycle status. Defaults to `active`. */
    status?: GetOrganizationAccountRequestStatus | (string & {}) | undefined;
    accept?: string | undefined;
}
export interface GetOrganizationAccountResultItemTenantAccountSettings {
    abuseContactEmail: string;
    accessApprovalExpiry: string;
    apiAccessEnabled: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    defaultNameservers: string;
    enforceTwofactor: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    useAccountCustomNsByDefault: boolean;
}
export type GetOrganizationAccountResultItemTenantAccountType = "standard" | "enterprise";
export type GetOrganizationAccountResultItemTenantAccountTagsMap = {
    [key: string]: string | undefined;
};
export interface GetOrganizationAccountResultItemTenantAccount {
    id: string;
    createdOn: string;
    name: string;
    settings: GetOrganizationAccountResultItemTenantAccountSettings;
    type: GetOrganizationAccountResultItemTenantAccountType;
    /** Account tags, present only when `include_tags=true` is requested. */
    tags?: GetOrganizationAccountResultItemTenantAccountTagsMap | null | undefined;
}
export type GetOrganizationAccountResultItemOrganizationsAPILegacyAccountAccountType = "standard" | "enterprise";
export interface GetOrganizationAccountResultItemOrganizationsAPILegacyAccountSettings {
    accessApprovalExpiry: string;
    apiAccessEnabled: boolean;
    enforceTwoFactor: boolean;
    useAccountCustomNsByDefault: boolean;
}
export interface GetOrganizationAccountResultItemOrganizationsAPILegacyAccount {
    accountPubname: string;
    accountTag: string;
    accountType: GetOrganizationAccountResultItemOrganizationsAPILegacyAccountAccountType;
    createdOn: string;
    settings: GetOrganizationAccountResultItemOrganizationsAPILegacyAccountSettings;
}
export type GetOrganizationAccountResultItem = GetOrganizationAccountResultItemTenantAccount | GetOrganizationAccountResultItemOrganizationsAPILegacyAccount;
export type GetOrganizationAccountResultList = Array<GetOrganizationAccountResultItem>;
export type GetOrganizationAccountResponse = GetOrganizationAccountResultList;
export interface GetOrganizationProfileRequest {
    organizationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOrganizationProfileResponse {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export type LogsAuditListRequestIdNotList = Array<string>;
export interface LogsAuditListRequestId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestIdNotList | undefined;
}
export type LogsAuditListRequestActionResultNotItem = "success" | "failure";
export type LogsAuditListRequestActionResultNotList = Array<LogsAuditListRequestActionResultNotItem | (string & {})>;
export interface LogsAuditListRequestActionResult {
    /** Filters out audit logs by whether the action was successful or not. */
    not?: LogsAuditListRequestActionResultNotList | undefined;
}
export type LogsAuditListRequestActionTypeNotItem = "create" | "delete" | "view" | "update";
export type LogsAuditListRequestActionTypeNotList = Array<LogsAuditListRequestActionTypeNotItem | (string & {})>;
export interface LogsAuditListRequestActionType {
    /** Filters out audit logs by the action type. */
    not?: LogsAuditListRequestActionTypeNotList | undefined;
}
export type LogsAuditListRequestActorContextNotItem = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditListRequestActorContextNotList = Array<LogsAuditListRequestActorContextNotItem | (string & {})>;
export interface LogsAuditListRequestActorContext {
    /** Filters out audit logs by the actor context. */
    not?: LogsAuditListRequestActorContextNotList | undefined;
}
export type LogsAuditListRequestActorEmailNotList = Array<string>;
export interface LogsAuditListRequestActorEmail {
    /** Filters out audit logs by the actor's email address. */
    not?: LogsAuditListRequestActorEmailNotList | undefined;
}
export type LogsAuditListRequestActorIdNotList = Array<string>;
export interface LogsAuditListRequestActorId {
    /** Filters out audit logs by the actor's user ID. */
    not?: LogsAuditListRequestActorIdNotList | undefined;
}
export type LogsAuditListRequestActorIpAddressNotList = Array<string>;
export interface LogsAuditListRequestActorIpAddress {
    /** Filters out audit logs IP address where the action was initiated. */
    not?: LogsAuditListRequestActorIpAddressNotList | undefined;
}
export type LogsAuditListRequestActorTokenIdNotList = Array<string>;
export interface LogsAuditListRequestActorTokenId {
    /** Filters out audit logs by the API token ID when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenIdNotList | undefined;
}
export type LogsAuditListRequestActorTokenNameNotList = Array<string>;
export interface LogsAuditListRequestActorTokenName {
    /** Filters out audit logs by the API token name when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenNameNotList | undefined;
}
export type LogsAuditListRequestActorTypeNotItem = "cloudflare_admin" | "system" | "user";
export type LogsAuditListRequestActorTypeNotList = Array<LogsAuditListRequestActorTypeNotItem | (string & {})>;
export interface LogsAuditListRequestActorType {
    /** Filters out audit logs by the actor type. */
    not?: LogsAuditListRequestActorTypeNotList | undefined;
}
export type LogsAuditListRequestDirection = "desc" | "asc";
export type LogsAuditListRequestRawCfRayIdNotList = Array<string>;
export interface LogsAuditListRequestRawCfRayId {
    /** Filters out audit logs by the response CF Ray ID. */
    not?: LogsAuditListRequestRawCfRayIdNotList | undefined;
}
export type LogsAuditListRequestRawMethodNotList = Array<string>;
export interface LogsAuditListRequestRawMethod {
    /** Filters out audit logs by the HTTP method for the API call. */
    not?: LogsAuditListRequestRawMethodNotList | undefined;
}
export type LogsAuditListRequestRawStatusCodeNotList = Array<number>;
export interface LogsAuditListRequestRawStatusCode {
    /** Filters out audit logs by the response status code that was returned. */
    not?: LogsAuditListRequestRawStatusCodeNotList | undefined;
}
export type LogsAuditListRequestRawUriNotList = Array<string>;
export interface LogsAuditListRequestRawUri {
    /** Filters out audit logs by the request URI. */
    not?: LogsAuditListRequestRawUriNotList | undefined;
}
export type LogsAuditListRequestResourceIdNotList = Array<string>;
export interface LogsAuditListRequestResourceId {
    /** Filters out audit logs by the resource ID. */
    not?: LogsAuditListRequestResourceIdNotList | undefined;
}
export type LogsAuditListRequestResourceProductNotList = Array<string>;
export interface LogsAuditListRequestResourceProduct {
    /** Filters out audit logs by the Cloudflare product associated with the changed resource. */
    not?: LogsAuditListRequestResourceProductNotList | undefined;
}
export type LogsAuditListRequestResourceScopeNotItem = "organizations";
export type LogsAuditListRequestResourceScopeNotList = Array<LogsAuditListRequestResourceScopeNotItem | (string & {})>;
export interface LogsAuditListRequestResourceScope {
    /** Filters out audit logs by the resource scope, specifying whether the resource is associated with an organization. */
    not?: LogsAuditListRequestResourceScopeNotList | undefined;
}
export type LogsAuditListRequestResourceTypeNotList = Array<string>;
export interface LogsAuditListRequestResourceType {
    /** Filters out audit logs based on the unique type of resource changed by the action. */
    not?: LogsAuditListRequestResourceTypeNotList | undefined;
}
export interface ListLogAuditsRequest {
    /** The unique id that identifies the organization. */
    organizationId: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    id?: LogsAuditListRequestId | undefined;
    actionResult?: LogsAuditListRequestActionResult | undefined;
    actionType?: LogsAuditListRequestActionType | undefined;
    actorContext?: LogsAuditListRequestActorContext | undefined;
    actorEmail?: LogsAuditListRequestActorEmail | undefined;
    actorId?: LogsAuditListRequestActorId | undefined;
    actorIpAddress?: LogsAuditListRequestActorIpAddress | undefined;
    actorTokenId?: LogsAuditListRequestActorTokenId | undefined;
    actorTokenName?: LogsAuditListRequestActorTokenName | undefined;
    actorType?: LogsAuditListRequestActorType | undefined;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string | undefined;
    /** Sets sorting order. */
    direction?: LogsAuditListRequestDirection | (string & {}) | undefined;
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number | undefined;
    rawCfRayId?: LogsAuditListRequestRawCfRayId | undefined;
    rawMethod?: LogsAuditListRequestRawMethod | undefined;
    rawStatusCode?: LogsAuditListRequestRawStatusCode | undefined;
    rawUri?: LogsAuditListRequestRawUri | undefined;
    resourceId?: LogsAuditListRequestResourceId | undefined;
    resourceProduct?: LogsAuditListRequestResourceProduct | undefined;
    resourceScope?: LogsAuditListRequestResourceScope | undefined;
    resourceType?: LogsAuditListRequestResourceType | undefined;
}
export interface LogsAuditListResultItemAction {
    /** A short description of the action performed. */
    description?: string | null | undefined;
    /** The result of the action, indicating success or failure. */
    result?: string | null | undefined;
    /** A timestamp indicating when the action was logged. */
    time?: string | null | undefined;
    /** A short string that describes the action that was performed. */
    type?: string | null | undefined;
}
export type LogsAuditListResultItemActorContext = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditListResultItemActorType = "cloudflare_admin" | "system" | "user";
export interface LogsAuditListResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null | undefined;
    /** The context in which the action was initiated. */
    context?: LogsAuditListResultItemActorContext | null | undefined;
    /** The email of the actor who performed the action. */
    email?: string | null | undefined;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null | undefined;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null | undefined;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null | undefined;
    /** The type of actor. */
    type?: LogsAuditListResultItemActorType | null | undefined;
}
export interface LogsAuditListResultItemOrganization {
    /** A unique identifier for the organization. */
    id?: string | null | undefined;
}
export interface LogsAuditListResultItemRaw {
    /** The Cloudflare Ray ID for the request. */
    cfRayId?: string | null | undefined;
    /** The HTTP method of the request. */
    method?: string | null | undefined;
    /** The HTTP response status code returned by the API. */
    statusCode?: number | null | undefined;
    /** The URI of the request. */
    uri?: string | null | undefined;
    /** The client's user agent string sent with the request. */
    userAgent?: string | null | undefined;
}
export interface LogsAuditListResultItemResource {
    /** The unique identifier for the affected resource. */
    id?: string | null | undefined;
    /** The Cloudflare product associated with the resource. */
    product?: string | null | undefined;
    request?: unknown | null | undefined;
    response?: unknown | null | undefined;
    /** The scope of the resource. */
    scope?: unknown | null | undefined;
    /** The type of the resource. */
    type?: string | null | undefined;
}
export interface LogsAuditListResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null | undefined;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null | undefined;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditListResultItemActor | null | undefined;
    /** Contains organization related information. */
    organization?: LogsAuditListResultItemOrganization | null | undefined;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null | undefined;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null | undefined;
}
export type LogsAuditListResultList = Array<LogsAuditListResultItem>;
export interface ListLogAuditsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogsAuditListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type ListMembersRequestStatus = "active" | "pending" | "rejected" | "canceled";
export type ListMembersRequestStatusList = Array<ListMembersRequestStatus | (string & {})>;
export interface ListMembersRequestUser {
    /** Filter the list of memberships for a specific email that ends with a substring. */
    email?: string | undefined;
}
export interface ListMembersRequest {
    organizationId: string;
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number | undefined;
    /** An opaque token returned from the last list response that when provided will retrieve the next page. */
    pageToken?: string | undefined;
    /** Filter the list of memberships by membership status. Defaults to `active`, `pending`, and `rejected`; pass `canceled` explicitly to include canceled memberships. */
    status?: ListMembersRequestStatusList | undefined;
    user?: ListMembersRequestUser | undefined;
}
export type ListMembersResultItemMetaMap = {
    [key: string]: unknown | undefined;
};
export type ListMembersResultItemStatus = "active" | "pending" | "rejected" | "canceled";
export type ListMembersResultItemUser = CreateMemberResponseUser;
export type ListMembersResultItemPoliciesItemRolesItem = CreateMemberResponsePoliciesItemRolesItem;
export type ListMembersResultItemPoliciesItemRolesList = Array<CreateMemberResponsePoliciesItemRolesItem>;
export type ListMembersResultItemPoliciesItemScopesItemSubsetOfList = Array<unknown>;
export interface ListMembersResultItemPoliciesItemScopesItem {
    /** An Organization (`com.cloudflare.api.tenant.unit.&lt;tag&gt;`) or Account (`com.cloudflare.api.account.&lt;tag&gt;`) key. */
    key: string;
    /** The route Organization for Account scopes. Optional in requests and always returned for Account scopes. */
    subsetOf?: ListMembersResultItemPoliciesItemScopesItemSubsetOfList | null | undefined;
}
export type ListMembersResultItemPoliciesItemScopesList = Array<ListMembersResultItemPoliciesItemScopesItem>;
export interface ListMembersResultItemPoliciesItem {
    roles: ListMembersResultItemPoliciesItemRolesList;
    scopes: ListMembersResultItemPoliciesItemScopesList;
    /** Omit to create a policy. An unchanged policy keeps its ID; a changed policy is replaced under a new ID. */
    id?: string | null | undefined;
}
export type ListMembersResultItemPoliciesList = Array<ListMembersResultItemPoliciesItem>;
export interface ListMembersResultItem {
    /** Organization Member ID */
    id: string;
    createTime: string;
    meta: ListMembersResultItemMetaMap;
    status: ListMembersResultItemStatus;
    updateTime: string;
    user: CreateMemberResponseUser;
    /** Direct policies of the membership. Present only for DSR members enrolled in Organization Roles. */
    policies?: ListMembersResultItemPoliciesList | null | undefined;
}
export type ListMembersResultList = Array<ListMembersResultItem>;
export type ListMembersResponse = ListMembersResultList;
export type ListRequestIdList = Array<string>;
export interface ListRequestContaining {
    /** Filter the list of organizations to the ones that contain this particular account. */
    account?: string | undefined;
    /** Filter the list of organizations to the ones that contain this particular organization. */
    organization?: string | undefined;
    /** Filter the list of organizations to the ones that contain this particular user. */
    user?: string | undefined;
}
export type ListRequestDirection = "asc" | "desc";
export interface ListRequestMember {
    /** Filter organizations to those where the given user, by email, is an active member of that exact organization. This does not include hierarchy-derived access. */
    email?: string | undefined;
}
export interface ListRequestName {
    /** (case-insensitive) Filter the list of organizations to where the name contains a particular string. */
    contains?: string | undefined;
    /** (case-insensitive) Filter the list of organizations to where the name ends with a particular string. */
    endsWith?: string | undefined;
    /** (case-insensitive) Filter the list of organizations to where the name starts with a particular string. */
    startsWith?: string | undefined;
}
export type ListRequestOrderBy = "name";
export interface ListRequestParent {
    /** Filter the list of organizations to the ones that are a sub-organization of the specified organization. */
    id?: string | undefined;
}
export interface ListOrganizationsRequest {
    /** Only return organizations with the specified IDs (ex. id=foo&id=bar). Send multiple elements by repeating the query value. */
    id?: ListRequestIdList | undefined;
    containing?: ListRequestContaining | undefined;
    /** Sort direction for the `order_by` field. Defaults to `asc` when `order_by` is specified. */
    direction?: ListRequestDirection | (string & {}) | undefined;
    member?: ListRequestMember | undefined;
    name?: ListRequestName | undefined;
    /** Field to order results by. Currently supported values: `name`. When not specified, results are ordered by hierarchy. */
    orderBy?: ListRequestOrderBy | (string & {}) | undefined;
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number | undefined;
    /** An opaque token returned from the last list response that when provided will retrieve the next page. */
    pageToken?: string | undefined;
    parent?: ListRequestParent | undefined;
}
export type ListResultItemMetaHierarchyTagsList = Array<string>;
export type ListResultItemMetaTenantFlags = CreateResponseMetaTenantFlags;
export interface ListResultItemMeta {
    areChildAccountsAccessibleByOrgMembers?: boolean | null | undefined;
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: ListResultItemMetaHierarchyTagsList | null | undefined;
    managedBy?: string | null | undefined;
    /** Enable features for Organizations. */
    tenantFlags?: CreateResponseMetaTenantFlags | null | undefined;
    tenantType?: string | null | undefined;
}
export type ListResultItemParent = CreateResponseParent;
export type ListResultItemProfile = CreateResponseProfile;
export interface ListResultItem {
    id: string;
    createTime: string;
    meta: ListResultItemMeta;
    name: string;
    parent?: CreateResponseParent | null | undefined;
    profile?: CreateResponseProfile | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListOrganizationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type LogsAuditHistoryRequestDirection = "desc" | "asc";
export interface LogsAuditHistoryRequest {
    /** The unique ID that identifies the organization. */
    organizationId: string;
    /** The ID of the audit log to fetch resource history for. */
    id: string;
    /** RFC3339 timestamp of the source audit log entry's action time. Used to narrow the source-entry lookup window. Provide the `action.time` value from the audit log identified by `id`. */
    actionTime: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string | undefined;
    /** Sets sorting order. */
    direction?: LogsAuditHistoryRequestDirection | (string & {}) | undefined;
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number | undefined;
}
export type LogsAuditHistoryResultItemAction = LogsAuditListResultItemAction;
export type LogsAuditHistoryResultItemActorContext = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditHistoryResultItemActorType = "cloudflare_admin" | "system" | "user";
export interface LogsAuditHistoryResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null | undefined;
    /** The context in which the action was initiated. */
    context?: LogsAuditHistoryResultItemActorContext | null | undefined;
    /** The email of the actor who performed the action. */
    email?: string | null | undefined;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null | undefined;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null | undefined;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null | undefined;
    /** The type of actor. */
    type?: LogsAuditHistoryResultItemActorType | null | undefined;
}
export type LogsAuditHistoryResultItemOrganization = LogsAuditListResultItemOrganization;
export type LogsAuditHistoryResultItemRaw = LogsAuditListResultItemRaw;
export type LogsAuditHistoryResultItemResource = LogsAuditListResultItemResource;
export interface LogsAuditHistoryResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null | undefined;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null | undefined;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditHistoryResultItemActor | null | undefined;
    /** Contains organization related information. */
    organization?: LogsAuditListResultItemOrganization | null | undefined;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null | undefined;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null | undefined;
}
export type LogsAuditHistoryResultList = Array<LogsAuditHistoryResultItem>;
export type LogsAuditHistoryResponse = LogsAuditHistoryResultList;
export interface PutOrganizationProfileRequest {
    organizationId: string;
    businessAddress?: string | undefined;
    businessEmail?: string | undefined;
    businessName?: string | undefined;
    businessPhone?: string | undefined;
    externalMetadata?: string | undefined;
}
export interface PutOrganizationProfileResponse {
}
export interface UpdateOrganizationRequest {
    organizationId: string;
    /** The Organization name, limited to 65 UTF-8 bytes. An omitted, empty, or unchanged value is a no-op. */
    name?: string | undefined;
    /** The current parent Organization ID. A different value is rejected; this endpoint cannot move an Organization. */
    parentId?: string | undefined;
}
export type UpdateResponseMetaHierarchyTagsList = Array<string>;
export type UpdateResponseMetaTenantFlags = CreateResponseMetaTenantFlags;
export interface UpdateResponseMeta {
    areChildAccountsAccessibleByOrgMembers?: boolean | null | undefined;
    /** Ordered chain of organization tags from the root organization down to (and including) this organization itself. Root organizations return a single-element array containing their own tag; sub-organizations return `[rootTag, ...intermediateTags, parentTag, selfTag]`. Useful for constructing authorization scopes that need to cover every ancestor in the hierarchy. */
    hierarchyTags?: UpdateResponseMetaHierarchyTagsList | null | undefined;
    managedBy?: string | null | undefined;
    /** Enable features for Organizations. */
    tenantFlags?: CreateResponseMetaTenantFlags | null | undefined;
    tenantType?: string | null | undefined;
}
export type UpdateResponseParent = CreateResponseParent;
export type UpdateResponseProfile = CreateResponseProfile;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateOrganizationResponse {
    id: string;
    createTime: string;
    meta: UpdateResponseMeta;
    name: string;
    parent?: CreateResponseParent | null | undefined;
    profile?: CreateResponseProfile | null | undefined;
}
export type CreateMemberError = CloudflareOpError;
/** Create a membership that grants access to a specific Organization. */
export declare const createMember: API.OperationMethod<CreateMemberRequest, CreateMemberResponse, CreateMemberError, CloudflareOpContext>;
export type CreateOrganizationError = Forbidden | CloudflareOpError;
/** Create a new organization for a user. Sub-organization creation availability depends on the organization's capabilities. The optional `profile` object accepts partial profile details; its individual fields are not required. Organization names are limited to 65 UTF-8 bytes. Each profile field is limited to 1,000 UTF-8 bytes, and a non-empty business email must be valid. At least one of business name, address, phone, or email must be non-empty to persist a profile. */
export declare const createOrganization: API.OperationMethod<CreateOrganizationRequest, CreateOrganizationResponse, CreateOrganizationError, CloudflareOpContext>;
export type DeleteMemberError = CloudflareOpError;
/** Delete a membership to a particular Organization. */
export declare const deleteMember: API.OperationMethod<DeleteMemberRequest, DeleteMemberResponse, DeleteMemberError, CloudflareOpContext>;
export type DeleteOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Delete an organization. It must not contain active sub-organizations or accounts. A root organization must also have no active managed users. Sub-organization deletion availability depends on the organization's capabilities. **Access Control:** Root deletion is restricted to enterprise organizations. */
export declare const deleteOrganization: API.OperationMethod<DeleteOrganizationRequest, DeleteOrganizationResponse, DeleteOrganizationError, CloudflareOpContext>;
export type GetBillingUsageError = CloudflareOpError;
/** Returns cost and usage data for all accounts within an organization, aligned with the [FinOps FOCUS v1.3](https://focus.finops.org/focus-specification/v1-3/) Cost and Usage dataset specification. Each record represents one billable metric for one account on one day. This includes all metered usage, including usage that falls within free-tier allowances and may result in zero cost. The response includes usage for every account belonging to the specified organization. **Note:** This endpoint serves `usage` records only; cost and pricing fields are absent from responses. Rated costs are available per account via `POST /accounts/{account_id}/billable/usage` with `Metric: cost`. When `from` and `to` are omitted, defaults to the start of the current month through today. The maximum date range is 31 days. An organization with no accounts, or an organization ID that does not exist, returns a successful response with an empty result set rather than an error. */
export declare const getBillingUsage: API.OperationMethod<GetBillingUsageRequest, GetBillingUsageResponse, GetBillingUsageError, CloudflareOpContext>;
export type GetMemberError = CloudflareOpError;
/** Retrieve a single membership from an Organization. */
export declare const getMember: API.OperationMethod<GetMemberRequest, GetMemberResponse, GetMemberError, CloudflareOpContext>;
export type GetOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Retrieve the details of a certain organization. */
export declare const getOrganization: API.OperationMethod<GetOrganizationRequest, GetOrganizationResponse, GetOrganizationError, CloudflareOpContext>;
export type GetOrganizationAccountError = CloudflareOpError;
/** Retrieve the accounts immediately attached to a specific organization. Accounts attached to sub-organizations are not included. Use `page_token` and `page_size` for cursor pagination. The default response uses Account fields; `Accept: application/json; legacy=true` requests the LegacyAccount representation. */
export declare const getOrganizationAccount: API.OperationMethod<GetOrganizationAccountRequest, GetOrganizationAccountResponse, GetOrganizationAccountError, CloudflareOpContext>;
export type GetOrganizationProfileError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Retrieves the business profile (name, email, phone, address, and external metadata) associated with this organization's customer record. Profiles can be shared across accounts and organizations. Only available to members of the organization. */
export declare const getOrganizationProfile: API.OperationMethod<GetOrganizationProfileRequest, GetOrganizationProfileResponse, GetOrganizationProfileError, CloudflareOpContext>;
export type ListLogAuditsError = CloudflareOpError;
/** Gets a list of audit logs for an organization. */
export declare const listLogAudits: API.PaginatedOperationMethod<ListLogAuditsRequest, ListLogAuditsResponse, ListLogAuditsError, CloudflareOpContext, LogsAuditListResultItem>;
export type ListMembersError = CloudflareOpError;
/** List memberships for an Organization. */
export declare const listMembers: API.OperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, CloudflareOpContext>;
export type ListOrganizationsError = Forbidden | CloudflareOpError;
/** Retrieve a list of organizations a particular user has access to. At most one of `containing.account`, `containing.user`, or `containing.organization` may be provided. */
export declare const listOrganizations: API.PaginatedOperationMethod<ListOrganizationsRequest, ListOrganizationsResponse, ListOrganizationsError, CloudflareOpContext, ListResultItem>;
export type LogsAuditHistoryError = CloudflareOpError;
/** Returns the chronological change history for the resource identified by the given organization-scoped audit log entry. The endpoint first locates the source audit log entry by `id` (using `action_time` to narrow the lookup window), derives identifying filters from that entry, and then returns matching audit logs within the `since`/`before` window. The `result_info.history_status` field indicates the quality of the resource identification used: - `exact`: Resource was identified by the resource URI. - `approximate`: Resource was identified without the resource URI. - `unavailable`: The source audit log entry did not contain enough information to identify the resource; an empty result is returned. */
export declare const logsAuditHistory: API.OperationMethod<LogsAuditHistoryRequest, LogsAuditHistoryResponse, LogsAuditHistoryError, CloudflareOpContext>;
export type PutOrganizationProfileError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Partially updates the business profile (name, email, phone, address, and external metadata) associated with this organization's customer record, creating the profile if it does not exist. Changes apply to every account and organization sharing that profile. Omitted, empty, or null fields are left unchanged. Each profile field is limited to 1,000 UTF-8 bytes. Only available to members of the organization. */
export declare const putOrganizationProfile: API.OperationMethod<PutOrganizationProfileRequest, PutOrganizationProfileResponse, PutOrganizationProfileError, CloudflareOpContext>;
export type UpdateOrganizationError = OrganizationNotFound | Forbidden | CloudflareOpError;
/** Update an organization's name. Supplying `parent_id` verifies the current parent; this endpoint cannot move an organization. Organization names are limited to 65 UTF-8 bytes. */
export declare const updateOrganization: API.OperationMethod<UpdateOrganizationRequest, UpdateOrganizationResponse, UpdateOrganizationError, CloudflareOpContext>;
//# sourceMappingURL=organizations.d.ts.map