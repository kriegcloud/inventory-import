import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const PreconditionFailedException_base: S.TaggedErrorClass<"PreconditionFailedException", {
    readonly message: any;
}>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const RequestTimeoutException_base: S.TaggedErrorClass<"RequestTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestTimeoutException extends /*@__PURE__*/ RequestTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type Name = string;
export type AssistantType = string;
export type Description = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type NonEmptyString = string;
export interface ServerSideEncryptionConfiguration {
    kmsKeyId?: string | undefined;
}
export interface CreateAssistantRequest {
    clientToken?: string | undefined;
    name: string;
    type: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
}
export type Uuid = string;
export type Arn = string;
export type AssistantStatus = string;
export type GenericArn = string;
export interface AssistantIntegrationConfiguration {
    topicIntegrationArn?: string | undefined;
}
export interface AssistantData {
    assistantId: string;
    assistantArn: string;
    name: string;
    type: string;
    status: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    integrationConfiguration?: AssistantIntegrationConfiguration | undefined;
}
export interface CreateAssistantResponse {
    assistant?: AssistantData | undefined;
}
export type UuidOrArn = string;
export type AssociationType = string;
export type AssistantAssociationInputData = {
    knowledgeBaseId: string;
};
export interface CreateAssistantAssociationRequest {
    assistantId: string;
    associationType: string;
    association: AssistantAssociationInputData;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface KnowledgeBaseAssociationData {
    knowledgeBaseId?: string | undefined;
    knowledgeBaseArn?: string | undefined;
}
export type AssistantAssociationOutputData = {
    knowledgeBaseAssociation: KnowledgeBaseAssociationData;
};
export interface AssistantAssociationData {
    assistantAssociationId: string;
    assistantAssociationArn: string;
    assistantId: string;
    assistantArn: string;
    associationType: string;
    associationData: AssistantAssociationOutputData;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateAssistantAssociationResponse {
    assistantAssociation?: AssistantAssociationData | undefined;
}
export type ContentTitle = string;
export type Uri = string;
export type ContentMetadata = {
    [key: string]: string | undefined;
};
export type UploadId = string;
export interface CreateContentRequest {
    knowledgeBaseId: string;
    name: string;
    title?: string | undefined;
    overrideLinkOutUri?: string | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    uploadId: string;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ContentType = string;
export type ContentStatus = string;
export type Url = string | redacted.Redacted<string>;
export interface ContentData {
    contentArn: string;
    contentId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    revisionId: string;
    title: string;
    contentType: string;
    status: string;
    metadata: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    linkOutUri?: string | undefined;
    url: string | redacted.Redacted<string>;
    urlExpiry: Date;
}
export interface CreateContentResponse {
    content?: ContentData | undefined;
}
export type KnowledgeBaseType = string;
export type ObjectFieldsList = string[];
export interface AppIntegrationsConfiguration {
    appIntegrationArn: string;
    objectFields?: string[] | undefined;
}
export type SourceConfiguration = {
    appIntegrations: AppIntegrationsConfiguration;
};
export interface RenderingConfiguration {
    templateUri?: string | undefined;
}
export interface CreateKnowledgeBaseRequest {
    clientToken?: string | undefined;
    name: string;
    knowledgeBaseType: string;
    sourceConfiguration?: SourceConfiguration | undefined;
    renderingConfiguration?: RenderingConfiguration | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type KnowledgeBaseStatus = string;
export interface KnowledgeBaseData {
    knowledgeBaseId: string;
    knowledgeBaseArn: string;
    name: string;
    knowledgeBaseType: string;
    status: string;
    lastContentModificationTime?: Date | undefined;
    sourceConfiguration?: SourceConfiguration | undefined;
    renderingConfiguration?: RenderingConfiguration | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateKnowledgeBaseResponse {
    knowledgeBase?: KnowledgeBaseData | undefined;
}
export type QuickResponseName = string;
export type QuickResponseContent = string | redacted.Redacted<string>;
export type QuickResponseDataProvider = {
    content: string | redacted.Redacted<string>;
};
export type QuickResponseType = string;
export type GroupingCriteria = string | redacted.Redacted<string>;
export type GroupingValue = string | redacted.Redacted<string>;
export type GroupingValues = (string | redacted.Redacted<string>)[];
export interface GroupingConfiguration {
    criteria?: string | redacted.Redacted<string> | undefined;
    values?: (string | redacted.Redacted<string>)[] | undefined;
}
export type QuickResponseDescription = string;
export type ShortCutKey = string;
export type Channel = string | redacted.Redacted<string>;
export type Channels = (string | redacted.Redacted<string>)[];
export type LanguageCode = string;
export interface CreateQuickResponseRequest {
    knowledgeBaseId: string;
    name: string;
    content: QuickResponseDataProvider;
    contentType?: string | undefined;
    groupingConfiguration?: GroupingConfiguration | undefined;
    description?: string | undefined;
    shortcutKey?: string | undefined;
    isActive?: boolean | undefined;
    channels?: (string | redacted.Redacted<string>)[] | undefined;
    language?: string | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type QuickResponseStatus = string;
export type QuickResponseContentProvider = {
    content: string | redacted.Redacted<string>;
};
export interface QuickResponseContents {
    plainText?: QuickResponseContentProvider | undefined;
    markdown?: QuickResponseContentProvider | undefined;
}
export interface QuickResponseData {
    quickResponseArn: string;
    quickResponseId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    contentType: string;
    status: string;
    createdTime: Date;
    lastModifiedTime: Date;
    contents?: QuickResponseContents | undefined;
    description?: string | undefined;
    groupingConfiguration?: GroupingConfiguration | undefined;
    shortcutKey?: string | undefined;
    lastModifiedBy?: string | undefined;
    isActive?: boolean | undefined;
    channels?: (string | redacted.Redacted<string>)[] | undefined;
    language?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateQuickResponseResponse {
    quickResponse?: QuickResponseData | undefined;
}
export interface CreateSessionRequest {
    clientToken?: string | undefined;
    assistantId: string;
    name: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface SessionIntegrationConfiguration {
    topicIntegrationArn?: string | undefined;
}
export interface SessionData {
    sessionArn: string;
    sessionId: string;
    name: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    integrationConfiguration?: SessionIntegrationConfiguration | undefined;
}
export interface CreateSessionResponse {
    session?: SessionData | undefined;
}
export interface DeleteAssistantRequest {
    assistantId: string;
}
export interface DeleteAssistantResponse {
}
export interface DeleteAssistantAssociationRequest {
    assistantAssociationId: string;
    assistantId: string;
}
export interface DeleteAssistantAssociationResponse {
}
export interface DeleteContentRequest {
    knowledgeBaseId: string;
    contentId: string;
}
export interface DeleteContentResponse {
}
export interface DeleteImportJobRequest {
    knowledgeBaseId: string;
    importJobId: string;
}
export interface DeleteImportJobResponse {
}
export interface DeleteKnowledgeBaseRequest {
    knowledgeBaseId: string;
}
export interface DeleteKnowledgeBaseResponse {
}
export interface DeleteQuickResponseRequest {
    knowledgeBaseId: string;
    quickResponseId: string;
}
export interface DeleteQuickResponseResponse {
}
export interface GetAssistantRequest {
    assistantId: string;
}
export interface GetAssistantResponse {
    assistant?: AssistantData | undefined;
}
export interface GetAssistantAssociationRequest {
    assistantAssociationId: string;
    assistantId: string;
}
export interface GetAssistantAssociationResponse {
    assistantAssociation?: AssistantAssociationData | undefined;
}
export interface GetContentRequest {
    contentId: string;
    knowledgeBaseId: string;
}
export interface GetContentResponse {
    content?: ContentData | undefined;
}
export interface GetContentSummaryRequest {
    contentId: string;
    knowledgeBaseId: string;
}
export interface ContentSummary {
    contentArn: string;
    contentId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    revisionId: string;
    title: string;
    contentType: string;
    status: string;
    metadata: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetContentSummaryResponse {
    contentSummary?: ContentSummary | undefined;
}
export interface GetImportJobRequest {
    importJobId: string;
    knowledgeBaseId: string;
}
export type ImportJobType = string;
export type ImportJobStatus = string;
export type ExternalSource = string;
export interface ConnectConfiguration {
    instanceId?: string | undefined;
}
export type Configuration = {
    connectConfiguration: ConnectConfiguration;
};
export interface ExternalSourceConfiguration {
    source: string;
    configuration: Configuration;
}
export interface ImportJobData {
    importJobId: string;
    knowledgeBaseId: string;
    uploadId: string;
    knowledgeBaseArn: string;
    importJobType: string;
    status: string;
    url: string | redacted.Redacted<string>;
    failedRecordReport?: string | redacted.Redacted<string> | undefined;
    urlExpiry: Date;
    createdTime: Date;
    lastModifiedTime: Date;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    externalSourceConfiguration?: ExternalSourceConfiguration | undefined;
}
export interface GetImportJobResponse {
    importJob?: ImportJobData | undefined;
}
export interface GetKnowledgeBaseRequest {
    knowledgeBaseId: string;
}
export interface GetKnowledgeBaseResponse {
    knowledgeBase?: KnowledgeBaseData | undefined;
}
export interface GetQuickResponseRequest {
    quickResponseId: string;
    knowledgeBaseId: string;
}
export interface GetQuickResponseResponse {
    quickResponse?: QuickResponseData | undefined;
}
export type MaxResults = number;
export type WaitTimeSeconds = number;
export interface GetRecommendationsRequest {
    assistantId: string;
    sessionId: string;
    maxResults?: number | undefined;
    waitTimeSeconds?: number | undefined;
}
export interface ContentReference {
    knowledgeBaseArn?: string | undefined;
    knowledgeBaseId?: string | undefined;
    contentArn?: string | undefined;
    contentId?: string | undefined;
}
export type SensitiveString = string | redacted.Redacted<string>;
export type HighlightOffset = number;
export interface Highlight {
    beginOffsetInclusive?: number | undefined;
    endOffsetExclusive?: number | undefined;
}
export type Highlights = Highlight[];
export interface DocumentText {
    text?: string | redacted.Redacted<string> | undefined;
    highlights?: Highlight[] | undefined;
}
export interface Document {
    contentReference: ContentReference;
    title?: DocumentText | undefined;
    excerpt?: DocumentText | undefined;
}
export type RelevanceScore = number;
export type RelevanceLevel = string;
export type RecommendationType = string;
export interface RecommendationData {
    recommendationId: string;
    document: Document;
    relevanceScore?: number | undefined;
    relevanceLevel?: string | undefined;
    type?: string | undefined;
}
export type RecommendationList = RecommendationData[];
export type RecommendationTriggerType = string;
export type RecommendationSourceType = string;
export type QueryText = string | redacted.Redacted<string>;
export interface QueryRecommendationTriggerData {
    text?: string | redacted.Redacted<string> | undefined;
}
export type RecommendationTriggerData = {
    query: QueryRecommendationTriggerData;
};
export type RecommendationIdList = string[];
export interface RecommendationTrigger {
    id: string;
    type: string;
    source: string;
    data: RecommendationTriggerData;
    recommendationIds: string[];
}
export type RecommendationTriggerList = RecommendationTrigger[];
export interface GetRecommendationsResponse {
    recommendations: RecommendationData[];
    triggers?: RecommendationTrigger[] | undefined;
}
export interface GetSessionRequest {
    assistantId: string;
    sessionId: string;
}
export interface GetSessionResponse {
    session?: SessionData | undefined;
}
export type NextToken = string;
export interface ListAssistantAssociationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    assistantId: string;
}
export interface AssistantAssociationSummary {
    assistantAssociationId: string;
    assistantAssociationArn: string;
    assistantId: string;
    assistantArn: string;
    associationType: string;
    associationData: AssistantAssociationOutputData;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AssistantAssociationSummaryList = AssistantAssociationSummary[];
export interface ListAssistantAssociationsResponse {
    assistantAssociationSummaries: AssistantAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListAssistantsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AssistantSummary {
    assistantId: string;
    assistantArn: string;
    name: string;
    type: string;
    status: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    integrationConfiguration?: AssistantIntegrationConfiguration | undefined;
}
export type AssistantList = AssistantSummary[];
export interface ListAssistantsResponse {
    assistantSummaries: AssistantSummary[];
    nextToken?: string | undefined;
}
export interface ListContentsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    knowledgeBaseId: string;
}
export type ContentSummaryList = ContentSummary[];
export interface ListContentsResponse {
    contentSummaries: ContentSummary[];
    nextToken?: string | undefined;
}
export interface ListImportJobsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    knowledgeBaseId: string;
}
export interface ImportJobSummary {
    importJobId: string;
    knowledgeBaseId: string;
    uploadId: string;
    knowledgeBaseArn: string;
    importJobType: string;
    status: string;
    createdTime: Date;
    lastModifiedTime: Date;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    externalSourceConfiguration?: ExternalSourceConfiguration | undefined;
}
export type ImportJobList = ImportJobSummary[];
export interface ListImportJobsResponse {
    importJobSummaries: ImportJobSummary[];
    nextToken?: string | undefined;
}
export interface ListKnowledgeBasesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface KnowledgeBaseSummary {
    knowledgeBaseId: string;
    knowledgeBaseArn: string;
    name: string;
    knowledgeBaseType: string;
    status: string;
    sourceConfiguration?: SourceConfiguration | undefined;
    renderingConfiguration?: RenderingConfiguration | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type KnowledgeBaseList = KnowledgeBaseSummary[];
export interface ListKnowledgeBasesResponse {
    knowledgeBaseSummaries: KnowledgeBaseSummary[];
    nextToken?: string | undefined;
}
export interface ListQuickResponsesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    knowledgeBaseId: string;
}
export interface QuickResponseSummary {
    quickResponseArn: string;
    quickResponseId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    contentType: string;
    status: string;
    createdTime: Date;
    lastModifiedTime: Date;
    description?: string | undefined;
    lastModifiedBy?: string | undefined;
    isActive?: boolean | undefined;
    channels?: (string | redacted.Redacted<string>)[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type QuickResponseSummaryList = QuickResponseSummary[];
export interface ListQuickResponsesResponse {
    quickResponseSummaries: QuickResponseSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface NotifyRecommendationsReceivedRequest {
    assistantId: string;
    sessionId: string;
    recommendationIds: string[];
}
export type NotifyRecommendationsReceivedErrorMessage = string;
export interface NotifyRecommendationsReceivedError_ {
    recommendationId?: string | undefined;
    message?: string | undefined;
}
export type NotifyRecommendationsReceivedErrorList = NotifyRecommendationsReceivedError_[];
export interface NotifyRecommendationsReceivedResponse {
    recommendationIds?: string[] | undefined;
    errors?: NotifyRecommendationsReceivedError_[] | undefined;
}
export interface QueryAssistantRequest {
    assistantId: string;
    queryText: string | redacted.Redacted<string>;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ResultData {
    resultId: string;
    document: Document;
    relevanceScore?: number | undefined;
}
export type QueryResultsList = ResultData[];
export interface QueryAssistantResponse {
    results: ResultData[];
    nextToken?: string | undefined;
}
export interface RemoveKnowledgeBaseTemplateUriRequest {
    knowledgeBaseId: string;
}
export interface RemoveKnowledgeBaseTemplateUriResponse {
}
export type FilterField = string;
export type FilterOperator = string;
export interface Filter {
    field: string;
    operator: string;
    value: string;
}
export type FilterList = Filter[];
export interface SearchExpression {
    filters: Filter[];
}
export interface SearchContentRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    knowledgeBaseId: string;
    searchExpression: SearchExpression;
}
export interface SearchContentResponse {
    contentSummaries: ContentSummary[];
    nextToken?: string | undefined;
}
export type QuickResponseQueryValue = string;
export type QuickResponseQueryValueList = string[];
export type QuickResponseQueryOperator = string;
export type Priority = string;
export interface QuickResponseQueryField {
    name: string;
    values: string[];
    operator: string;
    allowFuzziness?: boolean | undefined;
    priority?: string | undefined;
}
export type QuickResponseQueryFieldList = QuickResponseQueryField[];
export type QuickResponseFilterValue = string;
export type QuickResponseFilterValueList = string[];
export type QuickResponseFilterOperator = string;
export interface QuickResponseFilterField {
    name: string;
    values?: string[] | undefined;
    operator: string;
    includeNoExistence?: boolean | undefined;
}
export type QuickResponseFilterFieldList = QuickResponseFilterField[];
export type Order = string;
export interface QuickResponseOrderField {
    name: string;
    order?: string | undefined;
}
export interface QuickResponseSearchExpression {
    queries?: QuickResponseQueryField[] | undefined;
    filters?: QuickResponseFilterField[] | undefined;
    orderOnField?: QuickResponseOrderField | undefined;
}
export type ContactAttributeKey = string;
export type ContactAttributeValue = string;
export type ContactAttributes = {
    [key: string]: string | undefined;
};
export interface SearchQuickResponsesRequest {
    knowledgeBaseId: string;
    searchExpression: QuickResponseSearchExpression;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ContactAttributeKeys = string[];
export interface QuickResponseSearchResultData {
    quickResponseArn: string;
    quickResponseId: string;
    knowledgeBaseArn: string;
    knowledgeBaseId: string;
    name: string;
    contentType: string;
    status: string;
    contents: QuickResponseContents;
    createdTime: Date;
    lastModifiedTime: Date;
    isActive: boolean;
    description?: string | undefined;
    groupingConfiguration?: GroupingConfiguration | undefined;
    shortcutKey?: string | undefined;
    lastModifiedBy?: string | undefined;
    channels?: (string | redacted.Redacted<string>)[] | undefined;
    language?: string | undefined;
    attributesNotInterpolated?: string[] | undefined;
    attributesInterpolated?: string[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type QuickResponseSearchResultsList = QuickResponseSearchResultData[];
export interface SearchQuickResponsesResponse {
    results: QuickResponseSearchResultData[];
    nextToken?: string | undefined;
}
export interface SearchSessionsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    assistantId: string;
    searchExpression: SearchExpression;
}
export interface SessionSummary {
    sessionId: string;
    sessionArn: string;
    assistantId: string;
    assistantArn: string;
}
export type SessionSummaries = SessionSummary[];
export interface SearchSessionsResponse {
    sessionSummaries: SessionSummary[];
    nextToken?: string | undefined;
}
export type TimeToLive = number;
export interface StartContentUploadRequest {
    knowledgeBaseId: string;
    contentType: string;
    presignedUrlTimeToLive?: number | undefined;
}
export type Headers = {
    [key: string]: string | undefined;
};
export interface StartContentUploadResponse {
    uploadId: string;
    url: string | redacted.Redacted<string>;
    urlExpiry: Date;
    headersToInclude: {
        [key: string]: string | undefined;
    };
}
export interface StartImportJobRequest {
    knowledgeBaseId: string;
    importJobType: string;
    uploadId: string;
    clientToken?: string | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    externalSourceConfiguration?: ExternalSourceConfiguration | undefined;
}
export interface StartImportJobResponse {
    importJob?: ImportJobData | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateContentRequest {
    knowledgeBaseId: string;
    contentId: string;
    revisionId?: string | undefined;
    title?: string | undefined;
    overrideLinkOutUri?: string | undefined;
    removeOverrideLinkOutUri?: boolean | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    uploadId?: string | undefined;
}
export interface UpdateContentResponse {
    content?: ContentData | undefined;
}
export interface UpdateKnowledgeBaseTemplateUriRequest {
    knowledgeBaseId: string;
    templateUri: string;
}
export interface UpdateKnowledgeBaseTemplateUriResponse {
    knowledgeBase?: KnowledgeBaseData | undefined;
}
export interface UpdateQuickResponseRequest {
    knowledgeBaseId: string;
    quickResponseId: string;
    name?: string | undefined;
    content?: QuickResponseDataProvider | undefined;
    contentType?: string | undefined;
    groupingConfiguration?: GroupingConfiguration | undefined;
    removeGroupingConfiguration?: boolean | undefined;
    description?: string | undefined;
    removeDescription?: boolean | undefined;
    shortcutKey?: string | undefined;
    removeShortcutKey?: boolean | undefined;
    isActive?: boolean | undefined;
    channels?: (string | redacted.Redacted<string>)[] | undefined;
    language?: string | undefined;
}
export interface UpdateQuickResponseResponse {
    quickResponse?: QuickResponseData | undefined;
}
export type CreateAssistantError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Connect Wisdom assistant.
 */
export declare const createAssistant: API.OperationMethod<CreateAssistantRequest & RegionInput, CreateAssistantResponse, CreateAssistantError, Credentials | HttpClient.HttpClient>;
export type CreateAssistantAssociationError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an association between an Amazon Connect Wisdom assistant and another resource. Currently, the
 * only supported association is with a knowledge base. An assistant can have only a single
 * association.
 */
export declare const createAssistantAssociation: API.OperationMethod<CreateAssistantAssociationRequest & RegionInput, CreateAssistantAssociationResponse, CreateAssistantAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateContentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates Wisdom content. Before to calling this API, use StartContentUpload to
 * upload an asset.
 */
export declare const createContent: API.OperationMethod<CreateContentRequest & RegionInput, CreateContentResponse, CreateContentError, Credentials | HttpClient.HttpClient>;
export type CreateKnowledgeBaseError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a knowledge base.
 *
 * When using this API, you cannot reuse Amazon AppIntegrations
 * DataIntegrations with external knowledge bases such as Salesforce and ServiceNow. If you do,
 * you'll get an `InvalidRequestException` error.
 *
 * For example, you're programmatically managing your external knowledge base, and you want
 * to add or remove one of the fields that is being ingested from Salesforce. Do the
 * following:
 *
 * - Call DeleteKnowledgeBase.
 *
 * - Call DeleteDataIntegration.
 *
 * - Call CreateDataIntegration to recreate the DataIntegration or a create different
 * one.
 *
 * - Call CreateKnowledgeBase.
 */
export declare const createKnowledgeBase: API.OperationMethod<CreateKnowledgeBaseRequest & RegionInput, CreateKnowledgeBaseResponse, CreateKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type CreateQuickResponseError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a Wisdom quick response.
 */
export declare const createQuickResponse: API.OperationMethod<CreateQuickResponseRequest & RegionInput, CreateQuickResponseResponse, CreateQuickResponseError, Credentials | HttpClient.HttpClient>;
export type CreateSessionError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a session. A session is a contextual container used for generating
 * recommendations. Amazon Connect creates a new Wisdom session for each contact on which
 * Wisdom is enabled.
 */
export declare const createSession: API.OperationMethod<CreateSessionRequest & RegionInput, CreateSessionResponse, CreateSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteAssistantError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an assistant.
 */
export declare const deleteAssistant: API.OperationMethod<DeleteAssistantRequest & RegionInput, DeleteAssistantResponse, DeleteAssistantError, Credentials | HttpClient.HttpClient>;
export type DeleteAssistantAssociationError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an assistant association.
 */
export declare const deleteAssistantAssociation: API.OperationMethod<DeleteAssistantAssociationRequest & RegionInput, DeleteAssistantAssociationResponse, DeleteAssistantAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteContentError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the content.
 */
export declare const deleteContent: API.OperationMethod<DeleteContentRequest & RegionInput, DeleteContentResponse, DeleteContentError, Credentials | HttpClient.HttpClient>;
export type DeleteImportJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the quick response import job.
 */
export declare const deleteImportJob: API.OperationMethod<DeleteImportJobRequest & RegionInput, DeleteImportJobResponse, DeleteImportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteKnowledgeBaseError = AccessDeniedException | ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the knowledge base.
 *
 * When you use this API to delete an external knowledge base such as Salesforce or
 * ServiceNow, you must also delete the Amazon AppIntegrations
 * DataIntegration. This is because you can't reuse the DataIntegration after it's been
 * associated with an external knowledge base. However, you can delete and recreate it. See
 * DeleteDataIntegration and CreateDataIntegration in the Amazon AppIntegrations API
 * Reference.
 */
export declare const deleteKnowledgeBase: API.OperationMethod<DeleteKnowledgeBaseRequest & RegionInput, DeleteKnowledgeBaseResponse, DeleteKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type DeleteQuickResponseError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a quick response.
 */
export declare const deleteQuickResponse: API.OperationMethod<DeleteQuickResponseRequest & RegionInput, DeleteQuickResponseResponse, DeleteQuickResponseError, Credentials | HttpClient.HttpClient>;
export type GetAssistantError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about an assistant.
 */
export declare const getAssistant: API.OperationMethod<GetAssistantRequest & RegionInput, GetAssistantResponse, GetAssistantError, Credentials | HttpClient.HttpClient>;
export type GetAssistantAssociationError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about an assistant association.
 */
export declare const getAssistantAssociation: API.OperationMethod<GetAssistantAssociationRequest & RegionInput, GetAssistantAssociationResponse, GetAssistantAssociationError, Credentials | HttpClient.HttpClient>;
export type GetContentError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves content, including a pre-signed URL to download the content.
 */
export declare const getContent: API.OperationMethod<GetContentRequest & RegionInput, GetContentResponse, GetContentError, Credentials | HttpClient.HttpClient>;
export type GetContentSummaryError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves summary information about the content.
 */
export declare const getContentSummary: API.OperationMethod<GetContentSummaryRequest & RegionInput, GetContentSummaryResponse, GetContentSummaryError, Credentials | HttpClient.HttpClient>;
export type GetImportJobError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the started import job.
 */
export declare const getImportJob: API.OperationMethod<GetImportJobRequest & RegionInput, GetImportJobResponse, GetImportJobError, Credentials | HttpClient.HttpClient>;
export type GetKnowledgeBaseError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about the knowledge base.
 */
export declare const getKnowledgeBase: API.OperationMethod<GetKnowledgeBaseRequest & RegionInput, GetKnowledgeBaseResponse, GetKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type GetQuickResponseError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the quick response.
 */
export declare const getQuickResponse: API.OperationMethod<GetQuickResponseRequest & RegionInput, GetQuickResponseResponse, GetQuickResponseError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves recommendations for the specified session. To avoid retrieving the same
 * recommendations in subsequent calls, use NotifyRecommendationsReceived. This API supports long-polling behavior with the
 * `waitTimeSeconds` parameter. Short poll is the default behavior and only returns
 * recommendations already available. To perform a manual query against an assistant, use QueryAssistant.
 */
export declare const getRecommendations: API.OperationMethod<GetRecommendationsRequest & RegionInput, GetRecommendationsResponse, GetRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information for a specified session.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest & RegionInput, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type ListAssistantAssociationsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists information about assistant associations.
 */
export declare const listAssistantAssociations: API.PaginatedOperationMethod<ListAssistantAssociationsRequest & RegionInput, ListAssistantAssociationsResponse, ListAssistantAssociationsError, Credentials | HttpClient.HttpClient, AssistantAssociationSummary>;
export type ListAssistantsError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists information about assistants.
 */
export declare const listAssistants: API.PaginatedOperationMethod<ListAssistantsRequest & RegionInput, ListAssistantsResponse, ListAssistantsError, Credentials | HttpClient.HttpClient, AssistantSummary>;
export type ListContentsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the content.
 */
export declare const listContents: API.PaginatedOperationMethod<ListContentsRequest & RegionInput, ListContentsResponse, ListContentsError, Credentials | HttpClient.HttpClient, ContentSummary>;
export type ListImportJobsError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists information about import jobs.
 */
export declare const listImportJobs: API.PaginatedOperationMethod<ListImportJobsRequest & RegionInput, ListImportJobsResponse, ListImportJobsError, Credentials | HttpClient.HttpClient, ImportJobSummary>;
export type ListKnowledgeBasesError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Lists the knowledge bases.
 */
export declare const listKnowledgeBases: API.PaginatedOperationMethod<ListKnowledgeBasesRequest & RegionInput, ListKnowledgeBasesResponse, ListKnowledgeBasesError, Credentials | HttpClient.HttpClient, KnowledgeBaseSummary>;
export type ListQuickResponsesError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists information about quick response.
 */
export declare const listQuickResponses: API.PaginatedOperationMethod<ListQuickResponsesRequest & RegionInput, ListQuickResponsesResponse, ListQuickResponsesError, Credentials | HttpClient.HttpClient, QuickResponseSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type NotifyRecommendationsReceivedError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified recommendations from the specified assistant's queue of newly
 * available recommendations. You can use this API in conjunction with GetRecommendations and a `waitTimeSeconds` input for long-polling
 * behavior and avoiding duplicate recommendations.
 */
export declare const notifyRecommendationsReceived: API.OperationMethod<NotifyRecommendationsReceivedRequest & RegionInput, NotifyRecommendationsReceivedResponse, NotifyRecommendationsReceivedError, Credentials | HttpClient.HttpClient>;
export type QueryAssistantError = AccessDeniedException | RequestTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Performs a manual search against the specified assistant. To retrieve recommendations for
 * an assistant, use GetRecommendations.
 */
export declare const queryAssistant: API.PaginatedOperationMethod<QueryAssistantRequest & RegionInput, QueryAssistantResponse, QueryAssistantError, Credentials | HttpClient.HttpClient, ResultData>;
export type RemoveKnowledgeBaseTemplateUriError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a URI template from a knowledge base.
 */
export declare const removeKnowledgeBaseTemplateUri: API.OperationMethod<RemoveKnowledgeBaseTemplateUriRequest & RegionInput, RemoveKnowledgeBaseTemplateUriResponse, RemoveKnowledgeBaseTemplateUriError, Credentials | HttpClient.HttpClient>;
export type SearchContentError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Searches for content in a specified knowledge base. Can be used to get a specific content
 * resource by its name.
 */
export declare const searchContent: API.PaginatedOperationMethod<SearchContentRequest & RegionInput, SearchContentResponse, SearchContentError, Credentials | HttpClient.HttpClient, ContentSummary>;
export type SearchQuickResponsesError = AccessDeniedException | RequestTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Searches existing Wisdom quick responses in a Wisdom knowledge base.
 */
export declare const searchQuickResponses: API.PaginatedOperationMethod<SearchQuickResponsesRequest & RegionInput, SearchQuickResponsesResponse, SearchQuickResponsesError, Credentials | HttpClient.HttpClient, QuickResponseSearchResultData>;
export type SearchSessionsError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Searches for sessions.
 */
export declare const searchSessions: API.PaginatedOperationMethod<SearchSessionsRequest & RegionInput, SearchSessionsResponse, SearchSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type StartContentUploadError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get a URL to upload content to a knowledge base. To upload content, first make a PUT
 * request to the returned URL with your file, making sure to include the required headers. Then
 * use CreateContent to finalize the content creation process or UpdateContent to modify an existing resource. You can only upload content to a
 * knowledge base of type CUSTOM.
 */
export declare const startContentUpload: API.OperationMethod<StartContentUploadRequest & RegionInput, StartContentUploadResponse, StartContentUploadError, Credentials | HttpClient.HttpClient>;
export type StartImportJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Start an asynchronous job to import Wisdom resources from an uploaded source file. Before calling this API, use StartContentUpload to
 * upload an asset that contains the resource data.
 *
 * - For importing Wisdom quick responses, you need to upload a csv file including the quick responses. For information about how to format the csv file for importing quick responses, see Import quick responses.
 */
export declare const startImportJob: API.OperationMethod<StartImportJobRequest & RegionInput, StartImportJobResponse, StartImportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateContentError = AccessDeniedException | PreconditionFailedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates information about the content.
 */
export declare const updateContent: API.OperationMethod<UpdateContentRequest & RegionInput, UpdateContentResponse, UpdateContentError, Credentials | HttpClient.HttpClient>;
export type UpdateKnowledgeBaseTemplateUriError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the template URI of a knowledge base. This is only supported for knowledge bases
 * of type EXTERNAL. Include a single variable in `${variable}` format; this
 * interpolated by Wisdom using ingested content. For example, if you ingest a Salesforce
 * article, it has an `Id` value, and you can set the template URI to
 * `https://myInstanceName.lightning.force.com/lightning/r/Knowledge__kav/*${Id}*\/view`.
 */
export declare const updateKnowledgeBaseTemplateUri: API.OperationMethod<UpdateKnowledgeBaseTemplateUriRequest & RegionInput, UpdateKnowledgeBaseTemplateUriResponse, UpdateKnowledgeBaseTemplateUriError, Credentials | HttpClient.HttpClient>;
export type UpdateQuickResponseError = AccessDeniedException | ConflictException | PreconditionFailedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing Wisdom quick response.
 */
export declare const updateQuickResponse: API.OperationMethod<UpdateQuickResponseRequest & RegionInput, UpdateQuickResponseResponse, UpdateQuickResponseError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=wisdom.d.ts.map