/**
 * The dialects a SQL script can be split for. `sqlite` is split by
 * `splitSqliteStatements` (in `SqlFile.ts`), which also understands trigger
 * bodies.
 */
export type ScriptDialect = "postgres" | "mysql" | "googlesql";
/** One statement of a script, without its terminating `;`. */
export interface ScannedStatement {
    /**
     * The statement's exact source slice, comments and surrounding whitespace
     * included, so offsets into `code` index it directly.
     */
    readonly sql: string;
    /** The statement with comments removed: what to send to the database. */
    readonly text: string;
    /**
     * `sql` with comments blanked and every string, quoted identifier, and
     * dollar-quoted body masked to `_` plus spaces. Offsets match `sql`, so a
     * keyword found in `code` can be sliced out of `sql`.
     */
    readonly code: string;
    /** A comment or quoted span that never closed before the end of the script. */
    readonly unterminated?: "comment" | "quote";
}
/**
 * Split a SQL script into statements on top-level `;`. Semicolons inside
 * strings, quoted identifiers, dollar-quoted bodies, and comments never
 * split, and each dialect's quoting and comment rules apply. Empty
 * statements are dropped.
 *
 * This is a lexer, not a parser: it does not understand statement bodies
 * that contain their own `;` outside quotes (procedural blocks), which
 * migrations for these engines don't use.
 */
export declare const scanSqlScript: (sql: string, dialect: ScriptDialect) => ReadonlyArray<ScannedStatement>;
/** Statements of a SQL script with comments removed; see {@link scanSqlScript}. */
export declare const splitSqlScript: (sql: string, dialect: ScriptDialect) => string[];
//# sourceMappingURL=Script.d.ts.map