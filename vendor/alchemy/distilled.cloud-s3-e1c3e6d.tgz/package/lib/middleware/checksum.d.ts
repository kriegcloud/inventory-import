import { InvalidInput } from "@distilled.cloud/core/protocol-http";
import * as Effect from "effect/Effect";
import type * as S from "effect/Schema";
import * as Stream from "effect/Stream";
import type { Request as ProtocolRequest } from "../client/request.ts";
import type { Checksum } from "../hash/checksum.ts";
import { type StreamBody } from "../util/stream.ts";
export type SourceData = string | ArrayBuffer | ArrayBufferView;
export interface ChecksumConstructor {
    new (secret?: SourceData): Checksum;
}
/** The checksum of a buffered body. */
export declare const stringHasher: (checksumAlgorithmFn: ChecksumConstructor, body: string | Uint8Array) => Uint8Array;
/**
 * Apply checksum to a protocol Request based on schema annotations.
 * Uses the aws.protocols#httpChecksum trait to determine checksum requirements.
 *
 * For streaming bodies, uses aws-chunked encoding with trailing checksum.
 * For non-streaming bodies, computes checksum directly and adds header.
 *
 * @param schema - The request schema with checksum annotations
 * @param request - The protocol request to add checksum to
 * @returns Effect that produces the request with checksum header added
 */
export declare const applyHttpChecksum: (schema: S.Top, request: ProtocolRequest) => Effect.Effect<ProtocolRequest, InvalidInput>;
/**
 * Create an aws-chunked encoded stream with trailing checksum, its chunks
 * joined to S3's 8KB minimum. It runs in the fiber that sends the request,
 * with a fresh hash each run (a retried request re-runs it).
 * Format: <chunk-size-hex>\r\n<chunk-data>\r\n...0\r\n<trailer>\r\n\r\n
 *
 * @see https://docs.aws.amazon.com/AmazonS3/latest/API/sigv4-streaming.html
 */
export declare const createAwsChunkedStream: (source: StreamBody, checksumAlgorithmFn: ChecksumConstructor, checksumLocationName: string) => Stream.Stream<Uint8Array, unknown>;
//# sourceMappingURL=checksum.d.ts.map