import type * as Cause from "effect/Cause";
import * as Effect from "effect/Effect";
import { HttpServerRequest } from "effect/http/HttpServerRequest";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
import * as ChildProcessSpawner from "effect/process/ChildProcessSpawner";
import * as Scope from "effect/Scope";
import { HttpServer, type HttpEffect } from "./Http.ts";
import { SandboxSpawnError } from "./SandboxAgentClient.ts";
/**
 * The server half of the sandbox agent. A program that serves it answers the
 * `sandbox.*` methods of `alchemy/SandboxAgentClient` next to its own RPC
 * methods: it runs commands, streams processes, reads and writes files and
 * opens terminals inside the machine it runs on.
 *
 * Every RPC call needs the sandbox's bearer token. The program's own `fetch`
 * routes are not gated.
 */
/** How a sandbox agent is started. */
export interface SandboxAgentConfig {
    /** Bearer token every RPC call must carry. */
    readonly token: string;
    /**
     * Exit the process when nothing has called the sandbox for this long, in
     * milliseconds. A request in flight or an attached output stream keeps it
     * alive.
     */
    readonly idleTimeoutMs?: number;
}
/**
 * Wraps a program's HTTP handler with the sandbox agent: RPC calls reach the
 * program's own methods (`shape`) and the agent's `sandbox.*` methods, and
 * need the sandbox's bearer token. Everything else goes to `fallback`, the
 * program's `fetch`.
 */
export declare const serveSandboxAgent: <Req = never>(config: SandboxAgentConfig, shape: Record<string, unknown>, fallback: HttpEffect<Req>) => Effect.Effect<Effect.Effect<HttpServerResponse.HttpServerResponse, import("effect/http/HttpBody").HttpBodyError | import("effect/http/HttpServerError").HttpServerError, Req | HttpServerRequest | Scope.Scope>, never, never>;
declare const SandboxAgentNotStarted_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "SandboxAgentNotStarted";
} & Readonly<A>;
/** The agent was started with no sandbox token and no command to run in its place. */
export declare class SandboxAgentNotStarted extends SandboxAgentNotStarted_base<{
    readonly message: string;
}> {
}
/**
 * Runs the sandbox agent as a container's first process, for an image that
 * has no program of its own. It serves the `sandbox.*` methods on the port in
 * `ALCHEMY_SANDBOX_PORT`, and starts `command`, when one is given, as a child
 * that shares the container's output.
 *
 * A container started without a sandbox token is not a sandbox: it runs
 * `command` and exits with its code, as the image would without the agent.
 */
export declare const runSandboxAgent: (command: readonly string[]) => Effect.Effect<never, SandboxAgentNotStarted | SandboxSpawnError, ChildProcessSpawner.ChildProcessSpawner | HttpServer | Scope.Scope>;
export {};
//# sourceMappingURL=SandboxAgent.d.ts.map