import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the commit comment. */
export type CreateForCommitCommentRequestContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
export interface CreateForCommitCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the commit comment. */
    content: CreateForCommitCommentRequestContent | (string & {});
}
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** The reaction to use */
export type ReactionContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
/** Reactions to conversations provide a way to help people express their feelings more simply and effectively. */
export interface Reaction {
    id: number;
    node_id: string;
    user: NullableSimpleUser | null;
    /** The reaction to use */
    content: ReactionContent;
    created_at: string;
}
/** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the issue. */
export type CreateForIssueRequestContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
export interface CreateForIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the issue. */
    content: CreateForIssueRequestContent | (string & {});
}
/** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the issue comment. */
export type CreateForIssueCommentRequestContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
export interface CreateForIssueCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the issue comment. */
    content: CreateForIssueCommentRequestContent | (string & {});
}
/** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the pull request review comment. */
export type CreateForPullRequestReviewCommentRequestContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
export interface CreateForPullRequestReviewCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the pull request review comment. */
    content: CreateForPullRequestReviewCommentRequestContent | (string & {});
}
/** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the release. */
export type CreateForReleaseRequestContent = "+1" | "laugh" | "heart" | "hooray" | "rocket" | "eyes";
export interface CreateForReleaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the release. */
    release_id: number;
    /** The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the release. */
    content: CreateForReleaseRequestContent | (string & {});
}
export interface DeleteForCommitCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The unique identifier of the reaction. */
    reaction_id: number;
}
export interface DeleteForCommitCommentResponse {
}
export interface DeleteForIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The unique identifier of the reaction. */
    reaction_id: number;
}
export interface DeleteForIssueResponse {
}
export interface DeleteForIssueCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The unique identifier of the reaction. */
    reaction_id: number;
}
export interface DeleteForIssueCommentResponse {
}
export interface DeleteForPullRequestCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The unique identifier of the reaction. */
    reaction_id: number;
}
export interface DeleteForPullRequestCommentResponse {
}
export interface DeleteForReleaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the release. */
    release_id: number;
    /** The unique identifier of the reaction. */
    reaction_id: number;
}
export interface DeleteForReleaseResponse {
}
export type ListForCommitCommentRequestContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
export interface ListForCommitCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to a commit comment. */
    content?: ListForCommitCommentRequestContent | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForCommitCommentResponseBodyList = Array<Reaction>;
export type ListForCommitCommentResponse = ListForCommitCommentResponseBodyList;
export type ListForIssueRequestContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
export interface ListForIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to an issue. */
    content?: ListForIssueRequestContent | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForIssueResponseBodyList = Array<Reaction>;
export type ListForIssueResponse = ListForIssueResponseBodyList;
export type ListForIssueCommentRequestContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
export interface ListForIssueCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to an issue comment. */
    content?: ListForIssueCommentRequestContent | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForIssueCommentResponseBodyList = Array<Reaction>;
export type ListForIssueCommentResponse = ListForIssueCommentResponseBodyList;
export type ListForPullRequestReviewCommentRequestContent = "+1" | "-1" | "laugh" | "confused" | "heart" | "hooray" | "rocket" | "eyes";
export interface ListForPullRequestReviewCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to a pull request review comment. */
    content?: ListForPullRequestReviewCommentRequestContent | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForPullRequestReviewCommentResponseBodyList = Array<Reaction>;
export type ListForPullRequestReviewCommentResponse = ListForPullRequestReviewCommentResponseBodyList;
export type ListForReleaseRequestContent = "+1" | "laugh" | "heart" | "hooray" | "rocket" | "eyes";
export interface ListForReleaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the release. */
    release_id: number;
    /** Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to a release. */
    content?: ListForReleaseRequestContent | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForReleaseResponseBodyList = Array<Reaction>;
export type ListForReleaseResponse = ListForReleaseResponseBodyList;
export type CreateForCommitCommentError = GithubOpError;
/** Create reaction for a commit comment Create a reaction to a [commit comment](https://docs.github.com/rest/commits/comments#get-a-commit-comment). A response with an HTTP `200` status means that you already added the reaction type to this commit comment. */
export declare const createForCommitComment: API.OperationMethod<CreateForCommitCommentRequest, Reaction, CreateForCommitCommentError, GithubOpContext>;
export type CreateForIssueError = GithubOpError;
/** Create reaction for an issue Create a reaction to an [issue](https://docs.github.com/rest/issues/issues#get-an-issue). A response with an HTTP `200` status means that you already added the reaction type to this issue. */
export declare const createForIssue: API.OperationMethod<CreateForIssueRequest, Reaction, CreateForIssueError, GithubOpContext>;
export type CreateForIssueCommentError = GithubOpError;
/** Create reaction for an issue comment Create a reaction to an [issue comment](https://docs.github.com/rest/issues/comments#get-an-issue-comment). A response with an HTTP `200` status means that you already added the reaction type to this issue comment. */
export declare const createForIssueComment: API.OperationMethod<CreateForIssueCommentRequest, Reaction, CreateForIssueCommentError, GithubOpContext>;
export type CreateForPullRequestReviewCommentError = GithubOpError;
/** Create reaction for a pull request review comment Create a reaction to a [pull request review comment](https://docs.github.com/rest/pulls/comments#get-a-review-comment-for-a-pull-request). A response with an HTTP `200` status means that you already added the reaction type to this pull request review comment. */
export declare const createForPullRequestReviewComment: API.OperationMethod<CreateForPullRequestReviewCommentRequest, Reaction, CreateForPullRequestReviewCommentError, GithubOpContext>;
export type CreateForReleaseError = GithubOpError;
/** Create reaction for a release Create a reaction to a [release](https://docs.github.com/rest/releases/releases#get-a-release). A response with a `Status: 200 OK` means that you already added the reaction type to this release. */
export declare const createForRelease: API.OperationMethod<CreateForReleaseRequest, Reaction, CreateForReleaseError, GithubOpContext>;
export type DeleteForCommitCommentError = GithubOpError;
/** Delete a commit comment reaction > [!NOTE] > You can also specify a repository by `repository_id` using the route `DELETE /repositories/:repository_id/comments/:comment_id/reactions/:reaction_id`. Delete a reaction to a [commit comment](https://docs.github.com/rest/commits/comments#get-a-commit-comment). */
export declare const deleteForCommitComment: API.OperationMethod<DeleteForCommitCommentRequest, DeleteForCommitCommentResponse, DeleteForCommitCommentError, GithubOpContext>;
export type DeleteForIssueError = GithubOpError;
/** Delete an issue reaction > [!NOTE] > You can also specify a repository by `repository_id` using the route `DELETE /repositories/:repository_id/issues/:issue_number/reactions/:reaction_id`. Delete a reaction to an [issue](https://docs.github.com/rest/issues/issues#get-an-issue). */
export declare const deleteForIssue: API.OperationMethod<DeleteForIssueRequest, DeleteForIssueResponse, DeleteForIssueError, GithubOpContext>;
export type DeleteForIssueCommentError = GithubOpError;
/** Delete an issue comment reaction > [!NOTE] > You can also specify a repository by `repository_id` using the route `DELETE delete /repositories/:repository_id/issues/comments/:comment_id/reactions/:reaction_id`. Delete a reaction to an [issue comment](https://docs.github.com/rest/issues/comments#get-an-issue-comment). */
export declare const deleteForIssueComment: API.OperationMethod<DeleteForIssueCommentRequest, DeleteForIssueCommentResponse, DeleteForIssueCommentError, GithubOpContext>;
export type DeleteForPullRequestCommentError = GithubOpError;
/** Delete a pull request comment reaction > [!NOTE] > You can also specify a repository by `repository_id` using the route `DELETE /repositories/:repository_id/pulls/comments/:comment_id/reactions/:reaction_id.` Delete a reaction to a [pull request review comment](https://docs.github.com/rest/pulls/comments#get-a-review-comment-for-a-pull-request). */
export declare const deleteForPullRequestComment: API.OperationMethod<DeleteForPullRequestCommentRequest, DeleteForPullRequestCommentResponse, DeleteForPullRequestCommentError, GithubOpContext>;
export type DeleteForReleaseError = GithubOpError;
/** Delete a release reaction > [!NOTE] > You can also specify a repository by `repository_id` using the route `DELETE delete /repositories/:repository_id/releases/:release_id/reactions/:reaction_id`. Delete a reaction to a [release](https://docs.github.com/rest/releases/releases#get-a-release). */
export declare const deleteForRelease: API.OperationMethod<DeleteForReleaseRequest, DeleteForReleaseResponse, DeleteForReleaseError, GithubOpContext>;
export type ListForCommitCommentError = GithubOpError;
/** List reactions for a commit comment List the reactions to a [commit comment](https://docs.github.com/rest/commits/comments#get-a-commit-comment). */
export declare const listForCommitComment: API.PaginatedOperationMethod<ListForCommitCommentRequest, ListForCommitCommentResponse, ListForCommitCommentError, GithubOpContext, Reaction>;
export type ListForIssueError = GithubOpError;
/** List reactions for an issue List the reactions to an [issue](https://docs.github.com/rest/issues/issues#get-an-issue). */
export declare const listForIssue: API.PaginatedOperationMethod<ListForIssueRequest, ListForIssueResponse, ListForIssueError, GithubOpContext, Reaction>;
export type ListForIssueCommentError = GithubOpError;
/** List reactions for an issue comment List the reactions to an [issue comment](https://docs.github.com/rest/issues/comments#get-an-issue-comment). */
export declare const listForIssueComment: API.PaginatedOperationMethod<ListForIssueCommentRequest, ListForIssueCommentResponse, ListForIssueCommentError, GithubOpContext, Reaction>;
export type ListForPullRequestReviewCommentError = GithubOpError;
/** List reactions for a pull request review comment List the reactions to a [pull request review comment](https://docs.github.com/rest/pulls/comments#get-a-review-comment-for-a-pull-request). */
export declare const listForPullRequestReviewComment: API.PaginatedOperationMethod<ListForPullRequestReviewCommentRequest, ListForPullRequestReviewCommentResponse, ListForPullRequestReviewCommentError, GithubOpContext, Reaction>;
export type ListForReleaseError = GithubOpError;
/** List reactions for a release List the reactions to a [release](https://docs.github.com/rest/releases/releases#get-a-release). */
export declare const listForRelease: API.PaginatedOperationMethod<ListForReleaseRequest, ListForReleaseResponse, ListForReleaseError, GithubOpContext, Reaction>;
//# sourceMappingURL=reactions.d.ts.map