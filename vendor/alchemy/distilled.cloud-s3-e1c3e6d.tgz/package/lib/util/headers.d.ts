/**
 * HTTP header values of `@httpHeader` members: lists are one header whose
 * values are joined with ", ", and a string with a `@mediaType` is sent
 * base64-encoded (Smithy HTTP binding rules, as the AWS SDKs send and read
 * them).
 */
import type * as AST from "effect/SchemaAST";
/** The header value of a `@mediaType` string: its UTF-8 bytes in base64. */
export declare const toBase64Header: (value: string) => string;
/** What a header reader returns for a `@mediaType` value that is not base64. */
export declare const notBase64: unique symbol;
/**
 * The header value of a list: its elements joined with ", ". With `quote`,
 * an element holding a comma or a double quote is sent as a quoted string
 * with its double quotes escaped (`b,c` -> `"b,c"`). Timestamps are not
 * quoted: an http-date holds a comma, and readers split those in pairs.
 */
export declare const formatHeaderList: (values: ReadonlyArray<unknown>, quote: boolean) => string;
/**
 * The values of a list header: split on the commas outside quoted strings,
 * trimmed, and a quoted value unquoted (`"b,c", a` -> `["b,c", "a"]`).
 */
export declare const splitHeader: (value: string) => string[];
/**
 * The wire value of a response header bound to a member of type `ast`, for
 * the schema decoder: a list header split into its values, numbers and
 * booleans parsed, and a string with a `mediaType` decoded from base64
 * ({@link notBase64} when it is not base64).
 */
export declare const headerReader: (ast: AST.AST, mediaType?: string) => ((value: string) => unknown);
//# sourceMappingURL=headers.d.ts.map