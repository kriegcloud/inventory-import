import type { DockerImagePublicationError } from "@alchemy.run/docker/RegistryError";
import * as Effect from "effect/Effect";
/**
 * Retries an image build or push on transient registry errors. It never
 * imposes a deadline: a build or push takes as long as the image needs.
 */
export declare const retryContainerPublication: <A, E extends DockerImagePublicationError, R>(publication: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
//# sourceMappingURL=ContainerPublication.d.ts.map