/**
 * Shared XML utilities for AWS protocols (aws-query, ec2-query, rest-xml)
 */
import { type XmlObject } from "@distilled.cloud/core/xml";
import * as Effect from "effect/Effect";
import type * as AST from "effect/SchemaAST";
import { Unreadable } from "../client/protocol.ts";
import { ParseError } from "../errors.ts";
export { escapeXml, wrapTag, parseXmlSync, XmlParseError, type XmlObject, type XmlValue, type XmlParseOptions, } from "@distilled.cloud/core/xml";
/** Parse XML, failing with the AWS protocol error type. */
export declare const parseXml: (xml: string) => Effect.Effect<XmlObject, ParseError>;
/**
 * A 2xx XML body, parsed; a malformed one is {@link Unreadable} with the
 * `ParseError` {@link parseXml} fails with.
 */
export declare const readXml: (xml: string) => XmlObject | Unreadable;
/**
 * Extract the root element content from parsed XML.
 * Used by aws-query and ec2-query protocols.
 */
export declare function extractXmlRoot(parsed: Record<string, unknown>): Record<string, unknown>;
/**
 * Deserialize a primitive string value based on AST type.
 * Converts strings to numbers or booleans as needed.
 * Note: Dates are left as strings - Schema.decode handles the Date transformation.
 */
export declare function deserializePrimitive(ast: AST.AST, value: string): unknown;
/**
 * The text of an element: the parser reads an element with attributes and
 * text, `<K xmlns="...">a</K>`, as `{ "#text": "a", "@_xmlns": "..." }`.
 */
export declare function elementText(value: unknown): unknown;
/**
 * Read an XML map. A map is `<Map><entry><key>k</key><value>v</value></entry>...</Map>`;
 * a flattened map repeats the member element itself for each entry,
 * `<Map><key>k</key><value>v</value></Map><Map>...</Map>`, so `value` is that
 * element or the list of them. An empty element is an empty map.
 */
export declare function readXmlMap(value: unknown, flattened: boolean, keyTag: string, valueTag: string, readValue: (value: unknown) => unknown): Record<string, unknown>;
/**
 * Unwrap an array value from a wrapper object.
 * XML parsers often produce { member: [...] } instead of just [...].
 *
 * @param value - The value to unwrap
 * @param primaryTag - Primary tag to look for (e.g., from xmlName or identifier)
 * @param fallbackTags - Additional fallback tags to try (e.g., ["member", "item"])
 * @returns The unwrapped array value
 */
export declare function unwrapArrayValue(value: unknown, primaryTag: string | undefined, fallbackTags?: string[]): unknown;
//# sourceMappingURL=xml.d.ts.map