import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DataUnavailableException_base: S.TaggedErrorClass<"DataUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DataUnavailableException extends /*@__PURE__*/ DataUnavailableException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceId = string;
export type Key = string;
export type UsageGroup = string;
export type AccountId = string;
export type Uuid = string;
export type ReservedInstanceInstanceCount = number;
export interface AddReservedInstanceAction {
    reservedInstancesOfferingId?: string | undefined;
    instanceCount?: number | undefined;
}
export type SavingsPlanCommitment = number;
export interface AddSavingsPlanAction {
    savingsPlanOfferingId?: string | undefined;
    commitment?: number | undefined;
}
export interface NegateReservedInstanceAction {
    reservedInstancesId?: string | undefined;
}
export interface NegateSavingsPlanAction {
    savingsPlanId?: string | undefined;
}
export type BillScenarioCommitmentModificationAction = {
    addReservedInstanceAction: AddReservedInstanceAction;
    addSavingsPlanAction?: undefined;
    negateReservedInstanceAction?: undefined;
    negateSavingsPlanAction?: undefined;
} | {
    addReservedInstanceAction?: undefined;
    addSavingsPlanAction: AddSavingsPlanAction;
    negateReservedInstanceAction?: undefined;
    negateSavingsPlanAction?: undefined;
} | {
    addReservedInstanceAction?: undefined;
    addSavingsPlanAction?: undefined;
    negateReservedInstanceAction: NegateReservedInstanceAction;
    negateSavingsPlanAction?: undefined;
} | {
    addReservedInstanceAction?: undefined;
    addSavingsPlanAction?: undefined;
    negateReservedInstanceAction?: undefined;
    negateSavingsPlanAction: NegateSavingsPlanAction;
};
export interface BatchCreateBillScenarioCommitmentModificationEntry {
    key: string;
    group?: string | undefined;
    usageAccountId: string;
    commitmentAction: BillScenarioCommitmentModificationAction;
}
export type BatchCreateBillScenarioCommitmentModificationEntries = BatchCreateBillScenarioCommitmentModificationEntry[];
export type ClientToken = string;
export interface BatchCreateBillScenarioCommitmentModificationRequest {
    billScenarioId: string;
    commitmentModifications: BatchCreateBillScenarioCommitmentModificationEntry[];
    clientToken?: string | undefined;
}
export interface BatchCreateBillScenarioCommitmentModificationItem {
    key?: string | undefined;
    id?: string | undefined;
    group?: string | undefined;
    usageAccountId?: string | undefined;
    commitmentAction?: BillScenarioCommitmentModificationAction | undefined;
}
export type BatchCreateBillScenarioCommitmentModificationItems = BatchCreateBillScenarioCommitmentModificationItem[];
export type BatchCreateBillScenarioCommitmentModificationErrorCode = "CONFLICT" | "INTERNAL_SERVER_ERROR" | "INVALID_ACCOUNT" | (string & {});
export interface BatchCreateBillScenarioCommitmentModificationError_ {
    key?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: BatchCreateBillScenarioCommitmentModificationErrorCode | undefined;
}
export type BatchCreateBillScenarioCommitmentModificationErrors = BatchCreateBillScenarioCommitmentModificationError_[];
export interface BatchCreateBillScenarioCommitmentModificationResponse {
    items?: BatchCreateBillScenarioCommitmentModificationItem[] | undefined;
    errors?: BatchCreateBillScenarioCommitmentModificationError_[] | undefined;
}
export type ServiceCode = string;
export type UsageType = string;
export type Operation = string;
export type AvailabilityZone = string;
export interface UsageAmount {
    startHour: Date;
    amount: number;
}
export type UsageAmounts = UsageAmount[];
export interface BillInterval {
    start?: Date | undefined;
    end?: Date | undefined;
}
export type ExpressionList = Expression[];
export type StringList = string[];
export interface ExpressionFilter {
    key?: string | undefined;
    matchOptions?: string[] | undefined;
    values?: string[] | undefined;
}
export interface Expression {
    and?: Expression[] | undefined;
    or?: Expression[] | undefined;
    not?: Expression | undefined;
    costCategories?: ExpressionFilter | undefined;
    dimensions?: ExpressionFilter | undefined;
    tags?: ExpressionFilter | undefined;
}
export interface HistoricalUsageEntity {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string | undefined;
    usageAccountId: string;
    billInterval: BillInterval;
    filterExpression: Expression;
}
export interface BatchCreateBillScenarioUsageModificationEntry {
    serviceCode: string;
    usageType: string;
    operation: string;
    availabilityZone?: string | undefined;
    key: string;
    group?: string | undefined;
    usageAccountId: string;
    amounts?: UsageAmount[] | undefined;
    historicalUsage?: HistoricalUsageEntity | undefined;
}
export type BatchCreateBillScenarioUsageModificationEntries = BatchCreateBillScenarioUsageModificationEntry[];
export interface BatchCreateBillScenarioUsageModificationRequest {
    billScenarioId: string;
    usageModifications: BatchCreateBillScenarioUsageModificationEntry[];
    clientToken?: string | undefined;
}
export interface UsageQuantity {
    startHour?: Date | undefined;
    unit?: string | undefined;
    amount?: number | undefined;
}
export type UsageQuantities = UsageQuantity[];
export interface BatchCreateBillScenarioUsageModificationItem {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string | undefined;
    availabilityZone?: string | undefined;
    id?: string | undefined;
    group?: string | undefined;
    usageAccountId?: string | undefined;
    quantities?: UsageQuantity[] | undefined;
    historicalUsage?: HistoricalUsageEntity | undefined;
    key?: string | undefined;
}
export type BatchCreateBillScenarioUsageModificationItems = BatchCreateBillScenarioUsageModificationItem[];
export type BatchCreateBillScenarioUsageModificationErrorCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export interface BatchCreateBillScenarioUsageModificationError_ {
    key?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: BatchCreateBillScenarioUsageModificationErrorCode | undefined;
}
export type BatchCreateBillScenarioUsageModificationErrors = BatchCreateBillScenarioUsageModificationError_[];
export interface BatchCreateBillScenarioUsageModificationResponse {
    items?: BatchCreateBillScenarioUsageModificationItem[] | undefined;
    errors?: BatchCreateBillScenarioUsageModificationError_[] | undefined;
}
export interface BatchCreateWorkloadEstimateUsageEntry {
    serviceCode: string;
    usageType: string;
    operation: string;
    key: string;
    group?: string | undefined;
    usageAccountId: string;
    amount: number;
    historicalUsage?: HistoricalUsageEntity | undefined;
}
export type BatchCreateWorkloadEstimateUsageEntries = BatchCreateWorkloadEstimateUsageEntry[];
export interface BatchCreateWorkloadEstimateUsageRequest {
    workloadEstimateId: string;
    usage: BatchCreateWorkloadEstimateUsageEntry[];
    clientToken?: string | undefined;
}
export interface WorkloadEstimateUsageQuantity {
    unit?: string | undefined;
    amount?: number | undefined;
}
export type CurrencyCode = "USD" | (string & {});
export type WorkloadEstimateCostStatus = "VALID" | "INVALID" | "STALE" | (string & {});
export interface BatchCreateWorkloadEstimateUsageItem {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string | undefined;
    id?: string | undefined;
    usageAccountId?: string | undefined;
    group?: string | undefined;
    quantity?: WorkloadEstimateUsageQuantity | undefined;
    cost?: number | undefined;
    currency?: CurrencyCode | undefined;
    status?: WorkloadEstimateCostStatus | undefined;
    historicalUsage?: HistoricalUsageEntity | undefined;
    key?: string | undefined;
}
export type BatchCreateWorkloadEstimateUsageItems = BatchCreateWorkloadEstimateUsageItem[];
export type BatchCreateWorkloadEstimateUsageCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export interface BatchCreateWorkloadEstimateUsageError_ {
    key?: string | undefined;
    errorCode?: BatchCreateWorkloadEstimateUsageCode | undefined;
    errorMessage?: string | undefined;
}
export type BatchCreateWorkloadEstimateUsageErrors = BatchCreateWorkloadEstimateUsageError_[];
export interface BatchCreateWorkloadEstimateUsageResponse {
    items?: BatchCreateWorkloadEstimateUsageItem[] | undefined;
    errors?: BatchCreateWorkloadEstimateUsageError_[] | undefined;
}
export type BatchDeleteBillScenarioCommitmentModificationEntries = string[];
export interface BatchDeleteBillScenarioCommitmentModificationRequest {
    billScenarioId: string;
    ids: string[];
}
export type BatchDeleteBillScenarioCommitmentModificationErrorCode = "BAD_REQUEST" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export interface BatchDeleteBillScenarioCommitmentModificationError_ {
    id?: string | undefined;
    errorCode?: BatchDeleteBillScenarioCommitmentModificationErrorCode | undefined;
    errorMessage?: string | undefined;
}
export type BatchDeleteBillScenarioCommitmentModificationErrors = BatchDeleteBillScenarioCommitmentModificationError_[];
export interface BatchDeleteBillScenarioCommitmentModificationResponse {
    errors?: BatchDeleteBillScenarioCommitmentModificationError_[] | undefined;
}
export type BatchDeleteBillScenarioUsageModificationEntries = string[];
export interface BatchDeleteBillScenarioUsageModificationRequest {
    billScenarioId: string;
    ids: string[];
}
export type BatchDeleteBillScenarioUsageModificationErrorCode = "BAD_REQUEST" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export interface BatchDeleteBillScenarioUsageModificationError_ {
    id?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: BatchDeleteBillScenarioUsageModificationErrorCode | undefined;
}
export type BatchDeleteBillScenarioUsageModificationErrors = BatchDeleteBillScenarioUsageModificationError_[];
export interface BatchDeleteBillScenarioUsageModificationResponse {
    errors?: BatchDeleteBillScenarioUsageModificationError_[] | undefined;
}
export type BatchDeleteWorkloadEstimateUsageEntries = string[];
export interface BatchDeleteWorkloadEstimateUsageRequest {
    workloadEstimateId: string;
    ids: string[];
}
export type WorkloadEstimateUpdateUsageErrorCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export interface BatchDeleteWorkloadEstimateUsageError_ {
    id?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: WorkloadEstimateUpdateUsageErrorCode | undefined;
}
export type BatchDeleteWorkloadEstimateUsageErrors = BatchDeleteWorkloadEstimateUsageError_[];
export interface BatchDeleteWorkloadEstimateUsageResponse {
    errors?: BatchDeleteWorkloadEstimateUsageError_[] | undefined;
}
export interface BatchUpdateBillScenarioCommitmentModificationEntry {
    id: string;
    group?: string | undefined;
}
export type BatchUpdateBillScenarioCommitmentModificationEntries = BatchUpdateBillScenarioCommitmentModificationEntry[];
export interface BatchUpdateBillScenarioCommitmentModificationRequest {
    billScenarioId: string;
    commitmentModifications: BatchUpdateBillScenarioCommitmentModificationEntry[];
}
export interface BillScenarioCommitmentModificationItem {
    id?: string | undefined;
    usageAccountId?: string | undefined;
    group?: string | undefined;
    commitmentAction?: BillScenarioCommitmentModificationAction | undefined;
}
export type BillScenarioCommitmentModificationItems = BillScenarioCommitmentModificationItem[];
export type BatchUpdateBillScenarioCommitmentModificationErrorCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export interface BatchUpdateBillScenarioCommitmentModificationError_ {
    id?: string | undefined;
    errorCode?: BatchUpdateBillScenarioCommitmentModificationErrorCode | undefined;
    errorMessage?: string | undefined;
}
export type BatchUpdateBillScenarioCommitmentModificationErrors = BatchUpdateBillScenarioCommitmentModificationError_[];
export interface BatchUpdateBillScenarioCommitmentModificationResponse {
    items?: BillScenarioCommitmentModificationItem[] | undefined;
    errors?: BatchUpdateBillScenarioCommitmentModificationError_[] | undefined;
}
export interface BatchUpdateBillScenarioUsageModificationEntry {
    id: string;
    group?: string | undefined;
    amounts?: UsageAmount[] | undefined;
}
export type BatchUpdateBillScenarioUsageModificationEntries = BatchUpdateBillScenarioUsageModificationEntry[];
export interface BatchUpdateBillScenarioUsageModificationRequest {
    billScenarioId: string;
    usageModifications: BatchUpdateBillScenarioUsageModificationEntry[];
}
export interface BillScenarioUsageModificationItem {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string | undefined;
    availabilityZone?: string | undefined;
    id?: string | undefined;
    group?: string | undefined;
    usageAccountId?: string | undefined;
    quantities?: UsageQuantity[] | undefined;
    historicalUsage?: HistoricalUsageEntity | undefined;
}
export type BillScenarioUsageModificationItems = BillScenarioUsageModificationItem[];
export type BatchUpdateBillScenarioUsageModificationErrorCode = "BAD_REQUEST" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR" | (string & {});
export interface BatchUpdateBillScenarioUsageModificationError_ {
    id?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: BatchUpdateBillScenarioUsageModificationErrorCode | undefined;
}
export type BatchUpdateBillScenarioUsageModificationErrors = BatchUpdateBillScenarioUsageModificationError_[];
export interface BatchUpdateBillScenarioUsageModificationResponse {
    items?: BillScenarioUsageModificationItem[] | undefined;
    errors?: BatchUpdateBillScenarioUsageModificationError_[] | undefined;
}
export interface BatchUpdateWorkloadEstimateUsageEntry {
    id: string;
    group?: string | undefined;
    amount?: number | undefined;
}
export type BatchUpdateWorkloadEstimateUsageEntries = BatchUpdateWorkloadEstimateUsageEntry[];
export interface BatchUpdateWorkloadEstimateUsageRequest {
    workloadEstimateId: string;
    usage: BatchUpdateWorkloadEstimateUsageEntry[];
}
export interface WorkloadEstimateUsageItem {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string | undefined;
    id?: string | undefined;
    usageAccountId?: string | undefined;
    group?: string | undefined;
    quantity?: WorkloadEstimateUsageQuantity | undefined;
    cost?: number | undefined;
    currency?: CurrencyCode | undefined;
    status?: WorkloadEstimateCostStatus | undefined;
    historicalUsage?: HistoricalUsageEntity | undefined;
}
export type WorkloadEstimateUsageItems = WorkloadEstimateUsageItem[];
export interface BatchUpdateWorkloadEstimateUsageError_ {
    id?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: WorkloadEstimateUpdateUsageErrorCode | undefined;
}
export type BatchUpdateWorkloadEstimateUsageErrors = BatchUpdateWorkloadEstimateUsageError_[];
export interface BatchUpdateWorkloadEstimateUsageResponse {
    items?: WorkloadEstimateUsageItem[] | undefined;
    errors?: BatchUpdateWorkloadEstimateUsageError_[] | undefined;
}
export type BillEstimateName = string;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateBillEstimateRequest {
    billScenarioId: string;
    name: string;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type BillEstimateStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export interface CostAmount {
    amount?: number | undefined;
    currency?: CurrencyCode | undefined;
}
export interface CostDifference {
    historicalCost?: CostAmount | undefined;
    estimatedCost?: CostAmount | undefined;
}
export type ServiceCostDifferenceMap = {
    [key: string]: CostDifference | undefined;
};
export interface BillEstimateCostSummary {
    totalCostDifference?: CostDifference | undefined;
    serviceCostDifferences?: {
        [key: string]: CostDifference | undefined;
    } | undefined;
}
export type GroupSharingPreferenceEnum = "OPEN" | "PRIORITIZED" | "RESTRICTED" | (string & {});
export type CostCategoryArn = string;
export interface CreateBillEstimateResponse {
    id: string;
    name?: string | undefined;
    status?: BillEstimateStatus | undefined;
    failureMessage?: string | undefined;
    billInterval?: BillInterval | undefined;
    costSummary?: BillEstimateCostSummary | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
    costCategoryGroupSharingPreferenceEffectiveDate?: Date | undefined;
}
export type BillScenarioName = string;
export interface CreateBillScenarioRequest {
    name: string;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
}
export type BillScenarioStatus = "READY" | "LOCKED" | "FAILED" | "STALE" | (string & {});
export interface CreateBillScenarioResponse {
    id: string;
    name?: string | undefined;
    billInterval?: BillInterval | undefined;
    status?: BillScenarioStatus | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    failureMessage?: string | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
}
export type WorkloadEstimateName = string;
export type WorkloadEstimateRateType = "BEFORE_DISCOUNTS" | "AFTER_DISCOUNTS" | "AFTER_DISCOUNTS_AND_COMMITMENTS" | (string & {});
export interface CreateWorkloadEstimateRequest {
    name: string;
    clientToken?: string | undefined;
    rateType?: WorkloadEstimateRateType | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type WorkloadEstimateStatus = "UPDATING" | "VALID" | "INVALID" | "ACTION_NEEDED" | (string & {});
export interface CreateWorkloadEstimateResponse {
    id: string;
    name?: string | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    rateType?: WorkloadEstimateRateType | undefined;
    rateTimestamp?: Date | undefined;
    status?: WorkloadEstimateStatus | undefined;
    totalCost?: number | undefined;
    costCurrency?: CurrencyCode | undefined;
    failureMessage?: string | undefined;
}
export interface DeleteBillEstimateRequest {
    identifier: string;
}
export interface DeleteBillEstimateResponse {
}
export interface DeleteBillScenarioRequest {
    identifier: string;
}
export interface DeleteBillScenarioResponse {
}
export interface DeleteWorkloadEstimateRequest {
    identifier: string;
}
export interface DeleteWorkloadEstimateResponse {
}
export interface GetBillEstimateRequest {
    identifier: string;
}
export interface GetBillEstimateResponse {
    id: string;
    name?: string | undefined;
    status?: BillEstimateStatus | undefined;
    failureMessage?: string | undefined;
    billInterval?: BillInterval | undefined;
    costSummary?: BillEstimateCostSummary | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
    costCategoryGroupSharingPreferenceEffectiveDate?: Date | undefined;
}
export interface GetBillScenarioRequest {
    identifier: string;
}
export interface GetBillScenarioResponse {
    id: string;
    name?: string | undefined;
    billInterval?: BillInterval | undefined;
    status?: BillScenarioStatus | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    failureMessage?: string | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
}
export interface GetPreferencesRequest {
}
export type RateType = "BEFORE_DISCOUNTS" | "AFTER_DISCOUNTS" | "AFTER_DISCOUNTS_AND_COMMITMENTS" | (string & {});
export type RateTypes = RateType[];
export interface GetPreferencesResponse {
    managementAccountRateTypeSelections?: RateType[] | undefined;
    memberAccountRateTypeSelections?: RateType[] | undefined;
    standaloneAccountRateTypeSelections?: RateType[] | undefined;
}
export interface GetWorkloadEstimateRequest {
    identifier: string;
}
export interface GetWorkloadEstimateResponse {
    id: string;
    name?: string | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    rateType?: WorkloadEstimateRateType | undefined;
    rateTimestamp?: Date | undefined;
    status?: WorkloadEstimateStatus | undefined;
    totalCost?: number | undefined;
    costCurrency?: CurrencyCode | undefined;
    failureMessage?: string | undefined;
}
export type NextPageToken = string;
export type MaxResults = number;
export interface ListBillEstimateCommitmentsRequest {
    billEstimateId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type PurchaseAgreementType = "SAVINGS_PLANS" | "RESERVED_INSTANCE" | (string & {});
export interface BillEstimateCommitmentSummary {
    id?: string | undefined;
    purchaseAgreementType?: PurchaseAgreementType | undefined;
    offeringId?: string | undefined;
    usageAccountId?: string | undefined;
    region?: string | undefined;
    termLength?: string | undefined;
    paymentOption?: string | undefined;
    upfrontPayment?: CostAmount | undefined;
    monthlyPayment?: CostAmount | undefined;
}
export type BillEstimateCommitmentSummaries = BillEstimateCommitmentSummary[];
export interface ListBillEstimateCommitmentsResponse {
    items?: BillEstimateCommitmentSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBillEstimateInputCommitmentModificationsRequest {
    billEstimateId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BillEstimateInputCommitmentModificationSummary {
    id?: string | undefined;
    group?: string | undefined;
    usageAccountId?: string | undefined;
    commitmentAction?: BillScenarioCommitmentModificationAction | undefined;
}
export type BillEstimateInputCommitmentModificationSummaries = BillEstimateInputCommitmentModificationSummary[];
export interface ListBillEstimateInputCommitmentModificationsResponse {
    items?: BillEstimateInputCommitmentModificationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListUsageFilterName = "USAGE_ACCOUNT_ID" | "SERVICE_CODE" | "USAGE_TYPE" | "OPERATION" | "LOCATION" | "USAGE_GROUP" | "HISTORICAL_USAGE_ACCOUNT_ID" | "HISTORICAL_SERVICE_CODE" | "HISTORICAL_USAGE_TYPE" | "HISTORICAL_OPERATION" | "HISTORICAL_LOCATION" | (string & {});
export type ListUsageFilterValues = string[];
export type MatchOption = "EQUALS" | "STARTS_WITH" | "CONTAINS" | (string & {});
export interface ListUsageFilter {
    name: ListUsageFilterName;
    values: string[];
    matchOption?: MatchOption | undefined;
}
export type ListUsageFilters = ListUsageFilter[];
export interface ListBillEstimateInputUsageModificationsRequest {
    billEstimateId: string;
    filters?: ListUsageFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BillEstimateInputUsageModificationSummary {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string | undefined;
    availabilityZone?: string | undefined;
    id?: string | undefined;
    group?: string | undefined;
    usageAccountId?: string | undefined;
    quantities?: UsageQuantity[] | undefined;
    historicalUsage?: HistoricalUsageEntity | undefined;
}
export type BillEstimateInputUsageModificationSummaries = BillEstimateInputUsageModificationSummary[];
export interface ListBillEstimateInputUsageModificationsResponse {
    items?: BillEstimateInputUsageModificationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListBillEstimateLineItemsFilterName = "USAGE_ACCOUNT_ID" | "SERVICE_CODE" | "USAGE_TYPE" | "OPERATION" | "LOCATION" | "LINE_ITEM_TYPE" | (string & {});
export type ListBillEstimateLineItemsFilterValues = string[];
export interface ListBillEstimateLineItemsFilter {
    name: ListBillEstimateLineItemsFilterName;
    values: string[];
    matchOption?: MatchOption | undefined;
}
export type ListBillEstimateLineItemsFilters = ListBillEstimateLineItemsFilter[];
export interface ListBillEstimateLineItemsRequest {
    billEstimateId: string;
    filters?: ListBillEstimateLineItemsFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface UsageQuantityResult {
    amount?: number | undefined;
    unit?: string | undefined;
}
export type SavingsPlanArns = string[];
export interface BillEstimateLineItemSummary {
    serviceCode: string;
    usageType: string;
    operation: string;
    location?: string | undefined;
    availabilityZone?: string | undefined;
    id?: string | undefined;
    lineItemId?: string | undefined;
    lineItemType?: string | undefined;
    payerAccountId?: string | undefined;
    usageAccountId?: string | undefined;
    estimatedUsageQuantity?: UsageQuantityResult | undefined;
    estimatedCost?: CostAmount | undefined;
    historicalUsageQuantity?: UsageQuantityResult | undefined;
    historicalCost?: CostAmount | undefined;
    savingsPlanArns?: string[] | undefined;
}
export type BillEstimateLineItemSummaries = BillEstimateLineItemSummary[];
export interface ListBillEstimateLineItemsResponse {
    items?: BillEstimateLineItemSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListBillEstimatesFilterName = "STATUS" | "NAME" | (string & {});
export type ListBillEstimatesFilterValues = string[];
export interface ListBillEstimatesFilter {
    name: ListBillEstimatesFilterName;
    values: string[];
    matchOption?: MatchOption | undefined;
}
export type ListBillEstimatesFilters = ListBillEstimatesFilter[];
export interface FilterTimestamp {
    afterTimestamp?: Date | undefined;
    beforeTimestamp?: Date | undefined;
}
export interface ListBillEstimatesRequest {
    filters?: ListBillEstimatesFilter[] | undefined;
    createdAtFilter?: FilterTimestamp | undefined;
    expiresAtFilter?: FilterTimestamp | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BillEstimateSummary {
    id: string;
    name?: string | undefined;
    status?: BillEstimateStatus | undefined;
    billInterval?: BillInterval | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
}
export type BillEstimateSummaries = BillEstimateSummary[];
export interface ListBillEstimatesResponse {
    items?: BillEstimateSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBillScenarioCommitmentModificationsRequest {
    billScenarioId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListBillScenarioCommitmentModificationsResponse {
    items?: BillScenarioCommitmentModificationItem[] | undefined;
    nextToken?: string | undefined;
}
export type ListBillScenariosFilterName = "STATUS" | "NAME" | "GROUP_SHARING_PREFERENCE" | "COST_CATEGORY_ARN" | (string & {});
export type ListBillScenariosFilterValues = string[];
export interface ListBillScenariosFilter {
    name: ListBillScenariosFilterName;
    values: string[];
    matchOption?: MatchOption | undefined;
}
export type ListBillScenariosFilters = ListBillScenariosFilter[];
export interface ListBillScenariosRequest {
    filters?: ListBillScenariosFilter[] | undefined;
    createdAtFilter?: FilterTimestamp | undefined;
    expiresAtFilter?: FilterTimestamp | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BillScenarioSummary {
    id: string;
    name?: string | undefined;
    billInterval?: BillInterval | undefined;
    status?: BillScenarioStatus | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    failureMessage?: string | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
}
export type BillScenarioSummaries = BillScenarioSummary[];
export interface ListBillScenariosResponse {
    items?: BillScenarioSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBillScenarioUsageModificationsRequest {
    billScenarioId: string;
    filters?: ListUsageFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListBillScenarioUsageModificationsResponse {
    items?: BillScenarioUsageModificationItem[] | undefined;
    nextToken?: string | undefined;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    arn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListWorkloadEstimatesFilterName = "STATUS" | "NAME" | (string & {});
export type ListWorkloadEstimatesFilterValues = string[];
export interface ListWorkloadEstimatesFilter {
    name: ListWorkloadEstimatesFilterName;
    values: string[];
    matchOption?: MatchOption | undefined;
}
export type ListWorkloadEstimatesFilters = ListWorkloadEstimatesFilter[];
export interface ListWorkloadEstimatesRequest {
    createdAtFilter?: FilterTimestamp | undefined;
    expiresAtFilter?: FilterTimestamp | undefined;
    filters?: ListWorkloadEstimatesFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface WorkloadEstimateSummary {
    id: string;
    name?: string | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    rateType?: WorkloadEstimateRateType | undefined;
    rateTimestamp?: Date | undefined;
    status?: WorkloadEstimateStatus | undefined;
    totalCost?: number | undefined;
    costCurrency?: CurrencyCode | undefined;
    failureMessage?: string | undefined;
}
export type WorkloadEstimateSummaries = WorkloadEstimateSummary[];
export interface ListWorkloadEstimatesResponse {
    items?: WorkloadEstimateSummary[] | undefined;
    nextToken?: string | undefined;
}
export type WorkloadEstimateUsageMaxResults = number;
export interface ListWorkloadEstimateUsageRequest {
    workloadEstimateId: string;
    filters?: ListUsageFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListWorkloadEstimateUsageResponse {
    items?: WorkloadEstimateUsageItem[] | undefined;
    nextToken?: string | undefined;
}
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type ResourceTagKeys = string[];
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateBillEstimateRequest {
    identifier: string;
    name?: string | undefined;
    expiresAt?: Date | undefined;
}
export interface UpdateBillEstimateResponse {
    id: string;
    name?: string | undefined;
    status?: BillEstimateStatus | undefined;
    failureMessage?: string | undefined;
    billInterval?: BillInterval | undefined;
    costSummary?: BillEstimateCostSummary | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
    costCategoryGroupSharingPreferenceEffectiveDate?: Date | undefined;
}
export interface UpdateBillScenarioRequest {
    identifier: string;
    name?: string | undefined;
    expiresAt?: Date | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
}
export interface UpdateBillScenarioResponse {
    id: string;
    name?: string | undefined;
    billInterval?: BillInterval | undefined;
    status?: BillScenarioStatus | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    failureMessage?: string | undefined;
    groupSharingPreference?: GroupSharingPreferenceEnum | undefined;
    costCategoryGroupSharingPreferenceArn?: string | undefined;
}
export interface UpdatePreferencesRequest {
    managementAccountRateTypeSelections?: RateType[] | undefined;
    memberAccountRateTypeSelections?: RateType[] | undefined;
    standaloneAccountRateTypeSelections?: RateType[] | undefined;
}
export interface UpdatePreferencesResponse {
    managementAccountRateTypeSelections?: RateType[] | undefined;
    memberAccountRateTypeSelections?: RateType[] | undefined;
    standaloneAccountRateTypeSelections?: RateType[] | undefined;
}
export interface UpdateWorkloadEstimateRequest {
    identifier: string;
    name?: string | undefined;
    expiresAt?: Date | undefined;
}
export interface UpdateWorkloadEstimateResponse {
    id: string;
    name?: string | undefined;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    rateType?: WorkloadEstimateRateType | undefined;
    rateTimestamp?: Date | undefined;
    status?: WorkloadEstimateStatus | undefined;
    totalCost?: number | undefined;
    costCurrency?: CurrencyCode | undefined;
    failureMessage?: string | undefined;
}
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "invalidRequestFromMember" | "disallowedRate" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchCreateBillScenarioCommitmentModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create Compute Savings Plans, EC2 Instance Savings Plans, or EC2 Reserved Instances commitments that you want to model in a Bill Scenario.
 *
 * The `BatchCreateBillScenarioCommitmentModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:CreateBillScenarioCommitmentModification` in your policies.
 */
export declare const batchCreateBillScenarioCommitmentModification: API.OperationMethod<BatchCreateBillScenarioCommitmentModificationRequest & RegionInput, BatchCreateBillScenarioCommitmentModificationResponse, BatchCreateBillScenarioCommitmentModificationError, Credentials | HttpClient.HttpClient>;
export type BatchCreateBillScenarioUsageModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create Amazon Web Services service usage that you want to model in a Bill Scenario.
 *
 * The `BatchCreateBillScenarioUsageModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:CreateBillScenarioUsageModification` in your policies.
 */
export declare const batchCreateBillScenarioUsageModification: API.OperationMethod<BatchCreateBillScenarioUsageModificationRequest & RegionInput, BatchCreateBillScenarioUsageModificationResponse, BatchCreateBillScenarioUsageModificationError, Credentials | HttpClient.HttpClient>;
export type BatchCreateWorkloadEstimateUsageError = ConflictException | DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create Amazon Web Services service usage that you want to model in a Workload Estimate.
 *
 * The `BatchCreateWorkloadEstimateUsage` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:CreateWorkloadEstimateUsage` in your policies.
 */
export declare const batchCreateWorkloadEstimateUsage: API.OperationMethod<BatchCreateWorkloadEstimateUsageRequest & RegionInput, BatchCreateWorkloadEstimateUsageResponse, BatchCreateWorkloadEstimateUsageError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteBillScenarioCommitmentModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete commitment that you have created in a Bill Scenario. You can only delete a commitment that you had added and cannot model deletion (or removal) of a existing commitment. If you want model deletion of an existing commitment, see the negate BillScenarioCommitmentModificationAction of BatchCreateBillScenarioCommitmentModification operation.
 *
 * The `BatchDeleteBillScenarioCommitmentModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:DeleteBillScenarioCommitmentModification` in your policies.
 */
export declare const batchDeleteBillScenarioCommitmentModification: API.OperationMethod<BatchDeleteBillScenarioCommitmentModificationRequest & RegionInput, BatchDeleteBillScenarioCommitmentModificationResponse, BatchDeleteBillScenarioCommitmentModificationError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteBillScenarioUsageModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete usage that you have created in a Bill Scenario. You can only delete usage that you had added and cannot model deletion (or removal) of a existing usage. If you want model removal of an existing usage, see BatchUpdateBillScenarioUsageModification.
 *
 * The `BatchDeleteBillScenarioUsageModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:DeleteBillScenarioUsageModification` in your policies.
 */
export declare const batchDeleteBillScenarioUsageModification: API.OperationMethod<BatchDeleteBillScenarioUsageModificationRequest & RegionInput, BatchDeleteBillScenarioUsageModificationResponse, BatchDeleteBillScenarioUsageModificationError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteWorkloadEstimateUsageError = DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete usage that you have created in a Workload estimate. You can only delete usage that you had added and cannot model deletion (or removal) of a existing usage. If you want model removal of an existing usage, see BatchUpdateWorkloadEstimateUsage.
 *
 * The `BatchDeleteWorkloadEstimateUsage` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:DeleteWorkloadEstimateUsage` in your policies.
 */
export declare const batchDeleteWorkloadEstimateUsage: API.OperationMethod<BatchDeleteWorkloadEstimateUsageRequest & RegionInput, BatchDeleteWorkloadEstimateUsageResponse, BatchDeleteWorkloadEstimateUsageError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateBillScenarioCommitmentModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a newly added or existing commitment. You can update the commitment group based on a commitment ID and a Bill scenario ID.
 *
 * The `BatchUpdateBillScenarioCommitmentModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:UpdateBillScenarioCommitmentModification` in your policies.
 */
export declare const batchUpdateBillScenarioCommitmentModification: API.OperationMethod<BatchUpdateBillScenarioCommitmentModificationRequest & RegionInput, BatchUpdateBillScenarioCommitmentModificationResponse, BatchUpdateBillScenarioCommitmentModificationError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateBillScenarioUsageModificationError = ConflictException | DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a newly added or existing usage lines. You can update the usage amounts, usage hour, and usage group based on a usage ID and a Bill scenario ID.
 *
 * The `BatchUpdateBillScenarioUsageModification` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:UpdateBillScenarioUsageModification` in your policies.
 */
export declare const batchUpdateBillScenarioUsageModification: API.OperationMethod<BatchUpdateBillScenarioUsageModificationRequest & RegionInput, BatchUpdateBillScenarioUsageModificationResponse, BatchUpdateBillScenarioUsageModificationError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateWorkloadEstimateUsageError = DataUnavailableException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a newly added or existing usage lines. You can update the usage amounts and usage group based on a usage ID and a Workload estimate ID.
 *
 * The `BatchUpdateWorkloadEstimateUsage` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `bcm-pricing-calculator:UpdateWorkloadEstimateUsage` in your policies.
 */
export declare const batchUpdateWorkloadEstimateUsage: API.OperationMethod<BatchUpdateWorkloadEstimateUsageRequest & RegionInput, BatchUpdateWorkloadEstimateUsageResponse, BatchUpdateWorkloadEstimateUsageError, Credentials | HttpClient.HttpClient>;
export type CreateBillEstimateError = ConflictException | DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a Bill estimate from a Bill scenario. In the Bill scenario you can model usage addition, usage changes, and usage removal. You can also model commitment addition and commitment removal. After all changes in a Bill scenario is made satisfactorily, you can call this API with a Bill scenario ID to generate the Bill estimate. Bill estimate calculates the pre-tax cost for your consolidated billing family, incorporating all modeled usage and commitments alongside existing usage and commitments from your most recent completed anniversary bill, with any applicable discounts applied.
 */
export declare const createBillEstimate: API.OperationMethod<CreateBillEstimateRequest & RegionInput, CreateBillEstimateResponse, CreateBillEstimateError, Credentials | HttpClient.HttpClient>;
export type CreateBillScenarioError = ConflictException | DataUnavailableException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new bill scenario to model potential changes to Amazon Web Services usage and costs.
 */
export declare const createBillScenario: API.OperationMethod<CreateBillScenarioRequest & RegionInput, CreateBillScenarioResponse, CreateBillScenarioError, Credentials | HttpClient.HttpClient>;
export type CreateWorkloadEstimateError = ConflictException | DataUnavailableException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new workload estimate to model costs for a specific workload.
 */
export declare const createWorkloadEstimate: API.OperationMethod<CreateWorkloadEstimateRequest & RegionInput, CreateWorkloadEstimateResponse, CreateWorkloadEstimateError, Credentials | HttpClient.HttpClient>;
export type DeleteBillEstimateError = ConflictException | DataUnavailableException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing bill estimate.
 */
export declare const deleteBillEstimate: API.OperationMethod<DeleteBillEstimateRequest & RegionInput, DeleteBillEstimateResponse, DeleteBillEstimateError, Credentials | HttpClient.HttpClient>;
export type DeleteBillScenarioError = ConflictException | DataUnavailableException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing bill scenario.
 */
export declare const deleteBillScenario: API.OperationMethod<DeleteBillScenarioRequest & RegionInput, DeleteBillScenarioResponse, DeleteBillScenarioError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkloadEstimateError = DataUnavailableException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing workload estimate.
 */
export declare const deleteWorkloadEstimate: API.OperationMethod<DeleteWorkloadEstimateRequest & RegionInput, DeleteWorkloadEstimateResponse, DeleteWorkloadEstimateError, Credentials | HttpClient.HttpClient>;
export type GetBillEstimateError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of a specific bill estimate.
 */
export declare const getBillEstimate: API.OperationMethod<GetBillEstimateRequest & RegionInput, GetBillEstimateResponse, GetBillEstimateError, Credentials | HttpClient.HttpClient>;
export type GetBillScenarioError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of a specific bill scenario.
 */
export declare const getBillScenario: API.OperationMethod<GetBillScenarioRequest & RegionInput, GetBillScenarioResponse, GetBillScenarioError, Credentials | HttpClient.HttpClient>;
export type GetPreferencesError = DataUnavailableException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current preferences for Pricing Calculator.
 */
export declare const getPreferences: API.OperationMethod<GetPreferencesRequest & RegionInput, GetPreferencesResponse, GetPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadEstimateError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of a specific workload estimate.
 */
export declare const getWorkloadEstimate: API.OperationMethod<GetWorkloadEstimateRequest & RegionInput, GetWorkloadEstimateResponse, GetWorkloadEstimateError, Credentials | HttpClient.HttpClient>;
export type ListBillEstimateCommitmentsError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the commitments associated with a bill estimate.
 */
export declare const listBillEstimateCommitments: API.PaginatedOperationMethod<ListBillEstimateCommitmentsRequest & RegionInput, ListBillEstimateCommitmentsResponse, ListBillEstimateCommitmentsError, Credentials | HttpClient.HttpClient, BillEstimateCommitmentSummary>;
export type ListBillEstimateInputCommitmentModificationsError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the input commitment modifications associated with a bill estimate.
 */
export declare const listBillEstimateInputCommitmentModifications: API.PaginatedOperationMethod<ListBillEstimateInputCommitmentModificationsRequest & RegionInput, ListBillEstimateInputCommitmentModificationsResponse, ListBillEstimateInputCommitmentModificationsError, Credentials | HttpClient.HttpClient, BillEstimateInputCommitmentModificationSummary>;
export type ListBillEstimateInputUsageModificationsError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the input usage modifications associated with a bill estimate.
 */
export declare const listBillEstimateInputUsageModifications: API.PaginatedOperationMethod<ListBillEstimateInputUsageModificationsRequest & RegionInput, ListBillEstimateInputUsageModificationsResponse, ListBillEstimateInputUsageModificationsError, Credentials | HttpClient.HttpClient, BillEstimateInputUsageModificationSummary>;
export type ListBillEstimateLineItemsError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the line items associated with a bill estimate.
 */
export declare const listBillEstimateLineItems: API.PaginatedOperationMethod<ListBillEstimateLineItemsRequest & RegionInput, ListBillEstimateLineItemsResponse, ListBillEstimateLineItemsError, Credentials | HttpClient.HttpClient, BillEstimateLineItemSummary>;
export type ListBillEstimatesError = DataUnavailableException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all bill estimates for the account.
 */
export declare const listBillEstimates: API.PaginatedOperationMethod<ListBillEstimatesRequest & RegionInput, ListBillEstimatesResponse, ListBillEstimatesError, Credentials | HttpClient.HttpClient, BillEstimateSummary>;
export type ListBillScenarioCommitmentModificationsError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the commitment modifications associated with a bill scenario.
 */
export declare const listBillScenarioCommitmentModifications: API.PaginatedOperationMethod<ListBillScenarioCommitmentModificationsRequest & RegionInput, ListBillScenarioCommitmentModificationsResponse, ListBillScenarioCommitmentModificationsError, Credentials | HttpClient.HttpClient, BillScenarioCommitmentModificationItem>;
export type ListBillScenariosError = DataUnavailableException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all bill scenarios for the account.
 */
export declare const listBillScenarios: API.PaginatedOperationMethod<ListBillScenariosRequest & RegionInput, ListBillScenariosResponse, ListBillScenariosError, Credentials | HttpClient.HttpClient, BillScenarioSummary>;
export type ListBillScenarioUsageModificationsError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the usage modifications associated with a bill scenario.
 */
export declare const listBillScenarioUsageModifications: API.PaginatedOperationMethod<ListBillScenarioUsageModificationsRequest & RegionInput, ListBillScenarioUsageModificationsResponse, ListBillScenarioUsageModificationsError, Credentials | HttpClient.HttpClient, BillScenarioUsageModificationItem>;
export type ListTagsForResourceError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags associated with a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkloadEstimatesError = DataUnavailableException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all workload estimates for the account.
 */
export declare const listWorkloadEstimates: API.PaginatedOperationMethod<ListWorkloadEstimatesRequest & RegionInput, ListWorkloadEstimatesResponse, ListWorkloadEstimatesError, Credentials | HttpClient.HttpClient, WorkloadEstimateSummary>;
export type ListWorkloadEstimateUsageError = DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the usage associated with a workload estimate.
 */
export declare const listWorkloadEstimateUsage: API.PaginatedOperationMethod<ListWorkloadEstimateUsageRequest & RegionInput, ListWorkloadEstimateUsageResponse, ListWorkloadEstimateUsageError, Credentials | HttpClient.HttpClient, WorkloadEstimateUsageItem>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBillEstimateError = ConflictException | DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing bill estimate.
 */
export declare const updateBillEstimate: API.OperationMethod<UpdateBillEstimateRequest & RegionInput, UpdateBillEstimateResponse, UpdateBillEstimateError, Credentials | HttpClient.HttpClient>;
export type UpdateBillScenarioError = ConflictException | DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing bill scenario.
 */
export declare const updateBillScenario: API.OperationMethod<UpdateBillScenarioRequest & RegionInput, UpdateBillScenarioResponse, UpdateBillScenarioError, Credentials | HttpClient.HttpClient>;
export type UpdatePreferencesError = DataUnavailableException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the preferences for Pricing Calculator.
 */
export declare const updatePreferences: API.OperationMethod<UpdatePreferencesRequest & RegionInput, UpdatePreferencesResponse, UpdatePreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkloadEstimateError = ConflictException | DataUnavailableException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing workload estimate.
 */
export declare const updateWorkloadEstimate: API.OperationMethod<UpdateWorkloadEstimateRequest & RegionInput, UpdateWorkloadEstimateResponse, UpdateWorkloadEstimateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bcm-pricing-calculator.d.ts.map