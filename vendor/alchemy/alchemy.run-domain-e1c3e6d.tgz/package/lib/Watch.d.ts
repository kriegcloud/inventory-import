import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import type { HttpServerError } from "effect/http/HttpServerError";
import { HttpServerRequest } from "effect/http/HttpServerRequest";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
import * as Rpc from "effect/rpc/Rpc";
import * as Schema from "effect/Schema";
import * as Stream from "effect/Stream";
import type { Kernel } from "./Kernel.ts";
import { type Json, type Push, type StreamEntry, type StreamMeta, type Subscription, type ViewEntry, type ViewSnapshot } from "./Platform.ts";
import type * as Read from "./Read.ts";
import type * as DomainStream from "./Stream.ts";
import type * as View from "./View.ts";
/** Encode a read's refusal (a middleware error, or a redacted defect) as the `Exit` that ends it. */
export declare const refuse: (rpc: Rpc.Any, exit: Exit.Exit<void, unknown>) => Effect.Effect<Json, Schema.SchemaError>;
type Validate = (request: Read.Request<unknown>, state: unknown) => Effect.Effect<void, unknown>;
/** What a view key's subscriber receives after a commit (or when it connects). */
export declare const viewPush: (kernel: Kernel, view: View.Any, validatorOf: (name: string) => Validate | undefined) => (key: string, subscription: Subscription, snapshot: ViewSnapshot, entries: ReadonlyArray<ViewEntry>) => Effect.Effect<Push>;
/** What a stream key's subscriber receives after an append (or when it connects). */
export declare const streamPush: (kernel: Kernel, stream: DomainStream.Any, validatorOf: (name: string) => Validate | undefined) => (key: string, subscription: Subscription, meta: StreamMeta, entries: ReadonlyArray<StreamEntry>, latest: StreamEntry | undefined) => Effect.Effect<Push>;
/**
 * Serve a live read's WebSocket (the current request) in this process: send
 * what it starts with, then push on every change to the key, until the read
 * ends or the client goes. For platforms whose keys live in the process that
 * serves the Api, so no object holds the socket.
 */
export declare const serveSocket: (subscription: Subscription, push: (subscription: Subscription) => Effect.Effect<Push>, changes: Stream.Stream<unknown>) => Effect.Effect<HttpServerResponse.HttpServerResponse, HttpServerError, HttpServerRequest>;
export {};
//# sourceMappingURL=Watch.d.ts.map