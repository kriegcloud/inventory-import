import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as Exit from "effect/Exit";
import * as Fiber from "effect/Fiber";
import * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientError from "effect/http/HttpClientError";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
import type * as HttpClientResponse from "effect/http/HttpClientResponse";
import type * as AST from "effect/SchemaAST";
import type * as Stream from "effect/Stream";
import * as Tracer from "effect/Tracer";
/**
 * Debug mode's implementation, provided by `TelemetryDebug.layer`
 * (`./telemetry-debug.ts`); undefined, the default, is operation spans only.
 * The per-call path only checks whether it is set.
 */
export interface DebugHooks {
    /** An INTERNAL span around one of distilled's steps. */
    readonly phase: <A, E, R>(name: string, effect: Effect.Effect<A, E, R>, attributes?: Record<string, unknown>) => Effect.Effect<A, E, R>;
    /** Try `n` (1-based) as its own `Attempt` span. */
    readonly attempt: <A, E, R>(base: Effect.Effect<A, E, R>, n: number) => Effect.Effect<A, E, R>;
    /** The caller's read of a streamed output member, as a span under `parent`. */
    readonly readStream: <A, E, R>(stream: Stream.Stream<A, E, R>, parent: Tracer.Span, member: string) => Stream.Stream<A, E, R>;
    /**
     * The operation call with its debug log lines: `Effect.logDebug` at the
     * start (with the input) and on exit (with the output), every line inside
     * annotated with the operation. With `schemas`, input and output are
     * logged with their sensitive values `Redacted` (`./sensitive.ts`);
     * without, they are left out.
     */
    readonly call: <A, E, R>(info: OperationInfo, input: unknown, schemas: OperationSchemas | undefined, effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
    /** One HTTP exchange (`sent`) with its debug log lines. */
    readonly http: (request: HttpClientRequest.HttpClientRequest, sent: Effect.Effect<HttpClientResponse.HttpClientResponse, HttpClientError.HttpClientError>) => Effect.Effect<HttpClientResponse.HttpClientResponse, HttpClientError.HttpClientError>;
    /** OTel `code.*` attributes for the caller's line. */
    readonly callSite: (callSite: (() => string | undefined) | undefined) => Record<string, unknown> | undefined;
}
/** An operation's input and output schemas, for the debug log lines. */
export interface OperationSchemas {
    readonly input: AST.AST;
    readonly output: AST.AST;
}
export declare const Debug: Context.Reference<DebugHooks | undefined>;
/**
 * The traced call running on this fiber: its operation span, the debug-mode
 * attempt span of the current try, and the retry history so far. Protocols
 * write through {@link annotate} synchronously, without an extra effect.
 */
export interface Call {
    readonly span: Tracer.Span;
    readonly info: OperationInfo;
    attempt: Tracer.Span | undefined;
    readonly retryErrors: Array<string>;
    retryDelayMs: number;
}
export declare const OperationSpan: Context.Reference<Call | undefined>;
/**
 * How a value becomes an attribute value (`com.distilled.telemetry`
 * transforms; see `packages/dev/src/codegen/telemetry-traits.md`).
 */
export type Transform = "list" | "keys" | "count" | "lastPathSegment" | "arnResource" | "arn" | "jsonList" | "nonZero";
export interface AttributeRule {
    readonly name: string;
    /** Dotted path into the member's value, read before the transform. */
    readonly field?: string;
    readonly transform?: Transform;
}
/**
 * Extra facts for a request, by host (`hostRules` in
 * `./telemetry-host-rules.ts`): `set` records an attribute on the span.
 */
export type RequestHook = (host: string, span: Tracer.Span, set: (key: string, value: unknown) => void) => void;
/** The `com.distilled.telemetry#service` trait, as generated code carries it. */
export interface ServiceTelemetry {
    readonly system: string;
    readonly attributes?: Readonly<Record<string, string | number | boolean>>;
    readonly responseHeaders?: ReadonlyArray<AttributeRule & {
        readonly header: string;
    }>;
    /** From the trait's `hosts`. */
    readonly onRequest?: RequestHook;
    /**
     * The rules every operation of this module follows, so its generated
     * `span` holds only what differs (see {@link operationInfo}): span name
     * `<prefix>.<op>`, `rpc.method` `<service>/<op>`, and each path label
     * recorded as `<labels>.<label in snake_case>`.
     */
    readonly prefix?: string;
    readonly service?: string;
    readonly labels?: string;
    /** Path labels named another way than `<labels>.<snake_case>`, by property. */
    readonly labelNames?: Readonly<Record<string, string>>;
    /** `false`: operations do not derive `url.template` (RPC protocols). */
    readonly templates?: false;
    /**
     * How requests carry the span's trace context, from the trait's
     * `propagation`: `"w3c"`, a `traceparent` header; or a function returning
     * the header to set (X-Ray, `./telemetry-xray.ts`).
     */
    readonly propagate?: "w3c" | ((span: Tracer.AnySpan) => readonly [header: string, value: string]);
}
/** A span name for one call from its input attributes; undefined keeps the trait's `name`. */
export type SpanRename = (attributes: Readonly<Record<string, unknown>>) => string | undefined;
/**
 * Runs an operation call in its span and keeps the span open after the call
 * returns, until the caller has read a streamed output member (the trait's
 * `stream`; built by `./telemetry-stream.ts`). Every other operation uses
 * `Effect.useSpan`, which ends the span on return.
 */
export type SpanHold = <A, E, R>(fiber: Fiber.Fiber<unknown, unknown>, name: string, options: Tracer.SpanOptionsNoTrace, debug: DebugHooks | undefined, inSpan: (span: Tracer.Span) => Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/** Read trace context back from an operation's messages (the trait's `extract`). */
export interface MessageExtract {
    /** The input asking the service to return the trace context. */
    readonly request: (input: unknown) => unknown;
    /** Links to the spans the output's messages name. */
    readonly links: (output: unknown) => ReadonlyArray<Tracer.SpanLink>;
}
/**
 * The `com.distilled.telemetry#operation` trait plus its input members'
 * rules. The trait's `nameTemplate`, `inject` and `extract` arrive as the
 * functions `./telemetry-name-template.ts` and
 * `./telemetry-message-context.ts` build from them.
 */
export interface SpanConfig {
    /**
     * The operation's model name. With it, whatever this config leaves out
     * follows the service's rules and the input schema's annotations.
     */
    readonly op?: string;
    /** `false`: no `url.template`, whatever the service's rule. */
    readonly template?: false;
    readonly name?: string;
    readonly method?: string;
    readonly kind?: "client" | "producer" | "consumer";
    /** Fixed attributes; `null` drops one the service sets. */
    readonly attributes?: Readonly<Record<string, string | number | boolean | null>>;
    /** `com.distilled.telemetry#attributes` of the input members, by property name. */
    readonly input?: Readonly<Record<string, ReadonlyArray<AttributeRule>>>;
    /**
     * Attributes recorded under a second name once the request is built:
     * `{ "cloud.region": "faas.invoked_region" }`.
     */
    readonly copy?: Readonly<Record<string, string>>;
    /** The same, for output members: recorded when the call succeeds. */
    readonly output?: Readonly<Record<string, ReadonlyArray<AttributeRule>>>;
    readonly rename?: SpanRename;
    /** Write the span's trace context into the request's messages. */
    readonly inject?: (span: Tracer.Span, input: unknown) => unknown;
    readonly extract?: MessageExtract;
    /** Keep the span open until the caller has read a streamed output member. */
    readonly hold?: SpanHold;
}
/** One operation's span facts, built once per operation. */
export interface OperationInfo {
    /** Span name, e.g. `S3.GetObject`. */
    readonly name: string;
    readonly kind: "client" | "producer" | "consumer";
    /** Fixed attributes: rpc.system.name, rpc.method, service and operation attributes. */
    readonly attributes: Readonly<Record<string, unknown>>;
    /** Input property and rule pairs, flattened. */
    readonly input: ReadonlyArray<readonly [property: string, rule: AttributeRule]>;
    readonly output: ReadonlyArray<readonly [property: string, rule: AttributeRule]>;
    readonly responseHeaders: ReadonlyArray<AttributeRule & {
        readonly header: string;
    }>;
    readonly onRequest: RequestHook | undefined;
    readonly propagate: ServiceTelemetry["propagate"];
    readonly copy: SpanConfig["copy"];
    readonly rename: SpanRename | undefined;
    readonly inject: SpanConfig["inject"];
    readonly extract: MessageExtract | undefined;
    readonly hold: SpanHold | undefined;
}
/**
 * The span facts of an operation from its generated `telemetry` and `span`
 * config. A `span` naming its `op` (a string is just the op) derives what it
 * leaves out, from the service's rules and the input schema:
 *
 *   name          `<service.prefix>.<op>`
 *   rpc.method    `<service.service>/<op>`
 *   url.template  the path of the input's `T.Http` uri, unless the service
 *                 or the span says `false`
 *   input         each `T.Label` property as `<service.labels>.<snake_case>`;
 *                 an explicit entry replaces it (`[]` records nothing)
 *
 * The generator emits only what differs from these rules, so the result is
 * exactly the model's `com.distilled.telemetry` traits. An operation
 * generated without traits gets its operation name, or
 * `distilled.operation`.
 */
export declare const operationInfo: (service: ServiceTelemetry | undefined, config: SpanConfig | string | undefined, operationName: string | undefined, inputAst?: AST.AST) => OperationInfo;
export declare const flatten: (rules: Readonly<Record<string, ReadonlyArray<AttributeRule>>> | undefined) => Array<readonly [string, AttributeRule]>;
/** Attributes the rules read from a value (the input or the output). Redacted values are skipped. */
export declare const readRules: (rules: OperationInfo["input"], value: unknown, set: (key: string, value: unknown) => void) => void;
/**
 * An opt-in observer of every operation call (`./telemetry-metrics.ts`):
 * wraps the call, whether or not a span is recorded.
 */
export type Measure = <A, E, R>(info: OperationInfo, effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
export declare const Metrics: Context.Reference<Measure | undefined>;
/** App callbacks on each recorded operation span (`./telemetry-hooks.ts`). */
export interface SpanHooks {
    readonly onStart?: (span: Tracer.Span, call: {
        readonly name: string;
        readonly method: unknown;
        readonly input: unknown;
    }) => void;
    readonly onEnd?: (span: Tracer.Span, exit: Exit.Exit<unknown, unknown>) => void;
}
export declare const Hooks: Context.Reference<SpanHooks | undefined>;
export declare const isDebug: (context: Context.Context<any>) => boolean;
/**
 * Record a fact about the current try (status, request id, host): on the
 * operation span, where the last try wins, and on the debug attempt span.
 */
export declare const annotate: (context: Context.Context<any>, key: string, value: unknown) => void;
/**
 * The request facts, recorded when it is sent (so a call that never gets a
 * response still has them): method, host and port. Host only: the full URL
 * can carry a presigned signature.
 */
export declare const annotateRequest: (context: Context.Context<any>, method: string, url: string) => void;
/**
 * The response facts, for every protocol: status, and the response
 * headers the service trait lists (request ids).
 */
export declare const annotateResponse: (context: Context.Context<any>, status: number, headers: Readonly<Record<string, string | undefined>>) => void;
/**
 * `client.execute(request)` for the traced call on this fiber: the
 * request facts before it is sent, the response facts when it returns.
 * Untraced calls pay two context reads, and forward the caller's trace
 * header if there is a parent span.
 */
export declare const execute: (context: Context.Context<any>, client: HttpClient.HttpClient, request: HttpClientRequest.HttpClientRequest) => Effect.Effect<HttpClientResponse.HttpClientResponse, HttpClientError.HttpClientError>;
export declare const tagOf: (error: unknown) => string;
/**
 * Try `n` failed with `error` and the call retries after `delayMs`. The
 * operation span carries the history, so a slow call shows why:
 *
 *   distilled.attempts        5 (tries so far, including the next one)
 *   distilled.retry.errors    ["SlowDown", "SlowDown", "SlowDown", "SlowDown"]
 *   distilled.retry.delay_ms  4087 (total backoff)
 *
 * A call that succeeds first time has none of them.
 */
export declare const retried: (context: Context.Context<any>, n: number, error: unknown, delayMs: number) => void;
/** Debug-only internal span around `effect`; `effect` itself otherwise. */
export declare const phase: <A, E, R>(context: Context.Context<any>, name: string, effect: Effect.Effect<A, E, R>, attributes?: Record<string, unknown>) => Effect.Effect<A, E, R>;
/**
 * Capture the caller of an operation, cheaply: `Error.captureStackTrace`
 * drops `entry` (the operation function the user called) and every frame
 * above it, so 2 frames are enough. V8 records them now and formats them
 * only if someone reads `.stack` (an error rendered with `Cause.pretty`, or
 * a debug span exporting `code.*`). Skipped when `Error.stackTraceLimit`
 * is 0, the rule Effect's own spans follow.
 */
export declare const captureCallSite: (entry: Function) => (() => string | undefined) | undefined;
/**
 * Build typed errors without a JS stack: their own
 * frames all point into distilled's response decoder (noise), and the
 * failure frame supplies the caller's line instead. Saves the frame capture
 * on every error. Defects keep their stacks. Use inline:
 *
 *   const saved = suppressStack();
 *   try { error = new Cls(...) } finally { restoreStack(saved) }
 */
export declare const suppressStack: () => number | undefined;
export declare const restoreStack: (saved: number | undefined) => void;
/**
 * One operation call (every attempt), with or without debug hooks.
 *
 *   no exporter: no span. Effect's HTTP span is switched off too (nobody
 *                would see it); the failure frame still names the call.
 *                Requests still carry the caller's parent span, if any,
 *                in the service's trace header (`traceparent`, X-Ray).
 *   operation:   one CLIENT span. Effect's HTTP span is switched off and
 *                protocols copy its facts (status, host, request id) onto
 *                this span, so one span per call.
 *   debug:       the span is the parent of Effect's HTTP span (one per
 *                attempt) and of distilled's internal spans.
 *
 * Failures set `error.type` to the error's tag; Effect sets the status.
 * An operation whose trait names a streamed output member (`stream`:
 * Bedrock ConverseStream) keeps the span open until the caller has read
 * that stream (`./telemetry-stream.ts`); every other span ends when the
 * call returns, after the response headers.
 */
export declare const operationSpan: <A, E, R>(fiber: Fiber.Fiber<unknown, unknown>, debug: DebugHooks | undefined, info: OperationInfo, callSite: (() => string | undefined) | undefined, input: unknown, run: (input: unknown) => Effect.Effect<A, E, R>, schemas?: OperationSchemas) => Effect.Effect<A, E, R>;
//# sourceMappingURL=telemetry.d.ts.map