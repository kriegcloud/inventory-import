import type { ScopedPlanStatusSession } from "alchemy/Report";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Path from "effect/Path";
import { PlatformError } from "effect/PlatformError";
import * as ChildProcessSpawner from "effect/process/ChildProcessSpawner";
import * as Redacted from "effect/Redacted";
import { type DockerImagePublicationError } from "./RegistryError.ts";
/** Credentials for a single image registry, scoped to a Docker command. */
export interface RegistryCredentials {
    /** Registry hostname, without a URL scheme. */
    server: string;
    /** Registry authentication username. */
    username: string;
    /** Registry password or access token. */
    password: string | Redacted.Redacted<string>;
}
declare const Docker_base: Context.ServiceClass<Docker, "@alchemy/Docker", {
    /** Runs a Docker command and returns the output. Use this to run a command that doesn't have a dedicated method. */
    readonly run: (args: Array<string>) => Effect.Effect<CommandOutput, PlatformError>;
    /** Writes build files and an inline Dockerfile to the given context directory. */
    readonly materialize: (options: {
        context: string;
        dockerfile: string;
        files: ReadonlyArray<{
            path: string;
            content: string | Uint8Array;
        }>;
    }) => Effect.Effect<void, PlatformError>;
    readonly container: {
        /** Creates a new container. */
        readonly create: (options: {
            name: string;
            image: string;
            volume: Array<string> | undefined;
            env: Record<string, string> | undefined;
            /** Overrides the image's ENTRYPOINT executable. */
            entrypoint?: string | undefined;
            /** Working directory for the container process. */
            workdir?: string | undefined;
            /** Image platform, e.g. `linux/amd64`. */
            platform?: string | undefined;
            /** Paths to Docker env files, forwarded as repeated `--env-file`. */
            "env-file"?: Array<string> | undefined;
            restart: "no" | "always" | "on-failure" | "unless-stopped";
            rm: boolean;
            "health-cmd": string | undefined;
            /** `--no-healthcheck`: disable any healthcheck defined by the image. */
            "no-healthcheck"?: boolean;
            "health-interval": string | undefined;
            "health-timeout": string | undefined;
            "health-retries": number | undefined;
            "health-start-period": string | undefined;
            "health-start-interval": string | undefined;
            "stop-timeout": string | undefined;
            p: Array<string> | undefined;
            /** `--add-host` entries, each `hostname:address`. */
            "add-host"?: Array<string> | undefined;
            /** Container hostname. */
            hostname?: string | undefined;
            /** Explicit DNS servers. */
            dns?: Array<string> | undefined;
            /** DNS search domains. */
            "dns-search"?: Array<string> | undefined;
            /** Resolver options such as `ndots:1`. */
            "dns-option"?: Array<string> | undefined;
            /** Docker network namespace, including `container:<id>`. */
            network?: string | undefined;
            /** IPC namespace mode. */
            ipc?: string | undefined;
            /** PID namespace mode. */
            pid?: string | undefined;
            /** Namespace-scoped sysctls. */
            sysctl?: Record<string, string> | undefined;
            /** Linux capabilities to add. */
            "cap-add"?: Array<string> | undefined;
            /** Linux capabilities to drop. */
            "cap-drop"?: Array<string> | undefined;
            /** Hard memory limit in Docker's byte-suffix format. */
            memory?: string | undefined;
            /** Shared-memory filesystem size (`/dev/shm`). */
            "shm-size"?: string | undefined;
            /** Combined memory-and-swap limit in Docker's byte-suffix format. */
            "memory-swap"?: string | undefined;
            /** Soft memory reservation for memory contention. */
            "memory-reservation"?: string | undefined;
            /** CPU quota, in cores. */
            cpus?: number | undefined;
            /** Per-container process and thread limit. */
            "pids-limit"?: number | undefined;
            /** Mount the root filesystem read-only. */
            "read-only"?: boolean | undefined;
            /** Enable Docker privileged mode. */
            privileged?: boolean | undefined;
            /** Security options such as `no-new-privileges` and seccomp/AppArmor profiles. */
            "security-opt"?: Array<string> | undefined;
            /** Per-container user namespace; "host" disables daemon user remapping. */
            userns?: string | undefined;
            /** Supplemental Linux groups. */
            "group-add"?: Array<string> | undefined;
            /** Per-process soft/hard resource limits. */
            ulimit?: Array<string> | undefined;
            /** Docker log driver. */
            "log-driver"?: string | undefined;
            /** Driver-specific Docker logging options. */
            "log-opt"?: Array<string> | undefined;
            /** Kernel OOM score adjustment. */
            "oom-score-adj"?: number | undefined;
            /** Signal used on container stop. */
            "stop-signal"?: string | undefined;
            /** Run Docker's tiny init process. */
            init?: boolean | undefined;
            /** Runtime UID/GID or named user. */
            user?: string | undefined;
            /** Keep stdin open when detached. */
            interactive?: boolean | undefined;
            /** Allocate a TTY. */
            tty?: boolean | undefined;
            /** GPU device request, e.g. `all`. */
            gpus?: string | undefined;
            /** Docker tmpfs mount expressions (target[:options]). */
            tmpfs?: Array<string> | undefined;
            /** Host devices in Docker's `host:container[:permissions]` form. */
            device?: Array<string> | undefined;
            command: Array<string> | undefined;
            label?: Record<string, string>;
            context?: string;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Inspects a container. */
        readonly inspect: (name: string, context?: string) => Effect.Effect<Docker.Container, PlatformError>;
        /** Removes a container. */
        readonly remove: (name: string, force?: boolean, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
        /** Starts a container. */
        readonly start: (name: string, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
        /** Stops a container. */
        readonly stop: (name: string, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
    };
    readonly image: {
        /**
         * Builds locally, or publishes to a registry when credentials are
         * supplied. With Buildx 0.26.0 or newer the image is exported straight
         * from BuildKit (`buildx build --push`); older plugins build into the
         * local image store and then `push`. If a session is provided, build
         * logs will be emitted as session notes.
         */
        readonly build: (options: {
            context: string;
            /** Image tags to build and publish together. */
            tag: string | [string, ...string[]];
            file?: string;
            platform?: string;
            target?: string;
            "build-arg"?: Record<string, string>;
            /**
             * BuildKit secrets, keyed by id (`RUN --mount=type=secret,id=<id>`).
             * Values reach `docker` through its environment, never its argv,
             * and are not written to the image.
             */
            secrets?: Record<string, string | Redacted.Redacted<string>>;
            "cache-from"?: Array<string>;
            "cache-to"?: Array<string>;
            args?: Array<string>;
            engineContext?: string;
            /** Registry auth for the build itself (base images, caches); publishes nothing. */
            credentials?: RegistryCredentials;
        }, session?: ScopedPlanStatusSession, registry?: RegistryCredentials) => Effect.Effect<CommandOutput, DockerImagePublicationError>;
        /** Pulls an image. */
        readonly pull: (ref: string, platform?: string, context?: string, session?: Pick<ScopedPlanStatusSession, "note">) => Effect.Effect<CommandOutput, PlatformError>;
        /**
         * Pushes an image to a registry. When `platform` is given, only that
         * platform's manifest is pushed (`docker push --platform`) — with the
         * containerd image store, a bare push sends every locally-present
         * variant of a multi-arch tag, so a stale other-arch variant in the
         * local cache would otherwise reach the registry. Engines whose store
         * doesn't support the flag fall back to a plain push (their local tag
         * is already narrowed by `pull --platform`).
         */
        readonly push: (ref: string, credentials: RegistryCredentials, platform?: string, context?: string, session?: Pick<ScopedPlanStatusSession, "note">) => Effect.Effect<CommandOutput, DockerImagePublicationError>;
        /** Tags an image. */
        readonly tag: (source: string, target: string, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
        /** Inspects an image. */
        readonly inspect: (ref: string, context?: string) => Effect.Effect<Docker.Image, PlatformError>;
        /** Removes an image. */
        readonly remove: (ref: string | Array<string>, force?: boolean, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
    };
    readonly volume: {
        /** Creates a new volume. */
        readonly create: (options: {
            name: string;
            driver?: string;
            opt?: Record<string, string>;
            label?: Record<string, string>;
            context?: string;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Removes a volume. */
        readonly remove: (name: string, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
        /** Inspects a volume. */
        readonly inspect: (name: string, context?: string) => Effect.Effect<Docker.Volume, PlatformError>;
    };
    readonly context: {
        /** Creates a new Docker context. */
        readonly create: (options: {
            name: string;
            description?: string;
            /** Raw value for `--docker`, for example `host=ssh://user@host`. */
            docker?: string;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Updates an existing Docker context. */
        readonly update: (options: {
            name: string;
            description?: string;
            /** Raw value for `--docker`, for example `host=ssh://user@host`. */
            docker?: string;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Inspects a Docker context. */
        readonly inspect: (name: string) => Effect.Effect<Docker.Context, PlatformError>;
        /** Removes a Docker context. */
        readonly remove: (name: string, force?: boolean) => Effect.Effect<CommandOutput, PlatformError>;
    };
    readonly network: {
        /** Creates a new network. */
        readonly create: (options: {
            name: string;
            driver: string;
            /** Whether the network is isolated from external connectivity. */
            internal?: boolean;
            /** Whether standalone containers may attach to the network. */
            attachable?: boolean;
            /** Explicitly enable or disable IPv4 address allocation. */
            ipv4?: boolean;
            ipv6?: boolean;
            /** Network driver options, passed as repeated `--opt` arguments. */
            opt?: Record<string, string>;
            /** Network IP Address Management settings. */
            ipam?: {
                driver?: string;
                options?: Record<string, string>;
                config?: Array<{
                    subnet: string;
                    gateway?: string;
                    ipRange?: string;
                    auxAddresses?: Record<string, string>;
                }>;
            };
            label?: Record<string, string>;
            context?: string;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Connects a container to a network. */
        readonly connect: (options: {
            network: string;
            container: string;
            alias?: string[];
            ip?: string;
            ip6?: string;
            "gw-priority"?: number;
            /** Driver options for the endpoint, not for the network resource. */
            "driver-opt"?: Record<string, string>;
            context?: string;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Disconnects a container from a network. */
        readonly disconnect: (options: {
            network: string;
            container: string;
            context?: string;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Inspects a network. */
        readonly inspect: (name: string, context?: string) => Effect.Effect<Docker.Network, PlatformError>;
        /** Removes a network. */
        readonly remove: (id: string, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
    };
    readonly swarm: {
        /** Initializes swarm mode on the engine (`docker swarm init`). */
        readonly init: (options: {
            context?: string;
            "advertise-addr"?: string;
            "listen-addr"?: string;
            "default-addr-pool"?: string[];
            "default-addr-pool-mask-length"?: number;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Reads the engine's swarm state (`docker info --format '{{json .Swarm}}'`). */
        readonly info: (context?: string) => Effect.Effect<Docker.SwarmInfo, PlatformError>;
        /** Leaves the swarm (`docker swarm leave`). */
        readonly leave: (force?: boolean, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
    };
    readonly service: {
        /** Creates a new service. */
        readonly create: (options: {
            name: string;
            image: string;
            context?: string;
            replicas?: number;
            "endpoint-mode"?: "vip" | "dnsrr";
            network?: string[];
            constraint?: string[];
            "replicas-max-per-node"?: number;
            "placement-pref"?: string[];
            "update-parallelism"?: number;
            "update-delay"?: string;
            "update-monitor"?: string;
            "update-failure-action"?: "pause" | "continue" | "rollback";
            "update-max-failure-ratio"?: number;
            "update-order"?: "stop-first" | "start-first";
            "rollback-parallelism"?: number;
            "rollback-delay"?: string;
            "rollback-monitor"?: string;
            "rollback-failure-action"?: "pause" | "continue" | "rollback";
            "rollback-max-failure-ratio"?: number;
            "rollback-order"?: "stop-first" | "start-first";
            "restart-condition"?: "none" | "on-failure" | "any";
            "restart-delay"?: string;
            "restart-max-attempts"?: number;
            "restart-window"?: string;
            "health-cmd"?: string;
            /** `--no-healthcheck`: disable any healthcheck defined by the image. */
            "no-healthcheck"?: boolean;
            "health-interval"?: string;
            "health-timeout"?: string;
            "health-retries"?: number;
            "health-start-period"?: string;
            "stop-grace-period"?: string;
            mount?: string[];
            secret?: string[];
            config?: string[];
            "read-only"?: boolean;
            publish?: string[];
            label?: Record<string, string>;
            env?: Record<string, string>;
            command?: string[];
            args?: string[];
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Updates an existing service. */
        readonly update: (options: {
            id: string;
            image: string;
            context?: string;
            /** `--force`: replace every task, even when the spec is unchanged. */
            force?: boolean;
            replicas?: number;
            "endpoint-mode"?: "vip" | "dnsrr";
            /** Networks to detach, by name or id; applied before `network-add`. */
            "network-rm"?: string[];
            "network-add"?: string[];
            "constraint-add"?: string[];
            "constraint-rm"?: string[];
            "replicas-max-per-node"?: number;
            "update-parallelism"?: number;
            "update-delay"?: string;
            "update-monitor"?: string;
            "update-failure-action"?: "pause" | "continue" | "rollback";
            "update-max-failure-ratio"?: number;
            "update-order"?: "stop-first" | "start-first";
            "rollback-parallelism"?: number;
            "rollback-delay"?: string;
            "rollback-monitor"?: string;
            "rollback-failure-action"?: "pause" | "continue" | "rollback";
            "rollback-max-failure-ratio"?: number;
            "rollback-order"?: "stop-first" | "start-first";
            "restart-condition"?: "none" | "on-failure" | "any";
            "restart-delay"?: string;
            "restart-max-attempts"?: number;
            "restart-window"?: string;
            "health-cmd"?: string;
            /** `--no-healthcheck`: disable any healthcheck defined by the image. */
            "no-healthcheck"?: boolean;
            "health-interval"?: string;
            "health-timeout"?: string;
            "health-retries"?: number;
            "health-start-period"?: string;
            "stop-grace-period"?: string;
            "mount-add"?: string[];
            /** Mount targets to remove. */
            "mount-rm"?: string[];
            "secret-add"?: string[];
            /** Secret names to remove; applied before `secret-add`. */
            "secret-rm"?: string[];
            "config-add"?: string[];
            /** Config names to remove; applied before `config-add`. */
            "config-rm"?: string[];
            "read-only"?: boolean;
            "publish-add"?: string[];
            /** Published ports to remove, as `target=<port>,protocol=<p>,mode=<m>`. */
            "publish-rm"?: string[];
            "label-add"?: Record<string, string>;
            "label-rm"?: string[];
            "env-add"?: Record<string, string>;
            /** Environment variable names to remove. */
            "env-rm"?: string[];
            args?: string;
        }) => Effect.Effect<CommandOutput, PlatformError>;
        /** Inspects a service. */
        readonly inspect: (id: string, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
        /** Removes a service. */
        readonly remove: (id: string, context?: string) => Effect.Effect<CommandOutput, PlatformError>;
    };
}>;
export declare class Docker extends Docker_base {
}
export declare namespace Docker {
    type ContextRef = string | {
        name: string;
    };
    /**
     * A reference to the Docker engine an operation runs against: a context
     * name, a `Docker.Context` resource, or a `Docker.Swarm` resource
     * (narrowed structurally by its `nodeId` attribute) — passing the swarm
     * also orders the operation after the swarm is initialized.
     */
    type EngineRef = ContextRef | {
        nodeId: string;
        context?: string;
    };
    interface SwarmInfo {
        NodeID: string;
        LocalNodeState: "inactive" | "pending" | "active" | "error" | "locked" | (string & {});
        ControlAvailable: boolean;
        Cluster?: {
            ID: string;
            CreatedAt?: string;
        } | null;
        RemoteManagers?: Array<{
            NodeID: string;
            Addr: string;
        }> | null;
        Managers?: number;
        Nodes?: number;
    }
    type ContainerStatus = "created" | "running" | "paused" | "restarting" | "removing" | "exited" | "dead";
    interface Container {
        Id: string;
        Image: string;
        Name?: string;
        State: {
            Status: ContainerStatus;
            /** Present when the container has a healthcheck. */
            Health?: {
                Status: "starting" | "healthy" | "unhealthy";
            };
        };
        Created: string;
        Config: {
            Image: string;
            Cmd: string[] | null;
            Env: string[] | null;
            Hostname?: string;
            Entrypoint?: string[] | null;
            WorkingDir?: string;
            Tty?: boolean;
            OpenStdin?: boolean;
            User?: string;
            StopSignal?: string;
            Labels: Record<string, string> | null;
            StopTimeout?: number;
            Healthcheck?: {
                Test: string[] | null;
                Interval?: number;
                Timeout?: number;
                Retries?: number;
                StartPeriod?: number;
                StartInterval?: number;
            } | null;
        };
        HostConfig: {
            PortBindings: Record<string, Array<{
                HostIp: string;
                HostPort: string;
            }> | null> | null;
            Binds: string[] | null;
            ExtraHosts: string[] | null;
            Dns?: string[];
            DnsSearch?: string[];
            DnsOptions?: string[];
            RestartPolicy: {
                Name: string;
                MaximumRetryCount: number;
            };
            AutoRemove: boolean;
            NetworkMode?: string;
            CapAdd?: string[] | null;
            CapDrop?: string[] | null;
            Memory?: number;
            ShmSize?: number;
            IpcMode?: string;
            PidMode?: string;
            Sysctls?: Record<string, string> | null;
            Privileged?: boolean;
            DeviceRequests?: Array<{
                Driver?: string;
                Count?: number;
                DeviceIDs?: string[] | null;
                Capabilities?: string[][];
                Options?: Record<string, string>;
            }> | null;
            MemorySwap?: number;
            MemoryReservation?: number;
            NanoCpus?: number;
            PidsLimit?: number;
            ReadonlyRootfs?: boolean;
            SecurityOpt?: string[] | null;
            UsernsMode?: string;
            GroupAdd?: string[] | null;
            Ulimits?: Array<{
                Name: string;
                Soft: number;
                Hard: number;
            }> | null;
            LogConfig?: {
                Type: string;
                Config: Record<string, string> | null;
            };
            OomScoreAdj?: number;
            Init?: boolean | null;
            Tmpfs?: Record<string, string> | null;
            Devices?: Array<{
                PathOnHost: string;
                PathInContainer: string;
                CgroupPermissions: string;
            }> | null;
        };
        AppArmorProfile?: string;
        NetworkSettings: {
            Networks: Record<string, {
                NetworkID: string;
                Aliases: string[] | null;
                IPAMConfig?: {
                    IPv4Address?: string;
                    IPv6Address?: string;
                } | null;
                IPAddress?: string;
                GlobalIPv6Address?: string;
                GwPriority?: number;
                DriverOpts?: Record<string, string> | null;
            }> | null;
            Ports?: Record<string, Array<{
                HostIp: string;
                HostPort: string;
            }> | null> | null;
        };
    }
    interface Image {
        Id: string;
        Created?: string;
        RepoTags?: string[] | null;
        RepoDigests?: string[] | null;
    }
    interface Volume {
        CreatedAt: string;
        Driver: string;
        Labels: Record<string, string> | null;
        Mountpoint: string;
        Name: string;
        Options: Record<string, string> | null;
        Scope: string;
    }
    interface Context {
        Name: string;
        Metadata?: {
            Description?: string;
        };
        Endpoints?: {
            docker?: string;
        };
    }
    interface Network {
        Name: string;
        Id: string;
        Created: string;
        Scope: string;
        Driver: string;
        Internal?: boolean;
        Attachable?: boolean;
        EnableIPv4?: boolean;
        EnableIPv6: boolean;
        Options?: Record<string, string> | null;
        IPAM?: {
            Driver?: string;
            Options?: Record<string, string> | null;
            Config?: Array<{
                Subnet: string;
                Gateway?: string;
                IPRange?: string;
                AuxiliaryAddresses?: Record<string, string> | null;
            }> | null;
        };
        Labels: Record<string, string> | null;
    }
}
export interface CommandOutput {
    exitCode: ChildProcessSpawner.ExitCode;
    stdout: string;
    stderr: string;
}
export interface DockerOptions {
    /**
     * The Docker-compatible CLI to run, e.g. `"podman"`. The `DOCKER_BIN`
     * environment variable, when set, overrides it (per machine or CI).
     * @default "docker"
     */
    bin?: string;
}
/**
 * Extra environment for every Docker CLI invocation, layered over the
 * process environment (per-call variables still win). Scope it with
 * `Effect.provideService(DockerEnvironment, { BUILDX_BUILDER: "ci" })` to
 * target a buildx builder or Docker context without mutating `process.env`.
 * @default {}
 */
export declare const DockerEnvironment: Context.Reference<Record<string, string>>;
/** The Docker CLI client, running `options.bin` (`DOCKER_BIN` overrides). */
export declare const dockerLive: (options?: DockerOptions) => Layer.Layer<Docker, never, ChildProcessSpawner.ChildProcessSpawner | FileSystem.FileSystem | Path.Path>;
/** The Docker CLI client, running `docker` (or `DOCKER_BIN`). */
export declare const DockerLive: Layer.Layer<Docker, never, ChildProcessSpawner.ChildProcessSpawner | FileSystem.FileSystem | Path.Path>;
export declare const dockerContextName: (context: Docker.ContextRef | undefined) => string | undefined;
/**
 * Resolve an {@link Docker.EngineRef} to a context name. A `Docker.Swarm`
 * reference (narrowed by its `nodeId` attribute) contributes the context the
 * swarm was initialized on.
 */
export declare const dockerEngineContextName: (ref: Docker.EngineRef | undefined) => string | undefined;
export declare const dockerPhysicalName: (id: string, props: {
    name?: string;
} | undefined, instanceId: string, maxLength?: number) => Effect.Effect<string, never, import("alchemy/ResourceContext").ResourceContext | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
export {};
//# sourceMappingURL=Docker.d.ts.map