import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidObjectIdentifier_base: S.TaggedErrorClass<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const NotAuthorized_base: S.TaggedErrorClass<"NotAuthorized", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NotAuthorized extends /*@__PURE__*/ NotAuthorized_base {
}
declare const ZoneNotFound_base: S.TaggedErrorClass<"ZoneNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ZoneNotFound extends /*@__PURE__*/ ZoneNotFound_base {
}
export interface GetSmartRoutingRequest {
    /** Specifies the zone associated with the API call. */
    zoneId: string;
}
export type SmartRoutingGetResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSmartRoutingResponse {
    /** Specifies the identifier of the Argo Smart Routing setting. */
    id: string;
    /** Specifies if the setting is editable. */
    editable: boolean;
    /** Specifies the enablement value of Argo Smart Routing. */
    value: SmartRoutingGetResponseValue;
    /** Specifies the time when the setting was last modified. */
    modifiedOn?: string | null | undefined;
}
export interface GetTieredCachingRequest {
    /** Identifier. */
    zoneId: string;
}
export type TieredCachingGetResponseId = "tiered_caching";
export type TieredCachingGetResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTieredCachingResponse {
    /** The identifier of the caching setting. */
    id: TieredCachingGetResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Tiered Cache zone setting. */
    value: TieredCachingGetResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null | undefined;
}
export type SmartRoutingEditRequestValue = "on" | "off";
export interface PatchSmartRoutingRequest {
    /** Specifies the zone associated with the API call. */
    zoneId: string;
    /** Specifies the enablement value of Argo Smart Routing. */
    value: SmartRoutingEditRequestValue | (string & {});
}
export type SmartRoutingEditResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSmartRoutingResponse {
    /** Specifies the identifier of the Argo Smart Routing setting. */
    id: string;
    /** Specifies if the setting is editable. */
    editable: boolean;
    /** Specifies the enablement value of Argo Smart Routing. */
    value: SmartRoutingEditResponseValue;
    /** Specifies the time when the setting was last modified. */
    modifiedOn?: string | null | undefined;
}
export type TieredCachingEditRequestValue = "on" | "off";
export interface PatchTieredCachingRequest {
    /** Identifier. */
    zoneId: string;
    /** Enables or disables Tiered Cache. */
    value: TieredCachingEditRequestValue | (string & {});
}
export type TieredCachingEditResponseId = "tiered_caching";
export type TieredCachingEditResponseValue = "on" | "off";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchTieredCachingResponse {
    /** The identifier of the caching setting. */
    id: TieredCachingEditResponseId;
    /** Whether the setting is editable. */
    editable: boolean;
    /** Value of the Tiered Cache zone setting. */
    value: TieredCachingEditResponseValue;
    /** Last time this setting was modified. */
    modifiedOn?: string | null | undefined;
}
export type GetSmartRoutingError = InvalidObjectIdentifier | NotAuthorized | Forbidden | CloudflareOpError;
/** Retrieves the value of Argo Smart Routing enablement setting. */
export declare const getSmartRouting: API.OperationMethod<GetSmartRoutingRequest, GetSmartRoutingResponse, GetSmartRoutingError, CloudflareOpContext>;
export type GetTieredCachingError = InvalidObjectIdentifier | ZoneNotFound | Forbidden | CloudflareOpError;
/** Retrieves whether Tiered Cache is enabled for a zone. Tiered Cache reduces origin traffic by serving lower-tier cache misses from upper-tier data centers before requesting content from your origin. */
export declare const getTieredCaching: API.OperationMethod<GetTieredCachingRequest, GetTieredCachingResponse, GetTieredCachingError, CloudflareOpContext>;
export type PatchSmartRoutingError = InvalidObjectIdentifier | NotAuthorized | Forbidden | CloudflareOpError;
/** Configures the value of the Argo Smart Routing enablement setting. */
export declare const patchSmartRouting: API.OperationMethod<PatchSmartRoutingRequest, PatchSmartRoutingResponse, PatchSmartRoutingError, CloudflareOpContext>;
export type PatchTieredCachingError = InvalidObjectIdentifier | Forbidden | CloudflareOpError;
/** Enables or disables Tiered Cache for a zone. Tiered Cache reduces origin traffic by serving lower-tier cache misses from upper-tier data centers before requesting content from your origin. */
export declare const patchTieredCaching: API.OperationMethod<PatchTieredCachingRequest, PatchTieredCachingResponse, PatchTieredCachingError, CloudflareOpContext>;
//# sourceMappingURL=argo.d.ts.map