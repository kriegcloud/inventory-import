import * as Effect from "effect/Effect";
/**
 * The parts of workerd's `cloudflare:workers` builtin module the shared
 * bridges read. Engines cast {@link workerdModule} to the full module type
 * from `@cloudflare/workers-types`.
 */
export interface WorkerdModule {
    readonly env: Record<string, unknown>;
    readonly [key: string]: any;
}
/** workerd's `cloudflare:workers` module (a stub outside workerd). */
declare const workerdModule: Effect.Effect<WorkerdModule>;
export default workerdModule;
//# sourceMappingURL=Module.d.ts.map