import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** List of team names within the organization to which to grant access to GitHub Copilot. */
export type AddCopilotSeatsForTeamsRequestSelectedTeamsList = Array<string>;
export interface AddCopilotSeatsForTeamsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** List of team names within the organization to which to grant access to GitHub Copilot. */
    selected_teams: AddCopilotSeatsForTeamsRequestSelectedTeamsList;
}
export interface AddCopilotSeatsForTeamsResponse {
    seats_created: number;
}
/** The usernames of the organization members to be granted access to GitHub Copilot. */
export type AddCopilotSeatsForUsersRequestSelectedUsernamesList = Array<string>;
export interface AddCopilotSeatsForUsersRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The usernames of the organization members to be granted access to GitHub Copilot. */
    selected_usernames: AddCopilotSeatsForUsersRequestSelectedUsernamesList;
}
export interface AddCopilotSeatsForUsersResponse {
    seats_created: number;
}
/** List of organization logins within the enterprise to enable Copilot cloud agent for. */
export type AddOrganizationsToEnterpriseCodingAgentPolicyRequestOrganizationsList = Array<string>;
/** The values of the custom property to match. */
export type AddOrganizationsToEnterpriseCodingAgentPolicyRequestCustomPropertiesItemValuesList = Array<string>;
export interface AddOrganizationsToEnterpriseCodingAgentPolicyRequestCustomPropertiesItem {
    /** The name of the custom property to filter by. */
    property_name: string;
    /** The values of the custom property to match. */
    values: AddOrganizationsToEnterpriseCodingAgentPolicyRequestCustomPropertiesItemValuesList;
}
/** List of custom property filters to match organizations. Organizations matching any of the specified property name/value pairs will be included. This is a one-time operation, setting the property on an organization in the future will not automatically update its coding agent policy. */
export type AddOrganizationsToEnterpriseCodingAgentPolicyRequestCustomPropertiesList = Array<AddOrganizationsToEnterpriseCodingAgentPolicyRequestCustomPropertiesItem>;
export interface AddOrganizationsToEnterpriseCodingAgentPolicyRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** List of organization logins within the enterprise to enable Copilot cloud agent for. */
    organizations?: AddOrganizationsToEnterpriseCodingAgentPolicyRequestOrganizationsList | undefined;
    /** List of custom property filters to match organizations. Organizations matching any of the specified property name/value pairs will be included. This is a one-time operation, setting the property on an organization in the future will not automatically update its coding agent policy. */
    custom_properties?: AddOrganizationsToEnterpriseCodingAgentPolicyRequestCustomPropertiesList | undefined;
}
export interface AddOrganizationsToEnterpriseCodingAgentPolicyResponse {
}
/** The names of teams from which to revoke access to GitHub Copilot. */
export type CancelCopilotSeatAssignmentForTeamsRequestSelectedTeamsList = Array<string>;
export interface CancelCopilotSeatAssignmentForTeamsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The names of teams from which to revoke access to GitHub Copilot. */
    selected_teams: CancelCopilotSeatAssignmentForTeamsRequestSelectedTeamsList;
}
export interface CancelCopilotSeatAssignmentForTeamsResponse {
    seats_cancelled: number;
}
/** The usernames of the organization members for which to revoke access to GitHub Copilot. */
export type CancelCopilotSeatAssignmentForUsersRequestSelectedUsernamesList = Array<string>;
export interface CancelCopilotSeatAssignmentForUsersRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The usernames of the organization members for which to revoke access to GitHub Copilot. */
    selected_usernames: CancelCopilotSeatAssignmentForUsersRequestSelectedUsernamesList;
}
export interface CancelCopilotSeatAssignmentForUsersResponse {
    seats_cancelled: number;
}
export interface CopilotContentExclusionForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type CopilotOrganizationContentExclusionDetailsValueList = Array<string>;
/** List all Copilot Content Exclusion rules for an organization. */
export type CopilotOrganizationContentExclusionDetails = {
    [key: string]: CopilotOrganizationContentExclusionDetailsValueList | undefined;
};
export type CopilotContentExclusionForOrganizationResponse = CopilotOrganizationContentExclusionDetails;
export interface CopilotEnterpriseOneDayUsageMetricsRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The day to request data for, in `YYYY-MM-DD` format. */
    day: string;
}
/** The URLs to download the Copilot usage metrics report for the enterprise/organization for the specified day. */
export type CopilotUsageMetrics1DayReportDownloadLinksList = Array<string>;
/** Links to download the Copilot usage metrics report for an enterprise/organization for a specific day. */
export interface CopilotUsageMetrics1DayReport {
    /** The URLs to download the Copilot usage metrics report for the enterprise/organization for the specified day. */
    download_links: CopilotUsageMetrics1DayReportDownloadLinksList;
    /** The day of the report in `YYYY-MM-DD` format. */
    report_day: string;
}
export interface CopilotEnterpriseReposOneDayReportRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The day to request data for, in `YYYY-MM-DD` format. */
    day: string;
}
export interface CopilotEnterpriseUsageMetricsRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
}
/** The URLs to download the latest Copilot usage metrics report for the enterprise/organization. */
export type CopilotUsageMetrics28DayReportDownloadLinksList = Array<string>;
/** Links to download the latest Copilot usage metrics report for an enterprise/organization. */
export interface CopilotUsageMetrics28DayReport {
    /** The URLs to download the latest Copilot usage metrics report for the enterprise/organization. */
    download_links: CopilotUsageMetrics28DayReportDownloadLinksList;
    /** The start date of the report period in `YYYY-MM-DD` format. */
    report_start_day: string;
    /** The end date of the report period in `YYYY-MM-DD` format. */
    report_end_day: string;
}
export interface CopilotEnterpriseUserTeamsOneDayReportRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The day to request data for, in `YYYY-MM-DD` format. */
    day: string;
}
export interface CopilotOrganizationOneDayUsageMetricsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The day to request data for, in `YYYY-MM-DD` format. */
    day: string;
}
export interface CopilotOrganizationReposOneDayReportRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The day to request data for, in `YYYY-MM-DD` format. */
    day: string;
}
export interface CopilotOrganizationUsageMetricsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface CopilotOrganizationUsersOneDayUsageMetricsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The day to request data for, in `YYYY-MM-DD` format. */
    day: string;
}
export interface CopilotOrganizationUsersUsageMetricsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface CopilotOrganizationUserTeamsOneDayReportRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The day to request data for, in `YYYY-MM-DD` format. */
    day: string;
}
export interface CopilotUsersOneDayUsageMetricsRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The day to request data for, in `YYYY-MM-DD` format. */
    day: string;
}
export interface CopilotUsersUsageMetricsRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
}
export interface DeleteCopilotTeamCustomizationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
}
export interface DeleteCopilotTeamCustomizationsResponse {
}
export interface DisableCopilotCodingAgentForRepositoryInOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface DisableCopilotCodingAgentForRepositoryInOrganizationResponse {
}
export interface EnableCopilotCodingAgentForRepositoryInOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface EnableCopilotCodingAgentForRepositoryInOrganizationResponse {
}
export interface GetCopilotCloudAgentConfigurationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** The user-supplied MCP server configuration for the repository, as a free-form JSON object. This will be set to `null` if no configuration has been set. The shape of a valid MCP configuration may evolve over time, so this property is intentionally not strictly typed. Clients should not assume a fixed schema. */
export type GetCopilotCloudAgentConfigurationResponseMcpConfigurationMap = {
    [key: string]: unknown | undefined;
};
/** The enabled review tools for Copilot cloud agent. */
export interface GetCopilotCloudAgentConfigurationResponseEnabledTools {
    /** Whether the CodeQL tool is enabled for the Copilot cloud agent. */
    codeql: boolean;
    /** Whether the Copilot code review tool is enabled for the Copilot cloud agent. */
    copilot_code_review: boolean;
    /** Whether the secret scanning tool is enabled for the Copilot cloud agent. */
    secret_scanning: boolean;
    /** Whether the dependency vulnerability checks tool is enabled for the Copilot cloud agent. */
    dependency_vulnerability_checks: boolean;
}
/** A list of custom allowlist entries, as hosts or URLs, that the firewall will allow the Copilot cloud agent to access. */
export type GetCopilotCloudAgentConfigurationResponseCustomAllowlistList = Array<string>;
export interface GetCopilotCloudAgentConfigurationResponse {
    /** The user-supplied MCP server configuration for the repository, as a free-form JSON object. This will be set to `null` if no configuration has been set. The shape of a valid MCP configuration may evolve over time, so this property is intentionally not strictly typed. Clients should not assume a fixed schema. */
    mcp_configuration: GetCopilotCloudAgentConfigurationResponseMcpConfigurationMap | null;
    /** The enabled review tools for Copilot cloud agent. */
    enabled_tools: GetCopilotCloudAgentConfigurationResponseEnabledTools;
    /** Whether Actions workflow approval is required for Copilot cloud agent pull requests. */
    require_actions_workflow_approval: boolean;
    /** Whether the firewall is enabled. */
    is_firewall_enabled: boolean;
    /** Whether the firewall recommended allowlist is enabled. */
    is_firewall_recommended_allowlist_enabled: boolean;
    /** A list of custom allowlist entries, as hosts or URLs, that the firewall will allow the Copilot cloud agent to access. */
    custom_allowlist: GetCopilotCloudAgentConfigurationResponseCustomAllowlistList;
    /** Whether automations are enabled in this repository. When true, users can create automations that automatically run agents on a schedule or in response to events like new issues or updated pull requests. */
    is_automations_enabled: boolean;
    /** Whether write access is required for automation triggers. When true, automations will only run if the user triggering the event has write access to the repository. When false, users can create automations that listen for events triggered by users without write access. */
    require_write_access_for_automation_triggers: boolean;
}
export interface GetCopilotCodingAgentPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The policy for which repositories can use Copilot cloud agent. Can be one of `all`, `selected`, or `none`. */
export type GetCopilotCodingAgentPermissionsOrganizationResponseEnabledRepositories = "all" | "selected" | "none";
export interface GetCopilotCodingAgentPermissionsOrganizationResponse {
    /** The policy for which repositories can use Copilot cloud agent. Can be one of `all`, `selected`, or `none`. */
    enabled_repositories: GetCopilotCodingAgentPermissionsOrganizationResponseEnabledRepositories;
    /** The URL for the selected repositories endpoint. Only present when `enabled_repositories` is `selected`. */
    selected_repositories_url?: string | undefined;
}
export interface GetCopilotOrganizationDetailsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The breakdown of Copilot Business seats for the organization. */
export interface CopilotOrganizationSeatBreakdown {
    /** The total number of seats being billed for the organization as of the current billing cycle. */
    total?: number | undefined;
    /** Seats added during the current billing cycle. */
    added_this_cycle?: number | undefined;
    /** The number of seats that are pending cancellation at the end of the current billing cycle. */
    pending_cancellation?: number | undefined;
    /** The number of users who have been invited to receive a Copilot seat through this organization. */
    pending_invitation?: number | undefined;
    /** The number of seats that have used Copilot during the current billing cycle. */
    active_this_cycle?: number | undefined;
    /** The number of seats that have not used Copilot during the current billing cycle. */
    inactive_this_cycle?: number | undefined;
}
/** The organization policy for allowing or blocking suggestions matching public code (duplication detection filter). */
export type CopilotOrganizationDetailsPublicCodeSuggestions = "allow" | "block" | "unconfigured";
/** The organization policy for allowing or disallowing Copilot Chat in the IDE. */
export type CopilotOrganizationDetailsIdeChat = "enabled" | "disabled" | "unconfigured";
/** The organization policy for allowing or disallowing Copilot features on GitHub.com. */
export type CopilotOrganizationDetailsPlatformChat = "enabled" | "disabled" | "unconfigured";
/** The organization policy for allowing or disallowing Copilot CLI. */
export type CopilotOrganizationDetailsCli = "enabled" | "disabled" | "unconfigured";
/** The mode of assigning new seats. */
export type CopilotOrganizationDetailsSeatManagementSetting = "assign_all" | "assign_selected" | "disabled" | "unconfigured";
/** The Copilot plan of the organization, or the parent enterprise, when applicable. */
export type CopilotOrganizationDetailsPlanType = "business" | "enterprise" | "access";
/** Information about the seat breakdown and policies set for an organization with a Copilot Business or Copilot Enterprise subscription. */
export interface CopilotOrganizationDetails {
    seat_breakdown: CopilotOrganizationSeatBreakdown;
    /** The organization policy for allowing or blocking suggestions matching public code (duplication detection filter). */
    public_code_suggestions: CopilotOrganizationDetailsPublicCodeSuggestions;
    /** The organization policy for allowing or disallowing Copilot Chat in the IDE. */
    ide_chat?: CopilotOrganizationDetailsIdeChat | undefined;
    /** The organization policy for allowing or disallowing Copilot features on GitHub.com. */
    platform_chat?: CopilotOrganizationDetailsPlatformChat | undefined;
    /** The organization policy for allowing or disallowing Copilot CLI. */
    cli?: CopilotOrganizationDetailsCli | undefined;
    /** The mode of assigning new seats. */
    seat_management_setting: CopilotOrganizationDetailsSeatManagementSetting;
    /** The Copilot plan of the organization, or the parent enterprise, when applicable. */
    plan_type?: CopilotOrganizationDetailsPlanType | undefined;
    [key: string]: unknown;
}
export interface GetCopilotSeatDetailsForUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** A GitHub organization. */
export interface NullableOrganizationSimple {
    login: string;
    id: number;
    node_id: string;
    url: string;
    repos_url: string;
    events_url: string;
    hooks_url: string;
    issues_url: string;
    members_url: string;
    public_members_url: string;
    avatar_url: string;
    description: string | null;
}
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
/** Whether team members will receive notifications when the team is mentioned. */
export type EnterpriseTeamNotificationSetting = "notifications_enabled" | "notifications_disabled";
/** Group of enterprise owners and/or members */
export interface EnterpriseTeam {
    id: number;
    name: string;
    description?: string | undefined;
    slug: string;
    url: string;
    /** Retired: this field will not be returned with GHEC enterprise teams. */
    sync_to_organizations?: string | undefined;
    organization_selection_type?: string | undefined;
    group_id: string | null;
    /** Retired: this field will not be returned with GHEC enterprise teams. */
    group_name?: string | null | undefined;
    html_url: string;
    members_url: string;
    created_at: string;
    updated_at: string;
    /** Whether team members will receive notifications when the team is mentioned. */
    notification_setting?: EnterpriseTeamNotificationSetting | undefined;
}
/** The team through which the assignee is granted access to GitHub Copilot, if applicable. */
export type CopilotSeatDetailsAssigningTeam = Team | EnterpriseTeam;
/** The Copilot plan of the organization, or the parent enterprise, when applicable. */
export type CopilotSeatDetailsPlanType = "business" | "enterprise" | "unknown" | "access";
/** Information about a Copilot Business seat assignment for a user, team, or organization. */
export interface CopilotSeatDetails {
    assignee?: NullableSimpleUser | null | undefined;
    organization?: NullableOrganizationSimple | null | undefined;
    /** The team through which the assignee is granted access to GitHub Copilot, if applicable. */
    assigning_team?: CopilotSeatDetailsAssigningTeam | null | undefined;
    /** The pending cancellation date for the seat, in `YYYY-MM-DD` format. This will be null unless the assignee's Copilot access has been canceled during the current billing cycle. If the seat has been cancelled, this corresponds to the start of the organization's next billing cycle. */
    pending_cancellation_date?: string | null | undefined;
    /** Timestamp of user's last GitHub Copilot activity, in ISO 8601 format. */
    last_activity_at?: string | null | undefined;
    /** Last editor that was used by the user for a GitHub Copilot completion. */
    last_activity_editor?: string | null | undefined;
    /** Timestamp of the last time the user authenticated with GitHub Copilot, in ISO 8601 format. */
    last_authenticated_at?: string | null | undefined;
    /** Timestamp of when the assignee was last granted access to GitHub Copilot, in ISO 8601 format. */
    created_at: string;
    /** **Closing down notice:** This field is no longer relevant and is closing down. Use the `created_at` field to determine when the assignee was last granted access to GitHub Copilot. Timestamp of when the assignee's GitHub Copilot access was last updated, in ISO 8601 format. */
    updated_at?: string | undefined;
    /** The Copilot plan of the organization, or the parent enterprise, when applicable. */
    plan_type?: CopilotSeatDetailsPlanType | undefined;
}
export interface GetCopilotTeamCustomizationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
}
/** The assignment state. */
export type GetCopilotTeamCustomizationsResponsePluginAssignmentsValueState = "defaultEnabled";
export interface GetCopilotTeamCustomizationsResponsePluginAssignmentsValue {
    /** The assignment state. */
    state?: GetCopilotTeamCustomizationsResponsePluginAssignmentsValueState | undefined;
}
/** Plugins assigned to the team, keyed by `PLUGIN@MARKETPLACE`. */
export type GetCopilotTeamCustomizationsResponsePluginAssignmentsMap = {
    [key: string]: GetCopilotTeamCustomizationsResponsePluginAssignmentsValue | undefined;
};
/** Additional plugin marketplaces available to the team, keyed by marketplace name. */
export type GetCopilotTeamCustomizationsResponseExtraKnownMarketplacesMap = {
    [key: string]: unknown | undefined;
};
export interface GetCopilotTeamCustomizationsResponse {
    /** Plugins assigned to the team, keyed by `PLUGIN@MARKETPLACE`. */
    pluginAssignments?: GetCopilotTeamCustomizationsResponsePluginAssignmentsMap | undefined;
    /** Additional plugin marketplaces available to the team, keyed by marketplace name. */
    extraKnownMarketplaces?: GetCopilotTeamCustomizationsResponseExtraKnownMarketplacesMap | undefined;
}
export interface GetEnterpriseCodeReviewPolicyRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
}
/** The configured policy. Null means the enterprise has not configured a policy. */
export type EnterpriseCopilotCodeReviewPolicyPolicyState = "enabled_for_all_organizations" | "disabled_for_all_organizations" | "configured_by_organization_admins";
/** The configured enterprise policy, rather than a user's effective Copilot code review access. */
export interface EnterpriseCopilotCodeReviewPolicy {
    /** The configured policy. Null means the enterprise has not configured a policy. */
    policy_state: EnterpriseCopilotCodeReviewPolicyPolicyState | null;
}
export interface GetOrganizationCodeReviewPolicyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The policy stored for the organization. Null means the organization has not configured a policy. */
export type OrganizationCopilotCodeReviewPolicyConfiguredState = "enabled" | "disabled";
/** The policy that applies to the organization after enterprise policy is considered. */
export type OrganizationCopilotCodeReviewPolicyEffectiveState = "enabled" | "disabled";
/** Whether the enterprise or the organization controls the policy. */
export type OrganizationCopilotCodeReviewPolicyManagedBy = "enterprise" | "organization";
/** The organization's configured and effective Copilot code review policy. */
export interface OrganizationCopilotCodeReviewPolicy {
    /** The policy stored for the organization. Null means the organization has not configured a policy. */
    configured_state: OrganizationCopilotCodeReviewPolicyConfiguredState | null;
    /** The policy that applies to the organization after enterprise policy is considered. */
    effective_state: OrganizationCopilotCodeReviewPolicyEffectiveState;
    /** Whether organization administrators can update the policy. */
    editable: boolean;
    /** Whether the enterprise or the organization controls the policy. */
    managed_by: OrganizationCopilotCodeReviewPolicyManagedBy;
}
export interface GetOrganizationCodeReviewRunnerRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The type of runner. `standard` uses GitHub-hosted runners. `labeled` uses runners that match the configured labels or runner group. */
export type OrganizationCopilotCodeReviewRunnerRunnerType = "standard" | "labeled";
/** The runner labels used for a labeled runner. */
export type OrganizationCopilotCodeReviewRunnerRunnerLabelsList = Array<string>;
/** Which configuration the values come from. `code_review` means the organization has saved a Copilot code review runner configuration. `coding_agent` means it has not, and the values are inherited from the organization's Copilot coding agent runner configuration. */
export type OrganizationCopilotCodeReviewRunnerConfiguredBy = "code_review" | "coding_agent";
/** The effective runner configuration that Copilot code review uses for the organization. */
export interface OrganizationCopilotCodeReviewRunner {
    /** The type of runner. `standard` uses GitHub-hosted runners. `labeled` uses runners that match the configured labels or runner group. */
    runner_type: OrganizationCopilotCodeReviewRunnerRunnerType;
    /** The runner labels used for a labeled runner. */
    runner_labels: OrganizationCopilotCodeReviewRunnerRunnerLabelsList;
    /** The runner group used for a labeled runner, or null when none is set. */
    runner_group_name: string | null;
    /** Whether repositories can use their own runner configuration. */
    allow_repository_customization: boolean;
    /** Which configuration the values come from. `code_review` means the organization has saved a Copilot code review runner configuration. `coding_agent` means it has not, and the values are inherited from the organization's Copilot coding agent runner configuration. */
    configured_by: OrganizationCopilotCodeReviewRunnerConfiguredBy;
}
export interface GetOrganizationCodeReviewSettingsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** Whether the enterprise or the organization controls the setting. */
export type OrganizationCopilotCodeReviewSettingsDefaultReviewEffortManagedBy = "enterprise" | "organization";
/** The default review effort for repositories in the organization that do not choose their own. For more information, see [Review effort level](https://docs.github.com/copilot/concepts/agent-capabilities/agent-powered-workflows-and-operations/code-review#review-effort-level). */
export interface OrganizationCopilotCodeReviewSettingsDefaultReviewEffort {
    /** The review effort stored for the organization. Null means the organization inherits the default, or has stored a value that is not currently available. */
    configured: string | null;
    /** The review effort that repositories without their own setting use. When that effort is not currently available for the organization, this reports the fallback effort instead. */
    effective: string;
    /** The review effort the organization inherits when it does not configure one. This is the enterprise default when one applies, otherwise GitHub's default. */
    github_default: string;
    /** Whether organization administrators can update the setting. */
    editable: boolean;
    /** Whether the enterprise or the organization controls the setting. */
    managed_by: OrganizationCopilotCodeReviewSettingsDefaultReviewEffortManagedBy;
}
/** The review efforts that can currently be set for this organization, in display order. */
export type OrganizationCopilotCodeReviewSettingsAvailableReviewEffortsList = Array<string>;
/** The organization's Copilot code review settings. */
export interface OrganizationCopilotCodeReviewSettings {
    /** The default review effort for repositories in the organization that do not choose their own. For more information, see [Review effort level](https://docs.github.com/copilot/concepts/agent-capabilities/agent-powered-workflows-and-operations/code-review#review-effort-level). */
    default_review_effort: OrganizationCopilotCodeReviewSettingsDefaultReviewEffort;
    /** The review efforts that can currently be set for this organization, in display order. */
    available_review_efforts: OrganizationCopilotCodeReviewSettingsAvailableReviewEffortsList;
}
export interface GetRepositoryCodeReviewSettingsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** The review effort for the repository. For more information, see [Review effort level](https://docs.github.com/copilot/concepts/agent-capabilities/agent-powered-workflows-and-operations/code-review#review-effort-level). */
export interface RepositoryCopilotCodeReviewSettingsReviewEffort {
    /** The review effort stored for the repository. Null means the repository inherits the default, or has stored a value that is not currently available. */
    configured: string | null;
    /** The review effort reviews use when the requester and the pull request do not choose one. When that effort is not currently available for the repository, this reports the effort reviews would use without it. */
    effective: string;
}
/** The review efforts that can currently be set for this repository, in display order. */
export type RepositoryCopilotCodeReviewSettingsAvailableReviewEffortsList = Array<string>;
/** Which review comment severities Copilot code review leaves out. `no_filter` keeps every comment, `low` leaves out low-severity comments, and `low_and_medium` leaves out low- and medium-severity comments. */
export type RepositoryCopilotCodeReviewSettingsSeverityFilter = "no_filter" | "low" | "low_and_medium";
/** The repository's Copilot code review settings. These settings tune reviews; they do not enable Copilot code review. */
export interface RepositoryCopilotCodeReviewSettings {
    /** The review effort for the repository. For more information, see [Review effort level](https://docs.github.com/copilot/concepts/agent-capabilities/agent-powered-workflows-and-operations/code-review#review-effort-level). */
    review_effort: RepositoryCopilotCodeReviewSettingsReviewEffort;
    /** The review efforts that can currently be set for this repository, in display order. */
    available_review_efforts: RepositoryCopilotCodeReviewSettingsAvailableReviewEffortsList;
    /** Which review comment severities Copilot code review leaves out. `no_filter` keeps every comment, `low` leaves out low-severity comments, and `low_and_medium` leaves out low- and medium-severity comments. */
    severity_filter: RepositoryCopilotCodeReviewSettingsSeverityFilter;
    /** Whether reviews use the repository's custom instructions. */
    custom_instructions_enabled: boolean;
    /** Whether reviews can use MCP servers. */
    mcp_enabled: boolean;
}
export interface ListCopilotCodingAgentSelectedRepositoriesForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: NullableSimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
export type ListCopilotCodingAgentSelectedRepositoriesForOrganizationResponseRepositoriesList = Array<MinimalRepository>;
export interface ListCopilotCodingAgentSelectedRepositoriesForOrganizationResponse {
    total_count: number;
    repositories: ListCopilotCodingAgentSelectedRepositoriesForOrganizationResponseRepositoriesList;
}
export interface ListCopilotSeatsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListCopilotSeatsResponseSeatsList = Array<CopilotSeatDetails>;
export interface ListCopilotSeatsResponse {
    /** Total number of Copilot seats for the organization currently being billed. */
    total_seats?: number | undefined;
    seats: ListCopilotSeatsResponseSeatsList;
}
/** List of organization logins within the enterprise to disable Copilot cloud agent for. */
export type RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequestOrganizationsList = Array<string>;
/** The values of the custom property to match. */
export type RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequestCustomPropertiesItemValuesList = Array<string>;
export interface RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequestCustomPropertiesItem {
    /** The name of the custom property to filter by. */
    property_name: string;
    /** The values of the custom property to match. */
    values: RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequestCustomPropertiesItemValuesList;
}
/** List of custom property filters to match organizations. Organizations matching any of the specified property name/value pairs will be included. This is a one-time operation, setting the property on an organization in the future will not automatically update its coding agent policy. */
export type RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequestCustomPropertiesList = Array<RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequestCustomPropertiesItem>;
export interface RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** List of organization logins within the enterprise to disable Copilot cloud agent for. */
    organizations?: RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequestOrganizationsList | undefined;
    /** List of custom property filters to match organizations. Organizations matching any of the specified property name/value pairs will be included. This is a one-time operation, setting the property on an organization in the future will not automatically update its coding agent policy. */
    custom_properties?: RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequestCustomPropertiesList | undefined;
}
export interface RemoveOrganizationsFromEnterpriseCodingAgentPolicyResponse {
}
/** The policy for which repositories can use Copilot cloud agent. Can be one of `all`, `selected`, or `none`. */
export type SetCopilotCodingAgentPermissionsOrganizationRequestEnabledRepositories = "all" | "selected" | "none";
export interface SetCopilotCodingAgentPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The policy for which repositories can use Copilot cloud agent. Can be one of `all`, `selected`, or `none`. */
    enabled_repositories: SetCopilotCodingAgentPermissionsOrganizationRequestEnabledRepositories | (string & {});
}
export interface SetCopilotCodingAgentPermissionsOrganizationResponse {
}
/** List of repository IDs to enable for Copilot cloud agent. */
export type SetCopilotCodingAgentSelectedRepositoriesForOrganizationRequestSelectedRepositoryIdsList = Array<number>;
export interface SetCopilotCodingAgentSelectedRepositoriesForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** List of repository IDs to enable for Copilot cloud agent. */
    selected_repository_ids: SetCopilotCodingAgentSelectedRepositoriesForOrganizationRequestSelectedRepositoryIdsList;
}
export interface SetCopilotCodingAgentSelectedRepositoriesForOrganizationResponse {
}
export type SetCopilotContentExclusionForOrganizationRequestBodyValueItemCase1IfAnyMatchList = Array<string>;
export interface SetCopilotContentExclusionForOrganizationRequestBodyValueItemCase1 {
    ifAnyMatch: SetCopilotContentExclusionForOrganizationRequestBodyValueItemCase1IfAnyMatchList;
}
export type SetCopilotContentExclusionForOrganizationRequestBodyValueItemCase2IfNoneMatchList = Array<string>;
export interface SetCopilotContentExclusionForOrganizationRequestBodyValueItemCase2 {
    ifNoneMatch: SetCopilotContentExclusionForOrganizationRequestBodyValueItemCase2IfNoneMatchList;
}
export type SetCopilotContentExclusionForOrganizationRequestBodyValueItem = string | SetCopilotContentExclusionForOrganizationRequestBodyValueItemCase1 | SetCopilotContentExclusionForOrganizationRequestBodyValueItemCase2;
export type SetCopilotContentExclusionForOrganizationRequestBodyValueList = Array<SetCopilotContentExclusionForOrganizationRequestBodyValueItem>;
export type SetCopilotContentExclusionForOrganizationRequestBodyMap = {
    [key: string]: SetCopilotContentExclusionForOrganizationRequestBodyValueList | undefined;
};
export interface SetCopilotContentExclusionForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    body: SetCopilotContentExclusionForOrganizationRequestBodyMap;
}
export interface SetCopilotContentExclusionForOrganizationResponse {
    message?: string | undefined;
}
/** The assignment state. */
export type SetCopilotTeamCustomizationsRequestPluginAssignmentsValueState = "defaultEnabled";
export interface SetCopilotTeamCustomizationsRequestPluginAssignmentsValue {
    /** The assignment state. */
    state?: SetCopilotTeamCustomizationsRequestPluginAssignmentsValueState | (string & {}) | undefined;
}
/** Plugins assigned to the team, keyed by `PLUGIN@MARKETPLACE`. */
export type SetCopilotTeamCustomizationsRequestPluginAssignmentsMap = {
    [key: string]: SetCopilotTeamCustomizationsRequestPluginAssignmentsValue | undefined;
};
/** Additional plugin marketplaces available to the team, keyed by marketplace name. */
export type SetCopilotTeamCustomizationsRequestExtraKnownMarketplacesMap = {
    [key: string]: unknown | undefined;
};
export interface SetCopilotTeamCustomizationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** Plugins assigned to the team, keyed by `PLUGIN@MARKETPLACE`. */
    pluginAssignments?: SetCopilotTeamCustomizationsRequestPluginAssignmentsMap | undefined;
    /** Additional plugin marketplaces available to the team, keyed by marketplace name. */
    extraKnownMarketplaces?: SetCopilotTeamCustomizationsRequestExtraKnownMarketplacesMap | undefined;
}
/** The assignment state. */
export type SetCopilotTeamCustomizationsResponsePluginAssignmentsValueState = "defaultEnabled";
export interface SetCopilotTeamCustomizationsResponsePluginAssignmentsValue {
    /** The assignment state. */
    state?: SetCopilotTeamCustomizationsResponsePluginAssignmentsValueState | undefined;
}
/** Plugins assigned to the team, keyed by `PLUGIN@MARKETPLACE`. */
export type SetCopilotTeamCustomizationsResponsePluginAssignmentsMap = {
    [key: string]: SetCopilotTeamCustomizationsResponsePluginAssignmentsValue | undefined;
};
/** Additional plugin marketplaces available to the team, keyed by marketplace name. */
export type SetCopilotTeamCustomizationsResponseExtraKnownMarketplacesMap = {
    [key: string]: unknown | undefined;
};
export interface SetCopilotTeamCustomizationsResponse {
    /** Plugins assigned to the team, keyed by `PLUGIN@MARKETPLACE`. */
    pluginAssignments?: SetCopilotTeamCustomizationsResponsePluginAssignmentsMap | undefined;
    /** Additional plugin marketplaces available to the team, keyed by marketplace name. */
    extraKnownMarketplaces?: SetCopilotTeamCustomizationsResponseExtraKnownMarketplacesMap | undefined;
}
/** The enterprise's Copilot code review policy. */
export type SetEnterpriseCodeReviewPolicyRequestPolicyState = "enabled_for_all_organizations" | "disabled_for_all_organizations" | "configured_by_organization_admins";
export interface SetEnterpriseCodeReviewPolicyRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The enterprise's Copilot code review policy. */
    policy_state: SetEnterpriseCodeReviewPolicyRequestPolicyState | (string & {});
}
export interface SetEnterpriseCodeReviewPolicyResponse {
}
/** The policy state for Copilot cloud agent in the enterprise. Can be one of `enabled_for_all_orgs`, `disabled_for_all_orgs`, `enabled_for_selected_orgs`, or `configured_by_org_admins`. */
export type SetEnterpriseCodingAgentPolicyRequestPolicyState = "enabled_for_all_orgs" | "disabled_for_all_orgs" | "enabled_for_selected_orgs" | "configured_by_org_admins";
export interface SetEnterpriseCodingAgentPolicyRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The policy state for Copilot cloud agent in the enterprise. Can be one of `enabled_for_all_orgs`, `disabled_for_all_orgs`, `enabled_for_selected_orgs`, or `configured_by_org_admins`. */
    policy_state: SetEnterpriseCodingAgentPolicyRequestPolicyState | (string & {});
}
export interface SetEnterpriseCodingAgentPolicyResponse {
}
/** The organization's Copilot code review policy. */
export type SetOrganizationCodeReviewPolicyRequestState = "enabled" | "disabled";
export interface SetOrganizationCodeReviewPolicyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The organization's Copilot code review policy. */
    state: SetOrganizationCodeReviewPolicyRequestState | (string & {});
}
export interface SetOrganizationCodeReviewPolicyResponse {
}
/** The type of runner. `standard` uses GitHub-hosted runners. `labeled` uses runners that match the labels or runner group. */
export type SetOrganizationCodeReviewRunnerRequestRunnerType = "standard" | "labeled";
/** The runner labels for a labeled runner. */
export type SetOrganizationCodeReviewRunnerRequestRunnerLabelsList = Array<string>;
export interface SetOrganizationCodeReviewRunnerRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of runner. `standard` uses GitHub-hosted runners. `labeled` uses runners that match the labels or runner group. */
    runner_type: SetOrganizationCodeReviewRunnerRequestRunnerType | (string & {});
    /** The runner labels for a labeled runner. */
    runner_labels?: SetOrganizationCodeReviewRunnerRequestRunnerLabelsList | null | undefined;
    /** The runner group for a labeled runner. */
    runner_group_name?: string | null | undefined;
    /** Whether repositories can use their own runner configuration. */
    allow_repository_customization?: boolean | undefined;
}
export interface UpdateOrganizationCodeReviewSettingsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The default review effort for repositories that do not choose their own. Use `inherit` to clear the organization's value. Only efforts listed in the settings' `available_review_efforts` are accepted, and a rejected effort's error message lists them. For more information, see [Review effort level](https://docs.github.com/copilot/concepts/agent-capabilities/agent-powered-workflows-and-operations/code-review#review-effort-level). */
    default_review_effort?: string | undefined;
}
/** Which review comment severities Copilot code review leaves out. Can only be set when the severity filter is available for the repository. */
export type UpdateRepositoryCodeReviewSettingsRequestSeverityFilter = "no_filter" | "low" | "low_and_medium";
export interface UpdateRepositoryCodeReviewSettingsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The review effort for the repository. Use `inherit` to clear the repository's value. Only efforts listed in the settings' `available_review_efforts` are accepted, and a rejected effort's error message lists them. For more information, see [Review effort level](https://docs.github.com/copilot/concepts/agent-capabilities/agent-powered-workflows-and-operations/code-review#review-effort-level). */
    review_effort?: string | undefined;
    /** Which review comment severities Copilot code review leaves out. Can only be set when the severity filter is available for the repository. */
    severity_filter?: UpdateRepositoryCodeReviewSettingsRequestSeverityFilter | (string & {}) | undefined;
    /** Whether reviews use the repository's custom instructions. */
    custom_instructions_enabled?: boolean | undefined;
    /** Whether reviews can use MCP servers. */
    mcp_enabled?: boolean | undefined;
}
export type AddCopilotSeatsForTeamsError = GithubOpError;
/** Add teams to the Copilot subscription for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Purchases a GitHub Copilot seat for all users within each specified team. The organization will be billed for each seat based on the organization's Copilot plan. For more information about Copilot pricing, see "[About billing for GitHub Copilot in your organization](https://docs.github.com/copilot/managing-copilot/managing-github-copilot-in-your-organization/managing-the-copilot-subscription-for-your-organization/about-billing-for-github-copilot-in-your-organization)." Only organization owners can purchase Copilot seats for their organization members. The organization must have a Copilot Business or Copilot Enterprise subscription and a configured suggestion matching policy. For more information about setting up a Copilot subscription, see "[Subscribing to Copilot for your organization](https://docs.github.com/copilot/managing-copilot/managing-github-copilot-in-your-organization/managing-the-copilot-subscription-for-your-organization/subscribing-to-copilot-for-your-organization)." For more information about setting a suggestion matching policy, see "[Managing policies for Copilot in your organization](https://docs.github.com/copilot/managing-copilot/managing-github-copilot-in-your-organization/setting-policies-for-copilot-in-your-organization/managing-policies-for-copilot-in-your-organization#policies-for-suggestion-matching)." The response contains the total number of new seats that were created and existing seats that were refreshed. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:org` scopes to use this endpoint. */
export declare const addCopilotSeatsForTeams: API.OperationMethod<AddCopilotSeatsForTeamsRequest, AddCopilotSeatsForTeamsResponse, AddCopilotSeatsForTeamsError, GithubOpContext>;
export type AddCopilotSeatsForUsersError = GithubOpError;
/** Add users to the Copilot subscription for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Purchases a GitHub Copilot seat for each user specified. The organization will be billed for each seat based on the organization's Copilot plan. For more information about Copilot pricing, see "[About billing for GitHub Copilot in your organization](https://docs.github.com/copilot/managing-copilot/managing-github-copilot-in-your-organization/managing-the-copilot-subscription-for-your-organization/about-billing-for-github-copilot-in-your-organization)." Only organization owners can purchase Copilot seats for their organization members. The organization must have a Copilot Business or Copilot Enterprise subscription and a configured suggestion matching policy. For more information about setting up a Copilot subscription, see "[Subscribing to Copilot for your organization](https://docs.github.com/copilot/managing-copilot/managing-github-copilot-in-your-organization/managing-the-copilot-subscription-for-your-organization/subscribing-to-copilot-for-your-organization)." For more information about setting a suggestion matching policy, see "[Managing policies for Copilot in your organization](https://docs.github.com/copilot/managing-copilot/managing-github-copilot-in-your-organization/setting-policies-for-copilot-in-your-organization/managing-policies-for-copilot-in-your-organization#policies-for-suggestion-matching)." The response contains the total number of new seats that were created and existing seats that were refreshed. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:org` scopes to use this endpoint. */
export declare const addCopilotSeatsForUsers: API.OperationMethod<AddCopilotSeatsForUsersRequest, AddCopilotSeatsForUsersResponse, AddCopilotSeatsForUsersError, GithubOpContext>;
export type AddOrganizationsToEnterpriseCodingAgentPolicyError = GithubOpError;
/** Add organizations to the enterprise coding agent policy Enables Copilot cloud agent for the specified organizations within the enterprise. The enterprise's coding agent policy must be set to `enabled_for_selected_orgs` before using this endpoint. Organizations can be specified by login or matched via custom properties. Only organizations that have Copilot enabled and belong to the enterprise will be affected. Only enterprise owners can add organizations to the coding agent policy. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:enterprise` scopes to use this endpoint. */
export declare const addOrganizationsToEnterpriseCodingAgentPolicy: API.OperationMethod<AddOrganizationsToEnterpriseCodingAgentPolicyRequest, AddOrganizationsToEnterpriseCodingAgentPolicyResponse, AddOrganizationsToEnterpriseCodingAgentPolicyError, GithubOpContext>;
export type CancelCopilotSeatAssignmentForTeamsError = GithubOpError;
/** Remove teams from the Copilot subscription for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Sets seats for all members of each team specified to "pending cancellation". This will cause the members of the specified team(s) to lose access to GitHub Copilot at the end of the current billing cycle unless they retain access through another team. For more information about disabling access to Copilot, see "[Revoking access to Copilot for members of your organization](https://docs.github.com/copilot/managing-copilot/managing-github-copilot-in-your-organization/managing-access-to-github-copilot-in-your-organization/revoking-access-to-copilot-for-members-of-your-organization)." Only organization owners can cancel Copilot seats for their organization members. The response contains the total number of seats set to "pending cancellation". OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:org` scopes to use this endpoint. */
export declare const cancelCopilotSeatAssignmentForTeams: API.OperationMethod<CancelCopilotSeatAssignmentForTeamsRequest, CancelCopilotSeatAssignmentForTeamsResponse, CancelCopilotSeatAssignmentForTeamsError, GithubOpContext>;
export type CancelCopilotSeatAssignmentForUsersError = GithubOpError;
/** Remove users from the Copilot subscription for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Sets seats for all users specified to "pending cancellation". This will cause the specified users to lose access to GitHub Copilot at the end of the current billing cycle unless they retain access through team membership. For more information about disabling access to Copilot, see "[Revoking access to Copilot for members of your organization](https://docs.github.com/copilot/managing-copilot/managing-github-copilot-in-your-organization/managing-access-to-github-copilot-in-your-organization/revoking-access-to-copilot-for-members-of-your-organization)." Only organization owners can cancel Copilot seats for their organization members. The response contains the total number of seats set to "pending cancellation". OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:org` scopes to use this endpoint. */
export declare const cancelCopilotSeatAssignmentForUsers: API.OperationMethod<CancelCopilotSeatAssignmentForUsersRequest, CancelCopilotSeatAssignmentForUsersResponse, CancelCopilotSeatAssignmentForUsersError, GithubOpContext>;
export type CopilotContentExclusionForOrganizationError = GithubOpError;
/** Get Copilot content exclusion rules for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Gets information about an organization's Copilot content exclusion path rules. To configure these settings, go to the organization's settings on GitHub. For more information, see "[Excluding content from GitHub Copilot](https://docs.github.com/copilot/managing-copilot/configuring-and-auditing-content-exclusion/excluding-content-from-github-copilot#configuring-content-exclusions-for-your-organization)." Organization owners can view details about Copilot content exclusion rules for the organization. OAuth app tokens and personal access tokens (classic) need either the `copilot` or `read:org` scopes to use this endpoint. > [!CAUTION] > * At this time, the API does not support comments. This endpoint will not return any comments in the existing rules. > * At this time, the API does not support duplicate keys. If your content exclusion configuration contains duplicate keys, the API will return only the last occurrence of that key. For example, if duplicate entries are present, only the final value will be included in the response. */
export declare const copilotContentExclusionForOrganization: API.OperationMethod<CopilotContentExclusionForOrganizationRequest, CopilotContentExclusionForOrganizationResponse, CopilotContentExclusionForOrganizationError, GithubOpContext>;
export type CopilotEnterpriseOneDayUsageMetricsError = GithubOpError;
/** Get Copilot enterprise usage metrics for a specific day Use this endpoint to retrieve download links for the Copilot enterprise usage metrics report for a specific day. The report provides comprehensive usage data for Copilot features across the enterprise. The report contains aggregated metrics for the specified day, including usage statistics for various Copilot features, user engagement data, and feature adoption metrics. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date of the report. The report covers a complete day for which data has been processed. Reports are available starting from October 10, 2025, and historical data can be accessed for up to 1 year from the current date. Enterprise owners, billing managers, and authorized users with fine-grained "View Enterprise Copilot Metrics" permission can retrieve Copilot metrics reports for the enterprise. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:enterprise` scopes to use this endpoint. */
export declare const copilotEnterpriseOneDayUsageMetrics: API.OperationMethod<CopilotEnterpriseOneDayUsageMetricsRequest, CopilotUsageMetrics1DayReport, CopilotEnterpriseOneDayUsageMetricsError, GithubOpContext>;
export type CopilotEnterpriseReposOneDayReportError = GithubOpError;
/** Get Copilot enterprise repository report for a specific day Use this endpoint to retrieve download links for the Copilot enterprise repository report for a specific day. The report provides per-repository pull request metrics for Copilot across the enterprise, with one entry per repository. The report contains repository-level pull request activity for the specified day, including the Copilot Coding Agent (CCA) and Copilot Code Review (CCR) breakdowns. Only repositories that had activity on the specified day are included. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date of the report. The report covers a complete day for which data has been processed. Enterprise owners, billing managers, and authorized users with fine-grained "View Enterprise Copilot Metrics" permission can retrieve Copilot metrics reports for the enterprise. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:enterprise` scopes to use this endpoint. */
export declare const copilotEnterpriseReposOneDayReport: API.OperationMethod<CopilotEnterpriseReposOneDayReportRequest, CopilotUsageMetrics1DayReport, CopilotEnterpriseReposOneDayReportError, GithubOpContext>;
export type CopilotEnterpriseUsageMetricsError = GithubOpError;
/** Get Copilot enterprise usage metrics Use this endpoint to retrieve download links for the latest 28-day enterprise Copilot usage metrics report. The report provides comprehensive usage data for Copilot features across the enterprise. The report contains aggregated metrics for the previous 28 days, including usage statistics for various Copilot features, user engagement data, and feature adoption metrics. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date range covered by the report. The report covers a complete 28-day period ending on the most recent day for which data has been processed. Enterprise owners, billing managers, and authorized users with fine-grained "View Enterprise Copilot Metrics" permission can retrieve Copilot metrics reports for the enterprise. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:enterprise` scopes to use this endpoint. */
export declare const copilotEnterpriseUsageMetrics: API.OperationMethod<CopilotEnterpriseUsageMetricsRequest, CopilotUsageMetrics28DayReport, CopilotEnterpriseUsageMetricsError, GithubOpContext>;
export type CopilotEnterpriseUserTeamsOneDayReportError = GithubOpError;
/** Get Copilot enterprise user-teams report for a specific day Use this endpoint to retrieve download links for the Copilot enterprise user-teams report for a specific day. The report provides user-team join data for Copilot across the enterprise, with one entry per user-team pair. The report contains user-team membership data for the specified day, enabling consumers to join with the existing enterprise user reports to compute team-level usage metrics. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date of the report. The report covers a complete day for which data has been processed. Enterprise owners, billing managers, and authorized users with fine-grained "View Enterprise Copilot Metrics" permission can retrieve Copilot metrics reports for the enterprise. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:enterprise` scopes to use this endpoint. */
export declare const copilotEnterpriseUserTeamsOneDayReport: API.OperationMethod<CopilotEnterpriseUserTeamsOneDayReportRequest, CopilotUsageMetrics1DayReport, CopilotEnterpriseUserTeamsOneDayReportError, GithubOpContext>;
export type CopilotOrganizationOneDayUsageMetricsError = GithubOpError;
/** Get Copilot organization usage metrics for a specific day Use this endpoint to retrieve download links for the Copilot organization usage metrics report for a specific day. The report provides comprehensive usage data for Copilot features across the organization. The report contains aggregated metrics for the specified day, including usage statistics for various Copilot features, user engagement data, and feature adoption metrics. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date of the report. The report covers a complete day for which data has been processed. Organization owners and authorized users with fine-grained "View Organization Copilot Metrics" permission can retrieve Copilot metrics reports for the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. For more information about organization metrics attribution, see [How are metrics attributed across organizations](https://docs.github.com/copilot/concepts/copilot-metrics#how-are-metrics-attributed-across-organizations). */
export declare const copilotOrganizationOneDayUsageMetrics: API.OperationMethod<CopilotOrganizationOneDayUsageMetricsRequest, CopilotUsageMetrics1DayReport, CopilotOrganizationOneDayUsageMetricsError, GithubOpContext>;
export type CopilotOrganizationReposOneDayReportError = GithubOpError;
/** Get Copilot organization repository report for a specific day Use this endpoint to retrieve download links for the Copilot organization repository report for a specific day. The report provides per-repository pull request metrics for Copilot across the organization, with one entry per repository. The report contains repository-level pull request activity for the specified day, including the Copilot Coding Agent (CCA) and Copilot Code Review (CCR) breakdowns. Only repositories that had activity on the specified day are included. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date of the report. The report covers a complete day for which data has been processed. Organization owners and authorized users with fine-grained "View Organization Copilot Metrics" permission can retrieve Copilot metrics reports for the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. For more information about organization metrics attribution, see [How are metrics attributed across organizations](https://docs.github.com/copilot/concepts/copilot-metrics#how-are-metrics-attributed-across-organizations). */
export declare const copilotOrganizationReposOneDayReport: API.OperationMethod<CopilotOrganizationReposOneDayReportRequest, CopilotUsageMetrics1DayReport, CopilotOrganizationReposOneDayReportError, GithubOpContext>;
export type CopilotOrganizationUsageMetricsError = GithubOpError;
/** Get Copilot organization usage metrics Use this endpoint to retrieve download links for the latest 28-day organization Copilot usage metrics report. The report provides comprehensive usage data for Copilot features across the organization. The report contains aggregated metrics for the previous 28 days, including usage statistics for various Copilot features, user engagement data, and feature adoption metrics. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date range covered by the report. The report covers a complete 28-day period ending on the most recent day for which data has been processed. Organization owners and authorized users with fine-grained "View Organization Copilot Metrics" permission can retrieve Copilot metrics reports for the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. For more information about organization metrics attribution, see [How are metrics attributed across organizations](https://docs.github.com/copilot/concepts/copilot-metrics#how-are-metrics-attributed-across-organizations). */
export declare const copilotOrganizationUsageMetrics: API.OperationMethod<CopilotOrganizationUsageMetricsRequest, CopilotUsageMetrics28DayReport, CopilotOrganizationUsageMetricsError, GithubOpContext>;
export type CopilotOrganizationUsersOneDayUsageMetricsError = GithubOpError;
/** Get Copilot organization users usage metrics for a specific day Use this endpoint to retrieve download links for the Copilot organization user usage metrics report for a specific day. The report provides detailed user-level usage data and engagement metrics for Copilot features across the organization. The report contains user-specific metrics for the specified day, including individual user engagement statistics, feature usage patterns, and adoption metrics broken down by user. This report allows authorized users to analyze Copilot usage at the user level to understand adoption patterns and identify opportunities for increased engagement. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date of the report. The report covers a complete day for which data has been processed. Organization owners and authorized users with fine-grained "View Organization Copilot Metrics" permission can retrieve Copilot metrics reports for the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. For more information about organization metrics attribution, see [How are metrics attributed across organizations](https://docs.github.com/copilot/concepts/copilot-metrics#how-are-metrics-attributed-across-organizations). */
export declare const copilotOrganizationUsersOneDayUsageMetrics: API.OperationMethod<CopilotOrganizationUsersOneDayUsageMetricsRequest, CopilotUsageMetrics1DayReport, CopilotOrganizationUsersOneDayUsageMetricsError, GithubOpContext>;
export type CopilotOrganizationUsersUsageMetricsError = GithubOpError;
/** Get Copilot organization users usage metrics Use this endpoint to retrieve download links for the latest 28-day organization users Copilot usage metrics report. The report provides detailed user-level usage data and engagement metrics for Copilot features across the organization. The report contains user-specific metrics for the previous 28 days, including individual user engagement statistics, feature usage patterns, and adoption metrics broken down by user. This report allows authorized users to analyze Copilot usage at the user level to understand adoption patterns and identify opportunities for increased engagement. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date range covered by the report. The report covers a complete 28-day period ending on the most recent day for which data has been processed. Organization owners and authorized users with fine-grained "View Organization Copilot Metrics" permission can retrieve Copilot metrics reports for the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. For more information about organization metrics attribution, see [How are metrics attributed across organizations](https://docs.github.com/copilot/concepts/copilot-metrics#how-are-metrics-attributed-across-organizations). */
export declare const copilotOrganizationUsersUsageMetrics: API.OperationMethod<CopilotOrganizationUsersUsageMetricsRequest, CopilotUsageMetrics28DayReport, CopilotOrganizationUsersUsageMetricsError, GithubOpContext>;
export type CopilotOrganizationUserTeamsOneDayReportError = GithubOpError;
/** Get Copilot organization user-teams report for a specific day Use this endpoint to retrieve download links for the Copilot organization user-teams report for a specific day. The report provides user-team join data for Copilot across the organization, with one entry per user-team pair. The report contains user-team membership data for the specified day, enabling consumers to join with the existing organization user reports to compute team-level usage metrics. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date of the report. The report covers a complete day for which data has been processed. Organization owners and authorized users with fine-grained "View Organization Copilot Metrics" permission can retrieve Copilot metrics reports for the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. For more information about organization metrics attribution, see [How are metrics attributed across organizations](https://docs.github.com/copilot/concepts/copilot-metrics#how-are-metrics-attributed-across-organizations). */
export declare const copilotOrganizationUserTeamsOneDayReport: API.OperationMethod<CopilotOrganizationUserTeamsOneDayReportRequest, CopilotUsageMetrics1DayReport, CopilotOrganizationUserTeamsOneDayReportError, GithubOpContext>;
export type CopilotUsersOneDayUsageMetricsError = GithubOpError;
/** Get Copilot users usage metrics for a specific day Use this endpoint to retrieve download links for the Copilot user usage metrics report for a specific day. The report provides detailed user-level usage data and engagement metrics for Copilot features across the enterprise. The report contains user-specific metrics for the specified day, including individual user engagement statistics, feature usage patterns, and adoption metrics broken down by user. This report allows authorized users to analyze Copilot usage at the user level to understand adoption patterns and identify opportunities for increased engagement. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date of the report. The report covers a complete day for which data has been processed. Reports are available starting from October 10, 2025, and historical data can be accessed for up to 1 year from the current date. Enterprise owners, billing managers, and authorized users with fine-grained "View Enterprise Copilot Metrics" permission can retrieve Copilot metrics reports for the enterprise. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:enterprise` scopes to use this endpoint. */
export declare const copilotUsersOneDayUsageMetrics: API.OperationMethod<CopilotUsersOneDayUsageMetricsRequest, CopilotUsageMetrics1DayReport, CopilotUsersOneDayUsageMetricsError, GithubOpContext>;
export type CopilotUsersUsageMetricsError = GithubOpError;
/** Get Copilot users usage metrics Use this endpoint to retrieve download links for the latest 28-day enterprise users Copilot usage metrics report. The report provides detailed user-level usage data and engagement metrics for Copilot features across the enterprise. The report contains user-specific metrics for the previous 28 days, including individual user engagement statistics, feature usage patterns, and adoption metrics broken down by user. This report allows authorized users to analyze Copilot usage at the user level to understand adoption patterns and identify opportunities for increased engagement. Reports are generated daily and made available for download through signed URLs with a limited expiration time. The response includes download links to the report files, along with the specific date range covered by the report. The report covers a complete 28-day period ending on the most recent day for which data has been processed. Enterprise owners, billing managers, and authorized users with fine-grained "View Enterprise Copilot Metrics" permission can retrieve Copilot metrics reports for the enterprise. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:enterprise` scopes to use this endpoint. */
export declare const copilotUsersUsageMetrics: API.OperationMethod<CopilotUsersUsageMetricsRequest, CopilotUsageMetrics28DayReport, CopilotUsersUsageMetricsError, GithubOpContext>;
export type DeleteCopilotTeamCustomizationsError = GithubOpError;
/** Delete Copilot customizations for a team > [!NOTE] > This endpoint is in public preview and is subject to change. Deletes the GitHub-managed Copilot customizations of a team. Deleting customizations that don't exist succeeds. The authenticated user must be an organization owner or a team maintainer. Teams that keep their customizations in a repository return `409`. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteCopilotTeamCustomizations: API.OperationMethod<DeleteCopilotTeamCustomizationsRequest, DeleteCopilotTeamCustomizationsResponse, DeleteCopilotTeamCustomizationsError, GithubOpContext>;
export type DisableCopilotCodingAgentForRepositoryInOrganizationError = GithubOpError;
/** Disable a repository for Copilot cloud agent in an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Removes a repository from the list of selected repositories enabled for Copilot cloud agent in an organization. This method can only be called when the cloud agent repository policy is set to `selected`. OAuth app tokens and personal access tokens (classic) need the `admin:org` scopes to use this endpoint. */
export declare const disableCopilotCodingAgentForRepositoryInOrganization: API.OperationMethod<DisableCopilotCodingAgentForRepositoryInOrganizationRequest, DisableCopilotCodingAgentForRepositoryInOrganizationResponse, DisableCopilotCodingAgentForRepositoryInOrganizationError, GithubOpContext>;
export type EnableCopilotCodingAgentForRepositoryInOrganizationError = GithubOpError;
/** Enable a repository for Copilot cloud agent in an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Adds a repository to the list of selected repositories enabled for Copilot cloud agent in an organization. This method can only be called when the cloud agent repository policy is set to `selected`. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const enableCopilotCodingAgentForRepositoryInOrganization: API.OperationMethod<EnableCopilotCodingAgentForRepositoryInOrganizationRequest, EnableCopilotCodingAgentForRepositoryInOrganizationResponse, EnableCopilotCodingAgentForRepositoryInOrganizationError, GithubOpContext>;
export type GetCopilotCloudAgentConfigurationError = GithubOpError;
/** Get Copilot cloud agent configuration for a repository > [!NOTE] > This endpoint is in public preview and is subject to change. Gets the Copilot cloud agent configuration for a repository, including MCP server configuration, enabled review tools, Actions workflow approval settings, and firewall configuration. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getCopilotCloudAgentConfiguration: API.OperationMethod<GetCopilotCloudAgentConfigurationRequest, GetCopilotCloudAgentConfigurationResponse, GetCopilotCloudAgentConfigurationError, GithubOpContext>;
export type GetCopilotCodingAgentPermissionsOrganizationError = GithubOpError;
/** Get Copilot cloud agent permissions for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Gets information about which repositories in an organization have been enabled or disabled for the Copilot cloud agent. Organization owners and members with a custom organization role that includes either the `View organization Copilot cloud agent settings` or `Manage organization Copilot cloud agent settings` permission can use this endpoint to view whether Copilot cloud agent is enabled for all repositories, selected repositories, or no repositories owned by the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const getCopilotCodingAgentPermissionsOrganization: API.OperationMethod<GetCopilotCodingAgentPermissionsOrganizationRequest, GetCopilotCodingAgentPermissionsOrganizationResponse, GetCopilotCodingAgentPermissionsOrganizationError, GithubOpContext>;
export type GetCopilotOrganizationDetailsError = GithubOpError;
/** Get Copilot seat information and settings for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Gets information about an organization's Copilot subscription, including seat breakdown and feature policies. To configure these settings, go to your organization's settings on GitHub.com. For more information, see "[Managing policies for Copilot in your organization](https://docs.github.com/copilot/managing-copilot/managing-policies-for-copilot-business-in-your-organization)." Only organization owners can view details about the organization's Copilot Business or Copilot Enterprise subscription. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:org` scopes to use this endpoint. */
export declare const getCopilotOrganizationDetails: API.OperationMethod<GetCopilotOrganizationDetailsRequest, CopilotOrganizationDetails, GetCopilotOrganizationDetailsError, GithubOpContext>;
export type GetCopilotSeatDetailsForUserError = GithubOpError;
/** Get Copilot seat assignment details for a user > [!NOTE] > This endpoint is in public preview and is subject to change. Gets the GitHub Copilot seat details for a member of an organization who currently has access to GitHub Copilot. The seat object contains information about the user's most recent Copilot activity. Users must have telemetry enabled in their IDE for Copilot in the IDE activity to be reflected in `last_activity_at`. For more information about activity data, see [Metrics data properties for GitHub Copilot](https://docs.github.com/copilot/reference/metrics-data). Only organization owners can view Copilot seat assignment details for members of their organization. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:org` scopes to use this endpoint. */
export declare const getCopilotSeatDetailsForUser: API.OperationMethod<GetCopilotSeatDetailsForUserRequest, CopilotSeatDetails, GetCopilotSeatDetailsForUserError, GithubOpContext>;
export type GetCopilotTeamCustomizationsError = GithubOpError;
/** Get Copilot customizations for a team > [!NOTE] > This endpoint is in public preview and is subject to change. Gets the GitHub-managed Copilot customizations of a team. The authenticated user must be an organization owner or a team maintainer. Teams that keep their customizations in a repository return `409`. OAuth app tokens and personal access tokens (classic) need the `admin:org` or `read:org` scope to use this endpoint. */
export declare const getCopilotTeamCustomizations: API.OperationMethod<GetCopilotTeamCustomizationsRequest, GetCopilotTeamCustomizationsResponse, GetCopilotTeamCustomizationsError, GithubOpContext>;
export type GetEnterpriseCodeReviewPolicyError = GithubOpError;
/** Get the Copilot code review policy for an enterprise Gets the configured Copilot code review policy for an enterprise. This does not return a user's effective access, preview approval controls, or automatic-review rulesets. Enterprise owners and users with the `read_enterprise_ai_controls` permission can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope. GitHub App tokens and fine-grained personal access tokens are not supported. */
export declare const getEnterpriseCodeReviewPolicy: API.OperationMethod<GetEnterpriseCodeReviewPolicyRequest, EnterpriseCopilotCodeReviewPolicy, GetEnterpriseCodeReviewPolicyError, GithubOpContext>;
export type GetOrganizationCodeReviewPolicyError = GithubOpError;
/** Get the Copilot code review policy for an organization Gets the configured and effective Copilot code review policy for an organization, whether organization administrators can edit it, and whether the enterprise or the organization manages it. This does not return review effort, repository settings, preview approval controls, or automatic-review rulesets. Organization owners can use this endpoint. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:org` scope. GitHub App tokens and fine-grained personal access tokens are not supported. */
export declare const getOrganizationCodeReviewPolicy: API.OperationMethod<GetOrganizationCodeReviewPolicyRequest, OrganizationCopilotCodeReviewPolicy, GetOrganizationCodeReviewPolicyError, GithubOpContext>;
export type GetOrganizationCodeReviewRunnerError = GithubOpError;
/** Get the Copilot code review runner configuration for an organization Gets the runner configuration that Copilot code review uses for an organization. Until the organization saves a Copilot code review runner configuration, the response reports the values inherited from the organization's Copilot coding agent runner configuration, with `configured_by` set to `coding_agent`. Organization owners can use this endpoint. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:org` scope. GitHub App tokens and fine-grained personal access tokens are not supported. */
export declare const getOrganizationCodeReviewRunner: API.OperationMethod<GetOrganizationCodeReviewRunnerRequest, OrganizationCopilotCodeReviewRunner, GetOrganizationCodeReviewRunnerError, GithubOpContext>;
export type GetOrganizationCodeReviewSettingsError = GithubOpError;
/** Get Copilot code review settings for an organization Gets the Copilot code review settings for an organization. Currently this is the default review effort that repositories in the organization use when they do not choose their own. For each setting, the response includes the configured value, the effective value, the default inherited when nothing is configured, whether organization administrators can edit it, and whether the enterprise or the organization manages it. Organization owners can use this endpoint. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:org` scope. GitHub App tokens and fine-grained personal access tokens are not supported. */
export declare const getOrganizationCodeReviewSettings: API.OperationMethod<GetOrganizationCodeReviewSettingsRequest, OrganizationCopilotCodeReviewSettings, GetOrganizationCodeReviewSettingsError, GithubOpContext>;
export type GetRepositoryCodeReviewSettingsError = GithubOpError;
/** Get Copilot code review settings for a repository Gets the Copilot code review settings for a repository. These settings tune how Copilot code review reviews pull requests in the repository. They do not enable Copilot code review. `review_effort.configured` is `null` when the repository inherits its review effort from the organization, the enterprise, or GitHub's default. `review_effort.effective` is the review effort that reviews use when the requester and the pull request do not choose one. Only review efforts available for the repository are reported; when reviews would use an unavailable effort, `review_effort.effective` is the review effort they would use without it. Repository administrators can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepositoryCodeReviewSettings: API.OperationMethod<GetRepositoryCodeReviewSettingsRequest, RepositoryCopilotCodeReviewSettings, GetRepositoryCodeReviewSettingsError, GithubOpContext>;
export type ListCopilotCodingAgentSelectedRepositoriesForOrganizationError = GithubOpError;
/** List repositories enabled for Copilot cloud agent in an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Lists the selected repositories that are enabled for Copilot cloud agent in an organization. Organization owners and members with a custom organization role that includes either the `View organization Copilot cloud agent settings` or `Manage organization Copilot cloud agent settings` permission can use this endpoint when the coding agent repository policy is set to `selected` to see which repositories have been enabled. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const listCopilotCodingAgentSelectedRepositoriesForOrganization: API.PaginatedOperationMethod<ListCopilotCodingAgentSelectedRepositoriesForOrganizationRequest, ListCopilotCodingAgentSelectedRepositoriesForOrganizationResponse, ListCopilotCodingAgentSelectedRepositoriesForOrganizationError, GithubOpContext, MinimalRepository>;
export type ListCopilotSeatsError = GithubOpError;
/** List all Copilot seat assignments for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Lists all Copilot seats for which an organization with a Copilot Business or Copilot Enterprise subscription is currently being billed. Only organization owners can view assigned seats. Each seat object contains information about the assigned user's most recent Copilot activity. Users must have telemetry enabled in their IDE for Copilot in the IDE activity to be reflected in `last_activity_at`. For more information about activity data, see [Metrics data properties for GitHub Copilot](https://docs.github.com/copilot/reference/metrics-data). OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `read:org` scopes to use this endpoint. */
export declare const listCopilotSeats: API.PaginatedOperationMethod<ListCopilotSeatsRequest, ListCopilotSeatsResponse, ListCopilotSeatsError, GithubOpContext, CopilotSeatDetails>;
export type RemoveOrganizationsFromEnterpriseCodingAgentPolicyError = GithubOpError;
/** Remove organizations from the enterprise coding agent policy Disables Copilot cloud agent for the specified organizations within the enterprise. The enterprise's coding agent policy must be set to `enabled_for_selected_orgs` before using this endpoint. Organizations can be specified by login or matched via custom properties. Only organizations that have Copilot enabled and belong to the enterprise will be affected. Only enterprise owners can remove organizations from the coding agent policy. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:enterprise` scopes to use this endpoint. */
export declare const removeOrganizationsFromEnterpriseCodingAgentPolicy: API.OperationMethod<RemoveOrganizationsFromEnterpriseCodingAgentPolicyRequest, RemoveOrganizationsFromEnterpriseCodingAgentPolicyResponse, RemoveOrganizationsFromEnterpriseCodingAgentPolicyError, GithubOpContext>;
export type SetCopilotCodingAgentPermissionsOrganizationError = GithubOpError;
/** Set Copilot cloud agent permissions for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Sets the policy for which repositories in an organization can use Copilot cloud agent. Organization owners can configure whether Copilot cloud agent is enabled for all repositories, selected repositories, or no repositories owned by the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setCopilotCodingAgentPermissionsOrganization: API.OperationMethod<SetCopilotCodingAgentPermissionsOrganizationRequest, SetCopilotCodingAgentPermissionsOrganizationResponse, SetCopilotCodingAgentPermissionsOrganizationError, GithubOpContext>;
export type SetCopilotCodingAgentSelectedRepositoriesForOrganizationError = GithubOpError;
/** Set selected repositories for Copilot cloud agent in an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Replaces the list of selected repositories that are enabled for Copilot cloud agent in an organization. This method can only be called when the cloud agent repository policy is set to `selected`. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setCopilotCodingAgentSelectedRepositoriesForOrganization: API.OperationMethod<SetCopilotCodingAgentSelectedRepositoriesForOrganizationRequest, SetCopilotCodingAgentSelectedRepositoriesForOrganizationResponse, SetCopilotCodingAgentSelectedRepositoriesForOrganizationError, GithubOpContext>;
export type SetCopilotContentExclusionForOrganizationError = GithubOpError;
/** Set Copilot content exclusion rules for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Sets Copilot content exclusion path rules for an organization. To configure these settings, go to the organization's settings on GitHub. For more information, see "[Excluding content from GitHub Copilot](https://docs.github.com/copilot/managing-copilot/configuring-and-auditing-content-exclusion/excluding-content-from-github-copilot#configuring-content-exclusions-for-your-organization)." Organization owners can set Copilot content exclusion rules for the organization. OAuth app tokens and personal access tokens (classic) need the `copilot` scope to use this endpoint. > [!CAUTION] > * At this time, the API does not support comments. When using this endpoint, any existing comments in your rules will be deleted. > * At this time, the API does not support duplicate keys. If you submit content exclusions through the API with duplicate keys, only the last occurrence will be saved. Earlier entries with the same key will be overwritten. */
export declare const setCopilotContentExclusionForOrganization: API.OperationMethod<SetCopilotContentExclusionForOrganizationRequest, SetCopilotContentExclusionForOrganizationResponse, SetCopilotContentExclusionForOrganizationError, GithubOpContext>;
export type SetCopilotTeamCustomizationsError = GithubOpError;
/** Set Copilot customizations for a team > [!NOTE] > This endpoint is in public preview and is subject to change. Replaces the GitHub-managed Copilot customizations of a team, creating them on the first write. The authenticated user must be an organization owner or a team maintainer. Teams that keep their customizations in a repository return `409`. Documents that fail validation return `422` with the reason. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setCopilotTeamCustomizations: API.OperationMethod<SetCopilotTeamCustomizationsRequest, SetCopilotTeamCustomizationsResponse, SetCopilotTeamCustomizationsError, GithubOpContext>;
export type SetEnterpriseCodeReviewPolicyError = GithubOpError;
/** Set the Copilot code review policy for an enterprise Sets the configured Copilot code review policy for an enterprise, using the same asynchronous propagation and notifications as enterprise settings. Policies that depend on Copilot code review keep their values. Enterprise owners and users with the `write_enterprise_ai_controls` permission can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope. GitHub App tokens and fine-grained personal access tokens are not supported. Standalone enterprises support enabled and disabled policies, but cannot delegate policy to organization administrators. Invalid or unsupported input does not change any policy. */
export declare const setEnterpriseCodeReviewPolicy: API.OperationMethod<SetEnterpriseCodeReviewPolicyRequest, SetEnterpriseCodeReviewPolicyResponse, SetEnterpriseCodeReviewPolicyError, GithubOpContext>;
export type SetEnterpriseCodingAgentPolicyError = GithubOpError;
/** Set the coding agent policy for an enterprise Sets the policy for Copilot cloud agent usage across an enterprise. Enterprise owners can configure whether Copilot cloud agent is enabled for all organizations, disabled for all organizations, configured by individual organization admins, or enabled for selected organizations only. Only enterprise owners can set the coding agent policy for their enterprise. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:enterprise` scopes to use this endpoint. */
export declare const setEnterpriseCodingAgentPolicy: API.OperationMethod<SetEnterpriseCodingAgentPolicyRequest, SetEnterpriseCodingAgentPolicyResponse, SetEnterpriseCodingAgentPolicyError, GithubOpContext>;
export type SetOrganizationCodeReviewPolicyError = GithubOpError;
/** Set the Copilot code review policy for an organization Sets the Copilot code review policy for an organization, using the same user settings propagation and notifications as organization settings. Policies that depend on Copilot code review keep their values. Organization owners can use this endpoint. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:org` scope. GitHub App tokens and fine-grained personal access tokens are not supported. When the enterprise manages the policy, the request fails with `409` and the code `POLICY_MANAGED_BY_ENTERPRISE`, even if the requested state matches the effective state. Invalid input and conflicts do not change any policy. */
export declare const setOrganizationCodeReviewPolicy: API.OperationMethod<SetOrganizationCodeReviewPolicyRequest, SetOrganizationCodeReviewPolicyResponse, SetOrganizationCodeReviewPolicyError, GithubOpContext>;
export type SetOrganizationCodeReviewRunnerError = GithubOpError;
/** Set the Copilot code review runner configuration for an organization Sets the runner configuration that Copilot code review uses for an organization. After a successful update, Copilot code review uses its own runner configuration and `configured_by` is `code_review`. A `labeled` runner requires at least one label in `runner_labels` or a `runner_group_name`. A `standard` runner does not accept labels or a runner group. When `allow_repository_customization` is omitted, the current effective value is kept. The whole request is validated before any change is made, so invalid input does not change the configuration. Organization owners can use this endpoint. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:org` scope. GitHub App tokens and fine-grained personal access tokens are not supported. */
export declare const setOrganizationCodeReviewRunner: API.OperationMethod<SetOrganizationCodeReviewRunnerRequest, OrganizationCopilotCodeReviewRunner, SetOrganizationCodeReviewRunnerError, GithubOpContext>;
export type UpdateOrganizationCodeReviewSettingsError = GithubOpError;
/** Update Copilot code review settings for an organization Updates the Copilot code review settings for an organization. Omitted settings are not changed. Set `default_review_effort` to `inherit` to clear the organization's value so repositories use the inherited default again. Changes use the same audit logging and telemetry as organization settings. Organization owners can use this endpoint. OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot` or `admin:org` scope. GitHub App tokens and fine-grained personal access tokens are not supported. When a submitted setting cannot be changed by the organization, the request fails with `409` and the code `SETTING_NOT_EDITABLE`. The whole request is validated before any change is made, so invalid input and conflicts do not change any setting. */
export declare const updateOrganizationCodeReviewSettings: API.OperationMethod<UpdateOrganizationCodeReviewSettingsRequest, OrganizationCopilotCodeReviewSettings, UpdateOrganizationCodeReviewSettingsError, GithubOpContext>;
export type UpdateRepositoryCodeReviewSettingsError = GithubOpError;
/** Update Copilot code review settings for a repository Updates the Copilot code review settings for a repository. These settings tune how Copilot code review reviews pull requests in the repository. They do not enable Copilot code review, and they can be stored while an enterprise or organization policy disables Copilot code review. Omitted settings are not changed. Set `review_effort` to `inherit` to clear the repository's review effort so it inherits the effort from the organization, the enterprise, or GitHub's default. The whole request is validated before any change is made, so invalid input does not change any setting. Changes use the same audit logging and telemetry as the repository settings page. Repository administrators can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const updateRepositoryCodeReviewSettings: API.OperationMethod<UpdateRepositoryCodeReviewSettingsRequest, RepositoryCopilotCodeReviewSettings, UpdateRepositoryCodeReviewSettingsError, GithubOpContext>;
//# sourceMappingURL=copilot.d.ts.map