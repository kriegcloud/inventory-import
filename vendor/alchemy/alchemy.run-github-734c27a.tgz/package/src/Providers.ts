import { GraphQLLive } from "@distilled.cloud/github/GraphQL";
import { Retry as GitHubRetry } from "@distilled.cloud/github/Retry";
import { CredentialsStoreLive } from "alchemy/Auth/Credentials";
import { ProfileStoreLive } from "alchemy/Auth/Profile";
import * as DeployRetry from "alchemy/DeployRetry";
import * as Provider from "alchemy/Provider";
import * as Layer from "effect/Layer";
import { type GitHubAuthOptions, makeGitHubAuth } from "./AuthProvider.ts";
import { BranchProtection, BranchProtectionProvider } from "./BranchProtection.ts";
import { Collaborator, CollaboratorProvider } from "./Collaborator.ts";
import { Comment, CommentProvider } from "./Comment.ts";
import * as Credentials from "./Credentials.ts";
import { Environment, EnvironmentProvider } from "./Environment.ts";
import { Issue, IssueProvider } from "./Issue.ts";
import { Label, LabelProvider } from "./Label.ts";
import { Milestone, MilestoneProvider } from "./Milestone.ts";
import { PersonalAccessToken, PersonalAccessTokenProvider } from "./PersonalAccessToken.ts";
import { PullRequest, PullRequestProvider } from "./PullRequest.ts";
import { Release, ReleaseProvider } from "./Release.ts";
import { Repository, RepositoryProvider } from "./Repository.ts";
import { Ruleset, RulesetProvider } from "./Ruleset.ts";
import { Secret, SecretProvider } from "./Secret.ts";
import { TeamAccess, TeamAccessProvider } from "./TeamAccess.ts";
import { Variable, VariableProvider } from "./Variable.ts";
import { Webhook, WebhookProvider } from "./Webhook.ts";
import { WikiPage, WikiPageProvider } from "./WikiPage.ts";

export { Credentials } from "./Credentials.ts";

export class Providers extends Provider.ProviderCollection<Providers>()("GitHub") {}

export type ProviderRequirements = Layer.Services<ReturnType<typeof providers>>;

export interface ProvidersOptions extends GitHubAuthOptions {}

/**
 * GitHub resource providers and the GitHub AuthProvider discovered by the CLI.
 *
 * Pass `baseUrl` to pin every GitHub resource to a GitHub Enterprise host
 * without relying on the auth provider's configuration:
 *
 * ```typescript
 * providers: GitHub.providers({ baseUrl: "github.example.com" })
 * ```
 *
 * The auth provider receives the same value, so the configure flow skips the
 * host prompt and authenticates against the pinned host (`gh auth token
 * --hostname`, enterprise token env vars). Individual resources can still
 * override the host per-resource via their own `baseUrl` prop.
 */
export const providers = (options?: ProvidersOptions) =>
  Layer.effect(
    Providers,
    Provider.collection([
      BranchProtection,
      Collaborator,
      Comment,
      Environment,
      Label,
      Milestone,
      Issue,
      PersonalAccessToken,
      PullRequest,
      Release,
      Repository,
      Ruleset,
      Secret,
      TeamAccess,
      Variable,
      Webhook,
      WikiPage,
    ]),
  ).pipe(
    Layer.provide(
      Layer.mergeAll(
        BranchProtectionProvider(),
        CollaboratorProvider(),
        CommentProvider(),
        EnvironmentProvider(),
        LabelProvider(),
        MilestoneProvider(),
        IssueProvider(),
        PersonalAccessTokenProvider(),
        PullRequestProvider(),
        ReleaseProvider(),
        RepositoryProvider(),
        RulesetProvider(),
        SecretProvider(),
        TeamAccessProvider(),
        VariableProvider(),
        WebhookProvider(),
        WikiPageProvider(),
      ),
    ),
    Layer.provideMerge(GraphQLLive),
    Layer.provideMerge(Layer.succeed(GitHubRetry, DeployRetry.policy)),
    Layer.provideMerge(Credentials.fromAuthProvider(options)),
    Layer.provideMerge(makeGitHubAuth(options)),
    Layer.provideMerge(ProfileStoreLive),
    Layer.provideMerge(CredentialsStoreLive),
    Layer.orDie,
  );
