import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const EndpointAlreadyExists_base: S.TaggedErrorClass<"EndpointAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class EndpointAlreadyExists extends /*@__PURE__*/ EndpointAlreadyExists_base {
}
declare const EndpointConfigAlreadyExists_base: S.TaggedErrorClass<"EndpointConfigAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class EndpointConfigAlreadyExists extends /*@__PURE__*/ EndpointConfigAlreadyExists_base {
}
declare const EndpointConfigNotFound_base: S.TaggedErrorClass<"EndpointConfigNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class EndpointConfigNotFound extends /*@__PURE__*/ EndpointConfigNotFound_base {
}
declare const EndpointNotFound_base: S.TaggedErrorClass<"EndpointNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class EndpointNotFound extends /*@__PURE__*/ EndpointNotFound_base {
}
declare const ModelAlreadyExists_base: S.TaggedErrorClass<"ModelAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ModelAlreadyExists extends /*@__PURE__*/ ModelAlreadyExists_base {
}
declare const ModelNotFound_base: S.TaggedErrorClass<"ModelNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ModelNotFound extends /*@__PURE__*/ ModelNotFound_base {
}
declare const ResourceInUse_base: S.TaggedErrorClass<"ResourceInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ResourceInUse extends /*@__PURE__*/ ResourceInUse_base {
}
declare const ResourceLimitExceeded_base: S.TaggedErrorClass<"ResourceLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ResourceLimitExceeded extends /*@__PURE__*/ ResourceLimitExceeded_base {
}
declare const ResourceNotFound_base: S.TaggedErrorClass<"ResourceNotFound", {
    readonly message: any;
}>;
export declare class ResourceNotFound extends /*@__PURE__*/ ResourceNotFound_base {
}
export type AssociationEntityArn = string;
export type AssociationEdgeType = "ContributedTo" | "AssociatedWith" | "DerivedFrom" | "Produced" | "SameAs" | (string & {});
export interface AddAssociationRequest {
    SourceArn?: string | undefined;
    DestinationArn?: string | undefined;
    AssociationType?: AssociationEdgeType | undefined;
}
export interface AddAssociationResponse {
    SourceArn?: string | undefined;
    DestinationArn?: string | undefined;
}
export type ResourceArn = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface AddTagsInput {
    ResourceArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface AddTagsOutput {
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
}
export type ExperimentEntityName = string;
export interface AssociateTrialComponentRequest {
    TrialComponentName?: string | undefined;
    TrialName?: string | undefined;
}
export type TrialComponentArn = string;
export type TrialArn = string;
export interface AssociateTrialComponentResponse {
    TrialComponentArn?: string | undefined;
    TrialArn?: string | undefined;
}
export type ClusterNameOrArn = string;
export type ClusterNodeId = string;
export type ClusterNetworkInterfaceId = string;
export interface AttachClusterNodeNetworkInterfaceRequest {
    ClusterName?: string | undefined;
    NodeId?: string | undefined;
    NetworkInterfaceId?: string | undefined;
}
export type ClusterArn = string;
export type ClusterNetworkInterfaceAttachmentId = string;
export interface AttachClusterNodeNetworkInterfaceResponse {
    ClusterArn: string;
    NodeId: string;
    NetworkInterfaceId: string;
    AttachmentId: string;
}
export type VolumeId = string;
export interface AttachClusterNodeVolumeRequest {
    ClusterArn?: string | undefined;
    NodeId?: string | undefined;
    VolumeId?: string | undefined;
}
export type VolumeAttachmentStatus = "attaching" | "attached" | "detaching" | "detached" | "busy" | (string & {});
export type VolumeDeviceName = string;
export interface AttachClusterNodeVolumeResponse {
    ClusterArn: string;
    NodeId: string;
    VolumeId: string;
    AttachTime: Date;
    Status: VolumeAttachmentStatus;
    DeviceName: string;
}
export type ClusterInstanceGroupName = string;
export type BatchAddIncrementCount = number;
export type ClusterAvailabilityZone = string;
export type ClusterAvailabilityZones = string[];
export type ClusterInstanceType = "ml.p4d.24xlarge" | "ml.p4de.24xlarge" | "ml.p5.48xlarge" | "ml.p5.4xlarge" | "ml.p6e-gb200.36xlarge" | "ml.trn1.32xlarge" | "ml.trn1n.32xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.12xlarge" | "ml.g5.16xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.c5.large" | "ml.c5.xlarge" | "ml.c5.2xlarge" | "ml.c5.4xlarge" | "ml.c5.9xlarge" | "ml.c5.12xlarge" | "ml.c5.18xlarge" | "ml.c5.24xlarge" | "ml.c5n.large" | "ml.c5n.2xlarge" | "ml.c5n.4xlarge" | "ml.c5n.9xlarge" | "ml.c5n.18xlarge" | "ml.m5.large" | "ml.m5.xlarge" | "ml.m5.2xlarge" | "ml.m5.4xlarge" | "ml.m5.8xlarge" | "ml.m5.12xlarge" | "ml.m5.16xlarge" | "ml.m5.24xlarge" | "ml.t3.medium" | "ml.t3.large" | "ml.t3.xlarge" | "ml.t3.2xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.16xlarge" | "ml.g6.12xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.gr6.4xlarge" | "ml.gr6.8xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.16xlarge" | "ml.g6e.12xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | "ml.p5e.48xlarge" | "ml.p5en.48xlarge" | "ml.p6-b200.48xlarge" | "ml.trn2.3xlarge" | "ml.trn2.48xlarge" | "ml.c6i.large" | "ml.c6i.xlarge" | "ml.c6i.2xlarge" | "ml.c6i.4xlarge" | "ml.c6i.8xlarge" | "ml.c6i.12xlarge" | "ml.c6i.16xlarge" | "ml.c6i.24xlarge" | "ml.c6i.32xlarge" | "ml.m6i.large" | "ml.m6i.xlarge" | "ml.m6i.2xlarge" | "ml.m6i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.12xlarge" | "ml.m6i.16xlarge" | "ml.m6i.24xlarge" | "ml.m6i.32xlarge" | "ml.r6i.large" | "ml.r6i.xlarge" | "ml.r6i.2xlarge" | "ml.r6i.4xlarge" | "ml.r6i.8xlarge" | "ml.r6i.12xlarge" | "ml.r6i.16xlarge" | "ml.r6i.24xlarge" | "ml.r6i.32xlarge" | "ml.i3en.large" | "ml.i3en.xlarge" | "ml.i3en.2xlarge" | "ml.i3en.3xlarge" | "ml.i3en.6xlarge" | "ml.i3en.12xlarge" | "ml.i3en.24xlarge" | "ml.m7i.large" | "ml.m7i.xlarge" | "ml.m7i.2xlarge" | "ml.m7i.4xlarge" | "ml.m7i.8xlarge" | "ml.m7i.12xlarge" | "ml.m7i.16xlarge" | "ml.m7i.24xlarge" | "ml.m7i.48xlarge" | "ml.r7i.large" | "ml.r7i.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.4xlarge" | "ml.r7i.8xlarge" | "ml.r7i.12xlarge" | "ml.r7i.16xlarge" | "ml.r7i.24xlarge" | "ml.r7i.48xlarge" | "ml.r5d.16xlarge" | "ml.g7e.2xlarge" | "ml.g7e.4xlarge" | "ml.g7e.8xlarge" | "ml.g7e.12xlarge" | "ml.g7e.24xlarge" | "ml.g7e.48xlarge" | "ml.p6-b300.48xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.c6g.medium" | "ml.c6g.large" | "ml.c6g.xlarge" | "ml.c6g.2xlarge" | "ml.c6g.4xlarge" | "ml.c6g.8xlarge" | "ml.c6g.12xlarge" | "ml.c6g.16xlarge" | "ml.c7g.medium" | "ml.c7g.large" | "ml.c7g.xlarge" | "ml.c7g.2xlarge" | "ml.c7g.4xlarge" | "ml.c7g.8xlarge" | "ml.c7g.12xlarge" | "ml.c7g.16xlarge" | "ml.c8g.medium" | "ml.c8g.large" | "ml.c8g.xlarge" | "ml.c8g.2xlarge" | "ml.c8g.4xlarge" | "ml.c8g.8xlarge" | "ml.c8g.12xlarge" | "ml.c8g.16xlarge" | "ml.c8g.24xlarge" | "ml.c8g.48xlarge" | "ml.c6a.large" | "ml.c6a.xlarge" | "ml.c6a.2xlarge" | "ml.c6a.4xlarge" | "ml.c6a.8xlarge" | "ml.c6a.12xlarge" | "ml.c6a.16xlarge" | "ml.c6a.24xlarge" | "ml.c6a.32xlarge" | "ml.c6a.48xlarge" | "ml.m6a.large" | "ml.m6a.xlarge" | "ml.m6a.2xlarge" | "ml.m6a.4xlarge" | "ml.m6a.8xlarge" | "ml.m6a.12xlarge" | "ml.m6a.16xlarge" | "ml.m6a.24xlarge" | "ml.m6a.32xlarge" | "ml.m6a.48xlarge" | "ml.m6g.medium" | "ml.m6g.large" | "ml.m6g.xlarge" | "ml.m6g.2xlarge" | "ml.m6g.4xlarge" | "ml.m6g.8xlarge" | "ml.m6g.12xlarge" | "ml.m6g.16xlarge" | "ml.m7g.medium" | "ml.m7g.large" | "ml.m7g.xlarge" | "ml.m7g.2xlarge" | "ml.m7g.4xlarge" | "ml.m7g.8xlarge" | "ml.m7g.12xlarge" | "ml.m7g.16xlarge" | "ml.m8g.medium" | "ml.m8g.large" | "ml.m8g.xlarge" | "ml.m8g.2xlarge" | "ml.m8g.4xlarge" | "ml.m8g.8xlarge" | "ml.m8g.12xlarge" | "ml.m8g.16xlarge" | "ml.m8g.24xlarge" | "ml.m8g.48xlarge" | "ml.g7.2xlarge" | "ml.g7.4xlarge" | "ml.g7.8xlarge" | "ml.g7.12xlarge" | "ml.g7.24xlarge" | "ml.g7.48xlarge" | "ml.c8a.16xlarge" | "ml.m8a.16xlarge" | (string & {});
export type ClusterInstanceTypes = ClusterInstanceType[];
export interface AddClusterNodeSpecification {
    InstanceGroupName: string;
    IncrementTargetCountBy: number;
    AvailabilityZones?: string[] | undefined;
    InstanceTypes?: ClusterInstanceType[] | undefined;
}
export type AddClusterNodeSpecificationList = AddClusterNodeSpecification[];
export interface BatchAddClusterNodesRequest {
    ClusterName: string;
    ClientToken?: string | undefined;
    NodesToAdd?: AddClusterNodeSpecification[] | undefined;
}
export type ClusterNodeLogicalId = string;
export type ClusterInstanceStatus = "Running" | "Failure" | "Pending" | "ShuttingDown" | "SystemUpdating" | "DeepHealthCheckInProgress" | "NotFound" | (string & {});
export interface NodeAdditionResult {
    NodeLogicalId: string;
    InstanceGroupName: string;
    Status: ClusterInstanceStatus;
    AvailabilityZones?: string[] | undefined;
    InstanceTypes?: ClusterInstanceType[] | undefined;
}
export type NodeAdditionResultList = NodeAdditionResult[];
export type InstanceGroupName = string;
export type BatchAddClusterNodesErrorCode = "InstanceGroupNotFound" | "InvalidInstanceGroupStatus" | "IncompatibleAvailabilityZones" | "IncompatibleInstanceTypes" | (string & {});
export type BatchAddFailureCount = number;
export interface BatchAddClusterNodesError_ {
    InstanceGroupName: string;
    ErrorCode: BatchAddClusterNodesErrorCode;
    FailedCount: number;
    AvailabilityZones?: string[] | undefined;
    InstanceTypes?: ClusterInstanceType[] | undefined;
    Message?: string | undefined;
}
export type BatchAddClusterNodesErrorList = BatchAddClusterNodesError_[];
export interface BatchAddClusterNodesResponse {
    Successful: NodeAdditionResult[];
    Failed: BatchAddClusterNodesError_[];
}
export type ClusterNodeIds = string[];
export type ClusterNodeLogicalIdList = string[];
export interface BatchDeleteClusterNodesRequest {
    ClusterName?: string | undefined;
    NodeIds?: string[] | undefined;
    NodeLogicalIds?: string[] | undefined;
}
export type BatchDeleteClusterNodesErrorCode = "NodeIdNotFound" | "InvalidNodeStatus" | "NodeIdInUse" | (string & {});
export interface BatchDeleteClusterNodesError_ {
    Code?: BatchDeleteClusterNodesErrorCode | undefined;
    Message?: string | undefined;
    NodeId?: string | undefined;
}
export type BatchDeleteClusterNodesErrorList = BatchDeleteClusterNodesError_[];
export interface BatchDeleteClusterNodeLogicalIdsError {
    Code?: BatchDeleteClusterNodesErrorCode | undefined;
    Message?: string | undefined;
    NodeLogicalId?: string | undefined;
}
export type BatchDeleteClusterNodeLogicalIdsErrorList = BatchDeleteClusterNodeLogicalIdsError[];
export interface BatchDeleteClusterNodesResponse {
    Failed?: (BatchDeleteClusterNodesError & {
        Code: BatchDeleteClusterNodesErrorCode;
        Message: string;
        NodeId: ClusterNodeId;
    })[] | undefined;
    Successful?: string[] | undefined;
    FailedNodeLogicalIds?: (BatchDeleteClusterNodeLogicalIdsError & {
        Code: BatchDeleteClusterNodesErrorCode;
        Message: string;
        NodeLogicalId: ClusterNodeLogicalId;
    })[] | undefined;
    SuccessfulNodeLogicalIds?: string[] | undefined;
}
export type ModelPackageArn = string;
export type ModelPackageArnList = string[];
export interface BatchDescribeModelPackageInput {
    ModelPackageArnList?: string[] | undefined;
}
export type EntityName = string;
export type ModelPackageVersion = number;
export type EntityDescription = string;
export type CreationTime = Date;
export type ContainerHostname = string;
export type ContainerImage = string;
export type ImageDigest = string;
export type Url = string;
export type S3ModelUri = string;
export type S3ModelDataType = "S3Prefix" | "S3Object" | (string & {});
export type ModelCompressionType = "None" | "Gzip" | (string & {});
export type AcceptEula = boolean;
export interface ModelAccessConfig {
    AcceptEula?: boolean | undefined;
}
export type HubContentArn = string;
export interface InferenceHubAccessConfig {
    HubContentArn?: string | undefined;
}
export interface S3ModelDataSource {
    S3Uri?: string | undefined;
    S3DataType?: S3ModelDataType | undefined;
    CompressionType?: ModelCompressionType | undefined;
    ModelAccessConfig?: ModelAccessConfig | undefined;
    HubAccessConfig?: InferenceHubAccessConfig | undefined;
    ManifestS3Uri?: string | undefined;
    ETag?: string | undefined;
    ManifestEtag?: string | undefined;
}
export interface ModelDataSource {
    S3DataSource?: S3ModelDataSource | undefined;
}
export type ProductId = string;
export type EnvironmentKey = string;
export type EnvironmentValue = string;
export type EnvironmentMap = {
    [key: string]: string | undefined;
};
export type DataInputConfig = string;
export interface ModelInput {
    DataInputConfig?: string | undefined;
}
export type ModelPackageFrameworkVersion = string;
export type AdditionalModelChannelName = string;
export interface AdditionalModelDataSource {
    ChannelName?: string | undefined;
    S3DataSource?: S3ModelDataSource | undefined;
}
export type AdditionalModelDataSources = AdditionalModelDataSource[];
export type AdditionalS3DataSourceDataType = "S3Object" | "S3Prefix" | (string & {});
export type S3Uri = string;
export type CompressionType = "None" | "Gzip" | (string & {});
export interface AdditionalS3DataSource {
    S3DataType?: AdditionalS3DataSourceDataType | undefined;
    S3Uri?: string | undefined;
    CompressionType?: CompressionType | undefined;
    ETag?: string | undefined;
}
export type HubContentName = string;
export type HubContentVersion = string;
export type RecipeName = string;
export interface BaseModel {
    HubContentName?: string | undefined;
    HubContentVersion?: string | undefined;
    RecipeName?: string | undefined;
}
export interface ModelPackageContainerDefinition {
    ContainerHostname?: string | undefined;
    Image?: string | undefined;
    ImageDigest?: string | undefined;
    ModelDataUrl?: string | undefined;
    ModelDataSource?: ModelDataSource | undefined;
    ProductId?: string | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    ModelInput?: ModelInput | undefined;
    Framework?: string | undefined;
    FrameworkVersion?: string | undefined;
    NearestModelName?: string | undefined;
    AdditionalModelDataSources?: AdditionalModelDataSource[] | undefined;
    AdditionalS3DataSource?: AdditionalS3DataSource | undefined;
    ModelDataETag?: string | undefined;
    IsCheckpoint?: boolean | undefined;
    BaseModel?: BaseModel | undefined;
}
export type ModelPackageContainerDefinitionList = ModelPackageContainerDefinition[];
export type TransformInstanceType = "ml.m4.xlarge" | "ml.m4.2xlarge" | "ml.m4.4xlarge" | "ml.m4.10xlarge" | "ml.m4.16xlarge" | "ml.c4.xlarge" | "ml.c4.2xlarge" | "ml.c4.4xlarge" | "ml.c4.8xlarge" | "ml.p2.xlarge" | "ml.p2.8xlarge" | "ml.p2.16xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | "ml.p3.16xlarge" | "ml.c5.xlarge" | "ml.c5.2xlarge" | "ml.c5.4xlarge" | "ml.c5.9xlarge" | "ml.c5.18xlarge" | "ml.m5.large" | "ml.m5.xlarge" | "ml.m5.2xlarge" | "ml.m5.4xlarge" | "ml.m5.12xlarge" | "ml.m5.24xlarge" | "ml.m6i.large" | "ml.m6i.xlarge" | "ml.m6i.2xlarge" | "ml.m6i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.12xlarge" | "ml.m6i.16xlarge" | "ml.m6i.24xlarge" | "ml.m6i.32xlarge" | "ml.c6i.large" | "ml.c6i.xlarge" | "ml.c6i.2xlarge" | "ml.c6i.4xlarge" | "ml.c6i.8xlarge" | "ml.c6i.12xlarge" | "ml.c6i.16xlarge" | "ml.c6i.24xlarge" | "ml.c6i.32xlarge" | "ml.r6i.large" | "ml.r6i.xlarge" | "ml.r6i.2xlarge" | "ml.r6i.4xlarge" | "ml.r6i.8xlarge" | "ml.r6i.12xlarge" | "ml.r6i.16xlarge" | "ml.r6i.24xlarge" | "ml.r6i.32xlarge" | "ml.m7i.large" | "ml.m7i.xlarge" | "ml.m7i.2xlarge" | "ml.m7i.4xlarge" | "ml.m7i.8xlarge" | "ml.m7i.12xlarge" | "ml.m7i.16xlarge" | "ml.m7i.24xlarge" | "ml.m7i.48xlarge" | "ml.c7i.large" | "ml.c7i.xlarge" | "ml.c7i.2xlarge" | "ml.c7i.4xlarge" | "ml.c7i.8xlarge" | "ml.c7i.12xlarge" | "ml.c7i.16xlarge" | "ml.c7i.24xlarge" | "ml.c7i.48xlarge" | "ml.r7i.large" | "ml.r7i.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.4xlarge" | "ml.r7i.8xlarge" | "ml.r7i.12xlarge" | "ml.r7i.16xlarge" | "ml.r7i.24xlarge" | "ml.r7i.48xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.12xlarge" | "ml.g5.16xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.trn1.2xlarge" | "ml.trn1.32xlarge" | "ml.inf2.xlarge" | "ml.inf2.8xlarge" | "ml.inf2.24xlarge" | "ml.inf2.48xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.12xlarge" | "ml.g6.16xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.12xlarge" | "ml.g6e.16xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | (string & {});
export type TransformInstanceTypes = TransformInstanceType[];
export type ProductionVariantInstanceType = "ml.t2.medium" | "ml.t2.large" | "ml.t2.xlarge" | "ml.t2.2xlarge" | "ml.m4.xlarge" | "ml.m4.2xlarge" | "ml.m4.4xlarge" | "ml.m4.10xlarge" | "ml.m4.16xlarge" | "ml.m5.large" | "ml.m5.xlarge" | "ml.m5.2xlarge" | "ml.m5.4xlarge" | "ml.m5.12xlarge" | "ml.m5.24xlarge" | "ml.m5d.large" | "ml.m5d.xlarge" | "ml.m5d.2xlarge" | "ml.m5d.4xlarge" | "ml.m5d.12xlarge" | "ml.m5d.24xlarge" | "ml.c4.large" | "ml.c4.xlarge" | "ml.c4.2xlarge" | "ml.c4.4xlarge" | "ml.c4.8xlarge" | "ml.p2.xlarge" | "ml.p2.8xlarge" | "ml.p2.16xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | "ml.p3.16xlarge" | "ml.c5.large" | "ml.c5.xlarge" | "ml.c5.2xlarge" | "ml.c5.4xlarge" | "ml.c5.9xlarge" | "ml.c5.18xlarge" | "ml.c5d.large" | "ml.c5d.xlarge" | "ml.c5d.2xlarge" | "ml.c5d.4xlarge" | "ml.c5d.9xlarge" | "ml.c5d.18xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.r5.large" | "ml.r5.xlarge" | "ml.r5.2xlarge" | "ml.r5.4xlarge" | "ml.r5.12xlarge" | "ml.r5.24xlarge" | "ml.r5d.large" | "ml.r5d.xlarge" | "ml.r5d.2xlarge" | "ml.r5d.4xlarge" | "ml.r5d.12xlarge" | "ml.r5d.24xlarge" | "ml.inf1.xlarge" | "ml.inf1.2xlarge" | "ml.inf1.6xlarge" | "ml.inf1.24xlarge" | "ml.dl1.24xlarge" | "ml.c6i.large" | "ml.c6i.xlarge" | "ml.c6i.2xlarge" | "ml.c6i.4xlarge" | "ml.c6i.8xlarge" | "ml.c6i.12xlarge" | "ml.c6i.16xlarge" | "ml.c6i.24xlarge" | "ml.c6i.32xlarge" | "ml.m6i.large" | "ml.m6i.xlarge" | "ml.m6i.2xlarge" | "ml.m6i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.12xlarge" | "ml.m6i.16xlarge" | "ml.m6i.24xlarge" | "ml.m6i.32xlarge" | "ml.r6i.large" | "ml.r6i.xlarge" | "ml.r6i.2xlarge" | "ml.r6i.4xlarge" | "ml.r6i.8xlarge" | "ml.r6i.12xlarge" | "ml.r6i.16xlarge" | "ml.r6i.24xlarge" | "ml.r6i.32xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.12xlarge" | "ml.g5.16xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.12xlarge" | "ml.g6.16xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.r8g.medium" | "ml.r8g.large" | "ml.r8g.xlarge" | "ml.r8g.2xlarge" | "ml.r8g.4xlarge" | "ml.r8g.8xlarge" | "ml.r8g.12xlarge" | "ml.r8g.16xlarge" | "ml.r8g.24xlarge" | "ml.r8g.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.12xlarge" | "ml.g6e.16xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | "ml.g7e.2xlarge" | "ml.g7e.4xlarge" | "ml.g7e.8xlarge" | "ml.g7e.12xlarge" | "ml.g7e.24xlarge" | "ml.g7e.48xlarge" | "ml.g7.2xlarge" | "ml.g7.4xlarge" | "ml.g7.8xlarge" | "ml.g7.12xlarge" | "ml.g7.24xlarge" | "ml.g7.48xlarge" | "ml.p4d.24xlarge" | "ml.c7g.large" | "ml.c7g.xlarge" | "ml.c7g.2xlarge" | "ml.c7g.4xlarge" | "ml.c7g.8xlarge" | "ml.c7g.12xlarge" | "ml.c7g.16xlarge" | "ml.m6g.large" | "ml.m6g.xlarge" | "ml.m6g.2xlarge" | "ml.m6g.4xlarge" | "ml.m6g.8xlarge" | "ml.m6g.12xlarge" | "ml.m6g.16xlarge" | "ml.m6gd.large" | "ml.m6gd.xlarge" | "ml.m6gd.2xlarge" | "ml.m6gd.4xlarge" | "ml.m6gd.8xlarge" | "ml.m6gd.12xlarge" | "ml.m6gd.16xlarge" | "ml.c6g.large" | "ml.c6g.xlarge" | "ml.c6g.2xlarge" | "ml.c6g.4xlarge" | "ml.c6g.8xlarge" | "ml.c6g.12xlarge" | "ml.c6g.16xlarge" | "ml.c6gd.large" | "ml.c6gd.xlarge" | "ml.c6gd.2xlarge" | "ml.c6gd.4xlarge" | "ml.c6gd.8xlarge" | "ml.c6gd.12xlarge" | "ml.c6gd.16xlarge" | "ml.c6gn.large" | "ml.c6gn.xlarge" | "ml.c6gn.2xlarge" | "ml.c6gn.4xlarge" | "ml.c6gn.8xlarge" | "ml.c6gn.12xlarge" | "ml.c6gn.16xlarge" | "ml.r6g.large" | "ml.r6g.xlarge" | "ml.r6g.2xlarge" | "ml.r6g.4xlarge" | "ml.r6g.8xlarge" | "ml.r6g.12xlarge" | "ml.r6g.16xlarge" | "ml.r6gd.large" | "ml.r6gd.xlarge" | "ml.r6gd.2xlarge" | "ml.r6gd.4xlarge" | "ml.r6gd.8xlarge" | "ml.r6gd.12xlarge" | "ml.r6gd.16xlarge" | "ml.p4de.24xlarge" | "ml.trn1.2xlarge" | "ml.trn1.32xlarge" | "ml.trn1n.32xlarge" | "ml.trn2.48xlarge" | "ml.inf2.xlarge" | "ml.inf2.8xlarge" | "ml.inf2.24xlarge" | "ml.inf2.48xlarge" | "ml.p5.48xlarge" | "ml.p5e.48xlarge" | "ml.p5en.48xlarge" | "ml.m7i.large" | "ml.m7i.xlarge" | "ml.m7i.2xlarge" | "ml.m7i.4xlarge" | "ml.m7i.8xlarge" | "ml.m7i.12xlarge" | "ml.m7i.16xlarge" | "ml.m7i.24xlarge" | "ml.m7i.48xlarge" | "ml.c7i.large" | "ml.c7i.xlarge" | "ml.c7i.2xlarge" | "ml.c7i.4xlarge" | "ml.c7i.8xlarge" | "ml.c7i.12xlarge" | "ml.c7i.16xlarge" | "ml.c7i.24xlarge" | "ml.c7i.48xlarge" | "ml.r7i.large" | "ml.r7i.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.4xlarge" | "ml.r7i.8xlarge" | "ml.r7i.12xlarge" | "ml.r7i.16xlarge" | "ml.r7i.24xlarge" | "ml.r7i.48xlarge" | "ml.c8g.medium" | "ml.c8g.large" | "ml.c8g.xlarge" | "ml.c8g.2xlarge" | "ml.c8g.4xlarge" | "ml.c8g.8xlarge" | "ml.c8g.12xlarge" | "ml.c8g.16xlarge" | "ml.c8g.24xlarge" | "ml.c8g.48xlarge" | "ml.r7gd.medium" | "ml.r7gd.large" | "ml.r7gd.xlarge" | "ml.r7gd.2xlarge" | "ml.r7gd.4xlarge" | "ml.r7gd.8xlarge" | "ml.r7gd.12xlarge" | "ml.r7gd.16xlarge" | "ml.m8g.medium" | "ml.m8g.large" | "ml.m8g.xlarge" | "ml.m8g.2xlarge" | "ml.m8g.4xlarge" | "ml.m8g.8xlarge" | "ml.m8g.12xlarge" | "ml.m8g.16xlarge" | "ml.m8g.24xlarge" | "ml.m8g.48xlarge" | "ml.c6in.large" | "ml.c6in.xlarge" | "ml.c6in.2xlarge" | "ml.c6in.4xlarge" | "ml.c6in.8xlarge" | "ml.c6in.12xlarge" | "ml.c6in.16xlarge" | "ml.c6in.24xlarge" | "ml.c6in.32xlarge" | "ml.p6-b200.48xlarge" | "ml.p6-b300.48xlarge" | "ml.p6e-gb200.36xlarge" | "ml.p5.4xlarge" | (string & {});
export type RealtimeInferenceInstanceTypes = ProductionVariantInstanceType[];
export type ContentType = string;
export type ContentTypes = string[];
export type ResponseMIMEType = string;
export type ResponseMIMETypes = string[];
export interface InferenceSpecification {
    Containers?: ModelPackageContainerDefinition[] | undefined;
    SupportedTransformInstanceTypes?: TransformInstanceType[] | undefined;
    SupportedRealtimeInferenceInstanceTypes?: ProductionVariantInstanceType[] | undefined;
    SupportedContentTypes?: string[] | undefined;
    SupportedResponseMIMETypes?: string[] | undefined;
}
export type ModelPackageStatus = "Pending" | "InProgress" | "Completed" | "Failed" | "Deleting" | (string & {});
export type ModelApprovalStatus = "Approved" | "Rejected" | "PendingManualApproval" | (string & {});
export type ModelPackageRegistrationType = "Logged" | "Registered" | (string & {});
export interface BatchDescribeModelPackageSummary {
    ModelPackageGroupName?: string | undefined;
    ModelPackageVersion?: number | undefined;
    ModelPackageArn?: string | undefined;
    ModelPackageDescription?: string | undefined;
    CreationTime?: Date | undefined;
    InferenceSpecification?: InferenceSpecification | undefined;
    ModelPackageStatus?: ModelPackageStatus | undefined;
    ModelApprovalStatus?: ModelApprovalStatus | undefined;
    ModelPackageRegistrationType?: ModelPackageRegistrationType | undefined;
}
export type ModelPackageSummaries = {
    [key: string]: BatchDescribeModelPackageSummary | undefined;
};
export interface BatchDescribeModelPackageError_ {
    ErrorCode?: string | undefined;
    ErrorResponse?: string | undefined;
}
export type BatchDescribeModelPackageErrorMap = {
    [key: string]: BatchDescribeModelPackageError_ | undefined;
};
export interface BatchDescribeModelPackageOutput {
    ModelPackageSummaries?: {
        [key: string]: (BatchDescribeModelPackageSummary & {
            ModelPackageGroupName: EntityName;
            ModelPackageArn: ModelPackageArn;
            CreationTime: CreationTime;
            InferenceSpecification: InferenceSpecification & {
                Containers: (ModelPackageContainerDefinition & {
                    ModelDataSource: ModelDataSource & {
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    };
                    ModelInput: ModelInput & {
                        DataInputConfig: DataInputConfig;
                    };
                    AdditionalModelDataSources: (AdditionalModelDataSource & {
                        ChannelName: AdditionalModelChannelName;
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    })[];
                    AdditionalS3DataSource: AdditionalS3DataSource & {
                        S3DataType: AdditionalS3DataSourceDataType;
                        S3Uri: S3Uri;
                    };
                })[];
            };
            ModelPackageStatus: ModelPackageStatus;
        }) | undefined;
    } | undefined;
    BatchDescribeModelPackageErrorMap?: {
        [key: string]: (BatchDescribeModelPackageError & {
            ErrorCode: string;
            ErrorResponse: string;
        }) | undefined;
    } | undefined;
}
export interface BatchRebootClusterNodesRequest {
    ClusterName?: string | undefined;
    NodeIds?: string[] | undefined;
    NodeLogicalIds?: string[] | undefined;
}
export type BatchRebootClusterNodesErrorCode = "InstanceIdNotFound" | "InvalidInstanceStatus" | "InstanceIdInUse" | "InternalServerError" | (string & {});
export interface BatchRebootClusterNodesError_ {
    NodeId?: string | undefined;
    ErrorCode?: BatchRebootClusterNodesErrorCode | undefined;
    Message?: string | undefined;
}
export type BatchRebootClusterNodesErrors = BatchRebootClusterNodesError_[];
export interface BatchRebootClusterNodeLogicalIdsError {
    NodeLogicalId?: string | undefined;
    ErrorCode?: BatchRebootClusterNodesErrorCode | undefined;
    Message?: string | undefined;
}
export type BatchRebootClusterNodeLogicalIdsErrors = BatchRebootClusterNodeLogicalIdsError[];
export interface BatchRebootClusterNodesResponse {
    Successful?: string[] | undefined;
    Failed?: (BatchRebootClusterNodesError & {
        NodeId: ClusterNodeId;
        ErrorCode: BatchRebootClusterNodesErrorCode;
        Message: string;
    })[] | undefined;
    FailedNodeLogicalIds?: (BatchRebootClusterNodeLogicalIdsError & {
        NodeLogicalId: ClusterNodeLogicalId;
        ErrorCode: BatchRebootClusterNodesErrorCode;
        Message: string;
    })[] | undefined;
    SuccessfulNodeLogicalIds?: string[] | undefined;
}
export interface BatchReplaceClusterNodesRequest {
    ClusterName?: string | undefined;
    NodeIds?: string[] | undefined;
    NodeLogicalIds?: string[] | undefined;
}
export type BatchReplaceClusterNodesErrorCode = "InstanceIdNotFound" | "InvalidInstanceStatus" | "InstanceIdInUse" | "InternalServerError" | (string & {});
export interface BatchReplaceClusterNodesError_ {
    NodeId?: string | undefined;
    ErrorCode?: BatchReplaceClusterNodesErrorCode | undefined;
    Message?: string | undefined;
}
export type BatchReplaceClusterNodesErrors = BatchReplaceClusterNodesError_[];
export interface BatchReplaceClusterNodeLogicalIdsError {
    NodeLogicalId?: string | undefined;
    ErrorCode?: BatchReplaceClusterNodesErrorCode | undefined;
    Message?: string | undefined;
}
export type BatchReplaceClusterNodeLogicalIdsErrors = BatchReplaceClusterNodeLogicalIdsError[];
export interface BatchReplaceClusterNodesResponse {
    Successful?: string[] | undefined;
    Failed?: (BatchReplaceClusterNodesError & {
        NodeId: ClusterNodeId;
        ErrorCode: BatchReplaceClusterNodesErrorCode;
        Message: string;
    })[] | undefined;
    FailedNodeLogicalIds?: (BatchReplaceClusterNodeLogicalIdsError & {
        NodeLogicalId: ClusterNodeLogicalId;
        ErrorCode: BatchReplaceClusterNodesErrorCode;
        Message: string;
    })[] | undefined;
    SuccessfulNodeLogicalIds?: string[] | undefined;
}
export type SourceUri = string;
export type String256 = string;
export interface ActionSource {
    SourceUri?: string | undefined;
    SourceType?: string | undefined;
    SourceId?: string | undefined;
}
export type ExperimentDescription = string;
export type ActionStatus = "Unknown" | "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export type StringParameterValue = string;
export type LineageEntityParameters = {
    [key: string]: string | undefined;
};
export type MetadataPropertyValue = string;
export interface MetadataProperties {
    CommitId?: string | undefined;
    Repository?: string | undefined;
    GeneratedBy?: string | undefined;
    ProjectId?: string | undefined;
}
export interface CreateActionRequest {
    ActionName?: string | undefined;
    Source?: ActionSource | undefined;
    ActionType?: string | undefined;
    Description?: string | undefined;
    Status?: ActionStatus | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    Tags?: Tag[] | undefined;
}
export type ActionArn = string;
export interface CreateActionResponse {
    ActionArn?: string | undefined;
}
export type AIEntityName = string;
export type AIResourceIdentifier = string;
export interface AIBenchmarkInferenceComponent {
    Identifier?: string | undefined;
}
export type AIBenchmarkInferenceComponentList = AIBenchmarkInferenceComponent[];
export interface AIBenchmarkEndpoint {
    Identifier?: string | undefined;
    TargetContainerHostname?: string | undefined;
    InferenceComponents?: AIBenchmarkInferenceComponent[] | undefined;
}
export type AIBenchmarkTarget = {
    Endpoint: AIBenchmarkEndpoint;
};
export type AIMlflowResourceArn = string;
export type AIMlflowExperimentName = string;
export type AIMlflowRunName = string;
export interface AIMlflowConfig {
    MlflowResourceArn?: string | undefined;
    MlflowExperimentName?: string | undefined;
    MlflowRunName?: string | undefined;
}
export interface AIBenchmarkOutputConfig {
    S3OutputLocation?: string | undefined;
    MlflowConfig?: AIMlflowConfig | undefined;
}
export type RoleArn = string;
export type SecurityGroupId = string;
export type VpcSecurityGroupIds = string[];
export type SubnetId = string;
export type Subnets = string[];
export interface VpcConfig {
    SecurityGroupIds?: string[] | undefined;
    Subnets?: string[] | undefined;
}
export interface AIBenchmarkNetworkConfig {
    VpcConfig?: VpcConfig | undefined;
}
export interface CreateAIBenchmarkJobRequest {
    AIBenchmarkJobName?: string | undefined;
    BenchmarkTarget?: AIBenchmarkTarget | undefined;
    OutputConfig?: AIBenchmarkOutputConfig | undefined;
    AIWorkloadConfigIdentifier?: string | undefined;
    RoleArn?: string | undefined;
    NetworkConfig?: AIBenchmarkNetworkConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type AIBenchmarkJobArn = string;
export interface CreateAIBenchmarkJobResponse {
    AIBenchmarkJobArn: string;
}
export interface AIModelSourceS3 {
    S3Uri?: string | undefined;
}
export type AIModelSource = {
    S3: AIModelSourceS3;
};
export interface AIRecommendationOutputConfig {
    S3OutputLocation?: string | undefined;
    ModelPackageGroupIdentifier?: string | undefined;
    MlflowConfig?: AIMlflowConfig | undefined;
}
export type AIRecommendationMetric = "ttft-ms" | "throughput" | "cost" | (string & {});
export interface AIRecommendationConstraint {
    Metric?: AIRecommendationMetric | undefined;
}
export type AIRecommendationConstraintList = AIRecommendationConstraint[];
export interface AIRecommendationPerformanceTarget {
    Constraints?: AIRecommendationConstraint[] | undefined;
}
export type AIRecommendationInferenceFramework = "LMI" | "VLLM" | (string & {});
export interface AIRecommendationInferenceSpecification {
    Framework?: AIRecommendationInferenceFramework | undefined;
}
export type AIRecommendationAllowOptimization = boolean;
export type AIRecommendationInstanceType = "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.12xlarge" | "ml.g5.16xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.12xlarge" | "ml.g6.16xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.12xlarge" | "ml.g6e.16xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | "ml.g7.2xlarge" | "ml.g7.4xlarge" | "ml.g7.8xlarge" | "ml.g7.12xlarge" | "ml.g7.24xlarge" | "ml.g7.48xlarge" | "ml.g7e.2xlarge" | "ml.g7e.4xlarge" | "ml.g7e.8xlarge" | "ml.g7e.12xlarge" | "ml.g7e.24xlarge" | "ml.g7e.48xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | "ml.p3.16xlarge" | "ml.p4d.24xlarge" | "ml.p4de.24xlarge" | "ml.p5.4xlarge" | "ml.p5.48xlarge" | "ml.p5e.48xlarge" | "ml.p5en.48xlarge" | "ml.p6-b200.48xlarge" | (string & {});
export type AIRecommendationInstanceTypeList = AIRecommendationInstanceType[];
export type AICapacityReservationPreference = "capacity-reservations-only" | (string & {});
export type AIMlReservationArn = string;
export type AIMlReservationArnList = string[];
export interface AICapacityReservationConfig {
    CapacityReservationPreference?: AICapacityReservationPreference | undefined;
    MlReservationArns?: string[] | undefined;
}
export interface AIRecommendationComputeSpec {
    InstanceTypes?: AIRecommendationInstanceType[] | undefined;
    CapacityReservationConfig?: AICapacityReservationConfig | undefined;
}
export type AIAdapterId = string;
export interface AIAdapterModelPackageEntry {
    AdapterId?: string | undefined;
    ModelPackageArn?: string | undefined;
}
export type AIAdapterModelPackageEntryList = AIAdapterModelPackageEntry[];
export interface AIAdapterS3Entry {
    AdapterId?: string | undefined;
    S3Uri?: string | undefined;
}
export type AIAdapterS3EntryList = AIAdapterS3Entry[];
export type AIAdapterSource = {
    ModelPackageArns: AIAdapterModelPackageEntry[];
    S3Uris?: undefined;
} | {
    ModelPackageArns?: undefined;
    S3Uris: AIAdapterS3Entry[];
};
export interface CreateAIRecommendationJobRequest {
    AIRecommendationJobName?: string | undefined;
    ModelSource?: AIModelSource | undefined;
    OutputConfig?: AIRecommendationOutputConfig | undefined;
    AIWorkloadConfigIdentifier?: string | undefined;
    PerformanceTarget?: AIRecommendationPerformanceTarget | undefined;
    RoleArn?: string | undefined;
    InferenceSpecification?: AIRecommendationInferenceSpecification | undefined;
    OptimizeModel?: boolean | undefined;
    ComputeSpec?: AIRecommendationComputeSpec | undefined;
    AdapterSource?: AIAdapterSource | undefined;
    Tags?: Tag[] | undefined;
}
export type AIRecommendationJobArn = string;
export interface CreateAIRecommendationJobResponse {
    AIRecommendationJobArn: string;
}
export type AIChannelName = string;
export interface AIWorkloadS3DataSource {
    S3Uri?: string | undefined;
}
export interface AIWorkloadDataSource {
    S3DataSource?: AIWorkloadS3DataSource | undefined;
}
export interface AIWorkloadInputDataConfig {
    ChannelName?: string | undefined;
    DataSource?: AIWorkloadDataSource | undefined;
}
export type AIWorkloadInputDataConfigList = AIWorkloadInputDataConfig[];
export type AIDatasetConfig = {
    InputDataConfig: AIWorkloadInputDataConfig[];
};
export type WorkloadSpec = {
    Inline: string;
};
export interface AIWorkloadConfigs {
    WorkloadSpec?: WorkloadSpec | undefined;
}
export interface CreateAIWorkloadConfigRequest {
    AIWorkloadConfigName?: string | undefined;
    DatasetConfig?: AIDatasetConfig | undefined;
    AIWorkloadConfigs?: AIWorkloadConfigs | undefined;
    Tags?: Tag[] | undefined;
}
export type AIWorkloadConfigArn = string;
export interface CreateAIWorkloadConfigResponse {
    AIWorkloadConfigArn: string;
}
export type ParameterName = string;
export type ParameterType = "Integer" | "Continuous" | "Categorical" | "FreeText" | (string & {});
export type ParameterValue = string;
export interface IntegerParameterRangeSpecification {
    MinValue?: string | undefined;
    MaxValue?: string | undefined;
}
export interface ContinuousParameterRangeSpecification {
    MinValue?: string | undefined;
    MaxValue?: string | undefined;
}
export type ParameterValues = string[];
export interface CategoricalParameterRangeSpecification {
    Values?: string[] | undefined;
}
export interface ParameterRange {
    IntegerParameterRangeSpecification?: IntegerParameterRangeSpecification | undefined;
    ContinuousParameterRangeSpecification?: ContinuousParameterRangeSpecification | undefined;
    CategoricalParameterRangeSpecification?: CategoricalParameterRangeSpecification | undefined;
}
export type HyperParameterValue = string;
export interface HyperParameterSpecification {
    Name?: string | undefined;
    Description?: string | undefined;
    Type?: ParameterType | undefined;
    Range?: ParameterRange | undefined;
    IsTunable?: boolean | undefined;
    IsRequired?: boolean | undefined;
    DefaultValue?: string | undefined;
}
export type HyperParameterSpecifications = HyperParameterSpecification[];
export type TrainingInstanceType = "ml.m4.xlarge" | "ml.m4.2xlarge" | "ml.m4.4xlarge" | "ml.m4.10xlarge" | "ml.m4.16xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.m5.large" | "ml.m5.xlarge" | "ml.m5.2xlarge" | "ml.m5.4xlarge" | "ml.m5.12xlarge" | "ml.m5.24xlarge" | "ml.c4.xlarge" | "ml.c4.2xlarge" | "ml.c4.4xlarge" | "ml.c4.8xlarge" | "ml.p2.xlarge" | "ml.p2.8xlarge" | "ml.p2.16xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | "ml.p3.16xlarge" | "ml.p3dn.24xlarge" | "ml.p4d.24xlarge" | "ml.p4de.24xlarge" | "ml.p5.48xlarge" | "ml.p5e.48xlarge" | "ml.p5en.48xlarge" | "ml.c5.xlarge" | "ml.c5.2xlarge" | "ml.c5.4xlarge" | "ml.c5.9xlarge" | "ml.c5.18xlarge" | "ml.c5n.xlarge" | "ml.c5n.2xlarge" | "ml.c5n.4xlarge" | "ml.c5n.9xlarge" | "ml.c5n.18xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.16xlarge" | "ml.g5.12xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.16xlarge" | "ml.g6.12xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.16xlarge" | "ml.g6e.12xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | "ml.trn1.2xlarge" | "ml.trn1.32xlarge" | "ml.trn1n.32xlarge" | "ml.trn2.48xlarge" | "ml.m6i.large" | "ml.m6i.xlarge" | "ml.m6i.2xlarge" | "ml.m6i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.12xlarge" | "ml.m6i.16xlarge" | "ml.m6i.24xlarge" | "ml.m6i.32xlarge" | "ml.c6i.xlarge" | "ml.c6i.2xlarge" | "ml.c6i.8xlarge" | "ml.c6i.4xlarge" | "ml.c6i.12xlarge" | "ml.c6i.16xlarge" | "ml.c6i.24xlarge" | "ml.c6i.32xlarge" | "ml.r5d.large" | "ml.r5d.xlarge" | "ml.r5d.2xlarge" | "ml.r5d.4xlarge" | "ml.r5d.8xlarge" | "ml.r5d.12xlarge" | "ml.r5d.16xlarge" | "ml.r5d.24xlarge" | "ml.t3.medium" | "ml.t3.large" | "ml.t3.xlarge" | "ml.t3.2xlarge" | "ml.r5.large" | "ml.r5.xlarge" | "ml.r5.2xlarge" | "ml.r5.4xlarge" | "ml.r5.8xlarge" | "ml.r5.12xlarge" | "ml.r5.16xlarge" | "ml.r5.24xlarge" | "ml.p6-b200.48xlarge" | "ml.m7i.large" | "ml.m7i.xlarge" | "ml.m7i.2xlarge" | "ml.m7i.4xlarge" | "ml.m7i.8xlarge" | "ml.m7i.12xlarge" | "ml.m7i.16xlarge" | "ml.m7i.24xlarge" | "ml.m7i.48xlarge" | "ml.c7i.large" | "ml.c7i.xlarge" | "ml.c7i.2xlarge" | "ml.c7i.4xlarge" | "ml.c7i.8xlarge" | "ml.c7i.12xlarge" | "ml.c7i.16xlarge" | "ml.c7i.24xlarge" | "ml.c7i.48xlarge" | "ml.r7i.large" | "ml.r7i.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.4xlarge" | "ml.r7i.8xlarge" | "ml.r7i.12xlarge" | "ml.r7i.16xlarge" | "ml.r7i.24xlarge" | "ml.r7i.48xlarge" | "ml.p6e-gb200.36xlarge" | "ml.p5.4xlarge" | "ml.p6-b300.48xlarge" | "ml.g7e.2xlarge" | "ml.g7e.4xlarge" | "ml.g7e.8xlarge" | "ml.g7e.12xlarge" | "ml.g7e.24xlarge" | "ml.g7e.48xlarge" | "ml.g7.2xlarge" | "ml.g7.4xlarge" | "ml.g7.8xlarge" | "ml.g7.12xlarge" | "ml.g7.24xlarge" | "ml.g7.48xlarge" | "ml.r6i.large" | "ml.r6i.xlarge" | "ml.r6i.2xlarge" | "ml.r6i.4xlarge" | "ml.r6i.8xlarge" | "ml.r6i.12xlarge" | "ml.r6i.16xlarge" | "ml.r6i.24xlarge" | "ml.r6i.32xlarge" | "ml.m8i.large" | "ml.m8i.xlarge" | "ml.m8i.2xlarge" | "ml.m8i.4xlarge" | "ml.m8i.8xlarge" | "ml.m8i.12xlarge" | "ml.m8i.16xlarge" | "ml.m8i.24xlarge" | "ml.m8i.32xlarge" | "ml.m8i.48xlarge" | "ml.m8i.96xlarge" | "ml.c8i.xlarge" | "ml.c8i.2xlarge" | "ml.c8i.4xlarge" | "ml.c8i.8xlarge" | "ml.c8i.12xlarge" | "ml.c8i.16xlarge" | "ml.c8i.24xlarge" | "ml.c8i.32xlarge" | "ml.c8i.48xlarge" | "ml.c8i.96xlarge" | "ml.r8i.large" | "ml.r8i.xlarge" | "ml.r8i.2xlarge" | "ml.r8i.4xlarge" | "ml.r8i.8xlarge" | "ml.r8i.12xlarge" | "ml.r8i.16xlarge" | "ml.r8i.24xlarge" | "ml.r8i.32xlarge" | "ml.r8i.48xlarge" | "ml.r8i.96xlarge" | "ml.m7i-flex.large" | "ml.m7i-flex.xlarge" | "ml.m7i-flex.2xlarge" | "ml.m7i-flex.4xlarge" | "ml.m7i-flex.8xlarge" | "ml.m7i-flex.12xlarge" | "ml.m7i-flex.16xlarge" | "ml.c7i-flex.xlarge" | "ml.c7i-flex.2xlarge" | "ml.c7i-flex.4xlarge" | "ml.c7i-flex.8xlarge" | "ml.c7i-flex.12xlarge" | "ml.c7i-flex.16xlarge" | "ml.m8i-flex.large" | "ml.m8i-flex.xlarge" | "ml.m8i-flex.2xlarge" | "ml.m8i-flex.4xlarge" | "ml.m8i-flex.8xlarge" | "ml.m8i-flex.12xlarge" | "ml.m8i-flex.16xlarge" | "ml.c8i-flex.xlarge" | "ml.c8i-flex.2xlarge" | "ml.c8i-flex.4xlarge" | "ml.c8i-flex.8xlarge" | "ml.c8i-flex.12xlarge" | "ml.c8i-flex.16xlarge" | "ml.r8i-flex.large" | "ml.r8i-flex.xlarge" | "ml.r8i-flex.2xlarge" | "ml.r8i-flex.4xlarge" | "ml.r8i-flex.8xlarge" | "ml.r8i-flex.12xlarge" | "ml.r8i-flex.16xlarge" | (string & {});
export type TrainingInstanceTypes = TrainingInstanceType[];
export type MetricName = string;
export type MetricRegex = string;
export interface MetricDefinition {
    Name?: string | undefined;
    Regex?: string | undefined;
}
export type MetricDefinitionList = MetricDefinition[];
export type ChannelName = string;
export type CompressionTypes = CompressionType[];
export type TrainingInputMode = "Pipe" | "File" | "FastFile" | (string & {});
export type InputModes = TrainingInputMode[];
export interface ChannelSpecification {
    Name?: string | undefined;
    Description?: string | undefined;
    IsRequired?: boolean | undefined;
    SupportedContentTypes?: string[] | undefined;
    SupportedCompressionTypes?: CompressionType[] | undefined;
    SupportedInputModes?: TrainingInputMode[] | undefined;
}
export type ChannelSpecifications = ChannelSpecification[];
export type HyperParameterTuningJobObjectiveType = "Maximize" | "Minimize" | (string & {});
export interface HyperParameterTuningJobObjective {
    Type?: HyperParameterTuningJobObjectiveType | undefined;
    MetricName?: string | undefined;
}
export type HyperParameterTuningJobObjectives = HyperParameterTuningJobObjective[];
export interface TrainingSpecification {
    TrainingImage?: string | undefined;
    TrainingImageDigest?: string | undefined;
    SupportedHyperParameters?: HyperParameterSpecification[] | undefined;
    SupportedTrainingInstanceTypes?: TrainingInstanceType[] | undefined;
    SupportsDistributedTraining?: boolean | undefined;
    MetricDefinitions?: MetricDefinition[] | undefined;
    TrainingChannels?: ChannelSpecification[] | undefined;
    SupportedTuningJobObjectiveMetrics?: HyperParameterTuningJobObjective[] | undefined;
    AdditionalS3DataSource?: AdditionalS3DataSource | undefined;
}
export type HyperParameterKey = string;
export type HyperParameters = {
    [key: string]: string | undefined;
};
export type S3DataType = "ManifestFile" | "S3Prefix" | "AugmentedManifestFile" | "Converse" | (string & {});
export type S3DataDistribution = "FullyReplicated" | "ShardedByS3Key" | (string & {});
export type AttributeName = string;
export type AttributeNames = string[];
export type InstanceGroupNames = string[];
export interface HubAccessConfig {
    HubContentArn?: string | undefined;
}
export interface S3DataSource {
    S3DataType?: S3DataType | undefined;
    S3Uri?: string | undefined;
    S3DataDistributionType?: S3DataDistribution | undefined;
    AttributeNames?: string[] | undefined;
    InstanceGroupNames?: string[] | undefined;
    ModelAccessConfig?: ModelAccessConfig | undefined;
    HubAccessConfig?: HubAccessConfig | undefined;
}
export type FileSystemId = string;
export type FileSystemAccessMode = "rw" | "ro" | (string & {});
export type FileSystemType = "EFS" | "FSxLustre" | (string & {});
export type DirectoryPath = string;
export interface FileSystemDataSource {
    FileSystemId?: string | undefined;
    FileSystemAccessMode?: FileSystemAccessMode | undefined;
    FileSystemType?: FileSystemType | undefined;
    DirectoryPath?: string | undefined;
}
export type HubDataSetArn = string;
export interface DatasetSource {
    DatasetArn: string;
}
export interface DataSource {
    S3DataSource?: S3DataSource | undefined;
    FileSystemDataSource?: FileSystemDataSource | undefined;
    DatasetSource?: DatasetSource | undefined;
}
export type RecordWrapper = "None" | "RecordIO" | (string & {});
export type Seed = number;
export interface ShuffleConfig {
    Seed?: number | undefined;
}
export interface Channel {
    ChannelName?: string | undefined;
    DataSource?: DataSource | undefined;
    ContentType?: string | undefined;
    CompressionType?: CompressionType | undefined;
    RecordWrapperType?: RecordWrapper | undefined;
    InputMode?: TrainingInputMode | undefined;
    ShuffleConfig?: ShuffleConfig | undefined;
}
export type InputDataConfig = Channel[];
export type KmsKeyId = string;
export type OutputCompressionType = "GZIP" | "NONE" | (string & {});
export interface OutputDataConfig {
    KmsKeyId?: string | undefined;
    S3OutputPath?: string | undefined;
    CompressionType?: OutputCompressionType | undefined;
}
export type TrainingInstanceCount = number;
export type OptionalVolumeSizeInGB = number;
export type KeepAlivePeriodInSeconds = number;
export interface InstanceGroup {
    InstanceType?: TrainingInstanceType | undefined;
    InstanceCount?: number | undefined;
    InstanceGroupName?: string | undefined;
}
export type InstanceGroups = InstanceGroup[];
export type TrainingPlanArn = string;
export interface PlacementSpecification {
    UltraServerId?: string | undefined;
    InstanceCount?: number | undefined;
}
export type PlacementSpecifications = PlacementSpecification[];
export interface InstancePlacementConfig {
    EnableMultipleJobs?: boolean | undefined;
    PlacementSpecifications?: PlacementSpecification[] | undefined;
}
export type TrainingPlanArnList = string[];
export interface InstancePreference {
    InstanceType?: TrainingInstanceType | undefined;
    InstanceCount?: number | undefined;
    TrainingPlanArns?: string[] | undefined;
}
export type InstancePreferenceList = InstancePreference[];
export interface ResourceConfig {
    InstanceType?: TrainingInstanceType | undefined;
    InstanceCount?: number | undefined;
    VolumeSizeInGB?: number | undefined;
    VolumeKmsKeyId?: string | undefined;
    KeepAlivePeriodInSeconds?: number | undefined;
    InstanceGroups?: InstanceGroup[] | undefined;
    TrainingPlanArn?: string | undefined;
    InstancePlacementConfig?: InstancePlacementConfig | undefined;
    InstancePreferences?: InstancePreference[] | undefined;
    SelectedInstanceType?: TrainingInstanceType | undefined;
    SelectedInstanceCount?: number | undefined;
}
export type MaxRuntimeInSeconds = number;
export type MaxWaitTimeInSeconds = number;
export type MaxPendingTimeInSeconds = number;
export interface StoppingCondition {
    MaxRuntimeInSeconds?: number | undefined;
    MaxWaitTimeInSeconds?: number | undefined;
    MaxPendingTimeInSeconds?: number | undefined;
}
export interface TrainingJobDefinition {
    TrainingInputMode?: TrainingInputMode | undefined;
    HyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    InputDataConfig?: Channel[] | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    ResourceConfig?: ResourceConfig | undefined;
    StoppingCondition?: StoppingCondition | undefined;
}
export type MaxConcurrentTransforms = number;
export type MaxPayloadInMB = number;
export type BatchStrategy = "MultiRecord" | "SingleRecord" | (string & {});
export type TransformEnvironmentKey = string;
export type TransformEnvironmentValue = string;
export type TransformEnvironmentMap = {
    [key: string]: string | undefined;
};
export interface TransformS3DataSource {
    S3DataType?: S3DataType | undefined;
    S3Uri?: string | undefined;
}
export interface TransformDataSource {
    S3DataSource?: TransformS3DataSource | undefined;
}
export type SplitType = "None" | "Line" | "RecordIO" | "TFRecord" | (string & {});
export interface TransformInput {
    DataSource?: TransformDataSource | undefined;
    ContentType?: string | undefined;
    CompressionType?: CompressionType | undefined;
    SplitType?: SplitType | undefined;
}
export type Accept = string;
export type AssemblyType = "None" | "Line" | (string & {});
export interface TransformOutput {
    S3OutputPath?: string | undefined;
    Accept?: string | undefined;
    AssembleWith?: AssemblyType | undefined;
    KmsKeyId?: string | undefined;
}
export type TransformInstanceCount = number;
export type TransformAmiVersion = string;
export interface TransformResources {
    InstanceType?: TransformInstanceType | undefined;
    InstanceCount?: number | undefined;
    VolumeKmsKeyId?: string | undefined;
    TransformAmiVersion?: string | undefined;
}
export interface TransformJobDefinition {
    MaxConcurrentTransforms?: number | undefined;
    MaxPayloadInMB?: number | undefined;
    BatchStrategy?: BatchStrategy | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    TransformInput?: TransformInput | undefined;
    TransformOutput?: TransformOutput | undefined;
    TransformResources?: TransformResources | undefined;
}
export interface AlgorithmValidationProfile {
    ProfileName?: string | undefined;
    TrainingJobDefinition?: TrainingJobDefinition | undefined;
    TransformJobDefinition?: TransformJobDefinition | undefined;
}
export type AlgorithmValidationProfiles = AlgorithmValidationProfile[];
export interface AlgorithmValidationSpecification {
    ValidationRole?: string | undefined;
    ValidationProfiles?: AlgorithmValidationProfile[] | undefined;
}
export type CertifyForMarketplace = boolean;
export interface CreateAlgorithmInput {
    AlgorithmName?: string | undefined;
    AlgorithmDescription?: string | undefined;
    TrainingSpecification?: TrainingSpecification | undefined;
    InferenceSpecification?: InferenceSpecification | undefined;
    ValidationSpecification?: AlgorithmValidationSpecification | undefined;
    CertifyForMarketplace?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export type AlgorithmArn = string;
export interface CreateAlgorithmOutput {
    AlgorithmArn: string;
}
export type DomainId = string;
export type UserProfileName = string;
export type SpaceName = string;
export type AppType = "JupyterServer" | "KernelGateway" | "DetailedProfiler" | "TensorBoard" | "CodeEditor" | "JupyterLab" | "RStudioServerPro" | "RSessionGateway" | "Canvas" | (string & {});
export type AppName = string;
export type ImageArn = string;
export type ImageVersionArn = string;
export type ImageVersionAlias = string;
export type AppInstanceType = "system" | "ml.t3.micro" | "ml.t3.small" | "ml.t3.medium" | "ml.t3.large" | "ml.t3.xlarge" | "ml.t3.2xlarge" | "ml.m5.large" | "ml.m5.xlarge" | "ml.m5.2xlarge" | "ml.m5.4xlarge" | "ml.m5.8xlarge" | "ml.m5.12xlarge" | "ml.m5.16xlarge" | "ml.m5.24xlarge" | "ml.m5d.large" | "ml.m5d.xlarge" | "ml.m5d.2xlarge" | "ml.m5d.4xlarge" | "ml.m5d.8xlarge" | "ml.m5d.12xlarge" | "ml.m5d.16xlarge" | "ml.m5d.24xlarge" | "ml.c5.large" | "ml.c5.xlarge" | "ml.c5.2xlarge" | "ml.c5.4xlarge" | "ml.c5.9xlarge" | "ml.c5.12xlarge" | "ml.c5.18xlarge" | "ml.c5.24xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | "ml.p3.16xlarge" | "ml.p3dn.24xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.r5.large" | "ml.r5.xlarge" | "ml.r5.2xlarge" | "ml.r5.4xlarge" | "ml.r5.8xlarge" | "ml.r5.12xlarge" | "ml.r5.16xlarge" | "ml.r5.24xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.16xlarge" | "ml.g5.12xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.12xlarge" | "ml.g6.16xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.12xlarge" | "ml.g6e.16xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | "ml.geospatial.interactive" | "ml.p4d.24xlarge" | "ml.p4de.24xlarge" | "ml.trn1.2xlarge" | "ml.trn1.32xlarge" | "ml.trn1n.32xlarge" | "ml.p5.48xlarge" | "ml.p5en.48xlarge" | "ml.p6-b200.48xlarge" | "ml.m6i.large" | "ml.m6i.xlarge" | "ml.m6i.2xlarge" | "ml.m6i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.12xlarge" | "ml.m6i.16xlarge" | "ml.m6i.24xlarge" | "ml.m6i.32xlarge" | "ml.m7i.large" | "ml.m7i.xlarge" | "ml.m7i.2xlarge" | "ml.m7i.4xlarge" | "ml.m7i.8xlarge" | "ml.m7i.12xlarge" | "ml.m7i.16xlarge" | "ml.m7i.24xlarge" | "ml.m7i.48xlarge" | "ml.c6i.large" | "ml.c6i.xlarge" | "ml.c6i.2xlarge" | "ml.c6i.4xlarge" | "ml.c6i.8xlarge" | "ml.c6i.12xlarge" | "ml.c6i.16xlarge" | "ml.c6i.24xlarge" | "ml.c6i.32xlarge" | "ml.c7i.large" | "ml.c7i.xlarge" | "ml.c7i.2xlarge" | "ml.c7i.4xlarge" | "ml.c7i.8xlarge" | "ml.c7i.12xlarge" | "ml.c7i.16xlarge" | "ml.c7i.24xlarge" | "ml.c7i.48xlarge" | "ml.r6i.large" | "ml.r6i.xlarge" | "ml.r6i.2xlarge" | "ml.r6i.4xlarge" | "ml.r6i.8xlarge" | "ml.r6i.12xlarge" | "ml.r6i.16xlarge" | "ml.r6i.24xlarge" | "ml.r6i.32xlarge" | "ml.r7i.large" | "ml.r7i.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.4xlarge" | "ml.r7i.8xlarge" | "ml.r7i.12xlarge" | "ml.r7i.16xlarge" | "ml.r7i.24xlarge" | "ml.r7i.48xlarge" | "ml.m6id.large" | "ml.m6id.xlarge" | "ml.m6id.2xlarge" | "ml.m6id.4xlarge" | "ml.m6id.8xlarge" | "ml.m6id.12xlarge" | "ml.m6id.16xlarge" | "ml.m6id.24xlarge" | "ml.m6id.32xlarge" | "ml.c6id.large" | "ml.c6id.xlarge" | "ml.c6id.2xlarge" | "ml.c6id.4xlarge" | "ml.c6id.8xlarge" | "ml.c6id.12xlarge" | "ml.c6id.16xlarge" | "ml.c6id.24xlarge" | "ml.c6id.32xlarge" | "ml.r6id.large" | "ml.r6id.xlarge" | "ml.r6id.2xlarge" | "ml.r6id.4xlarge" | "ml.r6id.8xlarge" | "ml.r6id.12xlarge" | "ml.r6id.16xlarge" | "ml.r6id.24xlarge" | "ml.r6id.32xlarge" | "ml.p5.4xlarge" | "ml.g7.2xlarge" | "ml.g7.4xlarge" | "ml.g7.8xlarge" | "ml.g7.12xlarge" | "ml.g7.24xlarge" | "ml.g7.48xlarge" | "ml.g7e.2xlarge" | "ml.g7e.4xlarge" | "ml.g7e.8xlarge" | "ml.g7e.12xlarge" | "ml.g7e.24xlarge" | "ml.g7e.48xlarge" | (string & {});
export type StudioLifecycleConfigArn = string;
export type StudioResourceSpecTrainingPlanArn = string;
export interface ResourceSpec {
    SageMakerImageArn?: string | undefined;
    SageMakerImageVersionArn?: string | undefined;
    SageMakerImageVersionAlias?: string | undefined;
    InstanceType?: AppInstanceType | undefined;
    LifecycleConfigArn?: string | undefined;
    TrainingPlanArn?: string | undefined;
}
export interface CreateAppRequest {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    SpaceName?: string | undefined;
    AppType?: AppType | undefined;
    AppName?: string | undefined;
    Tags?: Tag[] | undefined;
    ResourceSpec?: ResourceSpec | undefined;
    RecoveryMode?: boolean | undefined;
}
export type AppArn = string;
export interface CreateAppResponse {
    AppArn?: string | undefined;
}
export type AppImageConfigName = string;
export type KernelName = string;
export type KernelDisplayName = string;
export interface KernelSpec {
    Name?: string | undefined;
    DisplayName?: string | undefined;
}
export type KernelSpecs = KernelSpec[];
export type MountPath = string;
export type DefaultUid = number;
export type DefaultGid = number;
export interface FileSystemConfig {
    MountPath?: string | undefined;
    DefaultUid?: number | undefined;
    DefaultGid?: number | undefined;
}
export interface KernelGatewayImageConfig {
    KernelSpecs?: KernelSpec[] | undefined;
    FileSystemConfig?: FileSystemConfig | undefined;
}
export type NonEmptyString64 = string;
export type CustomImageContainerArguments = string[];
export type NonEmptyString256 = string;
export type CustomImageContainerEntrypoint = string[];
export type CustomImageContainerEnvironmentVariables = {
    [key: string]: string | undefined;
};
export interface ContainerConfig {
    ContainerArguments?: string[] | undefined;
    ContainerEntrypoint?: string[] | undefined;
    ContainerEnvironmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface JupyterLabAppImageConfig {
    FileSystemConfig?: FileSystemConfig | undefined;
    ContainerConfig?: ContainerConfig | undefined;
}
export interface CodeEditorAppImageConfig {
    FileSystemConfig?: FileSystemConfig | undefined;
    ContainerConfig?: ContainerConfig | undefined;
}
export interface CreateAppImageConfigRequest {
    AppImageConfigName?: string | undefined;
    Tags?: Tag[] | undefined;
    KernelGatewayImageConfig?: KernelGatewayImageConfig | undefined;
    JupyterLabAppImageConfig?: JupyterLabAppImageConfig | undefined;
    CodeEditorAppImageConfig?: CodeEditorAppImageConfig | undefined;
}
export type AppImageConfigArn = string;
export interface CreateAppImageConfigResponse {
    AppImageConfigArn?: string | undefined;
}
export type ArtifactSourceIdType = "MD5Hash" | "S3ETag" | "S3Version" | "Custom" | (string & {});
export interface ArtifactSourceType {
    SourceIdType?: ArtifactSourceIdType | undefined;
    Value?: string | undefined;
}
export type ArtifactSourceTypes = ArtifactSourceType[];
export interface ArtifactSource {
    SourceUri?: string | undefined;
    SourceTypes?: ArtifactSourceType[] | undefined;
}
export type ArtifactPropertyValue = string;
export type ArtifactProperties = {
    [key: string]: string | undefined;
};
export interface CreateArtifactRequest {
    ArtifactName?: string | undefined;
    Source?: ArtifactSource | undefined;
    ArtifactType?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    Tags?: Tag[] | undefined;
}
export type ArtifactArn = string;
export interface CreateArtifactResponse {
    ArtifactArn?: string | undefined;
}
export type AutoMLJobName = string;
export type AutoMLS3DataType = "ManifestFile" | "S3Prefix" | "AugmentedManifestFile" | (string & {});
export interface AutoMLS3DataSource {
    S3DataType?: AutoMLS3DataType | undefined;
    S3Uri?: string | undefined;
}
export interface AutoMLDataSource {
    S3DataSource?: AutoMLS3DataSource | undefined;
}
export type TargetAttributeName = string;
export type AutoMLChannelType = "training" | "validation" | (string & {});
export type SampleWeightAttributeName = string;
export interface AutoMLChannel {
    DataSource?: AutoMLDataSource | undefined;
    CompressionType?: CompressionType | undefined;
    TargetAttributeName?: string | undefined;
    ContentType?: string | undefined;
    ChannelType?: AutoMLChannelType | undefined;
    SampleWeightAttributeName?: string | undefined;
}
export type AutoMLInputDataConfig = AutoMLChannel[];
export interface AutoMLOutputDataConfig {
    KmsKeyId?: string | undefined;
    S3OutputPath?: string | undefined;
}
export type ProblemType = "BinaryClassification" | "MulticlassClassification" | "Regression" | (string & {});
export type AutoMLMetricEnum = "Accuracy" | "MSE" | "F1" | "F1macro" | "AUC" | "RMSE" | "BalancedAccuracy" | "R2" | "Recall" | "RecallMacro" | "Precision" | "PrecisionMacro" | "MAE" | "MAPE" | "MASE" | "WAPE" | "AverageWeightedQuantileLoss" | (string & {});
export interface AutoMLJobObjective {
    MetricName?: AutoMLMetricEnum | undefined;
}
export type MaxCandidates = number;
export type MaxRuntimePerTrainingJobInSeconds = number;
export type MaxAutoMLJobRuntimeInSeconds = number;
export interface AutoMLJobCompletionCriteria {
    MaxCandidates?: number | undefined;
    MaxRuntimePerTrainingJobInSeconds?: number | undefined;
    MaxAutoMLJobRuntimeInSeconds?: number | undefined;
}
export interface AutoMLSecurityConfig {
    VolumeKmsKeyId?: string | undefined;
    EnableInterContainerTrafficEncryption?: boolean | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export type AutoMLAlgorithm = "xgboost" | "linear-learner" | "mlp" | "lightgbm" | "catboost" | "randomforest" | "extra-trees" | "nn-torch" | "fastai" | "cnn-qr" | "deepar" | "prophet" | "npts" | "arima" | "ets" | (string & {});
export type AutoMLAlgorithms = AutoMLAlgorithm[];
export interface AutoMLAlgorithmConfig {
    AutoMLAlgorithms?: AutoMLAlgorithm[] | undefined;
}
export type AutoMLAlgorithmsConfig = AutoMLAlgorithmConfig[];
export interface AutoMLCandidateGenerationConfig {
    FeatureSpecificationS3Uri?: string | undefined;
    AlgorithmsConfig?: AutoMLAlgorithmConfig[] | undefined;
}
export type ValidationFraction = number;
export interface AutoMLDataSplitConfig {
    ValidationFraction?: number | undefined;
}
export type AutoMLMode = "AUTO" | "ENSEMBLING" | "HYPERPARAMETER_TUNING" | (string & {});
export interface AutoMLJobConfig {
    CompletionCriteria?: AutoMLJobCompletionCriteria | undefined;
    SecurityConfig?: AutoMLSecurityConfig | undefined;
    CandidateGenerationConfig?: AutoMLCandidateGenerationConfig | undefined;
    DataSplitConfig?: AutoMLDataSplitConfig | undefined;
    Mode?: AutoMLMode | undefined;
}
export type GenerateCandidateDefinitionsOnly = boolean;
export type AutoGenerateEndpointName = boolean;
export type EndpointName = string;
export interface ModelDeployConfig {
    AutoGenerateEndpointName?: boolean | undefined;
    EndpointName?: string | undefined;
}
export interface CreateAutoMLJobRequest {
    AutoMLJobName?: string | undefined;
    InputDataConfig?: AutoMLChannel[] | undefined;
    OutputDataConfig?: AutoMLOutputDataConfig | undefined;
    ProblemType?: ProblemType | undefined;
    AutoMLJobObjective?: AutoMLJobObjective | undefined;
    AutoMLJobConfig?: AutoMLJobConfig | undefined;
    RoleArn?: string | undefined;
    GenerateCandidateDefinitionsOnly?: boolean | undefined;
    Tags?: Tag[] | undefined;
    ModelDeployConfig?: ModelDeployConfig | undefined;
}
export type AutoMLJobArn = string;
export interface CreateAutoMLJobResponse {
    AutoMLJobArn: string;
}
export interface AutoMLJobChannel {
    ChannelType?: AutoMLChannelType | undefined;
    ContentType?: string | undefined;
    CompressionType?: CompressionType | undefined;
    DataSource?: AutoMLDataSource | undefined;
}
export type AutoMLJobInputDataConfig = AutoMLJobChannel[];
export interface ImageClassificationJobConfig {
    CompletionCriteria?: AutoMLJobCompletionCriteria | undefined;
}
export type ContentColumn = string;
export type TargetLabelColumn = string;
export interface TextClassificationJobConfig {
    CompletionCriteria?: AutoMLJobCompletionCriteria | undefined;
    ContentColumn?: string | undefined;
    TargetLabelColumn?: string | undefined;
}
export type ForecastFrequency = string;
export type ForecastHorizon = number;
export type ForecastQuantile = string;
export type ForecastQuantiles = string[];
export type TransformationAttributeName = string;
export type FillingType = "frontfill" | "middlefill" | "backfill" | "futurefill" | "frontfill_value" | "middlefill_value" | "backfill_value" | "futurefill_value" | (string & {});
export type FillingTransformationValue = string;
export type FillingTransformationMap = {
    [key in FillingType]?: string | undefined;
};
export type FillingTransformations = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export type AggregationTransformationValue = "sum" | "avg" | "first" | "min" | "max" | (string & {});
export type AggregationTransformations = {
    [key: string]: AggregationTransformationValue | undefined;
};
export interface TimeSeriesTransformations {
    Filling?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    Aggregation?: {
        [key: string]: AggregationTransformationValue | undefined;
    } | undefined;
}
export type TimestampAttributeName = string;
export type ItemIdentifierAttributeName = string;
export type GroupingAttributeName = string;
export type GroupingAttributeNames = string[];
export interface TimeSeriesConfig {
    TargetAttributeName?: string | undefined;
    TimestampAttributeName?: string | undefined;
    ItemIdentifierAttributeName?: string | undefined;
    GroupingAttributeNames?: string[] | undefined;
}
export type CountryCode = string;
export interface HolidayConfigAttributes {
    CountryCode?: string | undefined;
}
export type HolidayConfig = HolidayConfigAttributes[];
export interface CandidateGenerationConfig {
    AlgorithmsConfig?: AutoMLAlgorithmConfig[] | undefined;
}
export interface TimeSeriesForecastingJobConfig {
    FeatureSpecificationS3Uri?: string | undefined;
    CompletionCriteria?: AutoMLJobCompletionCriteria | undefined;
    ForecastFrequency?: string | undefined;
    ForecastHorizon?: number | undefined;
    ForecastQuantiles?: string[] | undefined;
    Transformations?: TimeSeriesTransformations | undefined;
    TimeSeriesConfig?: TimeSeriesConfig | undefined;
    HolidayConfig?: HolidayConfigAttributes[] | undefined;
    CandidateGenerationConfig?: CandidateGenerationConfig | undefined;
}
export interface TabularJobConfig {
    CandidateGenerationConfig?: CandidateGenerationConfig | undefined;
    CompletionCriteria?: AutoMLJobCompletionCriteria | undefined;
    FeatureSpecificationS3Uri?: string | undefined;
    Mode?: AutoMLMode | undefined;
    GenerateCandidateDefinitionsOnly?: boolean | undefined;
    ProblemType?: ProblemType | undefined;
    TargetAttributeName?: string | undefined;
    SampleWeightAttributeName?: string | undefined;
}
export type BaseModelName = string;
export type TextGenerationHyperParameterKey = string;
export type TextGenerationHyperParameterValue = string;
export type TextGenerationHyperParameters = {
    [key: string]: string | undefined;
};
export interface TextGenerationJobConfig {
    CompletionCriteria?: AutoMLJobCompletionCriteria | undefined;
    BaseModelName?: string | undefined;
    TextGenerationHyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ModelAccessConfig?: ModelAccessConfig | undefined;
}
export type AutoMLProblemTypeConfig = {
    ImageClassificationJobConfig: ImageClassificationJobConfig;
    TextClassificationJobConfig?: undefined;
    TimeSeriesForecastingJobConfig?: undefined;
    TabularJobConfig?: undefined;
    TextGenerationJobConfig?: undefined;
} | {
    ImageClassificationJobConfig?: undefined;
    TextClassificationJobConfig: TextClassificationJobConfig;
    TimeSeriesForecastingJobConfig?: undefined;
    TabularJobConfig?: undefined;
    TextGenerationJobConfig?: undefined;
} | {
    ImageClassificationJobConfig?: undefined;
    TextClassificationJobConfig?: undefined;
    TimeSeriesForecastingJobConfig: TimeSeriesForecastingJobConfig;
    TabularJobConfig?: undefined;
    TextGenerationJobConfig?: undefined;
} | {
    ImageClassificationJobConfig?: undefined;
    TextClassificationJobConfig?: undefined;
    TimeSeriesForecastingJobConfig?: undefined;
    TabularJobConfig: TabularJobConfig;
    TextGenerationJobConfig?: undefined;
} | {
    ImageClassificationJobConfig?: undefined;
    TextClassificationJobConfig?: undefined;
    TimeSeriesForecastingJobConfig?: undefined;
    TabularJobConfig?: undefined;
    TextGenerationJobConfig: TextGenerationJobConfig;
};
export interface EmrServerlessComputeConfig {
    ExecutionRoleARN?: string | undefined;
}
export interface AutoMLComputeConfig {
    EmrServerlessComputeConfig?: EmrServerlessComputeConfig | undefined;
}
export interface CreateAutoMLJobV2Request {
    AutoMLJobName?: string | undefined;
    AutoMLJobInputDataConfig?: AutoMLJobChannel[] | undefined;
    OutputDataConfig?: AutoMLOutputDataConfig | undefined;
    AutoMLProblemTypeConfig?: AutoMLProblemTypeConfig | undefined;
    RoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
    SecurityConfig?: AutoMLSecurityConfig | undefined;
    AutoMLJobObjective?: AutoMLJobObjective | undefined;
    ModelDeployConfig?: ModelDeployConfig | undefined;
    DataSplitConfig?: AutoMLDataSplitConfig | undefined;
    AutoMLComputeConfig?: AutoMLComputeConfig | undefined;
}
export interface CreateAutoMLJobV2Response {
    AutoMLJobArn: string;
}
export type ClusterName = string;
export type ClusterInstanceCount = number;
export interface ClusterInstanceRequirements {
    InstanceTypes?: ClusterInstanceType[] | undefined;
}
export type ClusterLifeCycleConfigFileName = string;
export interface ClusterLifeCycleConfig {
    SourceS3Uri?: string | undefined;
    OnCreate?: string | undefined;
    OnInitComplete?: string | undefined;
}
export type ClusterThreadsPerCore = number;
export type ClusterEbsVolumeSizeInGB = number;
export interface ClusterEbsVolumeConfig {
    VolumeSizeInGB?: number | undefined;
    VolumeKmsKeyId?: string | undefined;
    RootVolume?: boolean | undefined;
}
export type ClusterDnsName = string;
export type ClusterMountName = string;
export type ClusterFsxMountPath = string;
export interface ClusterFsxLustreConfig {
    DnsName: string;
    MountName: string;
    MountPath?: string | undefined;
}
export interface ClusterFsxOpenZfsConfig {
    DnsName: string;
    MountPath?: string | undefined;
}
export type ClusterInstanceStorageConfig = {
    EbsVolumeConfig: ClusterEbsVolumeConfig;
    FsxLustreConfig?: undefined;
    FsxOpenZfsConfig?: undefined;
} | {
    EbsVolumeConfig?: undefined;
    FsxLustreConfig: ClusterFsxLustreConfig;
    FsxOpenZfsConfig?: undefined;
} | {
    EbsVolumeConfig?: undefined;
    FsxLustreConfig?: undefined;
    FsxOpenZfsConfig: ClusterFsxOpenZfsConfig;
};
export type ClusterInstanceStorageConfigs = ClusterInstanceStorageConfig[];
export type DeepHealthCheckType = "InstanceStress" | "InstanceConnectivity" | "MultiNodeTrainingValidation" | (string & {});
export type OnStartDeepHealthChecks = DeepHealthCheckType[];
export type CronScheduleExpression = string;
export type NodeUnavailabilityType = "INSTANCE_COUNT" | "CAPACITY_PERCENTAGE" | (string & {});
export type NodeUnavailabilityValue = number;
export interface CapacitySizeConfig {
    Type?: NodeUnavailabilityType | undefined;
    Value?: number | undefined;
}
export interface RollingDeploymentPolicy {
    MaximumBatchSize?: CapacitySizeConfig | undefined;
    RollbackMaximumBatchSize?: CapacitySizeConfig | undefined;
}
export type WaitTimeIntervalInSeconds = number;
export type AlarmName = string;
export interface AlarmDetails {
    AlarmName?: string | undefined;
}
export type AutoRollbackAlarms = AlarmDetails[];
export interface DeploymentConfiguration {
    RollingUpdatePolicy?: RollingDeploymentPolicy | undefined;
    WaitIntervalInSeconds?: number | undefined;
    AutoRollbackConfiguration?: AlarmDetails[] | undefined;
}
export interface ScheduledUpdateConfig {
    ScheduleExpression?: string | undefined;
    DeploymentConfig?: DeploymentConfiguration | undefined;
}
export type ImageId = string;
export type ClusterPatchingStrategy = "WhenIdle" | "WhenAllIdle" | "DrainFirst" | (string & {});
export interface ClusterPatchSchedule {
    NextPatchDate?: Date | undefined;
}
export type IdleWaitWindowInSecondsValue = number;
export type DrainTimeoutInSecondsValue = number;
export type ClusterOnDrainTimeout = "Force" | "Skip" | (string & {});
export interface ClusterDrainPolicy {
    DrainTimeoutInSeconds?: number | undefined;
    OnDrainTimeout?: ClusterOnDrainTimeout | undefined;
}
export interface ClusterAutoPatchConfig {
    PatchingStrategy: ClusterPatchingStrategy;
    PatchSchedule?: ClusterPatchSchedule | undefined;
    DeploymentConfig?: DeploymentConfiguration | undefined;
    IdleWaitWindowInSeconds?: number | undefined;
    DrainPolicy?: ClusterDrainPolicy | undefined;
}
export type ImageReleaseVersion = string;
export type ClusterKubernetesLabelKey = string;
export type ClusterKubernetesLabelValue = string;
export type ClusterKubernetesLabels = {
    [key: string]: string | undefined;
};
export type ClusterKubernetesTaintKey = string;
export type ClusterKubernetesTaintValue = string;
export type ClusterKubernetesTaintEffect = "NoSchedule" | "PreferNoSchedule" | "NoExecute" | (string & {});
export interface ClusterKubernetesTaint {
    Key: string;
    Value?: string | undefined;
    Effect: ClusterKubernetesTaintEffect;
}
export type ClusterKubernetesTaints = ClusterKubernetesTaint[];
export interface ClusterKubernetesConfig {
    Labels?: {
        [key: string]: string | undefined;
    } | undefined;
    Taints?: ClusterKubernetesTaint[] | undefined;
}
export type ClusterSlurmNodeType = "Controller" | "Login" | "Compute" | (string & {});
export type ClusterPartitionName = string;
export type ClusterPartitionNames = string[];
export interface ClusterSlurmConfig {
    NodeType: ClusterSlurmNodeType;
    PartitionNames?: string[] | undefined;
}
export interface ClusterSpotOptions {
}
export interface ClusterOnDemandOptions {
}
export interface ClusterCapacityRequirements {
    Spot?: ClusterSpotOptions | undefined;
    OnDemand?: ClusterOnDemandOptions | undefined;
}
export type ClusterInterfaceType = "efa" | "efa-only" | (string & {});
export interface ClusterNetworkInterface {
    InterfaceType?: ClusterInterfaceType | undefined;
}
export interface ClusterInstanceGroupSpecification {
    InstanceCount?: number | undefined;
    MinInstanceCount?: number | undefined;
    InstanceGroupName?: string | undefined;
    InstanceType?: ClusterInstanceType | undefined;
    InstanceRequirements?: ClusterInstanceRequirements | undefined;
    LifeCycleConfig?: ClusterLifeCycleConfig | undefined;
    ExecutionRole?: string | undefined;
    ThreadsPerCore?: number | undefined;
    InstanceStorageConfigs?: ClusterInstanceStorageConfig[] | undefined;
    OnStartDeepHealthChecks?: DeepHealthCheckType[] | undefined;
    TrainingPlanArn?: string | undefined;
    OverrideVpcConfig?: VpcConfig | undefined;
    ScheduledUpdateConfig?: ScheduledUpdateConfig | undefined;
    ImageId?: string | undefined;
    AutoPatchConfig?: ClusterAutoPatchConfig | undefined;
    ImageReleaseVersion?: string | undefined;
    KubernetesConfig?: ClusterKubernetesConfig | undefined;
    SlurmConfig?: ClusterSlurmConfig | undefined;
    CapacityRequirements?: ClusterCapacityRequirements | undefined;
    NetworkInterface?: ClusterNetworkInterface | undefined;
}
export type ClusterInstanceGroupSpecifications = ClusterInstanceGroupSpecification[];
export type FSxLustreSizeInGiB = number;
export type FSxLustrePerUnitStorageThroughput = number;
export interface FSxLustreConfig {
    SizeInGiB?: number | undefined;
    PerUnitStorageThroughput?: number | undefined;
}
export interface EnvironmentConfig {
    FSxLustreConfig?: FSxLustreConfig | undefined;
}
export interface ClusterRestrictedInstanceGroupSpecification {
    InstanceCount?: number | undefined;
    InstanceGroupName?: string | undefined;
    InstanceType?: ClusterInstanceType | undefined;
    ExecutionRole?: string | undefined;
    ThreadsPerCore?: number | undefined;
    InstanceStorageConfigs?: ClusterInstanceStorageConfig[] | undefined;
    OnStartDeepHealthChecks?: DeepHealthCheckType[] | undefined;
    TrainingPlanArn?: string | undefined;
    OverrideVpcConfig?: VpcConfig | undefined;
    ScheduledUpdateConfig?: ScheduledUpdateConfig | undefined;
    EnvironmentConfig?: EnvironmentConfig | undefined;
}
export type ClusterRestrictedInstanceGroupSpecifications = ClusterRestrictedInstanceGroupSpecification[];
export type ClusterFSxLustreDeletionPolicy = "DeleteIfNotUsed" | "Keep" | (string & {});
export interface ClusterSharedEnvironmentConfig {
    FSxLustreDeletionPolicy?: ClusterFSxLustreDeletionPolicy | undefined;
    FSxLustreConfig?: FSxLustreConfig | undefined;
}
export interface ClusterRestrictedInstanceGroupsConfig {
    SharedEnvironmentConfig?: ClusterSharedEnvironmentConfig | undefined;
}
export type EksClusterArn = string;
export interface ClusterOrchestratorEksConfig {
    ClusterArn?: string | undefined;
}
export type ClusterSlurmConfigStrategy = "Overwrite" | "Managed" | "Merge" | (string & {});
export type ClusterAccountingDatabaseEndpoint = string;
export type ClusterAccountingDatabasePort = number;
export type ClusterAccountingDatabaseName = string;
export type ClusterAccountingDatabaseSecretArn = string;
export interface ClusterAccountingDatabase {
    Endpoint: string;
    Port?: number | undefined;
    Name?: string | undefined;
    SecretArn: string;
}
export interface ClusterOrchestratorSlurmConfig {
    SlurmConfigStrategy?: ClusterSlurmConfigStrategy | undefined;
    AccountingDatabase?: ClusterAccountingDatabase | undefined;
}
export interface ClusterOrchestrator {
    Eks?: ClusterOrchestratorEksConfig | undefined;
    Slurm?: ClusterOrchestratorSlurmConfig | undefined;
}
export type ClusterNodeRecovery = "Automatic" | "None" | (string & {});
export type ClusterConfigMode = "Enable" | "Disable" | (string & {});
export type ClusterInstanceMemoryAllocationPercentage = number;
export interface ClusterTieredStorageConfig {
    Mode?: ClusterConfigMode | undefined;
    InstanceMemoryAllocationPercentage?: number | undefined;
}
export type ClusterNodeProvisioningMode = "Continuous" | (string & {});
export type ClusterAutoScalingMode = "Enable" | "Disable" | (string & {});
export type ClusterAutoScalerType = "Karpenter" | (string & {});
export interface ClusterAutoScalingConfig {
    Mode: ClusterAutoScalingMode;
    AutoScalerType?: ClusterAutoScalerType | undefined;
}
export interface CreateClusterRequest {
    ClusterName?: string | undefined;
    InstanceGroups?: ClusterInstanceGroupSpecification[] | undefined;
    RestrictedInstanceGroups?: ClusterRestrictedInstanceGroupSpecification[] | undefined;
    RestrictedInstanceGroupsConfig?: ClusterRestrictedInstanceGroupsConfig | undefined;
    VpcConfig?: VpcConfig | undefined;
    Tags?: Tag[] | undefined;
    Orchestrator?: ClusterOrchestrator | undefined;
    NodeRecovery?: ClusterNodeRecovery | undefined;
    TieredStorageConfig?: ClusterTieredStorageConfig | undefined;
    NodeProvisioningMode?: ClusterNodeProvisioningMode | undefined;
    ClusterRole?: string | undefined;
    AutoScaling?: ClusterAutoScalingConfig | undefined;
}
export interface CreateClusterResponse {
    ClusterArn: string;
}
export type ExtensionName = string;
export type ExtensionVersion = string;
export type ExtensionConfigurationValues = string;
export interface CreateClusterExtensionRequest {
    ClusterArn?: string | undefined;
    ExtensionName?: string | undefined;
    ExtensionVersion?: string | undefined;
    ConfigurationValues?: string | undefined;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
}
export type ExtensionArn = string;
export interface CreateClusterExtensionResponse {
    ExtensionArn: string;
}
export type ClusterSchedulerPriorityClassName = string;
export type PriorityWeight = number;
export interface PriorityClass {
    Name?: string | undefined;
    Weight?: number | undefined;
}
export type PriorityClassList = PriorityClass[];
export type FairShare = "Enabled" | "Disabled" | (string & {});
export type IdleResourceSharing = "Enabled" | "Disabled" | (string & {});
export interface SchedulerConfig {
    PriorityClasses?: PriorityClass[] | undefined;
    FairShare?: FairShare | undefined;
    IdleResourceSharing?: IdleResourceSharing | undefined;
}
export interface CreateClusterSchedulerConfigRequest {
    Name?: string | undefined;
    ClusterArn?: string | undefined;
    SchedulerConfig?: SchedulerConfig | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type ClusterSchedulerConfigArn = string;
export type ClusterSchedulerConfigId = string;
export interface CreateClusterSchedulerConfigResponse {
    ClusterSchedulerConfigArn: string;
    ClusterSchedulerConfigId: string;
}
export type GitConfigUrl = string;
export type Branch = string;
export type SecretArn = string;
export interface GitConfig {
    RepositoryUrl?: string | undefined;
    Branch?: string | undefined;
    SecretArn?: string | undefined;
}
export interface CreateCodeRepositoryInput {
    CodeRepositoryName?: string | undefined;
    GitConfig?: GitConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type CodeRepositoryArn = string;
export interface CreateCodeRepositoryOutput {
    CodeRepositoryArn: string;
}
export type Framework = "TENSORFLOW" | "KERAS" | "MXNET" | "ONNX" | "PYTORCH" | "XGBOOST" | "TFLITE" | "DARKNET" | "SKLEARN" | (string & {});
export type FrameworkVersion = string;
export interface InputConfig {
    S3Uri?: string | undefined;
    DataInputConfig?: string | undefined;
    Framework?: Framework | undefined;
    FrameworkVersion?: string | undefined;
}
export type TargetDevice = "lambda" | "ml_m4" | "ml_m5" | "ml_m6g" | "ml_c4" | "ml_c5" | "ml_c6g" | "ml_p2" | "ml_p3" | "ml_g4dn" | "ml_inf1" | "ml_inf2" | "ml_trn1" | "ml_eia2" | "jetson_tx1" | "jetson_tx2" | "jetson_nano" | "jetson_xavier" | "rasp3b" | "rasp4b" | "imx8qm" | "deeplens" | "rk3399" | "rk3288" | "aisage" | "sbe_c" | "qcs605" | "qcs603" | "sitara_am57x" | "amba_cv2" | "amba_cv22" | "amba_cv25" | "x86_win32" | "x86_win64" | "coreml" | "jacinto_tda4vm" | "imx8mplus" | (string & {});
export type TargetPlatformOs = "ANDROID" | "LINUX" | (string & {});
export type TargetPlatformArch = "X86_64" | "X86" | "ARM64" | "ARM_EABI" | "ARM_EABIHF" | (string & {});
export type TargetPlatformAccelerator = "INTEL_GRAPHICS" | "MALI" | "NVIDIA" | "NNA" | (string & {});
export interface TargetPlatform {
    Os?: TargetPlatformOs | undefined;
    Arch?: TargetPlatformArch | undefined;
    Accelerator?: TargetPlatformAccelerator | undefined;
}
export type CompilerOptions = string;
export interface OutputConfig {
    S3OutputLocation?: string | undefined;
    TargetDevice?: TargetDevice | undefined;
    TargetPlatform?: TargetPlatform | undefined;
    CompilerOptions?: string | undefined;
    KmsKeyId?: string | undefined;
}
export type NeoVpcSecurityGroupId = string;
export type NeoVpcSecurityGroupIds = string[];
export type NeoVpcSubnetId = string;
export type NeoVpcSubnets = string[];
export interface NeoVpcConfig {
    SecurityGroupIds?: string[] | undefined;
    Subnets?: string[] | undefined;
}
export interface CreateCompilationJobRequest {
    CompilationJobName?: string | undefined;
    RoleArn?: string | undefined;
    ModelPackageVersionArn?: string | undefined;
    InputConfig?: InputConfig | undefined;
    OutputConfig?: OutputConfig | undefined;
    VpcConfig?: NeoVpcConfig | undefined;
    StoppingCondition?: StoppingCondition | undefined;
    Tags?: Tag[] | undefined;
}
export type CompilationJobArn = string;
export interface CreateCompilationJobResponse {
    CompilationJobArn: string;
}
export type InstanceCount = number;
export type AcceleratorsAmount = number;
export type VCpuAmount = number;
export type MemoryInGiBAmount = number;
export type MIGProfileType = "mig-1g.5gb" | "mig-1g.10gb" | "mig-1g.18gb" | "mig-1g.20gb" | "mig-1g.23gb" | "mig-1g.35gb" | "mig-1g.45gb" | "mig-1g.47gb" | "mig-2g.10gb" | "mig-2g.20gb" | "mig-2g.35gb" | "mig-2g.45gb" | "mig-2g.47gb" | "mig-3g.20gb" | "mig-3g.40gb" | "mig-3g.71gb" | "mig-3g.90gb" | "mig-3g.93gb" | "mig-4g.20gb" | "mig-4g.40gb" | "mig-4g.71gb" | "mig-4g.90gb" | "mig-4g.93gb" | "mig-7g.40gb" | "mig-7g.80gb" | "mig-7g.141gb" | "mig-7g.180gb" | "mig-7g.186gb" | (string & {});
export interface AcceleratorPartitionConfig {
    Type?: MIGProfileType | undefined;
    Count?: number | undefined;
}
export interface ComputeQuotaResourceConfig {
    InstanceType?: ClusterInstanceType | undefined;
    Count?: number | undefined;
    Accelerators?: number | undefined;
    VCpu?: number | undefined;
    MemoryInGiB?: number | undefined;
    AcceleratorPartition?: AcceleratorPartitionConfig | undefined;
}
export type ComputeQuotaResourceConfigList = ComputeQuotaResourceConfig[];
export type ResourceSharingStrategy = "Lend" | "DontLend" | "LendAndBorrow" | (string & {});
export type BorrowLimit = number;
export type AbsoluteBorrowLimitResourceList = ComputeQuotaResourceConfig[];
export interface ResourceSharingConfig {
    Strategy?: ResourceSharingStrategy | undefined;
    BorrowLimit?: number | undefined;
    AbsoluteBorrowLimits?: ComputeQuotaResourceConfig[] | undefined;
}
export type PreemptTeamTasks = "Never" | "LowerPriority" | (string & {});
export interface ComputeQuotaConfig {
    ComputeQuotaResources?: ComputeQuotaResourceConfig[] | undefined;
    ResourceSharingConfig?: ResourceSharingConfig | undefined;
    PreemptTeamTasks?: PreemptTeamTasks | undefined;
}
export type ComputeQuotaTargetTeamName = string;
export type FairShareWeight = number;
export interface ComputeQuotaTarget {
    TeamName?: string | undefined;
    FairShareWeight?: number | undefined;
}
export type ActivationState = "Enabled" | "Disabled" | (string & {});
export interface CreateComputeQuotaRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    ClusterArn?: string | undefined;
    ComputeQuotaConfig?: ComputeQuotaConfig | undefined;
    ComputeQuotaTarget?: ComputeQuotaTarget | undefined;
    ActivationState?: ActivationState | undefined;
    Tags?: Tag[] | undefined;
}
export type ComputeQuotaArn = string;
export type ComputeQuotaId = string;
export interface CreateComputeQuotaResponse {
    ComputeQuotaArn: string;
    ComputeQuotaId: string;
}
export type ContextName = string;
export interface ContextSource {
    SourceUri?: string | undefined;
    SourceType?: string | undefined;
    SourceId?: string | undefined;
}
export interface CreateContextRequest {
    ContextName?: string | undefined;
    Source?: ContextSource | undefined;
    ContextType?: string | undefined;
    Description?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
}
export type ContextArn = string;
export interface CreateContextResponse {
    ContextArn?: string | undefined;
}
export type MonitoringJobDefinitionName = string;
export type ProcessingJobName = string;
export interface MonitoringConstraintsResource {
    S3Uri?: string | undefined;
}
export interface MonitoringStatisticsResource {
    S3Uri?: string | undefined;
}
export interface DataQualityBaselineConfig {
    BaseliningJobName?: string | undefined;
    ConstraintsResource?: MonitoringConstraintsResource | undefined;
    StatisticsResource?: MonitoringStatisticsResource | undefined;
}
export type ImageUri = string;
export type ContainerEntrypointString = string;
export type ContainerEntrypoint = string[];
export type ContainerArgument = string;
export type MonitoringContainerArguments = string[];
export type ProcessingEnvironmentKey = string;
export type ProcessingEnvironmentValue = string;
export type MonitoringEnvironmentMap = {
    [key: string]: string | undefined;
};
export interface DataQualityAppSpecification {
    ImageUri?: string | undefined;
    ContainerEntrypoint?: string[] | undefined;
    ContainerArguments?: string[] | undefined;
    RecordPreprocessorSourceUri?: string | undefined;
    PostAnalyticsProcessorSourceUri?: string | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProcessingLocalPath = string;
export type ProcessingS3InputMode = "Pipe" | "File" | (string & {});
export type ProcessingS3DataDistributionType = "FullyReplicated" | "ShardedByS3Key" | (string & {});
export type ProbabilityThresholdAttribute = number;
export type MonitoringTimeOffsetString = string;
export type ExcludeFeaturesAttribute = string;
export interface EndpointInput {
    EndpointName?: string | undefined;
    LocalPath?: string | undefined;
    S3InputMode?: ProcessingS3InputMode | undefined;
    S3DataDistributionType?: ProcessingS3DataDistributionType | undefined;
    FeaturesAttribute?: string | undefined;
    InferenceAttribute?: string | undefined;
    ProbabilityAttribute?: string | undefined;
    ProbabilityThresholdAttribute?: number | undefined;
    StartTimeOffset?: string | undefined;
    EndTimeOffset?: string | undefined;
    ExcludeFeaturesAttribute?: string | undefined;
}
export type DestinationS3Uri = string;
export interface MonitoringCsvDatasetFormat {
    Header?: boolean | undefined;
}
export interface MonitoringJsonDatasetFormat {
    Line?: boolean | undefined;
}
export interface MonitoringParquetDatasetFormat {
}
export interface MonitoringDatasetFormat {
    Csv?: MonitoringCsvDatasetFormat | undefined;
    Json?: MonitoringJsonDatasetFormat | undefined;
    Parquet?: MonitoringParquetDatasetFormat | undefined;
}
export interface BatchTransformInput {
    DataCapturedDestinationS3Uri?: string | undefined;
    DatasetFormat?: MonitoringDatasetFormat | undefined;
    LocalPath?: string | undefined;
    S3InputMode?: ProcessingS3InputMode | undefined;
    S3DataDistributionType?: ProcessingS3DataDistributionType | undefined;
    FeaturesAttribute?: string | undefined;
    InferenceAttribute?: string | undefined;
    ProbabilityAttribute?: string | undefined;
    ProbabilityThresholdAttribute?: number | undefined;
    StartTimeOffset?: string | undefined;
    EndTimeOffset?: string | undefined;
    ExcludeFeaturesAttribute?: string | undefined;
}
export interface DataQualityJobInput {
    EndpointInput?: EndpointInput | undefined;
    BatchTransformInput?: BatchTransformInput | undefined;
}
export type MonitoringS3Uri = string;
export type ProcessingS3UploadMode = "Continuous" | "EndOfJob" | (string & {});
export interface MonitoringS3Output {
    S3Uri?: string | undefined;
    LocalPath?: string | undefined;
    S3UploadMode?: ProcessingS3UploadMode | undefined;
}
export interface MonitoringOutput {
    S3Output?: MonitoringS3Output | undefined;
}
export type MonitoringOutputs = MonitoringOutput[];
export interface MonitoringOutputConfig {
    MonitoringOutputs?: MonitoringOutput[] | undefined;
    KmsKeyId?: string | undefined;
}
export type ProcessingInstanceCount = number;
export type ProcessingInstanceType = "ml.t3.medium" | "ml.t3.large" | "ml.t3.xlarge" | "ml.t3.2xlarge" | "ml.m4.xlarge" | "ml.m4.2xlarge" | "ml.m4.4xlarge" | "ml.m4.10xlarge" | "ml.m4.16xlarge" | "ml.c4.xlarge" | "ml.c4.2xlarge" | "ml.c4.4xlarge" | "ml.c4.8xlarge" | "ml.p2.xlarge" | "ml.p2.8xlarge" | "ml.p2.16xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | "ml.p3.16xlarge" | "ml.c5.xlarge" | "ml.c5.2xlarge" | "ml.c5.4xlarge" | "ml.c5.9xlarge" | "ml.c5.18xlarge" | "ml.m5.large" | "ml.m5.xlarge" | "ml.m5.2xlarge" | "ml.m5.4xlarge" | "ml.m5.12xlarge" | "ml.m5.24xlarge" | "ml.r5.large" | "ml.r5.xlarge" | "ml.r5.2xlarge" | "ml.r5.4xlarge" | "ml.r5.8xlarge" | "ml.r5.12xlarge" | "ml.r5.16xlarge" | "ml.r5.24xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.16xlarge" | "ml.g5.12xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.r5d.large" | "ml.r5d.xlarge" | "ml.r5d.2xlarge" | "ml.r5d.4xlarge" | "ml.r5d.8xlarge" | "ml.r5d.12xlarge" | "ml.r5d.16xlarge" | "ml.r5d.24xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.12xlarge" | "ml.g6.16xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.12xlarge" | "ml.g6e.16xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | "ml.m6i.large" | "ml.m6i.xlarge" | "ml.m6i.2xlarge" | "ml.m6i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.12xlarge" | "ml.m6i.16xlarge" | "ml.m6i.24xlarge" | "ml.m6i.32xlarge" | "ml.c6i.xlarge" | "ml.c6i.2xlarge" | "ml.c6i.4xlarge" | "ml.c6i.8xlarge" | "ml.c6i.12xlarge" | "ml.c6i.16xlarge" | "ml.c6i.24xlarge" | "ml.c6i.32xlarge" | "ml.m7i.large" | "ml.m7i.xlarge" | "ml.m7i.2xlarge" | "ml.m7i.4xlarge" | "ml.m7i.8xlarge" | "ml.m7i.12xlarge" | "ml.m7i.16xlarge" | "ml.m7i.24xlarge" | "ml.m7i.48xlarge" | "ml.c7i.large" | "ml.c7i.xlarge" | "ml.c7i.2xlarge" | "ml.c7i.4xlarge" | "ml.c7i.8xlarge" | "ml.c7i.12xlarge" | "ml.c7i.16xlarge" | "ml.c7i.24xlarge" | "ml.c7i.48xlarge" | "ml.r7i.large" | "ml.r7i.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.4xlarge" | "ml.r7i.8xlarge" | "ml.r7i.12xlarge" | "ml.r7i.16xlarge" | "ml.r7i.24xlarge" | "ml.r7i.48xlarge" | "ml.p5.4xlarge" | "ml.g7e.2xlarge" | "ml.g7e.4xlarge" | "ml.g7e.8xlarge" | "ml.g7e.12xlarge" | "ml.g7e.24xlarge" | "ml.g7e.48xlarge" | "ml.g7.2xlarge" | "ml.g7.4xlarge" | "ml.g7.8xlarge" | "ml.g7.12xlarge" | "ml.g7.24xlarge" | "ml.g7.48xlarge" | "ml.r6i.large" | "ml.r6i.xlarge" | "ml.r6i.2xlarge" | "ml.r6i.4xlarge" | "ml.r6i.8xlarge" | "ml.r6i.12xlarge" | "ml.r6i.16xlarge" | "ml.r6i.24xlarge" | "ml.r6i.32xlarge" | "ml.m8i.large" | "ml.m8i.xlarge" | "ml.m8i.2xlarge" | "ml.m8i.4xlarge" | "ml.m8i.8xlarge" | "ml.m8i.12xlarge" | "ml.m8i.16xlarge" | "ml.m8i.24xlarge" | "ml.m8i.32xlarge" | "ml.m8i.48xlarge" | "ml.m8i.96xlarge" | "ml.c8i.xlarge" | "ml.c8i.2xlarge" | "ml.c8i.4xlarge" | "ml.c8i.8xlarge" | "ml.c8i.12xlarge" | "ml.c8i.16xlarge" | "ml.c8i.24xlarge" | "ml.c8i.32xlarge" | "ml.c8i.48xlarge" | "ml.c8i.96xlarge" | "ml.r8i.large" | "ml.r8i.xlarge" | "ml.r8i.2xlarge" | "ml.r8i.4xlarge" | "ml.r8i.8xlarge" | "ml.r8i.12xlarge" | "ml.r8i.16xlarge" | "ml.r8i.24xlarge" | "ml.r8i.32xlarge" | "ml.r8i.48xlarge" | "ml.r8i.96xlarge" | "ml.m7i-flex.large" | "ml.m7i-flex.xlarge" | "ml.m7i-flex.2xlarge" | "ml.m7i-flex.4xlarge" | "ml.m7i-flex.8xlarge" | "ml.m7i-flex.12xlarge" | "ml.m7i-flex.16xlarge" | "ml.c7i-flex.xlarge" | "ml.c7i-flex.2xlarge" | "ml.c7i-flex.4xlarge" | "ml.c7i-flex.8xlarge" | "ml.c7i-flex.12xlarge" | "ml.c7i-flex.16xlarge" | "ml.m8i-flex.large" | "ml.m8i-flex.xlarge" | "ml.m8i-flex.2xlarge" | "ml.m8i-flex.4xlarge" | "ml.m8i-flex.8xlarge" | "ml.m8i-flex.12xlarge" | "ml.m8i-flex.16xlarge" | "ml.c8i-flex.xlarge" | "ml.c8i-flex.2xlarge" | "ml.c8i-flex.4xlarge" | "ml.c8i-flex.8xlarge" | "ml.c8i-flex.12xlarge" | "ml.c8i-flex.16xlarge" | "ml.r8i-flex.large" | "ml.r8i-flex.xlarge" | "ml.r8i-flex.2xlarge" | "ml.r8i-flex.4xlarge" | "ml.r8i-flex.8xlarge" | "ml.r8i-flex.12xlarge" | "ml.r8i-flex.16xlarge" | (string & {});
export type ProcessingVolumeSizeInGB = number;
export interface MonitoringClusterConfig {
    InstanceCount?: number | undefined;
    InstanceType?: ProcessingInstanceType | undefined;
    VolumeSizeInGB?: number | undefined;
    VolumeKmsKeyId?: string | undefined;
}
export interface MonitoringResources {
    ClusterConfig?: MonitoringClusterConfig | undefined;
}
export interface MonitoringNetworkConfig {
    EnableInterContainerTrafficEncryption?: boolean | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export type MonitoringMaxRuntimeInSeconds = number;
export interface MonitoringStoppingCondition {
    MaxRuntimeInSeconds?: number | undefined;
}
export interface CreateDataQualityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
    DataQualityBaselineConfig?: DataQualityBaselineConfig | undefined;
    DataQualityAppSpecification?: DataQualityAppSpecification | undefined;
    DataQualityJobInput?: DataQualityJobInput | undefined;
    DataQualityJobOutputConfig?: MonitoringOutputConfig | undefined;
    JobResources?: MonitoringResources | undefined;
    NetworkConfig?: MonitoringNetworkConfig | undefined;
    RoleArn?: string | undefined;
    StoppingCondition?: MonitoringStoppingCondition | undefined;
    Tags?: Tag[] | undefined;
}
export type MonitoringJobDefinitionArn = string;
export interface CreateDataQualityJobDefinitionResponse {
    JobDefinitionArn: string;
}
export type DeviceFleetDescription = string;
export type EdgePresetDeploymentType = "GreengrassV2Component" | (string & {});
export interface EdgeOutputConfig {
    S3OutputLocation?: string | undefined;
    KmsKeyId?: string | undefined;
    PresetDeploymentType?: EdgePresetDeploymentType | undefined;
    PresetDeploymentConfig?: string | undefined;
}
export type EnableIotRoleAlias = boolean;
export interface CreateDeviceFleetRequest {
    DeviceFleetName?: string | undefined;
    RoleArn?: string | undefined;
    Description?: string | undefined;
    OutputConfig?: EdgeOutputConfig | undefined;
    Tags?: Tag[] | undefined;
    EnableIotRoleAlias?: boolean | undefined;
}
export interface CreateDeviceFleetResponse {
}
export type DomainName = string;
export type AuthMode = "SSO" | "IAM" | (string & {});
export type SecurityGroupIds = string[];
export type NotebookOutputOption = "Allowed" | "Disabled" | (string & {});
export interface SharingSettings {
    NotebookOutputOption?: NotebookOutputOption | undefined;
    S3OutputPath?: string | undefined;
    S3KmsKeyId?: string | undefined;
}
export type LifecycleConfigArns = string[];
export type RepositoryUrl = string;
export interface CodeRepository {
    RepositoryUrl?: string | undefined;
}
export type CodeRepositories = CodeRepository[];
export interface JupyterServerAppSettings {
    DefaultResourceSpec?: ResourceSpec | undefined;
    LifecycleConfigArns?: string[] | undefined;
    CodeRepositories?: CodeRepository[] | undefined;
}
export type ImageName = string;
export type ImageVersionNumber = number;
export interface CustomImage {
    ImageName?: string | undefined;
    ImageVersionNumber?: number | undefined;
    AppImageConfigName?: string | undefined;
}
export type CustomImages = CustomImage[];
export interface KernelGatewayAppSettings {
    DefaultResourceSpec?: ResourceSpec | undefined;
    CustomImages?: CustomImage[] | undefined;
    LifecycleConfigArns?: string[] | undefined;
}
export interface TensorBoardAppSettings {
    DefaultResourceSpec?: ResourceSpec | undefined;
}
export type RStudioServerProAccessStatus = "ENABLED" | "DISABLED" | (string & {});
export type RStudioServerProUserGroup = "R_STUDIO_ADMIN" | "R_STUDIO_USER" | (string & {});
export interface RStudioServerProAppSettings {
    AccessStatus?: RStudioServerProAccessStatus | undefined;
    UserGroup?: RStudioServerProUserGroup | undefined;
}
export interface RSessionAppSettings {
    DefaultResourceSpec?: ResourceSpec | undefined;
    CustomImages?: CustomImage[] | undefined;
}
export type FeatureStatus = "ENABLED" | "DISABLED" | (string & {});
export interface TimeSeriesForecastingSettings {
    Status?: FeatureStatus | undefined;
    AmazonForecastRoleArn?: string | undefined;
}
export interface ModelRegisterSettings {
    Status?: FeatureStatus | undefined;
    CrossAccountModelRegisterRoleArn?: string | undefined;
}
export interface WorkspaceSettings {
    S3ArtifactPath?: string | undefined;
    S3KmsKeyId?: string | undefined;
}
export type DataSourceName = "SalesforceGenie" | "Snowflake" | (string & {});
export interface IdentityProviderOAuthSetting {
    DataSourceName?: DataSourceName | undefined;
    Status?: FeatureStatus | undefined;
    SecretArn?: string | undefined;
}
export type IdentityProviderOAuthSettings = IdentityProviderOAuthSetting[];
export interface DirectDeploySettings {
    Status?: FeatureStatus | undefined;
}
export interface KendraSettings {
    Status?: FeatureStatus | undefined;
}
export interface GenerativeAiSettings {
    AmazonBedrockRoleArn?: string | undefined;
}
export interface EmrServerlessSettings {
    ExecutionRoleArn?: string | undefined;
    Status?: FeatureStatus | undefined;
}
export interface CanvasAppSettings {
    TimeSeriesForecastingSettings?: TimeSeriesForecastingSettings | undefined;
    ModelRegisterSettings?: ModelRegisterSettings | undefined;
    WorkspaceSettings?: WorkspaceSettings | undefined;
    IdentityProviderOAuthSettings?: IdentityProviderOAuthSetting[] | undefined;
    DirectDeploySettings?: DirectDeploySettings | undefined;
    KendraSettings?: KendraSettings | undefined;
    GenerativeAiSettings?: GenerativeAiSettings | undefined;
    EmrServerlessSettings?: EmrServerlessSettings | undefined;
}
export type LifecycleManagement = "ENABLED" | "DISABLED" | (string & {});
export type IdleTimeoutInMinutes = number;
export interface IdleSettings {
    LifecycleManagement?: LifecycleManagement | undefined;
    IdleTimeoutInMinutes?: number | undefined;
    MinIdleTimeoutInMinutes?: number | undefined;
    MaxIdleTimeoutInMinutes?: number | undefined;
}
export interface AppLifecycleManagement {
    IdleSettings?: IdleSettings | undefined;
}
export interface CodeEditorAppSettings {
    DefaultResourceSpec?: ResourceSpec | undefined;
    CustomImages?: CustomImage[] | undefined;
    LifecycleConfigArns?: string[] | undefined;
    AppLifecycleManagement?: AppLifecycleManagement | undefined;
    BuiltInLifecycleConfigArn?: string | undefined;
}
export type AssumableRoleArns = string[];
export type ExecutionRoleArns = string[];
export interface EmrSettings {
    AssumableRoleArns?: string[] | undefined;
    ExecutionRoleArns?: string[] | undefined;
}
export interface JupyterLabAppSettings {
    DefaultResourceSpec?: ResourceSpec | undefined;
    CustomImages?: CustomImage[] | undefined;
    LifecycleConfigArns?: string[] | undefined;
    CodeRepositories?: CodeRepository[] | undefined;
    AppLifecycleManagement?: AppLifecycleManagement | undefined;
    EmrSettings?: EmrSettings | undefined;
    BuiltInLifecycleConfigArn?: string | undefined;
}
export type SpaceEbsVolumeSizeInGb = number;
export interface DefaultEbsStorageSettings {
    DefaultEbsVolumeSizeInGb?: number | undefined;
    MaximumEbsVolumeSizeInGb?: number | undefined;
}
export interface DefaultSpaceStorageSettings {
    DefaultEbsStorageSettings?: DefaultEbsStorageSettings | undefined;
}
export type LandingUri = string;
export type StudioWebPortal = "ENABLED" | "DISABLED" | (string & {});
export type Uid = number;
export type Gid = number;
export interface CustomPosixUserConfig {
    Uid?: number | undefined;
    Gid?: number | undefined;
}
export type FileSystemPath = string;
export interface EFSFileSystemConfig {
    FileSystemId?: string | undefined;
    FileSystemPath?: string | undefined;
}
export interface FSxLustreFileSystemConfig {
    FileSystemId?: string | undefined;
    FileSystemPath?: string | undefined;
}
export type String1024 = string;
export type S3SchemaUri = string;
export interface S3FileSystemConfig {
    MountPath?: string | undefined;
    S3Uri?: string | undefined;
}
export type CustomFileSystemConfig = {
    EFSFileSystemConfig: EFSFileSystemConfig;
    FSxLustreFileSystemConfig?: undefined;
    S3FileSystemConfig?: undefined;
} | {
    EFSFileSystemConfig?: undefined;
    FSxLustreFileSystemConfig: FSxLustreFileSystemConfig;
    S3FileSystemConfig?: undefined;
} | {
    EFSFileSystemConfig?: undefined;
    FSxLustreFileSystemConfig?: undefined;
    S3FileSystemConfig: S3FileSystemConfig;
};
export type CustomFileSystemConfigs = CustomFileSystemConfig[];
export type MlTools = "DataWrangler" | "FeatureStore" | "EmrClusters" | "AutoMl" | "Experiments" | "Training" | "ModelEvaluation" | "Pipelines" | "Models" | "JumpStart" | "InferenceRecommender" | "Endpoints" | "Projects" | "InferenceOptimization" | "PerformanceEvaluation" | "LakeraGuard" | "Comet" | "DeepchecksLLMEvaluation" | "Fiddler" | "HyperPodClusters" | "RunningInstances" | "Datasets" | "Evaluators" | (string & {});
export type HiddenMlToolsList = MlTools[];
export type HiddenAppTypesList = AppType[];
export type HiddenInstanceTypesList = AppInstanceType[];
export type SageMakerImageName = "sagemaker_distribution" | (string & {});
export type ImageVersionAliasPattern = string;
export type VersionAliasesList = string[];
export interface HiddenSageMakerImage {
    SageMakerImageName?: SageMakerImageName | undefined;
    VersionAliases?: string[] | undefined;
}
export type HiddenSageMakerImageVersionAliasesList = HiddenSageMakerImage[];
export type ExecutionRoleSessionNameMode = "STATIC" | "USER_IDENTITY" | (string & {});
export interface StudioWebPortalSettings {
    HiddenMlTools?: MlTools[] | undefined;
    HiddenAppTypes?: AppType[] | undefined;
    HiddenInstanceTypes?: AppInstanceType[] | undefined;
    HiddenSageMakerImageVersionAliases?: HiddenSageMakerImage[] | undefined;
    ExecutionRoleSessionNameMode?: ExecutionRoleSessionNameMode | undefined;
}
export type AutoMountHomeEFS = "Enabled" | "Disabled" | "DefaultAsDomain" | (string & {});
export interface UserSettings {
    ExecutionRole?: string | undefined;
    SecurityGroups?: string[] | undefined;
    SharingSettings?: SharingSettings | undefined;
    JupyterServerAppSettings?: JupyterServerAppSettings | undefined;
    KernelGatewayAppSettings?: KernelGatewayAppSettings | undefined;
    TensorBoardAppSettings?: TensorBoardAppSettings | undefined;
    RStudioServerProAppSettings?: RStudioServerProAppSettings | undefined;
    RSessionAppSettings?: RSessionAppSettings | undefined;
    CanvasAppSettings?: CanvasAppSettings | undefined;
    CodeEditorAppSettings?: CodeEditorAppSettings | undefined;
    JupyterLabAppSettings?: JupyterLabAppSettings | undefined;
    SpaceStorageSettings?: DefaultSpaceStorageSettings | undefined;
    DefaultLandingUri?: string | undefined;
    StudioWebPortal?: StudioWebPortal | undefined;
    CustomPosixUserConfig?: CustomPosixUserConfig | undefined;
    CustomFileSystemConfigs?: CustomFileSystemConfig[] | undefined;
    StudioWebPortalSettings?: StudioWebPortalSettings | undefined;
    AutoMountHomeEFS?: AutoMountHomeEFS | undefined;
}
export type DomainSecurityGroupIds = string[];
export interface RStudioServerProDomainSettings {
    DomainExecutionRoleArn?: string | undefined;
    RStudioConnectUrl?: string | undefined;
    RStudioPackageManagerUrl?: string | undefined;
    DefaultResourceSpec?: ResourceSpec | undefined;
}
export type ExecutionRoleIdentityConfig = "USER_PROFILE_NAME" | "DISABLED" | (string & {});
export interface TrustedIdentityPropagationSettings {
    Status?: FeatureStatus | undefined;
}
export type AccountId = string;
export type VpcOnlyTrustedAccounts = string[];
export interface DockerSettings {
    EnableDockerAccess?: FeatureStatus | undefined;
    VpcOnlyTrustedAccounts?: string[] | undefined;
    RootlessDocker?: FeatureStatus | undefined;
}
export type QProfileArn = string;
export interface AmazonQSettings {
    Status?: FeatureStatus | undefined;
    QProfileArn?: string | undefined;
}
export type RegionName = string;
export type UnifiedStudioDomainId = string;
export type UnifiedStudioProjectId = string;
export type UnifiedStudioEnvironmentId = string;
export type SingleSignOnApplicationArn = string;
export interface UnifiedStudioSettings {
    StudioWebPortalAccess?: FeatureStatus | undefined;
    DomainAccountId?: string | undefined;
    DomainRegion?: string | undefined;
    DomainId?: string | undefined;
    ProjectId?: string | undefined;
    EnvironmentId?: string | undefined;
    ProjectS3Path?: string | undefined;
    SingleSignOnApplicationArn?: string | undefined;
}
export type IPAddressType = "ipv4" | "dualstack" | (string & {});
export interface DomainSettings {
    SecurityGroupIds?: string[] | undefined;
    RStudioServerProDomainSettings?: RStudioServerProDomainSettings | undefined;
    ExecutionRoleIdentityConfig?: ExecutionRoleIdentityConfig | undefined;
    TrustedIdentityPropagationSettings?: TrustedIdentityPropagationSettings | undefined;
    DockerSettings?: DockerSettings | undefined;
    AmazonQSettings?: AmazonQSettings | undefined;
    UnifiedStudioSettings?: UnifiedStudioSettings | undefined;
    IpAddressType?: IPAddressType | undefined;
}
export type VpcId = string;
export type AppNetworkAccessType = "PublicInternetOnly" | "VpcOnly" | (string & {});
export type AppSecurityGroupManagement = "Service" | "Customer" | (string & {});
export type HomeEfsFileSystemCreation = "Enabled" | "Disabled" | (string & {});
export type TagPropagation = "ENABLED" | "DISABLED" | (string & {});
export interface DefaultSpaceSettings {
    ExecutionRole?: string | undefined;
    SecurityGroups?: string[] | undefined;
    JupyterServerAppSettings?: JupyterServerAppSettings | undefined;
    KernelGatewayAppSettings?: KernelGatewayAppSettings | undefined;
    JupyterLabAppSettings?: JupyterLabAppSettings | undefined;
    SpaceStorageSettings?: DefaultSpaceStorageSettings | undefined;
    CustomPosixUserConfig?: CustomPosixUserConfig | undefined;
    CustomFileSystemConfigs?: CustomFileSystemConfig[] | undefined;
}
export interface CreateDomainRequest {
    DomainName?: string | undefined;
    AuthMode?: AuthMode | undefined;
    DefaultUserSettings?: UserSettings | undefined;
    DomainSettings?: DomainSettings | undefined;
    SubnetIds?: string[] | undefined;
    VpcId?: string | undefined;
    Tags?: Tag[] | undefined;
    AppNetworkAccessType?: AppNetworkAccessType | undefined;
    HomeEfsFileSystemKmsKeyId?: string | undefined;
    KmsKeyId?: string | undefined;
    AppSecurityGroupManagement?: AppSecurityGroupManagement | undefined;
    HomeEfsFileSystemCreation?: HomeEfsFileSystemCreation | undefined;
    TagPropagation?: TagPropagation | undefined;
    DefaultSpaceSettings?: DefaultSpaceSettings | undefined;
}
export type DomainArn = string;
export interface CreateDomainResponse {
    DomainArn?: string | undefined;
    DomainId?: string | undefined;
    Url?: string | undefined;
}
export interface EdgeDeploymentModelConfig {
    ModelHandle?: string | undefined;
    EdgePackagingJobName?: string | undefined;
}
export type EdgeDeploymentModelConfigs = EdgeDeploymentModelConfig[];
export type DeviceSubsetType = "PERCENTAGE" | "SELECTION" | "NAMECONTAINS" | (string & {});
export type Percentage = number;
export type DeviceName = string;
export type DeviceNames = string[];
export interface DeviceSelectionConfig {
    DeviceSubsetType?: DeviceSubsetType | undefined;
    Percentage?: number | undefined;
    DeviceNames?: string[] | undefined;
    DeviceNameContains?: string | undefined;
}
export type FailureHandlingPolicy = "ROLLBACK_ON_FAILURE" | "DO_NOTHING" | (string & {});
export interface EdgeDeploymentConfig {
    FailureHandlingPolicy?: FailureHandlingPolicy | undefined;
}
export interface DeploymentStage {
    StageName?: string | undefined;
    DeviceSelectionConfig?: DeviceSelectionConfig | undefined;
    DeploymentConfig?: EdgeDeploymentConfig | undefined;
}
export type DeploymentStages = DeploymentStage[];
export interface CreateEdgeDeploymentPlanRequest {
    EdgeDeploymentPlanName?: string | undefined;
    ModelConfigs?: EdgeDeploymentModelConfig[] | undefined;
    DeviceFleetName?: string | undefined;
    Stages?: DeploymentStage[] | undefined;
    Tags?: Tag[] | undefined;
}
export type EdgeDeploymentPlanArn = string;
export interface CreateEdgeDeploymentPlanResponse {
    EdgeDeploymentPlanArn: string;
}
export interface CreateEdgeDeploymentStageRequest {
    EdgeDeploymentPlanName?: string | undefined;
    Stages?: DeploymentStage[] | undefined;
}
export interface CreateEdgeDeploymentStageResponse {
}
export type EdgeVersion = string;
export interface CreateEdgePackagingJobRequest {
    EdgePackagingJobName?: string | undefined;
    CompilationJobName?: string | undefined;
    ModelName?: string | undefined;
    ModelVersion?: string | undefined;
    RoleArn?: string | undefined;
    OutputConfig?: EdgeOutputConfig | undefined;
    ResourceKey?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateEdgePackagingJobResponse {
}
export type EndpointConfigName = string;
export type TrafficRoutingConfigType = "ALL_AT_ONCE" | "CANARY" | "LINEAR" | (string & {});
export type WaitIntervalInSeconds = number;
export type CapacitySizeType = "INSTANCE_COUNT" | "CAPACITY_PERCENT" | (string & {});
export type CapacitySizeValue = number;
export interface CapacitySize {
    Type?: CapacitySizeType | undefined;
    Value?: number | undefined;
}
export interface TrafficRoutingConfig {
    Type?: TrafficRoutingConfigType | undefined;
    WaitIntervalInSeconds?: number | undefined;
    CanarySize?: CapacitySize | undefined;
    LinearStepSize?: CapacitySize | undefined;
}
export type TerminationWaitInSeconds = number;
export type MaximumExecutionTimeoutInSeconds = number;
export interface BlueGreenUpdatePolicy {
    TrafficRoutingConfiguration?: TrafficRoutingConfig | undefined;
    TerminationWaitInSeconds?: number | undefined;
    MaximumExecutionTimeoutInSeconds?: number | undefined;
}
export interface RollingUpdatePolicy {
    MaximumBatchSize?: CapacitySize | undefined;
    WaitIntervalInSeconds?: number | undefined;
    MaximumExecutionTimeoutInSeconds?: number | undefined;
    RollbackMaximumBatchSize?: CapacitySize | undefined;
}
export interface Alarm {
    AlarmName?: string | undefined;
}
export type AlarmList = Alarm[];
export interface AutoRollbackConfig {
    Alarms?: Alarm[] | undefined;
}
export interface DeploymentConfig {
    BlueGreenUpdatePolicy?: BlueGreenUpdatePolicy | undefined;
    RollingUpdatePolicy?: RollingUpdatePolicy | undefined;
    AutoRollbackConfiguration?: AutoRollbackConfig | undefined;
}
export interface CreateEndpointInput {
    EndpointName?: string | undefined;
    EndpointConfigName?: string | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type EndpointArn = string;
export interface CreateEndpointOutput {
    EndpointArn: string;
}
export type VariantName = string;
export type ModelName = string;
export type InitialTaskCount = number;
export type InstancePoolPriority = number;
export interface InstancePool {
    InstanceType?: ProductionVariantInstanceType | undefined;
    ModelNameOverride?: string | undefined;
    Priority?: number | undefined;
}
export type InstancePoolList = InstancePool[];
export type VariantInstanceProvisionTimeoutInSeconds = number;
export type VariantWeight = number;
export type ProductionVariantAcceleratorType = "ml.eia1.medium" | "ml.eia1.large" | "ml.eia1.xlarge" | "ml.eia2.medium" | "ml.eia2.large" | "ml.eia2.xlarge" | (string & {});
export interface ProductionVariantCoreDumpConfig {
    DestinationS3Uri?: string | undefined;
    KmsKeyId?: string | undefined;
}
export type ServerlessMemorySizeInMB = number;
export type ServerlessMaxConcurrency = number;
export type ServerlessProvisionedConcurrency = number;
export interface ProductionVariantServerlessConfig {
    MemorySizeInMB?: number | undefined;
    MaxConcurrency?: number | undefined;
    ProvisionedConcurrency?: number | undefined;
}
export type ProductionVariantVolumeSizeInGB = number;
export type ProductionVariantModelDataDownloadTimeoutInSeconds = number;
export type ProductionVariantContainerStartupHealthCheckTimeoutInSeconds = number;
export type ProductionVariantSSMAccess = boolean;
export type ManagedInstanceScalingStatus = "ENABLED" | "DISABLED" | (string & {});
export type ManagedInstanceScalingMinInstanceCount = number;
export type ManagedInstanceScalingMaxInstanceCount = number;
export type ManagedInstanceScalingScaleInStrategy = "IDLE_RELEASE" | "CONSOLIDATION" | (string & {});
export type ManagedInstanceScalingMaximumStepSize = number;
export type ManagedInstanceScalingCooldownInMinutes = number;
export interface ProductionVariantManagedInstanceScalingScaleInPolicy {
    Strategy?: ManagedInstanceScalingScaleInStrategy | undefined;
    MaximumStepSize?: number | undefined;
    CooldownInMinutes?: number | undefined;
}
export interface ProductionVariantManagedInstanceScaling {
    Status?: ManagedInstanceScalingStatus | undefined;
    MinInstanceCount?: number | undefined;
    MaxInstanceCount?: number | undefined;
    ScaleInPolicy?: ProductionVariantManagedInstanceScalingScaleInPolicy | undefined;
}
export type RoutingStrategy = "LEAST_OUTSTANDING_REQUESTS" | "RANDOM" | "PREFIX_AWARE" | (string & {});
export type PrefixAwareRoutingPrefixLength = number;
export type PrefixAwareRoutingConcurrencyThreshold = number;
export interface PrefixAwareRoutingConfig {
    PrefixLength?: number | undefined;
    ConcurrencyThreshold?: number | undefined;
}
export interface ProductionVariantRoutingConfig {
    RoutingStrategy?: RoutingStrategy | undefined;
    PrefixAwareRoutingConfig?: PrefixAwareRoutingConfig | undefined;
}
export type ProductionVariantInferenceAmiVersion = "al2-ami-sagemaker-inference-gpu-2" | "al2-ami-sagemaker-inference-gpu-2-1" | "al2-ami-sagemaker-inference-gpu-3-1" | "al2-ami-sagemaker-inference-neuron-2" | "al2023-ami-sagemaker-inference-gpu-4-1" | (string & {});
export type CapacityReservationPreference = "capacity-reservations-only" | (string & {});
export type MlReservationArn = string;
export interface ProductionVariantCapacityReservationConfig {
    CapacityReservationPreference?: CapacityReservationPreference | undefined;
    MlReservationArn?: string | undefined;
}
export type AcceleratorPartitionType = string;
export type AcceleratorPartitionTypeList = string[];
export interface AcceleratorPartitionLayout {
    AcceleratorPartitionTypes?: string[] | undefined;
}
export type AcceleratorPartitionLayouts = AcceleratorPartitionLayout[];
export interface ProductionVariant {
    VariantName?: string | undefined;
    ModelName?: string | undefined;
    InitialInstanceCount?: number | undefined;
    InstanceType?: ProductionVariantInstanceType | undefined;
    InstancePools?: InstancePool[] | undefined;
    VariantInstanceProvisionTimeoutInSeconds?: number | undefined;
    InitialVariantWeight?: number | undefined;
    AcceleratorType?: ProductionVariantAcceleratorType | undefined;
    CoreDumpConfig?: ProductionVariantCoreDumpConfig | undefined;
    ServerlessConfig?: ProductionVariantServerlessConfig | undefined;
    VolumeSizeInGB?: number | undefined;
    ModelDataDownloadTimeoutInSeconds?: number | undefined;
    ContainerStartupHealthCheckTimeoutInSeconds?: number | undefined;
    EnableSSMAccess?: boolean | undefined;
    ManagedInstanceScaling?: ProductionVariantManagedInstanceScaling | undefined;
    RoutingConfig?: ProductionVariantRoutingConfig | undefined;
    InferenceAmiVersion?: ProductionVariantInferenceAmiVersion | undefined;
    CapacityReservationConfig?: ProductionVariantCapacityReservationConfig | undefined;
    AcceleratorPartitionLayouts?: AcceleratorPartitionLayout[] | undefined;
}
export type ProductionVariantList = ProductionVariant[];
export type EnableCapture = boolean;
export type SamplingPercentage = number;
export type CaptureMode = "Input" | "Output" | "InputAndOutput" | (string & {});
export interface CaptureOption {
    CaptureMode?: CaptureMode | undefined;
}
export type CaptureOptionList = CaptureOption[];
export type CsvContentType = string;
export type CsvContentTypes = string[];
export type JsonContentType = string;
export type JsonContentTypes = string[];
export interface CaptureContentTypeHeader {
    CsvContentTypes?: string[] | undefined;
    JsonContentTypes?: string[] | undefined;
}
export interface DataCaptureConfig {
    EnableCapture?: boolean | undefined;
    InitialSamplingPercentage?: number | undefined;
    DestinationS3Uri?: string | undefined;
    KmsKeyId?: string | undefined;
    CaptureOptions?: CaptureOption[] | undefined;
    CaptureContentTypeHeader?: CaptureContentTypeHeader | undefined;
}
export type MaxConcurrentInvocationsPerInstance = number;
export interface AsyncInferenceClientConfig {
    MaxConcurrentInvocationsPerInstance?: number | undefined;
}
export type SnsTopicArn = string;
export type AsyncNotificationTopicTypes = "SUCCESS_NOTIFICATION_TOPIC" | "ERROR_NOTIFICATION_TOPIC" | (string & {});
export type AsyncNotificationTopicTypeList = AsyncNotificationTopicTypes[];
export interface AsyncInferenceNotificationConfig {
    SuccessTopic?: string | undefined;
    ErrorTopic?: string | undefined;
    IncludeInferenceResponseIn?: AsyncNotificationTopicTypes[] | undefined;
}
export interface AsyncInferenceOutputConfig {
    KmsKeyId?: string | undefined;
    S3OutputPath?: string | undefined;
    NotificationConfig?: AsyncInferenceNotificationConfig | undefined;
    S3FailurePath?: string | undefined;
}
export interface AsyncInferenceConfig {
    ClientConfig?: AsyncInferenceClientConfig | undefined;
    OutputConfig?: AsyncInferenceOutputConfig | undefined;
}
export type ClarifyEnableExplanations = string;
export type ClarifyFeaturesAttribute = string;
export type ClarifyContentTemplate = string;
export type ClarifyMaxRecordCount = number;
export type ClarifyMaxPayloadInMB = number;
export type ClarifyProbabilityIndex = number;
export type ClarifyLabelIndex = number;
export type ClarifyProbabilityAttribute = string;
export type ClarifyLabelAttribute = string;
export type ClarifyHeader = string;
export type ClarifyLabelHeaders = string[];
export type ClarifyFeatureHeaders = string[];
export type ClarifyFeatureType = "numerical" | "categorical" | "text" | (string & {});
export type ClarifyFeatureTypes = ClarifyFeatureType[];
export interface ClarifyInferenceConfig {
    FeaturesAttribute?: string | undefined;
    ContentTemplate?: string | undefined;
    MaxRecordCount?: number | undefined;
    MaxPayloadInMB?: number | undefined;
    ProbabilityIndex?: number | undefined;
    LabelIndex?: number | undefined;
    ProbabilityAttribute?: string | undefined;
    LabelAttribute?: string | undefined;
    LabelHeaders?: string[] | undefined;
    FeatureHeaders?: string[] | undefined;
    FeatureTypes?: ClarifyFeatureType[] | undefined;
}
export type ClarifyMimeType = string;
export type ClarifyShapBaseline = string;
export interface ClarifyShapBaselineConfig {
    MimeType?: string | undefined;
    ShapBaseline?: string | undefined;
    ShapBaselineUri?: string | undefined;
}
export type ClarifyShapNumberOfSamples = number;
export type ClarifyShapUseLogit = boolean;
export type ClarifyShapSeed = number;
export type ClarifyTextLanguage = "af" | "sq" | "ar" | "hy" | "eu" | "bn" | "bg" | "ca" | "zh" | "hr" | "cs" | "da" | "nl" | "en" | "et" | "fi" | "fr" | "de" | "el" | "gu" | "he" | "hi" | "hu" | "is" | "id" | "ga" | "it" | "kn" | "ky" | "lv" | "lt" | "lb" | "mk" | "ml" | "mr" | "ne" | "nb" | "fa" | "pl" | "pt" | "ro" | "ru" | "sa" | "sr" | "tn" | "si" | "sk" | "sl" | "es" | "sv" | "tl" | "ta" | "tt" | "te" | "tr" | "uk" | "ur" | "yo" | "lij" | "xx" | (string & {});
export type ClarifyTextGranularity = "token" | "sentence" | "paragraph" | (string & {});
export interface ClarifyTextConfig {
    Language?: ClarifyTextLanguage | undefined;
    Granularity?: ClarifyTextGranularity | undefined;
}
export interface ClarifyShapConfig {
    ShapBaselineConfig?: ClarifyShapBaselineConfig | undefined;
    NumberOfSamples?: number | undefined;
    UseLogit?: boolean | undefined;
    Seed?: number | undefined;
    TextConfig?: ClarifyTextConfig | undefined;
}
export interface ClarifyExplainerConfig {
    EnableExplanations?: string | undefined;
    InferenceConfig?: ClarifyInferenceConfig | undefined;
    ShapConfig?: ClarifyShapConfig | undefined;
}
export interface ExplainerConfig {
    ClarifyExplainerConfig?: ClarifyExplainerConfig | undefined;
}
export type EnableEnhancedMetrics = boolean;
export type EnableDetailedObservability = boolean;
export type MetricPublishFrequencyInSeconds = 10 | 30 | 60 | 120 | 180 | 240 | 300 | (number & {});
export interface MetricsConfig {
    EnableEnhancedMetrics?: boolean | undefined;
    EnableDetailedObservability?: boolean | undefined;
    MetricPublishFrequencyInSeconds?: MetricPublishFrequencyInSeconds | undefined;
}
export interface CreateEndpointConfigInput {
    EndpointConfigName?: string | undefined;
    ProductionVariants?: ProductionVariant[] | undefined;
    DataCaptureConfig?: DataCaptureConfig | undefined;
    Tags?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
    AsyncInferenceConfig?: AsyncInferenceConfig | undefined;
    ExplainerConfig?: ExplainerConfig | undefined;
    ShadowProductionVariants?: ProductionVariant[] | undefined;
    ExecutionRoleArn?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    MetricsConfig?: MetricsConfig | undefined;
}
export type EndpointConfigArn = string;
export interface CreateEndpointConfigOutput {
    EndpointConfigArn: string;
}
export interface CreateExperimentRequest {
    ExperimentName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type ExperimentArn = string;
export interface CreateExperimentResponse {
    ExperimentArn?: string | undefined;
}
export type FeatureGroupName = string;
export type FeatureName = string;
export type FeatureType = "Integral" | "Fractional" | "String" | (string & {});
export type CollectionType = "List" | "Set" | "Vector" | (string & {});
export type Dimension = number;
export interface VectorConfig {
    Dimension?: number | undefined;
}
export type CollectionConfig = {
    VectorConfig: VectorConfig;
};
export interface FeatureDefinition {
    FeatureName?: string | undefined;
    FeatureType?: FeatureType | undefined;
    CollectionType?: CollectionType | undefined;
    CollectionConfig?: CollectionConfig | undefined;
}
export type FeatureDefinitions = FeatureDefinition[];
export interface OnlineStoreSecurityConfig {
    KmsKeyId?: string | undefined;
}
export type TtlDurationUnit = "Seconds" | "Minutes" | "Hours" | "Days" | "Weeks" | (string & {});
export type TtlDurationValue = number;
export interface TtlDuration {
    Unit?: TtlDurationUnit | undefined;
    Value?: number | undefined;
}
export type StorageType = "Standard" | "Standard_V2" | "InMemory" | (string & {});
export interface OnlineStoreConfig {
    SecurityConfig?: OnlineStoreSecurityConfig | undefined;
    EnableOnlineStore?: boolean | undefined;
    TtlDuration?: TtlDuration | undefined;
    StorageType?: StorageType | undefined;
}
export interface S3StorageConfig {
    S3Uri?: string | undefined;
    KmsKeyId?: string | undefined;
    ResolvedOutputS3Uri?: string | undefined;
}
export type TableName = string;
export type Catalog = string;
export type Database = string;
export interface DataCatalogConfig {
    TableName?: string | undefined;
    Catalog?: string | undefined;
    Database?: string | undefined;
}
export type TableFormat = "Default" | "Glue" | "Iceberg" | (string & {});
export interface OfflineStoreConfig {
    S3StorageConfig?: S3StorageConfig | undefined;
    DisableGlueTableCreation?: boolean | undefined;
    DataCatalogConfig?: DataCatalogConfig | undefined;
    TableFormat?: TableFormat | undefined;
}
export type ThroughputMode = "OnDemand" | "Provisioned" | (string & {});
export type CapacityUnit = number;
export interface ThroughputConfig {
    ThroughputMode?: ThroughputMode | undefined;
    ProvisionedReadCapacityUnits?: number | undefined;
    ProvisionedWriteCapacityUnits?: number | undefined;
}
export type Description = string;
export interface CreateFeatureGroupRequest {
    FeatureGroupName?: string | undefined;
    RecordIdentifierFeatureName?: string | undefined;
    EventTimeFeatureName?: string | undefined;
    FeatureDefinitions?: FeatureDefinition[] | undefined;
    OnlineStoreConfig?: OnlineStoreConfig | undefined;
    OfflineStoreConfig?: OfflineStoreConfig | undefined;
    ThroughputConfig?: ThroughputConfig | undefined;
    RoleArn?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type FeatureGroupArn = string;
export interface CreateFeatureGroupResponse {
    FeatureGroupArn: string;
}
export type FlowDefinitionName = string;
export type AwsManagedHumanLoopRequestSource = "AWS/Rekognition/DetectModerationLabels/Image/V3" | "AWS/Textract/AnalyzeDocument/Forms/V1" | (string & {});
export interface HumanLoopRequestSource {
    AwsManagedHumanLoopRequestSource?: AwsManagedHumanLoopRequestSource | undefined;
}
export type HumanLoopActivationConditions = string;
export interface HumanLoopActivationConditionsConfig {
    HumanLoopActivationConditions?: string | undefined;
}
export interface HumanLoopActivationConfig {
    HumanLoopActivationConditionsConfig?: HumanLoopActivationConditionsConfig | undefined;
}
export type WorkteamArn = string;
export type HumanTaskUiArn = string;
export type FlowDefinitionTaskTitle = string;
export type FlowDefinitionTaskDescription = string;
export type FlowDefinitionTaskCount = number;
export type FlowDefinitionTaskAvailabilityLifetimeInSeconds = number;
export type FlowDefinitionTaskTimeLimitInSeconds = number;
export type FlowDefinitionTaskKeyword = string;
export type FlowDefinitionTaskKeywords = string[];
export type Dollars = number;
export type Cents = number;
export type TenthFractionsOfACent = number;
export interface USD {
    Dollars?: number | undefined;
    Cents?: number | undefined;
    TenthFractionsOfACent?: number | undefined;
}
export interface PublicWorkforceTaskPrice {
    AmountInUsd?: USD | undefined;
}
export interface HumanLoopConfig {
    WorkteamArn?: string | undefined;
    HumanTaskUiArn?: string | undefined;
    TaskTitle?: string | undefined;
    TaskDescription?: string | undefined;
    TaskCount?: number | undefined;
    TaskAvailabilityLifetimeInSeconds?: number | undefined;
    TaskTimeLimitInSeconds?: number | undefined;
    TaskKeywords?: string[] | undefined;
    PublicWorkforceTaskPrice?: PublicWorkforceTaskPrice | undefined;
}
export interface FlowDefinitionOutputConfig {
    S3OutputPath?: string | undefined;
    KmsKeyId?: string | undefined;
}
export interface CreateFlowDefinitionRequest {
    FlowDefinitionName?: string | undefined;
    HumanLoopRequestSource?: HumanLoopRequestSource | undefined;
    HumanLoopActivationConfig?: HumanLoopActivationConfig | undefined;
    HumanLoopConfig?: HumanLoopConfig | undefined;
    OutputConfig?: FlowDefinitionOutputConfig | undefined;
    RoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type FlowDefinitionArn = string;
export interface CreateFlowDefinitionResponse {
    FlowDefinitionArn: string;
}
export type HubName = string;
export type HubDescription = string;
export type HubDisplayName = string;
export type HubSearchKeyword = string;
export type HubSearchKeywordList = string[];
export type S3OutputPath = string;
export interface HubS3StorageConfig {
    S3OutputPath?: string | undefined;
}
export interface CreateHubRequest {
    HubName?: string | undefined;
    HubDescription?: string | undefined;
    HubDisplayName?: string | undefined;
    HubSearchKeywords?: string[] | undefined;
    S3StorageConfig?: HubS3StorageConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type HubArn = string;
export interface CreateHubResponse {
    HubArn: string;
}
export type HubNameOrArn = string;
export type HubContentType = "Model" | "Notebook" | "ModelReference" | "DataSet" | "JsonDoc" | (string & {});
export interface PresignedUrlAccessConfig {
    AcceptEula?: boolean | undefined;
    ExpectedS3Url?: string | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface CreateHubContentPresignedUrlsRequest {
    HubName?: string | undefined;
    HubContentType?: HubContentType | undefined;
    HubContentName?: string | undefined;
    HubContentVersion?: string | undefined;
    AccessConfig?: PresignedUrlAccessConfig | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type LongS3Uri = string;
export type LocalPath = string;
export interface AuthorizedUrl {
    Url?: string | undefined;
    LocalPath?: string | undefined;
}
export type AuthorizedUrlConfigs = AuthorizedUrl[];
export interface CreateHubContentPresignedUrlsResponse {
    AuthorizedUrlConfigs: AuthorizedUrl[];
    NextToken?: string | undefined;
}
export type SageMakerPublicHubContentArn = string;
export interface CreateHubContentReferenceRequest {
    HubName?: string | undefined;
    SageMakerPublicHubContentArn?: string | undefined;
    HubContentName?: string | undefined;
    MinVersion?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateHubContentReferenceResponse {
    HubArn: string;
    HubContentArn: string;
}
export type HumanTaskUiName = string;
export type TemplateContent = string;
export interface UiTemplate {
    Content?: string | undefined;
}
export interface CreateHumanTaskUiRequest {
    HumanTaskUiName?: string | undefined;
    UiTemplate?: UiTemplate | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateHumanTaskUiResponse {
    HumanTaskUiArn: string;
}
export type HyperParameterTuningJobName = string;
export type HyperParameterTuningJobStrategyType = "Bayesian" | "Random" | "Hyperband" | "Grid" | (string & {});
export type HyperbandStrategyMinResource = number;
export type HyperbandStrategyMaxResource = number;
export interface HyperbandStrategyConfig {
    MinResource?: number | undefined;
    MaxResource?: number | undefined;
}
export interface HyperParameterTuningJobStrategyConfig {
    HyperbandStrategyConfig?: HyperbandStrategyConfig | undefined;
}
export type MaxNumberOfTrainingJobs = number;
export type MaxParallelTrainingJobs = number;
export type HyperParameterTuningMaxRuntimeInSeconds = number;
export interface ResourceLimits {
    MaxNumberOfTrainingJobs?: number | undefined;
    MaxParallelTrainingJobs?: number | undefined;
    MaxRuntimeInSeconds?: number | undefined;
}
export type ParameterKey = string;
export type HyperParameterScalingType = "Auto" | "Linear" | "Logarithmic" | "ReverseLogarithmic" | (string & {});
export interface IntegerParameterRange {
    Name?: string | undefined;
    MinValue?: string | undefined;
    MaxValue?: string | undefined;
    ScalingType?: HyperParameterScalingType | undefined;
}
export type IntegerParameterRanges = IntegerParameterRange[];
export interface ContinuousParameterRange {
    Name?: string | undefined;
    MinValue?: string | undefined;
    MaxValue?: string | undefined;
    ScalingType?: HyperParameterScalingType | undefined;
}
export type ContinuousParameterRanges = ContinuousParameterRange[];
export interface CategoricalParameterRange {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type CategoricalParameterRanges = CategoricalParameterRange[];
export interface AutoParameter {
    Name?: string | undefined;
    ValueHint?: string | undefined;
}
export type AutoParameters = AutoParameter[];
export interface ParameterRanges {
    IntegerParameterRanges?: IntegerParameterRange[] | undefined;
    ContinuousParameterRanges?: ContinuousParameterRange[] | undefined;
    CategoricalParameterRanges?: CategoricalParameterRange[] | undefined;
    AutoParameters?: AutoParameter[] | undefined;
}
export type TrainingJobEarlyStoppingType = "Off" | "Auto" | (string & {});
export type TargetObjectiveMetricValue = number;
export type MaxNumberOfTrainingJobsNotImproving = number;
export interface BestObjectiveNotImproving {
    MaxNumberOfTrainingJobsNotImproving?: number | undefined;
}
export type CompleteOnConvergence = "Disabled" | "Enabled" | (string & {});
export interface ConvergenceDetected {
    CompleteOnConvergence?: CompleteOnConvergence | undefined;
}
export interface TuningJobCompletionCriteria {
    TargetObjectiveMetricValue?: number | undefined;
    BestObjectiveNotImproving?: BestObjectiveNotImproving | undefined;
    ConvergenceDetected?: ConvergenceDetected | undefined;
}
export type RandomSeed = number;
export interface HyperParameterTuningJobConfig {
    Strategy?: HyperParameterTuningJobStrategyType | undefined;
    StrategyConfig?: HyperParameterTuningJobStrategyConfig | undefined;
    HyperParameterTuningJobObjective?: HyperParameterTuningJobObjective | undefined;
    ResourceLimits?: ResourceLimits | undefined;
    ParameterRanges?: ParameterRanges | undefined;
    TrainingJobEarlyStoppingType?: TrainingJobEarlyStoppingType | undefined;
    TuningJobCompletionCriteria?: TuningJobCompletionCriteria | undefined;
    RandomSeed?: number | undefined;
}
export type HyperParameterTrainingJobDefinitionName = string;
export type AlgorithmImage = string;
export type ArnOrName = string;
export interface HyperParameterAlgorithmSpecification {
    TrainingImage?: string | undefined;
    TrainingInputMode?: TrainingInputMode | undefined;
    AlgorithmName?: string | undefined;
    MetricDefinitions?: MetricDefinition[] | undefined;
}
export type HyperParameterTuningAllocationStrategy = "Prioritized" | (string & {});
export type VolumeSizeInGB = number;
export interface HyperParameterTuningInstanceConfig {
    InstanceType?: TrainingInstanceType | undefined;
    InstanceCount?: number | undefined;
    VolumeSizeInGB?: number | undefined;
}
export type HyperParameterTuningInstanceConfigs = HyperParameterTuningInstanceConfig[];
export interface HyperParameterTuningResourceConfig {
    InstanceType?: TrainingInstanceType | undefined;
    InstanceCount?: number | undefined;
    VolumeSizeInGB?: number | undefined;
    VolumeKmsKeyId?: string | undefined;
    AllocationStrategy?: HyperParameterTuningAllocationStrategy | undefined;
    InstanceConfigs?: HyperParameterTuningInstanceConfig[] | undefined;
}
export interface CheckpointConfig {
    S3Uri?: string | undefined;
    LocalPath?: string | undefined;
}
export type MaximumRetryAttempts = number;
export interface RetryStrategy {
    MaximumRetryAttempts?: number | undefined;
}
export type HyperParameterTrainingJobEnvironmentKey = string;
export type HyperParameterTrainingJobEnvironmentValue = string;
export type HyperParameterTrainingJobEnvironmentMap = {
    [key: string]: string | undefined;
};
export interface HyperParameterTrainingJobDefinition {
    DefinitionName?: string | undefined;
    TuningObjective?: HyperParameterTuningJobObjective | undefined;
    HyperParameterRanges?: ParameterRanges | undefined;
    StaticHyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AlgorithmSpecification?: HyperParameterAlgorithmSpecification | undefined;
    RoleArn?: string | undefined;
    InputDataConfig?: Channel[] | undefined;
    VpcConfig?: VpcConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    ResourceConfig?: ResourceConfig | undefined;
    HyperParameterTuningResourceConfig?: HyperParameterTuningResourceConfig | undefined;
    StoppingCondition?: StoppingCondition | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    EnableInterContainerTrafficEncryption?: boolean | undefined;
    EnableManagedSpotTraining?: boolean | undefined;
    CheckpointConfig?: CheckpointConfig | undefined;
    RetryStrategy?: RetryStrategy | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type HyperParameterTrainingJobDefinitions = HyperParameterTrainingJobDefinition[];
export interface ParentHyperParameterTuningJob {
    HyperParameterTuningJobName?: string | undefined;
}
export type ParentHyperParameterTuningJobs = ParentHyperParameterTuningJob[];
export type HyperParameterTuningJobWarmStartType = "IdenticalDataAndAlgorithm" | "TransferLearning" | (string & {});
export interface HyperParameterTuningJobWarmStartConfig {
    ParentHyperParameterTuningJobs?: ParentHyperParameterTuningJob[] | undefined;
    WarmStartType?: HyperParameterTuningJobWarmStartType | undefined;
}
export type AutotuneMode = "Enabled" | (string & {});
export interface Autotune {
    Mode?: AutotuneMode | undefined;
}
export interface CreateHyperParameterTuningJobRequest {
    HyperParameterTuningJobName?: string | undefined;
    HyperParameterTuningJobConfig?: HyperParameterTuningJobConfig | undefined;
    TrainingJobDefinition?: HyperParameterTrainingJobDefinition | undefined;
    TrainingJobDefinitions?: HyperParameterTrainingJobDefinition[] | undefined;
    WarmStartConfig?: HyperParameterTuningJobWarmStartConfig | undefined;
    Tags?: Tag[] | undefined;
    Autotune?: Autotune | undefined;
}
export type HyperParameterTuningJobArn = string;
export interface CreateHyperParameterTuningJobResponse {
    HyperParameterTuningJobArn: string;
}
export type ImageDescription = string;
export type ImageDisplayName = string;
export interface CreateImageRequest {
    Description?: string | undefined;
    DisplayName?: string | undefined;
    ImageName?: string | undefined;
    RoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateImageResponse {
    ImageArn?: string | undefined;
}
export type ImageBaseImage = string;
export type ClientToken = string;
export type SageMakerImageVersionAlias = string;
export type SageMakerImageVersionAliases = string[];
export type VendorGuidance = "NOT_PROVIDED" | "STABLE" | "TO_BE_ARCHIVED" | "ARCHIVED" | (string & {});
export type JobType = "TRAINING" | "INFERENCE" | "NOTEBOOK_KERNEL" | (string & {});
export type MLFramework = string;
export type ProgrammingLang = string;
export type Processor = "CPU" | "GPU" | (string & {});
export type Horovod = boolean;
export type ReleaseNotes = string;
export interface CreateImageVersionRequest {
    BaseImage?: string | undefined;
    ClientToken?: string | undefined;
    ImageName?: string | undefined;
    Aliases?: string[] | undefined;
    VendorGuidance?: VendorGuidance | undefined;
    JobType?: JobType | undefined;
    MLFramework?: string | undefined;
    ProgrammingLang?: string | undefined;
    Processor?: Processor | undefined;
    Horovod?: boolean | undefined;
    ReleaseNotes?: string | undefined;
}
export interface CreateImageVersionResponse {
    ImageVersionArn?: string | undefined;
}
export type InferenceComponentName = string;
export type MetricsEndpointPath = string;
export interface MetricsEndpoint {
    MetricsEndpointPath?: string | undefined;
    MetricPublishFrequencyInSeconds?: MetricPublishFrequencyInSeconds | undefined;
}
export type MetricsEndpointList = MetricsEndpoint[];
export interface ContainerMetricsConfig {
    MetricsEndpoints?: MetricsEndpoint[] | undefined;
}
export interface InferenceComponentContainerSpecification {
    Image?: string | undefined;
    ArtifactUrl?: string | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    ContainerMetricsConfig?: ContainerMetricsConfig | undefined;
}
export interface InferenceComponentStartupParameters {
    ModelDataDownloadTimeoutInSeconds?: number | undefined;
    ContainerStartupHealthCheckTimeoutInSeconds?: number | undefined;
}
export type NumberOfCpuCores = number;
export type NumberOfAcceleratorDevices = number;
export type MemoryInMb = number;
export interface InferenceComponentComputeResourceRequirements {
    NumberOfCpuCoresRequired?: number | undefined;
    NumberOfAcceleratorDevicesRequired?: number | undefined;
    MinMemoryRequiredInMb?: number | undefined;
    MaxMemoryRequiredInMb?: number | undefined;
    AcceleratorPartitionType?: string | undefined;
}
export type EnableCaching = boolean;
export interface InferenceComponentDataCacheConfig {
    EnableCaching?: boolean | undefined;
}
export type InferenceComponentPlacementStrategy = "SPREAD" | "BINPACK" | (string & {});
export type AvailabilityZoneBalanceEnforcementMode = "PERMISSIVE" | (string & {});
export type AvailabilityZoneBalanceMaxImbalance = number;
export interface InferenceComponentAvailabilityZoneBalance {
    EnforcementMode?: AvailabilityZoneBalanceEnforcementMode | undefined;
    MaxImbalance?: number | undefined;
}
export interface InferenceComponentSchedulingConfig {
    PlacementStrategy?: InferenceComponentPlacementStrategy | undefined;
    AvailabilityZoneBalance?: InferenceComponentAvailabilityZoneBalance | undefined;
}
export interface InferenceComponentSpecification {
    InstanceType?: ProductionVariantInstanceType | undefined;
    ModelName?: string | undefined;
    Container?: InferenceComponentContainerSpecification | undefined;
    StartupParameters?: InferenceComponentStartupParameters | undefined;
    ComputeResourceRequirements?: InferenceComponentComputeResourceRequirements | undefined;
    BaseInferenceComponentName?: string | undefined;
    DataCacheConfig?: InferenceComponentDataCacheConfig | undefined;
    SchedulingConfig?: InferenceComponentSchedulingConfig | undefined;
}
export type InferenceComponentSpecificationList = InferenceComponentSpecification[];
export type InferenceComponentCopyCount = number;
export interface InferenceComponentRuntimeConfig {
    CopyCount?: number | undefined;
}
export interface CreateInferenceComponentInput {
    InferenceComponentName?: string | undefined;
    EndpointName?: string | undefined;
    VariantName?: string | undefined;
    Specification?: InferenceComponentSpecification | undefined;
    Specifications?: InferenceComponentSpecification[] | undefined;
    RuntimeConfig?: InferenceComponentRuntimeConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type InferenceComponentArn = string;
export interface CreateInferenceComponentOutput {
    InferenceComponentArn: string;
}
export type InferenceExperimentName = string;
export type InferenceExperimentType = "ShadowMode" | (string & {});
export interface InferenceExperimentSchedule {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type InferenceExperimentDescription = string;
export type ModelVariantName = string;
export type ModelInfrastructureType = "RealTimeInference" | (string & {});
export type TaskCount = number;
export interface RealTimeInferenceConfig {
    InstanceType?: ProductionVariantInstanceType | undefined;
    InstanceCount?: number | undefined;
}
export interface ModelInfrastructureConfig {
    InfrastructureType?: ModelInfrastructureType | undefined;
    RealTimeInferenceConfig?: RealTimeInferenceConfig | undefined;
}
export interface ModelVariantConfig {
    ModelName?: string | undefined;
    VariantName?: string | undefined;
    InfrastructureConfig?: ModelInfrastructureConfig | undefined;
}
export type ModelVariantConfigList = ModelVariantConfig[];
export interface InferenceExperimentDataStorageConfig {
    Destination?: string | undefined;
    KmsKey?: string | undefined;
    ContentType?: CaptureContentTypeHeader | undefined;
}
export interface ShadowModelVariantConfig {
    ShadowModelVariantName?: string | undefined;
    SamplingPercentage?: number | undefined;
}
export type ShadowModelVariantConfigList = ShadowModelVariantConfig[];
export interface ShadowModeConfig {
    SourceModelVariantName?: string | undefined;
    ShadowModelVariants?: ShadowModelVariantConfig[] | undefined;
}
export interface CreateInferenceExperimentRequest {
    Name?: string | undefined;
    Type?: InferenceExperimentType | undefined;
    Schedule?: InferenceExperimentSchedule | undefined;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    EndpointName?: string | undefined;
    ModelVariants?: ModelVariantConfig[] | undefined;
    DataStorageConfig?: InferenceExperimentDataStorageConfig | undefined;
    ShadowModeConfig?: ShadowModeConfig | undefined;
    KmsKey?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type InferenceExperimentArn = string;
export interface CreateInferenceExperimentResponse {
    InferenceExperimentArn: string;
}
export type RecommendationJobName = string;
export type RecommendationJobType = "Default" | "Advanced" | (string & {});
export type JobDurationInSeconds = number;
export type TrafficType = "PHASES" | "STAIRS" | (string & {});
export type InitialNumberOfUsers = number;
export type SpawnRate = number;
export type TrafficDurationInSeconds = number;
export interface Phase {
    InitialNumberOfUsers?: number | undefined;
    SpawnRate?: number | undefined;
    DurationInSeconds?: number | undefined;
}
export type Phases = Phase[];
export type NumberOfSteps = number;
export type UsersPerStep = number;
export interface Stairs {
    DurationInSeconds?: number | undefined;
    NumberOfSteps?: number | undefined;
    UsersPerStep?: number | undefined;
}
export interface TrafficPattern {
    TrafficType?: TrafficType | undefined;
    Phases?: Phase[] | undefined;
    Stairs?: Stairs | undefined;
}
export type MaxNumberOfTests = number;
export type MaxParallelOfTests = number;
export interface RecommendationJobResourceLimit {
    MaxNumberOfTests?: number | undefined;
    MaxParallelOfTests?: number | undefined;
}
export type InferenceSpecificationName = string;
export type String64 = string;
export type String128 = string;
export type CategoricalParameterRangeValues = string[];
export interface CategoricalParameter {
    Name?: string | undefined;
    Value?: string[] | undefined;
}
export type CategoricalParameters = CategoricalParameter[];
export interface EnvironmentParameterRanges {
    CategoricalParameterRanges?: CategoricalParameter[] | undefined;
}
export interface EndpointInputConfiguration {
    InstanceType?: ProductionVariantInstanceType | undefined;
    ServerlessConfig?: ProductionVariantServerlessConfig | undefined;
    InferenceSpecificationName?: string | undefined;
    EnvironmentParameterRanges?: EnvironmentParameterRanges | undefined;
}
export type EndpointInputConfigurations = EndpointInputConfiguration[];
export type RecommendationJobFrameworkVersion = string;
export type RecommendationJobSupportedContentType = string;
export type RecommendationJobSupportedContentTypes = string[];
export interface RecommendationJobPayloadConfig {
    SamplePayloadUrl?: string | undefined;
    SupportedContentTypes?: string[] | undefined;
}
export type RecommendationJobSupportedInstanceTypes = string[];
export type RecommendationJobSupportedEndpointType = "RealTime" | "Serverless" | (string & {});
export type RecommendationJobDataInputConfig = string;
export type RecommendationJobSupportedResponseMIMEType = string;
export type RecommendationJobSupportedResponseMIMETypes = string[];
export interface RecommendationJobContainerConfig {
    Domain?: string | undefined;
    Task?: string | undefined;
    Framework?: string | undefined;
    FrameworkVersion?: string | undefined;
    PayloadConfig?: RecommendationJobPayloadConfig | undefined;
    NearestModelName?: string | undefined;
    SupportedInstanceTypes?: string[] | undefined;
    SupportedEndpointType?: RecommendationJobSupportedEndpointType | undefined;
    DataInputConfig?: string | undefined;
    SupportedResponseMIMETypes?: string[] | undefined;
}
export interface EndpointInfo {
    EndpointName?: string | undefined;
}
export type Endpoints = EndpointInfo[];
export type RecommendationJobVpcSecurityGroupId = string;
export type RecommendationJobVpcSecurityGroupIds = string[];
export type RecommendationJobVpcSubnetId = string;
export type RecommendationJobVpcSubnets = string[];
export interface RecommendationJobVpcConfig {
    SecurityGroupIds?: string[] | undefined;
    Subnets?: string[] | undefined;
}
export interface RecommendationJobInputConfig {
    ModelPackageVersionArn?: string | undefined;
    ModelName?: string | undefined;
    JobDurationInSeconds?: number | undefined;
    TrafficPattern?: TrafficPattern | undefined;
    ResourceLimit?: RecommendationJobResourceLimit | undefined;
    EndpointConfigurations?: EndpointInputConfiguration[] | undefined;
    VolumeKmsKeyId?: string | undefined;
    ContainerConfig?: RecommendationJobContainerConfig | undefined;
    Endpoints?: EndpointInfo[] | undefined;
    VpcConfig?: RecommendationJobVpcConfig | undefined;
}
export type RecommendationJobDescription = string;
export interface ModelLatencyThreshold {
    Percentile?: string | undefined;
    ValueInMilliseconds?: number | undefined;
}
export type ModelLatencyThresholds = ModelLatencyThreshold[];
export type FlatInvocations = "Continue" | "Stop" | (string & {});
export interface RecommendationJobStoppingConditions {
    MaxInvocations?: number | undefined;
    ModelLatencyThresholds?: ModelLatencyThreshold[] | undefined;
    FlatInvocations?: FlatInvocations | undefined;
}
export interface RecommendationJobCompiledOutputConfig {
    S3OutputUri?: string | undefined;
}
export interface RecommendationJobOutputConfig {
    KmsKeyId?: string | undefined;
    CompiledOutputConfig?: RecommendationJobCompiledOutputConfig | undefined;
}
export interface CreateInferenceRecommendationsJobRequest {
    JobName?: string | undefined;
    JobType?: RecommendationJobType | undefined;
    RoleArn?: string | undefined;
    InputConfig?: RecommendationJobInputConfig | undefined;
    JobDescription?: string | undefined;
    StoppingConditions?: RecommendationJobStoppingConditions | undefined;
    OutputConfig?: RecommendationJobOutputConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type RecommendationJobArn = string;
export interface CreateInferenceRecommendationsJobResponse {
    JobArn: string;
}
export type JobName = string;
export type JobCategory = "AgentRFT" | "AgentRFTEvaluation" | (string & {});
export type JobSchemaVersion = string;
export type JobConfigDocument = string;
export interface CreateJobRequest {
    JobName?: string | undefined;
    RoleArn?: string | undefined;
    JobCategory?: JobCategory | undefined;
    JobConfigSchemaVersion?: string | undefined;
    JobConfigDocument?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type JobArn = string;
export interface CreateJobResponse {
    JobArn: string;
}
export type LabelingJobName = string;
export type LabelAttributeName = string;
export interface LabelingJobS3DataSource {
    ManifestS3Uri?: string | undefined;
}
export interface LabelingJobSnsDataSource {
    SnsTopicArn?: string | undefined;
}
export interface LabelingJobDataSource {
    S3DataSource?: LabelingJobS3DataSource | undefined;
    SnsDataSource?: LabelingJobSnsDataSource | undefined;
}
export type ContentClassifier = "FreeOfPersonallyIdentifiableInformation" | "FreeOfAdultContent" | (string & {});
export type ContentClassifiers = ContentClassifier[];
export interface LabelingJobDataAttributes {
    ContentClassifiers?: ContentClassifier[] | undefined;
}
export interface LabelingJobInputConfig {
    DataSource?: LabelingJobDataSource | undefined;
    DataAttributes?: LabelingJobDataAttributes | undefined;
}
export interface LabelingJobOutputConfig {
    S3OutputPath?: string | undefined;
    KmsKeyId?: string | undefined;
    SnsTopicArn?: string | undefined;
}
export type MaxHumanLabeledObjectCount = number;
export type MaxPercentageOfInputDatasetLabeled = number;
export interface LabelingJobStoppingConditions {
    MaxHumanLabeledObjectCount?: number | undefined;
    MaxPercentageOfInputDatasetLabeled?: number | undefined;
}
export type LabelingJobAlgorithmSpecificationArn = string;
export type ModelArn = string;
export interface LabelingJobResourceConfig {
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface LabelingJobAlgorithmsConfig {
    LabelingJobAlgorithmSpecificationArn?: string | undefined;
    InitialActiveLearningModelArn?: string | undefined;
    LabelingJobResourceConfig?: LabelingJobResourceConfig | undefined;
}
export interface UiConfig {
    UiTemplateS3Uri?: string | undefined;
    HumanTaskUiArn?: string | undefined;
}
export type LambdaFunctionArn = string;
export type TaskKeyword = string;
export type TaskKeywords = string[];
export type TaskTitle = string;
export type TaskDescription = string;
export type NumberOfHumanWorkersPerDataObject = number;
export type TaskTimeLimitInSeconds = number;
export type TaskAvailabilityLifetimeInSeconds = number;
export type MaxConcurrentTaskCount = number;
export interface AnnotationConsolidationConfig {
    AnnotationConsolidationLambdaArn?: string | undefined;
}
export interface HumanTaskConfig {
    WorkteamArn?: string | undefined;
    UiConfig?: UiConfig | undefined;
    PreHumanTaskLambdaArn?: string | undefined;
    TaskKeywords?: string[] | undefined;
    TaskTitle?: string | undefined;
    TaskDescription?: string | undefined;
    NumberOfHumanWorkersPerDataObject?: number | undefined;
    TaskTimeLimitInSeconds?: number | undefined;
    TaskAvailabilityLifetimeInSeconds?: number | undefined;
    MaxConcurrentTaskCount?: number | undefined;
    AnnotationConsolidationConfig?: AnnotationConsolidationConfig | undefined;
    PublicWorkforceTaskPrice?: PublicWorkforceTaskPrice | undefined;
}
export interface CreateLabelingJobRequest {
    LabelingJobName?: string | undefined;
    LabelAttributeName?: string | undefined;
    InputConfig?: LabelingJobInputConfig | undefined;
    OutputConfig?: LabelingJobOutputConfig | undefined;
    RoleArn?: string | undefined;
    LabelCategoryConfigS3Uri?: string | undefined;
    StoppingConditions?: LabelingJobStoppingConditions | undefined;
    LabelingJobAlgorithmsConfig?: LabelingJobAlgorithmsConfig | undefined;
    HumanTaskConfig?: HumanTaskConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type LabelingJobArn = string;
export interface CreateLabelingJobResponse {
    LabelingJobArn: string;
}
export type MlflowAppName = string;
export type ModelRegistrationMode = "AutoModelRegistrationEnabled" | "AutoModelRegistrationDisabled" | (string & {});
export type WeeklyMaintenanceWindowStart = string;
export type AccountDefaultStatus = "ENABLED" | "DISABLED" | (string & {});
export type DefaultDomainIdList = string[];
export interface CreateMlflowAppRequest {
    Name?: string | undefined;
    ArtifactStoreUri?: string | undefined;
    RoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    ModelRegistrationMode?: ModelRegistrationMode | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    AccountDefaultStatus?: AccountDefaultStatus | undefined;
    DefaultDomainIdList?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export type MlflowAppArn = string;
export interface CreateMlflowAppResponse {
    Arn?: string | undefined;
}
export type TrackingServerName = string;
export type TrackingServerSize = "Small" | "Medium" | "Large" | (string & {});
export type MlflowVersion = string;
export interface CreateMlflowTrackingServerRequest {
    TrackingServerName?: string | undefined;
    ArtifactStoreUri?: string | undefined;
    TrackingServerSize?: TrackingServerSize | undefined;
    MlflowVersion?: string | undefined;
    RoleArn?: string | undefined;
    AutomaticModelRegistration?: boolean | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    Tags?: Tag[] | undefined;
    S3BucketOwnerAccountId?: string | undefined;
    S3BucketOwnerVerification?: boolean | undefined;
}
export type TrackingServerArn = string;
export interface CreateMlflowTrackingServerResponse {
    TrackingServerArn?: string | undefined;
}
export type RepositoryAccessMode = "Platform" | "Vpc" | (string & {});
export type RepositoryCredentialsProviderArn = string;
export interface RepositoryAuthConfig {
    RepositoryCredentialsProviderArn?: string | undefined;
}
export interface ImageConfig {
    RepositoryAccessMode?: RepositoryAccessMode | undefined;
    RepositoryAuthConfig?: RepositoryAuthConfig | undefined;
}
export type ContainerMode = "SingleModel" | "MultiModel" | (string & {});
export type VersionedArnOrName = string;
export type ModelCacheSetting = "Enabled" | "Disabled" | (string & {});
export interface MultiModelConfig {
    ModelCacheSetting?: ModelCacheSetting | undefined;
}
export interface ContainerDefinition {
    ContainerHostname?: string | undefined;
    Image?: string | undefined;
    ImageConfig?: ImageConfig | undefined;
    Mode?: ContainerMode | undefined;
    ModelDataUrl?: string | undefined;
    ModelDataSource?: ModelDataSource | undefined;
    AdditionalModelDataSources?: AdditionalModelDataSource[] | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    ModelPackageName?: string | undefined;
    InferenceSpecificationName?: string | undefined;
    MultiModelConfig?: MultiModelConfig | undefined;
    ContainerMetricsConfig?: ContainerMetricsConfig | undefined;
}
export type ContainerDefinitionList = ContainerDefinition[];
export type InferenceExecutionMode = "Serial" | "Direct" | (string & {});
export interface InferenceExecutionConfig {
    Mode?: InferenceExecutionMode | undefined;
}
export interface CreateModelInput {
    ModelName?: string | undefined;
    PrimaryContainer?: ContainerDefinition | undefined;
    Containers?: ContainerDefinition[] | undefined;
    InferenceExecutionConfig?: InferenceExecutionConfig | undefined;
    ExecutionRoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
    VpcConfig?: VpcConfig | undefined;
    EnableNetworkIsolation?: boolean | undefined;
}
export interface CreateModelOutput {
    ModelArn: string;
}
export interface ModelBiasBaselineConfig {
    BaseliningJobName?: string | undefined;
    ConstraintsResource?: MonitoringConstraintsResource | undefined;
}
export interface ModelBiasAppSpecification {
    ImageUri?: string | undefined;
    ConfigUri?: string | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface MonitoringGroundTruthS3Input {
    S3Uri?: string | undefined;
}
export interface ModelBiasJobInput {
    EndpointInput?: EndpointInput | undefined;
    BatchTransformInput?: BatchTransformInput | undefined;
    GroundTruthS3Input?: MonitoringGroundTruthS3Input | undefined;
}
export interface CreateModelBiasJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
    ModelBiasBaselineConfig?: ModelBiasBaselineConfig | undefined;
    ModelBiasAppSpecification?: ModelBiasAppSpecification | undefined;
    ModelBiasJobInput?: ModelBiasJobInput | undefined;
    ModelBiasJobOutputConfig?: MonitoringOutputConfig | undefined;
    JobResources?: MonitoringResources | undefined;
    NetworkConfig?: MonitoringNetworkConfig | undefined;
    RoleArn?: string | undefined;
    StoppingCondition?: MonitoringStoppingCondition | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateModelBiasJobDefinitionResponse {
    JobDefinitionArn: string;
}
export interface ModelCardSecurityConfig {
    KmsKeyId?: string | undefined;
}
export type ModelCardContent = string | redacted.Redacted<string>;
export type ModelCardStatus = "Draft" | "PendingReview" | "Approved" | "Archived" | (string & {});
export interface CreateModelCardRequest {
    ModelCardName?: string | undefined;
    SecurityConfig?: ModelCardSecurityConfig | undefined;
    Content?: string | redacted.Redacted<string> | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
    Tags?: Tag[] | undefined;
}
export type ModelCardArn = string;
export interface CreateModelCardResponse {
    ModelCardArn: string;
}
export type ModelCardNameOrArn = string;
export interface ModelCardExportOutputConfig {
    S3OutputPath?: string | undefined;
}
export interface CreateModelCardExportJobRequest {
    ModelCardName?: string | undefined;
    ModelCardVersion?: number | undefined;
    ModelCardExportJobName?: string | undefined;
    OutputConfig?: ModelCardExportOutputConfig | undefined;
}
export type ModelCardExportJobArn = string;
export interface CreateModelCardExportJobResponse {
    ModelCardExportJobArn: string;
}
export interface ModelExplainabilityBaselineConfig {
    BaseliningJobName?: string | undefined;
    ConstraintsResource?: MonitoringConstraintsResource | undefined;
}
export interface ModelExplainabilityAppSpecification {
    ImageUri?: string | undefined;
    ConfigUri?: string | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ModelExplainabilityJobInput {
    EndpointInput?: EndpointInput | undefined;
    BatchTransformInput?: BatchTransformInput | undefined;
}
export interface CreateModelExplainabilityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
    ModelExplainabilityBaselineConfig?: ModelExplainabilityBaselineConfig | undefined;
    ModelExplainabilityAppSpecification?: ModelExplainabilityAppSpecification | undefined;
    ModelExplainabilityJobInput?: ModelExplainabilityJobInput | undefined;
    ModelExplainabilityJobOutputConfig?: MonitoringOutputConfig | undefined;
    JobResources?: MonitoringResources | undefined;
    NetworkConfig?: MonitoringNetworkConfig | undefined;
    RoleArn?: string | undefined;
    StoppingCondition?: MonitoringStoppingCondition | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateModelExplainabilityJobDefinitionResponse {
    JobDefinitionArn: string;
}
export interface ModelPackageValidationProfile {
    ProfileName?: string | undefined;
    TransformJobDefinition?: TransformJobDefinition | undefined;
}
export type ModelPackageValidationProfiles = ModelPackageValidationProfile[];
export interface ModelPackageValidationSpecification {
    ValidationRole?: string | undefined;
    ValidationProfiles?: ModelPackageValidationProfile[] | undefined;
}
export interface SourceAlgorithm {
    ModelDataUrl?: string | undefined;
    ModelDataSource?: ModelDataSource | undefined;
    ModelDataETag?: string | undefined;
    AlgorithmName?: string | undefined;
}
export type SourceAlgorithmList = SourceAlgorithm[];
export interface SourceAlgorithmSpecification {
    SourceAlgorithms?: SourceAlgorithm[] | undefined;
}
export type ContentDigest = string;
export interface MetricsSource {
    ContentType?: string | undefined;
    ContentDigest?: string | undefined;
    S3Uri?: string | undefined;
}
export interface ModelQuality {
    Statistics?: MetricsSource | undefined;
    Constraints?: MetricsSource | undefined;
}
export interface ModelDataQuality {
    Statistics?: MetricsSource | undefined;
    Constraints?: MetricsSource | undefined;
}
export interface Bias {
    Report?: MetricsSource | undefined;
    PreTrainingReport?: MetricsSource | undefined;
    PostTrainingReport?: MetricsSource | undefined;
}
export interface Explainability {
    Report?: MetricsSource | undefined;
}
export interface ModelMetrics {
    ModelQuality?: ModelQuality | undefined;
    ModelDataQuality?: ModelDataQuality | undefined;
    Bias?: Bias | undefined;
    Explainability?: Explainability | undefined;
}
export type CustomerMetadataKey = string;
export type CustomerMetadataValue = string;
export type CustomerMetadataMap = {
    [key: string]: string | undefined;
};
export interface FileSource {
    ContentType?: string | undefined;
    ContentDigest?: string | undefined;
    S3Uri?: string | undefined;
}
export interface DriftCheckBias {
    ConfigFile?: FileSource | undefined;
    PreTrainingConstraints?: MetricsSource | undefined;
    PostTrainingConstraints?: MetricsSource | undefined;
}
export interface DriftCheckExplainability {
    Constraints?: MetricsSource | undefined;
    ConfigFile?: FileSource | undefined;
}
export interface DriftCheckModelQuality {
    Statistics?: MetricsSource | undefined;
    Constraints?: MetricsSource | undefined;
}
export interface DriftCheckModelDataQuality {
    Statistics?: MetricsSource | undefined;
    Constraints?: MetricsSource | undefined;
}
export interface DriftCheckBaselines {
    Bias?: DriftCheckBias | undefined;
    Explainability?: DriftCheckExplainability | undefined;
    ModelQuality?: DriftCheckModelQuality | undefined;
    ModelDataQuality?: DriftCheckModelDataQuality | undefined;
}
export interface AdditionalInferenceSpecificationDefinition {
    Name?: string | undefined;
    Description?: string | undefined;
    Containers?: ModelPackageContainerDefinition[] | undefined;
    SupportedTransformInstanceTypes?: TransformInstanceType[] | undefined;
    SupportedRealtimeInferenceInstanceTypes?: ProductionVariantInstanceType[] | undefined;
    SupportedContentTypes?: string[] | undefined;
    SupportedResponseMIMETypes?: string[] | undefined;
}
export type AdditionalInferenceSpecifications = AdditionalInferenceSpecificationDefinition[];
export type SkipModelValidation = "All" | "None" | (string & {});
export type ModelPackageSourceUri = string;
export interface ModelPackageSecurityConfig {
    KmsKeyId?: string | undefined;
}
export interface ModelPackageModelCard {
    ModelCardContent?: string | redacted.Redacted<string> | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
}
export type StageDescription = string;
export interface ModelLifeCycle {
    Stage?: string | undefined;
    StageStatus?: string | undefined;
    StageDescription?: string | undefined;
}
export type ManagedStorageType = "Restricted" | (string & {});
export interface CreateModelPackageInput {
    ModelPackageName?: string | undefined;
    ModelPackageGroupName?: string | undefined;
    ModelPackageDescription?: string | undefined;
    ModelPackageRegistrationType?: ModelPackageRegistrationType | undefined;
    InferenceSpecification?: InferenceSpecification | undefined;
    ValidationSpecification?: ModelPackageValidationSpecification | undefined;
    SourceAlgorithmSpecification?: SourceAlgorithmSpecification | undefined;
    CertifyForMarketplace?: boolean | undefined;
    Tags?: Tag[] | undefined;
    ModelApprovalStatus?: ModelApprovalStatus | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    ModelMetrics?: ModelMetrics | undefined;
    ClientToken?: string | undefined;
    Domain?: string | undefined;
    Task?: string | undefined;
    SamplePayloadUrl?: string | undefined;
    CustomerMetadataProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    DriftCheckBaselines?: DriftCheckBaselines | undefined;
    AdditionalInferenceSpecifications?: AdditionalInferenceSpecificationDefinition[] | undefined;
    SkipModelValidation?: SkipModelValidation | undefined;
    SourceUri?: string | undefined;
    SecurityConfig?: ModelPackageSecurityConfig | undefined;
    ModelCard?: ModelPackageModelCard | undefined;
    ModelLifeCycle?: ModelLifeCycle | undefined;
    ManagedStorageType?: ManagedStorageType | undefined;
}
export interface CreateModelPackageOutput {
    ModelPackageArn: string;
}
export interface ManagedConfiguration {
    ManagedStorageType?: ManagedStorageType | undefined;
}
export interface CreateModelPackageGroupInput {
    ModelPackageGroupName?: string | undefined;
    ModelPackageGroupDescription?: string | undefined;
    Tags?: Tag[] | undefined;
    ManagedConfiguration?: ManagedConfiguration | undefined;
}
export type ModelPackageGroupArn = string;
export interface CreateModelPackageGroupOutput {
    ModelPackageGroupArn: string;
}
export interface ModelQualityBaselineConfig {
    BaseliningJobName?: string | undefined;
    ConstraintsResource?: MonitoringConstraintsResource | undefined;
}
export type MonitoringProblemType = "BinaryClassification" | "MulticlassClassification" | "Regression" | (string & {});
export interface ModelQualityAppSpecification {
    ImageUri?: string | undefined;
    ContainerEntrypoint?: string[] | undefined;
    ContainerArguments?: string[] | undefined;
    RecordPreprocessorSourceUri?: string | undefined;
    PostAnalyticsProcessorSourceUri?: string | undefined;
    ProblemType?: MonitoringProblemType | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ModelQualityJobInput {
    EndpointInput?: EndpointInput | undefined;
    BatchTransformInput?: BatchTransformInput | undefined;
    GroundTruthS3Input?: MonitoringGroundTruthS3Input | undefined;
}
export interface CreateModelQualityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
    ModelQualityBaselineConfig?: ModelQualityBaselineConfig | undefined;
    ModelQualityAppSpecification?: ModelQualityAppSpecification | undefined;
    ModelQualityJobInput?: ModelQualityJobInput | undefined;
    ModelQualityJobOutputConfig?: MonitoringOutputConfig | undefined;
    JobResources?: MonitoringResources | undefined;
    NetworkConfig?: MonitoringNetworkConfig | undefined;
    RoleArn?: string | undefined;
    StoppingCondition?: MonitoringStoppingCondition | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateModelQualityJobDefinitionResponse {
    JobDefinitionArn: string;
}
export type MonitoringScheduleName = string;
export type ScheduleExpression = string;
export interface ScheduleConfig {
    ScheduleExpression?: string | undefined;
    DataAnalysisStartTime?: string | undefined;
    DataAnalysisEndTime?: string | undefined;
}
export interface MonitoringBaselineConfig {
    BaseliningJobName?: string | undefined;
    ConstraintsResource?: MonitoringConstraintsResource | undefined;
    StatisticsResource?: MonitoringStatisticsResource | undefined;
}
export interface MonitoringInput {
    EndpointInput?: EndpointInput | undefined;
    BatchTransformInput?: BatchTransformInput | undefined;
}
export type MonitoringInputs = MonitoringInput[];
export interface MonitoringAppSpecification {
    ImageUri?: string | undefined;
    ContainerEntrypoint?: string[] | undefined;
    ContainerArguments?: string[] | undefined;
    RecordPreprocessorSourceUri?: string | undefined;
    PostAnalyticsProcessorSourceUri?: string | undefined;
}
export interface NetworkConfig {
    EnableInterContainerTrafficEncryption?: boolean | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface MonitoringJobDefinition {
    BaselineConfig?: MonitoringBaselineConfig | undefined;
    MonitoringInputs?: MonitoringInput[] | undefined;
    MonitoringOutputConfig?: MonitoringOutputConfig | undefined;
    MonitoringResources?: MonitoringResources | undefined;
    MonitoringAppSpecification?: MonitoringAppSpecification | undefined;
    StoppingCondition?: MonitoringStoppingCondition | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    NetworkConfig?: NetworkConfig | undefined;
    RoleArn?: string | undefined;
}
export type MonitoringType = "DataQuality" | "ModelQuality" | "ModelBias" | "ModelExplainability" | (string & {});
export interface MonitoringScheduleConfig {
    ScheduleConfig?: ScheduleConfig | undefined;
    MonitoringJobDefinition?: MonitoringJobDefinition | undefined;
    MonitoringJobDefinitionName?: string | undefined;
    MonitoringType?: MonitoringType | undefined;
}
export interface CreateMonitoringScheduleRequest {
    MonitoringScheduleName?: string | undefined;
    MonitoringScheduleConfig?: MonitoringScheduleConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type MonitoringScheduleArn = string;
export interface CreateMonitoringScheduleResponse {
    MonitoringScheduleArn: string;
}
export type NotebookInstanceName = string;
export type InstanceType = "ml.t2.medium" | "ml.t2.large" | "ml.t2.xlarge" | "ml.t2.2xlarge" | "ml.t3.medium" | "ml.t3.large" | "ml.t3.xlarge" | "ml.t3.2xlarge" | "ml.m4.xlarge" | "ml.m4.2xlarge" | "ml.m4.4xlarge" | "ml.m4.10xlarge" | "ml.m4.16xlarge" | "ml.m5.xlarge" | "ml.m5.2xlarge" | "ml.m5.4xlarge" | "ml.m5.12xlarge" | "ml.m5.24xlarge" | "ml.m5d.large" | "ml.m5d.xlarge" | "ml.m5d.2xlarge" | "ml.m5d.4xlarge" | "ml.m5d.8xlarge" | "ml.m5d.12xlarge" | "ml.m5d.16xlarge" | "ml.m5d.24xlarge" | "ml.c4.xlarge" | "ml.c4.2xlarge" | "ml.c4.4xlarge" | "ml.c4.8xlarge" | "ml.c5.xlarge" | "ml.c5.2xlarge" | "ml.c5.4xlarge" | "ml.c5.9xlarge" | "ml.c5.18xlarge" | "ml.c5d.xlarge" | "ml.c5d.2xlarge" | "ml.c5d.4xlarge" | "ml.c5d.9xlarge" | "ml.c5d.18xlarge" | "ml.p2.xlarge" | "ml.p2.8xlarge" | "ml.p2.16xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | "ml.p3.16xlarge" | "ml.p3dn.24xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.r5.large" | "ml.r5.xlarge" | "ml.r5.2xlarge" | "ml.r5.4xlarge" | "ml.r5.8xlarge" | "ml.r5.12xlarge" | "ml.r5.16xlarge" | "ml.r5.24xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.16xlarge" | "ml.g5.12xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.inf1.xlarge" | "ml.inf1.2xlarge" | "ml.inf1.6xlarge" | "ml.inf1.24xlarge" | "ml.trn1.2xlarge" | "ml.trn1.32xlarge" | "ml.trn1n.32xlarge" | "ml.inf2.xlarge" | "ml.inf2.8xlarge" | "ml.inf2.24xlarge" | "ml.inf2.48xlarge" | "ml.p4d.24xlarge" | "ml.p4de.24xlarge" | "ml.p5.48xlarge" | "ml.p6-b200.48xlarge" | "ml.m6i.large" | "ml.m6i.xlarge" | "ml.m6i.2xlarge" | "ml.m6i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.12xlarge" | "ml.m6i.16xlarge" | "ml.m6i.24xlarge" | "ml.m6i.32xlarge" | "ml.m7i.large" | "ml.m7i.xlarge" | "ml.m7i.2xlarge" | "ml.m7i.4xlarge" | "ml.m7i.8xlarge" | "ml.m7i.12xlarge" | "ml.m7i.16xlarge" | "ml.m7i.24xlarge" | "ml.m7i.48xlarge" | "ml.c6i.large" | "ml.c6i.xlarge" | "ml.c6i.2xlarge" | "ml.c6i.4xlarge" | "ml.c6i.8xlarge" | "ml.c6i.12xlarge" | "ml.c6i.16xlarge" | "ml.c6i.24xlarge" | "ml.c6i.32xlarge" | "ml.c7i.large" | "ml.c7i.xlarge" | "ml.c7i.2xlarge" | "ml.c7i.4xlarge" | "ml.c7i.8xlarge" | "ml.c7i.12xlarge" | "ml.c7i.16xlarge" | "ml.c7i.24xlarge" | "ml.c7i.48xlarge" | "ml.r6i.large" | "ml.r6i.xlarge" | "ml.r6i.2xlarge" | "ml.r6i.4xlarge" | "ml.r6i.8xlarge" | "ml.r6i.12xlarge" | "ml.r6i.16xlarge" | "ml.r6i.24xlarge" | "ml.r6i.32xlarge" | "ml.r7i.large" | "ml.r7i.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.4xlarge" | "ml.r7i.8xlarge" | "ml.r7i.12xlarge" | "ml.r7i.16xlarge" | "ml.r7i.24xlarge" | "ml.r7i.48xlarge" | "ml.m6id.large" | "ml.m6id.xlarge" | "ml.m6id.2xlarge" | "ml.m6id.4xlarge" | "ml.m6id.8xlarge" | "ml.m6id.12xlarge" | "ml.m6id.16xlarge" | "ml.m6id.24xlarge" | "ml.m6id.32xlarge" | "ml.c6id.large" | "ml.c6id.xlarge" | "ml.c6id.2xlarge" | "ml.c6id.4xlarge" | "ml.c6id.8xlarge" | "ml.c6id.12xlarge" | "ml.c6id.16xlarge" | "ml.c6id.24xlarge" | "ml.c6id.32xlarge" | "ml.r6id.large" | "ml.r6id.xlarge" | "ml.r6id.2xlarge" | "ml.r6id.4xlarge" | "ml.r6id.8xlarge" | "ml.r6id.12xlarge" | "ml.r6id.16xlarge" | "ml.r6id.24xlarge" | "ml.r6id.32xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.12xlarge" | "ml.g6.16xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.g7e.2xlarge" | "ml.g7e.4xlarge" | "ml.g7e.8xlarge" | "ml.g7e.12xlarge" | "ml.g7e.24xlarge" | "ml.g7e.48xlarge" | "ml.p5.4xlarge" | "ml.p5en.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.12xlarge" | "ml.g6e.16xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | (string & {});
export type NotebookInstanceLifecycleConfigName = string;
export type DirectInternetAccess = "Enabled" | "Disabled" | (string & {});
export type NotebookInstanceVolumeSizeInGB = number;
export type NotebookInstanceAcceleratorType = "ml.eia1.medium" | "ml.eia1.large" | "ml.eia1.xlarge" | "ml.eia2.medium" | "ml.eia2.large" | "ml.eia2.xlarge" | (string & {});
export type NotebookInstanceAcceleratorTypes = NotebookInstanceAcceleratorType[];
export type CodeRepositoryNameOrUrl = string;
export type AdditionalCodeRepositoryNamesOrUrls = string[];
export type RootAccess = "Enabled" | "Disabled" | (string & {});
export type PlatformIdentifier = string;
export type MinimumInstanceMetadataServiceVersion = string;
export interface InstanceMetadataServiceConfiguration {
    MinimumInstanceMetadataServiceVersion?: string | undefined;
}
export interface CreateNotebookInstanceInput {
    NotebookInstanceName?: string | undefined;
    InstanceType?: InstanceType | undefined;
    SubnetId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    IpAddressType?: IPAddressType | undefined;
    RoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
    LifecycleConfigName?: string | undefined;
    DirectInternetAccess?: DirectInternetAccess | undefined;
    VolumeSizeInGB?: number | undefined;
    AcceleratorTypes?: NotebookInstanceAcceleratorType[] | undefined;
    DefaultCodeRepository?: string | undefined;
    AdditionalCodeRepositories?: string[] | undefined;
    RootAccess?: RootAccess | undefined;
    PlatformIdentifier?: string | undefined;
    InstanceMetadataServiceConfiguration?: InstanceMetadataServiceConfiguration | undefined;
}
export type NotebookInstanceArn = string;
export interface CreateNotebookInstanceOutput {
    NotebookInstanceArn?: string | undefined;
}
export type NotebookInstanceLifecycleConfigContent = string;
export interface NotebookInstanceLifecycleHook {
    Content?: string | undefined;
}
export type NotebookInstanceLifecycleConfigList = NotebookInstanceLifecycleHook[];
export interface CreateNotebookInstanceLifecycleConfigInput {
    NotebookInstanceLifecycleConfigName?: string | undefined;
    OnCreate?: NotebookInstanceLifecycleHook[] | undefined;
    OnStart?: NotebookInstanceLifecycleHook[] | undefined;
    Tags?: Tag[] | undefined;
}
export type NotebookInstanceLifecycleConfigArn = string;
export interface CreateNotebookInstanceLifecycleConfigOutput {
    NotebookInstanceLifecycleConfigArn?: string | undefined;
}
export type OptimizationModelAcceptEula = boolean;
export interface OptimizationModelAccessConfig {
    AcceptEula?: boolean | undefined;
}
export interface OptimizationJobModelSourceS3 {
    S3Uri?: string | undefined;
    ModelAccessConfig?: OptimizationModelAccessConfig | undefined;
}
export interface OptimizationSageMakerModel {
    ModelName?: string | undefined;
}
export interface OptimizationJobModelSource {
    S3?: OptimizationJobModelSourceS3 | undefined;
    SageMakerModel?: OptimizationSageMakerModel | undefined;
}
export type OptimizationJobDeploymentInstanceType = "ml.p4d.24xlarge" | "ml.p4de.24xlarge" | "ml.p5.48xlarge" | "ml.p5e.48xlarge" | "ml.p5en.48xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.12xlarge" | "ml.g5.16xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.12xlarge" | "ml.g6.16xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.12xlarge" | "ml.g6e.16xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | "ml.inf2.xlarge" | "ml.inf2.8xlarge" | "ml.inf2.24xlarge" | "ml.inf2.48xlarge" | "ml.trn1.2xlarge" | "ml.trn1.32xlarge" | "ml.trn1n.32xlarge" | "ml.p6-b200.48xlarge" | "ml.g7e.2xlarge" | "ml.g7e.4xlarge" | "ml.g7e.8xlarge" | "ml.g7e.12xlarge" | "ml.g7e.24xlarge" | "ml.g7e.48xlarge" | "ml.g7.2xlarge" | "ml.g7.4xlarge" | "ml.g7.8xlarge" | "ml.g7.12xlarge" | "ml.g7.24xlarge" | "ml.g7.48xlarge" | (string & {});
export type OptimizationJobMaxInstanceCount = number;
export type OptimizationJobEnvironmentVariables = {
    [key: string]: string | undefined;
};
export type OptimizationContainerImage = string;
export interface ModelQuantizationConfig {
    Image?: string | undefined;
    OverrideEnvironment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ModelCompilationConfig {
    Image?: string | undefined;
    OverrideEnvironment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ModelShardingConfig {
    Image?: string | undefined;
    OverrideEnvironment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ModelSpeculativeDecodingTechnique = "EAGLE" | (string & {});
export type ModelSpeculativeDecodingS3DataType = "S3Prefix" | "ManifestFile" | (string & {});
export interface ModelSpeculativeDecodingTrainingDataSource {
    S3Uri?: string | undefined;
    S3DataType?: ModelSpeculativeDecodingS3DataType | undefined;
}
export interface ModelSpeculativeDecodingConfig {
    Technique?: ModelSpeculativeDecodingTechnique | undefined;
    TrainingDataSource?: ModelSpeculativeDecodingTrainingDataSource | undefined;
}
export type OptimizationConfig = {
    ModelQuantizationConfig: ModelQuantizationConfig;
    ModelCompilationConfig?: undefined;
    ModelShardingConfig?: undefined;
    ModelSpeculativeDecodingConfig?: undefined;
} | {
    ModelQuantizationConfig?: undefined;
    ModelCompilationConfig: ModelCompilationConfig;
    ModelShardingConfig?: undefined;
    ModelSpeculativeDecodingConfig?: undefined;
} | {
    ModelQuantizationConfig?: undefined;
    ModelCompilationConfig?: undefined;
    ModelShardingConfig: ModelShardingConfig;
    ModelSpeculativeDecodingConfig?: undefined;
} | {
    ModelQuantizationConfig?: undefined;
    ModelCompilationConfig?: undefined;
    ModelShardingConfig?: undefined;
    ModelSpeculativeDecodingConfig: ModelSpeculativeDecodingConfig;
};
export type OptimizationConfigs = OptimizationConfig[];
export interface OptimizationJobOutputConfig {
    KmsKeyId?: string | undefined;
    S3OutputLocation?: string | undefined;
    SageMakerModel?: OptimizationSageMakerModel | undefined;
}
export type OptimizationVpcSecurityGroupId = string;
export type OptimizationVpcSecurityGroupIds = string[];
export type OptimizationVpcSubnetId = string;
export type OptimizationVpcSubnets = string[];
export interface OptimizationVpcConfig {
    SecurityGroupIds?: string[] | undefined;
    Subnets?: string[] | undefined;
}
export type OptimizationJobTrainingPlanArns = string[];
export interface CreateOptimizationJobRequest {
    OptimizationJobName?: string | undefined;
    RoleArn?: string | undefined;
    ModelSource?: OptimizationJobModelSource | undefined;
    DeploymentInstanceType?: OptimizationJobDeploymentInstanceType | undefined;
    MaxInstanceCount?: number | undefined;
    OptimizationEnvironment?: {
        [key: string]: string | undefined;
    } | undefined;
    OptimizationConfigs?: OptimizationConfig[] | undefined;
    OutputConfig?: OptimizationJobOutputConfig | undefined;
    StoppingCondition?: StoppingCondition | undefined;
    Tags?: Tag[] | undefined;
    VpcConfig?: OptimizationVpcConfig | undefined;
    TrainingPlanArns?: string[] | undefined;
}
export type OptimizationJobArn = string;
export interface CreateOptimizationJobResponse {
    OptimizationJobArn: string;
}
export type PartnerAppName = string;
export type PartnerAppType = "lakera-guard" | "comet" | "deepchecks-llm-evaluation" | "fiddler" | (string & {});
export type WeeklyScheduleTimeFormat = string;
export interface PartnerAppMaintenanceConfig {
    MaintenanceWindowStart?: string | undefined;
}
export type PartnerAppAdminUserList = string[];
export type PartnerAppArguments = {
    [key: string]: string | undefined;
};
export type GroupNamePattern = string;
export type AssignedGroupPatternsList = string[];
export type GroupPatternsList = string[];
export interface RoleGroupAssignment {
    RoleName: string;
    GroupPatterns: string[];
}
export type RoleGroupAssignmentsList = RoleGroupAssignment[];
export interface PartnerAppConfig {
    AdminUsers?: string[] | undefined;
    Arguments?: {
        [key: string]: string | undefined;
    } | undefined;
    AssignedGroupPatterns?: string[] | undefined;
    RoleGroupAssignments?: RoleGroupAssignment[] | undefined;
}
export type InstanceArn = string;
export interface IdcConfigInput {
    InstanceArn: string;
}
export type PartnerAppAuthType = "IAM" | "IDC" | (string & {});
export interface CreatePartnerAppRequest {
    Name?: string | undefined;
    Type?: PartnerAppType | undefined;
    ExecutionRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    MaintenanceConfig?: PartnerAppMaintenanceConfig | undefined;
    Tier?: string | undefined;
    ApplicationConfig?: PartnerAppConfig | undefined;
    IdcConfig?: IdcConfigInput | undefined;
    AuthType?: PartnerAppAuthType | undefined;
    EnableIamSessionBasedIdentity?: boolean | undefined;
    EnableAutoMinorVersionUpgrade?: boolean | undefined;
    ClientToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type PartnerAppArn = string;
export interface CreatePartnerAppResponse {
    Arn?: string | undefined;
}
export type ExpiresInSeconds = number;
export type SessionExpirationDurationInSeconds = number;
export interface CreatePartnerAppPresignedUrlRequest {
    Arn?: string | undefined;
    ExpiresInSeconds?: number | undefined;
    SessionExpirationDurationInSeconds?: number | undefined;
}
export type String2048 = string;
export interface CreatePartnerAppPresignedUrlResponse {
    Url?: string | undefined;
}
export type PipelineName = string;
export type PipelineDefinition = string;
export type BucketName = string;
export type Key = string;
export type VersionId = string;
export interface PipelineDefinitionS3Location {
    Bucket?: string | undefined;
    ObjectKey?: string | undefined;
    VersionId?: string | undefined;
}
export type PipelineDescription = string;
export type IdempotencyToken = string;
export type MaxParallelExecutionSteps = number;
export interface ParallelismConfiguration {
    MaxParallelExecutionSteps?: number | undefined;
}
export type PipelineVersionAlias = string;
export type PipelineVersionAliasList = string[];
export interface CreatePipelineRequest {
    PipelineName?: string | undefined;
    PipelineDisplayName?: string | undefined;
    PipelineDefinition?: string | undefined;
    PipelineDefinitionS3Location?: PipelineDefinitionS3Location | undefined;
    PipelineDescription?: string | undefined;
    ClientRequestToken?: string | undefined;
    RoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
    ParallelismConfiguration?: ParallelismConfiguration | undefined;
    PipelineVersionAliases?: string[] | undefined;
}
export type PipelineArn = string;
export interface CreatePipelineResponse {
    PipelineArn?: string | undefined;
}
export interface CreatePresignedDomainUrlRequest {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    SessionExpirationDurationInSeconds?: number | undefined;
    ExpiresInSeconds?: number | undefined;
    SpaceName?: string | undefined;
    LandingUri?: string | undefined;
}
export type PresignedDomainUrl = string;
export interface CreatePresignedDomainUrlResponse {
    AuthorizedUrl?: string | undefined;
}
export interface CreatePresignedMlflowAppUrlRequest {
    Arn?: string | undefined;
    ExpiresInSeconds?: number | undefined;
    SessionExpirationDurationInSeconds?: number | undefined;
}
export type MlflowAppUrl = string;
export interface CreatePresignedMlflowAppUrlResponse {
    AuthorizedUrl?: string | undefined;
}
export interface CreatePresignedMlflowTrackingServerUrlRequest {
    TrackingServerName?: string | undefined;
    ExpiresInSeconds?: number | undefined;
    SessionExpirationDurationInSeconds?: number | undefined;
}
export type TrackingServerUrl = string;
export interface CreatePresignedMlflowTrackingServerUrlResponse {
    AuthorizedUrl?: string | undefined;
}
export interface CreatePresignedNotebookInstanceUrlInput {
    NotebookInstanceName?: string | undefined;
    SessionExpirationDurationInSeconds?: number | undefined;
}
export type NotebookInstanceUrl = string;
export interface CreatePresignedNotebookInstanceUrlOutput {
    AuthorizedUrl?: string | undefined;
}
export type AppManaged = boolean;
export type ProcessingS3DataType = "ManifestFile" | "S3Prefix" | (string & {});
export type ProcessingS3CompressionType = "None" | "Gzip" | (string & {});
export interface ProcessingS3Input {
    S3Uri?: string | undefined;
    LocalPath?: string | undefined;
    S3DataType?: ProcessingS3DataType | undefined;
    S3InputMode?: ProcessingS3InputMode | undefined;
    S3DataDistributionType?: ProcessingS3DataDistributionType | undefined;
    S3CompressionType?: ProcessingS3CompressionType | undefined;
}
export type AthenaCatalog = string;
export type AthenaDatabase = string;
export type AthenaQueryString = string;
export type AthenaWorkGroup = string;
export type AthenaResultFormat = "PARQUET" | "ORC" | "AVRO" | "JSON" | "TEXTFILE" | (string & {});
export type AthenaResultCompressionType = "GZIP" | "SNAPPY" | "ZLIB" | (string & {});
export interface AthenaDatasetDefinition {
    Catalog?: string | undefined;
    Database?: string | undefined;
    QueryString?: string | undefined;
    WorkGroup?: string | undefined;
    OutputS3Uri?: string | undefined;
    KmsKeyId?: string | undefined;
    OutputFormat?: AthenaResultFormat | undefined;
    OutputCompression?: AthenaResultCompressionType | undefined;
}
export type RedshiftClusterId = string;
export type RedshiftDatabase = string;
export type RedshiftUserName = string;
export type RedshiftQueryString = string;
export type RedshiftResultFormat = "PARQUET" | "CSV" | (string & {});
export type RedshiftResultCompressionType = "None" | "GZIP" | "BZIP2" | "ZSTD" | "SNAPPY" | (string & {});
export interface RedshiftDatasetDefinition {
    ClusterId?: string | undefined;
    Database?: string | undefined;
    DbUser?: string | undefined;
    QueryString?: string | undefined;
    ClusterRoleArn?: string | undefined;
    OutputS3Uri?: string | undefined;
    KmsKeyId?: string | undefined;
    OutputFormat?: RedshiftResultFormat | undefined;
    OutputCompression?: RedshiftResultCompressionType | undefined;
}
export type DataDistributionType = "FullyReplicated" | "ShardedByS3Key" | (string & {});
export type InputMode = "Pipe" | "File" | (string & {});
export interface DatasetDefinition {
    AthenaDatasetDefinition?: AthenaDatasetDefinition | undefined;
    RedshiftDatasetDefinition?: RedshiftDatasetDefinition | undefined;
    LocalPath?: string | undefined;
    DataDistributionType?: DataDistributionType | undefined;
    InputMode?: InputMode | undefined;
}
export interface ProcessingInput {
    InputName?: string | undefined;
    AppManaged?: boolean | undefined;
    S3Input?: ProcessingS3Input | undefined;
    DatasetDefinition?: DatasetDefinition | undefined;
}
export type ProcessingInputs = ProcessingInput[];
export interface ProcessingS3Output {
    S3Uri?: string | undefined;
    LocalPath?: string | undefined;
    S3UploadMode?: ProcessingS3UploadMode | undefined;
}
export interface ProcessingFeatureStoreOutput {
    FeatureGroupName?: string | undefined;
}
export interface ProcessingOutput {
    OutputName?: string | undefined;
    S3Output?: ProcessingS3Output | undefined;
    FeatureStoreOutput?: ProcessingFeatureStoreOutput | undefined;
    AppManaged?: boolean | undefined;
}
export type ProcessingOutputs = ProcessingOutput[];
export interface ProcessingOutputConfig {
    Outputs?: ProcessingOutput[] | undefined;
    KmsKeyId?: string | undefined;
}
export interface ProcessingInstancePreference {
    InstanceType?: ProcessingInstanceType | undefined;
    InstanceCount?: number | undefined;
}
export type ProcessingInstancePreferenceList = ProcessingInstancePreference[];
export interface ProcessingClusterConfig {
    InstanceCount?: number | undefined;
    InstanceType?: ProcessingInstanceType | undefined;
    VolumeSizeInGB?: number | undefined;
    VolumeKmsKeyId?: string | undefined;
    InstancePreferences?: ProcessingInstancePreference[] | undefined;
    SelectedInstanceType?: ProcessingInstanceType | undefined;
    SelectedInstanceCount?: number | undefined;
}
export interface ProcessingResources {
    ClusterConfig?: ProcessingClusterConfig | undefined;
}
export type ProcessingMaxRuntimeInSeconds = number;
export interface ProcessingStoppingCondition {
    MaxRuntimeInSeconds?: number | undefined;
}
export type ContainerArguments = string[];
export interface AppSpecification {
    ImageUri?: string | undefined;
    ContainerEntrypoint?: string[] | undefined;
    ContainerArguments?: string[] | undefined;
}
export type ProcessingEnvironmentMap = {
    [key: string]: string | undefined;
};
export interface ExperimentConfig {
    ExperimentName?: string | undefined;
    TrialName?: string | undefined;
    TrialComponentDisplayName?: string | undefined;
    RunName?: string | undefined;
}
export interface CreateProcessingJobRequest {
    ProcessingInputs?: ProcessingInput[] | undefined;
    ProcessingOutputConfig?: ProcessingOutputConfig | undefined;
    ProcessingJobName?: string | undefined;
    ProcessingResources?: ProcessingResources | undefined;
    StoppingCondition?: ProcessingStoppingCondition | undefined;
    AppSpecification?: AppSpecification | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    NetworkConfig?: NetworkConfig | undefined;
    RoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
}
export type ProcessingJobArn = string;
export interface CreateProcessingJobResponse {
    ProcessingJobArn: string;
}
export type ProjectEntityName = string;
export type ServiceCatalogEntityId = string;
export type ProvisioningParameterKey = string;
export type ProvisioningParameterValue = string;
export interface ProvisioningParameter {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type ProvisioningParameters = ProvisioningParameter[];
export interface ServiceCatalogProvisioningDetails {
    ProductId?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    PathId?: string | undefined;
    ProvisioningParameters?: ProvisioningParameter[] | undefined;
}
export type CfnTemplateName = string;
export type CfnTemplateURL = string;
export type CfnStackParameterKey = string;
export type CfnStackParameterValue = string;
export interface CfnStackCreateParameter {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type CfnStackCreateParameters = CfnStackCreateParameter[];
export interface CfnCreateTemplateProvider {
    TemplateName?: string | undefined;
    TemplateURL?: string | undefined;
    RoleARN?: string | undefined;
    Parameters?: CfnStackCreateParameter[] | undefined;
}
export interface CreateTemplateProvider {
    CfnTemplateProvider?: CfnCreateTemplateProvider | undefined;
}
export type CreateTemplateProviderList = CreateTemplateProvider[];
export interface CreateProjectInput {
    ProjectName?: string | undefined;
    ProjectDescription?: string | undefined;
    ServiceCatalogProvisioningDetails?: ServiceCatalogProvisioningDetails | undefined;
    Tags?: Tag[] | undefined;
    TemplateProviders?: CreateTemplateProvider[] | undefined;
}
export type ProjectArn = string;
export type ProjectId = string;
export interface CreateProjectOutput {
    ProjectArn: string;
    ProjectId: string;
}
export interface SpaceIdleSettings {
    IdleTimeoutInMinutes?: number | undefined;
}
export interface SpaceAppLifecycleManagement {
    IdleSettings?: SpaceIdleSettings | undefined;
}
export interface SpaceCodeEditorAppSettings {
    DefaultResourceSpec?: ResourceSpec | undefined;
    AppLifecycleManagement?: SpaceAppLifecycleManagement | undefined;
}
export interface SpaceJupyterLabAppSettings {
    DefaultResourceSpec?: ResourceSpec | undefined;
    CodeRepositories?: CodeRepository[] | undefined;
    AppLifecycleManagement?: SpaceAppLifecycleManagement | undefined;
}
export interface EbsStorageSettings {
    EbsVolumeSizeInGb?: number | undefined;
}
export interface SpaceStorageSettings {
    EbsStorageSettings?: EbsStorageSettings | undefined;
}
export interface EFSFileSystem {
    FileSystemId?: string | undefined;
}
export interface FSxLustreFileSystem {
    FileSystemId?: string | undefined;
}
export interface S3FileSystem {
    S3Uri?: string | undefined;
}
export type CustomFileSystem = {
    EFSFileSystem: EFSFileSystem;
    FSxLustreFileSystem?: undefined;
    S3FileSystem?: undefined;
} | {
    EFSFileSystem?: undefined;
    FSxLustreFileSystem: FSxLustreFileSystem;
    S3FileSystem?: undefined;
} | {
    EFSFileSystem?: undefined;
    FSxLustreFileSystem?: undefined;
    S3FileSystem: S3FileSystem;
};
export type CustomFileSystems = CustomFileSystem[];
export interface SpaceSettings {
    JupyterServerAppSettings?: JupyterServerAppSettings | undefined;
    KernelGatewayAppSettings?: KernelGatewayAppSettings | undefined;
    CodeEditorAppSettings?: SpaceCodeEditorAppSettings | undefined;
    JupyterLabAppSettings?: SpaceJupyterLabAppSettings | undefined;
    AppType?: AppType | undefined;
    SpaceStorageSettings?: SpaceStorageSettings | undefined;
    SpaceManagedResources?: FeatureStatus | undefined;
    CustomFileSystems?: CustomFileSystem[] | undefined;
    RemoteAccess?: FeatureStatus | undefined;
}
export interface OwnershipSettings {
    OwnerUserProfileName?: string | undefined;
}
export type SharingType = "Private" | "Shared" | (string & {});
export interface SpaceSharingSettings {
    SharingType?: SharingType | undefined;
}
export interface CreateSpaceRequest {
    DomainId?: string | undefined;
    SpaceName?: string | undefined;
    Tags?: Tag[] | undefined;
    SpaceSettings?: SpaceSettings | undefined;
    OwnershipSettings?: OwnershipSettings | undefined;
    SpaceSharingSettings?: SpaceSharingSettings | undefined;
    SpaceDisplayName?: string | undefined;
}
export type SpaceArn = string;
export interface CreateSpaceResponse {
    SpaceArn?: string | undefined;
}
export type StudioLifecycleConfigName = string;
export type StudioLifecycleConfigContent = string;
export type StudioLifecycleConfigAppType = "JupyterServer" | "KernelGateway" | "CodeEditor" | "JupyterLab" | (string & {});
export interface CreateStudioLifecycleConfigRequest {
    StudioLifecycleConfigName?: string | undefined;
    StudioLifecycleConfigContent?: string | undefined;
    StudioLifecycleConfigAppType?: StudioLifecycleConfigAppType | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateStudioLifecycleConfigResponse {
    StudioLifecycleConfigArn?: string | undefined;
}
export type TrainingJobName = string;
export type TrainingContainerEntrypointString = string;
export type TrainingContainerEntrypoint = string[];
export type TrainingContainerArgument = string;
export type TrainingContainerArguments = string[];
export type TrainingRepositoryAccessMode = "Platform" | "Vpc" | (string & {});
export type TrainingRepositoryCredentialsProviderArn = string;
export interface TrainingRepositoryAuthConfig {
    TrainingRepositoryCredentialsProviderArn?: string | undefined;
}
export interface TrainingImageConfig {
    TrainingRepositoryAccessMode?: TrainingRepositoryAccessMode | undefined;
    TrainingRepositoryAuthConfig?: TrainingRepositoryAuthConfig | undefined;
}
export interface AlgorithmSpecification {
    TrainingImage?: string | undefined;
    AlgorithmName?: string | undefined;
    TrainingInputMode?: TrainingInputMode | undefined;
    MetricDefinitions?: MetricDefinition[] | undefined;
    EnableSageMakerMetricsTimeSeries?: boolean | undefined;
    ContainerEntrypoint?: string[] | undefined;
    ContainerArguments?: string[] | undefined;
    TrainingImageConfig?: TrainingImageConfig | undefined;
}
export type ConfigKey = string;
export type ConfigValue = string;
export type HookParameters = {
    [key: string]: string | undefined;
};
export type CollectionName = string;
export type CollectionParameters = {
    [key: string]: string | undefined;
};
export interface CollectionConfiguration {
    CollectionName?: string | undefined;
    CollectionParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CollectionConfigurations = CollectionConfiguration[];
export interface DebugHookConfig {
    LocalPath?: string | undefined;
    S3OutputPath?: string | undefined;
    HookParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    CollectionConfigurations?: CollectionConfiguration[] | undefined;
}
export type RuleConfigurationName = string;
export type RuleParameters = {
    [key: string]: string | undefined;
};
export interface DebugRuleConfiguration {
    RuleConfigurationName?: string | undefined;
    LocalPath?: string | undefined;
    S3OutputPath?: string | undefined;
    RuleEvaluatorImage?: string | undefined;
    InstanceType?: ProcessingInstanceType | undefined;
    VolumeSizeInGB?: number | undefined;
    RuleParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DebugRuleConfigurations = DebugRuleConfiguration[];
export interface TensorBoardOutputConfig {
    LocalPath?: string | undefined;
    S3OutputPath?: string | undefined;
}
export type ProfilingIntervalInMilliseconds = number;
export type ProfilingParameters = {
    [key: string]: string | undefined;
};
export type DisableProfiler = boolean;
export interface ProfilerConfig {
    S3OutputPath?: string | undefined;
    ProfilingIntervalInMilliseconds?: number | undefined;
    ProfilingParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    DisableProfiler?: boolean | undefined;
}
export interface ProfilerRuleConfiguration {
    RuleConfigurationName?: string | undefined;
    LocalPath?: string | undefined;
    S3OutputPath?: string | undefined;
    RuleEvaluatorImage?: string | undefined;
    InstanceType?: ProcessingInstanceType | undefined;
    VolumeSizeInGB?: number | undefined;
    RuleParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProfilerRuleConfigurations = ProfilerRuleConfiguration[];
export type TrainingEnvironmentKey = string;
export type TrainingEnvironmentValue = string;
export type TrainingEnvironmentMap = {
    [key: string]: string | undefined;
};
export type EnableRemoteDebug = boolean;
export interface RemoteDebugConfig {
    EnableRemoteDebug?: boolean | undefined;
}
export type EnableInfraCheck = boolean;
export interface InfraCheckConfig {
    EnableInfraCheck?: boolean | undefined;
}
export type EnableSessionTagChaining = boolean;
export interface SessionChainingConfig {
    EnableSessionTagChaining?: boolean | undefined;
}
export type ServerlessJobBaseModelArn = string;
export type ServerlessJobType = "FineTuning" | "Evaluation" | (string & {});
export type CustomizationTechnique = "SFT" | "DPO" | "RLVR" | "RLAIF" | (string & {});
export type Peft = "LORA" | (string & {});
export type EvaluationType = "LLMAJEvaluation" | "CustomScorerEvaluation" | "BenchmarkEvaluation" | (string & {});
export type EvaluatorArn = string;
export type SequenceLength = string;
export interface ServerlessJobConfig {
    BaseModelArn: string;
    AcceptEula?: boolean | undefined;
    JobType: ServerlessJobType;
    CustomizationTechnique?: CustomizationTechnique | undefined;
    Peft?: Peft | undefined;
    EvaluationType?: EvaluationType | undefined;
    EvaluatorArn?: string | undefined;
    SequenceLength?: string | undefined;
}
export type MlFlowResourceArn = string;
export type MlflowExperimentName = string;
export type MlflowRunName = string;
export interface MlflowConfig {
    MlflowResourceArn: string;
    MlflowExperimentName?: string | undefined;
    MlflowRunName?: string | undefined;
}
export interface ModelPackageConfig {
    ModelPackageGroupArn: string;
    SourceModelPackageArn?: string | undefined;
}
export interface CreateTrainingJobRequest {
    TrainingJobName?: string | undefined;
    HyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AlgorithmSpecification?: AlgorithmSpecification | undefined;
    RoleArn?: string | undefined;
    InputDataConfig?: Channel[] | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    ResourceConfig?: ResourceConfig | undefined;
    VpcConfig?: VpcConfig | undefined;
    StoppingCondition?: StoppingCondition | undefined;
    Tags?: Tag[] | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    EnableInterContainerTrafficEncryption?: boolean | undefined;
    EnableManagedSpotTraining?: boolean | undefined;
    CheckpointConfig?: CheckpointConfig | undefined;
    DebugHookConfig?: DebugHookConfig | undefined;
    DebugRuleConfigurations?: DebugRuleConfiguration[] | undefined;
    TensorBoardOutputConfig?: TensorBoardOutputConfig | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
    ProfilerConfig?: ProfilerConfig | undefined;
    ProfilerRuleConfigurations?: ProfilerRuleConfiguration[] | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    RetryStrategy?: RetryStrategy | undefined;
    RemoteDebugConfig?: RemoteDebugConfig | undefined;
    InfraCheckConfig?: InfraCheckConfig | undefined;
    SessionChainingConfig?: SessionChainingConfig | undefined;
    ServerlessJobConfig?: ServerlessJobConfig | undefined;
    MlflowConfig?: MlflowConfig | undefined;
    ModelPackageConfig?: ModelPackageConfig | undefined;
}
export type TrainingJobArn = string;
export interface CreateTrainingJobResponse {
    TrainingJobArn: string;
}
export type TrainingPlanName = string;
export type TrainingPlanOfferingId = string;
export type SpareInstanceCountPerUltraServer = number;
export interface CreateTrainingPlanRequest {
    TrainingPlanName?: string | undefined;
    TrainingPlanOfferingId?: string | undefined;
    SpareInstanceCountPerUltraServer?: number | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateTrainingPlanResponse {
    TrainingPlanArn: string;
}
export type TrainingSessionName = string;
export type Rank = number;
export type LoraAlpha = number;
export interface LoraConfig {
    Rank?: number | undefined;
    Alpha?: number | undefined;
}
export type BaseModelArn = string;
export type JavaBoolean = boolean;
export interface TrainingSessionModelConfig {
    BaseModelArn?: string | undefined;
    AcceptEula?: boolean | undefined;
}
export type OutputS3Path = string;
export type CustomerKmsKeyArn = string;
export interface TrainingSessionS3Location {
    Path?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export interface TrainingSessionOutputConfig {
    S3Location?: TrainingSessionS3Location | undefined;
}
export interface CreateTrainingSessionRequest {
    TrainingSessionName?: string | undefined;
    ModelPackageGroupArn?: string | undefined;
    LoraConfig?: LoraConfig | undefined;
    RoleArn?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    ModelConfig?: TrainingSessionModelConfig | undefined;
    OutputConfig?: TrainingSessionOutputConfig | undefined;
    Tags?: Tag[] | undefined;
}
export type TrainingSessionArn = string;
export interface CreateTrainingSessionResponse {
    TrainingSessionArn: string;
}
export type TransformJobName = string;
export type InvocationsTimeoutInSeconds = number;
export type InvocationsMaxRetries = number;
export interface ModelClientConfig {
    InvocationsTimeoutInSeconds?: number | undefined;
    InvocationsMaxRetries?: number | undefined;
}
export interface BatchDataCaptureConfig {
    DestinationS3Uri?: string | undefined;
    KmsKeyId?: string | undefined;
    GenerateInferenceId?: boolean | undefined;
}
export type JsonPath = string;
export type JoinSource = "Input" | "None" | (string & {});
export interface DataProcessing {
    InputFilter?: string | undefined;
    OutputFilter?: string | undefined;
    JoinSource?: JoinSource | undefined;
}
export interface CreateTransformJobRequest {
    TransformJobName?: string | undefined;
    ModelName?: string | undefined;
    MaxConcurrentTransforms?: number | undefined;
    ModelClientConfig?: ModelClientConfig | undefined;
    MaxPayloadInMB?: number | undefined;
    BatchStrategy?: BatchStrategy | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    TransformInput?: TransformInput | undefined;
    TransformOutput?: TransformOutput | undefined;
    DataCaptureConfig?: BatchDataCaptureConfig | undefined;
    TransformResources?: TransformResources | undefined;
    DataProcessing?: DataProcessing | undefined;
    Tags?: Tag[] | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
}
export type TransformJobArn = string;
export interface CreateTransformJobResponse {
    TransformJobArn: string;
}
export interface CreateTrialRequest {
    TrialName?: string | undefined;
    DisplayName?: string | undefined;
    ExperimentName?: string | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateTrialResponse {
    TrialArn?: string | undefined;
}
export type TrialComponentPrimaryStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export type TrialComponentStatusMessage = string;
export interface TrialComponentStatus {
    PrimaryStatus?: TrialComponentPrimaryStatus | undefined;
    Message?: string | undefined;
}
export type TrialComponentKey320 = string;
export type DoubleParameterValue = number;
export type TrialComponentParameterValue = {
    StringValue: string;
    NumberValue?: undefined;
} | {
    StringValue?: undefined;
    NumberValue: number;
};
export type TrialComponentParameters = {
    [key: string]: TrialComponentParameterValue | undefined;
};
export type TrialComponentKey128 = string;
export type MediaType = string;
export type TrialComponentArtifactValue = string;
export interface TrialComponentArtifact {
    MediaType?: string | undefined;
    Value?: string | undefined;
}
export type TrialComponentArtifacts = {
    [key: string]: TrialComponentArtifact | undefined;
};
export interface CreateTrialComponentRequest {
    TrialComponentName?: string | undefined;
    DisplayName?: string | undefined;
    Status?: TrialComponentStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Parameters?: {
        [key: string]: TrialComponentParameterValue | undefined;
    } | undefined;
    InputArtifacts?: {
        [key: string]: TrialComponentArtifact | undefined;
    } | undefined;
    OutputArtifacts?: {
        [key: string]: TrialComponentArtifact | undefined;
    } | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateTrialComponentResponse {
    TrialComponentArn?: string | undefined;
}
export type SingleSignOnUserIdentifier = string;
export interface CreateUserProfileRequest {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    SingleSignOnUserIdentifier?: string | undefined;
    SingleSignOnUserValue?: string | undefined;
    Tags?: Tag[] | undefined;
    UserSettings?: UserSettings | undefined;
}
export type UserProfileArn = string;
export interface CreateUserProfileResponse {
    UserProfileArn?: string | undefined;
}
export type CognitoUserPool = string;
export type ClientId = string;
export interface CognitoConfig {
    UserPool?: string | undefined;
    ClientId?: string | undefined;
}
export type ClientSecret = string | redacted.Redacted<string>;
export type OidcEndpoint = string;
export type Scope = string;
export type AuthenticationRequestExtraParamsKey = string;
export type AuthenticationRequestExtraParamsValue = string;
export type AuthenticationRequestExtraParams = {
    [key: string]: string | undefined;
};
export interface OidcConfig {
    ClientId?: string | undefined;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
    Issuer?: string | undefined;
    AuthorizationEndpoint?: string | undefined;
    TokenEndpoint?: string | undefined;
    UserInfoEndpoint?: string | undefined;
    LogoutEndpoint?: string | undefined;
    JwksUri?: string | undefined;
    Scope?: string | undefined;
    AuthenticationRequestExtraParams?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Cidr = string;
export type Cidrs = string[];
export interface SourceIpConfig {
    Cidrs?: string[] | undefined;
}
export type WorkforceName = string;
export type WorkforceVpcId = string;
export type WorkforceSecurityGroupId = string;
export type WorkforceSecurityGroupIds = string[];
export type WorkforceSubnetId = string;
export type WorkforceSubnets = string[];
export interface WorkforceVpcConfigRequest {
    VpcId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    Subnets?: string[] | undefined;
}
export type WorkforceIpAddressType = "ipv4" | "dualstack" | (string & {});
export interface CreateWorkforceRequest {
    CognitoConfig?: CognitoConfig | undefined;
    OidcConfig?: OidcConfig | undefined;
    SourceIpConfig?: SourceIpConfig | undefined;
    WorkforceName?: string | undefined;
    Tags?: Tag[] | undefined;
    WorkforceVpcConfig?: WorkforceVpcConfigRequest | undefined;
    IpAddressType?: WorkforceIpAddressType | undefined;
}
export type WorkforceArn = string;
export interface CreateWorkforceResponse {
    WorkforceArn: string;
}
export type WorkteamName = string;
export type CognitoUserGroup = string;
export interface CognitoMemberDefinition {
    UserPool?: string | undefined;
    UserGroup?: string | undefined;
    ClientId?: string | undefined;
}
export type Group = string;
export type Groups = string[];
export interface OidcMemberDefinition {
    Groups?: string[] | undefined;
}
export interface MemberDefinition {
    CognitoMemberDefinition?: CognitoMemberDefinition | undefined;
    OidcMemberDefinition?: OidcMemberDefinition | undefined;
}
export type MemberDefinitions = MemberDefinition[];
export type String200 = string;
export type NotificationTopicArn = string;
export interface NotificationConfiguration {
    NotificationTopicArn?: string | undefined;
}
export type EnabledOrDisabled = "Enabled" | "Disabled" | (string & {});
export interface IamPolicyConstraints {
    SourceIp?: EnabledOrDisabled | undefined;
    VpcSourceIp?: EnabledOrDisabled | undefined;
}
export interface S3Presign {
    IamPolicyConstraints?: IamPolicyConstraints | undefined;
}
export interface WorkerAccessConfiguration {
    S3Presign?: S3Presign | undefined;
}
export interface CreateWorkteamRequest {
    WorkteamName?: string | undefined;
    WorkforceName?: string | undefined;
    MemberDefinitions?: MemberDefinition[] | undefined;
    Description?: string | undefined;
    NotificationConfiguration?: NotificationConfiguration | undefined;
    WorkerAccessConfiguration?: WorkerAccessConfiguration | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateWorkteamResponse {
    WorkteamArn?: string | undefined;
}
export interface DeleteActionRequest {
    ActionName?: string | undefined;
}
export interface DeleteActionResponse {
    ActionArn?: string | undefined;
}
export interface DeleteAIBenchmarkJobRequest {
    AIBenchmarkJobName?: string | undefined;
}
export interface DeleteAIBenchmarkJobResponse {
    AIBenchmarkJobArn?: string | undefined;
}
export interface DeleteAIRecommendationJobRequest {
    AIRecommendationJobName?: string | undefined;
}
export interface DeleteAIRecommendationJobResponse {
    AIRecommendationJobArn?: string | undefined;
}
export interface DeleteAIWorkloadConfigRequest {
    AIWorkloadConfigName?: string | undefined;
}
export interface DeleteAIWorkloadConfigResponse {
    AIWorkloadConfigArn?: string | undefined;
}
export interface DeleteAlgorithmInput {
    AlgorithmName?: string | undefined;
}
export interface DeleteAlgorithmResponse {
}
export interface DeleteAppRequest {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    SpaceName?: string | undefined;
    AppType?: AppType | undefined;
    AppName?: string | undefined;
}
export interface DeleteAppResponse {
}
export interface DeleteAppImageConfigRequest {
    AppImageConfigName?: string | undefined;
}
export interface DeleteAppImageConfigResponse {
}
export interface DeleteArtifactRequest {
    ArtifactArn?: string | undefined;
    Source?: ArtifactSource | undefined;
}
export interface DeleteArtifactResponse {
    ArtifactArn?: string | undefined;
}
export interface DeleteAssociationRequest {
    SourceArn?: string | undefined;
    DestinationArn?: string | undefined;
}
export interface DeleteAssociationResponse {
    SourceArn?: string | undefined;
    DestinationArn?: string | undefined;
}
export interface DeleteClusterRequest {
    ClusterName?: string | undefined;
}
export interface DeleteClusterResponse {
    ClusterArn: string;
}
export interface DeleteClusterExtensionRequest {
    ClusterArn?: string | undefined;
    ExtensionArn?: string | undefined;
}
export interface DeleteClusterExtensionResponse {
    ExtensionArn: string;
}
export interface DeleteClusterSchedulerConfigRequest {
    ClusterSchedulerConfigId?: string | undefined;
}
export interface DeleteClusterSchedulerConfigResponse {
}
export interface DeleteCodeRepositoryInput {
    CodeRepositoryName?: string | undefined;
}
export interface DeleteCodeRepositoryResponse {
}
export interface DeleteCompilationJobRequest {
    CompilationJobName?: string | undefined;
}
export interface DeleteCompilationJobResponse {
}
export interface DeleteComputeQuotaRequest {
    ComputeQuotaId?: string | undefined;
}
export interface DeleteComputeQuotaResponse {
}
export interface DeleteContextRequest {
    ContextName?: string | undefined;
}
export interface DeleteContextResponse {
    ContextArn?: string | undefined;
}
export interface DeleteDataQualityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
}
export interface DeleteDataQualityJobDefinitionResponse {
}
export interface DeleteDeviceFleetRequest {
    DeviceFleetName?: string | undefined;
}
export interface DeleteDeviceFleetResponse {
}
export type RetentionType = "Retain" | "Delete" | (string & {});
export interface RetentionPolicy {
    HomeEfsFileSystem?: RetentionType | undefined;
}
export interface DeleteDomainRequest {
    DomainId?: string | undefined;
    RetentionPolicy?: RetentionPolicy | undefined;
}
export interface DeleteDomainResponse {
}
export interface DeleteEdgeDeploymentPlanRequest {
    EdgeDeploymentPlanName?: string | undefined;
}
export interface DeleteEdgeDeploymentPlanResponse {
}
export interface DeleteEdgeDeploymentStageRequest {
    EdgeDeploymentPlanName?: string | undefined;
    StageName?: string | undefined;
}
export interface DeleteEdgeDeploymentStageResponse {
}
export interface DeleteEndpointInput {
    EndpointName?: string | undefined;
}
export interface DeleteEndpointResponse {
}
export interface DeleteEndpointConfigInput {
    EndpointConfigName?: string | undefined;
}
export interface DeleteEndpointConfigResponse {
}
export interface DeleteExperimentRequest {
    ExperimentName?: string | undefined;
}
export interface DeleteExperimentResponse {
    ExperimentArn?: string | undefined;
}
export interface DeleteFeatureGroupRequest {
    FeatureGroupName?: string | undefined;
}
export interface DeleteFeatureGroupResponse {
}
export interface DeleteFlowDefinitionRequest {
    FlowDefinitionName?: string | undefined;
}
export interface DeleteFlowDefinitionResponse {
}
export interface DeleteHubRequest {
    HubName?: string | undefined;
}
export interface DeleteHubResponse {
}
export interface DeleteHubContentRequest {
    HubName?: string | undefined;
    HubContentType?: HubContentType | undefined;
    HubContentName?: string | undefined;
    HubContentVersion?: string | undefined;
}
export interface DeleteHubContentResponse {
}
export interface DeleteHubContentReferenceRequest {
    HubName?: string | undefined;
    HubContentType?: HubContentType | undefined;
    HubContentName?: string | undefined;
}
export interface DeleteHubContentReferenceResponse {
}
export interface DeleteHumanTaskUiRequest {
    HumanTaskUiName?: string | undefined;
}
export interface DeleteHumanTaskUiResponse {
}
export interface DeleteHyperParameterTuningJobRequest {
    HyperParameterTuningJobName?: string | undefined;
}
export interface DeleteHyperParameterTuningJobResponse {
}
export interface DeleteImageRequest {
    ImageName?: string | undefined;
}
export interface DeleteImageResponse {
}
export interface DeleteImageVersionRequest {
    ImageName?: string | undefined;
    Version?: number | undefined;
    Alias?: string | undefined;
}
export interface DeleteImageVersionResponse {
}
export interface DeleteInferenceComponentInput {
    InferenceComponentName?: string | undefined;
}
export interface DeleteInferenceComponentResponse {
}
export interface DeleteInferenceExperimentRequest {
    Name?: string | undefined;
}
export interface DeleteInferenceExperimentResponse {
    InferenceExperimentArn: string;
}
export interface DeleteJobRequest {
    JobName?: string | undefined;
    JobCategory?: JobCategory | undefined;
}
export interface DeleteJobResponse {
}
export interface DeleteMlflowAppRequest {
    Arn?: string | undefined;
}
export interface DeleteMlflowAppResponse {
    Arn?: string | undefined;
}
export interface DeleteMlflowTrackingServerRequest {
    TrackingServerName?: string | undefined;
}
export interface DeleteMlflowTrackingServerResponse {
    TrackingServerArn?: string | undefined;
}
export interface DeleteModelInput {
    ModelName?: string | undefined;
}
export interface DeleteModelResponse {
}
export interface DeleteModelBiasJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
}
export interface DeleteModelBiasJobDefinitionResponse {
}
export interface DeleteModelCardRequest {
    ModelCardName?: string | undefined;
}
export interface DeleteModelCardResponse {
}
export interface DeleteModelExplainabilityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
}
export interface DeleteModelExplainabilityJobDefinitionResponse {
}
export interface DeleteModelPackageInput {
    ModelPackageName?: string | undefined;
}
export interface DeleteModelPackageResponse {
}
export interface DeleteModelPackageGroupInput {
    ModelPackageGroupName?: string | undefined;
}
export interface DeleteModelPackageGroupResponse {
}
export interface DeleteModelPackageGroupPolicyInput {
    ModelPackageGroupName?: string | undefined;
}
export interface DeleteModelPackageGroupPolicyResponse {
}
export interface DeleteModelQualityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
}
export interface DeleteModelQualityJobDefinitionResponse {
}
export interface DeleteMonitoringScheduleRequest {
    MonitoringScheduleName?: string | undefined;
}
export interface DeleteMonitoringScheduleResponse {
}
export interface DeleteNotebookInstanceInput {
    NotebookInstanceName?: string | undefined;
}
export interface DeleteNotebookInstanceResponse {
}
export interface DeleteNotebookInstanceLifecycleConfigInput {
    NotebookInstanceLifecycleConfigName?: string | undefined;
}
export interface DeleteNotebookInstanceLifecycleConfigResponse {
}
export interface DeleteOptimizationJobRequest {
    OptimizationJobName?: string | undefined;
}
export interface DeleteOptimizationJobResponse {
}
export interface DeletePartnerAppRequest {
    Arn?: string | undefined;
    ClientToken?: string | undefined;
}
export interface DeletePartnerAppResponse {
    Arn?: string | undefined;
}
export interface DeletePipelineRequest {
    PipelineName?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface DeletePipelineResponse {
    PipelineArn?: string | undefined;
}
export interface DeleteProcessingJobRequest {
    ProcessingJobName?: string | undefined;
}
export interface DeleteProcessingJobResponse {
}
export interface DeleteProjectInput {
    ProjectName?: string | undefined;
}
export interface DeleteProjectResponse {
}
export interface DeleteSpaceRequest {
    DomainId?: string | undefined;
    SpaceName?: string | undefined;
}
export interface DeleteSpaceResponse {
}
export interface DeleteStudioLifecycleConfigRequest {
    StudioLifecycleConfigName?: string | undefined;
}
export interface DeleteStudioLifecycleConfigResponse {
}
export type TagKeyList = string[];
export interface DeleteTagsInput {
    ResourceArn?: string | undefined;
    TagKeys?: string[] | undefined;
}
export interface DeleteTagsOutput {
}
export interface DeleteTrainingJobRequest {
    TrainingJobName?: string | undefined;
}
export interface DeleteTrainingJobResponse {
}
export interface DeleteTrainingSessionRequest {
    TrainingSessionName?: string | undefined;
}
export interface DeleteTrainingSessionResponse {
}
export interface DeleteTrialRequest {
    TrialName?: string | undefined;
}
export interface DeleteTrialResponse {
    TrialArn?: string | undefined;
}
export interface DeleteTrialComponentRequest {
    TrialComponentName?: string | undefined;
}
export interface DeleteTrialComponentResponse {
    TrialComponentArn?: string | undefined;
}
export interface DeleteUserProfileRequest {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
}
export interface DeleteUserProfileResponse {
}
export interface DeleteWorkforceRequest {
    WorkforceName?: string | undefined;
}
export interface DeleteWorkforceResponse {
}
export interface DeleteWorkteamRequest {
    WorkteamName?: string | undefined;
}
export type Success = boolean;
export interface DeleteWorkteamResponse {
    Success: boolean;
}
export interface DeregisterDevicesRequest {
    DeviceFleetName?: string | undefined;
    DeviceNames?: string[] | undefined;
}
export interface DeregisterDevicesResponse {
}
export type ExperimentEntityNameOrArn = string;
export interface DescribeActionRequest {
    ActionName?: string | undefined;
}
export interface IamIdentity {
    Arn?: string | undefined;
    PrincipalId?: string | undefined;
    SourceIdentity?: string | undefined;
}
export interface UserContext {
    UserProfileArn?: string | undefined;
    UserProfileName?: string | undefined;
    DomainId?: string | undefined;
    IamIdentity?: IamIdentity | undefined;
}
export type LineageGroupArn = string;
export interface DescribeActionResponse {
    ActionName?: string | undefined;
    ActionArn?: string | undefined;
    Source?: (ActionSource & {
        SourceUri: SourceUri;
    }) | undefined;
    ActionType?: string | undefined;
    Description?: string | undefined;
    Status?: ActionStatus | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    LineageGroupArn?: string | undefined;
}
export interface DescribeAIBenchmarkJobRequest {
    AIBenchmarkJobName?: string | undefined;
}
export type AIBenchmarkJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export type FailureReason = string;
export interface AICloudWatchLogs {
    LogGroupArn?: string | undefined;
    LogStreamName?: string | undefined;
}
export type AICloudWatchLogsList = AICloudWatchLogs[];
export interface AIBenchmarkOutputResult {
    S3OutputLocation?: string | undefined;
    CloudWatchLogs?: AICloudWatchLogs[] | undefined;
    MlflowConfig?: AIMlflowConfig | undefined;
}
export interface DescribeAIBenchmarkJobResponse {
    AIBenchmarkJobName: string;
    AIBenchmarkJobArn: string;
    AIBenchmarkJobStatus: AIBenchmarkJobStatus;
    FailureReason?: string | undefined;
    BenchmarkTarget: AIBenchmarkTarget;
    OutputConfig: AIBenchmarkOutputResult & {
        S3OutputLocation: S3Uri;
        MlflowConfig: AIMlflowConfig & {
            MlflowResourceArn: AIMlflowResourceArn;
        };
    };
    AIWorkloadConfigIdentifier: string;
    RoleArn: string;
    NetworkConfig?: (AIBenchmarkNetworkConfig & {
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
    }) | undefined;
    CreationTime: Date;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
}
export interface DescribeAIRecommendationJobRequest {
    AIRecommendationJobName?: string | undefined;
}
export type AIRecommendationJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export interface AIRecommendationOutputResult {
    S3OutputLocation?: string | undefined;
    ModelPackageGroupIdentifier?: string | undefined;
    MlflowConfig?: AIMlflowConfig | undefined;
}
export type AIRecommendationOptimizationType = "SpeculativeDecoding" | "KernelTuning" | (string & {});
export type AIRecommendationOptimizationConfigMap = {
    [key: string]: string | undefined;
};
export interface AIRecommendationOptimizationDetail {
    OptimizationType?: AIRecommendationOptimizationType | undefined;
    OptimizationConfig?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AIRecommendationOptimizationDetailList = AIRecommendationOptimizationDetail[];
export type AIInferenceSpecificationName = string;
export type AIRecommendationInstanceCount = number;
export type AIRecommendationCopyCountPerInstance = number;
export interface AIRecommendationInstanceDetail {
    InstanceType?: AIRecommendationInstanceType | undefined;
    InstanceCount?: number | undefined;
    CopyCountPerInstance?: number | undefined;
}
export type AIRecommendationInstanceDetailList = AIRecommendationInstanceDetail[];
export interface AIRecommendationModelDetails {
    ModelPackageArn?: string | undefined;
    InferenceSpecificationName?: string | undefined;
    InstanceDetails?: AIRecommendationInstanceDetail[] | undefined;
}
export interface AIRecommendationDeploymentS3Channel {
    ChannelName?: string | undefined;
    Uri?: string | undefined;
}
export type AIRecommendationDeploymentS3ChannelList = AIRecommendationDeploymentS3Channel[];
export type AIRecommendationMinCpuMemoryRequiredInMb = number;
export interface AIRecommendationDeploymentConfiguration {
    S3?: AIRecommendationDeploymentS3Channel[] | undefined;
    ImageUri?: string | undefined;
    InstanceType?: AIRecommendationInstanceType | undefined;
    InstanceCount?: number | undefined;
    CopyCountPerInstance?: number | undefined;
    EnvironmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    MinCpuMemoryRequiredInMb?: number | undefined;
}
export interface AIRecommendationPerformanceMetric {
    Metric?: string | undefined;
    Stat?: string | undefined;
    Value?: string | undefined;
    Unit?: string | undefined;
}
export type ExpectedPerformanceList = AIRecommendationPerformanceMetric[];
export interface AIRecommendationAdapterDetails {
    ModelPackageArns?: AIAdapterModelPackageEntry[] | undefined;
    S3Uris?: AIAdapterS3Entry[] | undefined;
}
export interface AIRecommendation {
    RecommendationDescription?: string | undefined;
    OptimizationDetails?: AIRecommendationOptimizationDetail[] | undefined;
    ModelDetails?: AIRecommendationModelDetails | undefined;
    DeploymentConfiguration?: AIRecommendationDeploymentConfiguration | undefined;
    AIBenchmarkJobArn?: string | undefined;
    ExpectedPerformance?: AIRecommendationPerformanceMetric[] | undefined;
    AdapterDetails?: AIRecommendationAdapterDetails | undefined;
}
export type AIRecommendationList = AIRecommendation[];
export interface DescribeAIRecommendationJobResponse {
    AIRecommendationJobName: string;
    AIRecommendationJobArn: string;
    AIRecommendationJobStatus: AIRecommendationJobStatus;
    FailureReason?: string | undefined;
    ModelSource: AIModelSource;
    OutputConfig: AIRecommendationOutputResult & {
        S3OutputLocation: S3Uri;
        MlflowConfig: AIMlflowConfig & {
            MlflowResourceArn: AIMlflowResourceArn;
        };
    };
    InferenceSpecification?: AIRecommendationInferenceSpecification | undefined;
    AIWorkloadConfigIdentifier: string;
    OptimizeModel?: boolean | undefined;
    PerformanceTarget?: (AIRecommendationPerformanceTarget & {
        Constraints: (AIRecommendationConstraint & {
            Metric: AIRecommendationMetric;
        })[];
    }) | undefined;
    Recommendations?: (AIRecommendation & {
        OptimizationDetails: (AIRecommendationOptimizationDetail & {
            OptimizationType: AIRecommendationOptimizationType;
        })[];
        ExpectedPerformance: (AIRecommendationPerformanceMetric & {
            Metric: string;
            Value: string;
        })[];
        AdapterDetails: AIRecommendationAdapterDetails & {
            ModelPackageArns: (AIAdapterModelPackageEntry & {
                AdapterId: AIAdapterId;
                ModelPackageArn: ModelPackageArn;
            })[];
            S3Uris: (AIAdapterS3Entry & {
                AdapterId: AIAdapterId;
                S3Uri: S3Uri;
            })[];
        };
    })[] | undefined;
    RoleArn: string;
    ComputeSpec?: AIRecommendationComputeSpec | undefined;
    AdapterSource?: AIAdapterSource | undefined;
    CreationTime: Date;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
}
export interface DescribeAIWorkloadConfigRequest {
    AIWorkloadConfigName?: string | undefined;
}
export interface DescribeAIWorkloadConfigResponse {
    AIWorkloadConfigName: string;
    AIWorkloadConfigArn: string;
    DatasetConfig?: AIDatasetConfig | undefined;
    AIWorkloadConfigs?: (AIWorkloadConfigs & {
        WorkloadSpec: WorkloadSpec;
    }) | undefined;
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
    CreationTime: Date;
}
export interface DescribeAlgorithmInput {
    AlgorithmName?: string | undefined;
}
export type AlgorithmStatus = "Pending" | "InProgress" | "Completed" | "Failed" | "Deleting" | (string & {});
export type DetailedAlgorithmStatus = "NotStarted" | "InProgress" | "Completed" | "Failed" | (string & {});
export interface AlgorithmStatusItem {
    Name?: string | undefined;
    Status?: DetailedAlgorithmStatus | undefined;
    FailureReason?: string | undefined;
}
export type AlgorithmStatusItemList = AlgorithmStatusItem[];
export interface AlgorithmStatusDetails {
    ValidationStatuses?: AlgorithmStatusItem[] | undefined;
    ImageScanStatuses?: AlgorithmStatusItem[] | undefined;
}
export interface DescribeAlgorithmOutput {
    AlgorithmName: string;
    AlgorithmArn: string;
    AlgorithmDescription?: string | undefined;
    CreationTime: Date;
    TrainingSpecification: TrainingSpecification & {
        TrainingImage: ContainerImage;
        SupportedTrainingInstanceTypes: TrainingInstanceTypes;
        TrainingChannels: (ChannelSpecification & {
            Name: ChannelName;
            SupportedContentTypes: ContentTypes;
            SupportedInputModes: InputModes;
        })[];
        SupportedHyperParameters: (HyperParameterSpecification & {
            Name: ParameterName;
            Type: ParameterType;
            Range: ParameterRange & {
                IntegerParameterRangeSpecification: IntegerParameterRangeSpecification & {
                    MinValue: ParameterValue;
                    MaxValue: ParameterValue;
                };
                ContinuousParameterRangeSpecification: ContinuousParameterRangeSpecification & {
                    MinValue: ParameterValue;
                    MaxValue: ParameterValue;
                };
                CategoricalParameterRangeSpecification: CategoricalParameterRangeSpecification & {
                    Values: ParameterValues;
                };
            };
        })[];
        MetricDefinitions: (MetricDefinition & {
            Name: MetricName;
            Regex: MetricRegex;
        })[];
        SupportedTuningJobObjectiveMetrics: (HyperParameterTuningJobObjective & {
            Type: HyperParameterTuningJobObjectiveType;
            MetricName: MetricName;
        })[];
        AdditionalS3DataSource: AdditionalS3DataSource & {
            S3DataType: AdditionalS3DataSourceDataType;
            S3Uri: S3Uri;
        };
    };
    InferenceSpecification?: (InferenceSpecification & {
        Containers: (ModelPackageContainerDefinition & {
            ModelDataSource: ModelDataSource & {
                S3DataSource: S3ModelDataSource & {
                    S3Uri: S3ModelUri;
                    S3DataType: S3ModelDataType;
                    CompressionType: ModelCompressionType;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: InferenceHubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
            };
            ModelInput: ModelInput & {
                DataInputConfig: DataInputConfig;
            };
            AdditionalModelDataSources: (AdditionalModelDataSource & {
                ChannelName: AdditionalModelChannelName;
                S3DataSource: S3ModelDataSource & {
                    S3Uri: S3ModelUri;
                    S3DataType: S3ModelDataType;
                    CompressionType: ModelCompressionType;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: InferenceHubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
            })[];
            AdditionalS3DataSource: AdditionalS3DataSource & {
                S3DataType: AdditionalS3DataSourceDataType;
                S3Uri: S3Uri;
            };
        })[];
    }) | undefined;
    ValidationSpecification?: (AlgorithmValidationSpecification & {
        ValidationRole: RoleArn;
        ValidationProfiles: (AlgorithmValidationProfile & {
            ProfileName: EntityName;
            TrainingJobDefinition: TrainingJobDefinition & {
                TrainingInputMode: TrainingInputMode;
                InputDataConfig: (Channel & {
                    ChannelName: ChannelName;
                    DataSource: DataSource & {
                        S3DataSource: S3DataSource & {
                            S3DataType: S3DataType;
                            S3Uri: S3Uri;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: HubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                        FileSystemDataSource: FileSystemDataSource & {
                            FileSystemId: FileSystemId;
                            FileSystemAccessMode: FileSystemAccessMode;
                            FileSystemType: FileSystemType;
                            DirectoryPath: DirectoryPath;
                        };
                    };
                    ShuffleConfig: ShuffleConfig & {
                        Seed: Seed;
                    };
                })[];
                OutputDataConfig: OutputDataConfig & {
                    S3OutputPath: S3Uri;
                };
                ResourceConfig: ResourceConfig & {
                    InstanceGroups: (InstanceGroup & {
                        InstanceType: TrainingInstanceType;
                        InstanceCount: TrainingInstanceCount;
                        InstanceGroupName: InstanceGroupName;
                    })[];
                    InstancePlacementConfig: InstancePlacementConfig & {
                        PlacementSpecifications: (PlacementSpecification & {
                            InstanceCount: TrainingInstanceCount;
                        })[];
                    };
                    InstancePreferences: (InstancePreference & {
                        InstanceType: TrainingInstanceType;
                    })[];
                };
                StoppingCondition: StoppingCondition;
            };
            TransformJobDefinition: TransformJobDefinition & {
                TransformInput: TransformInput & {
                    DataSource: TransformDataSource & {
                        S3DataSource: TransformS3DataSource & {
                            S3DataType: S3DataType;
                            S3Uri: S3Uri;
                        };
                    };
                };
                TransformOutput: TransformOutput & {
                    S3OutputPath: S3Uri;
                };
                TransformResources: TransformResources & {
                    InstanceType: TransformInstanceType;
                    InstanceCount: TransformInstanceCount;
                };
            };
        })[];
    }) | undefined;
    AlgorithmStatus: AlgorithmStatus;
    AlgorithmStatusDetails: AlgorithmStatusDetails & {
        ValidationStatuses: (AlgorithmStatusItem & {
            Name: EntityName;
            Status: DetailedAlgorithmStatus;
        })[];
        ImageScanStatuses: (AlgorithmStatusItem & {
            Name: EntityName;
            Status: DetailedAlgorithmStatus;
        })[];
    };
    ProductId?: string | undefined;
    CertifyForMarketplace?: boolean | undefined;
}
export interface DescribeAppRequest {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    SpaceName?: string | undefined;
    AppType?: AppType | undefined;
    AppName?: string | undefined;
}
export type AppStatus = "Deleted" | "Deleting" | "Failed" | "InService" | "Pending" | (string & {});
export interface DescribeAppResponse {
    AppArn?: string | undefined;
    AppType?: AppType | undefined;
    AppName?: string | undefined;
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    SpaceName?: string | undefined;
    Status?: AppStatus | undefined;
    EffectiveTrustedIdentityPropagationStatus?: FeatureStatus | undefined;
    RecoveryMode?: boolean | undefined;
    LastHealthCheckTimestamp?: Date | undefined;
    LastUserActivityTimestamp?: Date | undefined;
    CreationTime?: Date | undefined;
    FailureReason?: string | undefined;
    ResourceSpec?: ResourceSpec | undefined;
    BuiltInLifecycleConfigArn?: string | undefined;
}
export interface DescribeAppImageConfigRequest {
    AppImageConfigName?: string | undefined;
}
export interface DescribeAppImageConfigResponse {
    AppImageConfigArn?: string | undefined;
    AppImageConfigName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    KernelGatewayImageConfig?: (KernelGatewayImageConfig & {
        KernelSpecs: (KernelSpec & {
            Name: KernelName;
        })[];
    }) | undefined;
    JupyterLabAppImageConfig?: JupyterLabAppImageConfig | undefined;
    CodeEditorAppImageConfig?: CodeEditorAppImageConfig | undefined;
}
export interface DescribeArtifactRequest {
    ArtifactArn?: string | undefined;
}
export interface DescribeArtifactResponse {
    ArtifactName?: string | undefined;
    ArtifactArn?: string | undefined;
    Source?: (ArtifactSource & {
        SourceUri: SourceUri;
        SourceTypes: (ArtifactSourceType & {
            SourceIdType: ArtifactSourceIdType;
            Value: String256;
        })[];
    }) | undefined;
    ArtifactType?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    LineageGroupArn?: string | undefined;
}
export interface DescribeAutoMLJobRequest {
    AutoMLJobName?: string | undefined;
}
export type AutoMLFailureReason = string;
export interface AutoMLPartialFailureReason {
    PartialFailureMessage?: string | undefined;
}
export type AutoMLPartialFailureReasons = AutoMLPartialFailureReason[];
export type CandidateName = string;
export type AutoMLJobObjectiveType = "Maximize" | "Minimize" | (string & {});
export type MetricValue = number;
export interface FinalAutoMLJobObjectiveMetric {
    Type?: AutoMLJobObjectiveType | undefined;
    MetricName?: AutoMLMetricEnum | undefined;
    Value?: number | undefined;
    StandardMetricName?: AutoMLMetricEnum | undefined;
}
export type ObjectiveStatus = "Succeeded" | "Pending" | "Failed" | (string & {});
export type CandidateStepType = "AWS::SageMaker::TrainingJob" | "AWS::SageMaker::TransformJob" | "AWS::SageMaker::ProcessingJob" | (string & {});
export type CandidateStepArn = string;
export type CandidateStepName = string;
export interface AutoMLCandidateStep {
    CandidateStepType?: CandidateStepType | undefined;
    CandidateStepArn?: string | undefined;
    CandidateStepName?: string | undefined;
}
export type CandidateSteps = AutoMLCandidateStep[];
export type CandidateStatus = "Completed" | "InProgress" | "Failed" | "Stopped" | "Stopping" | (string & {});
export interface AutoMLContainerDefinition {
    Image?: string | undefined;
    ModelDataUrl?: string | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AutoMLContainerDefinitions = AutoMLContainerDefinition[];
export type ExplainabilityLocation = string;
export type ModelInsightsLocation = string;
export type BacktestResultsLocation = string;
export interface CandidateArtifactLocations {
    Explainability?: string | undefined;
    ModelInsights?: string | undefined;
    BacktestResults?: string | undefined;
}
export type AutoMLMetricExtendedEnum = "Accuracy" | "MSE" | "F1" | "F1macro" | "AUC" | "RMSE" | "MAE" | "R2" | "BalancedAccuracy" | "Precision" | "PrecisionMacro" | "Recall" | "RecallMacro" | "LogLoss" | "InferenceLatency" | "MAPE" | "MASE" | "WAPE" | "AverageWeightedQuantileLoss" | "Rouge1" | "Rouge2" | "RougeL" | "RougeLSum" | "Perplexity" | "ValidationLoss" | "TrainingLoss" | (string & {});
export type MetricSetSource = "Train" | "Validation" | "Test" | (string & {});
export interface MetricDatum {
    MetricName?: AutoMLMetricEnum | undefined;
    StandardMetricName?: AutoMLMetricExtendedEnum | undefined;
    Value?: number | undefined;
    Set?: MetricSetSource | undefined;
}
export type MetricDataList = MetricDatum[];
export interface CandidateProperties {
    CandidateArtifactLocations?: CandidateArtifactLocations | undefined;
    CandidateMetrics?: MetricDatum[] | undefined;
}
export type AutoMLProcessingUnit = "CPU" | "GPU" | (string & {});
export type AutoMLInferenceContainerDefinitions = {
    [key in AutoMLProcessingUnit]?: AutoMLContainerDefinition[] | undefined;
};
export interface AutoMLCandidate {
    CandidateName?: string | undefined;
    FinalAutoMLJobObjectiveMetric?: FinalAutoMLJobObjectiveMetric | undefined;
    ObjectiveStatus?: ObjectiveStatus | undefined;
    CandidateSteps?: AutoMLCandidateStep[] | undefined;
    CandidateStatus?: CandidateStatus | undefined;
    InferenceContainers?: AutoMLContainerDefinition[] | undefined;
    CreationTime?: Date | undefined;
    EndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    FailureReason?: string | undefined;
    CandidateProperties?: CandidateProperties | undefined;
    InferenceContainerDefinitions?: {
        [key: string]: AutoMLContainerDefinition[] | undefined;
    } | undefined;
}
export type AutoMLJobStatus = "Completed" | "InProgress" | "Failed" | "Stopped" | "Stopping" | (string & {});
export type AutoMLJobSecondaryStatus = "Starting" | "MaxCandidatesReached" | "Failed" | "Stopped" | "MaxAutoMLJobRuntimeReached" | "Stopping" | "CandidateDefinitionsGenerated" | "Completed" | "ExplainabilityError" | "DeployingModel" | "ModelDeploymentError" | "GeneratingModelInsightsReport" | "ModelInsightsError" | "AnalyzingData" | "FeatureEngineering" | "ModelTuning" | "GeneratingExplainabilityReport" | "TrainingModels" | "PreTraining" | (string & {});
export type CandidateDefinitionNotebookLocation = string;
export type DataExplorationNotebookLocation = string;
export interface AutoMLJobArtifacts {
    CandidateDefinitionNotebookLocation?: string | undefined;
    DataExplorationNotebookLocation?: string | undefined;
}
export interface ResolvedAttributes {
    AutoMLJobObjective?: AutoMLJobObjective | undefined;
    ProblemType?: ProblemType | undefined;
    CompletionCriteria?: AutoMLJobCompletionCriteria | undefined;
}
export interface ModelDeployResult {
    EndpointName?: string | undefined;
}
export interface DescribeAutoMLJobResponse {
    AutoMLJobName: string;
    AutoMLJobArn: string;
    InputDataConfig: (AutoMLChannel & {
        TargetAttributeName: TargetAttributeName;
        DataSource: AutoMLDataSource & {
            S3DataSource: AutoMLS3DataSource & {
                S3DataType: AutoMLS3DataType;
                S3Uri: S3Uri;
            };
        };
    })[];
    OutputDataConfig: AutoMLOutputDataConfig & {
        S3OutputPath: S3Uri;
    };
    RoleArn: string;
    AutoMLJobObjective?: (AutoMLJobObjective & {
        MetricName: AutoMLMetricEnum;
    }) | undefined;
    ProblemType?: ProblemType | undefined;
    AutoMLJobConfig?: (AutoMLJobConfig & {
        SecurityConfig: AutoMLSecurityConfig & {
            VpcConfig: VpcConfig & {
                SecurityGroupIds: VpcSecurityGroupIds;
                Subnets: Subnets;
            };
        };
        CandidateGenerationConfig: AutoMLCandidateGenerationConfig & {
            AlgorithmsConfig: (AutoMLAlgorithmConfig & {
                AutoMLAlgorithms: AutoMLAlgorithms;
            })[];
        };
    }) | undefined;
    CreationTime: Date;
    EndTime?: Date | undefined;
    LastModifiedTime: Date;
    FailureReason?: string | undefined;
    PartialFailureReasons?: AutoMLPartialFailureReason[] | undefined;
    BestCandidate?: (AutoMLCandidate & {
        CandidateName: CandidateName;
        ObjectiveStatus: ObjectiveStatus;
        CandidateSteps: (AutoMLCandidateStep & {
            CandidateStepType: CandidateStepType;
            CandidateStepArn: CandidateStepArn;
            CandidateStepName: CandidateStepName;
        })[];
        CandidateStatus: CandidateStatus;
        CreationTime: Date;
        LastModifiedTime: Date;
        FinalAutoMLJobObjectiveMetric: FinalAutoMLJobObjectiveMetric & {
            MetricName: AutoMLMetricEnum;
            Value: MetricValue;
        };
        InferenceContainers: (AutoMLContainerDefinition & {
            Image: ContainerImage;
            ModelDataUrl: Url;
        })[];
        CandidateProperties: CandidateProperties & {
            CandidateArtifactLocations: CandidateArtifactLocations & {
                Explainability: ExplainabilityLocation;
            };
        };
        InferenceContainerDefinitions: {
            [key: string]: (AutoMLContainerDefinition & {
                Image: ContainerImage;
                ModelDataUrl: Url;
            })[] | undefined;
        };
    }) | undefined;
    AutoMLJobStatus: AutoMLJobStatus;
    AutoMLJobSecondaryStatus: AutoMLJobSecondaryStatus;
    GenerateCandidateDefinitionsOnly?: boolean | undefined;
    AutoMLJobArtifacts?: AutoMLJobArtifacts | undefined;
    ResolvedAttributes?: (ResolvedAttributes & {
        AutoMLJobObjective: AutoMLJobObjective & {
            MetricName: AutoMLMetricEnum;
        };
    }) | undefined;
    ModelDeployConfig?: ModelDeployConfig | undefined;
    ModelDeployResult?: ModelDeployResult | undefined;
}
export interface DescribeAutoMLJobV2Request {
    AutoMLJobName?: string | undefined;
}
export type AutoMLProblemTypeConfigName = "ImageClassification" | "TextClassification" | "TimeSeriesForecasting" | "Tabular" | "TextGeneration" | (string & {});
export interface TabularResolvedAttributes {
    ProblemType?: ProblemType | undefined;
}
export interface TextGenerationResolvedAttributes {
    BaseModelName?: string | undefined;
}
export type AutoMLProblemTypeResolvedAttributes = {
    TabularResolvedAttributes: TabularResolvedAttributes;
    TextGenerationResolvedAttributes?: undefined;
} | {
    TabularResolvedAttributes?: undefined;
    TextGenerationResolvedAttributes: TextGenerationResolvedAttributes;
};
export interface AutoMLResolvedAttributes {
    AutoMLJobObjective?: AutoMLJobObjective | undefined;
    CompletionCriteria?: AutoMLJobCompletionCriteria | undefined;
    AutoMLProblemTypeResolvedAttributes?: AutoMLProblemTypeResolvedAttributes | undefined;
}
export interface DescribeAutoMLJobV2Response {
    AutoMLJobName: string;
    AutoMLJobArn: string;
    AutoMLJobInputDataConfig: (AutoMLJobChannel & {
        DataSource: AutoMLDataSource & {
            S3DataSource: AutoMLS3DataSource & {
                S3DataType: AutoMLS3DataType;
                S3Uri: S3Uri;
            };
        };
    })[];
    OutputDataConfig: AutoMLOutputDataConfig & {
        S3OutputPath: S3Uri;
    };
    RoleArn: string;
    AutoMLJobObjective?: (AutoMLJobObjective & {
        MetricName: AutoMLMetricEnum;
    }) | undefined;
    AutoMLProblemTypeConfig?: AutoMLProblemTypeConfig | undefined;
    AutoMLProblemTypeConfigName?: AutoMLProblemTypeConfigName | undefined;
    CreationTime: Date;
    EndTime?: Date | undefined;
    LastModifiedTime: Date;
    FailureReason?: string | undefined;
    PartialFailureReasons?: AutoMLPartialFailureReason[] | undefined;
    BestCandidate?: (AutoMLCandidate & {
        CandidateName: CandidateName;
        ObjectiveStatus: ObjectiveStatus;
        CandidateSteps: (AutoMLCandidateStep & {
            CandidateStepType: CandidateStepType;
            CandidateStepArn: CandidateStepArn;
            CandidateStepName: CandidateStepName;
        })[];
        CandidateStatus: CandidateStatus;
        CreationTime: Date;
        LastModifiedTime: Date;
        FinalAutoMLJobObjectiveMetric: FinalAutoMLJobObjectiveMetric & {
            MetricName: AutoMLMetricEnum;
            Value: MetricValue;
        };
        InferenceContainers: (AutoMLContainerDefinition & {
            Image: ContainerImage;
            ModelDataUrl: Url;
        })[];
        CandidateProperties: CandidateProperties & {
            CandidateArtifactLocations: CandidateArtifactLocations & {
                Explainability: ExplainabilityLocation;
            };
        };
        InferenceContainerDefinitions: {
            [key: string]: (AutoMLContainerDefinition & {
                Image: ContainerImage;
                ModelDataUrl: Url;
            })[] | undefined;
        };
    }) | undefined;
    AutoMLJobStatus: AutoMLJobStatus;
    AutoMLJobSecondaryStatus: AutoMLJobSecondaryStatus;
    AutoMLJobArtifacts?: AutoMLJobArtifacts | undefined;
    ResolvedAttributes?: (AutoMLResolvedAttributes & {
        AutoMLJobObjective: AutoMLJobObjective & {
            MetricName: AutoMLMetricEnum;
        };
    }) | undefined;
    ModelDeployConfig?: ModelDeployConfig | undefined;
    ModelDeployResult?: ModelDeployResult | undefined;
    DataSplitConfig?: AutoMLDataSplitConfig | undefined;
    SecurityConfig?: (AutoMLSecurityConfig & {
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
    }) | undefined;
    AutoMLComputeConfig?: (AutoMLComputeConfig & {
        EmrServerlessComputeConfig: EmrServerlessComputeConfig & {
            ExecutionRoleARN: RoleArn;
        };
    }) | undefined;
}
export interface DescribeClusterRequest {
    ClusterName?: string | undefined;
}
export type ClusterStatus = "Creating" | "Deleting" | "Failed" | "InService" | "RollingBack" | "SystemUpdating" | "Updating" | (string & {});
export type ClusterNonNegativeInstanceCount = number;
export interface ClusterInstanceRequirementDetails {
    CurrentInstanceTypes?: ClusterInstanceType[] | undefined;
    DesiredInstanceTypes?: ClusterInstanceType[] | undefined;
}
export interface ClusterInstanceTypeDetail {
    InstanceType?: ClusterInstanceType | undefined;
    CurrentCount?: number | undefined;
    ThreadsPerCore?: number | undefined;
}
export type ClusterInstanceTypeDetails = ClusterInstanceTypeDetail[];
export type InstanceGroupStatus = "InService" | "Creating" | "Updating" | "Failed" | "Degraded" | "SystemUpdating" | "Deleting" | (string & {});
export type InstanceGroupTrainingPlanStatus = string;
export interface ClusterPatchScheduleDetails {
    NextPatchDate?: Date | undefined;
}
export interface ClusterAutoPatchConfigDetails {
    PatchingStrategy?: ClusterPatchingStrategy | undefined;
    CurrentPatchSchedule?: ClusterPatchScheduleDetails | undefined;
    DesiredPatchSchedule?: ClusterPatchScheduleDetails | undefined;
    DeploymentConfig?: DeploymentConfiguration | undefined;
    IdleWaitWindowInSeconds?: number | undefined;
    DrainPolicy?: ClusterDrainPolicy | undefined;
}
export type ClusterImageVersionStatus = "UpToDate" | "UpdateAvailable" | "SecurityUpdateRequired" | "EndOfLife" | (string & {});
export type ActiveClusterOperationName = "Scaling" | (string & {});
export type ActiveClusterOperationCount = number;
export type ActiveOperations = {
    [key in ActiveClusterOperationName]?: number | undefined;
};
export interface ClusterKubernetesConfigDetails {
    CurrentLabels?: {
        [key: string]: string | undefined;
    } | undefined;
    DesiredLabels?: {
        [key: string]: string | undefined;
    } | undefined;
    CurrentTaints?: ClusterKubernetesTaint[] | undefined;
    DesiredTaints?: ClusterKubernetesTaint[] | undefined;
}
export type SoftwareUpdateStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "RollbackInProgress" | "RollbackComplete" | (string & {});
export interface ClusterSlurmConfigDetails {
    NodeType: ClusterSlurmNodeType;
    PartitionNames?: string[] | undefined;
}
export interface ClusterNetworkInterfaceDetails {
    InterfaceType?: ClusterInterfaceType | undefined;
}
export interface ClusterInstanceGroupDetails {
    CurrentCount?: number | undefined;
    TargetCount?: number | undefined;
    MinCount?: number | undefined;
    InstanceGroupName?: string | undefined;
    InstanceType?: ClusterInstanceType | undefined;
    InstanceRequirements?: ClusterInstanceRequirementDetails | undefined;
    InstanceTypeDetails?: ClusterInstanceTypeDetail[] | undefined;
    LifeCycleConfig?: ClusterLifeCycleConfig | undefined;
    ExecutionRole?: string | undefined;
    ThreadsPerCore?: number | undefined;
    InstanceStorageConfigs?: ClusterInstanceStorageConfig[] | undefined;
    OnStartDeepHealthChecks?: DeepHealthCheckType[] | undefined;
    Status?: InstanceGroupStatus | undefined;
    TrainingPlanArn?: string | undefined;
    TrainingPlanStatus?: string | undefined;
    OverrideVpcConfig?: VpcConfig | undefined;
    ScheduledUpdateConfig?: ScheduledUpdateConfig | undefined;
    AutoPatchConfig?: ClusterAutoPatchConfigDetails | undefined;
    CurrentImageId?: string | undefined;
    DesiredImageId?: string | undefined;
    CurrentImageReleaseVersion?: string | undefined;
    DesiredImageReleaseVersion?: string | undefined;
    ImageVersionStatus?: ClusterImageVersionStatus | undefined;
    ActiveOperations?: {
        [key: string]: number | undefined;
    } | undefined;
    KubernetesConfig?: ClusterKubernetesConfigDetails | undefined;
    CapacityRequirements?: ClusterCapacityRequirements | undefined;
    TargetStateCount?: number | undefined;
    SoftwareUpdateStatus?: SoftwareUpdateStatus | undefined;
    ActiveSoftwareUpdateConfig?: DeploymentConfiguration | undefined;
    SlurmConfig?: ClusterSlurmConfigDetails | undefined;
    NetworkInterface?: ClusterNetworkInterfaceDetails | undefined;
}
export type ClusterInstanceGroupDetailsList = ClusterInstanceGroupDetails[];
export interface EnvironmentConfigDetails {
    FSxLustreConfig?: FSxLustreConfig | undefined;
    S3OutputPath?: string | undefined;
}
export interface ClusterRestrictedInstanceGroupDetails {
    CurrentCount?: number | undefined;
    TargetCount?: number | undefined;
    InstanceGroupName?: string | undefined;
    InstanceType?: ClusterInstanceType | undefined;
    ExecutionRole?: string | undefined;
    ThreadsPerCore?: number | undefined;
    InstanceStorageConfigs?: ClusterInstanceStorageConfig[] | undefined;
    OnStartDeepHealthChecks?: DeepHealthCheckType[] | undefined;
    Status?: InstanceGroupStatus | undefined;
    TrainingPlanArn?: string | undefined;
    TrainingPlanStatus?: string | undefined;
    OverrideVpcConfig?: VpcConfig | undefined;
    ScheduledUpdateConfig?: ScheduledUpdateConfig | undefined;
    EnvironmentConfig?: EnvironmentConfigDetails | undefined;
}
export type ClusterRestrictedInstanceGroupDetailsList = ClusterRestrictedInstanceGroupDetails[];
export interface ClusterSharedEnvironmentConfigDetails {
    CurrentFSxLustreConfig?: FSxLustreConfig | undefined;
    DesiredFSxLustreConfig?: FSxLustreConfig | undefined;
    CurrentFSxLustreDeletionPolicy?: ClusterFSxLustreDeletionPolicy | undefined;
    DesiredFSxLustreDeletionPolicy?: ClusterFSxLustreDeletionPolicy | undefined;
}
export interface ClusterRestrictedInstanceGroupsConfigOutput {
    SharedEnvironmentConfig?: ClusterSharedEnvironmentConfigDetails | undefined;
}
export type ClusterAutoScalingStatus = "InService" | "Failed" | "Creating" | "Deleting" | (string & {});
export interface ClusterAutoScalingConfigOutput {
    Mode: ClusterAutoScalingMode;
    AutoScalerType?: ClusterAutoScalerType | undefined;
    Status: ClusterAutoScalingStatus;
    FailureMessage?: string | undefined;
}
export interface DescribeClusterResponse {
    ClusterArn: string;
    ClusterName?: string | undefined;
    ClusterStatus: ClusterStatus;
    CreationTime?: Date | undefined;
    FailureMessage?: string | undefined;
    InstanceGroups: (ClusterInstanceGroupDetails & {
        OverrideVpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
        ScheduledUpdateConfig: ScheduledUpdateConfig & {
            ScheduleExpression: CronScheduleExpression;
            DeploymentConfig: DeploymentConfiguration & {
                RollingUpdatePolicy: RollingDeploymentPolicy & {
                    MaximumBatchSize: CapacitySizeConfig & {
                        Type: NodeUnavailabilityType;
                        Value: NodeUnavailabilityValue;
                    };
                    RollbackMaximumBatchSize: CapacitySizeConfig & {
                        Type: NodeUnavailabilityType;
                        Value: NodeUnavailabilityValue;
                    };
                };
                AutoRollbackConfiguration: (AlarmDetails & {
                    AlarmName: AlarmName;
                })[];
            };
        };
        AutoPatchConfig: ClusterAutoPatchConfigDetails & {
            DeploymentConfig: DeploymentConfiguration & {
                RollingUpdatePolicy: RollingDeploymentPolicy & {
                    MaximumBatchSize: CapacitySizeConfig & {
                        Type: NodeUnavailabilityType;
                        Value: NodeUnavailabilityValue;
                    };
                    RollbackMaximumBatchSize: CapacitySizeConfig & {
                        Type: NodeUnavailabilityType;
                        Value: NodeUnavailabilityValue;
                    };
                };
                AutoRollbackConfiguration: (AlarmDetails & {
                    AlarmName: AlarmName;
                })[];
            };
        };
        ActiveSoftwareUpdateConfig: DeploymentConfiguration & {
            RollingUpdatePolicy: RollingDeploymentPolicy & {
                MaximumBatchSize: CapacitySizeConfig & {
                    Type: NodeUnavailabilityType;
                    Value: NodeUnavailabilityValue;
                };
                RollbackMaximumBatchSize: CapacitySizeConfig & {
                    Type: NodeUnavailabilityType;
                    Value: NodeUnavailabilityValue;
                };
            };
            AutoRollbackConfiguration: (AlarmDetails & {
                AlarmName: AlarmName;
            })[];
        };
    })[];
    RestrictedInstanceGroups?: (ClusterRestrictedInstanceGroupDetails & {
        OverrideVpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
        ScheduledUpdateConfig: ScheduledUpdateConfig & {
            ScheduleExpression: CronScheduleExpression;
            DeploymentConfig: DeploymentConfiguration & {
                RollingUpdatePolicy: RollingDeploymentPolicy & {
                    MaximumBatchSize: CapacitySizeConfig & {
                        Type: NodeUnavailabilityType;
                        Value: NodeUnavailabilityValue;
                    };
                    RollbackMaximumBatchSize: CapacitySizeConfig & {
                        Type: NodeUnavailabilityType;
                        Value: NodeUnavailabilityValue;
                    };
                };
                AutoRollbackConfiguration: (AlarmDetails & {
                    AlarmName: AlarmName;
                })[];
            };
        };
        EnvironmentConfig: EnvironmentConfigDetails & {
            FSxLustreConfig: FSxLustreConfig & {
                SizeInGiB: FSxLustreSizeInGiB;
                PerUnitStorageThroughput: FSxLustrePerUnitStorageThroughput;
            };
        };
    })[] | undefined;
    RestrictedInstanceGroupsConfig?: (ClusterRestrictedInstanceGroupsConfigOutput & {
        SharedEnvironmentConfig: ClusterSharedEnvironmentConfigDetails & {
            CurrentFSxLustreConfig: FSxLustreConfig & {
                SizeInGiB: FSxLustreSizeInGiB;
                PerUnitStorageThroughput: FSxLustrePerUnitStorageThroughput;
            };
            DesiredFSxLustreConfig: FSxLustreConfig & {
                SizeInGiB: FSxLustreSizeInGiB;
                PerUnitStorageThroughput: FSxLustrePerUnitStorageThroughput;
            };
        };
    }) | undefined;
    VpcConfig?: (VpcConfig & {
        SecurityGroupIds: VpcSecurityGroupIds;
        Subnets: Subnets;
    }) | undefined;
    Orchestrator?: (ClusterOrchestrator & {
        Eks: ClusterOrchestratorEksConfig & {
            ClusterArn: EksClusterArn;
        };
    }) | undefined;
    TieredStorageConfig?: (ClusterTieredStorageConfig & {
        Mode: ClusterConfigMode;
    }) | undefined;
    NodeRecovery?: ClusterNodeRecovery | undefined;
    NodeProvisioningMode?: ClusterNodeProvisioningMode | undefined;
    ClusterRole?: string | undefined;
    AutoScaling?: ClusterAutoScalingConfigOutput | undefined;
}
export type EventId = string;
export interface DescribeClusterEventRequest {
    EventId?: string | undefined;
    ClusterName?: string | undefined;
}
export type ClusterEventResourceType = "Cluster" | "InstanceGroup" | "Instance" | (string & {});
export type EksRoleAccessEntries = string[];
export interface ClusterMetadata {
    FailureMessage?: string | undefined;
    EksRoleAccessEntries?: string[] | undefined;
    SlrAccessEntry?: string | undefined;
}
export type CapacityReservationType = "ODCR" | "CRG" | (string & {});
export interface CapacityReservation {
    Arn?: string | undefined;
    Type?: CapacityReservationType | undefined;
}
export interface InstanceGroupMetadata {
    FailureMessage?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    CapacityReservation?: CapacityReservation | undefined;
    SubnetId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    AmiOverride?: string | undefined;
}
export type TargetCount = number;
export interface InstanceGroupScalingMetadata {
    InstanceCount?: number | undefined;
    TargetCount?: number | undefined;
    MinCount?: number | undefined;
    FailureMessage?: string | undefined;
}
export type EfaEnis = string[];
export interface AdditionalEnis {
    EfaEnis?: string[] | undefined;
}
export interface InstanceRequirementsEniConfiguration {
    CustomerEni?: string | undefined;
    AdditionalEnis?: AdditionalEnis | undefined;
}
export type InstanceRequirementsEniConfigurations = InstanceRequirementsEniConfiguration[];
export interface InstanceMetadata {
    CustomerEni?: string | undefined;
    AdditionalEnis?: AdditionalEnis | undefined;
    InstanceRequirementsEniConfigurations?: InstanceRequirementsEniConfiguration[] | undefined;
    CapacityReservation?: CapacityReservation | undefined;
    FailureMessage?: string | undefined;
    LcsExecutionState?: string | undefined;
    NodeLogicalId?: string | undefined;
}
export type DatabaseConfigurationRollbackStatus = "NotApplicable" | "Reverted" | "RevertFailed" | (string & {});
export interface DatabaseConfigurationMetadata {
    RollbackStatus?: DatabaseConfigurationRollbackStatus | undefined;
    Advisory?: string | undefined;
    FailureMessage?: string | undefined;
}
export type SlurmHealthComponent = "Slurmdbd" | (string & {});
export type SlurmHealthStatus = "Healthy" | "Unhealthy" | (string & {});
export type SlurmHealthReason = "DaemonDown" | "DaemonDisabled" | "DbUnreachable" | (string & {});
export interface SlurmHealthMetadata {
    Component?: SlurmHealthComponent | undefined;
    Status?: SlurmHealthStatus | undefined;
    Reason?: SlurmHealthReason | undefined;
}
export type EventMetadata = {
    Cluster: ClusterMetadata;
    InstanceGroup?: undefined;
    InstanceGroupScaling?: undefined;
    Instance?: undefined;
    DatabaseConfiguration?: undefined;
    SlurmHealth?: undefined;
} | {
    Cluster?: undefined;
    InstanceGroup: InstanceGroupMetadata;
    InstanceGroupScaling?: undefined;
    Instance?: undefined;
    DatabaseConfiguration?: undefined;
    SlurmHealth?: undefined;
} | {
    Cluster?: undefined;
    InstanceGroup?: undefined;
    InstanceGroupScaling: InstanceGroupScalingMetadata;
    Instance?: undefined;
    DatabaseConfiguration?: undefined;
    SlurmHealth?: undefined;
} | {
    Cluster?: undefined;
    InstanceGroup?: undefined;
    InstanceGroupScaling?: undefined;
    Instance: InstanceMetadata;
    DatabaseConfiguration?: undefined;
    SlurmHealth?: undefined;
} | {
    Cluster?: undefined;
    InstanceGroup?: undefined;
    InstanceGroupScaling?: undefined;
    Instance?: undefined;
    DatabaseConfiguration: DatabaseConfigurationMetadata;
    SlurmHealth?: undefined;
} | {
    Cluster?: undefined;
    InstanceGroup?: undefined;
    InstanceGroupScaling?: undefined;
    Instance?: undefined;
    DatabaseConfiguration?: undefined;
    SlurmHealth: SlurmHealthMetadata;
};
export interface EventDetails {
    EventMetadata?: EventMetadata | undefined;
}
export type ClusterEventLevel = "Info" | "Warn" | "Error" | (string & {});
export type ClusterOperationId = string;
export interface ClusterEventDetail {
    EventId?: string | undefined;
    ClusterArn?: string | undefined;
    ClusterName?: string | undefined;
    InstanceGroupName?: string | undefined;
    InstanceId?: string | undefined;
    ResourceType?: ClusterEventResourceType | undefined;
    EventTime?: Date | undefined;
    EventDetails?: EventDetails | undefined;
    Description?: string | undefined;
    EventLevel?: ClusterEventLevel | undefined;
    OperationId?: string | undefined;
}
export interface DescribeClusterEventResponse {
    EventDetails?: (ClusterEventDetail & {
        EventId: EventId;
        ClusterArn: ClusterArn;
        ClusterName: ClusterName;
        ResourceType: ClusterEventResourceType;
        EventTime: Date;
    }) | undefined;
}
export interface DescribeClusterExtensionRequest {
    ClusterArn?: string | undefined;
    ExtensionArn?: string | undefined;
}
export type ExtensionStatus = "Creating" | "Active" | "CreateFailed" | "Updating" | "Deleting" | "DeleteFailed" | "Degraded" | "UpdateFailed" | (string & {});
export interface ExtensionDetails {
    ClusterArn?: string | undefined;
    ExtensionArn?: string | undefined;
    ExtensionName?: string | undefined;
    ExtensionVersion?: string | undefined;
    Status?: ExtensionStatus | undefined;
    ConfigurationValues?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ExtensionNodeCount = number;
export interface ExtensionNodeSummary {
    TotalCount?: number | undefined;
    ActiveCount?: number | undefined;
}
export type ExtensionHealthIssueCode = "InvalidConfiguration" | "ConfigurationConflict" | "AccessDenied" | "ResourceNotFound" | "DependencyUnreachable" | "ExtensionUnhealthy" | "InternalFailure" | "Other" | (string & {});
export type ExtensionHealthIssueMessage = string;
export interface ExtensionHealthIssue {
    Code?: ExtensionHealthIssueCode | undefined;
    Message?: string | undefined;
    NodeCount?: number | undefined;
}
export type ExtensionHealthIssues = ExtensionHealthIssue[];
export interface ExtensionHealth {
    Issues?: ExtensionHealthIssue[] | undefined;
}
export interface DescribeClusterExtensionResponse {
    ExtensionDetails: ExtensionDetails & {
        ClusterArn: ClusterArn;
        ExtensionArn: ExtensionArn;
        ExtensionName: ExtensionName;
        ExtensionVersion: ExtensionVersion;
        Status: ExtensionStatus;
    };
    NodeSummary?: (ExtensionNodeSummary & {
        TotalCount: ExtensionNodeCount;
        ActiveCount: ExtensionNodeCount;
    }) | undefined;
    Health?: (ExtensionHealth & {
        Issues: (ExtensionHealthIssue & {
            Code: ExtensionHealthIssueCode;
            Message: ExtensionHealthIssueMessage;
            NodeCount: ExtensionNodeCount;
        })[];
    }) | undefined;
}
export interface DescribeClusterNodeRequest {
    ClusterName?: string | undefined;
    NodeId?: string | undefined;
    NodeLogicalId?: string | undefined;
}
export interface ClusterInstanceStatusDetails {
    Status?: ClusterInstanceStatus | undefined;
    Message?: string | undefined;
}
export type ClusterPrivatePrimaryIp = string;
export type ClusterPrivatePrimaryIpv6 = string;
export type ClusterPrivateDnsHostname = string;
export type ClusterAvailabilityZoneId = string;
export interface ClusterInstancePlacement {
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
}
export interface UltraServerInfo {
    Id?: string | undefined;
    Type?: string | undefined;
}
export interface ClusterKubernetesConfigNodeDetails {
    CurrentLabels?: {
        [key: string]: string | undefined;
    } | undefined;
    DesiredLabels?: {
        [key: string]: string | undefined;
    } | undefined;
    CurrentTaints?: ClusterKubernetesTaint[] | undefined;
    DesiredTaints?: ClusterKubernetesTaint[] | undefined;
}
export type ClusterCapacityType = "Spot" | "OnDemand" | (string & {});
export interface ClusterNodeDetails {
    InstanceGroupName?: string | undefined;
    InstanceId?: string | undefined;
    NodeLogicalId?: string | undefined;
    InstanceStatus?: ClusterInstanceStatusDetails | undefined;
    InstanceType?: ClusterInstanceType | undefined;
    LaunchTime?: Date | undefined;
    LastSoftwareUpdateTime?: Date | undefined;
    LifeCycleConfig?: ClusterLifeCycleConfig | undefined;
    OverrideVpcConfig?: VpcConfig | undefined;
    ThreadsPerCore?: number | undefined;
    InstanceStorageConfigs?: ClusterInstanceStorageConfig[] | undefined;
    PrivatePrimaryIp?: string | undefined;
    PrivatePrimaryIpv6?: string | undefined;
    PrivateDnsHostname?: string | undefined;
    Placement?: ClusterInstancePlacement | undefined;
    CurrentImageId?: string | undefined;
    DesiredImageId?: string | undefined;
    CurrentImageReleaseVersion?: string | undefined;
    DesiredImageReleaseVersion?: string | undefined;
    ImageVersionStatus?: ClusterImageVersionStatus | undefined;
    UltraServerInfo?: UltraServerInfo | undefined;
    KubernetesConfig?: ClusterKubernetesConfigNodeDetails | undefined;
    CapacityType?: ClusterCapacityType | undefined;
    NetworkInterface?: ClusterNetworkInterfaceDetails | undefined;
}
export interface DescribeClusterNodeResponse {
    NodeDetails: ClusterNodeDetails & {
        InstanceStatus: ClusterInstanceStatusDetails & {
            Status: ClusterInstanceStatus;
        };
        OverrideVpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
    };
}
export interface DescribeClusterOperationRequest {
    ClusterName?: string | undefined;
    OperationId?: string | undefined;
}
export type ClusterOperationType = "Scaling" | "DeepHealthCheck" | (string & {});
export type ClusterOperationStatus = "InProgress" | "Superseded" | "Done" | (string & {});
export type ClusterOperationCount = number;
export interface ClusterOperationScalingConfiguration {
    CurrentCount?: number | undefined;
    TargetCount?: number | undefined;
    MinCount?: number | undefined;
}
export interface ClusterOperationScalingDetails {
    InstanceGroupName?: string | undefined;
    Status?: ClusterOperationStatus | undefined;
    Original?: ClusterOperationScalingConfiguration | undefined;
    Desired?: ClusterOperationScalingConfiguration | undefined;
}
export type ClusterOperationScalingDetailsList = ClusterOperationScalingDetails[];
export type InstanceIds = string[];
export type DeepHealthChecks = DeepHealthCheckType[];
export interface InstanceGroupHealthCheckConfiguration {
    InstanceGroupName: string;
    InstanceIds?: string[] | undefined;
    DeepHealthChecks: DeepHealthCheckType[];
}
export type DeepHealthCheckConfigurations = InstanceGroupHealthCheckConfiguration[];
export interface DescribeClusterOperationResponse {
    OperationId?: string | undefined;
    ClusterArn?: string | undefined;
    Type?: ClusterOperationType | undefined;
    Status?: ClusterOperationStatus | undefined;
    CreationTime?: Date | undefined;
    ScalingDetails?: ClusterOperationScalingDetails[] | undefined;
    DeepHealthCheckDetails?: InstanceGroupHealthCheckConfiguration[] | undefined;
}
export interface DescribeClusterSchedulerConfigRequest {
    ClusterSchedulerConfigId?: string | undefined;
    ClusterSchedulerConfigVersion?: number | undefined;
}
export type SchedulerResourceStatus = "Creating" | "CreateFailed" | "CreateRollbackFailed" | "Created" | "Updating" | "UpdateFailed" | "UpdateRollbackFailed" | "Updated" | "Deleting" | "DeleteFailed" | "DeleteRollbackFailed" | "Deleted" | (string & {});
export type SchedulerConfigComponent = "PriorityClasses" | "FairShare" | "IdleResourceSharing" | (string & {});
export type StatusDetailsMap = {
    [key in SchedulerConfigComponent]?: SchedulerResourceStatus | undefined;
};
export interface DescribeClusterSchedulerConfigResponse {
    ClusterSchedulerConfigArn: string;
    ClusterSchedulerConfigId: string;
    Name: string;
    ClusterSchedulerConfigVersion: number;
    Status: SchedulerResourceStatus;
    FailureReason?: string | undefined;
    StatusDetails?: {
        [key: string]: SchedulerResourceStatus | undefined;
    } | undefined;
    ClusterArn?: string | undefined;
    SchedulerConfig?: (SchedulerConfig & {
        PriorityClasses: (PriorityClass & {
            Name: ClusterSchedulerPriorityClassName;
            Weight: PriorityWeight;
        })[];
    }) | undefined;
    Description?: string | undefined;
    CreationTime: Date;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export interface DescribeCodeRepositoryInput {
    CodeRepositoryName?: string | undefined;
}
export type LastModifiedTime = Date;
export interface DescribeCodeRepositoryOutput {
    CodeRepositoryName: string;
    CodeRepositoryArn: string;
    CreationTime: Date;
    LastModifiedTime: Date;
    GitConfig?: (GitConfig & {
        RepositoryUrl: GitConfigUrl;
    }) | undefined;
}
export interface DescribeCompilationJobRequest {
    CompilationJobName?: string | undefined;
}
export type CompilationJobStatus = "INPROGRESS" | "COMPLETED" | "FAILED" | "STARTING" | "STOPPING" | "STOPPED" | (string & {});
export type InferenceImage = string;
export interface ModelArtifacts {
    S3ModelArtifacts?: string | undefined;
}
export type ArtifactDigest = string;
export interface ModelDigests {
    ArtifactDigest?: string | undefined;
}
export interface DerivedInformation {
    DerivedDataInputConfig?: string | undefined;
}
export interface DescribeCompilationJobResponse {
    CompilationJobName: string;
    CompilationJobArn: string;
    CompilationJobStatus: CompilationJobStatus;
    CompilationStartTime?: Date | undefined;
    CompilationEndTime?: Date | undefined;
    StoppingCondition: StoppingCondition;
    InferenceImage?: string | undefined;
    ModelPackageVersionArn?: string | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    FailureReason: string;
    ModelArtifacts: ModelArtifacts & {
        S3ModelArtifacts: S3Uri;
    };
    ModelDigests?: ModelDigests | undefined;
    RoleArn: string;
    InputConfig: InputConfig & {
        S3Uri: S3Uri;
        Framework: Framework;
    };
    OutputConfig: OutputConfig & {
        S3OutputLocation: S3Uri;
        TargetPlatform: TargetPlatform & {
            Os: TargetPlatformOs;
            Arch: TargetPlatformArch;
        };
    };
    VpcConfig?: (NeoVpcConfig & {
        SecurityGroupIds: NeoVpcSecurityGroupIds;
        Subnets: NeoVpcSubnets;
    }) | undefined;
    DerivedInformation?: DerivedInformation | undefined;
}
export interface DescribeComputeQuotaRequest {
    ComputeQuotaId?: string | undefined;
    ComputeQuotaVersion?: number | undefined;
}
export interface DescribeComputeQuotaResponse {
    ComputeQuotaArn: string;
    ComputeQuotaId: string;
    Name: string;
    Description?: string | undefined;
    ComputeQuotaVersion: number;
    Status: SchedulerResourceStatus;
    FailureReason?: string | undefined;
    ClusterArn?: string | undefined;
    ComputeQuotaConfig?: (ComputeQuotaConfig & {
        ComputeQuotaResources: (ComputeQuotaResourceConfig & {
            InstanceType: ClusterInstanceType;
            AcceleratorPartition: AcceleratorPartitionConfig & {
                Type: MIGProfileType;
                Count: number;
            };
        })[];
        ResourceSharingConfig: ResourceSharingConfig & {
            Strategy: ResourceSharingStrategy;
            AbsoluteBorrowLimits: (ComputeQuotaResourceConfig & {
                InstanceType: ClusterInstanceType;
                AcceleratorPartition: AcceleratorPartitionConfig & {
                    Type: MIGProfileType;
                    Count: number;
                };
            })[];
        };
    }) | undefined;
    ComputeQuotaTarget: ComputeQuotaTarget & {
        TeamName: ComputeQuotaTargetTeamName;
    };
    ActivationState?: ActivationState | undefined;
    CreationTime: Date;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export type ContextNameOrArn = string;
export interface DescribeContextRequest {
    ContextName?: string | undefined;
}
export interface DescribeContextResponse {
    ContextName?: string | undefined;
    ContextArn?: string | undefined;
    Source?: (ContextSource & {
        SourceUri: SourceUri;
    }) | undefined;
    ContextType?: string | undefined;
    Description?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    LineageGroupArn?: string | undefined;
}
export interface DescribeDataQualityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
}
export interface DescribeDataQualityJobDefinitionResponse {
    JobDefinitionArn: string;
    JobDefinitionName: string;
    CreationTime: Date;
    DataQualityBaselineConfig?: DataQualityBaselineConfig | undefined;
    DataQualityAppSpecification: DataQualityAppSpecification & {
        ImageUri: ImageUri;
    };
    DataQualityJobInput: DataQualityJobInput & {
        EndpointInput: EndpointInput & {
            EndpointName: EndpointName;
            LocalPath: ProcessingLocalPath;
        };
        BatchTransformInput: BatchTransformInput & {
            DataCapturedDestinationS3Uri: DestinationS3Uri;
            DatasetFormat: MonitoringDatasetFormat;
            LocalPath: ProcessingLocalPath;
        };
    };
    DataQualityJobOutputConfig: MonitoringOutputConfig & {
        MonitoringOutputs: (MonitoringOutput & {
            S3Output: MonitoringS3Output & {
                S3Uri: MonitoringS3Uri;
                LocalPath: ProcessingLocalPath;
            };
        })[];
    };
    JobResources: MonitoringResources & {
        ClusterConfig: MonitoringClusterConfig & {
            InstanceCount: ProcessingInstanceCount;
            InstanceType: ProcessingInstanceType;
            VolumeSizeInGB: ProcessingVolumeSizeInGB;
        };
    };
    NetworkConfig?: (MonitoringNetworkConfig & {
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
    }) | undefined;
    RoleArn: string;
    StoppingCondition?: (MonitoringStoppingCondition & {
        MaxRuntimeInSeconds: MonitoringMaxRuntimeInSeconds;
    }) | undefined;
}
export interface DescribeDeviceRequest {
    NextToken?: string | undefined;
    DeviceName?: string | undefined;
    DeviceFleetName?: string | undefined;
}
export type DeviceArn = string;
export type DeviceDescription = string;
export type ThingName = string;
export interface EdgeModel {
    ModelName?: string | undefined;
    ModelVersion?: string | undefined;
    LatestSampleTime?: Date | undefined;
    LatestInference?: Date | undefined;
}
export type EdgeModels = EdgeModel[];
export interface DescribeDeviceResponse {
    DeviceArn?: string | undefined;
    DeviceName: string;
    Description?: string | undefined;
    DeviceFleetName: string;
    IotThingName?: string | undefined;
    RegistrationTime: Date;
    LatestHeartbeat?: Date | undefined;
    Models?: (EdgeModel & {
        ModelName: EntityName;
        ModelVersion: EdgeVersion;
    })[] | undefined;
    MaxModels?: number | undefined;
    NextToken?: string | undefined;
    AgentVersion?: string | undefined;
}
export interface DescribeDeviceFleetRequest {
    DeviceFleetName?: string | undefined;
}
export type DeviceFleetArn = string;
export type IotRoleAlias = string;
export interface DescribeDeviceFleetResponse {
    DeviceFleetName: string;
    DeviceFleetArn: string;
    OutputConfig: EdgeOutputConfig & {
        S3OutputLocation: S3Uri;
    };
    Description?: string | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    RoleArn?: string | undefined;
    IotRoleAlias?: string | undefined;
}
export interface DescribeDomainRequest {
    DomainId?: string | undefined;
}
export type ResourceId = string;
export type DomainStatus = "Deleting" | "Failed" | "InService" | "Pending" | "Updating" | "Update_Failed" | "Delete_Failed" | (string & {});
export interface DescribeDomainResponse {
    DomainArn?: string | undefined;
    DomainId?: string | undefined;
    DomainName?: string | undefined;
    HomeEfsFileSystemId?: string | undefined;
    SingleSignOnManagedApplicationInstanceId?: string | undefined;
    SingleSignOnApplicationArn?: string | undefined;
    Status?: DomainStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    FailureReason?: string | undefined;
    SecurityGroupIdForDomainBoundary?: string | undefined;
    AuthMode?: AuthMode | undefined;
    DefaultUserSettings?: (UserSettings & {
        JupyterServerAppSettings: JupyterServerAppSettings & {
            CodeRepositories: (CodeRepository & {
                RepositoryUrl: RepositoryUrl;
            })[];
        };
        KernelGatewayAppSettings: KernelGatewayAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
        };
        RSessionAppSettings: RSessionAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
        };
        CodeEditorAppSettings: CodeEditorAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
        };
        JupyterLabAppSettings: JupyterLabAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
            CodeRepositories: (CodeRepository & {
                RepositoryUrl: RepositoryUrl;
            })[];
        };
        SpaceStorageSettings: DefaultSpaceStorageSettings & {
            DefaultEbsStorageSettings: DefaultEbsStorageSettings & {
                DefaultEbsVolumeSizeInGb: SpaceEbsVolumeSizeInGb;
                MaximumEbsVolumeSizeInGb: SpaceEbsVolumeSizeInGb;
            };
        };
        CustomPosixUserConfig: CustomPosixUserConfig & {
            Uid: Uid;
            Gid: Gid;
        };
    }) | undefined;
    DomainSettings?: (DomainSettings & {
        RStudioServerProDomainSettings: RStudioServerProDomainSettings & {
            DomainExecutionRoleArn: RoleArn;
        };
        TrustedIdentityPropagationSettings: TrustedIdentityPropagationSettings & {
            Status: FeatureStatus;
        };
    }) | undefined;
    AppNetworkAccessType?: AppNetworkAccessType | undefined;
    HomeEfsFileSystemKmsKeyId?: string | undefined;
    SubnetIds?: string[] | undefined;
    Url?: string | undefined;
    VpcId?: string | undefined;
    KmsKeyId?: string | undefined;
    AppSecurityGroupManagement?: AppSecurityGroupManagement | undefined;
    HomeEfsFileSystemCreation?: HomeEfsFileSystemCreation | undefined;
    TagPropagation?: TagPropagation | undefined;
    DefaultSpaceSettings?: (DefaultSpaceSettings & {
        JupyterServerAppSettings: JupyterServerAppSettings & {
            CodeRepositories: (CodeRepository & {
                RepositoryUrl: RepositoryUrl;
            })[];
        };
        KernelGatewayAppSettings: KernelGatewayAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
        };
        JupyterLabAppSettings: JupyterLabAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
            CodeRepositories: (CodeRepository & {
                RepositoryUrl: RepositoryUrl;
            })[];
        };
        SpaceStorageSettings: DefaultSpaceStorageSettings & {
            DefaultEbsStorageSettings: DefaultEbsStorageSettings & {
                DefaultEbsVolumeSizeInGb: SpaceEbsVolumeSizeInGb;
                MaximumEbsVolumeSizeInGb: SpaceEbsVolumeSizeInGb;
            };
        };
        CustomPosixUserConfig: CustomPosixUserConfig & {
            Uid: Uid;
            Gid: Gid;
        };
    }) | undefined;
}
export type DeploymentStageMaxResults = number;
export interface DescribeEdgeDeploymentPlanRequest {
    EdgeDeploymentPlanName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type StageStatus = "CREATING" | "READYTODEPLOY" | "STARTING" | "INPROGRESS" | "DEPLOYED" | "FAILED" | "STOPPING" | "STOPPED" | (string & {});
export interface EdgeDeploymentStatus {
    StageStatus?: StageStatus | undefined;
    EdgeDeploymentSuccessInStage?: number | undefined;
    EdgeDeploymentPendingInStage?: number | undefined;
    EdgeDeploymentFailedInStage?: number | undefined;
    EdgeDeploymentStatusMessage?: string | undefined;
    EdgeDeploymentStageStartTime?: Date | undefined;
}
export interface DeploymentStageStatusSummary {
    StageName?: string | undefined;
    DeviceSelectionConfig?: DeviceSelectionConfig | undefined;
    DeploymentConfig?: EdgeDeploymentConfig | undefined;
    DeploymentStatus?: EdgeDeploymentStatus | undefined;
}
export type DeploymentStageStatusSummaries = DeploymentStageStatusSummary[];
export interface DescribeEdgeDeploymentPlanResponse {
    EdgeDeploymentPlanArn: string;
    EdgeDeploymentPlanName: string;
    ModelConfigs: (EdgeDeploymentModelConfig & {
        ModelHandle: EntityName;
        EdgePackagingJobName: EntityName;
    })[];
    DeviceFleetName: string;
    EdgeDeploymentSuccess?: number | undefined;
    EdgeDeploymentPending?: number | undefined;
    EdgeDeploymentFailed?: number | undefined;
    Stages: (DeploymentStageStatusSummary & {
        StageName: EntityName;
        DeviceSelectionConfig: DeviceSelectionConfig & {
            DeviceSubsetType: DeviceSubsetType;
        };
        DeploymentConfig: EdgeDeploymentConfig & {
            FailureHandlingPolicy: FailureHandlingPolicy;
        };
        DeploymentStatus: EdgeDeploymentStatus & {
            StageStatus: StageStatus;
            EdgeDeploymentSuccessInStage: number;
            EdgeDeploymentPendingInStage: number;
            EdgeDeploymentFailedInStage: number;
        };
    })[];
    NextToken?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface DescribeEdgePackagingJobRequest {
    EdgePackagingJobName?: string | undefined;
}
export type EdgePackagingJobArn = string;
export type EdgePackagingJobStatus = "STARTING" | "INPROGRESS" | "COMPLETED" | "FAILED" | "STOPPING" | "STOPPED" | (string & {});
export type EdgePresetDeploymentArtifact = string;
export type EdgePresetDeploymentStatus = "COMPLETED" | "FAILED" | (string & {});
export interface EdgePresetDeploymentOutput {
    Type?: EdgePresetDeploymentType | undefined;
    Artifact?: string | undefined;
    Status?: EdgePresetDeploymentStatus | undefined;
    StatusMessage?: string | undefined;
}
export interface DescribeEdgePackagingJobResponse {
    EdgePackagingJobArn: string;
    EdgePackagingJobName: string;
    CompilationJobName?: string | undefined;
    ModelName?: string | undefined;
    ModelVersion?: string | undefined;
    RoleArn?: string | undefined;
    OutputConfig?: (EdgeOutputConfig & {
        S3OutputLocation: S3Uri;
    }) | undefined;
    ResourceKey?: string | undefined;
    EdgePackagingJobStatus: EdgePackagingJobStatus;
    EdgePackagingJobStatusMessage?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    ModelArtifact?: string | undefined;
    ModelSignature?: string | undefined;
    PresetDeploymentOutput?: (EdgePresetDeploymentOutput & {
        Type: EdgePresetDeploymentType;
    }) | undefined;
}
export interface DescribeEndpointInput {
    EndpointName?: string | undefined;
}
export interface DeployedImage {
    SpecifiedImage?: string | undefined;
    ResolvedImage?: string | undefined;
    ResolutionTime?: Date | undefined;
}
export type DeployedImages = DeployedImage[];
export interface InstancePoolSummary {
    InstanceType?: ProductionVariantInstanceType | undefined;
    CurrentInstanceCount?: number | undefined;
}
export type InstancePoolSummaryList = InstancePoolSummary[];
export type VariantStatus = "Creating" | "Updating" | "Deleting" | "ActivatingTraffic" | "Baking" | (string & {});
export type VariantStatusMessage = string;
export interface ProductionVariantStatus {
    Status?: VariantStatus | undefined;
    StatusMessage?: string | undefined;
    StartTime?: Date | undefined;
}
export type ProductionVariantStatusList = ProductionVariantStatus[];
export type Ec2CapacityReservationId = string;
export interface Ec2CapacityReservation {
    Ec2CapacityReservationId?: string | undefined;
    TotalInstanceCount?: number | undefined;
    AvailableInstanceCount?: number | undefined;
    UsedByCurrentEndpoint?: number | undefined;
}
export type Ec2CapacityReservationsList = Ec2CapacityReservation[];
export interface ProductionVariantCapacityReservationSummary {
    MlReservationArn?: string | undefined;
    CapacityReservationPreference?: CapacityReservationPreference | undefined;
    TotalInstanceCount?: number | undefined;
    AvailableInstanceCount?: number | undefined;
    UsedByCurrentEndpoint?: number | undefined;
    Ec2CapacityReservations?: Ec2CapacityReservation[] | undefined;
}
export interface ProductionVariantSummary {
    VariantName?: string | undefined;
    DeployedImages?: DeployedImage[] | undefined;
    CurrentWeight?: number | undefined;
    DesiredWeight?: number | undefined;
    CurrentInstanceCount?: number | undefined;
    DesiredInstanceCount?: number | undefined;
    InstancePools?: InstancePoolSummary[] | undefined;
    VariantStatus?: ProductionVariantStatus[] | undefined;
    CurrentServerlessConfig?: ProductionVariantServerlessConfig | undefined;
    DesiredServerlessConfig?: ProductionVariantServerlessConfig | undefined;
    ManagedInstanceScaling?: ProductionVariantManagedInstanceScaling | undefined;
    RoutingConfig?: ProductionVariantRoutingConfig | undefined;
    CapacityReservationConfig?: ProductionVariantCapacityReservationSummary | undefined;
    AcceleratorPartitionLayouts?: AcceleratorPartitionLayout[] | undefined;
}
export type ProductionVariantSummaryList = ProductionVariantSummary[];
export type CaptureStatus = "Started" | "Stopped" | (string & {});
export interface DataCaptureConfigSummary {
    EnableCapture?: boolean | undefined;
    CaptureStatus?: CaptureStatus | undefined;
    CurrentSamplingPercentage?: number | undefined;
    DestinationS3Uri?: string | undefined;
    KmsKeyId?: string | undefined;
}
export type EndpointStatus = "OutOfService" | "Creating" | "Updating" | "SystemUpdating" | "RollingBack" | "InService" | "Deleting" | "Failed" | "UpdateRollbackFailed" | (string & {});
export interface PendingProductionVariantSummary {
    VariantName?: string | undefined;
    DeployedImages?: DeployedImage[] | undefined;
    CurrentWeight?: number | undefined;
    DesiredWeight?: number | undefined;
    CurrentInstanceCount?: number | undefined;
    DesiredInstanceCount?: number | undefined;
    InstanceType?: ProductionVariantInstanceType | undefined;
    InstancePools?: InstancePoolSummary[] | undefined;
    AcceleratorType?: ProductionVariantAcceleratorType | undefined;
    VariantStatus?: ProductionVariantStatus[] | undefined;
    CurrentServerlessConfig?: ProductionVariantServerlessConfig | undefined;
    DesiredServerlessConfig?: ProductionVariantServerlessConfig | undefined;
    ManagedInstanceScaling?: ProductionVariantManagedInstanceScaling | undefined;
    RoutingConfig?: ProductionVariantRoutingConfig | undefined;
    AcceleratorPartitionLayouts?: AcceleratorPartitionLayout[] | undefined;
}
export type PendingProductionVariantSummaryList = PendingProductionVariantSummary[];
export interface PendingDeploymentSummary {
    EndpointConfigName?: string | undefined;
    ProductionVariants?: PendingProductionVariantSummary[] | undefined;
    StartTime?: Date | undefined;
    ShadowProductionVariants?: PendingProductionVariantSummary[] | undefined;
}
export interface DescribeEndpointOutput {
    EndpointName: string;
    EndpointArn: string;
    EndpointConfigName?: string | undefined;
    ProductionVariants?: (ProductionVariantSummary & {
        VariantName: VariantName;
        InstancePools: (InstancePoolSummary & {
            InstanceType: ProductionVariantInstanceType;
            CurrentInstanceCount: TaskCount;
        })[];
        VariantStatus: (ProductionVariantStatus & {
            Status: VariantStatus;
        })[];
        CurrentServerlessConfig: ProductionVariantServerlessConfig & {
            MemorySizeInMB: ServerlessMemorySizeInMB;
            MaxConcurrency: ServerlessMaxConcurrency;
        };
        DesiredServerlessConfig: ProductionVariantServerlessConfig & {
            MemorySizeInMB: ServerlessMemorySizeInMB;
            MaxConcurrency: ServerlessMaxConcurrency;
        };
        ManagedInstanceScaling: ProductionVariantManagedInstanceScaling & {
            ScaleInPolicy: ProductionVariantManagedInstanceScalingScaleInPolicy & {
                Strategy: ManagedInstanceScalingScaleInStrategy;
            };
        };
        RoutingConfig: ProductionVariantRoutingConfig & {
            RoutingStrategy: RoutingStrategy;
        };
    })[] | undefined;
    DataCaptureConfig?: (DataCaptureConfigSummary & {
        EnableCapture: EnableCapture;
        CaptureStatus: CaptureStatus;
        CurrentSamplingPercentage: SamplingPercentage;
        DestinationS3Uri: DestinationS3Uri;
        KmsKeyId: KmsKeyId;
    }) | undefined;
    EndpointStatus: EndpointStatus;
    FailureReason?: string | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    LastDeploymentConfig?: (DeploymentConfig & {
        BlueGreenUpdatePolicy: BlueGreenUpdatePolicy & {
            TrafficRoutingConfiguration: TrafficRoutingConfig & {
                Type: TrafficRoutingConfigType;
                WaitIntervalInSeconds: WaitIntervalInSeconds;
                CanarySize: CapacitySize & {
                    Type: CapacitySizeType;
                    Value: CapacitySizeValue;
                };
                LinearStepSize: CapacitySize & {
                    Type: CapacitySizeType;
                    Value: CapacitySizeValue;
                };
            };
        };
        RollingUpdatePolicy: RollingUpdatePolicy & {
            MaximumBatchSize: CapacitySize & {
                Type: CapacitySizeType;
                Value: CapacitySizeValue;
            };
            WaitIntervalInSeconds: WaitIntervalInSeconds;
            RollbackMaximumBatchSize: CapacitySize & {
                Type: CapacitySizeType;
                Value: CapacitySizeValue;
            };
        };
    }) | undefined;
    AsyncInferenceConfig?: (AsyncInferenceConfig & {
        OutputConfig: AsyncInferenceOutputConfig;
    }) | undefined;
    PendingDeploymentSummary?: (PendingDeploymentSummary & {
        EndpointConfigName: EndpointConfigName;
        ProductionVariants: (PendingProductionVariantSummary & {
            VariantName: VariantName;
            InstancePools: (InstancePoolSummary & {
                InstanceType: ProductionVariantInstanceType;
                CurrentInstanceCount: TaskCount;
            })[];
            VariantStatus: (ProductionVariantStatus & {
                Status: VariantStatus;
            })[];
            CurrentServerlessConfig: ProductionVariantServerlessConfig & {
                MemorySizeInMB: ServerlessMemorySizeInMB;
                MaxConcurrency: ServerlessMaxConcurrency;
            };
            DesiredServerlessConfig: ProductionVariantServerlessConfig & {
                MemorySizeInMB: ServerlessMemorySizeInMB;
                MaxConcurrency: ServerlessMaxConcurrency;
            };
            ManagedInstanceScaling: ProductionVariantManagedInstanceScaling & {
                ScaleInPolicy: ProductionVariantManagedInstanceScalingScaleInPolicy & {
                    Strategy: ManagedInstanceScalingScaleInStrategy;
                };
            };
            RoutingConfig: ProductionVariantRoutingConfig & {
                RoutingStrategy: RoutingStrategy;
            };
        })[];
        ShadowProductionVariants: (PendingProductionVariantSummary & {
            VariantName: VariantName;
            InstancePools: (InstancePoolSummary & {
                InstanceType: ProductionVariantInstanceType;
                CurrentInstanceCount: TaskCount;
            })[];
            VariantStatus: (ProductionVariantStatus & {
                Status: VariantStatus;
            })[];
            CurrentServerlessConfig: ProductionVariantServerlessConfig & {
                MemorySizeInMB: ServerlessMemorySizeInMB;
                MaxConcurrency: ServerlessMaxConcurrency;
            };
            DesiredServerlessConfig: ProductionVariantServerlessConfig & {
                MemorySizeInMB: ServerlessMemorySizeInMB;
                MaxConcurrency: ServerlessMaxConcurrency;
            };
            ManagedInstanceScaling: ProductionVariantManagedInstanceScaling & {
                ScaleInPolicy: ProductionVariantManagedInstanceScalingScaleInPolicy & {
                    Strategy: ManagedInstanceScalingScaleInStrategy;
                };
            };
            RoutingConfig: ProductionVariantRoutingConfig & {
                RoutingStrategy: RoutingStrategy;
            };
        })[];
    }) | undefined;
    ExplainerConfig?: (ExplainerConfig & {
        ClarifyExplainerConfig: ClarifyExplainerConfig & {
            ShapConfig: ClarifyShapConfig & {
                ShapBaselineConfig: ClarifyShapBaselineConfig;
                TextConfig: ClarifyTextConfig & {
                    Language: ClarifyTextLanguage;
                    Granularity: ClarifyTextGranularity;
                };
            };
        };
    }) | undefined;
    ShadowProductionVariants?: (ProductionVariantSummary & {
        VariantName: VariantName;
        InstancePools: (InstancePoolSummary & {
            InstanceType: ProductionVariantInstanceType;
            CurrentInstanceCount: TaskCount;
        })[];
        VariantStatus: (ProductionVariantStatus & {
            Status: VariantStatus;
        })[];
        CurrentServerlessConfig: ProductionVariantServerlessConfig & {
            MemorySizeInMB: ServerlessMemorySizeInMB;
            MaxConcurrency: ServerlessMaxConcurrency;
        };
        DesiredServerlessConfig: ProductionVariantServerlessConfig & {
            MemorySizeInMB: ServerlessMemorySizeInMB;
            MaxConcurrency: ServerlessMaxConcurrency;
        };
        ManagedInstanceScaling: ProductionVariantManagedInstanceScaling & {
            ScaleInPolicy: ProductionVariantManagedInstanceScalingScaleInPolicy & {
                Strategy: ManagedInstanceScalingScaleInStrategy;
            };
        };
        RoutingConfig: ProductionVariantRoutingConfig & {
            RoutingStrategy: RoutingStrategy;
        };
    })[] | undefined;
    MetricsConfig?: MetricsConfig | undefined;
}
export interface DescribeEndpointConfigInput {
    EndpointConfigName?: string | undefined;
}
export interface DescribeEndpointConfigOutput {
    EndpointConfigName: string;
    EndpointConfigArn: string;
    ProductionVariants: (ProductionVariant & {
        VariantName: VariantName;
        InstancePools: (InstancePool & {
            InstanceType: ProductionVariantInstanceType;
            Priority: InstancePoolPriority;
        })[];
        CoreDumpConfig: ProductionVariantCoreDumpConfig & {
            DestinationS3Uri: DestinationS3Uri;
        };
        ServerlessConfig: ProductionVariantServerlessConfig & {
            MemorySizeInMB: ServerlessMemorySizeInMB;
            MaxConcurrency: ServerlessMaxConcurrency;
        };
        ManagedInstanceScaling: ProductionVariantManagedInstanceScaling & {
            ScaleInPolicy: ProductionVariantManagedInstanceScalingScaleInPolicy & {
                Strategy: ManagedInstanceScalingScaleInStrategy;
            };
        };
        RoutingConfig: ProductionVariantRoutingConfig & {
            RoutingStrategy: RoutingStrategy;
        };
    })[];
    DataCaptureConfig?: (DataCaptureConfig & {
        InitialSamplingPercentage: SamplingPercentage;
        DestinationS3Uri: DestinationS3Uri;
        CaptureOptions: (CaptureOption & {
            CaptureMode: CaptureMode;
        })[];
    }) | undefined;
    KmsKeyId?: string | undefined;
    CreationTime: Date;
    AsyncInferenceConfig?: (AsyncInferenceConfig & {
        OutputConfig: AsyncInferenceOutputConfig;
    }) | undefined;
    ExplainerConfig?: (ExplainerConfig & {
        ClarifyExplainerConfig: ClarifyExplainerConfig & {
            ShapConfig: ClarifyShapConfig & {
                ShapBaselineConfig: ClarifyShapBaselineConfig;
                TextConfig: ClarifyTextConfig & {
                    Language: ClarifyTextLanguage;
                    Granularity: ClarifyTextGranularity;
                };
            };
        };
    }) | undefined;
    ShadowProductionVariants?: (ProductionVariant & {
        VariantName: VariantName;
        InstancePools: (InstancePool & {
            InstanceType: ProductionVariantInstanceType;
            Priority: InstancePoolPriority;
        })[];
        CoreDumpConfig: ProductionVariantCoreDumpConfig & {
            DestinationS3Uri: DestinationS3Uri;
        };
        ServerlessConfig: ProductionVariantServerlessConfig & {
            MemorySizeInMB: ServerlessMemorySizeInMB;
            MaxConcurrency: ServerlessMaxConcurrency;
        };
        ManagedInstanceScaling: ProductionVariantManagedInstanceScaling & {
            ScaleInPolicy: ProductionVariantManagedInstanceScalingScaleInPolicy & {
                Strategy: ManagedInstanceScalingScaleInStrategy;
            };
        };
        RoutingConfig: ProductionVariantRoutingConfig & {
            RoutingStrategy: RoutingStrategy;
        };
    })[] | undefined;
    ExecutionRoleArn?: string | undefined;
    VpcConfig?: (VpcConfig & {
        SecurityGroupIds: VpcSecurityGroupIds;
        Subnets: Subnets;
    }) | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    MetricsConfig?: MetricsConfig | undefined;
}
export interface DescribeExperimentRequest {
    ExperimentName?: string | undefined;
}
export type ExperimentSourceArn = string;
export type SourceType = string;
export interface ExperimentSource {
    SourceArn?: string | undefined;
    SourceType?: string | undefined;
}
export interface DescribeExperimentResponse {
    ExperimentName?: string | undefined;
    ExperimentArn?: string | undefined;
    DisplayName?: string | undefined;
    Source?: (ExperimentSource & {
        SourceArn: ExperimentSourceArn;
    }) | undefined;
    Description?: string | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export type FeatureGroupNameOrArn = string;
export interface DescribeFeatureGroupRequest {
    FeatureGroupName?: string | undefined;
    NextToken?: string | undefined;
}
export interface ThroughputConfigDescription {
    ThroughputMode?: ThroughputMode | undefined;
    ProvisionedReadCapacityUnits?: number | undefined;
    ProvisionedWriteCapacityUnits?: number | undefined;
}
export type FeatureGroupStatus = "Creating" | "Created" | "CreateFailed" | "Deleting" | "DeleteFailed" | (string & {});
export type OfflineStoreStatusValue = "Active" | "Blocked" | "Disabled" | (string & {});
export type BlockedReason = string;
export interface OfflineStoreStatus {
    Status?: OfflineStoreStatusValue | undefined;
    BlockedReason?: string | undefined;
}
export type LastUpdateStatusValue = "Successful" | "Failed" | "InProgress" | (string & {});
export interface LastUpdateStatus {
    Status?: LastUpdateStatusValue | undefined;
    FailureReason?: string | undefined;
}
export type OnlineStoreTotalSizeBytes = number;
export interface DescribeFeatureGroupResponse {
    FeatureGroupArn: string;
    FeatureGroupName: string;
    RecordIdentifierFeatureName: string;
    EventTimeFeatureName: string;
    FeatureDefinitions: (FeatureDefinition & {
        FeatureName: FeatureName;
        FeatureType: FeatureType;
    })[];
    CreationTime: Date;
    LastModifiedTime?: Date | undefined;
    OnlineStoreConfig?: OnlineStoreConfig | undefined;
    OfflineStoreConfig?: (OfflineStoreConfig & {
        S3StorageConfig: S3StorageConfig & {
            S3Uri: S3Uri;
        };
        DataCatalogConfig: DataCatalogConfig & {
            TableName: TableName;
            Catalog: Catalog;
            Database: Database;
        };
    }) | undefined;
    ThroughputConfig?: (ThroughputConfigDescription & {
        ThroughputMode: ThroughputMode;
    }) | undefined;
    RoleArn?: string | undefined;
    FeatureGroupStatus?: FeatureGroupStatus | undefined;
    OfflineStoreStatus?: (OfflineStoreStatus & {
        Status: OfflineStoreStatusValue;
    }) | undefined;
    LastUpdateStatus?: (LastUpdateStatus & {
        Status: LastUpdateStatusValue;
    }) | undefined;
    FailureReason?: string | undefined;
    Description?: string | undefined;
    NextToken: string;
    OnlineStoreTotalSizeBytes?: number | undefined;
}
export interface DescribeFeatureMetadataRequest {
    FeatureGroupName?: string | undefined;
    FeatureName?: string | undefined;
}
export type FeatureDescription = string;
export type FeatureParameterKey = string;
export type FeatureParameterValue = string;
export interface FeatureParameter {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type FeatureParameters = FeatureParameter[];
export interface DescribeFeatureMetadataResponse {
    FeatureGroupArn: string;
    FeatureGroupName: string;
    FeatureName: string;
    FeatureType: FeatureType;
    CreationTime: Date;
    LastModifiedTime: Date;
    Description?: string | undefined;
    Parameters?: FeatureParameter[] | undefined;
}
export interface DescribeFlowDefinitionRequest {
    FlowDefinitionName?: string | undefined;
}
export type FlowDefinitionStatus = "Initializing" | "Active" | "Failed" | "Deleting" | (string & {});
export interface DescribeFlowDefinitionResponse {
    FlowDefinitionArn: string;
    FlowDefinitionName: string;
    FlowDefinitionStatus: FlowDefinitionStatus;
    CreationTime: Date;
    HumanLoopRequestSource?: (HumanLoopRequestSource & {
        AwsManagedHumanLoopRequestSource: AwsManagedHumanLoopRequestSource;
    }) | undefined;
    HumanLoopActivationConfig?: (HumanLoopActivationConfig & {
        HumanLoopActivationConditionsConfig: HumanLoopActivationConditionsConfig & {
            HumanLoopActivationConditions: HumanLoopActivationConditions;
        };
    }) | undefined;
    HumanLoopConfig?: (HumanLoopConfig & {
        WorkteamArn: WorkteamArn;
        HumanTaskUiArn: HumanTaskUiArn;
        TaskTitle: FlowDefinitionTaskTitle;
        TaskDescription: FlowDefinitionTaskDescription;
        TaskCount: FlowDefinitionTaskCount;
    }) | undefined;
    OutputConfig: FlowDefinitionOutputConfig & {
        S3OutputPath: S3Uri;
    };
    RoleArn: string;
    FailureReason?: string | undefined;
}
export interface DescribeHubRequest {
    HubName?: string | undefined;
}
export type HubStatus = "InService" | "Creating" | "Updating" | "Deleting" | "CreateFailed" | "UpdateFailed" | "DeleteFailed" | (string & {});
export interface DescribeHubResponse {
    HubName: string;
    HubArn: string;
    HubDisplayName?: string | undefined;
    HubDescription?: string | undefined;
    HubSearchKeywords?: string[] | undefined;
    S3StorageConfig?: HubS3StorageConfig | undefined;
    HubStatus: HubStatus;
    FailureReason?: string | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    CreatedBy?: UserContext | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export interface DescribeHubContentRequest {
    HubName?: string | undefined;
    HubContentType?: HubContentType | undefined;
    HubContentName?: string | undefined;
    HubContentVersion?: string | undefined;
}
export type DocumentSchemaVersion = string;
export type HubContentDisplayName = string;
export type HubContentDescription = string;
export type HubContentMarkdown = string;
export type HubContentDocument = string;
export type ReferenceMinVersion = string;
export type HubContentSupportStatus = "Supported" | "Deprecated" | "Restricted" | (string & {});
export type HubContentSearchKeyword = string;
export type HubContentSearchKeywordList = string[];
export type DependencyOriginPath = string;
export type DependencyCopyPath = string;
export interface HubContentDependency {
    DependencyOriginPath?: string | undefined;
    DependencyCopyPath?: string | undefined;
}
export type HubContentDependencyList = HubContentDependency[];
export type HubContentStatus = "Available" | "Importing" | "Deleting" | "ImportFailed" | "DeleteFailed" | "PendingImport" | "PendingDelete" | (string & {});
export interface DescribeHubContentResponse {
    HubContentName: string;
    HubContentArn: string;
    HubContentVersion: string;
    HubContentType: HubContentType;
    DocumentSchemaVersion: string;
    HubName: string;
    HubArn: string;
    HubContentDisplayName?: string | undefined;
    HubContentDescription?: string | undefined;
    HubContentMarkdown?: string | undefined;
    HubContentDocument: string;
    SageMakerPublicHubContentArn?: string | undefined;
    ReferenceMinVersion?: string | undefined;
    SupportStatus?: HubContentSupportStatus | undefined;
    HubContentSearchKeywords?: string[] | undefined;
    HubContentDependencies?: HubContentDependency[] | undefined;
    HubContentStatus: HubContentStatus;
    FailureReason?: string | undefined;
    CreationTime: Date;
    LastModifiedTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export interface DescribeHumanTaskUiRequest {
    HumanTaskUiName?: string | undefined;
}
export type HumanTaskUiStatus = "Active" | "Deleting" | (string & {});
export type TemplateUrl = string;
export type TemplateContentSha256 = string;
export interface UiTemplateInfo {
    Url?: string | undefined;
    ContentSha256?: string | undefined;
}
export interface DescribeHumanTaskUiResponse {
    HumanTaskUiArn: string;
    HumanTaskUiName: string;
    HumanTaskUiStatus?: HumanTaskUiStatus | undefined;
    CreationTime: Date;
    UiTemplate: UiTemplateInfo;
}
export interface DescribeHyperParameterTuningJobRequest {
    HyperParameterTuningJobName?: string | undefined;
}
export type HyperParameterTuningJobStatus = "Completed" | "InProgress" | "Failed" | "Stopped" | "Stopping" | "Deleting" | "DeleteFailed" | (string & {});
export type TrainingJobStatusCounter = number;
export interface TrainingJobStatusCounters {
    Completed?: number | undefined;
    InProgress?: number | undefined;
    RetryableError?: number | undefined;
    NonRetryableError?: number | undefined;
    Stopped?: number | undefined;
}
export type ObjectiveStatusCounter = number;
export interface ObjectiveStatusCounters {
    Succeeded?: number | undefined;
    Pending?: number | undefined;
    Failed?: number | undefined;
}
export type TrainingJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | "Deleting" | (string & {});
export interface FinalHyperParameterTuningJobObjectiveMetric {
    Type?: HyperParameterTuningJobObjectiveType | undefined;
    MetricName?: string | undefined;
    Value?: number | undefined;
}
export interface HyperParameterTrainingJobSummary {
    TrainingJobDefinitionName?: string | undefined;
    TrainingJobName?: string | undefined;
    TrainingJobArn?: string | undefined;
    TuningJobName?: string | undefined;
    CreationTime?: Date | undefined;
    TrainingStartTime?: Date | undefined;
    TrainingEndTime?: Date | undefined;
    TrainingJobStatus?: TrainingJobStatus | undefined;
    TunedHyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    FailureReason?: string | undefined;
    FinalHyperParameterTuningJobObjectiveMetric?: FinalHyperParameterTuningJobObjectiveMetric | undefined;
    ObjectiveStatus?: ObjectiveStatus | undefined;
}
export interface HyperParameterTuningJobCompletionDetails {
    NumberOfTrainingJobsObjectiveNotImproving?: number | undefined;
    ConvergenceDetectedTime?: Date | undefined;
}
export interface HyperParameterTuningJobConsumedResources {
    RuntimeInSeconds?: number | undefined;
}
export interface DescribeHyperParameterTuningJobResponse {
    HyperParameterTuningJobName: string;
    HyperParameterTuningJobArn: string;
    HyperParameterTuningJobConfig: HyperParameterTuningJobConfig & {
        Strategy: HyperParameterTuningJobStrategyType;
        ResourceLimits: ResourceLimits & {
            MaxParallelTrainingJobs: MaxParallelTrainingJobs;
        };
        HyperParameterTuningJobObjective: HyperParameterTuningJobObjective & {
            Type: HyperParameterTuningJobObjectiveType;
            MetricName: MetricName;
        };
        ParameterRanges: ParameterRanges & {
            IntegerParameterRanges: (IntegerParameterRange & {
                Name: ParameterKey;
                MinValue: ParameterValue;
                MaxValue: ParameterValue;
            })[];
            ContinuousParameterRanges: (ContinuousParameterRange & {
                Name: ParameterKey;
                MinValue: ParameterValue;
                MaxValue: ParameterValue;
            })[];
            CategoricalParameterRanges: (CategoricalParameterRange & {
                Name: ParameterKey;
                Values: ParameterValues;
            })[];
            AutoParameters: (AutoParameter & {
                Name: ParameterKey;
                ValueHint: ParameterValue;
            })[];
        };
    };
    TrainingJobDefinition?: (HyperParameterTrainingJobDefinition & {
        AlgorithmSpecification: HyperParameterAlgorithmSpecification & {
            TrainingInputMode: TrainingInputMode;
            MetricDefinitions: (MetricDefinition & {
                Name: MetricName;
                Regex: MetricRegex;
            })[];
        };
        RoleArn: RoleArn;
        OutputDataConfig: OutputDataConfig & {
            S3OutputPath: S3Uri;
        };
        StoppingCondition: StoppingCondition;
        TuningObjective: HyperParameterTuningJobObjective & {
            Type: HyperParameterTuningJobObjectiveType;
            MetricName: MetricName;
        };
        HyperParameterRanges: ParameterRanges & {
            IntegerParameterRanges: (IntegerParameterRange & {
                Name: ParameterKey;
                MinValue: ParameterValue;
                MaxValue: ParameterValue;
            })[];
            ContinuousParameterRanges: (ContinuousParameterRange & {
                Name: ParameterKey;
                MinValue: ParameterValue;
                MaxValue: ParameterValue;
            })[];
            CategoricalParameterRanges: (CategoricalParameterRange & {
                Name: ParameterKey;
                Values: ParameterValues;
            })[];
            AutoParameters: (AutoParameter & {
                Name: ParameterKey;
                ValueHint: ParameterValue;
            })[];
        };
        InputDataConfig: (Channel & {
            ChannelName: ChannelName;
            DataSource: DataSource & {
                S3DataSource: S3DataSource & {
                    S3DataType: S3DataType;
                    S3Uri: S3Uri;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: HubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
                FileSystemDataSource: FileSystemDataSource & {
                    FileSystemId: FileSystemId;
                    FileSystemAccessMode: FileSystemAccessMode;
                    FileSystemType: FileSystemType;
                    DirectoryPath: DirectoryPath;
                };
            };
            ShuffleConfig: ShuffleConfig & {
                Seed: Seed;
            };
        })[];
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
        ResourceConfig: ResourceConfig & {
            InstanceGroups: (InstanceGroup & {
                InstanceType: TrainingInstanceType;
                InstanceCount: TrainingInstanceCount;
                InstanceGroupName: InstanceGroupName;
            })[];
            InstancePlacementConfig: InstancePlacementConfig & {
                PlacementSpecifications: (PlacementSpecification & {
                    InstanceCount: TrainingInstanceCount;
                })[];
            };
            InstancePreferences: (InstancePreference & {
                InstanceType: TrainingInstanceType;
            })[];
        };
        HyperParameterTuningResourceConfig: HyperParameterTuningResourceConfig & {
            InstanceConfigs: (HyperParameterTuningInstanceConfig & {
                InstanceType: TrainingInstanceType;
                InstanceCount: TrainingInstanceCount;
                VolumeSizeInGB: VolumeSizeInGB;
            })[];
        };
        CheckpointConfig: CheckpointConfig & {
            S3Uri: S3Uri;
        };
        RetryStrategy: RetryStrategy & {
            MaximumRetryAttempts: MaximumRetryAttempts;
        };
    }) | undefined;
    TrainingJobDefinitions?: (HyperParameterTrainingJobDefinition & {
        AlgorithmSpecification: HyperParameterAlgorithmSpecification & {
            TrainingInputMode: TrainingInputMode;
            MetricDefinitions: (MetricDefinition & {
                Name: MetricName;
                Regex: MetricRegex;
            })[];
        };
        RoleArn: RoleArn;
        OutputDataConfig: OutputDataConfig & {
            S3OutputPath: S3Uri;
        };
        StoppingCondition: StoppingCondition;
        TuningObjective: HyperParameterTuningJobObjective & {
            Type: HyperParameterTuningJobObjectiveType;
            MetricName: MetricName;
        };
        HyperParameterRanges: ParameterRanges & {
            IntegerParameterRanges: (IntegerParameterRange & {
                Name: ParameterKey;
                MinValue: ParameterValue;
                MaxValue: ParameterValue;
            })[];
            ContinuousParameterRanges: (ContinuousParameterRange & {
                Name: ParameterKey;
                MinValue: ParameterValue;
                MaxValue: ParameterValue;
            })[];
            CategoricalParameterRanges: (CategoricalParameterRange & {
                Name: ParameterKey;
                Values: ParameterValues;
            })[];
            AutoParameters: (AutoParameter & {
                Name: ParameterKey;
                ValueHint: ParameterValue;
            })[];
        };
        InputDataConfig: (Channel & {
            ChannelName: ChannelName;
            DataSource: DataSource & {
                S3DataSource: S3DataSource & {
                    S3DataType: S3DataType;
                    S3Uri: S3Uri;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: HubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
                FileSystemDataSource: FileSystemDataSource & {
                    FileSystemId: FileSystemId;
                    FileSystemAccessMode: FileSystemAccessMode;
                    FileSystemType: FileSystemType;
                    DirectoryPath: DirectoryPath;
                };
            };
            ShuffleConfig: ShuffleConfig & {
                Seed: Seed;
            };
        })[];
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
        ResourceConfig: ResourceConfig & {
            InstanceGroups: (InstanceGroup & {
                InstanceType: TrainingInstanceType;
                InstanceCount: TrainingInstanceCount;
                InstanceGroupName: InstanceGroupName;
            })[];
            InstancePlacementConfig: InstancePlacementConfig & {
                PlacementSpecifications: (PlacementSpecification & {
                    InstanceCount: TrainingInstanceCount;
                })[];
            };
            InstancePreferences: (InstancePreference & {
                InstanceType: TrainingInstanceType;
            })[];
        };
        HyperParameterTuningResourceConfig: HyperParameterTuningResourceConfig & {
            InstanceConfigs: (HyperParameterTuningInstanceConfig & {
                InstanceType: TrainingInstanceType;
                InstanceCount: TrainingInstanceCount;
                VolumeSizeInGB: VolumeSizeInGB;
            })[];
        };
        CheckpointConfig: CheckpointConfig & {
            S3Uri: S3Uri;
        };
        RetryStrategy: RetryStrategy & {
            MaximumRetryAttempts: MaximumRetryAttempts;
        };
    })[] | undefined;
    HyperParameterTuningJobStatus: HyperParameterTuningJobStatus;
    CreationTime: Date;
    HyperParameterTuningEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    TrainingJobStatusCounters: TrainingJobStatusCounters;
    ObjectiveStatusCounters: ObjectiveStatusCounters;
    BestTrainingJob?: (HyperParameterTrainingJobSummary & {
        TrainingJobName: TrainingJobName;
        TrainingJobArn: TrainingJobArn;
        CreationTime: Date;
        TrainingJobStatus: TrainingJobStatus;
        TunedHyperParameters: HyperParameters;
        FinalHyperParameterTuningJobObjectiveMetric: FinalHyperParameterTuningJobObjectiveMetric & {
            MetricName: MetricName;
            Value: MetricValue;
        };
    }) | undefined;
    OverallBestTrainingJob?: (HyperParameterTrainingJobSummary & {
        TrainingJobName: TrainingJobName;
        TrainingJobArn: TrainingJobArn;
        CreationTime: Date;
        TrainingJobStatus: TrainingJobStatus;
        TunedHyperParameters: HyperParameters;
        FinalHyperParameterTuningJobObjectiveMetric: FinalHyperParameterTuningJobObjectiveMetric & {
            MetricName: MetricName;
            Value: MetricValue;
        };
    }) | undefined;
    WarmStartConfig?: (HyperParameterTuningJobWarmStartConfig & {
        ParentHyperParameterTuningJobs: ParentHyperParameterTuningJobs;
        WarmStartType: HyperParameterTuningJobWarmStartType;
    }) | undefined;
    Autotune?: (Autotune & {
        Mode: AutotuneMode;
    }) | undefined;
    FailureReason?: string | undefined;
    TuningJobCompletionDetails?: HyperParameterTuningJobCompletionDetails | undefined;
    ConsumedResources?: HyperParameterTuningJobConsumedResources | undefined;
}
export interface DescribeImageRequest {
    ImageName?: string | undefined;
}
export type ImageStatus = "CREATING" | "CREATED" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface DescribeImageResponse {
    CreationTime?: Date | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    FailureReason?: string | undefined;
    ImageArn?: string | undefined;
    ImageName?: string | undefined;
    ImageStatus?: ImageStatus | undefined;
    LastModifiedTime?: Date | undefined;
    RoleArn?: string | undefined;
}
export interface DescribeImageVersionRequest {
    ImageName?: string | undefined;
    Version?: number | undefined;
    Alias?: string | undefined;
}
export type ImageContainerImage = string;
export type ImageVersionStatus = "CREATING" | "CREATED" | "CREATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface DescribeImageVersionResponse {
    BaseImage?: string | undefined;
    ContainerImage?: string | undefined;
    CreationTime?: Date | undefined;
    FailureReason?: string | undefined;
    ImageArn?: string | undefined;
    ImageVersionArn?: string | undefined;
    ImageVersionStatus?: ImageVersionStatus | undefined;
    LastModifiedTime?: Date | undefined;
    Version?: number | undefined;
    VendorGuidance?: VendorGuidance | undefined;
    JobType?: JobType | undefined;
    MLFramework?: string | undefined;
    ProgrammingLang?: string | undefined;
    Processor?: Processor | undefined;
    Horovod?: boolean | undefined;
    ReleaseNotes?: string | undefined;
}
export interface DescribeInferenceComponentInput {
    InferenceComponentName?: string | undefined;
}
export interface InferenceComponentContainerSpecificationSummary {
    DeployedImage?: DeployedImage | undefined;
    ArtifactUrl?: string | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    ContainerMetricsConfig?: ContainerMetricsConfig | undefined;
}
export interface InferenceComponentDataCacheConfigSummary {
    EnableCaching?: boolean | undefined;
}
export interface InferenceComponentSpecificationSummary {
    InstanceType?: ProductionVariantInstanceType | undefined;
    ModelName?: string | undefined;
    Container?: InferenceComponentContainerSpecificationSummary | undefined;
    StartupParameters?: InferenceComponentStartupParameters | undefined;
    ComputeResourceRequirements?: InferenceComponentComputeResourceRequirements | undefined;
    BaseInferenceComponentName?: string | undefined;
    DataCacheConfig?: InferenceComponentDataCacheConfigSummary | undefined;
    SchedulingConfig?: InferenceComponentSchedulingConfig | undefined;
}
export type InferenceComponentSpecificationSummaryList = InferenceComponentSpecificationSummary[];
export interface InferenceComponentPlacementStatus {
    InstanceType?: ProductionVariantInstanceType | undefined;
    CurrentCopyCount?: number | undefined;
}
export type InferenceComponentPlacementStatusList = InferenceComponentPlacementStatus[];
export interface InferenceComponentRuntimeConfigSummary {
    DesiredCopyCount?: number | undefined;
    CurrentCopyCount?: number | undefined;
    PlacementStatus?: InferenceComponentPlacementStatus[] | undefined;
}
export type InferenceComponentStatus = "InService" | "Creating" | "Updating" | "Failed" | "Deleting" | (string & {});
export type InferenceComponentCapacitySizeType = "COPY_COUNT" | "CAPACITY_PERCENT" | (string & {});
export interface InferenceComponentCapacitySize {
    Type?: InferenceComponentCapacitySizeType | undefined;
    Value?: number | undefined;
}
export interface InferenceComponentRollingUpdatePolicy {
    MaximumBatchSize?: InferenceComponentCapacitySize | undefined;
    WaitIntervalInSeconds?: number | undefined;
    MaximumExecutionTimeoutInSeconds?: number | undefined;
    RollbackMaximumBatchSize?: InferenceComponentCapacitySize | undefined;
}
export interface InferenceComponentDeploymentConfig {
    RollingUpdatePolicy?: InferenceComponentRollingUpdatePolicy | undefined;
    AutoRollbackConfiguration?: AutoRollbackConfig | undefined;
}
export interface DescribeInferenceComponentOutput {
    InferenceComponentName: string;
    InferenceComponentArn: string;
    EndpointName: string;
    EndpointArn: string;
    VariantName?: string | undefined;
    FailureReason?: string | undefined;
    Specification?: (InferenceComponentSpecificationSummary & {
        Container: InferenceComponentContainerSpecificationSummary & {
            ContainerMetricsConfig: ContainerMetricsConfig & {
                MetricsEndpoints: (MetricsEndpoint & {
                    MetricsEndpointPath: MetricsEndpointPath;
                })[];
            };
        };
        ComputeResourceRequirements: InferenceComponentComputeResourceRequirements & {
            MinMemoryRequiredInMb: MemoryInMb;
        };
        DataCacheConfig: InferenceComponentDataCacheConfigSummary & {
            EnableCaching: EnableCaching;
        };
        SchedulingConfig: InferenceComponentSchedulingConfig & {
            PlacementStrategy: InferenceComponentPlacementStrategy;
            AvailabilityZoneBalance: InferenceComponentAvailabilityZoneBalance & {
                EnforcementMode: AvailabilityZoneBalanceEnforcementMode;
            };
        };
    }) | undefined;
    Specifications?: (InferenceComponentSpecificationSummary & {
        Container: InferenceComponentContainerSpecificationSummary & {
            ContainerMetricsConfig: ContainerMetricsConfig & {
                MetricsEndpoints: (MetricsEndpoint & {
                    MetricsEndpointPath: MetricsEndpointPath;
                })[];
            };
        };
        ComputeResourceRequirements: InferenceComponentComputeResourceRequirements & {
            MinMemoryRequiredInMb: MemoryInMb;
        };
        DataCacheConfig: InferenceComponentDataCacheConfigSummary & {
            EnableCaching: EnableCaching;
        };
        SchedulingConfig: InferenceComponentSchedulingConfig & {
            PlacementStrategy: InferenceComponentPlacementStrategy;
            AvailabilityZoneBalance: InferenceComponentAvailabilityZoneBalance & {
                EnforcementMode: AvailabilityZoneBalanceEnforcementMode;
            };
        };
    })[] | undefined;
    RuntimeConfig?: (InferenceComponentRuntimeConfigSummary & {
        PlacementStatus: (InferenceComponentPlacementStatus & {
            InstanceType: ProductionVariantInstanceType;
            CurrentCopyCount: InferenceComponentCopyCount;
        })[];
    }) | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    InferenceComponentStatus?: InferenceComponentStatus | undefined;
    LastDeploymentConfig?: (InferenceComponentDeploymentConfig & {
        RollingUpdatePolicy: InferenceComponentRollingUpdatePolicy & {
            MaximumBatchSize: InferenceComponentCapacitySize & {
                Type: InferenceComponentCapacitySizeType;
                Value: CapacitySizeValue;
            };
            WaitIntervalInSeconds: WaitIntervalInSeconds;
            RollbackMaximumBatchSize: InferenceComponentCapacitySize & {
                Type: InferenceComponentCapacitySizeType;
                Value: CapacitySizeValue;
            };
        };
    }) | undefined;
}
export interface DescribeInferenceExperimentRequest {
    Name?: string | undefined;
}
export type InferenceExperimentStatus = "Creating" | "Created" | "Updating" | "Running" | "Starting" | "Stopping" | "Completed" | "Cancelled" | (string & {});
export type InferenceExperimentStatusReason = string;
export interface EndpointMetadata {
    EndpointName?: string | undefined;
    EndpointConfigName?: string | undefined;
    EndpointStatus?: EndpointStatus | undefined;
    FailureReason?: string | undefined;
}
export type ModelVariantStatus = "Creating" | "Updating" | "InService" | "Deleting" | "Deleted" | (string & {});
export interface ModelVariantConfigSummary {
    ModelName?: string | undefined;
    VariantName?: string | undefined;
    InfrastructureConfig?: ModelInfrastructureConfig | undefined;
    Status?: ModelVariantStatus | undefined;
}
export type ModelVariantConfigSummaryList = ModelVariantConfigSummary[];
export interface DescribeInferenceExperimentResponse {
    Arn: string;
    Name: string;
    Type: InferenceExperimentType;
    Schedule?: InferenceExperimentSchedule | undefined;
    Status: InferenceExperimentStatus;
    StatusReason?: string | undefined;
    Description?: string | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    RoleArn?: string | undefined;
    EndpointMetadata: EndpointMetadata & {
        EndpointName: EndpointName;
    };
    ModelVariants: (ModelVariantConfigSummary & {
        ModelName: ModelName;
        VariantName: ModelVariantName;
        InfrastructureConfig: ModelInfrastructureConfig & {
            InfrastructureType: ModelInfrastructureType;
            RealTimeInferenceConfig: RealTimeInferenceConfig & {
                InstanceType: ProductionVariantInstanceType;
                InstanceCount: TaskCount;
            };
        };
        Status: ModelVariantStatus;
    })[];
    DataStorageConfig?: (InferenceExperimentDataStorageConfig & {
        Destination: DestinationS3Uri;
    }) | undefined;
    ShadowModeConfig?: (ShadowModeConfig & {
        SourceModelVariantName: ModelVariantName;
        ShadowModelVariants: (ShadowModelVariantConfig & {
            ShadowModelVariantName: ModelVariantName;
            SamplingPercentage: Percentage;
        })[];
    }) | undefined;
    KmsKey?: string | undefined;
}
export interface DescribeInferenceRecommendationsJobRequest {
    JobName?: string | undefined;
}
export type RecommendationJobStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "STOPPING" | "STOPPED" | "DELETING" | "DELETED" | (string & {});
export type UtilizationMetric = number;
export type ModelSetupTime = number;
export interface RecommendationMetrics {
    CostPerHour?: number | undefined;
    CostPerInference?: number | undefined;
    MaxInvocations?: number | undefined;
    ModelLatency?: number | undefined;
    CpuUtilization?: number | undefined;
    MemoryUtilization?: number | undefined;
    ModelSetupTime?: number | undefined;
}
export type InitialInstanceCount = number;
export interface EndpointOutputConfiguration {
    EndpointName?: string | undefined;
    VariantName?: string | undefined;
    InstanceType?: ProductionVariantInstanceType | undefined;
    InitialInstanceCount?: number | undefined;
    ServerlessConfig?: ProductionVariantServerlessConfig | undefined;
}
export interface EnvironmentParameter {
    Key?: string | undefined;
    ValueType?: string | undefined;
    Value?: string | undefined;
}
export type EnvironmentParameters = EnvironmentParameter[];
export type RecommendationJobCompilationJobName = string;
export interface ModelConfiguration {
    InferenceSpecificationName?: string | undefined;
    EnvironmentParameters?: EnvironmentParameter[] | undefined;
    CompilationJobName?: string | undefined;
}
export type InvocationEndTime = Date;
export type InvocationStartTime = Date;
export interface InferenceRecommendation {
    RecommendationId?: string | undefined;
    Metrics?: RecommendationMetrics | undefined;
    EndpointConfiguration?: EndpointOutputConfiguration | undefined;
    ModelConfiguration?: ModelConfiguration | undefined;
    InvocationEndTime?: Date | undefined;
    InvocationStartTime?: Date | undefined;
}
export type InferenceRecommendations = InferenceRecommendation[];
export interface InferenceMetrics {
    MaxInvocations?: number | undefined;
    ModelLatency?: number | undefined;
}
export interface EndpointPerformance {
    Metrics?: InferenceMetrics | undefined;
    EndpointInfo?: EndpointInfo | undefined;
}
export type EndpointPerformances = EndpointPerformance[];
export interface DescribeInferenceRecommendationsJobResponse {
    JobName: string;
    JobDescription?: string | undefined;
    JobType: RecommendationJobType;
    JobArn: string;
    RoleArn: string;
    Status: RecommendationJobStatus;
    CreationTime: Date;
    CompletionTime?: Date | undefined;
    LastModifiedTime: Date;
    FailureReason?: string | undefined;
    InputConfig: RecommendationJobInputConfig & {
        EndpointConfigurations: (EndpointInputConfiguration & {
            ServerlessConfig: ProductionVariantServerlessConfig & {
                MemorySizeInMB: ServerlessMemorySizeInMB;
                MaxConcurrency: ServerlessMaxConcurrency;
            };
            EnvironmentParameterRanges: EnvironmentParameterRanges & {
                CategoricalParameterRanges: (CategoricalParameter & {
                    Name: String64;
                    Value: CategoricalParameterRangeValues;
                })[];
            };
        })[];
        VpcConfig: RecommendationJobVpcConfig & {
            SecurityGroupIds: RecommendationJobVpcSecurityGroupIds;
            Subnets: RecommendationJobVpcSubnets;
        };
    };
    StoppingConditions?: RecommendationJobStoppingConditions | undefined;
    InferenceRecommendations?: (InferenceRecommendation & {
        EndpointConfiguration: EndpointOutputConfiguration & {
            EndpointName: string;
            VariantName: string;
            ServerlessConfig: ProductionVariantServerlessConfig & {
                MemorySizeInMB: ServerlessMemorySizeInMB;
                MaxConcurrency: ServerlessMaxConcurrency;
            };
        };
        ModelConfiguration: ModelConfiguration & {
            EnvironmentParameters: (EnvironmentParameter & {
                Key: string;
                ValueType: string;
                Value: string;
            })[];
        };
    })[] | undefined;
    EndpointPerformances?: (EndpointPerformance & {
        Metrics: InferenceMetrics & {
            MaxInvocations: number;
            ModelLatency: number;
        };
        EndpointInfo: EndpointInfo;
    })[] | undefined;
}
export interface DescribeJobRequest {
    JobName?: string | undefined;
    JobCategory?: JobCategory | undefined;
}
export type JobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | "Deleting" | "DeleteFailed" | (string & {});
export type JobSecondaryStatus = "Starting" | "Downloading" | "Training" | "Uploading" | "Stopping" | "Stopped" | "MaxRuntimeExceeded" | "Interrupted" | "Failed" | "Completed" | "Restarting" | "Pending" | "Evaluating" | "Deleting" | "DeleteFailed" | (string & {});
export interface JobSecondaryStatusTransition {
    Status?: JobSecondaryStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    StatusMessage?: string | undefined;
}
export type JobSecondaryStatusTransitions = JobSecondaryStatusTransition[];
export interface DescribeJobResponse {
    JobName: string;
    JobArn: string;
    RoleArn: string;
    JobCategory: JobCategory;
    JobConfigSchemaVersion: string;
    JobConfigDocument?: string | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    EndTime?: Date | undefined;
    JobStatus: JobStatus;
    SecondaryStatus: JobSecondaryStatus;
    SecondaryStatusTransitions: (JobSecondaryStatusTransition & {
        Status: JobSecondaryStatus;
        StartTime: Date;
    })[];
    FailureReason?: string | undefined;
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
}
export interface DescribeJobSchemaVersionRequest {
    JobCategory?: JobCategory | undefined;
    JobConfigSchemaVersion?: string | undefined;
}
export interface DescribeJobSchemaVersionResponse {
    JobCategory: JobCategory;
    JobConfigSchemaVersion: string;
    JobConfigSchema: string;
}
export interface DescribeLabelingJobRequest {
    LabelingJobName?: string | undefined;
}
export type LabelingJobStatus = "Initializing" | "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export type LabelCounter = number;
export interface LabelCounters {
    TotalLabeled?: number | undefined;
    HumanLabeled?: number | undefined;
    MachineLabeled?: number | undefined;
    FailedNonRetryableError?: number | undefined;
    Unlabeled?: number | undefined;
}
export type JobReferenceCode = string;
export interface LabelingJobOutput {
    OutputDatasetS3Uri?: string | undefined;
    FinalActiveLearningModelArn?: string | undefined;
}
export interface DescribeLabelingJobResponse {
    LabelingJobStatus: LabelingJobStatus;
    LabelCounters: LabelCounters;
    FailureReason?: string | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    JobReferenceCode: string;
    LabelingJobName: string;
    LabelingJobArn: string;
    LabelAttributeName?: string | undefined;
    InputConfig: LabelingJobInputConfig & {
        DataSource: LabelingJobDataSource & {
            S3DataSource: LabelingJobS3DataSource & {
                ManifestS3Uri: S3Uri;
            };
            SnsDataSource: LabelingJobSnsDataSource & {
                SnsTopicArn: SnsTopicArn;
            };
        };
    };
    OutputConfig: LabelingJobOutputConfig & {
        S3OutputPath: S3Uri;
    };
    RoleArn: string;
    LabelCategoryConfigS3Uri?: string | undefined;
    StoppingConditions?: LabelingJobStoppingConditions | undefined;
    LabelingJobAlgorithmsConfig?: (LabelingJobAlgorithmsConfig & {
        LabelingJobAlgorithmSpecificationArn: LabelingJobAlgorithmSpecificationArn;
        LabelingJobResourceConfig: LabelingJobResourceConfig & {
            VpcConfig: VpcConfig & {
                SecurityGroupIds: VpcSecurityGroupIds;
                Subnets: Subnets;
            };
        };
    }) | undefined;
    HumanTaskConfig: HumanTaskConfig & {
        WorkteamArn: WorkteamArn;
        UiConfig: UiConfig;
        TaskTitle: TaskTitle;
        TaskDescription: TaskDescription;
        NumberOfHumanWorkersPerDataObject: NumberOfHumanWorkersPerDataObject;
        TaskTimeLimitInSeconds: TaskTimeLimitInSeconds;
        AnnotationConsolidationConfig: AnnotationConsolidationConfig & {
            AnnotationConsolidationLambdaArn: LambdaFunctionArn;
        };
    };
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
    LabelingJobOutput?: (LabelingJobOutput & {
        OutputDatasetS3Uri: S3Uri;
    }) | undefined;
}
export interface DescribeLineageGroupRequest {
    LineageGroupName?: string | undefined;
}
export interface DescribeLineageGroupResponse {
    LineageGroupName?: string | undefined;
    LineageGroupArn?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export interface DescribeMlflowAppRequest {
    Arn?: string | undefined;
}
export type MlflowAppStatus = "Creating" | "Created" | "CreateFailed" | "Updating" | "Updated" | "UpdateFailed" | "Deleting" | "DeleteFailed" | "Deleted" | (string & {});
export type MaintenanceStatus = "MaintenanceInProgress" | "MaintenanceComplete" | "MaintenanceFailed" | (string & {});
export interface DescribeMlflowAppResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    ArtifactStoreUri?: string | undefined;
    MlflowVersion?: string | undefined;
    RoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    Status?: MlflowAppStatus | undefined;
    ModelRegistrationMode?: ModelRegistrationMode | undefined;
    AccountDefaultStatus?: AccountDefaultStatus | undefined;
    DefaultDomainIdList?: string[] | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    MaintenanceStatus?: MaintenanceStatus | undefined;
}
export interface DescribeMlflowTrackingServerRequest {
    TrackingServerName?: string | undefined;
}
export type TrackingServerStatus = "Creating" | "Created" | "CreateFailed" | "Updating" | "Updated" | "UpdateFailed" | "Deleting" | "DeleteFailed" | "Stopping" | "Stopped" | "StopFailed" | "Starting" | "Started" | "StartFailed" | "MaintenanceInProgress" | "MaintenanceComplete" | "MaintenanceFailed" | (string & {});
export type TrackingServerMaintenanceStatus = "MaintenanceInProgress" | "MaintenanceComplete" | "MaintenanceFailed" | (string & {});
export type IsTrackingServerActive = "Active" | "Inactive" | (string & {});
export interface DescribeMlflowTrackingServerResponse {
    TrackingServerArn?: string | undefined;
    TrackingServerName?: string | undefined;
    ArtifactStoreUri?: string | undefined;
    TrackingServerSize?: TrackingServerSize | undefined;
    MlflowVersion?: string | undefined;
    RoleArn?: string | undefined;
    TrackingServerStatus?: TrackingServerStatus | undefined;
    TrackingServerMaintenanceStatus?: TrackingServerMaintenanceStatus | undefined;
    IsActive?: IsTrackingServerActive | undefined;
    TrackingServerUrl?: string | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    AutomaticModelRegistration?: boolean | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    S3BucketOwnerAccountId?: string | undefined;
    S3BucketOwnerVerification?: boolean | undefined;
}
export interface DescribeModelInput {
    ModelName?: string | undefined;
}
export type RecommendationStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | "NOT_APPLICABLE" | (string & {});
export interface RealTimeInferenceRecommendation {
    RecommendationId?: string | undefined;
    InstanceType?: ProductionVariantInstanceType | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RealTimeInferenceRecommendations = RealTimeInferenceRecommendation[];
export interface DeploymentRecommendation {
    RecommendationStatus?: RecommendationStatus | undefined;
    RealTimeInferenceRecommendations?: RealTimeInferenceRecommendation[] | undefined;
}
export interface DescribeModelOutput {
    ModelName: string;
    PrimaryContainer?: (ContainerDefinition & {
        ImageConfig: ImageConfig & {
            RepositoryAccessMode: RepositoryAccessMode;
            RepositoryAuthConfig: RepositoryAuthConfig & {
                RepositoryCredentialsProviderArn: RepositoryCredentialsProviderArn;
            };
        };
        ModelDataSource: ModelDataSource & {
            S3DataSource: S3ModelDataSource & {
                S3Uri: S3ModelUri;
                S3DataType: S3ModelDataType;
                CompressionType: ModelCompressionType;
                ModelAccessConfig: ModelAccessConfig & {
                    AcceptEula: AcceptEula;
                };
                HubAccessConfig: InferenceHubAccessConfig & {
                    HubContentArn: HubContentArn;
                };
            };
        };
        AdditionalModelDataSources: (AdditionalModelDataSource & {
            ChannelName: AdditionalModelChannelName;
            S3DataSource: S3ModelDataSource & {
                S3Uri: S3ModelUri;
                S3DataType: S3ModelDataType;
                CompressionType: ModelCompressionType;
                ModelAccessConfig: ModelAccessConfig & {
                    AcceptEula: AcceptEula;
                };
                HubAccessConfig: InferenceHubAccessConfig & {
                    HubContentArn: HubContentArn;
                };
            };
        })[];
        ContainerMetricsConfig: ContainerMetricsConfig & {
            MetricsEndpoints: (MetricsEndpoint & {
                MetricsEndpointPath: MetricsEndpointPath;
            })[];
        };
    }) | undefined;
    Containers?: (ContainerDefinition & {
        ImageConfig: ImageConfig & {
            RepositoryAccessMode: RepositoryAccessMode;
            RepositoryAuthConfig: RepositoryAuthConfig & {
                RepositoryCredentialsProviderArn: RepositoryCredentialsProviderArn;
            };
        };
        ModelDataSource: ModelDataSource & {
            S3DataSource: S3ModelDataSource & {
                S3Uri: S3ModelUri;
                S3DataType: S3ModelDataType;
                CompressionType: ModelCompressionType;
                ModelAccessConfig: ModelAccessConfig & {
                    AcceptEula: AcceptEula;
                };
                HubAccessConfig: InferenceHubAccessConfig & {
                    HubContentArn: HubContentArn;
                };
            };
        };
        AdditionalModelDataSources: (AdditionalModelDataSource & {
            ChannelName: AdditionalModelChannelName;
            S3DataSource: S3ModelDataSource & {
                S3Uri: S3ModelUri;
                S3DataType: S3ModelDataType;
                CompressionType: ModelCompressionType;
                ModelAccessConfig: ModelAccessConfig & {
                    AcceptEula: AcceptEula;
                };
                HubAccessConfig: InferenceHubAccessConfig & {
                    HubContentArn: HubContentArn;
                };
            };
        })[];
        ContainerMetricsConfig: ContainerMetricsConfig & {
            MetricsEndpoints: (MetricsEndpoint & {
                MetricsEndpointPath: MetricsEndpointPath;
            })[];
        };
    })[] | undefined;
    InferenceExecutionConfig?: (InferenceExecutionConfig & {
        Mode: InferenceExecutionMode;
    }) | undefined;
    ExecutionRoleArn?: string | undefined;
    VpcConfig?: (VpcConfig & {
        SecurityGroupIds: VpcSecurityGroupIds;
        Subnets: Subnets;
    }) | undefined;
    CreationTime: Date;
    ModelArn: string;
    EnableNetworkIsolation?: boolean | undefined;
    DeploymentRecommendation?: (DeploymentRecommendation & {
        RecommendationStatus: RecommendationStatus;
        RealTimeInferenceRecommendations: (RealTimeInferenceRecommendation & {
            RecommendationId: string;
            InstanceType: ProductionVariantInstanceType;
        })[];
    }) | undefined;
}
export interface DescribeModelBiasJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
}
export interface DescribeModelBiasJobDefinitionResponse {
    JobDefinitionArn: string;
    JobDefinitionName: string;
    CreationTime: Date;
    ModelBiasBaselineConfig?: ModelBiasBaselineConfig | undefined;
    ModelBiasAppSpecification: ModelBiasAppSpecification & {
        ImageUri: ImageUri;
        ConfigUri: S3Uri;
    };
    ModelBiasJobInput: ModelBiasJobInput & {
        GroundTruthS3Input: MonitoringGroundTruthS3Input;
        EndpointInput: EndpointInput & {
            EndpointName: EndpointName;
            LocalPath: ProcessingLocalPath;
        };
        BatchTransformInput: BatchTransformInput & {
            DataCapturedDestinationS3Uri: DestinationS3Uri;
            DatasetFormat: MonitoringDatasetFormat;
            LocalPath: ProcessingLocalPath;
        };
    };
    ModelBiasJobOutputConfig: MonitoringOutputConfig & {
        MonitoringOutputs: (MonitoringOutput & {
            S3Output: MonitoringS3Output & {
                S3Uri: MonitoringS3Uri;
                LocalPath: ProcessingLocalPath;
            };
        })[];
    };
    JobResources: MonitoringResources & {
        ClusterConfig: MonitoringClusterConfig & {
            InstanceCount: ProcessingInstanceCount;
            InstanceType: ProcessingInstanceType;
            VolumeSizeInGB: ProcessingVolumeSizeInGB;
        };
    };
    NetworkConfig?: (MonitoringNetworkConfig & {
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
    }) | undefined;
    RoleArn: string;
    StoppingCondition?: (MonitoringStoppingCondition & {
        MaxRuntimeInSeconds: MonitoringMaxRuntimeInSeconds;
    }) | undefined;
}
export type IncludedData = "AllData" | "MetadataOnly" | (string & {});
export interface DescribeModelCardRequest {
    ModelCardName?: string | undefined;
    ModelCardVersion?: number | undefined;
    IncludedData?: IncludedData | undefined;
}
export type ModelCardProcessingStatus = "DeleteInProgress" | "DeletePending" | "ContentDeleted" | "ExportJobsDeleted" | "DeleteCompleted" | "DeleteFailed" | (string & {});
export interface DescribeModelCardResponse {
    ModelCardArn: string;
    ModelCardName: string;
    ModelCardVersion: number;
    Content: string | redacted.Redacted<string>;
    ModelCardStatus: ModelCardStatus;
    SecurityConfig?: ModelCardSecurityConfig | undefined;
    CreationTime: Date;
    CreatedBy: UserContext;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    ModelCardProcessingStatus?: ModelCardProcessingStatus | undefined;
}
export interface DescribeModelCardExportJobRequest {
    ModelCardExportJobArn?: string | undefined;
}
export type ModelCardExportJobStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export interface ModelCardExportArtifacts {
    S3ExportArtifacts?: string | undefined;
}
export interface DescribeModelCardExportJobResponse {
    ModelCardExportJobName: string;
    ModelCardExportJobArn: string;
    Status: ModelCardExportJobStatus;
    ModelCardName: string;
    ModelCardVersion: number;
    OutputConfig: ModelCardExportOutputConfig & {
        S3OutputPath: S3Uri;
    };
    CreatedAt: Date;
    LastModifiedAt: Date;
    FailureReason?: string | undefined;
    ExportArtifacts?: (ModelCardExportArtifacts & {
        S3ExportArtifacts: S3Uri;
    }) | undefined;
}
export interface DescribeModelExplainabilityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
}
export interface DescribeModelExplainabilityJobDefinitionResponse {
    JobDefinitionArn: string;
    JobDefinitionName: string;
    CreationTime: Date;
    ModelExplainabilityBaselineConfig?: ModelExplainabilityBaselineConfig | undefined;
    ModelExplainabilityAppSpecification: ModelExplainabilityAppSpecification & {
        ImageUri: ImageUri;
        ConfigUri: S3Uri;
    };
    ModelExplainabilityJobInput: ModelExplainabilityJobInput & {
        EndpointInput: EndpointInput & {
            EndpointName: EndpointName;
            LocalPath: ProcessingLocalPath;
        };
        BatchTransformInput: BatchTransformInput & {
            DataCapturedDestinationS3Uri: DestinationS3Uri;
            DatasetFormat: MonitoringDatasetFormat;
            LocalPath: ProcessingLocalPath;
        };
    };
    ModelExplainabilityJobOutputConfig: MonitoringOutputConfig & {
        MonitoringOutputs: (MonitoringOutput & {
            S3Output: MonitoringS3Output & {
                S3Uri: MonitoringS3Uri;
                LocalPath: ProcessingLocalPath;
            };
        })[];
    };
    JobResources: MonitoringResources & {
        ClusterConfig: MonitoringClusterConfig & {
            InstanceCount: ProcessingInstanceCount;
            InstanceType: ProcessingInstanceType;
            VolumeSizeInGB: ProcessingVolumeSizeInGB;
        };
    };
    NetworkConfig?: (MonitoringNetworkConfig & {
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
    }) | undefined;
    RoleArn: string;
    StoppingCondition?: (MonitoringStoppingCondition & {
        MaxRuntimeInSeconds: MonitoringMaxRuntimeInSeconds;
    }) | undefined;
}
export interface DescribeModelPackageInput {
    ModelPackageName?: string | undefined;
    IncludedData?: IncludedData | undefined;
}
export type DetailedModelPackageStatus = "NotStarted" | "InProgress" | "Completed" | "Failed" | (string & {});
export interface ModelPackageStatusItem {
    Name?: string | undefined;
    Status?: DetailedModelPackageStatus | undefined;
    FailureReason?: string | undefined;
}
export type ModelPackageStatusItemList = ModelPackageStatusItem[];
export interface ModelPackageStatusDetails {
    ValidationStatuses?: ModelPackageStatusItem[] | undefined;
    ImageScanStatuses?: ModelPackageStatusItem[] | undefined;
}
export type ApprovalDescription = string;
export interface DescribeModelPackageOutput {
    ModelPackageName: string;
    ModelPackageGroupName?: string | undefined;
    ModelPackageVersion?: number | undefined;
    ModelPackageRegistrationType?: ModelPackageRegistrationType | undefined;
    ModelPackageArn: string;
    ModelPackageDescription?: string | undefined;
    CreationTime: Date;
    InferenceSpecification?: (InferenceSpecification & {
        Containers: (ModelPackageContainerDefinition & {
            ModelDataSource: ModelDataSource & {
                S3DataSource: S3ModelDataSource & {
                    S3Uri: S3ModelUri;
                    S3DataType: S3ModelDataType;
                    CompressionType: ModelCompressionType;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: InferenceHubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
            };
            ModelInput: ModelInput & {
                DataInputConfig: DataInputConfig;
            };
            AdditionalModelDataSources: (AdditionalModelDataSource & {
                ChannelName: AdditionalModelChannelName;
                S3DataSource: S3ModelDataSource & {
                    S3Uri: S3ModelUri;
                    S3DataType: S3ModelDataType;
                    CompressionType: ModelCompressionType;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: InferenceHubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
            })[];
            AdditionalS3DataSource: AdditionalS3DataSource & {
                S3DataType: AdditionalS3DataSourceDataType;
                S3Uri: S3Uri;
            };
        })[];
    }) | undefined;
    SourceAlgorithmSpecification?: (SourceAlgorithmSpecification & {
        SourceAlgorithms: (SourceAlgorithm & {
            AlgorithmName: ArnOrName;
            ModelDataSource: ModelDataSource & {
                S3DataSource: S3ModelDataSource & {
                    S3Uri: S3ModelUri;
                    S3DataType: S3ModelDataType;
                    CompressionType: ModelCompressionType;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: InferenceHubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
            };
        })[];
    }) | undefined;
    ValidationSpecification?: (ModelPackageValidationSpecification & {
        ValidationRole: RoleArn;
        ValidationProfiles: (ModelPackageValidationProfile & {
            ProfileName: EntityName;
            TransformJobDefinition: TransformJobDefinition & {
                TransformInput: TransformInput & {
                    DataSource: TransformDataSource & {
                        S3DataSource: TransformS3DataSource & {
                            S3DataType: S3DataType;
                            S3Uri: S3Uri;
                        };
                    };
                };
                TransformOutput: TransformOutput & {
                    S3OutputPath: S3Uri;
                };
                TransformResources: TransformResources & {
                    InstanceType: TransformInstanceType;
                    InstanceCount: TransformInstanceCount;
                };
            };
        })[];
    }) | undefined;
    ModelPackageStatus: ModelPackageStatus;
    ModelPackageStatusDetails: ModelPackageStatusDetails & {
        ValidationStatuses: (ModelPackageStatusItem & {
            Name: EntityName;
            Status: DetailedModelPackageStatus;
        })[];
        ImageScanStatuses: (ModelPackageStatusItem & {
            Name: EntityName;
            Status: DetailedModelPackageStatus;
        })[];
    };
    CertifyForMarketplace?: boolean | undefined;
    ModelApprovalStatus?: ModelApprovalStatus | undefined;
    CreatedBy?: UserContext | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    ModelMetrics?: (ModelMetrics & {
        ModelQuality: ModelQuality & {
            Statistics: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
            Constraints: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
        };
        ModelDataQuality: ModelDataQuality & {
            Statistics: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
            Constraints: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
        };
        Bias: Bias & {
            Report: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
            PreTrainingReport: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
            PostTrainingReport: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
        };
        Explainability: Explainability & {
            Report: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
        };
    }) | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    ApprovalDescription?: string | undefined;
    Domain?: string | undefined;
    Task?: string | undefined;
    SamplePayloadUrl?: string | undefined;
    CustomerMetadataProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    DriftCheckBaselines?: (DriftCheckBaselines & {
        Bias: DriftCheckBias & {
            ConfigFile: FileSource & {
                S3Uri: S3Uri;
            };
            PreTrainingConstraints: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
            PostTrainingConstraints: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
        };
        Explainability: DriftCheckExplainability & {
            Constraints: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
            ConfigFile: FileSource & {
                S3Uri: S3Uri;
            };
        };
        ModelQuality: DriftCheckModelQuality & {
            Statistics: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
            Constraints: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
        };
        ModelDataQuality: DriftCheckModelDataQuality & {
            Statistics: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
            Constraints: MetricsSource & {
                ContentType: ContentType;
                S3Uri: S3Uri;
            };
        };
    }) | undefined;
    AdditionalInferenceSpecifications?: (AdditionalInferenceSpecificationDefinition & {
        Name: EntityName;
        Containers: (ModelPackageContainerDefinition & {
            ModelDataSource: ModelDataSource & {
                S3DataSource: S3ModelDataSource & {
                    S3Uri: S3ModelUri;
                    S3DataType: S3ModelDataType;
                    CompressionType: ModelCompressionType;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: InferenceHubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
            };
            ModelInput: ModelInput & {
                DataInputConfig: DataInputConfig;
            };
            AdditionalModelDataSources: (AdditionalModelDataSource & {
                ChannelName: AdditionalModelChannelName;
                S3DataSource: S3ModelDataSource & {
                    S3Uri: S3ModelUri;
                    S3DataType: S3ModelDataType;
                    CompressionType: ModelCompressionType;
                    ModelAccessConfig: ModelAccessConfig & {
                        AcceptEula: AcceptEula;
                    };
                    HubAccessConfig: InferenceHubAccessConfig & {
                        HubContentArn: HubContentArn;
                    };
                };
            })[];
            AdditionalS3DataSource: AdditionalS3DataSource & {
                S3DataType: AdditionalS3DataSourceDataType;
                S3Uri: S3Uri;
            };
        })[];
    })[] | undefined;
    SkipModelValidation?: SkipModelValidation | undefined;
    SourceUri?: string | undefined;
    SecurityConfig?: (ModelPackageSecurityConfig & {
        KmsKeyId: KmsKeyId;
    }) | undefined;
    ModelCard?: ModelPackageModelCard | undefined;
    ModelLifeCycle?: (ModelLifeCycle & {
        Stage: EntityName;
        StageStatus: EntityName;
    }) | undefined;
    ManagedStorageType?: ManagedStorageType | undefined;
}
export interface DescribeModelPackageGroupInput {
    ModelPackageGroupName?: string | undefined;
}
export type ModelPackageGroupStatus = "Pending" | "InProgress" | "Completed" | "Failed" | "Deleting" | "DeleteFailed" | (string & {});
export interface DescribeModelPackageGroupOutput {
    ModelPackageGroupName: string;
    ModelPackageGroupArn: string;
    ModelPackageGroupDescription?: string | undefined;
    CreationTime: Date;
    CreatedBy: UserContext;
    ModelPackageGroupStatus: ModelPackageGroupStatus;
    ManagedConfiguration?: ManagedConfiguration | undefined;
}
export interface DescribeModelQualityJobDefinitionRequest {
    JobDefinitionName?: string | undefined;
}
export interface DescribeModelQualityJobDefinitionResponse {
    JobDefinitionArn: string;
    JobDefinitionName: string;
    CreationTime: Date;
    ModelQualityBaselineConfig?: ModelQualityBaselineConfig | undefined;
    ModelQualityAppSpecification: ModelQualityAppSpecification & {
        ImageUri: ImageUri;
    };
    ModelQualityJobInput: ModelQualityJobInput & {
        GroundTruthS3Input: MonitoringGroundTruthS3Input;
        EndpointInput: EndpointInput & {
            EndpointName: EndpointName;
            LocalPath: ProcessingLocalPath;
        };
        BatchTransformInput: BatchTransformInput & {
            DataCapturedDestinationS3Uri: DestinationS3Uri;
            DatasetFormat: MonitoringDatasetFormat;
            LocalPath: ProcessingLocalPath;
        };
    };
    ModelQualityJobOutputConfig: MonitoringOutputConfig & {
        MonitoringOutputs: (MonitoringOutput & {
            S3Output: MonitoringS3Output & {
                S3Uri: MonitoringS3Uri;
                LocalPath: ProcessingLocalPath;
            };
        })[];
    };
    JobResources: MonitoringResources & {
        ClusterConfig: MonitoringClusterConfig & {
            InstanceCount: ProcessingInstanceCount;
            InstanceType: ProcessingInstanceType;
            VolumeSizeInGB: ProcessingVolumeSizeInGB;
        };
    };
    NetworkConfig?: (MonitoringNetworkConfig & {
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
    }) | undefined;
    RoleArn: string;
    StoppingCondition?: (MonitoringStoppingCondition & {
        MaxRuntimeInSeconds: MonitoringMaxRuntimeInSeconds;
    }) | undefined;
}
export interface DescribeMonitoringScheduleRequest {
    MonitoringScheduleName?: string | undefined;
}
export type ScheduleStatus = "Pending" | "Failed" | "Scheduled" | "Stopped" | (string & {});
export type ExecutionStatus = "Pending" | "Completed" | "CompletedWithViolations" | "InProgress" | "Failed" | "Stopping" | "Stopped" | (string & {});
export interface MonitoringExecutionSummary {
    MonitoringScheduleName?: string | undefined;
    ScheduledTime?: Date | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    MonitoringExecutionStatus?: ExecutionStatus | undefined;
    ProcessingJobArn?: string | undefined;
    EndpointName?: string | undefined;
    FailureReason?: string | undefined;
    MonitoringJobDefinitionName?: string | undefined;
    MonitoringType?: MonitoringType | undefined;
}
export interface DescribeMonitoringScheduleResponse {
    MonitoringScheduleArn: string;
    MonitoringScheduleName: string;
    MonitoringScheduleStatus: ScheduleStatus;
    MonitoringType?: MonitoringType | undefined;
    FailureReason?: string | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    MonitoringScheduleConfig: MonitoringScheduleConfig & {
        ScheduleConfig: ScheduleConfig & {
            ScheduleExpression: ScheduleExpression;
        };
        MonitoringJobDefinition: MonitoringJobDefinition & {
            MonitoringInputs: (MonitoringInput & {
                EndpointInput: EndpointInput & {
                    EndpointName: EndpointName;
                    LocalPath: ProcessingLocalPath;
                };
                BatchTransformInput: BatchTransformInput & {
                    DataCapturedDestinationS3Uri: DestinationS3Uri;
                    DatasetFormat: MonitoringDatasetFormat;
                    LocalPath: ProcessingLocalPath;
                };
            })[];
            MonitoringOutputConfig: MonitoringOutputConfig & {
                MonitoringOutputs: (MonitoringOutput & {
                    S3Output: MonitoringS3Output & {
                        S3Uri: MonitoringS3Uri;
                        LocalPath: ProcessingLocalPath;
                    };
                })[];
            };
            MonitoringResources: MonitoringResources & {
                ClusterConfig: MonitoringClusterConfig & {
                    InstanceCount: ProcessingInstanceCount;
                    InstanceType: ProcessingInstanceType;
                    VolumeSizeInGB: ProcessingVolumeSizeInGB;
                };
            };
            MonitoringAppSpecification: MonitoringAppSpecification & {
                ImageUri: ImageUri;
            };
            RoleArn: RoleArn;
            StoppingCondition: MonitoringStoppingCondition & {
                MaxRuntimeInSeconds: MonitoringMaxRuntimeInSeconds;
            };
            NetworkConfig: NetworkConfig & {
                VpcConfig: VpcConfig & {
                    SecurityGroupIds: VpcSecurityGroupIds;
                    Subnets: Subnets;
                };
            };
        };
    };
    EndpointName?: string | undefined;
    LastMonitoringExecutionSummary?: (MonitoringExecutionSummary & {
        MonitoringScheduleName: MonitoringScheduleName;
        ScheduledTime: Date;
        CreationTime: Date;
        LastModifiedTime: Date;
        MonitoringExecutionStatus: ExecutionStatus;
    }) | undefined;
}
export interface DescribeNotebookInstanceInput {
    NotebookInstanceName?: string | undefined;
}
export type NotebookInstanceStatus = "Pending" | "InService" | "Stopping" | "Stopped" | "Failed" | "Deleting" | "Updating" | "PendingMaintenance" | "InMaintenance" | (string & {});
export type NetworkInterfaceId = string;
export interface DescribeNotebookInstanceOutput {
    NotebookInstanceArn?: string | undefined;
    NotebookInstanceName?: string | undefined;
    NotebookInstanceStatus?: NotebookInstanceStatus | undefined;
    FailureReason?: string | undefined;
    Url?: string | undefined;
    InstanceType?: InstanceType | undefined;
    IpAddressType?: IPAddressType | undefined;
    SubnetId?: string | undefined;
    SecurityGroups?: string[] | undefined;
    RoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    NetworkInterfaceId?: string | undefined;
    LastModifiedTime?: Date | undefined;
    CreationTime?: Date | undefined;
    NotebookInstanceLifecycleConfigName?: string | undefined;
    DirectInternetAccess?: DirectInternetAccess | undefined;
    VolumeSizeInGB?: number | undefined;
    AcceleratorTypes?: NotebookInstanceAcceleratorType[] | undefined;
    DefaultCodeRepository?: string | undefined;
    AdditionalCodeRepositories?: string[] | undefined;
    RootAccess?: RootAccess | undefined;
    PlatformIdentifier?: string | undefined;
    InstanceMetadataServiceConfiguration?: (InstanceMetadataServiceConfiguration & {
        MinimumInstanceMetadataServiceVersion: MinimumInstanceMetadataServiceVersion;
    }) | undefined;
}
export interface DescribeNotebookInstanceLifecycleConfigInput {
    NotebookInstanceLifecycleConfigName?: string | undefined;
}
export interface DescribeNotebookInstanceLifecycleConfigOutput {
    NotebookInstanceLifecycleConfigArn?: string | undefined;
    NotebookInstanceLifecycleConfigName?: string | undefined;
    OnCreate?: NotebookInstanceLifecycleHook[] | undefined;
    OnStart?: NotebookInstanceLifecycleHook[] | undefined;
    LastModifiedTime?: Date | undefined;
    CreationTime?: Date | undefined;
}
export interface DescribeOptimizationJobRequest {
    OptimizationJobName?: string | undefined;
}
export type OptimizationJobStatus = "INPROGRESS" | "COMPLETED" | "FAILED" | "STARTING" | "STOPPING" | "STOPPED" | (string & {});
export interface OptimizationOutput {
    RecommendedInferenceImage?: string | undefined;
}
export interface DescribeOptimizationJobResponse {
    OptimizationJobArn: string;
    OptimizationJobStatus: OptimizationJobStatus;
    OptimizationStartTime?: Date | undefined;
    OptimizationEndTime?: Date | undefined;
    CreationTime: Date;
    LastModifiedTime: Date;
    FailureReason?: string | undefined;
    OptimizationJobName: string;
    ModelSource: OptimizationJobModelSource & {
        S3: OptimizationJobModelSourceS3 & {
            ModelAccessConfig: OptimizationModelAccessConfig & {
                AcceptEula: OptimizationModelAcceptEula;
            };
        };
    };
    OptimizationEnvironment?: {
        [key: string]: string | undefined;
    } | undefined;
    DeploymentInstanceType: OptimizationJobDeploymentInstanceType;
    MaxInstanceCount?: number | undefined;
    OptimizationConfigs: OptimizationConfig[];
    OutputConfig: OptimizationJobOutputConfig & {
        S3OutputLocation: S3Uri;
    };
    OptimizationOutput?: OptimizationOutput | undefined;
    RoleArn: string;
    StoppingCondition: StoppingCondition;
    VpcConfig?: (OptimizationVpcConfig & {
        SecurityGroupIds: OptimizationVpcSecurityGroupIds;
        Subnets: OptimizationVpcSubnets;
    }) | undefined;
    TrainingPlanArns?: string[] | undefined;
}
export interface DescribePartnerAppRequest {
    Arn?: string | undefined;
    IncludeAvailableUpgrade?: boolean | undefined;
}
export type PartnerAppStatus = "Creating" | "Updating" | "Deleting" | "Available" | "Failed" | "UpdateFailed" | "Deleted" | (string & {});
export interface ErrorInfo {
    Code?: string | undefined;
    Reason?: string | undefined;
}
export type MajorMinorVersion = string;
export type ReleaseNotesList = string[];
export interface AvailableUpgrade {
    Version?: string | undefined;
    ReleaseNotes?: string[] | undefined;
}
export type ApplicationArn = string;
export interface IdcConfigOutput {
    InstanceArn: string;
    ApplicationArn?: string | undefined;
}
export interface DescribePartnerAppResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    Type?: PartnerAppType | undefined;
    Status?: PartnerAppStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    ExecutionRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    BaseUrl?: string | undefined;
    MaintenanceConfig?: PartnerAppMaintenanceConfig | undefined;
    Tier?: string | undefined;
    Version?: string | undefined;
    ApplicationConfig?: PartnerAppConfig | undefined;
    AuthType?: PartnerAppAuthType | undefined;
    EnableIamSessionBasedIdentity?: boolean | undefined;
    Error?: ErrorInfo | undefined;
    EnableAutoMinorVersionUpgrade?: boolean | undefined;
    CurrentVersionEolDate?: Date | undefined;
    AvailableUpgrade?: AvailableUpgrade | undefined;
    IdcConfig?: IdcConfigOutput | undefined;
}
export type PipelineNameOrArn = string;
export type PipelineVersionId = number;
export interface DescribePipelineRequest {
    PipelineName?: string | undefined;
    PipelineVersionId?: number | undefined;
    PipelineVersionAlias?: string | undefined;
}
export type PipelineStatus = "Active" | "Deleting" | (string & {});
export type PipelineVersionName = string;
export type PipelineVersionDescription = string;
export interface DescribePipelineResponse {
    PipelineArn?: string | undefined;
    PipelineName?: string | undefined;
    PipelineDisplayName?: string | undefined;
    PipelineDefinition?: string | undefined;
    PipelineDescription?: string | undefined;
    RoleArn?: string | undefined;
    PipelineStatus?: PipelineStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastRunTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedBy?: UserContext | undefined;
    ParallelismConfiguration?: (ParallelismConfiguration & {
        MaxParallelExecutionSteps: MaxParallelExecutionSteps;
    }) | undefined;
    PipelineVersionDisplayName?: string | undefined;
    PipelineVersionDescription?: string | undefined;
    PipelineVersionAliases?: string[] | undefined;
}
export type PipelineExecutionArn = string;
export interface DescribePipelineDefinitionForExecutionRequest {
    PipelineExecutionArn?: string | undefined;
}
export interface DescribePipelineDefinitionForExecutionResponse {
    PipelineDefinition?: string | undefined;
    CreationTime?: Date | undefined;
}
export interface DescribePipelineExecutionRequest {
    PipelineExecutionArn?: string | undefined;
}
export type PipelineExecutionName = string;
export type PipelineExecutionStatus = "Executing" | "Stopping" | "Stopped" | "Failed" | "Succeeded" | "CompletedWithFailures" | (string & {});
export type PipelineExecutionDescription = string;
export interface PipelineExperimentConfig {
    ExperimentName?: string | undefined;
    TrialName?: string | undefined;
}
export type PipelineExecutionFailureReason = string;
export interface SelectedStep {
    StepName?: string | undefined;
}
export type SelectedStepList = SelectedStep[];
export interface SelectiveExecutionConfig {
    SourcePipelineExecutionArn?: string | undefined;
    SelectedSteps?: SelectedStep[] | undefined;
}
export type MLflowArn = string;
export type MlflowExperimentEntityName = string;
export interface MLflowConfiguration {
    MlflowResourceArn?: string | undefined;
    MlflowExperimentName?: string | undefined;
}
export interface DescribePipelineExecutionResponse {
    PipelineArn?: string | undefined;
    PipelineExecutionArn?: string | undefined;
    PipelineExecutionDisplayName?: string | undefined;
    PipelineExecutionStatus?: PipelineExecutionStatus | undefined;
    PipelineExecutionDescription?: string | undefined;
    PipelineExperimentConfig?: PipelineExperimentConfig | undefined;
    FailureReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedBy?: UserContext | undefined;
    ParallelismConfiguration?: (ParallelismConfiguration & {
        MaxParallelExecutionSteps: MaxParallelExecutionSteps;
    }) | undefined;
    SelectiveExecutionConfig?: (SelectiveExecutionConfig & {
        SelectedSteps: (SelectedStep & {
            StepName: String256;
        })[];
    }) | undefined;
    PipelineVersionId?: number | undefined;
    MLflowConfig?: MLflowConfiguration | undefined;
    PipelineVersionAliases?: string[] | undefined;
    RoleArn?: string | undefined;
}
export interface DescribeProcessingJobRequest {
    ProcessingJobName?: string | undefined;
}
export type ProcessingJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export type ExitMessage = string;
export interface DescribeProcessingJobResponse {
    ProcessingInputs?: (ProcessingInput & {
        InputName: string;
        S3Input: ProcessingS3Input & {
            S3Uri: S3Uri;
            S3DataType: ProcessingS3DataType;
        };
        DatasetDefinition: DatasetDefinition & {
            AthenaDatasetDefinition: AthenaDatasetDefinition & {
                Catalog: AthenaCatalog;
                Database: AthenaDatabase;
                QueryString: AthenaQueryString;
                OutputS3Uri: S3Uri;
                OutputFormat: AthenaResultFormat;
            };
            RedshiftDatasetDefinition: RedshiftDatasetDefinition & {
                ClusterId: RedshiftClusterId;
                Database: RedshiftDatabase;
                DbUser: RedshiftUserName;
                QueryString: RedshiftQueryString;
                ClusterRoleArn: RoleArn;
                OutputS3Uri: S3Uri;
                OutputFormat: RedshiftResultFormat;
            };
        };
    })[] | undefined;
    ProcessingOutputConfig?: (ProcessingOutputConfig & {
        Outputs: (ProcessingOutput & {
            OutputName: string;
            S3Output: ProcessingS3Output & {
                S3Uri: S3Uri;
                S3UploadMode: ProcessingS3UploadMode;
            };
            FeatureStoreOutput: ProcessingFeatureStoreOutput & {
                FeatureGroupName: FeatureGroupName;
            };
        })[];
    }) | undefined;
    ProcessingJobName: string;
    ProcessingResources: ProcessingResources & {
        ClusterConfig: ProcessingClusterConfig & {
            VolumeSizeInGB: ProcessingVolumeSizeInGB;
            InstancePreferences: (ProcessingInstancePreference & {
                InstanceType: ProcessingInstanceType;
            })[];
        };
    };
    StoppingCondition?: (ProcessingStoppingCondition & {
        MaxRuntimeInSeconds: ProcessingMaxRuntimeInSeconds;
    }) | undefined;
    AppSpecification: AppSpecification & {
        ImageUri: ImageUri;
    };
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    NetworkConfig?: (NetworkConfig & {
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
    }) | undefined;
    RoleArn?: string | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
    ProcessingJobArn: string;
    ProcessingJobStatus: ProcessingJobStatus;
    ExitMessage?: string | undefined;
    FailureReason?: string | undefined;
    ProcessingEndTime?: Date | undefined;
    ProcessingStartTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    CreationTime: Date;
    MonitoringScheduleArn?: string | undefined;
    AutoMLJobArn?: string | undefined;
    TrainingJobArn?: string | undefined;
}
export interface DescribeProjectInput {
    ProjectName?: string | undefined;
}
export type ProvisionedProductStatusMessage = string;
export interface ServiceCatalogProvisionedProductDetails {
    ProvisionedProductId?: string | undefined;
    ProvisionedProductStatusMessage?: string | undefined;
}
export type ProjectStatus = "Pending" | "CreateInProgress" | "CreateCompleted" | "CreateFailed" | "DeleteInProgress" | "DeleteFailed" | "DeleteCompleted" | "UpdateInProgress" | "UpdateCompleted" | "UpdateFailed" | (string & {});
export interface CfnStackParameter {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type CfnStackParameters = CfnStackParameter[];
export type CfnStackName = string;
export type CfnStackId = string;
export type CfnStackStatusMessage = string;
export interface CfnStackDetail {
    Name?: string | undefined;
    Id?: string | undefined;
    StatusMessage?: string | undefined;
}
export interface CfnTemplateProviderDetail {
    TemplateName?: string | undefined;
    TemplateURL?: string | undefined;
    RoleARN?: string | undefined;
    Parameters?: CfnStackParameter[] | undefined;
    StackDetail?: CfnStackDetail | undefined;
}
export interface TemplateProviderDetail {
    CfnTemplateProviderDetail?: CfnTemplateProviderDetail | undefined;
}
export type TemplateProviderDetailList = TemplateProviderDetail[];
export interface DescribeProjectOutput {
    ProjectArn: string;
    ProjectName: string;
    ProjectId: string;
    ProjectDescription?: string | undefined;
    ServiceCatalogProvisioningDetails?: (ServiceCatalogProvisioningDetails & {
        ProductId: ServiceCatalogEntityId;
    }) | undefined;
    ServiceCatalogProvisionedProductDetails?: ServiceCatalogProvisionedProductDetails | undefined;
    ProjectStatus: ProjectStatus;
    TemplateProviderDetails?: (TemplateProviderDetail & {
        CfnTemplateProviderDetail: CfnTemplateProviderDetail & {
            TemplateName: CfnTemplateName;
            TemplateURL: CfnTemplateURL;
            Parameters: (CfnStackParameter & {
                Key: CfnStackParameterKey;
            })[];
            StackDetail: CfnStackDetail & {
                StatusMessage: CfnStackStatusMessage;
            };
        };
    })[] | undefined;
    CreatedBy?: UserContext | undefined;
    CreationTime: Date;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export type ReservedCapacityArn = string;
export interface DescribeReservedCapacityRequest {
    ReservedCapacityArn?: string | undefined;
}
export type ReservedCapacityType = "UltraServer" | "Instance" | (string & {});
export type ReservedCapacityStatus = "Pending" | "Active" | "Scheduled" | "Expired" | "Failed" | (string & {});
export type AvailabilityZone = string;
export type ReservedCapacityDurationHours = number;
export type ReservedCapacityDurationMinutes = number;
export type ReservedCapacityInstanceType = "ml.p4d.24xlarge" | "ml.p5.48xlarge" | "ml.p5e.48xlarge" | "ml.p5en.48xlarge" | "ml.trn1.32xlarge" | "ml.trn2.48xlarge" | "ml.p6-b200.48xlarge" | "ml.p4de.24xlarge" | "ml.p6e-gb200.36xlarge" | "ml.p5.4xlarge" | "ml.p6-b300.48xlarge" | (string & {});
export type TotalInstanceCount = number;
export type AvailableInstanceCount = number;
export type InUseInstanceCount = number;
export type UltraServerType = string;
export type UltraServerCount = number;
export type AvailableSpareInstanceCount = number;
export type UnhealthyInstanceCount = number;
export interface UltraServerSummary {
    UltraServerType?: string | undefined;
    InstanceType?: ReservedCapacityInstanceType | undefined;
    UltraServerCount?: number | undefined;
    AvailableSpareInstanceCount?: number | undefined;
    UnhealthyInstanceCount?: number | undefined;
}
export interface DescribeReservedCapacityResponse {
    ReservedCapacityArn: string;
    ReservedCapacityType?: ReservedCapacityType | undefined;
    Status?: ReservedCapacityStatus | undefined;
    AvailabilityZone?: string | undefined;
    DurationHours?: number | undefined;
    DurationMinutes?: number | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    InstanceType: ReservedCapacityInstanceType;
    TotalInstanceCount: number;
    AvailableInstanceCount?: number | undefined;
    InUseInstanceCount?: number | undefined;
    UltraServerSummary?: (UltraServerSummary & {
        UltraServerType: UltraServerType;
        InstanceType: ReservedCapacityInstanceType;
    }) | undefined;
}
export interface DescribeSpaceRequest {
    DomainId?: string | undefined;
    SpaceName?: string | undefined;
}
export type EfsUid = string;
export type SpaceStatus = "Deleting" | "Failed" | "InService" | "Pending" | "Updating" | "Update_Failed" | "Delete_Failed" | (string & {});
export interface DescribeSpaceResponse {
    DomainId?: string | undefined;
    SpaceArn?: string | undefined;
    SpaceName?: string | undefined;
    HomeEfsFileSystemUid?: string | undefined;
    Status?: SpaceStatus | undefined;
    LastModifiedTime?: Date | undefined;
    CreationTime?: Date | undefined;
    FailureReason?: string | undefined;
    SpaceSettings?: (SpaceSettings & {
        JupyterServerAppSettings: JupyterServerAppSettings & {
            CodeRepositories: (CodeRepository & {
                RepositoryUrl: RepositoryUrl;
            })[];
        };
        KernelGatewayAppSettings: KernelGatewayAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
        };
        JupyterLabAppSettings: SpaceJupyterLabAppSettings & {
            CodeRepositories: (CodeRepository & {
                RepositoryUrl: RepositoryUrl;
            })[];
        };
        SpaceStorageSettings: SpaceStorageSettings & {
            EbsStorageSettings: EbsStorageSettings & {
                EbsVolumeSizeInGb: SpaceEbsVolumeSizeInGb;
            };
        };
    }) | undefined;
    OwnershipSettings?: (OwnershipSettings & {
        OwnerUserProfileName: UserProfileName;
    }) | undefined;
    SpaceSharingSettings?: (SpaceSharingSettings & {
        SharingType: SharingType;
    }) | undefined;
    SpaceDisplayName?: string | undefined;
    Url?: string | undefined;
}
export interface DescribeStudioLifecycleConfigRequest {
    StudioLifecycleConfigName?: string | undefined;
}
export interface DescribeStudioLifecycleConfigResponse {
    StudioLifecycleConfigArn?: string | undefined;
    StudioLifecycleConfigName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    StudioLifecycleConfigContent?: string | undefined;
    StudioLifecycleConfigAppType?: StudioLifecycleConfigAppType | undefined;
}
export interface DescribeSubscribedWorkteamRequest {
    WorkteamArn?: string | undefined;
}
export interface SubscribedWorkteam {
    WorkteamArn?: string | undefined;
    MarketplaceTitle?: string | undefined;
    SellerName?: string | undefined;
    MarketplaceDescription?: string | undefined;
    ListingId?: string | undefined;
}
export interface DescribeSubscribedWorkteamResponse {
    SubscribedWorkteam: SubscribedWorkteam & {
        WorkteamArn: WorkteamArn;
    };
}
export interface DescribeTrainingJobRequest {
    TrainingJobName?: string | undefined;
}
export type SecondaryStatus = "Starting" | "LaunchingMLInstances" | "PreparingTrainingStack" | "Downloading" | "DownloadingTrainingImage" | "Training" | "Uploading" | "Stopping" | "Stopped" | "MaxRuntimeExceeded" | "Completed" | "Failed" | "Interrupted" | "MaxWaitTimeExceeded" | "Updating" | "Restarting" | "Pending" | (string & {});
export type WarmPoolResourceStatus = "Available" | "Terminated" | "Reused" | "InUse" | (string & {});
export type ResourceRetainedBillableTimeInSeconds = number;
export interface WarmPoolStatus {
    Status?: WarmPoolResourceStatus | undefined;
    ResourceRetainedBillableTimeInSeconds?: number | undefined;
    ReusedByJob?: string | undefined;
}
export type StatusMessage = string;
export interface SecondaryStatusTransition {
    Status?: SecondaryStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    StatusMessage?: string | undefined;
}
export type SecondaryStatusTransitions = SecondaryStatusTransition[];
export interface MetricData {
    MetricName?: string | undefined;
    Value?: number | undefined;
    Timestamp?: Date | undefined;
}
export type FinalMetricDataList = MetricData[];
export type TrainingTimeInSeconds = number;
export type BillableTimeInSeconds = number;
export type BillableTokenCount = number;
export type RuleEvaluationStatus = "InProgress" | "NoIssuesFound" | "IssuesFound" | "Error" | "Stopping" | "Stopped" | (string & {});
export type StatusDetails = string;
export interface DebugRuleEvaluationStatus {
    RuleConfigurationName?: string | undefined;
    RuleEvaluationJobArn?: string | undefined;
    RuleEvaluationStatus?: RuleEvaluationStatus | undefined;
    StatusDetails?: string | undefined;
    LastModifiedTime?: Date | undefined;
}
export type DebugRuleEvaluationStatuses = DebugRuleEvaluationStatus[];
export interface ProfilerRuleEvaluationStatus {
    RuleConfigurationName?: string | undefined;
    RuleEvaluationJobArn?: string | undefined;
    RuleEvaluationStatus?: RuleEvaluationStatus | undefined;
    StatusDetails?: string | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ProfilerRuleEvaluationStatuses = ProfilerRuleEvaluationStatus[];
export type ProfilingStatus = "Enabled" | "Disabled" | (string & {});
export type MlflowExperimentId = string;
export type MlflowRunId = string;
export interface MlflowDetails {
    MlflowExperimentId?: string | undefined;
    MlflowRunId?: string | undefined;
}
export type TotalStepCountPerEpoch = number;
export type TrainingStepIndex = number;
export type TrainingEpochIndex = number;
export type TrainingEpochCount = number;
export interface TrainingProgressInfo {
    TotalStepCountPerEpoch?: number | undefined;
    CurrentStep?: number | undefined;
    CurrentEpoch?: number | undefined;
    MaxEpoch?: number | undefined;
}
export interface DescribeTrainingJobResponse {
    TrainingJobName: string;
    TrainingJobArn: string;
    TuningJobArn?: string | undefined;
    LabelingJobArn?: string | undefined;
    AutoMLJobArn?: string | undefined;
    ModelArtifacts: ModelArtifacts & {
        S3ModelArtifacts: S3Uri;
    };
    TrainingJobStatus: TrainingJobStatus;
    SecondaryStatus: SecondaryStatus;
    FailureReason?: string | undefined;
    HyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AlgorithmSpecification?: (AlgorithmSpecification & {
        TrainingInputMode: TrainingInputMode;
        MetricDefinitions: (MetricDefinition & {
            Name: MetricName;
            Regex: MetricRegex;
        })[];
        TrainingImageConfig: TrainingImageConfig & {
            TrainingRepositoryAccessMode: TrainingRepositoryAccessMode;
            TrainingRepositoryAuthConfig: TrainingRepositoryAuthConfig & {
                TrainingRepositoryCredentialsProviderArn: TrainingRepositoryCredentialsProviderArn;
            };
        };
    }) | undefined;
    RoleArn?: string | undefined;
    InputDataConfig?: (Channel & {
        ChannelName: ChannelName;
        DataSource: DataSource & {
            S3DataSource: S3DataSource & {
                S3DataType: S3DataType;
                S3Uri: S3Uri;
                ModelAccessConfig: ModelAccessConfig & {
                    AcceptEula: AcceptEula;
                };
                HubAccessConfig: HubAccessConfig & {
                    HubContentArn: HubContentArn;
                };
            };
            FileSystemDataSource: FileSystemDataSource & {
                FileSystemId: FileSystemId;
                FileSystemAccessMode: FileSystemAccessMode;
                FileSystemType: FileSystemType;
                DirectoryPath: DirectoryPath;
            };
        };
        ShuffleConfig: ShuffleConfig & {
            Seed: Seed;
        };
    })[] | undefined;
    OutputDataConfig?: (OutputDataConfig & {
        S3OutputPath: S3Uri;
    }) | undefined;
    ResourceConfig?: (ResourceConfig & {
        InstanceGroups: (InstanceGroup & {
            InstanceType: TrainingInstanceType;
            InstanceCount: TrainingInstanceCount;
            InstanceGroupName: InstanceGroupName;
        })[];
        InstancePlacementConfig: InstancePlacementConfig & {
            PlacementSpecifications: (PlacementSpecification & {
                InstanceCount: TrainingInstanceCount;
            })[];
        };
        InstancePreferences: (InstancePreference & {
            InstanceType: TrainingInstanceType;
        })[];
    }) | undefined;
    WarmPoolStatus?: (WarmPoolStatus & {
        Status: WarmPoolResourceStatus;
    }) | undefined;
    VpcConfig?: (VpcConfig & {
        SecurityGroupIds: VpcSecurityGroupIds;
        Subnets: Subnets;
    }) | undefined;
    StoppingCondition: StoppingCondition;
    CreationTime: Date;
    TrainingStartTime?: Date | undefined;
    TrainingEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    SecondaryStatusTransitions?: (SecondaryStatusTransition & {
        Status: SecondaryStatus;
        StartTime: Date;
    })[] | undefined;
    FinalMetricDataList?: MetricData[] | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    EnableInterContainerTrafficEncryption?: boolean | undefined;
    EnableManagedSpotTraining?: boolean | undefined;
    CheckpointConfig?: (CheckpointConfig & {
        S3Uri: S3Uri;
    }) | undefined;
    TrainingTimeInSeconds?: number | undefined;
    BillableTimeInSeconds?: number | undefined;
    BillableTokenCount?: number | undefined;
    DebugHookConfig?: (DebugHookConfig & {
        S3OutputPath: S3Uri;
    }) | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
    DebugRuleConfigurations?: (DebugRuleConfiguration & {
        RuleConfigurationName: RuleConfigurationName;
        RuleEvaluatorImage: AlgorithmImage;
    })[] | undefined;
    TensorBoardOutputConfig?: (TensorBoardOutputConfig & {
        S3OutputPath: S3Uri;
    }) | undefined;
    DebugRuleEvaluationStatuses?: DebugRuleEvaluationStatus[] | undefined;
    ProfilerConfig?: ProfilerConfig | undefined;
    ProfilerRuleConfigurations?: (ProfilerRuleConfiguration & {
        RuleConfigurationName: RuleConfigurationName;
        RuleEvaluatorImage: AlgorithmImage;
    })[] | undefined;
    ProfilerRuleEvaluationStatuses?: ProfilerRuleEvaluationStatus[] | undefined;
    ProfilingStatus?: ProfilingStatus | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    RetryStrategy?: (RetryStrategy & {
        MaximumRetryAttempts: MaximumRetryAttempts;
    }) | undefined;
    RemoteDebugConfig?: RemoteDebugConfig | undefined;
    InfraCheckConfig?: InfraCheckConfig | undefined;
    ServerlessJobConfig?: ServerlessJobConfig | undefined;
    MlflowConfig?: MlflowConfig | undefined;
    ModelPackageConfig?: ModelPackageConfig | undefined;
    MlflowDetails?: MlflowDetails | undefined;
    ProgressInfo?: TrainingProgressInfo | undefined;
    OutputModelPackageArn?: string | undefined;
}
export type TrainingPlanNameOrArn = string;
export interface DescribeTrainingPlanRequest {
    TrainingPlanName?: string | undefined;
}
export type TrainingPlanStatus = "Pending" | "Active" | "Scheduled" | "Expired" | "Failed" | (string & {});
export type TrainingPlanStatusMessage = string;
export type TrainingPlanDurationHours = number;
export type TrainingPlanDurationMinutes = number;
export type CurrencyCode = string;
export type SageMakerResourceName = "training-job" | "hyperpod-cluster" | "endpoint" | "studio-apps" | (string & {});
export type SageMakerResourceNames = SageMakerResourceName[];
export type AvailabilityZoneId = string;
export interface ReservedCapacitySummary {
    ReservedCapacityArn?: string | undefined;
    ReservedCapacityType?: ReservedCapacityType | undefined;
    UltraServerType?: string | undefined;
    UltraServerCount?: number | undefined;
    InstanceType?: ReservedCapacityInstanceType | undefined;
    TotalInstanceCount?: number | undefined;
    Status?: ReservedCapacityStatus | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    DurationHours?: number | undefined;
    DurationMinutes?: number | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type ReservedCapacitySummaries = ReservedCapacitySummary[];
export interface DescribeTrainingPlanResponse {
    TrainingPlanArn: string;
    TrainingPlanName: string;
    Status: TrainingPlanStatus;
    StatusMessage?: string | undefined;
    DurationHours?: number | undefined;
    DurationMinutes?: number | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    UpfrontFee?: string | undefined;
    CurrencyCode?: string | undefined;
    TotalInstanceCount?: number | undefined;
    AvailableInstanceCount?: number | undefined;
    InUseInstanceCount?: number | undefined;
    UnhealthyInstanceCount?: number | undefined;
    AvailableSpareInstanceCount?: number | undefined;
    TotalUltraServerCount?: number | undefined;
    TargetResources?: SageMakerResourceName[] | undefined;
    ReservedCapacitySummaries?: (ReservedCapacitySummary & {
        ReservedCapacityArn: ReservedCapacityArn;
        InstanceType: ReservedCapacityInstanceType;
        TotalInstanceCount: TotalInstanceCount;
        Status: ReservedCapacityStatus;
    })[] | undefined;
}
export interface DescribeTrainingPlanExtensionHistoryRequest {
    TrainingPlanArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TrainingPlanExtensionOfferingId = string;
export type TrainingPlanExtensionDurationHours = number;
export interface TrainingPlanExtension {
    TrainingPlanExtensionOfferingId?: string | undefined;
    ExtendedAt?: Date | undefined;
    StartDate?: Date | undefined;
    EndDate?: Date | undefined;
    Status?: string | undefined;
    PaymentStatus?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    DurationHours?: number | undefined;
    UpfrontFee?: string | undefined;
    CurrencyCode?: string | undefined;
}
export type TrainingPlanExtensions = TrainingPlanExtension[];
export interface DescribeTrainingPlanExtensionHistoryResponse {
    TrainingPlanExtensions: (TrainingPlanExtension & {
        TrainingPlanExtensionOfferingId: TrainingPlanExtensionOfferingId;
    })[];
    NextToken?: string | undefined;
}
export interface DescribeTrainingSessionRequest {
    TrainingSessionName?: string | undefined;
}
export type TrainingSessionStatus = "Created" | "Blocked" | "Running" | "Failed" | "Scheduled" | "Stopping" | "Stopped" | "Expired" | "Deleting" | "DeletionFailed" | (string & {});
export type JavaInteger = number;
export type JavaLong = number;
export interface BillableTokenUsage {
    PrefillTokenCount?: number | undefined;
    SampleTokenCount?: number | undefined;
    TrainingTokenCount?: number | undefined;
}
export interface TrainingSessionDetail {
    TrainingSessionArn?: string | undefined;
    TrainingSessionName?: string | undefined;
    TrainingSessionStatus?: TrainingSessionStatus | undefined;
    ModelPackageGroupArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    EndTime?: Date | undefined;
    ErrorDetails?: string | undefined;
    LastReceivedSequenceNumber?: number | undefined;
    BillableTokenUsage?: BillableTokenUsage | undefined;
    VpcConfig?: VpcConfig | undefined;
    RoleArn?: string | undefined;
    LoraConfig?: LoraConfig | undefined;
    ModelConfig?: TrainingSessionModelConfig | undefined;
    OutputConfig?: TrainingSessionOutputConfig | undefined;
    Tags?: Tag[] | undefined;
}
export interface DescribeTrainingSessionResponse {
    TrainingSessionDetail: TrainingSessionDetail & {
        TrainingSessionArn: TrainingSessionArn;
        TrainingSessionName: TrainingSessionName;
        TrainingSessionStatus: TrainingSessionStatus;
        CreationTime: Date;
        VpcConfig: VpcConfig & {
            SecurityGroupIds: VpcSecurityGroupIds;
            Subnets: Subnets;
        };
        LoraConfig: LoraConfig & {
            Rank: Rank;
            Alpha: LoraAlpha;
        };
        ModelConfig: TrainingSessionModelConfig & {
            BaseModelArn: BaseModelArn;
        };
        OutputConfig: TrainingSessionOutputConfig & {
            S3Location: TrainingSessionS3Location & {
                Path: OutputS3Path;
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    };
}
export interface DescribeTransformJobRequest {
    TransformJobName?: string | undefined;
}
export type TransformJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export interface DescribeTransformJobResponse {
    TransformJobName: string;
    TransformJobArn: string;
    TransformJobStatus: TransformJobStatus;
    FailureReason?: string | undefined;
    ModelName: string;
    MaxConcurrentTransforms?: number | undefined;
    ModelClientConfig?: ModelClientConfig | undefined;
    MaxPayloadInMB?: number | undefined;
    BatchStrategy?: BatchStrategy | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    TransformInput: TransformInput & {
        DataSource: TransformDataSource & {
            S3DataSource: TransformS3DataSource & {
                S3DataType: S3DataType;
                S3Uri: S3Uri;
            };
        };
    };
    TransformOutput?: (TransformOutput & {
        S3OutputPath: S3Uri;
    }) | undefined;
    DataCaptureConfig?: (BatchDataCaptureConfig & {
        DestinationS3Uri: S3Uri;
    }) | undefined;
    TransformResources: TransformResources & {
        InstanceType: TransformInstanceType;
        InstanceCount: TransformInstanceCount;
    };
    CreationTime: Date;
    TransformStartTime?: Date | undefined;
    TransformEndTime?: Date | undefined;
    LabelingJobArn?: string | undefined;
    AutoMLJobArn?: string | undefined;
    DataProcessing?: DataProcessing | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
}
export interface DescribeTrialRequest {
    TrialName?: string | undefined;
}
export type TrialSourceArn = string;
export interface TrialSource {
    SourceArn?: string | undefined;
    SourceType?: string | undefined;
}
export interface DescribeTrialResponse {
    TrialName?: string | undefined;
    TrialArn?: string | undefined;
    DisplayName?: string | undefined;
    ExperimentName?: string | undefined;
    Source?: (TrialSource & {
        SourceArn: TrialSourceArn;
    }) | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    MetadataProperties?: MetadataProperties | undefined;
}
export interface DescribeTrialComponentRequest {
    TrialComponentName?: string | undefined;
}
export type TrialComponentSourceArn = string;
export interface TrialComponentSource {
    SourceArn?: string | undefined;
    SourceType?: string | undefined;
}
export type OptionalDouble = number;
export type OptionalInteger = number;
export interface TrialComponentMetricSummary {
    MetricName?: string | undefined;
    SourceArn?: string | undefined;
    TimeStamp?: Date | undefined;
    Max?: number | undefined;
    Min?: number | undefined;
    Last?: number | undefined;
    Count?: number | undefined;
    Avg?: number | undefined;
    StdDev?: number | undefined;
}
export type TrialComponentMetricSummaries = TrialComponentMetricSummary[];
export type TrialComponentSources = TrialComponentSource[];
export interface DescribeTrialComponentResponse {
    TrialComponentName?: string | undefined;
    TrialComponentArn?: string | undefined;
    DisplayName?: string | undefined;
    Source?: (TrialComponentSource & {
        SourceArn: TrialComponentSourceArn;
    }) | undefined;
    Status?: TrialComponentStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    Parameters?: {
        [key: string]: TrialComponentParameterValue | undefined;
    } | undefined;
    InputArtifacts?: {
        [key: string]: (TrialComponentArtifact & {
            Value: TrialComponentArtifactValue;
        }) | undefined;
    } | undefined;
    OutputArtifacts?: {
        [key: string]: (TrialComponentArtifact & {
            Value: TrialComponentArtifactValue;
        }) | undefined;
    } | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    Metrics?: TrialComponentMetricSummary[] | undefined;
    LineageGroupArn?: string | undefined;
    Sources?: (TrialComponentSource & {
        SourceArn: TrialComponentSourceArn;
    })[] | undefined;
}
export interface DescribeUserProfileRequest {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
}
export type UserProfileStatus = "Deleting" | "Failed" | "InService" | "Pending" | "Updating" | "Update_Failed" | "Delete_Failed" | (string & {});
export interface DescribeUserProfileResponse {
    DomainId?: string | undefined;
    UserProfileArn?: string | undefined;
    UserProfileName?: string | undefined;
    HomeEfsFileSystemUid?: string | undefined;
    Status?: UserProfileStatus | undefined;
    LastModifiedTime?: Date | undefined;
    CreationTime?: Date | undefined;
    FailureReason?: string | undefined;
    SingleSignOnUserIdentifier?: string | undefined;
    SingleSignOnUserValue?: string | undefined;
    UserSettings?: (UserSettings & {
        JupyterServerAppSettings: JupyterServerAppSettings & {
            CodeRepositories: (CodeRepository & {
                RepositoryUrl: RepositoryUrl;
            })[];
        };
        KernelGatewayAppSettings: KernelGatewayAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
        };
        RSessionAppSettings: RSessionAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
        };
        CodeEditorAppSettings: CodeEditorAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
        };
        JupyterLabAppSettings: JupyterLabAppSettings & {
            CustomImages: (CustomImage & {
                ImageName: ImageName;
                AppImageConfigName: AppImageConfigName;
            })[];
            CodeRepositories: (CodeRepository & {
                RepositoryUrl: RepositoryUrl;
            })[];
        };
        SpaceStorageSettings: DefaultSpaceStorageSettings & {
            DefaultEbsStorageSettings: DefaultEbsStorageSettings & {
                DefaultEbsVolumeSizeInGb: SpaceEbsVolumeSizeInGb;
                MaximumEbsVolumeSizeInGb: SpaceEbsVolumeSizeInGb;
            };
        };
        CustomPosixUserConfig: CustomPosixUserConfig & {
            Uid: Uid;
            Gid: Gid;
        };
    }) | undefined;
}
export interface DescribeWorkforceRequest {
    WorkforceName?: string | undefined;
}
export interface OidcConfigForResponse {
    ClientId?: string | undefined;
    Issuer?: string | undefined;
    AuthorizationEndpoint?: string | undefined;
    TokenEndpoint?: string | undefined;
    UserInfoEndpoint?: string | undefined;
    LogoutEndpoint?: string | undefined;
    JwksUri?: string | undefined;
    Scope?: string | undefined;
    AuthenticationRequestExtraParams?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type WorkforceVpcEndpointId = string;
export interface WorkforceVpcConfigResponse {
    VpcId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    Subnets?: string[] | undefined;
    VpcEndpointId?: string | undefined;
}
export type WorkforceStatus = "Initializing" | "Updating" | "Deleting" | "Failed" | "Active" | (string & {});
export type WorkforceFailureReason = string;
export interface Workforce {
    WorkforceName?: string | undefined;
    WorkforceArn?: string | undefined;
    LastUpdatedDate?: Date | undefined;
    SourceIpConfig?: SourceIpConfig | undefined;
    SubDomain?: string | undefined;
    CognitoConfig?: CognitoConfig | undefined;
    OidcConfig?: OidcConfigForResponse | undefined;
    CreateDate?: Date | undefined;
    WorkforceVpcConfig?: WorkforceVpcConfigResponse | undefined;
    Status?: WorkforceStatus | undefined;
    FailureReason?: string | undefined;
    IpAddressType?: WorkforceIpAddressType | undefined;
}
export interface DescribeWorkforceResponse {
    Workforce: Workforce & {
        WorkforceName: WorkforceName;
        WorkforceArn: WorkforceArn;
        SourceIpConfig: SourceIpConfig & {
            Cidrs: Cidrs;
        };
        CognitoConfig: CognitoConfig & {
            UserPool: CognitoUserPool;
            ClientId: ClientId;
        };
        WorkforceVpcConfig: WorkforceVpcConfigResponse & {
            VpcId: WorkforceVpcId;
            SecurityGroupIds: WorkforceSecurityGroupIds;
            Subnets: WorkforceSubnets;
        };
    };
}
export interface DescribeWorkteamRequest {
    WorkteamName?: string | undefined;
}
export type ProductListings = string[];
export interface Workteam {
    WorkteamName?: string | undefined;
    MemberDefinitions?: MemberDefinition[] | undefined;
    WorkteamArn?: string | undefined;
    WorkforceArn?: string | undefined;
    ProductListingIds?: string[] | undefined;
    Description?: string | undefined;
    SubDomain?: string | undefined;
    CreateDate?: Date | undefined;
    LastUpdatedDate?: Date | undefined;
    NotificationConfiguration?: NotificationConfiguration | undefined;
    WorkerAccessConfiguration?: WorkerAccessConfiguration | undefined;
}
export interface DescribeWorkteamResponse {
    Workteam: Workteam & {
        WorkteamName: WorkteamName;
        MemberDefinitions: (MemberDefinition & {
            CognitoMemberDefinition: CognitoMemberDefinition & {
                UserPool: CognitoUserPool;
                UserGroup: CognitoUserGroup;
                ClientId: ClientId;
            };
        })[];
        WorkteamArn: WorkteamArn;
        Description: String200;
    };
}
export interface DetachClusterNodeVolumeRequest {
    ClusterArn?: string | undefined;
    NodeId?: string | undefined;
    VolumeId?: string | undefined;
}
export interface DetachClusterNodeVolumeResponse {
    ClusterArn: string;
    NodeId: string;
    VolumeId: string;
    AttachTime: Date;
    Status: VolumeAttachmentStatus;
    DeviceName: string;
}
export interface DisableSagemakerServicecatalogPortfolioInput {
}
export interface DisableSagemakerServicecatalogPortfolioOutput {
}
export interface DisassociateTrialComponentRequest {
    TrialComponentName?: string | undefined;
    TrialName?: string | undefined;
}
export interface DisassociateTrialComponentResponse {
    TrialComponentArn?: string | undefined;
    TrialArn?: string | undefined;
}
export interface EnableSagemakerServicecatalogPortfolioInput {
}
export interface EnableSagemakerServicecatalogPortfolioOutput {
}
export interface ExtendTrainingPlanRequest {
    TrainingPlanExtensionOfferingId?: string | undefined;
}
export interface ExtendTrainingPlanResponse {
    TrainingPlanExtensions: (TrainingPlanExtension & {
        TrainingPlanExtensionOfferingId: TrainingPlanExtensionOfferingId;
    })[];
}
export interface GetDeviceFleetReportRequest {
    DeviceFleetName?: string | undefined;
}
export interface DeviceStats {
    ConnectedDeviceCount?: number | undefined;
    RegisteredDeviceCount?: number | undefined;
}
export interface AgentVersion {
    Version?: string | undefined;
    AgentCount?: number | undefined;
}
export type AgentVersions = AgentVersion[];
export interface EdgeModelStat {
    ModelName?: string | undefined;
    ModelVersion?: string | undefined;
    OfflineDeviceCount?: number | undefined;
    ConnectedDeviceCount?: number | undefined;
    ActiveDeviceCount?: number | undefined;
    SamplingDeviceCount?: number | undefined;
}
export type EdgeModelStats = EdgeModelStat[];
export interface GetDeviceFleetReportResponse {
    DeviceFleetArn: string;
    DeviceFleetName: string;
    OutputConfig?: (EdgeOutputConfig & {
        S3OutputLocation: S3Uri;
    }) | undefined;
    Description?: string | undefined;
    ReportGenerated?: Date | undefined;
    DeviceStats?: (DeviceStats & {
        ConnectedDeviceCount: number;
        RegisteredDeviceCount: number;
    }) | undefined;
    AgentVersions?: (AgentVersion & {
        Version: EdgeVersion;
        AgentCount: number;
    })[] | undefined;
    ModelStats?: (EdgeModelStat & {
        ModelName: EntityName;
        ModelVersion: EdgeVersion;
        OfflineDeviceCount: number;
        ConnectedDeviceCount: number;
        ActiveDeviceCount: number;
        SamplingDeviceCount: number;
    })[] | undefined;
}
export type LineageGroupNameOrArn = string;
export interface GetLineageGroupPolicyRequest {
    LineageGroupName?: string | undefined;
}
export type ResourcePolicyString = string;
export interface GetLineageGroupPolicyResponse {
    LineageGroupArn?: string | undefined;
    ResourcePolicy?: string | undefined;
}
export interface GetModelPackageGroupPolicyInput {
    ModelPackageGroupName?: string | undefined;
}
export type PolicyString = string;
export interface GetModelPackageGroupPolicyOutput {
    ResourcePolicy: string;
}
export interface GetSagemakerServicecatalogPortfolioStatusInput {
}
export type SagemakerServicecatalogStatus = "Enabled" | "Disabled" | (string & {});
export interface GetSagemakerServicecatalogPortfolioStatusOutput {
    Status?: SagemakerServicecatalogStatus | undefined;
}
export type UtilizationPercentagePerCore = number;
export interface ScalingPolicyObjective {
    MinInvocationsPerMinute?: number | undefined;
    MaxInvocationsPerMinute?: number | undefined;
}
export interface GetScalingConfigurationRecommendationRequest {
    InferenceRecommendationsJobName?: string | undefined;
    RecommendationId?: string | undefined;
    EndpointName?: string | undefined;
    TargetCpuUtilizationPerCore?: number | undefined;
    ScalingPolicyObjective?: ScalingPolicyObjective | undefined;
}
export interface ScalingPolicyMetric {
    InvocationsPerInstance?: number | undefined;
    ModelLatency?: number | undefined;
}
export interface PredefinedMetricSpecification {
    PredefinedMetricType?: string | undefined;
}
export type Statistic = "Average" | "Minimum" | "Maximum" | "SampleCount" | "Sum" | (string & {});
export interface CustomizedMetricSpecification {
    MetricName?: string | undefined;
    Namespace?: string | undefined;
    Statistic?: Statistic | undefined;
}
export type MetricSpecification = {
    Predefined: PredefinedMetricSpecification;
    Customized?: undefined;
} | {
    Predefined?: undefined;
    Customized: CustomizedMetricSpecification;
};
export interface TargetTrackingScalingPolicyConfiguration {
    MetricSpecification?: MetricSpecification | undefined;
    TargetValue?: number | undefined;
}
export type ScalingPolicy = {
    TargetTracking: TargetTrackingScalingPolicyConfiguration;
};
export type ScalingPolicies = ScalingPolicy[];
export interface DynamicScalingConfiguration {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
    ScaleInCooldown?: number | undefined;
    ScaleOutCooldown?: number | undefined;
    ScalingPolicies?: ScalingPolicy[] | undefined;
}
export interface GetScalingConfigurationRecommendationResponse {
    InferenceRecommendationsJobName?: string | undefined;
    RecommendationId?: string | undefined;
    EndpointName?: string | undefined;
    TargetCpuUtilizationPerCore?: number | undefined;
    ScalingPolicyObjective?: ScalingPolicyObjective | undefined;
    Metric?: ScalingPolicyMetric | undefined;
    DynamicScalingConfiguration?: DynamicScalingConfiguration | undefined;
}
export type ResourceType = "TrainingJob" | "Experiment" | "ExperimentTrial" | "ExperimentTrialComponent" | "Endpoint" | "Model" | "ModelPackage" | "ModelPackageGroup" | "Pipeline" | "PipelineExecution" | "FeatureGroup" | "FeatureMetadata" | "Image" | "ImageVersion" | "Project" | "HyperParameterTuningJob" | "ModelCard" | "PipelineVersion" | "Job" | "HubContent" | (string & {});
export type PropertyNameHint = string;
export interface PropertyNameQuery {
    PropertyNameHint?: string | undefined;
}
export interface SuggestionQuery {
    PropertyNameQuery?: PropertyNameQuery | undefined;
}
export interface GetSearchSuggestionsRequest {
    Resource?: ResourceType | undefined;
    SuggestionQuery?: SuggestionQuery | undefined;
}
export type ResourcePropertyName = string;
export interface PropertyNameSuggestion {
    PropertyName?: string | undefined;
}
export type PropertyNameSuggestionList = PropertyNameSuggestion[];
export interface GetSearchSuggestionsResponse {
    PropertyNameSuggestions?: PropertyNameSuggestion[] | undefined;
}
export interface ImportHubContentRequest {
    HubContentName?: string | undefined;
    HubContentVersion?: string | undefined;
    HubContentType?: HubContentType | undefined;
    DocumentSchemaVersion?: string | undefined;
    HubName?: string | undefined;
    HubContentDisplayName?: string | undefined;
    HubContentDescription?: string | undefined;
    HubContentMarkdown?: string | undefined;
    HubContentDocument?: string | undefined;
    SupportStatus?: HubContentSupportStatus | undefined;
    HubContentSearchKeywords?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface ImportHubContentResponse {
    HubArn: string;
    HubContentArn: string;
}
export type SortActionsBy = "Name" | "CreationTime" | (string & {});
export type SortOrder = "Ascending" | "Descending" | (string & {});
export interface ListActionsRequest {
    SourceUri?: string | undefined;
    ActionType?: string | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortActionsBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ActionSummary {
    ActionArn?: string | undefined;
    ActionName?: string | undefined;
    Source?: ActionSource | undefined;
    ActionType?: string | undefined;
    Status?: ActionStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ActionSummaries = ActionSummary[];
export interface ListActionsResponse {
    ActionSummaries?: (ActionSummary & {
        Source: ActionSource & {
            SourceUri: SourceUri;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type NameContains = string;
export type ListAIBenchmarkJobsSortBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListAIBenchmarkJobsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    NameContains?: string | undefined;
    StatusEquals?: AIBenchmarkJobStatus | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    SortBy?: ListAIBenchmarkJobsSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface AIBenchmarkJobSummary {
    AIBenchmarkJobName?: string | undefined;
    AIBenchmarkJobArn?: string | undefined;
    AIBenchmarkJobStatus?: AIBenchmarkJobStatus | undefined;
    CreationTime?: Date | undefined;
    EndTime?: Date | undefined;
    AIWorkloadConfigName?: string | undefined;
}
export type AIBenchmarkJobSummaryList = AIBenchmarkJobSummary[];
export interface ListAIBenchmarkJobsResponse {
    AIBenchmarkJobs: (AIBenchmarkJobSummary & {
        AIBenchmarkJobName: AIEntityName;
        AIBenchmarkJobArn: AIBenchmarkJobArn;
        AIBenchmarkJobStatus: AIBenchmarkJobStatus;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type ListAIRecommendationJobsSortBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListAIRecommendationJobsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    NameContains?: string | undefined;
    StatusEquals?: AIRecommendationJobStatus | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    SortBy?: ListAIRecommendationJobsSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface AIRecommendationJobSummary {
    AIRecommendationJobName?: string | undefined;
    AIRecommendationJobArn?: string | undefined;
    AIRecommendationJobStatus?: AIRecommendationJobStatus | undefined;
    CreationTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type AIRecommendationJobSummaryList = AIRecommendationJobSummary[];
export interface ListAIRecommendationJobsResponse {
    AIRecommendationJobs: (AIRecommendationJobSummary & {
        AIRecommendationJobName: AIEntityName;
        AIRecommendationJobArn: AIRecommendationJobArn;
        AIRecommendationJobStatus: AIRecommendationJobStatus;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type ListAIWorkloadConfigsSortBy = "Name" | "CreationTime" | (string & {});
export interface ListAIWorkloadConfigsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    NameContains?: string | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    SortBy?: ListAIWorkloadConfigsSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface AIWorkloadConfigSummary {
    AIWorkloadConfigName?: string | undefined;
    AIWorkloadConfigArn?: string | undefined;
    CreationTime?: Date | undefined;
}
export type AIWorkloadConfigSummaryList = AIWorkloadConfigSummary[];
export interface ListAIWorkloadConfigsResponse {
    AIWorkloadConfigs: (AIWorkloadConfigSummary & {
        AIWorkloadConfigName: AIEntityName;
        AIWorkloadConfigArn: AIWorkloadConfigArn;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type AlgorithmSortBy = "Name" | "CreationTime" | (string & {});
export interface ListAlgorithmsInput {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    SortBy?: AlgorithmSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface AlgorithmSummary {
    AlgorithmName?: string | undefined;
    AlgorithmArn?: string | undefined;
    AlgorithmDescription?: string | undefined;
    CreationTime?: Date | undefined;
    AlgorithmStatus?: AlgorithmStatus | undefined;
}
export type AlgorithmSummaryList = AlgorithmSummary[];
export interface ListAlgorithmsOutput {
    AlgorithmSummaryList: (AlgorithmSummary & {
        AlgorithmName: EntityName;
        AlgorithmArn: AlgorithmArn;
        CreationTime: CreationTime;
        AlgorithmStatus: AlgorithmStatus;
    })[];
    NextToken?: string | undefined;
}
export interface ListAliasesRequest {
    ImageName?: string | undefined;
    Alias?: string | undefined;
    Version?: number | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListAliasesResponse {
    SageMakerImageVersionAliases?: string[] | undefined;
    NextToken?: string | undefined;
}
export type AppImageConfigSortKey = "CreationTime" | "LastModifiedTime" | "Name" | (string & {});
export interface ListAppImageConfigsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    ModifiedTimeBefore?: Date | undefined;
    ModifiedTimeAfter?: Date | undefined;
    SortBy?: AppImageConfigSortKey | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface AppImageConfigDetails {
    AppImageConfigArn?: string | undefined;
    AppImageConfigName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    KernelGatewayImageConfig?: KernelGatewayImageConfig | undefined;
    JupyterLabAppImageConfig?: JupyterLabAppImageConfig | undefined;
    CodeEditorAppImageConfig?: CodeEditorAppImageConfig | undefined;
}
export type AppImageConfigList = AppImageConfigDetails[];
export interface ListAppImageConfigsResponse {
    NextToken?: string | undefined;
    AppImageConfigs?: (AppImageConfigDetails & {
        KernelGatewayImageConfig: KernelGatewayImageConfig & {
            KernelSpecs: (KernelSpec & {
                Name: KernelName;
            })[];
        };
    })[] | undefined;
}
export type AppSortKey = "CreationTime" | (string & {});
export interface ListAppsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortOrder?: SortOrder | undefined;
    SortBy?: AppSortKey | undefined;
    DomainIdEquals?: string | undefined;
    UserProfileNameEquals?: string | undefined;
    SpaceNameEquals?: string | undefined;
}
export interface AppDetails {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    SpaceName?: string | undefined;
    AppType?: AppType | undefined;
    AppName?: string | undefined;
    Status?: AppStatus | undefined;
    CreationTime?: Date | undefined;
    ResourceSpec?: ResourceSpec | undefined;
}
export type AppList = AppDetails[];
export interface ListAppsResponse {
    Apps?: AppDetails[] | undefined;
    NextToken?: string | undefined;
}
export type SortArtifactsBy = "CreationTime" | (string & {});
export interface ListArtifactsRequest {
    SourceUri?: string | undefined;
    ArtifactType?: string | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortArtifactsBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ArtifactSummary {
    ArtifactArn?: string | undefined;
    ArtifactName?: string | undefined;
    Source?: ArtifactSource | undefined;
    ArtifactType?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ArtifactSummaries = ArtifactSummary[];
export interface ListArtifactsResponse {
    ArtifactSummaries?: (ArtifactSummary & {
        Source: ArtifactSource & {
            SourceUri: SourceUri;
            SourceTypes: (ArtifactSourceType & {
                SourceIdType: ArtifactSourceIdType;
                Value: String256;
            })[];
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type SortAssociationsBy = "SourceArn" | "DestinationArn" | "SourceType" | "DestinationType" | "CreationTime" | (string & {});
export interface ListAssociationsRequest {
    SourceArn?: string | undefined;
    DestinationArn?: string | undefined;
    SourceType?: string | undefined;
    DestinationType?: string | undefined;
    AssociationType?: AssociationEdgeType | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortAssociationsBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AssociationSummary {
    SourceArn?: string | undefined;
    DestinationArn?: string | undefined;
    SourceType?: string | undefined;
    DestinationType?: string | undefined;
    AssociationType?: AssociationEdgeType | undefined;
    SourceName?: string | undefined;
    DestinationName?: string | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
}
export type AssociationSummaries = AssociationSummary[];
export interface ListAssociationsResponse {
    AssociationSummaries?: AssociationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type AutoMLNameContains = string;
export type AutoMLSortOrder = "Ascending" | "Descending" | (string & {});
export type AutoMLSortBy = "Name" | "CreationTime" | "Status" | (string & {});
export type AutoMLMaxResults = number;
export interface ListAutoMLJobsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    StatusEquals?: AutoMLJobStatus | undefined;
    SortOrder?: AutoMLSortOrder | undefined;
    SortBy?: AutoMLSortBy | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AutoMLJobSummary {
    AutoMLJobName?: string | undefined;
    AutoMLJobArn?: string | undefined;
    AutoMLJobStatus?: AutoMLJobStatus | undefined;
    AutoMLJobSecondaryStatus?: AutoMLJobSecondaryStatus | undefined;
    CreationTime?: Date | undefined;
    EndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    FailureReason?: string | undefined;
    PartialFailureReasons?: AutoMLPartialFailureReason[] | undefined;
}
export type AutoMLJobSummaries = AutoMLJobSummary[];
export interface ListAutoMLJobsResponse {
    AutoMLJobSummaries: (AutoMLJobSummary & {
        AutoMLJobName: AutoMLJobName;
        AutoMLJobArn: AutoMLJobArn;
        AutoMLJobStatus: AutoMLJobStatus;
        AutoMLJobSecondaryStatus: AutoMLJobSecondaryStatus;
        CreationTime: Date;
        LastModifiedTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type CandidateSortBy = "CreationTime" | "Status" | "FinalObjectiveMetricValue" | (string & {});
export type AutoMLMaxResultsForTrials = number;
export interface ListCandidatesForAutoMLJobRequest {
    AutoMLJobName?: string | undefined;
    StatusEquals?: CandidateStatus | undefined;
    CandidateNameEquals?: string | undefined;
    SortOrder?: AutoMLSortOrder | undefined;
    SortBy?: CandidateSortBy | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AutoMLCandidates = AutoMLCandidate[];
export interface ListCandidatesForAutoMLJobResponse {
    Candidates: (AutoMLCandidate & {
        CandidateName: CandidateName;
        ObjectiveStatus: ObjectiveStatus;
        CandidateSteps: (AutoMLCandidateStep & {
            CandidateStepType: CandidateStepType;
            CandidateStepArn: CandidateStepArn;
            CandidateStepName: CandidateStepName;
        })[];
        CandidateStatus: CandidateStatus;
        CreationTime: Date;
        LastModifiedTime: Date;
        FinalAutoMLJobObjectiveMetric: FinalAutoMLJobObjectiveMetric & {
            MetricName: AutoMLMetricEnum;
            Value: MetricValue;
        };
        InferenceContainers: (AutoMLContainerDefinition & {
            Image: ContainerImage;
            ModelDataUrl: Url;
        })[];
        CandidateProperties: CandidateProperties & {
            CandidateArtifactLocations: CandidateArtifactLocations & {
                Explainability: ExplainabilityLocation;
            };
        };
        InferenceContainerDefinitions: {
            [key: string]: (AutoMLContainerDefinition & {
                Image: ContainerImage;
                ModelDataUrl: Url;
            })[] | undefined;
        };
    })[];
    NextToken?: string | undefined;
}
export type EventSortBy = "EventTime" | (string & {});
export type ClusterEventMaxResults = number;
export interface ListClusterEventsRequest {
    ClusterName?: string | undefined;
    InstanceGroupName?: string | undefined;
    NodeId?: string | undefined;
    EventTimeAfter?: Date | undefined;
    EventTimeBefore?: Date | undefined;
    SortBy?: EventSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    ResourceType?: ClusterEventResourceType | undefined;
    OperationId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ClusterEventSummary {
    EventId?: string | undefined;
    ClusterArn?: string | undefined;
    ClusterName?: string | undefined;
    InstanceGroupName?: string | undefined;
    InstanceId?: string | undefined;
    ResourceType?: ClusterEventResourceType | undefined;
    EventTime?: Date | undefined;
    Description?: string | undefined;
    EventLevel?: ClusterEventLevel | undefined;
    OperationId?: string | undefined;
}
export type ClusterEventSummaries = ClusterEventSummary[];
export interface ListClusterEventsResponse {
    NextToken?: string | undefined;
    Events?: (ClusterEventSummary & {
        EventId: EventId;
        ClusterArn: ClusterArn;
        ClusterName: ClusterName;
        ResourceType: ClusterEventResourceType;
        EventTime: Date;
    })[] | undefined;
}
export interface ListClusterExtensionsRequest {
    ClusterArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
}
export interface ExtensionSummary {
    ExtensionArn?: string | undefined;
    ExtensionName?: string | undefined;
    ExtensionVersion?: string | undefined;
    Status?: ExtensionStatus | undefined;
    CreationTime?: Date | undefined;
}
export type ExtensionSummaries = ExtensionSummary[];
export interface ListClusterExtensionsResponse {
    Extensions: (ExtensionSummary & {
        ExtensionArn: ExtensionArn;
        ExtensionName: ExtensionName;
        ExtensionVersion: ExtensionVersion;
        Status: ExtensionStatus;
    })[];
    NextToken?: string | undefined;
}
export interface ListClusterExtensionVersionsRequest {
    ExtensionName?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ExtensionVersionSummary {
    ExtensionVersion?: string | undefined;
}
export type ExtensionVersionSummaries = ExtensionVersionSummary[];
export interface ListClusterExtensionVersionsResponse {
    ExtensionVersions: (ExtensionVersionSummary & {
        ExtensionVersion: ExtensionVersion;
    })[];
    NextToken?: string | undefined;
}
export type ClusterSortBy = "CREATION_TIME" | "NAME" | (string & {});
export type IncludeNodeLogicalIdsBoolean = boolean;
export interface ListClusterNodesRequest {
    ClusterName?: string | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    InstanceGroupNameContains?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    SortBy?: ClusterSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    IncludeNodeLogicalIds?: boolean | undefined;
}
export interface ClusterNodeSummary {
    InstanceGroupName?: string | undefined;
    InstanceId?: string | undefined;
    NodeLogicalId?: string | undefined;
    InstanceType?: ClusterInstanceType | undefined;
    LaunchTime?: Date | undefined;
    LastSoftwareUpdateTime?: Date | undefined;
    InstanceStatus?: ClusterInstanceStatusDetails | undefined;
    UltraServerInfo?: UltraServerInfo | undefined;
    PrivateDnsHostname?: string | undefined;
    CurrentImageReleaseVersion?: string | undefined;
    ImageVersionStatus?: ClusterImageVersionStatus | undefined;
}
export type ClusterNodeSummaries = ClusterNodeSummary[];
export interface ListClusterNodesResponse {
    NextToken?: string | undefined;
    ClusterNodeSummaries: (ClusterNodeSummary & {
        InstanceGroupName: ClusterInstanceGroupName;
        InstanceId: string;
        InstanceType: ClusterInstanceType;
        LaunchTime: Date;
        InstanceStatus: ClusterInstanceStatusDetails & {
            Status: ClusterInstanceStatus;
        };
    })[];
}
export type ClusterOperationSortBy = "CreationTime" | (string & {});
export type ClusterOperationMaxResults = number;
export interface ListClusterOperationsRequest {
    ClusterName?: string | undefined;
    Status?: ClusterOperationStatus | undefined;
    Type?: ClusterOperationType | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    SortBy?: ClusterOperationSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ClusterOperationSummary {
    OperationId?: string | undefined;
    ClusterArn?: string | undefined;
    Type?: ClusterOperationType | undefined;
    Status?: ClusterOperationStatus | undefined;
    CreationTime?: Date | undefined;
}
export type ClusterOperationSummaries = ClusterOperationSummary[];
export interface ListClusterOperationsResponse {
    NextToken?: string | undefined;
    ClusterOperationSummaries?: ClusterOperationSummary[] | undefined;
}
export interface ListClustersRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    SortBy?: ClusterSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    TrainingPlanArn?: string | undefined;
}
export type TrainingPlanArns = string[];
export interface ClusterSummary {
    ClusterArn?: string | undefined;
    ClusterName?: string | undefined;
    CreationTime?: Date | undefined;
    ClusterStatus?: ClusterStatus | undefined;
    TrainingPlanArns?: string[] | undefined;
    ImageVersionStatus?: ClusterImageVersionStatus | undefined;
}
export type ClusterSummaries = ClusterSummary[];
export interface ListClustersResponse {
    NextToken?: string | undefined;
    ClusterSummaries: (ClusterSummary & {
        ClusterArn: ClusterArn;
        ClusterName: ClusterName;
        CreationTime: Date;
        ClusterStatus: ClusterStatus;
    })[];
}
export type SortClusterSchedulerConfigBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListClusterSchedulerConfigsRequest {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    NameContains?: string | undefined;
    ClusterArn?: string | undefined;
    Status?: SchedulerResourceStatus | undefined;
    SortBy?: SortClusterSchedulerConfigBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ClusterSchedulerConfigSummary {
    ClusterSchedulerConfigArn?: string | undefined;
    ClusterSchedulerConfigId?: string | undefined;
    ClusterSchedulerConfigVersion?: number | undefined;
    Name?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    Status?: SchedulerResourceStatus | undefined;
    ClusterArn?: string | undefined;
}
export type ClusterSchedulerConfigSummaryList = ClusterSchedulerConfigSummary[];
export interface ListClusterSchedulerConfigsResponse {
    ClusterSchedulerConfigSummaries?: (ClusterSchedulerConfigSummary & {
        ClusterSchedulerConfigArn: ClusterSchedulerConfigArn;
        ClusterSchedulerConfigId: ClusterSchedulerConfigId;
        Name: EntityName;
        CreationTime: Date;
        Status: SchedulerResourceStatus;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type CodeRepositoryNameContains = string;
export type CodeRepositorySortBy = "Name" | "CreationTime" | "LastModifiedTime" | (string & {});
export type CodeRepositorySortOrder = "Ascending" | "Descending" | (string & {});
export interface ListCodeRepositoriesInput {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    SortBy?: CodeRepositorySortBy | undefined;
    SortOrder?: CodeRepositorySortOrder | undefined;
}
export interface CodeRepositorySummary {
    CodeRepositoryName?: string | undefined;
    CodeRepositoryArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    GitConfig?: GitConfig | undefined;
}
export type CodeRepositorySummaryList = CodeRepositorySummary[];
export interface ListCodeRepositoriesOutput {
    CodeRepositorySummaryList: (CodeRepositorySummary & {
        CodeRepositoryName: EntityName;
        CodeRepositoryArn: CodeRepositoryArn;
        CreationTime: CreationTime;
        LastModifiedTime: LastModifiedTime;
        GitConfig: GitConfig & {
            RepositoryUrl: GitConfigUrl;
        };
    })[];
    NextToken?: string | undefined;
}
export type ListCompilationJobsSortBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListCompilationJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    StatusEquals?: CompilationJobStatus | undefined;
    SortBy?: ListCompilationJobsSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface CompilationJobSummary {
    CompilationJobName?: string | undefined;
    CompilationJobArn?: string | undefined;
    CreationTime?: Date | undefined;
    CompilationStartTime?: Date | undefined;
    CompilationEndTime?: Date | undefined;
    CompilationTargetDevice?: TargetDevice | undefined;
    CompilationTargetPlatformOs?: TargetPlatformOs | undefined;
    CompilationTargetPlatformArch?: TargetPlatformArch | undefined;
    CompilationTargetPlatformAccelerator?: TargetPlatformAccelerator | undefined;
    LastModifiedTime?: Date | undefined;
    CompilationJobStatus?: CompilationJobStatus | undefined;
}
export type CompilationJobSummaries = CompilationJobSummary[];
export interface ListCompilationJobsResponse {
    CompilationJobSummaries: (CompilationJobSummary & {
        CompilationJobName: EntityName;
        CompilationJobArn: CompilationJobArn;
        CreationTime: CreationTime;
        CompilationJobStatus: CompilationJobStatus;
    })[];
    NextToken?: string | undefined;
}
export type SortQuotaBy = "Name" | "CreationTime" | "Status" | "ClusterArn" | (string & {});
export interface ListComputeQuotasRequest {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    NameContains?: string | undefined;
    Status?: SchedulerResourceStatus | undefined;
    ClusterArn?: string | undefined;
    SortBy?: SortQuotaBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ComputeQuotaSummary {
    ComputeQuotaArn?: string | undefined;
    ComputeQuotaId?: string | undefined;
    Name?: string | undefined;
    ComputeQuotaVersion?: number | undefined;
    Status?: SchedulerResourceStatus | undefined;
    ClusterArn?: string | undefined;
    ComputeQuotaConfig?: ComputeQuotaConfig | undefined;
    ComputeQuotaTarget?: ComputeQuotaTarget | undefined;
    ActivationState?: ActivationState | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ComputeQuotaSummaryList = ComputeQuotaSummary[];
export interface ListComputeQuotasResponse {
    ComputeQuotaSummaries?: (ComputeQuotaSummary & {
        ComputeQuotaArn: ComputeQuotaArn;
        ComputeQuotaId: ComputeQuotaId;
        Name: EntityName;
        Status: SchedulerResourceStatus;
        ComputeQuotaTarget: ComputeQuotaTarget & {
            TeamName: ComputeQuotaTargetTeamName;
        };
        CreationTime: Date;
        ComputeQuotaConfig: ComputeQuotaConfig & {
            ComputeQuotaResources: (ComputeQuotaResourceConfig & {
                InstanceType: ClusterInstanceType;
                AcceleratorPartition: AcceleratorPartitionConfig & {
                    Type: MIGProfileType;
                    Count: number;
                };
            })[];
            ResourceSharingConfig: ResourceSharingConfig & {
                Strategy: ResourceSharingStrategy;
                AbsoluteBorrowLimits: (ComputeQuotaResourceConfig & {
                    InstanceType: ClusterInstanceType;
                    AcceleratorPartition: AcceleratorPartitionConfig & {
                        Type: MIGProfileType;
                        Count: number;
                    };
                })[];
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type SortContextsBy = "Name" | "CreationTime" | (string & {});
export interface ListContextsRequest {
    SourceUri?: string | undefined;
    ContextType?: string | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortContextsBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ContextSummary {
    ContextArn?: string | undefined;
    ContextName?: string | undefined;
    Source?: ContextSource | undefined;
    ContextType?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ContextSummaries = ContextSummary[];
export interface ListContextsResponse {
    ContextSummaries?: (ContextSummary & {
        Source: ContextSource & {
            SourceUri: SourceUri;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type MonitoringJobDefinitionSortKey = "Name" | "CreationTime" | (string & {});
export interface ListDataQualityJobDefinitionsRequest {
    EndpointName?: string | undefined;
    SortBy?: MonitoringJobDefinitionSortKey | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
}
export interface MonitoringJobDefinitionSummary {
    MonitoringJobDefinitionName?: string | undefined;
    MonitoringJobDefinitionArn?: string | undefined;
    CreationTime?: Date | undefined;
    EndpointName?: string | undefined;
}
export type MonitoringJobDefinitionSummaryList = MonitoringJobDefinitionSummary[];
export interface ListDataQualityJobDefinitionsResponse {
    JobDefinitionSummaries: (MonitoringJobDefinitionSummary & {
        MonitoringJobDefinitionName: MonitoringJobDefinitionName;
        MonitoringJobDefinitionArn: MonitoringJobDefinitionArn;
        CreationTime: Date;
        EndpointName: EndpointName;
    })[];
    NextToken?: string | undefined;
}
export type ListMaxResults = number;
export type ListDeviceFleetsSortBy = "NAME" | "CREATION_TIME" | "LAST_MODIFIED_TIME" | (string & {});
export interface ListDeviceFleetsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    SortBy?: ListDeviceFleetsSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface DeviceFleetSummary {
    DeviceFleetArn?: string | undefined;
    DeviceFleetName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type DeviceFleetSummaries = DeviceFleetSummary[];
export interface ListDeviceFleetsResponse {
    DeviceFleetSummaries: (DeviceFleetSummary & {
        DeviceFleetArn: DeviceFleetArn;
        DeviceFleetName: EntityName;
    })[];
    NextToken?: string | undefined;
}
export interface ListDevicesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    LatestHeartbeatAfter?: Date | undefined;
    ModelName?: string | undefined;
    DeviceFleetName?: string | undefined;
}
export interface EdgeModelSummary {
    ModelName?: string | undefined;
    ModelVersion?: string | undefined;
}
export type EdgeModelSummaries = EdgeModelSummary[];
export interface DeviceSummary {
    DeviceName?: string | undefined;
    DeviceArn?: string | undefined;
    Description?: string | undefined;
    DeviceFleetName?: string | undefined;
    IotThingName?: string | undefined;
    RegistrationTime?: Date | undefined;
    LatestHeartbeat?: Date | undefined;
    Models?: EdgeModelSummary[] | undefined;
    AgentVersion?: string | undefined;
}
export type DeviceSummaries = DeviceSummary[];
export interface ListDevicesResponse {
    DeviceSummaries: (DeviceSummary & {
        DeviceName: EntityName;
        DeviceArn: DeviceArn;
        Models: (EdgeModelSummary & {
            ModelName: EntityName;
            ModelVersion: EdgeVersion;
        })[];
    })[];
    NextToken?: string | undefined;
}
export interface ListDomainsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DomainDetails {
    DomainArn?: string | undefined;
    DomainId?: string | undefined;
    DomainName?: string | undefined;
    Status?: DomainStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    Url?: string | undefined;
}
export type DomainList = DomainDetails[];
export interface ListDomainsResponse {
    Domains?: DomainDetails[] | undefined;
    NextToken?: string | undefined;
}
export type ListEdgeDeploymentPlansSortBy = "NAME" | "DEVICE_FLEET_NAME" | "CREATION_TIME" | "LAST_MODIFIED_TIME" | (string & {});
export interface ListEdgeDeploymentPlansRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    DeviceFleetNameContains?: string | undefined;
    SortBy?: ListEdgeDeploymentPlansSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface EdgeDeploymentPlanSummary {
    EdgeDeploymentPlanArn?: string | undefined;
    EdgeDeploymentPlanName?: string | undefined;
    DeviceFleetName?: string | undefined;
    EdgeDeploymentSuccess?: number | undefined;
    EdgeDeploymentPending?: number | undefined;
    EdgeDeploymentFailed?: number | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type EdgeDeploymentPlanSummaries = EdgeDeploymentPlanSummary[];
export interface ListEdgeDeploymentPlansResponse {
    EdgeDeploymentPlanSummaries: (EdgeDeploymentPlanSummary & {
        EdgeDeploymentPlanArn: EdgeDeploymentPlanArn;
        EdgeDeploymentPlanName: EntityName;
        DeviceFleetName: EntityName;
        EdgeDeploymentSuccess: number;
        EdgeDeploymentPending: number;
        EdgeDeploymentFailed: number;
    })[];
    NextToken?: string | undefined;
}
export type ListEdgePackagingJobsSortBy = "NAME" | "MODEL_NAME" | "CREATION_TIME" | "LAST_MODIFIED_TIME" | "STATUS" | (string & {});
export interface ListEdgePackagingJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    ModelNameContains?: string | undefined;
    StatusEquals?: EdgePackagingJobStatus | undefined;
    SortBy?: ListEdgePackagingJobsSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface EdgePackagingJobSummary {
    EdgePackagingJobArn?: string | undefined;
    EdgePackagingJobName?: string | undefined;
    EdgePackagingJobStatus?: EdgePackagingJobStatus | undefined;
    CompilationJobName?: string | undefined;
    ModelName?: string | undefined;
    ModelVersion?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type EdgePackagingJobSummaries = EdgePackagingJobSummary[];
export interface ListEdgePackagingJobsResponse {
    EdgePackagingJobSummaries: (EdgePackagingJobSummary & {
        EdgePackagingJobArn: EdgePackagingJobArn;
        EdgePackagingJobName: EntityName;
        EdgePackagingJobStatus: EdgePackagingJobStatus;
    })[];
    NextToken?: string | undefined;
}
export type EndpointConfigSortKey = "Name" | "CreationTime" | (string & {});
export type OrderKey = "Ascending" | "Descending" | (string & {});
export type PaginationToken = string;
export type EndpointConfigNameContains = string;
export interface ListEndpointConfigsInput {
    SortBy?: EndpointConfigSortKey | undefined;
    SortOrder?: OrderKey | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
}
export interface EndpointConfigSummary {
    EndpointConfigName?: string | undefined;
    EndpointConfigArn?: string | undefined;
    CreationTime?: Date | undefined;
}
export type EndpointConfigSummaryList = EndpointConfigSummary[];
export interface ListEndpointConfigsOutput {
    EndpointConfigs: (EndpointConfigSummary & {
        EndpointConfigName: EndpointConfigName;
        EndpointConfigArn: EndpointConfigArn;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type EndpointSortKey = "Name" | "CreationTime" | "Status" | (string & {});
export type EndpointNameContains = string;
export interface ListEndpointsInput {
    SortBy?: EndpointSortKey | undefined;
    SortOrder?: OrderKey | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    StatusEquals?: EndpointStatus | undefined;
}
export interface EndpointSummary {
    EndpointName?: string | undefined;
    EndpointArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    EndpointStatus?: EndpointStatus | undefined;
}
export type EndpointSummaryList = EndpointSummary[];
export interface ListEndpointsOutput {
    Endpoints: (EndpointSummary & {
        EndpointName: EndpointName;
        EndpointArn: EndpointArn;
        CreationTime: Date;
        LastModifiedTime: Date;
        EndpointStatus: EndpointStatus;
    })[];
    NextToken?: string | undefined;
}
export type SortExperimentsBy = "Name" | "CreationTime" | (string & {});
export interface ListExperimentsRequest {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortExperimentsBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ExperimentSummary {
    ExperimentArn?: string | undefined;
    ExperimentName?: string | undefined;
    DisplayName?: string | undefined;
    ExperimentSource?: ExperimentSource | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ExperimentSummaries = ExperimentSummary[];
export interface ListExperimentsResponse {
    ExperimentSummaries?: (ExperimentSummary & {
        ExperimentSource: ExperimentSource & {
            SourceArn: ExperimentSourceArn;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type FeatureGroupNameContains = string;
export type FeatureGroupSortOrder = "Ascending" | "Descending" | (string & {});
export type FeatureGroupSortBy = "Name" | "FeatureGroupStatus" | "OfflineStoreStatus" | "CreationTime" | (string & {});
export type FeatureGroupMaxResults = number;
export interface ListFeatureGroupsRequest {
    NameContains?: string | undefined;
    FeatureGroupStatusEquals?: FeatureGroupStatus | undefined;
    OfflineStoreStatusEquals?: OfflineStoreStatusValue | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    SortOrder?: FeatureGroupSortOrder | undefined;
    SortBy?: FeatureGroupSortBy | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface FeatureGroupSummary {
    FeatureGroupName?: string | undefined;
    FeatureGroupArn?: string | undefined;
    CreationTime?: Date | undefined;
    FeatureGroupStatus?: FeatureGroupStatus | undefined;
    OfflineStoreStatus?: OfflineStoreStatus | undefined;
}
export type FeatureGroupSummaries = FeatureGroupSummary[];
export interface ListFeatureGroupsResponse {
    FeatureGroupSummaries: (FeatureGroupSummary & {
        FeatureGroupName: FeatureGroupName;
        FeatureGroupArn: FeatureGroupArn;
        CreationTime: Date;
        OfflineStoreStatus: OfflineStoreStatus & {
            Status: OfflineStoreStatusValue;
        };
    })[];
    NextToken?: string | undefined;
}
export interface ListFlowDefinitionsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FlowDefinitionSummary {
    FlowDefinitionName?: string | undefined;
    FlowDefinitionArn?: string | undefined;
    FlowDefinitionStatus?: FlowDefinitionStatus | undefined;
    CreationTime?: Date | undefined;
    FailureReason?: string | undefined;
}
export type FlowDefinitionSummaries = FlowDefinitionSummary[];
export interface ListFlowDefinitionsResponse {
    FlowDefinitionSummaries: (FlowDefinitionSummary & {
        FlowDefinitionName: FlowDefinitionName;
        FlowDefinitionArn: FlowDefinitionArn;
        FlowDefinitionStatus: FlowDefinitionStatus;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type HubContentSortBy = "HubContentName" | "CreationTime" | "HubContentStatus" | (string & {});
export interface ListHubContentsRequest {
    HubName?: string | undefined;
    HubContentType?: HubContentType | undefined;
    NameContains?: string | undefined;
    MaxSchemaVersion?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    SortBy?: HubContentSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface HubContentInfo {
    HubContentName?: string | undefined;
    HubContentArn?: string | undefined;
    SageMakerPublicHubContentArn?: string | undefined;
    HubContentVersion?: string | undefined;
    HubContentType?: HubContentType | undefined;
    DocumentSchemaVersion?: string | undefined;
    HubContentDisplayName?: string | undefined;
    HubContentDescription?: string | undefined;
    SupportStatus?: HubContentSupportStatus | undefined;
    HubContentSearchKeywords?: string[] | undefined;
    HubContentStatus?: HubContentStatus | undefined;
    CreationTime?: Date | undefined;
    OriginalCreationTime?: Date | undefined;
}
export type HubContentInfoList = HubContentInfo[];
export interface ListHubContentsResponse {
    HubContentSummaries: (HubContentInfo & {
        HubContentName: HubContentName;
        HubContentArn: HubContentArn;
        HubContentVersion: HubContentVersion;
        HubContentType: HubContentType;
        DocumentSchemaVersion: DocumentSchemaVersion;
        HubContentStatus: HubContentStatus;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export interface ListHubContentVersionsRequest {
    HubName?: string | undefined;
    HubContentType?: HubContentType | undefined;
    HubContentName?: string | undefined;
    MinVersion?: string | undefined;
    MaxSchemaVersion?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    SortBy?: HubContentSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListHubContentVersionsResponse {
    HubContentSummaries: (HubContentInfo & {
        HubContentName: HubContentName;
        HubContentArn: HubContentArn;
        HubContentVersion: HubContentVersion;
        HubContentType: HubContentType;
        DocumentSchemaVersion: DocumentSchemaVersion;
        HubContentStatus: HubContentStatus;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type HubSortBy = "HubName" | "CreationTime" | "HubStatus" | "AccountIdOwner" | (string & {});
export interface ListHubsRequest {
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    SortBy?: HubSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface HubInfo {
    HubName?: string | undefined;
    HubArn?: string | undefined;
    HubDisplayName?: string | undefined;
    HubDescription?: string | undefined;
    HubSearchKeywords?: string[] | undefined;
    HubStatus?: HubStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type HubInfoList = HubInfo[];
export interface ListHubsResponse {
    HubSummaries: (HubInfo & {
        HubName: HubName;
        HubArn: HubArn;
        HubStatus: HubStatus;
        CreationTime: Date;
        LastModifiedTime: Date;
    })[];
    NextToken?: string | undefined;
}
export interface ListHumanTaskUisRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface HumanTaskUiSummary {
    HumanTaskUiName?: string | undefined;
    HumanTaskUiArn?: string | undefined;
    CreationTime?: Date | undefined;
}
export type HumanTaskUiSummaries = HumanTaskUiSummary[];
export interface ListHumanTaskUisResponse {
    HumanTaskUiSummaries: (HumanTaskUiSummary & {
        HumanTaskUiName: HumanTaskUiName;
        HumanTaskUiArn: HumanTaskUiArn;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type HyperParameterTuningJobSortByOptions = "Name" | "Status" | "CreationTime" | (string & {});
export interface ListHyperParameterTuningJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortBy?: HyperParameterTuningJobSortByOptions | undefined;
    SortOrder?: SortOrder | undefined;
    NameContains?: string | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    StatusEquals?: HyperParameterTuningJobStatus | undefined;
}
export interface HyperParameterTuningJobSummary {
    HyperParameterTuningJobName?: string | undefined;
    HyperParameterTuningJobArn?: string | undefined;
    HyperParameterTuningJobStatus?: HyperParameterTuningJobStatus | undefined;
    Strategy?: HyperParameterTuningJobStrategyType | undefined;
    CreationTime?: Date | undefined;
    HyperParameterTuningEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    TrainingJobStatusCounters?: TrainingJobStatusCounters | undefined;
    ObjectiveStatusCounters?: ObjectiveStatusCounters | undefined;
    ResourceLimits?: ResourceLimits | undefined;
}
export type HyperParameterTuningJobSummaries = HyperParameterTuningJobSummary[];
export interface ListHyperParameterTuningJobsResponse {
    HyperParameterTuningJobSummaries: (HyperParameterTuningJobSummary & {
        HyperParameterTuningJobName: HyperParameterTuningJobName;
        HyperParameterTuningJobArn: HyperParameterTuningJobArn;
        HyperParameterTuningJobStatus: HyperParameterTuningJobStatus;
        Strategy: HyperParameterTuningJobStrategyType;
        CreationTime: Date;
        TrainingJobStatusCounters: TrainingJobStatusCounters;
        ObjectiveStatusCounters: ObjectiveStatusCounters;
        ResourceLimits: ResourceLimits & {
            MaxParallelTrainingJobs: MaxParallelTrainingJobs;
        };
    })[];
    NextToken?: string | undefined;
}
export type ImageNameContains = string;
export type ImageSortBy = "CREATION_TIME" | "LAST_MODIFIED_TIME" | "IMAGE_NAME" | (string & {});
export type ImageSortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface ListImagesRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    SortBy?: ImageSortBy | undefined;
    SortOrder?: ImageSortOrder | undefined;
}
export interface Image {
    CreationTime?: Date | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    FailureReason?: string | undefined;
    ImageArn?: string | undefined;
    ImageName?: string | undefined;
    ImageStatus?: ImageStatus | undefined;
    LastModifiedTime?: Date | undefined;
}
export type Images = Image[];
export interface ListImagesResponse {
    Images?: (Image & {
        CreationTime: Date;
        ImageArn: ImageArn;
        ImageName: ImageName;
        ImageStatus: ImageStatus;
        LastModifiedTime: Date;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type ImageVersionSortBy = "CREATION_TIME" | "LAST_MODIFIED_TIME" | "VERSION" | (string & {});
export type ImageVersionSortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface ListImageVersionsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    ImageName?: string | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    SortBy?: ImageVersionSortBy | undefined;
    SortOrder?: ImageVersionSortOrder | undefined;
}
export interface ImageVersion {
    CreationTime?: Date | undefined;
    FailureReason?: string | undefined;
    ImageArn?: string | undefined;
    ImageVersionArn?: string | undefined;
    ImageVersionStatus?: ImageVersionStatus | undefined;
    LastModifiedTime?: Date | undefined;
    Version?: number | undefined;
}
export type ImageVersions = ImageVersion[];
export interface ListImageVersionsResponse {
    ImageVersions?: (ImageVersion & {
        CreationTime: Date;
        ImageArn: ImageArn;
        ImageVersionArn: ImageVersionArn;
        ImageVersionStatus: ImageVersionStatus;
        LastModifiedTime: Date;
        Version: ImageVersionNumber;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type InferenceComponentSortKey = "Name" | "CreationTime" | "Status" | (string & {});
export type InferenceComponentNameContains = string;
export interface ListInferenceComponentsInput {
    SortBy?: InferenceComponentSortKey | undefined;
    SortOrder?: OrderKey | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    StatusEquals?: InferenceComponentStatus | undefined;
    EndpointNameEquals?: string | undefined;
    VariantNameEquals?: string | undefined;
}
export interface InferenceComponentSummary {
    CreationTime?: Date | undefined;
    InferenceComponentArn?: string | undefined;
    InferenceComponentName?: string | undefined;
    EndpointArn?: string | undefined;
    EndpointName?: string | undefined;
    VariantName?: string | undefined;
    InferenceComponentStatus?: InferenceComponentStatus | undefined;
    LastModifiedTime?: Date | undefined;
}
export type InferenceComponentSummaryList = InferenceComponentSummary[];
export interface ListInferenceComponentsOutput {
    InferenceComponents: (InferenceComponentSummary & {
        CreationTime: Date;
        InferenceComponentArn: InferenceComponentArn;
        InferenceComponentName: InferenceComponentName;
        EndpointArn: EndpointArn;
        EndpointName: EndpointName;
        VariantName: VariantName;
        LastModifiedTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type SortInferenceExperimentsBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListInferenceExperimentsRequest {
    NameContains?: string | undefined;
    Type?: InferenceExperimentType | undefined;
    StatusEquals?: InferenceExperimentStatus | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    SortBy?: SortInferenceExperimentsBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface InferenceExperimentSummary {
    Name?: string | undefined;
    Type?: InferenceExperimentType | undefined;
    Schedule?: InferenceExperimentSchedule | undefined;
    Status?: InferenceExperimentStatus | undefined;
    StatusReason?: string | undefined;
    Description?: string | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    RoleArn?: string | undefined;
}
export type InferenceExperimentList = InferenceExperimentSummary[];
export interface ListInferenceExperimentsResponse {
    InferenceExperiments?: (InferenceExperimentSummary & {
        Name: InferenceExperimentName;
        Type: InferenceExperimentType;
        Status: InferenceExperimentStatus;
        CreationTime: Date;
        LastModifiedTime: Date;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type ListInferenceRecommendationsJobsSortBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListInferenceRecommendationsJobsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    StatusEquals?: RecommendationJobStatus | undefined;
    SortBy?: ListInferenceRecommendationsJobsSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ModelNameEquals?: string | undefined;
    ModelPackageVersionArnEquals?: string | undefined;
}
export interface InferenceRecommendationsJob {
    JobName?: string | undefined;
    JobDescription?: string | undefined;
    JobType?: RecommendationJobType | undefined;
    JobArn?: string | undefined;
    Status?: RecommendationJobStatus | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    RoleArn?: string | undefined;
    LastModifiedTime?: Date | undefined;
    FailureReason?: string | undefined;
    ModelName?: string | undefined;
    SamplePayloadUrl?: string | undefined;
    ModelPackageVersionArn?: string | undefined;
}
export type InferenceRecommendationsJobs = InferenceRecommendationsJob[];
export interface ListInferenceRecommendationsJobsResponse {
    InferenceRecommendationsJobs: (InferenceRecommendationsJob & {
        JobName: RecommendationJobName;
        JobDescription: RecommendationJobDescription;
        JobType: RecommendationJobType;
        JobArn: RecommendationJobArn;
        Status: RecommendationJobStatus;
        CreationTime: CreationTime;
        RoleArn: RoleArn;
        LastModifiedTime: LastModifiedTime;
    })[];
    NextToken?: string | undefined;
}
export type RecommendationStepType = "BENCHMARK" | (string & {});
export interface ListInferenceRecommendationsJobStepsRequest {
    JobName?: string | undefined;
    Status?: RecommendationJobStatus | undefined;
    StepType?: RecommendationStepType | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type RecommendationFailureReason = string;
export interface RecommendationJobInferenceBenchmark {
    Metrics?: RecommendationMetrics | undefined;
    EndpointMetrics?: InferenceMetrics | undefined;
    EndpointConfiguration?: EndpointOutputConfiguration | undefined;
    ModelConfiguration?: ModelConfiguration | undefined;
    FailureReason?: string | undefined;
    InvocationEndTime?: Date | undefined;
    InvocationStartTime?: Date | undefined;
}
export interface InferenceRecommendationsJobStep {
    StepType?: RecommendationStepType | undefined;
    JobName?: string | undefined;
    Status?: RecommendationJobStatus | undefined;
    InferenceBenchmark?: RecommendationJobInferenceBenchmark | undefined;
}
export type InferenceRecommendationsJobSteps = InferenceRecommendationsJobStep[];
export interface ListInferenceRecommendationsJobStepsResponse {
    Steps?: (InferenceRecommendationsJobStep & {
        StepType: RecommendationStepType;
        JobName: RecommendationJobName;
        Status: RecommendationJobStatus;
        InferenceBenchmark: RecommendationJobInferenceBenchmark & {
            ModelConfiguration: ModelConfiguration & {
                EnvironmentParameters: (EnvironmentParameter & {
                    Key: string;
                    ValueType: string;
                    Value: string;
                })[];
            };
            EndpointMetrics: InferenceMetrics & {
                MaxInvocations: number;
                ModelLatency: number;
            };
            EndpointConfiguration: EndpointOutputConfiguration & {
                EndpointName: string;
                VariantName: string;
                ServerlessConfig: ProductionVariantServerlessConfig & {
                    MemorySizeInMB: ServerlessMemorySizeInMB;
                    MaxConcurrency: ServerlessMaxConcurrency;
                };
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type SortBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListJobsRequest {
    JobCategory?: JobCategory | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    SortBy?: SortBy | undefined;
    SortOrder?: SortOrder | undefined;
    StatusEquals?: JobStatus | undefined;
}
export interface JobSummary {
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobCategory?: JobCategory | undefined;
    JobStatus?: JobStatus | undefined;
    JobSecondaryStatus?: JobSecondaryStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type JobSummaries = JobSummary[];
export interface ListJobsResponse {
    NextToken?: string | undefined;
    JobSummaries: (JobSummary & {
        JobArn: JobArn;
        JobName: JobName;
        JobCategory: JobCategory;
        JobStatus: JobStatus;
        JobSecondaryStatus: JobSecondaryStatus;
        CreationTime: Date;
        LastModifiedTime: Date;
    })[];
}
export interface ListJobSchemaVersionsRequest {
    JobCategory?: JobCategory | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface JobConfigSchemaVersionSummary {
    JobConfigSchemaVersion?: string | undefined;
}
export type JobConfigSchemas = JobConfigSchemaVersionSummary[];
export interface ListJobSchemaVersionsResponse {
    NextToken?: string | undefined;
    JobConfigSchemas: (JobConfigSchemaVersionSummary & {
        JobConfigSchemaVersion: JobSchemaVersion;
    })[];
}
export interface ListLabelingJobsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    NameContains?: string | undefined;
    SortBy?: SortBy | undefined;
    SortOrder?: SortOrder | undefined;
    StatusEquals?: LabelingJobStatus | undefined;
}
export interface LabelingJobSummary {
    LabelingJobName?: string | undefined;
    LabelingJobArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LabelingJobStatus?: LabelingJobStatus | undefined;
    LabelCounters?: LabelCounters | undefined;
    WorkteamArn?: string | undefined;
    PreHumanTaskLambdaArn?: string | undefined;
    AnnotationConsolidationLambdaArn?: string | undefined;
    FailureReason?: string | undefined;
    LabelingJobOutput?: LabelingJobOutput | undefined;
    InputConfig?: LabelingJobInputConfig | undefined;
}
export type LabelingJobSummaryList = LabelingJobSummary[];
export interface ListLabelingJobsResponse {
    LabelingJobSummaryList?: (LabelingJobSummary & {
        LabelingJobName: LabelingJobName;
        LabelingJobArn: LabelingJobArn;
        CreationTime: Date;
        LastModifiedTime: Date;
        LabelingJobStatus: LabelingJobStatus;
        LabelCounters: LabelCounters;
        WorkteamArn: WorkteamArn;
        LabelingJobOutput: LabelingJobOutput & {
            OutputDatasetS3Uri: S3Uri;
        };
        InputConfig: LabelingJobInputConfig & {
            DataSource: LabelingJobDataSource & {
                S3DataSource: LabelingJobS3DataSource & {
                    ManifestS3Uri: S3Uri;
                };
                SnsDataSource: LabelingJobSnsDataSource & {
                    SnsTopicArn: SnsTopicArn;
                };
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type JobReferenceCodeContains = string;
export type ListLabelingJobsForWorkteamSortByOptions = "CreationTime" | (string & {});
export interface ListLabelingJobsForWorkteamRequest {
    WorkteamArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    JobReferenceCodeContains?: string | undefined;
    SortBy?: ListLabelingJobsForWorkteamSortByOptions | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface LabelCountersForWorkteam {
    HumanLabeled?: number | undefined;
    PendingHuman?: number | undefined;
    Total?: number | undefined;
}
export interface LabelingJobForWorkteamSummary {
    LabelingJobName?: string | undefined;
    JobReferenceCode?: string | undefined;
    WorkRequesterAccountId?: string | undefined;
    CreationTime?: Date | undefined;
    LabelCounters?: LabelCountersForWorkteam | undefined;
    NumberOfHumanWorkersPerDataObject?: number | undefined;
}
export type LabelingJobForWorkteamSummaryList = LabelingJobForWorkteamSummary[];
export interface ListLabelingJobsForWorkteamResponse {
    LabelingJobSummaryList: (LabelingJobForWorkteamSummary & {
        JobReferenceCode: JobReferenceCode;
        WorkRequesterAccountId: AccountId;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type SortLineageGroupsBy = "Name" | "CreationTime" | (string & {});
export interface ListLineageGroupsRequest {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortLineageGroupsBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface LineageGroupSummary {
    LineageGroupArn?: string | undefined;
    LineageGroupName?: string | undefined;
    DisplayName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type LineageGroupSummaries = LineageGroupSummary[];
export interface ListLineageGroupsResponse {
    LineageGroupSummaries?: LineageGroupSummary[] | undefined;
    NextToken?: string | undefined;
}
export type SortMlflowAppBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListMlflowAppsRequest {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    Status?: MlflowAppStatus | undefined;
    MlflowVersion?: string | undefined;
    DefaultForDomainId?: string | undefined;
    AccountDefaultStatus?: AccountDefaultStatus | undefined;
    SortBy?: SortMlflowAppBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MlflowAppSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
    Status?: MlflowAppStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    MlflowVersion?: string | undefined;
}
export type MlflowAppSummaries = MlflowAppSummary[];
export interface ListMlflowAppsResponse {
    Summaries?: MlflowAppSummary[] | undefined;
    NextToken?: string | undefined;
}
export type SortTrackingServerBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListMlflowTrackingServersRequest {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    TrackingServerStatus?: TrackingServerStatus | undefined;
    MlflowVersion?: string | undefined;
    SortBy?: SortTrackingServerBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TrackingServerSummary {
    TrackingServerArn?: string | undefined;
    TrackingServerName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    TrackingServerStatus?: TrackingServerStatus | undefined;
    IsActive?: IsTrackingServerActive | undefined;
    MlflowVersion?: string | undefined;
}
export type TrackingServerSummaryList = TrackingServerSummary[];
export interface ListMlflowTrackingServersResponse {
    TrackingServerSummaries?: TrackingServerSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListModelBiasJobDefinitionsRequest {
    EndpointName?: string | undefined;
    SortBy?: MonitoringJobDefinitionSortKey | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
}
export interface ListModelBiasJobDefinitionsResponse {
    JobDefinitionSummaries: (MonitoringJobDefinitionSummary & {
        MonitoringJobDefinitionName: MonitoringJobDefinitionName;
        MonitoringJobDefinitionArn: MonitoringJobDefinitionArn;
        CreationTime: Date;
        EndpointName: EndpointName;
    })[];
    NextToken?: string | undefined;
}
export type ModelCardExportJobSortBy = "Name" | "CreationTime" | "Status" | (string & {});
export type ModelCardExportJobSortOrder = "Ascending" | "Descending" | (string & {});
export interface ListModelCardExportJobsRequest {
    ModelCardName?: string | undefined;
    ModelCardVersion?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    ModelCardExportJobNameContains?: string | undefined;
    StatusEquals?: ModelCardExportJobStatus | undefined;
    SortBy?: ModelCardExportJobSortBy | undefined;
    SortOrder?: ModelCardExportJobSortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ModelCardExportJobSummary {
    ModelCardExportJobName?: string | undefined;
    ModelCardExportJobArn?: string | undefined;
    Status?: ModelCardExportJobStatus | undefined;
    ModelCardName?: string | undefined;
    ModelCardVersion?: number | undefined;
    CreatedAt?: Date | undefined;
    LastModifiedAt?: Date | undefined;
}
export type ModelCardExportJobSummaryList = ModelCardExportJobSummary[];
export interface ListModelCardExportJobsResponse {
    ModelCardExportJobSummaries: (ModelCardExportJobSummary & {
        ModelCardExportJobName: EntityName;
        ModelCardExportJobArn: ModelCardExportJobArn;
        Status: ModelCardExportJobStatus;
        ModelCardName: EntityName;
        ModelCardVersion: number;
        CreatedAt: Date;
        LastModifiedAt: Date;
    })[];
    NextToken?: string | undefined;
}
export type ModelCardSortBy = "Name" | "CreationTime" | (string & {});
export type ModelCardSortOrder = "Ascending" | "Descending" | (string & {});
export interface ListModelCardsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
    NextToken?: string | undefined;
    SortBy?: ModelCardSortBy | undefined;
    SortOrder?: ModelCardSortOrder | undefined;
}
export interface ModelCardSummary {
    ModelCardName?: string | undefined;
    ModelCardArn?: string | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ModelCardSummaryList = ModelCardSummary[];
export interface ListModelCardsResponse {
    ModelCardSummaries: (ModelCardSummary & {
        ModelCardName: EntityName;
        ModelCardArn: ModelCardArn;
        ModelCardStatus: ModelCardStatus;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type ModelCardVersionSortBy = "Version" | (string & {});
export interface ListModelCardVersionsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    ModelCardName?: string | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
    NextToken?: string | undefined;
    SortBy?: ModelCardVersionSortBy | undefined;
    SortOrder?: ModelCardSortOrder | undefined;
}
export interface ModelCardVersionSummary {
    ModelCardName?: string | undefined;
    ModelCardArn?: string | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
    ModelCardVersion?: number | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ModelCardVersionSummaryList = ModelCardVersionSummary[];
export interface ListModelCardVersionsResponse {
    ModelCardVersionSummaryList: (ModelCardVersionSummary & {
        ModelCardName: EntityName;
        ModelCardArn: ModelCardArn;
        ModelCardStatus: ModelCardStatus;
        ModelCardVersion: number;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export interface ListModelExplainabilityJobDefinitionsRequest {
    EndpointName?: string | undefined;
    SortBy?: MonitoringJobDefinitionSortKey | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
}
export interface ListModelExplainabilityJobDefinitionsResponse {
    JobDefinitionSummaries: (MonitoringJobDefinitionSummary & {
        MonitoringJobDefinitionName: MonitoringJobDefinitionName;
        MonitoringJobDefinitionArn: MonitoringJobDefinitionArn;
        CreationTime: Date;
        EndpointName: EndpointName;
    })[];
    NextToken?: string | undefined;
}
export type ModelMetadataFilterType = "Domain" | "Framework" | "Task" | "FrameworkVersion" | (string & {});
export interface ModelMetadataFilter {
    Name?: ModelMetadataFilterType | undefined;
    Value?: string | undefined;
}
export type ModelMetadataFilters = ModelMetadataFilter[];
export interface ModelMetadataSearchExpression {
    Filters?: ModelMetadataFilter[] | undefined;
}
export interface ListModelMetadataRequest {
    SearchExpression?: ModelMetadataSearchExpression | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ModelMetadataSummary {
    Domain?: string | undefined;
    Framework?: string | undefined;
    Task?: string | undefined;
    Model?: string | undefined;
    FrameworkVersion?: string | undefined;
}
export type ModelMetadataSummaries = ModelMetadataSummary[];
export interface ListModelMetadataResponse {
    ModelMetadataSummaries: (ModelMetadataSummary & {
        Domain: string;
        Framework: string;
        Task: string;
        Model: string;
        FrameworkVersion: string;
    })[];
    NextToken?: string | undefined;
}
export type ModelPackageGroupSortBy = "Name" | "CreationTime" | (string & {});
export type CrossAccountFilterOption = "SameAccount" | "CrossAccount" | (string & {});
export interface ListModelPackageGroupsInput {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    SortBy?: ModelPackageGroupSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    CrossAccountFilterOption?: CrossAccountFilterOption | undefined;
}
export interface ModelPackageGroupSummary {
    ModelPackageGroupName?: string | undefined;
    ModelPackageGroupArn?: string | undefined;
    ModelPackageGroupDescription?: string | undefined;
    CreationTime?: Date | undefined;
    ModelPackageGroupStatus?: ModelPackageGroupStatus | undefined;
    ManagedConfiguration?: ManagedConfiguration | undefined;
}
export type ModelPackageGroupSummaryList = ModelPackageGroupSummary[];
export interface ListModelPackageGroupsOutput {
    ModelPackageGroupSummaryList: (ModelPackageGroupSummary & {
        ModelPackageGroupName: EntityName;
        ModelPackageGroupArn: ModelPackageGroupArn;
        CreationTime: CreationTime;
        ModelPackageGroupStatus: ModelPackageGroupStatus;
    })[];
    NextToken?: string | undefined;
}
export type ModelPackageType = "Versioned" | "Unversioned" | "Both" | (string & {});
export type ModelPackageSortBy = "Name" | "CreationTime" | (string & {});
export interface ListModelPackagesInput {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    ModelApprovalStatus?: ModelApprovalStatus | undefined;
    ModelPackageGroupName?: string | undefined;
    ModelPackageType?: ModelPackageType | undefined;
    NextToken?: string | undefined;
    SortBy?: ModelPackageSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface ModelPackageSummary {
    ModelPackageName?: string | undefined;
    ModelPackageGroupName?: string | undefined;
    ModelPackageVersion?: number | undefined;
    ModelPackageArn?: string | undefined;
    ModelPackageDescription?: string | undefined;
    CreationTime?: Date | undefined;
    ModelPackageStatus?: ModelPackageStatus | undefined;
    ModelApprovalStatus?: ModelApprovalStatus | undefined;
    ModelLifeCycle?: ModelLifeCycle | undefined;
    ModelPackageRegistrationType?: ModelPackageRegistrationType | undefined;
}
export type ModelPackageSummaryList = ModelPackageSummary[];
export interface ListModelPackagesOutput {
    ModelPackageSummaryList: (ModelPackageSummary & {
        ModelPackageArn: ModelPackageArn;
        CreationTime: CreationTime;
        ModelPackageStatus: ModelPackageStatus;
        ModelLifeCycle: ModelLifeCycle & {
            Stage: EntityName;
            StageStatus: EntityName;
        };
    })[];
    NextToken?: string | undefined;
}
export interface ListModelQualityJobDefinitionsRequest {
    EndpointName?: string | undefined;
    SortBy?: MonitoringJobDefinitionSortKey | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
}
export interface ListModelQualityJobDefinitionsResponse {
    JobDefinitionSummaries: (MonitoringJobDefinitionSummary & {
        MonitoringJobDefinitionName: MonitoringJobDefinitionName;
        MonitoringJobDefinitionArn: MonitoringJobDefinitionArn;
        CreationTime: Date;
        EndpointName: EndpointName;
    })[];
    NextToken?: string | undefined;
}
export type ModelSortKey = "Name" | "CreationTime" | (string & {});
export type ModelNameContains = string;
export interface ListModelsInput {
    SortBy?: ModelSortKey | undefined;
    SortOrder?: OrderKey | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
}
export interface ModelSummary {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    CreationTime?: Date | undefined;
}
export type ModelSummaryList = ModelSummary[];
export interface ListModelsOutput {
    Models: (ModelSummary & {
        ModelName: ModelName;
        ModelArn: ModelArn;
        CreationTime: Date;
    })[];
    NextToken?: string | undefined;
}
export type MonitoringAlertName = string;
export type MonitoringAlertHistorySortKey = "CreationTime" | "Status" | (string & {});
export type MonitoringAlertStatus = "InAlert" | "OK" | (string & {});
export interface ListMonitoringAlertHistoryRequest {
    MonitoringScheduleName?: string | undefined;
    MonitoringAlertName?: string | undefined;
    SortBy?: MonitoringAlertHistorySortKey | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    StatusEquals?: MonitoringAlertStatus | undefined;
}
export interface MonitoringAlertHistorySummary {
    MonitoringScheduleName?: string | undefined;
    MonitoringAlertName?: string | undefined;
    CreationTime?: Date | undefined;
    AlertStatus?: MonitoringAlertStatus | undefined;
}
export type MonitoringAlertHistoryList = MonitoringAlertHistorySummary[];
export interface ListMonitoringAlertHistoryResponse {
    MonitoringAlertHistory?: (MonitoringAlertHistorySummary & {
        MonitoringScheduleName: MonitoringScheduleName;
        MonitoringAlertName: MonitoringAlertName;
        CreationTime: Date;
        AlertStatus: MonitoringAlertStatus;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMonitoringAlertsRequest {
    MonitoringScheduleName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type MonitoringDatapointsToAlert = number;
export type MonitoringEvaluationPeriod = number;
export interface ModelDashboardIndicatorAction {
    Enabled?: boolean | undefined;
}
export interface MonitoringAlertActions {
    ModelDashboardIndicator?: ModelDashboardIndicatorAction | undefined;
}
export interface MonitoringAlertSummary {
    MonitoringAlertName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    AlertStatus?: MonitoringAlertStatus | undefined;
    DatapointsToAlert?: number | undefined;
    EvaluationPeriod?: number | undefined;
    Actions?: MonitoringAlertActions | undefined;
}
export type MonitoringAlertSummaryList = MonitoringAlertSummary[];
export interface ListMonitoringAlertsResponse {
    MonitoringAlertSummaries?: (MonitoringAlertSummary & {
        MonitoringAlertName: MonitoringAlertName;
        CreationTime: Date;
        LastModifiedTime: Date;
        AlertStatus: MonitoringAlertStatus;
        DatapointsToAlert: MonitoringDatapointsToAlert;
        EvaluationPeriod: MonitoringEvaluationPeriod;
        Actions: MonitoringAlertActions;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type MonitoringExecutionSortKey = "CreationTime" | "ScheduledTime" | "Status" | (string & {});
export interface ListMonitoringExecutionsRequest {
    MonitoringScheduleName?: string | undefined;
    EndpointName?: string | undefined;
    SortBy?: MonitoringExecutionSortKey | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ScheduledTimeBefore?: Date | undefined;
    ScheduledTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    StatusEquals?: ExecutionStatus | undefined;
    MonitoringJobDefinitionName?: string | undefined;
    MonitoringTypeEquals?: MonitoringType | undefined;
}
export type MonitoringExecutionSummaryList = MonitoringExecutionSummary[];
export interface ListMonitoringExecutionsResponse {
    MonitoringExecutionSummaries: (MonitoringExecutionSummary & {
        MonitoringScheduleName: MonitoringScheduleName;
        ScheduledTime: Date;
        CreationTime: Date;
        LastModifiedTime: Date;
        MonitoringExecutionStatus: ExecutionStatus;
    })[];
    NextToken?: string | undefined;
}
export type MonitoringScheduleSortKey = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListMonitoringSchedulesRequest {
    EndpointName?: string | undefined;
    SortBy?: MonitoringScheduleSortKey | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    StatusEquals?: ScheduleStatus | undefined;
    MonitoringJobDefinitionName?: string | undefined;
    MonitoringTypeEquals?: MonitoringType | undefined;
}
export interface MonitoringScheduleSummary {
    MonitoringScheduleName?: string | undefined;
    MonitoringScheduleArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    MonitoringScheduleStatus?: ScheduleStatus | undefined;
    EndpointName?: string | undefined;
    MonitoringJobDefinitionName?: string | undefined;
    MonitoringType?: MonitoringType | undefined;
}
export type MonitoringScheduleSummaryList = MonitoringScheduleSummary[];
export interface ListMonitoringSchedulesResponse {
    MonitoringScheduleSummaries: (MonitoringScheduleSummary & {
        MonitoringScheduleName: MonitoringScheduleName;
        MonitoringScheduleArn: MonitoringScheduleArn;
        CreationTime: Date;
        LastModifiedTime: Date;
        MonitoringScheduleStatus: ScheduleStatus;
    })[];
    NextToken?: string | undefined;
}
export type NotebookInstanceLifecycleConfigSortKey = "Name" | "CreationTime" | "LastModifiedTime" | (string & {});
export type NotebookInstanceLifecycleConfigSortOrder = "Ascending" | "Descending" | (string & {});
export type NotebookInstanceLifecycleConfigNameContains = string;
export interface ListNotebookInstanceLifecycleConfigsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortBy?: NotebookInstanceLifecycleConfigSortKey | undefined;
    SortOrder?: NotebookInstanceLifecycleConfigSortOrder | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
}
export interface NotebookInstanceLifecycleConfigSummary {
    NotebookInstanceLifecycleConfigName?: string | undefined;
    NotebookInstanceLifecycleConfigArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type NotebookInstanceLifecycleConfigSummaryList = NotebookInstanceLifecycleConfigSummary[];
export interface ListNotebookInstanceLifecycleConfigsOutput {
    NextToken?: string | undefined;
    NotebookInstanceLifecycleConfigs?: (NotebookInstanceLifecycleConfigSummary & {
        NotebookInstanceLifecycleConfigName: NotebookInstanceLifecycleConfigName;
        NotebookInstanceLifecycleConfigArn: NotebookInstanceLifecycleConfigArn;
    })[] | undefined;
}
export type NotebookInstanceSortKey = "Name" | "CreationTime" | "Status" | (string & {});
export type NotebookInstanceSortOrder = "Ascending" | "Descending" | (string & {});
export type NotebookInstanceNameContains = string;
export type CodeRepositoryContains = string;
export interface ListNotebookInstancesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortBy?: NotebookInstanceSortKey | undefined;
    SortOrder?: NotebookInstanceSortOrder | undefined;
    NameContains?: string | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    StatusEquals?: NotebookInstanceStatus | undefined;
    NotebookInstanceLifecycleConfigNameContains?: string | undefined;
    DefaultCodeRepositoryContains?: string | undefined;
    AdditionalCodeRepositoryEquals?: string | undefined;
}
export interface NotebookInstanceSummary {
    NotebookInstanceName?: string | undefined;
    NotebookInstanceArn?: string | undefined;
    NotebookInstanceStatus?: NotebookInstanceStatus | undefined;
    Url?: string | undefined;
    InstanceType?: InstanceType | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    NotebookInstanceLifecycleConfigName?: string | undefined;
    DefaultCodeRepository?: string | undefined;
    AdditionalCodeRepositories?: string[] | undefined;
}
export type NotebookInstanceSummaryList = NotebookInstanceSummary[];
export interface ListNotebookInstancesOutput {
    NextToken?: string | undefined;
    NotebookInstances?: (NotebookInstanceSummary & {
        NotebookInstanceName: NotebookInstanceName;
        NotebookInstanceArn: NotebookInstanceArn;
    })[] | undefined;
}
export type ListOptimizationJobsSortBy = "Name" | "CreationTime" | "Status" | (string & {});
export interface ListOptimizationJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    OptimizationContains?: string | undefined;
    NameContains?: string | undefined;
    StatusEquals?: OptimizationJobStatus | undefined;
    SortBy?: ListOptimizationJobsSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type OptimizationType = string;
export type OptimizationTypes = string[];
export interface OptimizationJobSummary {
    OptimizationJobName?: string | undefined;
    OptimizationJobArn?: string | undefined;
    CreationTime?: Date | undefined;
    OptimizationJobStatus?: OptimizationJobStatus | undefined;
    OptimizationStartTime?: Date | undefined;
    OptimizationEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    DeploymentInstanceType?: OptimizationJobDeploymentInstanceType | undefined;
    MaxInstanceCount?: number | undefined;
    OptimizationTypes?: string[] | undefined;
}
export type OptimizationJobSummaries = OptimizationJobSummary[];
export interface ListOptimizationJobsResponse {
    OptimizationJobSummaries: (OptimizationJobSummary & {
        OptimizationJobName: EntityName;
        OptimizationJobArn: OptimizationJobArn;
        CreationTime: CreationTime;
        OptimizationJobStatus: OptimizationJobStatus;
        DeploymentInstanceType: OptimizationJobDeploymentInstanceType;
        OptimizationTypes: OptimizationTypes;
    })[];
    NextToken?: string | undefined;
}
export interface ListPartnerAppsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface PartnerAppSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
    Type?: PartnerAppType | undefined;
    Status?: PartnerAppStatus | undefined;
    CreationTime?: Date | undefined;
}
export type PartnerAppSummaries = PartnerAppSummary[];
export interface ListPartnerAppsResponse {
    Summaries?: PartnerAppSummary[] | undefined;
    NextToken?: string | undefined;
}
export type SortPipelineExecutionsBy = "CreationTime" | "PipelineExecutionArn" | (string & {});
export interface ListPipelineExecutionsRequest {
    PipelineName?: string | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortPipelineExecutionsBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    PipelineVersionAlias?: string | undefined;
}
export type String3072 = string;
export interface PipelineExecutionSummary {
    PipelineExecutionArn?: string | undefined;
    StartTime?: Date | undefined;
    PipelineExecutionStatus?: PipelineExecutionStatus | undefined;
    PipelineExecutionDescription?: string | undefined;
    PipelineExecutionDisplayName?: string | undefined;
    PipelineExecutionFailureReason?: string | undefined;
    PipelineVersionAliases?: string[] | undefined;
}
export type PipelineExecutionSummaryList = PipelineExecutionSummary[];
export interface ListPipelineExecutionsResponse {
    PipelineExecutionSummaries?: PipelineExecutionSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPipelineExecutionStepsRequest {
    PipelineExecutionArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortOrder?: SortOrder | undefined;
}
export type StepName = string;
export type StepDisplayName = string;
export type StepDescription = string;
export type StepStatus = "Starting" | "Executing" | "Stopping" | "Stopped" | "Failed" | "Succeeded" | (string & {});
export interface CacheHitResult {
    SourcePipelineExecutionArn?: string | undefined;
}
export interface TrainingJobStepMetadata {
    Arn?: string | undefined;
}
export interface ProcessingJobStepMetadata {
    Arn?: string | undefined;
}
export interface TransformJobStepMetadata {
    Arn?: string | undefined;
}
export interface TuningJobStepMetaData {
    Arn?: string | undefined;
}
export interface ModelStepMetadata {
    Arn?: string | undefined;
}
export interface RegisterModelStepMetadata {
    Arn?: string | undefined;
}
export type ConditionOutcome = "True" | "False" | (string & {});
export interface ConditionStepMetadata {
    Outcome?: ConditionOutcome | undefined;
}
export type CallbackToken = string;
export interface OutputParameter {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type OutputParameterList = OutputParameter[];
export interface CallbackStepMetadata {
    CallbackToken?: string | undefined;
    SqsQueueUrl?: string | undefined;
    OutputParameters?: OutputParameter[] | undefined;
}
export interface LambdaStepMetadata {
    Arn?: string | undefined;
    OutputParameters?: OutputParameter[] | undefined;
}
export interface EMRStepMetadata {
    ClusterId?: string | undefined;
    StepId?: string | undefined;
    StepName?: string | undefined;
    LogFilePath?: string | undefined;
}
export type EMRServerlessApplicationId = string;
export type EMRServerlessJobRunId = string;
export interface EMRServerlessStepMetadata {
    ApplicationId?: string | undefined;
    JobRunId?: string | undefined;
    JobRunName?: string | undefined;
    LogFilePath?: string | undefined;
}
export interface QualityCheckStepMetadata {
    CheckType?: string | undefined;
    BaselineUsedForDriftCheckStatistics?: string | undefined;
    BaselineUsedForDriftCheckConstraints?: string | undefined;
    CalculatedBaselineStatistics?: string | undefined;
    CalculatedBaselineConstraints?: string | undefined;
    ModelPackageGroupName?: string | undefined;
    ViolationReport?: string | undefined;
    CheckJobArn?: string | undefined;
    SkipCheck?: boolean | undefined;
    RegisterNewBaseline?: boolean | undefined;
}
export interface ClarifyCheckStepMetadata {
    CheckType?: string | undefined;
    BaselineUsedForDriftCheckConstraints?: string | undefined;
    CalculatedBaselineConstraints?: string | undefined;
    ModelPackageGroupName?: string | undefined;
    ViolationReport?: string | undefined;
    CheckJobArn?: string | undefined;
    SkipCheck?: boolean | undefined;
    RegisterNewBaseline?: boolean | undefined;
}
export interface FailStepMetadata {
    ErrorMessage?: string | undefined;
}
export interface AutoMLJobStepMetadata {
    Arn?: string | undefined;
}
export interface EndpointStepMetadata {
    Arn?: string | undefined;
}
export interface EndpointConfigStepMetadata {
    Arn?: string | undefined;
}
export interface BedrockCustomModelMetadata {
    Arn?: string | undefined;
}
export interface BedrockCustomModelDeploymentMetadata {
    Arn?: string | undefined;
}
export interface BedrockProvisionedModelThroughputMetadata {
    Arn?: string | undefined;
}
export interface BedrockModelImportMetadata {
    Arn?: string | undefined;
}
export interface InferenceComponentMetadata {
    Arn?: string | undefined;
}
export type MapString2048 = {
    [key: string]: string | undefined;
};
export interface AssociationInfo {
    SourceArn?: string | undefined;
    DestinationArn?: string | undefined;
}
export type AssociationInfoList = AssociationInfo[];
export interface LineageMetadata {
    ActionArns?: {
        [key: string]: string | undefined;
    } | undefined;
    ArtifactArns?: {
        [key: string]: string | undefined;
    } | undefined;
    ContextArns?: {
        [key: string]: string | undefined;
    } | undefined;
    Associations?: AssociationInfo[] | undefined;
}
export interface JobStepMetadata {
    Arn?: string | undefined;
}
export interface AthenaStepMetadata {
    QueryExecutionId?: string | undefined;
    S3OutputLocation?: string | undefined;
}
export type CleanupStepNameList = string[];
export type CleanupFailureErrorCode = "ClientError" | "InternalFailure" | (string & {});
export interface CleanupFailure {
    StepName?: string | undefined;
    ErrorCode?: CleanupFailureErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type CleanupFailureList = CleanupFailure[];
export interface CleanupStepMetadata {
    CleanedSteps?: string[] | undefined;
    FailedSteps?: CleanupFailure[] | undefined;
    SkippedSteps?: string[] | undefined;
}
export type ForEachStatus = "Succeeded" | "Failed" | "Stopped" | (string & {});
export interface ForEachSelectorResult {
    StepName?: string | undefined;
    Index?: number | undefined;
}
export interface ForEachStepMetadata {
    Status?: ForEachStatus | undefined;
    InputItemCount?: number | undefined;
    TotalStepCount?: number | undefined;
    SucceededStepCount?: number | undefined;
    FailedStepCount?: number | undefined;
    StoppedStepCount?: number | undefined;
    Selector?: ForEachSelectorResult | undefined;
}
export interface HubContentStepMetadata {
    HubArn?: string | undefined;
    HubContentArn?: string | undefined;
}
export interface PipelineExecutionStepMetadata {
    TrainingJob?: TrainingJobStepMetadata | undefined;
    ProcessingJob?: ProcessingJobStepMetadata | undefined;
    TransformJob?: TransformJobStepMetadata | undefined;
    TuningJob?: TuningJobStepMetaData | undefined;
    Model?: ModelStepMetadata | undefined;
    RegisterModel?: RegisterModelStepMetadata | undefined;
    Condition?: ConditionStepMetadata | undefined;
    Callback?: CallbackStepMetadata | undefined;
    Lambda?: LambdaStepMetadata | undefined;
    EMR?: EMRStepMetadata | undefined;
    EMRServerless?: EMRServerlessStepMetadata | undefined;
    QualityCheck?: QualityCheckStepMetadata | undefined;
    ClarifyCheck?: ClarifyCheckStepMetadata | undefined;
    Fail?: FailStepMetadata | undefined;
    AutoMLJob?: AutoMLJobStepMetadata | undefined;
    Endpoint?: EndpointStepMetadata | undefined;
    EndpointConfig?: EndpointConfigStepMetadata | undefined;
    BedrockCustomModel?: BedrockCustomModelMetadata | undefined;
    BedrockCustomModelDeployment?: BedrockCustomModelDeploymentMetadata | undefined;
    BedrockProvisionedModelThroughput?: BedrockProvisionedModelThroughputMetadata | undefined;
    BedrockModelImport?: BedrockModelImportMetadata | undefined;
    InferenceComponent?: InferenceComponentMetadata | undefined;
    Lineage?: LineageMetadata | undefined;
    Job?: JobStepMetadata | undefined;
    Athena?: AthenaStepMetadata | undefined;
    Cleanup?: CleanupStepMetadata | undefined;
    ForEach?: ForEachStepMetadata | undefined;
    HubContent?: HubContentStepMetadata | undefined;
}
export interface SelectiveExecutionResult {
    SourcePipelineExecutionArn?: string | undefined;
}
export type String12800 = string;
export interface IterationContext {
    ParentStepName?: string | undefined;
    Index?: number | undefined;
    Item?: string | undefined;
}
export interface PipelineExecutionStep {
    StepName?: string | undefined;
    StepDisplayName?: string | undefined;
    StepDescription?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    StepStatus?: StepStatus | undefined;
    CacheHitResult?: CacheHitResult | undefined;
    FailureReason?: string | undefined;
    Metadata?: PipelineExecutionStepMetadata | undefined;
    AttemptCount?: number | undefined;
    SelectiveExecutionResult?: SelectiveExecutionResult | undefined;
    IterationContext?: IterationContext | undefined;
}
export type PipelineExecutionStepList = PipelineExecutionStep[];
export interface ListPipelineExecutionStepsResponse {
    PipelineExecutionSteps?: (PipelineExecutionStep & {
        Metadata: PipelineExecutionStepMetadata & {
            Callback: CallbackStepMetadata & {
                OutputParameters: (OutputParameter & {
                    Name: String256;
                    Value: String1024;
                })[];
            };
            Lambda: LambdaStepMetadata & {
                OutputParameters: (OutputParameter & {
                    Name: String256;
                    Value: String1024;
                })[];
            };
            Lineage: LineageMetadata & {
                Associations: (AssociationInfo & {
                    SourceArn: String2048;
                    DestinationArn: String2048;
                })[];
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPipelineParametersForExecutionRequest {
    PipelineExecutionArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type PipelineParameterName = string;
export interface Parameter {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type ParameterList = Parameter[];
export interface ListPipelineParametersForExecutionResponse {
    PipelineParameters?: (Parameter & {
        Name: PipelineParameterName;
        Value: String1024;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type SortPipelinesBy = "Name" | "CreationTime" | (string & {});
export type PipelineManagedBy = "AWS" | "CUSTOMER" | (string & {});
export interface ListPipelinesRequest {
    PipelineNamePrefix?: string | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortPipelinesBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ManagedBy?: PipelineManagedBy | undefined;
}
export interface PipelineSummary {
    PipelineArn?: string | undefined;
    PipelineName?: string | undefined;
    PipelineDisplayName?: string | undefined;
    PipelineDescription?: string | undefined;
    RoleArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastExecutionTime?: Date | undefined;
}
export type PipelineSummaryList = PipelineSummary[];
export interface ListPipelinesResponse {
    PipelineSummaries?: PipelineSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPipelineVersionsRequest {
    PipelineName?: string | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface PipelineVersionSummary {
    PipelineArn?: string | undefined;
    PipelineVersionId?: number | undefined;
    CreationTime?: Date | undefined;
    PipelineVersionDescription?: string | undefined;
    PipelineVersionDisplayName?: string | undefined;
    LastExecutionPipelineExecutionArn?: string | undefined;
    PipelineVersionAliases?: string[] | undefined;
}
export type PipelineVersionSummaryList = PipelineVersionSummary[];
export interface ListPipelineVersionsResponse {
    PipelineVersionSummaries?: PipelineVersionSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProcessingJobsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    StatusEquals?: ProcessingJobStatus | undefined;
    SortBy?: SortBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ProcessingJobSummary {
    ProcessingJobName?: string | undefined;
    ProcessingJobArn?: string | undefined;
    CreationTime?: Date | undefined;
    ProcessingEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    ProcessingJobStatus?: ProcessingJobStatus | undefined;
    FailureReason?: string | undefined;
    ExitMessage?: string | undefined;
}
export type ProcessingJobSummaries = ProcessingJobSummary[];
export interface ListProcessingJobsResponse {
    ProcessingJobSummaries: (ProcessingJobSummary & {
        ProcessingJobName: ProcessingJobName;
        ProcessingJobArn: ProcessingJobArn;
        CreationTime: Date;
        ProcessingJobStatus: ProcessingJobStatus;
    })[];
    NextToken?: string | undefined;
}
export type ProjectSortBy = "Name" | "CreationTime" | (string & {});
export type ProjectSortOrder = "Ascending" | "Descending" | (string & {});
export interface ListProjectsInput {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    SortBy?: ProjectSortBy | undefined;
    SortOrder?: ProjectSortOrder | undefined;
}
export interface ProjectSummary {
    ProjectName?: string | undefined;
    ProjectDescription?: string | undefined;
    ProjectArn?: string | undefined;
    ProjectId?: string | undefined;
    CreationTime?: Date | undefined;
    ProjectStatus?: ProjectStatus | undefined;
}
export type ProjectSummaryList = ProjectSummary[];
export interface ListProjectsOutput {
    ProjectSummaryList: (ProjectSummary & {
        ProjectName: ProjectEntityName;
        ProjectArn: ProjectArn;
        ProjectId: ProjectId;
        CreationTime: Date;
        ProjectStatus: ProjectStatus;
    })[];
    NextToken?: string | undefined;
}
export type ResourceCatalogName = string;
export type ResourceCatalogSortOrder = "Ascending" | "Descending" | (string & {});
export type ResourceCatalogSortBy = "CreationTime" | (string & {});
export interface ListResourceCatalogsRequest {
    NameContains?: string | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    SortOrder?: ResourceCatalogSortOrder | undefined;
    SortBy?: ResourceCatalogSortBy | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ResourceCatalogArn = string;
export type ResourceCatalogDescription = string;
export interface ResourceCatalog {
    ResourceCatalogArn?: string | undefined;
    ResourceCatalogName?: string | undefined;
    Description?: string | undefined;
    CreationTime?: Date | undefined;
}
export type ResourceCatalogList = ResourceCatalog[];
export interface ListResourceCatalogsResponse {
    ResourceCatalogs?: (ResourceCatalog & {
        ResourceCatalogArn: ResourceCatalogArn;
        ResourceCatalogName: ResourceCatalogName;
        Description: ResourceCatalogDescription;
        CreationTime: Date;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type SpaceSortKey = "CreationTime" | "LastModifiedTime" | (string & {});
export interface ListSpacesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortOrder?: SortOrder | undefined;
    SortBy?: SpaceSortKey | undefined;
    DomainIdEquals?: string | undefined;
    SpaceNameContains?: string | undefined;
}
export interface SpaceSettingsSummary {
    AppType?: AppType | undefined;
    RemoteAccess?: FeatureStatus | undefined;
    SpaceStorageSettings?: SpaceStorageSettings | undefined;
}
export interface SpaceSharingSettingsSummary {
    SharingType?: SharingType | undefined;
}
export interface OwnershipSettingsSummary {
    OwnerUserProfileName?: string | undefined;
}
export interface SpaceDetails {
    DomainId?: string | undefined;
    SpaceName?: string | undefined;
    Status?: SpaceStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    SpaceSettingsSummary?: SpaceSettingsSummary | undefined;
    SpaceSharingSettingsSummary?: SpaceSharingSettingsSummary | undefined;
    OwnershipSettingsSummary?: OwnershipSettingsSummary | undefined;
    SpaceDisplayName?: string | undefined;
}
export type SpaceList = SpaceDetails[];
export interface ListSpacesResponse {
    Spaces?: (SpaceDetails & {
        SpaceSettingsSummary: SpaceSettingsSummary & {
            SpaceStorageSettings: SpaceStorageSettings & {
                EbsStorageSettings: EbsStorageSettings & {
                    EbsVolumeSizeInGb: SpaceEbsVolumeSizeInGb;
                };
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListStageDevicesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    EdgeDeploymentPlanName?: string | undefined;
    ExcludeDevicesDeployedInOtherStage?: boolean | undefined;
    StageName?: string | undefined;
}
export type DeviceDeploymentStatus = "READYTODEPLOY" | "INPROGRESS" | "DEPLOYED" | "FAILED" | "STOPPING" | "STOPPED" | (string & {});
export interface DeviceDeploymentSummary {
    EdgeDeploymentPlanArn?: string | undefined;
    EdgeDeploymentPlanName?: string | undefined;
    StageName?: string | undefined;
    DeployedStageName?: string | undefined;
    DeviceFleetName?: string | undefined;
    DeviceName?: string | undefined;
    DeviceArn?: string | undefined;
    DeviceDeploymentStatus?: DeviceDeploymentStatus | undefined;
    DeviceDeploymentStatusMessage?: string | undefined;
    Description?: string | undefined;
    DeploymentStartTime?: Date | undefined;
}
export type DeviceDeploymentSummaries = DeviceDeploymentSummary[];
export interface ListStageDevicesResponse {
    DeviceDeploymentSummaries: (DeviceDeploymentSummary & {
        EdgeDeploymentPlanArn: EdgeDeploymentPlanArn;
        EdgeDeploymentPlanName: EntityName;
        StageName: EntityName;
        DeviceName: DeviceName;
        DeviceArn: DeviceArn;
    })[];
    NextToken?: string | undefined;
}
export type StudioLifecycleConfigSortKey = "CreationTime" | "LastModifiedTime" | "Name" | (string & {});
export interface ListStudioLifecycleConfigsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    NameContains?: string | undefined;
    AppTypeEquals?: StudioLifecycleConfigAppType | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
    ModifiedTimeBefore?: Date | undefined;
    ModifiedTimeAfter?: Date | undefined;
    SortBy?: StudioLifecycleConfigSortKey | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface StudioLifecycleConfigDetails {
    StudioLifecycleConfigArn?: string | undefined;
    StudioLifecycleConfigName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    StudioLifecycleConfigAppType?: StudioLifecycleConfigAppType | undefined;
}
export type StudioLifecycleConfigsList = StudioLifecycleConfigDetails[];
export interface ListStudioLifecycleConfigsResponse {
    NextToken?: string | undefined;
    StudioLifecycleConfigs?: StudioLifecycleConfigDetails[] | undefined;
}
export interface ListSubscribedWorkteamsRequest {
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type SubscribedWorkteams = SubscribedWorkteam[];
export interface ListSubscribedWorkteamsResponse {
    SubscribedWorkteams: (SubscribedWorkteam & {
        WorkteamArn: WorkteamArn;
    })[];
    NextToken?: string | undefined;
}
export type ListTagsMaxResults = number;
export interface ListTagsInput {
    ResourceArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListTagsOutput {
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTrainingJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    StatusEquals?: TrainingJobStatus | undefined;
    SortBy?: SortBy | undefined;
    SortOrder?: SortOrder | undefined;
    WarmPoolStatusEquals?: WarmPoolResourceStatus | undefined;
    TrainingPlanArnEquals?: string | undefined;
}
export interface TrainingJobSummary {
    TrainingJobName?: string | undefined;
    TrainingJobArn?: string | undefined;
    CreationTime?: Date | undefined;
    TrainingEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    TrainingJobStatus?: TrainingJobStatus | undefined;
    SecondaryStatus?: SecondaryStatus | undefined;
    WarmPoolStatus?: WarmPoolStatus | undefined;
    TrainingPlanArn?: string | undefined;
}
export type TrainingJobSummaries = TrainingJobSummary[];
export interface ListTrainingJobsResponse {
    TrainingJobSummaries: (TrainingJobSummary & {
        TrainingJobName: TrainingJobName;
        TrainingJobArn: TrainingJobArn;
        CreationTime: Date;
        TrainingJobStatus: TrainingJobStatus;
        WarmPoolStatus: WarmPoolStatus & {
            Status: WarmPoolResourceStatus;
        };
    })[];
    NextToken?: string | undefined;
}
export type TrainingJobSortByOptions = "Name" | "CreationTime" | "Status" | "FinalObjectiveMetricValue" | (string & {});
export interface ListTrainingJobsForHyperParameterTuningJobRequest {
    HyperParameterTuningJobName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    StatusEquals?: TrainingJobStatus | undefined;
    SortBy?: TrainingJobSortByOptions | undefined;
    SortOrder?: SortOrder | undefined;
}
export type HyperParameterTrainingJobSummaries = HyperParameterTrainingJobSummary[];
export interface ListTrainingJobsForHyperParameterTuningJobResponse {
    TrainingJobSummaries: (HyperParameterTrainingJobSummary & {
        TrainingJobName: TrainingJobName;
        TrainingJobArn: TrainingJobArn;
        CreationTime: Date;
        TrainingJobStatus: TrainingJobStatus;
        TunedHyperParameters: HyperParameters;
        FinalHyperParameterTuningJobObjectiveMetric: FinalHyperParameterTuningJobObjectiveMetric & {
            MetricName: MetricName;
            Value: MetricValue;
        };
    })[];
    NextToken?: string | undefined;
}
export type TrainingPlanSortBy = "TrainingPlanName" | "StartTime" | "Status" | (string & {});
export type TrainingPlanSortOrder = "Ascending" | "Descending" | (string & {});
export type TrainingPlanFilterName = "Status" | (string & {});
export interface TrainingPlanFilter {
    Name?: TrainingPlanFilterName | undefined;
    Value?: string | undefined;
}
export type TrainingPlanFilters = TrainingPlanFilter[];
export interface ListTrainingPlansRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    StartTimeAfter?: Date | undefined;
    StartTimeBefore?: Date | undefined;
    SortBy?: TrainingPlanSortBy | undefined;
    SortOrder?: TrainingPlanSortOrder | undefined;
    Filters?: TrainingPlanFilter[] | undefined;
}
export interface TrainingPlanSummary {
    TrainingPlanArn?: string | undefined;
    TrainingPlanName?: string | undefined;
    Status?: TrainingPlanStatus | undefined;
    StatusMessage?: string | undefined;
    DurationHours?: number | undefined;
    DurationMinutes?: number | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    UpfrontFee?: string | undefined;
    CurrencyCode?: string | undefined;
    TotalInstanceCount?: number | undefined;
    AvailableInstanceCount?: number | undefined;
    InUseInstanceCount?: number | undefined;
    TotalUltraServerCount?: number | undefined;
    TargetResources?: SageMakerResourceName[] | undefined;
    ReservedCapacitySummaries?: ReservedCapacitySummary[] | undefined;
}
export type TrainingPlanSummaries = TrainingPlanSummary[];
export interface ListTrainingPlansResponse {
    NextToken?: string | undefined;
    TrainingPlanSummaries: (TrainingPlanSummary & {
        TrainingPlanArn: TrainingPlanArn;
        TrainingPlanName: TrainingPlanName;
        Status: TrainingPlanStatus;
        ReservedCapacitySummaries: (ReservedCapacitySummary & {
            ReservedCapacityArn: ReservedCapacityArn;
            InstanceType: ReservedCapacityInstanceType;
            TotalInstanceCount: TotalInstanceCount;
            Status: ReservedCapacityStatus;
        })[];
    })[];
}
export interface ListTrainingSessionsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    StatusEquals?: TrainingSessionStatus | undefined;
}
export interface TrainingSessionSummary {
    TrainingSessionArn?: string | undefined;
    TrainingSessionStatus?: TrainingSessionStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type TrainingSessionSummaries = TrainingSessionSummary[];
export interface ListTrainingSessionsResponse {
    NextToken?: string | undefined;
    TrainingSessionSummaries?: (TrainingSessionSummary & {
        TrainingSessionArn: TrainingSessionArn;
        TrainingSessionStatus: TrainingSessionStatus;
        CreationTime: Date;
    })[] | undefined;
}
export interface ListTransformJobsRequest {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
    LastModifiedTimeAfter?: Date | undefined;
    LastModifiedTimeBefore?: Date | undefined;
    NameContains?: string | undefined;
    StatusEquals?: TransformJobStatus | undefined;
    SortBy?: SortBy | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TransformJobSummary {
    TransformJobName?: string | undefined;
    TransformJobArn?: string | undefined;
    CreationTime?: Date | undefined;
    TransformEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    TransformJobStatus?: TransformJobStatus | undefined;
    FailureReason?: string | undefined;
}
export type TransformJobSummaries = TransformJobSummary[];
export interface ListTransformJobsResponse {
    TransformJobSummaries: (TransformJobSummary & {
        TransformJobName: TransformJobName;
        TransformJobArn: TransformJobArn;
        CreationTime: Date;
        TransformJobStatus: TransformJobStatus;
    })[];
    NextToken?: string | undefined;
}
export type SortTrialComponentsBy = "Name" | "CreationTime" | (string & {});
export interface ListTrialComponentsRequest {
    ExperimentName?: string | undefined;
    TrialName?: string | undefined;
    SourceArn?: string | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortTrialComponentsBy | undefined;
    SortOrder?: SortOrder | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface TrialComponentSummary {
    TrialComponentName?: string | undefined;
    TrialComponentArn?: string | undefined;
    DisplayName?: string | undefined;
    TrialComponentSource?: TrialComponentSource | undefined;
    Status?: TrialComponentStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export type TrialComponentSummaries = TrialComponentSummary[];
export interface ListTrialComponentsResponse {
    TrialComponentSummaries?: (TrialComponentSummary & {
        TrialComponentSource: TrialComponentSource & {
            SourceArn: TrialComponentSourceArn;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type SortTrialsBy = "Name" | "CreationTime" | (string & {});
export interface ListTrialsRequest {
    ExperimentName?: string | undefined;
    TrialComponentName?: string | undefined;
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    SortBy?: SortTrialsBy | undefined;
    SortOrder?: SortOrder | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface TrialSummary {
    TrialArn?: string | undefined;
    TrialName?: string | undefined;
    DisplayName?: string | undefined;
    TrialSource?: TrialSource | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type TrialSummaries = TrialSummary[];
export interface ListTrialsResponse {
    TrialSummaries?: (TrialSummary & {
        TrialSource: TrialSource & {
            SourceArn: TrialSourceArn;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListUltraServersByReservedCapacityRequest {
    ReservedCapacityArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ConfiguredSpareInstanceCount = number;
export type UltraServerHealthStatus = "OK" | "Impaired" | "Insufficient-Data" | (string & {});
export interface UltraServer {
    UltraServerId?: string | undefined;
    UltraServerType?: string | undefined;
    AvailabilityZone?: string | undefined;
    InstanceType?: ReservedCapacityInstanceType | undefined;
    TotalInstanceCount?: number | undefined;
    ConfiguredSpareInstanceCount?: number | undefined;
    AvailableInstanceCount?: number | undefined;
    InUseInstanceCount?: number | undefined;
    AvailableSpareInstanceCount?: number | undefined;
    UnhealthyInstanceCount?: number | undefined;
    HealthStatus?: UltraServerHealthStatus | undefined;
}
export type UltraServers = UltraServer[];
export interface ListUltraServersByReservedCapacityResponse {
    NextToken?: string | undefined;
    UltraServers: (UltraServer & {
        UltraServerId: NonEmptyString256;
        UltraServerType: UltraServerType;
        AvailabilityZone: AvailabilityZone;
        InstanceType: ReservedCapacityInstanceType;
        TotalInstanceCount: TotalInstanceCount;
    })[];
}
export type UserProfileSortKey = "CreationTime" | "LastModifiedTime" | (string & {});
export interface ListUserProfilesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortOrder?: SortOrder | undefined;
    SortBy?: UserProfileSortKey | undefined;
    DomainIdEquals?: string | undefined;
    UserProfileNameContains?: string | undefined;
}
export interface UserProfileDetails {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    Status?: UserProfileStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type UserProfileList = UserProfileDetails[];
export interface ListUserProfilesResponse {
    UserProfiles?: UserProfileDetails[] | undefined;
    NextToken?: string | undefined;
}
export type ListWorkforcesSortByOptions = "Name" | "CreateDate" | (string & {});
export interface ListWorkforcesRequest {
    SortBy?: ListWorkforcesSortByOptions | undefined;
    SortOrder?: SortOrder | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Workforces = Workforce[];
export interface ListWorkforcesResponse {
    Workforces: (Workforce & {
        WorkforceName: WorkforceName;
        WorkforceArn: WorkforceArn;
        SourceIpConfig: SourceIpConfig & {
            Cidrs: Cidrs;
        };
        CognitoConfig: CognitoConfig & {
            UserPool: CognitoUserPool;
            ClientId: ClientId;
        };
        WorkforceVpcConfig: WorkforceVpcConfigResponse & {
            VpcId: WorkforceVpcId;
            SecurityGroupIds: WorkforceSecurityGroupIds;
            Subnets: WorkforceSubnets;
        };
    })[];
    NextToken?: string | undefined;
}
export type ListWorkteamsSortByOptions = "Name" | "CreateDate" | (string & {});
export interface ListWorkteamsRequest {
    SortBy?: ListWorkteamsSortByOptions | undefined;
    SortOrder?: SortOrder | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Workteams = Workteam[];
export interface ListWorkteamsResponse {
    Workteams: (Workteam & {
        WorkteamName: WorkteamName;
        MemberDefinitions: (MemberDefinition & {
            CognitoMemberDefinition: CognitoMemberDefinition & {
                UserPool: CognitoUserPool;
                UserGroup: CognitoUserGroup;
                ClientId: ClientId;
            };
        })[];
        WorkteamArn: WorkteamArn;
        Description: String200;
    })[];
    NextToken?: string | undefined;
}
export interface PutModelPackageGroupPolicyInput {
    ModelPackageGroupName?: string | undefined;
    ResourcePolicy?: string | undefined;
}
export interface PutModelPackageGroupPolicyOutput {
    ModelPackageGroupArn: string;
}
export type QueryLineageStartArns = string[];
export type Direction = "Both" | "Ascendants" | "Descendants" | (string & {});
export type String40 = string;
export type QueryTypes = string[];
export type LineageType = "TrialComponent" | "Artifact" | "Context" | "Action" | (string & {});
export type QueryLineageTypes = LineageType[];
export type QueryProperties = {
    [key: string]: string | undefined;
};
export interface QueryFilters {
    Types?: string[] | undefined;
    LineageTypes?: LineageType[] | undefined;
    CreatedBefore?: Date | undefined;
    CreatedAfter?: Date | undefined;
    ModifiedBefore?: Date | undefined;
    ModifiedAfter?: Date | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type QueryLineageMaxDepth = number;
export type QueryLineageMaxResults = number;
export type String8192 = string;
export interface QueryLineageRequest {
    StartArns?: string[] | undefined;
    Direction?: Direction | undefined;
    IncludeEdges?: boolean | undefined;
    Filters?: QueryFilters | undefined;
    MaxDepth?: number | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Vertex {
    Arn?: string | undefined;
    Type?: string | undefined;
    LineageType?: LineageType | undefined;
}
export type Vertices = Vertex[];
export interface Edge {
    SourceArn?: string | undefined;
    DestinationArn?: string | undefined;
    AssociationType?: AssociationEdgeType | undefined;
}
export type Edges = Edge[];
export interface QueryLineageResponse {
    Vertices?: Vertex[] | undefined;
    Edges?: Edge[] | undefined;
    NextToken?: string | undefined;
}
export interface Device {
    DeviceName?: string | undefined;
    Description?: string | undefined;
    IotThingName?: string | undefined;
}
export type Devices = Device[];
export interface RegisterDevicesRequest {
    DeviceFleetName?: string | undefined;
    Devices?: Device[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface RegisterDevicesResponse {
}
export type TaskInput = string;
export interface RenderableTask {
    Input?: string | undefined;
}
export interface RenderUiTemplateRequest {
    UiTemplate?: UiTemplate | undefined;
    Task?: RenderableTask | undefined;
    RoleArn?: string | undefined;
    HumanTaskUiArn?: string | undefined;
}
export interface RenderingError {
    Code?: string | undefined;
    Message?: string | undefined;
}
export type RenderingErrorList = RenderingError[];
export interface RenderUiTemplateResponse {
    RenderedContent: string;
    Errors: (RenderingError & {
        Code: string;
        Message: string;
    })[];
}
export interface RetryPipelineExecutionRequest {
    PipelineExecutionArn?: string | undefined;
    ClientRequestToken?: string | undefined;
    ParallelismConfiguration?: ParallelismConfiguration | undefined;
}
export interface RetryPipelineExecutionResponse {
    PipelineExecutionArn?: string | undefined;
}
export type Operator = "Equals" | "NotEquals" | "GreaterThan" | "GreaterThanOrEqualTo" | "LessThan" | "LessThanOrEqualTo" | "Contains" | "Exists" | "NotExists" | "In" | (string & {});
export type FilterValue = string;
export interface Filter {
    Name?: string | undefined;
    Operator?: Operator | undefined;
    Value?: string | undefined;
}
export type FilterList = Filter[];
export interface NestedFilters {
    NestedPropertyName?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type NestedFiltersList = NestedFilters[];
export type SearchExpressionList = SearchExpression[];
export type BooleanOperator = "And" | "Or" | (string & {});
export interface SearchExpression {
    Filters?: Filter[] | undefined;
    NestedFilters?: NestedFilters[] | undefined;
    SubExpressions?: SearchExpression[] | undefined;
    Operator?: BooleanOperator | undefined;
}
export type SearchSortOrder = "Ascending" | "Descending" | (string & {});
export type VisibilityConditionsKey = string;
export type VisibilityConditionsValue = string;
export interface VisibilityConditions {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type VisibilityConditionsList = VisibilityConditions[];
export interface SearchRequest {
    Resource?: ResourceType | undefined;
    SearchExpression?: SearchExpression | undefined;
    SortBy?: string | undefined;
    SortOrder?: SearchSortOrder | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CrossAccountFilterOption?: CrossAccountFilterOption | undefined;
    VisibilityConditions?: VisibilityConditions[] | undefined;
}
export interface TrainingJob {
    TrainingJobName?: string | undefined;
    TrainingJobArn?: string | undefined;
    TuningJobArn?: string | undefined;
    LabelingJobArn?: string | undefined;
    AutoMLJobArn?: string | undefined;
    ModelArtifacts?: ModelArtifacts | undefined;
    TrainingJobStatus?: TrainingJobStatus | undefined;
    SecondaryStatus?: SecondaryStatus | undefined;
    FailureReason?: string | undefined;
    HyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AlgorithmSpecification?: AlgorithmSpecification | undefined;
    RoleArn?: string | undefined;
    InputDataConfig?: Channel[] | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    ResourceConfig?: ResourceConfig | undefined;
    WarmPoolStatus?: WarmPoolStatus | undefined;
    VpcConfig?: VpcConfig | undefined;
    StoppingCondition?: StoppingCondition | undefined;
    CreationTime?: Date | undefined;
    TrainingStartTime?: Date | undefined;
    TrainingEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    SecondaryStatusTransitions?: SecondaryStatusTransition[] | undefined;
    FinalMetricDataList?: MetricData[] | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    EnableInterContainerTrafficEncryption?: boolean | undefined;
    EnableManagedSpotTraining?: boolean | undefined;
    CheckpointConfig?: CheckpointConfig | undefined;
    TrainingTimeInSeconds?: number | undefined;
    BillableTimeInSeconds?: number | undefined;
    DebugHookConfig?: DebugHookConfig | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
    DebugRuleConfigurations?: DebugRuleConfiguration[] | undefined;
    TensorBoardOutputConfig?: TensorBoardOutputConfig | undefined;
    DebugRuleEvaluationStatuses?: DebugRuleEvaluationStatus[] | undefined;
    OutputModelPackageArn?: string | undefined;
    ModelPackageConfig?: ModelPackageConfig | undefined;
    ProfilerConfig?: ProfilerConfig | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    RetryStrategy?: RetryStrategy | undefined;
    Tags?: Tag[] | undefined;
}
export interface Experiment {
    ExperimentName?: string | undefined;
    ExperimentArn?: string | undefined;
    DisplayName?: string | undefined;
    Source?: ExperimentSource | undefined;
    Description?: string | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    Tags?: Tag[] | undefined;
}
export interface TrialComponentSimpleSummary {
    TrialComponentName?: string | undefined;
    TrialComponentArn?: string | undefined;
    TrialComponentSource?: TrialComponentSource | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
}
export type TrialComponentSimpleSummaries = TrialComponentSimpleSummary[];
export interface Trial {
    TrialName?: string | undefined;
    TrialArn?: string | undefined;
    DisplayName?: string | undefined;
    ExperimentName?: string | undefined;
    Source?: TrialSource | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    Tags?: Tag[] | undefined;
    TrialComponentSummaries?: TrialComponentSimpleSummary[] | undefined;
}
export interface ProcessingJob {
    ProcessingInputs?: ProcessingInput[] | undefined;
    ProcessingOutputConfig?: ProcessingOutputConfig | undefined;
    ProcessingJobName?: string | undefined;
    ProcessingResources?: ProcessingResources | undefined;
    StoppingCondition?: ProcessingStoppingCondition | undefined;
    AppSpecification?: AppSpecification | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    NetworkConfig?: NetworkConfig | undefined;
    RoleArn?: string | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
    ProcessingJobArn?: string | undefined;
    ProcessingJobStatus?: ProcessingJobStatus | undefined;
    ExitMessage?: string | undefined;
    FailureReason?: string | undefined;
    ProcessingEndTime?: Date | undefined;
    ProcessingStartTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    CreationTime?: Date | undefined;
    MonitoringScheduleArn?: string | undefined;
    AutoMLJobArn?: string | undefined;
    TrainingJobArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface TransformJob {
    TransformJobName?: string | undefined;
    TransformJobArn?: string | undefined;
    TransformJobStatus?: TransformJobStatus | undefined;
    FailureReason?: string | undefined;
    ModelName?: string | undefined;
    MaxConcurrentTransforms?: number | undefined;
    ModelClientConfig?: ModelClientConfig | undefined;
    MaxPayloadInMB?: number | undefined;
    BatchStrategy?: BatchStrategy | undefined;
    Environment?: {
        [key: string]: string | undefined;
    } | undefined;
    TransformInput?: TransformInput | undefined;
    TransformOutput?: TransformOutput | undefined;
    DataCaptureConfig?: BatchDataCaptureConfig | undefined;
    TransformResources?: TransformResources | undefined;
    CreationTime?: Date | undefined;
    TransformStartTime?: Date | undefined;
    TransformEndTime?: Date | undefined;
    LabelingJobArn?: string | undefined;
    AutoMLJobArn?: string | undefined;
    DataProcessing?: DataProcessing | undefined;
    ExperimentConfig?: ExperimentConfig | undefined;
    Tags?: Tag[] | undefined;
}
export interface TrialComponentSourceDetail {
    SourceArn?: string | undefined;
    TrainingJob?: TrainingJob | undefined;
    ProcessingJob?: ProcessingJob | undefined;
    TransformJob?: TransformJob | undefined;
}
export interface Parent {
    TrialName?: string | undefined;
    ExperimentName?: string | undefined;
}
export type Parents = Parent[];
export interface TrialComponent {
    TrialComponentName?: string | undefined;
    DisplayName?: string | undefined;
    TrialComponentArn?: string | undefined;
    Source?: TrialComponentSource | undefined;
    Status?: TrialComponentStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    Parameters?: {
        [key: string]: TrialComponentParameterValue | undefined;
    } | undefined;
    InputArtifacts?: {
        [key: string]: TrialComponentArtifact | undefined;
    } | undefined;
    OutputArtifacts?: {
        [key: string]: TrialComponentArtifact | undefined;
    } | undefined;
    Metrics?: TrialComponentMetricSummary[] | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    SourceDetail?: TrialComponentSourceDetail | undefined;
    LineageGroupArn?: string | undefined;
    Tags?: Tag[] | undefined;
    Parents?: Parent[] | undefined;
    RunName?: string | undefined;
}
export interface MonitoringSchedule {
    MonitoringScheduleArn?: string | undefined;
    MonitoringScheduleName?: string | undefined;
    MonitoringScheduleStatus?: ScheduleStatus | undefined;
    MonitoringType?: MonitoringType | undefined;
    FailureReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    MonitoringScheduleConfig?: MonitoringScheduleConfig | undefined;
    EndpointName?: string | undefined;
    LastMonitoringExecutionSummary?: MonitoringExecutionSummary | undefined;
    Tags?: Tag[] | undefined;
}
export type MonitoringScheduleList = MonitoringSchedule[];
export interface Endpoint {
    EndpointName?: string | undefined;
    EndpointArn?: string | undefined;
    EndpointConfigName?: string | undefined;
    ProductionVariants?: ProductionVariantSummary[] | undefined;
    DataCaptureConfig?: DataCaptureConfigSummary | undefined;
    EndpointStatus?: EndpointStatus | undefined;
    FailureReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    MonitoringSchedules?: MonitoringSchedule[] | undefined;
    Tags?: Tag[] | undefined;
    ShadowProductionVariants?: ProductionVariantSummary[] | undefined;
}
export interface ModelPackage {
    ModelPackageName?: string | undefined;
    ModelPackageGroupName?: string | undefined;
    ModelPackageVersion?: number | undefined;
    ModelPackageRegistrationType?: ModelPackageRegistrationType | undefined;
    ModelPackageArn?: string | undefined;
    ModelPackageDescription?: string | undefined;
    CreationTime?: Date | undefined;
    InferenceSpecification?: InferenceSpecification | undefined;
    SourceAlgorithmSpecification?: SourceAlgorithmSpecification | undefined;
    ValidationSpecification?: ModelPackageValidationSpecification | undefined;
    ModelPackageStatus?: ModelPackageStatus | undefined;
    ModelPackageStatusDetails?: ModelPackageStatusDetails | undefined;
    CertifyForMarketplace?: boolean | undefined;
    ModelApprovalStatus?: ModelApprovalStatus | undefined;
    CreatedBy?: UserContext | undefined;
    MetadataProperties?: MetadataProperties | undefined;
    ModelMetrics?: ModelMetrics | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    ApprovalDescription?: string | undefined;
    Domain?: string | undefined;
    Task?: string | undefined;
    SamplePayloadUrl?: string | undefined;
    AdditionalInferenceSpecifications?: AdditionalInferenceSpecificationDefinition[] | undefined;
    SourceUri?: string | undefined;
    SecurityConfig?: ModelPackageSecurityConfig | undefined;
    ModelCard?: ModelPackageModelCard | undefined;
    ModelLifeCycle?: ModelLifeCycle | undefined;
    Tags?: Tag[] | undefined;
    CustomerMetadataProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    DriftCheckBaselines?: DriftCheckBaselines | undefined;
    SkipModelValidation?: SkipModelValidation | undefined;
}
export interface ModelPackageGroup {
    ModelPackageGroupName?: string | undefined;
    ModelPackageGroupArn?: string | undefined;
    ModelPackageGroupDescription?: string | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    ModelPackageGroupStatus?: ModelPackageGroupStatus | undefined;
    Tags?: Tag[] | undefined;
}
export interface Pipeline {
    PipelineArn?: string | undefined;
    PipelineName?: string | undefined;
    PipelineDisplayName?: string | undefined;
    PipelineDescription?: string | undefined;
    RoleArn?: string | undefined;
    PipelineStatus?: PipelineStatus | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastRunTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedBy?: UserContext | undefined;
    ParallelismConfiguration?: ParallelismConfiguration | undefined;
    Tags?: Tag[] | undefined;
}
export interface PipelineExecution {
    PipelineArn?: string | undefined;
    PipelineExecutionArn?: string | undefined;
    PipelineExecutionDisplayName?: string | undefined;
    PipelineExecutionStatus?: PipelineExecutionStatus | undefined;
    PipelineExecutionDescription?: string | undefined;
    PipelineExperimentConfig?: PipelineExperimentConfig | undefined;
    FailureReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedBy?: UserContext | undefined;
    ParallelismConfiguration?: ParallelismConfiguration | undefined;
    SelectiveExecutionConfig?: SelectiveExecutionConfig | undefined;
    PipelineParameters?: Parameter[] | undefined;
    PipelineVersionId?: number | undefined;
    PipelineVersionDisplayName?: string | undefined;
}
export interface PipelineVersion {
    PipelineArn?: string | undefined;
    PipelineVersionId?: number | undefined;
    PipelineVersionDisplayName?: string | undefined;
    PipelineVersionDescription?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedBy?: UserContext | undefined;
    LastExecutedPipelineExecutionArn?: string | undefined;
    LastExecutedPipelineExecutionDisplayName?: string | undefined;
    LastExecutedPipelineExecutionStatus?: PipelineExecutionStatus | undefined;
    PipelineVersionAliases?: string[] | undefined;
}
export interface FeatureGroup {
    FeatureGroupArn?: string | undefined;
    FeatureGroupName?: string | undefined;
    RecordIdentifierFeatureName?: string | undefined;
    EventTimeFeatureName?: string | undefined;
    FeatureDefinitions?: FeatureDefinition[] | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    OnlineStoreConfig?: OnlineStoreConfig | undefined;
    OfflineStoreConfig?: OfflineStoreConfig | undefined;
    RoleArn?: string | undefined;
    FeatureGroupStatus?: FeatureGroupStatus | undefined;
    OfflineStoreStatus?: OfflineStoreStatus | undefined;
    LastUpdateStatus?: LastUpdateStatus | undefined;
    FailureReason?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface FeatureMetadata {
    FeatureGroupArn?: string | undefined;
    FeatureGroupName?: string | undefined;
    FeatureName?: string | undefined;
    FeatureType?: FeatureType | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    Description?: string | undefined;
    Parameters?: FeatureParameter[] | undefined;
}
export interface Project {
    ProjectArn?: string | undefined;
    ProjectName?: string | undefined;
    ProjectId?: string | undefined;
    ProjectDescription?: string | undefined;
    ServiceCatalogProvisioningDetails?: ServiceCatalogProvisioningDetails | undefined;
    ServiceCatalogProvisionedProductDetails?: ServiceCatalogProvisionedProductDetails | undefined;
    ProjectStatus?: ProjectStatus | undefined;
    CreatedBy?: UserContext | undefined;
    CreationTime?: Date | undefined;
    TemplateProviderDetails?: TemplateProviderDetail[] | undefined;
    Tags?: Tag[] | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
}
export interface HyperParameterTuningJobSearchEntity {
    HyperParameterTuningJobName?: string | undefined;
    HyperParameterTuningJobArn?: string | undefined;
    HyperParameterTuningJobConfig?: HyperParameterTuningJobConfig | undefined;
    TrainingJobDefinition?: HyperParameterTrainingJobDefinition | undefined;
    TrainingJobDefinitions?: HyperParameterTrainingJobDefinition[] | undefined;
    HyperParameterTuningJobStatus?: HyperParameterTuningJobStatus | undefined;
    CreationTime?: Date | undefined;
    HyperParameterTuningEndTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    TrainingJobStatusCounters?: TrainingJobStatusCounters | undefined;
    ObjectiveStatusCounters?: ObjectiveStatusCounters | undefined;
    BestTrainingJob?: HyperParameterTrainingJobSummary | undefined;
    OverallBestTrainingJob?: HyperParameterTrainingJobSummary | undefined;
    WarmStartConfig?: HyperParameterTuningJobWarmStartConfig | undefined;
    FailureReason?: string | undefined;
    TuningJobCompletionDetails?: HyperParameterTuningJobCompletionDetails | undefined;
    ConsumedResources?: HyperParameterTuningJobConsumedResources | undefined;
    Tags?: Tag[] | undefined;
}
export interface ModelCard {
    ModelCardArn?: string | undefined;
    ModelCardName?: string | undefined;
    ModelCardVersion?: number | undefined;
    Content?: string | redacted.Redacted<string> | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
    SecurityConfig?: ModelCardSecurityConfig | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    Tags?: Tag[] | undefined;
    ModelId?: string | undefined;
    RiskRating?: string | undefined;
    ModelPackageGroupName?: string | undefined;
}
export interface Model {
    ModelName?: string | undefined;
    PrimaryContainer?: ContainerDefinition | undefined;
    Containers?: ContainerDefinition[] | undefined;
    InferenceExecutionConfig?: InferenceExecutionConfig | undefined;
    ExecutionRoleArn?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    CreationTime?: Date | undefined;
    ModelArn?: string | undefined;
    EnableNetworkIsolation?: boolean | undefined;
    Tags?: Tag[] | undefined;
    DeploymentRecommendation?: DeploymentRecommendation | undefined;
}
export interface ModelDashboardEndpoint {
    EndpointName?: string | undefined;
    EndpointArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    EndpointStatus?: EndpointStatus | undefined;
}
export type ModelDashboardEndpoints = ModelDashboardEndpoint[];
export interface ModelDashboardMonitoringSchedule {
    MonitoringScheduleArn?: string | undefined;
    MonitoringScheduleName?: string | undefined;
    MonitoringScheduleStatus?: ScheduleStatus | undefined;
    MonitoringType?: MonitoringType | undefined;
    FailureReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    MonitoringScheduleConfig?: MonitoringScheduleConfig | undefined;
    EndpointName?: string | undefined;
    MonitoringAlertSummaries?: MonitoringAlertSummary[] | undefined;
    LastMonitoringExecutionSummary?: MonitoringExecutionSummary | undefined;
    BatchTransformInput?: BatchTransformInput | undefined;
}
export type ModelDashboardMonitoringSchedules = ModelDashboardMonitoringSchedule[];
export interface ModelDashboardModelCard {
    ModelCardArn?: string | undefined;
    ModelCardName?: string | undefined;
    ModelCardVersion?: number | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
    SecurityConfig?: ModelCardSecurityConfig | undefined;
    CreationTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedBy?: UserContext | undefined;
    Tags?: Tag[] | undefined;
    ModelId?: string | undefined;
    RiskRating?: string | undefined;
}
export interface ModelDashboardModel {
    Model?: Model | undefined;
    Endpoints?: ModelDashboardEndpoint[] | undefined;
    LastBatchTransformJob?: TransformJob | undefined;
    MonitoringSchedules?: ModelDashboardMonitoringSchedule[] | undefined;
    ModelCard?: ModelDashboardModelCard | undefined;
}
export interface Job {
    JobName?: string | undefined;
    JobArn?: string | undefined;
    RoleArn?: string | undefined;
    JobCategory?: JobCategory | undefined;
    JobConfigSchemaVersion?: string | undefined;
    JobConfigDocument?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    EndTime?: Date | undefined;
    JobStatus?: JobStatus | undefined;
    SecondaryStatus?: JobSecondaryStatus | undefined;
    SecondaryStatusTransitions?: JobSecondaryStatusTransition[] | undefined;
    FailureReason?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface HubContent {
    HubContentName?: string | undefined;
    HubContentArn?: string | undefined;
    HubContentVersion?: string | undefined;
    HubContentType?: HubContentType | undefined;
    DocumentSchemaVersion?: string | undefined;
    HubName?: string | undefined;
    HubArn?: string | undefined;
    HubContentDisplayName?: string | undefined;
    HubContentDescription?: string | undefined;
    HubContentMarkdown?: string | undefined;
    HubContentDocument?: string | undefined;
    SageMakerPublicHubContentArn?: string | undefined;
    ReferenceMinVersion?: string | undefined;
    SupportStatus?: HubContentSupportStatus | undefined;
    HubContentSearchKeywords?: string[] | undefined;
    HubContentDependencies?: HubContentDependency[] | undefined;
    HubContentStatus?: HubContentStatus | undefined;
    FailureReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    CreatedBy?: UserContext | undefined;
    LastModifiedBy?: UserContext | undefined;
    Tags?: Tag[] | undefined;
}
export interface SearchRecord {
    TrainingJob?: TrainingJob | undefined;
    Experiment?: Experiment | undefined;
    Trial?: Trial | undefined;
    TrialComponent?: TrialComponent | undefined;
    Endpoint?: Endpoint | undefined;
    ModelPackage?: ModelPackage | undefined;
    ModelPackageGroup?: ModelPackageGroup | undefined;
    Pipeline?: Pipeline | undefined;
    PipelineExecution?: PipelineExecution | undefined;
    PipelineVersion?: PipelineVersion | undefined;
    FeatureGroup?: FeatureGroup | undefined;
    FeatureMetadata?: FeatureMetadata | undefined;
    Project?: Project | undefined;
    HyperParameterTuningJob?: HyperParameterTuningJobSearchEntity | undefined;
    ModelCard?: ModelCard | undefined;
    Model?: ModelDashboardModel | undefined;
    Job?: Job | undefined;
    HubContent?: HubContent | undefined;
}
export type SearchResultsList = SearchRecord[];
export type Relation = "EqualTo" | "GreaterThanOrEqualTo" | (string & {});
export interface TotalHits {
    Value?: number | undefined;
    Relation?: Relation | undefined;
}
export interface SearchResponse {
    Results?: (SearchRecord & {
        TrainingJob: TrainingJob & {
            ModelArtifacts: ModelArtifacts & {
                S3ModelArtifacts: S3Uri;
            };
            AlgorithmSpecification: AlgorithmSpecification & {
                TrainingInputMode: TrainingInputMode;
                MetricDefinitions: (MetricDefinition & {
                    Name: MetricName;
                    Regex: MetricRegex;
                })[];
                TrainingImageConfig: TrainingImageConfig & {
                    TrainingRepositoryAccessMode: TrainingRepositoryAccessMode;
                    TrainingRepositoryAuthConfig: TrainingRepositoryAuthConfig & {
                        TrainingRepositoryCredentialsProviderArn: TrainingRepositoryCredentialsProviderArn;
                    };
                };
            };
            InputDataConfig: (Channel & {
                ChannelName: ChannelName;
                DataSource: DataSource & {
                    S3DataSource: S3DataSource & {
                        S3DataType: S3DataType;
                        S3Uri: S3Uri;
                        ModelAccessConfig: ModelAccessConfig & {
                            AcceptEula: AcceptEula;
                        };
                        HubAccessConfig: HubAccessConfig & {
                            HubContentArn: HubContentArn;
                        };
                    };
                    FileSystemDataSource: FileSystemDataSource & {
                        FileSystemId: FileSystemId;
                        FileSystemAccessMode: FileSystemAccessMode;
                        FileSystemType: FileSystemType;
                        DirectoryPath: DirectoryPath;
                    };
                };
                ShuffleConfig: ShuffleConfig & {
                    Seed: Seed;
                };
            })[];
            OutputDataConfig: OutputDataConfig & {
                S3OutputPath: S3Uri;
            };
            ResourceConfig: ResourceConfig & {
                InstanceGroups: (InstanceGroup & {
                    InstanceType: TrainingInstanceType;
                    InstanceCount: TrainingInstanceCount;
                    InstanceGroupName: InstanceGroupName;
                })[];
                InstancePlacementConfig: InstancePlacementConfig & {
                    PlacementSpecifications: (PlacementSpecification & {
                        InstanceCount: TrainingInstanceCount;
                    })[];
                };
                InstancePreferences: (InstancePreference & {
                    InstanceType: TrainingInstanceType;
                })[];
            };
            WarmPoolStatus: WarmPoolStatus & {
                Status: WarmPoolResourceStatus;
            };
            VpcConfig: VpcConfig & {
                SecurityGroupIds: VpcSecurityGroupIds;
                Subnets: Subnets;
            };
            SecondaryStatusTransitions: (SecondaryStatusTransition & {
                Status: SecondaryStatus;
                StartTime: Date;
            })[];
            CheckpointConfig: CheckpointConfig & {
                S3Uri: S3Uri;
            };
            DebugHookConfig: DebugHookConfig & {
                S3OutputPath: S3Uri;
            };
            DebugRuleConfigurations: (DebugRuleConfiguration & {
                RuleConfigurationName: RuleConfigurationName;
                RuleEvaluatorImage: AlgorithmImage;
            })[];
            TensorBoardOutputConfig: TensorBoardOutputConfig & {
                S3OutputPath: S3Uri;
            };
            RetryStrategy: RetryStrategy & {
                MaximumRetryAttempts: MaximumRetryAttempts;
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        Experiment: Experiment & {
            Source: ExperimentSource & {
                SourceArn: ExperimentSourceArn;
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        Trial: Trial & {
            Source: TrialSource & {
                SourceArn: TrialSourceArn;
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            TrialComponentSummaries: (TrialComponentSimpleSummary & {
                TrialComponentSource: TrialComponentSource & {
                    SourceArn: TrialComponentSourceArn;
                };
            })[];
        };
        TrialComponent: TrialComponent & {
            Source: TrialComponentSource & {
                SourceArn: TrialComponentSourceArn;
            };
            InputArtifacts: {
                [key: string]: (TrialComponentArtifact & {
                    Value: TrialComponentArtifactValue;
                }) | undefined;
            };
            OutputArtifacts: {
                [key: string]: (TrialComponentArtifact & {
                    Value: TrialComponentArtifactValue;
                }) | undefined;
            };
            SourceDetail: TrialComponentSourceDetail & {
                TrainingJob: TrainingJob & {
                    ModelArtifacts: ModelArtifacts & {
                        S3ModelArtifacts: S3Uri;
                    };
                    AlgorithmSpecification: AlgorithmSpecification & {
                        TrainingInputMode: TrainingInputMode;
                        MetricDefinitions: (MetricDefinition & {
                            Name: MetricName;
                            Regex: MetricRegex;
                        })[];
                        TrainingImageConfig: TrainingImageConfig & {
                            TrainingRepositoryAccessMode: TrainingRepositoryAccessMode;
                            TrainingRepositoryAuthConfig: TrainingRepositoryAuthConfig & {
                                TrainingRepositoryCredentialsProviderArn: TrainingRepositoryCredentialsProviderArn;
                            };
                        };
                    };
                    InputDataConfig: (Channel & {
                        ChannelName: ChannelName;
                        DataSource: DataSource & {
                            S3DataSource: S3DataSource & {
                                S3DataType: S3DataType;
                                S3Uri: S3Uri;
                                ModelAccessConfig: ModelAccessConfig & {
                                    AcceptEula: AcceptEula;
                                };
                                HubAccessConfig: HubAccessConfig & {
                                    HubContentArn: HubContentArn;
                                };
                            };
                            FileSystemDataSource: FileSystemDataSource & {
                                FileSystemId: FileSystemId;
                                FileSystemAccessMode: FileSystemAccessMode;
                                FileSystemType: FileSystemType;
                                DirectoryPath: DirectoryPath;
                            };
                        };
                        ShuffleConfig: ShuffleConfig & {
                            Seed: Seed;
                        };
                    })[];
                    OutputDataConfig: OutputDataConfig & {
                        S3OutputPath: S3Uri;
                    };
                    ResourceConfig: ResourceConfig & {
                        InstanceGroups: (InstanceGroup & {
                            InstanceType: TrainingInstanceType;
                            InstanceCount: TrainingInstanceCount;
                            InstanceGroupName: InstanceGroupName;
                        })[];
                        InstancePlacementConfig: InstancePlacementConfig & {
                            PlacementSpecifications: (PlacementSpecification & {
                                InstanceCount: TrainingInstanceCount;
                            })[];
                        };
                        InstancePreferences: (InstancePreference & {
                            InstanceType: TrainingInstanceType;
                        })[];
                    };
                    WarmPoolStatus: WarmPoolStatus & {
                        Status: WarmPoolResourceStatus;
                    };
                    VpcConfig: VpcConfig & {
                        SecurityGroupIds: VpcSecurityGroupIds;
                        Subnets: Subnets;
                    };
                    SecondaryStatusTransitions: (SecondaryStatusTransition & {
                        Status: SecondaryStatus;
                        StartTime: Date;
                    })[];
                    CheckpointConfig: CheckpointConfig & {
                        S3Uri: S3Uri;
                    };
                    DebugHookConfig: DebugHookConfig & {
                        S3OutputPath: S3Uri;
                    };
                    DebugRuleConfigurations: (DebugRuleConfiguration & {
                        RuleConfigurationName: RuleConfigurationName;
                        RuleEvaluatorImage: AlgorithmImage;
                    })[];
                    TensorBoardOutputConfig: TensorBoardOutputConfig & {
                        S3OutputPath: S3Uri;
                    };
                    RetryStrategy: RetryStrategy & {
                        MaximumRetryAttempts: MaximumRetryAttempts;
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
                ProcessingJob: ProcessingJob & {
                    ProcessingInputs: (ProcessingInput & {
                        InputName: string;
                        S3Input: ProcessingS3Input & {
                            S3Uri: S3Uri;
                            S3DataType: ProcessingS3DataType;
                        };
                        DatasetDefinition: DatasetDefinition & {
                            AthenaDatasetDefinition: AthenaDatasetDefinition & {
                                Catalog: AthenaCatalog;
                                Database: AthenaDatabase;
                                QueryString: AthenaQueryString;
                                OutputS3Uri: S3Uri;
                                OutputFormat: AthenaResultFormat;
                            };
                            RedshiftDatasetDefinition: RedshiftDatasetDefinition & {
                                ClusterId: RedshiftClusterId;
                                Database: RedshiftDatabase;
                                DbUser: RedshiftUserName;
                                QueryString: RedshiftQueryString;
                                ClusterRoleArn: RoleArn;
                                OutputS3Uri: S3Uri;
                                OutputFormat: RedshiftResultFormat;
                            };
                        };
                    })[];
                    ProcessingOutputConfig: ProcessingOutputConfig & {
                        Outputs: (ProcessingOutput & {
                            OutputName: string;
                            S3Output: ProcessingS3Output & {
                                S3Uri: S3Uri;
                                S3UploadMode: ProcessingS3UploadMode;
                            };
                            FeatureStoreOutput: ProcessingFeatureStoreOutput & {
                                FeatureGroupName: FeatureGroupName;
                            };
                        })[];
                    };
                    ProcessingResources: ProcessingResources & {
                        ClusterConfig: ProcessingClusterConfig & {
                            VolumeSizeInGB: ProcessingVolumeSizeInGB;
                            InstancePreferences: (ProcessingInstancePreference & {
                                InstanceType: ProcessingInstanceType;
                            })[];
                        };
                    };
                    StoppingCondition: ProcessingStoppingCondition & {
                        MaxRuntimeInSeconds: ProcessingMaxRuntimeInSeconds;
                    };
                    AppSpecification: AppSpecification & {
                        ImageUri: ImageUri;
                    };
                    NetworkConfig: NetworkConfig & {
                        VpcConfig: VpcConfig & {
                            SecurityGroupIds: VpcSecurityGroupIds;
                            Subnets: Subnets;
                        };
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
                TransformJob: TransformJob & {
                    TransformInput: TransformInput & {
                        DataSource: TransformDataSource & {
                            S3DataSource: TransformS3DataSource & {
                                S3DataType: S3DataType;
                                S3Uri: S3Uri;
                            };
                        };
                    };
                    TransformOutput: TransformOutput & {
                        S3OutputPath: S3Uri;
                    };
                    DataCaptureConfig: BatchDataCaptureConfig & {
                        DestinationS3Uri: S3Uri;
                    };
                    TransformResources: TransformResources & {
                        InstanceType: TransformInstanceType;
                        InstanceCount: TransformInstanceCount;
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        Endpoint: Endpoint & {
            EndpointName: EndpointName;
            EndpointArn: EndpointArn;
            EndpointConfigName: EndpointConfigName;
            EndpointStatus: EndpointStatus;
            CreationTime: Date;
            LastModifiedTime: Date;
            ProductionVariants: (ProductionVariantSummary & {
                VariantName: VariantName;
                InstancePools: (InstancePoolSummary & {
                    InstanceType: ProductionVariantInstanceType;
                    CurrentInstanceCount: TaskCount;
                })[];
                VariantStatus: (ProductionVariantStatus & {
                    Status: VariantStatus;
                })[];
                CurrentServerlessConfig: ProductionVariantServerlessConfig & {
                    MemorySizeInMB: ServerlessMemorySizeInMB;
                    MaxConcurrency: ServerlessMaxConcurrency;
                };
                DesiredServerlessConfig: ProductionVariantServerlessConfig & {
                    MemorySizeInMB: ServerlessMemorySizeInMB;
                    MaxConcurrency: ServerlessMaxConcurrency;
                };
                ManagedInstanceScaling: ProductionVariantManagedInstanceScaling & {
                    ScaleInPolicy: ProductionVariantManagedInstanceScalingScaleInPolicy & {
                        Strategy: ManagedInstanceScalingScaleInStrategy;
                    };
                };
                RoutingConfig: ProductionVariantRoutingConfig & {
                    RoutingStrategy: RoutingStrategy;
                };
            })[];
            DataCaptureConfig: DataCaptureConfigSummary & {
                EnableCapture: EnableCapture;
                CaptureStatus: CaptureStatus;
                CurrentSamplingPercentage: SamplingPercentage;
                DestinationS3Uri: DestinationS3Uri;
                KmsKeyId: KmsKeyId;
            };
            MonitoringSchedules: (MonitoringSchedule & {
                MonitoringScheduleConfig: MonitoringScheduleConfig & {
                    ScheduleConfig: ScheduleConfig & {
                        ScheduleExpression: ScheduleExpression;
                    };
                    MonitoringJobDefinition: MonitoringJobDefinition & {
                        MonitoringInputs: (MonitoringInput & {
                            EndpointInput: EndpointInput & {
                                EndpointName: EndpointName;
                                LocalPath: ProcessingLocalPath;
                            };
                            BatchTransformInput: BatchTransformInput & {
                                DataCapturedDestinationS3Uri: DestinationS3Uri;
                                DatasetFormat: MonitoringDatasetFormat;
                                LocalPath: ProcessingLocalPath;
                            };
                        })[];
                        MonitoringOutputConfig: MonitoringOutputConfig & {
                            MonitoringOutputs: (MonitoringOutput & {
                                S3Output: MonitoringS3Output & {
                                    S3Uri: MonitoringS3Uri;
                                    LocalPath: ProcessingLocalPath;
                                };
                            })[];
                        };
                        MonitoringResources: MonitoringResources & {
                            ClusterConfig: MonitoringClusterConfig & {
                                InstanceCount: ProcessingInstanceCount;
                                InstanceType: ProcessingInstanceType;
                                VolumeSizeInGB: ProcessingVolumeSizeInGB;
                            };
                        };
                        MonitoringAppSpecification: MonitoringAppSpecification & {
                            ImageUri: ImageUri;
                        };
                        RoleArn: RoleArn;
                        StoppingCondition: MonitoringStoppingCondition & {
                            MaxRuntimeInSeconds: MonitoringMaxRuntimeInSeconds;
                        };
                        NetworkConfig: NetworkConfig & {
                            VpcConfig: VpcConfig & {
                                SecurityGroupIds: VpcSecurityGroupIds;
                                Subnets: Subnets;
                            };
                        };
                    };
                };
                LastMonitoringExecutionSummary: MonitoringExecutionSummary & {
                    MonitoringScheduleName: MonitoringScheduleName;
                    ScheduledTime: Date;
                    CreationTime: Date;
                    LastModifiedTime: Date;
                    MonitoringExecutionStatus: ExecutionStatus;
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            })[];
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            ShadowProductionVariants: (ProductionVariantSummary & {
                VariantName: VariantName;
                InstancePools: (InstancePoolSummary & {
                    InstanceType: ProductionVariantInstanceType;
                    CurrentInstanceCount: TaskCount;
                })[];
                VariantStatus: (ProductionVariantStatus & {
                    Status: VariantStatus;
                })[];
                CurrentServerlessConfig: ProductionVariantServerlessConfig & {
                    MemorySizeInMB: ServerlessMemorySizeInMB;
                    MaxConcurrency: ServerlessMaxConcurrency;
                };
                DesiredServerlessConfig: ProductionVariantServerlessConfig & {
                    MemorySizeInMB: ServerlessMemorySizeInMB;
                    MaxConcurrency: ServerlessMaxConcurrency;
                };
                ManagedInstanceScaling: ProductionVariantManagedInstanceScaling & {
                    ScaleInPolicy: ProductionVariantManagedInstanceScalingScaleInPolicy & {
                        Strategy: ManagedInstanceScalingScaleInStrategy;
                    };
                };
                RoutingConfig: ProductionVariantRoutingConfig & {
                    RoutingStrategy: RoutingStrategy;
                };
            })[];
        };
        ModelPackage: ModelPackage & {
            InferenceSpecification: InferenceSpecification & {
                Containers: (ModelPackageContainerDefinition & {
                    ModelDataSource: ModelDataSource & {
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    };
                    ModelInput: ModelInput & {
                        DataInputConfig: DataInputConfig;
                    };
                    AdditionalModelDataSources: (AdditionalModelDataSource & {
                        ChannelName: AdditionalModelChannelName;
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    })[];
                    AdditionalS3DataSource: AdditionalS3DataSource & {
                        S3DataType: AdditionalS3DataSourceDataType;
                        S3Uri: S3Uri;
                    };
                })[];
            };
            SourceAlgorithmSpecification: SourceAlgorithmSpecification & {
                SourceAlgorithms: (SourceAlgorithm & {
                    AlgorithmName: ArnOrName;
                    ModelDataSource: ModelDataSource & {
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    };
                })[];
            };
            ValidationSpecification: ModelPackageValidationSpecification & {
                ValidationRole: RoleArn;
                ValidationProfiles: (ModelPackageValidationProfile & {
                    ProfileName: EntityName;
                    TransformJobDefinition: TransformJobDefinition & {
                        TransformInput: TransformInput & {
                            DataSource: TransformDataSource & {
                                S3DataSource: TransformS3DataSource & {
                                    S3DataType: S3DataType;
                                    S3Uri: S3Uri;
                                };
                            };
                        };
                        TransformOutput: TransformOutput & {
                            S3OutputPath: S3Uri;
                        };
                        TransformResources: TransformResources & {
                            InstanceType: TransformInstanceType;
                            InstanceCount: TransformInstanceCount;
                        };
                    };
                })[];
            };
            ModelPackageStatusDetails: ModelPackageStatusDetails & {
                ValidationStatuses: (ModelPackageStatusItem & {
                    Name: EntityName;
                    Status: DetailedModelPackageStatus;
                })[];
                ImageScanStatuses: (ModelPackageStatusItem & {
                    Name: EntityName;
                    Status: DetailedModelPackageStatus;
                })[];
            };
            ModelMetrics: ModelMetrics & {
                ModelQuality: ModelQuality & {
                    Statistics: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                    Constraints: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                };
                ModelDataQuality: ModelDataQuality & {
                    Statistics: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                    Constraints: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                };
                Bias: Bias & {
                    Report: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                    PreTrainingReport: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                    PostTrainingReport: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                };
                Explainability: Explainability & {
                    Report: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                };
            };
            AdditionalInferenceSpecifications: (AdditionalInferenceSpecificationDefinition & {
                Name: EntityName;
                Containers: (ModelPackageContainerDefinition & {
                    ModelDataSource: ModelDataSource & {
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    };
                    ModelInput: ModelInput & {
                        DataInputConfig: DataInputConfig;
                    };
                    AdditionalModelDataSources: (AdditionalModelDataSource & {
                        ChannelName: AdditionalModelChannelName;
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    })[];
                    AdditionalS3DataSource: AdditionalS3DataSource & {
                        S3DataType: AdditionalS3DataSourceDataType;
                        S3Uri: S3Uri;
                    };
                })[];
            })[];
            SecurityConfig: ModelPackageSecurityConfig & {
                KmsKeyId: KmsKeyId;
            };
            ModelLifeCycle: ModelLifeCycle & {
                Stage: EntityName;
                StageStatus: EntityName;
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            DriftCheckBaselines: DriftCheckBaselines & {
                Bias: DriftCheckBias & {
                    ConfigFile: FileSource & {
                        S3Uri: S3Uri;
                    };
                    PreTrainingConstraints: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                    PostTrainingConstraints: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                };
                Explainability: DriftCheckExplainability & {
                    Constraints: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                    ConfigFile: FileSource & {
                        S3Uri: S3Uri;
                    };
                };
                ModelQuality: DriftCheckModelQuality & {
                    Statistics: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                    Constraints: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                };
                ModelDataQuality: DriftCheckModelDataQuality & {
                    Statistics: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                    Constraints: MetricsSource & {
                        ContentType: ContentType;
                        S3Uri: S3Uri;
                    };
                };
            };
        };
        ModelPackageGroup: ModelPackageGroup & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        Pipeline: Pipeline & {
            ParallelismConfiguration: ParallelismConfiguration & {
                MaxParallelExecutionSteps: MaxParallelExecutionSteps;
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        PipelineExecution: PipelineExecution & {
            ParallelismConfiguration: ParallelismConfiguration & {
                MaxParallelExecutionSteps: MaxParallelExecutionSteps;
            };
            SelectiveExecutionConfig: SelectiveExecutionConfig & {
                SelectedSteps: (SelectedStep & {
                    StepName: String256;
                })[];
            };
            PipelineParameters: (Parameter & {
                Name: PipelineParameterName;
                Value: String1024;
            })[];
        };
        FeatureGroup: FeatureGroup & {
            FeatureDefinitions: (FeatureDefinition & {
                FeatureName: FeatureName;
                FeatureType: FeatureType;
            })[];
            OfflineStoreConfig: OfflineStoreConfig & {
                S3StorageConfig: S3StorageConfig & {
                    S3Uri: S3Uri;
                };
                DataCatalogConfig: DataCatalogConfig & {
                    TableName: TableName;
                    Catalog: Catalog;
                    Database: Database;
                };
            };
            OfflineStoreStatus: OfflineStoreStatus & {
                Status: OfflineStoreStatusValue;
            };
            LastUpdateStatus: LastUpdateStatus & {
                Status: LastUpdateStatusValue;
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        Project: Project & {
            ServiceCatalogProvisioningDetails: ServiceCatalogProvisioningDetails & {
                ProductId: ServiceCatalogEntityId;
            };
            TemplateProviderDetails: (TemplateProviderDetail & {
                CfnTemplateProviderDetail: CfnTemplateProviderDetail & {
                    TemplateName: CfnTemplateName;
                    TemplateURL: CfnTemplateURL;
                    Parameters: (CfnStackParameter & {
                        Key: CfnStackParameterKey;
                    })[];
                    StackDetail: CfnStackDetail & {
                        StatusMessage: CfnStackStatusMessage;
                    };
                };
            })[];
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        HyperParameterTuningJob: HyperParameterTuningJobSearchEntity & {
            HyperParameterTuningJobConfig: HyperParameterTuningJobConfig & {
                Strategy: HyperParameterTuningJobStrategyType;
                ResourceLimits: ResourceLimits & {
                    MaxParallelTrainingJobs: MaxParallelTrainingJobs;
                };
                HyperParameterTuningJobObjective: HyperParameterTuningJobObjective & {
                    Type: HyperParameterTuningJobObjectiveType;
                    MetricName: MetricName;
                };
                ParameterRanges: ParameterRanges & {
                    IntegerParameterRanges: (IntegerParameterRange & {
                        Name: ParameterKey;
                        MinValue: ParameterValue;
                        MaxValue: ParameterValue;
                    })[];
                    ContinuousParameterRanges: (ContinuousParameterRange & {
                        Name: ParameterKey;
                        MinValue: ParameterValue;
                        MaxValue: ParameterValue;
                    })[];
                    CategoricalParameterRanges: (CategoricalParameterRange & {
                        Name: ParameterKey;
                        Values: ParameterValues;
                    })[];
                    AutoParameters: (AutoParameter & {
                        Name: ParameterKey;
                        ValueHint: ParameterValue;
                    })[];
                };
            };
            TrainingJobDefinition: HyperParameterTrainingJobDefinition & {
                AlgorithmSpecification: HyperParameterAlgorithmSpecification & {
                    TrainingInputMode: TrainingInputMode;
                    MetricDefinitions: (MetricDefinition & {
                        Name: MetricName;
                        Regex: MetricRegex;
                    })[];
                };
                RoleArn: RoleArn;
                OutputDataConfig: OutputDataConfig & {
                    S3OutputPath: S3Uri;
                };
                StoppingCondition: StoppingCondition;
                TuningObjective: HyperParameterTuningJobObjective & {
                    Type: HyperParameterTuningJobObjectiveType;
                    MetricName: MetricName;
                };
                HyperParameterRanges: ParameterRanges & {
                    IntegerParameterRanges: (IntegerParameterRange & {
                        Name: ParameterKey;
                        MinValue: ParameterValue;
                        MaxValue: ParameterValue;
                    })[];
                    ContinuousParameterRanges: (ContinuousParameterRange & {
                        Name: ParameterKey;
                        MinValue: ParameterValue;
                        MaxValue: ParameterValue;
                    })[];
                    CategoricalParameterRanges: (CategoricalParameterRange & {
                        Name: ParameterKey;
                        Values: ParameterValues;
                    })[];
                    AutoParameters: (AutoParameter & {
                        Name: ParameterKey;
                        ValueHint: ParameterValue;
                    })[];
                };
                InputDataConfig: (Channel & {
                    ChannelName: ChannelName;
                    DataSource: DataSource & {
                        S3DataSource: S3DataSource & {
                            S3DataType: S3DataType;
                            S3Uri: S3Uri;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: HubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                        FileSystemDataSource: FileSystemDataSource & {
                            FileSystemId: FileSystemId;
                            FileSystemAccessMode: FileSystemAccessMode;
                            FileSystemType: FileSystemType;
                            DirectoryPath: DirectoryPath;
                        };
                    };
                    ShuffleConfig: ShuffleConfig & {
                        Seed: Seed;
                    };
                })[];
                VpcConfig: VpcConfig & {
                    SecurityGroupIds: VpcSecurityGroupIds;
                    Subnets: Subnets;
                };
                ResourceConfig: ResourceConfig & {
                    InstanceGroups: (InstanceGroup & {
                        InstanceType: TrainingInstanceType;
                        InstanceCount: TrainingInstanceCount;
                        InstanceGroupName: InstanceGroupName;
                    })[];
                    InstancePlacementConfig: InstancePlacementConfig & {
                        PlacementSpecifications: (PlacementSpecification & {
                            InstanceCount: TrainingInstanceCount;
                        })[];
                    };
                    InstancePreferences: (InstancePreference & {
                        InstanceType: TrainingInstanceType;
                    })[];
                };
                HyperParameterTuningResourceConfig: HyperParameterTuningResourceConfig & {
                    InstanceConfigs: (HyperParameterTuningInstanceConfig & {
                        InstanceType: TrainingInstanceType;
                        InstanceCount: TrainingInstanceCount;
                        VolumeSizeInGB: VolumeSizeInGB;
                    })[];
                };
                CheckpointConfig: CheckpointConfig & {
                    S3Uri: S3Uri;
                };
                RetryStrategy: RetryStrategy & {
                    MaximumRetryAttempts: MaximumRetryAttempts;
                };
            };
            TrainingJobDefinitions: (HyperParameterTrainingJobDefinition & {
                AlgorithmSpecification: HyperParameterAlgorithmSpecification & {
                    TrainingInputMode: TrainingInputMode;
                    MetricDefinitions: (MetricDefinition & {
                        Name: MetricName;
                        Regex: MetricRegex;
                    })[];
                };
                RoleArn: RoleArn;
                OutputDataConfig: OutputDataConfig & {
                    S3OutputPath: S3Uri;
                };
                StoppingCondition: StoppingCondition;
                TuningObjective: HyperParameterTuningJobObjective & {
                    Type: HyperParameterTuningJobObjectiveType;
                    MetricName: MetricName;
                };
                HyperParameterRanges: ParameterRanges & {
                    IntegerParameterRanges: (IntegerParameterRange & {
                        Name: ParameterKey;
                        MinValue: ParameterValue;
                        MaxValue: ParameterValue;
                    })[];
                    ContinuousParameterRanges: (ContinuousParameterRange & {
                        Name: ParameterKey;
                        MinValue: ParameterValue;
                        MaxValue: ParameterValue;
                    })[];
                    CategoricalParameterRanges: (CategoricalParameterRange & {
                        Name: ParameterKey;
                        Values: ParameterValues;
                    })[];
                    AutoParameters: (AutoParameter & {
                        Name: ParameterKey;
                        ValueHint: ParameterValue;
                    })[];
                };
                InputDataConfig: (Channel & {
                    ChannelName: ChannelName;
                    DataSource: DataSource & {
                        S3DataSource: S3DataSource & {
                            S3DataType: S3DataType;
                            S3Uri: S3Uri;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: HubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                        FileSystemDataSource: FileSystemDataSource & {
                            FileSystemId: FileSystemId;
                            FileSystemAccessMode: FileSystemAccessMode;
                            FileSystemType: FileSystemType;
                            DirectoryPath: DirectoryPath;
                        };
                    };
                    ShuffleConfig: ShuffleConfig & {
                        Seed: Seed;
                    };
                })[];
                VpcConfig: VpcConfig & {
                    SecurityGroupIds: VpcSecurityGroupIds;
                    Subnets: Subnets;
                };
                ResourceConfig: ResourceConfig & {
                    InstanceGroups: (InstanceGroup & {
                        InstanceType: TrainingInstanceType;
                        InstanceCount: TrainingInstanceCount;
                        InstanceGroupName: InstanceGroupName;
                    })[];
                    InstancePlacementConfig: InstancePlacementConfig & {
                        PlacementSpecifications: (PlacementSpecification & {
                            InstanceCount: TrainingInstanceCount;
                        })[];
                    };
                    InstancePreferences: (InstancePreference & {
                        InstanceType: TrainingInstanceType;
                    })[];
                };
                HyperParameterTuningResourceConfig: HyperParameterTuningResourceConfig & {
                    InstanceConfigs: (HyperParameterTuningInstanceConfig & {
                        InstanceType: TrainingInstanceType;
                        InstanceCount: TrainingInstanceCount;
                        VolumeSizeInGB: VolumeSizeInGB;
                    })[];
                };
                CheckpointConfig: CheckpointConfig & {
                    S3Uri: S3Uri;
                };
                RetryStrategy: RetryStrategy & {
                    MaximumRetryAttempts: MaximumRetryAttempts;
                };
            })[];
            BestTrainingJob: HyperParameterTrainingJobSummary & {
                TrainingJobName: TrainingJobName;
                TrainingJobArn: TrainingJobArn;
                CreationTime: Date;
                TrainingJobStatus: TrainingJobStatus;
                TunedHyperParameters: HyperParameters;
                FinalHyperParameterTuningJobObjectiveMetric: FinalHyperParameterTuningJobObjectiveMetric & {
                    MetricName: MetricName;
                    Value: MetricValue;
                };
            };
            OverallBestTrainingJob: HyperParameterTrainingJobSummary & {
                TrainingJobName: TrainingJobName;
                TrainingJobArn: TrainingJobArn;
                CreationTime: Date;
                TrainingJobStatus: TrainingJobStatus;
                TunedHyperParameters: HyperParameters;
                FinalHyperParameterTuningJobObjectiveMetric: FinalHyperParameterTuningJobObjectiveMetric & {
                    MetricName: MetricName;
                    Value: MetricValue;
                };
            };
            WarmStartConfig: HyperParameterTuningJobWarmStartConfig & {
                ParentHyperParameterTuningJobs: ParentHyperParameterTuningJobs;
                WarmStartType: HyperParameterTuningJobWarmStartType;
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        ModelCard: ModelCard & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        Model: ModelDashboardModel & {
            Model: Model & {
                PrimaryContainer: ContainerDefinition & {
                    ImageConfig: ImageConfig & {
                        RepositoryAccessMode: RepositoryAccessMode;
                        RepositoryAuthConfig: RepositoryAuthConfig & {
                            RepositoryCredentialsProviderArn: RepositoryCredentialsProviderArn;
                        };
                    };
                    ModelDataSource: ModelDataSource & {
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    };
                    AdditionalModelDataSources: (AdditionalModelDataSource & {
                        ChannelName: AdditionalModelChannelName;
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    })[];
                    ContainerMetricsConfig: ContainerMetricsConfig & {
                        MetricsEndpoints: (MetricsEndpoint & {
                            MetricsEndpointPath: MetricsEndpointPath;
                        })[];
                    };
                };
                Containers: (ContainerDefinition & {
                    ImageConfig: ImageConfig & {
                        RepositoryAccessMode: RepositoryAccessMode;
                        RepositoryAuthConfig: RepositoryAuthConfig & {
                            RepositoryCredentialsProviderArn: RepositoryCredentialsProviderArn;
                        };
                    };
                    ModelDataSource: ModelDataSource & {
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    };
                    AdditionalModelDataSources: (AdditionalModelDataSource & {
                        ChannelName: AdditionalModelChannelName;
                        S3DataSource: S3ModelDataSource & {
                            S3Uri: S3ModelUri;
                            S3DataType: S3ModelDataType;
                            CompressionType: ModelCompressionType;
                            ModelAccessConfig: ModelAccessConfig & {
                                AcceptEula: AcceptEula;
                            };
                            HubAccessConfig: InferenceHubAccessConfig & {
                                HubContentArn: HubContentArn;
                            };
                        };
                    })[];
                    ContainerMetricsConfig: ContainerMetricsConfig & {
                        MetricsEndpoints: (MetricsEndpoint & {
                            MetricsEndpointPath: MetricsEndpointPath;
                        })[];
                    };
                })[];
                InferenceExecutionConfig: InferenceExecutionConfig & {
                    Mode: InferenceExecutionMode;
                };
                VpcConfig: VpcConfig & {
                    SecurityGroupIds: VpcSecurityGroupIds;
                    Subnets: Subnets;
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                DeploymentRecommendation: DeploymentRecommendation & {
                    RecommendationStatus: RecommendationStatus;
                    RealTimeInferenceRecommendations: (RealTimeInferenceRecommendation & {
                        RecommendationId: string;
                        InstanceType: ProductionVariantInstanceType;
                    })[];
                };
            };
            Endpoints: (ModelDashboardEndpoint & {
                EndpointName: EndpointName;
                EndpointArn: EndpointArn;
                CreationTime: Date;
                LastModifiedTime: Date;
                EndpointStatus: EndpointStatus;
            })[];
            LastBatchTransformJob: TransformJob & {
                TransformInput: TransformInput & {
                    DataSource: TransformDataSource & {
                        S3DataSource: TransformS3DataSource & {
                            S3DataType: S3DataType;
                            S3Uri: S3Uri;
                        };
                    };
                };
                TransformOutput: TransformOutput & {
                    S3OutputPath: S3Uri;
                };
                DataCaptureConfig: BatchDataCaptureConfig & {
                    DestinationS3Uri: S3Uri;
                };
                TransformResources: TransformResources & {
                    InstanceType: TransformInstanceType;
                    InstanceCount: TransformInstanceCount;
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
            MonitoringSchedules: (ModelDashboardMonitoringSchedule & {
                MonitoringScheduleConfig: MonitoringScheduleConfig & {
                    ScheduleConfig: ScheduleConfig & {
                        ScheduleExpression: ScheduleExpression;
                    };
                    MonitoringJobDefinition: MonitoringJobDefinition & {
                        MonitoringInputs: (MonitoringInput & {
                            EndpointInput: EndpointInput & {
                                EndpointName: EndpointName;
                                LocalPath: ProcessingLocalPath;
                            };
                            BatchTransformInput: BatchTransformInput & {
                                DataCapturedDestinationS3Uri: DestinationS3Uri;
                                DatasetFormat: MonitoringDatasetFormat;
                                LocalPath: ProcessingLocalPath;
                            };
                        })[];
                        MonitoringOutputConfig: MonitoringOutputConfig & {
                            MonitoringOutputs: (MonitoringOutput & {
                                S3Output: MonitoringS3Output & {
                                    S3Uri: MonitoringS3Uri;
                                    LocalPath: ProcessingLocalPath;
                                };
                            })[];
                        };
                        MonitoringResources: MonitoringResources & {
                            ClusterConfig: MonitoringClusterConfig & {
                                InstanceCount: ProcessingInstanceCount;
                                InstanceType: ProcessingInstanceType;
                                VolumeSizeInGB: ProcessingVolumeSizeInGB;
                            };
                        };
                        MonitoringAppSpecification: MonitoringAppSpecification & {
                            ImageUri: ImageUri;
                        };
                        RoleArn: RoleArn;
                        StoppingCondition: MonitoringStoppingCondition & {
                            MaxRuntimeInSeconds: MonitoringMaxRuntimeInSeconds;
                        };
                        NetworkConfig: NetworkConfig & {
                            VpcConfig: VpcConfig & {
                                SecurityGroupIds: VpcSecurityGroupIds;
                                Subnets: Subnets;
                            };
                        };
                    };
                };
                MonitoringAlertSummaries: (MonitoringAlertSummary & {
                    MonitoringAlertName: MonitoringAlertName;
                    CreationTime: Date;
                    LastModifiedTime: Date;
                    AlertStatus: MonitoringAlertStatus;
                    DatapointsToAlert: MonitoringDatapointsToAlert;
                    EvaluationPeriod: MonitoringEvaluationPeriod;
                    Actions: MonitoringAlertActions;
                })[];
                LastMonitoringExecutionSummary: MonitoringExecutionSummary & {
                    MonitoringScheduleName: MonitoringScheduleName;
                    ScheduledTime: Date;
                    CreationTime: Date;
                    LastModifiedTime: Date;
                    MonitoringExecutionStatus: ExecutionStatus;
                };
                BatchTransformInput: BatchTransformInput & {
                    DataCapturedDestinationS3Uri: DestinationS3Uri;
                    DatasetFormat: MonitoringDatasetFormat;
                    LocalPath: ProcessingLocalPath;
                };
            })[];
            ModelCard: ModelDashboardModelCard & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        };
        Job: Job & {
            SecondaryStatusTransitions: (JobSecondaryStatusTransition & {
                Status: JobSecondaryStatus;
                StartTime: Date;
            })[];
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        HubContent: HubContent & {
            HubContentName: HubContentName;
            HubContentArn: HubContentArn;
            HubContentVersion: HubContentVersion;
            HubContentType: HubContentType;
            DocumentSchemaVersion: DocumentSchemaVersion;
            HubName: HubName;
            HubArn: HubArn;
            HubContentStatus: HubContentStatus;
            CreationTime: Date;
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
    })[] | undefined;
    NextToken?: string | undefined;
    TotalHits?: TotalHits | undefined;
}
export type ReservedCapacityInstanceCount = number;
export type TrainingPlanDurationHoursInput = number;
export interface SearchTrainingPlanOfferingsRequest {
    InstanceType?: ReservedCapacityInstanceType | undefined;
    InstanceCount?: number | undefined;
    UltraServerType?: string | undefined;
    UltraServerCount?: number | undefined;
    StartTimeAfter?: Date | undefined;
    EndTimeBefore?: Date | undefined;
    DurationHours?: number | undefined;
    TargetResources?: SageMakerResourceName[] | undefined;
    TrainingPlanArn?: string | undefined;
}
export interface ReservedCapacityOffering {
    ReservedCapacityType?: ReservedCapacityType | undefined;
    UltraServerType?: string | undefined;
    UltraServerCount?: number | undefined;
    InstanceType?: ReservedCapacityInstanceType | undefined;
    InstanceCount?: number | undefined;
    AvailabilityZone?: string | undefined;
    DurationHours?: number | undefined;
    DurationMinutes?: number | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ExtensionStartTime?: Date | undefined;
    ExtensionEndTime?: Date | undefined;
}
export type ReservedCapacityOfferings = ReservedCapacityOffering[];
export interface TrainingPlanOffering {
    TrainingPlanOfferingId?: string | undefined;
    TargetResources?: SageMakerResourceName[] | undefined;
    RequestedStartTimeAfter?: Date | undefined;
    RequestedEndTimeBefore?: Date | undefined;
    DurationHours?: number | undefined;
    DurationMinutes?: number | undefined;
    UpfrontFee?: string | undefined;
    CurrencyCode?: string | undefined;
    ReservedCapacityOfferings?: ReservedCapacityOffering[] | undefined;
}
export type TrainingPlanOfferings = TrainingPlanOffering[];
export interface TrainingPlanExtensionOffering {
    TrainingPlanExtensionOfferingId?: string | undefined;
    AvailabilityZone?: string | undefined;
    StartDate?: Date | undefined;
    EndDate?: Date | undefined;
    DurationHours?: number | undefined;
    UpfrontFee?: string | undefined;
    CurrencyCode?: string | undefined;
}
export type TrainingPlanExtensionOfferings = TrainingPlanExtensionOffering[];
export interface SearchTrainingPlanOfferingsResponse {
    TrainingPlanOfferings: (TrainingPlanOffering & {
        TrainingPlanOfferingId: TrainingPlanOfferingId;
        TargetResources: SageMakerResourceNames;
        ReservedCapacityOfferings: (ReservedCapacityOffering & {
            InstanceType: ReservedCapacityInstanceType;
            InstanceCount: ReservedCapacityInstanceCount;
        })[];
    })[];
    TrainingPlanExtensionOfferings?: (TrainingPlanExtensionOffering & {
        TrainingPlanExtensionOfferingId: TrainingPlanExtensionOfferingId;
    })[] | undefined;
}
export interface SendPipelineExecutionStepFailureRequest {
    CallbackToken?: string | undefined;
    FailureReason?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface SendPipelineExecutionStepFailureResponse {
    PipelineExecutionArn?: string | undefined;
}
export interface SendPipelineExecutionStepSuccessRequest {
    CallbackToken?: string | undefined;
    OutputParameters?: OutputParameter[] | undefined;
    ClientRequestToken?: string | undefined;
}
export interface SendPipelineExecutionStepSuccessResponse {
    PipelineExecutionArn?: string | undefined;
}
export interface StartClusterHealthCheckRequest {
    ClusterName: string;
    DeepHealthCheckConfigurations: InstanceGroupHealthCheckConfiguration[];
}
export interface StartClusterHealthCheckResponse {
    ClusterArn: string;
}
export interface StartEdgeDeploymentStageRequest {
    EdgeDeploymentPlanName?: string | undefined;
    StageName?: string | undefined;
}
export interface StartEdgeDeploymentStageResponse {
}
export interface StartInferenceExperimentRequest {
    Name?: string | undefined;
}
export interface StartInferenceExperimentResponse {
    InferenceExperimentArn: string;
}
export interface StartMlflowTrackingServerRequest {
    TrackingServerName?: string | undefined;
}
export interface StartMlflowTrackingServerResponse {
    TrackingServerArn?: string | undefined;
}
export interface StartMonitoringScheduleRequest {
    MonitoringScheduleName?: string | undefined;
}
export interface StartMonitoringScheduleResponse {
}
export interface StartNotebookInstanceInput {
    NotebookInstanceName?: string | undefined;
}
export interface StartNotebookInstanceResponse {
}
export interface StartPipelineExecutionRequest {
    PipelineName?: string | undefined;
    PipelineExecutionDisplayName?: string | undefined;
    PipelineParameters?: Parameter[] | undefined;
    PipelineExecutionDescription?: string | undefined;
    ClientRequestToken?: string | undefined;
    ParallelismConfiguration?: ParallelismConfiguration | undefined;
    SelectiveExecutionConfig?: SelectiveExecutionConfig | undefined;
    PipelineVersionId?: number | undefined;
    MlflowExperimentName?: string | undefined;
    PipelineVersionAlias?: string | undefined;
    RoleArn?: string | undefined;
}
export interface StartPipelineExecutionResponse {
    PipelineExecutionArn?: string | undefined;
}
export type ResourceIdentifier = string;
export interface StartSessionRequest {
    ResourceIdentifier?: string | undefined;
}
export type SessionId = string;
export type StreamUrl = string;
export type TokenValue = string;
export interface StartSessionResponse {
    SessionId?: string | undefined;
    StreamUrl?: string | undefined;
    TokenValue?: string | undefined;
}
export interface StopAIBenchmarkJobRequest {
    AIBenchmarkJobName?: string | undefined;
}
export interface StopAIBenchmarkJobResponse {
    AIBenchmarkJobArn: string;
}
export interface StopAIRecommendationJobRequest {
    AIRecommendationJobName?: string | undefined;
}
export interface StopAIRecommendationJobResponse {
    AIRecommendationJobArn: string;
}
export interface StopAutoMLJobRequest {
    AutoMLJobName?: string | undefined;
}
export interface StopAutoMLJobResponse {
}
export interface StopCompilationJobRequest {
    CompilationJobName?: string | undefined;
}
export interface StopCompilationJobResponse {
}
export interface StopEdgeDeploymentStageRequest {
    EdgeDeploymentPlanName?: string | undefined;
    StageName?: string | undefined;
}
export interface StopEdgeDeploymentStageResponse {
}
export interface StopEdgePackagingJobRequest {
    EdgePackagingJobName?: string | undefined;
}
export interface StopEdgePackagingJobResponse {
}
export interface StopHyperParameterTuningJobRequest {
    HyperParameterTuningJobName?: string | undefined;
}
export interface StopHyperParameterTuningJobResponse {
}
export type ModelVariantAction = "Retain" | "Remove" | "Promote" | (string & {});
export type ModelVariantActionMap = {
    [key: string]: ModelVariantAction | undefined;
};
export type InferenceExperimentStopDesiredState = "Completed" | "Cancelled" | (string & {});
export interface StopInferenceExperimentRequest {
    Name?: string | undefined;
    ModelVariantActions?: {
        [key: string]: ModelVariantAction | undefined;
    } | undefined;
    DesiredModelVariants?: ModelVariantConfig[] | undefined;
    DesiredState?: InferenceExperimentStopDesiredState | undefined;
    Reason?: string | undefined;
}
export interface StopInferenceExperimentResponse {
    InferenceExperimentArn: string;
}
export interface StopInferenceRecommendationsJobRequest {
    JobName?: string | undefined;
}
export interface StopInferenceRecommendationsJobResponse {
}
export interface StopJobRequest {
    JobName?: string | undefined;
    JobCategory?: JobCategory | undefined;
}
export interface StopJobResponse {
}
export interface StopLabelingJobRequest {
    LabelingJobName?: string | undefined;
}
export interface StopLabelingJobResponse {
}
export interface StopMlflowTrackingServerRequest {
    TrackingServerName?: string | undefined;
}
export interface StopMlflowTrackingServerResponse {
    TrackingServerArn?: string | undefined;
}
export interface StopMonitoringScheduleRequest {
    MonitoringScheduleName?: string | undefined;
}
export interface StopMonitoringScheduleResponse {
}
export interface StopNotebookInstanceInput {
    NotebookInstanceName?: string | undefined;
}
export interface StopNotebookInstanceResponse {
}
export interface StopOptimizationJobRequest {
    OptimizationJobName?: string | undefined;
}
export interface StopOptimizationJobResponse {
}
export interface StopPipelineExecutionRequest {
    PipelineExecutionArn?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface StopPipelineExecutionResponse {
    PipelineExecutionArn?: string | undefined;
}
export interface StopProcessingJobRequest {
    ProcessingJobName?: string | undefined;
}
export interface StopProcessingJobResponse {
}
export interface StopTrainingJobRequest {
    TrainingJobName?: string | undefined;
}
export interface StopTrainingJobResponse {
}
export interface StopTrainingSessionRequest {
    TrainingSessionName?: string | undefined;
}
export interface StopTrainingSessionResponse {
}
export interface StopTransformJobRequest {
    TransformJobName?: string | undefined;
}
export interface StopTransformJobResponse {
}
export type ListLineageEntityParameterKey = string[];
export interface UpdateActionRequest {
    ActionName?: string | undefined;
    Description?: string | undefined;
    Status?: ActionStatus | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    PropertiesToRemove?: string[] | undefined;
}
export interface UpdateActionResponse {
    ActionArn?: string | undefined;
}
export interface UpdateAppImageConfigRequest {
    AppImageConfigName?: string | undefined;
    KernelGatewayImageConfig?: KernelGatewayImageConfig | undefined;
    JupyterLabAppImageConfig?: JupyterLabAppImageConfig | undefined;
    CodeEditorAppImageConfig?: CodeEditorAppImageConfig | undefined;
}
export interface UpdateAppImageConfigResponse {
    AppImageConfigArn?: string | undefined;
}
export interface UpdateArtifactRequest {
    ArtifactArn?: string | undefined;
    ArtifactName?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    PropertiesToRemove?: string[] | undefined;
}
export interface UpdateArtifactResponse {
    ArtifactArn?: string | undefined;
}
export type ClusterInstanceGroupsToDelete = string[];
export interface UpdateClusterRequest {
    ClusterName?: string | undefined;
    InstanceGroups?: ClusterInstanceGroupSpecification[] | undefined;
    RestrictedInstanceGroups?: ClusterRestrictedInstanceGroupSpecification[] | undefined;
    RestrictedInstanceGroupsConfig?: ClusterRestrictedInstanceGroupsConfig | undefined;
    TieredStorageConfig?: ClusterTieredStorageConfig | undefined;
    NodeRecovery?: ClusterNodeRecovery | undefined;
    InstanceGroupsToDelete?: string[] | undefined;
    NodeProvisioningMode?: ClusterNodeProvisioningMode | undefined;
    ClusterRole?: string | undefined;
    AutoScaling?: ClusterAutoScalingConfig | undefined;
    Orchestrator?: ClusterOrchestrator | undefined;
}
export interface UpdateClusterResponse {
    ClusterArn: string;
}
export interface UpdateClusterExtensionRequest {
    ClusterArn?: string | undefined;
    ExtensionArn?: string | undefined;
    ExtensionVersion?: string | undefined;
    ConfigurationValues?: string | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateClusterExtensionResponse {
    ExtensionArn: string;
}
export interface UpdateClusterSchedulerConfigRequest {
    ClusterSchedulerConfigId?: string | undefined;
    TargetVersion?: number | undefined;
    SchedulerConfig?: SchedulerConfig | undefined;
    Description?: string | undefined;
}
export interface UpdateClusterSchedulerConfigResponse {
    ClusterSchedulerConfigArn: string;
    ClusterSchedulerConfigVersion: number;
}
export interface UpdateClusterSoftwareInstanceGroupSpecification {
    InstanceGroupName?: string | undefined;
    ImageReleaseVersion?: string | undefined;
}
export type UpdateClusterSoftwareInstanceGroups = UpdateClusterSoftwareInstanceGroupSpecification[];
export interface UpdateClusterSoftwareRequest {
    ClusterName?: string | undefined;
    InstanceGroups?: UpdateClusterSoftwareInstanceGroupSpecification[] | undefined;
    DeploymentConfig?: DeploymentConfiguration | undefined;
    ImageId?: string | undefined;
}
export interface UpdateClusterSoftwareResponse {
    ClusterArn: string;
}
export interface GitConfigForUpdate {
    SecretArn?: string | undefined;
}
export interface UpdateCodeRepositoryInput {
    CodeRepositoryName?: string | undefined;
    GitConfig?: GitConfigForUpdate | undefined;
}
export interface UpdateCodeRepositoryOutput {
    CodeRepositoryArn: string;
}
export interface UpdateComputeQuotaRequest {
    ComputeQuotaId?: string | undefined;
    TargetVersion?: number | undefined;
    ComputeQuotaConfig?: ComputeQuotaConfig | undefined;
    ComputeQuotaTarget?: ComputeQuotaTarget | undefined;
    ActivationState?: ActivationState | undefined;
    Description?: string | undefined;
}
export interface UpdateComputeQuotaResponse {
    ComputeQuotaArn: string;
    ComputeQuotaVersion: number;
}
export interface UpdateContextRequest {
    ContextName?: string | undefined;
    Description?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    PropertiesToRemove?: string[] | undefined;
}
export interface UpdateContextResponse {
    ContextArn?: string | undefined;
}
export interface UpdateDeviceFleetRequest {
    DeviceFleetName?: string | undefined;
    RoleArn?: string | undefined;
    Description?: string | undefined;
    OutputConfig?: EdgeOutputConfig | undefined;
    EnableIotRoleAlias?: boolean | undefined;
}
export interface UpdateDeviceFleetResponse {
}
export interface UpdateDevicesRequest {
    DeviceFleetName?: string | undefined;
    Devices?: Device[] | undefined;
}
export interface UpdateDevicesResponse {
}
export interface RStudioServerProDomainSettingsForUpdate {
    DomainExecutionRoleArn?: string | undefined;
    DefaultResourceSpec?: ResourceSpec | undefined;
    RStudioConnectUrl?: string | undefined;
    RStudioPackageManagerUrl?: string | undefined;
}
export interface DomainSettingsForUpdate {
    RStudioServerProDomainSettingsForUpdate?: RStudioServerProDomainSettingsForUpdate | undefined;
    ExecutionRoleIdentityConfig?: ExecutionRoleIdentityConfig | undefined;
    SecurityGroupIds?: string[] | undefined;
    TrustedIdentityPropagationSettings?: TrustedIdentityPropagationSettings | undefined;
    DockerSettings?: DockerSettings | undefined;
    AmazonQSettings?: AmazonQSettings | undefined;
    UnifiedStudioSettings?: UnifiedStudioSettings | undefined;
    IpAddressType?: IPAddressType | undefined;
}
export interface UpdateDomainRequest {
    DomainId?: string | undefined;
    DefaultUserSettings?: UserSettings | undefined;
    DomainSettingsForUpdate?: DomainSettingsForUpdate | undefined;
    AppSecurityGroupManagement?: AppSecurityGroupManagement | undefined;
    DefaultSpaceSettings?: DefaultSpaceSettings | undefined;
    SubnetIds?: string[] | undefined;
    AppNetworkAccessType?: AppNetworkAccessType | undefined;
    TagPropagation?: TagPropagation | undefined;
    HomeEfsFileSystemCreation?: HomeEfsFileSystemCreation | undefined;
    VpcId?: string | undefined;
}
export interface UpdateDomainResponse {
    DomainArn?: string | undefined;
}
export type VariantPropertyType = "DesiredInstanceCount" | "DesiredWeight" | "DataCaptureConfig" | (string & {});
export interface VariantProperty {
    VariantPropertyType?: VariantPropertyType | undefined;
}
export type VariantPropertyList = VariantProperty[];
export interface UpdateEndpointInput {
    EndpointName?: string | undefined;
    EndpointConfigName?: string | undefined;
    RetainAllVariantProperties?: boolean | undefined;
    ExcludeRetainedVariantProperties?: VariantProperty[] | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
    RetainDeploymentConfig?: boolean | undefined;
}
export interface UpdateEndpointOutput {
    EndpointArn: string;
}
export interface ProductionVariantServerlessUpdateConfig {
    MaxConcurrency?: number | undefined;
    ProvisionedConcurrency?: number | undefined;
}
export interface DesiredWeightAndCapacity {
    VariantName?: string | undefined;
    DesiredWeight?: number | undefined;
    DesiredInstanceCount?: number | undefined;
    ServerlessUpdateConfig?: ProductionVariantServerlessUpdateConfig | undefined;
}
export type DesiredWeightAndCapacityList = DesiredWeightAndCapacity[];
export interface UpdateEndpointWeightsAndCapacitiesInput {
    EndpointName?: string | undefined;
    DesiredWeightsAndCapacities?: DesiredWeightAndCapacity[] | undefined;
}
export interface UpdateEndpointWeightsAndCapacitiesOutput {
    EndpointArn: string;
}
export interface UpdateExperimentRequest {
    ExperimentName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateExperimentResponse {
    ExperimentArn?: string | undefined;
}
export type FeatureAdditions = FeatureDefinition[];
export interface OnlineStoreConfigUpdate {
    TtlDuration?: TtlDuration | undefined;
    StorageType?: StorageType | undefined;
}
export interface ThroughputConfigUpdate {
    ThroughputMode?: ThroughputMode | undefined;
    ProvisionedReadCapacityUnits?: number | undefined;
    ProvisionedWriteCapacityUnits?: number | undefined;
}
export interface UpdateFeatureGroupRequest {
    FeatureGroupName?: string | undefined;
    FeatureAdditions?: FeatureDefinition[] | undefined;
    OnlineStoreConfig?: OnlineStoreConfigUpdate | undefined;
    ThroughputConfig?: ThroughputConfigUpdate | undefined;
}
export interface UpdateFeatureGroupResponse {
    FeatureGroupArn: string;
}
export type FeatureParameterAdditions = FeatureParameter[];
export type FeatureParameterRemovals = string[];
export interface UpdateFeatureMetadataRequest {
    FeatureGroupName?: string | undefined;
    FeatureName?: string | undefined;
    Description?: string | undefined;
    ParameterAdditions?: FeatureParameter[] | undefined;
    ParameterRemovals?: string[] | undefined;
}
export interface UpdateFeatureMetadataResponse {
}
export interface UpdateHubRequest {
    HubName?: string | undefined;
    HubDescription?: string | undefined;
    HubDisplayName?: string | undefined;
    HubSearchKeywords?: string[] | undefined;
}
export interface UpdateHubResponse {
    HubArn: string;
}
export interface UpdateHubContentRequest {
    HubName?: string | undefined;
    HubContentName?: string | undefined;
    HubContentType?: HubContentType | undefined;
    HubContentVersion?: string | undefined;
    HubContentDisplayName?: string | undefined;
    HubContentDescription?: string | undefined;
    HubContentMarkdown?: string | undefined;
    HubContentSearchKeywords?: string[] | undefined;
    SupportStatus?: HubContentSupportStatus | undefined;
}
export interface UpdateHubContentResponse {
    HubArn: string;
    HubContentArn: string;
}
export interface UpdateHubContentReferenceRequest {
    HubName?: string | undefined;
    HubContentName?: string | undefined;
    HubContentType?: HubContentType | undefined;
    MinVersion?: string | undefined;
}
export interface UpdateHubContentReferenceResponse {
    HubArn: string;
    HubContentArn: string;
}
export type ImageDeleteProperty = string;
export type ImageDeletePropertyList = string[];
export interface UpdateImageRequest {
    DeleteProperties?: string[] | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    ImageName?: string | undefined;
    RoleArn?: string | undefined;
}
export interface UpdateImageResponse {
    ImageArn?: string | undefined;
}
export interface UpdateImageVersionRequest {
    ImageName?: string | undefined;
    Alias?: string | undefined;
    Version?: number | undefined;
    AliasesToAdd?: string[] | undefined;
    AliasesToDelete?: string[] | undefined;
    VendorGuidance?: VendorGuidance | undefined;
    JobType?: JobType | undefined;
    MLFramework?: string | undefined;
    ProgrammingLang?: string | undefined;
    Processor?: Processor | undefined;
    Horovod?: boolean | undefined;
    ReleaseNotes?: string | undefined;
}
export interface UpdateImageVersionResponse {
    ImageVersionArn?: string | undefined;
}
export interface UpdateInferenceComponentInput {
    InferenceComponentName?: string | undefined;
    Specification?: InferenceComponentSpecification | undefined;
    Specifications?: InferenceComponentSpecification[] | undefined;
    RuntimeConfig?: InferenceComponentRuntimeConfig | undefined;
    DeploymentConfig?: InferenceComponentDeploymentConfig | undefined;
}
export interface UpdateInferenceComponentOutput {
    InferenceComponentArn: string;
}
export interface UpdateInferenceComponentRuntimeConfigInput {
    InferenceComponentName?: string | undefined;
    DesiredRuntimeConfig?: InferenceComponentRuntimeConfig | undefined;
}
export interface UpdateInferenceComponentRuntimeConfigOutput {
    InferenceComponentArn: string;
}
export interface UpdateInferenceExperimentRequest {
    Name?: string | undefined;
    Schedule?: InferenceExperimentSchedule | undefined;
    Description?: string | undefined;
    ModelVariants?: ModelVariantConfig[] | undefined;
    DataStorageConfig?: InferenceExperimentDataStorageConfig | undefined;
    ShadowModeConfig?: ShadowModeConfig | undefined;
}
export interface UpdateInferenceExperimentResponse {
    InferenceExperimentArn: string;
}
export interface UpdateMlflowAppRequest {
    Arn?: string | undefined;
    Name?: string | undefined;
    ArtifactStoreUri?: string | undefined;
    ModelRegistrationMode?: ModelRegistrationMode | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    DefaultDomainIdList?: string[] | undefined;
    AccountDefaultStatus?: AccountDefaultStatus | undefined;
}
export interface UpdateMlflowAppResponse {
    Arn?: string | undefined;
}
export interface UpdateMlflowTrackingServerRequest {
    TrackingServerName?: string | undefined;
    ArtifactStoreUri?: string | undefined;
    TrackingServerSize?: TrackingServerSize | undefined;
    AutomaticModelRegistration?: boolean | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    S3BucketOwnerAccountId?: string | undefined;
    S3BucketOwnerVerification?: boolean | undefined;
}
export interface UpdateMlflowTrackingServerResponse {
    TrackingServerArn?: string | undefined;
}
export interface UpdateModelCardRequest {
    ModelCardName?: string | undefined;
    Content?: string | redacted.Redacted<string> | undefined;
    ModelCardStatus?: ModelCardStatus | undefined;
}
export interface UpdateModelCardResponse {
    ModelCardArn: string;
}
export type CustomerMetadataKeyList = string[];
export interface UpdateModelPackageInput {
    ModelPackageArn?: string | undefined;
    ModelApprovalStatus?: ModelApprovalStatus | undefined;
    ModelPackageRegistrationType?: ModelPackageRegistrationType | undefined;
    ApprovalDescription?: string | undefined;
    CustomerMetadataProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    CustomerMetadataPropertiesToRemove?: string[] | undefined;
    AdditionalInferenceSpecificationsToAdd?: AdditionalInferenceSpecificationDefinition[] | undefined;
    InferenceSpecification?: InferenceSpecification | undefined;
    SourceUri?: string | undefined;
    ModelCard?: ModelPackageModelCard | undefined;
    ModelLifeCycle?: ModelLifeCycle | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateModelPackageOutput {
    ModelPackageArn: string;
}
export interface UpdateMonitoringAlertRequest {
    MonitoringScheduleName?: string | undefined;
    MonitoringAlertName?: string | undefined;
    DatapointsToAlert?: number | undefined;
    EvaluationPeriod?: number | undefined;
}
export interface UpdateMonitoringAlertResponse {
    MonitoringScheduleArn: string;
    MonitoringAlertName?: string | undefined;
}
export interface UpdateMonitoringScheduleRequest {
    MonitoringScheduleName?: string | undefined;
    MonitoringScheduleConfig?: MonitoringScheduleConfig | undefined;
}
export interface UpdateMonitoringScheduleResponse {
    MonitoringScheduleArn: string;
}
export type DisassociateNotebookInstanceLifecycleConfig = boolean;
export type DisassociateNotebookInstanceAcceleratorTypes = boolean;
export type DisassociateDefaultCodeRepository = boolean;
export type DisassociateAdditionalCodeRepositories = boolean;
export interface UpdateNotebookInstanceInput {
    NotebookInstanceName?: string | undefined;
    InstanceType?: InstanceType | undefined;
    IpAddressType?: IPAddressType | undefined;
    PlatformIdentifier?: string | undefined;
    RoleArn?: string | undefined;
    LifecycleConfigName?: string | undefined;
    DisassociateLifecycleConfig?: boolean | undefined;
    VolumeSizeInGB?: number | undefined;
    DefaultCodeRepository?: string | undefined;
    AdditionalCodeRepositories?: string[] | undefined;
    AcceleratorTypes?: NotebookInstanceAcceleratorType[] | undefined;
    DisassociateAcceleratorTypes?: boolean | undefined;
    DisassociateDefaultCodeRepository?: boolean | undefined;
    DisassociateAdditionalCodeRepositories?: boolean | undefined;
    RootAccess?: RootAccess | undefined;
    InstanceMetadataServiceConfiguration?: InstanceMetadataServiceConfiguration | undefined;
}
export interface UpdateNotebookInstanceOutput {
}
export interface UpdateNotebookInstanceLifecycleConfigInput {
    NotebookInstanceLifecycleConfigName?: string | undefined;
    OnCreate?: NotebookInstanceLifecycleHook[] | undefined;
    OnStart?: NotebookInstanceLifecycleHook[] | undefined;
}
export interface UpdateNotebookInstanceLifecycleConfigOutput {
}
export interface UpdatePartnerAppRequest {
    Arn?: string | undefined;
    MaintenanceConfig?: PartnerAppMaintenanceConfig | undefined;
    Tier?: string | undefined;
    ApplicationConfig?: PartnerAppConfig | undefined;
    IdcConfig?: IdcConfigInput | undefined;
    AuthType?: PartnerAppAuthType | undefined;
    EnableIamSessionBasedIdentity?: boolean | undefined;
    EnableAutoMinorVersionUpgrade?: boolean | undefined;
    AppVersion?: string | undefined;
    ClientToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface UpdatePartnerAppResponse {
    Arn?: string | undefined;
}
export interface UpdatePipelineRequest {
    PipelineName?: string | undefined;
    PipelineDisplayName?: string | undefined;
    PipelineDefinition?: string | undefined;
    PipelineDefinitionS3Location?: PipelineDefinitionS3Location | undefined;
    PipelineDescription?: string | undefined;
    RoleArn?: string | undefined;
    ParallelismConfiguration?: ParallelismConfiguration | undefined;
    PipelineVersionAliases?: string[] | undefined;
}
export interface UpdatePipelineResponse {
    PipelineArn?: string | undefined;
    PipelineVersionId?: number | undefined;
}
export interface UpdatePipelineExecutionRequest {
    PipelineExecutionArn?: string | undefined;
    PipelineExecutionDescription?: string | undefined;
    PipelineExecutionDisplayName?: string | undefined;
    ParallelismConfiguration?: ParallelismConfiguration | undefined;
}
export interface UpdatePipelineExecutionResponse {
    PipelineExecutionArn?: string | undefined;
}
export interface AliasOperations {
    Add?: string[] | undefined;
    Remove?: string[] | undefined;
}
export interface UpdatePipelineVersionRequest {
    PipelineArn?: string | undefined;
    PipelineVersionId?: number | undefined;
    PipelineVersionDisplayName?: string | undefined;
    PipelineVersionDescription?: string | undefined;
    PipelineVersionAliasOperations?: AliasOperations | undefined;
}
export interface UpdatePipelineVersionResponse {
    PipelineArn?: string | undefined;
    PipelineVersionId?: number | undefined;
}
export interface ServiceCatalogProvisioningUpdateDetails {
    ProvisioningArtifactId?: string | undefined;
    ProvisioningParameters?: ProvisioningParameter[] | undefined;
}
export interface CfnStackUpdateParameter {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type CfnStackUpdateParameters = CfnStackUpdateParameter[];
export interface CfnUpdateTemplateProvider {
    TemplateName?: string | undefined;
    TemplateURL?: string | undefined;
    Parameters?: CfnStackUpdateParameter[] | undefined;
}
export interface UpdateTemplateProvider {
    CfnTemplateProvider?: CfnUpdateTemplateProvider | undefined;
}
export type UpdateTemplateProviderList = UpdateTemplateProvider[];
export interface UpdateProjectInput {
    ProjectName?: string | undefined;
    ProjectDescription?: string | undefined;
    ServiceCatalogProvisioningUpdateDetails?: ServiceCatalogProvisioningUpdateDetails | undefined;
    Tags?: Tag[] | undefined;
    TemplateProvidersToUpdate?: UpdateTemplateProvider[] | undefined;
}
export interface UpdateProjectOutput {
    ProjectArn: string;
}
export interface UpdateSpaceRequest {
    DomainId?: string | undefined;
    SpaceName?: string | undefined;
    SpaceSettings?: SpaceSettings | undefined;
    SpaceDisplayName?: string | undefined;
}
export interface UpdateSpaceResponse {
    SpaceArn?: string | undefined;
}
export interface ProfilerConfigForUpdate {
    S3OutputPath?: string | undefined;
    ProfilingIntervalInMilliseconds?: number | undefined;
    ProfilingParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    DisableProfiler?: boolean | undefined;
}
export interface ResourceConfigForUpdate {
    KeepAlivePeriodInSeconds?: number | undefined;
}
export interface RemoteDebugConfigForUpdate {
    EnableRemoteDebug?: boolean | undefined;
}
export interface UpdateTrainingJobRequest {
    TrainingJobName?: string | undefined;
    ProfilerConfig?: ProfilerConfigForUpdate | undefined;
    ProfilerRuleConfigurations?: ProfilerRuleConfiguration[] | undefined;
    ResourceConfig?: ResourceConfigForUpdate | undefined;
    RemoteDebugConfig?: RemoteDebugConfigForUpdate | undefined;
}
export interface UpdateTrainingJobResponse {
    TrainingJobArn: string;
}
export interface UpdateTrialRequest {
    TrialName?: string | undefined;
    DisplayName?: string | undefined;
}
export interface UpdateTrialResponse {
    TrialArn?: string | undefined;
}
export type TrialComponentKey256 = string;
export type ListTrialComponentKey256 = string[];
export interface UpdateTrialComponentRequest {
    TrialComponentName?: string | undefined;
    DisplayName?: string | undefined;
    Status?: TrialComponentStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Parameters?: {
        [key: string]: TrialComponentParameterValue | undefined;
    } | undefined;
    ParametersToRemove?: string[] | undefined;
    InputArtifacts?: {
        [key: string]: TrialComponentArtifact | undefined;
    } | undefined;
    InputArtifactsToRemove?: string[] | undefined;
    OutputArtifacts?: {
        [key: string]: TrialComponentArtifact | undefined;
    } | undefined;
    OutputArtifactsToRemove?: string[] | undefined;
}
export interface UpdateTrialComponentResponse {
    TrialComponentArn?: string | undefined;
}
export interface UpdateUserProfileRequest {
    DomainId?: string | undefined;
    UserProfileName?: string | undefined;
    UserSettings?: UserSettings | undefined;
}
export interface UpdateUserProfileResponse {
    UserProfileArn?: string | undefined;
}
export interface UpdateWorkforceRequest {
    WorkforceName?: string | undefined;
    SourceIpConfig?: SourceIpConfig | undefined;
    OidcConfig?: OidcConfig | undefined;
    WorkforceVpcConfig?: WorkforceVpcConfigRequest | undefined;
    IpAddressType?: WorkforceIpAddressType | undefined;
}
export interface UpdateWorkforceResponse {
    Workforce: Workforce & {
        WorkforceName: WorkforceName;
        WorkforceArn: WorkforceArn;
        SourceIpConfig: SourceIpConfig & {
            Cidrs: Cidrs;
        };
        CognitoConfig: CognitoConfig & {
            UserPool: CognitoUserPool;
            ClientId: ClientId;
        };
        WorkforceVpcConfig: WorkforceVpcConfigResponse & {
            VpcId: WorkforceVpcId;
            SecurityGroupIds: WorkforceSecurityGroupIds;
            Subnets: WorkforceSubnets;
        };
    };
}
export interface UpdateWorkteamRequest {
    WorkteamName?: string | undefined;
    MemberDefinitions?: MemberDefinition[] | undefined;
    Description?: string | undefined;
    NotificationConfiguration?: NotificationConfiguration | undefined;
    WorkerAccessConfiguration?: WorkerAccessConfiguration | undefined;
}
export interface UpdateWorkteamResponse {
    Workteam: Workteam & {
        WorkteamName: WorkteamName;
        MemberDefinitions: (MemberDefinition & {
            CognitoMemberDefinition: CognitoMemberDefinition & {
                UserPool: CognitoUserPool;
                UserGroup: CognitoUserGroup;
                ClientId: ClientId;
            };
        })[];
        WorkteamArn: WorkteamArn;
        Description: String200;
    };
}
export type AddAssociationError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates an *association* between the source and the destination. A source can be associated with multiple destinations, and a destination can be associated with multiple sources. An association is a lineage tracking entity. For more information, see Amazon SageMaker ML Lineage Tracking.
 */
export declare const addAssociation: API.OperationMethod<AddAssociationRequest & RegionInput, AddAssociationResponse, AddAssociationError, Credentials | HttpClient.HttpClient>;
export type AddTagsError = CommonErrors;
/**
 * Adds or overwrites one or more tags for the specified SageMaker resource. You can add tags to notebook instances, training jobs, hyperparameter tuning jobs, batch transform jobs, models, labeling jobs, work teams, endpoint configurations, and endpoints.
 *
 * Each tag consists of a key and an optional value. Tag keys must be unique per resource. For more information about tags, see For more information, see Amazon Web Services Tagging Strategies.
 *
 * Tags that you add to a hyperparameter tuning job by calling this API are also added to any training jobs that the hyperparameter tuning job launches after you call this API, but not to training jobs that the hyperparameter tuning job launched before you called this API. To make sure that the tags associated with a hyperparameter tuning job are also added to all training jobs that the hyperparameter tuning job launches, add the tags when you first create the tuning job by specifying them in the `Tags` parameter of CreateHyperParameterTuningJob
 *
 * Tags that you add to a SageMaker Domain or User Profile by calling this API are also added to any Apps that the Domain or User Profile launches after you call this API, but not to Apps that the Domain or User Profile launched before you called this API. To make sure that the tags associated with a Domain or User Profile are also added to all Apps that the Domain or User Profile launches, add the tags when you first create the Domain or User Profile by specifying them in the `Tags` parameter of CreateDomain or CreateUserProfile.
 */
export declare const addTags: API.OperationMethod<AddTagsInput & RegionInput, AddTagsOutput, AddTagsError, Credentials | HttpClient.HttpClient>;
export type AssociateTrialComponentError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Associates a trial component with a trial. A trial component can be associated with multiple trials. To disassociate a trial component from a trial, call the DisassociateTrialComponent API.
 */
export declare const associateTrialComponent: API.OperationMethod<AssociateTrialComponentRequest & RegionInput, AssociateTrialComponentResponse, AssociateTrialComponentError, Credentials | HttpClient.HttpClient>;
export type AttachClusterNodeNetworkInterfaceError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Attaches an elastic network interface (ENI) to a node in a HyperPod cluster.
 *
 * To use this operation, you must have the `sagemaker:AttachClusterNodeNetworkInterface` permission.
 */
export declare const attachClusterNodeNetworkInterface: API.OperationMethod<AttachClusterNodeNetworkInterfaceRequest & RegionInput, AttachClusterNodeNetworkInterfaceResponse, AttachClusterNodeNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type AttachClusterNodeVolumeError = ResourceNotFound | CommonErrors;
/**
 * Attaches your Amazon Elastic Block Store (Amazon EBS) volume to a node in your EKS orchestrated HyperPod cluster.
 *
 * This API works with the Amazon Elastic Block Store (Amazon EBS) Container Storage Interface (CSI) driver to manage the lifecycle of persistent storage in your HyperPod EKS clusters.
 */
export declare const attachClusterNodeVolume: API.OperationMethod<AttachClusterNodeVolumeRequest & RegionInput, AttachClusterNodeVolumeResponse, AttachClusterNodeVolumeError, Credentials | HttpClient.HttpClient>;
export type BatchAddClusterNodesError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Adds nodes to a HyperPod cluster by incrementing the target count for one or more instance groups. This operation returns a unique `NodeLogicalId` for each node being added, which can be used to track the provisioning status of the node. This API provides a safer alternative to `UpdateCluster` for scaling operations by avoiding unintended configuration changes.
 *
 * This API is only supported for clusters using `Continuous` as the `NodeProvisioningMode`.
 */
export declare const batchAddClusterNodes: API.OperationMethod<BatchAddClusterNodesRequest & RegionInput, BatchAddClusterNodesResponse, BatchAddClusterNodesError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteClusterNodesError = ResourceNotFound | CommonErrors;
/**
 * Deletes specific nodes within a SageMaker HyperPod cluster. `BatchDeleteClusterNodes` accepts a cluster name and a list of node IDs.
 *
 * - To safeguard your work, back up your data to Amazon S3 or an FSx for Lustre file system before invoking the API on a worker node group. This will help prevent any potential data loss from the instance root volume. For more information about backup, see Use the backup script provided by SageMaker HyperPod.
 *
 * - If you want to invoke this API on an existing cluster, you'll first need to patch the cluster by running the UpdateClusterSoftware API. For more information about patching a cluster, see Update the SageMaker HyperPod platform software of a cluster.
 */
export declare const batchDeleteClusterNodes: API.OperationMethod<BatchDeleteClusterNodesRequest & RegionInput, BatchDeleteClusterNodesResponse, BatchDeleteClusterNodesError, Credentials | HttpClient.HttpClient>;
export type BatchDescribeModelPackageError = CommonErrors;
/**
 * This action batch describes a list of versioned model packages
 */
export declare const batchDescribeModelPackage: API.OperationMethod<BatchDescribeModelPackageInput & RegionInput, BatchDescribeModelPackageOutput, BatchDescribeModelPackageError, Credentials | HttpClient.HttpClient>;
export type BatchRebootClusterNodesError = ResourceNotFound | CommonErrors;
/**
 * Reboots specific nodes within a SageMaker HyperPod cluster using a soft recovery mechanism. `BatchRebootClusterNodes` performs a graceful reboot of the specified nodes by calling the Amazon Elastic Compute Cloud `RebootInstances` API, which attempts to cleanly shut down the operating system before restarting the instance.
 *
 * This operation is useful for recovering from transient issues or applying certain configuration changes that require a restart.
 *
 * - Rebooting a node may cause temporary service interruption for workloads running on that node. Ensure your workloads can handle node restarts or use appropriate scheduling to minimize impact.
 *
 * - You can reboot up to 25 nodes in a single request.
 *
 * - For SageMaker HyperPod clusters using the Slurm workload manager, ensure rebooting nodes will not disrupt critical cluster operations.
 */
export declare const batchRebootClusterNodes: API.OperationMethod<BatchRebootClusterNodesRequest & RegionInput, BatchRebootClusterNodesResponse, BatchRebootClusterNodesError, Credentials | HttpClient.HttpClient>;
export type BatchReplaceClusterNodesError = ResourceNotFound | CommonErrors;
/**
 * Replaces specific nodes within a SageMaker HyperPod cluster with new hardware. `BatchReplaceClusterNodes` terminates the specified instances and provisions new replacement instances with the same configuration but fresh hardware. The Amazon Machine Image (AMI) and instance configuration remain the same.
 *
 * This operation is useful for recovering from hardware failures or persistent issues that cannot be resolved through a reboot.
 *
 * - **Data Loss Warning:** Replacing nodes destroys all instance volumes, including both root and secondary volumes. All data stored on these volumes will be permanently lost and cannot be recovered.
 *
 * - To safeguard your work, back up your data to Amazon S3 or an FSx for Lustre file system before invoking the API on a worker node group. This will help prevent any potential data loss from the instance root volume. For more information about backup, see Use the backup script provided by SageMaker HyperPod.
 *
 * - If you want to invoke this API on an existing cluster, you'll first need to patch the cluster by running the UpdateClusterSoftware API. For more information about patching a cluster, see Update the SageMaker HyperPod platform software of a cluster.
 *
 * - You can replace up to 25 nodes in a single request.
 */
export declare const batchReplaceClusterNodes: API.OperationMethod<BatchReplaceClusterNodesRequest & RegionInput, BatchReplaceClusterNodesResponse, BatchReplaceClusterNodesError, Credentials | HttpClient.HttpClient>;
export type CreateActionError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates an *action*. An action is a lineage tracking entity that represents an action or activity. For example, a model deployment or an HPO job. Generally, an action involves at least one input or output artifact. For more information, see Amazon SageMaker ML Lineage Tracking.
 */
export declare const createAction: API.OperationMethod<CreateActionRequest & RegionInput, CreateActionResponse, CreateActionError, Credentials | HttpClient.HttpClient>;
export type CreateAIBenchmarkJobError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates a benchmark job that runs performance benchmarks against inference infrastructure using a predefined AI workload configuration. The benchmark job measures metrics such as latency, throughput, and cost for your generative AI inference endpoints.
 */
export declare const createAIBenchmarkJob: API.OperationMethod<CreateAIBenchmarkJobRequest & RegionInput, CreateAIBenchmarkJobResponse, CreateAIBenchmarkJobError, Credentials | HttpClient.HttpClient>;
export type CreateAIRecommendationJobError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates a recommendation job that generates intelligent optimization recommendations for generative AI inference deployments. The job analyzes your model, workload configuration, and performance targets to recommend optimal instance types, model optimization techniques (such as quantization and speculative decoding), and deployment configurations.
 */
export declare const createAIRecommendationJob: API.OperationMethod<CreateAIRecommendationJobRequest & RegionInput, CreateAIRecommendationJobResponse, CreateAIRecommendationJobError, Credentials | HttpClient.HttpClient>;
export type CreateAIWorkloadConfigError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a reusable AI workload configuration that defines datasets, data sources, and benchmark tool settings for consistent performance testing of generative AI inference deployments on Amazon SageMaker AI.
 */
export declare const createAIWorkloadConfig: API.OperationMethod<CreateAIWorkloadConfigRequest & RegionInput, CreateAIWorkloadConfigResponse, CreateAIWorkloadConfigError, Credentials | HttpClient.HttpClient>;
export type CreateAlgorithmError = CommonErrors;
/**
 * Create a machine learning algorithm that you can use in SageMaker and list in the Amazon Web Services Marketplace.
 */
export declare const createAlgorithm: API.OperationMethod<CreateAlgorithmInput & RegionInput, CreateAlgorithmOutput, CreateAlgorithmError, Credentials | HttpClient.HttpClient>;
export type CreateAppError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a running app for the specified UserProfile. This operation is automatically invoked by Amazon SageMaker AI upon access to the associated Domain, and when new kernel configurations are selected by the user. A user may have multiple Apps active simultaneously.
 */
export declare const createApp: API.OperationMethod<CreateAppRequest & RegionInput, CreateAppResponse, CreateAppError, Credentials | HttpClient.HttpClient>;
export type CreateAppImageConfigError = ResourceInUse | CommonErrors;
/**
 * Creates a configuration for running a SageMaker AI image as a KernelGateway app. The configuration specifies the Amazon Elastic File System storage volume on the image, and a list of the kernels in the image.
 */
export declare const createAppImageConfig: API.OperationMethod<CreateAppImageConfigRequest & RegionInput, CreateAppImageConfigResponse, CreateAppImageConfigError, Credentials | HttpClient.HttpClient>;
export type CreateArtifactError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates an *artifact*. An artifact is a lineage tracking entity that represents a URI addressable object or data. Some examples are the S3 URI of a dataset and the ECR registry path of an image. For more information, see Amazon SageMaker ML Lineage Tracking.
 */
export declare const createArtifact: API.OperationMethod<CreateArtifactRequest & RegionInput, CreateArtifactResponse, CreateArtifactError, Credentials | HttpClient.HttpClient>;
export type CreateAutoMLJobError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates an Autopilot job also referred to as Autopilot experiment or AutoML job.
 *
 * An AutoML job in SageMaker AI is a fully automated process that allows you to build machine learning models with minimal effort and machine learning expertise. When initiating an AutoML job, you provide your data and optionally specify parameters tailored to your use case. SageMaker AI then automates the entire model development lifecycle, including data preprocessing, model training, tuning, and evaluation. AutoML jobs are designed to simplify and accelerate the model building process by automating various tasks and exploring different combinations of machine learning algorithms, data preprocessing techniques, and hyperparameter values. The output of an AutoML job comprises one or more trained models ready for deployment and inference. Additionally, SageMaker AI AutoML jobs generate a candidate model leaderboard, allowing you to select the best-performing model for deployment.
 *
 * For more information about AutoML jobs, see https://docs.aws.amazon.com/sagemaker/latest/dg/autopilot-automate-model-development.html in the SageMaker AI developer guide.
 *
 * We recommend using the new versions CreateAutoMLJobV2 and DescribeAutoMLJobV2, which offer backward compatibility.
 *
 * `CreateAutoMLJobV2` can manage tabular problem types identical to those of its previous version `CreateAutoMLJob`, as well as time-series forecasting, non-tabular problem types such as image or text classification, and text generation (LLMs fine-tuning).
 *
 * Find guidelines about how to migrate a `CreateAutoMLJob` to `CreateAutoMLJobV2` in Migrate a CreateAutoMLJob to CreateAutoMLJobV2.
 *
 * You can find the best-performing model after you run an AutoML job by calling DescribeAutoMLJobV2 (recommended) or DescribeAutoMLJob.
 */
export declare const createAutoMLJob: API.OperationMethod<CreateAutoMLJobRequest & RegionInput, CreateAutoMLJobResponse, CreateAutoMLJobError, Credentials | HttpClient.HttpClient>;
export type CreateAutoMLJobV2Error = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates an Autopilot job also referred to as Autopilot experiment or AutoML job V2.
 *
 * An AutoML job in SageMaker AI is a fully automated process that allows you to build machine learning models with minimal effort and machine learning expertise. When initiating an AutoML job, you provide your data and optionally specify parameters tailored to your use case. SageMaker AI then automates the entire model development lifecycle, including data preprocessing, model training, tuning, and evaluation. AutoML jobs are designed to simplify and accelerate the model building process by automating various tasks and exploring different combinations of machine learning algorithms, data preprocessing techniques, and hyperparameter values. The output of an AutoML job comprises one or more trained models ready for deployment and inference. Additionally, SageMaker AI AutoML jobs generate a candidate model leaderboard, allowing you to select the best-performing model for deployment.
 *
 * For more information about AutoML jobs, see https://docs.aws.amazon.com/sagemaker/latest/dg/autopilot-automate-model-development.html in the SageMaker AI developer guide.
 *
 * AutoML jobs V2 support various problem types such as regression, binary, and multiclass classification with tabular data, text and image classification, time-series forecasting, and fine-tuning of large language models (LLMs) for text generation.
 *
 * CreateAutoMLJobV2 and DescribeAutoMLJobV2 are new versions of CreateAutoMLJob and DescribeAutoMLJob which offer backward compatibility.
 *
 * `CreateAutoMLJobV2` can manage tabular problem types identical to those of its previous version `CreateAutoMLJob`, as well as time-series forecasting, non-tabular problem types such as image or text classification, and text generation (LLMs fine-tuning).
 *
 * Find guidelines about how to migrate a `CreateAutoMLJob` to `CreateAutoMLJobV2` in Migrate a CreateAutoMLJob to CreateAutoMLJobV2.
 *
 * For the list of available problem types supported by `CreateAutoMLJobV2`, see AutoMLProblemTypeConfig.
 *
 * You can find the best-performing model after you run an AutoML job V2 by calling DescribeAutoMLJobV2.
 */
export declare const createAutoMLJobV2: API.OperationMethod<CreateAutoMLJobV2Request & RegionInput, CreateAutoMLJobV2Response, CreateAutoMLJobV2Error, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates an Amazon SageMaker HyperPod cluster. SageMaker HyperPod is a capability of SageMaker for creating and managing persistent clusters for developing large machine learning models, such as large language models (LLMs) and diffusion models. To learn more, see Amazon SageMaker HyperPod in the *Amazon SageMaker Developer Guide*.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest & RegionInput, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateClusterExtensionError = ConflictException | ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Installs an extension, such as `sagemaker-observability`, on a SageMaker HyperPod cluster orchestrated by Slurm. The cluster must have `NodeProvisioningMode` set to `Continuous` and can have only one extension with a given name. To track the installation, call `DescribeClusterExtension`.
 */
export declare const createClusterExtension: API.OperationMethod<CreateClusterExtensionRequest & RegionInput, CreateClusterExtensionResponse, CreateClusterExtensionError, Credentials | HttpClient.HttpClient>;
export type CreateClusterSchedulerConfigError = ConflictException | ResourceLimitExceeded | CommonErrors;
/**
 * Create cluster policy configuration. This policy is used for task prioritization and fair-share allocation of idle compute. This helps prioritize critical workloads and distributes idle compute across entities.
 */
export declare const createClusterSchedulerConfig: API.OperationMethod<CreateClusterSchedulerConfigRequest & RegionInput, CreateClusterSchedulerConfigResponse, CreateClusterSchedulerConfigError, Credentials | HttpClient.HttpClient>;
export type CreateCodeRepositoryError = CommonErrors;
/**
 * Creates a Git repository as a resource in your SageMaker AI account. You can associate the repository with notebook instances so that you can use Git source control for the notebooks you create. The Git repository is a resource in your SageMaker AI account, so it can be associated with more than one notebook instance, and it persists independently from the lifecycle of any notebook instances it is associated with.
 *
 * The repository can be hosted either in Amazon Web Services CodeCommit or in any other Git repository.
 */
export declare const createCodeRepository: API.OperationMethod<CreateCodeRepositoryInput & RegionInput, CreateCodeRepositoryOutput, CreateCodeRepositoryError, Credentials | HttpClient.HttpClient>;
export type CreateCompilationJobError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Starts a model compilation job. After the model has been compiled, Amazon SageMaker AI saves the resulting model artifacts to an Amazon Simple Storage Service (Amazon S3) bucket that you specify.
 *
 * If you choose to host your model using Amazon SageMaker AI hosting services, you can use the resulting model artifacts as part of the model. You can also use the artifacts with Amazon Web Services IoT Greengrass. In that case, deploy them as an ML resource.
 *
 * In the request body, you provide the following:
 *
 * - A name for the compilation job
 *
 * - Information about the input model artifacts
 *
 * - The output location for the compiled model and the device (target) that the model runs on
 *
 * - The Amazon Resource Name (ARN) of the IAM role that Amazon SageMaker AI assumes to perform the model compilation job.
 *
 * You can also provide a `Tag` to track the model compilation job's resource use and costs. The response body contains the `CompilationJobArn` for the compiled job.
 *
 * To stop a model compilation job, use StopCompilationJob. To get information about a particular model compilation job, use DescribeCompilationJob. To get information about multiple model compilation jobs, use ListCompilationJobs.
 */
export declare const createCompilationJob: API.OperationMethod<CreateCompilationJobRequest & RegionInput, CreateCompilationJobResponse, CreateCompilationJobError, Credentials | HttpClient.HttpClient>;
export type CreateComputeQuotaError = ConflictException | ResourceLimitExceeded | CommonErrors;
/**
 * Create compute allocation definition. This defines how compute is allocated, shared, and borrowed for specified entities. Specifically, how to lend and borrow idle compute and assign a fair-share weight to the specified entities.
 */
export declare const createComputeQuota: API.OperationMethod<CreateComputeQuotaRequest & RegionInput, CreateComputeQuotaResponse, CreateComputeQuotaError, Credentials | HttpClient.HttpClient>;
export type CreateContextError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates a *context*. A context is a lineage tracking entity that represents a logical grouping of other tracking or experiment entities. Some examples are an endpoint and a model package. For more information, see Amazon SageMaker ML Lineage Tracking.
 */
export declare const createContext: API.OperationMethod<CreateContextRequest & RegionInput, CreateContextResponse, CreateContextError, Credentials | HttpClient.HttpClient>;
export type CreateDataQualityJobDefinitionError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a definition for a job that monitors data quality and drift. For information about model monitor, see Amazon SageMaker AI Model Monitor.
 */
export declare const createDataQualityJobDefinition: API.OperationMethod<CreateDataQualityJobDefinitionRequest & RegionInput, CreateDataQualityJobDefinitionResponse, CreateDataQualityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateDeviceFleetError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a device fleet.
 */
export declare const createDeviceFleet: API.OperationMethod<CreateDeviceFleetRequest & RegionInput, CreateDeviceFleetResponse, CreateDeviceFleetError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a `Domain`. A domain consists of an associated Amazon Elastic File System volume, a list of authorized users, and a variety of security, application, policy, and Amazon Virtual Private Cloud (VPC) configurations. Users within a domain can share notebook files and other artifacts with each other.
 *
 * **EFS storage**
 *
 * When a domain is created, an EFS volume is created for use by all of the users within the domain. Each user receives a private home directory within the EFS volume for notebooks, Git repositories, and data files.
 *
 * SageMaker AI uses the Amazon Web Services Key Management Service (Amazon Web Services KMS) to encrypt the EFS volume attached to the domain with an Amazon Web Services managed key by default. For more control, you can specify a customer managed key. For more information, see Protect Data at Rest Using Encryption.
 *
 * **VPC configuration**
 *
 * All traffic between the domain and the Amazon EFS volume is through the specified VPC and subnets. For other traffic, you can specify the `AppNetworkAccessType` parameter. `AppNetworkAccessType` corresponds to the network access type that you choose when you onboard to the domain. The following options are available:
 *
 * - `PublicInternetOnly` - Non-EFS traffic goes through a VPC managed by Amazon SageMaker AI, which allows internet access. This is the default value.
 *
 * - `VpcOnly` - All traffic is through the specified VPC and subnets. Internet access is disabled by default. To allow internet access, you must specify a NAT gateway.
 *
 * When internet access is disabled, you won't be able to run a Amazon SageMaker AI Studio notebook or to train or host models unless your VPC has an interface endpoint to the SageMaker AI API and runtime or a NAT gateway and your security groups allow outbound connections.
 *
 * NFS traffic over TCP on port 2049 needs to be allowed in both inbound and outbound rules in order to launch a Amazon SageMaker AI Studio app successfully.
 *
 * For more information, see Connect Amazon SageMaker AI Studio Notebooks to Resources in a VPC.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest & RegionInput, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateEdgeDeploymentPlanError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates an edge deployment plan, consisting of multiple stages. Each stage may have a different deployment configuration and devices.
 */
export declare const createEdgeDeploymentPlan: API.OperationMethod<CreateEdgeDeploymentPlanRequest & RegionInput, CreateEdgeDeploymentPlanResponse, CreateEdgeDeploymentPlanError, Credentials | HttpClient.HttpClient>;
export type CreateEdgeDeploymentStageError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates a new stage in an existing edge deployment plan.
 */
export declare const createEdgeDeploymentStage: API.OperationMethod<CreateEdgeDeploymentStageRequest & RegionInput, CreateEdgeDeploymentStageResponse, CreateEdgeDeploymentStageError, Credentials | HttpClient.HttpClient>;
export type CreateEdgePackagingJobError = ResourceLimitExceeded | CommonErrors;
/**
 * Starts a SageMaker Edge Manager model packaging job. Edge Manager will use the model artifacts from the Amazon Simple Storage Service bucket that you specify. After the model has been packaged, Amazon SageMaker saves the resulting artifacts to an S3 bucket that you specify.
 */
export declare const createEdgePackagingJob: API.OperationMethod<CreateEdgePackagingJobRequest & RegionInput, CreateEdgePackagingJobResponse, CreateEdgePackagingJobError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointError = ResourceLimitExceeded | EndpointConfigNotFound | EndpointAlreadyExists | CommonErrors;
/**
 * Creates an endpoint using the endpoint configuration specified in the request. SageMaker uses the endpoint to provision resources and deploy models. You create the endpoint configuration with the CreateEndpointConfig API.
 *
 * Use this API to deploy models using SageMaker hosting services.
 *
 * You must not delete an `EndpointConfig` that is in use by an endpoint that is live or while the `UpdateEndpoint` or `CreateEndpoint` operations are being performed on the endpoint. To update an endpoint, you must create a new `EndpointConfig`.
 *
 * The endpoint name must be unique within an Amazon Web Services Region in your Amazon Web Services account.
 *
 * When it receives the request, SageMaker creates the endpoint, launches the resources (ML compute instances), and deploys the model(s) on them.
 *
 * When you call CreateEndpoint, a load call is made to DynamoDB to verify that your endpoint configuration exists. When you read data from a DynamoDB table supporting `Eventually Consistent Reads` , the response might not reflect the results of a recently completed write operation. The response might include some stale data. If the dependent entities are not yet in DynamoDB, this causes a validation error. If you repeat your read request after a short time, the response should return the latest data. So retry logic is recommended to handle these possible issues. We also recommend that customers call DescribeEndpointConfig before calling CreateEndpoint to minimize the potential impact of a DynamoDB eventually consistent read.
 *
 * When SageMaker receives the request, it sets the endpoint status to `Creating`. After it creates the endpoint, it sets the status to `InService`. SageMaker can then process incoming requests for inferences. To check the status of an endpoint, use the DescribeEndpoint API.
 *
 * If any of the models hosted at this endpoint get model data from an Amazon S3 location, SageMaker uses Amazon Web Services Security Token Service to download model artifacts from the S3 path you provided. Amazon Web Services STS is activated in your Amazon Web Services account by default. If you previously deactivated Amazon Web Services STS for a region, you need to reactivate Amazon Web Services STS for that region. For more information, see Activating and Deactivating Amazon Web Services STS in an Amazon Web Services Region in the *Amazon Web Services Identity and Access Management User Guide*.
 *
 * To add the IAM role policies for using this API operation, go to the IAM console, and choose Roles in the left navigation pane. Search the IAM role that you want to grant access to use the CreateEndpoint and CreateEndpointConfig API operations, add the following policies to the role.
 *
 * - Option 1: For a full SageMaker access, search and attach the `AmazonSageMakerFullAccess` policy.
 *
 * - Option 2: For granting a limited access to an IAM role, paste the following Action elements manually into the JSON file of the IAM role:
 *
 * `"Action": ["sagemaker:CreateEndpoint", "sagemaker:CreateEndpointConfig"]`
 *
 * `"Resource": [`
 *
 * `"arn:aws:sagemaker:region:account-id:endpoint/endpointName"`
 *
 * `"arn:aws:sagemaker:region:account-id:endpoint-config/endpointConfigName"`
 *
 * `]`
 *
 * For more information, see SageMaker API Permissions: Actions, Permissions, and Resources Reference.
 */
export declare const createEndpoint: API.OperationMethod<CreateEndpointInput & RegionInput, CreateEndpointOutput, CreateEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointConfigError = ResourceLimitExceeded | EndpointConfigAlreadyExists | CommonErrors;
/**
 * Creates an endpoint configuration that SageMaker hosting services uses to deploy models. In the configuration, you identify one or more models, created using the `CreateModel` API, to deploy and the resources that you want SageMaker to provision. Then you call the CreateEndpoint API.
 *
 * Use this API if you want to use SageMaker hosting services to deploy models into production.
 *
 * In the request, you define a `ProductionVariant`, for each model that you want to deploy. Each `ProductionVariant` parameter also describes the resources that you want SageMaker to provision. This includes the number and type of ML compute instances to deploy.
 *
 * If you are hosting multiple models, you also assign a `VariantWeight` to specify how much traffic you want to allocate to each model. For example, suppose that you want to host two models, A and B, and you assign traffic weight 2 for model A and 1 for model B. SageMaker distributes two-thirds of the traffic to Model A, and one-third to model B.
 *
 * When you call CreateEndpoint, a load call is made to DynamoDB to verify that your endpoint configuration exists. When you read data from a DynamoDB table supporting `Eventually Consistent Reads` , the response might not reflect the results of a recently completed write operation. The response might include some stale data. If the dependent entities are not yet in DynamoDB, this causes a validation error. If you repeat your read request after a short time, the response should return the latest data. So retry logic is recommended to handle these possible issues. We also recommend that customers call DescribeEndpointConfig before calling CreateEndpoint to minimize the potential impact of a DynamoDB eventually consistent read.
 */
export declare const createEndpointConfig: API.OperationMethod<CreateEndpointConfigInput & RegionInput, CreateEndpointConfigOutput, CreateEndpointConfigError, Credentials | HttpClient.HttpClient>;
export type CreateExperimentError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates a SageMaker *experiment*. An experiment is a collection of *trials* that are observed, compared and evaluated as a group. A trial is a set of steps, called *trial components*, that produce a machine learning model.
 *
 * In the Studio UI, trials are referred to as *run groups* and trial components are referred to as *runs*.
 *
 * The goal of an experiment is to determine the components that produce the best model. Multiple trials are performed, each one isolating and measuring the impact of a change to one or more inputs, while keeping the remaining inputs constant.
 *
 * When you use SageMaker Studio or the SageMaker Python SDK, all experiments, trials, and trial components are automatically tracked, logged, and indexed. When you use the Amazon Web Services SDK for Python (Boto), you must use the logging APIs provided by the SDK.
 *
 * You can add tags to experiments, trials, trial components and then use the Search API to search for the tags.
 *
 * To add a description to an experiment, specify the optional `Description` parameter. To add a description later, or to change the description, call the UpdateExperiment API.
 *
 * To get a list of all your experiments, call the ListExperiments API. To view an experiment's properties, call the DescribeExperiment API. To get a list of all the trials associated with an experiment, call the ListTrials API. To create a trial call the CreateTrial API.
 */
export declare const createExperiment: API.OperationMethod<CreateExperimentRequest & RegionInput, CreateExperimentResponse, CreateExperimentError, Credentials | HttpClient.HttpClient>;
export type CreateFeatureGroupError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Create a new `FeatureGroup`. A `FeatureGroup` is a group of `Features` defined in the `FeatureStore` to describe a `Record`.
 *
 * The `FeatureGroup` defines the schema and features contained in the `FeatureGroup`. A `FeatureGroup` definition is composed of a list of `Features`, a `RecordIdentifierFeatureName`, an `EventTimeFeatureName` and configurations for its `OnlineStore` and `OfflineStore`. Check Amazon Web Services service quotas to see the `FeatureGroup`s quota for your Amazon Web Services account.
 *
 * Note that it can take approximately 10-15 minutes to provision an `OnlineStore` `FeatureGroup` with the `InMemory` `StorageType`.
 *
 * You must include at least one of `OnlineStoreConfig` and `OfflineStoreConfig` to create a `FeatureGroup`.
 */
export declare const createFeatureGroup: API.OperationMethod<CreateFeatureGroupRequest & RegionInput, CreateFeatureGroupResponse, CreateFeatureGroupError, Credentials | HttpClient.HttpClient>;
export type CreateFlowDefinitionError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a flow definition.
 */
export declare const createFlowDefinition: API.OperationMethod<CreateFlowDefinitionRequest & RegionInput, CreateFlowDefinitionResponse, CreateFlowDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateHubError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Create a hub.
 */
export declare const createHub: API.OperationMethod<CreateHubRequest & RegionInput, CreateHubResponse, CreateHubError, Credentials | HttpClient.HttpClient>;
export type CreateHubContentPresignedUrlsError = CommonErrors;
/**
 * Creates presigned URLs for accessing hub content artifacts. This operation generates time-limited, secure URLs that allow direct download of model artifacts and associated files from Amazon SageMaker hub content, including gated models that require end-user license agreement acceptance.
 */
export declare const createHubContentPresignedUrls: API.PaginatedOperationMethod<CreateHubContentPresignedUrlsRequest & RegionInput, CreateHubContentPresignedUrlsResponse, CreateHubContentPresignedUrlsError, Credentials | HttpClient.HttpClient, AuthorizedUrl>;
export type CreateHubContentReferenceError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Create a hub content reference in order to add a model in the JumpStart public hub to a private hub.
 */
export declare const createHubContentReference: API.OperationMethod<CreateHubContentReferenceRequest & RegionInput, CreateHubContentReferenceResponse, CreateHubContentReferenceError, Credentials | HttpClient.HttpClient>;
export type CreateHumanTaskUiError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Defines the settings you will use for the human review workflow user interface. Reviewers will see a three-panel interface with an instruction area, the item to review, and an input area.
 */
export declare const createHumanTaskUi: API.OperationMethod<CreateHumanTaskUiRequest & RegionInput, CreateHumanTaskUiResponse, CreateHumanTaskUiError, Credentials | HttpClient.HttpClient>;
export type CreateHyperParameterTuningJobError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Starts a hyperparameter tuning job. A hyperparameter tuning job finds the best version of a model by running many training jobs on your dataset using the algorithm you choose and values for hyperparameters within ranges that you specify. It then chooses the hyperparameter values that result in a model that performs the best, as measured by an objective metric that you choose.
 *
 * A hyperparameter tuning job automatically creates Amazon SageMaker experiments, trials, and trial components for each training job that it runs. You can view these entities in Amazon SageMaker Studio. For more information, see View Experiments, Trials, and Trial Components.
 *
 * Do not include any security-sensitive information including account access IDs, secrets, or tokens in any hyperparameter fields. As part of the shared responsibility model, you are responsible for any potential exposure, unauthorized access, or compromise of your sensitive data if caused by any security-sensitive information included in the request hyperparameter variable or plain text fields..
 */
export declare const createHyperParameterTuningJob: API.OperationMethod<CreateHyperParameterTuningJobRequest & RegionInput, CreateHyperParameterTuningJobResponse, CreateHyperParameterTuningJobError, Credentials | HttpClient.HttpClient>;
export type CreateImageError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a custom SageMaker AI image. A SageMaker AI image is a set of image versions. Each image version represents a container image stored in Amazon ECR. For more information, see Bring your own SageMaker AI image.
 */
export declare const createImage: API.OperationMethod<CreateImageRequest & RegionInput, CreateImageResponse, CreateImageError, Credentials | HttpClient.HttpClient>;
export type CreateImageVersionError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates a version of the SageMaker AI image specified by `ImageName`. The version represents the Amazon ECR container image specified by `BaseImage`.
 */
export declare const createImageVersion: API.OperationMethod<CreateImageVersionRequest & RegionInput, CreateImageVersionResponse, CreateImageVersionError, Credentials | HttpClient.HttpClient>;
export type CreateInferenceComponentError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates an inference component, which is a SageMaker AI hosting object that you can use to deploy a model to an endpoint. In the inference component settings, you specify the model, the endpoint, and how the model utilizes the resources that the endpoint hosts. You can optimize resource utilization by tailoring how the required CPU cores, accelerators, and memory are allocated. You can deploy multiple inference components to an endpoint, where each inference component contains one model and the resource utilization needs for that individual model. After you deploy an inference component, you can directly invoke the associated model when you use the InvokeEndpoint API action.
 */
export declare const createInferenceComponent: API.OperationMethod<CreateInferenceComponentInput & RegionInput, CreateInferenceComponentOutput, CreateInferenceComponentError, Credentials | HttpClient.HttpClient>;
export type CreateInferenceExperimentError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates an inference experiment using the configurations specified in the request.
 *
 * Use this API to setup and schedule an experiment to compare model variants on a Amazon SageMaker inference endpoint. For more information about inference experiments, see Shadow tests.
 *
 * Amazon SageMaker begins your experiment at the scheduled time and routes traffic to your endpoint's model variants based on your specified configuration.
 *
 * While the experiment is in progress or after it has concluded, you can view metrics that compare your model variants. For more information, see View, monitor, and edit shadow tests.
 */
export declare const createInferenceExperiment: API.OperationMethod<CreateInferenceExperimentRequest & RegionInput, CreateInferenceExperimentResponse, CreateInferenceExperimentError, Credentials | HttpClient.HttpClient>;
export type CreateInferenceRecommendationsJobError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Starts a recommendation job. You can create either an instance recommendation or load test job.
 */
export declare const createInferenceRecommendationsJob: API.OperationMethod<CreateInferenceRecommendationsJobRequest & RegionInput, CreateInferenceRecommendationsJobResponse, CreateInferenceRecommendationsJobError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates a model customization job in Amazon SageMaker. A job runs a workload based on the job category and configuration you provide. You specify the job category, a schema-versioned configuration document, and an IAM role that grants Amazon SageMaker permission to access resources on your behalf.
 *
 * Use the `AgentRFT` category to fine-tune a model using multi-turn reinforcement learning with reward signals. Use the `AgentRFTEvaluation` category to evaluate a fine-tuned or base model by running multi-turn rollouts against a held-out prompt dataset and computing metrics such as pass@k and mean reward.
 *
 * Before creating a job, call `ListJobSchemaVersions` and `DescribeJobSchemaVersion` to retrieve the configuration schema for your job category. The `JobConfigDocument` must conform to the schema specified by `JobConfigSchemaVersion`.
 *
 * The following operations are related to `CreateJob`:
 *
 * - `DescribeJob`
 *
 * - `ListJobs`
 *
 * - `StopJob`
 *
 * - `DeleteJob`
 *
 * - `ListJobSchemaVersions`
 *
 * - `DescribeJobSchemaVersion`
 */
export declare const createJob: API.OperationMethod<CreateJobRequest & RegionInput, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateLabelingJobError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a job that uses workers to label the data objects in your input dataset. You can use the labeled data to train machine learning models.
 *
 * You can select your workforce from one of three providers:
 *
 * - A private workforce that you create. It can include employees, contractors, and outside experts. Use a private workforce when want the data to stay within your organization or when a specific set of skills is required.
 *
 * - One or more vendors that you select from the Amazon Web Services Marketplace. Vendors provide expertise in specific areas.
 *
 * - The Amazon Mechanical Turk workforce. This is the largest workforce, but it should only be used for public data or data that has been stripped of any personally identifiable information.
 *
 * You can also use *automated data labeling* to reduce the number of data objects that need to be labeled by a human. Automated data labeling uses *active learning* to determine if a data object can be labeled by machine or if it needs to be sent to a human worker. For more information, see Using Automated Data Labeling.
 *
 * The data objects to be labeled are contained in an Amazon S3 bucket. You create a *manifest file* that describes the location of each object. For more information, see Using Input and Output Data.
 *
 * The output can be used as the manifest file for another labeling job or as training data for your machine learning models.
 *
 * You can use this operation to create a static labeling job or a streaming labeling job. A static labeling job stops if all data objects in the input manifest file identified in `ManifestS3Uri` have been labeled. A streaming labeling job runs perpetually until it is manually stopped, or remains idle for 10 days. You can send new data objects to an active (`InProgress`) streaming labeling job in real time. To learn how to create a static labeling job, see Create a Labeling Job (API) in the Amazon SageMaker Developer Guide. To learn how to create a streaming labeling job, see Create a Streaming Labeling Job.
 */
export declare const createLabelingJob: API.OperationMethod<CreateLabelingJobRequest & RegionInput, CreateLabelingJobResponse, CreateLabelingJobError, Credentials | HttpClient.HttpClient>;
export type CreateMlflowAppError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates an MLflow Tracking Server using a general purpose Amazon S3 bucket as the artifact store.
 */
export declare const createMlflowApp: API.OperationMethod<CreateMlflowAppRequest & RegionInput, CreateMlflowAppResponse, CreateMlflowAppError, Credentials | HttpClient.HttpClient>;
export type CreateMlflowTrackingServerError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates an MLflow Tracking Server using a general purpose Amazon S3 bucket as the artifact store. For more information, see Create an MLflow Tracking Server.
 */
export declare const createMlflowTrackingServer: API.OperationMethod<CreateMlflowTrackingServerRequest & RegionInput, CreateMlflowTrackingServerResponse, CreateMlflowTrackingServerError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = ResourceLimitExceeded | ModelAlreadyExists | CommonErrors;
/**
 * Creates a model in SageMaker. In the request, you name the model and describe a primary container. For the primary container, you specify the Docker image that contains inference code, artifacts (from prior training), and a custom environment map that the inference code uses when you deploy the model for predictions.
 *
 * Use this API to create a model if you want to use SageMaker hosting services or run a batch transform job.
 *
 * To host your model, you create an endpoint configuration with the `CreateEndpointConfig` API, and then create an endpoint with the `CreateEndpoint` API. SageMaker then deploys all of the containers that you defined for the model in the hosting environment.
 *
 * To run a batch transform using your model, you start a job with the `CreateTransformJob` API. SageMaker uses your model and your dataset to get inferences which are then saved to a specified S3 location.
 *
 * In the request, you also provide an IAM role that SageMaker can assume to access model artifacts and docker image for deployment on ML compute hosting instances or for batch transform jobs. In addition, you also use the IAM role to manage permissions the inference code needs. For example, if the inference code access any other Amazon Web Services resources, you grant necessary permissions via this role.
 */
export declare const createModel: API.OperationMethod<CreateModelInput & RegionInput, CreateModelOutput, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreateModelBiasJobDefinitionError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates the definition for a model bias job.
 */
export declare const createModelBiasJobDefinition: API.OperationMethod<CreateModelBiasJobDefinitionRequest & RegionInput, CreateModelBiasJobDefinitionResponse, CreateModelBiasJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateModelCardError = ConflictException | ResourceLimitExceeded | CommonErrors;
/**
 * Creates an Amazon SageMaker Model Card.
 *
 * For information about how to use model cards, see Amazon SageMaker Model Card.
 */
export declare const createModelCard: API.OperationMethod<CreateModelCardRequest & RegionInput, CreateModelCardResponse, CreateModelCardError, Credentials | HttpClient.HttpClient>;
export type CreateModelCardExportJobError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates an Amazon SageMaker Model Card export job.
 */
export declare const createModelCardExportJob: API.OperationMethod<CreateModelCardExportJobRequest & RegionInput, CreateModelCardExportJobResponse, CreateModelCardExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateModelExplainabilityJobDefinitionError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates the definition for a model explainability job.
 */
export declare const createModelExplainabilityJobDefinition: API.OperationMethod<CreateModelExplainabilityJobDefinitionRequest & RegionInput, CreateModelExplainabilityJobDefinitionResponse, CreateModelExplainabilityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateModelPackageError = ConflictException | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a model package that you can use to create SageMaker models or list on Amazon Web Services Marketplace, or a versioned model that is part of a model group. Buyers can subscribe to model packages listed on Amazon Web Services Marketplace to create models in SageMaker.
 *
 * To create a model package by specifying a Docker container that contains your inference code and the Amazon S3 location of your model artifacts, provide values for `InferenceSpecification`. To create a model from an algorithm resource that you created or subscribed to in Amazon Web Services Marketplace, provide a value for `SourceAlgorithmSpecification`.
 *
 * There are two types of model packages:
 *
 * - Versioned - a model that is part of a model group in the model registry.
 *
 * - Unversioned - a model package that is not part of a model group.
 */
export declare const createModelPackage: API.OperationMethod<CreateModelPackageInput & RegionInput, CreateModelPackageOutput, CreateModelPackageError, Credentials | HttpClient.HttpClient>;
export type CreateModelPackageGroupError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates a model group. A model group contains a group of model versions.
 */
export declare const createModelPackageGroup: API.OperationMethod<CreateModelPackageGroupInput & RegionInput, CreateModelPackageGroupOutput, CreateModelPackageGroupError, Credentials | HttpClient.HttpClient>;
export type CreateModelQualityJobDefinitionError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a definition for a job that monitors model quality and drift. For information about model monitor, see Amazon SageMaker AI Model Monitor.
 */
export declare const createModelQualityJobDefinition: API.OperationMethod<CreateModelQualityJobDefinitionRequest & RegionInput, CreateModelQualityJobDefinitionResponse, CreateModelQualityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateMonitoringScheduleError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a schedule that regularly starts Amazon SageMaker AI Processing Jobs to monitor the data captured for an Amazon SageMaker AI Endpoint.
 */
export declare const createMonitoringSchedule: API.OperationMethod<CreateMonitoringScheduleRequest & RegionInput, CreateMonitoringScheduleResponse, CreateMonitoringScheduleError, Credentials | HttpClient.HttpClient>;
export type CreateNotebookInstanceError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates an SageMaker AI notebook instance. A notebook instance is a machine learning (ML) compute instance running on a Jupyter notebook.
 *
 * In a `CreateNotebookInstance` request, specify the type of ML compute instance that you want to run. SageMaker AI launches the instance, installs common libraries that you can use to explore datasets for model training, and attaches an ML storage volume to the notebook instance.
 *
 * SageMaker AI also provides a set of example notebooks. Each notebook demonstrates how to use SageMaker AI with a specific algorithm or with a machine learning framework.
 *
 * After receiving the request, SageMaker AI does the following:
 *
 * - Creates a network interface in the SageMaker AI VPC.
 *
 * - (Option) If you specified `SubnetId`, SageMaker AI creates a network interface in your own VPC, which is inferred from the subnet ID that you provide in the input. When creating this network interface, SageMaker AI attaches the security group that you specified in the request to the network interface that it creates in your VPC.
 *
 * - Launches an EC2 instance of the type specified in the request in the SageMaker AI VPC. If you specified `SubnetId` of your VPC, SageMaker AI specifies both network interfaces when launching this instance. This enables inbound traffic from your own VPC to the notebook instance, assuming that the security groups allow it.
 *
 * After creating the notebook instance, SageMaker AI returns its Amazon Resource Name (ARN). You can't change the name of a notebook instance after you create it.
 *
 * After SageMaker AI creates the notebook instance, you can connect to the Jupyter server and work in Jupyter notebooks. For example, you can write code to explore a dataset that you can use for model training, train a model, host models by creating SageMaker AI endpoints, and validate hosted models.
 *
 * For more information, see How It Works.
 */
export declare const createNotebookInstance: API.OperationMethod<CreateNotebookInstanceInput & RegionInput, CreateNotebookInstanceOutput, CreateNotebookInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateNotebookInstanceLifecycleConfigError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates a lifecycle configuration that you can associate with a notebook instance. A *lifecycle configuration* is a collection of shell scripts that run when you create or start a notebook instance.
 *
 * Each lifecycle configuration script has a limit of 16384 characters.
 *
 * The value of the `$PATH` environment variable that is available to both scripts is `/sbin:bin:/usr/sbin:/usr/bin`.
 *
 * View Amazon CloudWatch Logs for notebook instance lifecycle configurations in log group `/aws/sagemaker/NotebookInstances` in log stream `[notebook-instance-name]/[LifecycleConfigHook]`.
 *
 * Lifecycle configuration scripts cannot run for longer than 5 minutes. If a script runs for longer than 5 minutes, it fails and the notebook instance is not created or started.
 *
 * For information about notebook instance lifestyle configurations, see Step 2.1: (Optional) Customize a Notebook Instance.
 *
 * Lifecycle configuration scripts execute with root access and the notebook instance's IAM execution role privileges. Grant this permission only to trusted principals. See Customize a Notebook Instance Using a Lifecycle Configuration Script for security best practices.
 */
export declare const createNotebookInstanceLifecycleConfig: API.OperationMethod<CreateNotebookInstanceLifecycleConfigInput & RegionInput, CreateNotebookInstanceLifecycleConfigOutput, CreateNotebookInstanceLifecycleConfigError, Credentials | HttpClient.HttpClient>;
export type CreateOptimizationJobError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a job that optimizes a model for inference performance. To create the job, you provide the location of a source model, and you provide the settings for the optimization techniques that you want the job to apply. When the job completes successfully, SageMaker uploads the new optimized model to the output destination that you specify.
 *
 * For more information about how to use this action, and about the supported optimization techniques, see Optimize model inference with Amazon SageMaker.
 */
export declare const createOptimizationJob: API.OperationMethod<CreateOptimizationJobRequest & RegionInput, CreateOptimizationJobResponse, CreateOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type CreatePartnerAppError = ConflictException | ResourceLimitExceeded | CommonErrors;
/**
 * Creates an Amazon SageMaker Partner AI App.
 */
export declare const createPartnerApp: API.OperationMethod<CreatePartnerAppRequest & RegionInput, CreatePartnerAppResponse, CreatePartnerAppError, Credentials | HttpClient.HttpClient>;
export type CreatePartnerAppPresignedUrlError = ResourceNotFound | CommonErrors;
/**
 * Creates a presigned URL to access an Amazon SageMaker Partner AI App.
 */
export declare const createPartnerAppPresignedUrl: API.OperationMethod<CreatePartnerAppPresignedUrlRequest & RegionInput, CreatePartnerAppPresignedUrlResponse, CreatePartnerAppPresignedUrlError, Credentials | HttpClient.HttpClient>;
export type CreatePipelineError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates a pipeline using a JSON pipeline definition.
 */
export declare const createPipeline: API.OperationMethod<CreatePipelineRequest & RegionInput, CreatePipelineResponse, CreatePipelineError, Credentials | HttpClient.HttpClient>;
export type CreatePresignedDomainUrlError = ResourceNotFound | CommonErrors;
/**
 * Creates a URL for a specified UserProfile in a Domain. When accessed in a web browser, the user will be automatically signed in to the domain, and granted access to all of the Apps and files associated with the Domain's Amazon Elastic File System volume. This operation can only be called when the authentication mode equals IAM.
 *
 * The IAM role or user passed to this API defines the permissions to access the app. Once the presigned URL is created, no additional permission is required to access this URL. IAM authorization policies for this API are also enforced for every HTTP request and WebSocket frame that attempts to connect to the app.
 *
 * You can restrict access to this API and to the URL that it returns to a list of IP addresses, Amazon VPCs or Amazon VPC Endpoints that you specify. For more information, see Connect to Amazon SageMaker AI Studio Through an Interface VPC Endpoint .
 *
 * - The URL that you get from a call to `CreatePresignedDomainUrl` has a default timeout of 5 minutes. You can configure this value using `ExpiresInSeconds`. If you try to use the URL after the timeout limit expires, you are directed to the Amazon Web Services console sign-in page.
 *
 * - The JupyterLab session default expiration time is 12 hours. You can configure this value using SessionExpirationDurationInSeconds.
 */
export declare const createPresignedDomainUrl: API.OperationMethod<CreatePresignedDomainUrlRequest & RegionInput, CreatePresignedDomainUrlResponse, CreatePresignedDomainUrlError, Credentials | HttpClient.HttpClient>;
export type CreatePresignedMlflowAppUrlError = ResourceNotFound | CommonErrors;
/**
 * Returns a presigned URL that you can use to connect to the MLflow UI attached to your MLflow App. For more information, see Launch the MLflow UI using a presigned URL.
 */
export declare const createPresignedMlflowAppUrl: API.OperationMethod<CreatePresignedMlflowAppUrlRequest & RegionInput, CreatePresignedMlflowAppUrlResponse, CreatePresignedMlflowAppUrlError, Credentials | HttpClient.HttpClient>;
export type CreatePresignedMlflowTrackingServerUrlError = ResourceNotFound | CommonErrors;
/**
 * Returns a presigned URL that you can use to connect to the MLflow UI attached to your tracking server. For more information, see Launch the MLflow UI using a presigned URL.
 */
export declare const createPresignedMlflowTrackingServerUrl: API.OperationMethod<CreatePresignedMlflowTrackingServerUrlRequest & RegionInput, CreatePresignedMlflowTrackingServerUrlResponse, CreatePresignedMlflowTrackingServerUrlError, Credentials | HttpClient.HttpClient>;
export type CreatePresignedNotebookInstanceUrlError = CommonErrors;
/**
 * Returns a URL that you can use to connect to the Jupyter server from a notebook instance. In the SageMaker AI console, when you choose `Open` next to a notebook instance, SageMaker AI opens a new tab showing the Jupyter server home page from the notebook instance. The console uses this API to get the URL and show the page.
 *
 * The IAM role or user used to call this API defines the permissions to access the notebook instance. Once the presigned URL is created, no additional permission is required to access this URL. IAM authorization policies for this API are also enforced for every HTTP request and WebSocket frame that attempts to connect to the notebook instance.
 *
 * You can restrict access to this API and to the URL that it returns to a list of IP addresses that you specify. Use the `NotIpAddress` condition operator and the `aws:SourceIP` condition context key to specify the list of IP addresses that you want to have access to the notebook instance. For more information, see Limit Access to a Notebook Instance by IP Address.
 *
 * The URL that you get from a call to CreatePresignedNotebookInstanceUrl is valid only for 5 minutes. If you try to use the URL after the 5-minute limit expires, you are directed to the Amazon Web Services console sign-in page.
 */
export declare const createPresignedNotebookInstanceUrl: API.OperationMethod<CreatePresignedNotebookInstanceUrlInput & RegionInput, CreatePresignedNotebookInstanceUrlOutput, CreatePresignedNotebookInstanceUrlError, Credentials | HttpClient.HttpClient>;
export type CreateProcessingJobError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates a processing job.
 */
export declare const createProcessingJob: API.OperationMethod<CreateProcessingJobRequest & RegionInput, CreateProcessingJobResponse, CreateProcessingJobError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates a machine learning (ML) project that can contain one or more templates that set up an ML pipeline from training to deploying an approved model.
 */
export declare const createProject: API.OperationMethod<CreateProjectInput & RegionInput, CreateProjectOutput, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateSpaceError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a private space or a space used for real time collaboration in a domain.
 */
export declare const createSpace: API.OperationMethod<CreateSpaceRequest & RegionInput, CreateSpaceResponse, CreateSpaceError, Credentials | HttpClient.HttpClient>;
export type CreateStudioLifecycleConfigError = ResourceInUse | CommonErrors;
/**
 * Creates a new Amazon SageMaker AI Studio Lifecycle Configuration.
 */
export declare const createStudioLifecycleConfig: API.OperationMethod<CreateStudioLifecycleConfigRequest & RegionInput, CreateStudioLifecycleConfigResponse, CreateStudioLifecycleConfigError, Credentials | HttpClient.HttpClient>;
export type CreateTrainingJobError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Starts a model training job. After training completes, SageMaker saves the resulting model artifacts to an Amazon S3 location that you specify.
 *
 * If you choose to host your model using SageMaker hosting services, you can use the resulting model artifacts as part of the model. You can also use the artifacts in a machine learning service other than SageMaker, provided that you know how to use them for inference.
 *
 * In the request body, you provide the following:
 *
 * - `AlgorithmSpecification` - Identifies the training algorithm to use.
 *
 * - `HyperParameters` - Specify these algorithm-specific parameters to enable the estimation of model parameters during training. Hyperparameters can be tuned to optimize this learning process. For a list of hyperparameters for each training algorithm provided by SageMaker, see Algorithms.
 *
 * Do not include any security-sensitive information including account access IDs, secrets, or tokens in any hyperparameter fields. As part of the shared responsibility model, you are responsible for any potential exposure, unauthorized access, or compromise of your sensitive data if caused by security-sensitive information included in the request hyperparameter variable or plain text fields.
 *
 * - `InputDataConfig` - Describes the input required by the training job and the Amazon S3, EFS, or FSx location where it is stored.
 *
 * - `OutputDataConfig` - Identifies the Amazon S3 bucket where you want SageMaker to save the results of model training.
 *
 * - `ResourceConfig` - Identifies the resources, ML compute instances, and ML storage volumes to deploy for model training. In distributed training, you specify more than one instance.
 *
 * - `EnableManagedSpotTraining` - Optimize the cost of training machine learning models by up to 80% by using Amazon EC2 Spot instances. For more information, see Managed Spot Training.
 *
 * - `RoleArn` - The Amazon Resource Name (ARN) that SageMaker assumes to perform tasks on your behalf during model training. You must grant this role the necessary permissions so that SageMaker can successfully complete model training.
 *
 * - `StoppingCondition` - To help cap training costs, use `MaxRuntimeInSeconds` to set a time limit for training. Use `MaxWaitTimeInSeconds` to specify how long a managed spot training job has to complete.
 *
 * - `Environment` - The environment variables to set in the Docker container.
 *
 * Do not include any security-sensitive information including account access IDs, secrets, or tokens in any environment fields. As part of the shared responsibility model, you are responsible for any potential exposure, unauthorized access, or compromise of your sensitive data if caused by security-sensitive information included in the request environment variable or plain text fields.
 *
 * - `RetryStrategy` - The number of times to retry the job when the job fails due to an `InternalServerError`.
 *
 * For more information about SageMaker, see How It Works.
 */
export declare const createTrainingJob: API.OperationMethod<CreateTrainingJobRequest & RegionInput, CreateTrainingJobResponse, CreateTrainingJobError, Credentials | HttpClient.HttpClient>;
export type CreateTrainingPlanError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates a new training plan in SageMaker to reserve compute capacity.
 *
 * Amazon SageMaker Training Plan is a capability within SageMaker that allows customers to reserve and manage GPU capacity for large-scale AI model training. It provides a way to secure predictable access to computational resources within specific timelines and budgets, without the need to manage underlying infrastructure.
 *
 * **How it works**
 *
 * Plans can be created for specific resources such as SageMaker Training Jobs or SageMaker HyperPod clusters, automatically provisioning resources, setting up infrastructure, executing workloads, and handling infrastructure failures.
 *
 * **Plan creation workflow**
 *
 * - Users search for available plan offerings based on their requirements (e.g., instance type, count, start time, duration) using the ` SearchTrainingPlanOfferings ` API operation.
 *
 * - They create a plan that best matches their needs using the ID of the plan offering they want to use.
 *
 * - After successful upfront payment, the plan's status becomes `Scheduled`.
 *
 * - The plan can be used to:
 *
 * - Queue training jobs.
 *
 * - Allocate to an instance group of a SageMaker HyperPod cluster.
 *
 * - When the plan start date arrives, it becomes `Active`. Based on available reserved capacity:
 *
 * - Training jobs are launched.
 *
 * - Instance groups are provisioned.
 *
 * **Plan composition**
 *
 * A plan can consist of one or more Reserved Capacities, each defined by a specific instance type, quantity, Availability Zone, duration, and start and end times. For more information about Reserved Capacity, see ` ReservedCapacitySummary `.
 */
export declare const createTrainingPlan: API.OperationMethod<CreateTrainingPlanRequest & RegionInput, CreateTrainingPlanResponse, CreateTrainingPlanError, Credentials | HttpClient.HttpClient>;
export type CreateTrainingSessionError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates a training session in Amazon SageMaker. A training session provisions compute resources for fine-tuning a foundation model using Low-Rank Adaptation (LoRA). After the session is created, you can submit training operations and sample inference requests through the Amazon SageMaker Training Session Runtime API.
 *
 * The following operations are related to `CreateTrainingSession`:
 *
 * - `DescribeTrainingSession`
 *
 * - `ListTrainingSessions`
 *
 * - `StopTrainingSession`
 *
 * - `DeleteTrainingSession`
 */
export declare const createTrainingSession: API.OperationMethod<CreateTrainingSessionRequest & RegionInput, CreateTrainingSessionResponse, CreateTrainingSessionError, Credentials | HttpClient.HttpClient>;
export type CreateTransformJobError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Starts a transform job. A transform job uses a trained model to get inferences on a dataset and saves these results to an Amazon S3 location that you specify.
 *
 * To perform batch transformations, you create a transform job and use the data that you have readily available.
 *
 * In the request body, you provide the following:
 *
 * - `TransformJobName` - Identifies the transform job. The name must be unique within an Amazon Web Services Region in an Amazon Web Services account.
 *
 * - `ModelName` - Identifies the model to use. `ModelName` must be the name of an existing Amazon SageMaker model in the same Amazon Web Services Region and Amazon Web Services account. For information on creating a model, see CreateModel.
 *
 * - `TransformInput` - Describes the dataset to be transformed and the Amazon S3 location where it is stored.
 *
 * - `TransformOutput` - Identifies the Amazon S3 location where you want Amazon SageMaker to save the results from the transform job.
 *
 * - `TransformResources` - Identifies the ML compute instances and AMI image versions for the transform job.
 *
 * For more information about how batch transformation works, see Batch Transform.
 */
export declare const createTransformJob: API.OperationMethod<CreateTransformJobRequest & RegionInput, CreateTransformJobResponse, CreateTransformJobError, Credentials | HttpClient.HttpClient>;
export type CreateTrialError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Creates an SageMaker *trial*. A trial is a set of steps called *trial components* that produce a machine learning model. A trial is part of a single SageMaker *experiment*.
 *
 * When you use SageMaker Studio or the SageMaker Python SDK, all experiments, trials, and trial components are automatically tracked, logged, and indexed. When you use the Amazon Web Services SDK for Python (Boto), you must use the logging APIs provided by the SDK.
 *
 * You can add tags to a trial and then use the Search API to search for the tags.
 *
 * To get a list of all your trials, call the ListTrials API. To view a trial's properties, call the DescribeTrial API. To create a trial component, call the CreateTrialComponent API.
 */
export declare const createTrial: API.OperationMethod<CreateTrialRequest & RegionInput, CreateTrialResponse, CreateTrialError, Credentials | HttpClient.HttpClient>;
export type CreateTrialComponentError = ResourceLimitExceeded | CommonErrors;
/**
 * Creates a *trial component*, which is a stage of a machine learning *trial*. A trial is composed of one or more trial components. A trial component can be used in multiple trials.
 *
 * Trial components include pre-processing jobs, training jobs, and batch transform jobs.
 *
 * When you use SageMaker Studio or the SageMaker Python SDK, all experiments, trials, and trial components are automatically tracked, logged, and indexed. When you use the Amazon Web Services SDK for Python (Boto), you must use the logging APIs provided by the SDK.
 *
 * You can add tags to a trial component and then use the Search API to search for the tags.
 */
export declare const createTrialComponent: API.OperationMethod<CreateTrialComponentRequest & RegionInput, CreateTrialComponentResponse, CreateTrialComponentError, Credentials | HttpClient.HttpClient>;
export type CreateUserProfileError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a user profile. A user profile represents a single user within a domain, and is the main way to reference a "person" for the purposes of sharing, reporting, and other user-oriented features. This entity is created when a user onboards to a domain. If an administrator invites a person by email or imports them from IAM Identity Center, a user profile is automatically created. A user profile is the primary holder of settings for an individual user and has a reference to the user's private Amazon Elastic File System home directory.
 */
export declare const createUserProfile: API.OperationMethod<CreateUserProfileRequest & RegionInput, CreateUserProfileResponse, CreateUserProfileError, Credentials | HttpClient.HttpClient>;
export type CreateWorkforceError = CommonErrors;
/**
 * Use this operation to create a workforce. This operation will return an error if a workforce already exists in the Amazon Web Services Region that you specify. You can only create one workforce in each Amazon Web Services Region per Amazon Web Services account.
 *
 * If you want to create a new workforce in an Amazon Web Services Region where a workforce already exists, use the DeleteWorkforce API operation to delete the existing workforce and then use `CreateWorkforce` to create a new workforce.
 *
 * To create a private workforce using Amazon Cognito, you must specify a Cognito user pool in `CognitoConfig`. You can also create an Amazon Cognito workforce using the Amazon SageMaker console. For more information, see Create a Private Workforce (Amazon Cognito).
 *
 * To create a private workforce using your own OIDC Identity Provider (IdP), specify your IdP configuration in `OidcConfig`. Your OIDC IdP must support *groups* because groups are used by Ground Truth and Amazon A2I to create work teams. For more information, see Create a Private Workforce (OIDC IdP).
 */
export declare const createWorkforce: API.OperationMethod<CreateWorkforceRequest & RegionInput, CreateWorkforceResponse, CreateWorkforceError, Credentials | HttpClient.HttpClient>;
export type CreateWorkteamError = ResourceInUse | ResourceLimitExceeded | CommonErrors;
/**
 * Creates a new work team for labeling your data. A work team is defined by one or more Amazon Cognito user pools. You must first create the user pools before you can create a work team.
 *
 * You cannot create more than 25 work teams in an account and region.
 */
export declare const createWorkteam: API.OperationMethod<CreateWorkteamRequest & RegionInput, CreateWorkteamResponse, CreateWorkteamError, Credentials | HttpClient.HttpClient>;
export type DeleteActionError = ResourceNotFound | CommonErrors;
/**
 * Deletes an action.
 */
export declare const deleteAction: API.OperationMethod<DeleteActionRequest & RegionInput, DeleteActionResponse, DeleteActionError, Credentials | HttpClient.HttpClient>;
export type DeleteAIBenchmarkJobError = ResourceNotFound | CommonErrors;
/**
 * Deletes the specified AI benchmark job.
 */
export declare const deleteAIBenchmarkJob: API.OperationMethod<DeleteAIBenchmarkJobRequest & RegionInput, DeleteAIBenchmarkJobResponse, DeleteAIBenchmarkJobError, Credentials | HttpClient.HttpClient>;
export type DeleteAIRecommendationJobError = ResourceNotFound | CommonErrors;
/**
 * Deletes the specified AI recommendation job.
 */
export declare const deleteAIRecommendationJob: API.OperationMethod<DeleteAIRecommendationJobRequest & RegionInput, DeleteAIRecommendationJobResponse, DeleteAIRecommendationJobError, Credentials | HttpClient.HttpClient>;
export type DeleteAIWorkloadConfigError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes the specified AI workload configuration. You cannot delete a configuration that is referenced by an active benchmark job.
 */
export declare const deleteAIWorkloadConfig: API.OperationMethod<DeleteAIWorkloadConfigRequest & RegionInput, DeleteAIWorkloadConfigResponse, DeleteAIWorkloadConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteAlgorithmError = ConflictException | CommonErrors;
/**
 * Removes the specified algorithm from your account.
 */
export declare const deleteAlgorithm: API.OperationMethod<DeleteAlgorithmInput & RegionInput, DeleteAlgorithmResponse, DeleteAlgorithmError, Credentials | HttpClient.HttpClient>;
export type DeleteAppError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Used to stop and delete an app.
 */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest & RegionInput, DeleteAppResponse, DeleteAppError, Credentials | HttpClient.HttpClient>;
export type DeleteAppImageConfigError = ResourceNotFound | CommonErrors;
/**
 * Deletes an AppImageConfig.
 */
export declare const deleteAppImageConfig: API.OperationMethod<DeleteAppImageConfigRequest & RegionInput, DeleteAppImageConfigResponse, DeleteAppImageConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteArtifactError = ResourceNotFound | CommonErrors;
/**
 * Deletes an artifact. Either `ArtifactArn` or `Source` must be specified.
 */
export declare const deleteArtifact: API.OperationMethod<DeleteArtifactRequest & RegionInput, DeleteArtifactResponse, DeleteArtifactError, Credentials | HttpClient.HttpClient>;
export type DeleteAssociationError = ResourceNotFound | CommonErrors;
/**
 * Deletes an association.
 */
export declare const deleteAssociation: API.OperationMethod<DeleteAssociationRequest & RegionInput, DeleteAssociationResponse, DeleteAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Delete a SageMaker HyperPod cluster.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest & RegionInput, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterExtensionError = ConflictException | ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes an extension from a SageMaker HyperPod cluster. SageMaker HyperPod removes the extension's software from every node in the cluster. While SageMaker HyperPod removes the extension, its status is `Deleting`. After SageMaker HyperPod removes the extension from all nodes, it no longer appears in `ListClusterExtensions`, and `DescribeClusterExtension` returns a `ResourceNotFound` error.
 *
 * Deleting an extension doesn't delete data that the extension sent to other Amazon Web Services services, such as metrics in Amazon CloudWatch or Amazon Managed Service for Prometheus.
 */
export declare const deleteClusterExtension: API.OperationMethod<DeleteClusterExtensionRequest & RegionInput, DeleteClusterExtensionResponse, DeleteClusterExtensionError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterSchedulerConfigError = ResourceNotFound | CommonErrors;
/**
 * Deletes the cluster policy of the cluster.
 */
export declare const deleteClusterSchedulerConfig: API.OperationMethod<DeleteClusterSchedulerConfigRequest & RegionInput, DeleteClusterSchedulerConfigResponse, DeleteClusterSchedulerConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteCodeRepositoryError = CommonErrors;
/**
 * Deletes the specified Git repository from your account.
 */
export declare const deleteCodeRepository: API.OperationMethod<DeleteCodeRepositoryInput & RegionInput, DeleteCodeRepositoryResponse, DeleteCodeRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteCompilationJobError = ResourceNotFound | CommonErrors;
/**
 * Deletes the specified compilation job. This action deletes only the compilation job resource in Amazon SageMaker AI. It doesn't delete other resources that are related to that job, such as the model artifacts that the job creates, the compilation logs in CloudWatch, the compiled model, or the IAM role.
 *
 * You can delete a compilation job only if its current status is `COMPLETED`, `FAILED`, or `STOPPED`. If the job status is `STARTING` or `INPROGRESS`, stop the job, and then delete it after its status becomes `STOPPED`.
 */
export declare const deleteCompilationJob: API.OperationMethod<DeleteCompilationJobRequest & RegionInput, DeleteCompilationJobResponse, DeleteCompilationJobError, Credentials | HttpClient.HttpClient>;
export type DeleteComputeQuotaError = ResourceNotFound | CommonErrors;
/**
 * Deletes the compute allocation from the cluster.
 */
export declare const deleteComputeQuota: API.OperationMethod<DeleteComputeQuotaRequest & RegionInput, DeleteComputeQuotaResponse, DeleteComputeQuotaError, Credentials | HttpClient.HttpClient>;
export type DeleteContextError = ResourceNotFound | CommonErrors;
/**
 * Deletes an context.
 */
export declare const deleteContext: API.OperationMethod<DeleteContextRequest & RegionInput, DeleteContextResponse, DeleteContextError, Credentials | HttpClient.HttpClient>;
export type DeleteDataQualityJobDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Deletes a data quality monitoring job definition.
 */
export declare const deleteDataQualityJobDefinition: API.OperationMethod<DeleteDataQualityJobDefinitionRequest & RegionInput, DeleteDataQualityJobDefinitionResponse, DeleteDataQualityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteDeviceFleetError = ResourceInUse | CommonErrors;
/**
 * Deletes a fleet.
 */
export declare const deleteDeviceFleet: API.OperationMethod<DeleteDeviceFleetRequest & RegionInput, DeleteDeviceFleetResponse, DeleteDeviceFleetError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Used to delete a domain. If you onboarded with IAM mode, you will need to delete your domain to onboard again using IAM Identity Center. Use with caution. All of the members of the domain will lose access to their EFS volume, including data, notebooks, and other artifacts.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest & RegionInput, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteEdgeDeploymentPlanError = ResourceInUse | CommonErrors;
/**
 * Deletes an edge deployment plan if (and only if) all the stages in the plan are inactive or there are no stages in the plan.
 */
export declare const deleteEdgeDeploymentPlan: API.OperationMethod<DeleteEdgeDeploymentPlanRequest & RegionInput, DeleteEdgeDeploymentPlanResponse, DeleteEdgeDeploymentPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteEdgeDeploymentStageError = ResourceInUse | CommonErrors;
/**
 * Delete a stage in an edge deployment plan if (and only if) the stage is inactive.
 */
export declare const deleteEdgeDeploymentStage: API.OperationMethod<DeleteEdgeDeploymentStageRequest & RegionInput, DeleteEdgeDeploymentStageResponse, DeleteEdgeDeploymentStageError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = EndpointNotFound | CommonErrors;
/**
 * Deletes an endpoint. SageMaker frees up all of the resources that were deployed when the endpoint was created.
 *
 * SageMaker retires any custom KMS key grants associated with the endpoint, meaning you don't need to use the RevokeGrant API call.
 *
 * When you delete your endpoint, SageMaker asynchronously deletes associated endpoint resources such as KMS key grants. You might still see these resources in your account for a few minutes after deleting your endpoint. Do not delete or revoke the permissions for your ` ExecutionRoleArn `, otherwise SageMaker cannot delete these resources.
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointInput & RegionInput, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointConfigError = EndpointConfigNotFound | CommonErrors;
/**
 * Deletes an endpoint configuration. The `DeleteEndpointConfig` API deletes only the specified configuration. It does not delete endpoints created using the configuration.
 *
 * You must not delete an `EndpointConfig` in use by an endpoint that is live or while the `UpdateEndpoint` or `CreateEndpoint` operations are being performed on the endpoint. If you delete the `EndpointConfig` of an endpoint that is active or being created or updated you may lose visibility into the instance type the endpoint is using. The endpoint must be deleted in order to stop incurring charges.
 */
export declare const deleteEndpointConfig: API.OperationMethod<DeleteEndpointConfigInput & RegionInput, DeleteEndpointConfigResponse, DeleteEndpointConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteExperimentError = ResourceNotFound | CommonErrors;
/**
 * Deletes an SageMaker experiment. All trials associated with the experiment must be deleted first. Use the ListTrials API to get a list of the trials associated with the experiment.
 */
export declare const deleteExperiment: API.OperationMethod<DeleteExperimentRequest & RegionInput, DeleteExperimentResponse, DeleteExperimentError, Credentials | HttpClient.HttpClient>;
export type DeleteFeatureGroupError = ResourceNotFound | CommonErrors;
/**
 * Delete the `FeatureGroup` and any data that was written to the `OnlineStore` of the `FeatureGroup`. Data cannot be accessed from the `OnlineStore` immediately after `DeleteFeatureGroup` is called.
 *
 * Data written into the `OfflineStore` will not be deleted. The Amazon Web Services Glue database and tables that are automatically created for your `OfflineStore` are not deleted.
 *
 * Note that it can take approximately 10-15 minutes to delete an `OnlineStore` `FeatureGroup` with the `InMemory` `StorageType`.
 */
export declare const deleteFeatureGroup: API.OperationMethod<DeleteFeatureGroupRequest & RegionInput, DeleteFeatureGroupResponse, DeleteFeatureGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowDefinitionError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes the specified flow definition.
 */
export declare const deleteFlowDefinition: API.OperationMethod<DeleteFlowDefinitionRequest & RegionInput, DeleteFlowDefinitionResponse, DeleteFlowDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteHubError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Delete a hub.
 */
export declare const deleteHub: API.OperationMethod<DeleteHubRequest & RegionInput, DeleteHubResponse, DeleteHubError, Credentials | HttpClient.HttpClient>;
export type DeleteHubContentError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Delete the contents of a hub.
 */
export declare const deleteHubContent: API.OperationMethod<DeleteHubContentRequest & RegionInput, DeleteHubContentResponse, DeleteHubContentError, Credentials | HttpClient.HttpClient>;
export type DeleteHubContentReferenceError = ResourceNotFound | CommonErrors;
/**
 * Delete a hub content reference in order to remove a model from a private hub.
 */
export declare const deleteHubContentReference: API.OperationMethod<DeleteHubContentReferenceRequest & RegionInput, DeleteHubContentReferenceResponse, DeleteHubContentReferenceError, Credentials | HttpClient.HttpClient>;
export type DeleteHumanTaskUiError = ResourceNotFound | CommonErrors;
/**
 * Use this operation to delete a human task user interface (worker task template).
 *
 * To see a list of human task user interfaces (work task templates) in your account, use ListHumanTaskUis. When you delete a worker task template, it no longer appears when you call `ListHumanTaskUis`.
 */
export declare const deleteHumanTaskUi: API.OperationMethod<DeleteHumanTaskUiRequest & RegionInput, DeleteHumanTaskUiResponse, DeleteHumanTaskUiError, Credentials | HttpClient.HttpClient>;
export type DeleteHyperParameterTuningJobError = CommonErrors;
/**
 * Deletes a hyperparameter tuning job. The `DeleteHyperParameterTuningJob` API deletes only the tuning job entry that was created in SageMaker when you called the `CreateHyperParameterTuningJob` API. It does not delete training jobs, artifacts, or the IAM role that you specified when creating the model.
 */
export declare const deleteHyperParameterTuningJob: API.OperationMethod<DeleteHyperParameterTuningJobRequest & RegionInput, DeleteHyperParameterTuningJobResponse, DeleteHyperParameterTuningJobError, Credentials | HttpClient.HttpClient>;
export type DeleteImageError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes a SageMaker AI image and all versions of the image. The container images aren't deleted.
 */
export declare const deleteImage: API.OperationMethod<DeleteImageRequest & RegionInput, DeleteImageResponse, DeleteImageError, Credentials | HttpClient.HttpClient>;
export type DeleteImageVersionError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes a version of a SageMaker AI image. The container image the version represents isn't deleted.
 */
export declare const deleteImageVersion: API.OperationMethod<DeleteImageVersionRequest & RegionInput, DeleteImageVersionResponse, DeleteImageVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteInferenceComponentError = CommonErrors;
/**
 * Deletes an inference component.
 */
export declare const deleteInferenceComponent: API.OperationMethod<DeleteInferenceComponentInput & RegionInput, DeleteInferenceComponentResponse, DeleteInferenceComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteInferenceExperimentError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Deletes an inference experiment.
 *
 * This operation does not delete your endpoint, variants, or any underlying resources. This operation only deletes the metadata of your experiment.
 */
export declare const deleteInferenceExperiment: API.OperationMethod<DeleteInferenceExperimentRequest & RegionInput, DeleteInferenceExperimentResponse, DeleteInferenceExperimentError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes a job. This operation is idempotent. If the job is currently running, you must stop it before deleting it by calling `StopJob`.
 *
 * The following operations are related to `DeleteJob`:
 *
 * - `CreateJob`
 *
 * - `StopJob`
 *
 * - `DescribeJob`
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest & RegionInput, DeleteJobResponse, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteMlflowAppError = ResourceNotFound | CommonErrors;
/**
 * Deletes an MLflow App.
 */
export declare const deleteMlflowApp: API.OperationMethod<DeleteMlflowAppRequest & RegionInput, DeleteMlflowAppResponse, DeleteMlflowAppError, Credentials | HttpClient.HttpClient>;
export type DeleteMlflowTrackingServerError = ResourceNotFound | CommonErrors;
/**
 * Deletes an MLflow Tracking Server. For more information, see Clean up MLflow resources.
 */
export declare const deleteMlflowTrackingServer: API.OperationMethod<DeleteMlflowTrackingServerRequest & RegionInput, DeleteMlflowTrackingServerResponse, DeleteMlflowTrackingServerError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = ModelNotFound | CommonErrors;
/**
 * Deletes a model. The `DeleteModel` API deletes only the model entry that was created in SageMaker when you called the `CreateModel` API. It does not delete model artifacts, inference code, or the IAM role that you specified when creating the model.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelInput & RegionInput, DeleteModelResponse, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeleteModelBiasJobDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Deletes an Amazon SageMaker AI model bias job definition.
 */
export declare const deleteModelBiasJobDefinition: API.OperationMethod<DeleteModelBiasJobDefinitionRequest & RegionInput, DeleteModelBiasJobDefinitionResponse, DeleteModelBiasJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteModelCardError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Deletes an Amazon SageMaker Model Card.
 */
export declare const deleteModelCard: API.OperationMethod<DeleteModelCardRequest & RegionInput, DeleteModelCardResponse, DeleteModelCardError, Credentials | HttpClient.HttpClient>;
export type DeleteModelExplainabilityJobDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Deletes an Amazon SageMaker AI model explainability job definition.
 */
export declare const deleteModelExplainabilityJobDefinition: API.OperationMethod<DeleteModelExplainabilityJobDefinitionRequest & RegionInput, DeleteModelExplainabilityJobDefinitionResponse, DeleteModelExplainabilityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteModelPackageError = ConflictException | CommonErrors;
/**
 * Deletes a model package.
 *
 * A model package is used to create SageMaker models or list on Amazon Web Services Marketplace. Buyers can subscribe to model packages listed on Amazon Web Services Marketplace to create models in SageMaker.
 */
export declare const deleteModelPackage: API.OperationMethod<DeleteModelPackageInput & RegionInput, DeleteModelPackageResponse, DeleteModelPackageError, Credentials | HttpClient.HttpClient>;
export type DeleteModelPackageGroupError = ConflictException | CommonErrors;
/**
 * Deletes the specified model group.
 */
export declare const deleteModelPackageGroup: API.OperationMethod<DeleteModelPackageGroupInput & RegionInput, DeleteModelPackageGroupResponse, DeleteModelPackageGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteModelPackageGroupPolicyError = CommonErrors;
/**
 * Deletes a model group resource policy.
 */
export declare const deleteModelPackageGroupPolicy: API.OperationMethod<DeleteModelPackageGroupPolicyInput & RegionInput, DeleteModelPackageGroupPolicyResponse, DeleteModelPackageGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteModelQualityJobDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Deletes the secified model quality monitoring job definition.
 */
export declare const deleteModelQualityJobDefinition: API.OperationMethod<DeleteModelQualityJobDefinitionRequest & RegionInput, DeleteModelQualityJobDefinitionResponse, DeleteModelQualityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteMonitoringScheduleError = ResourceNotFound | CommonErrors;
/**
 * Deletes a monitoring schedule. Also stops the schedule had not already been stopped. This does not delete the job execution history of the monitoring schedule.
 */
export declare const deleteMonitoringSchedule: API.OperationMethod<DeleteMonitoringScheduleRequest & RegionInput, DeleteMonitoringScheduleResponse, DeleteMonitoringScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteNotebookInstanceError = CommonErrors;
/**
 * Deletes an SageMaker AI notebook instance. Before you can delete a notebook instance, you must call the `StopNotebookInstance` API.
 *
 * When you delete a notebook instance, you lose all of your data. SageMaker AI removes the ML compute instance, and deletes the ML storage volume and the network interface associated with the notebook instance.
 */
export declare const deleteNotebookInstance: API.OperationMethod<DeleteNotebookInstanceInput & RegionInput, DeleteNotebookInstanceResponse, DeleteNotebookInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteNotebookInstanceLifecycleConfigError = CommonErrors;
/**
 * Deletes a notebook instance lifecycle configuration.
 */
export declare const deleteNotebookInstanceLifecycleConfig: API.OperationMethod<DeleteNotebookInstanceLifecycleConfigInput & RegionInput, DeleteNotebookInstanceLifecycleConfigResponse, DeleteNotebookInstanceLifecycleConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteOptimizationJobError = ResourceNotFound | CommonErrors;
/**
 * Deletes an optimization job.
 */
export declare const deleteOptimizationJob: API.OperationMethod<DeleteOptimizationJobRequest & RegionInput, DeleteOptimizationJobResponse, DeleteOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type DeletePartnerAppError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Deletes a SageMaker Partner AI App.
 */
export declare const deletePartnerApp: API.OperationMethod<DeletePartnerAppRequest & RegionInput, DeletePartnerAppResponse, DeletePartnerAppError, Credentials | HttpClient.HttpClient>;
export type DeletePipelineError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Deletes a pipeline if there are no running instances of the pipeline. To delete a pipeline, you must stop all running instances of the pipeline using the `StopPipelineExecution` API. When you delete a pipeline, all instances of the pipeline are deleted.
 */
export declare const deletePipeline: API.OperationMethod<DeletePipelineRequest & RegionInput, DeletePipelineResponse, DeletePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteProcessingJobError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes a processing job. After Amazon SageMaker deletes a processing job, all of the metadata for the processing job is lost. You can delete only processing jobs that are in a terminal state (`Stopped`, `Failed`, or `Completed`). You cannot delete a job that is in the `InProgress` or `Stopping` state. After deleting the job, you can reuse its name to create another processing job.
 */
export declare const deleteProcessingJob: API.OperationMethod<DeleteProcessingJobRequest & RegionInput, DeleteProcessingJobResponse, DeleteProcessingJobError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = ConflictException | CommonErrors;
/**
 * Delete the specified project.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectInput & RegionInput, DeleteProjectResponse, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteSpaceError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Used to delete a space.
 */
export declare const deleteSpace: API.OperationMethod<DeleteSpaceRequest & RegionInput, DeleteSpaceResponse, DeleteSpaceError, Credentials | HttpClient.HttpClient>;
export type DeleteStudioLifecycleConfigError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes the Amazon SageMaker AI Studio Lifecycle Configuration. In order to delete the Lifecycle Configuration, there must be no running apps using the Lifecycle Configuration. You must also remove the Lifecycle Configuration from UserSettings in all Domains and UserProfiles.
 */
export declare const deleteStudioLifecycleConfig: API.OperationMethod<DeleteStudioLifecycleConfigRequest & RegionInput, DeleteStudioLifecycleConfigResponse, DeleteStudioLifecycleConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = CommonErrors;
/**
 * Deletes the specified tags from an SageMaker resource.
 *
 * To list a resource's tags, use the `ListTags` API.
 *
 * When you call this API to delete tags from a hyperparameter tuning job, the deleted tags are not removed from training jobs that the hyperparameter tuning job launched before you called this API.
 *
 * When you call this API to delete tags from a SageMaker Domain or User Profile, the deleted tags are not removed from Apps that the SageMaker Domain or User Profile launched before you called this API.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsInput & RegionInput, DeleteTagsOutput, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteTrainingJobError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes a training job. After SageMaker deletes a training job, all of the metadata for the training job is lost. You can delete only training jobs that are in a terminal state (`Stopped`, `Failed`, or `Completed`) and don't retain an `Available` managed warm pool. You cannot delete a job that is in the `InProgress` or `Stopping` state. After deleting the job, you can reuse its name to create another training job.
 */
export declare const deleteTrainingJob: API.OperationMethod<DeleteTrainingJobRequest & RegionInput, DeleteTrainingJobResponse, DeleteTrainingJobError, Credentials | HttpClient.HttpClient>;
export type DeleteTrainingSessionError = ResourceNotFound | CommonErrors;
/**
 * Deletes a training session. You must stop a running session before deleting it. Use the `StopTrainingSession` operation to stop the session first.
 *
 * The following operations are related to `DeleteTrainingSession`:
 *
 * - `CreateTrainingSession`
 *
 * - `DescribeTrainingSession`
 *
 * - `StopTrainingSession`
 */
export declare const deleteTrainingSession: API.OperationMethod<DeleteTrainingSessionRequest & RegionInput, DeleteTrainingSessionResponse, DeleteTrainingSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteTrialError = ResourceNotFound | CommonErrors;
/**
 * Deletes the specified trial. All trial components that make up the trial must be deleted first. Use the DescribeTrialComponent API to get the list of trial components.
 */
export declare const deleteTrial: API.OperationMethod<DeleteTrialRequest & RegionInput, DeleteTrialResponse, DeleteTrialError, Credentials | HttpClient.HttpClient>;
export type DeleteTrialComponentError = ResourceNotFound | CommonErrors;
/**
 * Deletes the specified trial component. A trial component must be disassociated from all trials before the trial component can be deleted. To disassociate a trial component from a trial, call the DisassociateTrialComponent API.
 */
export declare const deleteTrialComponent: API.OperationMethod<DeleteTrialComponentRequest & RegionInput, DeleteTrialComponentResponse, DeleteTrialComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteUserProfileError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Deletes a user profile. When a user profile is deleted, the user loses access to their EFS volume, including data, notebooks, and other artifacts.
 */
export declare const deleteUserProfile: API.OperationMethod<DeleteUserProfileRequest & RegionInput, DeleteUserProfileResponse, DeleteUserProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkforceError = CommonErrors;
/**
 * Use this operation to delete a workforce.
 *
 * If you want to create a new workforce in an Amazon Web Services Region where a workforce already exists, use this operation to delete the existing workforce and then use CreateWorkforce to create a new workforce.
 *
 * If a private workforce contains one or more work teams, you must use the DeleteWorkteam operation to delete all work teams before you delete the workforce. If you try to delete a workforce that contains one or more work teams, you will receive a `ResourceInUse` error.
 */
export declare const deleteWorkforce: API.OperationMethod<DeleteWorkforceRequest & RegionInput, DeleteWorkforceResponse, DeleteWorkforceError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkteamError = ResourceLimitExceeded | CommonErrors;
/**
 * Deletes an existing work team. This operation can't be undone.
 */
export declare const deleteWorkteam: API.OperationMethod<DeleteWorkteamRequest & RegionInput, DeleteWorkteamResponse, DeleteWorkteamError, Credentials | HttpClient.HttpClient>;
export type DeregisterDevicesError = CommonErrors;
/**
 * Deregisters the specified devices. After you deregister a device, you will need to re-register the devices.
 */
export declare const deregisterDevices: API.OperationMethod<DeregisterDevicesRequest & RegionInput, DeregisterDevicesResponse, DeregisterDevicesError, Credentials | HttpClient.HttpClient>;
export type DescribeActionError = ResourceNotFound | CommonErrors;
/**
 * Describes an action.
 */
export declare const describeAction: API.OperationMethod<DescribeActionRequest & RegionInput, DescribeActionResponse, DescribeActionError, Credentials | HttpClient.HttpClient>;
export type DescribeAIBenchmarkJobError = ResourceNotFound | CommonErrors;
/**
 * Returns details of an AI benchmark job, including its status, configuration, target endpoint, and timing information.
 */
export declare const describeAIBenchmarkJob: API.OperationMethod<DescribeAIBenchmarkJobRequest & RegionInput, DescribeAIBenchmarkJobResponse, DescribeAIBenchmarkJobError, Credentials | HttpClient.HttpClient>;
export type DescribeAIRecommendationJobError = ResourceNotFound | CommonErrors;
/**
 * Returns details of an AI recommendation job, including its status, model source, performance targets, optimization recommendations, and deployment configurations.
 */
export declare const describeAIRecommendationJob: API.OperationMethod<DescribeAIRecommendationJobRequest & RegionInput, DescribeAIRecommendationJobResponse, DescribeAIRecommendationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeAIWorkloadConfigError = ResourceNotFound | CommonErrors;
/**
 * Returns details of an AI workload configuration, including the dataset configuration, benchmark tool settings, tags, and creation time.
 */
export declare const describeAIWorkloadConfig: API.OperationMethod<DescribeAIWorkloadConfigRequest & RegionInput, DescribeAIWorkloadConfigResponse, DescribeAIWorkloadConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeAlgorithmError = CommonErrors;
/**
 * Returns a description of the specified algorithm that is in your account.
 */
export declare const describeAlgorithm: API.OperationMethod<DescribeAlgorithmInput & RegionInput, DescribeAlgorithmOutput, DescribeAlgorithmError, Credentials | HttpClient.HttpClient>;
export type DescribeAppError = ResourceNotFound | CommonErrors;
/**
 * Describes the app.
 */
export declare const describeApp: API.OperationMethod<DescribeAppRequest & RegionInput, DescribeAppResponse, DescribeAppError, Credentials | HttpClient.HttpClient>;
export type DescribeAppImageConfigError = ResourceNotFound | CommonErrors;
/**
 * Describes an AppImageConfig.
 */
export declare const describeAppImageConfig: API.OperationMethod<DescribeAppImageConfigRequest & RegionInput, DescribeAppImageConfigResponse, DescribeAppImageConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeArtifactError = ResourceNotFound | CommonErrors;
/**
 * Describes an artifact.
 */
export declare const describeArtifact: API.OperationMethod<DescribeArtifactRequest & RegionInput, DescribeArtifactResponse, DescribeArtifactError, Credentials | HttpClient.HttpClient>;
export type DescribeAutoMLJobError = ResourceNotFound | CommonErrors;
/**
 * Returns information about an AutoML job created by calling CreateAutoMLJob.
 *
 * AutoML jobs created by calling CreateAutoMLJobV2 cannot be described by `DescribeAutoMLJob`.
 */
export declare const describeAutoMLJob: API.OperationMethod<DescribeAutoMLJobRequest & RegionInput, DescribeAutoMLJobResponse, DescribeAutoMLJobError, Credentials | HttpClient.HttpClient>;
export type DescribeAutoMLJobV2Error = ResourceNotFound | CommonErrors;
/**
 * Returns information about an AutoML job created by calling CreateAutoMLJobV2 or CreateAutoMLJob.
 */
export declare const describeAutoMLJobV2: API.OperationMethod<DescribeAutoMLJobV2Request & RegionInput, DescribeAutoMLJobV2Response, DescribeAutoMLJobV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeClusterError = ResourceNotFound | CommonErrors;
/**
 * Retrieves information of a SageMaker HyperPod cluster.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest & RegionInput, DescribeClusterResponse, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterEventError = ResourceNotFound | CommonErrors;
/**
 * Retrieves detailed information about a specific event for a given HyperPod cluster. This functionality is only supported when the `NodeProvisioningMode` is set to `Continuous`.
 */
export declare const describeClusterEvent: API.OperationMethod<DescribeClusterEventRequest & RegionInput, DescribeClusterEventResponse, DescribeClusterEventError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterExtensionError = ResourceNotFound | CommonErrors;
/**
 * Retrieves information about an extension installed on a SageMaker HyperPod cluster. The information includes the extension's version, configuration, and status, and a summary of how many cluster nodes are running the current version and configuration of the extension. If the extension has problems on some nodes, the response also lists the problems and how many nodes each one affects.
 */
export declare const describeClusterExtension: API.OperationMethod<DescribeClusterExtensionRequest & RegionInput, DescribeClusterExtensionResponse, DescribeClusterExtensionError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterNodeError = ResourceNotFound | CommonErrors;
/**
 * Retrieves information of a node (also called a *instance* interchangeably) of a SageMaker HyperPod cluster.
 */
export declare const describeClusterNode: API.OperationMethod<DescribeClusterNodeRequest & RegionInput, DescribeClusterNodeResponse, DescribeClusterNodeError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterOperationError = ResourceNotFound | CommonErrors;
/**
 * Retrieves detailed information about a specific operation for a given HyperPod cluster, such as a scaling operation or a deep health check. Use the `OperationId` returned by the `ListClusterOperations` operation to identify the operation to describe.
 */
export declare const describeClusterOperation: API.OperationMethod<DescribeClusterOperationRequest & RegionInput, DescribeClusterOperationResponse, DescribeClusterOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterSchedulerConfigError = ResourceNotFound | CommonErrors;
/**
 * Description of the cluster policy. This policy is used for task prioritization and fair-share allocation. This helps prioritize critical workloads and distributes idle compute across entities.
 */
export declare const describeClusterSchedulerConfig: API.OperationMethod<DescribeClusterSchedulerConfigRequest & RegionInput, DescribeClusterSchedulerConfigResponse, DescribeClusterSchedulerConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeCodeRepositoryError = CommonErrors;
/**
 * Gets details about the specified Git repository.
 */
export declare const describeCodeRepository: API.OperationMethod<DescribeCodeRepositoryInput & RegionInput, DescribeCodeRepositoryOutput, DescribeCodeRepositoryError, Credentials | HttpClient.HttpClient>;
export type DescribeCompilationJobError = ResourceNotFound | CommonErrors;
/**
 * Returns information about a model compilation job.
 *
 * To create a model compilation job, use CreateCompilationJob. To get information about multiple model compilation jobs, use ListCompilationJobs.
 */
export declare const describeCompilationJob: API.OperationMethod<DescribeCompilationJobRequest & RegionInput, DescribeCompilationJobResponse, DescribeCompilationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeComputeQuotaError = ResourceNotFound | CommonErrors;
/**
 * Description of the compute allocation definition.
 */
export declare const describeComputeQuota: API.OperationMethod<DescribeComputeQuotaRequest & RegionInput, DescribeComputeQuotaResponse, DescribeComputeQuotaError, Credentials | HttpClient.HttpClient>;
export type DescribeContextError = ResourceNotFound | CommonErrors;
/**
 * Describes a context.
 */
export declare const describeContext: API.OperationMethod<DescribeContextRequest & RegionInput, DescribeContextResponse, DescribeContextError, Credentials | HttpClient.HttpClient>;
export type DescribeDataQualityJobDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Gets the details of a data quality monitoring job definition.
 */
export declare const describeDataQualityJobDefinition: API.OperationMethod<DescribeDataQualityJobDefinitionRequest & RegionInput, DescribeDataQualityJobDefinitionResponse, DescribeDataQualityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeDeviceError = ResourceNotFound | CommonErrors;
/**
 * Describes the device.
 */
export declare const describeDevice: API.OperationMethod<DescribeDeviceRequest & RegionInput, DescribeDeviceResponse, DescribeDeviceError, Credentials | HttpClient.HttpClient>;
export type DescribeDeviceFleetError = ResourceNotFound | CommonErrors;
/**
 * A description of the fleet the device belongs to.
 */
export declare const describeDeviceFleet: API.OperationMethod<DescribeDeviceFleetRequest & RegionInput, DescribeDeviceFleetResponse, DescribeDeviceFleetError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainError = ResourceNotFound | CommonErrors;
/**
 * The description of the domain.
 */
export declare const describeDomain: API.OperationMethod<DescribeDomainRequest & RegionInput, DescribeDomainResponse, DescribeDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeEdgeDeploymentPlanError = ResourceNotFound | CommonErrors;
/**
 * Describes an edge deployment plan with deployment status per stage.
 */
export declare const describeEdgeDeploymentPlan: API.OperationMethod<DescribeEdgeDeploymentPlanRequest & RegionInput, DescribeEdgeDeploymentPlanResponse, DescribeEdgeDeploymentPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeEdgePackagingJobError = ResourceNotFound | CommonErrors;
/**
 * A description of edge packaging jobs.
 */
export declare const describeEdgePackagingJob: API.OperationMethod<DescribeEdgePackagingJobRequest & RegionInput, DescribeEdgePackagingJobResponse, DescribeEdgePackagingJobError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointError = EndpointNotFound | CommonErrors;
/**
 * Returns the description of an endpoint.
 */
export declare const describeEndpoint: API.OperationMethod<DescribeEndpointInput & RegionInput, DescribeEndpointOutput, DescribeEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointConfigError = EndpointConfigNotFound | CommonErrors;
/**
 * Returns the description of an endpoint configuration created using the `CreateEndpointConfig` API.
 */
export declare const describeEndpointConfig: API.OperationMethod<DescribeEndpointConfigInput & RegionInput, DescribeEndpointConfigOutput, DescribeEndpointConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeExperimentError = ResourceNotFound | CommonErrors;
/**
 * Provides a list of an experiment's properties.
 */
export declare const describeExperiment: API.OperationMethod<DescribeExperimentRequest & RegionInput, DescribeExperimentResponse, DescribeExperimentError, Credentials | HttpClient.HttpClient>;
export type DescribeFeatureGroupError = ResourceNotFound | CommonErrors;
/**
 * Use this operation to describe a `FeatureGroup`. The response includes information on the creation time, `FeatureGroup` name, the unique identifier for each `FeatureGroup`, and more.
 */
export declare const describeFeatureGroup: API.OperationMethod<DescribeFeatureGroupRequest & RegionInput, DescribeFeatureGroupResponse, DescribeFeatureGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeFeatureMetadataError = ResourceNotFound | CommonErrors;
/**
 * Shows the metadata for a feature within a feature group.
 */
export declare const describeFeatureMetadata: API.OperationMethod<DescribeFeatureMetadataRequest & RegionInput, DescribeFeatureMetadataResponse, DescribeFeatureMetadataError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Returns information about the specified flow definition.
 */
export declare const describeFlowDefinition: API.OperationMethod<DescribeFlowDefinitionRequest & RegionInput, DescribeFlowDefinitionResponse, DescribeFlowDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeHubError = ResourceNotFound | CommonErrors;
/**
 * Describes a hub.
 */
export declare const describeHub: API.OperationMethod<DescribeHubRequest & RegionInput, DescribeHubResponse, DescribeHubError, Credentials | HttpClient.HttpClient>;
export type DescribeHubContentError = ResourceNotFound | CommonErrors;
/**
 * Describe the content of a hub.
 */
export declare const describeHubContent: API.OperationMethod<DescribeHubContentRequest & RegionInput, DescribeHubContentResponse, DescribeHubContentError, Credentials | HttpClient.HttpClient>;
export type DescribeHumanTaskUiError = ResourceNotFound | CommonErrors;
/**
 * Returns information about the requested human task user interface (worker task template).
 */
export declare const describeHumanTaskUi: API.OperationMethod<DescribeHumanTaskUiRequest & RegionInput, DescribeHumanTaskUiResponse, DescribeHumanTaskUiError, Credentials | HttpClient.HttpClient>;
export type DescribeHyperParameterTuningJobError = ResourceNotFound | CommonErrors;
/**
 * Returns a description of a hyperparameter tuning job, depending on the fields selected. These fields can include the name, Amazon Resource Name (ARN), job status of your tuning job and more.
 */
export declare const describeHyperParameterTuningJob: API.OperationMethod<DescribeHyperParameterTuningJobRequest & RegionInput, DescribeHyperParameterTuningJobResponse, DescribeHyperParameterTuningJobError, Credentials | HttpClient.HttpClient>;
export type DescribeImageError = ResourceNotFound | CommonErrors;
/**
 * Describes a SageMaker AI image.
 */
export declare const describeImage: API.OperationMethod<DescribeImageRequest & RegionInput, DescribeImageResponse, DescribeImageError, Credentials | HttpClient.HttpClient>;
export type DescribeImageVersionError = ResourceNotFound | CommonErrors;
/**
 * Describes a version of a SageMaker AI image.
 */
export declare const describeImageVersion: API.OperationMethod<DescribeImageVersionRequest & RegionInput, DescribeImageVersionResponse, DescribeImageVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeInferenceComponentError = CommonErrors;
/**
 * Returns information about an inference component.
 */
export declare const describeInferenceComponent: API.OperationMethod<DescribeInferenceComponentInput & RegionInput, DescribeInferenceComponentOutput, DescribeInferenceComponentError, Credentials | HttpClient.HttpClient>;
export type DescribeInferenceExperimentError = ResourceNotFound | CommonErrors;
/**
 * Returns details about an inference experiment.
 */
export declare const describeInferenceExperiment: API.OperationMethod<DescribeInferenceExperimentRequest & RegionInput, DescribeInferenceExperimentResponse, DescribeInferenceExperimentError, Credentials | HttpClient.HttpClient>;
export type DescribeInferenceRecommendationsJobError = ResourceNotFound | CommonErrors;
/**
 * Provides the results of the Inference Recommender job. One or more recommendation jobs are returned.
 */
export declare const describeInferenceRecommendationsJob: API.OperationMethod<DescribeInferenceRecommendationsJobRequest & RegionInput, DescribeInferenceRecommendationsJobResponse, DescribeInferenceRecommendationsJobError, Credentials | HttpClient.HttpClient>;
export type DescribeJobError = ResourceNotFound | CommonErrors;
/**
 * Returns detailed information about a job, including its current status, secondary status, configuration, and timestamps. Use `SecondaryStatus` for granular progress tracking and `SecondaryStatusTransitions` to see the full history of status changes with timestamps.
 *
 * The following operations are related to `DescribeJob`:
 *
 * - `CreateJob`
 *
 * - `ListJobs`
 *
 * - `StopJob`
 *
 * - `DeleteJob`
 */
export declare const describeJob: API.OperationMethod<DescribeJobRequest & RegionInput, DescribeJobResponse, DescribeJobError, Credentials | HttpClient.HttpClient>;
export type DescribeJobSchemaVersionError = ResourceNotFound | CommonErrors;
/**
 * Returns the JSON schema for a specified job category and schema version. Use this schema to validate your `JobConfigDocument` before calling `CreateJob`. If you don't specify a schema version, the latest version is returned. The schema defines required fields, allowed values, and constraints for the job configuration.
 *
 * The following operations are related to `DescribeJobSchemaVersion`:
 *
 * - `ListJobSchemaVersions`
 *
 * - `CreateJob`
 */
export declare const describeJobSchemaVersion: API.OperationMethod<DescribeJobSchemaVersionRequest & RegionInput, DescribeJobSchemaVersionResponse, DescribeJobSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeLabelingJobError = ResourceNotFound | CommonErrors;
/**
 * Gets information about a labeling job.
 */
export declare const describeLabelingJob: API.OperationMethod<DescribeLabelingJobRequest & RegionInput, DescribeLabelingJobResponse, DescribeLabelingJobError, Credentials | HttpClient.HttpClient>;
export type DescribeLineageGroupError = ResourceNotFound | CommonErrors;
/**
 * Provides a list of properties for the requested lineage group. For more information, see Cross-Account Lineage Tracking in the *Amazon SageMaker Developer Guide*.
 */
export declare const describeLineageGroup: API.OperationMethod<DescribeLineageGroupRequest & RegionInput, DescribeLineageGroupResponse, DescribeLineageGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeMlflowAppError = ResourceNotFound | CommonErrors;
/**
 * Returns information about an MLflow App.
 */
export declare const describeMlflowApp: API.OperationMethod<DescribeMlflowAppRequest & RegionInput, DescribeMlflowAppResponse, DescribeMlflowAppError, Credentials | HttpClient.HttpClient>;
export type DescribeMlflowTrackingServerError = ResourceNotFound | CommonErrors;
/**
 * Returns information about an MLflow Tracking Server.
 */
export declare const describeMlflowTrackingServer: API.OperationMethod<DescribeMlflowTrackingServerRequest & RegionInput, DescribeMlflowTrackingServerResponse, DescribeMlflowTrackingServerError, Credentials | HttpClient.HttpClient>;
export type DescribeModelError = ModelNotFound | CommonErrors;
/**
 * Describes a model that you created using the `CreateModel` API.
 */
export declare const describeModel: API.OperationMethod<DescribeModelInput & RegionInput, DescribeModelOutput, DescribeModelError, Credentials | HttpClient.HttpClient>;
export type DescribeModelBiasJobDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Returns a description of a model bias job definition.
 */
export declare const describeModelBiasJobDefinition: API.OperationMethod<DescribeModelBiasJobDefinitionRequest & RegionInput, DescribeModelBiasJobDefinitionResponse, DescribeModelBiasJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeModelCardError = ResourceNotFound | CommonErrors;
/**
 * Describes the content, creation time, and security configuration of an Amazon SageMaker Model Card.
 *
 * To retrieve only metadata about a model card without requiring `kms:Decrypt` permission on the associated customer-managed Amazon Web Services KMS key, set `IncludedData` to `MetadataOnly`. The default is `AllData`, which returns the full model card `Content` and requires `kms:Decrypt` permission when a customer-managed key is configured.
 */
export declare const describeModelCard: API.OperationMethod<DescribeModelCardRequest & RegionInput, DescribeModelCardResponse, DescribeModelCardError, Credentials | HttpClient.HttpClient>;
export type DescribeModelCardExportJobError = ResourceNotFound | CommonErrors;
/**
 * Describes an Amazon SageMaker Model Card export job.
 */
export declare const describeModelCardExportJob: API.OperationMethod<DescribeModelCardExportJobRequest & RegionInput, DescribeModelCardExportJobResponse, DescribeModelCardExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeModelExplainabilityJobDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Returns a description of a model explainability job definition.
 */
export declare const describeModelExplainabilityJobDefinition: API.OperationMethod<DescribeModelExplainabilityJobDefinitionRequest & RegionInput, DescribeModelExplainabilityJobDefinitionResponse, DescribeModelExplainabilityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeModelPackageError = CommonErrors;
/**
 * Returns a description of the specified model package, which is used to create SageMaker models or list them on Amazon Web Services Marketplace.
 *
 * If you provided a KMS Key ID when you created your model package, you will see the KMS Decrypt API call in your CloudTrail logs when you use this API. To call this operation without requiring `kms:Decrypt` permission on the customer-managed key, set `IncludedData` to `MetadataOnly`; the response is returned with the embedded `ModelCard.ModelCardContent` field sanitized.
 *
 * To create models in SageMaker, buyers can subscribe to model packages listed on Amazon Web Services Marketplace.
 */
export declare const describeModelPackage: API.OperationMethod<DescribeModelPackageInput & RegionInput, DescribeModelPackageOutput, DescribeModelPackageError, Credentials | HttpClient.HttpClient>;
export type DescribeModelPackageGroupError = CommonErrors;
/**
 * Gets a description for the specified model group.
 */
export declare const describeModelPackageGroup: API.OperationMethod<DescribeModelPackageGroupInput & RegionInput, DescribeModelPackageGroupOutput, DescribeModelPackageGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeModelQualityJobDefinitionError = ResourceNotFound | CommonErrors;
/**
 * Returns a description of a model quality job definition.
 */
export declare const describeModelQualityJobDefinition: API.OperationMethod<DescribeModelQualityJobDefinitionRequest & RegionInput, DescribeModelQualityJobDefinitionResponse, DescribeModelQualityJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeMonitoringScheduleError = ResourceNotFound | CommonErrors;
/**
 * Describes the schedule for a monitoring job.
 */
export declare const describeMonitoringSchedule: API.OperationMethod<DescribeMonitoringScheduleRequest & RegionInput, DescribeMonitoringScheduleResponse, DescribeMonitoringScheduleError, Credentials | HttpClient.HttpClient>;
export type DescribeNotebookInstanceError = CommonErrors;
/**
 * Returns information about a notebook instance.
 */
export declare const describeNotebookInstance: API.OperationMethod<DescribeNotebookInstanceInput & RegionInput, DescribeNotebookInstanceOutput, DescribeNotebookInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeNotebookInstanceLifecycleConfigError = CommonErrors;
/**
 * Returns a description of a notebook instance lifecycle configuration.
 *
 * For information about notebook instance lifestyle configurations, see Step 2.1: (Optional) Customize a Notebook Instance.
 */
export declare const describeNotebookInstanceLifecycleConfig: API.OperationMethod<DescribeNotebookInstanceLifecycleConfigInput & RegionInput, DescribeNotebookInstanceLifecycleConfigOutput, DescribeNotebookInstanceLifecycleConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeOptimizationJobError = ResourceNotFound | CommonErrors;
/**
 * Provides the properties of the specified optimization job.
 */
export declare const describeOptimizationJob: API.OperationMethod<DescribeOptimizationJobRequest & RegionInput, DescribeOptimizationJobResponse, DescribeOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type DescribePartnerAppError = ResourceNotFound | CommonErrors;
/**
 * Gets information about a SageMaker Partner AI App.
 */
export declare const describePartnerApp: API.OperationMethod<DescribePartnerAppRequest & RegionInput, DescribePartnerAppResponse, DescribePartnerAppError, Credentials | HttpClient.HttpClient>;
export type DescribePipelineError = ResourceNotFound | CommonErrors;
/**
 * Describes the details of a pipeline.
 */
export declare const describePipeline: API.OperationMethod<DescribePipelineRequest & RegionInput, DescribePipelineResponse, DescribePipelineError, Credentials | HttpClient.HttpClient>;
export type DescribePipelineDefinitionForExecutionError = ResourceNotFound | CommonErrors;
/**
 * Describes the details of an execution's pipeline definition.
 */
export declare const describePipelineDefinitionForExecution: API.OperationMethod<DescribePipelineDefinitionForExecutionRequest & RegionInput, DescribePipelineDefinitionForExecutionResponse, DescribePipelineDefinitionForExecutionError, Credentials | HttpClient.HttpClient>;
export type DescribePipelineExecutionError = ResourceNotFound | CommonErrors;
/**
 * Describes the details of a pipeline execution.
 */
export declare const describePipelineExecution: API.OperationMethod<DescribePipelineExecutionRequest & RegionInput, DescribePipelineExecutionResponse, DescribePipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type DescribeProcessingJobError = ResourceNotFound | CommonErrors;
/**
 * Returns a description of a processing job.
 */
export declare const describeProcessingJob: API.OperationMethod<DescribeProcessingJobRequest & RegionInput, DescribeProcessingJobResponse, DescribeProcessingJobError, Credentials | HttpClient.HttpClient>;
export type DescribeProjectError = CommonErrors;
/**
 * Describes the details of a project.
 */
export declare const describeProject: API.OperationMethod<DescribeProjectInput & RegionInput, DescribeProjectOutput, DescribeProjectError, Credentials | HttpClient.HttpClient>;
export type DescribeReservedCapacityError = ResourceNotFound | CommonErrors;
/**
 * Retrieves details about a reserved capacity.
 */
export declare const describeReservedCapacity: API.OperationMethod<DescribeReservedCapacityRequest & RegionInput, DescribeReservedCapacityResponse, DescribeReservedCapacityError, Credentials | HttpClient.HttpClient>;
export type DescribeSpaceError = ResourceNotFound | CommonErrors;
/**
 * Describes the space.
 */
export declare const describeSpace: API.OperationMethod<DescribeSpaceRequest & RegionInput, DescribeSpaceResponse, DescribeSpaceError, Credentials | HttpClient.HttpClient>;
export type DescribeStudioLifecycleConfigError = ResourceNotFound | CommonErrors;
/**
 * Describes the Amazon SageMaker AI Studio Lifecycle Configuration.
 */
export declare const describeStudioLifecycleConfig: API.OperationMethod<DescribeStudioLifecycleConfigRequest & RegionInput, DescribeStudioLifecycleConfigResponse, DescribeStudioLifecycleConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeSubscribedWorkteamError = CommonErrors;
/**
 * Gets information about a work team provided by a vendor. It returns details about the subscription with a vendor in the Amazon Web Services Marketplace.
 */
export declare const describeSubscribedWorkteam: API.OperationMethod<DescribeSubscribedWorkteamRequest & RegionInput, DescribeSubscribedWorkteamResponse, DescribeSubscribedWorkteamError, Credentials | HttpClient.HttpClient>;
export type DescribeTrainingJobError = ResourceNotFound | CommonErrors;
/**
 * Returns information about a training job.
 *
 * Some of the attributes below only appear if the training job successfully starts. If the training job fails, `TrainingJobStatus` is `Failed` and, depending on the `FailureReason`, attributes like `TrainingStartTime`, `TrainingTimeInSeconds`, `TrainingEndTime`, and `BillableTimeInSeconds` may not be present in the response.
 */
export declare const describeTrainingJob: API.OperationMethod<DescribeTrainingJobRequest & RegionInput, DescribeTrainingJobResponse, DescribeTrainingJobError, Credentials | HttpClient.HttpClient>;
export type DescribeTrainingPlanError = ResourceNotFound | CommonErrors;
/**
 * Retrieves detailed information about a specific training plan.
 */
export declare const describeTrainingPlan: API.OperationMethod<DescribeTrainingPlanRequest & RegionInput, DescribeTrainingPlanResponse, DescribeTrainingPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeTrainingPlanExtensionHistoryError = ResourceNotFound | CommonErrors;
/**
 * Retrieves the extension history for a specified training plan. The response includes details about each extension, such as the offering ID, start and end dates, status, payment status, and cost information.
 */
export declare const describeTrainingPlanExtensionHistory: API.PaginatedOperationMethod<DescribeTrainingPlanExtensionHistoryRequest & RegionInput, DescribeTrainingPlanExtensionHistoryResponse, DescribeTrainingPlanExtensionHistoryError, Credentials | HttpClient.HttpClient, TrainingPlanExtension>;
export type DescribeTrainingSessionError = ResourceNotFound | CommonErrors;
/**
 * Retrieves detailed information about a training session, including its current status, model configuration, Low-Rank Adaptation (LoRA) parameters, and timestamps.
 *
 * The following operations are related to `DescribeTrainingSession`:
 *
 * - `CreateTrainingSession`
 *
 * - `ListTrainingSessions`
 *
 * - `StopTrainingSession`
 *
 * - `DeleteTrainingSession`
 */
export declare const describeTrainingSession: API.OperationMethod<DescribeTrainingSessionRequest & RegionInput, DescribeTrainingSessionResponse, DescribeTrainingSessionError, Credentials | HttpClient.HttpClient>;
export type DescribeTransformJobError = ResourceNotFound | CommonErrors;
/**
 * Returns information about a transform job.
 */
export declare const describeTransformJob: API.OperationMethod<DescribeTransformJobRequest & RegionInput, DescribeTransformJobResponse, DescribeTransformJobError, Credentials | HttpClient.HttpClient>;
export type DescribeTrialError = ResourceNotFound | CommonErrors;
/**
 * Provides a list of a trial's properties.
 */
export declare const describeTrial: API.OperationMethod<DescribeTrialRequest & RegionInput, DescribeTrialResponse, DescribeTrialError, Credentials | HttpClient.HttpClient>;
export type DescribeTrialComponentError = ResourceNotFound | CommonErrors;
/**
 * Provides a list of a trials component's properties.
 */
export declare const describeTrialComponent: API.OperationMethod<DescribeTrialComponentRequest & RegionInput, DescribeTrialComponentResponse, DescribeTrialComponentError, Credentials | HttpClient.HttpClient>;
export type DescribeUserProfileError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Describes a user profile. For more information, see `CreateUserProfile`.
 */
export declare const describeUserProfile: API.OperationMethod<DescribeUserProfileRequest & RegionInput, DescribeUserProfileResponse, DescribeUserProfileError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkforceError = CommonErrors;
/**
 * Lists private workforce information, including workforce name, Amazon Resource Name (ARN), and, if applicable, allowed IP address ranges (CIDRs). Allowable IP address ranges are the IP addresses that workers can use to access tasks.
 *
 * This operation applies only to private workforces.
 */
export declare const describeWorkforce: API.OperationMethod<DescribeWorkforceRequest & RegionInput, DescribeWorkforceResponse, DescribeWorkforceError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkteamError = CommonErrors;
/**
 * Gets information about a specific work team. You can see information such as the creation date, the last updated date, membership information, and the work team's Amazon Resource Name (ARN).
 */
export declare const describeWorkteam: API.OperationMethod<DescribeWorkteamRequest & RegionInput, DescribeWorkteamResponse, DescribeWorkteamError, Credentials | HttpClient.HttpClient>;
export type DetachClusterNodeVolumeError = ResourceNotFound | CommonErrors;
/**
 * Detaches your Amazon Elastic Block Store (Amazon EBS) volume from a node in your EKS orchestrated SageMaker HyperPod cluster.
 *
 * This API works with the Amazon Elastic Block Store (Amazon EBS) Container Storage Interface (CSI) driver to manage the lifecycle of persistent storage in your HyperPod EKS clusters.
 */
export declare const detachClusterNodeVolume: API.OperationMethod<DetachClusterNodeVolumeRequest & RegionInput, DetachClusterNodeVolumeResponse, DetachClusterNodeVolumeError, Credentials | HttpClient.HttpClient>;
export type DisableSagemakerServicecatalogPortfolioError = CommonErrors;
/**
 * Disables using Service Catalog in SageMaker. Service Catalog is used to create SageMaker projects.
 */
export declare const disableSagemakerServicecatalogPortfolio: API.OperationMethod<DisableSagemakerServicecatalogPortfolioInput & RegionInput, DisableSagemakerServicecatalogPortfolioOutput, DisableSagemakerServicecatalogPortfolioError, Credentials | HttpClient.HttpClient>;
export type DisassociateTrialComponentError = ResourceNotFound | CommonErrors;
/**
 * Disassociates a trial component from a trial. This doesn't effect other trials the component is associated with. Before you can delete a component, you must disassociate the component from all trials it is associated with. To associate a trial component with a trial, call the AssociateTrialComponent API.
 *
 * To get a list of the trials a component is associated with, use the Search API. Specify `ExperimentTrialComponent` for the `Resource` parameter. The list appears in the response under `Results.TrialComponent.Parents`.
 */
export declare const disassociateTrialComponent: API.OperationMethod<DisassociateTrialComponentRequest & RegionInput, DisassociateTrialComponentResponse, DisassociateTrialComponentError, Credentials | HttpClient.HttpClient>;
export type EnableSagemakerServicecatalogPortfolioError = CommonErrors;
/**
 * Enables using Service Catalog in SageMaker. Service Catalog is used to create SageMaker projects.
 */
export declare const enableSagemakerServicecatalogPortfolio: API.OperationMethod<EnableSagemakerServicecatalogPortfolioInput & RegionInput, EnableSagemakerServicecatalogPortfolioOutput, EnableSagemakerServicecatalogPortfolioError, Credentials | HttpClient.HttpClient>;
export type ExtendTrainingPlanError = ResourceNotFound | CommonErrors;
/**
 * Extends an existing training plan by purchasing an extension offering. This allows you to add additional compute capacity time to your training plan without creating a new plan or reconfiguring your workloads.
 *
 * To find available extension offerings, use the ` SearchTrainingPlanOfferings ` API with the `TrainingPlanArn` parameter.
 *
 * To view the history of extensions for a training plan, use the ` DescribeTrainingPlanExtensionHistory ` API.
 */
export declare const extendTrainingPlan: API.OperationMethod<ExtendTrainingPlanRequest & RegionInput, ExtendTrainingPlanResponse, ExtendTrainingPlanError, Credentials | HttpClient.HttpClient>;
export type GetDeviceFleetReportError = CommonErrors;
/**
 * Describes a fleet.
 */
export declare const getDeviceFleetReport: API.OperationMethod<GetDeviceFleetReportRequest & RegionInput, GetDeviceFleetReportResponse, GetDeviceFleetReportError, Credentials | HttpClient.HttpClient>;
export type GetLineageGroupPolicyError = ResourceNotFound | CommonErrors;
/**
 * The resource policy for the lineage group.
 */
export declare const getLineageGroupPolicy: API.OperationMethod<GetLineageGroupPolicyRequest & RegionInput, GetLineageGroupPolicyResponse, GetLineageGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type GetModelPackageGroupPolicyError = CommonErrors;
/**
 * Gets a resource policy that manages access for a model group. For information about resource policies, see Identity-based policies and resource-based policies in the *Amazon Web Services Identity and Access Management User Guide.*.
 */
export declare const getModelPackageGroupPolicy: API.OperationMethod<GetModelPackageGroupPolicyInput & RegionInput, GetModelPackageGroupPolicyOutput, GetModelPackageGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type GetSagemakerServicecatalogPortfolioStatusError = CommonErrors;
/**
 * Gets the status of Service Catalog in SageMaker. Service Catalog is used to create SageMaker projects.
 */
export declare const getSagemakerServicecatalogPortfolioStatus: API.OperationMethod<GetSagemakerServicecatalogPortfolioStatusInput & RegionInput, GetSagemakerServicecatalogPortfolioStatusOutput, GetSagemakerServicecatalogPortfolioStatusError, Credentials | HttpClient.HttpClient>;
export type GetScalingConfigurationRecommendationError = ResourceNotFound | CommonErrors;
/**
 * Starts an Amazon SageMaker Inference Recommender autoscaling recommendation job. Returns recommendations for autoscaling policies that you can apply to your SageMaker endpoint.
 */
export declare const getScalingConfigurationRecommendation: API.OperationMethod<GetScalingConfigurationRecommendationRequest & RegionInput, GetScalingConfigurationRecommendationResponse, GetScalingConfigurationRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetSearchSuggestionsError = CommonErrors;
/**
 * An auto-complete API for the search functionality in the SageMaker console. It returns suggestions of possible matches for the property name to use in `Search` queries. Provides suggestions for `HyperParameters`, `Tags`, and `Metrics`.
 */
export declare const getSearchSuggestions: API.OperationMethod<GetSearchSuggestionsRequest & RegionInput, GetSearchSuggestionsResponse, GetSearchSuggestionsError, Credentials | HttpClient.HttpClient>;
export type ImportHubContentError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Import hub content.
 */
export declare const importHubContent: API.OperationMethod<ImportHubContentRequest & RegionInput, ImportHubContentResponse, ImportHubContentError, Credentials | HttpClient.HttpClient>;
export type ListActionsError = ResourceNotFound | CommonErrors;
/**
 * Lists the actions in your account and their properties.
 */
export declare const listActions: API.PaginatedOperationMethod<ListActionsRequest & RegionInput, ListActionsResponse, ListActionsError, Credentials | HttpClient.HttpClient, ActionSummary>;
export type ListAIBenchmarkJobsError = CommonErrors;
/**
 * Returns a list of AI benchmark jobs in your account. You can filter the results by name, status, and creation time, and sort the results. The response is paginated.
 */
export declare const listAIBenchmarkJobs: API.PaginatedOperationMethod<ListAIBenchmarkJobsRequest & RegionInput, ListAIBenchmarkJobsResponse, ListAIBenchmarkJobsError, Credentials | HttpClient.HttpClient, AIBenchmarkJobSummary>;
export type ListAIRecommendationJobsError = CommonErrors;
/**
 * Returns a list of AI recommendation jobs in your account. You can filter the results by name, status, and creation time, and sort the results. The response is paginated.
 */
export declare const listAIRecommendationJobs: API.PaginatedOperationMethod<ListAIRecommendationJobsRequest & RegionInput, ListAIRecommendationJobsResponse, ListAIRecommendationJobsError, Credentials | HttpClient.HttpClient, AIRecommendationJobSummary>;
export type ListAIWorkloadConfigsError = CommonErrors;
/**
 * Returns a list of AI workload configurations in your account. You can filter the results by name and creation time, and sort the results. The response is paginated.
 */
export declare const listAIWorkloadConfigs: API.PaginatedOperationMethod<ListAIWorkloadConfigsRequest & RegionInput, ListAIWorkloadConfigsResponse, ListAIWorkloadConfigsError, Credentials | HttpClient.HttpClient, AIWorkloadConfigSummary>;
export type ListAlgorithmsError = CommonErrors;
/**
 * Lists the machine learning algorithms that have been created.
 */
export declare const listAlgorithms: API.PaginatedOperationMethod<ListAlgorithmsInput & RegionInput, ListAlgorithmsOutput, ListAlgorithmsError, Credentials | HttpClient.HttpClient, AlgorithmSummary>;
export type ListAliasesError = ResourceNotFound | CommonErrors;
/**
 * Lists the aliases of a specified image or image version.
 */
export declare const listAliases: API.PaginatedOperationMethod<ListAliasesRequest & RegionInput, ListAliasesResponse, ListAliasesError, Credentials | HttpClient.HttpClient, SageMakerImageVersionAlias>;
export type ListAppImageConfigsError = CommonErrors;
/**
 * Lists the AppImageConfigs in your account and their properties. The list can be filtered by creation time or modified time, and whether the AppImageConfig name contains a specified string.
 */
export declare const listAppImageConfigs: API.PaginatedOperationMethod<ListAppImageConfigsRequest & RegionInput, ListAppImageConfigsResponse, ListAppImageConfigsError, Credentials | HttpClient.HttpClient, AppImageConfigDetails>;
export type ListAppsError = CommonErrors;
/**
 * Lists apps.
 */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest & RegionInput, ListAppsResponse, ListAppsError, Credentials | HttpClient.HttpClient, AppDetails>;
export type ListArtifactsError = ResourceNotFound | CommonErrors;
/**
 * Lists the artifacts in your account and their properties.
 */
export declare const listArtifacts: API.PaginatedOperationMethod<ListArtifactsRequest & RegionInput, ListArtifactsResponse, ListArtifactsError, Credentials | HttpClient.HttpClient, ArtifactSummary>;
export type ListAssociationsError = ResourceNotFound | CommonErrors;
/**
 * Lists the associations in your account and their properties.
 */
export declare const listAssociations: API.PaginatedOperationMethod<ListAssociationsRequest & RegionInput, ListAssociationsResponse, ListAssociationsError, Credentials | HttpClient.HttpClient, AssociationSummary>;
export type ListAutoMLJobsError = CommonErrors;
/**
 * Request a list of jobs.
 */
export declare const listAutoMLJobs: API.PaginatedOperationMethod<ListAutoMLJobsRequest & RegionInput, ListAutoMLJobsResponse, ListAutoMLJobsError, Credentials | HttpClient.HttpClient, AutoMLJobSummary>;
export type ListCandidatesForAutoMLJobError = ResourceNotFound | CommonErrors;
/**
 * List the candidates created for the job.
 */
export declare const listCandidatesForAutoMLJob: API.PaginatedOperationMethod<ListCandidatesForAutoMLJobRequest & RegionInput, ListCandidatesForAutoMLJobResponse, ListCandidatesForAutoMLJobError, Credentials | HttpClient.HttpClient, AutoMLCandidate>;
export type ListClusterEventsError = ResourceNotFound | CommonErrors;
/**
 * Retrieves a list of event summaries for a specified HyperPod cluster. The operation supports filtering, sorting, and pagination of results. This functionality is only supported when the `NodeProvisioningMode` is set to `Continuous`.
 */
export declare const listClusterEvents: API.PaginatedOperationMethod<ListClusterEventsRequest & RegionInput, ListClusterEventsResponse, ListClusterEventsError, Credentials | HttpClient.HttpClient, ClusterEventSummary>;
export type ListClusterExtensionsError = ResourceNotFound | CommonErrors;
/**
 * Lists the extensions installed on a SageMaker HyperPod cluster.
 */
export declare const listClusterExtensions: API.PaginatedOperationMethod<ListClusterExtensionsRequest & RegionInput, ListClusterExtensionsResponse, ListClusterExtensionsError, Credentials | HttpClient.HttpClient, ExtensionSummary>;
export type ListClusterExtensionVersionsError = CommonErrors;
/**
 * Lists the versions of an extension that you can install on a SageMaker HyperPod cluster, from the highest version to the lowest. Use a version from this list as the `ExtensionVersion` in `CreateClusterExtension` or `UpdateClusterExtension`.
 *
 * The list contains only versions that you can install. Versions that SageMaker HyperPod no longer offers for new installations don't appear. If SageMaker HyperPod doesn't offer an extension with the name that you specify, the response contains an empty list.
 */
export declare const listClusterExtensionVersions: API.PaginatedOperationMethod<ListClusterExtensionVersionsRequest & RegionInput, ListClusterExtensionVersionsResponse, ListClusterExtensionVersionsError, Credentials | HttpClient.HttpClient, ExtensionVersionSummary>;
export type ListClusterNodesError = ResourceNotFound | CommonErrors;
/**
 * Retrieves the list of instances (also called *nodes* interchangeably) in a SageMaker HyperPod cluster.
 */
export declare const listClusterNodes: API.PaginatedOperationMethod<ListClusterNodesRequest & RegionInput, ListClusterNodesResponse, ListClusterNodesError, Credentials | HttpClient.HttpClient, ClusterNodeSummary>;
export type ListClusterOperationsError = ResourceNotFound | CommonErrors;
/**
 * Retrieves a list of operation summaries for a specified HyperPod cluster, such as scaling operations and deep health checks. The operation supports filtering, sorting, and pagination of results.
 */
export declare const listClusterOperations: API.PaginatedOperationMethod<ListClusterOperationsRequest & RegionInput, ListClusterOperationsResponse, ListClusterOperationsError, Credentials | HttpClient.HttpClient, ClusterOperationSummary>;
export type ListClustersError = CommonErrors;
/**
 * Retrieves the list of SageMaker HyperPod clusters.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest & RegionInput, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, ClusterSummary>;
export type ListClusterSchedulerConfigsError = CommonErrors;
/**
 * List the cluster policy configurations.
 */
export declare const listClusterSchedulerConfigs: API.PaginatedOperationMethod<ListClusterSchedulerConfigsRequest & RegionInput, ListClusterSchedulerConfigsResponse, ListClusterSchedulerConfigsError, Credentials | HttpClient.HttpClient, ClusterSchedulerConfigSummary>;
export type ListCodeRepositoriesError = CommonErrors;
/**
 * Gets a list of the Git repositories in your account.
 */
export declare const listCodeRepositories: API.PaginatedOperationMethod<ListCodeRepositoriesInput & RegionInput, ListCodeRepositoriesOutput, ListCodeRepositoriesError, Credentials | HttpClient.HttpClient, CodeRepositorySummary>;
export type ListCompilationJobsError = CommonErrors;
/**
 * Lists model compilation jobs that satisfy various filters.
 *
 * To create a model compilation job, use CreateCompilationJob. To get information about a particular model compilation job you have created, use DescribeCompilationJob.
 */
export declare const listCompilationJobs: API.PaginatedOperationMethod<ListCompilationJobsRequest & RegionInput, ListCompilationJobsResponse, ListCompilationJobsError, Credentials | HttpClient.HttpClient, CompilationJobSummary>;
export type ListComputeQuotasError = CommonErrors;
/**
 * List the resource allocation definitions.
 */
export declare const listComputeQuotas: API.PaginatedOperationMethod<ListComputeQuotasRequest & RegionInput, ListComputeQuotasResponse, ListComputeQuotasError, Credentials | HttpClient.HttpClient, ComputeQuotaSummary>;
export type ListContextsError = ResourceNotFound | CommonErrors;
/**
 * Lists the contexts in your account and their properties.
 */
export declare const listContexts: API.PaginatedOperationMethod<ListContextsRequest & RegionInput, ListContextsResponse, ListContextsError, Credentials | HttpClient.HttpClient, ContextSummary>;
export type ListDataQualityJobDefinitionsError = CommonErrors;
/**
 * Lists the data quality job definitions in your account.
 */
export declare const listDataQualityJobDefinitions: API.PaginatedOperationMethod<ListDataQualityJobDefinitionsRequest & RegionInput, ListDataQualityJobDefinitionsResponse, ListDataQualityJobDefinitionsError, Credentials | HttpClient.HttpClient, MonitoringJobDefinitionSummary>;
export type ListDeviceFleetsError = CommonErrors;
/**
 * Returns a list of devices in the fleet.
 */
export declare const listDeviceFleets: API.PaginatedOperationMethod<ListDeviceFleetsRequest & RegionInput, ListDeviceFleetsResponse, ListDeviceFleetsError, Credentials | HttpClient.HttpClient, DeviceFleetSummary>;
export type ListDevicesError = CommonErrors;
/**
 * A list of devices.
 */
export declare const listDevices: API.PaginatedOperationMethod<ListDevicesRequest & RegionInput, ListDevicesResponse, ListDevicesError, Credentials | HttpClient.HttpClient, DeviceSummary>;
export type ListDomainsError = CommonErrors;
/**
 * Lists the domains.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest & RegionInput, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient, DomainDetails>;
export type ListEdgeDeploymentPlansError = CommonErrors;
/**
 * Lists all edge deployment plans.
 */
export declare const listEdgeDeploymentPlans: API.PaginatedOperationMethod<ListEdgeDeploymentPlansRequest & RegionInput, ListEdgeDeploymentPlansResponse, ListEdgeDeploymentPlansError, Credentials | HttpClient.HttpClient, EdgeDeploymentPlanSummary>;
export type ListEdgePackagingJobsError = CommonErrors;
/**
 * Returns a list of edge packaging jobs.
 */
export declare const listEdgePackagingJobs: API.PaginatedOperationMethod<ListEdgePackagingJobsRequest & RegionInput, ListEdgePackagingJobsResponse, ListEdgePackagingJobsError, Credentials | HttpClient.HttpClient, EdgePackagingJobSummary>;
export type ListEndpointConfigsError = CommonErrors;
/**
 * Lists endpoint configurations.
 */
export declare const listEndpointConfigs: API.PaginatedOperationMethod<ListEndpointConfigsInput & RegionInput, ListEndpointConfigsOutput, ListEndpointConfigsError, Credentials | HttpClient.HttpClient, EndpointConfigSummary>;
export type ListEndpointsError = CommonErrors;
/**
 * Lists endpoints.
 */
export declare const listEndpoints: API.PaginatedOperationMethod<ListEndpointsInput & RegionInput, ListEndpointsOutput, ListEndpointsError, Credentials | HttpClient.HttpClient, EndpointSummary>;
export type ListExperimentsError = CommonErrors;
/**
 * Lists all the experiments in your account. The list can be filtered to show only experiments that were created in a specific time range. The list can be sorted by experiment name or creation time.
 */
export declare const listExperiments: API.PaginatedOperationMethod<ListExperimentsRequest & RegionInput, ListExperimentsResponse, ListExperimentsError, Credentials | HttpClient.HttpClient, ExperimentSummary>;
export type ListFeatureGroupsError = CommonErrors;
/**
 * List `FeatureGroup`s based on given filter and order.
 */
export declare const listFeatureGroups: API.PaginatedOperationMethod<ListFeatureGroupsRequest & RegionInput, ListFeatureGroupsResponse, ListFeatureGroupsError, Credentials | HttpClient.HttpClient, FeatureGroupSummary>;
export type ListFlowDefinitionsError = CommonErrors;
/**
 * Returns information about the flow definitions in your account.
 */
export declare const listFlowDefinitions: API.PaginatedOperationMethod<ListFlowDefinitionsRequest & RegionInput, ListFlowDefinitionsResponse, ListFlowDefinitionsError, Credentials | HttpClient.HttpClient, FlowDefinitionSummary>;
export type ListHubContentsError = ResourceNotFound | CommonErrors;
/**
 * List the contents of a hub.
 */
export declare const listHubContents: API.OperationMethod<ListHubContentsRequest & RegionInput, ListHubContentsResponse, ListHubContentsError, Credentials | HttpClient.HttpClient>;
export type ListHubContentVersionsError = ResourceNotFound | CommonErrors;
/**
 * List hub content versions.
 */
export declare const listHubContentVersions: API.OperationMethod<ListHubContentVersionsRequest & RegionInput, ListHubContentVersionsResponse, ListHubContentVersionsError, Credentials | HttpClient.HttpClient>;
export type ListHubsError = CommonErrors;
/**
 * List all existing hubs.
 */
export declare const listHubs: API.OperationMethod<ListHubsRequest & RegionInput, ListHubsResponse, ListHubsError, Credentials | HttpClient.HttpClient>;
export type ListHumanTaskUisError = CommonErrors;
/**
 * Returns information about the human task user interfaces in your account.
 */
export declare const listHumanTaskUis: API.PaginatedOperationMethod<ListHumanTaskUisRequest & RegionInput, ListHumanTaskUisResponse, ListHumanTaskUisError, Credentials | HttpClient.HttpClient, HumanTaskUiSummary>;
export type ListHyperParameterTuningJobsError = CommonErrors;
/**
 * Gets a list of HyperParameterTuningJobSummary objects that describe the hyperparameter tuning jobs launched in your account.
 */
export declare const listHyperParameterTuningJobs: API.PaginatedOperationMethod<ListHyperParameterTuningJobsRequest & RegionInput, ListHyperParameterTuningJobsResponse, ListHyperParameterTuningJobsError, Credentials | HttpClient.HttpClient, HyperParameterTuningJobSummary>;
export type ListImagesError = CommonErrors;
/**
 * Lists the images in your account and their properties. The list can be filtered by creation time or modified time, and whether the image name contains a specified string.
 */
export declare const listImages: API.PaginatedOperationMethod<ListImagesRequest & RegionInput, ListImagesResponse, ListImagesError, Credentials | HttpClient.HttpClient, Image>;
export type ListImageVersionsError = ResourceNotFound | CommonErrors;
/**
 * Lists the versions of a specified image and their properties. The list can be filtered by creation time or modified time.
 */
export declare const listImageVersions: API.PaginatedOperationMethod<ListImageVersionsRequest & RegionInput, ListImageVersionsResponse, ListImageVersionsError, Credentials | HttpClient.HttpClient, ImageVersion>;
export type ListInferenceComponentsError = CommonErrors;
/**
 * Lists the inference components in your account and their properties.
 */
export declare const listInferenceComponents: API.PaginatedOperationMethod<ListInferenceComponentsInput & RegionInput, ListInferenceComponentsOutput, ListInferenceComponentsError, Credentials | HttpClient.HttpClient, InferenceComponentSummary>;
export type ListInferenceExperimentsError = CommonErrors;
/**
 * Returns the list of all inference experiments.
 */
export declare const listInferenceExperiments: API.PaginatedOperationMethod<ListInferenceExperimentsRequest & RegionInput, ListInferenceExperimentsResponse, ListInferenceExperimentsError, Credentials | HttpClient.HttpClient, InferenceExperimentSummary>;
export type ListInferenceRecommendationsJobsError = CommonErrors;
/**
 * Lists recommendation jobs that satisfy various filters.
 */
export declare const listInferenceRecommendationsJobs: API.PaginatedOperationMethod<ListInferenceRecommendationsJobsRequest & RegionInput, ListInferenceRecommendationsJobsResponse, ListInferenceRecommendationsJobsError, Credentials | HttpClient.HttpClient, InferenceRecommendationsJob>;
export type ListInferenceRecommendationsJobStepsError = ResourceNotFound | CommonErrors;
/**
 * Returns a list of the subtasks for an Inference Recommender job.
 *
 * The supported subtasks are benchmarks, which evaluate the performance of your model on different instance types.
 */
export declare const listInferenceRecommendationsJobSteps: API.PaginatedOperationMethod<ListInferenceRecommendationsJobStepsRequest & RegionInput, ListInferenceRecommendationsJobStepsResponse, ListInferenceRecommendationsJobStepsError, Credentials | HttpClient.HttpClient, InferenceRecommendationsJobStep>;
export type ListJobsError = CommonErrors;
/**
 * Lists jobs in a specified category. You can filter results by creation time, last modified time, name, and status. Results are sorted by the field you specify in `SortBy`. Use pagination to retrieve large result sets efficiently.
 *
 * The following operations are related to `ListJobs`:
 *
 * - `CreateJob`
 *
 * - `DescribeJob`
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest & RegionInput, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListJobSchemaVersionsError = ResourceNotFound | CommonErrors;
/**
 * Lists available configuration schema versions for a specified job category. Use the schema versions with `DescribeJobSchemaVersion` to retrieve the full schema document.
 *
 * The following operations are related to `ListJobSchemaVersions`:
 *
 * - `DescribeJobSchemaVersion`
 *
 * - `CreateJob`
 */
export declare const listJobSchemaVersions: API.PaginatedOperationMethod<ListJobSchemaVersionsRequest & RegionInput, ListJobSchemaVersionsResponse, ListJobSchemaVersionsError, Credentials | HttpClient.HttpClient, JobConfigSchemaVersionSummary>;
export type ListLabelingJobsError = CommonErrors;
/**
 * Gets a list of labeling jobs.
 */
export declare const listLabelingJobs: API.PaginatedOperationMethod<ListLabelingJobsRequest & RegionInput, ListLabelingJobsResponse, ListLabelingJobsError, Credentials | HttpClient.HttpClient, LabelingJobSummary>;
export type ListLabelingJobsForWorkteamError = ResourceNotFound | CommonErrors;
/**
 * Gets a list of labeling jobs assigned to a specified work team.
 */
export declare const listLabelingJobsForWorkteam: API.PaginatedOperationMethod<ListLabelingJobsForWorkteamRequest & RegionInput, ListLabelingJobsForWorkteamResponse, ListLabelingJobsForWorkteamError, Credentials | HttpClient.HttpClient, LabelingJobForWorkteamSummary>;
export type ListLineageGroupsError = CommonErrors;
/**
 * A list of lineage groups shared with your Amazon Web Services account. For more information, see Cross-Account Lineage Tracking in the *Amazon SageMaker Developer Guide*.
 */
export declare const listLineageGroups: API.PaginatedOperationMethod<ListLineageGroupsRequest & RegionInput, ListLineageGroupsResponse, ListLineageGroupsError, Credentials | HttpClient.HttpClient, LineageGroupSummary>;
export type ListMlflowAppsError = CommonErrors;
/**
 * Lists all MLflow Apps
 */
export declare const listMlflowApps: API.PaginatedOperationMethod<ListMlflowAppsRequest & RegionInput, ListMlflowAppsResponse, ListMlflowAppsError, Credentials | HttpClient.HttpClient, MlflowAppSummary>;
export type ListMlflowTrackingServersError = CommonErrors;
/**
 * Lists all MLflow Tracking Servers.
 */
export declare const listMlflowTrackingServers: API.PaginatedOperationMethod<ListMlflowTrackingServersRequest & RegionInput, ListMlflowTrackingServersResponse, ListMlflowTrackingServersError, Credentials | HttpClient.HttpClient, TrackingServerSummary>;
export type ListModelBiasJobDefinitionsError = CommonErrors;
/**
 * Lists model bias jobs definitions that satisfy various filters.
 */
export declare const listModelBiasJobDefinitions: API.PaginatedOperationMethod<ListModelBiasJobDefinitionsRequest & RegionInput, ListModelBiasJobDefinitionsResponse, ListModelBiasJobDefinitionsError, Credentials | HttpClient.HttpClient, MonitoringJobDefinitionSummary>;
export type ListModelCardExportJobsError = CommonErrors;
/**
 * List the export jobs for the Amazon SageMaker Model Card.
 */
export declare const listModelCardExportJobs: API.PaginatedOperationMethod<ListModelCardExportJobsRequest & RegionInput, ListModelCardExportJobsResponse, ListModelCardExportJobsError, Credentials | HttpClient.HttpClient, ModelCardExportJobSummary>;
export type ListModelCardsError = CommonErrors;
/**
 * List existing model cards.
 */
export declare const listModelCards: API.PaginatedOperationMethod<ListModelCardsRequest & RegionInput, ListModelCardsResponse, ListModelCardsError, Credentials | HttpClient.HttpClient, ModelCardSummary>;
export type ListModelCardVersionsError = ResourceNotFound | CommonErrors;
/**
 * List existing versions of an Amazon SageMaker Model Card.
 */
export declare const listModelCardVersions: API.PaginatedOperationMethod<ListModelCardVersionsRequest & RegionInput, ListModelCardVersionsResponse, ListModelCardVersionsError, Credentials | HttpClient.HttpClient, ModelCardVersionSummary>;
export type ListModelExplainabilityJobDefinitionsError = CommonErrors;
/**
 * Lists model explainability job definitions that satisfy various filters.
 */
export declare const listModelExplainabilityJobDefinitions: API.PaginatedOperationMethod<ListModelExplainabilityJobDefinitionsRequest & RegionInput, ListModelExplainabilityJobDefinitionsResponse, ListModelExplainabilityJobDefinitionsError, Credentials | HttpClient.HttpClient, MonitoringJobDefinitionSummary>;
export type ListModelMetadataError = CommonErrors;
/**
 * Lists the domain, framework, task, and model name of standard machine learning models found in common model zoos.
 */
export declare const listModelMetadata: API.PaginatedOperationMethod<ListModelMetadataRequest & RegionInput, ListModelMetadataResponse, ListModelMetadataError, Credentials | HttpClient.HttpClient, ModelMetadataSummary>;
export type ListModelPackageGroupsError = CommonErrors;
/**
 * Gets a list of the model groups in your Amazon Web Services account.
 */
export declare const listModelPackageGroups: API.PaginatedOperationMethod<ListModelPackageGroupsInput & RegionInput, ListModelPackageGroupsOutput, ListModelPackageGroupsError, Credentials | HttpClient.HttpClient, ModelPackageGroupSummary>;
export type ListModelPackagesError = CommonErrors;
/**
 * Lists the model packages that have been created.
 */
export declare const listModelPackages: API.PaginatedOperationMethod<ListModelPackagesInput & RegionInput, ListModelPackagesOutput, ListModelPackagesError, Credentials | HttpClient.HttpClient, ModelPackageSummary>;
export type ListModelQualityJobDefinitionsError = CommonErrors;
/**
 * Gets a list of model quality monitoring job definitions in your account.
 */
export declare const listModelQualityJobDefinitions: API.PaginatedOperationMethod<ListModelQualityJobDefinitionsRequest & RegionInput, ListModelQualityJobDefinitionsResponse, ListModelQualityJobDefinitionsError, Credentials | HttpClient.HttpClient, MonitoringJobDefinitionSummary>;
export type ListModelsError = CommonErrors;
/**
 * Lists models created with the `CreateModel` API.
 */
export declare const listModels: API.PaginatedOperationMethod<ListModelsInput & RegionInput, ListModelsOutput, ListModelsError, Credentials | HttpClient.HttpClient, ModelSummary>;
export type ListMonitoringAlertHistoryError = ResourceNotFound | CommonErrors;
/**
 * Gets a list of past alerts in a model monitoring schedule.
 */
export declare const listMonitoringAlertHistory: API.PaginatedOperationMethod<ListMonitoringAlertHistoryRequest & RegionInput, ListMonitoringAlertHistoryResponse, ListMonitoringAlertHistoryError, Credentials | HttpClient.HttpClient, MonitoringAlertHistorySummary>;
export type ListMonitoringAlertsError = ResourceNotFound | CommonErrors;
/**
 * Gets the alerts for a single monitoring schedule.
 */
export declare const listMonitoringAlerts: API.PaginatedOperationMethod<ListMonitoringAlertsRequest & RegionInput, ListMonitoringAlertsResponse, ListMonitoringAlertsError, Credentials | HttpClient.HttpClient, MonitoringAlertSummary>;
export type ListMonitoringExecutionsError = CommonErrors;
/**
 * Returns list of all monitoring job executions.
 */
export declare const listMonitoringExecutions: API.PaginatedOperationMethod<ListMonitoringExecutionsRequest & RegionInput, ListMonitoringExecutionsResponse, ListMonitoringExecutionsError, Credentials | HttpClient.HttpClient, MonitoringExecutionSummary>;
export type ListMonitoringSchedulesError = CommonErrors;
/**
 * Returns list of all monitoring schedules.
 */
export declare const listMonitoringSchedules: API.PaginatedOperationMethod<ListMonitoringSchedulesRequest & RegionInput, ListMonitoringSchedulesResponse, ListMonitoringSchedulesError, Credentials | HttpClient.HttpClient, MonitoringScheduleSummary>;
export type ListNotebookInstanceLifecycleConfigsError = CommonErrors;
/**
 * Lists notebook instance lifestyle configurations created with the CreateNotebookInstanceLifecycleConfig API.
 */
export declare const listNotebookInstanceLifecycleConfigs: API.PaginatedOperationMethod<ListNotebookInstanceLifecycleConfigsInput & RegionInput, ListNotebookInstanceLifecycleConfigsOutput, ListNotebookInstanceLifecycleConfigsError, Credentials | HttpClient.HttpClient, NotebookInstanceLifecycleConfigSummary>;
export type ListNotebookInstancesError = CommonErrors;
/**
 * Returns a list of the SageMaker AI notebook instances in the requester's account in an Amazon Web Services Region.
 */
export declare const listNotebookInstances: API.PaginatedOperationMethod<ListNotebookInstancesInput & RegionInput, ListNotebookInstancesOutput, ListNotebookInstancesError, Credentials | HttpClient.HttpClient, NotebookInstanceSummary>;
export type ListOptimizationJobsError = CommonErrors;
/**
 * Lists the optimization jobs in your account and their properties.
 */
export declare const listOptimizationJobs: API.PaginatedOperationMethod<ListOptimizationJobsRequest & RegionInput, ListOptimizationJobsResponse, ListOptimizationJobsError, Credentials | HttpClient.HttpClient, OptimizationJobSummary>;
export type ListPartnerAppsError = CommonErrors;
/**
 * Lists all of the SageMaker Partner AI Apps in an account.
 */
export declare const listPartnerApps: API.PaginatedOperationMethod<ListPartnerAppsRequest & RegionInput, ListPartnerAppsResponse, ListPartnerAppsError, Credentials | HttpClient.HttpClient, PartnerAppSummary>;
export type ListPipelineExecutionsError = ResourceNotFound | CommonErrors;
/**
 * Gets a list of the pipeline executions.
 */
export declare const listPipelineExecutions: API.PaginatedOperationMethod<ListPipelineExecutionsRequest & RegionInput, ListPipelineExecutionsResponse, ListPipelineExecutionsError, Credentials | HttpClient.HttpClient, PipelineExecutionSummary>;
export type ListPipelineExecutionStepsError = ResourceNotFound | CommonErrors;
/**
 * Gets a list of `PipeLineExecutionStep` objects.
 */
export declare const listPipelineExecutionSteps: API.PaginatedOperationMethod<ListPipelineExecutionStepsRequest & RegionInput, ListPipelineExecutionStepsResponse, ListPipelineExecutionStepsError, Credentials | HttpClient.HttpClient, PipelineExecutionStep>;
export type ListPipelineParametersForExecutionError = ResourceNotFound | CommonErrors;
/**
 * Gets a list of parameters for a pipeline execution.
 */
export declare const listPipelineParametersForExecution: API.PaginatedOperationMethod<ListPipelineParametersForExecutionRequest & RegionInput, ListPipelineParametersForExecutionResponse, ListPipelineParametersForExecutionError, Credentials | HttpClient.HttpClient, Parameter>;
export type ListPipelinesError = CommonErrors;
/**
 * Gets a list of pipelines.
 */
export declare const listPipelines: API.PaginatedOperationMethod<ListPipelinesRequest & RegionInput, ListPipelinesResponse, ListPipelinesError, Credentials | HttpClient.HttpClient, PipelineSummary>;
export type ListPipelineVersionsError = ResourceNotFound | CommonErrors;
/**
 * Gets a list of all versions of the pipeline.
 */
export declare const listPipelineVersions: API.PaginatedOperationMethod<ListPipelineVersionsRequest & RegionInput, ListPipelineVersionsResponse, ListPipelineVersionsError, Credentials | HttpClient.HttpClient, PipelineVersionSummary>;
export type ListProcessingJobsError = CommonErrors;
/**
 * Lists processing jobs that satisfy various filters.
 */
export declare const listProcessingJobs: API.PaginatedOperationMethod<ListProcessingJobsRequest & RegionInput, ListProcessingJobsResponse, ListProcessingJobsError, Credentials | HttpClient.HttpClient, ProcessingJobSummary>;
export type ListProjectsError = CommonErrors;
/**
 * Gets a list of the projects in an Amazon Web Services account.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsInput & RegionInput, ListProjectsOutput, ListProjectsError, Credentials | HttpClient.HttpClient, ProjectSummary>;
export type ListResourceCatalogsError = CommonErrors;
/**
 * Lists Amazon SageMaker Catalogs based on given filters and orders. The maximum number of `ResourceCatalog`s viewable is 1000.
 */
export declare const listResourceCatalogs: API.PaginatedOperationMethod<ListResourceCatalogsRequest & RegionInput, ListResourceCatalogsResponse, ListResourceCatalogsError, Credentials | HttpClient.HttpClient, ResourceCatalog>;
export type ListSpacesError = CommonErrors;
/**
 * Lists spaces.
 */
export declare const listSpaces: API.PaginatedOperationMethod<ListSpacesRequest & RegionInput, ListSpacesResponse, ListSpacesError, Credentials | HttpClient.HttpClient, SpaceDetails>;
export type ListStageDevicesError = CommonErrors;
/**
 * Lists devices allocated to the stage, containing detailed device information and deployment status.
 */
export declare const listStageDevices: API.PaginatedOperationMethod<ListStageDevicesRequest & RegionInput, ListStageDevicesResponse, ListStageDevicesError, Credentials | HttpClient.HttpClient, DeviceDeploymentSummary>;
export type ListStudioLifecycleConfigsError = ResourceInUse | CommonErrors;
/**
 * Lists the Amazon SageMaker AI Studio Lifecycle Configurations in your Amazon Web Services Account.
 */
export declare const listStudioLifecycleConfigs: API.PaginatedOperationMethod<ListStudioLifecycleConfigsRequest & RegionInput, ListStudioLifecycleConfigsResponse, ListStudioLifecycleConfigsError, Credentials | HttpClient.HttpClient, StudioLifecycleConfigDetails>;
export type ListSubscribedWorkteamsError = CommonErrors;
/**
 * Gets a list of the work teams that you are subscribed to in the Amazon Web Services Marketplace. The list may be empty if no work team satisfies the filter specified in the `NameContains` parameter.
 */
export declare const listSubscribedWorkteams: API.PaginatedOperationMethod<ListSubscribedWorkteamsRequest & RegionInput, ListSubscribedWorkteamsResponse, ListSubscribedWorkteamsError, Credentials | HttpClient.HttpClient, SubscribedWorkteam>;
export type ListTagsError = CommonErrors;
/**
 * Returns the tags for the specified SageMaker resource.
 */
export declare const listTags: API.PaginatedOperationMethod<ListTagsInput & RegionInput, ListTagsOutput, ListTagsError, Credentials | HttpClient.HttpClient, Tag>;
export type ListTrainingJobsError = CommonErrors;
/**
 * Lists training jobs.
 *
 * When `StatusEquals` and `MaxResults` are set at the same time, the `MaxResults` number of training jobs are first retrieved ignoring the `StatusEquals` parameter and then they are filtered by the `StatusEquals` parameter, which is returned as a response.
 *
 * For example, if `ListTrainingJobs` is invoked with the following parameters:
 *
 * `{ ... MaxResults: 100, StatusEquals: InProgress ... }`
 *
 * First, 100 trainings jobs with any status, including those other than `InProgress`, are selected (sorted according to the creation time, from the most current to the oldest). Next, those with a status of `InProgress` are returned.
 *
 * You can quickly test the API using the following Amazon Web Services CLI code.
 *
 * `aws sagemaker list-training-jobs --max-results 100 --status-equals InProgress`
 */
export declare const listTrainingJobs: API.PaginatedOperationMethod<ListTrainingJobsRequest & RegionInput, ListTrainingJobsResponse, ListTrainingJobsError, Credentials | HttpClient.HttpClient, TrainingJobSummary>;
export type ListTrainingJobsForHyperParameterTuningJobError = ResourceNotFound | CommonErrors;
/**
 * Gets a list of TrainingJobSummary objects that describe the training jobs that a hyperparameter tuning job launched.
 */
export declare const listTrainingJobsForHyperParameterTuningJob: API.PaginatedOperationMethod<ListTrainingJobsForHyperParameterTuningJobRequest & RegionInput, ListTrainingJobsForHyperParameterTuningJobResponse, ListTrainingJobsForHyperParameterTuningJobError, Credentials | HttpClient.HttpClient, HyperParameterTrainingJobSummary>;
export type ListTrainingPlansError = CommonErrors;
/**
 * Retrieves a list of training plans for the current account.
 */
export declare const listTrainingPlans: API.PaginatedOperationMethod<ListTrainingPlansRequest & RegionInput, ListTrainingPlansResponse, ListTrainingPlansError, Credentials | HttpClient.HttpClient, TrainingPlanSummary>;
export type ListTrainingSessionsError = CommonErrors;
/**
 * Lists training sessions in your account. You can filter results by creation time, name, and status. The operation paginates results. To retrieve additional results, use the `NextToken` parameter.
 *
 * The following operations are related to `ListTrainingSessions`:
 *
 * - `CreateTrainingSession`
 *
 * - `DescribeTrainingSession`
 */
export declare const listTrainingSessions: API.PaginatedOperationMethod<ListTrainingSessionsRequest & RegionInput, ListTrainingSessionsResponse, ListTrainingSessionsError, Credentials | HttpClient.HttpClient, TrainingSessionSummary>;
export type ListTransformJobsError = CommonErrors;
/**
 * Lists transform jobs.
 */
export declare const listTransformJobs: API.PaginatedOperationMethod<ListTransformJobsRequest & RegionInput, ListTransformJobsResponse, ListTransformJobsError, Credentials | HttpClient.HttpClient, TransformJobSummary>;
export type ListTrialComponentsError = ResourceNotFound | CommonErrors;
/**
 * Lists the trial components in your account. You can sort the list by trial component name or creation time. You can filter the list to show only components that were created in a specific time range. You can also filter on one of the following:
 *
 * - `ExperimentName`
 *
 * - `SourceArn`
 *
 * - `TrialName`
 */
export declare const listTrialComponents: API.PaginatedOperationMethod<ListTrialComponentsRequest & RegionInput, ListTrialComponentsResponse, ListTrialComponentsError, Credentials | HttpClient.HttpClient, TrialComponentSummary>;
export type ListTrialsError = ResourceNotFound | CommonErrors;
/**
 * Lists the trials in your account. Specify an experiment name to limit the list to the trials that are part of that experiment. Specify a trial component name to limit the list to the trials that associated with that trial component. The list can be filtered to show only trials that were created in a specific time range. The list can be sorted by trial name or creation time.
 */
export declare const listTrials: API.PaginatedOperationMethod<ListTrialsRequest & RegionInput, ListTrialsResponse, ListTrialsError, Credentials | HttpClient.HttpClient, TrialSummary>;
export type ListUltraServersByReservedCapacityError = ResourceNotFound | CommonErrors;
/**
 * Lists all UltraServers that are part of a specified reserved capacity.
 */
export declare const listUltraServersByReservedCapacity: API.PaginatedOperationMethod<ListUltraServersByReservedCapacityRequest & RegionInput, ListUltraServersByReservedCapacityResponse, ListUltraServersByReservedCapacityError, Credentials | HttpClient.HttpClient, UltraServer>;
export type ListUserProfilesError = CommonErrors;
/**
 * Lists user profiles.
 */
export declare const listUserProfiles: API.PaginatedOperationMethod<ListUserProfilesRequest & RegionInput, ListUserProfilesResponse, ListUserProfilesError, Credentials | HttpClient.HttpClient, UserProfileDetails>;
export type ListWorkforcesError = CommonErrors;
/**
 * Use this operation to list all private and vendor workforces in an Amazon Web Services Region. Note that you can only have one private workforce per Amazon Web Services Region.
 */
export declare const listWorkforces: API.PaginatedOperationMethod<ListWorkforcesRequest & RegionInput, ListWorkforcesResponse, ListWorkforcesError, Credentials | HttpClient.HttpClient, Workforce>;
export type ListWorkteamsError = CommonErrors;
/**
 * Gets a list of private work teams that you have defined in a region. The list may be empty if no work team satisfies the filter specified in the `NameContains` parameter.
 */
export declare const listWorkteams: API.PaginatedOperationMethod<ListWorkteamsRequest & RegionInput, ListWorkteamsResponse, ListWorkteamsError, Credentials | HttpClient.HttpClient, Workteam>;
export type PutModelPackageGroupPolicyError = ConflictException | CommonErrors;
/**
 * Adds a resouce policy to control access to a model group. For information about resoure policies, see Identity-based policies and resource-based policies in the *Amazon Web Services Identity and Access Management User Guide.*.
 */
export declare const putModelPackageGroupPolicy: API.OperationMethod<PutModelPackageGroupPolicyInput & RegionInput, PutModelPackageGroupPolicyOutput, PutModelPackageGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type QueryLineageError = ResourceNotFound | CommonErrors;
/**
 * Use this action to inspect your lineage and discover relationships between entities. For more information, see Querying Lineage Entities in the *Amazon SageMaker Developer Guide*.
 */
export declare const queryLineage: API.PaginatedOperationMethod<QueryLineageRequest & RegionInput, QueryLineageResponse, QueryLineageError, Credentials | HttpClient.HttpClient, unknown>;
export type RegisterDevicesError = ResourceLimitExceeded | CommonErrors;
/**
 * Register devices.
 */
export declare const registerDevices: API.OperationMethod<RegisterDevicesRequest & RegionInput, RegisterDevicesResponse, RegisterDevicesError, Credentials | HttpClient.HttpClient>;
export type RenderUiTemplateError = ResourceNotFound | CommonErrors;
/**
 * Renders the UI template so that you can preview the worker's experience.
 */
export declare const renderUiTemplate: API.OperationMethod<RenderUiTemplateRequest & RegionInput, RenderUiTemplateResponse, RenderUiTemplateError, Credentials | HttpClient.HttpClient>;
export type RetryPipelineExecutionError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Retry the execution of the pipeline.
 */
export declare const retryPipelineExecution: API.OperationMethod<RetryPipelineExecutionRequest & RegionInput, RetryPipelineExecutionResponse, RetryPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type SearchError = CommonErrors;
/**
 * Finds SageMaker resources that match a search query. Matching resources are returned as a list of `SearchRecord` objects in the response. You can sort the search results by any resource property in a ascending or descending order.
 *
 * You can query against the following value types: numeric, text, Boolean, and timestamp.
 *
 * The Search API may provide access to otherwise restricted data. See Amazon SageMaker API Permissions: Actions, Permissions, and Resources Reference for more information.
 */
export declare const search: API.PaginatedOperationMethod<SearchRequest & RegionInput, SearchResponse, SearchError, Credentials | HttpClient.HttpClient, SearchRecord>;
export type SearchTrainingPlanOfferingsError = ResourceLimitExceeded | CommonErrors;
/**
 * Searches for available training plan offerings based on specified criteria.
 *
 * - Users search for available plan offerings based on their requirements (e.g., instance type, count, start time, duration).
 *
 * - And then, they create a plan that best matches their needs using the ID of the plan offering they want to use.
 *
 * For more information about how to reserve GPU capacity for your SageMaker training jobs or SageMaker HyperPod clusters using Amazon SageMaker Training Plan , see ` CreateTrainingPlan `.
 */
export declare const searchTrainingPlanOfferings: API.OperationMethod<SearchTrainingPlanOfferingsRequest & RegionInput, SearchTrainingPlanOfferingsResponse, SearchTrainingPlanOfferingsError, Credentials | HttpClient.HttpClient>;
export type SendPipelineExecutionStepFailureError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Notifies the pipeline that the execution of a callback step failed, along with a message describing why. When a callback step is run, the pipeline generates a callback token and includes the token in a message sent to Amazon Simple Queue Service (Amazon SQS).
 */
export declare const sendPipelineExecutionStepFailure: API.OperationMethod<SendPipelineExecutionStepFailureRequest & RegionInput, SendPipelineExecutionStepFailureResponse, SendPipelineExecutionStepFailureError, Credentials | HttpClient.HttpClient>;
export type SendPipelineExecutionStepSuccessError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Notifies the pipeline that the execution of a callback step succeeded and provides a list of the step's output parameters. When a callback step is run, the pipeline generates a callback token and includes the token in a message sent to Amazon Simple Queue Service (Amazon SQS).
 */
export declare const sendPipelineExecutionStepSuccess: API.OperationMethod<SendPipelineExecutionStepSuccessRequest & RegionInput, SendPipelineExecutionStepSuccessResponse, SendPipelineExecutionStepSuccessError, Credentials | HttpClient.HttpClient>;
export type StartClusterHealthCheckError = ResourceNotFound | CommonErrors;
/**
 * Start deep health checks for a SageMaker HyperPod cluster. You can use DescribeClusterNode API to track progress of the deep health checks. The unhealthy nodes will be automatically rebooted or replaced. Please see Resilience-related Kubernetes labels by SageMaker HyperPod for details.
 */
export declare const startClusterHealthCheck: API.OperationMethod<StartClusterHealthCheckRequest & RegionInput, StartClusterHealthCheckResponse, StartClusterHealthCheckError, Credentials | HttpClient.HttpClient>;
export type StartEdgeDeploymentStageError = CommonErrors;
/**
 * Starts a stage in an edge deployment plan.
 */
export declare const startEdgeDeploymentStage: API.OperationMethod<StartEdgeDeploymentStageRequest & RegionInput, StartEdgeDeploymentStageResponse, StartEdgeDeploymentStageError, Credentials | HttpClient.HttpClient>;
export type StartInferenceExperimentError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Starts an inference experiment.
 */
export declare const startInferenceExperiment: API.OperationMethod<StartInferenceExperimentRequest & RegionInput, StartInferenceExperimentResponse, StartInferenceExperimentError, Credentials | HttpClient.HttpClient>;
export type StartMlflowTrackingServerError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Programmatically start an MLflow Tracking Server.
 */
export declare const startMlflowTrackingServer: API.OperationMethod<StartMlflowTrackingServerRequest & RegionInput, StartMlflowTrackingServerResponse, StartMlflowTrackingServerError, Credentials | HttpClient.HttpClient>;
export type StartMonitoringScheduleError = ResourceNotFound | CommonErrors;
/**
 * Starts a previously stopped monitoring schedule.
 *
 * By default, when you successfully create a new schedule, the status of a monitoring schedule is `scheduled`.
 */
export declare const startMonitoringSchedule: API.OperationMethod<StartMonitoringScheduleRequest & RegionInput, StartMonitoringScheduleResponse, StartMonitoringScheduleError, Credentials | HttpClient.HttpClient>;
export type StartNotebookInstanceError = ResourceLimitExceeded | CommonErrors;
/**
 * Launches an ML compute instance with the latest version of the libraries and attaches your ML storage volume. After configuring the notebook instance, SageMaker AI sets the notebook instance status to `InService`. A notebook instance's status must be `InService` before you can connect to your Jupyter notebook.
 */
export declare const startNotebookInstance: API.OperationMethod<StartNotebookInstanceInput & RegionInput, StartNotebookInstanceResponse, StartNotebookInstanceError, Credentials | HttpClient.HttpClient>;
export type StartPipelineExecutionError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Starts a pipeline execution.
 */
export declare const startPipelineExecution: API.OperationMethod<StartPipelineExecutionRequest & RegionInput, StartPipelineExecutionResponse, StartPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StartSessionError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Initiates a remote connection session between a local integrated development environments (IDEs) and a remote SageMaker space.
 */
export declare const startSession: API.OperationMethod<StartSessionRequest & RegionInput, StartSessionResponse, StartSessionError, Credentials | HttpClient.HttpClient>;
export type StopAIBenchmarkJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a running AI benchmark job.
 */
export declare const stopAIBenchmarkJob: API.OperationMethod<StopAIBenchmarkJobRequest & RegionInput, StopAIBenchmarkJobResponse, StopAIBenchmarkJobError, Credentials | HttpClient.HttpClient>;
export type StopAIRecommendationJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a running AI recommendation job.
 */
export declare const stopAIRecommendationJob: API.OperationMethod<StopAIRecommendationJobRequest & RegionInput, StopAIRecommendationJobResponse, StopAIRecommendationJobError, Credentials | HttpClient.HttpClient>;
export type StopAutoMLJobError = ResourceNotFound | CommonErrors;
/**
 * A method for forcing a running job to shut down.
 */
export declare const stopAutoMLJob: API.OperationMethod<StopAutoMLJobRequest & RegionInput, StopAutoMLJobResponse, StopAutoMLJobError, Credentials | HttpClient.HttpClient>;
export type StopCompilationJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a model compilation job.
 *
 * To stop a job, Amazon SageMaker AI sends the algorithm the SIGTERM signal. This gracefully shuts the job down. If the job hasn't stopped, it sends the SIGKILL signal.
 *
 * When it receives a `StopCompilationJob` request, Amazon SageMaker AI changes the `CompilationJobStatus` of the job to `Stopping`. After Amazon SageMaker stops the job, it sets the `CompilationJobStatus` to `Stopped`.
 */
export declare const stopCompilationJob: API.OperationMethod<StopCompilationJobRequest & RegionInput, StopCompilationJobResponse, StopCompilationJobError, Credentials | HttpClient.HttpClient>;
export type StopEdgeDeploymentStageError = CommonErrors;
/**
 * Stops a stage in an edge deployment plan.
 */
export declare const stopEdgeDeploymentStage: API.OperationMethod<StopEdgeDeploymentStageRequest & RegionInput, StopEdgeDeploymentStageResponse, StopEdgeDeploymentStageError, Credentials | HttpClient.HttpClient>;
export type StopEdgePackagingJobError = CommonErrors;
/**
 * Request to stop an edge packaging job.
 */
export declare const stopEdgePackagingJob: API.OperationMethod<StopEdgePackagingJobRequest & RegionInput, StopEdgePackagingJobResponse, StopEdgePackagingJobError, Credentials | HttpClient.HttpClient>;
export type StopHyperParameterTuningJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a running hyperparameter tuning job and all running training jobs that the tuning job launched.
 *
 * All model artifacts output from the training jobs are stored in Amazon Simple Storage Service (Amazon S3). All data that the training jobs write to Amazon CloudWatch Logs are still available in CloudWatch. After the tuning job moves to the `Stopped` state, it releases all reserved resources for the tuning job.
 */
export declare const stopHyperParameterTuningJob: API.OperationMethod<StopHyperParameterTuningJobRequest & RegionInput, StopHyperParameterTuningJobResponse, StopHyperParameterTuningJobError, Credentials | HttpClient.HttpClient>;
export type StopInferenceExperimentError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Stops an inference experiment.
 */
export declare const stopInferenceExperiment: API.OperationMethod<StopInferenceExperimentRequest & RegionInput, StopInferenceExperimentResponse, StopInferenceExperimentError, Credentials | HttpClient.HttpClient>;
export type StopInferenceRecommendationsJobError = ResourceNotFound | CommonErrors;
/**
 * Stops an Inference Recommender job.
 */
export declare const stopInferenceRecommendationsJob: API.OperationMethod<StopInferenceRecommendationsJobRequest & RegionInput, StopInferenceRecommendationsJobResponse, StopInferenceRecommendationsJobError, Credentials | HttpClient.HttpClient>;
export type StopJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a running job. When you call `StopJob`, Amazon SageMaker sets the job status to `Stopping`. After the job stops, the status changes to `Stopped`. Partial results may be available in the output location if the job was in progress. To delete a stopped job, call `DeleteJob`.
 *
 * The following operations are related to `StopJob`:
 *
 * - `CreateJob`
 *
 * - `DescribeJob`
 *
 * - `DeleteJob`
 */
export declare const stopJob: API.OperationMethod<StopJobRequest & RegionInput, StopJobResponse, StopJobError, Credentials | HttpClient.HttpClient>;
export type StopLabelingJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a running labeling job. A job that is stopped cannot be restarted. Any results obtained before the job is stopped are placed in the Amazon S3 output bucket.
 */
export declare const stopLabelingJob: API.OperationMethod<StopLabelingJobRequest & RegionInput, StopLabelingJobResponse, StopLabelingJobError, Credentials | HttpClient.HttpClient>;
export type StopMlflowTrackingServerError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Programmatically stop an MLflow Tracking Server.
 */
export declare const stopMlflowTrackingServer: API.OperationMethod<StopMlflowTrackingServerRequest & RegionInput, StopMlflowTrackingServerResponse, StopMlflowTrackingServerError, Credentials | HttpClient.HttpClient>;
export type StopMonitoringScheduleError = ResourceNotFound | CommonErrors;
/**
 * Stops a previously started monitoring schedule.
 */
export declare const stopMonitoringSchedule: API.OperationMethod<StopMonitoringScheduleRequest & RegionInput, StopMonitoringScheduleResponse, StopMonitoringScheduleError, Credentials | HttpClient.HttpClient>;
export type StopNotebookInstanceError = CommonErrors;
/**
 * Terminates the ML compute instance. Before terminating the instance, SageMaker AI disconnects the ML storage volume from it. SageMaker AI preserves the ML storage volume. SageMaker AI stops charging you for the ML compute instance when you call `StopNotebookInstance`.
 *
 * To access data on the ML storage volume for a notebook instance that has been terminated, call the `StartNotebookInstance` API. `StartNotebookInstance` launches another ML compute instance, configures it, and attaches the preserved ML storage volume so you can continue your work.
 */
export declare const stopNotebookInstance: API.OperationMethod<StopNotebookInstanceInput & RegionInput, StopNotebookInstanceResponse, StopNotebookInstanceError, Credentials | HttpClient.HttpClient>;
export type StopOptimizationJobError = ResourceNotFound | CommonErrors;
/**
 * Ends a running inference optimization job.
 */
export declare const stopOptimizationJob: API.OperationMethod<StopOptimizationJobRequest & RegionInput, StopOptimizationJobResponse, StopOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type StopPipelineExecutionError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Stops a pipeline execution.
 *
 * **Callback Step**
 *
 * A pipeline execution won't stop while a callback step is running. When you call `StopPipelineExecution` on a pipeline execution with a running callback step, SageMaker Pipelines sends an additional Amazon SQS message to the specified SQS queue. The body of the SQS message contains a "Status" field which is set to "Stopping".
 *
 * You should add logic to your Amazon SQS message consumer to take any needed action (for example, resource cleanup) upon receipt of the message followed by a call to `SendPipelineExecutionStepSuccess` or `SendPipelineExecutionStepFailure`.
 *
 * Only when SageMaker Pipelines receives one of these calls will it stop the pipeline execution.
 *
 * **Lambda Step**
 *
 * A pipeline execution can't be stopped while a lambda step is running because the Lambda function invoked by the lambda step can't be stopped. If you attempt to stop the execution while the Lambda function is running, the pipeline waits for the Lambda function to finish or until the timeout is hit, whichever occurs first, and then stops. If the Lambda function finishes, the pipeline execution status is `Stopped`. If the timeout is hit the pipeline execution status is `Failed`.
 */
export declare const stopPipelineExecution: API.OperationMethod<StopPipelineExecutionRequest & RegionInput, StopPipelineExecutionResponse, StopPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StopProcessingJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a processing job.
 */
export declare const stopProcessingJob: API.OperationMethod<StopProcessingJobRequest & RegionInput, StopProcessingJobResponse, StopProcessingJobError, Credentials | HttpClient.HttpClient>;
export type StopTrainingJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a training job. To stop a job, SageMaker sends the algorithm the `SIGTERM` signal, which delays job termination for 120 seconds. Algorithms might use this 120-second window to save the model artifacts, so the results of the training is not lost.
 *
 * When it receives a `StopTrainingJob` request, SageMaker changes the status of the job to `Stopping`. After SageMaker stops the job, it sets the status to `Stopped`.
 */
export declare const stopTrainingJob: API.OperationMethod<StopTrainingJobRequest & RegionInput, StopTrainingJobResponse, StopTrainingJobError, Credentials | HttpClient.HttpClient>;
export type StopTrainingSessionError = ResourceNotFound | CommonErrors;
/**
 * Stops a running training session and sets the session status to `Stopping`. After the session stops, the status changes to `Stopped`. To delete a stopped session, use the `DeleteTrainingSession` operation.
 *
 * The following operations are related to `StopTrainingSession`:
 *
 * - `CreateTrainingSession`
 *
 * - `DescribeTrainingSession`
 *
 * - `DeleteTrainingSession`
 */
export declare const stopTrainingSession: API.OperationMethod<StopTrainingSessionRequest & RegionInput, StopTrainingSessionResponse, StopTrainingSessionError, Credentials | HttpClient.HttpClient>;
export type StopTransformJobError = ResourceNotFound | CommonErrors;
/**
 * Stops a batch transform job.
 *
 * When Amazon SageMaker receives a `StopTransformJob` request, the status of the job changes to `Stopping`. After Amazon SageMaker stops the job, the status is set to `Stopped`. When you stop a batch transform job before it is completed, Amazon SageMaker doesn't store the job's output in Amazon S3.
 */
export declare const stopTransformJob: API.OperationMethod<StopTransformJobRequest & RegionInput, StopTransformJobResponse, StopTransformJobError, Credentials | HttpClient.HttpClient>;
export type UpdateActionError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates an action.
 */
export declare const updateAction: API.OperationMethod<UpdateActionRequest & RegionInput, UpdateActionResponse, UpdateActionError, Credentials | HttpClient.HttpClient>;
export type UpdateAppImageConfigError = ResourceNotFound | CommonErrors;
/**
 * Updates the properties of an AppImageConfig.
 */
export declare const updateAppImageConfig: API.OperationMethod<UpdateAppImageConfigRequest & RegionInput, UpdateAppImageConfigResponse, UpdateAppImageConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateArtifactError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates an artifact.
 */
export declare const updateArtifact: API.OperationMethod<UpdateArtifactRequest & RegionInput, UpdateArtifactResponse, UpdateArtifactError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Updates a SageMaker HyperPod cluster.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest & RegionInput, UpdateClusterResponse, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterExtensionError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates the configuration or the version of an extension installed on a SageMaker HyperPod cluster. SageMaker HyperPod applies the change to every node in the cluster. You can change the configuration, the version, or both in one request.
 *
 * - **Configuration:** You can change settings by sending `ConfigurationValues`. Settings that you include are changed. Settings that you omit keep their current values. A setting with the value `null` is removed and returns to its default value.
 *
 * - **Version:** You can update to a later version. You can't update to an earlier version. To use an earlier version, delete the extension and create it again with that version.
 *
 * To retry the operation on nodes where it failed, fix the cause that `DescribeClusterExtension` reports in `Health`, and then send an `UpdateClusterExtension` request that doesn't change the version or the configuration.
 *
 * You can't update an extension while it is being deleted.
 */
export declare const updateClusterExtension: API.OperationMethod<UpdateClusterExtensionRequest & RegionInput, UpdateClusterExtensionResponse, UpdateClusterExtensionError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterSchedulerConfigError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Update the cluster policy configuration.
 */
export declare const updateClusterSchedulerConfig: API.OperationMethod<UpdateClusterSchedulerConfigRequest & RegionInput, UpdateClusterSchedulerConfigResponse, UpdateClusterSchedulerConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterSoftwareError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates the platform software of a SageMaker HyperPod cluster for security patching. To learn how to use this API, see Update the SageMaker HyperPod platform software of a cluster.
 *
 * The `UpgradeClusterSoftware` API call may impact your SageMaker HyperPod cluster uptime and availability. Plan accordingly to mitigate potential disruptions to your workloads.
 */
export declare const updateClusterSoftware: API.OperationMethod<UpdateClusterSoftwareRequest & RegionInput, UpdateClusterSoftwareResponse, UpdateClusterSoftwareError, Credentials | HttpClient.HttpClient>;
export type UpdateCodeRepositoryError = ConflictException | CommonErrors;
/**
 * Updates the specified Git repository with the specified values.
 */
export declare const updateCodeRepository: API.OperationMethod<UpdateCodeRepositoryInput & RegionInput, UpdateCodeRepositoryOutput, UpdateCodeRepositoryError, Credentials | HttpClient.HttpClient>;
export type UpdateComputeQuotaError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Update the compute allocation definition.
 */
export declare const updateComputeQuota: API.OperationMethod<UpdateComputeQuotaRequest & RegionInput, UpdateComputeQuotaResponse, UpdateComputeQuotaError, Credentials | HttpClient.HttpClient>;
export type UpdateContextError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates a context.
 */
export declare const updateContext: API.OperationMethod<UpdateContextRequest & RegionInput, UpdateContextResponse, UpdateContextError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceFleetError = ResourceInUse | CommonErrors;
/**
 * Updates a fleet of devices.
 */
export declare const updateDeviceFleet: API.OperationMethod<UpdateDeviceFleetRequest & RegionInput, UpdateDeviceFleetResponse, UpdateDeviceFleetError, Credentials | HttpClient.HttpClient>;
export type UpdateDevicesError = CommonErrors;
/**
 * Updates one or more devices in a fleet.
 */
export declare const updateDevices: API.OperationMethod<UpdateDevicesRequest & RegionInput, UpdateDevicesResponse, UpdateDevicesError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Updates the default settings for new user profiles in the domain.
 */
export declare const updateDomain: API.OperationMethod<UpdateDomainRequest & RegionInput, UpdateDomainResponse, UpdateDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointError = ResourceLimitExceeded | EndpointConfigNotFound | EndpointNotFound | CommonErrors;
/**
 * Deploys the `EndpointConfig` specified in the request to a new fleet of instances. SageMaker shifts endpoint traffic to the new instances with the updated endpoint configuration and then deletes the old instances using the previous `EndpointConfig` (there is no availability loss). For more information about how to control the update and traffic shifting process, see Update models in production.
 *
 * When SageMaker receives the request, it sets the endpoint status to `Updating`. After updating the endpoint, it sets the status to `InService`. To check the status of an endpoint, use the DescribeEndpoint API.
 *
 * You must not delete an `EndpointConfig` in use by an endpoint that is live or while the `UpdateEndpoint` or `CreateEndpoint` operations are being performed on the endpoint. To update an endpoint, you must create a new `EndpointConfig`.
 *
 * If you delete the `EndpointConfig` of an endpoint that is active or being created or updated you may lose visibility into the instance type the endpoint is using. The endpoint must be deleted in order to stop incurring charges.
 */
export declare const updateEndpoint: API.OperationMethod<UpdateEndpointInput & RegionInput, UpdateEndpointOutput, UpdateEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointWeightsAndCapacitiesError = ResourceLimitExceeded | CommonErrors;
/**
 * Updates variant weight of one or more variants associated with an existing endpoint, or capacity of one variant associated with an existing endpoint. When it receives the request, SageMaker sets the endpoint status to `Updating`. After updating the endpoint, it sets the status to `InService`. To check the status of an endpoint, use the DescribeEndpoint API.
 */
export declare const updateEndpointWeightsAndCapacities: API.OperationMethod<UpdateEndpointWeightsAndCapacitiesInput & RegionInput, UpdateEndpointWeightsAndCapacitiesOutput, UpdateEndpointWeightsAndCapacitiesError, Credentials | HttpClient.HttpClient>;
export type UpdateExperimentError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Adds, updates, or removes the description of an experiment. Updates the display name of an experiment.
 */
export declare const updateExperiment: API.OperationMethod<UpdateExperimentRequest & RegionInput, UpdateExperimentResponse, UpdateExperimentError, Credentials | HttpClient.HttpClient>;
export type UpdateFeatureGroupError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Updates the feature group by either adding features or updating the online store configuration. Use one of the following request parameters at a time while using the `UpdateFeatureGroup` API.
 *
 * You can add features for your feature group using the `FeatureAdditions` request parameter. Features cannot be removed from a feature group.
 *
 * You can update the online store configuration by using the `OnlineStoreConfig` request parameter. If a `TtlDuration` is specified, the default `TtlDuration` applies for all records added to the feature group *after the feature group is updated*. If a record level `TtlDuration` exists from using the `PutRecord` API, the record level `TtlDuration` applies to that record instead of the default `TtlDuration`. To remove the default `TtlDuration` from an existing feature group, use the `UpdateFeatureGroup` API and set the `TtlDuration` `Unit` and `Value` to `null`.
 */
export declare const updateFeatureGroup: API.OperationMethod<UpdateFeatureGroupRequest & RegionInput, UpdateFeatureGroupResponse, UpdateFeatureGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateFeatureMetadataError = ResourceNotFound | CommonErrors;
/**
 * Updates the description and parameters of the feature group.
 */
export declare const updateFeatureMetadata: API.OperationMethod<UpdateFeatureMetadataRequest & RegionInput, UpdateFeatureMetadataResponse, UpdateFeatureMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdateHubError = ResourceNotFound | CommonErrors;
/**
 * Update a hub.
 */
export declare const updateHub: API.OperationMethod<UpdateHubRequest & RegionInput, UpdateHubResponse, UpdateHubError, Credentials | HttpClient.HttpClient>;
export type UpdateHubContentError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Updates SageMaker hub content (either a `Model` or `Notebook` resource).
 *
 * You can update the metadata that describes the resource. In addition to the required request fields, specify at least one of the following fields to update:
 *
 * - `HubContentDescription`
 *
 * - `HubContentDisplayName`
 *
 * - `HubContentMarkdown`
 *
 * - `HubContentSearchKeywords`
 *
 * - `SupportStatus`
 *
 * For more information about hubs, see Private curated hubs for foundation model access control in JumpStart.
 *
 * If you want to update a `ModelReference` resource in your hub, use the `UpdateHubContentResource` API instead.
 */
export declare const updateHubContent: API.OperationMethod<UpdateHubContentRequest & RegionInput, UpdateHubContentResponse, UpdateHubContentError, Credentials | HttpClient.HttpClient>;
export type UpdateHubContentReferenceError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Updates the contents of a SageMaker hub for a `ModelReference` resource. A `ModelReference` allows you to access public SageMaker JumpStart models from within your private hub.
 *
 * When using this API, you can update the `MinVersion` field for additional flexibility in the model version. You shouldn't update any additional fields when using this API, because the metadata in your private hub should match the public JumpStart model's metadata.
 *
 * If you want to update a `Model` or `Notebook` resource in your hub, use the `UpdateHubContent` API instead.
 *
 * For more information about adding model references to your hub, see Add models to a private hub.
 */
export declare const updateHubContentReference: API.OperationMethod<UpdateHubContentReferenceRequest & RegionInput, UpdateHubContentReferenceResponse, UpdateHubContentReferenceError, Credentials | HttpClient.HttpClient>;
export type UpdateImageError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Updates the properties of a SageMaker AI image. To change the image's tags, use the AddTags and DeleteTags APIs.
 */
export declare const updateImage: API.OperationMethod<UpdateImageRequest & RegionInput, UpdateImageResponse, UpdateImageError, Credentials | HttpClient.HttpClient>;
export type UpdateImageVersionError = ResourceInUse | ResourceNotFound | CommonErrors;
/**
 * Updates the properties of a SageMaker AI image version.
 */
export declare const updateImageVersion: API.OperationMethod<UpdateImageVersionRequest & RegionInput, UpdateImageVersionResponse, UpdateImageVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateInferenceComponentError = ResourceLimitExceeded | CommonErrors;
/**
 * Updates an inference component.
 */
export declare const updateInferenceComponent: API.OperationMethod<UpdateInferenceComponentInput & RegionInput, UpdateInferenceComponentOutput, UpdateInferenceComponentError, Credentials | HttpClient.HttpClient>;
export type UpdateInferenceComponentRuntimeConfigError = ResourceLimitExceeded | CommonErrors;
/**
 * Runtime settings for a model that is deployed with an inference component.
 */
export declare const updateInferenceComponentRuntimeConfig: API.OperationMethod<UpdateInferenceComponentRuntimeConfigInput & RegionInput, UpdateInferenceComponentRuntimeConfigOutput, UpdateInferenceComponentRuntimeConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateInferenceExperimentError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates an inference experiment that you created. The status of the inference experiment has to be either `Created`, `Running`. For more information on the status of an inference experiment, see DescribeInferenceExperiment.
 */
export declare const updateInferenceExperiment: API.OperationMethod<UpdateInferenceExperimentRequest & RegionInput, UpdateInferenceExperimentResponse, UpdateInferenceExperimentError, Credentials | HttpClient.HttpClient>;
export type UpdateMlflowAppError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates an MLflow App.
 */
export declare const updateMlflowApp: API.OperationMethod<UpdateMlflowAppRequest & RegionInput, UpdateMlflowAppResponse, UpdateMlflowAppError, Credentials | HttpClient.HttpClient>;
export type UpdateMlflowTrackingServerError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Updates properties of an existing MLflow Tracking Server.
 */
export declare const updateMlflowTrackingServer: API.OperationMethod<UpdateMlflowTrackingServerRequest & RegionInput, UpdateMlflowTrackingServerResponse, UpdateMlflowTrackingServerError, Credentials | HttpClient.HttpClient>;
export type UpdateModelCardError = ConflictException | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Update an Amazon SageMaker Model Card.
 *
 * You cannot update both model card content and model card status in a single call.
 */
export declare const updateModelCard: API.OperationMethod<UpdateModelCardRequest & RegionInput, UpdateModelCardResponse, UpdateModelCardError, Credentials | HttpClient.HttpClient>;
export type UpdateModelPackageError = ConflictException | CommonErrors;
/**
 * Updates a versioned model.
 */
export declare const updateModelPackage: API.OperationMethod<UpdateModelPackageInput & RegionInput, UpdateModelPackageOutput, UpdateModelPackageError, Credentials | HttpClient.HttpClient>;
export type UpdateMonitoringAlertError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Update the parameters of a model monitor alert.
 */
export declare const updateMonitoringAlert: API.OperationMethod<UpdateMonitoringAlertRequest & RegionInput, UpdateMonitoringAlertResponse, UpdateMonitoringAlertError, Credentials | HttpClient.HttpClient>;
export type UpdateMonitoringScheduleError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Updates a previously created schedule.
 */
export declare const updateMonitoringSchedule: API.OperationMethod<UpdateMonitoringScheduleRequest & RegionInput, UpdateMonitoringScheduleResponse, UpdateMonitoringScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateNotebookInstanceError = ResourceLimitExceeded | CommonErrors;
/**
 * Updates a notebook instance. NotebookInstance updates include upgrading or downgrading the ML compute instance used for your notebook instance to accommodate changes in your workload requirements.
 *
 * This API can attach lifecycle configurations to notebook instances. Lifecycle configuration scripts execute with root access and the notebook instance's IAM execution role privileges. Principals with this permission and access to lifecycle configurations can execute code with the execution role's credentials. See Customize a Notebook Instance Using a Lifecycle Configuration Script for security best practices.
 */
export declare const updateNotebookInstance: API.OperationMethod<UpdateNotebookInstanceInput & RegionInput, UpdateNotebookInstanceOutput, UpdateNotebookInstanceError, Credentials | HttpClient.HttpClient>;
export type UpdateNotebookInstanceLifecycleConfigError = ResourceLimitExceeded | CommonErrors;
/**
 * Updates a notebook instance lifecycle configuration created with the CreateNotebookInstanceLifecycleConfig API.
 *
 * Updates to lifecycle configurations affect all notebook instances using that configuration upon their next start. Lifecycle configuration scripts execute with root access and the notebook instance's IAM execution role privileges. Grant this permission only to trusted principals. See Customize a Notebook Instance Using a Lifecycle Configuration Script for security best practices.
 */
export declare const updateNotebookInstanceLifecycleConfig: API.OperationMethod<UpdateNotebookInstanceLifecycleConfigInput & RegionInput, UpdateNotebookInstanceLifecycleConfigOutput, UpdateNotebookInstanceLifecycleConfigError, Credentials | HttpClient.HttpClient>;
export type UpdatePartnerAppError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates all of the SageMaker Partner AI Apps in an account.
 */
export declare const updatePartnerApp: API.OperationMethod<UpdatePartnerAppRequest & RegionInput, UpdatePartnerAppResponse, UpdatePartnerAppError, Credentials | HttpClient.HttpClient>;
export type UpdatePipelineError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates a pipeline.
 */
export declare const updatePipeline: API.OperationMethod<UpdatePipelineRequest & RegionInput, UpdatePipelineResponse, UpdatePipelineError, Credentials | HttpClient.HttpClient>;
export type UpdatePipelineExecutionError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates a pipeline execution.
 */
export declare const updatePipelineExecution: API.OperationMethod<UpdatePipelineExecutionRequest & RegionInput, UpdatePipelineExecutionResponse, UpdatePipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type UpdatePipelineVersionError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates a pipeline version.
 */
export declare const updatePipelineVersion: API.OperationMethod<UpdatePipelineVersionRequest & RegionInput, UpdatePipelineVersionResponse, UpdatePipelineVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = ConflictException | CommonErrors;
/**
 * Updates a machine learning (ML) project that is created from a template that sets up an ML pipeline from training to deploying an approved model.
 *
 * You must not update a project that is in use. If you update the `ServiceCatalogProvisioningUpdateDetails` of a project that is active or being created, or updated, you may lose resources already created by the project.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectInput & RegionInput, UpdateProjectOutput, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateSpaceError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Updates the settings of a space.
 *
 * You can't edit the app type of a space in the `SpaceSettings`.
 */
export declare const updateSpace: API.OperationMethod<UpdateSpaceRequest & RegionInput, UpdateSpaceResponse, UpdateSpaceError, Credentials | HttpClient.HttpClient>;
export type UpdateTrainingJobError = ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Update a model training job to request a new Debugger profiling configuration or to change warm pool retention length.
 */
export declare const updateTrainingJob: API.OperationMethod<UpdateTrainingJobRequest & RegionInput, UpdateTrainingJobResponse, UpdateTrainingJobError, Credentials | HttpClient.HttpClient>;
export type UpdateTrialError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates the display name of a trial.
 */
export declare const updateTrial: API.OperationMethod<UpdateTrialRequest & RegionInput, UpdateTrialResponse, UpdateTrialError, Credentials | HttpClient.HttpClient>;
export type UpdateTrialComponentError = ConflictException | ResourceNotFound | CommonErrors;
/**
 * Updates one or more properties of a trial component.
 */
export declare const updateTrialComponent: API.OperationMethod<UpdateTrialComponentRequest & RegionInput, UpdateTrialComponentResponse, UpdateTrialComponentError, Credentials | HttpClient.HttpClient>;
export type UpdateUserProfileError = ResourceInUse | ResourceLimitExceeded | ResourceNotFound | CommonErrors;
/**
 * Updates a user profile.
 */
export declare const updateUserProfile: API.OperationMethod<UpdateUserProfileRequest & RegionInput, UpdateUserProfileResponse, UpdateUserProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkforceError = ConflictException | CommonErrors;
/**
 * Use this operation to update your workforce. You can use this operation to require that workers use specific IP addresses to work on tasks and to update your OpenID Connect (OIDC) Identity Provider (IdP) workforce configuration.
 *
 * The worker portal is now supported in VPC and public internet.
 *
 * Use `SourceIpConfig` to restrict worker access to tasks to a specific range of IP addresses. You specify allowed IP addresses by creating a list of up to ten CIDRs. By default, a workforce isn't restricted to specific IP addresses. If you specify a range of IP addresses, workers who attempt to access tasks using any IP address outside the specified range are denied and get a `Not Found` error message on the worker portal.
 *
 * To restrict public internet access for all workers, configure the `SourceIpConfig` CIDR value. For example, when using `SourceIpConfig` with an `IpAddressType` of `IPv4`, you can restrict access to the IPv4 CIDR block "10.0.0.0/16". When using an `IpAddressType` of `dualstack`, you can specify both the IPv4 and IPv6 CIDR blocks, such as "10.0.0.0/16" for IPv4 only, "2001:db8:1234:1a00::/56" for IPv6 only, or "10.0.0.0/16" and "2001:db8:1234:1a00::/56" for dual stack.
 *
 * Amazon SageMaker does not support Source Ip restriction for worker portals in VPC.
 *
 * Use `OidcConfig` to update the configuration of a workforce created using your own OIDC IdP.
 *
 * You can only update your OIDC IdP configuration when there are no work teams associated with your workforce. You can delete work teams using the DeleteWorkteam operation.
 *
 * After restricting access to a range of IP addresses or updating your OIDC IdP configuration with this operation, you can view details about your update workforce using the DescribeWorkforce operation.
 *
 * This operation only applies to private workforces.
 */
export declare const updateWorkforce: API.OperationMethod<UpdateWorkforceRequest & RegionInput, UpdateWorkforceResponse, UpdateWorkforceError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkteamError = ResourceLimitExceeded | CommonErrors;
/**
 * Updates an existing work team with new member definitions or description.
 */
export declare const updateWorkteam: API.OperationMethod<UpdateWorkteamRequest & RegionInput, UpdateWorkteamResponse, UpdateWorkteamError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemaker.d.ts.map