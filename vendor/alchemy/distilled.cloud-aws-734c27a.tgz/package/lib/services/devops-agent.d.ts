import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ContentSizeExceededException_base: S.TaggedErrorClass<"ContentSizeExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ContentSizeExceededException extends /*@__PURE__*/ ContentSizeExceededException_base {
}
declare const IdentityCenterServiceException_base: S.TaggedErrorClass<"IdentityCenterServiceException", {
    readonly message: any;
    readonly underlyingErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdentityCenterServiceException extends /*@__PURE__*/ IdentityCenterServiceException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AgentSpaceId = string;
export type ServiceId = string;
export type SourceAccountType = "source" | (string & {});
export type RoleArn = string;
export type ValidationStatus = "valid" | "invalid" | "pending-confirmation" | (string & {});
export interface SourceAwsConfiguration {
    accountId: string;
    accountType: SourceAccountType;
    assumableRoleArn: string;
    externalId?: string | undefined;
    agentElevatedRoleArn?: string | undefined;
    agentElevatedRoleArnStatus?: ValidationStatus | undefined;
}
export type MonitorAccountType = "monitor" | (string & {});
export interface AWSConfiguration {
    assumableRoleArn: string;
    accountId: string;
    accountType: MonitorAccountType;
    agentElevatedRoleArn?: string | undefined;
    agentElevatedRoleArnStatus?: ValidationStatus | undefined;
}
export type GithubRepoOwnerType = "organization" | "user" | (string & {});
export type AssociationId = string;
export interface GitHubConfiguration {
    repoName: string;
    repoId: string;
    owner: string;
    ownerType: GithubRepoOwnerType;
    instanceIdentifier?: string | undefined;
    runtimeRoleArn?: string | undefined;
    releaseManagementAssociationId?: string | undefined;
}
export interface SlackChannel {
    channelName?: string | undefined;
    channelId: string;
}
export interface SlackTransmissionTarget {
    opsOncallTarget: SlackChannel;
    opsSRETarget?: SlackChannel | undefined;
}
export interface SlackBidirectionalConfiguration {
    roleArn: string;
    enabled?: boolean | undefined;
}
export interface SlackConfiguration {
    workspaceId: string;
    workspaceName: string;
    transmissionTarget: SlackTransmissionTarget;
    bidirectional?: SlackBidirectionalConfiguration | undefined;
}
export type DynatraceResourceList = string[];
export interface DynatraceConfiguration {
    envId: string;
    resources?: string[] | undefined;
}
export type ServiceNowAuthenticationScopeList = string[];
export interface ServiceNowConfiguration {
    instanceId?: string | undefined;
    authScopes?: string[] | undefined;
}
export interface MCPServerNewRelicConfiguration {
    accountId: string;
    endpoint: string;
}
export type ToolClassification = "READ_ONLY" | "MUTATIVE" | "DESTRUCTIVE" | (string & {});
export interface MCPToolDetail {
    name: string;
    toolClassification?: ToolClassification | undefined;
}
export type MCPToolDetailsList = MCPToolDetail[];
export interface MCPServerDatadogConfiguration {
    enabledElevatedTools?: MCPToolDetail[] | undefined;
}
export type MCPToolsList = string[];
export interface MCPServerConfiguration {
    tools: string[];
    toolDetails?: MCPToolDetail[] | undefined;
}
export interface GitLabConfiguration {
    projectId: string;
    projectPath: string;
    instanceIdentifier?: string | undefined;
    runtimeRoleArn?: string | undefined;
    releaseManagementAssociationId?: string | undefined;
}
export interface MCPServerSplunkConfiguration {
}
export interface EventChannelConfiguration {
}
export interface AzureConfiguration {
    subscriptionId: string;
}
export interface AzureDevOpsConfiguration {
    organizationName: string;
    projectId: string;
    projectName: string;
}
export interface MCPServerGrafanaConfiguration {
    endpoint: string;
    organizationId?: string | undefined;
    tools?: string[] | undefined;
    enabledElevatedTools?: MCPToolDetail[] | undefined;
}
export type PagerDutyServicesList = string[];
export type EmailAddress = string | redacted.Redacted<string>;
export interface PagerDutyConfiguration {
    services: string[];
    customerEmail: string | redacted.Redacted<string>;
}
export interface MCPServerSigV4Configuration {
    tools: string[];
    toolDetails?: MCPToolDetail[] | undefined;
}
export interface RemoteAgentConfiguration {
}
export interface RemoteAgentSigV4Configuration {
}
export type Guid = string;
export type MSTeamsChannelId = string;
export interface MSTeamsChannel {
    channelName: string;
    channelId: string;
}
export interface MSTeamsTransmissionTarget {
    opsOncallTarget?: MSTeamsChannel | undefined;
    opsSRETarget?: MSTeamsChannel | undefined;
}
export interface MSTeamsBidirectionalConfiguration {
    roleArn: string;
    enabled?: boolean | undefined;
}
export interface MSTeamsConfiguration {
    teamId: string;
    teamName: string;
    transmissionTarget: MSTeamsTransmissionTarget;
    bidirectional?: MSTeamsBidirectionalConfiguration | undefined;
}
export type DisplayName = string;
export type PrivateConnectionName = string;
export interface PrivateNetworkAccess {
    privateConnectionName: string;
    runtimeRoleArn: string;
}
export type NetworkAccessConfiguration = {
    privateAccess: PrivateNetworkAccess;
};
export interface ReleaseManagementConfiguration {
    name: string;
    networkAccess: NetworkAccessConfiguration;
}
export type ServiceConfiguration = {
    sourceAws: SourceAwsConfiguration;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws: AWSConfiguration;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github: GitHubConfiguration;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack: SlackConfiguration;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace: DynatraceConfiguration;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow: ServiceNowConfiguration;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic: MCPServerNewRelicConfiguration;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog: MCPServerDatadogConfiguration;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver: MCPServerConfiguration;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab: GitLabConfiguration;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk: MCPServerSplunkConfiguration;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel: EventChannelConfiguration;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure: AzureConfiguration;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops: AzureDevOpsConfiguration;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana: MCPServerGrafanaConfiguration;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty: PagerDutyConfiguration;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4: MCPServerSigV4Configuration;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent: RemoteAgentConfiguration;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4: RemoteAgentSigV4Configuration;
    msteams?: undefined;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams: MSTeamsConfiguration;
    releaseManagement?: undefined;
} | {
    sourceAws?: undefined;
    aws?: undefined;
    github?: undefined;
    slack?: undefined;
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpservernewrelic?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    eventChannel?: undefined;
    azure?: undefined;
    azuredevops?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
    msteams?: undefined;
    releaseManagement: ReleaseManagementConfiguration;
};
export type CapabilityType = "RELEASE_READINESS_REVIEW" | "RELEASE_READINESS_REVIEW_AUTOMATED_TESTING" | (string & {});
export type TriggerEvent = "PULL_REQUEST_READY_FOR_REVIEW" | "PULL_REQUEST_DRAFT" | (string & {});
export type TriggerEventList = TriggerEvent[];
export type TriggerRegexPattern = string;
export type TriggerRegexPatternList = string[];
export interface PatternFilter {
    patterns: string[];
}
export interface TriggerFilterGroup {
    events?: TriggerEvent[] | undefined;
    targetBranches?: PatternFilter | undefined;
}
export type TriggerFilterGroups = TriggerFilterGroup[];
export interface CapabilityConfiguration {
    enabled?: boolean | undefined;
    triggerFilterGroups?: TriggerFilterGroup[] | undefined;
}
export type AssociationCapabilities = {
    [key in CapabilityType]?: CapabilityConfiguration | undefined;
};
export interface AssociateServiceInput {
    agentSpaceId: string;
    serviceId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    } | undefined;
}
export interface Association {
    agentSpaceId: string;
    createdAt: Date;
    updatedAt: Date;
    status?: ValidationStatus | undefined;
    associationId: string;
    serviceId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    } | undefined;
}
export type WebhookType = "hmac" | "apikey" | "gitlab" | "pagerduty" | (string & {});
export type WebhookSecret = string | redacted.Redacted<string>;
export type ApiKeyValue = string | redacted.Redacted<string>;
export interface GenericWebhook {
    webhookUrl?: string | undefined;
    webhookId?: string | undefined;
    webhookType?: WebhookType | undefined;
    webhookSecret?: string | redacted.Redacted<string> | undefined;
    apiKey?: string | redacted.Redacted<string> | undefined;
}
export interface AssociateServiceOutput {
    association: Association;
    webhook?: GenericWebhook | undefined;
}
export type AgentSpaceName = string;
export type Description = string | redacted.Redacted<string>;
export type Locale = string;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type AgentSpacePreferenceKey = "elevatedActionsEnabled" | (string & {});
export type AgentSpacePreferences = {
    [key in AgentSpacePreferenceKey]?: boolean | undefined;
};
export interface CreateAgentSpaceInput {
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    locale?: string | undefined;
    kmsKeyArn?: string | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    preferences?: {
        [key: string]: boolean | undefined;
    } | undefined;
}
export interface AgentSpace {
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    locale?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
    kmsKeyArn?: string | undefined;
    agentSpaceId: string;
    preferences?: {
        [key: string]: boolean | undefined;
    } | undefined;
}
export interface CreateAgentSpaceOutput {
    agentSpace: AgentSpace;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AgentSpaceIdentifier = string;
export type AssetType = string;
export type AssetFilePath = string;
export type AssetFileBytes = Uint8Array;
export type AssetFileText = string;
export type AssetFileBody = {
    bytes: Uint8Array;
    text?: undefined;
} | {
    bytes?: undefined;
    text: string;
};
export interface AssetFileContent {
    path: string;
    body: AssetFileBody;
    metadata?: any | undefined;
}
export type AssetZipBytes = Uint8Array;
export interface AssetZipContent {
    zipFile: Uint8Array;
}
export type AssetContentUrl = string;
export interface AssetSourceUrlContent {
    url: string;
}
export type AssetContent = {
    file: AssetFileContent;
    zip?: undefined;
    sourceUrl?: undefined;
} | {
    file?: undefined;
    zip: AssetZipContent;
    sourceUrl?: undefined;
} | {
    file?: undefined;
    zip?: undefined;
    sourceUrl: AssetSourceUrlContent;
};
export interface CreateAssetRequest {
    agentSpaceId: string;
    assetType: string;
    metadata?: any | undefined;
    content: AssetContent;
    clientToken?: string | undefined;
}
export type ResourceId = string;
export interface Asset {
    assetId: string;
    assetType: string;
    metadata: any;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateAssetResponse {
    asset: Asset;
}
export interface CreateAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    content: AssetFileBody;
    metadata?: any | undefined;
    clientToken?: string | undefined;
}
export interface AssetFile {
    path: string;
    content: AssetFileBody;
    metadata?: any | undefined;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateAssetFileResponse {
    file: AssetFile;
}
export interface ReferenceInput {
    system: string;
    title?: string | undefined;
    referenceId: string;
    referenceUrl: string;
    associationId: string;
}
export type TaskType = "INVESTIGATION" | "EVALUATION" | "RELEASE_READINESS_REVIEW" | "RELEASE_TESTING" | (string & {});
export type BacklogTaskTitle = string;
export type BacklogTaskDescription = string;
export type Priority = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "MINIMAL" | (string & {});
export interface CreateBacklogTaskRequest {
    agentSpaceId: string;
    reference?: ReferenceInput | undefined;
    taskType: TaskType;
    title: string;
    description?: string | undefined;
    priority: Priority;
    clientToken?: string | undefined;
}
export interface ReferenceOutput {
    system: string;
    title?: string | undefined;
    referenceId: string;
    referenceUrl: string;
    associationId: string;
}
export type TaskStatus = "PENDING_TRIAGE" | "LINKED" | "PENDING_START" | "IN_PROGRESS" | "PENDING_CUSTOMER_APPROVAL" | "COMPLETED" | "FAILED" | "TIMED_OUT" | "CANCELED" | "SKIPPED" | "WAITING" | (string & {});
export type BackLogTimestamp = Date;
export interface Task {
    agentSpaceId: string;
    taskId: string;
    executionId?: string | undefined;
    title: string;
    description?: string | undefined;
    reference?: ReferenceOutput | undefined;
    taskType: TaskType;
    priority: Priority;
    status: TaskStatus;
    createdAt: Date;
    updatedAt: Date;
    version: number;
    supportMetadata?: any | undefined;
    metadata?: any | undefined;
    primaryTaskId?: string | undefined;
    statusReason?: string | undefined;
    hasLinkedTasks?: boolean | undefined;
}
export interface CreateBacklogTaskResponse {
    task: Task;
}
export type UserType = "IAM" | "IDC" | "IDP" | (string & {});
export interface CreateChatRequest {
    agentSpaceId: string;
    userId?: string | undefined;
    userType?: UserType | undefined;
}
export interface CreateChatResponse {
    executionId: string;
    createdAt: Date;
}
export type IpAddressOrDnsName = string;
export type VpcId = string;
export type SubnetId = string;
export type ListOfSubnetIds = string[];
export type SecurityGroupId = string;
export type ListOfSecurityGroupIds = string[];
export type IpAddressType = "IPV4" | "IPV6" | "DUAL_STACK" | (string & {});
export type MaxIpv4AddressesPerEni = number;
export type PortRange = string;
export type PortRanges = string[];
export type CertificateString = string;
export type ResourceConfigDnsResolution = "PUBLIC" | "IN_VPC" | (string & {});
export interface ServiceManagedInput {
    hostAddress: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds?: string[] | undefined;
    ipAddressType?: IpAddressType | undefined;
    ipv4AddressesPerEni?: number | undefined;
    portRanges?: string[] | undefined;
    certificate?: string | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
}
export type ResourceConfigurationArn = string;
export interface SelfManagedInput {
    resourceConfigurationId: string;
    certificate?: string | undefined;
}
export type PrivateConnectionMode = {
    serviceManaged: ServiceManagedInput;
    selfManaged?: undefined;
} | {
    serviceManaged?: undefined;
    selfManaged: SelfManagedInput;
};
export interface CreatePrivateConnectionInput {
    name: string;
    mode: PrivateConnectionMode;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PrivateConnectionType = "SELF_MANAGED" | "SERVICE_MANAGED" | (string & {});
export type ResourceGatewayArn = string;
export type PrivateConnectionStatus = "ACTIVE" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export type FailureMessage = string;
export interface CreatePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TriggerType = string;
export type ScheduleExpression = string;
export interface CronSchedule {
    expression: string;
}
export type TimeOfDay = string;
export interface DailyRecurrence {
}
export type DayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface WeeklyRecurrence {
    dayOfWeek: DayOfWeek;
}
export interface MonthlyRecurrence {
    dayOfMonth: number;
}
export type Recurrence = {
    daily: DailyRecurrence;
    weekly?: undefined;
    monthly?: undefined;
} | {
    daily?: undefined;
    weekly: WeeklyRecurrence;
    monthly?: undefined;
} | {
    daily?: undefined;
    weekly?: undefined;
    monthly: MonthlyRecurrence;
};
export interface TimeRangeSchedule {
    startAfter: string;
    startBefore: string;
    recurrence: Recurrence;
}
export type ScheduleSpec = {
    cron: CronSchedule;
    timeRange?: undefined;
} | {
    cron?: undefined;
    timeRange: TimeRangeSchedule;
};
export interface ScheduleCondition {
    expression?: string | undefined;
    spec?: ScheduleSpec | undefined;
}
export type TriggerCondition = {
    schedule: ScheduleCondition;
};
export type TriggerAction = unknown;
export type TriggerStatus = string;
export interface CreateTriggerRequest {
    agentSpaceId: string;
    type: string;
    condition: TriggerCondition;
    action: any;
    status?: string | undefined;
    clientToken?: string | undefined;
}
export interface Trigger {
    triggerId: string;
    agentSpaceId: string;
    type: string;
    condition: TriggerCondition;
    action: any;
    status: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateTriggerResponse {
    trigger: Trigger;
}
export interface DeleteAgentSpaceInput {
    agentSpaceId: string;
}
export interface DeleteAgentSpaceOutput {
}
export interface DeleteAssetRequest {
    agentSpaceId: string;
    assetId: string;
}
export interface DeleteAssetResponse {
}
export interface DeleteAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
}
export interface DeleteAssetFileResponse {
}
export interface DeletePrivateConnectionInput {
    name: string;
}
export interface DeletePrivateConnectionOutput {
    name: string;
    status: PrivateConnectionStatus;
}
export interface DeleteTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
}
export interface DeleteTriggerResponse {
}
export interface DeregisterServiceInput {
    serviceId: string;
}
export interface DeregisterServiceOutput {
}
export interface DescribePrivateConnectionInput {
    name: string;
}
export interface DescribePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AuthFlow = "iam" | "idc" | "idp" | (string & {});
export interface DisableOperatorAppInput {
    agentSpaceId: string;
    authFlow?: AuthFlow | undefined;
}
export interface DisableOperatorAppResponse {
}
export interface DisassociateServiceInput {
    agentSpaceId: string;
    associationId: string;
}
export interface DisassociateServiceOutput {
}
export type IdpClientId = string;
export type IdpClientSecret = string | redacted.Redacted<string>;
export interface EnableOperatorAppInput {
    agentSpaceId: string;
    authFlow: AuthFlow;
    operatorAppRoleArn: string;
    idcInstanceArn?: string | undefined;
    issuerUrl?: string | undefined;
    idpClientId?: string | undefined;
    idpClientSecret?: string | redacted.Redacted<string> | undefined;
    provider?: string | undefined;
}
export type OperatorAppUrl = string;
export interface IamAuthConfiguration {
    operatorAppRoleArn: string;
    createdAt: Date;
    updatedAt?: Date | undefined;
}
export interface IdcAuthConfiguration {
    operatorAppRoleArn: string;
    idcInstanceArn: string;
    idcApplicationArn?: string | undefined;
    createdAt: Date;
    updatedAt?: Date | undefined;
}
export interface IdpAuthConfiguration {
    issuerUrl: string;
    clientId: string;
    operatorAppRoleArn: string;
    provider: string;
    createdAt: Date;
    updatedAt?: Date | undefined;
}
export interface EnableOperatorAppOutput {
    agentSpaceId: string;
    operatorAppUrl?: string | undefined;
    iam?: IamAuthConfiguration | undefined;
    idc?: IdcAuthConfiguration | undefined;
    idp?: IdpAuthConfiguration | undefined;
}
export interface GetAccountUsageInput {
}
export interface UsageMetric {
    limit: number;
    usage: number;
}
export interface GetAccountUsageOutput {
    monthlyAccountInvestigationHours?: UsageMetric | undefined;
    monthlyAccountEvaluationHours?: UsageMetric | undefined;
    monthlyAccountSystemLearningHours?: UsageMetric | undefined;
    monthlyAccountOnDemandHours?: UsageMetric | undefined;
    monthlyAccountGraderHours?: UsageMetric | undefined;
    usagePeriodStartTime: Date;
    usagePeriodEndTime: Date;
}
export type IncludedData = "METADATA_ONLY" | "ALL_DATA" | (string & {});
export interface GetAgentSpaceInput {
    agentSpaceId: string;
    includedData?: IncludedData | undefined;
}
export interface GetAgentSpaceOutput {
    agentSpace: AgentSpace;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetAssetRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number | undefined;
}
export interface GetAssetResponse {
    asset: Asset;
}
export interface GetAssetContentRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number | undefined;
}
export interface GetAssetContentResponse {
    content: AssetZipContent;
    version: number;
}
export interface GetAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    assetVersion?: number | undefined;
}
export interface GetAssetFileResponse {
    file: AssetFile;
}
export interface GetAssociationInput {
    agentSpaceId: string;
    associationId: string;
}
export interface GetAssociationOutput {
    association: Association;
}
export interface GetBacklogTaskRequest {
    agentSpaceId: string;
    taskId: string;
}
export interface GetBacklogTaskResponse {
    task: Task;
}
export interface GetOperatorAppInput {
    agentSpaceId: string;
}
export interface GetOperatorAppOutput {
    operatorAppUrl?: string | undefined;
    iam?: IamAuthConfiguration | undefined;
    idc?: IdcAuthConfiguration | undefined;
    idp?: IdpAuthConfiguration | undefined;
}
export interface GetRecommendationRequest {
    agentSpaceId: string;
    recommendationId: string;
    recommendationVersion?: number | undefined;
}
export interface RecommendationContent {
    summary: string;
    spec?: string | undefined;
}
export type RecommendationStatus = "PROPOSED" | "ACCEPTED" | "REJECTED" | "CLOSED" | "COMPLETED" | "UPDATE_IN_PROGRESS" | (string & {});
export type RecommendationPriority = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export interface Recommendation {
    agentSpaceArn: string;
    recommendationId: string;
    taskId: string;
    goalId?: string | undefined;
    title: string;
    content: RecommendationContent;
    status: RecommendationStatus;
    priority: RecommendationPriority;
    goalVersion?: number | undefined;
    additionalContext?: string | undefined;
    rankPosition?: number | undefined;
    rankedAt?: Date | undefined;
    createdAt: Date;
    updatedAt: Date;
    version: number;
}
export interface GetRecommendationResponse {
    recommendation: Recommendation;
}
export interface GetServiceInput {
    serviceId: string;
}
export type Service = "github" | "slack" | "azure" | "azuredevops" | "msteams" | "dynatrace" | "servicenow" | "pagerduty" | "gitlab" | "eventChannel" | "mcpservernewrelic" | "mcpservergrafana" | "mcpserverdatadog" | "mcpserver" | "mcpserversplunk" | "azureidentity" | "mcpserversigv4" | "remoteagent" | "remoteagentsigv4" | (string & {});
export type ServiceName = string;
export type DocumentList = any[];
export interface RegisteredGithubServiceDetails {
    owner: string;
    ownerType: GithubRepoOwnerType;
    targetUrl?: string | undefined;
}
export interface RegisteredSlackServiceDetails {
    teamId: string;
    teamName: string;
}
export type MCPServerAuthorizationMethod = "oauth-client-credentials" | "oauth-3lo" | "api-key" | "bearer-token" | "custom-headers" | (string & {});
export type CustomHeaderName = string;
export type CustomHeaderNames = string[];
export interface RegisteredMCPServerDetails {
    name: string;
    endpoint: string;
    authorizationMethod: MCPServerAuthorizationMethod;
    description?: string | redacted.Redacted<string> | undefined;
    apiKeyHeader?: string | undefined;
    customHeaderNames?: string[] | undefined;
}
export type ServiceNowInstanceUrl = string;
export interface RegisteredServiceNowDetails {
    instanceUrl?: string | undefined;
}
export type GitLabTokenType = "personal" | "group" | (string & {});
export interface RegisteredGitLabServiceDetails {
    targetUrl: string;
    tokenType: GitLabTokenType;
    groupId?: string | undefined;
}
export type NewRelicRegion = "US" | "EU" | "JP" | (string & {});
export interface RegisteredNewRelicDetails {
    accountId: string;
    region: NewRelicRegion;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface RegisteredAzureDevOpsServiceDetails {
    organizationName: string;
}
export type WebIdentityTokenAudienceList = string[];
export interface RegisteredAzureIdentityDetails {
    tenantId: string;
    clientId: string;
    webIdentityRoleArn: string;
    webIdentityTokenAudiences: string[];
}
export type MCPServerEndpoint = string;
export interface RegisteredGrafanaServerDetails {
    endpoint: string;
    authorizationMethod: MCPServerAuthorizationMethod;
}
export type PagerDutyScopesList = string[];
export interface RegisteredPagerDutyDetails {
    scopes: string[];
}
export type MCPServerName = string;
export type SigV4Region = string;
export type CustomHeaderValue = string | redacted.Redacted<string>;
export type CustomHeaders = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface RegisteredMCPServerSigV4Details {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    region: string;
    service: string;
    roleArn: string;
    mcpRoleArn?: string | undefined;
    customHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export type RemoteAgentName = string;
export type RemoteAgentEndpoint = string;
export type RemoteAgentAuthorizationMethod = "oauth-client-credentials" | "api-key" | "bearer-token" | (string & {});
export interface RegisteredRemoteAgentDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    authorizationMethod: RemoteAgentAuthorizationMethod;
    apiKeyHeader?: string | undefined;
}
export interface RegisteredRemoteAgentSigV4Details {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    region: string;
    service: string;
    roleArn?: string | undefined;
}
export type AdditionalServiceDetails = {
    github: RegisteredGithubServiceDetails;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack: RegisteredSlackServiceDetails;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog: RegisteredMCPServerDetails;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver: RegisteredMCPServerDetails;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow: RegisteredServiceNowDetails;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab: RegisteredGitLabServiceDetails;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk: RegisteredMCPServerDetails;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic: RegisteredNewRelicDetails;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops: RegisteredAzureDevOpsServiceDetails;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity: RegisteredAzureIdentityDetails;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana: RegisteredGrafanaServerDetails;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty: RegisteredPagerDutyDetails;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4: RegisteredMCPServerSigV4Details;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent: RegisteredRemoteAgentDetails;
    remoteagentsigv4?: undefined;
} | {
    github?: undefined;
    slack?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    servicenow?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    azuredevops?: undefined;
    azureidentity?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4: RegisteredRemoteAgentSigV4Details;
};
export interface RegisteredService {
    serviceId: string;
    serviceType: Service;
    name?: string | undefined;
    accessibleResources?: any[] | undefined;
    additionalServiceDetails?: AdditionalServiceDetails | undefined;
    kmsKeyArn?: string | undefined;
    privateConnectionName?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetServiceOutput {
    service: RegisteredService & {
        createdAt: Date;
        updatedAt: Date;
    };
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
}
export interface GetTriggerResponse {
    trigger: Trigger;
}
export type NextToken = string;
export interface ListAgentSpacesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    includedData?: IncludedData | undefined;
}
export type AgentSpaceList = AgentSpace[];
export interface ListAgentSpacesOutput {
    nextToken?: string | undefined;
    agentSpaces: AgentSpace[];
}
export interface ListAssetFilesRequest {
    agentSpaceId: string;
    assetId: string;
    assetVersion?: number | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AssetFileSummary {
    path: string;
    metadata?: any | undefined;
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export type AssetFileSummaryList = AssetFileSummary[];
export interface ListAssetFilesResponse {
    items: AssetFileSummary[];
    nextToken?: string | undefined;
}
export interface ListAssetsRequest {
    agentSpaceId: string;
    assetType?: string | undefined;
    updatedAfter?: Date | undefined;
    updatedBefore?: Date | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type AssetList = Asset[];
export interface ListAssetsResponse {
    items: Asset[];
    nextToken?: string | undefined;
}
export interface ListAssetTypesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AssetTypeSummary {
    assetType: string;
    description: string;
}
export type AssetTypeList = AssetTypeSummary[];
export interface ListAssetTypesResponse {
    items: AssetTypeSummary[];
    nextToken?: string | undefined;
}
export interface ListAssetVersionsRequest {
    agentSpaceId: string;
    assetId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AssetVersionMetadata {
    version: number;
    createdAt: Date;
    updatedAt: Date;
}
export type AssetVersionMetadataList = AssetVersionMetadata[];
export interface ListAssetVersionsResponse {
    items: AssetVersionMetadata[];
    nextToken?: string | undefined;
}
export interface ListAssociationsInput {
    agentSpaceId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filterServiceTypes?: string | undefined;
}
export type AssociationsList = Association[];
export interface ListAssociationsOutput {
    nextToken?: string | undefined;
    associations: Association[];
}
export type PriorityList = Priority[];
export type TaskStatusList = TaskStatus[];
export type TaskTypeList = TaskType[];
export interface TaskFilter {
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
    priority?: Priority[] | undefined;
    status?: TaskStatus[] | undefined;
    taskType?: TaskType[] | undefined;
    primaryTaskId?: string | undefined;
}
export type TaskSortField = "CREATED_AT" | "PRIORITY" | (string & {});
export type TaskSortOrder = "ASC" | "DESC" | (string & {});
export interface ListBacklogTasksRequest {
    agentSpaceId: string;
    filter?: TaskFilter | undefined;
    limit?: number | undefined;
    nextToken?: string | undefined;
    sortField?: TaskSortField | undefined;
    order?: TaskSortOrder | undefined;
}
export type TaskList = Task[];
export interface ListBacklogTasksResponse {
    tasks: Task[];
    nextToken?: string | undefined;
}
export interface ListChatsRequest {
    agentSpaceId: string;
    userId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ChatExecution {
    executionId: string;
    createdAt: Date;
    updatedAt?: Date | undefined;
    summary?: string | undefined;
}
export type ChatExecutionList = ChatExecution[];
export interface ListChatsResponse {
    executions: ChatExecution[];
    nextToken?: string | undefined;
}
export interface ListExecutionsRequest {
    agentSpaceId: string;
    taskId: string;
    limit?: number | undefined;
    nextToken?: string | undefined;
}
export type JournalTimestamp = Date;
export type ExecutionStatus = "FAILED" | "RUNNING" | "STOPPED" | "CANCELED" | "TIMED_OUT" | "WAITING" | (string & {});
export interface Execution {
    agentSpaceId: string;
    executionId: string;
    parentExecutionId?: string | undefined;
    agentSubTask: string;
    createdAt: Date;
    updatedAt: Date;
    executionStatus: ExecutionStatus;
    agentType?: string | undefined;
    uid?: string | undefined;
}
export type ExecutionList = Execution[];
export interface ListExecutionsResponse {
    executions: Execution[];
    nextToken?: string | undefined;
}
export type GoalStatus = "ACTIVE" | "PAUSED" | "COMPLETE" | (string & {});
export type GoalType = "CUSTOMER_DEFINED" | "ONCALL_REPORT" | (string & {});
export interface ListGoalsRequest {
    agentSpaceId: string;
    status?: GoalStatus | undefined;
    goalType?: GoalType | undefined;
    limit?: number | undefined;
    nextToken?: string | undefined;
}
export interface GoalContent {
    description: string;
    objectives: string;
}
export type SchedulerState = "ENABLED" | "DISABLED" | (string & {});
export interface GoalSchedule {
    state: SchedulerState;
    expression?: string | undefined;
}
export interface Goal {
    agentSpaceArn: string;
    goalId: string;
    title: string;
    content: GoalContent;
    status: GoalStatus;
    goalType: GoalType;
    createdAt: Date;
    updatedAt: Date;
    lastEvaluatedAt?: Date | undefined;
    lastTaskId?: string | undefined;
    lastSuccessfulTaskId?: string | undefined;
    version: number;
    evaluationSchedule?: GoalSchedule | undefined;
}
export type GoalList = Goal[];
export interface ListGoalsResponse {
    goals: Goal[];
    nextToken?: string | undefined;
}
export type OrderType = "ASC" | "DESC" | (string & {});
export interface ListJournalRecordsRequest {
    agentSpaceId: string;
    executionId: string;
    limit?: number | undefined;
    nextToken?: string | undefined;
    recordType?: string | undefined;
    order?: OrderType | undefined;
}
export interface UserReference {
    userId: string;
    userType: UserType;
}
export interface JournalRecord {
    agentSpaceId: string;
    executionId: string;
    recordId: string;
    content: any;
    createdAt: Date;
    recordType: string;
    userReference?: UserReference | undefined;
}
export type JournalRecordList = JournalRecord[];
export interface ListJournalRecordsResponse {
    records: JournalRecord[];
    nextToken?: string | undefined;
}
export interface ListPendingMessagesRequest {
    agentSpaceId: string;
    executionId: string;
}
export type UserMessageBlock = {
    text: string;
    toolResult?: undefined;
} | {
    text?: undefined;
    toolResult: any;
};
export type UserMessage = UserMessageBlock[];
export type AssistantMessageBlock = {
    text: string;
    toolUse?: undefined;
} | {
    text?: undefined;
    toolUse: any;
};
export type AssistantMessage = AssistantMessageBlock[];
export type Message = {
    userMessage: UserMessageBlock[];
    assistantMessage?: undefined;
} | {
    userMessage?: undefined;
    assistantMessage: AssistantMessageBlock[];
};
export interface PendingMessage {
    messageId: string;
    message: Message;
}
export type PendingMessages = PendingMessage[];
export interface ListPendingMessagesResponse {
    agentSpaceId: string;
    executionId: string;
    messages: PendingMessage[];
    createdAt: Date;
}
export interface ListPrivateConnectionsInput {
}
export interface PrivateConnectionSummary {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
}
export type PrivateConnectionSummaryList = PrivateConnectionSummary[];
export interface ListPrivateConnectionsOutput {
    privateConnections: PrivateConnectionSummary[];
}
export interface ListRecommendationsRequest {
    agentSpaceId: string;
    taskId?: string | undefined;
    goalId?: string | undefined;
    status?: RecommendationStatus | undefined;
    priority?: RecommendationPriority | undefined;
    limit?: number | undefined;
    nextToken?: string | undefined;
}
export type RecommendationList = Recommendation[];
export interface ListRecommendationsResponse {
    recommendations: Recommendation[];
    nextToken?: string | undefined;
}
export interface ListServicesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filterServiceType?: Service | undefined;
}
export type RegisteredServicesList = RegisteredService[];
export interface ListServicesOutput {
    nextToken?: string | undefined;
    services: (RegisteredService & {
        createdAt: Date;
        updatedAt: Date;
    })[];
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface ListTriggersRequest {
    agentSpaceId: string;
    status?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type TriggerList = Trigger[];
export interface ListTriggersResponse {
    items: Trigger[];
    nextToken?: string | undefined;
}
export interface ListWebhooksInput {
    agentSpaceId: string;
    associationId: string;
}
export interface Webhook {
    webhookUrl: string;
    webhookType?: WebhookType | undefined;
    webhookId: string;
}
export type WebhooksList = Webhook[];
export interface ListWebhooksOutput {
    webhooks: Webhook[];
}
export type PostRegisterServiceSupportedService = "dynatrace" | "servicenow" | "pagerduty" | "gitlab" | "eventChannel" | "mcpservernewrelic" | "mcpservergrafana" | "mcpserverdatadog" | "mcpserver" | "mcpserversplunk" | "azureidentity" | "mcpserversigv4" | "remoteagent" | "remoteagentsigv4" | (string & {});
export type ClientId = string | redacted.Redacted<string>;
export type ExchangeParameterValue = string | redacted.Redacted<string>;
export type ExchangeParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type ClientSecret = string | redacted.Redacted<string>;
export interface DynatraceOAuthClientCredentialsConfig {
    clientName?: string | undefined;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    clientSecret: string | redacted.Redacted<string>;
}
export type DynatraceServiceAuthorizationConfig = {
    oAuthClientCredentials: DynatraceOAuthClientCredentialsConfig;
};
export interface DynatraceServiceDetails {
    accountUrn: string;
    authorizationConfig?: DynatraceServiceAuthorizationConfig | undefined;
}
export interface ServiceNowOAuthClientCredentialsConfig {
    clientName?: string | undefined;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    clientSecret: string | redacted.Redacted<string>;
}
export type ServiceNowServiceAuthorizationConfig = {
    oAuthClientCredentials: ServiceNowOAuthClientCredentialsConfig;
};
export interface ServiceNowServiceDetails {
    instanceUrl: string;
    authorizationConfig?: ServiceNowServiceAuthorizationConfig | undefined;
}
export interface MCPServerAuthorizationDiscoveryConfig {
    returnToEndpoint: string;
}
export type DatadogAuthorizationConfig = {
    authorizationDiscovery: MCPServerAuthorizationDiscoveryConfig;
};
export interface DatadogServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    authorizationConfig: DatadogAuthorizationConfig;
}
export type OAuthScope = string;
export type Scopes = string[];
export interface MCPServerOAuthClientCredentialsConfig {
    clientName?: string | undefined;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    clientSecret: string | redacted.Redacted<string>;
    exchangeUrl: string;
    scopes?: string[] | undefined;
}
export interface MCPServerOAuth3LOConfig {
    clientName?: string | undefined;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    returnToEndpoint: string;
    authorizationUrl: string;
    exchangeUrl: string;
    clientSecret?: string | redacted.Redacted<string> | undefined;
    supportCodeChallenge?: boolean | undefined;
    scopes?: string[] | undefined;
}
export interface MCPServerAPIKeyConfig {
    apiKeyName: string;
    apiKeyValue: string | redacted.Redacted<string>;
    apiKeyHeader: string;
}
export type TokenValue = string | redacted.Redacted<string>;
export interface MCPServerBearerTokenConfig {
    tokenName: string;
    tokenValue: string | redacted.Redacted<string>;
    authorizationHeader?: string | undefined;
}
export interface MCPServerCustomHeadersConfig {
    headers: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export type MCPServerAuthorizationConfig = {
    oAuthClientCredentials: MCPServerOAuthClientCredentialsConfig;
    oAuth3LO?: undefined;
    apiKey?: undefined;
    bearerToken?: undefined;
    customHeaders?: undefined;
    authorizationDiscovery?: undefined;
} | {
    oAuthClientCredentials?: undefined;
    oAuth3LO: MCPServerOAuth3LOConfig;
    apiKey?: undefined;
    bearerToken?: undefined;
    customHeaders?: undefined;
    authorizationDiscovery?: undefined;
} | {
    oAuthClientCredentials?: undefined;
    oAuth3LO?: undefined;
    apiKey: MCPServerAPIKeyConfig;
    bearerToken?: undefined;
    customHeaders?: undefined;
    authorizationDiscovery?: undefined;
} | {
    oAuthClientCredentials?: undefined;
    oAuth3LO?: undefined;
    apiKey?: undefined;
    bearerToken: MCPServerBearerTokenConfig;
    customHeaders?: undefined;
    authorizationDiscovery?: undefined;
} | {
    oAuthClientCredentials?: undefined;
    oAuth3LO?: undefined;
    apiKey?: undefined;
    bearerToken?: undefined;
    customHeaders: MCPServerCustomHeadersConfig;
    authorizationDiscovery?: undefined;
} | {
    oAuthClientCredentials?: undefined;
    oAuth3LO?: undefined;
    apiKey?: undefined;
    bearerToken?: undefined;
    customHeaders?: undefined;
    authorizationDiscovery: MCPServerAuthorizationDiscoveryConfig;
};
export interface MCPServerDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    authorizationConfig: MCPServerAuthorizationConfig;
}
export type GitLabTokenValue = string | redacted.Redacted<string>;
export interface GitLabDetails {
    targetUrl: string;
    tokenType: GitLabTokenType;
    tokenValue: string | redacted.Redacted<string>;
    groupId?: string | undefined;
}
export type NewRelicApiKey = string | redacted.Redacted<string>;
export type NewRelicApplicationIds = string[];
export type NewRelicEntityGuids = string[];
export type NewRelicAlertPolicyIds = string[];
export interface NewRelicApiKeyConfig {
    apiKey: string | redacted.Redacted<string>;
    accountId: string;
    region: NewRelicRegion;
    applicationIds?: string[] | undefined;
    entityGuids?: string[] | undefined;
    alertPolicyIds?: string[] | undefined;
}
export type NewRelicServiceAuthorizationConfig = {
    apiKey: NewRelicApiKeyConfig;
};
export interface NewRelicServiceDetails {
    authorizationConfig: NewRelicServiceAuthorizationConfig;
}
export type EventChannelType = "webhook" | (string & {});
export interface EventChannelDetails {
    type?: EventChannelType | undefined;
}
export interface GrafanaServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    authorizationConfig: MCPServerAuthorizationConfig;
}
export type PagerDutyScopes = string[];
export interface PagerDutyOAuthClientCredentialsConfig {
    clientName?: string | undefined;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    clientSecret: string | redacted.Redacted<string>;
}
export type PagerDutyAuthorizationConfig = {
    oAuthClientCredentials: PagerDutyOAuthClientCredentialsConfig;
};
export interface PagerDutyDetails {
    scopes: string[];
    authorizationConfig: PagerDutyAuthorizationConfig;
}
export interface MCPServerSigV4AuthorizationConfig {
    region: string;
    service: string;
    roleArn?: string | undefined;
    mcpRoleArn?: string | undefined;
    customHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export interface MCPServerSigV4ServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    authorizationConfig: MCPServerSigV4AuthorizationConfig;
}
export interface RemoteAgentAPIKeyConfig {
    apiKeyName: string;
    apiKeyValue: string | redacted.Redacted<string>;
    apiKeyHeader: string;
}
export interface RemoteAgentOAuthClientCredentialsConfig {
    clientName?: string | undefined;
    clientId: string | redacted.Redacted<string>;
    exchangeParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    clientSecret: string | redacted.Redacted<string>;
    exchangeUrl: string;
    scopes?: string[] | undefined;
}
export interface RemoteAgentBearerTokenConfig {
    tokenName: string;
    tokenValue: string | redacted.Redacted<string>;
    authorizationHeader?: string | undefined;
}
export type RemoteAgentAuthorizationConfig = {
    apiKey: RemoteAgentAPIKeyConfig;
    oAuthClientCredentials?: undefined;
    bearerToken?: undefined;
} | {
    apiKey?: undefined;
    oAuthClientCredentials: RemoteAgentOAuthClientCredentialsConfig;
    bearerToken?: undefined;
} | {
    apiKey?: undefined;
    oAuthClientCredentials?: undefined;
    bearerToken: RemoteAgentBearerTokenConfig;
};
export interface RemoteAgentServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    authorizationConfig: RemoteAgentAuthorizationConfig;
}
export interface RemoteAgentSigV4AuthorizationConfig {
    region: string;
    service: string;
    roleArn?: string | undefined;
}
export interface RemoteAgentSigV4ServiceDetails {
    name: string;
    endpoint: string;
    description?: string | redacted.Redacted<string> | undefined;
    authorizationConfig: RemoteAgentSigV4AuthorizationConfig;
}
export type ServiceDetails = {
    dynatrace: DynatraceServiceDetails;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow: ServiceNowServiceDetails;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog: DatadogServiceDetails;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver: MCPServerDetails;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab: GitLabDetails;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk: MCPServerDetails;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic: NewRelicServiceDetails;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel: EventChannelDetails;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana: GrafanaServiceDetails;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty: PagerDutyDetails;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity: RegisteredAzureIdentityDetails;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4: MCPServerSigV4ServiceDetails;
    remoteagent?: undefined;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent: RemoteAgentServiceDetails;
    remoteagentsigv4?: undefined;
} | {
    dynatrace?: undefined;
    servicenow?: undefined;
    mcpserverdatadog?: undefined;
    mcpserver?: undefined;
    gitlab?: undefined;
    mcpserversplunk?: undefined;
    mcpservernewrelic?: undefined;
    eventChannel?: undefined;
    mcpservergrafana?: undefined;
    pagerduty?: undefined;
    azureidentity?: undefined;
    mcpserversigv4?: undefined;
    remoteagent?: undefined;
    remoteagentsigv4: RemoteAgentSigV4ServiceDetails;
};
export type ServiceNameInput = string;
export interface RegisterServiceInput {
    service: PostRegisterServiceSupportedService;
    serviceDetails: ServiceDetails;
    kmsKeyArn?: string | undefined;
    privateConnectionName?: string | undefined;
    targetUrlPrivateConnectionName?: string | undefined;
    exchangeUrlPrivateConnectionName?: string | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface OAuthAdditionalStepDetails {
    authorizationUrl: string;
}
export type AdditionalServiceRegistrationStep = {
    oauth: OAuthAdditionalStepDetails;
};
export interface RegisterServiceOutput {
    serviceId?: string | undefined;
    additionalStep?: AdditionalServiceRegistrationStep | undefined;
    kmsKeyArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ChatExecutionId = string;
export type MessageContent = string;
export type ToolUseId = string;
export type InterruptId = string;
export type ApprovalId = string;
export type ButtonText = string;
export type ApprovalActionType = "APPROVED" | "REJECTED" | (string & {});
export interface ApprovalAction {
    toolUseId?: string | undefined;
    interruptId?: string | undefined;
    approvalId?: string | undefined;
    buttonText?: string | undefined;
    action?: ApprovalActionType | undefined;
}
export interface SendMessageContext {
    currentPage?: string | undefined;
    lastMessage?: string | undefined;
    userActionResponse?: string | undefined;
    approvalAction?: ApprovalAction | undefined;
}
export type AssetIdList = string[];
export interface SendMessageRequest {
    agentSpaceId: string;
    executionId: string;
    content: string;
    context?: SendMessageContext | undefined;
    userId?: string | undefined;
    assetIds?: string[] | undefined;
    modelTier?: string | undefined;
}
export interface SendMessageResponseCreatedEvent {
    responseId?: string | undefined;
    sequenceNumber?: number | undefined;
}
export interface SendMessageResponseInProgressEvent {
    responseId?: string | undefined;
    sequenceNumber?: number | undefined;
}
export interface SendMessageUsageInfo {
    inputTokens?: number | undefined;
    outputTokens?: number | undefined;
    totalTokens?: number | undefined;
}
export interface SendMessageResponseCompletedEvent {
    responseId?: string | undefined;
    usage?: SendMessageUsageInfo | undefined;
    sequenceNumber?: number | undefined;
}
export interface SendMessageResponseFailedEvent {
    responseId?: string | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
    sequenceNumber?: number | undefined;
}
export interface SendMessageSummaryEvent {
    content?: string | undefined;
    sequenceNumber?: number | undefined;
}
export interface SendMessageHeartbeatEvent {
}
export interface SendMessageContentBlockStartEvent {
    index?: number | undefined;
    type?: string | undefined;
    id?: string | undefined;
    parentId?: string | undefined;
    sequenceNumber?: number | undefined;
}
export interface SendMessageTextDelta {
    text?: string | undefined;
}
export interface SendMessageJsonDelta {
    partialJson?: string | undefined;
}
export type SendMessageContentBlockDelta = {
    textDelta: SendMessageTextDelta;
    jsonDelta?: undefined;
} | {
    textDelta?: undefined;
    jsonDelta: SendMessageJsonDelta;
};
export interface SendMessageContentBlockDeltaEvent {
    index?: number | undefined;
    delta?: SendMessageContentBlockDelta | undefined;
    sequenceNumber?: number | undefined;
}
export interface SendMessageContentBlockStopEvent {
    index?: number | undefined;
    type?: string | undefined;
    text?: string | undefined;
    last?: boolean | undefined;
    sequenceNumber?: number | undefined;
}
export type SendMessageEvents = {
    responseCreated: SendMessageResponseCreatedEvent;
    responseInProgress?: undefined;
    responseCompleted?: undefined;
    responseFailed?: undefined;
    summary?: undefined;
    heartbeat?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
} | {
    responseCreated?: undefined;
    responseInProgress: SendMessageResponseInProgressEvent;
    responseCompleted?: undefined;
    responseFailed?: undefined;
    summary?: undefined;
    heartbeat?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
} | {
    responseCreated?: undefined;
    responseInProgress?: undefined;
    responseCompleted: SendMessageResponseCompletedEvent;
    responseFailed?: undefined;
    summary?: undefined;
    heartbeat?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
} | {
    responseCreated?: undefined;
    responseInProgress?: undefined;
    responseCompleted?: undefined;
    responseFailed: SendMessageResponseFailedEvent;
    summary?: undefined;
    heartbeat?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
} | {
    responseCreated?: undefined;
    responseInProgress?: undefined;
    responseCompleted?: undefined;
    responseFailed?: undefined;
    summary: SendMessageSummaryEvent;
    heartbeat?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
} | {
    responseCreated?: undefined;
    responseInProgress?: undefined;
    responseCompleted?: undefined;
    responseFailed?: undefined;
    summary?: undefined;
    heartbeat: SendMessageHeartbeatEvent;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
} | {
    responseCreated?: undefined;
    responseInProgress?: undefined;
    responseCompleted?: undefined;
    responseFailed?: undefined;
    summary?: undefined;
    heartbeat?: undefined;
    contentBlockStart: SendMessageContentBlockStartEvent;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
} | {
    responseCreated?: undefined;
    responseInProgress?: undefined;
    responseCompleted?: undefined;
    responseFailed?: undefined;
    summary?: undefined;
    heartbeat?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta: SendMessageContentBlockDeltaEvent;
    contentBlockStop?: undefined;
} | {
    responseCreated?: undefined;
    responseInProgress?: undefined;
    responseCompleted?: undefined;
    responseFailed?: undefined;
    summary?: undefined;
    heartbeat?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop: SendMessageContentBlockStopEvent;
};
export interface SendMessageResponse {
    events: stream.Stream<SendMessageEvents, Error, never>;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAgentSpaceInput {
    agentSpaceId: string;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    locale?: string | undefined;
    preferences?: {
        [key: string]: boolean | undefined;
    } | undefined;
}
export interface UpdateAgentSpaceOutput {
    agentSpace: AgentSpace;
}
export type ToolIdentifier = string;
export type ApprovalPinKey = string;
export type ApprovalPinValue = string;
export type ApprovalArgumentPins = {
    [key: string]: string | undefined;
};
export interface ApprovalPattern {
    tool: string;
    argumentPins: {
        [key: string]: string | undefined;
    };
}
export type ApprovalReason = string;
export interface UpdateApprovalActionRequest {
    agentSpaceId: string;
    approvalId: string;
    action: ApprovalActionType;
    finalPattern?: ApprovalPattern | undefined;
    reason?: string | undefined;
    ttlSeconds?: number | undefined;
    singleUse?: boolean | undefined;
}
export type ApprovalStatus = "PENDING" | "APPROVED" | "REJECTED" | "REVOKED" | "REDEEMED" | (string & {});
export interface UpdateApprovalActionResponse {
    approvalId: string;
    status: ApprovalStatus;
    expiresAt?: Date | undefined;
}
export interface UpdateAssetRequest {
    agentSpaceId: string;
    assetId: string;
    metadata?: any | undefined;
    content?: AssetContent | undefined;
    clientToken?: string | undefined;
}
export interface UpdateAssetResponse {
    asset: Asset;
}
export interface UpdateAssetFileRequest {
    agentSpaceId: string;
    assetId: string;
    path: string;
    content?: AssetFileBody | undefined;
    metadata?: any | undefined;
    clientToken?: string | undefined;
}
export interface UpdateAssetFileResponse {
    file: AssetFile;
}
export interface UpdateAssociationInput {
    agentSpaceId: string;
    associationId: string;
    configuration: ServiceConfiguration;
    capabilities?: {
        [key: string]: CapabilityConfiguration | undefined;
    } | undefined;
}
export interface UpdateAssociationOutput {
    association: Association;
    webhook?: GenericWebhook | undefined;
}
export interface UpdateBacklogTaskRequest {
    agentSpaceId: string;
    taskId: string;
    taskStatus?: TaskStatus | undefined;
    clientToken?: string | undefined;
}
export interface UpdateBacklogTaskResponse {
    task: Task;
}
export interface GoalScheduleInput {
    state: SchedulerState;
}
export interface UpdateGoalRequest {
    agentSpaceId: string;
    goalId: string;
    evaluationSchedule?: GoalScheduleInput | undefined;
    clientToken?: string | undefined;
}
export interface UpdateGoalResponse {
    goal: Goal;
}
export interface UpdateOperatorAppIdpConfigInput {
    agentSpaceId: string;
    idpClientSecret?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateOperatorAppIdpConfigOutput {
    agentSpaceId: string;
    idp: IdpAuthConfiguration;
}
export interface UpdatePrivateConnectionCertificateInput {
    name: string;
    certificate: string;
}
export interface UpdatePrivateConnectionCertificateOutput {
    name: string;
    type: PrivateConnectionType;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    status: PrivateConnectionStatus;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
}
export interface UpdateRecommendationRequest {
    agentSpaceId: string;
    recommendationId: string;
    status?: RecommendationStatus | undefined;
    additionalContext?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateRecommendationResponse {
    recommendation: Recommendation;
}
export interface UpdateTriggerRequest {
    agentSpaceId: string;
    triggerId: string;
    status?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateTriggerResponse {
    trigger: Trigger;
}
export interface ValidateAwsAssociationsInput {
    agentSpaceId: string;
}
export interface ValidateAwsAssociationsOutput {
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateServiceError = ConflictException | InternalServerException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | AccessDeniedException | ContentSizeExceededException | ThrottlingException | CommonErrors;
/**
 * Adds a specific service association to an AgentSpace. It overwrites the existing association of the same service. Returns 201 Created on success.
 */
export declare const associateService: API.OperationMethod<AssociateServiceInput & RegionInput, AssociateServiceOutput, AssociateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateAgentSpaceError = ConflictException | InternalServerException | InvalidParameterException | ServiceQuotaExceededException | ValidationException | AccessDeniedException | ContentSizeExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new AgentSpace with the specified name and description. Duplicate space names are allowed.
 */
export declare const createAgentSpace: API.OperationMethod<CreateAgentSpaceInput & RegionInput, CreateAgentSpaceOutput, CreateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new asset in the specified agent space
 */
export declare const createAsset: API.OperationMethod<CreateAssetRequest & RegionInput, CreateAssetResponse, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreateAssetFileError = AccessDeniedException | ConflictException | ContentSizeExceededException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a file in an asset
 */
export declare const createAssetFile: API.OperationMethod<CreateAssetFileRequest & RegionInput, CreateAssetFileResponse, CreateAssetFileError, Credentials | HttpClient.HttpClient>;
export type CreateBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new backlog task in the specified agent space
 */
export declare const createBacklogTask: API.OperationMethod<CreateBacklogTaskRequest & RegionInput, CreateBacklogTaskResponse, CreateBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type CreateChatError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new chat execution in the specified agent space
 */
export declare const createChat: API.OperationMethod<CreateChatRequest & RegionInput, CreateChatResponse, CreateChatError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateConnectionError = AccessDeniedException | InternalServerException | InvalidParameterException | ValidationException | ConflictException | ContentSizeExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a Private Connection to a target resource.
 */
export declare const createPrivateConnection: API.OperationMethod<CreatePrivateConnectionInput & RegionInput, CreatePrivateConnectionOutput, CreatePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateTriggerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new Trigger in the specified agent space
 */
export declare const createTrigger: API.OperationMethod<CreateTriggerRequest & RegionInput, CreateTriggerResponse, CreateTriggerError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentSpaceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Deletes an AgentSpace. This operation is idempotent and returns a 204 No Content response on success.
 */
export declare const deleteAgentSpace: API.OperationMethod<DeleteAgentSpaceInput & RegionInput, DeleteAgentSpaceOutput, DeleteAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Deletes an asset and all its files from the specified agent space
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest & RegionInput, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetFileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Deletes a file from an asset
 */
export declare const deleteAssetFile: API.OperationMethod<DeleteAssetFileRequest & RegionInput, DeleteAssetFileResponse, DeleteAssetFileError, Credentials | HttpClient.HttpClient>;
export type DeletePrivateConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Deletes a Private Connection. The deletion is asynchronous and returns DELETE_IN_PROGRESS status.
 */
export declare const deletePrivateConnection: API.OperationMethod<DeletePrivateConnectionInput & RegionInput, DeletePrivateConnectionOutput, DeletePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteTriggerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Deletes a Trigger from the specified agent space
 */
export declare const deleteTrigger: API.OperationMethod<DeleteTriggerRequest & RegionInput, DeleteTriggerResponse, DeleteTriggerError, Credentials | HttpClient.HttpClient>;
export type DeregisterServiceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Deregister a service
 */
export declare const deregisterService: API.OperationMethod<DeregisterServiceInput & RegionInput, DeregisterServiceOutput, DeregisterServiceError, Credentials | HttpClient.HttpClient>;
export type DescribePrivateConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Retrieves details of an existing Private Connection.
 */
export declare const describePrivateConnection: API.OperationMethod<DescribePrivateConnectionInput & RegionInput, DescribePrivateConnectionOutput, DescribePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type DisableOperatorAppError = IdentityCenterServiceException | InternalServerException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Disable the Operator App for the specified AgentSpace
 */
export declare const disableOperatorApp: API.OperationMethod<DisableOperatorAppInput & RegionInput, DisableOperatorAppResponse, DisableOperatorAppError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Deletes a specific service association from an AgentSpace. This operation is idempotent and returns a 204 No Content response on success.
 */
export declare const disassociateService: API.OperationMethod<DisassociateServiceInput & RegionInput, DisassociateServiceOutput, DisassociateServiceError, Credentials | HttpClient.HttpClient>;
export type EnableOperatorAppError = IdentityCenterServiceException | InternalServerException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Enable the Operator App to access the given AgentSpace
 */
export declare const enableOperatorApp: API.OperationMethod<EnableOperatorAppInput & RegionInput, EnableOperatorAppOutput, EnableOperatorAppError, Credentials | HttpClient.HttpClient>;
export type GetAccountUsageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Retrieves monthly account usage metrics and limits for the AWS account.
 */
export declare const getAccountUsage: API.OperationMethod<GetAccountUsageInput & RegionInput, GetAccountUsageOutput, GetAccountUsageError, Credentials | HttpClient.HttpClient>;
export type GetAgentSpaceError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific AgentSpace.
 */
export declare const getAgentSpace: API.OperationMethod<GetAgentSpaceInput & RegionInput, GetAgentSpaceOutput, GetAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Gets an asset from the specified agent space
 */
export declare const getAsset: API.OperationMethod<GetAssetRequest & RegionInput, GetAssetResponse, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetAssetContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Gets an asset's content as a zip bundle
 */
export declare const getAssetContent: API.OperationMethod<GetAssetContentRequest & RegionInput, GetAssetContentResponse, GetAssetContentError, Credentials | HttpClient.HttpClient>;
export type GetAssetFileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Gets a file from an asset
 */
export declare const getAssetFile: API.OperationMethod<GetAssetFileRequest & RegionInput, GetAssetFileResponse, GetAssetFileError, Credentials | HttpClient.HttpClient>;
export type GetAssociationError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Retrieves given associations configured for a specific AgentSpace.
 */
export declare const getAssociation: API.OperationMethod<GetAssociationInput & RegionInput, GetAssociationOutput, GetAssociationError, Credentials | HttpClient.HttpClient>;
export type GetBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Gets a backlog task for the specified agent space and task id
 */
export declare const getBacklogTask: API.OperationMethod<GetBacklogTaskRequest & RegionInput, GetBacklogTaskResponse, GetBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type GetOperatorAppError = InternalServerException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Get the full auth configuration of operator including any enabled auth flow
 */
export declare const getOperatorApp: API.OperationMethod<GetOperatorAppInput & RegionInput, GetOperatorAppOutput, GetOperatorAppError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Retrieves a specific recommendation by its ID
 */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest & RegionInput, GetRecommendationResponse, GetRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetServiceError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Retrieves given service by it's unique identifier
 */
export declare const getService: API.OperationMethod<GetServiceInput & RegionInput, GetServiceOutput, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetTriggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Gets a Trigger from the specified agent space
 */
export declare const getTrigger: API.OperationMethod<GetTriggerRequest & RegionInput, GetTriggerResponse, GetTriggerError, Credentials | HttpClient.HttpClient>;
export type ListAgentSpacesError = InternalServerException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Lists all AgentSpaces with optional pagination.
 */
export declare const listAgentSpaces: API.PaginatedOperationMethod<ListAgentSpacesInput & RegionInput, ListAgentSpacesOutput, ListAgentSpacesError, Credentials | HttpClient.HttpClient, AgentSpace>;
export type ListAssetFilesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Lists files in an asset
 */
export declare const listAssetFiles: API.PaginatedOperationMethod<ListAssetFilesRequest & RegionInput, ListAssetFilesResponse, ListAssetFilesError, Credentials | HttpClient.HttpClient, AssetFileSummary>;
export type ListAssetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Lists assets in the specified agent space
 */
export declare const listAssets: API.PaginatedOperationMethod<ListAssetsRequest & RegionInput, ListAssetsResponse, ListAssetsError, Credentials | HttpClient.HttpClient, Asset>;
export type ListAssetTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Lists the supported asset types
 */
export declare const listAssetTypes: API.PaginatedOperationMethod<ListAssetTypesRequest & RegionInput, ListAssetTypesResponse, ListAssetTypesError, Credentials | HttpClient.HttpClient, AssetTypeSummary>;
export type ListAssetVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Lists versions of an asset in the specified agent space
 */
export declare const listAssetVersions: API.PaginatedOperationMethod<ListAssetVersionsRequest & RegionInput, ListAssetVersionsResponse, ListAssetVersionsError, Credentials | HttpClient.HttpClient, AssetVersionMetadata>;
export type ListAssociationsError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * List all associations for given AgentSpace
 */
export declare const listAssociations: API.PaginatedOperationMethod<ListAssociationsInput & RegionInput, ListAssociationsOutput, ListAssociationsError, Credentials | HttpClient.HttpClient, Association>;
export type ListBacklogTasksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Lists backlog tasks in the specified agent space with optional filtering and sorting
 */
export declare const listBacklogTasks: API.PaginatedOperationMethod<ListBacklogTasksRequest & RegionInput, ListBacklogTasksResponse, ListBacklogTasksError, Credentials | HttpClient.HttpClient, Task>;
export type ListChatsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Retrieves a paginated list of the user's recent chat executions
 */
export declare const listChats: API.OperationMethod<ListChatsRequest & RegionInput, ListChatsResponse, ListChatsError, Credentials | HttpClient.HttpClient>;
export type ListExecutionsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * List executions
 */
export declare const listExecutions: API.PaginatedOperationMethod<ListExecutionsRequest & RegionInput, ListExecutionsResponse, ListExecutionsError, Credentials | HttpClient.HttpClient, Execution>;
export type ListGoalsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Lists goals in the specified agent space with optional filtering
 */
export declare const listGoals: API.PaginatedOperationMethod<ListGoalsRequest & RegionInput, ListGoalsResponse, ListGoalsError, Credentials | HttpClient.HttpClient, Goal>;
export type ListJournalRecordsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * List journal records for a specific execution
 */
export declare const listJournalRecords: API.PaginatedOperationMethod<ListJournalRecordsRequest & RegionInput, ListJournalRecordsResponse, ListJournalRecordsError, Credentials | HttpClient.HttpClient, JournalRecord>;
export type ListPendingMessagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * List pending messages for a specific execution.
 */
export declare const listPendingMessages: API.OperationMethod<ListPendingMessagesRequest & RegionInput, ListPendingMessagesResponse, ListPendingMessagesError, Credentials | HttpClient.HttpClient>;
export type ListPrivateConnectionsError = AccessDeniedException | InternalServerException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Lists all Private Connections in the caller's account.
 */
export declare const listPrivateConnections: API.OperationMethod<ListPrivateConnectionsInput & RegionInput, ListPrivateConnectionsOutput, ListPrivateConnectionsError, Credentials | HttpClient.HttpClient>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Lists recommendations for the specified agent space
 */
export declare const listRecommendations: API.OperationMethod<ListRecommendationsRequest & RegionInput, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ListServicesError = InternalServerException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * List a list of registered service on the account level.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesInput & RegionInput, ListServicesOutput, ListServicesError, Credentials | HttpClient.HttpClient, RegisteredService>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Lists tags for the specified AWS DevOps Agent resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTriggersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Lists Triggers in the specified agent space
 */
export declare const listTriggers: API.PaginatedOperationMethod<ListTriggersRequest & RegionInput, ListTriggersResponse, ListTriggersError, Credentials | HttpClient.HttpClient, Trigger>;
export type ListWebhooksError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * List all webhooks for given Association
 */
export declare const listWebhooks: API.OperationMethod<ListWebhooksInput & RegionInput, ListWebhooksOutput, ListWebhooksError, Credentials | HttpClient.HttpClient>;
export type RegisterServiceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This operation registers the specified service
 */
export declare const registerService: API.OperationMethod<RegisterServiceInput & RegionInput, RegisterServiceOutput, RegisterServiceError, Credentials | HttpClient.HttpClient>;
export type SendMessageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | CommonErrors;
/**
 * Sends a chat message and streams the response for the specified agent space execution
 */
export declare const sendMessage: API.OperationMethod<SendMessageRequest & RegionInput, SendMessageResponse, SendMessageError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Adds or overwrites tags for the specified AWS DevOps Agent resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Removes tags from the specified AWS DevOps Agent resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentSpaceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates the information of an existing AgentSpace.
 */
export declare const updateAgentSpace: API.OperationMethod<UpdateAgentSpaceInput & RegionInput, UpdateAgentSpaceOutput, UpdateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | CommonErrors;
/**
 * Updates an approval request with the terminal decision (APPROVED or REJECTED). A single operation handles both verbs via the action enum.
 */
export declare const updateApprovalAction: API.OperationMethod<UpdateApprovalActionRequest & RegionInput, UpdateApprovalActionResponse, UpdateApprovalActionError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates an asset in the specified agent space
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest & RegionInput, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetFileError = AccessDeniedException | ConflictException | ContentSizeExceededException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates a file in an asset
 */
export declare const updateAssetFile: API.OperationMethod<UpdateAssetFileRequest & RegionInput, UpdateAssetFileResponse, UpdateAssetFileError, Credentials | HttpClient.HttpClient>;
export type UpdateAssociationError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | AccessDeniedException | ContentSizeExceededException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Partially updates the configuration of an existing service association for an AgentSpace. Present fields are fully replaced; absent fields are left unchanged. Returns 200 OK on success.
 */
export declare const updateAssociation: API.OperationMethod<UpdateAssociationInput & RegionInput, UpdateAssociationOutput, UpdateAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateBacklogTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Update an existing backlog task.
 */
export declare const updateBacklogTask: API.OperationMethod<UpdateBacklogTaskRequest & RegionInput, UpdateBacklogTaskResponse, UpdateBacklogTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateGoalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Update an existing goal
 */
export declare const updateGoal: API.OperationMethod<UpdateGoalRequest & RegionInput, UpdateGoalResponse, UpdateGoalError, Credentials | HttpClient.HttpClient>;
export type UpdateOperatorAppIdpConfigError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Update the external Identity Provider configuration for the Operator App
 */
export declare const updateOperatorAppIdpConfig: API.OperationMethod<UpdateOperatorAppIdpConfigInput & RegionInput, UpdateOperatorAppIdpConfigOutput, UpdateOperatorAppIdpConfigError, Credentials | HttpClient.HttpClient>;
export type UpdatePrivateConnectionCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates the certificate associated with a Private Connection.
 */
export declare const updatePrivateConnectionCertificate: API.OperationMethod<UpdatePrivateConnectionCertificateInput & RegionInput, UpdatePrivateConnectionCertificateOutput, UpdatePrivateConnectionCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateRecommendationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates an existing recommendation with new content, status, or metadata
 */
export declare const updateRecommendation: API.OperationMethod<UpdateRecommendationRequest & RegionInput, UpdateRecommendationResponse, UpdateRecommendationError, Credentials | HttpClient.HttpClient>;
export type UpdateTriggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates the status of an existing Trigger
 */
export declare const updateTrigger: API.OperationMethod<UpdateTriggerRequest & RegionInput, UpdateTriggerResponse, UpdateTriggerError, Credentials | HttpClient.HttpClient>;
export type ValidateAwsAssociationsError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ConflictException | ContentSizeExceededException | InvalidParameterException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Validates an aws association and set status and returns a 204 No Content response on success.
 */
export declare const validateAwsAssociations: API.OperationMethod<ValidateAwsAssociationsInput & RegionInput, ValidateAwsAssociationsOutput, ValidateAwsAssociationsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=devops-agent.d.ts.map