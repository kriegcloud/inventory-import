import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const EnvironmentBlueprintConfigurationInUse_base: S.TaggedErrorClass<"EnvironmentBlueprintConfigurationInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class EnvironmentBlueprintConfigurationInUse extends /*@__PURE__*/ EnvironmentBlueprintConfigurationInUse_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainId = string;
export type AssetIdentifier = string;
export type Revision = string;
export type AcceptRuleBehavior = "ALL" | "NONE" | (string & {});
export interface AcceptRule {
    rule?: AcceptRuleBehavior | undefined;
    threshold?: number | undefined;
}
export type EditedValue = string | redacted.Redacted<string>;
export interface AcceptChoice {
    predictionTarget?: string | undefined;
    predictionChoice?: number | undefined;
    editedValue?: string | redacted.Redacted<string> | undefined;
}
export type AcceptChoices = AcceptChoice[];
export type ClientToken = string;
export interface AcceptPredictionsInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string | undefined;
    acceptRule?: AcceptRule | undefined;
    acceptChoices?: AcceptChoice[] | undefined;
    clientToken?: string | undefined;
}
export type AssetId = string;
export interface AcceptPredictionsOutput {
    domainId: string;
    assetId: string;
    revision: string;
}
export type SubscriptionRequestId = string;
export type DecisionComment = string | redacted.Redacted<string>;
export type FilterId = string;
export type FilterIds = string[];
export interface AcceptedAssetScope {
    assetId: string;
    filterIds: string[];
}
export type AcceptedAssetScopes = AcceptedAssetScope[];
export type S3Permission = "READ" | "WRITE" | (string & {});
export type S3Permissions = S3Permission[];
export type Permissions = {
    s3: S3Permission[];
};
export interface AssetPermission {
    assetId: string;
    permissions: Permissions;
}
export type AssetPermissions = AssetPermission[];
export interface AcceptSubscriptionRequestInput {
    domainIdentifier: string;
    identifier: string;
    decisionComment?: string | redacted.Redacted<string> | undefined;
    assetScopes?: AcceptedAssetScope[] | undefined;
    assetPermissions?: AssetPermission[] | undefined;
}
export type CreatedBy = string;
export type UpdatedBy = string;
export type SubscriptionRequestStatus = "PENDING" | "ACCEPTED" | "REJECTED" | (string & {});
export type CreatedAt = Date;
export type UpdatedAt = Date;
export type RequestReason = string | redacted.Redacted<string>;
export type ProjectId = string;
export type ProjectName = string | redacted.Redacted<string>;
export interface SubscribedProject {
    id?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
}
export type UserProfileId = string;
export interface IamUserProfileDetails {
    arn?: string | undefined;
    principalId?: string | undefined;
    sessionName?: string | undefined;
    groupProfileId?: string | undefined;
}
export type UserProfileName = string | redacted.Redacted<string>;
export type FirstName = string | redacted.Redacted<string>;
export type LastName = string | redacted.Redacted<string>;
export interface SsoUserProfileDetails {
    username?: string | redacted.Redacted<string> | undefined;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
}
export type UserProfileDetails = {
    iam: IamUserProfileDetails;
    sso?: undefined;
} | {
    iam?: undefined;
    sso: SsoUserProfileDetails;
};
export interface SubscribedUser {
    id?: string | undefined;
    details?: UserProfileDetails | undefined;
}
export type GroupProfileId = string;
export type GroupProfileName = string | redacted.Redacted<string>;
export interface SubscribedGroup {
    id?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
}
export type IamPrincipalArn = string;
export interface SubscribedIamPrincipal {
    principalArn?: string | undefined;
}
export type SubscribedPrincipal = {
    project: SubscribedProject;
    user?: undefined;
    group?: undefined;
    iam?: undefined;
} | {
    project?: undefined;
    user: SubscribedUser;
    group?: undefined;
    iam?: undefined;
} | {
    project?: undefined;
    user?: undefined;
    group: SubscribedGroup;
    iam?: undefined;
} | {
    project?: undefined;
    user?: undefined;
    group?: undefined;
    iam: SubscribedIamPrincipal;
};
export type SubscribedPrincipals = SubscribedPrincipal[];
export type ListingId = string;
export type ListingName = string;
export type Description = string | redacted.Redacted<string>;
export type TypeName = string;
export type Forms = string;
export type GlossaryTermName = string | redacted.Redacted<string>;
export type ShortDescription = string | redacted.Redacted<string>;
export interface DetailedGlossaryTerm {
    name?: string | redacted.Redacted<string> | undefined;
    shortDescription?: string | redacted.Redacted<string> | undefined;
}
export type DetailedGlossaryTerms = DetailedGlossaryTerm[];
export interface AssetScope {
    assetId: string;
    filterIds: string[];
    status: string;
    scopeName?: string | undefined;
    errorMessage?: string | undefined;
}
export interface SubscribedAssetListing {
    entityId?: string | undefined;
    entityRevision?: string | undefined;
    entityType?: string | undefined;
    forms?: string | undefined;
    glossaryTerms?: DetailedGlossaryTerm[] | undefined;
    assetScope?: AssetScope | undefined;
    permissions?: Permissions | undefined;
}
export interface AssetInDataProductListingItem {
    entityId?: string | undefined;
    entityRevision?: string | undefined;
    entityType?: string | undefined;
}
export type AssetInDataProductListingItems = AssetInDataProductListingItem[];
export interface SubscribedProductListing {
    entityId?: string | undefined;
    entityRevision?: string | undefined;
    glossaryTerms?: DetailedGlossaryTerm[] | undefined;
    name?: string | undefined;
    description?: string | undefined;
    assetListings?: AssetInDataProductListingItem[] | undefined;
}
export type SubscribedListingItem = {
    assetListing: SubscribedAssetListing;
    productListing?: undefined;
} | {
    assetListing?: undefined;
    productListing: SubscribedProductListing;
};
export interface SubscribedListing {
    id: string;
    revision?: string | undefined;
    name: string;
    description: string | redacted.Redacted<string>;
    item: SubscribedListingItem;
    ownerProjectId: string;
    ownerProjectName?: string | undefined;
}
export type SubscribedListings = SubscribedListing[];
export type SubscriptionId = string;
export type FormName = string;
export type FormTypeName = string | redacted.Redacted<string>;
export interface FormOutput {
    formName: string;
    typeName?: string | redacted.Redacted<string> | undefined;
    typeRevision?: string | undefined;
    content?: string | undefined;
}
export type MetadataForms = FormOutput[];
export interface AcceptSubscriptionRequestOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string | undefined;
    decisionComment?: string | redacted.Redacted<string> | undefined;
    existingSubscriptionId?: string | undefined;
    metadataForms?: FormOutput[] | undefined;
}
export type DataZoneEntityType = "DOMAIN_UNIT" | (string & {});
export type UserIdentifier = string;
export interface OwnerUserProperties {
    userIdentifier: string;
}
export type GroupIdentifier = string;
export interface OwnerGroupProperties {
    groupIdentifier: string;
}
export type OwnerProperties = {
    user: OwnerUserProperties;
    group?: undefined;
} | {
    user?: undefined;
    group: OwnerGroupProperties;
};
export interface AddEntityOwnerInput {
    domainIdentifier: string;
    entityType: DataZoneEntityType;
    entityIdentifier: string;
    owner: OwnerProperties;
    clientToken?: string | undefined;
}
export interface AddEntityOwnerOutput {
}
export type TargetEntityType = "DOMAIN_UNIT" | "ENVIRONMENT_BLUEPRINT_CONFIGURATION" | "ENVIRONMENT_PROFILE" | "ASSET_TYPE" | (string & {});
export type ManagedPolicyType = "CREATE_DOMAIN_UNIT" | "OVERRIDE_DOMAIN_UNIT_OWNERS" | "ADD_TO_PROJECT_MEMBER_POOL" | "OVERRIDE_PROJECT_OWNERS" | "CREATE_GLOSSARY" | "CREATE_FORM_TYPE" | "CREATE_ASSET_TYPE" | "CREATE_PROJECT" | "CREATE_ENVIRONMENT_PROFILE" | "DELEGATE_CREATE_ENVIRONMENT_PROFILE" | "CREATE_ENVIRONMENT" | "CREATE_ENVIRONMENT_FROM_BLUEPRINT" | "CREATE_PROJECT_FROM_PROJECT_PROFILE" | "USE_ASSET_TYPE" | (string & {});
export interface AllUsersGrantFilter {
}
export type UserPolicyGrantPrincipal = {
    userIdentifier: string;
    allUsersGrantFilter?: undefined;
} | {
    userIdentifier?: undefined;
    allUsersGrantFilter: AllUsersGrantFilter;
};
export type GroupPolicyGrantPrincipal = {
    groupIdentifier: string;
};
export type ProjectDesignation = "OWNER" | "CONTRIBUTOR" | "PROJECT_CATALOG_STEWARD" | "USER_CREATED_DESIGNATION" | (string & {});
export type DesignationId = string;
export type DomainUnitId = string;
export interface DomainUnitFilterForProject {
    domainUnit: string;
    includeChildDomainUnits?: boolean | undefined;
}
export type ProjectGrantFilter = {
    domainUnitFilter: DomainUnitFilterForProject;
};
export interface ProjectPolicyGrantPrincipal {
    projectDesignation: ProjectDesignation;
    userCreatedDesignationId?: string | undefined;
    projectIdentifier?: string | undefined;
    projectGrantFilter?: ProjectGrantFilter | undefined;
}
export type DomainUnitDesignation = "OWNER" | (string & {});
export interface AllDomainUnitsGrantFilter {
}
export type DomainUnitGrantFilter = {
    allDomainUnitsGrantFilter: AllDomainUnitsGrantFilter;
};
export interface DomainUnitPolicyGrantPrincipal {
    domainUnitDesignation: DomainUnitDesignation;
    domainUnitIdentifier?: string | undefined;
    domainUnitGrantFilter?: DomainUnitGrantFilter | undefined;
}
export type PolicyGrantPrincipal = {
    user: UserPolicyGrantPrincipal;
    group?: undefined;
    project?: undefined;
    domainUnit?: undefined;
} | {
    user?: undefined;
    group: GroupPolicyGrantPrincipal;
    project?: undefined;
    domainUnit?: undefined;
} | {
    user?: undefined;
    group?: undefined;
    project: ProjectPolicyGrantPrincipal;
    domainUnit?: undefined;
} | {
    user?: undefined;
    group?: undefined;
    project?: undefined;
    domainUnit: DomainUnitPolicyGrantPrincipal;
};
export interface CreateDomainUnitPolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
}
export interface OverrideDomainUnitOwnersPolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
}
export interface AddToProjectMemberPoolPolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
}
export interface OverrideProjectOwnersPolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
}
export interface CreateGlossaryPolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
}
export interface CreateFormTypePolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
}
export interface CreateAssetTypePolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
}
export interface CreateProjectPolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
}
export interface CreateEnvironmentProfilePolicyGrantDetail {
    domainUnitId?: string | undefined;
}
export interface Unit {
}
export type ProjectProfileList = string[];
export interface CreateProjectFromProjectProfilePolicyGrantDetail {
    includeChildDomainUnits?: boolean | undefined;
    projectProfiles?: string[] | undefined;
}
export interface UseAssetTypePolicyGrantDetail {
    domainUnitId?: string | undefined;
}
export type PolicyGrantDetail = {
    createDomainUnit: CreateDomainUnitPolicyGrantDetail;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners: OverrideDomainUnitOwnersPolicyGrantDetail;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool: AddToProjectMemberPoolPolicyGrantDetail;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners: OverrideProjectOwnersPolicyGrantDetail;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary: CreateGlossaryPolicyGrantDetail;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType: CreateFormTypePolicyGrantDetail;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType: CreateAssetTypePolicyGrantDetail;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject: CreateProjectPolicyGrantDetail;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile: CreateEnvironmentProfilePolicyGrantDetail;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile: Unit;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment: Unit;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint: Unit;
    createProjectFromProjectProfile?: undefined;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile: CreateProjectFromProjectProfilePolicyGrantDetail;
    useAssetType?: undefined;
} | {
    createDomainUnit?: undefined;
    overrideDomainUnitOwners?: undefined;
    addToProjectMemberPool?: undefined;
    overrideProjectOwners?: undefined;
    createGlossary?: undefined;
    createFormType?: undefined;
    createAssetType?: undefined;
    createProject?: undefined;
    createEnvironmentProfile?: undefined;
    delegateCreateEnvironmentProfile?: undefined;
    createEnvironment?: undefined;
    createEnvironmentFromBlueprint?: undefined;
    createProjectFromProjectProfile?: undefined;
    useAssetType: UseAssetTypePolicyGrantDetail;
};
export interface AddPolicyGrantInput {
    domainIdentifier: string;
    entityType: TargetEntityType;
    entityIdentifier: string;
    policyType: ManagedPolicyType;
    principal: PolicyGrantPrincipal;
    detail: PolicyGrantDetail;
    clientToken?: string | undefined;
}
export type GrantIdentifier = string;
export interface AddPolicyGrantOutput {
    grantId?: string | undefined;
}
export type EnvironmentId = string;
export interface AssociateEnvironmentRoleInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    environmentRoleArn: string;
}
export interface AssociateEnvironmentRoleOutput {
}
export type EntityIdentifier = string;
export type GovernedEntityType = "ASSET" | (string & {});
export type GlossaryTermId = string;
export type GovernedGlossaryTerms = string[];
export interface AssociateGovernedTermsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: GovernedEntityType;
    governedGlossaryTerms: string[];
}
export interface AssociateGovernedTermsOutput {
}
export type AttributeEntityType = "ASSET" | "LISTING" | (string & {});
export type EntityId = string;
export type AttributeIdentifier = string;
export type AttributesList = string[];
export interface BatchGetAttributesMetadataInput {
    domainIdentifier: string;
    entityType: AttributeEntityType;
    entityIdentifier: string;
    entityRevision?: string | undefined;
    attributeIdentifiers: string[];
}
export type FormOutputList = FormOutput[];
export interface BatchGetAttributeOutput {
    attributeIdentifier: string;
    forms?: FormOutput[] | undefined;
}
export type BatchGetAttributeItems = BatchGetAttributeOutput[];
export interface AttributeError {
    attributeIdentifier: string;
    code: string;
    message: string;
}
export type AttributesErrors = AttributeError[];
export interface BatchGetAttributesMetadataOutput {
    attributes?: BatchGetAttributeOutput[] | undefined;
    errors: AttributeError[];
}
export type FormTypeIdentifier = string;
export type RevisionInput = string;
export interface FormInput {
    formName: string;
    typeIdentifier?: string | undefined;
    typeRevision?: string | undefined;
    content?: string | undefined;
}
export type FormInputList = FormInput[];
export interface AttributeInput {
    attributeIdentifier: string;
    forms: FormInput[];
}
export type Attributes = AttributeInput[];
export interface BatchPutAttributesMetadataInput {
    domainIdentifier: string;
    entityType: AttributeEntityType;
    entityIdentifier: string;
    clientToken?: string | undefined;
    attributes: AttributeInput[];
}
export interface BatchPutAttributeOutput {
    attributeIdentifier: string;
}
export type BatchPutAttributeItems = BatchPutAttributeOutput[];
export interface BatchPutAttributesMetadataOutput {
    errors?: AttributeError[] | undefined;
    attributes?: BatchPutAttributeOutput[] | undefined;
}
export type MetadataGenerationRunIdentifier = string;
export interface CancelMetadataGenerationRunInput {
    domainIdentifier: string;
    identifier: string;
}
export interface CancelMetadataGenerationRunOutput {
}
export interface CancelSubscriptionInput {
    domainIdentifier: string;
    identifier: string;
}
export type SubscriptionStatus = "APPROVED" | "REVOKED" | "CANCELLED" | (string & {});
export interface CancelSubscriptionOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionStatus;
    createdAt: Date;
    updatedAt: Date;
    subscribedPrincipal: SubscribedPrincipal;
    subscribedListing: SubscribedListing;
    subscriptionRequestId?: string | undefined;
    retainPermissions?: boolean | undefined;
}
export type AccountPoolName = string | redacted.Redacted<string>;
export type ResolutionStrategy = "MANUAL" | (string & {});
export type AwsAccountId = string;
export type AwsRegion = string;
export type AwsRegionList = string[];
export type AwsAccountName = string | redacted.Redacted<string>;
export interface AccountInfo {
    awsAccountId: string;
    supportedRegions: string[];
    awsAccountName?: string | redacted.Redacted<string> | undefined;
}
export type AccountInfoList = AccountInfo[];
export type LambdaFunctionArn = string;
export type LambdaExecutionRoleArn = string;
export interface CustomAccountPoolHandler {
    lambdaFunctionArn: string;
    lambdaExecutionRoleArn?: string | undefined;
}
export type AccountSource = {
    accounts: AccountInfo[];
    customAccountPoolHandler?: undefined;
} | {
    accounts?: undefined;
    customAccountPoolHandler: CustomAccountPoolHandler;
};
export interface CreateAccountPoolInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    resolutionStrategy: ResolutionStrategy;
    accountSource: AccountSource;
}
export type AccountPoolId = string;
export interface CreateAccountPoolOutput {
    domainId?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    id?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    resolutionStrategy?: ResolutionStrategy | undefined;
    accountSource: AccountSource;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    domainUnitId?: string | undefined;
}
export type AssetName = string | redacted.Redacted<string>;
export type ExternalIdentifier = string;
export type AssetTypeIdentifier = string;
export type GlossaryTerms = string[];
export interface BusinessNameGenerationConfiguration {
    enabled?: boolean | undefined;
}
export interface PredictionConfiguration {
    businessNameGeneration?: BusinessNameGenerationConfiguration | undefined;
}
export interface CreateAssetInput {
    name: string | redacted.Redacted<string>;
    domainIdentifier: string;
    externalIdentifier?: string | undefined;
    typeIdentifier: string;
    typeRevision?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    glossaryTerms?: string[] | undefined;
    formsInput?: FormInput[] | undefined;
    owningProjectIdentifier: string;
    predictionConfiguration?: PredictionConfiguration | undefined;
    clientToken?: string | undefined;
}
export type ListingStatus = "CREATING" | "ACTIVE" | "INACTIVE" | (string & {});
export interface AssetListingDetails {
    listingId: string;
    listingStatus: ListingStatus;
}
export type TimeSeriesFormName = string;
export type DataPointIdentifier = string;
export interface TimeSeriesDataPointSummaryFormOutput {
    formName: string;
    typeIdentifier: string;
    typeRevision?: string | undefined;
    timestamp: Date;
    contentSummary?: string | undefined;
    id?: string | undefined;
}
export type TimeSeriesDataPointSummaryFormOutputList = TimeSeriesDataPointSummaryFormOutput[];
export interface CreateAssetOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    typeIdentifier: string;
    typeRevision: string;
    externalIdentifier?: string | undefined;
    revision: string;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    firstRevisionCreatedAt?: Date | undefined;
    firstRevisionCreatedBy?: string | undefined;
    glossaryTerms?: string[] | undefined;
    governedGlossaryTerms?: string[] | undefined;
    owningProjectId: string;
    domainId: string;
    listing?: AssetListingDetails | undefined;
    formsOutput: FormOutput[];
    readOnlyFormsOutput?: FormOutput[] | undefined;
    latestTimeSeriesDataPointFormsOutput?: TimeSeriesDataPointSummaryFormOutput[] | undefined;
    predictionConfiguration?: PredictionConfiguration | undefined;
}
export type FilterName = string | redacted.Redacted<string>;
export type ColumnNameList = string[];
export interface ColumnFilterConfiguration {
    includedColumnNames?: string[] | undefined;
}
export interface EqualToExpression {
    columnName: string;
    value: string;
}
export interface NotEqualToExpression {
    columnName: string;
    value: string;
}
export interface GreaterThanExpression {
    columnName: string;
    value: string;
}
export interface LessThanExpression {
    columnName: string;
    value: string;
}
export interface GreaterThanOrEqualToExpression {
    columnName: string;
    value: string;
}
export interface LessThanOrEqualToExpression {
    columnName: string;
    value: string;
}
export interface IsNullExpression {
    columnName: string;
}
export interface IsNotNullExpression {
    columnName: string;
}
export type StringList = string[];
export interface InExpression {
    columnName: string;
    values: string[];
}
export interface NotInExpression {
    columnName: string;
    values: string[];
}
export interface LikeExpression {
    columnName: string;
    value: string;
}
export interface NotLikeExpression {
    columnName: string;
    value: string;
}
export type RowFilterExpression = {
    equalTo: EqualToExpression;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo: NotEqualToExpression;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan: GreaterThanExpression;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan: LessThanExpression;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo: GreaterThanOrEqualToExpression;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo: LessThanOrEqualToExpression;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull: IsNullExpression;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull: IsNotNullExpression;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in: InExpression;
    notIn?: undefined;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn: NotInExpression;
    like?: undefined;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like: LikeExpression;
    notLike?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    greaterThan?: undefined;
    lessThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThanOrEqualTo?: undefined;
    isNull?: undefined;
    isNotNull?: undefined;
    in?: undefined;
    notIn?: undefined;
    like?: undefined;
    notLike: NotLikeExpression;
};
export type RowFilterList = RowFilter[];
export type RowFilter = {
    expression: RowFilterExpression;
    and?: undefined;
    or?: undefined;
} | {
    expression?: undefined;
    and: RowFilter[];
    or?: undefined;
} | {
    expression?: undefined;
    and?: undefined;
    or: RowFilter[];
};
export interface RowFilterConfiguration {
    rowFilter: RowFilter;
    sensitive?: boolean | undefined;
}
export type AssetFilterConfiguration = {
    columnConfiguration: ColumnFilterConfiguration;
    rowConfiguration?: undefined;
} | {
    columnConfiguration?: undefined;
    rowConfiguration: RowFilterConfiguration;
};
export interface CreateAssetFilterInput {
    domainIdentifier: string;
    assetIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    configuration: AssetFilterConfiguration;
    clientToken?: string | undefined;
}
export type FilterStatus = "VALID" | "INVALID" | (string & {});
export interface CreateAssetFilterOutput {
    id: string;
    domainId: string;
    assetId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: FilterStatus | undefined;
    configuration: AssetFilterConfiguration;
    createdAt?: Date | undefined;
    errorMessage?: string | undefined;
    effectiveColumnNames?: string[] | undefined;
    effectiveRowFilter?: string | undefined;
}
export interface CreateAssetRevisionInput {
    name: string | redacted.Redacted<string>;
    domainIdentifier: string;
    identifier: string;
    typeRevision?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    glossaryTerms?: string[] | undefined;
    formsInput?: FormInput[] | undefined;
    predictionConfiguration?: PredictionConfiguration | undefined;
    clientToken?: string | undefined;
}
export interface CreateAssetRevisionOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    typeIdentifier: string;
    typeRevision: string;
    externalIdentifier?: string | undefined;
    revision: string;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    firstRevisionCreatedAt?: Date | undefined;
    firstRevisionCreatedBy?: string | undefined;
    glossaryTerms?: string[] | undefined;
    governedGlossaryTerms?: string[] | undefined;
    owningProjectId: string;
    domainId: string;
    listing?: AssetListingDetails | undefined;
    formsOutput: FormOutput[];
    readOnlyFormsOutput?: FormOutput[] | undefined;
    latestTimeSeriesDataPointFormsOutput?: TimeSeriesDataPointSummaryFormOutput[] | undefined;
    predictionConfiguration?: PredictionConfiguration | undefined;
}
export interface FormEntryInput {
    typeIdentifier: string;
    typeRevision: string;
    required?: boolean | undefined;
}
export type FormsInputMap = {
    [key: string]: FormEntryInput | undefined;
};
export interface CreateAssetTypeInput {
    domainIdentifier: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    formsInput: {
        [key: string]: FormEntryInput | undefined;
    };
    owningProjectIdentifier: string;
}
export interface FormEntryOutput {
    typeName: string | redacted.Redacted<string>;
    typeRevision: string;
    required?: boolean | undefined;
}
export type FormsOutputMap = {
    [key: string]: FormEntryOutput | undefined;
};
export interface CreateAssetTypeOutput {
    domainId: string;
    name: string;
    revision: string;
    description?: string | redacted.Redacted<string> | undefined;
    formsOutput: {
        [key: string]: FormEntryOutput | undefined;
    };
    owningProjectId?: string | undefined;
    originDomainId?: string | undefined;
    originProjectId?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
}
export type ConnectionId = string;
export interface AwsLocation {
    accessRole?: string | undefined;
    awsAccountId?: string | undefined;
    awsRegion?: string | undefined;
    iamConnectionId?: string | undefined;
}
export type PropertyMap = {
    [key: string]: string | undefined;
};
export interface Configuration {
    classification?: string | undefined;
    properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Configurations = Configuration[];
export type ConnectionName = string;
export interface AthenaPropertiesInput {
    workgroupName?: string | undefined;
}
export type ConnectionProperties = {
    [key: string]: string | undefined;
};
export type SubnetId = string;
export type SubnetIdList = string[];
export type SecurityGroupIdList = string[];
export interface PhysicalConnectionRequirements {
    subnetId?: string | undefined;
    subnetIdList?: string[] | undefined;
    securityGroupIdList?: string[] | undefined;
    availabilityZone?: string | undefined;
}
export type GlueConnectionType = "SNOWFLAKE" | "BIGQUERY" | "DOCUMENTDB" | "DYNAMODB" | "MYSQL" | "OPENSEARCH" | "ORACLE" | "POSTGRESQL" | "REDSHIFT" | "SAPHANA" | "SQLSERVER" | "TERADATA" | "VERTICA" | "ICEBERGRESTCATALOG" | "SNOWFLAKEICEBERGRESTCATALOG" | "DATABRICKSICEBERGRESTCATALOG" | "WORKDAYICEBERGRESTCATALOG" | "WORKDAYLDQ" | (string & {});
export type ComputeEnvironments = "SPARK" | "ATHENA" | "PYTHON" | (string & {});
export type ComputeEnvironmentsList = ComputeEnvironments[];
export type AuthenticationType = "BASIC" | "OAUTH2" | "CUSTOM" | (string & {});
export type OAuth2GrantType = "AUTHORIZATION_CODE" | "CLIENT_CREDENTIALS" | "JWT_BEARER" | (string & {});
export interface OAuth2ClientApplication {
    userManagedClientApplicationClientId?: string | undefined;
    aWSManagedClientApplicationReference?: string | undefined;
}
export type TokenUrlParametersMap = {
    [key: string]: string | undefined;
};
export interface AuthorizationCodeProperties {
    authorizationCode?: string | undefined;
    redirectUri?: string | undefined;
}
export interface GlueOAuth2Credentials {
    userManagedClientApplicationClientSecret?: string | undefined;
    accessToken?: string | undefined;
    refreshToken?: string | undefined;
    jwtToken?: string | undefined;
}
export interface OAuth2Properties {
    oAuth2GrantType?: OAuth2GrantType | undefined;
    oAuth2ClientApplication?: OAuth2ClientApplication | undefined;
    tokenUrl?: string | undefined;
    tokenUrlParametersMap?: {
        [key: string]: string | undefined;
    } | undefined;
    authorizationCodeProperties?: AuthorizationCodeProperties | undefined;
    oAuth2Credentials?: GlueOAuth2Credentials | undefined;
}
export interface BasicAuthenticationCredentials {
    userName?: string | undefined;
    password?: string | undefined;
}
export type CredentialMap = {
    [key: string]: string | undefined;
};
export interface AuthenticationConfigurationInput {
    authenticationType?: AuthenticationType | undefined;
    oAuth2Properties?: OAuth2Properties | undefined;
    secretArn?: string | undefined;
    kmsKeyArn?: string | undefined;
    basicAuthenticationCredentials?: BasicAuthenticationCredentials | undefined;
    customAuthenticationCredentials?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GlueConnectionInput {
    connectionProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    physicalConnectionRequirements?: PhysicalConnectionRequirements | undefined;
    name?: string | undefined;
    description?: string | undefined;
    connectionType?: GlueConnectionType | undefined;
    matchCriteria?: string | undefined;
    validateCredentials?: boolean | undefined;
    validateForComputeEnvironments?: ComputeEnvironments[] | undefined;
    sparkProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    athenaProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    pythonProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    authenticationConfiguration?: AuthenticationConfigurationInput | undefined;
}
export interface GluePropertiesInput {
    glueConnectionInput?: GlueConnectionInput | undefined;
}
export interface HyperPodPropertiesInput {
    clusterName: string;
}
export type RoleArn = string;
export interface IamPropertiesInput {
    glueLineageSyncEnabled?: boolean | undefined;
    roleArn?: string | undefined;
}
export type RedshiftStorageProperties = {
    clusterName: string;
    workgroupName?: undefined;
} | {
    clusterName?: undefined;
    workgroupName: string;
};
export type Password = string | redacted.Redacted<string>;
export type Username = string;
export interface UsernamePassword {
    password: string | redacted.Redacted<string>;
    username: string;
}
export type RedshiftCredentials = {
    secretArn: string;
    usernamePassword?: undefined;
} | {
    secretArn?: undefined;
    usernamePassword: UsernamePassword;
};
export interface LineageSyncSchedule {
    schedule?: string | undefined;
}
export interface RedshiftLineageSyncConfigurationInput {
    enabled?: boolean | undefined;
    schedule?: LineageSyncSchedule | undefined;
}
export interface RedshiftPropertiesInput {
    storage?: RedshiftStorageProperties | undefined;
    databaseName?: string | undefined;
    host?: string | undefined;
    port?: number | undefined;
    credentials?: RedshiftCredentials | undefined;
    lineageSync?: RedshiftLineageSyncConfigurationInput | undefined;
}
export interface SparkEmrPropertiesInput {
    computeArn?: string | undefined;
    instanceProfileArn?: string | undefined;
    javaVirtualEnv?: string | undefined;
    logUri?: string | undefined;
    pythonVirtualEnv?: string | undefined;
    runtimeRole?: string | undefined;
    trustedCertificatesS3Uri?: string | undefined;
    managedEndpointArn?: string | undefined;
}
export interface SparkGlueArgs {
    connection?: string | undefined;
}
export type GlueConnectionName = string;
export type GlueConnectionNames = string[];
export interface SparkGluePropertiesInput {
    additionalArgs?: SparkGlueArgs | undefined;
    glueConnectionName?: string | undefined;
    glueConnectionNames?: string[] | undefined;
    glueVersion?: string | undefined;
    idleTimeout?: number | undefined;
    javaVirtualEnv?: string | undefined;
    numberOfWorkers?: number | undefined;
    pythonVirtualEnv?: string | undefined;
    workerType?: string | undefined;
}
export type S3Uri = string;
export type S3AccessGrantLocationId = string;
export interface S3PropertiesInput {
    s3Uri: string;
    s3AccessGrantLocationId?: string | undefined;
    registerS3AccessGrantLocation?: boolean | undefined;
}
export interface ConnectivityProperties {
    connectionProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    physicalConnectionRequirements?: PhysicalConnectionRequirements | undefined;
    name?: string | undefined;
    description?: string | undefined;
    validateCredentials?: boolean | undefined;
    validateForComputeEnvironments?: ComputeEnvironments[] | undefined;
    sparkProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    athenaProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    pythonProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    authenticationConfiguration?: AuthenticationConfigurationInput | undefined;
}
export type SnowflakeRole = string;
export interface IdentityMapping {
    usernameAttribute: string;
    prefix?: string | undefined;
}
export type Timezone = "UTC" | "AFRICA_JOHANNESBURG" | "AMERICA_MONTREAL" | "AMERICA_SAO_PAULO" | "ASIA_BAHRAIN" | "ASIA_BANGKOK" | "ASIA_CALCUTTA" | "ASIA_DUBAI" | "ASIA_HONG_KONG" | "ASIA_JAKARTA" | "ASIA_KUALA_LUMPUR" | "ASIA_SEOUL" | "ASIA_SHANGHAI" | "ASIA_SINGAPORE" | "ASIA_TAIPEI" | "ASIA_TOKYO" | "AUSTRALIA_MELBOURNE" | "AUSTRALIA_SYDNEY" | "CANADA_CENTRAL" | "CET" | "CST6CDT" | "ETC_GMT" | "ETC_GMT0" | "ETC_GMT_ADD_0" | "ETC_GMT_ADD_1" | "ETC_GMT_ADD_10" | "ETC_GMT_ADD_11" | "ETC_GMT_ADD_12" | "ETC_GMT_ADD_2" | "ETC_GMT_ADD_3" | "ETC_GMT_ADD_4" | "ETC_GMT_ADD_5" | "ETC_GMT_ADD_6" | "ETC_GMT_ADD_7" | "ETC_GMT_ADD_8" | "ETC_GMT_ADD_9" | "ETC_GMT_NEG_0" | "ETC_GMT_NEG_1" | "ETC_GMT_NEG_10" | "ETC_GMT_NEG_11" | "ETC_GMT_NEG_12" | "ETC_GMT_NEG_13" | "ETC_GMT_NEG_14" | "ETC_GMT_NEG_2" | "ETC_GMT_NEG_3" | "ETC_GMT_NEG_4" | "ETC_GMT_NEG_5" | "ETC_GMT_NEG_6" | "ETC_GMT_NEG_7" | "ETC_GMT_NEG_8" | "ETC_GMT_NEG_9" | "EUROPE_DUBLIN" | "EUROPE_LONDON" | "EUROPE_PARIS" | "EUROPE_STOCKHOLM" | "EUROPE_ZURICH" | "ISRAEL" | "MEXICO_GENERAL" | "MST7MDT" | "PACIFIC_AUCKLAND" | "US_CENTRAL" | "US_EASTERN" | "US_MOUNTAIN" | "US_PACIFIC" | (string & {});
export type LineageSyncScheduleCronString = string;
export interface LineageSyncInput {
    timezone?: Timezone | undefined;
    enabled: boolean;
    schedule?: string | undefined;
}
export interface SnowflakePropertiesInput {
    connectivityProperties?: ConnectivityProperties | undefined;
    snowflakeRole: string;
    identityMapping: IdentityMapping;
    lineageSync?: LineageSyncInput | undefined;
}
export interface AmazonQPropertiesInput {
    isEnabled: boolean;
    profileArn?: string | undefined;
    authMode?: string | undefined;
}
export interface MlflowPropertiesInput {
    trackingServerArn?: string | undefined;
}
export interface WorkflowsMwaaPropertiesInput {
    mwaaEnvironmentName?: string | undefined;
}
export interface WorkflowsServerlessPropertiesInput {
}
export interface LakehousePropertiesInput {
    glueLineageSyncEnabled?: boolean | undefined;
}
export type VpcId = string;
export type VpcConnectionSubnetIdList = string[];
export type SecurityGroupId = string;
export interface VpcPropertiesInput {
    vpcId: string;
    subnetIds: string[];
    securityGroupId?: string | undefined;
}
export interface GitPropertiesInput {
    codeConnectionArn: string;
    repositoryId: string;
    defaultBranch: string;
}
export type ConnectionPropertiesInput = {
    athenaProperties: AthenaPropertiesInput;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties: GluePropertiesInput;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties: HyperPodPropertiesInput;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties: IamPropertiesInput;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties: RedshiftPropertiesInput;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties: SparkEmrPropertiesInput;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties: SparkGluePropertiesInput;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties: S3PropertiesInput;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties: SnowflakePropertiesInput;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties: AmazonQPropertiesInput;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties: MlflowPropertiesInput;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties: WorkflowsMwaaPropertiesInput;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties: WorkflowsServerlessPropertiesInput;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties: LakehousePropertiesInput;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties: VpcPropertiesInput;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties: GitPropertiesInput;
};
export type ConnectionScope = "DOMAIN" | "PROJECT" | (string & {});
export interface CreateConnectionInput {
    awsLocation?: AwsLocation | undefined;
    clientToken?: string | undefined;
    configurations?: Configuration[] | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    domainIdentifier: string;
    environmentIdentifier?: string | undefined;
    name: string;
    props?: ConnectionPropertiesInput | undefined;
    enableTrustedIdentityPropagation?: boolean | undefined;
    scope?: ConnectionScope | undefined;
}
export type ConnectionType = "ATHENA" | "BIGQUERY" | "DATABRICKS" | "DOCUMENTDB" | "DYNAMODB" | "HYPERPOD" | "IAM" | "MYSQL" | "OPENSEARCH" | "ORACLE" | "POSTGRESQL" | "REDSHIFT" | "S3" | "SAPHANA" | "SNOWFLAKE" | "SPARK" | "SQLSERVER" | "TERADATA" | "VERTICA" | "WORKFLOWS_MWAA" | "AMAZON_Q" | "MLFLOW" | "VPC" | "GIT" | "ICEBERGRESTCATALOG" | "SNOWFLAKEICEBERGRESTCATALOG" | "DATABRICKSICEBERGRESTCATALOG" | "WORKDAYICEBERGRESTCATALOG" | "WORKDAYLDQ" | (string & {});
export type MatchCriteria = string[];
export type ConnectionStatus = "CREATING" | "CREATE_FAILED" | "DELETING" | "DELETE_FAILED" | "READY" | "UPDATING" | "UPDATE_FAILED" | "DELETED" | (string & {});
export interface AuthenticationConfiguration {
    authenticationType?: AuthenticationType | undefined;
    secretArn?: string | undefined;
    oAuth2Properties?: OAuth2Properties | undefined;
}
export interface GlueConnection {
    name?: string | undefined;
    description?: string | undefined;
    connectionType?: ConnectionType | undefined;
    matchCriteria?: string[] | undefined;
    connectionProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    sparkProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    athenaProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    pythonProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    physicalConnectionRequirements?: PhysicalConnectionRequirements | undefined;
    creationTime?: Date | undefined;
    lastUpdatedTime?: Date | undefined;
    lastUpdatedBy?: string | undefined;
    status?: ConnectionStatus | undefined;
    statusReason?: string | undefined;
    lastConnectionValidationTime?: Date | undefined;
    authenticationConfiguration?: AuthenticationConfiguration | undefined;
    connectionSchemaVersion?: number | undefined;
    compatibleComputeEnvironments?: ComputeEnvironments[] | undefined;
}
export type Protocol = "ATHENA" | "GLUE_INTERACTIVE_SESSION" | "HTTPS" | "JDBC" | "LIVY" | "ODBC" | "PRISM" | (string & {});
export interface PhysicalEndpoint {
    awsLocation?: AwsLocation | undefined;
    glueConnectionName?: string | undefined;
    glueConnectionNames?: string[] | undefined;
    glueConnection?: GlueConnection | undefined;
    enableTrustedIdentityPropagation?: boolean | undefined;
    host?: string | undefined;
    port?: number | undefined;
    protocol?: Protocol | undefined;
    stage?: string | undefined;
}
export type PhysicalEndpoints = PhysicalEndpoint[];
export interface AthenaPropertiesOutput {
    workgroupName?: string | undefined;
}
export interface GluePropertiesOutput {
    status?: ConnectionStatus | undefined;
    errorMessage?: string | undefined;
}
export type HyperPodOrchestrator = "EKS" | "SLURM" | (string & {});
export interface HyperPodPropertiesOutput {
    clusterName: string;
    clusterArn?: string | undefined;
    orchestrator?: HyperPodOrchestrator | undefined;
}
export interface IamPropertiesOutput {
    environmentId?: string | undefined;
    glueLineageSyncEnabled?: boolean | undefined;
}
export interface RedshiftLineageSyncConfigurationOutput {
    lineageJobId?: string | undefined;
    enabled?: boolean | undefined;
    schedule?: LineageSyncSchedule | undefined;
}
export interface RedshiftPropertiesOutput {
    storage?: RedshiftStorageProperties | undefined;
    credentials?: RedshiftCredentials | undefined;
    isProvisionedSecret?: boolean | undefined;
    jdbcIamUrl?: string | undefined;
    jdbcUrl?: string | undefined;
    redshiftTempDir?: string | undefined;
    lineageSync?: RedshiftLineageSyncConfigurationOutput | undefined;
    status?: ConnectionStatus | undefined;
    databaseName?: string | undefined;
}
export type GovernanceType = "AWS_MANAGED" | "USER_MANAGED" | (string & {});
export interface ManagedEndpointCredentials {
    id?: string | undefined;
    token?: string | undefined;
}
export interface SparkEmrPropertiesOutput {
    computeArn?: string | undefined;
    credentials?: UsernamePassword | undefined;
    credentialsExpiration?: Date | undefined;
    governanceType?: GovernanceType | undefined;
    instanceProfileArn?: string | undefined;
    javaVirtualEnv?: string | undefined;
    livyEndpoint?: string | undefined;
    logUri?: string | undefined;
    pythonVirtualEnv?: string | undefined;
    runtimeRole?: string | undefined;
    trustedCertificatesS3Uri?: string | undefined;
    certificateData?: string | undefined;
    managedEndpointArn?: string | undefined;
    managedEndpointCredentials?: ManagedEndpointCredentials | undefined;
}
export interface SparkGluePropertiesOutput {
    additionalArgs?: SparkGlueArgs | undefined;
    glueConnectionName?: string | undefined;
    glueConnectionNames?: string[] | undefined;
    glueVersion?: string | undefined;
    idleTimeout?: number | undefined;
    javaVirtualEnv?: string | undefined;
    numberOfWorkers?: number | undefined;
    pythonVirtualEnv?: string | undefined;
    workerType?: string | undefined;
}
export interface S3PropertiesOutput {
    s3Uri: string;
    s3AccessGrantLocationId?: string | undefined;
    registerS3AccessGrantLocation?: boolean | undefined;
    status?: ConnectionStatus | undefined;
    errorMessage?: string | undefined;
}
export interface LineageSyncOutput {
    lineageJobId?: string | undefined;
    timezone?: Timezone | undefined;
    enabled?: boolean | undefined;
    schedule?: string | undefined;
}
export interface SnowflakePropertiesOutput {
    snowflakeRole: string;
    identityMapping: IdentityMapping;
    lineageSync: LineageSyncOutput;
    status: ConnectionStatus;
    errorMessage?: string | undefined;
}
export interface AmazonQPropertiesOutput {
    isEnabled: boolean;
    profileArn?: string | undefined;
    authMode?: string | undefined;
}
export interface MlflowPropertiesOutput {
    trackingServerArn?: string | undefined;
}
export interface WorkflowsMwaaPropertiesOutput {
    mwaaEnvironmentName?: string | undefined;
}
export interface WorkflowsServerlessPropertiesOutput {
}
export interface LakehousePropertiesOutput {
    glueLineageSyncEnabled?: boolean | undefined;
}
export interface VpcPropertiesOutput {
    vpcId: string;
    subnetIds: string[];
    status: ConnectionStatus;
    securityGroupId?: string | undefined;
    glueConnectionNames?: string[] | undefined;
}
export interface GitPropertiesOutput {
    codeConnectionArn: string;
    repositoryId: string;
    defaultBranch: string;
    status?: ConnectionStatus | undefined;
    errorMessage?: string | undefined;
}
export type ConnectionPropertiesOutput = {
    athenaProperties: AthenaPropertiesOutput;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties: GluePropertiesOutput;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties: HyperPodPropertiesOutput;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties: IamPropertiesOutput;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties: RedshiftPropertiesOutput;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties: SparkEmrPropertiesOutput;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties: SparkGluePropertiesOutput;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties: S3PropertiesOutput;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties: SnowflakePropertiesOutput;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties: AmazonQPropertiesOutput;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties: MlflowPropertiesOutput;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties: WorkflowsMwaaPropertiesOutput;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties: WorkflowsServerlessPropertiesOutput;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties: LakehousePropertiesOutput;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties: VpcPropertiesOutput;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    hyperPodProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    sparkGlueProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    workflowsMwaaProperties?: undefined;
    workflowsServerlessProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties: GitPropertiesOutput;
};
export interface CreateConnectionOutput {
    connectionId: string;
    configurations?: Configuration[] | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    domainId: string;
    domainUnitId: string;
    environmentId?: string | undefined;
    name: string;
    physicalEndpoints: PhysicalEndpoint[];
    projectId?: string | undefined;
    props?: ConnectionPropertiesOutput | undefined;
    type: ConnectionType;
    scope?: ConnectionScope | undefined;
}
export type DataProductName = string | redacted.Redacted<string>;
export type DataProductDescription = string | redacted.Redacted<string>;
export type DataProductItemType = "ASSET" | (string & {});
export type ItemGlossaryTerms = string[];
export interface DataProductItem {
    itemType: DataProductItemType;
    identifier: string;
    revision?: string | undefined;
    glossaryTerms?: string[] | undefined;
}
export type DataProductItems = DataProductItem[];
export interface CreateDataProductInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    owningProjectIdentifier: string;
    description?: string | redacted.Redacted<string> | undefined;
    glossaryTerms?: string[] | undefined;
    formsInput?: FormInput[] | undefined;
    items?: DataProductItem[] | undefined;
    clientToken?: string | undefined;
}
export type DataProductId = string;
export type DataProductStatus = "CREATED" | "CREATING" | "CREATE_FAILED" | (string & {});
export interface CreateDataProductOutput {
    domainId: string;
    id: string;
    revision: string;
    owningProjectId: string;
    name: string | redacted.Redacted<string>;
    status: DataProductStatus;
    description?: string | redacted.Redacted<string> | undefined;
    glossaryTerms?: string[] | undefined;
    items?: DataProductItem[] | undefined;
    formsOutput?: FormOutput[] | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    firstRevisionCreatedAt?: Date | undefined;
    firstRevisionCreatedBy?: string | undefined;
}
export interface CreateDataProductRevisionInput {
    domainIdentifier: string;
    identifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    glossaryTerms?: string[] | undefined;
    items?: DataProductItem[] | undefined;
    formsInput?: FormInput[] | undefined;
    clientToken?: string | undefined;
}
export interface CreateDataProductRevisionOutput {
    domainId: string;
    id: string;
    revision: string;
    owningProjectId: string;
    name: string | redacted.Redacted<string>;
    status: DataProductStatus;
    description?: string | redacted.Redacted<string> | undefined;
    glossaryTerms?: string[] | undefined;
    items?: DataProductItem[] | undefined;
    formsOutput?: FormOutput[] | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    firstRevisionCreatedAt?: Date | undefined;
    firstRevisionCreatedBy?: string | undefined;
}
export type Name = string | redacted.Redacted<string>;
export type DataSourceType = string;
export type FilterExpressionType = "INCLUDE" | "EXCLUDE" | (string & {});
export interface FilterExpression {
    type: FilterExpressionType;
    expression: string;
}
export type FilterExpressions = FilterExpression[];
export interface RelationalFilterConfiguration {
    databaseName: string;
    schemaName?: string | undefined;
    filterExpressions?: FilterExpression[] | undefined;
}
export type RelationalFilterConfigurations = RelationalFilterConfiguration[];
export interface GlueRunConfigurationInput {
    dataAccessRole?: string | undefined;
    relationalFilterConfigurations: RelationalFilterConfiguration[];
    autoImportDataQualityResult?: boolean | undefined;
    catalogName?: string | undefined;
}
export interface RedshiftCredentialConfiguration {
    secretManagerArn: string;
}
export interface RedshiftClusterStorage {
    clusterName: string;
}
export interface RedshiftServerlessStorage {
    workgroupName: string;
}
export type RedshiftStorage = {
    redshiftClusterSource: RedshiftClusterStorage;
    redshiftServerlessSource?: undefined;
} | {
    redshiftClusterSource?: undefined;
    redshiftServerlessSource: RedshiftServerlessStorage;
};
export interface RedshiftRunConfigurationInput {
    dataAccessRole?: string | undefined;
    relationalFilterConfigurations: RelationalFilterConfiguration[];
    redshiftCredentialConfiguration?: RedshiftCredentialConfiguration | undefined;
    redshiftStorage?: RedshiftStorage | undefined;
}
export type SageMakerAssetType = string;
export type SageMakerResourceArn = string;
export type TrackingAssetArns = string[];
export type TrackingAssets = {
    [key: string]: string[] | undefined;
};
export interface SageMakerRunConfigurationInput {
    trackingAssets: {
        [key: string]: string[] | undefined;
    };
}
export type DataSourceConfigurationInput = {
    glueRunConfiguration: GlueRunConfigurationInput;
    redshiftRunConfiguration?: undefined;
    sageMakerRunConfiguration?: undefined;
} | {
    glueRunConfiguration?: undefined;
    redshiftRunConfiguration: RedshiftRunConfigurationInput;
    sageMakerRunConfiguration?: undefined;
} | {
    glueRunConfiguration?: undefined;
    redshiftRunConfiguration?: undefined;
    sageMakerRunConfiguration: SageMakerRunConfigurationInput;
};
export interface RecommendationConfiguration {
    enableBusinessNameGeneration?: boolean | undefined;
}
export type EnableSetting = "ENABLED" | "DISABLED" | (string & {});
export type CronString = string;
export interface ScheduleConfiguration {
    timezone?: Timezone | undefined;
    schedule?: string | undefined;
}
export interface CreateDataSourceInput {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    domainIdentifier: string;
    projectIdentifier: string;
    environmentIdentifier?: string | undefined;
    connectionIdentifier?: string | undefined;
    type: string;
    configuration?: DataSourceConfigurationInput | undefined;
    recommendation?: RecommendationConfiguration | undefined;
    enableSetting?: EnableSetting | undefined;
    schedule?: ScheduleConfiguration | undefined;
    publishOnImport?: boolean | undefined;
    assetFormsInput?: FormInput[] | undefined;
    clientToken?: string | undefined;
}
export type DataSourceId = string;
export type DataSourceStatus = "CREATING" | "FAILED_CREATION" | "READY" | "UPDATING" | "FAILED_UPDATE" | "RUNNING" | "DELETING" | "FAILED_DELETION" | (string & {});
export interface GlueRunConfigurationOutput {
    accountId?: string | undefined;
    region?: string | undefined;
    dataAccessRole?: string | undefined;
    relationalFilterConfigurations: RelationalFilterConfiguration[];
    autoImportDataQualityResult?: boolean | undefined;
    catalogName?: string | undefined;
}
export interface RedshiftRunConfigurationOutput {
    accountId?: string | undefined;
    region?: string | undefined;
    dataAccessRole?: string | undefined;
    relationalFilterConfigurations: RelationalFilterConfiguration[];
    redshiftCredentialConfiguration?: RedshiftCredentialConfiguration | undefined;
    redshiftStorage: RedshiftStorage;
}
export interface SageMakerRunConfigurationOutput {
    accountId?: string | undefined;
    region?: string | undefined;
    trackingAssets: {
        [key: string]: string[] | undefined;
    };
}
export type DataSourceConfigurationOutput = {
    glueRunConfiguration: GlueRunConfigurationOutput;
    redshiftRunConfiguration?: undefined;
    sageMakerRunConfiguration?: undefined;
} | {
    glueRunConfiguration?: undefined;
    redshiftRunConfiguration: RedshiftRunConfigurationOutput;
    sageMakerRunConfiguration?: undefined;
} | {
    glueRunConfiguration?: undefined;
    redshiftRunConfiguration?: undefined;
    sageMakerRunConfiguration: SageMakerRunConfigurationOutput;
};
export type DataSourceRunStatus = "REQUESTED" | "RUNNING" | "FAILED" | "PARTIALLY_SUCCEEDED" | "SUCCESS" | (string & {});
export type DataSourceErrorType = "ACCESS_DENIED_EXCEPTION" | "CONFLICT_EXCEPTION" | "INTERNAL_SERVER_EXCEPTION" | "RESOURCE_NOT_FOUND_EXCEPTION" | "SERVICE_QUOTA_EXCEEDED_EXCEPTION" | "THROTTLING_EXCEPTION" | "VALIDATION_EXCEPTION" | (string & {});
export interface DataSourceErrorMessage {
    errorType: DataSourceErrorType;
    errorDetail?: string | undefined;
}
export interface CreateDataSourceOutput {
    id: string;
    status?: DataSourceStatus | undefined;
    type?: string | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    domainId: string;
    projectId: string;
    environmentId?: string | undefined;
    connectionId?: string | undefined;
    configuration?: DataSourceConfigurationOutput | undefined;
    recommendation?: RecommendationConfiguration | undefined;
    enableSetting?: EnableSetting | undefined;
    publishOnImport?: boolean | undefined;
    assetFormsOutput?: FormOutput[] | undefined;
    schedule?: ScheduleConfiguration | undefined;
    lastRunStatus?: DataSourceRunStatus | undefined;
    lastRunAt?: Date | undefined;
    lastRunErrorMessage?: DataSourceErrorMessage | undefined;
    errorMessage?: DataSourceErrorMessage | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type DesignationName = string;
export type CedarDesignationPolicy = string;
export interface CreateDesignationInput {
    domainIdentifier: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    policy: string;
    deletionProtection?: boolean | undefined;
}
export type DesignationType = "MANAGED" | "USER_CREATED" | (string & {});
export interface CreateDesignationOutput {
    domainId: string;
    id: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    designationType: DesignationType;
    policy: string;
    deletionProtection: boolean;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type AuthType = "IAM_IDC" | "DISABLED" | (string & {});
export type UserAssignment = "AUTOMATIC" | "MANUAL" | (string & {});
export interface SingleSignOn {
    type?: AuthType | undefined;
    userAssignment?: UserAssignment | undefined;
    idcInstanceArn?: string | undefined;
}
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type DomainVersion = "V1" | "V2" | (string & {});
export interface CreateDomainInput {
    name: string;
    description?: string | undefined;
    singleSignOn?: SingleSignOn | undefined;
    domainExecutionRole?: string | undefined;
    kmsKeyIdentifier?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    domainVersion?: DomainVersion | undefined;
    serviceRole?: string | undefined;
    clientToken?: string | undefined;
}
export type DomainStatus = "CREATING" | "AVAILABLE" | "CREATION_FAILED" | "DELETING" | "DELETED" | "DELETION_FAILED" | (string & {});
export interface CreateDomainOutput {
    id: string;
    rootDomainUnitId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    singleSignOn?: SingleSignOn | undefined;
    domainExecutionRole?: string | undefined;
    arn?: string | undefined;
    kmsKeyIdentifier?: string | undefined;
    status?: DomainStatus | undefined;
    portalUrl?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    domainVersion?: DomainVersion | undefined;
    serviceRole?: string | undefined;
}
export type DomainUnitName = string | redacted.Redacted<string>;
export type DomainUnitDescription = string | redacted.Redacted<string>;
export interface CreateDomainUnitInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    parentDomainUnitIdentifier: string;
    description?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
}
export interface DomainUnitUserProperties {
    userId?: string | undefined;
}
export interface DomainUnitGroupProperties {
    groupId?: string | undefined;
}
export type DomainUnitOwnerProperties = {
    user: DomainUnitUserProperties;
    group?: undefined;
} | {
    user?: undefined;
    group: DomainUnitGroupProperties;
};
export type DomainUnitOwners = DomainUnitOwnerProperties[];
export type DomainUnitIds = string[];
export interface CreateDomainUnitOutput {
    id: string;
    domainId: string;
    name: string | redacted.Redacted<string>;
    parentDomainUnitId?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    owners: DomainUnitOwnerProperties[];
    ancestorDomainUnitIds: string[];
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
}
export type EnvironmentProfileId = string;
export interface EnvironmentParameter {
    name?: string | undefined;
    value?: string | undefined;
}
export type EnvironmentParametersList = EnvironmentParameter[];
export type EnvironmentConfigurationName = string | redacted.Redacted<string>;
export interface CreateEnvironmentInput {
    projectIdentifier: string;
    domainIdentifier: string;
    description?: string | undefined;
    name: string;
    environmentProfileIdentifier?: string | undefined;
    userParameters?: EnvironmentParameter[] | undefined;
    glossaryTerms?: string[] | undefined;
    environmentAccountIdentifier?: string | undefined;
    environmentAccountRegion?: string | undefined;
    environmentBlueprintIdentifier?: string | undefined;
    deploymentOrder?: number | undefined;
    environmentConfigurationId?: string | undefined;
    environmentConfigurationName?: string | redacted.Redacted<string> | undefined;
}
export type EnvironmentName = string | redacted.Redacted<string>;
export interface Resource {
    provider?: string | undefined;
    name?: string | undefined;
    value: string;
    type: string;
}
export type ResourceList = Resource[];
export type EnvironmentStatus = "ACTIVE" | "CREATING" | "UPDATING" | "DELETING" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETE_FAILED" | "VALIDATION_FAILED" | "SUSPENDED" | "DISABLED" | "EXPIRED" | "DELETED" | "INACCESSIBLE" | (string & {});
export type ConfigurableActionTypeAuthorization = "IAM" | "HTTPS" | (string & {});
export interface ConfigurableActionParameter {
    key?: string | undefined;
    value?: string | undefined;
}
export type ConfigurableActionParameterList = ConfigurableActionParameter[];
export interface ConfigurableEnvironmentAction {
    type: string;
    auth?: ConfigurableActionTypeAuthorization | undefined;
    parameters: ConfigurableActionParameter[];
}
export type EnvironmentActionList = ConfigurableEnvironmentAction[];
export interface CustomParameter {
    keyName: string;
    description?: string | redacted.Redacted<string> | undefined;
    fieldType: string;
    defaultValue?: string | undefined;
    isEditable?: boolean | undefined;
    isOptional?: boolean | undefined;
    isUpdateSupported?: boolean | undefined;
}
export type CustomParameterList = CustomParameter[];
export type DeploymentType = "CREATE" | "UPDATE" | "DELETE" | (string & {});
export type DeploymentStatus = "IN_PROGRESS" | "SUCCESSFUL" | "FAILED" | "PENDING_DEPLOYMENT" | (string & {});
export interface EnvironmentError {
    code?: string | undefined;
    message: string;
}
export type DeploymentMessage = string;
export type DeploymentMessagesList = string[];
export interface Deployment {
    deploymentId?: string | undefined;
    deploymentType?: DeploymentType | undefined;
    deploymentStatus?: DeploymentStatus | undefined;
    failureReason?: EnvironmentError | undefined;
    messages?: string[] | undefined;
    isDeploymentComplete?: boolean | undefined;
}
export interface CloudFormationProperties {
    templateUrl: string;
}
export type ProvisioningProperties = {
    cloudFormation: CloudFormationProperties;
    manual?: undefined;
} | {
    cloudFormation?: undefined;
    manual: Record<string, never>;
};
export interface DeploymentProperties {
    startTimeoutMinutes?: number | undefined;
    endTimeoutMinutes?: number | undefined;
}
export type EnvironmentBlueprintId = string;
export type EnvironmentConfigurationId = string | redacted.Redacted<string>;
export interface CreateEnvironmentOutput {
    projectId: string;
    id?: string | undefined;
    domainId: string;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentProfileId?: string | undefined;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    provider: string;
    provisionedResources?: Resource[] | undefined;
    status?: EnvironmentStatus | undefined;
    environmentActions?: ConfigurableEnvironmentAction[] | undefined;
    glossaryTerms?: string[] | undefined;
    userParameters?: CustomParameter[] | undefined;
    lastDeployment?: Deployment | undefined;
    provisioningProperties?: ProvisioningProperties | undefined;
    deploymentProperties?: DeploymentProperties | undefined;
    environmentBlueprintId?: string | undefined;
    environmentConfigurationId?: string | redacted.Redacted<string> | undefined;
    environmentConfigurationName?: string | redacted.Redacted<string> | undefined;
}
export interface AwsConsoleLinkParameters {
    uri?: string | undefined;
}
export type ActionParameters = {
    awsConsoleLink: AwsConsoleLinkParameters;
};
export interface CreateEnvironmentActionInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    name: string;
    parameters: ActionParameters;
    description?: string | undefined;
}
export type EnvironmentActionId = string;
export interface CreateEnvironmentActionOutput {
    domainId: string;
    environmentId: string;
    id: string;
    name: string;
    parameters: ActionParameters;
    description?: string | undefined;
}
export type EnvironmentBlueprintName = string;
export type BlueprintCategory = "TOOLING" | (string & {});
export interface CreateEnvironmentBlueprintInput {
    domainIdentifier: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    provisioningProperties: ProvisioningProperties;
    userParameters?: CustomParameter[] | undefined;
    blueprintCategory?: BlueprintCategory | undefined;
}
export interface CreateEnvironmentBlueprintOutput {
    id: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    provider: string;
    provisioningProperties: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties | undefined;
    userParameters?: CustomParameter[] | undefined;
    glossaryTerms?: string[] | undefined;
    blueprintCategory?: BlueprintCategory | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type EnvironmentProfileName = string | redacted.Redacted<string>;
export interface CreateEnvironmentProfileInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentBlueprintIdentifier: string;
    projectIdentifier: string;
    userParameters?: EnvironmentParameter[] | undefined;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
}
export interface CreateEnvironmentProfileOutput {
    id: string;
    domainId: string;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentBlueprintId: string;
    projectId?: string | undefined;
    userParameters?: CustomParameter[] | undefined;
}
export type Smithy = string;
export type Model = {
    smithy: string;
};
export type FormTypeStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CreateFormTypeInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    model: Model;
    owningProjectIdentifier: string;
    status?: FormTypeStatus | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface CreateFormTypeOutput {
    domainId: string;
    name: string | redacted.Redacted<string>;
    revision: string;
    description?: string | redacted.Redacted<string> | undefined;
    owningProjectId?: string | undefined;
    originDomainId?: string | undefined;
    originProjectId?: string | undefined;
}
export type GlossaryName = string | redacted.Redacted<string>;
export type GlossaryDescription = string | redacted.Redacted<string>;
export type GlossaryStatus = "DISABLED" | "ENABLED" | (string & {});
export type GlossaryUsageRestriction = "ASSET_GOVERNED_TERMS" | (string & {});
export type GlossaryUsageRestrictions = GlossaryUsageRestriction[];
export interface CreateGlossaryInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    owningProjectIdentifier: string;
    description?: string | redacted.Redacted<string> | undefined;
    status?: GlossaryStatus | undefined;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
    clientToken?: string | undefined;
}
export type GlossaryId = string;
export interface CreateGlossaryOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    description?: string | redacted.Redacted<string> | undefined;
    status?: GlossaryStatus | undefined;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
}
export type GlossaryTermStatus = "ENABLED" | "DISABLED" | (string & {});
export type LongDescription = string | redacted.Redacted<string>;
export interface TermRelations {
    isA?: string[] | undefined;
    classifies?: string[] | undefined;
}
export interface CreateGlossaryTermInput {
    domainIdentifier: string;
    glossaryIdentifier: string;
    name: string | redacted.Redacted<string>;
    status?: GlossaryTermStatus | undefined;
    shortDescription?: string | redacted.Redacted<string> | undefined;
    longDescription?: string | redacted.Redacted<string> | undefined;
    termRelations?: TermRelations | undefined;
    clientToken?: string | undefined;
}
export interface CreateGlossaryTermOutput {
    id: string;
    domainId: string;
    glossaryId: string;
    name: string | redacted.Redacted<string>;
    status: GlossaryTermStatus;
    shortDescription?: string | redacted.Redacted<string> | undefined;
    longDescription?: string | redacted.Redacted<string> | undefined;
    termRelations?: TermRelations | undefined;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
}
export interface CreateGroupProfileInput {
    domainIdentifier: string;
    groupIdentifier?: string | undefined;
    rolePrincipalArn?: string | undefined;
    clientToken?: string | undefined;
}
export type GroupProfileStatus = "ASSIGNED" | "NOT_ASSIGNED" | (string & {});
export interface CreateGroupProfileOutput {
    domainId?: string | undefined;
    id?: string | undefined;
    status?: GroupProfileStatus | undefined;
    groupName?: string | redacted.Redacted<string> | undefined;
    rolePrincipalArn?: string | undefined;
    rolePrincipalId?: string | undefined;
}
export type EntityType = "ASSET" | "DATA_PRODUCT" | (string & {});
export type ChangeAction = "PUBLISH" | "UNPUBLISH" | (string & {});
export interface CreateListingChangeSetInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: EntityType;
    entityRevision?: string | undefined;
    action: ChangeAction;
    clientToken?: string | undefined;
}
export interface CreateListingChangeSetOutput {
    listingId: string;
    listingRevision: string;
    status: ListingStatus;
}
export type NotebookName = string | redacted.Redacted<string>;
export type NotebookType = "DATA" | "SQL" | (string & {});
export type MetadataKey = string;
export type MetadataValue = string | redacted.Redacted<string>;
export type Metadata = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type ParameterKey = string;
export type ParameterValue = string;
export type Parameters = {
    [key: string]: string | undefined;
};
export interface CreateNotebookInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    type?: NotebookType | undefined;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export type NotebookId = string;
export interface CellInformation {
}
export type CellOrder = CellInformation[];
export type NotebookStatus = "ACTIVE" | "ARCHIVED" | "SYNC_IN_PROGRESS" | "SYNC_FAILED" | (string & {});
export type ComputeId = string;
export type PackageManager = "UV" | (string & {});
export interface PackageConfig {
    packageManager: PackageManager;
    packageSpecification?: string | undefined;
}
export interface EnvironmentConfig {
    imageVersion?: string | undefined;
    packageConfig?: PackageConfig | undefined;
}
export interface NotebookError {
    message: string;
}
export type GitConnectionId = string;
export type GitRepository = string | redacted.Redacted<string>;
export type GitBranch = string | redacted.Redacted<string>;
export type CommitHash = string;
export type FileName = string;
export type CommitMessage = string | redacted.Redacted<string>;
export interface GitMetadata {
    connectionId: string;
    repository: string | redacted.Redacted<string>;
    branch: string | redacted.Redacted<string>;
    commitHash: string;
    fileName?: string | undefined;
    committedAt?: Date | undefined;
    commitMessage?: string | redacted.Redacted<string> | undefined;
}
export interface CreateNotebookOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    domainId: string;
    cellOrder: CellInformation[];
    status: NotebookStatus;
    type?: NotebookType | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    lockedBy?: string | undefined;
    lockedAt?: Date | undefined;
    lockExpiresAt?: Date | undefined;
    computeId?: string | undefined;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    environmentConfiguration?: EnvironmentConfig | undefined;
    error?: NotebookError | undefined;
    gitMetadata?: GitMetadata | undefined;
}
export type ProjectProfileId = string;
export interface EnvironmentResolvedAccount {
    awsAccountId: string;
    regionName: string;
    sourceAccountPoolId?: string | undefined;
}
export interface EnvironmentConfigurationUserParameter {
    environmentId?: string | undefined;
    environmentResolvedAccount?: EnvironmentResolvedAccount | undefined;
    environmentConfigurationName?: string | redacted.Redacted<string> | undefined;
    environmentParameters?: EnvironmentParameter[] | undefined;
}
export type EnvironmentConfigurationUserParametersList = EnvironmentConfigurationUserParameter[];
export type Member = {
    userIdentifier: string;
    groupIdentifier?: undefined;
} | {
    userIdentifier?: undefined;
    groupIdentifier: string;
};
export type UserDesignation = "PROJECT_OWNER" | "PROJECT_CONTRIBUTOR" | "PROJECT_CATALOG_VIEWER" | "PROJECT_CATALOG_CONSUMER" | "PROJECT_CATALOG_STEWARD" | "USER_CREATED_DESIGNATION" | (string & {});
export interface ProjectMembershipAssignment {
    member: Member;
    designation: UserDesignation;
    userCreatedDesignationId?: string | undefined;
}
export type ProjectMembershipAssignments = ProjectMembershipAssignment[];
export interface CreateProjectInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    glossaryTerms?: string[] | undefined;
    domainUnitId?: string | undefined;
    projectProfileId?: string | undefined;
    userParameters?: EnvironmentConfigurationUserParameter[] | undefined;
    projectCategory?: string | undefined;
    projectExecutionRole?: string | undefined;
    membershipAssignments?: ProjectMembershipAssignment[] | undefined;
}
export type ProjectStatus = "ACTIVE" | "DELETING" | "DELETE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "MOVING" | (string & {});
export interface ProjectDeletionError {
    code?: string | undefined;
    message?: string | undefined;
}
export type FailureReasons = ProjectDeletionError[];
export type ResourceTagSource = "PROJECT" | "PROJECT_PROFILE" | (string & {});
export interface ResourceTag {
    key: string;
    value: string;
    source: ResourceTagSource;
}
export type ResourceTags = ResourceTag[];
export type OverallDeploymentStatus = "PENDING_DEPLOYMENT" | "IN_PROGRESS" | "SUCCESSFUL" | "FAILED_VALIDATION" | "FAILED_DEPLOYMENT" | (string & {});
export type EnvironmentFailureReasonsList = EnvironmentError[];
export type EnvironmentFailureReasons = {
    [key: string]: EnvironmentError[] | undefined;
};
export interface EnvironmentDeploymentDetails {
    overallDeploymentStatus?: OverallDeploymentStatus | undefined;
    environmentFailureReasons?: {
        [key: string]: EnvironmentError[] | undefined;
    } | undefined;
}
export interface CreateProjectOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    projectStatus?: ProjectStatus | undefined;
    failureReasons?: ProjectDeletionError[] | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    resourceTags?: ResourceTag[] | undefined;
    glossaryTerms?: string[] | undefined;
    domainUnitId?: string | undefined;
    projectProfileId?: string | undefined;
    userParameters?: EnvironmentConfigurationUserParameter[] | undefined;
    environmentDeploymentDetails?: EnvironmentDeploymentDetails | undefined;
    projectCategory?: string | undefined;
}
export interface CreateProjectMembershipInput {
    domainIdentifier: string;
    projectIdentifier: string;
    member: Member;
    designation: UserDesignation;
    userCreatedDesignationId?: string | undefined;
}
export interface CreateProjectMembershipOutput {
}
export type ProjectProfileName = string | redacted.Redacted<string>;
export type Status = "ENABLED" | "DISABLED" | (string & {});
export interface ResourceTagParameter {
    key: string;
    value: string;
    isValueEditable: boolean;
}
export type ProjectResourceTagParameters = ResourceTagParameter[];
export type DeploymentMode = "ON_CREATE" | "ON_DEMAND" | (string & {});
export type ParameterStorePath = string;
export type EnvironmentConfigurationParameterName = string;
export interface EnvironmentConfigurationParameter {
    name?: string | undefined;
    value?: string | undefined;
    isEditable?: boolean | undefined;
}
export type EnvironmentConfigurationParametersList = EnvironmentConfigurationParameter[];
export interface EnvironmentConfigurationParametersDetails {
    ssmPath?: string | undefined;
    parameterOverrides?: EnvironmentConfigurationParameter[] | undefined;
    resolvedParameters?: EnvironmentConfigurationParameter[] | undefined;
}
export type AwsAccount = {
    awsAccountId: string;
    awsAccountIdPath?: undefined;
} | {
    awsAccountId?: undefined;
    awsAccountIdPath: string;
};
export type AccountPoolList = string[];
export type RegionName = string;
export type Region = {
    regionName: string;
    regionNamePath?: undefined;
} | {
    regionName?: undefined;
    regionNamePath: string;
};
export type DeploymentOrder = number;
export interface EnvironmentConfiguration {
    name: string | redacted.Redacted<string>;
    id?: string | redacted.Redacted<string> | undefined;
    environmentBlueprintId: string;
    description?: string | redacted.Redacted<string> | undefined;
    deploymentMode?: DeploymentMode | undefined;
    configurationParameters?: EnvironmentConfigurationParametersDetails | undefined;
    awsAccount?: AwsAccount | undefined;
    accountPools?: string[] | undefined;
    awsRegion?: Region | undefined;
    deploymentOrder?: number | undefined;
}
export type EnvironmentConfigurationsList = EnvironmentConfiguration[];
export interface CreateProjectProfileInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: Status | undefined;
    projectResourceTags?: ResourceTagParameter[] | undefined;
    allowCustomProjectResourceTags?: boolean | undefined;
    projectResourceTagsDescription?: string | redacted.Redacted<string> | undefined;
    environmentConfigurations?: EnvironmentConfiguration[] | undefined;
    domainUnitIdentifier?: string | undefined;
}
export interface CreateProjectProfileOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: Status | undefined;
    projectResourceTags?: ResourceTagParameter[] | undefined;
    allowCustomProjectResourceTags?: boolean | undefined;
    projectResourceTagsDescription?: string | redacted.Redacted<string> | undefined;
    environmentConfigurations?: EnvironmentConfiguration[] | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    domainUnitId?: string | undefined;
}
export type RuleName = string | redacted.Redacted<string>;
export interface DomainUnitTarget {
    domainUnitId: string;
    includeChildDomainUnits?: boolean | undefined;
}
export type RuleTarget = {
    domainUnitTarget: DomainUnitTarget;
};
export type RuleAction = "CREATE_LISTING_CHANGE_SET" | "CREATE_SUBSCRIPTION_REQUEST" | (string & {});
export type RuleScopeSelectionMode = "ALL" | "SPECIFIC" | (string & {});
export type RuleAssetTypeList = string[];
export interface AssetTypesForRule {
    selectionMode: RuleScopeSelectionMode;
    specificAssetTypes?: string[] | undefined;
}
export type RuleProjectIdentifierList = string[];
export interface ProjectsForRule {
    selectionMode: RuleScopeSelectionMode;
    specificProjects?: string[] | undefined;
}
export interface RuleScope {
    assetType?: AssetTypesForRule | undefined;
    dataProduct?: boolean | undefined;
    project?: ProjectsForRule | undefined;
}
export interface MetadataFormReference {
    typeIdentifier: string;
    typeRevision: string;
}
export type RequiredMetadataFormList = MetadataFormReference[];
export interface MetadataFormEnforcementDetail {
    requiredMetadataForms?: MetadataFormReference[] | undefined;
}
export type GlossaryTermIdentifiers = string[];
export interface GlossaryTermEnforcementDetail {
    requiredGlossaryTermIds?: string[] | undefined;
}
export type RuleDetail = {
    metadataFormEnforcementDetail: MetadataFormEnforcementDetail;
    glossaryTermEnforcementDetail?: undefined;
} | {
    metadataFormEnforcementDetail?: undefined;
    glossaryTermEnforcementDetail: GlossaryTermEnforcementDetail;
};
export interface CreateRuleInput {
    domainIdentifier: string;
    name: string | redacted.Redacted<string>;
    target: RuleTarget;
    action: RuleAction;
    scope: RuleScope;
    detail: RuleDetail;
    description?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
}
export type RuleId = string;
export type RuleType = "METADATA_FORM_ENFORCEMENT" | "GLOSSARY_TERM_ENFORCEMENT" | (string & {});
export type RuleTargetType = "DOMAIN_UNIT" | (string & {});
export interface CreateRuleOutput {
    identifier: string;
    name: string | redacted.Redacted<string>;
    ruleType: RuleType;
    target: RuleTarget;
    action: RuleAction;
    scope: RuleScope;
    detail: RuleDetail;
    targetType?: RuleTargetType | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt: Date;
    createdBy: string;
}
export type SubscriptionTargetId = string;
export interface ListingRevisionInput {
    identifier: string;
    revision: string;
}
export type GrantedEntityInput = {
    listing: ListingRevisionInput;
};
export interface AssetTargetNameMap {
    assetId: string;
    targetName: string;
}
export type AssetTargetNames = AssetTargetNameMap[];
export interface CreateSubscriptionGrantInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    subscriptionTargetIdentifier?: string | undefined;
    grantedEntity: GrantedEntityInput;
    assetTargetNames?: AssetTargetNameMap[] | undefined;
    clientToken?: string | undefined;
}
export type SubscriptionGrantId = string;
export interface ListingRevision {
    id: string;
    revision: string;
}
export type GrantedEntity = {
    listing: ListingRevision;
};
export type SubscriptionGrantOverallStatus = "PENDING" | "IN_PROGRESS" | "GRANT_FAILED" | "REVOKE_FAILED" | "GRANT_AND_REVOKE_FAILED" | "COMPLETED" | "INACCESSIBLE" | (string & {});
export type SubscriptionGrantStatus = "GRANT_PENDING" | "REVOKE_PENDING" | "GRANT_IN_PROGRESS" | "REVOKE_IN_PROGRESS" | "GRANTED" | "REVOKED" | "GRANT_FAILED" | "REVOKE_FAILED" | (string & {});
export interface FailureCause {
    message?: string | undefined;
}
export interface SubscribedAsset {
    assetId: string;
    assetRevision: string;
    status: SubscriptionGrantStatus;
    targetName?: string | undefined;
    failureCause?: FailureCause | undefined;
    grantedTimestamp?: Date | undefined;
    failureTimestamp?: Date | undefined;
    assetScope?: AssetScope | undefined;
    permissions?: Permissions | undefined;
}
export type SubscribedAssets = SubscribedAsset[];
export interface CreateSubscriptionGrantOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string | undefined;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[] | undefined;
    subscriptionId?: string | undefined;
}
export interface SubscribedProjectInput {
    identifier?: string | undefined;
}
export interface SubscribedUserInput {
    identifier?: string | undefined;
}
export interface SubscribedGroupInput {
    identifier?: string | undefined;
}
export interface SubscribedIamPrincipalInput {
    identifier?: string | undefined;
}
export type SubscribedPrincipalInput = {
    project: SubscribedProjectInput;
    user?: undefined;
    group?: undefined;
    iam?: undefined;
} | {
    project?: undefined;
    user: SubscribedUserInput;
    group?: undefined;
    iam?: undefined;
} | {
    project?: undefined;
    user?: undefined;
    group: SubscribedGroupInput;
    iam?: undefined;
} | {
    project?: undefined;
    user?: undefined;
    group?: undefined;
    iam: SubscribedIamPrincipalInput;
};
export type SubscribedPrincipalInputs = SubscribedPrincipalInput[];
export interface SubscribedListingInput {
    identifier: string;
}
export type SubscribedListingInputs = SubscribedListingInput[];
export type MetadataFormInputs = FormInput[];
export interface CreateSubscriptionRequestInput {
    domainIdentifier: string;
    subscribedPrincipals: SubscribedPrincipalInput[];
    subscribedListings: SubscribedListingInput[];
    requestReason: string | redacted.Redacted<string>;
    clientToken?: string | undefined;
    metadataForms?: FormInput[] | undefined;
    assetPermissions?: AssetPermission[] | undefined;
    assetScopes?: AcceptedAssetScope[] | undefined;
}
export interface CreateSubscriptionRequestOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string | undefined;
    decisionComment?: string | redacted.Redacted<string> | undefined;
    existingSubscriptionId?: string | undefined;
    metadataForms?: FormOutput[] | undefined;
}
export type SubscriptionTargetName = string | redacted.Redacted<string>;
export interface SubscriptionTargetForm {
    formName: string;
    content: string;
}
export type SubscriptionTargetForms = SubscriptionTargetForm[];
export type AuthorizedPrincipalIdentifier = string;
export type AuthorizedPrincipalIdentifiers = string[];
export type IamRoleArn = string;
export type ApplicableAssetTypes = string[];
export type SubscriptionGrantCreationMode = "AUTOMATIC" | "MANUAL" | (string & {});
export interface CreateSubscriptionTargetInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    name: string | redacted.Redacted<string>;
    type: string;
    subscriptionTargetConfig: SubscriptionTargetForm[];
    authorizedPrincipals: string[];
    manageAccessRole: string;
    applicableAssetTypes: string[];
    provider?: string | undefined;
    clientToken?: string | undefined;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode | undefined;
}
export interface CreateSubscriptionTargetOutput {
    id: string;
    authorizedPrincipals: string[];
    domainId: string;
    projectId: string;
    environmentId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    createdBy: string;
    updatedBy?: string | undefined;
    createdAt: Date;
    updatedAt?: Date | undefined;
    manageAccessRole?: string | undefined;
    applicableAssetTypes: string[];
    subscriptionTargetConfig: SubscriptionTargetForm[];
    provider: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode | undefined;
}
export type UserType = "IAM_USER" | "IAM_ROLE" | "SSO_USER" | "IAM_ROLE_SESSION" | (string & {});
export interface CreateUserProfileInput {
    domainIdentifier: string;
    userIdentifier: string;
    userType?: UserType | undefined;
    sessionName?: string | undefined;
    clientToken?: string | undefined;
}
export type UserProfileType = "IAM" | "SSO" | (string & {});
export type UserProfileStatus = "ASSIGNED" | "NOT_ASSIGNED" | "ACTIVATED" | "DEACTIVATED" | (string & {});
export interface CreateUserProfileOutput {
    domainId?: string | undefined;
    id?: string | undefined;
    type?: UserProfileType | undefined;
    status?: UserProfileStatus | undefined;
    details?: UserProfileDetails | undefined;
}
export interface DeleteAccountPoolInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteAccountPoolOutput {
}
export interface DeleteAssetInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteAssetOutput {
}
export interface DeleteAssetFilterInput {
    domainIdentifier: string;
    assetIdentifier: string;
    identifier: string;
}
export interface DeleteAssetFilterResponse {
}
export interface DeleteAssetTypeInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteAssetTypeOutput {
}
export interface DeleteConnectionInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteConnectionOutput {
    status?: string | undefined;
}
export interface DeleteDataExportConfigurationInput {
    domainIdentifier: string;
}
export interface DeleteDataExportConfigurationOutput {
}
export interface DeleteDataProductInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteDataProductOutput {
}
export interface DeleteDataSourceInput {
    domainIdentifier: string;
    identifier: string;
    clientToken?: string | undefined;
    retainPermissionsOnRevokeFailure?: boolean | undefined;
}
export type SelfGrantStatus = "GRANT_PENDING" | "REVOKE_PENDING" | "GRANT_IN_PROGRESS" | "REVOKE_IN_PROGRESS" | "GRANTED" | "GRANT_FAILED" | "REVOKE_FAILED" | (string & {});
export interface SelfGrantStatusDetail {
    databaseName: string;
    schemaName?: string | undefined;
    status: SelfGrantStatus;
    failureCause?: string | undefined;
}
export type SelfGrantStatusDetails = SelfGrantStatusDetail[];
export interface GlueSelfGrantStatusOutput {
    selfGrantStatusDetails: SelfGrantStatusDetail[];
}
export interface RedshiftSelfGrantStatusOutput {
    selfGrantStatusDetails: SelfGrantStatusDetail[];
}
export type SelfGrantStatusOutput = {
    glueSelfGrantStatus: GlueSelfGrantStatusOutput;
    redshiftSelfGrantStatus?: undefined;
} | {
    glueSelfGrantStatus?: undefined;
    redshiftSelfGrantStatus: RedshiftSelfGrantStatusOutput;
};
export interface DeleteDataSourceOutput {
    id: string;
    status?: DataSourceStatus | undefined;
    type?: string | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    domainId: string;
    projectId: string;
    environmentId?: string | undefined;
    connectionId?: string | undefined;
    configuration?: DataSourceConfigurationOutput | undefined;
    enableSetting?: EnableSetting | undefined;
    publishOnImport?: boolean | undefined;
    assetFormsOutput?: FormOutput[] | undefined;
    schedule?: ScheduleConfiguration | undefined;
    lastRunStatus?: DataSourceRunStatus | undefined;
    lastRunAt?: Date | undefined;
    lastRunErrorMessage?: DataSourceErrorMessage | undefined;
    errorMessage?: DataSourceErrorMessage | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    selfGrantStatus?: SelfGrantStatusOutput | undefined;
    retainPermissionsOnRevokeFailure?: boolean | undefined;
}
export interface DeleteDesignationInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteDesignationOutput {
}
export interface DeleteDomainInput {
    identifier: string;
    clientToken?: string | undefined;
    skipDeletionCheck?: boolean | undefined;
    cascadeDelete?: boolean | undefined;
}
export interface DeleteDomainOutput {
    status: DomainStatus;
}
export interface DeleteDomainUnitInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteDomainUnitOutput {
}
export interface DeleteEnvironmentInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteEnvironmentResponse {
}
export interface DeleteEnvironmentActionInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
}
export interface DeleteEnvironmentActionResponse {
}
export interface DeleteEnvironmentBlueprintInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteEnvironmentBlueprintResponse {
}
export interface DeleteEnvironmentBlueprintConfigurationInput {
    domainIdentifier: string;
    environmentBlueprintIdentifier: string;
}
export interface DeleteEnvironmentBlueprintConfigurationOutput {
}
export interface DeleteEnvironmentProfileInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteEnvironmentProfileResponse {
}
export interface DeleteFormTypeInput {
    domainIdentifier: string;
    formTypeIdentifier: string;
}
export interface DeleteFormTypeOutput {
}
export interface DeleteGlossaryInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteGlossaryOutput {
}
export interface DeleteGlossaryTermInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteGlossaryTermOutput {
}
export type LineageEventIdentifier = string;
export interface DeleteLineageEventInput {
    domainIdentifier: string;
    identifier: string;
}
export type LineageEventProcessingStatus = "REQUESTED" | "PROCESSING" | "SUCCESS" | "FAILED" | (string & {});
export interface DeleteLineageEventOutput {
    id?: string | undefined;
    domainId?: string | undefined;
    processingStatus?: LineageEventProcessingStatus | undefined;
}
export interface DeleteListingInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteListingOutput {
}
export interface DeleteNotebookInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteNotebookOutput {
}
export interface DeleteProjectInput {
    domainIdentifier: string;
    identifier: string;
    skipDeletionCheck?: boolean | undefined;
}
export interface DeleteProjectOutput {
}
export interface DeleteProjectMembershipInput {
    domainIdentifier: string;
    projectIdentifier: string;
    member: Member;
}
export interface DeleteProjectMembershipOutput {
}
export interface DeleteProjectProfileInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteProjectProfileOutput {
}
export interface DeleteRuleInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteRuleOutput {
}
export interface DeleteSubscriptionGrantInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteSubscriptionGrantOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string | undefined;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[] | undefined;
    subscriptionId?: string | undefined;
}
export interface DeleteSubscriptionRequestInput {
    domainIdentifier: string;
    identifier: string;
}
export interface DeleteSubscriptionRequestResponse {
}
export interface DeleteSubscriptionTargetInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
}
export interface DeleteSubscriptionTargetResponse {
}
export type TimeSeriesEntityType = "ASSET" | "LISTING" | (string & {});
export interface DeleteTimeSeriesDataPointsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: TimeSeriesEntityType;
    formName: string;
    clientToken?: string | undefined;
}
export interface DeleteTimeSeriesDataPointsOutput {
}
export interface DisassociateEnvironmentRoleInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    environmentRoleArn: string;
}
export interface DisassociateEnvironmentRoleOutput {
}
export interface DisassociateGovernedTermsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: GovernedEntityType;
    governedGlossaryTerms: string[];
}
export interface DisassociateGovernedTermsOutput {
}
export interface GetAccountPoolInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetAccountPoolOutput {
    domainId?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    id?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    resolutionStrategy?: ResolutionStrategy | undefined;
    accountSource: AccountSource;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    domainUnitId?: string | undefined;
}
export interface GetAssetInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string | undefined;
}
export interface GetAssetOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    typeIdentifier: string;
    typeRevision: string;
    externalIdentifier?: string | undefined;
    revision: string;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    firstRevisionCreatedAt?: Date | undefined;
    firstRevisionCreatedBy?: string | undefined;
    glossaryTerms?: string[] | undefined;
    governedGlossaryTerms?: string[] | undefined;
    owningProjectId: string;
    domainId: string;
    listing?: AssetListingDetails | undefined;
    formsOutput: FormOutput[];
    readOnlyFormsOutput?: FormOutput[] | undefined;
    latestTimeSeriesDataPointFormsOutput?: TimeSeriesDataPointSummaryFormOutput[] | undefined;
}
export interface GetAssetFilterInput {
    domainIdentifier: string;
    assetIdentifier: string;
    identifier: string;
}
export interface GetAssetFilterOutput {
    id: string;
    domainId: string;
    assetId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: FilterStatus | undefined;
    configuration: AssetFilterConfiguration;
    createdAt?: Date | undefined;
    errorMessage?: string | undefined;
    effectiveColumnNames?: string[] | undefined;
    effectiveRowFilter?: string | undefined;
}
export interface GetAssetTypeInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string | undefined;
}
export interface GetAssetTypeOutput {
    domainId: string;
    name: string;
    revision: string;
    description?: string | redacted.Redacted<string> | undefined;
    formsOutput: {
        [key: string]: FormEntryOutput | undefined;
    };
    owningProjectId: string;
    originDomainId?: string | undefined;
    originProjectId?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
}
export interface GetConnectionInput {
    domainIdentifier: string;
    identifier: string;
    withSecret?: boolean | undefined;
}
export interface ConnectionCredentials {
    accessKeyId?: string | undefined;
    secretAccessKey?: string | redacted.Redacted<string> | undefined;
    sessionToken?: string | redacted.Redacted<string> | undefined;
    expiration?: Date | undefined;
}
export interface GetConnectionOutput {
    connectionCredentials?: ConnectionCredentials | undefined;
    configurations?: Configuration[] | undefined;
    connectionId: string;
    description?: string | redacted.Redacted<string> | undefined;
    domainId: string;
    domainUnitId: string;
    environmentId?: string | undefined;
    environmentUserRole?: string | undefined;
    name: string;
    physicalEndpoints: PhysicalEndpoint[];
    projectId?: string | undefined;
    props?: ConnectionPropertiesOutput | undefined;
    type: ConnectionType;
    scope?: ConnectionScope | undefined;
}
export interface GetDataExportConfigurationInput {
    domainIdentifier: string;
}
export type ConfigurationStatus = "COMPLETED" | "FAILED" | (string & {});
export interface EncryptionConfiguration {
    kmsKeyArn?: string | undefined;
    sseAlgorithm?: string | undefined;
}
export interface GetDataExportConfigurationOutput {
    isExportEnabled?: boolean | undefined;
    status?: ConfigurationStatus | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    s3TableBucketArn?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetDataProductInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string | undefined;
}
export interface GetDataProductOutput {
    domainId: string;
    id: string;
    revision: string;
    owningProjectId: string;
    name: string | redacted.Redacted<string>;
    status: DataProductStatus;
    description?: string | redacted.Redacted<string> | undefined;
    glossaryTerms?: string[] | undefined;
    items?: DataProductItem[] | undefined;
    formsOutput?: FormOutput[] | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    firstRevisionCreatedAt?: Date | undefined;
    firstRevisionCreatedBy?: string | undefined;
}
export interface GetDataSourceInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetDataSourceOutput {
    id: string;
    status?: DataSourceStatus | undefined;
    type?: string | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    domainId: string;
    projectId: string;
    environmentId?: string | undefined;
    connectionId?: string | undefined;
    configuration?: DataSourceConfigurationOutput | undefined;
    recommendation?: RecommendationConfiguration | undefined;
    enableSetting?: EnableSetting | undefined;
    publishOnImport?: boolean | undefined;
    assetFormsOutput?: FormOutput[] | undefined;
    schedule?: ScheduleConfiguration | undefined;
    lastRunStatus?: DataSourceRunStatus | undefined;
    lastRunAt?: Date | undefined;
    lastRunErrorMessage?: DataSourceErrorMessage | undefined;
    lastRunAssetCount?: number | undefined;
    errorMessage?: DataSourceErrorMessage | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    selfGrantStatus?: SelfGrantStatusOutput | undefined;
}
export type DataSourceRunId = string;
export interface GetDataSourceRunInput {
    domainIdentifier: string;
    identifier: string;
}
export type DataSourceRunType = "PRIORITIZED" | "SCHEDULED" | (string & {});
export interface RunStatisticsForAssets {
    added?: number | undefined;
    updated?: number | undefined;
    unchanged?: number | undefined;
    skipped?: number | undefined;
    failed?: number | undefined;
}
export type LineageImportStatus = "IN_PROGRESS" | "SUCCESS" | "FAILED" | "PARTIALLY_SUCCEEDED" | (string & {});
export interface DataSourceRunLineageSummary {
    importStatus?: LineageImportStatus | undefined;
}
export interface GetDataSourceRunOutput {
    domainId: string;
    dataSourceId: string;
    id: string;
    projectId: string;
    status: DataSourceRunStatus;
    type: DataSourceRunType;
    dataSourceConfigurationSnapshot?: string | undefined;
    runStatisticsForAssets?: RunStatisticsForAssets | undefined;
    lineageSummary?: DataSourceRunLineageSummary | undefined;
    errorMessage?: DataSourceErrorMessage | undefined;
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date | undefined;
    stoppedAt?: Date | undefined;
}
export interface GetDesignationInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetDesignationOutput {
    domainId: string;
    id: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    designationType: DesignationType;
    policy: string;
    deletionProtection: boolean;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface GetDomainInput {
    identifier: string;
}
export interface FailureReason {
    id?: string | undefined;
    message?: string | undefined;
}
export type FailureReasonsList = FailureReason[];
export interface DeleteProgress {
    successfullyDeletedProjectCount?: number | undefined;
}
export interface GetDomainOutput {
    id: string;
    rootDomainUnitId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    singleSignOn?: SingleSignOn | undefined;
    domainExecutionRole: string;
    arn?: string | undefined;
    kmsKeyIdentifier?: string | undefined;
    status: DomainStatus;
    portalUrl?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    domainVersion?: DomainVersion | undefined;
    serviceRole?: string | undefined;
    failureReasons?: FailureReason[] | undefined;
    deleteProgress?: DeleteProgress | undefined;
}
export interface GetDomainUnitInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetDomainUnitOutput {
    id: string;
    domainId: string;
    name: string | redacted.Redacted<string>;
    parentDomainUnitId?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    owners: DomainUnitOwnerProperties[];
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    createdBy?: string | undefined;
    lastUpdatedBy?: string | undefined;
}
export interface GetEnvironmentInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetEnvironmentOutput {
    projectId: string;
    id?: string | undefined;
    domainId: string;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentProfileId?: string | undefined;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    provider: string;
    provisionedResources?: Resource[] | undefined;
    status?: EnvironmentStatus | undefined;
    environmentActions?: ConfigurableEnvironmentAction[] | undefined;
    glossaryTerms?: string[] | undefined;
    userParameters?: CustomParameter[] | undefined;
    lastDeployment?: Deployment | undefined;
    provisioningProperties?: ProvisioningProperties | undefined;
    deploymentProperties?: DeploymentProperties | undefined;
    environmentBlueprintId?: string | undefined;
    environmentConfigurationId?: string | redacted.Redacted<string> | undefined;
    environmentConfigurationName?: string | redacted.Redacted<string> | undefined;
}
export interface GetEnvironmentActionInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
}
export interface GetEnvironmentActionOutput {
    domainId: string;
    environmentId: string;
    id: string;
    name: string;
    parameters: ActionParameters;
    description?: string | undefined;
}
export interface GetEnvironmentBlueprintInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetEnvironmentBlueprintOutput {
    id: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    provider: string;
    provisioningProperties: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties | undefined;
    userParameters?: CustomParameter[] | undefined;
    glossaryTerms?: string[] | undefined;
    blueprintCategory?: BlueprintCategory | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetEnvironmentBlueprintConfigurationInput {
    domainIdentifier: string;
    environmentBlueprintIdentifier: string;
}
export type PolicyArn = string;
export type EnabledRegionList = string[];
export type RegionalParameter = {
    [key: string]: string | undefined;
};
export type RegionalParameterMap = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export type ResourceConfigurationParameterMap = {
    [key: string]: string | undefined;
};
export interface ResourceConfiguration {
    identifier: string;
    name: string;
    description?: string | undefined;
    region: string;
    parameters: {
        [key: string]: string | undefined;
    };
}
export type ResourceConfigurations = ResourceConfiguration[];
export type S3Location = string;
export type S3LocationList = string[];
export interface LakeFormationConfiguration {
    locationRegistrationRole?: string | undefined;
    locationRegistrationExcludeS3Locations?: string[] | undefined;
}
export type ProvisioningConfiguration = {
    lakeFormationConfiguration: LakeFormationConfiguration;
};
export type ProvisioningConfigurationList = ProvisioningConfiguration[];
export interface GetEnvironmentBlueprintConfigurationOutput {
    domainId: string;
    environmentBlueprintId: string;
    provisioningRoleArn?: string | undefined;
    environmentRolePermissionBoundary?: string | undefined;
    manageAccessRoleArn?: string | undefined;
    enabledRegions?: string[] | undefined;
    regionalParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    allowUserProvidedConfigurations?: boolean | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    resourceConfigurations?: ResourceConfiguration[] | undefined;
    provisioningConfigurations?: ProvisioningConfiguration[] | undefined;
}
export interface GetEnvironmentCredentialsInput {
    domainIdentifier: string;
    environmentIdentifier: string;
}
export interface GetEnvironmentCredentialsOutput {
    accessKeyId?: string | undefined;
    secretAccessKey?: string | redacted.Redacted<string> | undefined;
    sessionToken?: string | redacted.Redacted<string> | undefined;
    expiration?: Date | undefined;
}
export interface GetEnvironmentProfileInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetEnvironmentProfileOutput {
    id: string;
    domainId: string;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentBlueprintId: string;
    projectId?: string | undefined;
    userParameters?: CustomParameter[] | undefined;
}
export interface GetFormTypeInput {
    domainIdentifier: string;
    formTypeIdentifier: string;
    revision?: string | undefined;
}
export interface Import {
    name: string | redacted.Redacted<string>;
    revision: string;
}
export type ImportList = Import[];
export interface GetFormTypeOutput {
    domainId: string;
    name: string | redacted.Redacted<string>;
    revision: string;
    model: Model;
    owningProjectId?: string | undefined;
    originDomainId?: string | undefined;
    originProjectId?: string | undefined;
    status?: FormTypeStatus | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    imports?: Import[] | undefined;
}
export interface GetGlossaryInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetGlossaryOutput {
    domainId: string;
    id: string;
    owningProjectId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status: GlossaryStatus;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
}
export interface GetGlossaryTermInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetGlossaryTermOutput {
    domainId: string;
    glossaryId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    shortDescription?: string | redacted.Redacted<string> | undefined;
    longDescription?: string | redacted.Redacted<string> | undefined;
    termRelations?: TermRelations | undefined;
    status: GlossaryTermStatus;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
}
export interface GetGroupProfileInput {
    domainIdentifier: string;
    groupIdentifier: string;
}
export interface GetGroupProfileOutput {
    domainId?: string | undefined;
    id?: string | undefined;
    status?: GroupProfileStatus | undefined;
    groupName?: string | redacted.Redacted<string> | undefined;
    rolePrincipalArn?: string | undefined;
    rolePrincipalId?: string | undefined;
}
export interface GetIamPortalLoginUrlInput {
    domainIdentifier: string;
}
export interface GetIamPortalLoginUrlOutput {
    authCodeUrl?: string | undefined;
    userProfileId: string;
}
export type RunIdentifier = string;
export interface GetJobRunInput {
    domainIdentifier: string;
    identifier: string;
}
export type JobType = "LINEAGE" | (string & {});
export type JobRunMode = "SCHEDULED" | "ON_DEMAND" | (string & {});
export type FailedQueryProcessingErrorMessages = string[];
export interface LineageSqlQueryRunDetails {
    queryStartTime?: Date | undefined;
    queryEndTime?: Date | undefined;
    totalQueriesProcessed?: number | undefined;
    numQueriesFailed?: number | undefined;
    errorMessages?: string[] | undefined;
}
export interface LineageRunDetails {
    sqlQueryRunDetails?: LineageSqlQueryRunDetails | undefined;
}
export type JobRunDetails = {
    lineageRunDetails: LineageRunDetails;
};
export type JobRunStatus = "SCHEDULED" | "IN_PROGRESS" | "SUCCESS" | "PARTIALLY_SUCCEEDED" | "FAILED" | "ABORTED" | "TIMED_OUT" | "CANCELED" | (string & {});
export interface JobRunError {
    message: string;
}
export interface GetJobRunOutput {
    domainId?: string | undefined;
    id?: string | undefined;
    jobId?: string | undefined;
    jobType?: JobType | undefined;
    runMode?: JobRunMode | undefined;
    details?: JobRunDetails | undefined;
    status?: JobRunStatus | undefined;
    error?: JobRunError | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export interface GetLineageEventInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetLineageEventOutput {
    domainId?: string | undefined;
    id?: string | undefined;
    event?: T.StreamingOutputBody | undefined;
    createdBy?: string | undefined;
    processingStatus?: LineageEventProcessingStatus | undefined;
    eventTime?: Date | undefined;
    createdAt?: Date | undefined;
}
export type LineageNodeIdentifier = string;
export interface GetLineageNodeInput {
    domainIdentifier: string;
    identifier: string;
    eventTimestamp?: Date | undefined;
}
export type LineageNodeId = string;
export interface LineageNodeReference {
    id?: string | undefined;
    eventTimestamp?: Date | undefined;
}
export type LineageNodeReferenceList = LineageNodeReference[];
export interface GetLineageNodeOutput {
    domainId: string;
    name?: string | undefined;
    description?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    id: string;
    typeName: string;
    typeRevision?: string | undefined;
    sourceIdentifier?: string | undefined;
    eventTimestamp?: Date | undefined;
    formsOutput?: FormOutput[] | undefined;
    upstreamNodes?: LineageNodeReference[] | undefined;
    downstreamNodes?: LineageNodeReference[] | undefined;
}
export interface GetListingInput {
    domainIdentifier: string;
    identifier: string;
    listingRevision?: string | undefined;
}
export interface AssetListing {
    assetId?: string | undefined;
    assetRevision?: string | undefined;
    assetType?: string | undefined;
    createdAt?: Date | undefined;
    forms?: string | undefined;
    latestTimeSeriesDataPointForms?: TimeSeriesDataPointSummaryFormOutput[] | undefined;
    glossaryTerms?: DetailedGlossaryTerm[] | undefined;
    governedGlossaryTerms?: DetailedGlossaryTerm[] | undefined;
    owningProjectId?: string | undefined;
}
export interface ListingSummary {
    listingId?: string | undefined;
    listingRevision?: string | undefined;
    glossaryTerms?: DetailedGlossaryTerm[] | undefined;
}
export type ListingSummaries = ListingSummary[];
export interface DataProductListing {
    dataProductId?: string | undefined;
    dataProductRevision?: string | undefined;
    createdAt?: Date | undefined;
    forms?: string | undefined;
    glossaryTerms?: DetailedGlossaryTerm[] | undefined;
    owningProjectId?: string | undefined;
    items?: ListingSummary[] | undefined;
}
export type ListingItem = {
    assetListing: AssetListing;
    dataProductListing?: undefined;
} | {
    assetListing?: undefined;
    dataProductListing: DataProductListing;
};
export interface GetListingOutput {
    domainId: string;
    id: string;
    listingRevision: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedBy?: string | undefined;
    item?: ListingItem | undefined;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    status?: ListingStatus | undefined;
}
export type MetadataGenerationRunType = "BUSINESS_DESCRIPTIONS" | "BUSINESS_NAMES" | "BUSINESS_GLOSSARY_ASSOCIATIONS" | (string & {});
export interface GetMetadataGenerationRunInput {
    domainIdentifier: string;
    identifier: string;
    type?: MetadataGenerationRunType | undefined;
}
export type MetadataGenerationTargetType = "ASSET" | (string & {});
export interface MetadataGenerationRunTarget {
    type: MetadataGenerationTargetType;
    identifier: string;
    revision?: string | undefined;
}
export type MetadataGenerationRunStatus = "SUBMITTED" | "IN_PROGRESS" | "CANCELED" | "SUCCEEDED" | "FAILED" | "PARTIALLY_SUCCEEDED" | (string & {});
export type MetadataGenerationRunTypes = MetadataGenerationRunType[];
export interface MetadataGenerationRunTypeStat {
    type: MetadataGenerationRunType;
    status: MetadataGenerationRunStatus;
    errorMessage?: string | undefined;
}
export type MetadataGenerationRunTypeStats = MetadataGenerationRunTypeStat[];
export interface GetMetadataGenerationRunOutput {
    domainId: string;
    id: string;
    target?: MetadataGenerationRunTarget | undefined;
    status?: MetadataGenerationRunStatus | undefined;
    type?: MetadataGenerationRunType | undefined;
    types?: MetadataGenerationRunType[] | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    owningProjectId: string;
    typeStats?: MetadataGenerationRunTypeStat[] | undefined;
}
export interface GetNotebookInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetNotebookOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    domainId: string;
    cellOrder: CellInformation[];
    status: NotebookStatus;
    type?: NotebookType | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    lockedBy?: string | undefined;
    lockedAt?: Date | undefined;
    lockExpiresAt?: Date | undefined;
    computeId?: string | undefined;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    environmentConfiguration?: EnvironmentConfig | undefined;
    error?: NotebookError | undefined;
    gitMetadata?: GitMetadata | undefined;
}
export type ExportId = string;
export interface GetNotebookExportInput {
    domainIdentifier: string;
    identifier: string;
}
export type FileFormat = "PDF" | "IPYNB" | (string & {});
export type NotebookExportStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export type NotebookS3Uri = string | redacted.Redacted<string>;
export interface S3Destination {
    uri?: string | redacted.Redacted<string> | undefined;
}
export type OutputLocation = {
    s3: S3Destination;
};
export interface NotebookExportError {
    message: string;
}
export type CompletedAt = Date;
export interface GetNotebookExportOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    fileFormat: FileFormat;
    status: NotebookExportStatus;
    outputLocation?: OutputLocation | undefined;
    error?: NotebookExportError | undefined;
    completedAt?: Date | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
}
export type NotebookRunId = string;
export interface GetNotebookRunInput {
    domainIdentifier: string;
    identifier: string;
}
export type ScheduleId = string;
export type NotebookRunStatus = "QUEUED" | "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | "SUCCEEDED" | "FAILED" | (string & {});
export type InstanceType = string;
export interface ComputeConfig {
    instanceType?: string | undefined;
    environmentVersion?: string | undefined;
}
export type NetworkAccessType = "PUBLIC_INTERNET_ONLY" | "VPC_ONLY" | (string & {});
export type SubnetIds = string[];
export type SecurityGroupIds = string[];
export interface NetworkConfig {
    networkAccessType: NetworkAccessType;
    vpcId?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
}
export interface TimeoutConfig {
    runTimeoutInMinutes?: number | undefined;
}
export type S3Path = string;
export interface StorageConfig {
    projectS3Path?: string | undefined;
    kmsKeyArn?: string | undefined;
}
export type NotifyOnState = "SUCCEEDED" | "FAILED" | "STOPPED" | "QUEUED" | "STARTING" | "RUNNING" | "STOPPING" | (string & {});
export type NotifyOnStates = NotifyOnState[];
export interface NotificationConfig {
    notifyOn: NotifyOnState[];
}
export type TriggerSourceType = "MANUAL" | "SCHEDULED" | "WORKFLOW" | (string & {});
export interface TriggerSource {
    type?: TriggerSourceType | undefined;
    name?: string | undefined;
}
export interface NotebookRunError {
    message: string;
}
export interface GetNotebookRunOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    scheduleId?: string | undefined;
    status: NotebookRunStatus;
    cellOrder?: CellInformation[] | undefined;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    computeConfiguration?: ComputeConfig | undefined;
    networkConfiguration?: NetworkConfig | undefined;
    timeoutConfiguration?: TimeoutConfig | undefined;
    environmentConfiguration?: EnvironmentConfig | undefined;
    storageConfiguration?: StorageConfig | undefined;
    notificationConfiguration?: NotificationConfig | undefined;
    triggerSource?: TriggerSource | undefined;
    error?: NotebookRunError | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    startedAt?: Date | undefined;
    completedAt?: Date | undefined;
}
export interface GetProjectInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetProjectOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    projectStatus?: ProjectStatus | undefined;
    failureReasons?: ProjectDeletionError[] | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    resourceTags?: ResourceTag[] | undefined;
    glossaryTerms?: string[] | undefined;
    domainUnitId?: string | undefined;
    projectProfileId?: string | undefined;
    userParameters?: EnvironmentConfigurationUserParameter[] | undefined;
    environmentDeploymentDetails?: EnvironmentDeploymentDetails | undefined;
    projectCategory?: string | undefined;
}
export interface GetProjectProfileInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetProjectProfileOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: Status | undefined;
    projectResourceTags?: ResourceTagParameter[] | undefined;
    allowCustomProjectResourceTags?: boolean | undefined;
    projectResourceTagsDescription?: string | redacted.Redacted<string> | undefined;
    environmentConfigurations?: EnvironmentConfiguration[] | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    domainUnitId?: string | undefined;
}
export interface GetRuleInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string | undefined;
}
export interface GetRuleOutput {
    identifier: string;
    revision: string;
    name: string | redacted.Redacted<string>;
    ruleType: RuleType;
    target: RuleTarget;
    action: RuleAction;
    scope: RuleScope;
    detail: RuleDetail;
    targetType?: RuleTargetType | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt: Date;
    updatedAt: Date;
    createdBy: string;
    lastUpdatedBy: string;
}
export interface GetSubscriptionInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetSubscriptionOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionStatus;
    createdAt: Date;
    updatedAt: Date;
    subscribedPrincipal: SubscribedPrincipal;
    subscribedListing: SubscribedListing;
    subscriptionRequestId?: string | undefined;
    retainPermissions?: boolean | undefined;
}
export interface GetSubscriptionGrantInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetSubscriptionGrantOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string | undefined;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[] | undefined;
    subscriptionId?: string | undefined;
}
export interface GetSubscriptionRequestDetailsInput {
    domainIdentifier: string;
    identifier: string;
}
export interface GetSubscriptionRequestDetailsOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string | undefined;
    decisionComment?: string | redacted.Redacted<string> | undefined;
    existingSubscriptionId?: string | undefined;
    metadataForms?: FormOutput[] | undefined;
}
export interface GetSubscriptionTargetInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
}
export interface GetSubscriptionTargetOutput {
    id: string;
    authorizedPrincipals: string[];
    domainId: string;
    projectId: string;
    environmentId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    createdBy: string;
    updatedBy?: string | undefined;
    createdAt: Date;
    updatedAt?: Date | undefined;
    manageAccessRole?: string | undefined;
    applicableAssetTypes: string[];
    subscriptionTargetConfig: SubscriptionTargetForm[];
    provider: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode | undefined;
}
export type TimeSeriesDataPointIdentifier = string;
export interface GetTimeSeriesDataPointInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: TimeSeriesEntityType;
    identifier: string;
    formName: string;
}
export interface TimeSeriesDataPointFormOutput {
    formName: string;
    typeIdentifier: string;
    typeRevision?: string | undefined;
    timestamp: Date;
    content?: string | undefined;
    id?: string | undefined;
}
export interface GetTimeSeriesDataPointOutput {
    domainId?: string | undefined;
    entityId?: string | undefined;
    entityType?: TimeSeriesEntityType | undefined;
    formName?: string | undefined;
    form?: TimeSeriesDataPointFormOutput | undefined;
}
export interface GetUserProfileInput {
    domainIdentifier: string;
    userIdentifier: string;
    type?: UserProfileType | undefined;
    sessionName?: string | undefined;
}
export interface GetUserProfileOutput {
    domainId?: string | undefined;
    id?: string | undefined;
    type?: UserProfileType | undefined;
    status?: UserProfileStatus | undefined;
    details?: UserProfileDetails | undefined;
}
export type SortFieldAccountPool = "NAME" | (string & {});
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export type PaginationToken = string;
export type MaxResults = number;
export interface ListAccountPoolsInput {
    domainIdentifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    sortBy?: SortFieldAccountPool | undefined;
    sortOrder?: SortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AccountPoolSummary {
    domainId?: string | undefined;
    id?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    resolutionStrategy?: ResolutionStrategy | undefined;
    domainUnitId?: string | undefined;
    createdBy?: string | undefined;
    updatedBy?: string | undefined;
}
export type AccountPoolSummaries = AccountPoolSummary[];
export interface ListAccountPoolsOutput {
    items?: AccountPoolSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAccountsInAccountPoolInput {
    domainIdentifier: string;
    identifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListAccountsInAccountPoolOutput {
    items?: AccountInfo[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAssetFiltersInput {
    domainIdentifier: string;
    assetIdentifier: string;
    status?: FilterStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AssetFilterSummary {
    id: string;
    domainId: string;
    assetId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: FilterStatus | undefined;
    effectiveColumnNames?: string[] | undefined;
    effectiveRowFilter?: string | undefined;
    createdAt?: Date | undefined;
    errorMessage?: string | undefined;
}
export type AssetFilters = AssetFilterSummary[];
export interface ListAssetFiltersOutput {
    items: AssetFilterSummary[];
    nextToken?: string | undefined;
}
export interface ListAssetRevisionsInput {
    domainIdentifier: string;
    identifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AssetRevision {
    domainId?: string | undefined;
    id?: string | undefined;
    revision?: string | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
}
export type AssetRevisions = AssetRevision[];
export interface ListAssetRevisionsOutput {
    items?: AssetRevision[] | undefined;
    nextToken?: string | undefined;
}
export type SortFieldConnection = "NAME" | (string & {});
export interface ListConnectionsInput {
    domainIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortFieldConnection | undefined;
    sortOrder?: SortOrder | undefined;
    name?: string | undefined;
    environmentIdentifier?: string | undefined;
    projectIdentifier?: string | undefined;
    type?: ConnectionType | undefined;
    scope?: ConnectionScope | undefined;
}
export interface ConnectionSummary {
    configurations?: Configuration[] | undefined;
    connectionId: string;
    domainId: string;
    domainUnitId: string;
    environmentId?: string | undefined;
    name: string;
    physicalEndpoints: PhysicalEndpoint[];
    projectId?: string | undefined;
    props?: ConnectionPropertiesOutput | undefined;
    type: ConnectionType;
    scope?: ConnectionScope | undefined;
}
export type ConnectionSummaries = ConnectionSummary[];
export interface ListConnectionsOutput {
    items: ConnectionSummary[];
    nextToken?: string | undefined;
}
export interface ListDataProductRevisionsInput {
    domainIdentifier: string;
    identifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DataProductRevision {
    domainId?: string | undefined;
    id?: string | undefined;
    revision?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
}
export type DataProductRevisions = DataProductRevision[];
export interface ListDataProductRevisionsOutput {
    items: DataProductRevision[];
    nextToken?: string | undefined;
}
export type DataAssetActivityStatus = "FAILED" | "PUBLISHING_FAILED" | "SUCCEEDED_CREATED" | "SUCCEEDED_UPDATED" | "SKIPPED_ALREADY_IMPORTED" | "SKIPPED_ARCHIVED" | "SKIPPED_NO_ACCESS" | "UNCHANGED" | (string & {});
export interface ListDataSourceRunActivitiesInput {
    domainIdentifier: string;
    identifier: string;
    status?: DataAssetActivityStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type LineageEventErrorMessage = string;
export interface LineageInfo {
    eventId?: string | undefined;
    eventStatus?: LineageEventProcessingStatus | undefined;
    errorMessage?: string | undefined;
}
export interface DataSourceRunActivity {
    database: string | redacted.Redacted<string>;
    dataSourceRunId: string;
    technicalName: string | redacted.Redacted<string>;
    dataAssetStatus: DataAssetActivityStatus;
    projectId: string;
    dataAssetId?: string | undefined;
    technicalDescription?: string | redacted.Redacted<string> | undefined;
    errorMessage?: DataSourceErrorMessage | undefined;
    lineageSummary?: LineageInfo | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type DataSourceRunActivities = DataSourceRunActivity[];
export interface ListDataSourceRunActivitiesOutput {
    items: DataSourceRunActivity[];
    nextToken?: string | undefined;
}
export interface ListDataSourceRunsInput {
    domainIdentifier: string;
    dataSourceIdentifier: string;
    status?: DataSourceRunStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DataSourceRunSummary {
    id: string;
    dataSourceId: string;
    type: DataSourceRunType;
    status: DataSourceRunStatus;
    projectId: string;
    runStatisticsForAssets?: RunStatisticsForAssets | undefined;
    errorMessage?: DataSourceErrorMessage | undefined;
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date | undefined;
    stoppedAt?: Date | undefined;
    lineageSummary?: DataSourceRunLineageSummary | undefined;
}
export type DataSourceRunSummaries = DataSourceRunSummary[];
export interface ListDataSourceRunsOutput {
    items: DataSourceRunSummary[];
    nextToken?: string | undefined;
}
export interface ListDataSourcesInput {
    domainIdentifier: string;
    projectIdentifier: string;
    environmentIdentifier?: string | undefined;
    connectionIdentifier?: string | undefined;
    type?: string | undefined;
    status?: DataSourceStatus | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DataSourceSummary {
    domainId: string;
    environmentId?: string | undefined;
    connectionId?: string | undefined;
    dataSourceId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    status: DataSourceStatus;
    enableSetting?: EnableSetting | undefined;
    schedule?: ScheduleConfiguration | undefined;
    lastRunStatus?: DataSourceRunStatus | undefined;
    lastRunAt?: Date | undefined;
    lastRunErrorMessage?: DataSourceErrorMessage | undefined;
    lastRunAssetCount?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export type DataSourceSummaries = DataSourceSummary[];
export interface ListDataSourcesOutput {
    items: DataSourceSummary[];
    nextToken?: string | undefined;
}
export type ListDesignationsMaxResults = number;
export interface ListDesignationsInput {
    domainIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DesignationSummary {
    domainId: string;
    id: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    designationType?: DesignationType | undefined;
    deletionProtection: boolean;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type DesignationSummaries = DesignationSummary[];
export interface ListDesignationsOutput {
    items?: DesignationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type MaxResultsForListDomains = number;
export interface ListDomainsInput {
    status?: DomainStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type DomainName = string | redacted.Redacted<string>;
export type DomainDescription = string | redacted.Redacted<string>;
export interface DomainSummary {
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    arn: string;
    managedAccountId: string;
    status: DomainStatus;
    portalUrl?: string | undefined;
    createdAt: Date;
    lastUpdatedAt?: Date | undefined;
    domainVersion?: DomainVersion | undefined;
}
export type DomainSummaries = DomainSummary[];
export interface ListDomainsOutput {
    items: DomainSummary[];
    nextToken?: string | undefined;
}
export interface ListDomainUnitsForParentInput {
    domainIdentifier: string;
    parentDomainUnitIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DomainUnitSummary {
    name: string;
    id: string;
}
export type DomainUnitSummaries = DomainUnitSummary[];
export interface ListDomainUnitsForParentOutput {
    items: DomainUnitSummary[];
    nextToken?: string | undefined;
}
export interface ListEntityOwnersInput {
    domainIdentifier: string;
    entityType: DataZoneEntityType;
    entityIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface OwnerUserPropertiesOutput {
    userId?: string | undefined;
}
export interface OwnerGroupPropertiesOutput {
    groupId?: string | undefined;
}
export type OwnerPropertiesOutput = {
    user: OwnerUserPropertiesOutput;
    group?: undefined;
} | {
    user?: undefined;
    group: OwnerGroupPropertiesOutput;
};
export type EntityOwners = OwnerPropertiesOutput[];
export interface ListEntityOwnersOutput {
    owners: OwnerPropertiesOutput[];
    nextToken?: string | undefined;
}
export interface ListEnvironmentActionsInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface EnvironmentActionSummary {
    domainId: string;
    environmentId: string;
    id: string;
    name: string;
    parameters: ActionParameters;
    description?: string | undefined;
}
export type ListEnvironmentActionSummaries = EnvironmentActionSummary[];
export interface ListEnvironmentActionsOutput {
    items?: EnvironmentActionSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListEnvironmentBlueprintConfigurationsInput {
    domainIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface EnvironmentBlueprintConfigurationItem {
    domainId: string;
    environmentBlueprintId: string;
    provisioningRoleArn?: string | undefined;
    environmentRolePermissionBoundary?: string | undefined;
    manageAccessRoleArn?: string | undefined;
    enabledRegions?: string[] | undefined;
    regionalParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    allowUserProvidedConfigurations?: boolean | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    resourceConfigurations?: ResourceConfiguration[] | undefined;
    provisioningConfigurations?: ProvisioningConfiguration[] | undefined;
}
export type EnvironmentBlueprintConfigurations = EnvironmentBlueprintConfigurationItem[];
export interface ListEnvironmentBlueprintConfigurationsOutput {
    items?: EnvironmentBlueprintConfigurationItem[] | undefined;
    nextToken?: string | undefined;
}
export interface ListEnvironmentBlueprintsInput {
    domainIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    name?: string | undefined;
    managed?: boolean | undefined;
}
export interface EnvironmentBlueprintSummary {
    id: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    provider: string;
    provisioningProperties: ProvisioningProperties;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    blueprintCategory?: BlueprintCategory | undefined;
}
export type EnvironmentBlueprintSummaries = EnvironmentBlueprintSummary[];
export interface ListEnvironmentBlueprintsOutput {
    items: EnvironmentBlueprintSummary[];
    nextToken?: string | undefined;
}
export interface ListEnvironmentProfilesInput {
    domainIdentifier: string;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    environmentBlueprintIdentifier?: string | undefined;
    projectIdentifier?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface EnvironmentProfileSummary {
    id: string;
    domainId: string;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentBlueprintId: string;
    projectId?: string | undefined;
}
export type EnvironmentProfileSummaries = EnvironmentProfileSummary[];
export interface ListEnvironmentProfilesOutput {
    items: EnvironmentProfileSummary[];
    nextToken?: string | undefined;
}
export interface ListEnvironmentsInput {
    domainIdentifier: string;
    awsAccountId?: string | undefined;
    status?: EnvironmentStatus | undefined;
    awsAccountRegion?: string | undefined;
    projectIdentifier: string;
    environmentProfileIdentifier?: string | undefined;
    environmentBlueprintIdentifier?: string | undefined;
    provider?: string | undefined;
    name?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface EnvironmentSummary {
    projectId: string;
    id?: string | undefined;
    domainId: string;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentProfileId?: string | undefined;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    provider: string;
    status?: EnvironmentStatus | undefined;
    environmentConfigurationId?: string | redacted.Redacted<string> | undefined;
    environmentConfigurationName?: string | redacted.Redacted<string> | undefined;
}
export type EnvironmentSummaries = EnvironmentSummary[];
export interface ListEnvironmentsOutput {
    items: EnvironmentSummary[];
    nextToken?: string | undefined;
}
export interface ListJobRunsInput {
    domainIdentifier: string;
    jobIdentifier: string;
    status?: JobRunStatus | undefined;
    sortOrder?: SortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface JobRunSummary {
    domainId?: string | undefined;
    jobId?: string | undefined;
    jobType?: JobType | undefined;
    runId?: string | undefined;
    runMode?: JobRunMode | undefined;
    status?: JobRunStatus | undefined;
    error?: JobRunError | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type JobRunSummaries = JobRunSummary[];
export interface ListJobRunsOutput {
    items?: JobRunSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListLineageEventsInput {
    domainIdentifier: string;
    maxResults?: number | undefined;
    timestampAfter?: Date | undefined;
    timestampBefore?: Date | undefined;
    processingStatus?: LineageEventProcessingStatus | undefined;
    sortOrder?: SortOrder | undefined;
    nextToken?: string | undefined;
}
export type OpenLineageRunState = "START" | "RUNNING" | "COMPLETE" | "ABORT" | "FAIL" | "OTHER" | (string & {});
export interface NameIdentifier {
    name?: string | undefined;
    namespace?: string | undefined;
}
export type NameIdentifiers = NameIdentifier[];
export interface OpenLineageRunEventSummary {
    eventType?: OpenLineageRunState | undefined;
    runId?: string | undefined;
    job?: NameIdentifier | undefined;
    inputs?: NameIdentifier[] | undefined;
    outputs?: NameIdentifier[] | undefined;
}
export type EventSummary = {
    openLineageRunEventSummary: OpenLineageRunEventSummary;
};
export interface LineageEventSummary {
    id?: string | undefined;
    domainId?: string | undefined;
    processingStatus?: LineageEventProcessingStatus | undefined;
    eventTime?: Date | undefined;
    eventSummary?: EventSummary | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
}
export type LineageEventSummaries = LineageEventSummary[];
export interface ListLineageEventsOutput {
    items?: LineageEventSummary[] | undefined;
    nextToken?: string | undefined;
}
export type EdgeDirection = "UPSTREAM" | "DOWNSTREAM" | (string & {});
export interface ListLineageNodeHistoryInput {
    domainIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    identifier: string;
    direction?: EdgeDirection | undefined;
    eventTimestampGTE?: Date | undefined;
    eventTimestampLTE?: Date | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface LineageNodeSummary {
    domainId: string;
    name?: string | undefined;
    description?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    id: string;
    typeName: string;
    typeRevision?: string | undefined;
    sourceIdentifier?: string | undefined;
    eventTimestamp?: Date | undefined;
}
export type LineageNodeSummaries = LineageNodeSummary[];
export interface ListLineageNodeHistoryOutput {
    nodes?: LineageNodeSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListMetadataGenerationRunsInput {
    domainIdentifier: string;
    status?: MetadataGenerationRunStatus | undefined;
    type?: MetadataGenerationRunType | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    targetIdentifier?: string | undefined;
}
export interface MetadataGenerationRunItem {
    domainId: string;
    id: string;
    target?: MetadataGenerationRunTarget | undefined;
    status?: MetadataGenerationRunStatus | undefined;
    type?: MetadataGenerationRunType | undefined;
    types?: MetadataGenerationRunType[] | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    owningProjectId: string;
}
export type MetadataGenerationRuns = MetadataGenerationRunItem[];
export interface ListMetadataGenerationRunsOutput {
    items?: MetadataGenerationRunItem[] | undefined;
    nextToken?: string | undefined;
}
export interface ListNotebookRunsInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    notebookIdentifier?: string | undefined;
    status?: NotebookRunStatus | undefined;
    scheduleIdentifier?: string | undefined;
    maxResults?: number | undefined;
    sortOrder?: SortOrder | undefined;
    nextToken?: string | undefined;
}
export interface NotebookRunSummary {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    scheduleId?: string | undefined;
    status: NotebookRunStatus;
    triggerSource?: TriggerSource | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    startedAt?: Date | undefined;
    completedAt?: Date | undefined;
}
export type NotebookRunSummaryList = NotebookRunSummary[];
export interface ListNotebookRunsOutput {
    items?: NotebookRunSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SortKey = "CREATED_AT" | "UPDATED_AT" | (string & {});
export interface ListNotebooksInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    maxResults?: number | undefined;
    sortOrder?: SortOrder | undefined;
    sortBy?: SortKey | undefined;
    status?: NotebookStatus | undefined;
    type?: NotebookType | undefined;
    nextToken?: string | undefined;
}
export interface NotebookSummary {
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    domainId: string;
    status: NotebookStatus;
    type?: NotebookType | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
}
export type NotebookSummaryList = NotebookSummary[];
export interface ListNotebooksOutput {
    items?: NotebookSummary[] | undefined;
    nextToken?: string | undefined;
}
export type NotificationType = "TASK" | "EVENT" | (string & {});
export type NotificationSubjects = string[];
export type TaskStatus = "ACTIVE" | "INACTIVE" | (string & {});
export interface ListNotificationsInput {
    domainIdentifier: string;
    type: NotificationType;
    afterTimestamp?: Date | undefined;
    beforeTimestamp?: Date | undefined;
    subjects?: string[] | undefined;
    taskStatus?: TaskStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TaskId = string;
export type NotificationResourceType = "PROJECT" | (string & {});
export interface NotificationResource {
    type: NotificationResourceType;
    id: string;
    name?: string | undefined;
}
export type NotificationRole = "PROJECT_OWNER" | "PROJECT_CONTRIBUTOR" | "PROJECT_VIEWER" | "DOMAIN_OWNER" | "PROJECT_SUBSCRIBER" | (string & {});
export interface Topic {
    subject: string;
    resource: NotificationResource;
    role: NotificationRole;
}
export type Title = string | redacted.Redacted<string>;
export type Message = string | redacted.Redacted<string>;
export type ActionLink = string | redacted.Redacted<string>;
export type MetadataMap = {
    [key: string]: string | undefined;
};
export interface NotificationOutput {
    identifier: string;
    domainIdentifier: string;
    type: NotificationType;
    topic: Topic;
    title: string | redacted.Redacted<string>;
    message: string | redacted.Redacted<string>;
    status?: TaskStatus | undefined;
    actionLink: string | redacted.Redacted<string>;
    creationTimestamp: Date;
    lastUpdatedTimestamp: Date;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NotificationsList = NotificationOutput[];
export interface ListNotificationsOutput {
    notifications?: NotificationOutput[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPolicyGrantsInput {
    domainIdentifier: string;
    entityType: TargetEntityType;
    entityIdentifier: string;
    policyType: ManagedPolicyType;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface PolicyGrantMember {
    principal?: PolicyGrantPrincipal | undefined;
    detail?: PolicyGrantDetail | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    grantId?: string | undefined;
}
export type PolicyGrantList = PolicyGrantMember[];
export interface ListPolicyGrantsOutput {
    grantList: PolicyGrantMember[];
    nextToken?: string | undefined;
}
export type SortFieldProject = "NAME" | (string & {});
export interface ListProjectMembershipsInput {
    domainIdentifier: string;
    projectIdentifier: string;
    sortBy?: SortFieldProject | undefined;
    sortOrder?: SortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface UserDetails {
    userId: string;
}
export interface GroupDetails {
    groupId: string;
}
export type MemberDetails = {
    user: UserDetails;
    group?: undefined;
} | {
    user?: undefined;
    group: GroupDetails;
};
export interface ProjectMember {
    memberDetails: MemberDetails;
    designation: UserDesignation;
    userCreatedDesignationId?: string | undefined;
}
export type ProjectMembers = ProjectMember[];
export interface ListProjectMembershipsOutput {
    members: ProjectMember[];
    nextToken?: string | undefined;
}
export interface ListProjectProfilesInput {
    domainIdentifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    sortBy?: SortFieldProject | undefined;
    sortOrder?: SortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ProjectProfileSummary {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: Status | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    domainUnitId?: string | undefined;
}
export type ProjectProfileSummaries = ProjectProfileSummary[];
export interface ListProjectProfilesOutput {
    items?: ProjectProfileSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListProjectsInput {
    domainIdentifier: string;
    userIdentifier?: string | undefined;
    groupIdentifier?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    projectCategory?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ProjectSummary {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    projectStatus?: ProjectStatus | undefined;
    failureReasons?: ProjectDeletionError[] | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    domainUnitId?: string | undefined;
    projectCategory?: string | undefined;
}
export type ProjectSummaries = ProjectSummary[];
export interface ListProjectsOutput {
    items?: ProjectSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ProjectIds = string[];
export type AssetTypeIdentifiers = string[];
export interface ListRulesInput {
    domainIdentifier: string;
    targetType: RuleTargetType;
    targetIdentifier: string;
    ruleType?: RuleType | undefined;
    action?: RuleAction | undefined;
    projectIds?: string[] | undefined;
    assetTypes?: string[] | undefined;
    dataProduct?: boolean | undefined;
    includeCascaded?: boolean | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RuleSummary {
    identifier?: string | undefined;
    revision?: string | undefined;
    ruleType?: RuleType | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    targetType?: RuleTargetType | undefined;
    target?: RuleTarget | undefined;
    action?: RuleAction | undefined;
    scope?: RuleScope | undefined;
    updatedAt?: Date | undefined;
    lastUpdatedBy?: string | undefined;
}
export type RuleSummaries = RuleSummary[];
export interface ListRulesOutput {
    items: RuleSummary[];
    nextToken?: string | undefined;
}
export interface ListSubscriptionGrantsInput {
    domainIdentifier: string;
    environmentId?: string | undefined;
    subscriptionTargetId?: string | undefined;
    subscribedListingId?: string | undefined;
    subscriptionId?: string | undefined;
    owningProjectId?: string | undefined;
    owningIamPrincipalArn?: string | undefined;
    owningUserId?: string | undefined;
    owningGroupId?: string | undefined;
    sortBy?: SortKey | undefined;
    sortOrder?: SortOrder | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SubscriptionGrantSummary {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string | undefined;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[] | undefined;
    subscriptionId?: string | undefined;
}
export type SubscriptionGrants = SubscriptionGrantSummary[];
export interface ListSubscriptionGrantsOutput {
    items: SubscriptionGrantSummary[];
    nextToken?: string | undefined;
}
export interface ListSubscriptionRequestsInput {
    domainIdentifier: string;
    status?: SubscriptionRequestStatus | undefined;
    subscribedListingId?: string | undefined;
    owningProjectId?: string | undefined;
    owningIamPrincipalArn?: string | undefined;
    approverProjectId?: string | undefined;
    owningUserId?: string | undefined;
    owningGroupId?: string | undefined;
    sortBy?: SortKey | undefined;
    sortOrder?: SortOrder | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface MetadataFormSummary {
    formName?: string | undefined;
    typeName: string | redacted.Redacted<string>;
    typeRevision: string;
}
export type MetadataFormsSummary = MetadataFormSummary[];
export interface SubscriptionRequestSummary {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string | undefined;
    decisionComment?: string | redacted.Redacted<string> | undefined;
    existingSubscriptionId?: string | undefined;
    metadataFormsSummary?: MetadataFormSummary[] | undefined;
}
export type SubscriptionRequests = SubscriptionRequestSummary[];
export interface ListSubscriptionRequestsOutput {
    items: SubscriptionRequestSummary[];
    nextToken?: string | undefined;
}
export interface ListSubscriptionsInput {
    domainIdentifier: string;
    subscriptionRequestIdentifier?: string | undefined;
    status?: SubscriptionStatus | undefined;
    subscribedListingId?: string | undefined;
    owningProjectId?: string | undefined;
    owningIamPrincipalArn?: string | undefined;
    owningUserId?: string | undefined;
    owningGroupId?: string | undefined;
    approverProjectId?: string | undefined;
    sortBy?: SortKey | undefined;
    sortOrder?: SortOrder | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SubscriptionSummary {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionStatus;
    createdAt: Date;
    updatedAt: Date;
    subscribedPrincipal: SubscribedPrincipal;
    subscribedListing: SubscribedListing;
    subscriptionRequestId?: string | undefined;
    retainPermissions?: boolean | undefined;
}
export type Subscriptions = SubscriptionSummary[];
export interface ListSubscriptionsOutput {
    items: SubscriptionSummary[];
    nextToken?: string | undefined;
}
export interface ListSubscriptionTargetsInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    sortBy?: SortKey | undefined;
    sortOrder?: SortOrder | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SubscriptionTargetSummary {
    id: string;
    authorizedPrincipals: string[];
    domainId: string;
    projectId: string;
    environmentId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    createdBy: string;
    updatedBy?: string | undefined;
    createdAt: Date;
    updatedAt?: Date | undefined;
    manageAccessRole?: string | undefined;
    applicableAssetTypes: string[];
    subscriptionTargetConfig: SubscriptionTargetForm[];
    provider: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode | undefined;
}
export type SubscriptionTargets = SubscriptionTargetSummary[];
export interface ListSubscriptionTargetsOutput {
    items: SubscriptionTargetSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTimeSeriesDataPointsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: TimeSeriesEntityType;
    formName: string;
    startedAt?: Date | undefined;
    endedAt?: Date | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListTimeSeriesDataPointsOutput {
    items?: TimeSeriesDataPointSummaryFormOutput[] | undefined;
    nextToken?: string | undefined;
}
export interface PostLineageEventInput {
    domainIdentifier: string;
    event: T.StreamingInputBody;
    clientToken?: string | undefined;
}
export interface PostLineageEventOutput {
    id?: string | undefined;
    domainId?: string | undefined;
}
export interface TimeSeriesDataPointFormInput {
    formName: string;
    typeIdentifier: string;
    typeRevision?: string | undefined;
    timestamp: Date;
    content?: string | undefined;
}
export type TimeSeriesDataPointFormInputList = TimeSeriesDataPointFormInput[];
export interface PostTimeSeriesDataPointsInput {
    domainIdentifier: string;
    entityIdentifier: string;
    entityType: TimeSeriesEntityType;
    forms: TimeSeriesDataPointFormInput[];
    clientToken?: string | undefined;
}
export type TimeSeriesDataPointFormOutputList = TimeSeriesDataPointFormOutput[];
export interface PostTimeSeriesDataPointsOutput {
    domainId?: string | undefined;
    entityId?: string | undefined;
    entityType?: TimeSeriesEntityType | undefined;
    forms?: TimeSeriesDataPointFormOutput[] | undefined;
}
export interface PutDataExportConfigurationInput {
    domainIdentifier: string;
    enableExport: boolean;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    clientToken?: string | undefined;
}
export interface PutDataExportConfigurationOutput {
}
export interface PutResourceConfiguration {
    name: string;
    description?: string | undefined;
    region: string;
    parameters: {
        [key: string]: string | undefined;
    };
}
export type PutResourceConfigurations = PutResourceConfiguration[];
export type GlobalParameterMap = {
    [key: string]: string | undefined;
};
export interface PutEnvironmentBlueprintConfigurationInput {
    domainIdentifier: string;
    environmentBlueprintIdentifier: string;
    provisioningRoleArn?: string | undefined;
    manageAccessRoleArn?: string | undefined;
    environmentRolePermissionBoundary?: string | undefined;
    enabledRegions: string[];
    regionalParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    resourceConfigurations?: PutResourceConfiguration[] | undefined;
    allowUserProvidedConfigurations?: boolean | undefined;
    globalParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    provisioningConfigurations?: ProvisioningConfiguration[] | undefined;
}
export interface PutEnvironmentBlueprintConfigurationOutput {
    domainId: string;
    environmentBlueprintId: string;
    provisioningRoleArn?: string | undefined;
    environmentRolePermissionBoundary?: string | undefined;
    manageAccessRoleArn?: string | undefined;
    enabledRegions?: string[] | undefined;
    regionalParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    allowUserProvidedConfigurations?: boolean | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    resourceConfigurations?: ResourceConfiguration[] | undefined;
    provisioningConfigurations?: ProvisioningConfiguration[] | undefined;
}
export type RelationType = "LINEAGE" | (string & {});
export type RelationDirection = "IN" | "OUT" | (string & {});
export interface RelationPattern {
    relationType: RelationType;
    relationDirection: RelationDirection;
    maxPathLength?: number | undefined;
}
export type GraphEntityType = "LINEAGE_NODE" | (string & {});
export type Attribute = string;
export type FilterOperator = "EQ" | "LE" | "LT" | "GE" | "GT" | "TEXT_SEARCH" | (string & {});
export interface Filter {
    attribute: string;
    value?: string | undefined;
    intValue?: number | undefined;
    operator?: FilterOperator | undefined;
}
export type FilterList = FilterClause[];
export type FilterClause = {
    filter: Filter;
    and?: undefined;
    or?: undefined;
} | {
    filter?: undefined;
    and: FilterClause[];
    or?: undefined;
} | {
    filter?: undefined;
    and?: undefined;
    or: FilterClause[];
};
export interface EntityPattern {
    entityType: GraphEntityType;
    identifier: string;
    filters?: FilterClause | undefined;
}
export type MatchClause = {
    relationPattern: RelationPattern;
    entityPattern?: undefined;
} | {
    relationPattern?: undefined;
    entityPattern: EntityPattern;
};
export type MatchClauses = MatchClause[];
export type FormNameList = string[];
export interface AdditionalAttributes {
    formNames?: string[] | undefined;
}
export interface QueryGraphInput {
    domainIdentifier: string;
    match: MatchClause[];
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    additionalAttributes?: AdditionalAttributes | undefined;
}
export type LineageNodeIds = string[];
export interface LineageNodeItem {
    domainId: string;
    name?: string | undefined;
    description?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    id: string;
    typeName: string;
    typeRevision?: string | undefined;
    sourceIdentifier?: string | undefined;
    eventTimestamp?: Date | undefined;
    formsOutput?: FormOutput[] | undefined;
    upstreamLineageNodeIds?: string[] | undefined;
    downstreamLineageNodeIds?: string[] | undefined;
}
export type ResultItem = {
    lineageNode: LineageNodeItem;
};
export type ResultItemList = ResultItem[];
export interface QueryGraphOutput {
    items?: ResultItem[] | undefined;
    nextToken?: string | undefined;
}
export type RejectRuleBehavior = "ALL" | "NONE" | (string & {});
export interface RejectRule {
    rule?: RejectRuleBehavior | undefined;
    threshold?: number | undefined;
}
export type PredictionChoices = number[];
export interface RejectChoice {
    predictionTarget?: string | undefined;
    predictionChoices?: number[] | undefined;
}
export type RejectChoices = RejectChoice[];
export interface RejectPredictionsInput {
    domainIdentifier: string;
    identifier: string;
    revision?: string | undefined;
    rejectRule?: RejectRule | undefined;
    rejectChoices?: RejectChoice[] | undefined;
    clientToken?: string | undefined;
}
export interface RejectPredictionsOutput {
    domainId: string;
    assetId: string;
    assetRevision: string;
}
export interface RejectSubscriptionRequestInput {
    domainIdentifier: string;
    identifier: string;
    decisionComment?: string | redacted.Redacted<string> | undefined;
}
export interface RejectSubscriptionRequestOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string | undefined;
    decisionComment?: string | redacted.Redacted<string> | undefined;
    existingSubscriptionId?: string | undefined;
    metadataForms?: FormOutput[] | undefined;
}
export interface RemoveEntityOwnerInput {
    domainIdentifier: string;
    entityType: DataZoneEntityType;
    entityIdentifier: string;
    owner: OwnerProperties;
    clientToken?: string | undefined;
}
export interface RemoveEntityOwnerOutput {
}
export interface RemovePolicyGrantInput {
    domainIdentifier: string;
    entityType: TargetEntityType;
    entityIdentifier: string;
    policyType: ManagedPolicyType;
    principal: PolicyGrantPrincipal;
    grantIdentifier?: string | undefined;
    clientToken?: string | undefined;
}
export interface RemovePolicyGrantOutput {
}
export interface RevokeSubscriptionInput {
    domainIdentifier: string;
    identifier: string;
    retainPermissions?: boolean | undefined;
}
export interface RevokeSubscriptionOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionStatus;
    createdAt: Date;
    updatedAt: Date;
    subscribedPrincipal: SubscribedPrincipal;
    subscribedListing: SubscribedListing;
    subscriptionRequestId?: string | undefined;
    retainPermissions?: boolean | undefined;
}
export type InventorySearchScope = "ASSET" | "GLOSSARY" | "GLOSSARY_TERM" | "DATA_PRODUCT" | (string & {});
export type SearchText = string;
export interface SearchInItem {
    attribute: string;
}
export type SearchInList = SearchInItem[];
export interface SearchSort {
    attribute: string;
    order?: SortOrder | undefined;
}
export type SearchOutputAdditionalAttribute = "FORMS" | "TIME_SERIES_DATA_POINT_FORMS" | "TEXT_MATCH_RATIONALE" | (string & {});
export type SearchOutputAdditionalAttributes = SearchOutputAdditionalAttribute[];
export interface SearchInput {
    domainIdentifier: string;
    owningProjectIdentifier?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    searchScope: InventorySearchScope;
    searchText?: string | undefined;
    searchIn?: SearchInItem[] | undefined;
    filters?: FilterClause | undefined;
    sort?: SearchSort | undefined;
    additionalAttributes?: SearchOutputAdditionalAttribute[] | undefined;
}
export interface MatchOffset {
    startOffset?: number | undefined;
    endOffset?: number | undefined;
}
export type MatchOffsets = MatchOffset[];
export interface TextMatchItem {
    attribute?: string | undefined;
    text?: string | undefined;
    matchOffsets?: MatchOffset[] | undefined;
}
export type TextMatches = TextMatchItem[];
export type MatchRationaleItem = {
    textMatches: TextMatchItem[];
};
export type MatchRationale = MatchRationaleItem[];
export interface GlossaryItemAdditionalAttributes {
    matchRationale?: MatchRationaleItem[] | undefined;
}
export interface GlossaryItem {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    description?: string | redacted.Redacted<string> | undefined;
    status: GlossaryStatus;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    additionalAttributes?: GlossaryItemAdditionalAttributes | undefined;
}
export interface GlossaryTermItemAdditionalAttributes {
    matchRationale?: MatchRationaleItem[] | undefined;
}
export interface GlossaryTermItem {
    domainId: string;
    glossaryId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    shortDescription?: string | redacted.Redacted<string> | undefined;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
    longDescription?: string | redacted.Redacted<string> | undefined;
    termRelations?: TermRelations | undefined;
    status: GlossaryTermStatus;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    additionalAttributes?: GlossaryTermItemAdditionalAttributes | undefined;
}
export interface AssetItemAdditionalAttributes {
    formsOutput?: FormOutput[] | undefined;
    readOnlyFormsOutput?: FormOutput[] | undefined;
    latestTimeSeriesDataPointFormsOutput?: TimeSeriesDataPointSummaryFormOutput[] | undefined;
    matchRationale?: MatchRationaleItem[] | undefined;
}
export interface AssetItem {
    domainId: string;
    identifier: string;
    name: string | redacted.Redacted<string>;
    typeIdentifier: string;
    typeRevision: string;
    externalIdentifier?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    firstRevisionCreatedAt?: Date | undefined;
    firstRevisionCreatedBy?: string | undefined;
    glossaryTerms?: string[] | undefined;
    owningProjectId: string;
    additionalAttributes?: AssetItemAdditionalAttributes | undefined;
    governedGlossaryTerms?: string[] | undefined;
}
export interface DataProductItemAdditionalAttributes {
    matchRationale?: MatchRationaleItem[] | undefined;
}
export interface DataProductResultItem {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    description?: string | redacted.Redacted<string> | undefined;
    glossaryTerms?: string[] | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    firstRevisionCreatedAt?: Date | undefined;
    firstRevisionCreatedBy?: string | undefined;
    additionalAttributes?: DataProductItemAdditionalAttributes | undefined;
}
export type SearchInventoryResultItem = {
    glossaryItem: GlossaryItem;
    glossaryTermItem?: undefined;
    assetItem?: undefined;
    dataProductItem?: undefined;
} | {
    glossaryItem?: undefined;
    glossaryTermItem: GlossaryTermItem;
    assetItem?: undefined;
    dataProductItem?: undefined;
} | {
    glossaryItem?: undefined;
    glossaryTermItem?: undefined;
    assetItem: AssetItem;
    dataProductItem?: undefined;
} | {
    glossaryItem?: undefined;
    glossaryTermItem?: undefined;
    assetItem?: undefined;
    dataProductItem: DataProductResultItem;
};
export type SearchInventoryResultItems = SearchInventoryResultItem[];
export interface SearchOutput {
    items?: SearchInventoryResultItem[] | undefined;
    nextToken?: string | undefined;
    totalMatchCount?: number | undefined;
}
export type GroupSearchType = "SSO_GROUP" | "DATAZONE_SSO_GROUP" | "IAM_ROLE_SESSION_GROUP" | (string & {});
export type GroupSearchText = string | redacted.Redacted<string>;
export interface SearchGroupProfilesInput {
    domainIdentifier: string;
    groupType: GroupSearchType;
    searchText?: string | redacted.Redacted<string> | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GroupProfileSummary {
    domainId?: string | undefined;
    id?: string | undefined;
    status?: GroupProfileStatus | undefined;
    groupName?: string | redacted.Redacted<string> | undefined;
    rolePrincipalArn?: string | undefined;
    rolePrincipalId?: string | undefined;
}
export type GroupProfileSummaries = GroupProfileSummary[];
export interface SearchGroupProfilesOutput {
    items?: GroupProfileSummary[] | undefined;
    nextToken?: string | undefined;
}
export type AggregationDisplayValue = string;
export interface AggregationListItem {
    attribute: string;
    displayValue?: string | undefined;
}
export type AggregationList = AggregationListItem[];
export interface SearchListingsInput {
    domainIdentifier: string;
    searchText?: string | undefined;
    searchIn?: SearchInItem[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: FilterClause | undefined;
    aggregations?: AggregationListItem[] | undefined;
    sort?: SearchSort | undefined;
    additionalAttributes?: SearchOutputAdditionalAttribute[] | undefined;
}
export interface AssetListingItemAdditionalAttributes {
    forms?: string | undefined;
    matchRationale?: MatchRationaleItem[] | undefined;
    latestTimeSeriesDataPointForms?: TimeSeriesDataPointSummaryFormOutput[] | undefined;
}
export interface AssetListingItem {
    listingId?: string | undefined;
    listingRevision?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    entityId?: string | undefined;
    entityRevision?: string | undefined;
    entityType?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    listingCreatedBy?: string | undefined;
    listingUpdatedBy?: string | undefined;
    glossaryTerms?: DetailedGlossaryTerm[] | undefined;
    governedGlossaryTerms?: DetailedGlossaryTerm[] | undefined;
    owningProjectId?: string | undefined;
    additionalAttributes?: AssetListingItemAdditionalAttributes | undefined;
}
export interface DataProductListingItemAdditionalAttributes {
    forms?: string | undefined;
    matchRationale?: MatchRationaleItem[] | undefined;
}
export interface ListingSummaryItem {
    listingId?: string | undefined;
    listingRevision?: string | undefined;
    glossaryTerms?: DetailedGlossaryTerm[] | undefined;
}
export type ListingSummaryItems = ListingSummaryItem[];
export interface DataProductListingItem {
    listingId?: string | undefined;
    listingRevision?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    entityId?: string | undefined;
    entityRevision?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    listingCreatedBy?: string | undefined;
    listingUpdatedBy?: string | undefined;
    glossaryTerms?: DetailedGlossaryTerm[] | undefined;
    owningProjectId?: string | undefined;
    additionalAttributes?: DataProductListingItemAdditionalAttributes | undefined;
    items?: ListingSummaryItem[] | undefined;
}
export type SearchResultItem = {
    assetListing: AssetListingItem;
    dataProductListing?: undefined;
} | {
    assetListing?: undefined;
    dataProductListing: DataProductListingItem;
};
export type SearchResultItems = SearchResultItem[];
export type AggregationAttributeValue = string;
export type AggregationAttributeDisplayValue = string;
export interface AggregationOutputItem {
    value?: string | undefined;
    count?: number | undefined;
    displayValue?: string | undefined;
}
export type AggregationOutputItems = AggregationOutputItem[];
export interface AggregationOutput {
    attribute?: string | undefined;
    displayValue?: string | undefined;
    items?: AggregationOutputItem[] | undefined;
}
export type AggregationOutputList = AggregationOutput[];
export interface SearchListingsOutput {
    items?: SearchResultItem[] | undefined;
    nextToken?: string | undefined;
    totalMatchCount?: number | undefined;
    aggregates?: AggregationOutput[] | undefined;
}
export type TypesSearchScope = "ASSET_TYPE" | "FORM_TYPE" | "LINEAGE_NODE_TYPE" | (string & {});
export interface SearchTypesInput {
    domainIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    searchScope: TypesSearchScope;
    searchText?: string | undefined;
    searchIn?: SearchInItem[] | undefined;
    filters?: FilterClause | undefined;
    sort?: SearchSort | undefined;
    managed: boolean;
}
export interface AssetTypeItem {
    domainId: string;
    name: string;
    revision: string;
    description?: string | redacted.Redacted<string> | undefined;
    formsOutput: {
        [key: string]: FormEntryOutput | undefined;
    };
    owningProjectId: string;
    originDomainId?: string | undefined;
    originProjectId?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
}
export interface FormTypeData {
    domainId: string;
    name: string | redacted.Redacted<string>;
    revision: string;
    model?: Model | undefined;
    status?: FormTypeStatus | undefined;
    owningProjectId?: string | undefined;
    originDomainId?: string | undefined;
    originProjectId?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    imports?: Import[] | undefined;
}
export interface LineageNodeTypeItem {
    domainId: string;
    name?: string | undefined;
    description?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    revision: string;
    formsOutput: {
        [key: string]: FormEntryOutput | undefined;
    };
}
export type SearchTypesResultItem = {
    assetTypeItem: AssetTypeItem;
    formTypeItem?: undefined;
    lineageNodeTypeItem?: undefined;
} | {
    assetTypeItem?: undefined;
    formTypeItem: FormTypeData;
    lineageNodeTypeItem?: undefined;
} | {
    assetTypeItem?: undefined;
    formTypeItem?: undefined;
    lineageNodeTypeItem: LineageNodeTypeItem;
};
export type SearchTypesResultItems = SearchTypesResultItem[];
export interface SearchTypesOutput {
    items?: SearchTypesResultItem[] | undefined;
    nextToken?: string | undefined;
    totalMatchCount?: number | undefined;
}
export type UserSearchType = "SSO_USER" | "DATAZONE_USER" | "DATAZONE_SSO_USER" | "DATAZONE_IAM_USER" | (string & {});
export type UserSearchText = string | redacted.Redacted<string>;
export interface SearchUserProfilesInput {
    domainIdentifier: string;
    userType: UserSearchType;
    searchText?: string | redacted.Redacted<string> | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface UserProfileSummary {
    domainId?: string | undefined;
    id?: string | undefined;
    type?: UserProfileType | undefined;
    status?: UserProfileStatus | undefined;
    details?: UserProfileDetails | undefined;
}
export type UserProfileSummaries = UserProfileSummary[];
export interface SearchUserProfilesOutput {
    items?: UserProfileSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface StartDataSourceRunInput {
    domainIdentifier: string;
    dataSourceIdentifier: string;
    clientToken?: string | undefined;
}
export interface StartDataSourceRunOutput {
    domainId: string;
    dataSourceId: string;
    id: string;
    projectId: string;
    status: DataSourceRunStatus;
    type: DataSourceRunType;
    dataSourceConfigurationSnapshot?: string | undefined;
    runStatisticsForAssets?: RunStatisticsForAssets | undefined;
    errorMessage?: DataSourceErrorMessage | undefined;
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date | undefined;
    stoppedAt?: Date | undefined;
}
export interface StartMetadataGenerationRunInput {
    domainIdentifier: string;
    type?: MetadataGenerationRunType | undefined;
    types?: MetadataGenerationRunType[] | undefined;
    target: MetadataGenerationRunTarget;
    clientToken?: string | undefined;
    owningProjectIdentifier: string;
}
export interface StartMetadataGenerationRunOutput {
    domainId: string;
    id: string;
    status?: MetadataGenerationRunStatus | undefined;
    type?: MetadataGenerationRunType | undefined;
    types?: MetadataGenerationRunType[] | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    owningProjectId?: string | undefined;
}
export interface StartNotebookExportInput {
    domainIdentifier: string;
    notebookIdentifier: string;
    owningProjectIdentifier: string;
    fileFormat: FileFormat;
    clientToken?: string | undefined;
}
export interface StartNotebookExportOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    fileFormat: FileFormat;
    status: NotebookExportStatus;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
}
export type S3SourceLocation = string | redacted.Redacted<string>;
export type S3BucketName = string | redacted.Redacted<string>;
export type S3ObjectKey = string | redacted.Redacted<string>;
export interface S3File {
    key: string | redacted.Redacted<string>;
}
export type S3FileList = S3File[];
export interface S3FilesLocation {
    bucket: string | redacted.Redacted<string>;
    fileList: S3File[];
}
export type SourceLocation = {
    s3: string | redacted.Redacted<string>;
    s3Files?: undefined;
} | {
    s3?: undefined;
    s3Files: S3FilesLocation;
};
export interface StartNotebookImportInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    sourceLocation: SourceLocation;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    type?: NotebookType | undefined;
    clientToken?: string | undefined;
}
export interface StartNotebookImportOutput {
    notebookId?: string | undefined;
    status?: NotebookStatus | undefined;
    domainId?: string | undefined;
    owningProjectId?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    type?: NotebookType | undefined;
    sourceLocation?: SourceLocation | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
}
export interface StartNotebookRunInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    notebookIdentifier: string;
    scheduleIdentifier?: string | undefined;
    computeConfiguration?: ComputeConfig | undefined;
    networkConfiguration?: NetworkConfig | undefined;
    timeoutConfiguration?: TimeoutConfig | undefined;
    notificationConfiguration?: NotificationConfig | undefined;
    triggerSource?: TriggerSource | undefined;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export interface StartNotebookRunOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    notebookId: string;
    scheduleId?: string | undefined;
    status: NotebookRunStatus;
    cellOrder?: CellInformation[] | undefined;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    computeConfiguration?: ComputeConfig | undefined;
    networkConfiguration?: NetworkConfig | undefined;
    timeoutConfiguration?: TimeoutConfig | undefined;
    environmentConfiguration?: EnvironmentConfig | undefined;
    storageConfiguration?: StorageConfig | undefined;
    notificationConfiguration?: NotificationConfig | undefined;
    triggerSource?: TriggerSource | undefined;
    error?: NotebookRunError | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    startedAt?: Date | undefined;
    completedAt?: Date | undefined;
}
export interface StartNotebookSyncInput {
    domainIdentifier: string;
    owningProjectIdentifier: string;
    sourceLocation: SourceLocation;
    gitMetadata?: GitMetadata | undefined;
    notebookId?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
}
export interface StartNotebookSyncOutput {
    notebookId?: string | undefined;
    status?: NotebookStatus | undefined;
    domainId?: string | undefined;
    owningProjectId?: string | undefined;
    sourceLocation?: SourceLocation | undefined;
    gitMetadata?: GitMetadata | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
}
export interface StopNotebookRunInput {
    domainIdentifier: string;
    identifier: string;
    clientToken?: string | undefined;
}
export interface StopNotebookRunOutput {
    id: string;
    domainId: string;
    owningProjectId: string;
    status: NotebookRunStatus;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccountPoolInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    resolutionStrategy?: ResolutionStrategy | undefined;
    accountSource?: AccountSource | undefined;
}
export interface UpdateAccountPoolOutput {
    domainId?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    id?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    resolutionStrategy?: ResolutionStrategy | undefined;
    accountSource: AccountSource;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    domainUnitId?: string | undefined;
}
export interface UpdateAssetFilterInput {
    domainIdentifier: string;
    assetIdentifier: string;
    identifier: string;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    configuration?: AssetFilterConfiguration | undefined;
}
export interface UpdateAssetFilterOutput {
    id: string;
    domainId: string;
    assetId: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: FilterStatus | undefined;
    configuration: AssetFilterConfiguration;
    createdAt?: Date | undefined;
    errorMessage?: string | undefined;
    effectiveColumnNames?: string[] | undefined;
    effectiveRowFilter?: string | undefined;
}
export interface AthenaPropertiesPatch {
    workgroupName?: string | undefined;
}
export interface OAuth2PropertiesPatch {
    oAuth2GrantType?: OAuth2GrantType | undefined;
    oAuth2ClientApplication?: OAuth2ClientApplication | undefined;
    tokenUrl?: string | undefined;
    tokenUrlParametersMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface AuthenticationConfigurationPatch {
    secretArn?: string | undefined;
    basicAuthenticationCredentials?: BasicAuthenticationCredentials | undefined;
    oAuth2Properties?: OAuth2PropertiesPatch | undefined;
}
export interface GlueConnectionPatch {
    description?: string | undefined;
    connectionProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    authenticationConfiguration?: AuthenticationConfigurationPatch | undefined;
}
export interface GluePropertiesPatch {
    glueConnectionInput?: GlueConnectionPatch | undefined;
}
export interface IamPropertiesPatch {
    glueLineageSyncEnabled?: boolean | undefined;
}
export interface RedshiftPropertiesPatch {
    storage?: RedshiftStorageProperties | undefined;
    databaseName?: string | undefined;
    host?: string | undefined;
    port?: number | undefined;
    credentials?: RedshiftCredentials | undefined;
    lineageSync?: RedshiftLineageSyncConfigurationInput | undefined;
}
export interface SparkEmrPropertiesPatch {
    computeArn?: string | undefined;
    instanceProfileArn?: string | undefined;
    javaVirtualEnv?: string | undefined;
    logUri?: string | undefined;
    pythonVirtualEnv?: string | undefined;
    runtimeRole?: string | undefined;
    trustedCertificatesS3Uri?: string | undefined;
    managedEndpointArn?: string | undefined;
}
export interface S3PropertiesPatch {
    s3Uri: string;
    s3AccessGrantLocationId?: string | undefined;
    registerS3AccessGrantLocation?: boolean | undefined;
}
export interface ConnectivityPropertiesPatch {
    description?: string | undefined;
    connectionProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    authenticationConfiguration?: AuthenticationConfigurationPatch | undefined;
}
export interface SnowflakePropertiesPatch {
    connectivityPropertiesPatch?: ConnectivityPropertiesPatch | undefined;
    snowflakeRole?: string | undefined;
    lineageSync?: LineageSyncInput | undefined;
}
export interface AmazonQPropertiesPatch {
    isEnabled: boolean;
    profileArn?: string | undefined;
    authMode?: string | undefined;
}
export interface MlflowPropertiesPatch {
    trackingServerArn?: string | undefined;
}
export interface LakehousePropertiesPatch {
    glueLineageSyncEnabled?: boolean | undefined;
}
export interface VpcPropertiesPatch {
    vpcId?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupId?: string | undefined;
}
export interface GitPropertiesPatch {
    codeConnectionArn?: string | undefined;
    defaultBranch?: string | undefined;
}
export type ConnectionPropertiesPatch = {
    athenaProperties: AthenaPropertiesPatch;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties: GluePropertiesPatch;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties: IamPropertiesPatch;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties: RedshiftPropertiesPatch;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties: SparkEmrPropertiesPatch;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties: S3PropertiesPatch;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties: SnowflakePropertiesPatch;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties: AmazonQPropertiesPatch;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties: MlflowPropertiesPatch;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties: LakehousePropertiesPatch;
    vpcProperties?: undefined;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties: VpcPropertiesPatch;
    gitProperties?: undefined;
} | {
    athenaProperties?: undefined;
    glueProperties?: undefined;
    iamProperties?: undefined;
    redshiftProperties?: undefined;
    sparkEmrProperties?: undefined;
    s3Properties?: undefined;
    snowflakeProperties?: undefined;
    amazonQProperties?: undefined;
    mlflowProperties?: undefined;
    lakehouseProperties?: undefined;
    vpcProperties?: undefined;
    gitProperties: GitPropertiesPatch;
};
export interface UpdateConnectionInput {
    configurations?: Configuration[] | undefined;
    domainIdentifier: string;
    identifier: string;
    description?: string | redacted.Redacted<string> | undefined;
    awsLocation?: AwsLocation | undefined;
    props?: ConnectionPropertiesPatch | undefined;
}
export interface UpdateConnectionOutput {
    configurations?: Configuration[] | undefined;
    connectionId: string;
    description?: string | redacted.Redacted<string> | undefined;
    domainId: string;
    domainUnitId: string;
    environmentId?: string | undefined;
    name: string;
    physicalEndpoints: PhysicalEndpoint[];
    projectId?: string | undefined;
    props?: ConnectionPropertiesOutput | undefined;
    type: ConnectionType;
    scope?: ConnectionScope | undefined;
}
export interface UpdateDataSourceInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    enableSetting?: EnableSetting | undefined;
    publishOnImport?: boolean | undefined;
    assetFormsInput?: FormInput[] | undefined;
    schedule?: ScheduleConfiguration | undefined;
    configuration?: DataSourceConfigurationInput | undefined;
    recommendation?: RecommendationConfiguration | undefined;
    retainPermissionsOnRevokeFailure?: boolean | undefined;
}
export interface UpdateDataSourceOutput {
    id: string;
    status?: DataSourceStatus | undefined;
    type?: string | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    domainId: string;
    projectId: string;
    environmentId?: string | undefined;
    connectionId?: string | undefined;
    configuration?: DataSourceConfigurationOutput | undefined;
    recommendation?: RecommendationConfiguration | undefined;
    enableSetting?: EnableSetting | undefined;
    publishOnImport?: boolean | undefined;
    assetFormsOutput?: FormOutput[] | undefined;
    schedule?: ScheduleConfiguration | undefined;
    lastRunStatus?: DataSourceRunStatus | undefined;
    lastRunAt?: Date | undefined;
    lastRunErrorMessage?: DataSourceErrorMessage | undefined;
    errorMessage?: DataSourceErrorMessage | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    selfGrantStatus?: SelfGrantStatusOutput | undefined;
    retainPermissionsOnRevokeFailure?: boolean | undefined;
}
export interface UpdateDesignationInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    policy?: string | undefined;
    deletionProtection?: boolean | undefined;
}
export interface UpdateDesignationOutput {
    domainId: string;
    id: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    designationType: DesignationType;
    policy: string;
    deletionProtection: boolean;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface UpdateDomainInput {
    identifier: string;
    description?: string | undefined;
    singleSignOn?: SingleSignOn | undefined;
    domainExecutionRole?: string | undefined;
    serviceRole?: string | undefined;
    name?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateDomainOutput {
    id: string;
    rootDomainUnitId?: string | undefined;
    description?: string | undefined;
    singleSignOn?: SingleSignOn | undefined;
    domainExecutionRole?: string | undefined;
    serviceRole?: string | undefined;
    name?: string | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface UpdateDomainUnitInput {
    domainIdentifier: string;
    identifier: string;
    description?: string | redacted.Redacted<string> | undefined;
    name?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateDomainUnitOutput {
    id: string;
    domainId: string;
    name: string | redacted.Redacted<string>;
    owners: DomainUnitOwnerProperties[];
    description?: string | redacted.Redacted<string> | undefined;
    parentDomainUnitId?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    createdBy?: string | undefined;
    lastUpdatedBy?: string | undefined;
}
export interface UpdateEnvironmentInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | undefined;
    description?: string | undefined;
    glossaryTerms?: string[] | undefined;
    blueprintVersion?: string | undefined;
    userParameters?: EnvironmentParameter[] | undefined;
    environmentConfigurationName?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateEnvironmentOutput {
    projectId: string;
    id?: string | undefined;
    domainId: string;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentProfileId?: string | undefined;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    provider: string;
    provisionedResources?: Resource[] | undefined;
    status?: EnvironmentStatus | undefined;
    environmentActions?: ConfigurableEnvironmentAction[] | undefined;
    glossaryTerms?: string[] | undefined;
    userParameters?: CustomParameter[] | undefined;
    lastDeployment?: Deployment | undefined;
    provisioningProperties?: ProvisioningProperties | undefined;
    deploymentProperties?: DeploymentProperties | undefined;
    environmentBlueprintId?: string | undefined;
    environmentConfigurationId?: string | redacted.Redacted<string> | undefined;
    environmentConfigurationName?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateEnvironmentActionInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
    parameters?: ActionParameters | undefined;
    name?: string | undefined;
    description?: string | undefined;
}
export interface UpdateEnvironmentActionOutput {
    domainId: string;
    environmentId: string;
    id: string;
    name: string;
    parameters: ActionParameters;
    description?: string | undefined;
}
export interface UpdateEnvironmentBlueprintInput {
    domainIdentifier: string;
    identifier: string;
    description?: string | undefined;
    provisioningProperties?: ProvisioningProperties | undefined;
    userParameters?: CustomParameter[] | undefined;
    blueprintCategory?: BlueprintCategory | undefined;
}
export interface UpdateEnvironmentBlueprintOutput {
    id: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    provider: string;
    provisioningProperties: ProvisioningProperties;
    deploymentProperties?: DeploymentProperties | undefined;
    userParameters?: CustomParameter[] | undefined;
    glossaryTerms?: string[] | undefined;
    blueprintCategory?: BlueprintCategory | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface UpdateEnvironmentProfileInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | undefined;
    userParameters?: EnvironmentParameter[] | undefined;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
}
export interface UpdateEnvironmentProfileOutput {
    id: string;
    domainId: string;
    awsAccountId?: string | undefined;
    awsAccountRegion?: string | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    environmentBlueprintId: string;
    projectId?: string | undefined;
    userParameters?: CustomParameter[] | undefined;
}
export interface UpdateGlossaryInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    status?: GlossaryStatus | undefined;
    clientToken?: string | undefined;
}
export interface UpdateGlossaryOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    description?: string | redacted.Redacted<string> | undefined;
    status?: GlossaryStatus | undefined;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
}
export interface UpdateGlossaryTermInput {
    domainIdentifier: string;
    glossaryIdentifier?: string | undefined;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    shortDescription?: string | redacted.Redacted<string> | undefined;
    longDescription?: string | redacted.Redacted<string> | undefined;
    termRelations?: TermRelations | undefined;
    status?: GlossaryTermStatus | undefined;
}
export interface UpdateGlossaryTermOutput {
    id: string;
    domainId: string;
    glossaryId: string;
    name: string | redacted.Redacted<string>;
    status: GlossaryTermStatus;
    shortDescription?: string | redacted.Redacted<string> | undefined;
    longDescription?: string | redacted.Redacted<string> | undefined;
    termRelations?: TermRelations | undefined;
    usageRestrictions?: GlossaryUsageRestriction[] | undefined;
}
export interface UpdateGroupProfileInput {
    domainIdentifier: string;
    groupIdentifier: string;
    status: GroupProfileStatus;
}
export interface UpdateGroupProfileOutput {
    domainId?: string | undefined;
    id?: string | undefined;
    status?: GroupProfileStatus | undefined;
    groupName?: string | redacted.Redacted<string> | undefined;
    rolePrincipalArn?: string | undefined;
    rolePrincipalId?: string | undefined;
}
export interface UpdateNotebookInput {
    domainIdentifier: string;
    identifier: string;
    description?: string | redacted.Redacted<string> | undefined;
    status?: NotebookStatus | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    cellOrder?: CellInformation[] | undefined;
    type?: NotebookType | undefined;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    environmentConfiguration?: EnvironmentConfig | undefined;
    clientToken?: string | undefined;
}
export interface UpdateNotebookOutput {
    id: string;
    name: string | redacted.Redacted<string>;
    owningProjectId: string;
    domainId: string;
    cellOrder: CellInformation[];
    status: NotebookStatus;
    type?: NotebookType | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    lockedBy?: string | undefined;
    lockedAt?: Date | undefined;
    lockExpiresAt?: Date | undefined;
    computeId?: string | undefined;
    metadata?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    environmentConfiguration?: EnvironmentConfig | undefined;
    error?: NotebookError | undefined;
    gitMetadata?: GitMetadata | undefined;
}
export interface UpdateProjectInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    glossaryTerms?: string[] | undefined;
    domainUnitId?: string | undefined;
    environmentDeploymentDetails?: EnvironmentDeploymentDetails | undefined;
    userParameters?: EnvironmentConfigurationUserParameter[] | undefined;
    projectProfileVersion?: string | undefined;
}
export interface UpdateProjectOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    projectStatus?: ProjectStatus | undefined;
    failureReasons?: ProjectDeletionError[] | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    resourceTags?: ResourceTag[] | undefined;
    glossaryTerms?: string[] | undefined;
    domainUnitId?: string | undefined;
    projectProfileId?: string | undefined;
    userParameters?: EnvironmentConfigurationUserParameter[] | undefined;
    environmentDeploymentDetails?: EnvironmentDeploymentDetails | undefined;
    projectCategory?: string | undefined;
}
export interface UpdateProjectProfileInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    status?: Status | undefined;
    projectResourceTags?: ResourceTagParameter[] | undefined;
    allowCustomProjectResourceTags?: boolean | undefined;
    projectResourceTagsDescription?: string | redacted.Redacted<string> | undefined;
    environmentConfigurations?: EnvironmentConfiguration[] | undefined;
    domainUnitIdentifier?: string | undefined;
}
export interface UpdateProjectProfileOutput {
    domainId: string;
    id: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    status?: Status | undefined;
    projectResourceTags?: ResourceTagParameter[] | undefined;
    allowCustomProjectResourceTags?: boolean | undefined;
    projectResourceTagsDescription?: string | redacted.Redacted<string> | undefined;
    environmentConfigurations?: EnvironmentConfiguration[] | undefined;
    createdBy: string;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    domainUnitId?: string | undefined;
}
export interface UpdateRootDomainUnitOwnerInput {
    domainIdentifier: string;
    currentOwner: string;
    newOwner: string;
    clientToken?: string | undefined;
}
export interface UpdateRootDomainUnitOwnerOutput {
}
export interface UpdateRuleInput {
    domainIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    scope?: RuleScope | undefined;
    detail?: RuleDetail | undefined;
    includeChildDomainUnits?: boolean | undefined;
}
export interface UpdateRuleOutput {
    identifier: string;
    revision: string;
    name: string | redacted.Redacted<string>;
    ruleType: RuleType;
    target: RuleTarget;
    action: RuleAction;
    scope: RuleScope;
    detail: RuleDetail;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt: Date;
    updatedAt: Date;
    createdBy: string;
    lastUpdatedBy: string;
}
export interface UpdateSubscriptionGrantStatusInput {
    domainIdentifier: string;
    identifier: string;
    assetIdentifier: string;
    status: SubscriptionGrantStatus;
    failureCause?: FailureCause | undefined;
    targetName?: string | undefined;
}
export interface UpdateSubscriptionGrantStatusOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    createdAt: Date;
    updatedAt: Date;
    environmentId?: string | undefined;
    subscriptionTargetId: string;
    grantedEntity: GrantedEntity;
    status: SubscriptionGrantOverallStatus;
    assets?: SubscribedAsset[] | undefined;
    subscriptionId?: string | undefined;
}
export interface UpdateSubscriptionRequestInput {
    domainIdentifier: string;
    identifier: string;
    requestReason: string | redacted.Redacted<string>;
}
export interface UpdateSubscriptionRequestOutput {
    id: string;
    createdBy: string;
    updatedBy?: string | undefined;
    domainId: string;
    status: SubscriptionRequestStatus;
    createdAt: Date;
    updatedAt: Date;
    requestReason: string | redacted.Redacted<string>;
    subscribedPrincipals: SubscribedPrincipal[];
    subscribedListings: SubscribedListing[];
    reviewerId?: string | undefined;
    decisionComment?: string | redacted.Redacted<string> | undefined;
    existingSubscriptionId?: string | undefined;
    metadataForms?: FormOutput[] | undefined;
}
export interface UpdateSubscriptionTargetInput {
    domainIdentifier: string;
    environmentIdentifier: string;
    identifier: string;
    name?: string | redacted.Redacted<string> | undefined;
    authorizedPrincipals?: string[] | undefined;
    applicableAssetTypes?: string[] | undefined;
    subscriptionTargetConfig?: SubscriptionTargetForm[] | undefined;
    manageAccessRole?: string | undefined;
    provider?: string | undefined;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode | undefined;
}
export interface UpdateSubscriptionTargetOutput {
    id: string;
    authorizedPrincipals: string[];
    domainId: string;
    projectId: string;
    environmentId: string;
    name: string | redacted.Redacted<string>;
    type: string;
    createdBy: string;
    updatedBy?: string | undefined;
    createdAt: Date;
    updatedAt?: Date | undefined;
    manageAccessRole?: string | undefined;
    applicableAssetTypes: string[];
    subscriptionTargetConfig: SubscriptionTargetForm[];
    provider: string;
    subscriptionGrantCreationMode?: SubscriptionGrantCreationMode | undefined;
}
export interface UpdateUserProfileInput {
    domainIdentifier: string;
    userIdentifier: string;
    type?: UserProfileType | undefined;
    status: UserProfileStatus;
    sessionName?: string | undefined;
}
export interface UpdateUserProfileOutput {
    domainId?: string | undefined;
    id?: string | undefined;
    type?: UserProfileType | undefined;
    status?: UserProfileStatus | undefined;
    details?: UserProfileDetails | undefined;
}
export type ErrorMessage = string;
export type AcceptPredictionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Accepts automatically generated business-friendly metadata for your Amazon DataZone assets.
 */
export declare const acceptPredictions: API.OperationMethod<AcceptPredictionsInput & RegionInput, AcceptPredictionsOutput, AcceptPredictionsError, Credentials | HttpClient.HttpClient>;
export type AcceptSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Accepts a subscription request to a specific asset.
 */
export declare const acceptSubscriptionRequest: API.OperationMethod<AcceptSubscriptionRequestInput & RegionInput, AcceptSubscriptionRequestOutput, AcceptSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type AddEntityOwnerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Adds the owner of an entity (a domain unit).
 */
export declare const addEntityOwner: API.OperationMethod<AddEntityOwnerInput & RegionInput, AddEntityOwnerOutput, AddEntityOwnerError, Credentials | HttpClient.HttpClient>;
export type AddPolicyGrantError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Adds a policy grant (an authorization policy) to a specified entity, including domain units, environment blueprint configurations, or environment profiles.
 */
export declare const addPolicyGrant: API.OperationMethod<AddPolicyGrantInput & RegionInput, AddPolicyGrantOutput, AddPolicyGrantError, Credentials | HttpClient.HttpClient>;
export type AssociateEnvironmentRoleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Associates the environment role in Amazon DataZone.
 */
export declare const associateEnvironmentRole: API.OperationMethod<AssociateEnvironmentRoleInput & RegionInput, AssociateEnvironmentRoleOutput, AssociateEnvironmentRoleError, Credentials | HttpClient.HttpClient>;
export type AssociateGovernedTermsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Associates governed terms with an asset.
 */
export declare const associateGovernedTerms: API.OperationMethod<AssociateGovernedTermsInput & RegionInput, AssociateGovernedTermsOutput, AssociateGovernedTermsError, Credentials | HttpClient.HttpClient>;
export type BatchGetAttributesMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the attribute metadata.
 */
export declare const batchGetAttributesMetadata: API.OperationMethod<BatchGetAttributesMetadataInput & RegionInput, BatchGetAttributesMetadataOutput, BatchGetAttributesMetadataError, Credentials | HttpClient.HttpClient>;
export type BatchPutAttributesMetadataError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Writes the attribute metadata.
 */
export declare const batchPutAttributesMetadata: API.OperationMethod<BatchPutAttributesMetadataInput & RegionInput, BatchPutAttributesMetadataOutput, BatchPutAttributesMetadataError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataGenerationRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Cancels the metadata generation run.
 *
 * Prerequisites:
 *
 * - The run must exist and be in a cancelable status (e.g., SUBMITTED, IN_PROGRESS).
 *
 * - Runs in SUCCEEDED status cannot be cancelled.
 *
 * - User must have access to the run and cancel permissions.
 */
export declare const cancelMetadataGenerationRun: API.OperationMethod<CancelMetadataGenerationRunInput & RegionInput, CancelMetadataGenerationRunOutput, CancelMetadataGenerationRunError, Credentials | HttpClient.HttpClient>;
export type CancelSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Cancels the subscription to the specified asset.
 */
export declare const cancelSubscription: API.OperationMethod<CancelSubscriptionInput & RegionInput, CancelSubscriptionOutput, CancelSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateAccountPoolError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an account pool.
 */
export declare const createAccountPool: API.OperationMethod<CreateAccountPoolInput & RegionInput, CreateAccountPoolOutput, CreateAccountPoolError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an asset in Amazon DataZone catalog.
 *
 * Before creating assets, make sure that the following requirements are met:
 *
 * - `--domain-identifier` must refer to an existing domain.
 *
 * - `--owning-project-identifier` must be a valid project within the domain.
 *
 * - Asset type must be created beforehand using `create-asset-type`, or be a supported system-defined type. For more information, see create-asset-type.
 *
 * - `--type-revision` (if used) must match a valid revision of the asset type.
 *
 * - `formsInput` is required when it is associated as required in the `asset-type`. For more information, see create-form-type.
 *
 * - Form content must include all required fields as per the form schema (e.g., `bucketArn`).
 *
 * You must invoke the following pre-requisite commands before invoking this API:
 *
 * - CreateFormType
 *
 * - CreateAssetType
 */
export declare const createAsset: API.OperationMethod<CreateAssetInput & RegionInput, CreateAssetOutput, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreateAssetFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a data asset filter.
 *
 * Asset filters provide a sophisticated way to create controlled views of data assets by selecting specific columns or applying row-level filters. This capability is crucial for organizations that need to share data while maintaining security and privacy controls. For example, your database might be filtered to show only non-PII fields to certain users, or sales data might be filtered by region for different regional teams. Asset filters enable fine-grained access control while maintaining a single source of truth.
 *
 * Prerequisites:
 *
 * - A valid domain (`--domain-identifier`) must exist.
 *
 * - A data asset (`--asset-identifier`) must already be created under that domain.
 *
 * - The asset must have the referenced columns available in its schema for column-based filtering.
 *
 * - You cannot specify both (`columnConfiguration`, `rowConfiguration`)at the same time.
 */
export declare const createAssetFilter: API.OperationMethod<CreateAssetFilterInput & RegionInput, CreateAssetFilterOutput, CreateAssetFilterError, Credentials | HttpClient.HttpClient>;
export type CreateAssetRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a revision of the asset.
 *
 * Asset revisions represent new versions of existing assets, capturing changes to either the underlying data or its metadata. They maintain a historical record of how assets evolve over time, who made changes, and when those changes occurred. This versioning capability is crucial for governance and compliance, allowing organizations to track changes, understand their impact, and roll back if necessary.
 *
 * Prerequisites:
 *
 * - Asset must already exist in the domain with identifier.
 *
 * - `formsInput` is required when asset has the form type. `typeRevision` should be the latest version of form type.
 *
 * - The form content must include all required fields (e.g., `bucketArn` for `S3ObjectCollectionForm`).
 *
 * - The owning project of the original asset must still exist and be active.
 *
 * - User must have write access to the project and domain.
 */
export declare const createAssetRevision: API.OperationMethod<CreateAssetRevisionInput & RegionInput, CreateAssetRevisionOutput, CreateAssetRevisionError, Credentials | HttpClient.HttpClient>;
export type CreateAssetTypeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a custom asset type.
 *
 * Prerequisites:
 *
 * - The `formsInput` field is required, however, can be passed as empty (e.g. `-forms-input {})`.
 *
 * - You must have `CreateAssetType` permissions.
 *
 * - The domain-identifier and owning-project-identifier must be valid and active.
 *
 * - The name of the asset type must be unique within the domain -- duplicate names will cause failure.
 *
 * - JSON input must be valid -- incorrect formatting causes Invalid JSON errors.
 */
export declare const createAssetType: API.OperationMethod<CreateAssetTypeInput & RegionInput, CreateAssetTypeOutput, CreateAssetTypeError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a new connection. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionInput & RegionInput, CreateConnectionOutput, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateDataProductError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a data product.
 *
 * A data product is a comprehensive package that combines data assets with their associated metadata, documentation, and access controls. It's designed to serve specific business needs or use cases, making it easier for users to find and consume data appropriately. Data products include important information about data quality, freshness, and usage guidelines, effectively bridging the gap between data producers and consumers while ensuring proper governance.
 *
 * Prerequisites:
 *
 * - The domain must exist and be accessible.
 *
 * - The owning project must be valid and active.
 *
 * - The name must be unique within the domain (no existing data product with the same name).
 *
 * - User must have create permissions for data products in the project.
 */
export declare const createDataProduct: API.OperationMethod<CreateDataProductInput & RegionInput, CreateDataProductOutput, CreateDataProductError, Credentials | HttpClient.HttpClient>;
export type CreateDataProductRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a data product revision.
 *
 * Prerequisites:
 *
 * - The original data product must exist in the given domain.
 *
 * - User must have permissions on the data product.
 *
 * - The domain must be valid and accessible.
 *
 * - The new revision name must comply with naming constraints (if required).
 */
export declare const createDataProductRevision: API.OperationMethod<CreateDataProductRevisionInput & RegionInput, CreateDataProductRevisionOutput, CreateDataProductRevisionError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an Amazon DataZone data source.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceInput & RegionInput, CreateDataSourceOutput, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateDesignationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a new user-defined designation with a Cedar permit policy. The designation defines a named role that can be assigned to project members through `CreateProjectMembership` or granted through `AddPolicyGrant`.
 */
export declare const createDesignation: API.OperationMethod<CreateDesignationInput & RegionInput, CreateDesignationOutput, CreateDesignationError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an Amazon DataZone domain.
 */
export declare const createDomain: API.OperationMethod<CreateDomainInput & RegionInput, CreateDomainOutput, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateDomainUnitError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a domain unit in Amazon DataZone.
 */
export declare const createDomainUnit: API.OperationMethod<CreateDomainUnitInput & RegionInput, CreateDomainUnitOutput, CreateDomainUnitError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Create an Amazon DataZone environment.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentInput & RegionInput, CreateEnvironmentOutput, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an action for the environment, for example, creates a console link for an analytics tool that is available in this environment.
 */
export declare const createEnvironmentAction: API.OperationMethod<CreateEnvironmentActionInput & RegionInput, CreateEnvironmentActionOutput, CreateEnvironmentActionError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a Amazon DataZone blueprint.
 */
export declare const createEnvironmentBlueprint: API.OperationMethod<CreateEnvironmentBlueprintInput & RegionInput, CreateEnvironmentBlueprintOutput, CreateEnvironmentBlueprintError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an Amazon DataZone environment profile.
 */
export declare const createEnvironmentProfile: API.OperationMethod<CreateEnvironmentProfileInput & RegionInput, CreateEnvironmentProfileOutput, CreateEnvironmentProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFormTypeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a metadata form type.
 *
 * Prerequisites:
 *
 * - The domain must exist and be in an `ENABLED` state.
 *
 * - The owning project must exist and be accessible.
 *
 * - The name must be unique within the domain.
 *
 * For custom form types, to indicate that a field should be searchable, annotate it with `@amazon.datazone#searchable`. By default, searchable fields are indexed for semantic search, where related query terms will match the attribute value even if they are not stemmed or keyword matches. To indicate that a field should be indexed for lexical search (which disables semantic search but supports stemmed and partial matches), annotate it with `@amazon.datazone#searchable(modes:["LEXICAL"])`. To indicate that a field should be indexed for technical identifier search (for more information on technical identifier search, see: https://aws.amazon.com/blogs/big-data/streamline-data-discovery-with-precise-technical-identifier-search-in-amazon-sagemaker-unified-studio/), annotate it with `@amazon.datazone#searchable(modes:["TECHNICAL"])`.
 *
 * To denote that a field will store glossary term ids (which are filterable via the Search/SearchListings APIs), annotate it with `@amazon.datazone#glossaryterm("${GLOSSARY_ID}")`, where `${GLOSSARY_ID}` is the id of the glossary that the glossary terms stored in the field belong to.
 */
export declare const createFormType: API.OperationMethod<CreateFormTypeInput & RegionInput, CreateFormTypeOutput, CreateFormTypeError, Credentials | HttpClient.HttpClient>;
export type CreateGlossaryError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an Amazon DataZone business glossary.
 *
 * Specifies that this is a create glossary policy.
 *
 * A glossary serves as the central repository for business terminology and definitions within an organization. It helps establish and maintain a common language across different departments and teams, reducing miscommunication and ensuring consistent interpretation of business concepts. Glossaries can include hierarchical relationships between terms, cross-references, and links to actual data assets, making them invaluable for both business users and technical teams trying to understand and use data correctly.
 *
 * Prerequisites:
 *
 * - Domain must exist and be in an active state.
 *
 * - Owning project must exist and be accessible by the caller.
 *
 * - The glossary name must be unique within the domain.
 */
export declare const createGlossary: API.OperationMethod<CreateGlossaryInput & RegionInput, CreateGlossaryOutput, CreateGlossaryError, Credentials | HttpClient.HttpClient>;
export type CreateGlossaryTermError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a business glossary term.
 *
 * A glossary term represents an individual entry within the Amazon DataZone glossary, serving as a standardized definition for a specific business concept or data element. Each term can include rich metadata such as detailed definitions, synonyms, related terms, and usage examples. Glossary terms can be linked directly to data assets, providing business context to technical data elements. This linking capability helps users understand the business meaning of data fields and ensures consistent interpretation across different systems and teams. Terms can also have relationships with other terms, creating a semantic network that reflects the complexity of business concepts.
 *
 * Prerequisites:
 *
 * - Domain must exist.
 *
 * - Glossary must exist.
 *
 * - The term name must be unique within the glossary.
 *
 * - Ensure term does not conflict with existing terms in hierarchy.
 */
export declare const createGlossaryTerm: API.OperationMethod<CreateGlossaryTermInput & RegionInput, CreateGlossaryTermOutput, CreateGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type CreateGroupProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Creates a group profile in Amazon DataZone.
 */
export declare const createGroupProfile: API.OperationMethod<CreateGroupProfileInput & RegionInput, CreateGroupProfileOutput, CreateGroupProfileError, Credentials | HttpClient.HttpClient>;
export type CreateListingChangeSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Publishes a listing (a record of an asset at a given time) or removes a listing from the catalog.
 */
export declare const createListingChangeSet: API.OperationMethod<CreateListingChangeSetInput & RegionInput, CreateListingChangeSetOutput, CreateListingChangeSetError, Credentials | HttpClient.HttpClient>;
export type CreateNotebookError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a notebook in Amazon SageMaker Unified Studio. A notebook is a collaborative document within a project that contains code cells for interactive computing.
 */
export declare const createNotebook: API.OperationMethod<CreateNotebookInput & RegionInput, CreateNotebookOutput, CreateNotebookError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates an Amazon DataZone project.
 */
export declare const createProject: API.OperationMethod<CreateProjectInput & RegionInput, CreateProjectOutput, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateProjectMembershipError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Creates a project membership in Amazon DataZone.
 */
export declare const createProjectMembership: API.OperationMethod<CreateProjectMembershipInput & RegionInput, CreateProjectMembershipOutput, CreateProjectMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateProjectProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a project profile.
 */
export declare const createProjectProfile: API.OperationMethod<CreateProjectProfileInput & RegionInput, CreateProjectProfileOutput, CreateProjectProfileError, Credentials | HttpClient.HttpClient>;
export type CreateRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a rule in Amazon DataZone. A rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const createRule: API.OperationMethod<CreateRuleInput & RegionInput, CreateRuleOutput, CreateRuleError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a subsscription grant in Amazon DataZone.
 */
export declare const createSubscriptionGrant: API.OperationMethod<CreateSubscriptionGrantInput & RegionInput, CreateSubscriptionGrantOutput, CreateSubscriptionGrantError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a subscription request in Amazon DataZone.
 */
export declare const createSubscriptionRequest: API.OperationMethod<CreateSubscriptionRequestInput & RegionInput, CreateSubscriptionRequestOutput, CreateSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates a subscription target in Amazon DataZone.
 */
export declare const createSubscriptionTarget: API.OperationMethod<CreateSubscriptionTargetInput & RegionInput, CreateSubscriptionTargetOutput, CreateSubscriptionTargetError, Credentials | HttpClient.HttpClient>;
export type CreateUserProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Creates a user profile in Amazon DataZone.
 */
export declare const createUserProfile: API.OperationMethod<CreateUserProfileInput & RegionInput, CreateUserProfileOutput, CreateUserProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountPoolError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes an account pool.
 */
export declare const deleteAccountPool: API.OperationMethod<DeleteAccountPoolInput & RegionInput, DeleteAccountPoolOutput, DeleteAccountPoolError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes an asset in Amazon DataZone.
 *
 * - --domain-identifier must refer to a valid and existing domain.
 *
 * - --identifier must refer to an existing asset in the specified domain.
 *
 * - Asset must not be referenced in any existing asset filters.
 *
 * - Asset must not be linked to any draft or published data product.
 *
 * - User must have delete permissions for the domain and project.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetInput & RegionInput, DeleteAssetOutput, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes an asset filter.
 *
 * Prerequisites:
 *
 * - The asset filter must exist.
 *
 * - The domain and asset must not have been deleted.
 *
 * - Ensure the --identifier refers to a valid filter ID.
 */
export declare const deleteAssetFilter: API.OperationMethod<DeleteAssetFilterInput & RegionInput, DeleteAssetFilterResponse, DeleteAssetFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes an asset type in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The asset type must exist in the domain.
 *
 * - You must have DeleteAssetType permission.
 *
 * - The asset type must not be in use (e.g., assigned to any asset). If used, deletion will fail.
 *
 * - You should retrieve the asset type using get-asset-type to confirm its presence before deletion.
 */
export declare const deleteAssetType: API.OperationMethod<DeleteAssetTypeInput & RegionInput, DeleteAssetTypeOutput, DeleteAssetTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes and connection. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionInput & RegionInput, DeleteConnectionOutput, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataExportConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes data export configuration for a domain.
 *
 * This operation does not delete the S3 table created by the PutDataExportConfiguration operation.
 *
 * To temporarily disable export without deleting the configuration, use the PutDataExportConfiguration operation with the `--no-enable-export` flag instead. This allows you to re-enable export for the same domain using the `--enable-export` flag without deleting S3 table.
 */
export declare const deleteDataExportConfiguration: API.OperationMethod<DeleteDataExportConfigurationInput & RegionInput, DeleteDataExportConfigurationOutput, DeleteDataExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataProductError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a data product in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The data product must exist and not be deleted or archived.
 *
 * - The user must have delete permissions for the data product.
 *
 * - Domain and project must be active.
 */
export declare const deleteDataProduct: API.OperationMethod<DeleteDataProductInput & RegionInput, DeleteDataProductOutput, DeleteDataProductError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a data source in Amazon DataZone.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceInput & RegionInput, DeleteDataSourceOutput, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDesignationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a user-created designation. Managed designations cannot be deleted. The call fails if the designation has `deletionProtection` enabled or if any project member still holds it. This operation is idempotent.
 */
export declare const deleteDesignation: API.OperationMethod<DeleteDesignationInput & RegionInput, DeleteDesignationOutput, DeleteDesignationError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Amazon DataZone domain.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainInput & RegionInput, DeleteDomainOutput, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainUnitError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a domain unit.
 */
export declare const deleteDomainUnit: API.OperationMethod<DeleteDomainUnitInput & RegionInput, DeleteDomainUnitOutput, DeleteDomainUnitError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes an environment in Amazon DataZone.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentInput & RegionInput, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes an action for the environment, for example, deletes a console link for an analytics tool that is available in this environment.
 */
export declare const deleteEnvironmentAction: API.OperationMethod<DeleteEnvironmentActionInput & RegionInput, DeleteEnvironmentActionResponse, DeleteEnvironmentActionError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a blueprint in Amazon DataZone.
 */
export declare const deleteEnvironmentBlueprint: API.OperationMethod<DeleteEnvironmentBlueprintInput & RegionInput, DeleteEnvironmentBlueprintResponse, DeleteEnvironmentBlueprintError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentBlueprintConfigurationError = AccessDeniedException | InternalServerException | ValidationException | ResourceNotFoundException | EnvironmentBlueprintConfigurationInUse | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Deletes the blueprint configuration in Amazon DataZone.
 */
export declare const deleteEnvironmentBlueprintConfiguration: API.OperationMethod<DeleteEnvironmentBlueprintConfigurationInput & RegionInput, DeleteEnvironmentBlueprintConfigurationOutput, DeleteEnvironmentBlueprintConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes an environment profile in Amazon DataZone.
 */
export declare const deleteEnvironmentProfile: API.OperationMethod<DeleteEnvironmentProfileInput & RegionInput, DeleteEnvironmentProfileResponse, DeleteEnvironmentProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFormTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes and metadata form type in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The form type must exist in the domain.
 *
 * - The form type must not be in use by any asset types or assets.
 *
 * - The domain must be valid and accessible.
 *
 * - User must have delete permissions on the form type.
 *
 * - Any dependencies (such as linked asset types) must be removed first.
 */
export declare const deleteFormType: API.OperationMethod<DeleteFormTypeInput & RegionInput, DeleteFormTypeOutput, DeleteFormTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteGlossaryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a business glossary in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The glossary must be in DISABLED state.
 *
 * - The glossary must not have any glossary terms associated with it.
 *
 * - The glossary must exist in the specified domain.
 *
 * - The caller must have the `datazone:DeleteGlossary` permission in the domain and glossary.
 *
 * - Glossary should not be linked to any active metadata forms.
 */
export declare const deleteGlossary: API.OperationMethod<DeleteGlossaryInput & RegionInput, DeleteGlossaryOutput, DeleteGlossaryError, Credentials | HttpClient.HttpClient>;
export type DeleteGlossaryTermError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a business glossary term in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - Glossary term must exist and be active.
 *
 * - The term must not be linked to other assets or child terms.
 *
 * - Caller must have delete permissions in the domain/glossary.
 *
 * - Ensure all associations (such as to assets or parent terms) are removed before deletion.
 */
export declare const deleteGlossaryTerm: API.OperationMethod<DeleteGlossaryTermInput & RegionInput, DeleteGlossaryTermOutput, DeleteGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type DeleteLineageEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified lineage event.
 */
export declare const deleteLineageEvent: API.OperationMethod<DeleteLineageEventInput & RegionInput, DeleteLineageEventOutput, DeleteLineageEventError, Credentials | HttpClient.HttpClient>;
export type DeleteListingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a listing (a record of an asset at a given time).
 */
export declare const deleteListing: API.OperationMethod<DeleteListingInput & RegionInput, DeleteListingOutput, DeleteListingError, Credentials | HttpClient.HttpClient>;
export type DeleteNotebookError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a notebook in Amazon SageMaker Unified Studio.
 */
export declare const deleteNotebook: API.OperationMethod<DeleteNotebookInput & RegionInput, DeleteNotebookOutput, DeleteNotebookError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a project in Amazon DataZone.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectInput & RegionInput, DeleteProjectOutput, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectMembershipError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes project membership in Amazon DataZone.
 */
export declare const deleteProjectMembership: API.OperationMethod<DeleteProjectMembershipInput & RegionInput, DeleteProjectMembershipOutput, DeleteProjectMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a project profile.
 */
export declare const deleteProjectProfile: API.OperationMethod<DeleteProjectProfileInput & RegionInput, DeleteProjectProfileOutput, DeleteProjectProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a rule in Amazon DataZone. A rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleInput & RegionInput, DeleteRuleOutput, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes and subscription grant in Amazon DataZone.
 */
export declare const deleteSubscriptionGrant: API.OperationMethod<DeleteSubscriptionGrantInput & RegionInput, DeleteSubscriptionGrantOutput, DeleteSubscriptionGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a subscription request in Amazon DataZone.
 */
export declare const deleteSubscriptionRequest: API.OperationMethod<DeleteSubscriptionRequestInput & RegionInput, DeleteSubscriptionRequestResponse, DeleteSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes a subscription target in Amazon DataZone.
 */
export declare const deleteSubscriptionTarget: API.OperationMethod<DeleteSubscriptionTargetInput & RegionInput, DeleteSubscriptionTargetResponse, DeleteSubscriptionTargetError, Credentials | HttpClient.HttpClient>;
export type DeleteTimeSeriesDataPointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified time series form for the specified asset.
 */
export declare const deleteTimeSeriesDataPoints: API.OperationMethod<DeleteTimeSeriesDataPointsInput & RegionInput, DeleteTimeSeriesDataPointsOutput, DeleteTimeSeriesDataPointsError, Credentials | HttpClient.HttpClient>;
export type DisassociateEnvironmentRoleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Disassociates the environment role in Amazon DataZone.
 */
export declare const disassociateEnvironmentRole: API.OperationMethod<DisassociateEnvironmentRoleInput & RegionInput, DisassociateEnvironmentRoleOutput, DisassociateEnvironmentRoleError, Credentials | HttpClient.HttpClient>;
export type DisassociateGovernedTermsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Disassociates restricted terms from an asset.
 */
export declare const disassociateGovernedTerms: API.OperationMethod<DisassociateGovernedTermsInput & RegionInput, DisassociateGovernedTermsOutput, DisassociateGovernedTermsError, Credentials | HttpClient.HttpClient>;
export type GetAccountPoolError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the details of the account pool.
 */
export declare const getAccountPool: API.OperationMethod<GetAccountPoolInput & RegionInput, GetAccountPoolOutput, GetAccountPoolError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an Amazon DataZone asset.
 *
 * An asset is the fundamental building block in Amazon DataZone, representing any data resource that needs to be cataloged and managed. It can take many forms, from Amazon S3 buckets and database tables to dashboards and machine learning models. Each asset contains comprehensive metadata about the resource, including its location, schema, ownership, and lineage information. Assets are essential for organizing and managing data resources across an organization, making them discoverable and usable while maintaining proper governance.
 *
 * Before using the Amazon DataZone GetAsset command, ensure the following prerequisites are met:
 *
 * - Domain identifier must exist and be valid
 *
 * - Asset identifier must exist
 *
 * - User must have the required permissions to perform the action
 */
export declare const getAsset: API.OperationMethod<GetAssetInput & RegionInput, GetAssetOutput, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetAssetFilterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an asset filter.
 *
 * Prerequisites:
 *
 * - Domain (`--domain-identifier`), asset (`--asset-identifier`), and filter (`--identifier`) must all exist.
 *
 * - The asset filter should not have been deleted.
 *
 * - The asset must still exist (since the filter is linked to it).
 */
export declare const getAssetFilter: API.OperationMethod<GetAssetFilterInput & RegionInput, GetAssetFilterOutput, GetAssetFilterError, Credentials | HttpClient.HttpClient>;
export type GetAssetTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an Amazon DataZone asset type.
 *
 * Asset types define the categories and characteristics of different kinds of data assets within Amazon DataZone.. They determine what metadata fields are required, what operations are possible, and how the asset integrates with other Amazon Web Services services. Asset types can range from built-in types like Amazon S3 buckets and Amazon Web Services Glue tables to custom types defined for specific organizational needs. Understanding asset types is crucial for properly organizing and managing different kinds of data resources.
 *
 * Prerequisites:
 *
 * - The asset type with identifier must exist in the domain. ResourceNotFoundException.
 *
 * - You must have the GetAssetType permission.
 *
 * - Ensure the domain-identifier value is correct and accessible.
 */
export declare const getAssetType: API.OperationMethod<GetAssetTypeInput & RegionInput, GetAssetTypeOutput, GetAssetTypeError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets a connection. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const getConnection: API.OperationMethod<GetConnectionInput & RegionInput, GetConnectionOutput, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type GetDataExportConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets data export configuration details.
 */
export declare const getDataExportConfiguration: API.OperationMethod<GetDataExportConfigurationInput & RegionInput, GetDataExportConfigurationOutput, GetDataExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDataProductError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the data product.
 *
 * Prerequisites:
 *
 * - The data product ID must exist.
 *
 * - The domain must be valid and accessible.
 *
 * - User must have read or discovery permissions for the data product.
 */
export declare const getDataProduct: API.OperationMethod<GetDataProductInput & RegionInput, GetDataProductOutput, GetDataProductError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an Amazon DataZone data source.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceInput & RegionInput, GetDataSourceOutput, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an Amazon DataZone data source run.
 */
export declare const getDataSourceRun: API.OperationMethod<GetDataSourceRunInput & RegionInput, GetDataSourceRunOutput, GetDataSourceRunError, Credentials | HttpClient.HttpClient>;
export type GetDesignationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the details of a designation, including its Cedar permit policy. Returns the full designation record for both system-managed and user-created designations.
 */
export declare const getDesignation: API.OperationMethod<GetDesignationInput & RegionInput, GetDesignationOutput, GetDesignationError, Credentials | HttpClient.HttpClient>;
export type GetDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an Amazon DataZone domain.
 */
export declare const getDomain: API.OperationMethod<GetDomainInput & RegionInput, GetDomainOutput, GetDomainError, Credentials | HttpClient.HttpClient>;
export type GetDomainUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the details of the specified domain unit.
 */
export declare const getDomainUnit: API.OperationMethod<GetDomainUnitInput & RegionInput, GetDomainUnitOutput, GetDomainUnitError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an Amazon DataZone environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentInput & RegionInput, GetEnvironmentOutput, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentActionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the specified environment action.
 */
export declare const getEnvironmentAction: API.OperationMethod<GetEnvironmentActionInput & RegionInput, GetEnvironmentActionOutput, GetEnvironmentActionError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentBlueprintError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an Amazon DataZone blueprint.
 */
export declare const getEnvironmentBlueprint: API.OperationMethod<GetEnvironmentBlueprintInput & RegionInput, GetEnvironmentBlueprintOutput, GetEnvironmentBlueprintError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentBlueprintConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Gets the blueprint configuration in Amazon DataZone.
 */
export declare const getEnvironmentBlueprintConfiguration: API.OperationMethod<GetEnvironmentBlueprintConfigurationInput & RegionInput, GetEnvironmentBlueprintConfigurationOutput, GetEnvironmentBlueprintConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentCredentialsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the credentials of an environment in Amazon DataZone.
 */
export declare const getEnvironmentCredentials: API.OperationMethod<GetEnvironmentCredentialsInput & RegionInput, GetEnvironmentCredentialsOutput, GetEnvironmentCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets an evinronment profile in Amazon DataZone.
 */
export declare const getEnvironmentProfile: API.OperationMethod<GetEnvironmentProfileInput & RegionInput, GetEnvironmentProfileOutput, GetEnvironmentProfileError, Credentials | HttpClient.HttpClient>;
export type GetFormTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets a metadata form type in Amazon DataZone.
 *
 * Form types define the structure and validation rules for collecting metadata about assets in Amazon DataZone. They act as templates that ensure consistent metadata capture across similar types of assets, while allowing for customization to meet specific organizational needs. Form types can include required fields, validation rules, and dependencies, helping maintain high-quality metadata that makes data assets more discoverable and usable.
 *
 * - The form type with the specified identifier must exist in the given domain.
 *
 * - The domain must be valid and active.
 *
 * - User must have permission on the form type.
 *
 * - The form type should not be deleted or in an invalid state.
 *
 * One use case for this API is to determine whether a form field is indexed for search.
 *
 * A searchable field will be annotated with `@amazon.datazone#searchable`. By default, searchable fields are indexed for semantic search, where related query terms will match the attribute value even if they are not stemmed or keyword matches. If a field is indexed technical identifier search, it will be annotated with `@amazon.datazone#searchable(modes:["TECHNICAL"])`. If a field is indexed for lexical search (supports stemmed and prefix matches but not semantic matches), it will be annotated with `@amazon.datazone#searchable(modes:["LEXICAL"])`.
 *
 * A field storing glossary term IDs (which is filterable) will be annotated with `@amazon.datazone#glossaryterm("${glossaryId}")`.
 */
export declare const getFormType: API.OperationMethod<GetFormTypeInput & RegionInput, GetFormTypeOutput, GetFormTypeError, Credentials | HttpClient.HttpClient>;
export type GetGlossaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets a business glossary in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The specified glossary ID must exist and be associated with the given domain.
 *
 * - The caller must have the `datazone:GetGlossary` permission on the domain.
 */
export declare const getGlossary: API.OperationMethod<GetGlossaryInput & RegionInput, GetGlossaryOutput, GetGlossaryError, Credentials | HttpClient.HttpClient>;
export type GetGlossaryTermError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets a business glossary term in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - Glossary term with identifier must exist in the domain.
 *
 * - User must have permission on the glossary term.
 *
 * - Domain must be accessible and active.
 */
export declare const getGlossaryTerm: API.OperationMethod<GetGlossaryTermInput & RegionInput, GetGlossaryTermOutput, GetGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type GetGroupProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Gets a group profile in Amazon DataZone.
 */
export declare const getGroupProfile: API.OperationMethod<GetGroupProfileInput & RegionInput, GetGroupProfileOutput, GetGroupProfileError, Credentials | HttpClient.HttpClient>;
export type GetIamPortalLoginUrlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the data portal URL for the specified Amazon DataZone domain.
 */
export declare const getIamPortalLoginUrl: API.OperationMethod<GetIamPortalLoginUrlInput & RegionInput, GetIamPortalLoginUrlOutput, GetIamPortalLoginUrlError, Credentials | HttpClient.HttpClient>;
export type GetJobRunError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * The details of the job run.
 */
export declare const getJobRun: API.OperationMethod<GetJobRunInput & RegionInput, GetJobRunOutput, GetJobRunError, Credentials | HttpClient.HttpClient>;
export type GetLineageEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Describes the lineage event.
 */
export declare const getLineageEvent: API.OperationMethod<GetLineageEventInput & RegionInput, GetLineageEventOutput, GetLineageEventError, Credentials | HttpClient.HttpClient>;
export type GetLineageNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the data lineage node.
 */
export declare const getLineageNode: API.OperationMethod<GetLineageNodeInput & RegionInput, GetLineageNodeOutput, GetLineageNodeError, Credentials | HttpClient.HttpClient>;
export type GetListingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets a listing (a record of an asset at a given time). If you specify a listing version, only details that are specific to that version are returned.
 */
export declare const getListing: API.OperationMethod<GetListingInput & RegionInput, GetListingOutput, GetListingError, Credentials | HttpClient.HttpClient>;
export type GetMetadataGenerationRunError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets a metadata generation run in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - Valid domain and run identifier.
 *
 * - The metadata generation run must exist.
 *
 * - User must have read access to the metadata run.
 */
export declare const getMetadataGenerationRun: API.OperationMethod<GetMetadataGenerationRunInput & RegionInput, GetMetadataGenerationRunOutput, GetMetadataGenerationRunError, Credentials | HttpClient.HttpClient>;
export type GetNotebookError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the details of a notebook in Amazon SageMaker Unified Studio.
 */
export declare const getNotebook: API.OperationMethod<GetNotebookInput & RegionInput, GetNotebookOutput, GetNotebookError, Credentials | HttpClient.HttpClient>;
export type GetNotebookExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the details of a notebook export in Amazon SageMaker Unified Studio.
 */
export declare const getNotebookExport: API.OperationMethod<GetNotebookExportInput & RegionInput, GetNotebookExportOutput, GetNotebookExportError, Credentials | HttpClient.HttpClient>;
export type GetNotebookRunError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the details of a notebook run in Amazon SageMaker Unified Studio.
 */
export declare const getNotebookRun: API.OperationMethod<GetNotebookRunInput & RegionInput, GetNotebookRunOutput, GetNotebookRunError, Credentials | HttpClient.HttpClient>;
export type GetProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets a project in Amazon DataZone.
 */
export declare const getProject: API.OperationMethod<GetProjectInput & RegionInput, GetProjectOutput, GetProjectError, Credentials | HttpClient.HttpClient>;
export type GetProjectProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * The details of the project profile.
 */
export declare const getProjectProfile: API.OperationMethod<GetProjectProfileInput & RegionInput, GetProjectProfileOutput, GetProjectProfileError, Credentials | HttpClient.HttpClient>;
export type GetRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the details of a rule in Amazon DataZone. A rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const getRule: API.OperationMethod<GetRuleInput & RegionInput, GetRuleOutput, GetRuleError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets a subscription in Amazon DataZone.
 */
export declare const getSubscription: API.OperationMethod<GetSubscriptionInput & RegionInput, GetSubscriptionOutput, GetSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the subscription grant in Amazon DataZone.
 */
export declare const getSubscriptionGrant: API.OperationMethod<GetSubscriptionGrantInput & RegionInput, GetSubscriptionGrantOutput, GetSubscriptionGrantError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionRequestDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the details of the specified subscription request.
 */
export declare const getSubscriptionRequestDetails: API.OperationMethod<GetSubscriptionRequestDetailsInput & RegionInput, GetSubscriptionRequestDetailsOutput, GetSubscriptionRequestDetailsError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionTargetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the subscription target in Amazon DataZone.
 */
export declare const getSubscriptionTarget: API.OperationMethod<GetSubscriptionTargetInput & RegionInput, GetSubscriptionTargetOutput, GetSubscriptionTargetError, Credentials | HttpClient.HttpClient>;
export type GetTimeSeriesDataPointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Gets the existing data point for the asset.
 */
export declare const getTimeSeriesDataPoint: API.OperationMethod<GetTimeSeriesDataPointInput & RegionInput, GetTimeSeriesDataPointOutput, GetTimeSeriesDataPointError, Credentials | HttpClient.HttpClient>;
export type GetUserProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Gets a user profile in Amazon DataZone.
 */
export declare const getUserProfile: API.OperationMethod<GetUserProfileInput & RegionInput, GetUserProfileOutput, GetUserProfileError, Credentials | HttpClient.HttpClient>;
export type ListAccountPoolsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists existing account pools.
 */
export declare const listAccountPools: API.PaginatedOperationMethod<ListAccountPoolsInput & RegionInput, ListAccountPoolsOutput, ListAccountPoolsError, Credentials | HttpClient.HttpClient, AccountPoolSummary>;
export type ListAccountsInAccountPoolError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists the accounts in the specified account pool.
 */
export declare const listAccountsInAccountPool: API.PaginatedOperationMethod<ListAccountsInAccountPoolInput & RegionInput, ListAccountsInAccountPoolOutput, ListAccountsInAccountPoolError, Credentials | HttpClient.HttpClient, AccountInfo>;
export type ListAssetFiltersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists asset filters.
 *
 * Prerequisites:
 *
 * - A valid domain and asset must exist.
 *
 * - The asset must have at least one filter created to return results.
 */
export declare const listAssetFilters: API.PaginatedOperationMethod<ListAssetFiltersInput & RegionInput, ListAssetFiltersOutput, ListAssetFiltersError, Credentials | HttpClient.HttpClient, AssetFilterSummary>;
export type ListAssetRevisionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists the revisions for the asset.
 *
 * Prerequisites:
 *
 * - The asset must exist in the domain.
 *
 * - There must be at least one revision of the asset (which happens automatically after creation).
 *
 * - The domain must be valid and active.
 *
 * - User must have permissions on the asset and domain.
 */
export declare const listAssetRevisions: API.PaginatedOperationMethod<ListAssetRevisionsInput & RegionInput, ListAssetRevisionsOutput, ListAssetRevisionsError, Credentials | HttpClient.HttpClient, AssetRevision>;
export type ListConnectionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists connections. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const listConnections: API.PaginatedOperationMethod<ListConnectionsInput & RegionInput, ListConnectionsOutput, ListConnectionsError, Credentials | HttpClient.HttpClient, ConnectionSummary>;
export type ListDataProductRevisionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists data product revisions.
 *
 * Prerequisites:
 *
 * - The data product ID must exist within the domain.
 *
 * - User must have view permissions on the data product.
 *
 * - The domain must be in a valid and accessible state.
 */
export declare const listDataProductRevisions: API.PaginatedOperationMethod<ListDataProductRevisionsInput & RegionInput, ListDataProductRevisionsOutput, ListDataProductRevisionsError, Credentials | HttpClient.HttpClient, DataProductRevision>;
export type ListDataSourceRunActivitiesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists data source run activities.
 */
export declare const listDataSourceRunActivities: API.PaginatedOperationMethod<ListDataSourceRunActivitiesInput & RegionInput, ListDataSourceRunActivitiesOutput, ListDataSourceRunActivitiesError, Credentials | HttpClient.HttpClient, DataSourceRunActivity>;
export type ListDataSourceRunsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists data source runs in Amazon DataZone.
 */
export declare const listDataSourceRuns: API.PaginatedOperationMethod<ListDataSourceRunsInput & RegionInput, ListDataSourceRunsOutput, ListDataSourceRunsError, Credentials | HttpClient.HttpClient, DataSourceRunSummary>;
export type ListDataSourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists data sources in Amazon DataZone.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesInput & RegionInput, ListDataSourcesOutput, ListDataSourcesError, Credentials | HttpClient.HttpClient, DataSourceSummary>;
export type ListDesignationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists the designations in a domain. The response returns system-managed designations first, followed by user-created designations in alphabetical order by name. Results are paginated. Use `nextToken` to retrieve additional pages of results.
 */
export declare const listDesignations: API.PaginatedOperationMethod<ListDesignationsInput & RegionInput, ListDesignationsOutput, ListDesignationsError, Credentials | HttpClient.HttpClient, DesignationSummary>;
export type ListDomainsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists Amazon DataZone domains.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsInput & RegionInput, ListDomainsOutput, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListDomainUnitsForParentError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists child domain units for the specified parent domain unit.
 */
export declare const listDomainUnitsForParent: API.PaginatedOperationMethod<ListDomainUnitsForParentInput & RegionInput, ListDomainUnitsForParentOutput, ListDomainUnitsForParentError, Credentials | HttpClient.HttpClient, DomainUnitSummary>;
export type ListEntityOwnersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists the entity (domain units) owners.
 */
export declare const listEntityOwners: API.PaginatedOperationMethod<ListEntityOwnersInput & RegionInput, ListEntityOwnersOutput, ListEntityOwnersError, Credentials | HttpClient.HttpClient, OwnerPropertiesOutput>;
export type ListEnvironmentActionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists existing environment actions.
 */
export declare const listEnvironmentActions: API.PaginatedOperationMethod<ListEnvironmentActionsInput & RegionInput, ListEnvironmentActionsOutput, ListEnvironmentActionsError, Credentials | HttpClient.HttpClient, EnvironmentActionSummary>;
export type ListEnvironmentBlueprintConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists blueprint configurations for a Amazon DataZone environment.
 */
export declare const listEnvironmentBlueprintConfigurations: API.PaginatedOperationMethod<ListEnvironmentBlueprintConfigurationsInput & RegionInput, ListEnvironmentBlueprintConfigurationsOutput, ListEnvironmentBlueprintConfigurationsError, Credentials | HttpClient.HttpClient, EnvironmentBlueprintConfigurationItem>;
export type ListEnvironmentBlueprintsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists blueprints in an Amazon DataZone environment.
 */
export declare const listEnvironmentBlueprints: API.PaginatedOperationMethod<ListEnvironmentBlueprintsInput & RegionInput, ListEnvironmentBlueprintsOutput, ListEnvironmentBlueprintsError, Credentials | HttpClient.HttpClient, EnvironmentBlueprintSummary>;
export type ListEnvironmentProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists Amazon DataZone environment profiles.
 */
export declare const listEnvironmentProfiles: API.PaginatedOperationMethod<ListEnvironmentProfilesInput & RegionInput, ListEnvironmentProfilesOutput, ListEnvironmentProfilesError, Credentials | HttpClient.HttpClient, EnvironmentProfileSummary>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists Amazon DataZone environments.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsInput & RegionInput, ListEnvironmentsOutput, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentSummary>;
export type ListJobRunsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists job runs.
 */
export declare const listJobRuns: API.PaginatedOperationMethod<ListJobRunsInput & RegionInput, ListJobRunsOutput, ListJobRunsError, Credentials | HttpClient.HttpClient, JobRunSummary>;
export type ListLineageEventsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists lineage events.
 */
export declare const listLineageEvents: API.PaginatedOperationMethod<ListLineageEventsInput & RegionInput, ListLineageEventsOutput, ListLineageEventsError, Credentials | HttpClient.HttpClient, LineageEventSummary>;
export type ListLineageNodeHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists the history of the specified data lineage node.
 */
export declare const listLineageNodeHistory: API.PaginatedOperationMethod<ListLineageNodeHistoryInput & RegionInput, ListLineageNodeHistoryOutput, ListLineageNodeHistoryError, Credentials | HttpClient.HttpClient, LineageNodeSummary>;
export type ListMetadataGenerationRunsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists all metadata generation runs.
 *
 * Metadata generation runs represent automated processes that leverage AI/ML capabilities to create or enhance asset metadata at scale. This feature helps organizations maintain comprehensive and consistent metadata across large numbers of assets without manual intervention. It can automatically generate business descriptions, tags, and other metadata elements, significantly reducing the time and effort required for metadata management while improving consistency and completeness.
 *
 * Prerequisites:
 *
 * - Valid domain identifier.
 *
 * - User must have access to metadata generation runs in the domain.
 */
export declare const listMetadataGenerationRuns: API.PaginatedOperationMethod<ListMetadataGenerationRunsInput & RegionInput, ListMetadataGenerationRunsOutput, ListMetadataGenerationRunsError, Credentials | HttpClient.HttpClient, MetadataGenerationRunItem>;
export type ListNotebookRunsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists notebook runs in Amazon SageMaker Unified Studio.
 */
export declare const listNotebookRuns: API.PaginatedOperationMethod<ListNotebookRunsInput & RegionInput, ListNotebookRunsOutput, ListNotebookRunsError, Credentials | HttpClient.HttpClient, NotebookRunSummary>;
export type ListNotebooksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists notebooks in Amazon SageMaker Unified Studio.
 */
export declare const listNotebooks: API.PaginatedOperationMethod<ListNotebooksInput & RegionInput, ListNotebooksOutput, ListNotebooksError, Credentials | HttpClient.HttpClient, NotebookSummary>;
export type ListNotificationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists all Amazon DataZone notifications.
 */
export declare const listNotifications: API.PaginatedOperationMethod<ListNotificationsInput & RegionInput, ListNotificationsOutput, ListNotificationsError, Credentials | HttpClient.HttpClient, NotificationOutput>;
export type ListPolicyGrantsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists policy grants.
 */
export declare const listPolicyGrants: API.PaginatedOperationMethod<ListPolicyGrantsInput & RegionInput, ListPolicyGrantsOutput, ListPolicyGrantsError, Credentials | HttpClient.HttpClient, PolicyGrantMember>;
export type ListProjectMembershipsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists all members of the specified project.
 */
export declare const listProjectMemberships: API.PaginatedOperationMethod<ListProjectMembershipsInput & RegionInput, ListProjectMembershipsOutput, ListProjectMembershipsError, Credentials | HttpClient.HttpClient, ProjectMember>;
export type ListProjectProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists project profiles.
 */
export declare const listProjectProfiles: API.PaginatedOperationMethod<ListProjectProfilesInput & RegionInput, ListProjectProfilesOutput, ListProjectProfilesError, Credentials | HttpClient.HttpClient, ProjectProfileSummary>;
export type ListProjectsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists Amazon DataZone projects.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsInput & RegionInput, ListProjectsOutput, ListProjectsError, Credentials | HttpClient.HttpClient, ProjectSummary>;
export type ListRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists existing rules. In Amazon DataZone, a rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const listRules: API.PaginatedOperationMethod<ListRulesInput & RegionInput, ListRulesOutput, ListRulesError, Credentials | HttpClient.HttpClient, RuleSummary>;
export type ListSubscriptionGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists subscription grants.
 */
export declare const listSubscriptionGrants: API.PaginatedOperationMethod<ListSubscriptionGrantsInput & RegionInput, ListSubscriptionGrantsOutput, ListSubscriptionGrantsError, Credentials | HttpClient.HttpClient, SubscriptionGrantSummary>;
export type ListSubscriptionRequestsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists Amazon DataZone subscription requests.
 */
export declare const listSubscriptionRequests: API.PaginatedOperationMethod<ListSubscriptionRequestsInput & RegionInput, ListSubscriptionRequestsOutput, ListSubscriptionRequestsError, Credentials | HttpClient.HttpClient, SubscriptionRequestSummary>;
export type ListSubscriptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists subscriptions in Amazon DataZone.
 */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsInput & RegionInput, ListSubscriptionsOutput, ListSubscriptionsError, Credentials | HttpClient.HttpClient, SubscriptionSummary>;
export type ListSubscriptionTargetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists subscription targets in Amazon DataZone.
 */
export declare const listSubscriptionTargets: API.PaginatedOperationMethod<ListSubscriptionTargetsInput & RegionInput, ListSubscriptionTargetsOutput, ListSubscriptionTargetsError, Credentials | HttpClient.HttpClient, SubscriptionTargetSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists tags for the specified resource in Amazon DataZone.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTimeSeriesDataPointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Lists time series data points.
 */
export declare const listTimeSeriesDataPoints: API.PaginatedOperationMethod<ListTimeSeriesDataPointsInput & RegionInput, ListTimeSeriesDataPointsOutput, ListTimeSeriesDataPointsError, Credentials | HttpClient.HttpClient, TimeSeriesDataPointSummaryFormOutput>;
export type PostLineageEventError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Posts a data lineage event.
 */
export declare const postLineageEvent: API.OperationMethod<PostLineageEventInput & RegionInput, PostLineageEventOutput, PostLineageEventError, Credentials | HttpClient.HttpClient>;
export type PostTimeSeriesDataPointsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Posts time series data points to Amazon DataZone for the specified asset.
 */
export declare const postTimeSeriesDataPoints: API.OperationMethod<PostTimeSeriesDataPointsInput & RegionInput, PostTimeSeriesDataPointsOutput, PostTimeSeriesDataPointsError, Credentials | HttpClient.HttpClient>;
export type PutDataExportConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Creates data export configuration details.
 *
 * If you want to temporarily disable export and later re-enable it for the same domain, use the `--no-enable-export` flag to disable and the `--enable-export` flag to re-enable. This preserves the configuration and allows you to re-enable export without deleting S3 table.
 *
 * You can enable asset metadata export for only one domain per account per Region. To enable export for a different domain, complete the following steps:
 *
 * - Delete the export configuration for the currently enabled domain using the DeleteDataExportConfiguration operation.
 *
 * - Delete the asset S3 table under the aws-sagemaker-catalog S3 table bucket. We recommend backing up the S3 table before deletion.
 *
 * - Call the PutDataExportConfiguration API to enable export for the new domain.
 */
export declare const putDataExportConfiguration: API.OperationMethod<PutDataExportConfigurationInput & RegionInput, PutDataExportConfigurationOutput, PutDataExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutEnvironmentBlueprintConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Writes the configuration for the specified environment blueprint in Amazon DataZone.
 */
export declare const putEnvironmentBlueprintConfiguration: API.OperationMethod<PutEnvironmentBlueprintConfigurationInput & RegionInput, PutEnvironmentBlueprintConfigurationOutput, PutEnvironmentBlueprintConfigurationError, Credentials | HttpClient.HttpClient>;
export type QueryGraphError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Queries entities in the graph store.
 */
export declare const queryGraph: API.PaginatedOperationMethod<QueryGraphInput & RegionInput, QueryGraphOutput, QueryGraphError, Credentials | HttpClient.HttpClient, ResultItem>;
export type RejectPredictionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Rejects automatically generated business-friendly metadata for your Amazon DataZone assets.
 */
export declare const rejectPredictions: API.OperationMethod<RejectPredictionsInput & RegionInput, RejectPredictionsOutput, RejectPredictionsError, Credentials | HttpClient.HttpClient>;
export type RejectSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Rejects the specified subscription request.
 */
export declare const rejectSubscriptionRequest: API.OperationMethod<RejectSubscriptionRequestInput & RegionInput, RejectSubscriptionRequestOutput, RejectSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type RemoveEntityOwnerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Removes an owner from an entity.
 */
export declare const removeEntityOwner: API.OperationMethod<RemoveEntityOwnerInput & RegionInput, RemoveEntityOwnerOutput, RemoveEntityOwnerError, Credentials | HttpClient.HttpClient>;
export type RemovePolicyGrantError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Removes a policy grant.
 */
export declare const removePolicyGrant: API.OperationMethod<RemovePolicyGrantInput & RegionInput, RemovePolicyGrantOutput, RemovePolicyGrantError, Credentials | HttpClient.HttpClient>;
export type RevokeSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Revokes a specified subscription in Amazon DataZone.
 */
export declare const revokeSubscription: API.OperationMethod<RevokeSubscriptionInput & RegionInput, RevokeSubscriptionOutput, RevokeSubscriptionError, Credentials | HttpClient.HttpClient>;
export type SearchError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Searches for assets in Amazon DataZone.
 *
 * Search in Amazon DataZone is a powerful capability that enables users to discover and explore data assets, glossary terms, and data products across their organization. It provides both basic and advanced search functionality, allowing users to find resources based on names, descriptions, metadata, and other attributes. Search can be scoped to specific types of resources (like assets, glossary terms, or data products) and can be filtered using various criteria such as creation date, owner, or status. The search functionality is essential for making the wealth of data resources in an organization discoverable and usable, helping users find the right data for their needs quickly and efficiently.
 *
 * Many search commands in Amazon DataZone are paginated, including `search` and `search-types`. When the result set is large, Amazon DataZone returns a `nextToken` in the response. This token can be used to retrieve the next page of results.
 *
 * Prerequisites:
 *
 * - The --domain-identifier must refer to an existing Amazon DataZone domain.
 *
 * - --search-scope must be one of: ASSET, GLOSSARY_TERM, DATA_PRODUCT, or GLOSSARY.
 *
 * - The user must have search permissions in the specified domain.
 *
 * - If using --filters, ensure that the JSON is well-formed and that each filter includes valid attribute and value keys.
 *
 * - For paginated results, be prepared to use --next-token to fetch additional pages.
 *
 * To run a standard free-text search, the `searchText` parameter must be supplied. By default, all searchable fields are indexed for semantic search and will return semantic matches for SearchListings queries. To prevent semantic search indexing for a custom form attribute, see the CreateFormType API documentation. To run a lexical search query, enclose the query with double quotes (""). This will disable semantic search even for fields that have semantic search enabled and will only return results that contain the keywords wrapped by double quotes (order of tokens in the query is not enforced). Free-text search is supported for all attributes annotated with @amazon.datazone#searchable.
 *
 * To run a filtered search, provide filter clause using the `filters` parameter. To filter on glossary terms, use the special attribute `__DataZoneGlossaryTerms`. To filter on an indexed numeric attribute (i.e., a numeric attribute annotated with `@amazon.datazone#sortable`), provide a filter using the `intValue` parameter. The filters parameter can also be used to run more advanced free-text searches that target specific attributes (attributes must be annotated with `@amazon.datazone#searchable` for free-text search). Create/update timestamp filtering is supported using the special `creationTime`/`lastUpdatedTime` attributes. Filter types can be mixed and matched to power complex queries.
 *
 * To find out whether an attribute has been annotated and indexed for a given search type, use the GetFormType API to retrieve the form containing the attribute.
 */
export declare const search: API.PaginatedOperationMethod<SearchInput & RegionInput, SearchOutput, SearchError, Credentials | HttpClient.HttpClient, SearchInventoryResultItem>;
export type SearchGroupProfilesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Searches group profiles in Amazon DataZone.
 */
export declare const searchGroupProfiles: API.PaginatedOperationMethod<SearchGroupProfilesInput & RegionInput, SearchGroupProfilesOutput, SearchGroupProfilesError, Credentials | HttpClient.HttpClient, GroupProfileSummary>;
export type SearchListingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Searches listings in Amazon DataZone.
 *
 * SearchListings is a powerful capability that enables users to discover and explore published assets and data products across their organization. It provides both basic and advanced search functionality, allowing users to find resources based on names, descriptions, metadata, and other attributes. SearchListings also supports filtering using various criteria such as creation date, owner, or status. This API is essential for making the wealth of data resources in an organization discoverable and usable, helping users find the right data for their needs quickly and efficiently.
 *
 * SearchListings returns results in a paginated format. When the result set is large, the response will include a nextToken, which can be used to retrieve the next page of results.
 *
 * The SearchListings API gives users flexibility in specifying what kind of search is run.
 *
 * To run a standard free-text search, the `searchText` parameter must be supplied. By default, all searchable fields are indexed for semantic search and will return semantic matches for SearchListings queries. To prevent semantic search indexing for a custom form attribute, see the CreateFormType API documentation. To run a lexical search query, enclose the query with double quotes (""). This will disable semantic search even for fields that have semantic search enabled and will only return results that contain the keywords wrapped by double quotes (order of tokens in the query is not enforced). Free-text search is supported for all attributes annotated with @amazon.datazone#searchable.
 *
 * To run a filtered search, provide filter clause using the `filters` parameter. To filter on glossary terms, use the special attribute `__DataZoneGlossaryTerms`. To filter on an indexed numeric attribute (i.e., a numeric attribute annotated with `@amazon.datazone#sortable`), provide a filter using the `intValue` parameter. The filters parameter can also be used to run more advanced free-text searches that target specific attributes (attributes must be annotated with `@amazon.datazone#searchable` for free-text search). Create/update timestamp filtering is supported using the special `creationTime`/`lastUpdatedTime` attributes. Filter types can be mixed and matched to power complex queries.
 *
 * To find out whether an attribute has been annotated and indexed for a given search type, use the GetFormType API to retrieve the form containing the attribute.
 */
export declare const searchListings: API.PaginatedOperationMethod<SearchListingsInput & RegionInput, SearchListingsOutput, SearchListingsError, Credentials | HttpClient.HttpClient, SearchResultItem>;
export type SearchTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Searches for types in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The --domain-identifier must refer to an existing Amazon DataZone domain.
 *
 * - --search-scope must be one of the valid values including: ASSET_TYPE, GLOSSARY_TERM_TYPE, DATA_PRODUCT_TYPE.
 *
 * - The --managed flag must be present without a value.
 *
 * - The user must have permissions for form or asset types in the domain.
 *
 * - If using --filters, ensure that the JSON is valid.
 *
 * - Filters contain correct structure (attribute, value, operator).
 */
export declare const searchTypes: API.PaginatedOperationMethod<SearchTypesInput & RegionInput, SearchTypesOutput, SearchTypesError, Credentials | HttpClient.HttpClient, SearchTypesResultItem>;
export type SearchUserProfilesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Searches user profiles in Amazon DataZone.
 */
export declare const searchUserProfiles: API.PaginatedOperationMethod<SearchUserProfilesInput & RegionInput, SearchUserProfilesOutput, SearchUserProfilesError, Credentials | HttpClient.HttpClient, UserProfileSummary>;
export type StartDataSourceRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Start the run of the specified data source in Amazon DataZone.
 */
export declare const startDataSourceRun: API.OperationMethod<StartDataSourceRunInput & RegionInput, StartDataSourceRunOutput, StartDataSourceRunError, Credentials | HttpClient.HttpClient>;
export type StartMetadataGenerationRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Starts the metadata generation run.
 *
 * Prerequisites:
 *
 * - Asset must be created and belong to the specified domain and project.
 *
 * - Asset type must be supported for metadata generation (e.g., Amazon Web Services Glue table).
 *
 * - Asset must have a structured schema with valid rows and columns.
 *
 * - Valid values for --type: BUSINESS_DESCRIPTIONS, BUSINESS_NAMES, BUSINESS_GLOSSARY_ASSOCIATIONS.
 *
 * - The user must have permission to run metadata generation in the domain/project.
 */
export declare const startMetadataGenerationRun: API.OperationMethod<StartMetadataGenerationRunInput & RegionInput, StartMetadataGenerationRunOutput, StartMetadataGenerationRunError, Credentials | HttpClient.HttpClient>;
export type StartNotebookExportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Starts a notebook export in Amazon SageMaker Unified Studio. This operation exports a notebook to a specified file format and stores the output in Amazon Simple Storage Service.
 */
export declare const startNotebookExport: API.OperationMethod<StartNotebookExportInput & RegionInput, StartNotebookExportOutput, StartNotebookExportError, Credentials | HttpClient.HttpClient>;
export type StartNotebookImportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Starts a notebook import in Amazon SageMaker Unified Studio. This operation imports a notebook from an Amazon Simple Storage Service location into a project.
 */
export declare const startNotebookImport: API.OperationMethod<StartNotebookImportInput & RegionInput, StartNotebookImportOutput, StartNotebookImportError, Credentials | HttpClient.HttpClient>;
export type StartNotebookRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Starts a notebook run in Amazon SageMaker Unified Studio. A notebook run represents the execution of an Amazon SageMaker notebook within a project. You can configure compute, network, timeout, and environment settings for the run.
 */
export declare const startNotebookRun: API.OperationMethod<StartNotebookRunInput & RegionInput, StartNotebookRunOutput, StartNotebookRunError, Credentials | HttpClient.HttpClient>;
export type StartNotebookSyncError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Starts a notebook sync in Amazon SageMaker Unified Studio. This operation syncs a notebook from a Git repository into a project.
 */
export declare const startNotebookSync: API.OperationMethod<StartNotebookSyncInput & RegionInput, StartNotebookSyncOutput, StartNotebookSyncError, Credentials | HttpClient.HttpClient>;
export type StopNotebookRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Stops a running notebook run in Amazon SageMaker Unified Studio.
 */
export declare const stopNotebookRun: API.OperationMethod<StopNotebookRunInput & RegionInput, StopNotebookRunOutput, StopNotebookRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | AccessDeniedException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Tags a resource in Amazon DataZone.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | AccessDeniedException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Untags a resource in Amazon DataZone.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountPoolError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the account pool.
 */
export declare const updateAccountPool: API.OperationMethod<UpdateAccountPoolInput & RegionInput, UpdateAccountPoolOutput, UpdateAccountPoolError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates an asset filter.
 *
 * Prerequisites:
 *
 * - The domain, asset, and asset filter identifier must all exist.
 *
 * - The asset must contain the columns being referenced in the update.
 *
 * - If applying a row filter, ensure the column referenced in the expression exists in the asset schema.
 */
export declare const updateAssetFilter: API.OperationMethod<UpdateAssetFilterInput & RegionInput, UpdateAssetFilterOutput, UpdateAssetFilterError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates a connection. In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionInput & RegionInput, UpdateConnectionOutput, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified data source in Amazon DataZone.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceInput & RegionInput, UpdateDataSourceOutput, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDesignationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing user-created designation. Managed designations cannot be modified. Omit a field to leave its current value unchanged.
 */
export declare const updateDesignation: API.OperationMethod<UpdateDesignationInput & RegionInput, UpdateDesignationOutput, UpdateDesignationError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates a Amazon DataZone domain.
 */
export declare const updateDomain: API.OperationMethod<UpdateDomainInput & RegionInput, UpdateDomainOutput, UpdateDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainUnitError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the domain unit.
 */
export declare const updateDomainUnit: API.OperationMethod<UpdateDomainUnitInput & RegionInput, UpdateDomainUnitOutput, UpdateDomainUnitError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified environment in Amazon DataZone.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentInput & RegionInput, UpdateEnvironmentOutput, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates an environment action.
 */
export declare const updateEnvironmentAction: API.OperationMethod<UpdateEnvironmentActionInput & RegionInput, UpdateEnvironmentActionOutput, UpdateEnvironmentActionError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates an environment blueprint in Amazon DataZone.
 */
export declare const updateEnvironmentBlueprint: API.OperationMethod<UpdateEnvironmentBlueprintInput & RegionInput, UpdateEnvironmentBlueprintOutput, UpdateEnvironmentBlueprintError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified environment profile in Amazon DataZone.
 */
export declare const updateEnvironmentProfile: API.OperationMethod<UpdateEnvironmentProfileInput & RegionInput, UpdateEnvironmentProfileOutput, UpdateEnvironmentProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateGlossaryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the business glossary in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - The glossary must exist in the given domain.
 *
 * - The caller must have the `datazone:UpdateGlossary` permission to update it.
 *
 * - When updating the name, the new name must be unique within the domain.
 *
 * - The glossary must not be deleted or in a terminal state.
 */
export declare const updateGlossary: API.OperationMethod<UpdateGlossaryInput & RegionInput, UpdateGlossaryOutput, UpdateGlossaryError, Credentials | HttpClient.HttpClient>;
export type UpdateGlossaryTermError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates a business glossary term in Amazon DataZone.
 *
 * Prerequisites:
 *
 * - Glossary term must exist in the specified domain.
 *
 * - New name must not conflict with existing terms in the same glossary.
 *
 * - User must have permissions on the term.
 *
 * - The term must not be in DELETED status.
 */
export declare const updateGlossaryTerm: API.OperationMethod<UpdateGlossaryTermInput & RegionInput, UpdateGlossaryTermOutput, UpdateGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified group profile in Amazon DataZone.
 */
export declare const updateGroupProfile: API.OperationMethod<UpdateGroupProfileInput & RegionInput, UpdateGroupProfileOutput, UpdateGroupProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateNotebookError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates a notebook in Amazon SageMaker Unified Studio.
 */
export declare const updateNotebook: API.OperationMethod<UpdateNotebookInput & RegionInput, UpdateNotebookOutput, UpdateNotebookError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified project in Amazon DataZone.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectInput & RegionInput, UpdateProjectOutput, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates a project profile.
 */
export declare const updateProjectProfile: API.OperationMethod<UpdateProjectProfileInput & RegionInput, UpdateProjectProfileOutput, UpdateProjectProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateRootDomainUnitOwnerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the owner of the root domain unit.
 */
export declare const updateRootDomainUnitOwner: API.OperationMethod<UpdateRootDomainUnitOwnerInput & RegionInput, UpdateRootDomainUnitOwnerOutput, UpdateRootDomainUnitOwnerError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates a rule. In Amazon DataZone, a rule is a formal agreement that enforces specific requirements across user workflows (e.g., publishing assets to the catalog, requesting subscriptions, creating projects) within the Amazon DataZone data portal. These rules help maintain consistency, ensure compliance, and uphold governance standards in data management processes. For instance, a metadata enforcement rule can specify the required information for creating a subscription request or publishing a data asset to the catalog, ensuring alignment with organizational standards.
 */
export declare const updateRule: API.OperationMethod<UpdateRuleInput & RegionInput, UpdateRuleOutput, UpdateRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionGrantStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the status of the specified subscription grant status in Amazon DataZone.
 */
export declare const updateSubscriptionGrantStatus: API.OperationMethod<UpdateSubscriptionGrantStatusInput & RegionInput, UpdateSubscriptionGrantStatusOutput, UpdateSubscriptionGrantStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates a specified subscription request in Amazon DataZone.
 */
export declare const updateSubscriptionRequest: API.OperationMethod<UpdateSubscriptionRequestInput & RegionInput, UpdateSubscriptionRequestOutput, UpdateSubscriptionRequestError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionTargetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified subscription target in Amazon DataZone.
 */
export declare const updateSubscriptionTarget: API.OperationMethod<UpdateSubscriptionTargetInput & RegionInput, UpdateSubscriptionTargetOutput, UpdateSubscriptionTargetError, Credentials | HttpClient.HttpClient>;
export type UpdateUserProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified user profile in Amazon DataZone.
 */
export declare const updateUserProfile: API.OperationMethod<UpdateUserProfileInput & RegionInput, UpdateUserProfileOutput, UpdateUserProfileError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=datazone.d.ts.map