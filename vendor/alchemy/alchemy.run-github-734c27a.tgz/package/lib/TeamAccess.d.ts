import * as Repos from "@distilled.cloud/github/repos";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as GitHub from "./Providers.ts";
export interface TeamAccessProps {
    /**
     * Repository owner — must be an organization login.
     */
    owner: string;
    /**
     * Repository name.
     */
    repository: string;
    /**
     * Team slug within the organization (e.g. `platform`, `frontend`).
     */
    teamSlug: string;
    /**
     * Permission level to grant.
     * - `pull` — read-only access
     * - `push` — read and write access
     * - `maintain` — read, write, and manage issues/PRs
     * - `triage` — read and manage issues/PRs without write access
     * - `admin` — full admin access
     *
     * @default "push"
     */
    permission?: "pull" | "push" | "maintain" | "triage" | "admin";
    /**
     * Override the GitHub host or API base URL for this resource only (e.g.
     * `github.example.com` for GitHub Enterprise). Falls back to
     * `GitHub.providers({ baseUrl })`, then to the host resolved by the auth
     * provider. Changing it replaces the resource — the same name on a
     * different GitHub instance is a different physical resource.
     */
    baseUrl?: string;
}
export interface TeamAccess extends Resource<"GitHub.TeamAccess", TeamAccessProps, {
    /**
     * Team slug.
     */
    teamSlug: string;
    /**
     * Permission level granted.
     */
    permission: string;
}, never, GitHub.Providers> {
}
/**
 * A GitHub team repository access grant.
 *
 * `TeamAccess` grants a team access to a repository within an organization.
 * Teams provide a scalable way to manage repository permissions — add users
 * to teams instead of granting individual collaborator access.
 *
 * Team access grants default to **retain** on removal — destroying the stack
 * does NOT remove the team's access, preventing accidental lockout. Opt in
 * to actual removal by wrapping the resource in {@link destroy}() from
 * `alchemy/RemovalPolicy`.
 *
 * Authentication is resolved via the GitHub `Credentials` service supplied by
 * `GitHub.providers()` (env, stored PAT, `gh` CLI, or OAuth). The token needs
 * `repo` scope and `admin:org` for managing team access.
 *
 * ### Granting Team Access
 * **Example:** Grant Push Access to a Team
 * ```typescript
 * yield* GitHub.TeamAccess("platform-access", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   teamSlug: "platform",
 *   permission: "push",
 * })
 * ```
 *
 * **Example:** Grant Admin Access to a Team
 * ```typescript
 * yield* GitHub.TeamAccess("admin-access", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   teamSlug: "admins",
 *   permission: "admin",
 * })
 * ```
 *
 * **Example:** Grant Read-Only Access
 * ```typescript
 * yield* GitHub.TeamAccess("readonly", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   teamSlug: "contractors",
 *   permission: "pull",
 * })
 * ```
 *
 * ### Multiple Teams
 * **Example:** Grant Different Permissions to Multiple Teams
 * ```typescript
 * yield* GitHub.TeamAccess("platform-write", {
 *   owner: "my-org",
 *   repository: "api",
 *   teamSlug: "platform",
 *   permission: "push",
 * })
 *
 * yield* GitHub.TeamAccess("security-read", {
 *   owner: "my-org",
 *   repository: "api",
 *   teamSlug: "security",
 *   permission: "pull",
 * })
 * ```
 *
 * ### Removing Team Access
 * **Example:** Allow Removal on Destroy
 * ```typescript
 * import { destroy } from "alchemy/RemovalPolicy"
 *
 * yield* GitHub.TeamAccess("temp", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   teamSlug: "contractors",
 *   permission: "push",
 * }).pipe(destroy())
 * ```
 *
 * @resource
 * @product Repository
 */
export declare const TeamAccess: import("alchemy/Resource").ResourceClass<TeamAccess>;
export declare const TeamAccessProvider: () => import("effect/Layer").Layer<Provider.Provider<TeamAccess>, never, Repos.GithubOpContext>;
//# sourceMappingURL=TeamAccess.d.ts.map