import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const MethodNotAllowedException_base: S.TaggedErrorClass<"MethodNotAllowedException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MethodNotAllowedException extends /*@__PURE__*/ MethodNotAllowedException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const PayloadTooLargeException_base: S.TaggedErrorClass<"PayloadTooLargeException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PayloadTooLargeException extends /*@__PURE__*/ PayloadTooLargeException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
    readonly RequestID: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type MapOf__string = {
    [key: string]: string | undefined;
};
export interface CreateApplicationRequest {
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateAppRequest {
    CreateApplicationRequest?: CreateApplicationRequest | undefined;
}
export interface ApplicationResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    CreationDate?: string | undefined;
}
export interface CreateAppResponse {
    ApplicationResponse: ApplicationResponse & {
        Arn: string;
        Id: string;
        Name: string;
    };
}
export type __EndpointTypesElement = "PUSH" | "GCM" | "APNS" | "APNS_SANDBOX" | "APNS_VOIP" | "APNS_VOIP_SANDBOX" | "ADM" | "SMS" | "VOICE" | "EMAIL" | "BAIDU" | "CUSTOM" | "IN_APP" | (string & {});
export type ListOf__EndpointTypesElement = __EndpointTypesElement[];
export interface CustomDeliveryConfiguration {
    DeliveryUri?: string | undefined;
    EndpointTypes?: __EndpointTypesElement[] | undefined;
}
export type Action = "OPEN_APP" | "DEEP_LINK" | "URL" | (string & {});
export interface Message {
    Action?: Action | undefined;
    Body?: string | undefined;
    ImageIconUrl?: string | undefined;
    ImageSmallIconUrl?: string | undefined;
    ImageUrl?: string | undefined;
    JsonBody?: string | undefined;
    MediaUrl?: string | undefined;
    RawContent?: string | undefined;
    SilentPush?: boolean | undefined;
    TimeToLive?: number | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export interface CampaignCustomMessage {
    Data?: string | undefined;
}
export interface MessageHeader {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type ListOfMessageHeader = MessageHeader[];
export interface CampaignEmailMessage {
    Body?: string | undefined;
    FromAddress?: string | undefined;
    Headers?: MessageHeader[] | undefined;
    HtmlBody?: string | undefined;
    Title?: string | undefined;
}
export type MessageType = "TRANSACTIONAL" | "PROMOTIONAL" | (string & {});
export interface CampaignSmsMessage {
    Body?: string | undefined;
    MessageType?: MessageType | undefined;
    OriginationNumber?: string | undefined;
    SenderId?: string | undefined;
    EntityId?: string | undefined;
    TemplateId?: string | undefined;
}
export type Alignment = "LEFT" | "CENTER" | "RIGHT" | (string & {});
export interface InAppMessageBodyConfig {
    Alignment?: Alignment | undefined;
    Body?: string | undefined;
    TextColor?: string | undefined;
}
export interface InAppMessageHeaderConfig {
    Alignment?: Alignment | undefined;
    Header?: string | undefined;
    TextColor?: string | undefined;
}
export type ButtonAction = "LINK" | "DEEP_LINK" | "CLOSE" | (string & {});
export interface OverrideButtonConfiguration {
    ButtonAction?: ButtonAction | undefined;
    Link?: string | undefined;
}
export interface DefaultButtonConfiguration {
    BackgroundColor?: string | undefined;
    BorderRadius?: number | undefined;
    ButtonAction?: ButtonAction | undefined;
    Link?: string | undefined;
    Text?: string | undefined;
    TextColor?: string | undefined;
}
export interface InAppMessageButton {
    Android?: OverrideButtonConfiguration | undefined;
    DefaultConfig?: DefaultButtonConfiguration | undefined;
    IOS?: OverrideButtonConfiguration | undefined;
    Web?: OverrideButtonConfiguration | undefined;
}
export interface InAppMessageContent {
    BackgroundColor?: string | undefined;
    BodyConfig?: InAppMessageBodyConfig | undefined;
    HeaderConfig?: InAppMessageHeaderConfig | undefined;
    ImageUrl?: string | undefined;
    PrimaryBtn?: InAppMessageButton | undefined;
    SecondaryBtn?: InAppMessageButton | undefined;
}
export type ListOfInAppMessageContent = InAppMessageContent[];
export type Layout = "BOTTOM_BANNER" | "TOP_BANNER" | "OVERLAYS" | "MOBILE_FEED" | "MIDDLE_BANNER" | "CAROUSEL" | (string & {});
export interface CampaignInAppMessage {
    Body?: string | undefined;
    Content?: InAppMessageContent[] | undefined;
    CustomConfig?: {
        [key: string]: string | undefined;
    } | undefined;
    Layout?: Layout | undefined;
}
export interface MessageConfiguration {
    ADMMessage?: Message | undefined;
    APNSMessage?: Message | undefined;
    BaiduMessage?: Message | undefined;
    CustomMessage?: CampaignCustomMessage | undefined;
    DefaultMessage?: Message | undefined;
    EmailMessage?: CampaignEmailMessage | undefined;
    GCMMessage?: Message | undefined;
    SMSMessage?: CampaignSmsMessage | undefined;
    InAppMessage?: CampaignInAppMessage | undefined;
}
export type AttributeType = "INCLUSIVE" | "EXCLUSIVE" | "CONTAINS" | "BEFORE" | "AFTER" | "ON" | "BETWEEN" | (string & {});
export type ListOf__string = string[];
export interface AttributeDimension {
    AttributeType?: AttributeType | undefined;
    Values?: string[] | undefined;
}
export type MapOfAttributeDimension = {
    [key: string]: AttributeDimension | undefined;
};
export type DimensionType = "INCLUSIVE" | "EXCLUSIVE" | (string & {});
export interface SetDimension {
    DimensionType?: DimensionType | undefined;
    Values?: string[] | undefined;
}
export interface MetricDimension {
    ComparisonOperator?: string | undefined;
    Value?: number | undefined;
}
export type MapOfMetricDimension = {
    [key: string]: MetricDimension | undefined;
};
export interface EventDimensions {
    Attributes?: {
        [key: string]: AttributeDimension | undefined;
    } | undefined;
    EventType?: SetDimension | undefined;
    Metrics?: {
        [key: string]: MetricDimension | undefined;
    } | undefined;
}
export type FilterType = "SYSTEM" | "ENDPOINT" | (string & {});
export interface CampaignEventFilter {
    Dimensions?: EventDimensions | undefined;
    FilterType?: FilterType | undefined;
}
export type Frequency = "ONCE" | "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "EVENT" | "IN_APP_EVENT" | (string & {});
export interface QuietTime {
    End?: string | undefined;
    Start?: string | undefined;
}
export interface Schedule {
    EndTime?: string | undefined;
    EventFilter?: CampaignEventFilter | undefined;
    Frequency?: Frequency | undefined;
    IsLocalTime?: boolean | undefined;
    QuietTime?: QuietTime | undefined;
    StartTime?: string | undefined;
    Timezone?: string | undefined;
}
export interface Template {
    Name?: string | undefined;
    Version?: string | undefined;
}
export interface TemplateConfiguration {
    EmailTemplate?: Template | undefined;
    PushTemplate?: Template | undefined;
    SMSTemplate?: Template | undefined;
    VoiceTemplate?: Template | undefined;
    InAppTemplate?: Template | undefined;
}
export interface WriteTreatmentResource {
    CustomDeliveryConfiguration?: CustomDeliveryConfiguration | undefined;
    MessageConfiguration?: MessageConfiguration | undefined;
    Schedule?: Schedule | undefined;
    SizePercent?: number | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
    TreatmentDescription?: string | undefined;
    TreatmentName?: string | undefined;
}
export type ListOfWriteTreatmentResource = WriteTreatmentResource[];
export type Mode = "DELIVERY" | "FILTER" | (string & {});
export interface CampaignHook {
    LambdaFunctionName?: string | undefined;
    Mode?: Mode | undefined;
    WebUrl?: string | undefined;
}
export interface CampaignLimits {
    Daily?: number | undefined;
    MaximumDuration?: number | undefined;
    MessagesPerSecond?: number | undefined;
    Total?: number | undefined;
    Session?: number | undefined;
}
export interface WriteCampaignRequest {
    AdditionalTreatments?: WriteTreatmentResource[] | undefined;
    CustomDeliveryConfiguration?: CustomDeliveryConfiguration | undefined;
    Description?: string | undefined;
    HoldoutPercent?: number | undefined;
    Hook?: CampaignHook | undefined;
    IsPaused?: boolean | undefined;
    Limits?: CampaignLimits | undefined;
    MessageConfiguration?: MessageConfiguration | undefined;
    Name?: string | undefined;
    Schedule?: Schedule | undefined;
    SegmentId?: string | undefined;
    SegmentVersion?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
    TreatmentDescription?: string | undefined;
    TreatmentName?: string | undefined;
    Priority?: number | undefined;
}
export interface CreateCampaignRequest {
    ApplicationId: string;
    WriteCampaignRequest?: WriteCampaignRequest | undefined;
}
export type CampaignStatus = "SCHEDULED" | "EXECUTING" | "PENDING_NEXT_RUN" | "COMPLETED" | "PAUSED" | "DELETED" | "INVALID" | (string & {});
export interface CampaignState {
    CampaignStatus?: CampaignStatus | undefined;
}
export interface TreatmentResource {
    CustomDeliveryConfiguration?: CustomDeliveryConfiguration | undefined;
    Id?: string | undefined;
    MessageConfiguration?: MessageConfiguration | undefined;
    Schedule?: Schedule | undefined;
    SizePercent?: number | undefined;
    State?: CampaignState | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
    TreatmentDescription?: string | undefined;
    TreatmentName?: string | undefined;
}
export type ListOfTreatmentResource = TreatmentResource[];
export interface CampaignResponse {
    AdditionalTreatments?: TreatmentResource[] | undefined;
    ApplicationId?: string | undefined;
    Arn?: string | undefined;
    CreationDate?: string | undefined;
    CustomDeliveryConfiguration?: CustomDeliveryConfiguration | undefined;
    DefaultState?: CampaignState | undefined;
    Description?: string | undefined;
    HoldoutPercent?: number | undefined;
    Hook?: CampaignHook | undefined;
    Id?: string | undefined;
    IsPaused?: boolean | undefined;
    LastModifiedDate?: string | undefined;
    Limits?: CampaignLimits | undefined;
    MessageConfiguration?: MessageConfiguration | undefined;
    Name?: string | undefined;
    Schedule?: Schedule | undefined;
    SegmentId?: string | undefined;
    SegmentVersion?: number | undefined;
    State?: CampaignState | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
    TreatmentDescription?: string | undefined;
    TreatmentName?: string | undefined;
    Version?: number | undefined;
    Priority?: number | undefined;
}
export interface CreateCampaignResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface EmailTemplateRequest {
    DefaultSubstitutions?: string | undefined;
    HtmlPart?: string | undefined;
    RecommenderId?: string | undefined;
    Subject?: string | undefined;
    Headers?: MessageHeader[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
    TextPart?: string | undefined;
}
export interface CreateEmailTemplateRequest {
    EmailTemplateRequest?: EmailTemplateRequest | undefined;
    TemplateName: string;
}
export interface CreateTemplateMessageBody {
    Arn?: string | undefined;
    Message?: string | undefined;
    RequestID?: string | undefined;
}
export interface CreateEmailTemplateResponse {
    CreateTemplateMessageBody: CreateTemplateMessageBody;
}
export interface ExportJobRequest {
    RoleArn?: string | undefined;
    S3UrlPrefix?: string | undefined;
    SegmentId?: string | undefined;
    SegmentVersion?: number | undefined;
}
export interface CreateExportJobRequest {
    ApplicationId: string;
    ExportJobRequest?: ExportJobRequest | undefined;
}
export interface ExportJobResource {
    RoleArn?: string | undefined;
    S3UrlPrefix?: string | undefined;
    SegmentId?: string | undefined;
    SegmentVersion?: number | undefined;
}
export type JobStatus = "CREATED" | "PREPARING_FOR_INITIALIZATION" | "INITIALIZING" | "PROCESSING" | "PENDING_JOB" | "COMPLETING" | "COMPLETED" | "FAILING" | "FAILED" | (string & {});
export interface ExportJobResponse {
    ApplicationId?: string | undefined;
    CompletedPieces?: number | undefined;
    CompletionDate?: string | undefined;
    CreationDate?: string | undefined;
    Definition?: ExportJobResource | undefined;
    FailedPieces?: number | undefined;
    Failures?: string[] | undefined;
    Id?: string | undefined;
    JobStatus?: JobStatus | undefined;
    TotalFailures?: number | undefined;
    TotalPieces?: number | undefined;
    TotalProcessed?: number | undefined;
    Type?: string | undefined;
}
export interface CreateExportJobResponse {
    ExportJobResponse: ExportJobResponse & {
        ApplicationId: string;
        CreationDate: string;
        Definition: ExportJobResource & {
            RoleArn: string;
            S3UrlPrefix: string;
        };
        Id: string;
        JobStatus: JobStatus;
        Type: string;
    };
}
export type Format = "CSV" | "JSON" | (string & {});
export interface ImportJobRequest {
    DefineSegment?: boolean | undefined;
    ExternalId?: string | undefined;
    Format?: Format | undefined;
    RegisterEndpoints?: boolean | undefined;
    RoleArn?: string | undefined;
    S3Url?: string | undefined;
    SegmentId?: string | undefined;
    SegmentName?: string | undefined;
}
export interface CreateImportJobRequest {
    ApplicationId: string;
    ImportJobRequest?: ImportJobRequest | undefined;
}
export interface ImportJobResource {
    DefineSegment?: boolean | undefined;
    ExternalId?: string | undefined;
    Format?: Format | undefined;
    RegisterEndpoints?: boolean | undefined;
    RoleArn?: string | undefined;
    S3Url?: string | undefined;
    SegmentId?: string | undefined;
    SegmentName?: string | undefined;
}
export interface ImportJobResponse {
    ApplicationId?: string | undefined;
    CompletedPieces?: number | undefined;
    CompletionDate?: string | undefined;
    CreationDate?: string | undefined;
    Definition?: ImportJobResource | undefined;
    FailedPieces?: number | undefined;
    Failures?: string[] | undefined;
    Id?: string | undefined;
    JobStatus?: JobStatus | undefined;
    TotalFailures?: number | undefined;
    TotalPieces?: number | undefined;
    TotalProcessed?: number | undefined;
    Type?: string | undefined;
}
export interface CreateImportJobResponse {
    ImportJobResponse: ImportJobResponse & {
        ApplicationId: string;
        CreationDate: string;
        Definition: ImportJobResource & {
            Format: Format;
            RoleArn: string;
            S3Url: string;
        };
        Id: string;
        JobStatus: JobStatus;
        Type: string;
    };
}
export interface InAppTemplateRequest {
    Content?: InAppMessageContent[] | undefined;
    CustomConfig?: {
        [key: string]: string | undefined;
    } | undefined;
    Layout?: Layout | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
}
export interface CreateInAppTemplateRequest {
    InAppTemplateRequest?: InAppTemplateRequest | undefined;
    TemplateName: string;
}
export interface TemplateCreateMessageBody {
    Arn?: string | undefined;
    Message?: string | undefined;
    RequestID?: string | undefined;
}
export interface CreateInAppTemplateResponse {
    TemplateCreateMessageBody: TemplateCreateMessageBody;
}
export interface JourneyCustomMessage {
    Data?: string | undefined;
}
export interface CustomMessageActivity {
    DeliveryUri?: string | undefined;
    EndpointTypes?: __EndpointTypesElement[] | undefined;
    MessageConfig?: JourneyCustomMessage | undefined;
    NextActivity?: string | undefined;
    TemplateName?: string | undefined;
    TemplateVersion?: string | undefined;
}
export interface EventCondition {
    Dimensions?: EventDimensions | undefined;
    MessageActivity?: string | undefined;
}
export interface SegmentCondition {
    SegmentId?: string | undefined;
}
export type Duration = "HR_24" | "DAY_7" | "DAY_14" | "DAY_30" | (string & {});
export type RecencyType = "ACTIVE" | "INACTIVE" | (string & {});
export interface RecencyDimension {
    Duration?: Duration | undefined;
    RecencyType?: RecencyType | undefined;
}
export interface SegmentBehaviors {
    Recency?: RecencyDimension | undefined;
}
export interface SegmentDemographics {
    AppVersion?: SetDimension | undefined;
    Channel?: SetDimension | undefined;
    DeviceType?: SetDimension | undefined;
    Make?: SetDimension | undefined;
    Model?: SetDimension | undefined;
    Platform?: SetDimension | undefined;
}
export interface GPSCoordinates {
    Latitude?: number | undefined;
    Longitude?: number | undefined;
}
export interface GPSPointDimension {
    Coordinates?: GPSCoordinates | undefined;
    RangeInKilometers?: number | undefined;
}
export interface SegmentLocation {
    Country?: SetDimension | undefined;
    GPSPoint?: GPSPointDimension | undefined;
}
export interface SegmentDimensions {
    Attributes?: {
        [key: string]: AttributeDimension | undefined;
    } | undefined;
    Behavior?: SegmentBehaviors | undefined;
    Demographic?: SegmentDemographics | undefined;
    Location?: SegmentLocation | undefined;
    Metrics?: {
        [key: string]: MetricDimension | undefined;
    } | undefined;
    UserAttributes?: {
        [key: string]: AttributeDimension | undefined;
    } | undefined;
}
export interface SimpleCondition {
    EventCondition?: EventCondition | undefined;
    SegmentCondition?: SegmentCondition | undefined;
    SegmentDimensions?: SegmentDimensions | undefined;
}
export type ListOfSimpleCondition = SimpleCondition[];
export type Operator = "ALL" | "ANY" | (string & {});
export interface Condition {
    Conditions?: SimpleCondition[] | undefined;
    Operator?: Operator | undefined;
}
export interface WaitTime {
    WaitFor?: string | undefined;
    WaitUntil?: string | undefined;
}
export interface ConditionalSplitActivity {
    Condition?: Condition | undefined;
    EvaluationWaitTime?: WaitTime | undefined;
    FalseActivity?: string | undefined;
    TrueActivity?: string | undefined;
}
export interface JourneyEmailMessage {
    FromAddress?: string | undefined;
}
export interface EmailMessageActivity {
    MessageConfig?: JourneyEmailMessage | undefined;
    NextActivity?: string | undefined;
    TemplateName?: string | undefined;
    TemplateVersion?: string | undefined;
}
export interface HoldoutActivity {
    NextActivity?: string | undefined;
    Percentage?: number | undefined;
}
export interface MultiConditionalBranch {
    Condition?: SimpleCondition | undefined;
    NextActivity?: string | undefined;
}
export type ListOfMultiConditionalBranch = MultiConditionalBranch[];
export interface MultiConditionalSplitActivity {
    Branches?: MultiConditionalBranch[] | undefined;
    DefaultActivity?: string | undefined;
    EvaluationWaitTime?: WaitTime | undefined;
}
export interface JourneyPushMessage {
    TimeToLive?: string | undefined;
}
export interface PushMessageActivity {
    MessageConfig?: JourneyPushMessage | undefined;
    NextActivity?: string | undefined;
    TemplateName?: string | undefined;
    TemplateVersion?: string | undefined;
}
export interface RandomSplitEntry {
    NextActivity?: string | undefined;
    Percentage?: number | undefined;
}
export type ListOfRandomSplitEntry = RandomSplitEntry[];
export interface RandomSplitActivity {
    Branches?: RandomSplitEntry[] | undefined;
}
export interface JourneySMSMessage {
    MessageType?: MessageType | undefined;
    OriginationNumber?: string | undefined;
    SenderId?: string | undefined;
    EntityId?: string | undefined;
    TemplateId?: string | undefined;
}
export interface SMSMessageActivity {
    MessageConfig?: JourneySMSMessage | undefined;
    NextActivity?: string | undefined;
    TemplateName?: string | undefined;
    TemplateVersion?: string | undefined;
}
export interface WaitActivity {
    NextActivity?: string | undefined;
    WaitTime?: WaitTime | undefined;
}
export interface ContactCenterActivity {
    NextActivity?: string | undefined;
}
export interface Activity {
    CUSTOM?: CustomMessageActivity | undefined;
    ConditionalSplit?: ConditionalSplitActivity | undefined;
    Description?: string | undefined;
    EMAIL?: EmailMessageActivity | undefined;
    Holdout?: HoldoutActivity | undefined;
    MultiCondition?: MultiConditionalSplitActivity | undefined;
    PUSH?: PushMessageActivity | undefined;
    RandomSplit?: RandomSplitActivity | undefined;
    SMS?: SMSMessageActivity | undefined;
    Wait?: WaitActivity | undefined;
    ContactCenter?: ContactCenterActivity | undefined;
}
export type MapOfActivity = {
    [key: string]: Activity | undefined;
};
export interface JourneyTimeframeCap {
    Cap?: number | undefined;
    Days?: number | undefined;
}
export interface JourneyLimits {
    DailyCap?: number | undefined;
    EndpointReentryCap?: number | undefined;
    MessagesPerSecond?: number | undefined;
    EndpointReentryInterval?: string | undefined;
    TimeframeCap?: JourneyTimeframeCap | undefined;
    TotalCap?: number | undefined;
}
export type __timestampIso8601 = Date;
export interface JourneySchedule {
    EndTime?: Date | undefined;
    StartTime?: Date | undefined;
    Timezone?: string | undefined;
}
export interface EventFilter {
    Dimensions?: EventDimensions | undefined;
    FilterType?: FilterType | undefined;
}
export interface EventStartCondition {
    EventFilter?: EventFilter | undefined;
    SegmentId?: string | undefined;
}
export interface StartCondition {
    Description?: string | undefined;
    EventStartCondition?: EventStartCondition | undefined;
    SegmentStartCondition?: SegmentCondition | undefined;
}
export type State = "DRAFT" | "ACTIVE" | "COMPLETED" | "CANCELLED" | "CLOSED" | "PAUSED" | (string & {});
export interface JourneyChannelSettings {
    ConnectCampaignArn?: string | undefined;
    ConnectCampaignExecutionRoleArn?: string | undefined;
}
export type DayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface OpenHoursRule {
    StartTime?: string | undefined;
    EndTime?: string | undefined;
}
export type ListOfOpenHoursRules = OpenHoursRule[];
export type MapOfListOfOpenHoursRules = {
    [key in DayOfWeek]?: OpenHoursRule[] | undefined;
};
export interface OpenHours {
    EMAIL?: {
        [key: string]: OpenHoursRule[] | undefined;
    } | undefined;
    SMS?: {
        [key: string]: OpenHoursRule[] | undefined;
    } | undefined;
    PUSH?: {
        [key: string]: OpenHoursRule[] | undefined;
    } | undefined;
    VOICE?: {
        [key: string]: OpenHoursRule[] | undefined;
    } | undefined;
    CUSTOM?: {
        [key: string]: OpenHoursRule[] | undefined;
    } | undefined;
}
export interface ClosedDaysRule {
    Name?: string | undefined;
    StartDateTime?: string | undefined;
    EndDateTime?: string | undefined;
}
export type ListOfClosedDaysRules = ClosedDaysRule[];
export interface ClosedDays {
    EMAIL?: ClosedDaysRule[] | undefined;
    SMS?: ClosedDaysRule[] | undefined;
    PUSH?: ClosedDaysRule[] | undefined;
    VOICE?: ClosedDaysRule[] | undefined;
    CUSTOM?: ClosedDaysRule[] | undefined;
}
export type __TimezoneEstimationMethodsElement = "PHONE_NUMBER" | "POSTAL_CODE" | (string & {});
export type ListOf__TimezoneEstimationMethodsElement = __TimezoneEstimationMethodsElement[];
export interface WriteJourneyRequest {
    Activities?: {
        [key: string]: Activity | undefined;
    } | undefined;
    CreationDate?: string | undefined;
    LastModifiedDate?: string | undefined;
    Limits?: JourneyLimits | undefined;
    LocalTime?: boolean | undefined;
    Name?: string | undefined;
    QuietTime?: QuietTime | undefined;
    RefreshFrequency?: string | undefined;
    Schedule?: JourneySchedule | undefined;
    StartActivity?: string | undefined;
    StartCondition?: StartCondition | undefined;
    State?: State | undefined;
    WaitForQuietTime?: boolean | undefined;
    RefreshOnSegmentUpdate?: boolean | undefined;
    JourneyChannelSettings?: JourneyChannelSettings | undefined;
    SendingSchedule?: boolean | undefined;
    OpenHours?: OpenHours | undefined;
    ClosedDays?: ClosedDays | undefined;
    TimezoneEstimationMethods?: __TimezoneEstimationMethodsElement[] | undefined;
}
export interface CreateJourneyRequest {
    ApplicationId: string;
    WriteJourneyRequest?: WriteJourneyRequest | undefined;
}
export interface JourneyResponse {
    Activities?: {
        [key: string]: Activity | undefined;
    } | undefined;
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    Id?: string | undefined;
    LastModifiedDate?: string | undefined;
    Limits?: JourneyLimits | undefined;
    LocalTime?: boolean | undefined;
    Name?: string | undefined;
    QuietTime?: QuietTime | undefined;
    RefreshFrequency?: string | undefined;
    Schedule?: JourneySchedule | undefined;
    StartActivity?: string | undefined;
    StartCondition?: StartCondition | undefined;
    State?: State | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    WaitForQuietTime?: boolean | undefined;
    RefreshOnSegmentUpdate?: boolean | undefined;
    JourneyChannelSettings?: JourneyChannelSettings | undefined;
    SendingSchedule?: boolean | undefined;
    OpenHours?: OpenHours | undefined;
    ClosedDays?: ClosedDays | undefined;
    TimezoneEstimationMethods?: __TimezoneEstimationMethodsElement[] | undefined;
}
export interface CreateJourneyResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface AndroidPushNotificationTemplate {
    Action?: Action | undefined;
    Body?: string | undefined;
    ImageIconUrl?: string | undefined;
    ImageUrl?: string | undefined;
    RawContent?: string | undefined;
    SmallImageIconUrl?: string | undefined;
    Sound?: string | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export interface APNSPushNotificationTemplate {
    Action?: Action | undefined;
    Body?: string | undefined;
    MediaUrl?: string | undefined;
    RawContent?: string | undefined;
    Sound?: string | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export interface DefaultPushNotificationTemplate {
    Action?: Action | undefined;
    Body?: string | undefined;
    Sound?: string | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export interface PushNotificationTemplateRequest {
    ADM?: AndroidPushNotificationTemplate | undefined;
    APNS?: APNSPushNotificationTemplate | undefined;
    Baidu?: AndroidPushNotificationTemplate | undefined;
    Default?: DefaultPushNotificationTemplate | undefined;
    DefaultSubstitutions?: string | undefined;
    GCM?: AndroidPushNotificationTemplate | undefined;
    RecommenderId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
}
export interface CreatePushTemplateRequest {
    PushNotificationTemplateRequest?: PushNotificationTemplateRequest | undefined;
    TemplateName: string;
}
export interface CreatePushTemplateResponse {
    CreateTemplateMessageBody: CreateTemplateMessageBody;
}
export interface CreateRecommenderConfigurationShape {
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    Description?: string | undefined;
    Name?: string | undefined;
    RecommendationProviderIdType?: string | undefined;
    RecommendationProviderRoleArn?: string | undefined;
    RecommendationProviderUri?: string | undefined;
    RecommendationTransformerUri?: string | undefined;
    RecommendationsDisplayName?: string | undefined;
    RecommendationsPerMessage?: number | undefined;
}
export interface CreateRecommenderConfigurationRequest {
    CreateRecommenderConfiguration?: CreateRecommenderConfigurationShape | undefined;
}
export interface RecommenderConfigurationResponse {
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    CreationDate?: string | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    LastModifiedDate?: string | undefined;
    Name?: string | undefined;
    RecommendationProviderIdType?: string | undefined;
    RecommendationProviderRoleArn?: string | undefined;
    RecommendationProviderUri?: string | undefined;
    RecommendationTransformerUri?: string | undefined;
    RecommendationsDisplayName?: string | undefined;
    RecommendationsPerMessage?: number | undefined;
}
export interface CreateRecommenderConfigurationResponse {
    RecommenderConfigurationResponse: RecommenderConfigurationResponse & {
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        RecommendationProviderRoleArn: string;
        RecommendationProviderUri: string;
    };
}
export type ListOfSegmentDimensions = SegmentDimensions[];
export interface SegmentReference {
    Id?: string | undefined;
    Version?: number | undefined;
}
export type ListOfSegmentReference = SegmentReference[];
export type SourceType = "ALL" | "ANY" | "NONE" | (string & {});
export type Type = "ALL" | "ANY" | "NONE" | (string & {});
export interface SegmentGroup {
    Dimensions?: SegmentDimensions[] | undefined;
    SourceSegments?: SegmentReference[] | undefined;
    SourceType?: SourceType | undefined;
    Type?: Type | undefined;
}
export type ListOfSegmentGroup = SegmentGroup[];
export type Include = "ALL" | "ANY" | "NONE" | (string & {});
export interface SegmentGroupList {
    Groups?: SegmentGroup[] | undefined;
    Include?: Include | undefined;
}
export interface WriteSegmentRequest {
    Dimensions?: SegmentDimensions | undefined;
    Name?: string | undefined;
    SegmentGroups?: SegmentGroupList | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateSegmentRequest {
    ApplicationId: string;
    WriteSegmentRequest?: WriteSegmentRequest | undefined;
}
export type MapOf__integer = {
    [key: string]: number | undefined;
};
export interface SegmentImportResource {
    ChannelCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    ExternalId?: string | undefined;
    Format?: Format | undefined;
    RoleArn?: string | undefined;
    S3Url?: string | undefined;
    Size?: number | undefined;
}
export type SegmentType = "DIMENSIONAL" | "IMPORT" | (string & {});
export interface SegmentResponse {
    ApplicationId?: string | undefined;
    Arn?: string | undefined;
    CreationDate?: string | undefined;
    Dimensions?: SegmentDimensions | undefined;
    Id?: string | undefined;
    ImportDefinition?: SegmentImportResource | undefined;
    LastModifiedDate?: string | undefined;
    Name?: string | undefined;
    SegmentGroups?: SegmentGroupList | undefined;
    SegmentType?: SegmentType | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Version?: number | undefined;
}
export interface CreateSegmentResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface SMSTemplateRequest {
    Body?: string | undefined;
    DefaultSubstitutions?: string | undefined;
    RecommenderId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
}
export interface CreateSmsTemplateRequest {
    SMSTemplateRequest?: SMSTemplateRequest | undefined;
    TemplateName: string;
}
export interface CreateSmsTemplateResponse {
    CreateTemplateMessageBody: CreateTemplateMessageBody;
}
export interface VoiceTemplateRequest {
    Body?: string | undefined;
    DefaultSubstitutions?: string | undefined;
    LanguageCode?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
    VoiceId?: string | undefined;
}
export interface CreateVoiceTemplateRequest {
    TemplateName: string;
    VoiceTemplateRequest?: VoiceTemplateRequest | undefined;
}
export interface CreateVoiceTemplateResponse {
    CreateTemplateMessageBody: CreateTemplateMessageBody;
}
export interface DeleteAdmChannelRequest {
    ApplicationId: string;
}
export interface ADMChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteAdmChannelResponse {
    ADMChannelResponse: ADMChannelResponse & {
        Platform: string;
    };
}
export interface DeleteApnsChannelRequest {
    ApplicationId: string;
}
export interface APNSChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    HasTokenKey?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteApnsChannelResponse {
    APNSChannelResponse: APNSChannelResponse & {
        Platform: string;
    };
}
export interface DeleteApnsSandboxChannelRequest {
    ApplicationId: string;
}
export interface APNSSandboxChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    HasTokenKey?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteApnsSandboxChannelResponse {
    APNSSandboxChannelResponse: APNSSandboxChannelResponse & {
        Platform: string;
    };
}
export interface DeleteApnsVoipChannelRequest {
    ApplicationId: string;
}
export interface APNSVoipChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    HasTokenKey?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteApnsVoipChannelResponse {
    APNSVoipChannelResponse: APNSVoipChannelResponse & {
        Platform: string;
    };
}
export interface DeleteApnsVoipSandboxChannelRequest {
    ApplicationId: string;
}
export interface APNSVoipSandboxChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    HasTokenKey?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteApnsVoipSandboxChannelResponse {
    APNSVoipSandboxChannelResponse: APNSVoipSandboxChannelResponse & {
        Platform: string;
    };
}
export interface DeleteAppRequest {
    ApplicationId: string;
}
export interface DeleteAppResponse {
    ApplicationResponse: ApplicationResponse & {
        Arn: string;
        Id: string;
        Name: string;
    };
}
export interface DeleteBaiduChannelRequest {
    ApplicationId: string;
}
export interface BaiduChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    Credential?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteBaiduChannelResponse {
    BaiduChannelResponse: BaiduChannelResponse & {
        Credential: string;
        Platform: string;
    };
}
export interface DeleteCampaignRequest {
    ApplicationId: string;
    CampaignId: string;
}
export interface DeleteCampaignResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface DeleteEmailChannelRequest {
    ApplicationId: string;
}
export interface EmailChannelResponse {
    ApplicationId?: string | undefined;
    ConfigurationSet?: string | undefined;
    CreationDate?: string | undefined;
    Enabled?: boolean | undefined;
    FromAddress?: string | undefined;
    HasCredential?: boolean | undefined;
    Id?: string | undefined;
    Identity?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    MessagesPerSecond?: number | undefined;
    Platform?: string | undefined;
    RoleArn?: string | undefined;
    OrchestrationSendingRoleArn?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteEmailChannelResponse {
    EmailChannelResponse: EmailChannelResponse & {
        Platform: string;
    };
}
export interface DeleteEmailTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface MessageBody {
    Message?: string | undefined;
    RequestID?: string | undefined;
}
export interface DeleteEmailTemplateResponse {
    MessageBody: MessageBody;
}
export interface DeleteEndpointRequest {
    ApplicationId: string;
    EndpointId: string;
}
export type MapOfListOf__string = {
    [key: string]: string[] | undefined;
};
export type ChannelType = "PUSH" | "GCM" | "APNS" | "APNS_SANDBOX" | "APNS_VOIP" | "APNS_VOIP_SANDBOX" | "ADM" | "SMS" | "VOICE" | "EMAIL" | "BAIDU" | "CUSTOM" | "IN_APP" | (string & {});
export interface EndpointDemographic {
    AppVersion?: string | undefined;
    Locale?: string | undefined;
    Make?: string | undefined;
    Model?: string | undefined;
    ModelVersion?: string | undefined;
    Platform?: string | undefined;
    PlatformVersion?: string | undefined;
    Timezone?: string | undefined;
}
export interface EndpointLocation {
    City?: string | undefined;
    Country?: string | undefined;
    Latitude?: number | undefined;
    Longitude?: number | undefined;
    PostalCode?: string | undefined;
    Region?: string | undefined;
}
export type MapOf__double = {
    [key: string]: number | undefined;
};
export interface EndpointUser {
    UserAttributes?: {
        [key: string]: string[] | undefined;
    } | undefined;
    UserId?: string | undefined;
}
export interface EndpointResponse {
    Address?: string | undefined;
    ApplicationId?: string | undefined;
    Attributes?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ChannelType?: ChannelType | undefined;
    CohortId?: string | undefined;
    CreationDate?: string | undefined;
    Demographic?: EndpointDemographic | undefined;
    EffectiveDate?: string | undefined;
    EndpointStatus?: string | undefined;
    Id?: string | undefined;
    Location?: EndpointLocation | undefined;
    Metrics?: {
        [key: string]: number | undefined;
    } | undefined;
    OptOut?: string | undefined;
    RequestId?: string | undefined;
    User?: EndpointUser | undefined;
}
export interface DeleteEndpointResponse {
    EndpointResponse: EndpointResponse;
}
export interface DeleteEventStreamRequest {
    ApplicationId: string;
}
export interface EventStream {
    ApplicationId?: string | undefined;
    DestinationStreamArn?: string | undefined;
    ExternalId?: string | undefined;
    LastModifiedDate?: string | undefined;
    LastUpdatedBy?: string | undefined;
    RoleArn?: string | undefined;
}
export interface DeleteEventStreamResponse {
    EventStream: EventStream & {
        ApplicationId: string;
        DestinationStreamArn: string;
        RoleArn: string;
    };
}
export interface DeleteGcmChannelRequest {
    ApplicationId: string;
}
export interface GCMChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    Credential?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    HasFcmServiceCredentials?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteGcmChannelResponse {
    GCMChannelResponse: GCMChannelResponse & {
        Platform: string;
    };
}
export interface DeleteInAppTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface DeleteInAppTemplateResponse {
    MessageBody: MessageBody;
}
export interface DeleteJourneyRequest {
    ApplicationId: string;
    JourneyId: string;
}
export interface DeleteJourneyResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface DeletePushTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface DeletePushTemplateResponse {
    MessageBody: MessageBody;
}
export interface DeleteRecommenderConfigurationRequest {
    RecommenderId: string;
}
export interface DeleteRecommenderConfigurationResponse {
    RecommenderConfigurationResponse: RecommenderConfigurationResponse & {
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        RecommendationProviderRoleArn: string;
        RecommendationProviderUri: string;
    };
}
export interface DeleteSegmentRequest {
    ApplicationId: string;
    SegmentId: string;
}
export interface DeleteSegmentResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface DeleteSmsChannelRequest {
    ApplicationId: string;
}
export interface SMSChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    PromotionalMessagesPerSecond?: number | undefined;
    SenderId?: string | undefined;
    ShortCode?: string | undefined;
    TransactionalMessagesPerSecond?: number | undefined;
    Version?: number | undefined;
}
export interface DeleteSmsChannelResponse {
    SMSChannelResponse: SMSChannelResponse & {
        Platform: string;
    };
}
export interface DeleteSmsTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface DeleteSmsTemplateResponse {
    MessageBody: MessageBody;
}
export interface DeleteUserEndpointsRequest {
    ApplicationId: string;
    UserId: string;
}
export type ListOfEndpointResponse = EndpointResponse[];
export interface EndpointsResponse {
    Item?: EndpointResponse[] | undefined;
}
export interface DeleteUserEndpointsResponse {
    EndpointsResponse: EndpointsResponse & {
        Item: ListOfEndpointResponse;
    };
}
export interface DeleteVoiceChannelRequest {
    ApplicationId: string;
}
export interface VoiceChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Platform?: string | undefined;
    Version?: number | undefined;
}
export interface DeleteVoiceChannelResponse {
    VoiceChannelResponse: VoiceChannelResponse & {
        Platform: string;
    };
}
export interface DeleteVoiceTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface DeleteVoiceTemplateResponse {
    MessageBody: MessageBody;
}
export interface GetAdmChannelRequest {
    ApplicationId: string;
}
export interface GetAdmChannelResponse {
    ADMChannelResponse: ADMChannelResponse & {
        Platform: string;
    };
}
export interface GetApnsChannelRequest {
    ApplicationId: string;
}
export interface GetApnsChannelResponse {
    APNSChannelResponse: APNSChannelResponse & {
        Platform: string;
    };
}
export interface GetApnsSandboxChannelRequest {
    ApplicationId: string;
}
export interface GetApnsSandboxChannelResponse {
    APNSSandboxChannelResponse: APNSSandboxChannelResponse & {
        Platform: string;
    };
}
export interface GetApnsVoipChannelRequest {
    ApplicationId: string;
}
export interface GetApnsVoipChannelResponse {
    APNSVoipChannelResponse: APNSVoipChannelResponse & {
        Platform: string;
    };
}
export interface GetApnsVoipSandboxChannelRequest {
    ApplicationId: string;
}
export interface GetApnsVoipSandboxChannelResponse {
    APNSVoipSandboxChannelResponse: APNSVoipSandboxChannelResponse & {
        Platform: string;
    };
}
export interface GetAppRequest {
    ApplicationId: string;
}
export interface GetAppResponse {
    ApplicationResponse: ApplicationResponse & {
        Arn: string;
        Id: string;
        Name: string;
    };
}
export interface GetApplicationDateRangeKpiRequest {
    ApplicationId: string;
    EndTime?: Date | undefined;
    KpiName: string;
    NextToken?: string | undefined;
    PageSize?: string | undefined;
    StartTime?: Date | undefined;
}
export interface ResultRowValue {
    Key?: string | undefined;
    Type?: string | undefined;
    Value?: string | undefined;
}
export type ListOfResultRowValue = ResultRowValue[];
export interface ResultRow {
    GroupedBys?: ResultRowValue[] | undefined;
    Values?: ResultRowValue[] | undefined;
}
export type ListOfResultRow = ResultRow[];
export interface BaseKpiResult {
    Rows?: ResultRow[] | undefined;
}
export interface ApplicationDateRangeKpiResponse {
    ApplicationId?: string | undefined;
    EndTime?: Date | undefined;
    KpiName?: string | undefined;
    KpiResult?: BaseKpiResult | undefined;
    NextToken?: string | undefined;
    StartTime?: Date | undefined;
}
export interface GetApplicationDateRangeKpiResponse {
    ApplicationDateRangeKpiResponse: ApplicationDateRangeKpiResponse & {
        ApplicationId: string;
        EndTime: __timestampIso8601;
        KpiName: string;
        KpiResult: BaseKpiResult & {
            Rows: (ResultRow & {
                GroupedBys: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
                Values: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
            })[];
        };
        StartTime: __timestampIso8601;
    };
}
export interface GetApplicationSettingsRequest {
    ApplicationId: string;
}
export interface ApplicationSettingsJourneyLimits {
    DailyCap?: number | undefined;
    TimeframeCap?: JourneyTimeframeCap | undefined;
    TotalCap?: number | undefined;
}
export interface ApplicationSettingsResource {
    ApplicationId?: string | undefined;
    CampaignHook?: CampaignHook | undefined;
    LastModifiedDate?: string | undefined;
    Limits?: CampaignLimits | undefined;
    QuietTime?: QuietTime | undefined;
    JourneyLimits?: ApplicationSettingsJourneyLimits | undefined;
}
export interface GetApplicationSettingsResponse {
    ApplicationSettingsResource: ApplicationSettingsResource & {
        ApplicationId: string;
    };
}
export interface GetAppsRequest {
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export type ListOfApplicationResponse = ApplicationResponse[];
export interface ApplicationsResponse {
    Item?: ApplicationResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface GetAppsResponse {
    ApplicationsResponse: ApplicationsResponse & {
        Item: (ApplicationResponse & {
            Arn: string;
            Id: string;
            Name: string;
        })[];
    };
}
export interface GetBaiduChannelRequest {
    ApplicationId: string;
}
export interface GetBaiduChannelResponse {
    BaiduChannelResponse: BaiduChannelResponse & {
        Credential: string;
        Platform: string;
    };
}
export interface GetCampaignRequest {
    ApplicationId: string;
    CampaignId: string;
}
export interface GetCampaignResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface GetCampaignActivitiesRequest {
    ApplicationId: string;
    CampaignId: string;
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export interface ActivityResponse {
    ApplicationId?: string | undefined;
    CampaignId?: string | undefined;
    End?: string | undefined;
    Id?: string | undefined;
    Result?: string | undefined;
    ScheduledStart?: string | undefined;
    Start?: string | undefined;
    State?: string | undefined;
    SuccessfulEndpointCount?: number | undefined;
    TimezonesCompletedCount?: number | undefined;
    TimezonesTotalCount?: number | undefined;
    TotalEndpointCount?: number | undefined;
    TreatmentId?: string | undefined;
    ExecutionMetrics?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListOfActivityResponse = ActivityResponse[];
export interface ActivitiesResponse {
    Item?: ActivityResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCampaignActivitiesResponse {
    ActivitiesResponse: ActivitiesResponse & {
        Item: (ActivityResponse & {
            ApplicationId: string;
            CampaignId: string;
            Id: string;
        })[];
    };
}
export interface GetCampaignDateRangeKpiRequest {
    ApplicationId: string;
    CampaignId: string;
    EndTime?: Date | undefined;
    KpiName: string;
    NextToken?: string | undefined;
    PageSize?: string | undefined;
    StartTime?: Date | undefined;
}
export interface CampaignDateRangeKpiResponse {
    ApplicationId?: string | undefined;
    CampaignId?: string | undefined;
    EndTime?: Date | undefined;
    KpiName?: string | undefined;
    KpiResult?: BaseKpiResult | undefined;
    NextToken?: string | undefined;
    StartTime?: Date | undefined;
}
export interface GetCampaignDateRangeKpiResponse {
    CampaignDateRangeKpiResponse: CampaignDateRangeKpiResponse & {
        ApplicationId: string;
        CampaignId: string;
        EndTime: __timestampIso8601;
        KpiName: string;
        KpiResult: BaseKpiResult & {
            Rows: (ResultRow & {
                GroupedBys: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
                Values: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
            })[];
        };
        StartTime: __timestampIso8601;
    };
}
export interface GetCampaignsRequest {
    ApplicationId: string;
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export type ListOfCampaignResponse = CampaignResponse[];
export interface CampaignsResponse {
    Item?: CampaignResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCampaignsResponse {
    CampaignsResponse: CampaignsResponse & {
        Item: (CampaignResponse & {
            ApplicationId: string;
            Arn: string;
            CreationDate: string;
            Id: string;
            LastModifiedDate: string;
            SegmentId: string;
            SegmentVersion: number;
            AdditionalTreatments: (TreatmentResource & {
                Id: string;
                SizePercent: number;
                CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                    DeliveryUri: string;
                };
                MessageConfiguration: MessageConfiguration & {
                    InAppMessage: CampaignInAppMessage & {
                        Content: (InAppMessageContent & {
                            BodyConfig: InAppMessageBodyConfig & {
                                Alignment: Alignment;
                                Body: string;
                                TextColor: string;
                            };
                            HeaderConfig: InAppMessageHeaderConfig & {
                                Alignment: Alignment;
                                Header: string;
                                TextColor: string;
                            };
                            PrimaryBtn: InAppMessageButton & {
                                Android: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                DefaultConfig: DefaultButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                    Text: string;
                                };
                                IOS: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                Web: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                            };
                            SecondaryBtn: InAppMessageButton & {
                                Android: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                DefaultConfig: DefaultButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                    Text: string;
                                };
                                IOS: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                Web: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                            };
                        })[];
                    };
                };
                Schedule: Schedule & {
                    StartTime: string;
                    EventFilter: CampaignEventFilter & {
                        Dimensions: EventDimensions & {
                            Attributes: {
                                [key: string]: (AttributeDimension & {
                                    Values: ListOf__string;
                                }) | undefined;
                            };
                            EventType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Metrics: {
                                [key: string]: (MetricDimension & {
                                    ComparisonOperator: string;
                                    Value: number;
                                }) | undefined;
                            };
                        };
                        FilterType: FilterType;
                    };
                };
            })[];
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
    };
}
export interface GetCampaignVersionRequest {
    ApplicationId: string;
    CampaignId: string;
    Version: string;
}
export interface GetCampaignVersionResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface GetCampaignVersionsRequest {
    ApplicationId: string;
    CampaignId: string;
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export interface GetCampaignVersionsResponse {
    CampaignsResponse: CampaignsResponse & {
        Item: (CampaignResponse & {
            ApplicationId: string;
            Arn: string;
            CreationDate: string;
            Id: string;
            LastModifiedDate: string;
            SegmentId: string;
            SegmentVersion: number;
            AdditionalTreatments: (TreatmentResource & {
                Id: string;
                SizePercent: number;
                CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                    DeliveryUri: string;
                };
                MessageConfiguration: MessageConfiguration & {
                    InAppMessage: CampaignInAppMessage & {
                        Content: (InAppMessageContent & {
                            BodyConfig: InAppMessageBodyConfig & {
                                Alignment: Alignment;
                                Body: string;
                                TextColor: string;
                            };
                            HeaderConfig: InAppMessageHeaderConfig & {
                                Alignment: Alignment;
                                Header: string;
                                TextColor: string;
                            };
                            PrimaryBtn: InAppMessageButton & {
                                Android: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                DefaultConfig: DefaultButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                    Text: string;
                                };
                                IOS: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                Web: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                            };
                            SecondaryBtn: InAppMessageButton & {
                                Android: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                DefaultConfig: DefaultButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                    Text: string;
                                };
                                IOS: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                                Web: OverrideButtonConfiguration & {
                                    ButtonAction: ButtonAction;
                                };
                            };
                        })[];
                    };
                };
                Schedule: Schedule & {
                    StartTime: string;
                    EventFilter: CampaignEventFilter & {
                        Dimensions: EventDimensions & {
                            Attributes: {
                                [key: string]: (AttributeDimension & {
                                    Values: ListOf__string;
                                }) | undefined;
                            };
                            EventType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Metrics: {
                                [key: string]: (MetricDimension & {
                                    ComparisonOperator: string;
                                    Value: number;
                                }) | undefined;
                            };
                        };
                        FilterType: FilterType;
                    };
                };
            })[];
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
    };
}
export interface GetChannelsRequest {
    ApplicationId: string;
}
export interface ChannelResponse {
    ApplicationId?: string | undefined;
    CreationDate?: string | undefined;
    Enabled?: boolean | undefined;
    HasCredential?: boolean | undefined;
    Id?: string | undefined;
    IsArchived?: boolean | undefined;
    LastModifiedBy?: string | undefined;
    LastModifiedDate?: string | undefined;
    Version?: number | undefined;
}
export type MapOfChannelResponse = {
    [key: string]: ChannelResponse | undefined;
};
export interface ChannelsResponse {
    Channels?: {
        [key: string]: ChannelResponse | undefined;
    } | undefined;
}
export interface GetChannelsResponse {
    ChannelsResponse: ChannelsResponse & {
        Channels: MapOfChannelResponse;
    };
}
export interface GetEmailChannelRequest {
    ApplicationId: string;
}
export interface GetEmailChannelResponse {
    EmailChannelResponse: EmailChannelResponse & {
        Platform: string;
    };
}
export interface GetEmailTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export type TemplateType = "EMAIL" | "SMS" | "VOICE" | "PUSH" | "INAPP" | (string & {});
export interface EmailTemplateResponse {
    Arn?: string | undefined;
    CreationDate?: string | undefined;
    DefaultSubstitutions?: string | undefined;
    HtmlPart?: string | undefined;
    LastModifiedDate?: string | undefined;
    RecommenderId?: string | undefined;
    Subject?: string | undefined;
    Headers?: MessageHeader[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
    TemplateName?: string | undefined;
    TemplateType?: TemplateType | undefined;
    TextPart?: string | undefined;
    Version?: string | undefined;
}
export interface GetEmailTemplateResponse {
    EmailTemplateResponse: EmailTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
    };
}
export interface GetEndpointRequest {
    ApplicationId: string;
    EndpointId: string;
}
export interface GetEndpointResponse {
    EndpointResponse: EndpointResponse;
}
export interface GetEventStreamRequest {
    ApplicationId: string;
}
export interface GetEventStreamResponse {
    EventStream: EventStream & {
        ApplicationId: string;
        DestinationStreamArn: string;
        RoleArn: string;
    };
}
export interface GetExportJobRequest {
    ApplicationId: string;
    JobId: string;
}
export interface GetExportJobResponse {
    ExportJobResponse: ExportJobResponse & {
        ApplicationId: string;
        CreationDate: string;
        Definition: ExportJobResource & {
            RoleArn: string;
            S3UrlPrefix: string;
        };
        Id: string;
        JobStatus: JobStatus;
        Type: string;
    };
}
export interface GetExportJobsRequest {
    ApplicationId: string;
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export type ListOfExportJobResponse = ExportJobResponse[];
export interface ExportJobsResponse {
    Item?: ExportJobResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface GetExportJobsResponse {
    ExportJobsResponse: ExportJobsResponse & {
        Item: (ExportJobResponse & {
            ApplicationId: string;
            CreationDate: string;
            Definition: ExportJobResource & {
                RoleArn: string;
                S3UrlPrefix: string;
            };
            Id: string;
            JobStatus: JobStatus;
            Type: string;
        })[];
    };
}
export interface GetGcmChannelRequest {
    ApplicationId: string;
}
export interface GetGcmChannelResponse {
    GCMChannelResponse: GCMChannelResponse & {
        Platform: string;
    };
}
export interface GetImportJobRequest {
    ApplicationId: string;
    JobId: string;
}
export interface GetImportJobResponse {
    ImportJobResponse: ImportJobResponse & {
        ApplicationId: string;
        CreationDate: string;
        Definition: ImportJobResource & {
            Format: Format;
            RoleArn: string;
            S3Url: string;
        };
        Id: string;
        JobStatus: JobStatus;
        Type: string;
    };
}
export interface GetImportJobsRequest {
    ApplicationId: string;
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export type ListOfImportJobResponse = ImportJobResponse[];
export interface ImportJobsResponse {
    Item?: ImportJobResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface GetImportJobsResponse {
    ImportJobsResponse: ImportJobsResponse & {
        Item: (ImportJobResponse & {
            ApplicationId: string;
            CreationDate: string;
            Definition: ImportJobResource & {
                Format: Format;
                RoleArn: string;
                S3Url: string;
            };
            Id: string;
            JobStatus: JobStatus;
            Type: string;
        })[];
    };
}
export interface GetInAppMessagesRequest {
    ApplicationId: string;
    EndpointId: string;
}
export interface InAppMessage {
    Content?: InAppMessageContent[] | undefined;
    CustomConfig?: {
        [key: string]: string | undefined;
    } | undefined;
    Layout?: Layout | undefined;
}
export interface InAppCampaignSchedule {
    EndDate?: string | undefined;
    EventFilter?: CampaignEventFilter | undefined;
    QuietTime?: QuietTime | undefined;
}
export interface InAppMessageCampaign {
    CampaignId?: string | undefined;
    DailyCap?: number | undefined;
    InAppMessage?: InAppMessage | undefined;
    Priority?: number | undefined;
    Schedule?: InAppCampaignSchedule | undefined;
    SessionCap?: number | undefined;
    TotalCap?: number | undefined;
    TreatmentId?: string | undefined;
}
export type ListOfInAppMessageCampaign = InAppMessageCampaign[];
export interface InAppMessagesResponse {
    InAppMessageCampaigns?: InAppMessageCampaign[] | undefined;
}
export interface GetInAppMessagesResponse {
    InAppMessagesResponse: InAppMessagesResponse & {
        InAppMessageCampaigns: (InAppMessageCampaign & {
            InAppMessage: InAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
            Schedule: InAppCampaignSchedule & {
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
    };
}
export interface GetInAppTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface InAppTemplateResponse {
    Arn?: string | undefined;
    Content?: InAppMessageContent[] | undefined;
    CreationDate?: string | undefined;
    CustomConfig?: {
        [key: string]: string | undefined;
    } | undefined;
    LastModifiedDate?: string | undefined;
    Layout?: Layout | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
    TemplateName?: string | undefined;
    TemplateType?: TemplateType | undefined;
    Version?: string | undefined;
}
export interface GetInAppTemplateResponse {
    InAppTemplateResponse: InAppTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
        Content: (InAppMessageContent & {
            BodyConfig: InAppMessageBodyConfig & {
                Alignment: Alignment;
                Body: string;
                TextColor: string;
            };
            HeaderConfig: InAppMessageHeaderConfig & {
                Alignment: Alignment;
                Header: string;
                TextColor: string;
            };
            PrimaryBtn: InAppMessageButton & {
                Android: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
                DefaultConfig: DefaultButtonConfiguration & {
                    ButtonAction: ButtonAction;
                    Text: string;
                };
                IOS: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
                Web: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
            };
            SecondaryBtn: InAppMessageButton & {
                Android: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
                DefaultConfig: DefaultButtonConfiguration & {
                    ButtonAction: ButtonAction;
                    Text: string;
                };
                IOS: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
                Web: OverrideButtonConfiguration & {
                    ButtonAction: ButtonAction;
                };
            };
        })[];
    };
}
export interface GetJourneyRequest {
    ApplicationId: string;
    JourneyId: string;
}
export interface GetJourneyResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface GetJourneyDateRangeKpiRequest {
    ApplicationId: string;
    EndTime?: Date | undefined;
    JourneyId: string;
    KpiName: string;
    NextToken?: string | undefined;
    PageSize?: string | undefined;
    StartTime?: Date | undefined;
}
export interface JourneyDateRangeKpiResponse {
    ApplicationId?: string | undefined;
    EndTime?: Date | undefined;
    JourneyId?: string | undefined;
    KpiName?: string | undefined;
    KpiResult?: BaseKpiResult | undefined;
    NextToken?: string | undefined;
    StartTime?: Date | undefined;
}
export interface GetJourneyDateRangeKpiResponse {
    JourneyDateRangeKpiResponse: JourneyDateRangeKpiResponse & {
        ApplicationId: string;
        EndTime: __timestampIso8601;
        JourneyId: string;
        KpiName: string;
        KpiResult: BaseKpiResult & {
            Rows: (ResultRow & {
                GroupedBys: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
                Values: (ResultRowValue & {
                    Key: string;
                    Type: string;
                    Value: string;
                })[];
            })[];
        };
        StartTime: __timestampIso8601;
    };
}
export interface GetJourneyExecutionActivityMetricsRequest {
    ApplicationId: string;
    JourneyActivityId: string;
    JourneyId: string;
    NextToken?: string | undefined;
    PageSize?: string | undefined;
}
export interface JourneyExecutionActivityMetricsResponse {
    ActivityType?: string | undefined;
    ApplicationId?: string | undefined;
    JourneyActivityId?: string | undefined;
    JourneyId?: string | undefined;
    LastEvaluatedTime?: string | undefined;
    Metrics?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetJourneyExecutionActivityMetricsResponse {
    JourneyExecutionActivityMetricsResponse: JourneyExecutionActivityMetricsResponse & {
        ActivityType: string;
        ApplicationId: string;
        JourneyActivityId: string;
        JourneyId: string;
        LastEvaluatedTime: string;
        Metrics: MapOf__string;
    };
}
export interface GetJourneyExecutionMetricsRequest {
    ApplicationId: string;
    JourneyId: string;
    NextToken?: string | undefined;
    PageSize?: string | undefined;
}
export interface JourneyExecutionMetricsResponse {
    ApplicationId?: string | undefined;
    JourneyId?: string | undefined;
    LastEvaluatedTime?: string | undefined;
    Metrics?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetJourneyExecutionMetricsResponse {
    JourneyExecutionMetricsResponse: JourneyExecutionMetricsResponse & {
        ApplicationId: string;
        JourneyId: string;
        LastEvaluatedTime: string;
        Metrics: MapOf__string;
    };
}
export interface GetJourneyRunExecutionActivityMetricsRequest {
    ApplicationId: string;
    JourneyActivityId: string;
    JourneyId: string;
    NextToken?: string | undefined;
    PageSize?: string | undefined;
    RunId: string;
}
export interface JourneyRunExecutionActivityMetricsResponse {
    ActivityType?: string | undefined;
    ApplicationId?: string | undefined;
    JourneyActivityId?: string | undefined;
    JourneyId?: string | undefined;
    LastEvaluatedTime?: string | undefined;
    Metrics?: {
        [key: string]: string | undefined;
    } | undefined;
    RunId?: string | undefined;
}
export interface GetJourneyRunExecutionActivityMetricsResponse {
    JourneyRunExecutionActivityMetricsResponse: JourneyRunExecutionActivityMetricsResponse & {
        ActivityType: string;
        ApplicationId: string;
        JourneyActivityId: string;
        JourneyId: string;
        LastEvaluatedTime: string;
        Metrics: MapOf__string;
        RunId: string;
    };
}
export interface GetJourneyRunExecutionMetricsRequest {
    ApplicationId: string;
    JourneyId: string;
    NextToken?: string | undefined;
    PageSize?: string | undefined;
    RunId: string;
}
export interface JourneyRunExecutionMetricsResponse {
    ApplicationId?: string | undefined;
    JourneyId?: string | undefined;
    LastEvaluatedTime?: string | undefined;
    Metrics?: {
        [key: string]: string | undefined;
    } | undefined;
    RunId?: string | undefined;
}
export interface GetJourneyRunExecutionMetricsResponse {
    JourneyRunExecutionMetricsResponse: JourneyRunExecutionMetricsResponse & {
        ApplicationId: string;
        JourneyId: string;
        LastEvaluatedTime: string;
        Metrics: MapOf__string;
        RunId: string;
    };
}
export interface GetJourneyRunsRequest {
    ApplicationId: string;
    JourneyId: string;
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export type JourneyRunStatus = "SCHEDULED" | "RUNNING" | "COMPLETED" | "CANCELLED" | (string & {});
export interface JourneyRunResponse {
    CreationTime?: string | undefined;
    LastUpdateTime?: string | undefined;
    RunId?: string | undefined;
    Status?: JourneyRunStatus | undefined;
}
export type ListOfJourneyRunResponse = JourneyRunResponse[];
export interface JourneyRunsResponse {
    Item?: JourneyRunResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface GetJourneyRunsResponse {
    JourneyRunsResponse: JourneyRunsResponse & {
        Item: (JourneyRunResponse & {
            CreationTime: string;
            LastUpdateTime: string;
            RunId: string;
            Status: JourneyRunStatus;
        })[];
    };
}
export interface GetPushTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface PushNotificationTemplateResponse {
    ADM?: AndroidPushNotificationTemplate | undefined;
    APNS?: APNSPushNotificationTemplate | undefined;
    Arn?: string | undefined;
    Baidu?: AndroidPushNotificationTemplate | undefined;
    CreationDate?: string | undefined;
    Default?: DefaultPushNotificationTemplate | undefined;
    DefaultSubstitutions?: string | undefined;
    GCM?: AndroidPushNotificationTemplate | undefined;
    LastModifiedDate?: string | undefined;
    RecommenderId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
    TemplateName?: string | undefined;
    TemplateType?: TemplateType | undefined;
    Version?: string | undefined;
}
export interface GetPushTemplateResponse {
    PushNotificationTemplateResponse: PushNotificationTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
    };
}
export interface GetRecommenderConfigurationRequest {
    RecommenderId: string;
}
export interface GetRecommenderConfigurationResponse {
    RecommenderConfigurationResponse: RecommenderConfigurationResponse & {
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        RecommendationProviderRoleArn: string;
        RecommendationProviderUri: string;
    };
}
export interface GetRecommenderConfigurationsRequest {
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export type ListOfRecommenderConfigurationResponse = RecommenderConfigurationResponse[];
export interface ListRecommenderConfigurationsResponse {
    Item?: RecommenderConfigurationResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface GetRecommenderConfigurationsResponse {
    ListRecommenderConfigurationsResponse: ListRecommenderConfigurationsResponse & {
        Item: (RecommenderConfigurationResponse & {
            CreationDate: string;
            Id: string;
            LastModifiedDate: string;
            RecommendationProviderRoleArn: string;
            RecommendationProviderUri: string;
        })[];
    };
}
export interface GetSegmentRequest {
    ApplicationId: string;
    SegmentId: string;
}
export interface GetSegmentResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface GetSegmentExportJobsRequest {
    ApplicationId: string;
    PageSize?: string | undefined;
    SegmentId: string;
    Token?: string | undefined;
}
export interface GetSegmentExportJobsResponse {
    ExportJobsResponse: ExportJobsResponse & {
        Item: (ExportJobResponse & {
            ApplicationId: string;
            CreationDate: string;
            Definition: ExportJobResource & {
                RoleArn: string;
                S3UrlPrefix: string;
            };
            Id: string;
            JobStatus: JobStatus;
            Type: string;
        })[];
    };
}
export interface GetSegmentImportJobsRequest {
    ApplicationId: string;
    PageSize?: string | undefined;
    SegmentId: string;
    Token?: string | undefined;
}
export interface GetSegmentImportJobsResponse {
    ImportJobsResponse: ImportJobsResponse & {
        Item: (ImportJobResponse & {
            ApplicationId: string;
            CreationDate: string;
            Definition: ImportJobResource & {
                Format: Format;
                RoleArn: string;
                S3Url: string;
            };
            Id: string;
            JobStatus: JobStatus;
            Type: string;
        })[];
    };
}
export interface GetSegmentsRequest {
    ApplicationId: string;
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export type ListOfSegmentResponse = SegmentResponse[];
export interface SegmentsResponse {
    Item?: SegmentResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface GetSegmentsResponse {
    SegmentsResponse: SegmentsResponse & {
        Item: (SegmentResponse & {
            ApplicationId: string;
            Arn: string;
            CreationDate: string;
            Id: string;
            SegmentType: SegmentType;
            Dimensions: SegmentDimensions & {
                Attributes: {
                    [key: string]: (AttributeDimension & {
                        Values: ListOf__string;
                    }) | undefined;
                };
                Behavior: SegmentBehaviors & {
                    Recency: RecencyDimension & {
                        Duration: Duration;
                        RecencyType: RecencyType;
                    };
                };
                Demographic: SegmentDemographics & {
                    AppVersion: SetDimension & {
                        Values: ListOf__string;
                    };
                    Channel: SetDimension & {
                        Values: ListOf__string;
                    };
                    DeviceType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Make: SetDimension & {
                        Values: ListOf__string;
                    };
                    Model: SetDimension & {
                        Values: ListOf__string;
                    };
                    Platform: SetDimension & {
                        Values: ListOf__string;
                    };
                };
                Location: SegmentLocation & {
                    Country: SetDimension & {
                        Values: ListOf__string;
                    };
                    GPSPoint: GPSPointDimension & {
                        Coordinates: GPSCoordinates & {
                            Latitude: number;
                            Longitude: number;
                        };
                    };
                };
                Metrics: {
                    [key: string]: (MetricDimension & {
                        ComparisonOperator: string;
                        Value: number;
                    }) | undefined;
                };
                UserAttributes: {
                    [key: string]: (AttributeDimension & {
                        Values: ListOf__string;
                    }) | undefined;
                };
            };
            ImportDefinition: SegmentImportResource & {
                ExternalId: string;
                Format: Format;
                RoleArn: string;
                S3Url: string;
                Size: number;
            };
            SegmentGroups: SegmentGroupList & {
                Groups: (SegmentGroup & {
                    Dimensions: (SegmentDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        Behavior: SegmentBehaviors & {
                            Recency: RecencyDimension & {
                                Duration: Duration;
                                RecencyType: RecencyType;
                            };
                        };
                        Demographic: SegmentDemographics & {
                            AppVersion: SetDimension & {
                                Values: ListOf__string;
                            };
                            Channel: SetDimension & {
                                Values: ListOf__string;
                            };
                            DeviceType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Make: SetDimension & {
                                Values: ListOf__string;
                            };
                            Model: SetDimension & {
                                Values: ListOf__string;
                            };
                            Platform: SetDimension & {
                                Values: ListOf__string;
                            };
                        };
                        Location: SegmentLocation & {
                            Country: SetDimension & {
                                Values: ListOf__string;
                            };
                            GPSPoint: GPSPointDimension & {
                                Coordinates: GPSCoordinates & {
                                    Latitude: number;
                                    Longitude: number;
                                };
                            };
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                        UserAttributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                    })[];
                    SourceSegments: (SegmentReference & {
                        Id: string;
                    })[];
                })[];
            };
        })[];
    };
}
export interface GetSegmentVersionRequest {
    ApplicationId: string;
    SegmentId: string;
    Version: string;
}
export interface GetSegmentVersionResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface GetSegmentVersionsRequest {
    ApplicationId: string;
    PageSize?: string | undefined;
    SegmentId: string;
    Token?: string | undefined;
}
export interface GetSegmentVersionsResponse {
    SegmentsResponse: SegmentsResponse & {
        Item: (SegmentResponse & {
            ApplicationId: string;
            Arn: string;
            CreationDate: string;
            Id: string;
            SegmentType: SegmentType;
            Dimensions: SegmentDimensions & {
                Attributes: {
                    [key: string]: (AttributeDimension & {
                        Values: ListOf__string;
                    }) | undefined;
                };
                Behavior: SegmentBehaviors & {
                    Recency: RecencyDimension & {
                        Duration: Duration;
                        RecencyType: RecencyType;
                    };
                };
                Demographic: SegmentDemographics & {
                    AppVersion: SetDimension & {
                        Values: ListOf__string;
                    };
                    Channel: SetDimension & {
                        Values: ListOf__string;
                    };
                    DeviceType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Make: SetDimension & {
                        Values: ListOf__string;
                    };
                    Model: SetDimension & {
                        Values: ListOf__string;
                    };
                    Platform: SetDimension & {
                        Values: ListOf__string;
                    };
                };
                Location: SegmentLocation & {
                    Country: SetDimension & {
                        Values: ListOf__string;
                    };
                    GPSPoint: GPSPointDimension & {
                        Coordinates: GPSCoordinates & {
                            Latitude: number;
                            Longitude: number;
                        };
                    };
                };
                Metrics: {
                    [key: string]: (MetricDimension & {
                        ComparisonOperator: string;
                        Value: number;
                    }) | undefined;
                };
                UserAttributes: {
                    [key: string]: (AttributeDimension & {
                        Values: ListOf__string;
                    }) | undefined;
                };
            };
            ImportDefinition: SegmentImportResource & {
                ExternalId: string;
                Format: Format;
                RoleArn: string;
                S3Url: string;
                Size: number;
            };
            SegmentGroups: SegmentGroupList & {
                Groups: (SegmentGroup & {
                    Dimensions: (SegmentDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        Behavior: SegmentBehaviors & {
                            Recency: RecencyDimension & {
                                Duration: Duration;
                                RecencyType: RecencyType;
                            };
                        };
                        Demographic: SegmentDemographics & {
                            AppVersion: SetDimension & {
                                Values: ListOf__string;
                            };
                            Channel: SetDimension & {
                                Values: ListOf__string;
                            };
                            DeviceType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Make: SetDimension & {
                                Values: ListOf__string;
                            };
                            Model: SetDimension & {
                                Values: ListOf__string;
                            };
                            Platform: SetDimension & {
                                Values: ListOf__string;
                            };
                        };
                        Location: SegmentLocation & {
                            Country: SetDimension & {
                                Values: ListOf__string;
                            };
                            GPSPoint: GPSPointDimension & {
                                Coordinates: GPSCoordinates & {
                                    Latitude: number;
                                    Longitude: number;
                                };
                            };
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                        UserAttributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                    })[];
                    SourceSegments: (SegmentReference & {
                        Id: string;
                    })[];
                })[];
            };
        })[];
    };
}
export interface GetSmsChannelRequest {
    ApplicationId: string;
}
export interface GetSmsChannelResponse {
    SMSChannelResponse: SMSChannelResponse & {
        Platform: string;
    };
}
export interface GetSmsTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface SMSTemplateResponse {
    Arn?: string | undefined;
    Body?: string | undefined;
    CreationDate?: string | undefined;
    DefaultSubstitutions?: string | undefined;
    LastModifiedDate?: string | undefined;
    RecommenderId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
    TemplateName?: string | undefined;
    TemplateType?: TemplateType | undefined;
    Version?: string | undefined;
}
export interface GetSmsTemplateResponse {
    SMSTemplateResponse: SMSTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
    };
}
export interface GetUserEndpointsRequest {
    ApplicationId: string;
    UserId: string;
}
export interface GetUserEndpointsResponse {
    EndpointsResponse: EndpointsResponse & {
        Item: ListOfEndpointResponse;
    };
}
export interface GetVoiceChannelRequest {
    ApplicationId: string;
}
export interface GetVoiceChannelResponse {
    VoiceChannelResponse: VoiceChannelResponse & {
        Platform: string;
    };
}
export interface GetVoiceTemplateRequest {
    TemplateName: string;
    Version?: string | undefined;
}
export interface VoiceTemplateResponse {
    Arn?: string | undefined;
    Body?: string | undefined;
    CreationDate?: string | undefined;
    DefaultSubstitutions?: string | undefined;
    LanguageCode?: string | undefined;
    LastModifiedDate?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
    TemplateName?: string | undefined;
    TemplateType?: TemplateType | undefined;
    Version?: string | undefined;
    VoiceId?: string | undefined;
}
export interface GetVoiceTemplateResponse {
    VoiceTemplateResponse: VoiceTemplateResponse & {
        CreationDate: string;
        LastModifiedDate: string;
        TemplateName: string;
        TemplateType: TemplateType;
    };
}
export interface ListJourneysRequest {
    ApplicationId: string;
    PageSize?: string | undefined;
    Token?: string | undefined;
}
export type ListOfJourneyResponse = JourneyResponse[];
export interface JourneysResponse {
    Item?: JourneyResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface ListJourneysResponse {
    JourneysResponse: JourneysResponse & {
        Item: (JourneyResponse & {
            ApplicationId: string;
            Id: string;
            Name: string;
            Activities: {
                [key: string]: (Activity & {
                    ConditionalSplit: ConditionalSplitActivity & {
                        Condition: Condition & {
                            Conditions: (SimpleCondition & {
                                EventCondition: EventCondition & {
                                    Dimensions: EventDimensions & {
                                        Attributes: {
                                            [key: string]: (AttributeDimension & {
                                                Values: ListOf__string;
                                            }) | undefined;
                                        };
                                        EventType: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Metrics: {
                                            [key: string]: (MetricDimension & {
                                                ComparisonOperator: string;
                                                Value: number;
                                            }) | undefined;
                                        };
                                    };
                                };
                                SegmentCondition: SegmentCondition & {
                                    SegmentId: string;
                                };
                                SegmentDimensions: SegmentDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    Behavior: SegmentBehaviors & {
                                        Recency: RecencyDimension & {
                                            Duration: Duration;
                                            RecencyType: RecencyType;
                                        };
                                    };
                                    Demographic: SegmentDemographics & {
                                        AppVersion: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Channel: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        DeviceType: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Make: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Model: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Platform: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                    };
                                    Location: SegmentLocation & {
                                        Country: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        GPSPoint: GPSPointDimension & {
                                            Coordinates: GPSCoordinates & {
                                                Latitude: number;
                                                Longitude: number;
                                            };
                                        };
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                    UserAttributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                };
                            })[];
                        };
                    };
                    Holdout: HoldoutActivity & {
                        Percentage: number;
                    };
                    MultiCondition: MultiConditionalSplitActivity & {
                        Branches: (MultiConditionalBranch & {
                            Condition: SimpleCondition & {
                                EventCondition: EventCondition & {
                                    Dimensions: EventDimensions & {
                                        Attributes: {
                                            [key: string]: (AttributeDimension & {
                                                Values: ListOf__string;
                                            }) | undefined;
                                        };
                                        EventType: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Metrics: {
                                            [key: string]: (MetricDimension & {
                                                ComparisonOperator: string;
                                                Value: number;
                                            }) | undefined;
                                        };
                                    };
                                };
                                SegmentCondition: SegmentCondition & {
                                    SegmentId: string;
                                };
                                SegmentDimensions: SegmentDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    Behavior: SegmentBehaviors & {
                                        Recency: RecencyDimension & {
                                            Duration: Duration;
                                            RecencyType: RecencyType;
                                        };
                                    };
                                    Demographic: SegmentDemographics & {
                                        AppVersion: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Channel: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        DeviceType: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Make: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Model: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        Platform: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                    };
                                    Location: SegmentLocation & {
                                        Country: SetDimension & {
                                            Values: ListOf__string;
                                        };
                                        GPSPoint: GPSPointDimension & {
                                            Coordinates: GPSCoordinates & {
                                                Latitude: number;
                                                Longitude: number;
                                            };
                                        };
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                    UserAttributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                };
                            };
                        })[];
                    };
                }) | undefined;
            };
            StartCondition: StartCondition & {
                EventStartCondition: EventStartCondition & {
                    EventFilter: EventFilter & {
                        Dimensions: EventDimensions & {
                            Attributes: {
                                [key: string]: (AttributeDimension & {
                                    Values: ListOf__string;
                                }) | undefined;
                            };
                            EventType: SetDimension & {
                                Values: ListOf__string;
                            };
                            Metrics: {
                                [key: string]: (MetricDimension & {
                                    ComparisonOperator: string;
                                    Value: number;
                                }) | undefined;
                            };
                        };
                        FilterType: FilterType;
                    };
                };
                SegmentStartCondition: SegmentCondition & {
                    SegmentId: string;
                };
            };
        })[];
    };
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface TagsModel {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTagsForResourceResponse {
    TagsModel: TagsModel & {
        tags: MapOf__string;
    };
}
export interface ListTemplatesRequest {
    NextToken?: string | undefined;
    PageSize?: string | undefined;
    Prefix?: string | undefined;
    TemplateType?: string | undefined;
}
export interface TemplateResponse {
    Arn?: string | undefined;
    CreationDate?: string | undefined;
    DefaultSubstitutions?: string | undefined;
    LastModifiedDate?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateDescription?: string | undefined;
    TemplateName?: string | undefined;
    TemplateType?: TemplateType | undefined;
    Version?: string | undefined;
}
export type ListOfTemplateResponse = TemplateResponse[];
export interface TemplatesResponse {
    Item?: TemplateResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTemplatesResponse {
    TemplatesResponse: TemplatesResponse & {
        Item: (TemplateResponse & {
            CreationDate: string;
            LastModifiedDate: string;
            TemplateName: string;
            TemplateType: TemplateType;
        })[];
    };
}
export interface ListTemplateVersionsRequest {
    NextToken?: string | undefined;
    PageSize?: string | undefined;
    TemplateName: string;
    TemplateType: string;
}
export interface TemplateVersionResponse {
    CreationDate?: string | undefined;
    DefaultSubstitutions?: string | undefined;
    LastModifiedDate?: string | undefined;
    TemplateDescription?: string | undefined;
    TemplateName?: string | undefined;
    TemplateType?: string | undefined;
    Version?: string | undefined;
}
export type ListOfTemplateVersionResponse = TemplateVersionResponse[];
export interface TemplateVersionsResponse {
    Item?: TemplateVersionResponse[] | undefined;
    Message?: string | undefined;
    NextToken?: string | undefined;
    RequestID?: string | undefined;
}
export interface ListTemplateVersionsResponse {
    TemplateVersionsResponse: TemplateVersionsResponse & {
        Item: (TemplateVersionResponse & {
            CreationDate: string;
            LastModifiedDate: string;
            TemplateName: string;
            TemplateType: string;
        })[];
    };
}
export interface NumberValidateRequest {
    IsoCountryCode?: string | undefined;
    PhoneNumber?: string | undefined;
}
export interface PhoneNumberValidateRequest {
    NumberValidateRequest?: NumberValidateRequest | undefined;
}
export interface NumberValidateResponse {
    Carrier?: string | undefined;
    City?: string | undefined;
    CleansedPhoneNumberE164?: string | undefined;
    CleansedPhoneNumberNational?: string | undefined;
    Country?: string | undefined;
    CountryCodeIso2?: string | undefined;
    CountryCodeNumeric?: string | undefined;
    County?: string | undefined;
    OriginalCountryCodeIso2?: string | undefined;
    OriginalPhoneNumber?: string | undefined;
    PhoneType?: string | undefined;
    PhoneTypeCode?: number | undefined;
    Timezone?: string | undefined;
    ZipCode?: string | undefined;
}
export interface PhoneNumberValidateResponse {
    NumberValidateResponse: NumberValidateResponse;
}
export interface PublicEndpoint {
    Address?: string | undefined;
    Attributes?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ChannelType?: ChannelType | undefined;
    Demographic?: EndpointDemographic | undefined;
    EffectiveDate?: string | undefined;
    EndpointStatus?: string | undefined;
    Location?: EndpointLocation | undefined;
    Metrics?: {
        [key: string]: number | undefined;
    } | undefined;
    OptOut?: string | undefined;
    RequestId?: string | undefined;
    User?: EndpointUser | undefined;
}
export interface Session {
    Duration?: number | undefined;
    Id?: string | undefined;
    StartTimestamp?: string | undefined;
    StopTimestamp?: string | undefined;
}
export interface Event {
    AppPackageName?: string | undefined;
    AppTitle?: string | undefined;
    AppVersionCode?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientSdkVersion?: string | undefined;
    EventType?: string | undefined;
    Metrics?: {
        [key: string]: number | undefined;
    } | undefined;
    SdkName?: string | undefined;
    Session?: Session | undefined;
    Timestamp?: string | undefined;
}
export type MapOfEvent = {
    [key: string]: Event | undefined;
};
export interface EventsBatch {
    Endpoint?: PublicEndpoint | undefined;
    Events?: {
        [key: string]: Event | undefined;
    } | undefined;
}
export type MapOfEventsBatch = {
    [key: string]: EventsBatch | undefined;
};
export interface EventsRequest {
    BatchItem?: {
        [key: string]: EventsBatch | undefined;
    } | undefined;
}
export interface PutEventsRequest {
    ApplicationId: string;
    EventsRequest?: EventsRequest | undefined;
}
export interface EndpointItemResponse {
    Message?: string | undefined;
    StatusCode?: number | undefined;
}
export interface EventItemResponse {
    Message?: string | undefined;
    StatusCode?: number | undefined;
}
export type MapOfEventItemResponse = {
    [key: string]: EventItemResponse | undefined;
};
export interface ItemResponse {
    EndpointItemResponse?: EndpointItemResponse | undefined;
    EventsItemResponse?: {
        [key: string]: EventItemResponse | undefined;
    } | undefined;
}
export type MapOfItemResponse = {
    [key: string]: ItemResponse | undefined;
};
export interface EventsResponse {
    Results?: {
        [key: string]: ItemResponse | undefined;
    } | undefined;
}
export interface PutEventsResponse {
    EventsResponse: EventsResponse;
}
export interface WriteEventStream {
    DestinationStreamArn?: string | undefined;
    RoleArn?: string | undefined;
}
export interface PutEventStreamRequest {
    ApplicationId: string;
    WriteEventStream?: WriteEventStream | undefined;
}
export interface PutEventStreamResponse {
    EventStream: EventStream & {
        ApplicationId: string;
        DestinationStreamArn: string;
        RoleArn: string;
    };
}
export interface UpdateAttributesRequest {
    Blacklist?: string[] | undefined;
}
export interface RemoveAttributesRequest {
    ApplicationId: string;
    AttributeType: string;
    UpdateAttributesRequest?: UpdateAttributesRequest | undefined;
}
export interface AttributesResource {
    ApplicationId?: string | undefined;
    AttributeType?: string | undefined;
    Attributes?: string[] | undefined;
}
export interface RemoveAttributesResponse {
    AttributesResource: AttributesResource & {
        ApplicationId: string;
        AttributeType: string;
    };
}
export interface AddressConfiguration {
    BodyOverride?: string | undefined;
    ChannelType?: ChannelType | undefined;
    Context?: {
        [key: string]: string | undefined;
    } | undefined;
    RawContent?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    TitleOverride?: string | undefined;
}
export type MapOfAddressConfiguration = {
    [key: string]: AddressConfiguration | undefined;
};
export interface EndpointSendConfiguration {
    BodyOverride?: string | undefined;
    Context?: {
        [key: string]: string | undefined;
    } | undefined;
    RawContent?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    TitleOverride?: string | undefined;
}
export type MapOfEndpointSendConfiguration = {
    [key: string]: EndpointSendConfiguration | undefined;
};
export interface ADMMessage {
    Action?: Action | undefined;
    Body?: string | undefined;
    ConsolidationKey?: string | undefined;
    Data?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpiresAfter?: string | undefined;
    IconReference?: string | undefined;
    ImageIconUrl?: string | undefined;
    ImageUrl?: string | undefined;
    MD5?: string | undefined;
    RawContent?: string | undefined;
    SilentPush?: boolean | undefined;
    SmallImageIconUrl?: string | undefined;
    Sound?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export interface APNSMessage {
    APNSPushType?: string | undefined;
    Action?: Action | undefined;
    Badge?: number | undefined;
    Body?: string | undefined;
    Category?: string | undefined;
    CollapseId?: string | undefined;
    Data?: {
        [key: string]: string | undefined;
    } | undefined;
    MediaUrl?: string | undefined;
    PreferredAuthenticationMethod?: string | undefined;
    Priority?: string | undefined;
    RawContent?: string | undefined;
    SilentPush?: boolean | undefined;
    Sound?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ThreadId?: string | undefined;
    TimeToLive?: number | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export interface BaiduMessage {
    Action?: Action | undefined;
    Body?: string | undefined;
    Data?: {
        [key: string]: string | undefined;
    } | undefined;
    IconReference?: string | undefined;
    ImageIconUrl?: string | undefined;
    ImageUrl?: string | undefined;
    RawContent?: string | undefined;
    SilentPush?: boolean | undefined;
    SmallImageIconUrl?: string | undefined;
    Sound?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    TimeToLive?: number | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export interface DefaultMessage {
    Body?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface DefaultPushNotificationMessage {
    Action?: Action | undefined;
    Body?: string | undefined;
    Data?: {
        [key: string]: string | undefined;
    } | undefined;
    SilentPush?: boolean | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export type __blob = Uint8Array;
export interface RawEmail {
    Data?: Uint8Array | undefined;
}
export interface SimpleEmailPart {
    Charset?: string | undefined;
    Data?: string | undefined;
}
export interface SimpleEmail {
    HtmlPart?: SimpleEmailPart | undefined;
    Subject?: SimpleEmailPart | undefined;
    TextPart?: SimpleEmailPart | undefined;
    Headers?: MessageHeader[] | undefined;
}
export interface EmailMessage {
    Body?: string | undefined;
    FeedbackForwardingAddress?: string | undefined;
    FromAddress?: string | undefined;
    RawEmail?: RawEmail | undefined;
    ReplyToAddresses?: string[] | undefined;
    SimpleEmail?: SimpleEmail | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface GCMMessage {
    Action?: Action | undefined;
    Body?: string | undefined;
    CollapseKey?: string | undefined;
    Data?: {
        [key: string]: string | undefined;
    } | undefined;
    IconReference?: string | undefined;
    ImageIconUrl?: string | undefined;
    ImageUrl?: string | undefined;
    PreferredAuthenticationMethod?: string | undefined;
    Priority?: string | undefined;
    RawContent?: string | undefined;
    RestrictedPackageName?: string | undefined;
    SilentPush?: boolean | undefined;
    SmallImageIconUrl?: string | undefined;
    Sound?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    TimeToLive?: number | undefined;
    Title?: string | undefined;
    Url?: string | undefined;
}
export interface SMSMessage {
    Body?: string | undefined;
    Keyword?: string | undefined;
    MediaUrl?: string | undefined;
    MessageType?: MessageType | undefined;
    OriginationNumber?: string | undefined;
    SenderId?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    EntityId?: string | undefined;
    TemplateId?: string | undefined;
}
export interface VoiceMessage {
    Body?: string | undefined;
    LanguageCode?: string | undefined;
    OriginationNumber?: string | undefined;
    Substitutions?: {
        [key: string]: string[] | undefined;
    } | undefined;
    VoiceId?: string | undefined;
}
export interface DirectMessageConfiguration {
    ADMMessage?: ADMMessage | undefined;
    APNSMessage?: APNSMessage | undefined;
    BaiduMessage?: BaiduMessage | undefined;
    DefaultMessage?: DefaultMessage | undefined;
    DefaultPushNotificationMessage?: DefaultPushNotificationMessage | undefined;
    EmailMessage?: EmailMessage | undefined;
    GCMMessage?: GCMMessage | undefined;
    SMSMessage?: SMSMessage | undefined;
    VoiceMessage?: VoiceMessage | undefined;
}
export interface MessageRequest {
    Addresses?: {
        [key: string]: AddressConfiguration | undefined;
    } | undefined;
    Context?: {
        [key: string]: string | undefined;
    } | undefined;
    Endpoints?: {
        [key: string]: EndpointSendConfiguration | undefined;
    } | undefined;
    MessageConfiguration?: DirectMessageConfiguration | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
    TraceId?: string | undefined;
}
export interface SendMessagesRequest {
    ApplicationId: string;
    MessageRequest?: MessageRequest | undefined;
}
export type DeliveryStatus = "SUCCESSFUL" | "THROTTLED" | "TEMPORARY_FAILURE" | "PERMANENT_FAILURE" | "UNKNOWN_FAILURE" | "OPT_OUT" | "DUPLICATE" | (string & {});
export interface EndpointMessageResult {
    Address?: string | undefined;
    DeliveryStatus?: DeliveryStatus | undefined;
    MessageId?: string | undefined;
    StatusCode?: number | undefined;
    StatusMessage?: string | undefined;
    UpdatedToken?: string | undefined;
}
export type MapOfEndpointMessageResult = {
    [key: string]: EndpointMessageResult | undefined;
};
export interface MessageResult {
    DeliveryStatus?: DeliveryStatus | undefined;
    MessageId?: string | undefined;
    StatusCode?: number | undefined;
    StatusMessage?: string | undefined;
    UpdatedToken?: string | undefined;
}
export type MapOfMessageResult = {
    [key: string]: MessageResult | undefined;
};
export interface MessageResponse {
    ApplicationId?: string | undefined;
    EndpointResult?: {
        [key: string]: EndpointMessageResult | undefined;
    } | undefined;
    RequestId?: string | undefined;
    Result?: {
        [key: string]: MessageResult | undefined;
    } | undefined;
}
export interface SendMessagesResponse {
    MessageResponse: MessageResponse & {
        ApplicationId: string;
        EndpointResult: {
            [key: string]: (EndpointMessageResult & {
                DeliveryStatus: DeliveryStatus;
                StatusCode: number;
            }) | undefined;
        };
        Result: {
            [key: string]: (MessageResult & {
                DeliveryStatus: DeliveryStatus;
                StatusCode: number;
            }) | undefined;
        };
    };
}
export interface SendOTPMessageRequestParameters {
    AllowedAttempts?: number | undefined;
    BrandName?: string | undefined;
    Channel?: string | undefined;
    CodeLength?: number | undefined;
    DestinationIdentity?: string | undefined;
    EntityId?: string | undefined;
    Language?: string | undefined;
    OriginationIdentity?: string | undefined;
    ReferenceId?: string | undefined;
    TemplateId?: string | undefined;
    ValidityPeriod?: number | undefined;
}
export interface SendOTPMessageRequest {
    ApplicationId: string;
    SendOTPMessageRequestParameters?: SendOTPMessageRequestParameters | undefined;
}
export interface SendOTPMessageResponse {
    MessageResponse: MessageResponse & {
        ApplicationId: string;
        EndpointResult: {
            [key: string]: (EndpointMessageResult & {
                DeliveryStatus: DeliveryStatus;
                StatusCode: number;
            }) | undefined;
        };
        Result: {
            [key: string]: (MessageResult & {
                DeliveryStatus: DeliveryStatus;
                StatusCode: number;
            }) | undefined;
        };
    };
}
export interface SendUsersMessageRequest {
    Context?: {
        [key: string]: string | undefined;
    } | undefined;
    MessageConfiguration?: DirectMessageConfiguration | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
    TraceId?: string | undefined;
    Users?: {
        [key: string]: EndpointSendConfiguration | undefined;
    } | undefined;
}
export interface SendUsersMessagesRequest {
    ApplicationId: string;
    SendUsersMessageRequest?: SendUsersMessageRequest | undefined;
}
export type MapOfMapOfEndpointMessageResult = {
    [key: string]: {
        [key: string]: EndpointMessageResult | undefined;
    } | undefined;
};
export interface SendUsersMessageResponse {
    ApplicationId?: string | undefined;
    RequestId?: string | undefined;
    Result?: {
        [key: string]: {
            [key: string]: EndpointMessageResult | undefined;
        } | undefined;
    } | undefined;
}
export interface SendUsersMessagesResponse {
    SendUsersMessageResponse: SendUsersMessageResponse & {
        ApplicationId: string;
        Result: {
            [key: string]: {
                [key: string]: (EndpointMessageResult & {
                    DeliveryStatus: DeliveryStatus;
                    StatusCode: number;
                }) | undefined;
            } | undefined;
        };
    };
}
export interface TagResourceRequest {
    ResourceArn: string;
    TagsModel?: TagsModel | undefined;
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface ADMChannelRequest {
    ClientId?: string | undefined;
    ClientSecret?: string | undefined;
    Enabled?: boolean | undefined;
}
export interface UpdateAdmChannelRequest {
    ADMChannelRequest?: ADMChannelRequest | undefined;
    ApplicationId: string;
}
export interface UpdateAdmChannelResponse {
    ADMChannelResponse: ADMChannelResponse & {
        Platform: string;
    };
}
export interface APNSChannelRequest {
    BundleId?: string | undefined;
    Certificate?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    PrivateKey?: string | undefined;
    TeamId?: string | undefined;
    TokenKey?: string | undefined;
    TokenKeyId?: string | undefined;
}
export interface UpdateApnsChannelRequest {
    APNSChannelRequest?: APNSChannelRequest | undefined;
    ApplicationId: string;
}
export interface UpdateApnsChannelResponse {
    APNSChannelResponse: APNSChannelResponse & {
        Platform: string;
    };
}
export interface APNSSandboxChannelRequest {
    BundleId?: string | undefined;
    Certificate?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    PrivateKey?: string | undefined;
    TeamId?: string | undefined;
    TokenKey?: string | undefined;
    TokenKeyId?: string | undefined;
}
export interface UpdateApnsSandboxChannelRequest {
    APNSSandboxChannelRequest?: APNSSandboxChannelRequest | undefined;
    ApplicationId: string;
}
export interface UpdateApnsSandboxChannelResponse {
    APNSSandboxChannelResponse: APNSSandboxChannelResponse & {
        Platform: string;
    };
}
export interface APNSVoipChannelRequest {
    BundleId?: string | undefined;
    Certificate?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    PrivateKey?: string | undefined;
    TeamId?: string | undefined;
    TokenKey?: string | undefined;
    TokenKeyId?: string | undefined;
}
export interface UpdateApnsVoipChannelRequest {
    APNSVoipChannelRequest?: APNSVoipChannelRequest | undefined;
    ApplicationId: string;
}
export interface UpdateApnsVoipChannelResponse {
    APNSVoipChannelResponse: APNSVoipChannelResponse & {
        Platform: string;
    };
}
export interface APNSVoipSandboxChannelRequest {
    BundleId?: string | undefined;
    Certificate?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    PrivateKey?: string | undefined;
    TeamId?: string | undefined;
    TokenKey?: string | undefined;
    TokenKeyId?: string | undefined;
}
export interface UpdateApnsVoipSandboxChannelRequest {
    APNSVoipSandboxChannelRequest?: APNSVoipSandboxChannelRequest | undefined;
    ApplicationId: string;
}
export interface UpdateApnsVoipSandboxChannelResponse {
    APNSVoipSandboxChannelResponse: APNSVoipSandboxChannelResponse & {
        Platform: string;
    };
}
export interface WriteApplicationSettingsRequest {
    CampaignHook?: CampaignHook | undefined;
    CloudWatchMetricsEnabled?: boolean | undefined;
    EventTaggingEnabled?: boolean | undefined;
    Limits?: CampaignLimits | undefined;
    QuietTime?: QuietTime | undefined;
    JourneyLimits?: ApplicationSettingsJourneyLimits | undefined;
}
export interface UpdateApplicationSettingsRequest {
    ApplicationId: string;
    WriteApplicationSettingsRequest?: WriteApplicationSettingsRequest | undefined;
}
export interface UpdateApplicationSettingsResponse {
    ApplicationSettingsResource: ApplicationSettingsResource & {
        ApplicationId: string;
    };
}
export interface BaiduChannelRequest {
    ApiKey?: string | undefined;
    Enabled?: boolean | undefined;
    SecretKey?: string | undefined;
}
export interface UpdateBaiduChannelRequest {
    ApplicationId: string;
    BaiduChannelRequest?: BaiduChannelRequest | undefined;
}
export interface UpdateBaiduChannelResponse {
    BaiduChannelResponse: BaiduChannelResponse & {
        Credential: string;
        Platform: string;
    };
}
export interface UpdateCampaignRequest {
    ApplicationId: string;
    CampaignId: string;
    WriteCampaignRequest?: WriteCampaignRequest | undefined;
}
export interface UpdateCampaignResponse {
    CampaignResponse: CampaignResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        SegmentId: string;
        SegmentVersion: number;
        AdditionalTreatments: (TreatmentResource & {
            Id: string;
            SizePercent: number;
            CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
                DeliveryUri: string;
            };
            MessageConfiguration: MessageConfiguration & {
                InAppMessage: CampaignInAppMessage & {
                    Content: (InAppMessageContent & {
                        BodyConfig: InAppMessageBodyConfig & {
                            Alignment: Alignment;
                            Body: string;
                            TextColor: string;
                        };
                        HeaderConfig: InAppMessageHeaderConfig & {
                            Alignment: Alignment;
                            Header: string;
                            TextColor: string;
                        };
                        PrimaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                        SecondaryBtn: InAppMessageButton & {
                            Android: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            DefaultConfig: DefaultButtonConfiguration & {
                                ButtonAction: ButtonAction;
                                Text: string;
                            };
                            IOS: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                            Web: OverrideButtonConfiguration & {
                                ButtonAction: ButtonAction;
                            };
                        };
                    })[];
                };
            };
            Schedule: Schedule & {
                StartTime: string;
                EventFilter: CampaignEventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
        })[];
        CustomDeliveryConfiguration: CustomDeliveryConfiguration & {
            DeliveryUri: string;
        };
        MessageConfiguration: MessageConfiguration & {
            InAppMessage: CampaignInAppMessage & {
                Content: (InAppMessageContent & {
                    BodyConfig: InAppMessageBodyConfig & {
                        Alignment: Alignment;
                        Body: string;
                        TextColor: string;
                    };
                    HeaderConfig: InAppMessageHeaderConfig & {
                        Alignment: Alignment;
                        Header: string;
                        TextColor: string;
                    };
                    PrimaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                    SecondaryBtn: InAppMessageButton & {
                        Android: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        DefaultConfig: DefaultButtonConfiguration & {
                            ButtonAction: ButtonAction;
                            Text: string;
                        };
                        IOS: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                        Web: OverrideButtonConfiguration & {
                            ButtonAction: ButtonAction;
                        };
                    };
                })[];
            };
        };
        Schedule: Schedule & {
            StartTime: string;
            EventFilter: CampaignEventFilter & {
                Dimensions: EventDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    EventType: SetDimension & {
                        Values: ListOf__string;
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                };
                FilterType: FilterType;
            };
        };
    };
}
export interface EmailChannelRequest {
    ConfigurationSet?: string | undefined;
    Enabled?: boolean | undefined;
    FromAddress?: string | undefined;
    Identity?: string | undefined;
    RoleArn?: string | undefined;
    OrchestrationSendingRoleArn?: string | undefined;
}
export interface UpdateEmailChannelRequest {
    ApplicationId: string;
    EmailChannelRequest?: EmailChannelRequest | undefined;
}
export interface UpdateEmailChannelResponse {
    EmailChannelResponse: EmailChannelResponse & {
        Platform: string;
    };
}
export interface UpdateEmailTemplateRequest {
    CreateNewVersion?: boolean | undefined;
    EmailTemplateRequest?: EmailTemplateRequest | undefined;
    TemplateName: string;
    Version?: string | undefined;
}
export interface UpdateEmailTemplateResponse {
    MessageBody: MessageBody;
}
export interface EndpointRequest {
    Address?: string | undefined;
    Attributes?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ChannelType?: ChannelType | undefined;
    Demographic?: EndpointDemographic | undefined;
    EffectiveDate?: string | undefined;
    EndpointStatus?: string | undefined;
    Location?: EndpointLocation | undefined;
    Metrics?: {
        [key: string]: number | undefined;
    } | undefined;
    OptOut?: string | undefined;
    RequestId?: string | undefined;
    User?: EndpointUser | undefined;
}
export interface UpdateEndpointRequest {
    ApplicationId: string;
    EndpointId: string;
    EndpointRequest?: EndpointRequest | undefined;
}
export interface UpdateEndpointResponse {
    MessageBody: MessageBody;
}
export interface EndpointBatchItem {
    Address?: string | undefined;
    Attributes?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ChannelType?: ChannelType | undefined;
    Demographic?: EndpointDemographic | undefined;
    EffectiveDate?: string | undefined;
    EndpointStatus?: string | undefined;
    Id?: string | undefined;
    Location?: EndpointLocation | undefined;
    Metrics?: {
        [key: string]: number | undefined;
    } | undefined;
    OptOut?: string | undefined;
    RequestId?: string | undefined;
    User?: EndpointUser | undefined;
}
export type ListOfEndpointBatchItem = EndpointBatchItem[];
export interface EndpointBatchRequest {
    Item?: EndpointBatchItem[] | undefined;
}
export interface UpdateEndpointsBatchRequest {
    ApplicationId: string;
    EndpointBatchRequest?: EndpointBatchRequest | undefined;
}
export interface UpdateEndpointsBatchResponse {
    MessageBody: MessageBody;
}
export interface GCMChannelRequest {
    ApiKey?: string | undefined;
    DefaultAuthenticationMethod?: string | undefined;
    Enabled?: boolean | undefined;
    ServiceJson?: string | undefined;
}
export interface UpdateGcmChannelRequest {
    ApplicationId: string;
    GCMChannelRequest?: GCMChannelRequest | undefined;
}
export interface UpdateGcmChannelResponse {
    GCMChannelResponse: GCMChannelResponse & {
        Platform: string;
    };
}
export interface UpdateInAppTemplateRequest {
    CreateNewVersion?: boolean | undefined;
    InAppTemplateRequest?: InAppTemplateRequest | undefined;
    TemplateName: string;
    Version?: string | undefined;
}
export interface UpdateInAppTemplateResponse {
    MessageBody: MessageBody;
}
export interface UpdateJourneyRequest {
    ApplicationId: string;
    JourneyId: string;
    WriteJourneyRequest?: WriteJourneyRequest | undefined;
}
export interface UpdateJourneyResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface JourneyStateRequest {
    State?: State | undefined;
}
export interface UpdateJourneyStateRequest {
    ApplicationId: string;
    JourneyId: string;
    JourneyStateRequest?: JourneyStateRequest | undefined;
}
export interface UpdateJourneyStateResponse {
    JourneyResponse: JourneyResponse & {
        ApplicationId: string;
        Id: string;
        Name: string;
        Activities: {
            [key: string]: (Activity & {
                ConditionalSplit: ConditionalSplitActivity & {
                    Condition: Condition & {
                        Conditions: (SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        })[];
                    };
                };
                Holdout: HoldoutActivity & {
                    Percentage: number;
                };
                MultiCondition: MultiConditionalSplitActivity & {
                    Branches: (MultiConditionalBranch & {
                        Condition: SimpleCondition & {
                            EventCondition: EventCondition & {
                                Dimensions: EventDimensions & {
                                    Attributes: {
                                        [key: string]: (AttributeDimension & {
                                            Values: ListOf__string;
                                        }) | undefined;
                                    };
                                    EventType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Metrics: {
                                        [key: string]: (MetricDimension & {
                                            ComparisonOperator: string;
                                            Value: number;
                                        }) | undefined;
                                    };
                                };
                            };
                            SegmentCondition: SegmentCondition & {
                                SegmentId: string;
                            };
                            SegmentDimensions: SegmentDimensions & {
                                Attributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                                Behavior: SegmentBehaviors & {
                                    Recency: RecencyDimension & {
                                        Duration: Duration;
                                        RecencyType: RecencyType;
                                    };
                                };
                                Demographic: SegmentDemographics & {
                                    AppVersion: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Channel: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    DeviceType: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Make: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Model: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    Platform: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                };
                                Location: SegmentLocation & {
                                    Country: SetDimension & {
                                        Values: ListOf__string;
                                    };
                                    GPSPoint: GPSPointDimension & {
                                        Coordinates: GPSCoordinates & {
                                            Latitude: number;
                                            Longitude: number;
                                        };
                                    };
                                };
                                Metrics: {
                                    [key: string]: (MetricDimension & {
                                        ComparisonOperator: string;
                                        Value: number;
                                    }) | undefined;
                                };
                                UserAttributes: {
                                    [key: string]: (AttributeDimension & {
                                        Values: ListOf__string;
                                    }) | undefined;
                                };
                            };
                        };
                    })[];
                };
            }) | undefined;
        };
        StartCondition: StartCondition & {
            EventStartCondition: EventStartCondition & {
                EventFilter: EventFilter & {
                    Dimensions: EventDimensions & {
                        Attributes: {
                            [key: string]: (AttributeDimension & {
                                Values: ListOf__string;
                            }) | undefined;
                        };
                        EventType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Metrics: {
                            [key: string]: (MetricDimension & {
                                ComparisonOperator: string;
                                Value: number;
                            }) | undefined;
                        };
                    };
                    FilterType: FilterType;
                };
            };
            SegmentStartCondition: SegmentCondition & {
                SegmentId: string;
            };
        };
    };
}
export interface UpdatePushTemplateRequest {
    CreateNewVersion?: boolean | undefined;
    PushNotificationTemplateRequest?: PushNotificationTemplateRequest | undefined;
    TemplateName: string;
    Version?: string | undefined;
}
export interface UpdatePushTemplateResponse {
    MessageBody: MessageBody;
}
export interface UpdateRecommenderConfigurationShape {
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    Description?: string | undefined;
    Name?: string | undefined;
    RecommendationProviderIdType?: string | undefined;
    RecommendationProviderRoleArn?: string | undefined;
    RecommendationProviderUri?: string | undefined;
    RecommendationTransformerUri?: string | undefined;
    RecommendationsDisplayName?: string | undefined;
    RecommendationsPerMessage?: number | undefined;
}
export interface UpdateRecommenderConfigurationRequest {
    RecommenderId: string;
    UpdateRecommenderConfiguration?: UpdateRecommenderConfigurationShape | undefined;
}
export interface UpdateRecommenderConfigurationResponse {
    RecommenderConfigurationResponse: RecommenderConfigurationResponse & {
        CreationDate: string;
        Id: string;
        LastModifiedDate: string;
        RecommendationProviderRoleArn: string;
        RecommendationProviderUri: string;
    };
}
export interface UpdateSegmentRequest {
    ApplicationId: string;
    SegmentId: string;
    WriteSegmentRequest?: WriteSegmentRequest | undefined;
}
export interface UpdateSegmentResponse {
    SegmentResponse: SegmentResponse & {
        ApplicationId: string;
        Arn: string;
        CreationDate: string;
        Id: string;
        SegmentType: SegmentType;
        Dimensions: SegmentDimensions & {
            Attributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
            Behavior: SegmentBehaviors & {
                Recency: RecencyDimension & {
                    Duration: Duration;
                    RecencyType: RecencyType;
                };
            };
            Demographic: SegmentDemographics & {
                AppVersion: SetDimension & {
                    Values: ListOf__string;
                };
                Channel: SetDimension & {
                    Values: ListOf__string;
                };
                DeviceType: SetDimension & {
                    Values: ListOf__string;
                };
                Make: SetDimension & {
                    Values: ListOf__string;
                };
                Model: SetDimension & {
                    Values: ListOf__string;
                };
                Platform: SetDimension & {
                    Values: ListOf__string;
                };
            };
            Location: SegmentLocation & {
                Country: SetDimension & {
                    Values: ListOf__string;
                };
                GPSPoint: GPSPointDimension & {
                    Coordinates: GPSCoordinates & {
                        Latitude: number;
                        Longitude: number;
                    };
                };
            };
            Metrics: {
                [key: string]: (MetricDimension & {
                    ComparisonOperator: string;
                    Value: number;
                }) | undefined;
            };
            UserAttributes: {
                [key: string]: (AttributeDimension & {
                    Values: ListOf__string;
                }) | undefined;
            };
        };
        ImportDefinition: SegmentImportResource & {
            ExternalId: string;
            Format: Format;
            RoleArn: string;
            S3Url: string;
            Size: number;
        };
        SegmentGroups: SegmentGroupList & {
            Groups: (SegmentGroup & {
                Dimensions: (SegmentDimensions & {
                    Attributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                    Behavior: SegmentBehaviors & {
                        Recency: RecencyDimension & {
                            Duration: Duration;
                            RecencyType: RecencyType;
                        };
                    };
                    Demographic: SegmentDemographics & {
                        AppVersion: SetDimension & {
                            Values: ListOf__string;
                        };
                        Channel: SetDimension & {
                            Values: ListOf__string;
                        };
                        DeviceType: SetDimension & {
                            Values: ListOf__string;
                        };
                        Make: SetDimension & {
                            Values: ListOf__string;
                        };
                        Model: SetDimension & {
                            Values: ListOf__string;
                        };
                        Platform: SetDimension & {
                            Values: ListOf__string;
                        };
                    };
                    Location: SegmentLocation & {
                        Country: SetDimension & {
                            Values: ListOf__string;
                        };
                        GPSPoint: GPSPointDimension & {
                            Coordinates: GPSCoordinates & {
                                Latitude: number;
                                Longitude: number;
                            };
                        };
                    };
                    Metrics: {
                        [key: string]: (MetricDimension & {
                            ComparisonOperator: string;
                            Value: number;
                        }) | undefined;
                    };
                    UserAttributes: {
                        [key: string]: (AttributeDimension & {
                            Values: ListOf__string;
                        }) | undefined;
                    };
                })[];
                SourceSegments: (SegmentReference & {
                    Id: string;
                })[];
            })[];
        };
    };
}
export interface SMSChannelRequest {
    Enabled?: boolean | undefined;
    SenderId?: string | undefined;
    ShortCode?: string | undefined;
}
export interface UpdateSmsChannelRequest {
    ApplicationId: string;
    SMSChannelRequest?: SMSChannelRequest | undefined;
}
export interface UpdateSmsChannelResponse {
    SMSChannelResponse: SMSChannelResponse & {
        Platform: string;
    };
}
export interface UpdateSmsTemplateRequest {
    CreateNewVersion?: boolean | undefined;
    SMSTemplateRequest?: SMSTemplateRequest | undefined;
    TemplateName: string;
    Version?: string | undefined;
}
export interface UpdateSmsTemplateResponse {
    MessageBody: MessageBody;
}
export interface TemplateActiveVersionRequest {
    Version?: string | undefined;
}
export interface UpdateTemplateActiveVersionRequest {
    TemplateActiveVersionRequest?: TemplateActiveVersionRequest | undefined;
    TemplateName: string;
    TemplateType: string;
}
export interface UpdateTemplateActiveVersionResponse {
    MessageBody: MessageBody;
}
export interface VoiceChannelRequest {
    Enabled?: boolean | undefined;
}
export interface UpdateVoiceChannelRequest {
    ApplicationId: string;
    VoiceChannelRequest?: VoiceChannelRequest | undefined;
}
export interface UpdateVoiceChannelResponse {
    VoiceChannelResponse: VoiceChannelResponse & {
        Platform: string;
    };
}
export interface UpdateVoiceTemplateRequest {
    CreateNewVersion?: boolean | undefined;
    TemplateName: string;
    Version?: string | undefined;
    VoiceTemplateRequest?: VoiceTemplateRequest | undefined;
}
export interface UpdateVoiceTemplateResponse {
    MessageBody: MessageBody;
}
export interface VerifyOTPMessageRequestParameters {
    DestinationIdentity?: string | undefined;
    Otp?: string | undefined;
    ReferenceId?: string | undefined;
}
export interface VerifyOTPMessageRequest {
    ApplicationId: string;
    VerifyOTPMessageRequestParameters?: VerifyOTPMessageRequestParameters | undefined;
}
export interface VerificationResponse {
    Valid?: boolean | undefined;
}
export interface VerifyOTPMessageResponse {
    VerificationResponse: VerificationResponse;
}
export type CreateAppError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates an application.
 */
export declare const createApp: API.OperationMethod<CreateAppRequest & RegionInput, CreateAppResponse, CreateAppError, Credentials | HttpClient.HttpClient>;
export type CreateCampaignError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new campaign for an application or updates the settings of an existing campaign for an application.
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest & RegionInput, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type CreateEmailTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a message template for messages that are sent through the email channel.
 */
export declare const createEmailTemplate: API.OperationMethod<CreateEmailTemplateRequest & RegionInput, CreateEmailTemplateResponse, CreateEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateExportJobError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates an export job for an application.
 */
export declare const createExportJob: API.OperationMethod<CreateExportJobRequest & RegionInput, CreateExportJobResponse, CreateExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateImportJobError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates an import job for an application.
 */
export declare const createImportJob: API.OperationMethod<CreateImportJobRequest & RegionInput, CreateImportJobResponse, CreateImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateInAppTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new message template for messages using the in-app message channel.
 */
export declare const createInAppTemplate: API.OperationMethod<CreateInAppTemplateRequest & RegionInput, CreateInAppTemplateResponse, CreateInAppTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateJourneyError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a journey for an application.
 */
export declare const createJourney: API.OperationMethod<CreateJourneyRequest & RegionInput, CreateJourneyResponse, CreateJourneyError, Credentials | HttpClient.HttpClient>;
export type CreatePushTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a message template for messages that are sent through a push notification channel.
 */
export declare const createPushTemplate: API.OperationMethod<CreatePushTemplateRequest & RegionInput, CreatePushTemplateResponse, CreatePushTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateRecommenderConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Amazon Pinpoint configuration for a recommender model.
 */
export declare const createRecommenderConfiguration: API.OperationMethod<CreateRecommenderConfigurationRequest & RegionInput, CreateRecommenderConfigurationResponse, CreateRecommenderConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateSegmentError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new segment for an application or updates the configuration, dimension, and other settings for an existing segment that's associated with an application.
 */
export declare const createSegment: API.OperationMethod<CreateSegmentRequest & RegionInput, CreateSegmentResponse, CreateSegmentError, Credentials | HttpClient.HttpClient>;
export type CreateSmsTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a message template for messages that are sent through the SMS channel.
 */
export declare const createSmsTemplate: API.OperationMethod<CreateSmsTemplateRequest & RegionInput, CreateSmsTemplateResponse, CreateSmsTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Creates a message template for messages that are sent through the voice channel.
 */
export declare const createVoiceTemplate: API.OperationMethod<CreateVoiceTemplateRequest & RegionInput, CreateVoiceTemplateResponse, CreateVoiceTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteAdmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the ADM channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteAdmChannel: API.OperationMethod<DeleteAdmChannelRequest & RegionInput, DeleteAdmChannelResponse, DeleteAdmChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteApnsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the APNs channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteApnsChannel: API.OperationMethod<DeleteApnsChannelRequest & RegionInput, DeleteApnsChannelResponse, DeleteApnsChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteApnsSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the APNs sandbox channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteApnsSandboxChannel: API.OperationMethod<DeleteApnsSandboxChannelRequest & RegionInput, DeleteApnsSandboxChannelResponse, DeleteApnsSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteApnsVoipChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the APNs VoIP channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteApnsVoipChannel: API.OperationMethod<DeleteApnsVoipChannelRequest & RegionInput, DeleteApnsVoipChannelResponse, DeleteApnsVoipChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteApnsVoipSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the APNs VoIP sandbox channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteApnsVoipSandboxChannel: API.OperationMethod<DeleteApnsVoipSandboxChannelRequest & RegionInput, DeleteApnsVoipSandboxChannelResponse, DeleteApnsVoipSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteAppError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest & RegionInput, DeleteAppResponse, DeleteAppError, Credentials | HttpClient.HttpClient>;
export type DeleteBaiduChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the Baidu channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteBaiduChannel: API.OperationMethod<DeleteBaiduChannelRequest & RegionInput, DeleteBaiduChannelResponse, DeleteBaiduChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a campaign from an application.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest & RegionInput, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the email channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteEmailChannel: API.OperationMethod<DeleteEmailChannelRequest & RegionInput, DeleteEmailChannelResponse, DeleteEmailChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages that were sent through the email channel.
 */
export declare const deleteEmailTemplate: API.OperationMethod<DeleteEmailTemplateRequest & RegionInput, DeleteEmailTemplateResponse, DeleteEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an endpoint from an application.
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointRequest & RegionInput, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEventStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the event stream for an application.
 */
export declare const deleteEventStream: API.OperationMethod<DeleteEventStreamRequest & RegionInput, DeleteEventStreamResponse, DeleteEventStreamError, Credentials | HttpClient.HttpClient>;
export type DeleteGcmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the GCM channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteGcmChannel: API.OperationMethod<DeleteGcmChannelRequest & RegionInput, DeleteGcmChannelResponse, DeleteGcmChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteInAppTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages sent using the in-app message channel.
 */
export declare const deleteInAppTemplate: API.OperationMethod<DeleteInAppTemplateRequest & RegionInput, DeleteInAppTemplateResponse, DeleteInAppTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteJourneyError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a journey from an application.
 */
export declare const deleteJourney: API.OperationMethod<DeleteJourneyRequest & RegionInput, DeleteJourneyResponse, DeleteJourneyError, Credentials | HttpClient.HttpClient>;
export type DeletePushTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages that were sent through a push notification channel.
 */
export declare const deletePushTemplate: API.OperationMethod<DeletePushTemplateRequest & RegionInput, DeletePushTemplateResponse, DeletePushTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteRecommenderConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Amazon Pinpoint configuration for a recommender model.
 */
export declare const deleteRecommenderConfiguration: API.OperationMethod<DeleteRecommenderConfigurationRequest & RegionInput, DeleteRecommenderConfigurationResponse, DeleteRecommenderConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteSegmentError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a segment from an application.
 */
export declare const deleteSegment: API.OperationMethod<DeleteSegmentRequest & RegionInput, DeleteSegmentResponse, DeleteSegmentError, Credentials | HttpClient.HttpClient>;
export type DeleteSmsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the SMS channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteSmsChannel: API.OperationMethod<DeleteSmsChannelRequest & RegionInput, DeleteSmsChannelResponse, DeleteSmsChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteSmsTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages that were sent through the SMS channel.
 */
export declare const deleteSmsTemplate: API.OperationMethod<DeleteSmsTemplateRequest & RegionInput, DeleteSmsTemplateResponse, DeleteSmsTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteUserEndpointsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes all the endpoints that are associated with a specific user ID.
 */
export declare const deleteUserEndpoints: API.OperationMethod<DeleteUserEndpointsRequest & RegionInput, DeleteUserEndpointsResponse, DeleteUserEndpointsError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Disables the voice channel for an application and deletes any existing settings for the channel.
 */
export declare const deleteVoiceChannel: API.OperationMethod<DeleteVoiceChannelRequest & RegionInput, DeleteVoiceChannelResponse, DeleteVoiceChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a message template for messages that were sent through the voice channel.
 */
export declare const deleteVoiceTemplate: API.OperationMethod<DeleteVoiceTemplateRequest & RegionInput, DeleteVoiceTemplateResponse, DeleteVoiceTemplateError, Credentials | HttpClient.HttpClient>;
export type GetAdmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the ADM channel for an application.
 */
export declare const getAdmChannel: API.OperationMethod<GetAdmChannelRequest & RegionInput, GetAdmChannelResponse, GetAdmChannelError, Credentials | HttpClient.HttpClient>;
export type GetApnsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the APNs channel for an application.
 */
export declare const getApnsChannel: API.OperationMethod<GetApnsChannelRequest & RegionInput, GetApnsChannelResponse, GetApnsChannelError, Credentials | HttpClient.HttpClient>;
export type GetApnsSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the APNs sandbox channel for an application.
 */
export declare const getApnsSandboxChannel: API.OperationMethod<GetApnsSandboxChannelRequest & RegionInput, GetApnsSandboxChannelResponse, GetApnsSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type GetApnsVoipChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the APNs VoIP channel for an application.
 */
export declare const getApnsVoipChannel: API.OperationMethod<GetApnsVoipChannelRequest & RegionInput, GetApnsVoipChannelResponse, GetApnsVoipChannelError, Credentials | HttpClient.HttpClient>;
export type GetApnsVoipSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the APNs VoIP sandbox channel for an application.
 */
export declare const getApnsVoipSandboxChannel: API.OperationMethod<GetApnsVoipSandboxChannelRequest & RegionInput, GetApnsVoipSandboxChannelResponse, GetApnsVoipSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type GetAppError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about an application.
 */
export declare const getApp: API.OperationMethod<GetAppRequest & RegionInput, GetAppResponse, GetAppError, Credentials | HttpClient.HttpClient>;
export type GetApplicationDateRangeKpiError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard metric that applies to an application.
 */
export declare const getApplicationDateRangeKpi: API.OperationMethod<GetApplicationDateRangeKpiRequest & RegionInput, GetApplicationDateRangeKpiResponse, GetApplicationDateRangeKpiError, Credentials | HttpClient.HttpClient>;
export type GetApplicationSettingsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the settings for an application.
 */
export declare const getApplicationSettings: API.OperationMethod<GetApplicationSettingsRequest & RegionInput, GetApplicationSettingsResponse, GetApplicationSettingsError, Credentials | HttpClient.HttpClient>;
export type GetAppsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the applications that are associated with your Amazon Pinpoint account.
 */
export declare const getApps: API.OperationMethod<GetAppsRequest & RegionInput, GetAppsResponse, GetAppsError, Credentials | HttpClient.HttpClient>;
export type GetBaiduChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the Baidu channel for an application.
 */
export declare const getBaiduChannel: API.OperationMethod<GetBaiduChannelRequest & RegionInput, GetBaiduChannelResponse, GetBaiduChannelError, Credentials | HttpClient.HttpClient>;
export type GetCampaignError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for a campaign.
 */
export declare const getCampaign: API.OperationMethod<GetCampaignRequest & RegionInput, GetCampaignResponse, GetCampaignError, Credentials | HttpClient.HttpClient>;
export type GetCampaignActivitiesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the activities for a campaign.
 */
export declare const getCampaignActivities: API.OperationMethod<GetCampaignActivitiesRequest & RegionInput, GetCampaignActivitiesResponse, GetCampaignActivitiesError, Credentials | HttpClient.HttpClient>;
export type GetCampaignDateRangeKpiError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard metric that applies to a campaign.
 */
export declare const getCampaignDateRangeKpi: API.OperationMethod<GetCampaignDateRangeKpiRequest & RegionInput, GetCampaignDateRangeKpiResponse, GetCampaignDateRangeKpiError, Credentials | HttpClient.HttpClient>;
export type GetCampaignsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for all the campaigns that are associated with an application.
 */
export declare const getCampaigns: API.OperationMethod<GetCampaignsRequest & RegionInput, GetCampaignsResponse, GetCampaignsError, Credentials | HttpClient.HttpClient>;
export type GetCampaignVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for a specific version of a campaign.
 */
export declare const getCampaignVersion: API.OperationMethod<GetCampaignVersionRequest & RegionInput, GetCampaignVersionResponse, GetCampaignVersionError, Credentials | HttpClient.HttpClient>;
export type GetCampaignVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for all versions of a campaign.
 */
export declare const getCampaignVersions: API.OperationMethod<GetCampaignVersionsRequest & RegionInput, GetCampaignVersionsResponse, GetCampaignVersionsError, Credentials | HttpClient.HttpClient>;
export type GetChannelsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the history and status of each channel for an application.
 */
export declare const getChannels: API.OperationMethod<GetChannelsRequest & RegionInput, GetChannelsResponse, GetChannelsError, Credentials | HttpClient.HttpClient>;
export type GetEmailChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the email channel for an application.
 */
export declare const getEmailChannel: API.OperationMethod<GetEmailChannelRequest & RegionInput, GetEmailChannelResponse, GetEmailChannelError, Credentials | HttpClient.HttpClient>;
export type GetEmailTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages that are sent through the email channel.
 */
export declare const getEmailTemplate: API.OperationMethod<GetEmailTemplateRequest & RegionInput, GetEmailTemplateResponse, GetEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type GetEndpointError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the settings and attributes of a specific endpoint for an application.
 */
export declare const getEndpoint: API.OperationMethod<GetEndpointRequest & RegionInput, GetEndpointResponse, GetEndpointError, Credentials | HttpClient.HttpClient>;
export type GetEventStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the event stream settings for an application.
 */
export declare const getEventStream: API.OperationMethod<GetEventStreamRequest & RegionInput, GetEventStreamResponse, GetEventStreamError, Credentials | HttpClient.HttpClient>;
export type GetExportJobError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of a specific export job for an application.
 */
export declare const getExportJob: API.OperationMethod<GetExportJobRequest & RegionInput, GetExportJobResponse, GetExportJobError, Credentials | HttpClient.HttpClient>;
export type GetExportJobsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of all the export jobs for an application.
 */
export declare const getExportJobs: API.OperationMethod<GetExportJobsRequest & RegionInput, GetExportJobsResponse, GetExportJobsError, Credentials | HttpClient.HttpClient>;
export type GetGcmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the GCM channel for an application.
 */
export declare const getGcmChannel: API.OperationMethod<GetGcmChannelRequest & RegionInput, GetGcmChannelResponse, GetGcmChannelError, Credentials | HttpClient.HttpClient>;
export type GetImportJobError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of a specific import job for an application.
 */
export declare const getImportJob: API.OperationMethod<GetImportJobRequest & RegionInput, GetImportJobResponse, GetImportJobError, Credentials | HttpClient.HttpClient>;
export type GetImportJobsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of all the import jobs for an application.
 */
export declare const getImportJobs: API.OperationMethod<GetImportJobsRequest & RegionInput, GetImportJobsResponse, GetImportJobsError, Credentials | HttpClient.HttpClient>;
export type GetInAppMessagesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the in-app messages targeted for the provided endpoint ID.
 */
export declare const getInAppMessages: API.OperationMethod<GetInAppMessagesRequest & RegionInput, GetInAppMessagesResponse, GetInAppMessagesError, Credentials | HttpClient.HttpClient>;
export type GetInAppTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages sent through the in-app channel.
 */
export declare const getInAppTemplate: API.OperationMethod<GetInAppTemplateRequest & RegionInput, GetInAppTemplateResponse, GetInAppTemplateError, Credentials | HttpClient.HttpClient>;
export type GetJourneyError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for a journey.
 */
export declare const getJourney: API.OperationMethod<GetJourneyRequest & RegionInput, GetJourneyResponse, GetJourneyError, Credentials | HttpClient.HttpClient>;
export type GetJourneyDateRangeKpiError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard engagement metric that applies to a journey.
 */
export declare const getJourneyDateRangeKpi: API.OperationMethod<GetJourneyDateRangeKpiRequest & RegionInput, GetJourneyDateRangeKpiResponse, GetJourneyDateRangeKpiError, Credentials | HttpClient.HttpClient>;
export type GetJourneyExecutionActivityMetricsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard execution metric that applies to a journey activity.
 */
export declare const getJourneyExecutionActivityMetrics: API.OperationMethod<GetJourneyExecutionActivityMetricsRequest & RegionInput, GetJourneyExecutionActivityMetricsResponse, GetJourneyExecutionActivityMetricsError, Credentials | HttpClient.HttpClient>;
export type GetJourneyExecutionMetricsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard execution metric that applies to a journey.
 */
export declare const getJourneyExecutionMetrics: API.OperationMethod<GetJourneyExecutionMetricsRequest & RegionInput, GetJourneyExecutionMetricsResponse, GetJourneyExecutionMetricsError, Credentials | HttpClient.HttpClient>;
export type GetJourneyRunExecutionActivityMetricsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard run execution metric that applies to a journey activity.
 */
export declare const getJourneyRunExecutionActivityMetrics: API.OperationMethod<GetJourneyRunExecutionActivityMetricsRequest & RegionInput, GetJourneyRunExecutionActivityMetricsResponse, GetJourneyRunExecutionActivityMetricsError, Credentials | HttpClient.HttpClient>;
export type GetJourneyRunExecutionMetricsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves (queries) pre-aggregated data for a standard run execution metric that applies to a journey.
 */
export declare const getJourneyRunExecutionMetrics: API.OperationMethod<GetJourneyRunExecutionMetricsRequest & RegionInput, GetJourneyRunExecutionMetricsResponse, GetJourneyRunExecutionMetricsError, Credentials | HttpClient.HttpClient>;
export type GetJourneyRunsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Provides information about the runs of a journey.
 */
export declare const getJourneyRuns: API.OperationMethod<GetJourneyRunsRequest & RegionInput, GetJourneyRunsResponse, GetJourneyRunsError, Credentials | HttpClient.HttpClient>;
export type GetPushTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages that are sent through a push notification channel.
 */
export declare const getPushTemplate: API.OperationMethod<GetPushTemplateRequest & RegionInput, GetPushTemplateResponse, GetPushTemplateError, Credentials | HttpClient.HttpClient>;
export type GetRecommenderConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about an Amazon Pinpoint configuration for a recommender model.
 */
export declare const getRecommenderConfiguration: API.OperationMethod<GetRecommenderConfigurationRequest & RegionInput, GetRecommenderConfigurationResponse, GetRecommenderConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetRecommenderConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the recommender model configurations that are associated with your Amazon Pinpoint account.
 */
export declare const getRecommenderConfigurations: API.OperationMethod<GetRecommenderConfigurationsRequest & RegionInput, GetRecommenderConfigurationsResponse, GetRecommenderConfigurationsError, Credentials | HttpClient.HttpClient>;
export type GetSegmentError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the configuration, dimension, and other settings for a specific segment that's associated with an application.
 */
export declare const getSegment: API.OperationMethod<GetSegmentRequest & RegionInput, GetSegmentResponse, GetSegmentError, Credentials | HttpClient.HttpClient>;
export type GetSegmentExportJobsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the export jobs for a segment.
 */
export declare const getSegmentExportJobs: API.OperationMethod<GetSegmentExportJobsRequest & RegionInput, GetSegmentExportJobsResponse, GetSegmentExportJobsError, Credentials | HttpClient.HttpClient>;
export type GetSegmentImportJobsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the import jobs for a segment.
 */
export declare const getSegmentImportJobs: API.OperationMethod<GetSegmentImportJobsRequest & RegionInput, GetSegmentImportJobsResponse, GetSegmentImportJobsError, Credentials | HttpClient.HttpClient>;
export type GetSegmentsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the configuration, dimension, and other settings for all the segments that are associated with an application.
 */
export declare const getSegments: API.OperationMethod<GetSegmentsRequest & RegionInput, GetSegmentsResponse, GetSegmentsError, Credentials | HttpClient.HttpClient>;
export type GetSegmentVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the configuration, dimension, and other settings for a specific version of a segment that's associated with an application.
 */
export declare const getSegmentVersion: API.OperationMethod<GetSegmentVersionRequest & RegionInput, GetSegmentVersionResponse, GetSegmentVersionError, Credentials | HttpClient.HttpClient>;
export type GetSegmentVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the configuration, dimension, and other settings for all the versions of a specific segment that's associated with an application.
 */
export declare const getSegmentVersions: API.OperationMethod<GetSegmentVersionsRequest & RegionInput, GetSegmentVersionsResponse, GetSegmentVersionsError, Credentials | HttpClient.HttpClient>;
export type GetSmsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the SMS channel for an application.
 */
export declare const getSmsChannel: API.OperationMethod<GetSmsChannelRequest & RegionInput, GetSmsChannelResponse, GetSmsChannelError, Credentials | HttpClient.HttpClient>;
export type GetSmsTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages that are sent through the SMS channel.
 */
export declare const getSmsTemplate: API.OperationMethod<GetSmsTemplateRequest & RegionInput, GetSmsTemplateResponse, GetSmsTemplateError, Credentials | HttpClient.HttpClient>;
export type GetUserEndpointsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the endpoints that are associated with a specific user ID.
 */
export declare const getUserEndpoints: API.OperationMethod<GetUserEndpointsRequest & RegionInput, GetUserEndpointsResponse, GetUserEndpointsError, Credentials | HttpClient.HttpClient>;
export type GetVoiceChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status and settings of the voice channel for an application.
 */
export declare const getVoiceChannel: API.OperationMethod<GetVoiceChannelRequest & RegionInput, GetVoiceChannelResponse, GetVoiceChannelError, Credentials | HttpClient.HttpClient>;
export type GetVoiceTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the content and settings of a message template for messages that are sent through the voice channel.
 */
export declare const getVoiceTemplate: API.OperationMethod<GetVoiceTemplateRequest & RegionInput, GetVoiceTemplateResponse, GetVoiceTemplateError, Credentials | HttpClient.HttpClient>;
export type ListJourneysError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the status, configuration, and other settings for all the journeys that are associated with an application.
 */
export declare const listJourneys: API.OperationMethod<ListJourneysRequest & RegionInput, ListJourneysResponse, ListJourneysError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Retrieves all the tags (keys and values) that are associated with an application, campaign, message template, or segment.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplatesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the message templates that are associated with your Amazon Pinpoint account.
 */
export declare const listTemplates: API.OperationMethod<ListTemplatesRequest & RegionInput, ListTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient>;
export type ListTemplateVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about all the versions of a specific message template.
 */
export declare const listTemplateVersions: API.OperationMethod<ListTemplateVersionsRequest & RegionInput, ListTemplateVersionsResponse, ListTemplateVersionsError, Credentials | HttpClient.HttpClient>;
export type PhoneNumberValidateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a phone number.
 */
export declare const phoneNumberValidate: API.OperationMethod<PhoneNumberValidateRequest & RegionInput, PhoneNumberValidateResponse, PhoneNumberValidateError, Credentials | HttpClient.HttpClient>;
export type PutEventsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new event to record for endpoints, or creates or updates endpoint data that existing events are associated with.
 */
export declare const putEvents: API.OperationMethod<PutEventsRequest & RegionInput, PutEventsResponse, PutEventsError, Credentials | HttpClient.HttpClient>;
export type PutEventStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new event stream for an application or updates the settings of an existing event stream for an application.
 */
export declare const putEventStream: API.OperationMethod<PutEventStreamRequest & RegionInput, PutEventStreamResponse, PutEventStreamError, Credentials | HttpClient.HttpClient>;
export type RemoveAttributesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Removes one or more custom attributes, of the same attribute type, from the application. Existing endpoints still have the attributes but Amazon Pinpoint will stop capturing new or changed values for these attributes.
 */
export declare const removeAttributes: API.OperationMethod<RemoveAttributesRequest & RegionInput, RemoveAttributesResponse, RemoveAttributesError, Credentials | HttpClient.HttpClient>;
export type SendMessagesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates and sends a direct message.
 */
export declare const sendMessages: API.OperationMethod<SendMessagesRequest & RegionInput, SendMessagesResponse, SendMessagesError, Credentials | HttpClient.HttpClient>;
export type SendOTPMessageError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Send an OTP message
 */
export declare const sendOTPMessage: API.OperationMethod<SendOTPMessageRequest & RegionInput, SendOTPMessageResponse, SendOTPMessageError, Credentials | HttpClient.HttpClient>;
export type SendUsersMessagesError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates and sends a message to a list of users.
 */
export declare const sendUsersMessages: API.OperationMethod<SendUsersMessagesRequest & RegionInput, SendUsersMessagesResponse, SendUsersMessagesError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Adds one or more tags (keys and values) to an application, campaign, message template, or segment.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes one or more tags (keys and values) from an application, campaign, message template, or segment.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAdmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the ADM channel for an application or updates the status and settings of the ADM channel for an application.
 */
export declare const updateAdmChannel: API.OperationMethod<UpdateAdmChannelRequest & RegionInput, UpdateAdmChannelResponse, UpdateAdmChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApnsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the APNs channel for an application or updates the status and settings of the APNs channel for an application.
 */
export declare const updateApnsChannel: API.OperationMethod<UpdateApnsChannelRequest & RegionInput, UpdateApnsChannelResponse, UpdateApnsChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApnsSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the APNs sandbox channel for an application or updates the status and settings of the APNs sandbox channel for an application.
 */
export declare const updateApnsSandboxChannel: API.OperationMethod<UpdateApnsSandboxChannelRequest & RegionInput, UpdateApnsSandboxChannelResponse, UpdateApnsSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApnsVoipChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the APNs VoIP channel for an application or updates the status and settings of the APNs VoIP channel for an application.
 */
export declare const updateApnsVoipChannel: API.OperationMethod<UpdateApnsVoipChannelRequest & RegionInput, UpdateApnsVoipChannelResponse, UpdateApnsVoipChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApnsVoipSandboxChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the APNs VoIP sandbox channel for an application or updates the status and settings of the APNs VoIP sandbox channel for an application.
 */
export declare const updateApnsVoipSandboxChannel: API.OperationMethod<UpdateApnsVoipSandboxChannelRequest & RegionInput, UpdateApnsVoipSandboxChannelResponse, UpdateApnsVoipSandboxChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationSettingsError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates the settings for an application.
 */
export declare const updateApplicationSettings: API.OperationMethod<UpdateApplicationSettingsRequest & RegionInput, UpdateApplicationSettingsResponse, UpdateApplicationSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateBaiduChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the Baidu channel for an application or updates the status and settings of the Baidu channel for an application.
 */
export declare const updateBaiduChannel: API.OperationMethod<UpdateBaiduChannelRequest & RegionInput, UpdateBaiduChannelResponse, UpdateBaiduChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration and other settings for a campaign.
 */
export declare const updateCampaign: API.OperationMethod<UpdateCampaignRequest & RegionInput, UpdateCampaignResponse, UpdateCampaignError, Credentials | HttpClient.HttpClient>;
export type UpdateEmailChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the email channel for an application or updates the status and settings of the email channel for an application.
 */
export declare const updateEmailChannel: API.OperationMethod<UpdateEmailChannelRequest & RegionInput, UpdateEmailChannelResponse, UpdateEmailChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateEmailTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages that are sent through the email channel.
 */
export declare const updateEmailTemplate: API.OperationMethod<UpdateEmailTemplateRequest & RegionInput, UpdateEmailTemplateResponse, UpdateEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new endpoint for an application or updates the settings and attributes of an existing endpoint for an application. You can also use this operation to define custom attributes for an endpoint. If an update includes one or more values for a custom attribute, Amazon Pinpoint replaces (overwrites) any existing values with the new values.
 */
export declare const updateEndpoint: API.OperationMethod<UpdateEndpointRequest & RegionInput, UpdateEndpointResponse, UpdateEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointsBatchError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new batch of endpoints for an application or updates the settings and attributes of a batch of existing endpoints for an application. You can also use this operation to define custom attributes for a batch of endpoints. If an update includes one or more values for a custom attribute, Amazon Pinpoint replaces (overwrites) any existing values with the new values.
 */
export declare const updateEndpointsBatch: API.OperationMethod<UpdateEndpointsBatchRequest & RegionInput, UpdateEndpointsBatchResponse, UpdateEndpointsBatchError, Credentials | HttpClient.HttpClient>;
export type UpdateGcmChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the GCM channel for an application or updates the status and settings of the GCM channel for an application.
 */
export declare const updateGcmChannel: API.OperationMethod<UpdateGcmChannelRequest & RegionInput, UpdateGcmChannelResponse, UpdateGcmChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateInAppTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages sent through the in-app message channel.
 */
export declare const updateInAppTemplate: API.OperationMethod<UpdateInAppTemplateRequest & RegionInput, UpdateInAppTemplateResponse, UpdateInAppTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateJourneyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration and other settings for a journey.
 */
export declare const updateJourney: API.OperationMethod<UpdateJourneyRequest & RegionInput, UpdateJourneyResponse, UpdateJourneyError, Credentials | HttpClient.HttpClient>;
export type UpdateJourneyStateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Cancels (stops) an active journey.
 */
export declare const updateJourneyState: API.OperationMethod<UpdateJourneyStateRequest & RegionInput, UpdateJourneyStateResponse, UpdateJourneyStateError, Credentials | HttpClient.HttpClient>;
export type UpdatePushTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages that are sent through a push notification channel.
 */
export declare const updatePushTemplate: API.OperationMethod<UpdatePushTemplateRequest & RegionInput, UpdatePushTemplateResponse, UpdatePushTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateRecommenderConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Amazon Pinpoint configuration for a recommender model.
 */
export declare const updateRecommenderConfiguration: API.OperationMethod<UpdateRecommenderConfigurationRequest & RegionInput, UpdateRecommenderConfigurationResponse, UpdateRecommenderConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSegmentError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new segment for an application or updates the configuration, dimension, and other settings for an existing segment that's associated with an application.
 */
export declare const updateSegment: API.OperationMethod<UpdateSegmentRequest & RegionInput, UpdateSegmentResponse, UpdateSegmentError, Credentials | HttpClient.HttpClient>;
export type UpdateSmsChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the SMS channel for an application or updates the status and settings of the SMS channel for an application.
 */
export declare const updateSmsChannel: API.OperationMethod<UpdateSmsChannelRequest & RegionInput, UpdateSmsChannelResponse, UpdateSmsChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateSmsTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages that are sent through the SMS channel.
 */
export declare const updateSmsTemplate: API.OperationMethod<UpdateSmsTemplateRequest & RegionInput, UpdateSmsTemplateResponse, UpdateSmsTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateActiveVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Changes the status of a specific version of a message template to *active*.
 */
export declare const updateTemplateActiveVersion: API.OperationMethod<UpdateTemplateActiveVersionRequest & RegionInput, UpdateTemplateActiveVersionResponse, UpdateTemplateActiveVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Enables the voice channel for an application or updates the status and settings of the voice channel for an application.
 */
export declare const updateVoiceChannel: API.OperationMethod<UpdateVoiceChannelRequest & RegionInput, UpdateVoiceChannelResponse, UpdateVoiceChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing message template for messages that are sent through the voice channel.
 */
export declare const updateVoiceTemplate: API.OperationMethod<UpdateVoiceTemplateRequest & RegionInput, UpdateVoiceTemplateResponse, UpdateVoiceTemplateError, Credentials | HttpClient.HttpClient>;
export type VerifyOTPMessageError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | PayloadTooLargeException | TooManyRequestsException | CommonErrors;
/**
 * Verify an OTP
 */
export declare const verifyOTPMessage: API.OperationMethod<VerifyOTPMessageRequest & RegionInput, VerifyOTPMessageResponse, VerifyOTPMessageError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pinpoint.d.ts.map