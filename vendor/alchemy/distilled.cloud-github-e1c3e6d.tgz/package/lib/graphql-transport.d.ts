import { GqlTransport } from "@distilled.cloud/core/graphql";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import { Credentials } from "./credentials.ts";
export type GraphQLRequirements = Credentials | HttpClient.HttpClient;
/** The GraphQL endpoint for a REST API root. */
export declare const graphqlUrl: (apiBaseUrl: string) => string;
export declare const GraphQLLive: Layer.Layer<GqlTransport, never, never>;
//# sourceMappingURL=graphql-transport.d.ts.map