import * as queues from "@distilled.cloud/cloudflare/queues";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { Stack } from "alchemy/Stack";
import * as SecureRandom from "effect/crypto/SecureRandom";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import { LocalRuntimeState } from "../LocalRuntime.ts";
import type { Providers } from "../Providers.ts";
declare const ConsumerScriptUnbound_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ConsumerScriptUnbound";
} & Readonly<A>;
/** The consumer exists but is not (yet) attached to the expected Worker script. */
export declare class ConsumerScriptUnbound extends ConsumerScriptUnbound_base<{
    readonly scriptName: string | undefined;
}> {
    get message(): string;
}
export type ConsumerProps = {
    /**
     * The queue ID to attach the consumer to.
     */
    queueId: string;
    /**
     * Name of the Worker script that will consume messages.
     */
    scriptName: string;
    /**
     * Name of the queue that receives messages after `maxRetries` failed
     * deliveries.
     *
     * Cloudflare does not drain or alert on a dead-letter queue. A message
     * left there expires after the queue's retention period, so give the
     * dead-letter queue its own consumer.
     */
    deadLetterQueue?: string;
    /**
     * Consumer settings.
     */
    settings?: ConsumerSettings;
};
export interface ConsumerSettings {
    /**
     * The maximum number of messages per batch.
     * @default 10
     */
    batchSize?: number;
    /**
     * The maximum number of concurrent consumer invocations.
     */
    maxConcurrency?: number;
    /**
     * The maximum number of retries for a message.
     * @default 3
     */
    maxRetries?: number;
    /**
     * The maximum time to wait for a batch to fill, in milliseconds.
     * @default 5000
     */
    maxWaitTimeMs?: number;
    /**
     * The number of seconds to wait before retrying a message.
     */
    retryDelay?: number;
}
export type Consumer = Resource<"Cloudflare.Queues.Consumer", ConsumerProps, {
    consumerId: string;
    queueId: string;
    scriptName: string;
    accountId: string;
    deadLetterQueue?: string;
    settings?: ConsumerSettings;
    /**
     * Dev only, live queues only: the real queue's name, resolved from the
     * cloud so the local runtime can wire the broker + pull loop for a
     * locally-running consumer of an `Alchemy.remote()` queue.
     */
    queueName?: string;
    /**
     * Dev only, live queues only: id of the `http_pull` consumer attached
     * to the real queue so the local runtime can drain it via the HTTP
     * pull API. Deleted when this resource is deleted.
     */
    pullConsumerId?: string;
}, never, Providers>;
/**
 * A Cloudflare Queue Consumer that processes messages from a Queue.
 *
 * Register a Worker as a consumer of a Queue. The Worker's `queue()`
 * handler will be invoked with batches of messages.
 *
 * Cloudflare allows at most one Worker consumer per queue (HTTP-pull
 * consumers can coexist). The reconciler enforces this: if the queue
 * already has a Worker consumer pointing at a different logical Worker's
 * script, the deploy fails with a clear error rather than silently
 * adopting it. A stranded consumer from a prior generation of the *same*
 * Worker (identified by the scripts' ownership tags) is rebuilt in place.
 * ### Registering a Consumer
 * **Example:** Basic consumer
 * ```typescript
 * const queue = yield* Cloudflare.Queues.Queue("MyQueue");
 * const worker = yield* Cloudflare.Worker("Worker", { ... });
 *
 * yield* Cloudflare.Queues.Consumer("MyConsumer", {
 *   queueId: queue.queueId,
 *   scriptName: worker.workerName,
 * });
 * ```
 *
 * **Example:** Consumer with settings
 * ```typescript
 * yield* Cloudflare.Queues.Consumer("MyConsumer", {
 *   queueId: queue.queueId,
 *   scriptName: worker.workerName,
 *   settings: {
 *     batchSize: 50,
 *     maxRetries: 5,
 *     maxWaitTimeMs: 10000,
 *   },
 * });
 * ```
 *
 * ### Dead-Lettering Failed Messages
 * **Example:** Consume the dead-letter queue
 * ```typescript
 * const dlq = yield* Cloudflare.Queues.Queue("MyDeadLetterQueue");
 *
 * yield* Cloudflare.Queues.Consumer("MyConsumer", {
 *   queueId: queue.queueId,
 *   scriptName: worker.workerName,
 *   deadLetterQueue: dlq.queueName,
 *   settings: { maxRetries: 3 },
 * });
 *
 * // Without a consumer, dead-lettered messages expire unseen.
 * yield* Cloudflare.Queues.Consumer("MyDeadLetterConsumer", {
 *   queueId: dlq.queueId,
 *   scriptName: worker.workerName,
 * });
 * ```
 *
 * **Example:** Dead-letter to a queue in another stack
 * ```typescript
 * const dlq = yield* Cloudflare.Queues.Queue.ref("DeadLetters", {
 *   stack: "shared",
 *   stage: "production",
 * });
 *
 * yield* Cloudflare.Queues.Consumer("MyConsumer", {
 *   queueId: queue.queueId,
 *   scriptName: worker.workerName,
 *   deadLetterQueue: dlq.queueName,
 * });
 * ```
 *
 * **Example:** Dead-letter to a queue by name
 * ```typescript
 * yield* Cloudflare.Queues.Consumer("MyConsumer", {
 *   queueId: queue.queueId,
 *   scriptName: worker.workerName,
 *   deadLetterQueue: "orders-dead-letters",
 * });
 * ```
 *
 * @resource
 * @product Queues
 * @category Storage & Databases
 */
export declare const Consumer: import("alchemy").ResourceClass<Consumer>;
/**
 * Find and detach every worker queue-consumer pointing at `scriptName`.
 * Queue consumers have no by-script lookup, so scan the account's queues
 * (the list response inlines each queue's consumers). Waits until each
 * detach propagates to the workers subsystem so a follow-up deleteScript
 * doesn't re-race the conflict.
 *
 * Shared by the Worker provider's script delete (QueueConsumerConflict
 * recovery) and the Queue provider's orphaned-script cleanup.
 *
 * @internal
 */
export declare const detachQueueConsumersOfScript: (accountId: string, scriptName: string) => Effect.Effect<void, queues.InvalidRequestBody | queues.InvalidRoute | queues.CloudflareOpError, queues.CloudflareOpContext>;
export declare const ConsumerProviderLive: () => Layer.Layer<Provider.Provider<Consumer>, never, CloudflareEnvironment | Stack | queues.CloudflareOpContext>;
export declare const ConsumerProviderLocal: () => Layer.Layer<Provider.Provider<Consumer>, never, import("alchemy").AlchemyContext | import("alchemy/Artifacts").ArtifactStore | CloudflareEnvironment | LocalRuntimeState | SecureRandom.SecureRandom | Stack | queues.CloudflareOpContext>;
export declare const ConsumerProvider: () => Layer.Layer<Provider.Provider<Consumer>, import("effect/Config").ConfigError | import("@alchemy.run/cloudflare-runtime/core").ConfigError | import("effect/PlatformError").PlatformError | import("@alchemy.run/cloudflare-runtime/core").SystemError, import("alchemy").AlchemyContext | import("alchemy/Artifacts").ArtifactStore | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | CloudflareEnvironment | import("effect/FileSystem").FileSystem | import("effect/Path").Path | Stack | queues.CloudflareOpContext>;
export {};
//# sourceMappingURL=Consumer.d.ts.map