import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface AddRepositoryForSecretForAuthenticatedUserRequest {
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface AddRepositoryForSecretForAuthenticatedUserResponse {
}
export interface AddSelectedRepoToOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface AddSelectedRepoToOrgSecretResponse {
}
export interface CheckPermissionsForDevcontainerRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The git reference that points to the location of the devcontainer configuration to use for the permission check. The value of `ref` will typically be a branch name (`heads/BRANCH_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
    /** Path to the devcontainer.json configuration to use for the permission check. */
    devcontainer_path: string;
}
/** Permission check result for a given devcontainer config. */
export interface CodespacesPermissionsCheckForDevcontainer {
    /** Whether the user has accepted the permissions defined by the devcontainer config */
    accepted: boolean;
}
export interface CodespaceMachinesForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
}
/** Whether a prebuild is currently available when creating a codespace for this machine and repository. If a branch was not specified as a ref, the default branch will be assumed. Value will be "null" if prebuilds are not supported or prebuild availability could not be determined. Value will be "none" if no prebuild is available. Latest values "ready" and "in_progress" indicate the prebuild availability status. */
export type CodespaceMachinePrebuildAvailability = "none" | "ready" | "in_progress";
/** A description of the machine powering a codespace. */
export interface CodespaceMachine {
    /** The name of the machine. */
    name: string;
    /** The display name of the machine includes cores, memory, and storage. */
    display_name: string;
    /** The operating system of the machine. */
    operating_system: string;
    /** How much storage is available to the codespace. */
    storage_in_bytes: number;
    /** How much memory is available to the codespace. */
    memory_in_bytes: number;
    /** How many cores are available to the codespace. */
    cpus: number;
    /** Whether a prebuild is currently available when creating a codespace for this machine and repository. If a branch was not specified as a ref, the default branch will be assumed. Value will be "null" if prebuilds are not supported or prebuild availability could not be determined. Value will be "none" if no prebuild is available. Latest values "ready" and "in_progress" indicate the prebuild availability status. */
    prebuild_availability: CodespaceMachinePrebuildAvailability | null;
}
export type CodespaceMachinesForAuthenticatedUserResponseMachinesList = Array<CodespaceMachine>;
export interface CodespaceMachinesForAuthenticatedUserResponse {
    total_count: number;
    machines: CodespaceMachinesForAuthenticatedUserResponseMachinesList;
}
/** The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down. */
export type CreateForAuthenticatedUserRequestBodyCase0Geo = "EuropeWest" | "SoutheastAsia" | "UsEast" | "UsWest";
export interface CreateForAuthenticatedUserRequestBodyCase0 {
    /** Repository id for this codespace */
    repository_id: number;
    /** Git ref (typically a branch name) for this codespace */
    ref?: string | undefined;
    /** The requested location for a new codespace. Best efforts are made to respect this upon creation. Assigned by IP if not provided. */
    location?: string | undefined;
    /** The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down. */
    geo?: CreateForAuthenticatedUserRequestBodyCase0Geo | (string & {}) | undefined;
    /** IP for location auto-detection when proxying a request */
    client_ip?: string | undefined;
    /** Machine type to use for this codespace */
    machine?: string | undefined;
    /** Path to devcontainer.json config to use for this codespace */
    devcontainer_path?: string | undefined;
    /** Whether to authorize requested permissions from devcontainer.json */
    multi_repo_permissions_opt_out?: boolean | undefined;
    /** Working directory for this codespace */
    working_directory?: string | undefined;
    /** Time in minutes before codespace stops from inactivity */
    idle_timeout_minutes?: number | undefined;
    /** Display name for this codespace */
    display_name?: string | undefined;
    /** Duration in minutes after codespace has gone idle in which it will be deleted. Must be integer minutes between 0 and 43200 (30 days). */
    retention_period_minutes?: number | undefined;
}
/** Pull request number for this codespace */
export interface CreateForAuthenticatedUserRequestBodyCase1PullRequest {
    /** Pull request number */
    pull_request_number: number;
    /** Repository id for this codespace */
    repository_id: number;
}
/** The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down. */
export type CreateForAuthenticatedUserRequestBodyCase1Geo = "EuropeWest" | "SoutheastAsia" | "UsEast" | "UsWest";
export interface CreateForAuthenticatedUserRequestBodyCase1 {
    /** Pull request number for this codespace */
    pull_request: CreateForAuthenticatedUserRequestBodyCase1PullRequest;
    /** The requested location for a new codespace. Best efforts are made to respect this upon creation. Assigned by IP if not provided. */
    location?: string | undefined;
    /** The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down. */
    geo?: CreateForAuthenticatedUserRequestBodyCase1Geo | (string & {}) | undefined;
    /** Machine type to use for this codespace */
    machine?: string | undefined;
    /** Path to devcontainer.json config to use for this codespace */
    devcontainer_path?: string | undefined;
    /** Working directory for this codespace */
    working_directory?: string | undefined;
    /** Time in minutes before codespace stops from inactivity */
    idle_timeout_minutes?: number | undefined;
}
export type CreateForAuthenticatedUserRequestBody = CreateForAuthenticatedUserRequestBodyCase0 | CreateForAuthenticatedUserRequestBodyCase1;
export interface CreateForAuthenticatedUserRequest {
    body: CreateForAuthenticatedUserRequestBody;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
/** Whether a prebuild is currently available when creating a codespace for this machine and repository. If a branch was not specified as a ref, the default branch will be assumed. Value will be "null" if prebuilds are not supported or prebuild availability could not be determined. Value will be "none" if no prebuild is available. Latest values "ready" and "in_progress" indicate the prebuild availability status. */
export type NullableCodespaceMachinePrebuildAvailability = "none" | "ready" | "in_progress";
/** A description of the machine powering a codespace. */
export interface NullableCodespaceMachine {
    /** The name of the machine. */
    name: string;
    /** The display name of the machine includes cores, memory, and storage. */
    display_name: string;
    /** The operating system of the machine. */
    operating_system: string;
    /** How much storage is available to the codespace. */
    storage_in_bytes: number;
    /** How much memory is available to the codespace. */
    memory_in_bytes: number;
    /** How many cores are available to the codespace. */
    cpus: number;
    /** Whether a prebuild is currently available when creating a codespace for this machine and repository. If a branch was not specified as a ref, the default branch will be assumed. Value will be "null" if prebuilds are not supported or prebuild availability could not be determined. Value will be "none" if no prebuild is available. Latest values "ready" and "in_progress" indicate the prebuild availability status. */
    prebuild_availability: NullableCodespaceMachinePrebuildAvailability | null;
}
/** State of this codespace. */
export type CodespaceState = "Unknown" | "Created" | "Queued" | "Provisioning" | "Available" | "Awaiting" | "Unavailable" | "Deleted" | "Moved" | "Shutdown" | "Archived" | "Starting" | "ShuttingDown" | "Failed" | "Exporting" | "Updating" | "Rebuilding";
/** Details about the codespace's git repository. */
export interface CodespaceGitStatus {
    /** The number of commits the local repository is ahead of the remote. */
    ahead?: number | undefined;
    /** The number of commits the local repository is behind the remote. */
    behind?: number | undefined;
    /** Whether the local repository has unpushed changes. */
    has_unpushed_changes?: boolean | undefined;
    /** Whether the local repository has uncommitted changes. */
    has_uncommitted_changes?: boolean | undefined;
    /** The current branch (or SHA if in detached HEAD state) of the local repository. */
    ref?: string | undefined;
}
/** The initally assigned location of a new codespace. */
export type CodespaceLocation = "EastUs" | "SouthEastAsia" | "WestEurope" | "WestUs2";
export type CodespaceRecentFoldersList = Array<string>;
/** The privacy settings a user can select from when forwarding a port. */
export type CodespaceRuntimeConstraintsAllowedPortPrivacySettingsList = Array<string>;
export interface CodespaceRuntimeConstraints {
    /** The privacy settings a user can select from when forwarding a port. */
    allowed_port_privacy_settings?: CodespaceRuntimeConstraintsAllowedPortPrivacySettingsList | null | undefined;
}
/** A codespace. */
export interface Codespace {
    id: number;
    /** Automatically generated name of this codespace. */
    name: string;
    /** Display name for this codespace. */
    display_name?: string | null | undefined;
    /** UUID identifying this codespace's environment. */
    environment_id: string | null;
    owner: SimpleUser;
    billable_owner: SimpleUser;
    repository: MinimalRepository;
    machine: NullableCodespaceMachine | null;
    /** Path to devcontainer.json from repo root used to create Codespace. */
    devcontainer_path?: string | null | undefined;
    /** Whether the codespace was created from a prebuild. */
    prebuild: boolean | null;
    created_at: string;
    updated_at: string;
    /** Last known time this codespace was started. */
    last_used_at: string;
    /** State of this codespace. */
    state: CodespaceState;
    /** API URL for this codespace. */
    url: string;
    /** Details about the codespace's git repository. */
    git_status: CodespaceGitStatus;
    /** The initally assigned location of a new codespace. */
    location: CodespaceLocation;
    /** The number of minutes of inactivity after which this codespace will be automatically stopped. */
    idle_timeout_minutes: number | null;
    /** URL to access this codespace on the web. */
    web_url: string;
    /** API URL to access available alternate machine types for this codespace. */
    machines_url: string;
    /** API URL to start this codespace. */
    start_url: string;
    /** API URL to stop this codespace. */
    stop_url: string;
    /** API URL to publish this codespace to a new repository. */
    publish_url?: string | null | undefined;
    /** API URL for the Pull Request associated with this codespace, if any. */
    pulls_url: string | null;
    recent_folders: CodespaceRecentFoldersList;
    runtime_constraints?: CodespaceRuntimeConstraints | undefined;
    /** Whether or not a codespace has a pending async operation. This would mean that the codespace is temporarily unavailable. The only thing that you can do with a codespace in this state is delete it. */
    pending_operation?: boolean | null | undefined;
    /** Text to show user when codespace is disabled by a pending operation */
    pending_operation_disabled_reason?: string | null | undefined;
    /** Text to show user when codespace idle timeout minutes has been overriden by an organization policy */
    idle_timeout_notice?: string | null | undefined;
    /** Duration in minutes after codespace has gone idle in which it will be deleted. Must be integer minutes between 0 and 43200 (30 days). */
    retention_period_minutes?: number | null | undefined;
    /** When a codespace will be auto-deleted based on the "retention_period_minutes" and "last_used_at" */
    retention_expires_at?: string | null | undefined;
    /** The text to display to a user when a codespace has been stopped for a potentially actionable reason. */
    last_known_stop_notice?: string | null | undefined;
}
/** Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret. */
export type CreateOrUpdateOrgSecretRequestVisibility = "all" | "private" | "selected";
/** An array of repository IDs that can access the organization secret. You can only provide a list of repository IDs when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
export type CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsList = Array<number>;
export interface CreateOrUpdateOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** The value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an organization public key](https://docs.github.com/rest/codespaces/organization-secrets#get-an-organization-public-key) endpoint. */
    encrypted_value?: string | undefined;
    /** The ID of the key you used to encrypt the secret. */
    key_id?: string | undefined;
    /** Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret. */
    visibility: CreateOrUpdateOrgSecretRequestVisibility | (string & {});
    /** An array of repository IDs that can access the organization secret. You can only provide a list of repository IDs when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
    selected_repository_ids?: CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsList | undefined;
}
export type CreateOrUpdateOrgSecretResponse = unknown;
export interface CreateOrUpdateRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get a repository public key](https://docs.github.com/rest/codespaces/repository-secrets#get-a-repository-public-key) endpoint. */
    encrypted_value?: string | undefined;
    /** ID of the key you used to encrypt the secret. */
    key_id?: string | undefined;
}
export type CreateOrUpdateRepoSecretResponse = unknown;
export type CreateOrUpdateSecretForAuthenticatedUserRequestSelectedRepositoryIdsItem = number | string;
/** An array of repository ids that can access the user secret. You can manage the list of selected repositories using the [List selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#list-selected-repositories-for-a-user-secret), [Set selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#set-selected-repositories-for-a-user-secret), and [Remove a selected repository from a user secret](https://docs.github.com/rest/codespaces/secrets#remove-a-selected-repository-from-a-user-secret) endpoints. */
export type CreateOrUpdateSecretForAuthenticatedUserRequestSelectedRepositoryIdsList = Array<CreateOrUpdateSecretForAuthenticatedUserRequestSelectedRepositoryIdsItem>;
export interface CreateOrUpdateSecretForAuthenticatedUserRequest {
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get the public key for the authenticated user](https://docs.github.com/rest/codespaces/secrets#get-public-key-for-the-authenticated-user) endpoint. */
    encrypted_value?: string | undefined;
    /** ID of the key you used to encrypt the secret. */
    key_id: string;
    /** An array of repository ids that can access the user secret. You can manage the list of selected repositories using the [List selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#list-selected-repositories-for-a-user-secret), [Set selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#set-selected-repositories-for-a-user-secret), and [Remove a selected repository from a user secret](https://docs.github.com/rest/codespaces/secrets#remove-a-selected-repository-from-a-user-secret) endpoints. */
    selected_repository_ids?: CreateOrUpdateSecretForAuthenticatedUserRequestSelectedRepositoryIdsList | undefined;
}
export type CreateOrUpdateSecretForAuthenticatedUserResponse = unknown;
/** The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down. */
export type CreateWithPrForAuthenticatedUserRequestGeo = "EuropeWest" | "SoutheastAsia" | "UsEast" | "UsWest";
export interface CreateWithPrForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The requested location for a new codespace. Best efforts are made to respect this upon creation. Assigned by IP if not provided. */
    location?: string | undefined;
    /** The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down. */
    geo?: CreateWithPrForAuthenticatedUserRequestGeo | (string & {}) | undefined;
    /** IP for location auto-detection when proxying a request */
    client_ip?: string | undefined;
    /** Machine type to use for this codespace */
    machine?: string | undefined;
    /** Path to devcontainer.json config to use for this codespace */
    devcontainer_path?: string | undefined;
    /** Whether to authorize requested permissions from devcontainer.json */
    multi_repo_permissions_opt_out?: boolean | undefined;
    /** Working directory for this codespace */
    working_directory?: string | undefined;
    /** Time in minutes before codespace stops from inactivity */
    idle_timeout_minutes?: number | undefined;
    /** Display name for this codespace */
    display_name?: string | undefined;
    /** Duration in minutes after codespace has gone idle in which it will be deleted. Must be integer minutes between 0 and 43200 (30 days). */
    retention_period_minutes?: number | undefined;
}
/** The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down. */
export type CreateWithRepoForAuthenticatedUserRequestGeo = "EuropeWest" | "SoutheastAsia" | "UsEast" | "UsWest";
export interface CreateWithRepoForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Git ref (typically a branch name) for this codespace */
    ref?: string | undefined;
    /** The requested location for a new codespace. Best efforts are made to respect this upon creation. Assigned by IP if not provided. */
    location?: string | undefined;
    /** The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down. */
    geo?: CreateWithRepoForAuthenticatedUserRequestGeo | (string & {}) | undefined;
    /** IP for location auto-detection when proxying a request */
    client_ip?: string | undefined;
    /** Machine type to use for this codespace */
    machine?: string | undefined;
    /** Path to devcontainer.json config to use for this codespace */
    devcontainer_path?: string | undefined;
    /** Whether to authorize requested permissions from devcontainer.json */
    multi_repo_permissions_opt_out?: boolean | undefined;
    /** Working directory for this codespace */
    working_directory?: string | undefined;
    /** Time in minutes before codespace stops from inactivity */
    idle_timeout_minutes?: number | undefined;
    /** Display name for this codespace */
    display_name?: string | undefined;
    /** Duration in minutes after codespace has gone idle in which it will be deleted. Must be integer minutes between 0 and 43200 (30 days). */
    retention_period_minutes?: number | undefined;
}
export interface DeleteForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
}
export interface DeleteForAuthenticatedUserResponse {
}
export interface DeleteFromOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** The name of the codespace. */
    codespace_name: string;
}
export interface DeleteFromOrganizationResponse {
}
export interface DeleteOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteOrgSecretResponse {
}
export interface DeleteRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteRepoSecretResponse {
}
export interface DeleteSecretForAuthenticatedUserRequest {
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteSecretForAuthenticatedUserResponse {
}
export interface ExportForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
}
export interface ExportForAuthenticatedUserResponse {
}
export interface GetCodespacesForUserInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type GetCodespacesForUserInOrgResponseCodespacesList = Array<Codespace>;
export interface GetCodespacesForUserInOrgResponse {
    total_count: number;
    codespaces: GetCodespacesForUserInOrgResponseCodespacesList;
}
export interface GetExportDetailsForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
    /** The ID of the export operation, or `latest`. Currently only `latest` is currently supported. */
    export_id: string;
}
/** An export of a codespace. Also, latest export details for a codespace can be fetched with id = latest */
export interface CodespaceExportDetails {
    /** State of the latest export */
    state?: string | null | undefined;
    /** Completion time of the last export operation */
    completed_at?: string | null | undefined;
    /** Name of the exported branch */
    branch?: string | null | undefined;
    /** Git commit SHA of the exported branch */
    sha?: string | null | undefined;
    /** Id for the export details */
    id?: string | undefined;
    /** Url for fetching export details */
    export_url?: string | undefined;
    /** Web url for the exported branch */
    html_url?: string | null | undefined;
}
export interface GetForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
}
export interface GetOrgPublicKeyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The public key used for setting Codespaces secrets. */
export interface CodespacesPublicKey {
    /** The identifier for the key. */
    key_id: string;
    /** The Base64 encoded public key. */
    key: string;
    id?: number | undefined;
    url?: string | undefined;
    title?: string | undefined;
    created_at?: string | undefined;
}
export interface GetOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
/** The type of repositories in the organization that the secret is visible to */
export type CodespacesOrgSecretVisibility = "all" | "private" | "selected";
/** Secrets for a GitHub Codespace. */
export interface CodespacesOrgSecret {
    /** The name of the secret */
    name: string;
    /** The date and time at which the secret was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at: string;
    /** The date and time at which the secret was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at: string;
    /** The type of repositories in the organization that the secret is visible to */
    visibility: CodespacesOrgSecretVisibility;
    /** The API URL at which the list of repositories this secret is visible to can be retrieved */
    selected_repositories_url?: string | undefined;
}
export interface GetPublicKeyForAuthenticatedUserRequest {
}
/** The public key used for setting user Codespaces' Secrets. */
export interface CodespacesUserPublicKey {
    /** The identifier for the key. */
    key_id: string;
    /** The Base64 encoded public key. */
    key: string;
}
export interface GetRepoPublicKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
}
/** Set repository secrets for GitHub Codespaces. */
export interface RepoCodespacesSecret {
    /** The name of the secret. */
    name: string;
    created_at: string;
    updated_at: string;
}
export interface GetSecretForAuthenticatedUserRequest {
    /** The name of the secret. */
    secret_name: string;
}
/** The type of repositories in the organization that the secret is visible to */
export type CodespacesSecretVisibility = "all" | "private" | "selected";
/** Secrets for a GitHub Codespace. */
export interface CodespacesSecret {
    /** The name of the secret */
    name: string;
    /** The date and time at which the secret was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at: string;
    /** The date and time at which the secret was last updated, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at: string;
    /** The type of repositories in the organization that the secret is visible to */
    visibility: CodespacesSecretVisibility;
    /** The API URL at which the list of repositories this secret is visible to can be retrieved */
    selected_repositories_url: string;
}
export interface ListDevcontainersInRepositoryForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface ListDevcontainersInRepositoryForAuthenticatedUserResponseDevcontainersItem {
    path: string;
    name?: string | undefined;
    display_name?: string | undefined;
}
export type ListDevcontainersInRepositoryForAuthenticatedUserResponseDevcontainersList = Array<ListDevcontainersInRepositoryForAuthenticatedUserResponseDevcontainersItem>;
export interface ListDevcontainersInRepositoryForAuthenticatedUserResponse {
    total_count: number;
    devcontainers: ListDevcontainersInRepositoryForAuthenticatedUserResponseDevcontainersList;
}
export interface ListForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** ID of the Repository to filter on */
    repository_id?: number | undefined;
}
export type ListForAuthenticatedUserResponseCodespacesList = Array<Codespace>;
export interface ListForAuthenticatedUserResponse {
    total_count: number;
    codespaces: ListForAuthenticatedUserResponseCodespacesList;
}
export interface ListInOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListInOrganizationResponseCodespacesList = Array<Codespace>;
export interface ListInOrganizationResponse {
    total_count: number;
    codespaces: ListInOrganizationResponseCodespacesList;
}
export interface ListInRepositoryForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListInRepositoryForAuthenticatedUserResponseCodespacesList = Array<Codespace>;
export interface ListInRepositoryForAuthenticatedUserResponse {
    total_count: number;
    codespaces: ListInRepositoryForAuthenticatedUserResponseCodespacesList;
}
export interface ListOrgSecretsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOrgSecretsResponseSecretsList = Array<CodespacesOrgSecret>;
export interface ListOrgSecretsResponse {
    total_count: number;
    secrets: ListOrgSecretsResponseSecretsList;
}
export interface ListRepoSecretsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoSecretsResponseSecretsList = Array<RepoCodespacesSecret>;
export interface ListRepoSecretsResponse {
    total_count: number;
    secrets: ListRepoSecretsResponseSecretsList;
}
export interface ListRepositoriesForSecretForAuthenticatedUserRequest {
    /** The name of the secret. */
    secret_name: string;
}
export type ListRepositoriesForSecretForAuthenticatedUserResponseRepositoriesList = Array<MinimalRepository>;
export interface ListRepositoriesForSecretForAuthenticatedUserResponse {
    total_count: number;
    repositories: ListRepositoriesForSecretForAuthenticatedUserResponseRepositoriesList;
}
export interface ListSecretsForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSecretsForAuthenticatedUserResponseSecretsList = Array<CodespacesSecret>;
export interface ListSecretsForAuthenticatedUserResponse {
    total_count: number;
    secrets: ListSecretsForAuthenticatedUserResponseSecretsList;
}
export interface ListSelectedReposForOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListSelectedReposForOrgSecretResponseRepositoriesList = Array<MinimalRepository>;
export interface ListSelectedReposForOrgSecretResponse {
    total_count: number;
    repositories: ListSelectedReposForOrgSecretResponseRepositoriesList;
}
export interface PreFlightWithRepoForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The branch or commit to check for a default devcontainer path. If not specified, the default branch will be checked. */
    ref?: string | undefined;
    /** An alternative IP for default location auto-detection, such as when proxying a request. */
    client_ip?: string | undefined;
}
export interface PreFlightWithRepoForAuthenticatedUserResponseDefaults {
    location: string;
    devcontainer_path: string | null;
}
export interface PreFlightWithRepoForAuthenticatedUserResponse {
    billable_owner?: SimpleUser | undefined;
    defaults?: PreFlightWithRepoForAuthenticatedUserResponseDefaults | undefined;
}
export interface PublishForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
    /** A name for the new repository. */
    name?: string | undefined;
    /** Whether the new repository should be private. */
    private?: boolean | undefined;
}
export type FullRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type FullRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface FullRepositoryPermissions {
    admin: boolean;
    maintain?: boolean | undefined;
    push: boolean;
    triage?: boolean | undefined;
    pull: boolean;
}
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface NullableRepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type NullableRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type NullableRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type NullableRepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type NullableRepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type NullableRepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type NullableRepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface NullableRepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface NullableRepository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: NullableRepositoryPermissions | undefined;
    owner: SimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: NullableRepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: NullableRepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: NullableRepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: NullableRepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: NullableRepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: NullableRepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: NullableRepositoryCodeSearchIndexStatus | undefined;
}
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type FullRepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type FullRepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type FullRepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type FullRepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** A GitHub user. */
export type NullableSimpleUser = SimpleUser;
export type RepositoryPermissions = NullableRepositoryPermissions;
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export type RepositoryCodeSearchIndexStatus = NullableRepositoryCodeSearchIndexStatus;
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: NullableRepositoryPermissions | undefined;
    owner: SimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: NullableRepositoryCodeSearchIndexStatus | undefined;
}
/** Code of Conduct Simple */
export interface CodeOfConductSimple {
    url: string;
    key: string;
    name: string;
    html_url: string | null;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type FullRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Full Repository */
export interface FullRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    default_branch: string;
    open_issues_count: number;
    is_template?: boolean | undefined;
    topics?: FullRepositoryTopicsList | undefined;
    has_issues: boolean;
    has_projects: boolean;
    has_wiki: boolean;
    has_pages: boolean;
    has_downloads?: boolean | undefined;
    has_discussions: boolean;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: FullRepositoryPullRequestCreationPolicy | undefined;
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string;
    created_at: string;
    updated_at: string;
    permissions?: FullRepositoryPermissions | undefined;
    allow_rebase_merge?: boolean | undefined;
    template_repository?: NullableRepository | null | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | null | undefined;
    allow_squash_merge?: boolean | undefined;
    allow_auto_merge?: boolean | undefined;
    delete_branch_on_merge?: boolean | undefined;
    allow_merge_commit?: boolean | undefined;
    allow_update_branch?: boolean | undefined;
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: FullRepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: FullRepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: FullRepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: FullRepositoryMergeCommitMessage | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    subscribers_count: number;
    network_count: number;
    license: NullableLicenseSimple | null;
    organization?: SimpleUser | null | undefined;
    parent?: Repository | undefined;
    source?: Repository | undefined;
    forks: number;
    master_branch?: string | undefined;
    open_issues: number;
    watchers: number;
    /** Whether anonymous git access is allowed. */
    anonymous_access_enabled?: boolean | undefined;
    code_of_conduct?: CodeOfConductSimple | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: FullRepositoryCustomPropertiesMap | undefined;
}
/** State of this codespace. */
export type CodespaceWithFullRepositoryState = "Unknown" | "Created" | "Queued" | "Provisioning" | "Available" | "Awaiting" | "Unavailable" | "Deleted" | "Moved" | "Shutdown" | "Archived" | "Starting" | "ShuttingDown" | "Failed" | "Exporting" | "Updating" | "Rebuilding";
/** Details about the codespace's git repository. */
export type CodespaceWithFullRepositoryGitStatus = CodespaceGitStatus;
/** The initally assigned location of a new codespace. */
export type CodespaceWithFullRepositoryLocation = "EastUs" | "SouthEastAsia" | "WestEurope" | "WestUs2";
export type CodespaceWithFullRepositoryRecentFoldersList = Array<string>;
/** The privacy settings a user can select from when forwarding a port. */
export type CodespaceWithFullRepositoryRuntimeConstraintsAllowedPortPrivacySettingsList = Array<string>;
export interface CodespaceWithFullRepositoryRuntimeConstraints {
    /** The privacy settings a user can select from when forwarding a port. */
    allowed_port_privacy_settings?: CodespaceWithFullRepositoryRuntimeConstraintsAllowedPortPrivacySettingsList | null | undefined;
}
/** A codespace. */
export interface CodespaceWithFullRepository {
    id: number;
    /** Automatically generated name of this codespace. */
    name: string;
    /** Display name for this codespace. */
    display_name?: string | null | undefined;
    /** UUID identifying this codespace's environment. */
    environment_id: string | null;
    owner: SimpleUser;
    billable_owner: SimpleUser;
    repository: FullRepository;
    machine: NullableCodespaceMachine | null;
    /** Path to devcontainer.json from repo root used to create Codespace. */
    devcontainer_path?: string | null | undefined;
    /** Whether the codespace was created from a prebuild. */
    prebuild: boolean | null;
    created_at: string;
    updated_at: string;
    /** Last known time this codespace was started. */
    last_used_at: string;
    /** State of this codespace. */
    state: CodespaceWithFullRepositoryState;
    /** API URL for this codespace. */
    url: string;
    /** Details about the codespace's git repository. */
    git_status: CodespaceGitStatus;
    /** The initally assigned location of a new codespace. */
    location: CodespaceWithFullRepositoryLocation;
    /** The number of minutes of inactivity after which this codespace will be automatically stopped. */
    idle_timeout_minutes: number | null;
    /** URL to access this codespace on the web. */
    web_url: string;
    /** API URL to access available alternate machine types for this codespace. */
    machines_url: string;
    /** API URL to start this codespace. */
    start_url: string;
    /** API URL to stop this codespace. */
    stop_url: string;
    /** API URL to publish this codespace to a new repository. */
    publish_url?: string | null | undefined;
    /** API URL for the Pull Request associated with this codespace, if any. */
    pulls_url: string | null;
    recent_folders: CodespaceWithFullRepositoryRecentFoldersList;
    runtime_constraints?: CodespaceWithFullRepositoryRuntimeConstraints | undefined;
    /** Whether or not a codespace has a pending async operation. This would mean that the codespace is temporarily unavailable. The only thing that you can do with a codespace in this state is delete it. */
    pending_operation?: boolean | null | undefined;
    /** Text to show user when codespace is disabled by a pending operation */
    pending_operation_disabled_reason?: string | null | undefined;
    /** Text to show user when codespace idle timeout minutes has been overriden by an organization policy */
    idle_timeout_notice?: string | null | undefined;
    /** Duration in minutes after codespace has gone idle in which it will be deleted. Must be integer minutes between 0 and 43200 (30 days). */
    retention_period_minutes?: number | null | undefined;
    /** When a codespace will be auto-deleted based on the "retention_period_minutes" and "last_used_at" */
    retention_expires_at?: string | null | undefined;
}
export interface RemoveRepositoryForSecretForAuthenticatedUserRequest {
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface RemoveRepositoryForSecretForAuthenticatedUserResponse {
}
export interface RemoveSelectedRepoFromOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface RemoveSelectedRepoFromOrgSecretResponse {
}
export interface RepoMachinesForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The location to check for available machines. Assigned by IP if not provided. */
    location?: string | undefined;
    /** IP for location auto-detection when proxying a request */
    client_ip?: string | undefined;
    /** The branch or commit to check for prebuild availability and devcontainer restrictions. */
    ref?: string | undefined;
}
export type RepoMachinesForAuthenticatedUserResponseMachinesList = Array<CodespaceMachine>;
export interface RepoMachinesForAuthenticatedUserResponse {
    total_count: number;
    machines: RepoMachinesForAuthenticatedUserResponseMachinesList;
}
/** An array of repository ids for which a codespace can access the secret. You can manage the list of selected repositories using the [List selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#list-selected-repositories-for-a-user-secret), [Add a selected repository to a user secret](https://docs.github.com/rest/codespaces/secrets#add-a-selected-repository-to-a-user-secret), and [Remove a selected repository from a user secret](https://docs.github.com/rest/codespaces/secrets#remove-a-selected-repository-from-a-user-secret) endpoints. */
export type SetRepositoriesForSecretForAuthenticatedUserRequestSelectedRepositoryIdsList = Array<number>;
export interface SetRepositoriesForSecretForAuthenticatedUserRequest {
    /** The name of the secret. */
    secret_name: string;
    /** An array of repository ids for which a codespace can access the secret. You can manage the list of selected repositories using the [List selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#list-selected-repositories-for-a-user-secret), [Add a selected repository to a user secret](https://docs.github.com/rest/codespaces/secrets#add-a-selected-repository-to-a-user-secret), and [Remove a selected repository from a user secret](https://docs.github.com/rest/codespaces/secrets#remove-a-selected-repository-from-a-user-secret) endpoints. */
    selected_repository_ids: SetRepositoriesForSecretForAuthenticatedUserRequestSelectedRepositoryIdsList;
}
export interface SetRepositoriesForSecretForAuthenticatedUserResponse {
}
/** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Set selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#set-selected-repositories-for-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
export type SetSelectedReposForOrgSecretRequestSelectedRepositoryIdsList = Array<number>;
export interface SetSelectedReposForOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Set selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#set-selected-repositories-for-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
    selected_repository_ids: SetSelectedReposForOrgSecretRequestSelectedRepositoryIdsList;
}
export interface SetSelectedReposForOrgSecretResponse {
}
export interface StartForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
}
export interface StopForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
}
export interface StopInOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** The name of the codespace. */
    codespace_name: string;
}
/** Recently opened folders inside the codespace. It is currently used by the clients to determine the folder path to load the codespace in. */
export type UpdateForAuthenticatedUserRequestRecentFoldersList = Array<string>;
export interface UpdateForAuthenticatedUserRequest {
    /** The name of the codespace. */
    codespace_name: string;
    /** A valid machine to transition this codespace to. */
    machine?: string | undefined;
    /** Display name for this codespace */
    display_name?: string | undefined;
    /** Recently opened folders inside the codespace. It is currently used by the clients to determine the folder path to load the codespace in. */
    recent_folders?: UpdateForAuthenticatedUserRequestRecentFoldersList | undefined;
}
export type AddRepositoryForSecretForAuthenticatedUserError = GithubOpError;
/** Add a selected repository to a user secret Adds a repository to the selected repositories for a user's development environment secret. The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const addRepositoryForSecretForAuthenticatedUser: API.OperationMethod<AddRepositoryForSecretForAuthenticatedUserRequest, AddRepositoryForSecretForAuthenticatedUserResponse, AddRepositoryForSecretForAuthenticatedUserError, GithubOpContext>;
export type AddSelectedRepoToOrgSecretError = GithubOpError;
/** Add selected repository to an organization secret Adds a repository to an organization development environment secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#create-or-update-an-organization-secret). OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const addSelectedRepoToOrgSecret: API.OperationMethod<AddSelectedRepoToOrgSecretRequest, AddSelectedRepoToOrgSecretResponse, AddSelectedRepoToOrgSecretError, GithubOpContext>;
export type CheckPermissionsForDevcontainerError = GithubOpError;
/** Check if permissions defined by a devcontainer have been accepted by the authenticated user Checks whether the permissions defined by a given devcontainer configuration have been accepted by the authenticated user. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const checkPermissionsForDevcontainer: API.OperationMethod<CheckPermissionsForDevcontainerRequest, CodespacesPermissionsCheckForDevcontainer, CheckPermissionsForDevcontainerError, GithubOpContext>;
export type CodespaceMachinesForAuthenticatedUserError = GithubOpError;
/** List machine types for a codespace List the machine types a codespace can transition to use. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const codespaceMachinesForAuthenticatedUser: API.OperationMethod<CodespaceMachinesForAuthenticatedUserRequest, CodespaceMachinesForAuthenticatedUserResponse, CodespaceMachinesForAuthenticatedUserError, GithubOpContext>;
export type CreateForAuthenticatedUserError = GithubOpError;
/** Create a codespace for the authenticated user Creates a new codespace, owned by the authenticated user. This endpoint requires either a `repository_id` OR a `pull_request` but not both. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const createForAuthenticatedUser: API.OperationMethod<CreateForAuthenticatedUserRequest, Codespace, CreateForAuthenticatedUserError, GithubOpContext>;
export type CreateOrUpdateOrgSecretError = GithubOpError;
/** Create or update an organization secret Creates or updates an organization development environment secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const createOrUpdateOrgSecret: API.OperationMethod<CreateOrUpdateOrgSecretRequest, CreateOrUpdateOrgSecretResponse, CreateOrUpdateOrgSecretError, GithubOpContext>;
export type CreateOrUpdateRepoSecretError = GithubOpError;
/** Create or update a repository secret Creates or updates a repository development environment secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. The associated user must be a repository admin. */
export declare const createOrUpdateRepoSecret: API.OperationMethod<CreateOrUpdateRepoSecretRequest, CreateOrUpdateRepoSecretResponse, CreateOrUpdateRepoSecretError, GithubOpContext>;
export type CreateOrUpdateSecretForAuthenticatedUserError = GithubOpError;
/** Create or update a secret for the authenticated user Creates or updates a development environment secret for a user's codespace with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const createOrUpdateSecretForAuthenticatedUser: API.OperationMethod<CreateOrUpdateSecretForAuthenticatedUserRequest, CreateOrUpdateSecretForAuthenticatedUserResponse, CreateOrUpdateSecretForAuthenticatedUserError, GithubOpContext>;
export type CreateWithPrForAuthenticatedUserError = GithubOpError;
/** Create a codespace from a pull request Creates a codespace owned by the authenticated user for the specified pull request. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const createWithPrForAuthenticatedUser: API.OperationMethod<CreateWithPrForAuthenticatedUserRequest, Codespace, CreateWithPrForAuthenticatedUserError, GithubOpContext>;
export type CreateWithRepoForAuthenticatedUserError = GithubOpError;
/** Create a codespace in a repository Creates a codespace owned by the authenticated user in the specified repository. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const createWithRepoForAuthenticatedUser: API.OperationMethod<CreateWithRepoForAuthenticatedUserRequest, Codespace, CreateWithRepoForAuthenticatedUserError, GithubOpContext>;
export type DeleteForAuthenticatedUserError = GithubOpError;
/** Delete a codespace for the authenticated user Deletes a user's codespace. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const deleteForAuthenticatedUser: API.OperationMethod<DeleteForAuthenticatedUserRequest, DeleteForAuthenticatedUserResponse, DeleteForAuthenticatedUserError, GithubOpContext>;
export type DeleteFromOrganizationError = GithubOpError;
/** Delete a codespace from the organization Deletes a user's codespace. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteFromOrganization: API.OperationMethod<DeleteFromOrganizationRequest, DeleteFromOrganizationResponse, DeleteFromOrganizationError, GithubOpContext>;
export type DeleteOrgSecretError = GithubOpError;
/** Delete an organization secret Deletes an organization development environment secret using the secret name. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteOrgSecret: API.OperationMethod<DeleteOrgSecretRequest, DeleteOrgSecretResponse, DeleteOrgSecretError, GithubOpContext>;
export type DeleteRepoSecretError = GithubOpError;
/** Delete a repository secret Deletes a development environment secret in a repository using the secret name. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. The associated user must be a repository admin. */
export declare const deleteRepoSecret: API.OperationMethod<DeleteRepoSecretRequest, DeleteRepoSecretResponse, DeleteRepoSecretError, GithubOpContext>;
export type DeleteSecretForAuthenticatedUserError = GithubOpError;
/** Delete a secret for the authenticated user Deletes a development environment secret from a user's codespaces using the secret name. Deleting the secret will remove access from all codespaces that were allowed to access the secret. The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const deleteSecretForAuthenticatedUser: API.OperationMethod<DeleteSecretForAuthenticatedUserRequest, DeleteSecretForAuthenticatedUserResponse, DeleteSecretForAuthenticatedUserError, GithubOpContext>;
export type ExportForAuthenticatedUserError = GithubOpError;
/** Export a codespace for the authenticated user Triggers an export of the specified codespace and returns a URL and ID where the status of the export can be monitored. If changes cannot be pushed to the codespace's repository, they will be pushed to a new or previously-existing fork instead. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const exportForAuthenticatedUser: API.OperationMethod<ExportForAuthenticatedUserRequest, ExportForAuthenticatedUserResponse, ExportForAuthenticatedUserError, GithubOpContext>;
export type GetCodespacesForUserInOrgError = GithubOpError;
/** List codespaces for a user in organization Lists the codespaces that a member of an organization has for repositories in that organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getCodespacesForUserInOrg: API.PaginatedOperationMethod<GetCodespacesForUserInOrgRequest, GetCodespacesForUserInOrgResponse, GetCodespacesForUserInOrgError, GithubOpContext, Codespace>;
export type GetExportDetailsForAuthenticatedUserError = GithubOpError;
/** Get details about a codespace export Gets information about an export of a codespace. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const getExportDetailsForAuthenticatedUser: API.OperationMethod<GetExportDetailsForAuthenticatedUserRequest, CodespaceExportDetails, GetExportDetailsForAuthenticatedUserError, GithubOpContext>;
export type GetForAuthenticatedUserError = GithubOpError;
/** Get a codespace for the authenticated user Gets information about a user's codespace. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const getForAuthenticatedUser: API.OperationMethod<GetForAuthenticatedUserRequest, Codespace, GetForAuthenticatedUserError, GithubOpContext>;
export type GetOrgPublicKeyError = GithubOpError;
/** Get an organization public key Gets a public key for an organization, which is required in order to encrypt secrets. You need to encrypt the value of a secret before you can create or update secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getOrgPublicKey: API.OperationMethod<GetOrgPublicKeyRequest, CodespacesPublicKey, GetOrgPublicKeyError, GithubOpContext>;
export type GetOrgSecretError = GithubOpError;
/** Get an organization secret Gets an organization development environment secret without revealing its encrypted value. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getOrgSecret: API.OperationMethod<GetOrgSecretRequest, CodespacesOrgSecret, GetOrgSecretError, GithubOpContext>;
export type GetPublicKeyForAuthenticatedUserError = GithubOpError;
/** Get public key for the authenticated user Gets your public key, which you need to encrypt secrets. You need to encrypt a secret before you can create or update secrets. The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const getPublicKeyForAuthenticatedUser: API.OperationMethod<GetPublicKeyForAuthenticatedUserRequest, CodespacesUserPublicKey, GetPublicKeyForAuthenticatedUserError, GithubOpContext>;
export type GetRepoPublicKeyError = GithubOpError;
/** Get a repository public key Gets your public key, which you need to encrypt secrets. You need to encrypt a secret before you can create or update secrets. If the repository is private, OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoPublicKey: API.OperationMethod<GetRepoPublicKeyRequest, CodespacesPublicKey, GetRepoPublicKeyError, GithubOpContext>;
export type GetRepoSecretError = GithubOpError;
/** Get a repository secret Gets a single repository development environment secret without revealing its encrypted value. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoSecret: API.OperationMethod<GetRepoSecretRequest, RepoCodespacesSecret, GetRepoSecretError, GithubOpContext>;
export type GetSecretForAuthenticatedUserError = GithubOpError;
/** Get a secret for the authenticated user Gets a development environment secret available to a user's codespaces without revealing its encrypted value. The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const getSecretForAuthenticatedUser: API.OperationMethod<GetSecretForAuthenticatedUserRequest, CodespacesSecret, GetSecretForAuthenticatedUserError, GithubOpContext>;
export type ListDevcontainersInRepositoryForAuthenticatedUserError = GithubOpError;
/** List devcontainer configurations in a repository for the authenticated user Lists the devcontainer.json files associated with a specified repository and the authenticated user. These files specify launchpoint configurations for codespaces created within the repository. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const listDevcontainersInRepositoryForAuthenticatedUser: API.PaginatedOperationMethod<ListDevcontainersInRepositoryForAuthenticatedUserRequest, ListDevcontainersInRepositoryForAuthenticatedUserResponse, ListDevcontainersInRepositoryForAuthenticatedUserError, GithubOpContext, ListDevcontainersInRepositoryForAuthenticatedUserResponseDevcontainersItem>;
export type ListForAuthenticatedUserError = GithubOpError;
/** List codespaces for the authenticated user Lists the authenticated user's codespaces. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const listForAuthenticatedUser: API.PaginatedOperationMethod<ListForAuthenticatedUserRequest, ListForAuthenticatedUserResponse, ListForAuthenticatedUserError, GithubOpContext, Codespace>;
export type ListInOrganizationError = GithubOpError;
/** List codespaces for the organization Lists the codespaces associated to a specified organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listInOrganization: API.PaginatedOperationMethod<ListInOrganizationRequest, ListInOrganizationResponse, ListInOrganizationError, GithubOpContext, Codespace>;
export type ListInRepositoryForAuthenticatedUserError = GithubOpError;
/** List codespaces in a repository for the authenticated user Lists the codespaces associated to a specified repository and the authenticated user. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const listInRepositoryForAuthenticatedUser: API.PaginatedOperationMethod<ListInRepositoryForAuthenticatedUserRequest, ListInRepositoryForAuthenticatedUserResponse, ListInRepositoryForAuthenticatedUserError, GithubOpContext, Codespace>;
export type ListOrgSecretsError = GithubOpError;
/** List organization secrets Lists all Codespaces development environment secrets available at the organization-level without revealing their encrypted values. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listOrgSecrets: API.PaginatedOperationMethod<ListOrgSecretsRequest, ListOrgSecretsResponse, ListOrgSecretsError, GithubOpContext, CodespacesOrgSecret>;
export type ListRepoSecretsError = GithubOpError;
/** List repository secrets Lists all development environment secrets available in a repository without revealing their encrypted values. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoSecrets: API.PaginatedOperationMethod<ListRepoSecretsRequest, ListRepoSecretsResponse, ListRepoSecretsError, GithubOpContext, RepoCodespacesSecret>;
export type ListRepositoriesForSecretForAuthenticatedUserError = GithubOpError;
/** List selected repositories for a user secret List the repositories that have been granted the ability to use a user's development environment secret. The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const listRepositoriesForSecretForAuthenticatedUser: API.OperationMethod<ListRepositoriesForSecretForAuthenticatedUserRequest, ListRepositoriesForSecretForAuthenticatedUserResponse, ListRepositoriesForSecretForAuthenticatedUserError, GithubOpContext>;
export type ListSecretsForAuthenticatedUserError = GithubOpError;
/** List secrets for the authenticated user Lists all development environment secrets available for a user's codespaces without revealing their encrypted values. The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const listSecretsForAuthenticatedUser: API.PaginatedOperationMethod<ListSecretsForAuthenticatedUserRequest, ListSecretsForAuthenticatedUserResponse, ListSecretsForAuthenticatedUserError, GithubOpContext, CodespacesSecret>;
export type ListSelectedReposForOrgSecretError = GithubOpError;
/** List selected repositories for an organization secret Lists all repositories that have been selected when the `visibility` for repository access to a secret is set to `selected`. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listSelectedReposForOrgSecret: API.PaginatedOperationMethod<ListSelectedReposForOrgSecretRequest, ListSelectedReposForOrgSecretResponse, ListSelectedReposForOrgSecretError, GithubOpContext, MinimalRepository>;
export type PreFlightWithRepoForAuthenticatedUserError = GithubOpError;
/** Get default attributes for a codespace Gets the default attributes for codespaces created by the user with the repository. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const preFlightWithRepoForAuthenticatedUser: API.OperationMethod<PreFlightWithRepoForAuthenticatedUserRequest, PreFlightWithRepoForAuthenticatedUserResponse, PreFlightWithRepoForAuthenticatedUserError, GithubOpContext>;
export type PublishForAuthenticatedUserError = GithubOpError;
/** Create a repository from an unpublished codespace Publishes an unpublished codespace, creating a new repository and assigning it to the codespace. The codespace's token is granted write permissions to the repository, allowing the user to push their changes. This will fail for a codespace that is already published, meaning it has an associated repository. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const publishForAuthenticatedUser: API.OperationMethod<PublishForAuthenticatedUserRequest, CodespaceWithFullRepository, PublishForAuthenticatedUserError, GithubOpContext>;
export type RemoveRepositoryForSecretForAuthenticatedUserError = GithubOpError;
/** Remove a selected repository from a user secret Removes a repository from the selected repositories for a user's development environment secret. The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const removeRepositoryForSecretForAuthenticatedUser: API.OperationMethod<RemoveRepositoryForSecretForAuthenticatedUserRequest, RemoveRepositoryForSecretForAuthenticatedUserResponse, RemoveRepositoryForSecretForAuthenticatedUserError, GithubOpContext>;
export type RemoveSelectedRepoFromOrgSecretError = GithubOpError;
/** Remove selected repository from an organization secret Removes a repository from an organization development environment secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#create-or-update-an-organization-secret). OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const removeSelectedRepoFromOrgSecret: API.OperationMethod<RemoveSelectedRepoFromOrgSecretRequest, RemoveSelectedRepoFromOrgSecretResponse, RemoveSelectedRepoFromOrgSecretError, GithubOpContext>;
export type RepoMachinesForAuthenticatedUserError = GithubOpError;
/** List available machine types for a repository List the machine types available for a given repository based on its configuration. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const repoMachinesForAuthenticatedUser: API.OperationMethod<RepoMachinesForAuthenticatedUserRequest, RepoMachinesForAuthenticatedUserResponse, RepoMachinesForAuthenticatedUserError, GithubOpContext>;
export type SetRepositoriesForSecretForAuthenticatedUserError = GithubOpError;
/** Set selected repositories for a user secret Select the repositories that will use a user's development environment secret. The authenticated user must have Codespaces access to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `codespace` or `codespace:secrets` scope to use this endpoint. */
export declare const setRepositoriesForSecretForAuthenticatedUser: API.OperationMethod<SetRepositoriesForSecretForAuthenticatedUserRequest, SetRepositoriesForSecretForAuthenticatedUserResponse, SetRepositoriesForSecretForAuthenticatedUserError, GithubOpContext>;
export type SetSelectedReposForOrgSecretError = GithubOpError;
/** Set selected repositories for an organization secret Replaces all repositories for an organization development environment secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#create-or-update-an-organization-secret). OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setSelectedReposForOrgSecret: API.OperationMethod<SetSelectedReposForOrgSecretRequest, SetSelectedReposForOrgSecretResponse, SetSelectedReposForOrgSecretError, GithubOpContext>;
export type StartForAuthenticatedUserError = GithubOpError;
/** Start a codespace for the authenticated user Starts a user's codespace. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const startForAuthenticatedUser: API.OperationMethod<StartForAuthenticatedUserRequest, Codespace, StartForAuthenticatedUserError, GithubOpContext>;
export type StopForAuthenticatedUserError = GithubOpError;
/** Stop a codespace for the authenticated user Stops a user's codespace. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const stopForAuthenticatedUser: API.OperationMethod<StopForAuthenticatedUserRequest, Codespace, StopForAuthenticatedUserError, GithubOpContext>;
export type StopInOrganizationError = GithubOpError;
/** Stop a codespace for an organization user Stops a user's codespace. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const stopInOrganization: API.OperationMethod<StopInOrganizationRequest, Codespace, StopInOrganizationError, GithubOpContext>;
export type UpdateForAuthenticatedUserError = GithubOpError;
/** Update a codespace for the authenticated user Updates a codespace owned by the authenticated user. Currently only the codespace's machine type and recent folders can be modified using this endpoint. If you specify a new machine type it will be applied the next time your codespace is started. OAuth app tokens and personal access tokens (classic) need the `codespace` scope to use this endpoint. */
export declare const updateForAuthenticatedUser: API.OperationMethod<UpdateForAuthenticatedUserRequest, Codespace, UpdateForAuthenticatedUserError, GithubOpContext>;
//# sourceMappingURL=codespaces.d.ts.map