import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}>;
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
    readonly FieldName: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidPolicyDocument_base: S.TaggedErrorClass<"InvalidPolicyDocument", {
    readonly message: any;
}>;
export declare class InvalidPolicyDocument extends /*@__PURE__*/ InvalidPolicyDocument_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidTagException_base: S.TaggedErrorClass<"InvalidTagException", {
    readonly message: any;
}>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceExistsException_base: S.TaggedErrorClass<"ResourceExistsException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class ResourceExistsException extends /*@__PURE__*/ ResourceExistsException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnknownResourceException_base: S.TaggedErrorClass<"UnknownResourceException", {
    readonly message: any;
}>;
export declare class UnknownResourceException extends /*@__PURE__*/ UnknownResourceException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CreatorRequestId = string;
export type ResourceId = string;
export type Priority = number;
export type Name = string;
export type MutationProtectionStatus = "ENABLED" | "DISABLED" | (string & {});
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface AssociateFirewallRuleGroupRequest {
    CreatorRequestId: string;
    FirewallRuleGroupId: string;
    VpcId: string;
    Priority: number;
    Name: string;
    MutationProtection?: MutationProtectionStatus | undefined;
    Tags?: Tag[] | undefined;
}
export type Arn = string;
export type ServicePrinciple = string;
export type FirewallRuleGroupAssociationStatus = "COMPLETE" | "DELETING" | "UPDATING" | (string & {});
export type StatusMessage = string;
export type Rfc3339TimeString = string;
export interface FirewallRuleGroupAssociation {
    Id?: string | undefined;
    Arn?: string | undefined;
    FirewallRuleGroupId?: string | undefined;
    VpcId?: string | undefined;
    Name?: string | undefined;
    Priority?: number | undefined;
    MutationProtection?: MutationProtectionStatus | undefined;
    ManagedOwnerName?: string | undefined;
    Status?: FirewallRuleGroupAssociationStatus | undefined;
    StatusMessage?: string | undefined;
    CreatorRequestId?: string | undefined;
    CreationTime?: string | undefined;
    ModificationTime?: string | undefined;
}
export interface AssociateFirewallRuleGroupResponse {
    FirewallRuleGroupAssociation?: FirewallRuleGroupAssociation | undefined;
}
export type SubnetId = string;
export type Ip = string;
export type Ipv6 = string;
export interface IpAddressUpdate {
    IpId?: string | undefined;
    SubnetId?: string | undefined;
    Ip?: string | undefined;
    Ipv6?: string | undefined;
}
export interface AssociateResolverEndpointIpAddressRequest {
    ResolverEndpointId: string;
    IpAddress: IpAddressUpdate;
}
export type SecurityGroupIds = string[];
export type ResolverEndpointDirection = "INBOUND" | "OUTBOUND" | "INBOUND_DELEGATION" | (string & {});
export type IpAddressCount = number;
export type ResolverEndpointStatus = "CREATING" | "OPERATIONAL" | "UPDATING" | "AUTO_RECOVERING" | "ACTION_NEEDED" | "DELETING" | (string & {});
export type OutpostArn = string;
export type OutpostInstanceType = string;
export type ResolverEndpointType = "IPV6" | "IPV4" | "DUALSTACK" | (string & {});
export type Protocol = "DoH" | "Do53" | "DoH-FIPS" | (string & {});
export type ProtocolList = Protocol[];
export type RniEnhancedMetricsEnabled = boolean;
export type TargetNameServerMetricsEnabled = boolean;
export type Dns64Enabled = boolean;
export type Ipv6InternetAccessEnabled = boolean;
export interface ResolverEndpoint {
    Id?: string | undefined;
    CreatorRequestId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    Direction?: ResolverEndpointDirection | undefined;
    IpAddressCount?: number | undefined;
    HostVPCId?: string | undefined;
    Status?: ResolverEndpointStatus | undefined;
    StatusMessage?: string | undefined;
    CreationTime?: string | undefined;
    ModificationTime?: string | undefined;
    OutpostArn?: string | undefined;
    PreferredInstanceType?: string | undefined;
    ResolverEndpointType?: ResolverEndpointType | undefined;
    Protocols?: Protocol[] | undefined;
    RniEnhancedMetricsEnabled?: boolean | undefined;
    TargetNameServerMetricsEnabled?: boolean | undefined;
    Dns64Enabled?: boolean | undefined;
    Ipv6InternetAccessEnabled?: boolean | undefined;
}
export interface AssociateResolverEndpointIpAddressResponse {
    ResolverEndpoint?: ResolverEndpoint | undefined;
}
export interface AssociateResolverQueryLogConfigRequest {
    ResolverQueryLogConfigId: string;
    ResourceId: string;
}
export type ResolverQueryLogConfigAssociationStatus = "CREATING" | "ACTIVE" | "ACTION_NEEDED" | "DELETING" | "FAILED" | (string & {});
export type ResolverQueryLogConfigAssociationError = "NONE" | "DESTINATION_NOT_FOUND" | "ACCESS_DENIED" | "INTERNAL_SERVICE_ERROR" | (string & {});
export type ResolverQueryLogConfigAssociationErrorMessage = string;
export interface ResolverQueryLogConfigAssociation {
    Id?: string | undefined;
    ResolverQueryLogConfigId?: string | undefined;
    ResourceId?: string | undefined;
    Status?: ResolverQueryLogConfigAssociationStatus | undefined;
    Error?: ResolverQueryLogConfigAssociationError | undefined;
    ErrorMessage?: string | undefined;
    CreationTime?: string | undefined;
}
export interface AssociateResolverQueryLogConfigResponse {
    ResolverQueryLogConfigAssociation?: ResolverQueryLogConfigAssociation | undefined;
}
export interface AssociateResolverRuleRequest {
    ResolverRuleId: string;
    Name?: string | undefined;
    VPCId: string;
}
export type ResolverRuleAssociationStatus = "CREATING" | "COMPLETE" | "DELETING" | "FAILED" | "OVERRIDDEN" | (string & {});
export interface ResolverRuleAssociation {
    Id?: string | undefined;
    ResolverRuleId?: string | undefined;
    Name?: string | undefined;
    VPCId?: string | undefined;
    Status?: ResolverRuleAssociationStatus | undefined;
    StatusMessage?: string | undefined;
}
export interface AssociateResolverRuleResponse {
    ResolverRuleAssociation?: ResolverRuleAssociation | undefined;
}
export type Action = "ALLOW" | "BLOCK" | "ALERT" | (string & {});
export type BlockResponse = "NODATA" | "NXDOMAIN" | "OVERRIDE" | (string & {});
export type BlockOverrideDomain = string;
export type BlockOverrideDnsType = "CNAME" | (string & {});
export type BlockOverrideTtl = number;
export type FirewallDomainRedirectionAction = "INSPECT_REDIRECTION_DOMAIN" | "TRUST_REDIRECTION_DOMAIN" | (string & {});
export type Qtype = string;
export type DnsThreatProtection = "DGA" | "DNS_TUNNELING" | "DICTIONARY_DGA" | (string & {});
export type ConfidenceThreshold = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type PartnerValue = string;
export interface PartnerThreatProtectionConfig {
    Partner: string;
}
export type FirewallAdvancedContentCategoryValue = string;
export interface FirewallAdvancedContentCategoryConfig {
    Category: string;
}
export type FirewallAdvancedThreatCategoryValue = string;
export interface FirewallAdvancedThreatCategoryConfig {
    Category: string;
}
export type DnsThreatProtectionRuleTypeValue = string;
export interface DnsThreatProtectionRuleTypeConfig {
    Value: string;
    ConfidenceThreshold: ConfidenceThreshold;
}
export interface FirewallRuleType {
    PartnerThreatProtection?: PartnerThreatProtectionConfig | undefined;
    FirewallAdvancedContentCategory?: FirewallAdvancedContentCategoryConfig | undefined;
    FirewallAdvancedThreatCategory?: FirewallAdvancedThreatCategoryConfig | undefined;
    DnsThreatProtection?: DnsThreatProtectionRuleTypeConfig | undefined;
}
export interface CreateFirewallRuleEntry {
    CreatorRequestId: string;
    FirewallRuleGroupId: string;
    FirewallDomainListId?: string | undefined;
    Priority: number;
    Action: Action;
    BlockResponse?: BlockResponse | undefined;
    BlockOverrideDomain?: string | undefined;
    BlockOverrideDnsType?: BlockOverrideDnsType | undefined;
    BlockOverrideTtl?: number | undefined;
    Name: string;
    FirewallDomainRedirectionAction?: FirewallDomainRedirectionAction | undefined;
    Qtype?: string | undefined;
    DnsThreatProtection?: DnsThreatProtection | undefined;
    ConfidenceThreshold?: ConfidenceThreshold | undefined;
    FirewallRuleType?: FirewallRuleType | undefined;
}
export type CreateFirewallRuleEntries = CreateFirewallRuleEntry[];
export interface BatchCreateFirewallRuleRequest {
    CreateFirewallRuleEntries: CreateFirewallRuleEntry[];
}
export type Unsigned = number;
export type FirewallRuleStatus = string;
export type FirewallRuleStatusMessage = string;
export interface FirewallRule {
    FirewallRuleGroupId?: string | undefined;
    FirewallDomainListId?: string | undefined;
    FirewallThreatProtectionId?: string | undefined;
    Name?: string | undefined;
    Priority?: number | undefined;
    Action?: Action | undefined;
    BlockResponse?: BlockResponse | undefined;
    BlockOverrideDomain?: string | undefined;
    BlockOverrideDnsType?: BlockOverrideDnsType | undefined;
    BlockOverrideTtl?: number | undefined;
    CreatorRequestId?: string | undefined;
    CreationTime?: string | undefined;
    ModificationTime?: string | undefined;
    FirewallDomainRedirectionAction?: FirewallDomainRedirectionAction | undefined;
    Qtype?: string | undefined;
    DnsThreatProtection?: DnsThreatProtection | undefined;
    ConfidenceThreshold?: ConfidenceThreshold | undefined;
    FirewallRuleType?: FirewallRuleType | undefined;
    Status?: string | undefined;
    StatusMessage?: string | undefined;
}
export type FirewallRules = FirewallRule[];
export interface BatchCreateFirewallRuleError_ {
    FirewallRule?: CreateFirewallRuleEntry | undefined;
    Code?: string | undefined;
    Message?: string | undefined;
}
export type BatchCreateFirewallRuleErrors = BatchCreateFirewallRuleError_[];
export interface BatchCreateFirewallRuleResponse {
    CreatedFirewallRules?: FirewallRule[] | undefined;
    CreateErrors?: BatchCreateFirewallRuleError_[] | undefined;
}
export interface DeleteFirewallRuleEntry {
    FirewallRuleGroupId: string;
    FirewallDomainListId?: string | undefined;
    FirewallThreatProtectionId?: string | undefined;
    Qtype?: string | undefined;
}
export type DeleteFirewallRuleEntries = DeleteFirewallRuleEntry[];
export interface BatchDeleteFirewallRuleRequest {
    DeleteFirewallRuleEntries: DeleteFirewallRuleEntry[];
}
export interface BatchDeleteFirewallRuleError_ {
    FirewallRule?: DeleteFirewallRuleEntry | undefined;
    Code?: string | undefined;
    Message?: string | undefined;
}
export type BatchDeleteFirewallRuleErrors = BatchDeleteFirewallRuleError_[];
export interface BatchDeleteFirewallRuleResponse {
    DeletedFirewallRules?: FirewallRule[] | undefined;
    DeleteErrors?: BatchDeleteFirewallRuleError_[] | undefined;
}
export interface UpdateFirewallRuleEntry {
    FirewallRuleGroupId: string;
    FirewallDomainListId?: string | undefined;
    FirewallThreatProtectionId?: string | undefined;
    Priority?: number | undefined;
    Action?: Action | undefined;
    BlockResponse?: BlockResponse | undefined;
    BlockOverrideDomain?: string | undefined;
    BlockOverrideDnsType?: BlockOverrideDnsType | undefined;
    BlockOverrideTtl?: number | undefined;
    Name?: string | undefined;
    FirewallDomainRedirectionAction?: FirewallDomainRedirectionAction | undefined;
    Qtype?: string | undefined;
    DnsThreatProtection?: DnsThreatProtection | undefined;
    ConfidenceThreshold?: ConfidenceThreshold | undefined;
    FirewallRuleType?: FirewallRuleType | undefined;
}
export type UpdateFirewallRuleEntries = UpdateFirewallRuleEntry[];
export interface BatchUpdateFirewallRuleRequest {
    UpdateFirewallRuleEntries: UpdateFirewallRuleEntry[];
}
export interface BatchUpdateFirewallRuleError_ {
    FirewallRule?: UpdateFirewallRuleEntry | undefined;
    Code?: string | undefined;
    Message?: string | undefined;
}
export type BatchUpdateFirewallRuleErrors = BatchUpdateFirewallRuleError_[];
export interface BatchUpdateFirewallRuleResponse {
    UpdatedFirewallRules?: FirewallRule[] | undefined;
    UpdateErrors?: BatchUpdateFirewallRuleError_[] | undefined;
}
export interface CreateFirewallDomainListRequest {
    CreatorRequestId: string;
    Name: string;
    Tags?: Tag[] | undefined;
}
export type FirewallDomainListStatus = "COMPLETE" | "COMPLETE_IMPORT_FAILED" | "IMPORTING" | "DELETING" | "UPDATING" | (string & {});
export type Category = string;
export type DomainListType = "THREAT" | "CONTENT" | (string & {});
export interface FirewallDomainList {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    DomainCount?: number | undefined;
    Status?: FirewallDomainListStatus | undefined;
    StatusMessage?: string | undefined;
    ManagedOwnerName?: string | undefined;
    CreatorRequestId?: string | undefined;
    CreationTime?: string | undefined;
    ModificationTime?: string | undefined;
    Category?: string | undefined;
    ManagedListType?: DomainListType | undefined;
}
export interface CreateFirewallDomainListResponse {
    FirewallDomainList?: FirewallDomainList | undefined;
}
export interface CreateFirewallRuleRequest {
    CreatorRequestId: string;
    FirewallRuleGroupId: string;
    FirewallDomainListId?: string | undefined;
    Priority: number;
    Action: Action;
    BlockResponse?: BlockResponse | undefined;
    BlockOverrideDomain?: string | undefined;
    BlockOverrideDnsType?: BlockOverrideDnsType | undefined;
    BlockOverrideTtl?: number | undefined;
    Name: string;
    FirewallDomainRedirectionAction?: FirewallDomainRedirectionAction | undefined;
    Qtype?: string | undefined;
    DnsThreatProtection?: DnsThreatProtection | undefined;
    ConfidenceThreshold?: ConfidenceThreshold | undefined;
    FirewallRuleType?: FirewallRuleType | undefined;
}
export interface CreateFirewallRuleResponse {
    FirewallRule?: FirewallRule | undefined;
}
export interface CreateFirewallRuleGroupRequest {
    CreatorRequestId: string;
    Name: string;
    Tags?: Tag[] | undefined;
}
export type FirewallRuleGroupStatus = "COMPLETE" | "DELETING" | "UPDATING" | (string & {});
export type AccountId = string;
export type ShareStatus = "NOT_SHARED" | "SHARED_WITH_ME" | "SHARED_BY_ME" | (string & {});
export interface FirewallRuleGroup {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    RuleCount?: number | undefined;
    Status?: FirewallRuleGroupStatus | undefined;
    StatusMessage?: string | undefined;
    OwnerId?: string | undefined;
    CreatorRequestId?: string | undefined;
    ShareStatus?: ShareStatus | undefined;
    CreationTime?: string | undefined;
    ModificationTime?: string | undefined;
}
export interface CreateFirewallRuleGroupResponse {
    FirewallRuleGroup?: FirewallRuleGroup | undefined;
}
export type OutpostResolverName = string;
export type InstanceCount = number;
export interface CreateOutpostResolverRequest {
    CreatorRequestId: string;
    Name: string;
    InstanceCount?: number | undefined;
    PreferredInstanceType: string;
    OutpostArn: string;
    Tags?: Tag[] | undefined;
}
export type OutpostResolverStatus = "CREATING" | "OPERATIONAL" | "UPDATING" | "DELETING" | "ACTION_NEEDED" | "FAILED_CREATION" | "FAILED_DELETION" | (string & {});
export type OutpostResolverStatusMessage = string;
export interface OutpostResolver {
    Arn?: string | undefined;
    CreationTime?: string | undefined;
    ModificationTime?: string | undefined;
    CreatorRequestId?: string | undefined;
    Id?: string | undefined;
    InstanceCount?: number | undefined;
    PreferredInstanceType?: string | undefined;
    Name?: string | undefined;
    Status?: OutpostResolverStatus | undefined;
    StatusMessage?: string | undefined;
    OutpostArn?: string | undefined;
}
export interface CreateOutpostResolverResponse {
    OutpostResolver?: OutpostResolver | undefined;
}
export interface IpAddressRequest {
    SubnetId: string;
    Ip?: string | undefined;
    Ipv6?: string | undefined;
}
export type IpAddressesRequest = IpAddressRequest[];
export interface CreateResolverEndpointRequest {
    CreatorRequestId: string;
    Name?: string | undefined;
    SecurityGroupIds: string[];
    Direction: ResolverEndpointDirection;
    IpAddresses: IpAddressRequest[];
    OutpostArn?: string | undefined;
    PreferredInstanceType?: string | undefined;
    Tags?: Tag[] | undefined;
    ResolverEndpointType?: ResolverEndpointType | undefined;
    Protocols?: Protocol[] | undefined;
    RniEnhancedMetricsEnabled?: boolean | undefined;
    TargetNameServerMetricsEnabled?: boolean | undefined;
    Dns64Enabled?: boolean | undefined;
    Ipv6InternetAccessEnabled?: boolean | undefined;
}
export interface CreateResolverEndpointResponse {
    ResolverEndpoint?: ResolverEndpoint | undefined;
}
export type ResolverQueryLogConfigName = string;
export type DestinationArn = string;
export interface CreateResolverQueryLogConfigRequest {
    Name: string;
    DestinationArn: string;
    CreatorRequestId: string;
    Tags?: Tag[] | undefined;
}
export type ResolverQueryLogConfigStatus = "CREATING" | "CREATED" | "DELETING" | "FAILED" | (string & {});
export type Count = number;
export interface ResolverQueryLogConfig {
    Id?: string | undefined;
    OwnerId?: string | undefined;
    Status?: ResolverQueryLogConfigStatus | undefined;
    ShareStatus?: ShareStatus | undefined;
    AssociationCount?: number | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    DestinationArn?: string | undefined;
    CreatorRequestId?: string | undefined;
    CreationTime?: string | undefined;
}
export interface CreateResolverQueryLogConfigResponse {
    ResolverQueryLogConfig?: ResolverQueryLogConfig | undefined;
}
export type RuleTypeOption = "FORWARD" | "SYSTEM" | "RECURSIVE" | "DELEGATE" | (string & {});
export type DomainName = string;
export type Port = number;
export type ServerNameIndication = string;
export interface TargetAddress {
    Ip?: string | undefined;
    Port?: number | undefined;
    Ipv6?: string | undefined;
    Protocol?: Protocol | undefined;
    ServerNameIndication?: string | undefined;
}
export type TargetList = TargetAddress[];
export type DelegationRecord = string;
export interface CreateResolverRuleRequest {
    CreatorRequestId: string;
    Name?: string | undefined;
    RuleType: RuleTypeOption;
    DomainName?: string | undefined;
    TargetIps?: TargetAddress[] | undefined;
    ResolverEndpointId?: string | undefined;
    Tags?: Tag[] | undefined;
    DelegationRecord?: string | undefined;
}
export type ResolverRuleStatus = "COMPLETE" | "DELETING" | "UPDATING" | "FAILED" | (string & {});
export interface ResolverRule {
    Id?: string | undefined;
    CreatorRequestId?: string | undefined;
    Arn?: string | undefined;
    DomainName?: string | undefined;
    Status?: ResolverRuleStatus | undefined;
    StatusMessage?: string | undefined;
    RuleType?: RuleTypeOption | undefined;
    Name?: string | undefined;
    TargetIps?: TargetAddress[] | undefined;
    ResolverEndpointId?: string | undefined;
    OwnerId?: string | undefined;
    ShareStatus?: ShareStatus | undefined;
    CreationTime?: string | undefined;
    ModificationTime?: string | undefined;
    DelegationRecord?: string | undefined;
}
export interface CreateResolverRuleResponse {
    ResolverRule?: ResolverRule | undefined;
}
export interface DeleteFirewallDomainListRequest {
    FirewallDomainListId: string;
}
export interface DeleteFirewallDomainListResponse {
    FirewallDomainList?: FirewallDomainList | undefined;
}
export interface DeleteFirewallRuleRequest {
    FirewallRuleGroupId: string;
    FirewallDomainListId?: string | undefined;
    FirewallThreatProtectionId?: string | undefined;
    Qtype?: string | undefined;
}
export interface DeleteFirewallRuleResponse {
    FirewallRule?: FirewallRule | undefined;
}
export interface DeleteFirewallRuleGroupRequest {
    FirewallRuleGroupId: string;
}
export interface DeleteFirewallRuleGroupResponse {
    FirewallRuleGroup?: FirewallRuleGroup | undefined;
}
export interface DeleteOutpostResolverRequest {
    Id: string;
}
export interface DeleteOutpostResolverResponse {
    OutpostResolver?: OutpostResolver | undefined;
}
export interface DeleteResolverEndpointRequest {
    ResolverEndpointId: string;
}
export interface DeleteResolverEndpointResponse {
    ResolverEndpoint?: ResolverEndpoint | undefined;
}
export interface DeleteResolverQueryLogConfigRequest {
    ResolverQueryLogConfigId: string;
}
export interface DeleteResolverQueryLogConfigResponse {
    ResolverQueryLogConfig?: ResolverQueryLogConfig | undefined;
}
export interface DeleteResolverRuleRequest {
    ResolverRuleId: string;
}
export interface DeleteResolverRuleResponse {
    ResolverRule?: ResolverRule | undefined;
}
export interface DisassociateFirewallRuleGroupRequest {
    FirewallRuleGroupAssociationId: string;
}
export interface DisassociateFirewallRuleGroupResponse {
    FirewallRuleGroupAssociation?: FirewallRuleGroupAssociation | undefined;
}
export interface DisassociateResolverEndpointIpAddressRequest {
    ResolverEndpointId: string;
    IpAddress: IpAddressUpdate;
}
export interface DisassociateResolverEndpointIpAddressResponse {
    ResolverEndpoint?: ResolverEndpoint | undefined;
}
export interface DisassociateResolverQueryLogConfigRequest {
    ResolverQueryLogConfigId: string;
    ResourceId: string;
}
export interface DisassociateResolverQueryLogConfigResponse {
    ResolverQueryLogConfigAssociation?: ResolverQueryLogConfigAssociation | undefined;
}
export interface DisassociateResolverRuleRequest {
    VPCId: string;
    ResolverRuleId: string;
}
export interface DisassociateResolverRuleResponse {
    ResolverRuleAssociation?: ResolverRuleAssociation | undefined;
}
export interface GetFirewallConfigRequest {
    ResourceId: string;
}
export type FirewallFailOpenStatus = "ENABLED" | "DISABLED" | "USE_LOCAL_RESOURCE_SETTING" | (string & {});
export interface FirewallConfig {
    Id?: string | undefined;
    ResourceId?: string | undefined;
    OwnerId?: string | undefined;
    FirewallFailOpen?: FirewallFailOpenStatus | undefined;
}
export interface GetFirewallConfigResponse {
    FirewallConfig?: FirewallConfig | undefined;
}
export interface GetFirewallDomainListRequest {
    FirewallDomainListId: string;
}
export interface GetFirewallDomainListResponse {
    FirewallDomainList?: FirewallDomainList | undefined;
}
export interface GetFirewallRuleGroupRequest {
    FirewallRuleGroupId: string;
}
export interface GetFirewallRuleGroupResponse {
    FirewallRuleGroup?: FirewallRuleGroup | undefined;
}
export interface GetFirewallRuleGroupAssociationRequest {
    FirewallRuleGroupAssociationId: string;
}
export interface GetFirewallRuleGroupAssociationResponse {
    FirewallRuleGroupAssociation?: FirewallRuleGroupAssociation | undefined;
}
export interface GetFirewallRuleGroupPolicyRequest {
    Arn: string;
}
export type FirewallRuleGroupPolicy = string;
export interface GetFirewallRuleGroupPolicyResponse {
    FirewallRuleGroupPolicy?: string | undefined;
}
export interface GetOutpostResolverRequest {
    Id: string;
}
export interface GetOutpostResolverResponse {
    OutpostResolver?: OutpostResolver | undefined;
}
export interface GetResolverConfigRequest {
    ResourceId: string;
}
export type ResolverAutodefinedReverseStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | "UPDATING_TO_USE_LOCAL_RESOURCE_SETTING" | "USE_LOCAL_RESOURCE_SETTING" | (string & {});
export interface ResolverConfig {
    Id?: string | undefined;
    ResourceId?: string | undefined;
    OwnerId?: string | undefined;
    AutodefinedReverse?: ResolverAutodefinedReverseStatus | undefined;
}
export interface GetResolverConfigResponse {
    ResolverConfig?: ResolverConfig | undefined;
}
export interface GetResolverDnssecConfigRequest {
    ResourceId: string;
}
export type ResolverDNSSECValidationStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | "UPDATING_TO_USE_LOCAL_RESOURCE_SETTING" | "USE_LOCAL_RESOURCE_SETTING" | (string & {});
export interface ResolverDnssecConfig {
    Id?: string | undefined;
    OwnerId?: string | undefined;
    ResourceId?: string | undefined;
    ValidationStatus?: ResolverDNSSECValidationStatus | undefined;
}
export interface GetResolverDnssecConfigResponse {
    ResolverDNSSECConfig?: ResolverDnssecConfig | undefined;
}
export interface GetResolverEndpointRequest {
    ResolverEndpointId: string;
}
export interface GetResolverEndpointResponse {
    ResolverEndpoint?: ResolverEndpoint | undefined;
}
export interface GetResolverQueryLogConfigRequest {
    ResolverQueryLogConfigId: string;
}
export interface GetResolverQueryLogConfigResponse {
    ResolverQueryLogConfig?: ResolverQueryLogConfig | undefined;
}
export interface GetResolverQueryLogConfigAssociationRequest {
    ResolverQueryLogConfigAssociationId: string;
}
export interface GetResolverQueryLogConfigAssociationResponse {
    ResolverQueryLogConfigAssociation?: ResolverQueryLogConfigAssociation | undefined;
}
export interface GetResolverQueryLogConfigPolicyRequest {
    Arn: string;
}
export type ResolverQueryLogConfigPolicy = string;
export interface GetResolverQueryLogConfigPolicyResponse {
    ResolverQueryLogConfigPolicy?: string | undefined;
}
export interface GetResolverRuleRequest {
    ResolverRuleId: string;
}
export interface GetResolverRuleResponse {
    ResolverRule?: ResolverRule | undefined;
}
export interface GetResolverRuleAssociationRequest {
    ResolverRuleAssociationId: string;
}
export interface GetResolverRuleAssociationResponse {
    ResolverRuleAssociation?: ResolverRuleAssociation | undefined;
}
export interface GetResolverRulePolicyRequest {
    Arn: string;
}
export type ResolverRulePolicy = string;
export interface GetResolverRulePolicyResponse {
    ResolverRulePolicy?: string | undefined;
}
export type FirewallDomainImportOperation = "REPLACE" | (string & {});
export type DomainListFileUrl = string;
export interface ImportFirewallDomainsRequest {
    FirewallDomainListId: string;
    Operation: FirewallDomainImportOperation;
    DomainFileUrl: string;
}
export interface ImportFirewallDomainsResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Status?: FirewallDomainListStatus | undefined;
    StatusMessage?: string | undefined;
}
export type ListFirewallConfigsMaxResult = number;
export type NextToken = string;
export interface ListFirewallConfigsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type FirewallConfigList = FirewallConfig[];
export interface ListFirewallConfigsResponse {
    NextToken?: string | undefined;
    FirewallConfigs?: FirewallConfig[] | undefined;
}
export type MaxResults = number;
export interface ListFirewallDomainListsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface FirewallDomainListMetadata {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    CreatorRequestId?: string | undefined;
    ManagedOwnerName?: string | undefined;
    ManagedListType?: DomainListType | undefined;
    Category?: string | undefined;
}
export type FirewallDomainListMetadataList = FirewallDomainListMetadata[];
export interface ListFirewallDomainListsResponse {
    NextToken?: string | undefined;
    FirewallDomainLists?: FirewallDomainListMetadata[] | undefined;
}
export type ListDomainMaxResults = number;
export interface ListFirewallDomainsRequest {
    FirewallDomainListId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type FirewallDomainName = string;
export type FirewallDomains = string[];
export interface ListFirewallDomainsResponse {
    NextToken?: string | undefined;
    Domains?: string[] | undefined;
}
export interface ListFirewallRuleGroupAssociationsRequest {
    FirewallRuleGroupId?: string | undefined;
    VpcId?: string | undefined;
    Priority?: number | undefined;
    Status?: FirewallRuleGroupAssociationStatus | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type FirewallRuleGroupAssociations = FirewallRuleGroupAssociation[];
export interface ListFirewallRuleGroupAssociationsResponse {
    NextToken?: string | undefined;
    FirewallRuleGroupAssociations?: FirewallRuleGroupAssociation[] | undefined;
}
export interface ListFirewallRuleGroupsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface FirewallRuleGroupMetadata {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    OwnerId?: string | undefined;
    CreatorRequestId?: string | undefined;
    ShareStatus?: ShareStatus | undefined;
}
export type FirewallRuleGroupMetadataList = FirewallRuleGroupMetadata[];
export interface ListFirewallRuleGroupsResponse {
    NextToken?: string | undefined;
    FirewallRuleGroups?: FirewallRuleGroupMetadata[] | undefined;
}
export interface ListFirewallRulesRequest {
    FirewallRuleGroupId: string;
    Priority?: number | undefined;
    Action?: Action | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListFirewallRulesResponse {
    NextToken?: string | undefined;
    FirewallRules?: FirewallRule[] | undefined;
}
export type RuleTypeName = string;
export interface ListFirewallRuleTypesRequest {
    RuleType?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type RuleTypeValue = string;
export type DisplayName = string;
export type RuleTypeDescription = string;
export type VendorName = string;
export type ProductId = string;
export interface SubscriptionInfo {
    VendorName?: string | undefined;
    ProductId?: string | undefined;
}
export interface FirewallRuleTypeDefinition {
    RuleType?: string | undefined;
    Value?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    SubscriptionInfo?: SubscriptionInfo | undefined;
}
export type FirewallRuleTypeDefinitions = FirewallRuleTypeDefinition[];
export interface ListFirewallRuleTypesResponse {
    FirewallRuleTypes?: FirewallRuleTypeDefinition[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOutpostResolversRequest {
    OutpostArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type OutpostResolverList = OutpostResolver[];
export interface ListOutpostResolversResponse {
    OutpostResolvers?: OutpostResolver[] | undefined;
    NextToken?: string | undefined;
}
export type ListResolverConfigsMaxResult = number;
export interface ListResolverConfigsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ResolverConfigList = ResolverConfig[];
export interface ListResolverConfigsResponse {
    NextToken?: string | undefined;
    ResolverConfigs?: ResolverConfig[] | undefined;
}
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type Filters = Filter[];
export interface ListResolverDnssecConfigsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type ResolverDnssecConfigList = ResolverDnssecConfig[];
export interface ListResolverDnssecConfigsResponse {
    NextToken?: string | undefined;
    ResolverDnssecConfigs?: ResolverDnssecConfig[] | undefined;
}
export interface ListResolverEndpointIpAddressesRequest {
    ResolverEndpointId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type IpAddressStatus = "CREATING" | "FAILED_CREATION" | "FAILED_CREATION_INSUFFICIENT_EC2_CAPACITY_IN_OUTPOST" | "ATTACHING" | "ATTACHED" | "REMAP_DETACHING" | "REMAP_ATTACHING" | "DETACHING" | "FAILED_RESOURCE_GONE" | "DELETING" | "DELETE_FAILED_FAS_EXPIRED" | "UPDATING" | "UPDATE_FAILED" | "ISOLATED" | (string & {});
export interface IpAddressResponse {
    IpId?: string | undefined;
    SubnetId?: string | undefined;
    Ip?: string | undefined;
    Ipv6?: string | undefined;
    Status?: IpAddressStatus | undefined;
    StatusMessage?: string | undefined;
    CreationTime?: string | undefined;
    ModificationTime?: string | undefined;
}
export type IpAddressesResponse = IpAddressResponse[];
export interface ListResolverEndpointIpAddressesResponse {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    IpAddresses?: IpAddressResponse[] | undefined;
}
export interface ListResolverEndpointsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type ResolverEndpoints = ResolverEndpoint[];
export interface ListResolverEndpointsResponse {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ResolverEndpoints?: ResolverEndpoint[] | undefined;
}
export type SortByKey = string;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface ListResolverQueryLogConfigAssociationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
    SortBy?: string | undefined;
    SortOrder?: SortOrder | undefined;
}
export type ResolverQueryLogConfigAssociationList = ResolverQueryLogConfigAssociation[];
export interface ListResolverQueryLogConfigAssociationsResponse {
    NextToken?: string | undefined;
    TotalCount?: number | undefined;
    TotalFilteredCount?: number | undefined;
    ResolverQueryLogConfigAssociations?: ResolverQueryLogConfigAssociation[] | undefined;
}
export interface ListResolverQueryLogConfigsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
    SortBy?: string | undefined;
    SortOrder?: SortOrder | undefined;
}
export type ResolverQueryLogConfigList = ResolverQueryLogConfig[];
export interface ListResolverQueryLogConfigsResponse {
    NextToken?: string | undefined;
    TotalCount?: number | undefined;
    TotalFilteredCount?: number | undefined;
    ResolverQueryLogConfigs?: ResolverQueryLogConfig[] | undefined;
}
export interface ListResolverRuleAssociationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type ResolverRuleAssociations = ResolverRuleAssociation[];
export interface ListResolverRuleAssociationsResponse {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ResolverRuleAssociations?: ResolverRuleAssociation[] | undefined;
}
export interface ListResolverRulesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type ResolverRules = ResolverRule[];
export interface ListResolverRulesResponse {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ResolverRules?: ResolverRule[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
    NextToken?: string | undefined;
}
export interface PutFirewallRuleGroupPolicyRequest {
    Arn: string;
    FirewallRuleGroupPolicy: string;
}
export interface PutFirewallRuleGroupPolicyResponse {
    ReturnValue?: boolean | undefined;
}
export interface PutResolverQueryLogConfigPolicyRequest {
    Arn: string;
    ResolverQueryLogConfigPolicy: string;
}
export interface PutResolverQueryLogConfigPolicyResponse {
    ReturnValue?: boolean | undefined;
}
export interface PutResolverRulePolicyRequest {
    Arn: string;
    ResolverRulePolicy: string;
}
export interface PutResolverRulePolicyResponse {
    ReturnValue?: boolean | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateFirewallConfigRequest {
    ResourceId: string;
    FirewallFailOpen: FirewallFailOpenStatus;
}
export interface UpdateFirewallConfigResponse {
    FirewallConfig?: FirewallConfig | undefined;
}
export type FirewallDomainUpdateOperation = "ADD" | "REMOVE" | "REPLACE" | (string & {});
export interface UpdateFirewallDomainsRequest {
    FirewallDomainListId: string;
    Operation: FirewallDomainUpdateOperation;
    Domains: string[];
}
export interface UpdateFirewallDomainsResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Status?: FirewallDomainListStatus | undefined;
    StatusMessage?: string | undefined;
}
export interface UpdateFirewallRuleRequest {
    FirewallRuleGroupId: string;
    FirewallDomainListId?: string | undefined;
    FirewallThreatProtectionId?: string | undefined;
    Priority?: number | undefined;
    Action?: Action | undefined;
    BlockResponse?: BlockResponse | undefined;
    BlockOverrideDomain?: string | undefined;
    BlockOverrideDnsType?: BlockOverrideDnsType | undefined;
    BlockOverrideTtl?: number | undefined;
    Name?: string | undefined;
    FirewallDomainRedirectionAction?: FirewallDomainRedirectionAction | undefined;
    Qtype?: string | undefined;
    DnsThreatProtection?: DnsThreatProtection | undefined;
    ConfidenceThreshold?: ConfidenceThreshold | undefined;
    FirewallRuleType?: FirewallRuleType | undefined;
}
export interface UpdateFirewallRuleResponse {
    FirewallRule?: FirewallRule | undefined;
}
export interface UpdateFirewallRuleGroupAssociationRequest {
    FirewallRuleGroupAssociationId: string;
    Priority?: number | undefined;
    MutationProtection?: MutationProtectionStatus | undefined;
    Name?: string | undefined;
}
export interface UpdateFirewallRuleGroupAssociationResponse {
    FirewallRuleGroupAssociation?: FirewallRuleGroupAssociation | undefined;
}
export interface UpdateOutpostResolverRequest {
    Id: string;
    Name?: string | undefined;
    InstanceCount?: number | undefined;
    PreferredInstanceType?: string | undefined;
}
export interface UpdateOutpostResolverResponse {
    OutpostResolver?: OutpostResolver | undefined;
}
export type AutodefinedReverseFlag = "ENABLE" | "DISABLE" | "USE_LOCAL_RESOURCE_SETTING" | (string & {});
export interface UpdateResolverConfigRequest {
    ResourceId: string;
    AutodefinedReverseFlag: AutodefinedReverseFlag;
}
export interface UpdateResolverConfigResponse {
    ResolverConfig?: ResolverConfig | undefined;
}
export type Validation = "ENABLE" | "DISABLE" | "USE_LOCAL_RESOURCE_SETTING" | (string & {});
export interface UpdateResolverDnssecConfigRequest {
    ResourceId: string;
    Validation: Validation;
}
export interface UpdateResolverDnssecConfigResponse {
    ResolverDNSSECConfig?: ResolverDnssecConfig | undefined;
}
export interface UpdateIpAddress {
    IpId: string;
    Ipv6: string;
}
export type UpdateIpAddresses = UpdateIpAddress[];
export interface UpdateResolverEndpointRequest {
    ResolverEndpointId: string;
    Name?: string | undefined;
    ResolverEndpointType?: ResolverEndpointType | undefined;
    UpdateIpAddresses?: UpdateIpAddress[] | undefined;
    Protocols?: Protocol[] | undefined;
    RniEnhancedMetricsEnabled?: boolean | undefined;
    TargetNameServerMetricsEnabled?: boolean | undefined;
    Dns64Enabled?: boolean | undefined;
    Ipv6InternetAccessEnabled?: boolean | undefined;
}
export interface UpdateResolverEndpointResponse {
    ResolverEndpoint?: ResolverEndpoint | undefined;
}
export interface ResolverRuleConfig {
    Name?: string | undefined;
    TargetIps?: TargetAddress[] | undefined;
    ResolverEndpointId?: string | undefined;
}
export interface UpdateResolverRuleRequest {
    ResolverRuleId: string;
    Config: ResolverRuleConfig;
}
export interface UpdateResolverRuleResponse {
    ResolverRule?: ResolverRule | undefined;
}
export type ExceptionMessage = string;
export type AssociateFirewallRuleGroupError = AccessDeniedException | ConflictException | InternalServiceErrorException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a FirewallRuleGroup with a VPC, to provide DNS filtering for the VPC.
 *
 * If the rule group contains any rule configured with the `PartnerThreatProtection` rule type, the calling account must hold an active Amazon Web Services Marketplace subscription to the named partner. If the subscription is missing, the association request is rejected.
 */
export declare const associateFirewallRuleGroup: API.OperationMethod<AssociateFirewallRuleGroupRequest & RegionInput, AssociateFirewallRuleGroupResponse, AssociateFirewallRuleGroupError, Credentials | HttpClient.HttpClient>;
export type AssociateResolverEndpointIpAddressError = InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds IP addresses to an inbound or an outbound Resolver endpoint. If you want to add more than one IP address,
 * submit one `AssociateResolverEndpointIpAddress` request for each IP address.
 *
 * To remove an IP address from an endpoint, see
 * DisassociateResolverEndpointIpAddress.
 */
export declare const associateResolverEndpointIpAddress: API.OperationMethod<AssociateResolverEndpointIpAddressRequest & RegionInput, AssociateResolverEndpointIpAddressResponse, AssociateResolverEndpointIpAddressError, Credentials | HttpClient.HttpClient>;
export type AssociateResolverQueryLogConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates an Amazon VPC with a specified query logging configuration. Route 53 Resolver logs DNS queries that originate in all of the Amazon VPCs
 * that are associated with a specified query logging configuration. To associate more than one VPC with a configuration, submit one `AssociateResolverQueryLogConfig`
 * request for each VPC.
 *
 * The VPCs that you associate with a query logging configuration must be in the same Region as the configuration.
 *
 * To remove a VPC from a query logging configuration, see
 * DisassociateResolverQueryLogConfig.
 */
export declare const associateResolverQueryLogConfig: API.OperationMethod<AssociateResolverQueryLogConfigRequest & RegionInput, AssociateResolverQueryLogConfigResponse, AssociateResolverQueryLogConfigError, Credentials | HttpClient.HttpClient>;
export type AssociateResolverRuleError = InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Associates a Resolver rule with a VPC. When you associate a rule with a VPC, Resolver forwards all DNS queries
 * for the domain name that is specified in the rule and that originate in the VPC. The queries are forwarded to the
 * IP addresses for the DNS resolvers that are specified in the rule. For more information about rules, see
 * CreateResolverRule.
 */
export declare const associateResolverRule: API.OperationMethod<AssociateResolverRuleRequest & RegionInput, AssociateResolverRuleResponse, AssociateResolverRuleError, Credentials | HttpClient.HttpClient>;
export type BatchCreateFirewallRuleError = AccessDeniedException | InternalServiceErrorException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates multiple DNS Firewall rules in the specified rule group.
 */
export declare const batchCreateFirewallRule: API.OperationMethod<BatchCreateFirewallRuleRequest & RegionInput, BatchCreateFirewallRuleResponse, BatchCreateFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteFirewallRuleError = AccessDeniedException | InternalServiceErrorException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes multiple DNS Firewall rules from the specified rule group.
 */
export declare const batchDeleteFirewallRule: API.OperationMethod<BatchDeleteFirewallRuleRequest & RegionInput, BatchDeleteFirewallRuleResponse, BatchDeleteFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateFirewallRuleError = AccessDeniedException | InternalServiceErrorException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates multiple DNS Firewall rules in the specified rule group.
 */
export declare const batchUpdateFirewallRule: API.OperationMethod<BatchUpdateFirewallRuleRequest & RegionInput, BatchUpdateFirewallRuleResponse, BatchUpdateFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type CreateFirewallDomainListError = AccessDeniedException | InternalServiceErrorException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an empty firewall domain list for use in DNS Firewall rules. You can populate the domains for the new list with a file, using ImportFirewallDomains, or with domain strings, using UpdateFirewallDomains.
 */
export declare const createFirewallDomainList: API.OperationMethod<CreateFirewallDomainListRequest & RegionInput, CreateFirewallDomainListResponse, CreateFirewallDomainListError, Credentials | HttpClient.HttpClient>;
export type CreateFirewallRuleError = AccessDeniedException | InternalServiceErrorException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a single DNS Firewall rule in the specified rule group. The rule can use any one of the following match sources, and the chosen source must be supplied through the matching request field -- they are mutually exclusive:
 *
 * - `FirewallDomainListId` -- match a customer-managed or Amazon Web Services-managed domain list.
 *
 * - `DnsThreatProtection` -- match a built-in DNS Firewall Advanced threat detector (`DGA`, `DNS_TUNNELING`, or `DICTIONARY_DGA`).
 *
 * - `FirewallRuleType` -- match one of the rule-type variants returned by ListFirewallRuleTypes: `FirewallAdvancedContentCategory`, `FirewallAdvancedThreatCategory`, `DnsThreatProtection`, or `PartnerThreatProtection`. The `PartnerThreatProtection` variant requires an active Amazon Web Services Marketplace subscription to the named partner product.
 *
 * For rules that require asynchronous provisioning (today, the `PartnerThreatProtection` rule type), the rule's `Status` begins at `CREATING` and transitions to `COMPLETE` once the rule is provisioned and the marketplace entitlement is verified. If provisioning fails, `Status` becomes `CREATION_FAILED` and `StatusMessage` contains a human-readable reason; the rule is then immutable and must be removed with DeleteFirewallRule.
 */
export declare const createFirewallRule: API.OperationMethod<CreateFirewallRuleRequest & RegionInput, CreateFirewallRuleResponse, CreateFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type CreateFirewallRuleGroupError = AccessDeniedException | InternalServiceErrorException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an empty DNS Firewall rule group for filtering DNS network traffic in a VPC. You can add rules to the new rule group
 * by calling CreateFirewallRule.
 */
export declare const createFirewallRuleGroup: API.OperationMethod<CreateFirewallRuleGroupRequest & RegionInput, CreateFirewallRuleGroupResponse, CreateFirewallRuleGroupError, Credentials | HttpClient.HttpClient>;
export type CreateOutpostResolverError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Route 53 Resolver on an Outpost.
 *
 * This operation applies to first-generation Outposts only. On second-generation Outposts, Resolver
 * is enabled by default and managed automatically by Amazon Web Services, so you don't need to create it.
 */
export declare const createOutpostResolver: API.OperationMethod<CreateOutpostResolverRequest & RegionInput, CreateOutpostResolverResponse, CreateOutpostResolverError, Credentials | HttpClient.HttpClient>;
export type CreateResolverEndpointError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a Resolver endpoint. There are two types of Resolver endpoints, inbound and outbound:
 *
 * - An *inbound Resolver endpoint* forwards DNS queries to the DNS service for a VPC
 * from your network.
 *
 * - An *outbound Resolver endpoint* forwards DNS queries from the DNS service for a VPC
 * to your network.
 */
export declare const createResolverEndpoint: API.OperationMethod<CreateResolverEndpointRequest & RegionInput, CreateResolverEndpointResponse, CreateResolverEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateResolverQueryLogConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a Resolver query logging configuration, which defines where you want Resolver to save DNS query logs that originate in your VPCs.
 * Resolver can log queries only for VPCs that are in the same Region as the query logging configuration.
 *
 * To specify which VPCs you want to log queries for, you use `AssociateResolverQueryLogConfig`. For more information, see
 * AssociateResolverQueryLogConfig.
 *
 * You can optionally use Resource Access Manager (RAM) to share a query logging configuration with other Amazon Web Services accounts. The other accounts
 * can then associate VPCs with the configuration. The query logs that Resolver creates for a configuration include all DNS queries that originate in all
 * VPCs that are associated with the configuration.
 */
export declare const createResolverQueryLogConfig: API.OperationMethod<CreateResolverQueryLogConfigRequest & RegionInput, CreateResolverQueryLogConfigResponse, CreateResolverQueryLogConfigError, Credentials | HttpClient.HttpClient>;
export type CreateResolverRuleError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * For DNS queries that originate in your VPCs, specifies which Resolver endpoint the queries pass through,
 * one domain name that you want to forward to your network, and the IP addresses of the DNS resolvers in your network.
 */
export declare const createResolverRule: API.OperationMethod<CreateResolverRuleRequest & RegionInput, CreateResolverRuleResponse, CreateResolverRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallDomainListError = AccessDeniedException | ConflictException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified domain list.
 */
export declare const deleteFirewallDomainList: API.OperationMethod<DeleteFirewallDomainListRequest & RegionInput, DeleteFirewallDomainListResponse, DeleteFirewallDomainListError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallRuleError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified firewall rule. Identify the rule using either `FirewallDomainListId` (for domain-list and DNS Firewall Advanced rules) or `FirewallThreatProtectionId` (for partner-managed and DNS Firewall Advanced rules) -- together with `FirewallRuleGroupId`.
 *
 * `DeleteFirewallRule` is the only operation that succeeds against a rule whose `Status` is `CREATION_FAILED`.
 */
export declare const deleteFirewallRule: API.OperationMethod<DeleteFirewallRuleRequest & RegionInput, DeleteFirewallRuleResponse, DeleteFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallRuleGroupError = AccessDeniedException | ConflictException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified firewall rule group.
 */
export declare const deleteFirewallRuleGroup: API.OperationMethod<DeleteFirewallRuleGroupRequest & RegionInput, DeleteFirewallRuleGroupResponse, DeleteFirewallRuleGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteOutpostResolverError = AccessDeniedException | ConflictException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Resolver on the Outpost.
 *
 * This operation applies to first-generation Outposts only. On second-generation Outposts, Resolver
 * is managed automatically by Amazon Web Services and can't be deleted directly. To opt out of Resolver on
 * second-generation Outposts, contact Amazon Web Services Support.
 */
export declare const deleteOutpostResolver: API.OperationMethod<DeleteOutpostResolverRequest & RegionInput, DeleteOutpostResolverResponse, DeleteOutpostResolverError, Credentials | HttpClient.HttpClient>;
export type DeleteResolverEndpointError = InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a Resolver endpoint. The effect of deleting a Resolver endpoint depends on whether it's an inbound or an outbound
 * Resolver endpoint:
 *
 * - **Inbound**: DNS queries from your network are no longer routed
 * to the DNS service for the specified VPC.
 *
 * - **Outbound**: DNS queries from a VPC are no longer routed to your network.
 */
export declare const deleteResolverEndpoint: API.OperationMethod<DeleteResolverEndpointRequest & RegionInput, DeleteResolverEndpointResponse, DeleteResolverEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteResolverQueryLogConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a query logging configuration. When you delete a configuration, Resolver stops logging DNS queries for all of the Amazon VPCs that are
 * associated with the configuration. This also applies if the query logging configuration is shared with other Amazon Web Services accounts, and
 * the other accounts have associated VPCs with the shared configuration.
 *
 * Before you can delete a query logging configuration, you must first disassociate all VPCs from the configuration. See
 * DisassociateResolverQueryLogConfig.
 *
 * If you used Resource Access Manager (RAM) to share a query logging configuration with other accounts, you must stop sharing
 * the configuration before you can delete a configuration. The accounts that you shared the configuration with can first disassociate VPCs
 * that they associated with the configuration, but that's not necessary. If you stop sharing the configuration, those VPCs are automatically
 * disassociated from the configuration.
 */
export declare const deleteResolverQueryLogConfig: API.OperationMethod<DeleteResolverQueryLogConfigRequest & RegionInput, DeleteResolverQueryLogConfigResponse, DeleteResolverQueryLogConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteResolverRuleError = InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a Resolver rule. Before you can delete a Resolver rule, you must disassociate it from all the VPCs that you
 * associated the Resolver rule with. For more information, see
 * DisassociateResolverRule.
 */
export declare const deleteResolverRule: API.OperationMethod<DeleteResolverRuleRequest & RegionInput, DeleteResolverRuleResponse, DeleteResolverRuleError, Credentials | HttpClient.HttpClient>;
export type DisassociateFirewallRuleGroupError = AccessDeniedException | ConflictException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a FirewallRuleGroup from a VPC, to remove DNS filtering from the VPC.
 */
export declare const disassociateFirewallRuleGroup: API.OperationMethod<DisassociateFirewallRuleGroupRequest & RegionInput, DisassociateFirewallRuleGroupResponse, DisassociateFirewallRuleGroupError, Credentials | HttpClient.HttpClient>;
export type DisassociateResolverEndpointIpAddressError = InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes IP addresses from an inbound or an outbound Resolver endpoint. If you want to remove more than one IP address,
 * submit one `DisassociateResolverEndpointIpAddress` request for each IP address.
 *
 * To add an IP address to an endpoint, see
 * AssociateResolverEndpointIpAddress.
 */
export declare const disassociateResolverEndpointIpAddress: API.OperationMethod<DisassociateResolverEndpointIpAddressRequest & RegionInput, DisassociateResolverEndpointIpAddressResponse, DisassociateResolverEndpointIpAddressError, Credentials | HttpClient.HttpClient>;
export type DisassociateResolverQueryLogConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a VPC from a query logging configuration.
 *
 * Before you can delete a query logging configuration, you must first disassociate all VPCs
 * from the configuration. If you used Resource Access Manager (RAM) to share a
 * query logging configuration with other accounts, VPCs can be disassociated from the
 * configuration in the following ways:
 *
 * - The accounts that you shared the configuration with can disassociate VPCs from the configuration.
 *
 * - You can stop sharing the configuration.
 */
export declare const disassociateResolverQueryLogConfig: API.OperationMethod<DisassociateResolverQueryLogConfigRequest & RegionInput, DisassociateResolverQueryLogConfigResponse, DisassociateResolverQueryLogConfigError, Credentials | HttpClient.HttpClient>;
export type DisassociateResolverRuleError = InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the association between a specified Resolver rule and a specified VPC.
 *
 * If you disassociate a Resolver rule from a VPC, Resolver stops forwarding DNS queries for the
 * domain name that you specified in the Resolver rule.
 */
export declare const disassociateResolverRule: API.OperationMethod<DisassociateResolverRuleRequest & RegionInput, DisassociateResolverRuleResponse, DisassociateResolverRuleError, Credentials | HttpClient.HttpClient>;
export type GetFirewallConfigError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration of the firewall behavior provided by DNS Firewall for a
 * single VPC from Amazon Virtual Private Cloud (Amazon VPC).
 */
export declare const getFirewallConfig: API.OperationMethod<GetFirewallConfigRequest & RegionInput, GetFirewallConfigResponse, GetFirewallConfigError, Credentials | HttpClient.HttpClient>;
export type GetFirewallDomainListError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the specified firewall domain list.
 */
export declare const getFirewallDomainList: API.OperationMethod<GetFirewallDomainListRequest & RegionInput, GetFirewallDomainListResponse, GetFirewallDomainListError, Credentials | HttpClient.HttpClient>;
export type GetFirewallRuleGroupError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the specified firewall rule group.
 */
export declare const getFirewallRuleGroup: API.OperationMethod<GetFirewallRuleGroupRequest & RegionInput, GetFirewallRuleGroupResponse, GetFirewallRuleGroupError, Credentials | HttpClient.HttpClient>;
export type GetFirewallRuleGroupAssociationError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a firewall rule group association, which enables DNS filtering for a VPC with one rule group. A VPC can have more than one firewall rule group association, and a rule group can be associated with more than one VPC.
 */
export declare const getFirewallRuleGroupAssociation: API.OperationMethod<GetFirewallRuleGroupAssociationRequest & RegionInput, GetFirewallRuleGroupAssociationResponse, GetFirewallRuleGroupAssociationError, Credentials | HttpClient.HttpClient>;
export type GetFirewallRuleGroupPolicyError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the Identity and Access Management (Amazon Web Services IAM) policy for sharing the
 * specified rule group. You can use the policy to share the rule group using Resource Access Manager (RAM).
 */
export declare const getFirewallRuleGroupPolicy: API.OperationMethod<GetFirewallRuleGroupPolicyRequest & RegionInput, GetFirewallRuleGroupPolicyResponse, GetFirewallRuleGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type GetOutpostResolverError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specified Resolver on the Outpost, such as its instance count and
 * type, name, and the current status of the Resolver.
 */
export declare const getOutpostResolver: API.OperationMethod<GetOutpostResolverRequest & RegionInput, GetOutpostResolverResponse, GetOutpostResolverError, Credentials | HttpClient.HttpClient>;
export type GetResolverConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the behavior configuration of Route 53 Resolver behavior for a single VPC from
 * Amazon Virtual Private Cloud.
 */
export declare const getResolverConfig: API.OperationMethod<GetResolverConfigRequest & RegionInput, GetResolverConfigResponse, GetResolverConfigError, Credentials | HttpClient.HttpClient>;
export type GetResolverDnssecConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets DNSSEC validation information for a specified resource.
 */
export declare const getResolverDnssecConfig: API.OperationMethod<GetResolverDnssecConfigRequest & RegionInput, GetResolverDnssecConfigResponse, GetResolverDnssecConfigError, Credentials | HttpClient.HttpClient>;
export type GetResolverEndpointError = InternalServiceErrorException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets information about a specified Resolver endpoint, such as whether it's an inbound or an outbound Resolver endpoint, and the
 * current status of the endpoint.
 */
export declare const getResolverEndpoint: API.OperationMethod<GetResolverEndpointRequest & RegionInput, GetResolverEndpointResponse, GetResolverEndpointError, Credentials | HttpClient.HttpClient>;
export type GetResolverQueryLogConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets information about a specified Resolver query logging configuration, such as the number of VPCs that the configuration
 * is logging queries for and the location that logs are sent to.
 */
export declare const getResolverQueryLogConfig: API.OperationMethod<GetResolverQueryLogConfigRequest & RegionInput, GetResolverQueryLogConfigResponse, GetResolverQueryLogConfigError, Credentials | HttpClient.HttpClient>;
export type GetResolverQueryLogConfigAssociationError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets information about a specified association between a Resolver query logging configuration and an Amazon VPC. When you associate a VPC
 * with a query logging configuration, Resolver logs DNS queries that originate in that VPC.
 */
export declare const getResolverQueryLogConfigAssociation: API.OperationMethod<GetResolverQueryLogConfigAssociationRequest & RegionInput, GetResolverQueryLogConfigAssociationResponse, GetResolverQueryLogConfigAssociationError, Credentials | HttpClient.HttpClient>;
export type GetResolverQueryLogConfigPolicyError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | UnknownResourceException | CommonErrors;
/**
 * Gets information about a query logging policy. A query logging policy specifies the Resolver query logging
 * operations and resources that you want to allow another Amazon Web Services account to be able to use.
 */
export declare const getResolverQueryLogConfigPolicy: API.OperationMethod<GetResolverQueryLogConfigPolicyRequest & RegionInput, GetResolverQueryLogConfigPolicyResponse, GetResolverQueryLogConfigPolicyError, Credentials | HttpClient.HttpClient>;
export type GetResolverRuleError = InternalServiceErrorException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets information about a specified Resolver rule, such as the domain name that the rule forwards DNS queries for and the ID of the
 * outbound Resolver endpoint that the rule is associated with.
 */
export declare const getResolverRule: API.OperationMethod<GetResolverRuleRequest & RegionInput, GetResolverRuleResponse, GetResolverRuleError, Credentials | HttpClient.HttpClient>;
export type GetResolverRuleAssociationError = InternalServiceErrorException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets information about an association between a specified Resolver rule and a VPC. You associate a Resolver rule and a VPC using
 * AssociateResolverRule.
 */
export declare const getResolverRuleAssociation: API.OperationMethod<GetResolverRuleAssociationRequest & RegionInput, GetResolverRuleAssociationResponse, GetResolverRuleAssociationError, Credentials | HttpClient.HttpClient>;
export type GetResolverRulePolicyError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | UnknownResourceException | CommonErrors;
/**
 * Gets information about the Resolver rule policy for a specified rule. A Resolver rule policy includes the rule that you want to share
 * with another account, the account that you want to share the rule with, and the Resolver operations that you want to allow the account to use.
 */
export declare const getResolverRulePolicy: API.OperationMethod<GetResolverRulePolicyRequest & RegionInput, GetResolverRulePolicyResponse, GetResolverRulePolicyError, Credentials | HttpClient.HttpClient>;
export type ImportFirewallDomainsError = AccessDeniedException | ConflictException | InternalServiceErrorException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports domain names from a file into a domain list, for use in a DNS firewall rule group.
 *
 * Each domain specification in your domain list must satisfy the following
 * requirements:
 *
 * - It can optionally start with `*` (asterisk).
 *
 * - With the exception of the optional starting asterisk, it must only contain
 * the following characters: `A-Z`, `a-z`,
 * `0-9`, `-` (hyphen).
 *
 * - It must be from 1-255 characters in length.
 */
export declare const importFirewallDomains: API.OperationMethod<ImportFirewallDomainsRequest & RegionInput, ImportFirewallDomainsResponse, ImportFirewallDomainsError, Credentials | HttpClient.HttpClient>;
export type ListFirewallConfigsError = AccessDeniedException | InternalServiceErrorException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the firewall configurations that you have defined. DNS Firewall uses the configurations to manage firewall behavior for your VPCs.
 *
 * A single call might return only a partial list of the configurations. For information, see `MaxResults`.
 */
export declare const listFirewallConfigs: API.PaginatedOperationMethod<ListFirewallConfigsRequest & RegionInput, ListFirewallConfigsResponse, ListFirewallConfigsError, Credentials | HttpClient.HttpClient, FirewallConfig>;
export type ListFirewallDomainListsError = AccessDeniedException | InternalServiceErrorException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the firewall domain lists that you have defined. For each firewall domain list, you can retrieve the domains that are defined for a list by calling ListFirewallDomains.
 *
 * A single call to this list operation might return only a partial list of the domain lists. For information, see `MaxResults`.
 */
export declare const listFirewallDomainLists: API.PaginatedOperationMethod<ListFirewallDomainListsRequest & RegionInput, ListFirewallDomainListsResponse, ListFirewallDomainListsError, Credentials | HttpClient.HttpClient, FirewallDomainListMetadata>;
export type ListFirewallDomainsError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the domains that you have defined for the specified firewall domain list.
 *
 * A single call might return only a partial list of the domains. For information, see `MaxResults`.
 */
export declare const listFirewallDomains: API.PaginatedOperationMethod<ListFirewallDomainsRequest & RegionInput, ListFirewallDomainsResponse, ListFirewallDomainsError, Credentials | HttpClient.HttpClient, FirewallDomainName>;
export type ListFirewallRuleGroupAssociationsError = AccessDeniedException | InternalServiceErrorException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the firewall rule group associations that you have defined. Each association enables DNS filtering for a VPC with one rule group.
 *
 * A single call might return only a partial list of the associations. For information, see `MaxResults`.
 */
export declare const listFirewallRuleGroupAssociations: API.PaginatedOperationMethod<ListFirewallRuleGroupAssociationsRequest & RegionInput, ListFirewallRuleGroupAssociationsResponse, ListFirewallRuleGroupAssociationsError, Credentials | HttpClient.HttpClient, FirewallRuleGroupAssociation>;
export type ListFirewallRuleGroupsError = AccessDeniedException | InternalServiceErrorException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the minimal high-level information for the rule groups that you have defined.
 *
 * A single call might return only a partial list of the rule groups. For information, see `MaxResults`.
 */
export declare const listFirewallRuleGroups: API.PaginatedOperationMethod<ListFirewallRuleGroupsRequest & RegionInput, ListFirewallRuleGroupsResponse, ListFirewallRuleGroupsError, Credentials | HttpClient.HttpClient, FirewallRuleGroupMetadata>;
export type ListFirewallRulesError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the firewall rules that you have defined for the specified firewall rule group. DNS Firewall uses the rules in a rule group to filter DNS network traffic for a VPC.
 *
 * A single call might return only a partial list of the rules. For information, see `MaxResults`.
 *
 * For rules that require asynchronous provisioning, the response includes `Status` (see FirewallRuleStatus) and, on failure, `StatusMessage` with the reason.
 */
export declare const listFirewallRules: API.PaginatedOperationMethod<ListFirewallRulesRequest & RegionInput, ListFirewallRulesResponse, ListFirewallRulesError, Credentials | HttpClient.HttpClient, FirewallRule>;
export type ListFirewallRuleTypesError = AccessDeniedException | InternalServiceErrorException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the rule-type variants that can be used in the `FirewallRuleType` field of CreateFirewallRule and UpdateFirewallRule. Each returned FirewallRuleTypeDefinition identifies one variant + value combination -- for example, `FirewallAdvancedContentCategory` + `VIOLENCE_AND_HATE_SPEECH`, or `PartnerThreatProtection` + a partner-managed feed.
 *
 * The supported `RuleType` filter values are `FirewallAdvancedContentCategory`, `FirewallAdvancedThreatCategory`, `DnsThreatProtection`, and `PartnerThreatProtection`. When a returned definition's variant requires an external subscription (currently only `PartnerThreatProtection`), the response also includes a SubscriptionInfo identifying the Amazon Web Services Marketplace product that backs it; absence of `SubscriptionInfo` means the variant is fully managed by Amazon Web Services and requires no separate subscription.
 */
export declare const listFirewallRuleTypes: API.PaginatedOperationMethod<ListFirewallRuleTypesRequest & RegionInput, ListFirewallRuleTypesResponse, ListFirewallRuleTypesError, Credentials | HttpClient.HttpClient, FirewallRuleTypeDefinition>;
export type ListOutpostResolversError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the Resolvers on Outposts that were created using the current Amazon Web Services account.
 */
export declare const listOutpostResolvers: API.PaginatedOperationMethod<ListOutpostResolversRequest & RegionInput, ListOutpostResolversResponse, ListOutpostResolversError, Credentials | HttpClient.HttpClient, OutpostResolver>;
export type ListResolverConfigsError = AccessDeniedException | InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the Resolver configurations that you have defined.
 * Route 53 Resolver uses the configurations to manage DNS resolution behavior for your VPCs.
 */
export declare const listResolverConfigs: API.PaginatedOperationMethod<ListResolverConfigsRequest & RegionInput, ListResolverConfigsResponse, ListResolverConfigsError, Credentials | HttpClient.HttpClient, ResolverConfig>;
export type ListResolverDnssecConfigsError = AccessDeniedException | InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists the configurations for DNSSEC validation that are associated with the current Amazon Web Services account.
 */
export declare const listResolverDnssecConfigs: API.PaginatedOperationMethod<ListResolverDnssecConfigsRequest & RegionInput, ListResolverDnssecConfigsResponse, ListResolverDnssecConfigsError, Credentials | HttpClient.HttpClient, ResolverDnssecConfig>;
export type ListResolverEndpointIpAddressesError = InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the IP addresses for a specified Resolver endpoint.
 */
export declare const listResolverEndpointIpAddresses: API.PaginatedOperationMethod<ListResolverEndpointIpAddressesRequest & RegionInput, ListResolverEndpointIpAddressesResponse, ListResolverEndpointIpAddressesError, Credentials | HttpClient.HttpClient, IpAddressResponse>;
export type ListResolverEndpointsError = InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists all the Resolver endpoints that were created using the current Amazon Web Services account.
 */
export declare const listResolverEndpoints: API.PaginatedOperationMethod<ListResolverEndpointsRequest & RegionInput, ListResolverEndpointsResponse, ListResolverEndpointsError, Credentials | HttpClient.HttpClient, ResolverEndpoint>;
export type ListResolverQueryLogConfigAssociationsError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Lists information about associations between Amazon VPCs and query logging configurations.
 */
export declare const listResolverQueryLogConfigAssociations: API.PaginatedOperationMethod<ListResolverQueryLogConfigAssociationsRequest & RegionInput, ListResolverQueryLogConfigAssociationsResponse, ListResolverQueryLogConfigAssociationsError, Credentials | HttpClient.HttpClient, ResolverQueryLogConfigAssociation>;
export type ListResolverQueryLogConfigsError = AccessDeniedException | InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists information about the specified query logging configurations. Each configuration defines where you want Resolver to save
 * DNS query logs and specifies the VPCs that you want to log queries for.
 */
export declare const listResolverQueryLogConfigs: API.PaginatedOperationMethod<ListResolverQueryLogConfigsRequest & RegionInput, ListResolverQueryLogConfigsResponse, ListResolverQueryLogConfigsError, Credentials | HttpClient.HttpClient, ResolverQueryLogConfig>;
export type ListResolverRuleAssociationsError = InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists the associations that were created between Resolver rules and VPCs using the current Amazon Web Services account.
 */
export declare const listResolverRuleAssociations: API.PaginatedOperationMethod<ListResolverRuleAssociationsRequest & RegionInput, ListResolverRuleAssociationsResponse, ListResolverRuleAssociationsError, Credentials | HttpClient.HttpClient, ResolverRuleAssociation>;
export type ListResolverRulesError = InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists the Resolver rules that were created using the current Amazon Web Services account.
 */
export declare const listResolverRules: API.PaginatedOperationMethod<ListResolverRulesRequest & RegionInput, ListResolverRulesResponse, ListResolverRulesError, Credentials | HttpClient.HttpClient, ResolverRule>;
export type ListTagsForResourceError = InternalServiceErrorException | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the tags that you associated with the specified resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type PutFirewallRuleGroupPolicyError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches an Identity and Access Management (Amazon Web Services IAM) policy for sharing the rule
 * group. You can use the policy to share the rule group using Resource Access Manager
 * (RAM).
 */
export declare const putFirewallRuleGroupPolicy: API.OperationMethod<PutFirewallRuleGroupPolicyRequest & RegionInput, PutFirewallRuleGroupPolicyResponse, PutFirewallRuleGroupPolicyError, Credentials | HttpClient.HttpClient>;
export type PutResolverQueryLogConfigPolicyError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidPolicyDocument | InvalidRequestException | UnknownResourceException | CommonErrors;
/**
 * Specifies an Amazon Web Services account that you want to share a query logging configuration with, the query logging configuration that you want to share,
 * and the operations that you want the account to be able to perform on the configuration.
 */
export declare const putResolverQueryLogConfigPolicy: API.OperationMethod<PutResolverQueryLogConfigPolicyRequest & RegionInput, PutResolverQueryLogConfigPolicyResponse, PutResolverQueryLogConfigPolicyError, Credentials | HttpClient.HttpClient>;
export type PutResolverRulePolicyError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidPolicyDocument | UnknownResourceException | CommonErrors;
/**
 * Specifies an Amazon Web Services rule that you want to share with another account, the account that you want to share the rule with,
 * and the operations that you want the account to be able to perform on the rule.
 */
export declare const putResolverRulePolicy: API.OperationMethod<PutResolverRulePolicyRequest & RegionInput, PutResolverRulePolicyResponse, PutResolverRulePolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceErrorException | InvalidParameterException | InvalidRequestException | InvalidTagException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds one or more tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes one or more tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallConfigError = AccessDeniedException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of the firewall behavior provided by DNS Firewall for a single
 * VPC from Amazon Virtual Private Cloud (Amazon VPC).
 */
export declare const updateFirewallConfig: API.OperationMethod<UpdateFirewallConfigRequest & RegionInput, UpdateFirewallConfigResponse, UpdateFirewallConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallDomainsError = AccessDeniedException | ConflictException | InternalServiceErrorException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the firewall domain list from an array of domain specifications.
 */
export declare const updateFirewallDomains: API.OperationMethod<UpdateFirewallDomainsRequest & RegionInput, UpdateFirewallDomainsResponse, UpdateFirewallDomainsError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallRuleError = AccessDeniedException | ConflictException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified firewall rule. The rule's `FirewallRuleType`, `FirewallDomainListId`, and top-level `DnsThreatProtection` match source cannot be changed after creation. Rules whose `Status` is `CREATING` or `CREATION_FAILED` cannot be updated; remove a failed rule with DeleteFirewallRule.
 */
export declare const updateFirewallRule: API.OperationMethod<UpdateFirewallRuleRequest & RegionInput, UpdateFirewallRuleResponse, UpdateFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallRuleGroupAssociationError = AccessDeniedException | ConflictException | InternalServiceErrorException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes the association of a FirewallRuleGroup with a VPC. The association enables DNS filtering for the VPC.
 */
export declare const updateFirewallRuleGroupAssociation: API.OperationMethod<UpdateFirewallRuleGroupAssociationRequest & RegionInput, UpdateFirewallRuleGroupAssociationResponse, UpdateFirewallRuleGroupAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateOutpostResolverError = AccessDeniedException | ConflictException | InternalServiceErrorException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * You can use `UpdateOutpostResolver` to update the instance count, type, or name of a Resolver on an Outpost.
 *
 * This operation applies to first-generation Outposts only. On second-generation Outposts, Resolver
 * is managed automatically by Amazon Web Services and can't be updated directly.
 */
export declare const updateOutpostResolver: API.OperationMethod<UpdateOutpostResolverRequest & RegionInput, UpdateOutpostResolverResponse, UpdateOutpostResolverError, Credentials | HttpClient.HttpClient>;
export type UpdateResolverConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the behavior configuration of Route 53 Resolver behavior for a single VPC from
 * Amazon Virtual Private Cloud.
 */
export declare const updateResolverConfig: API.OperationMethod<UpdateResolverConfigRequest & RegionInput, UpdateResolverConfigResponse, UpdateResolverConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateResolverDnssecConfigError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing DNSSEC validation configuration. If there is no existing DNSSEC validation configuration, one is created.
 */
export declare const updateResolverDnssecConfig: API.OperationMethod<UpdateResolverDnssecConfigRequest & RegionInput, UpdateResolverDnssecConfigResponse, UpdateResolverDnssecConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateResolverEndpointError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name, or endpoint type for an inbound or an outbound Resolver endpoint.
 * You can only update between IPV4 and DUALSTACK, IPV6 endpoint type can't be updated to other type.
 */
export declare const updateResolverEndpoint: API.OperationMethod<UpdateResolverEndpointRequest & RegionInput, UpdateResolverEndpointResponse, UpdateResolverEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateResolverRuleError = AccessDeniedException | InternalServiceErrorException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates settings for a specified Resolver rule. `ResolverRuleId` is required, and all other parameters are optional.
 * If you don't specify a parameter, it retains its current value.
 */
export declare const updateResolverRule: API.OperationMethod<UpdateResolverRuleRequest & RegionInput, UpdateResolverRuleResponse, UpdateResolverRuleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=route53resolver.d.ts.map