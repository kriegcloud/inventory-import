import type { Kit, Model } from "../Kit.ts";
import type { Eval, V } from "../Value.ts";
/**
 * `Result`, and what of `Option` reads like it. Both are plain data: a tag
 * the prover always knows on a path, and the value under it.
 */
export declare const make: (kit: Kit) => {
    models: Readonly<Record<string, Model>>;
    values: Record<string, V>;
    yielded: (value: V) => Eval<V> | undefined;
};
//# sourceMappingURL=Results.d.ts.map