import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type InquiryName = string | redacted.Redacted<string>;
export type LongStringAttribute = string;
export type ShortStringAttribute = string;
export type FileSectionList = string[];
export interface InquiryFileContent {
    fileSections?: string[] | undefined;
    content: Uint8Array;
}
export type InquiryContent = {
    query: string;
    fileContent?: undefined;
} | {
    query?: undefined;
    fileContent: InquiryFileContent;
};
export type IdempotentClientToken = string;
export type InquirySupportMode = "AI_ONLY" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateComplianceInquiryRequest {
    name: string | redacted.Redacted<string>;
    inquiryContent: InquiryContent;
    clientToken?: string | undefined;
    supportMode?: InquirySupportMode | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type InquiryId = string;
export type InquiryStatus = "PROCESSING" | "HUMAN_REVIEW" | "COMPLETED" | "FAILED" | (string & {});
export type InquiryStatusMessage = "Compliance inquiry processing is complete." | "Malware was detected on the file. Provide a new file and try again." | "Compliance inquiry processing is in-progress." | "An internal error occurred while processing the inquiry. Try again at a later time." | "Human review is in progress." | "Compliance inquiry processing is complete. One or more queries encountered errors during processing." | (string & {});
export type InputSource = "TEXT" | "FILE" | (string & {});
export type TimestampAttribute = Date;
export interface InquirySummary {
    arn: string;
    name: string;
    id: string;
    status: InquiryStatus;
    statusMessage: InquiryStatusMessage;
    inputSource: InputSource;
    createdAt: Date;
}
export interface CreateComplianceInquiryResponse {
    complianceInquirySummary?: InquirySummary | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type QueryIdentifiersList = number[];
export interface ExportComplianceInquiryRequest {
    complianceInquiryId: string;
    queryIdentifiers?: number[] | undefined;
    includeCitations?: boolean | undefined;
}
export type PresignedUrl = string | redacted.Redacted<string>;
export interface ExportComplianceInquiryResponse {
    documentPresignedUrl?: string | redacted.Redacted<string> | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetAccountSettingsRequest {
}
export type NotificationSubscriptionStatus = "SUBSCRIBED" | "NOT_SUBSCRIBED" | (string & {});
export interface AccountSettings {
    notificationSubscriptionStatus?: NotificationSubscriptionStatus | undefined;
}
export interface GetAccountSettingsResponse {
    accountSettings?: AccountSettings | undefined;
}
export interface GetComplianceInquiryMetadataRequest {
    complianceInquiryId: string;
}
export interface InquiryDetail {
    arn: string;
    name: string;
    id: string;
    status: InquiryStatus;
    statusMessage: InquiryStatusMessage;
    inputSource: InputSource;
    createdAt: Date;
    updatedAt?: Date | undefined;
    supportMode?: InquirySupportMode | undefined;
}
export interface GetComplianceInquiryMetadataResponse {
    complianceInquiryDetail?: InquiryDetail | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ReportId = string;
export type VersionAttribute = number;
export interface GetReportRequest {
    reportId: string;
    reportVersion?: number | undefined;
    termToken: string;
}
export interface GetReportResponse {
    documentPresignedUrl?: string | undefined;
}
export interface GetReportMetadataRequest {
    reportId: string;
    reportVersion?: number | undefined;
}
export type PublishedState = "PUBLISHED" | "UNPUBLISHED" | (string & {});
export type AcceptanceType = "PASSTHROUGH" | "EXPLICIT" | (string & {});
export type SequenceNumberAttribute = number;
export type UploadState = "PROCESSING" | "COMPLETE" | "FAILED" | "FAULT" | (string & {});
export type StatusMessage = string;
export interface ReportDetail {
    id?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    periodStart?: Date | undefined;
    periodEnd?: Date | undefined;
    createdAt?: Date | undefined;
    lastModifiedAt?: Date | undefined;
    deletedAt?: Date | undefined;
    state?: PublishedState | undefined;
    arn?: string | undefined;
    series?: string | undefined;
    category?: string | undefined;
    companyName?: string | undefined;
    productName?: string | undefined;
    termArn?: string | undefined;
    version?: number | undefined;
    acceptanceType?: AcceptanceType | undefined;
    sequenceNumber?: number | undefined;
    uploadState?: UploadState | undefined;
    statusMessage?: string | undefined;
}
export interface GetReportMetadataResponse {
    reportDetails?: ReportDetail | undefined;
}
export interface GetTermForReportRequest {
    reportId: string;
    reportVersion?: number | undefined;
}
export interface GetTermForReportResponse {
    documentPresignedUrl?: string | undefined;
    termToken?: string | undefined;
}
export type MaxResultsAttribute = number;
export type NextTokenAttribute = string;
export interface ListComplianceInquiriesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type InquiriesList = InquirySummary[];
export interface ListComplianceInquiriesResponse {
    complianceInquiries?: InquirySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListComplianceInquiryQueriesRequest {
    complianceInquiryId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ReviewType = "HUMAN" | "AI" | (string & {});
export interface Citation {
    sourceLabel?: string | undefined;
    sourceContent?: string | undefined;
    sourceLink?: string | undefined;
}
export type CitationList = Citation[];
export type QueryStatus = "PROCESSING" | "COMPLETED" | "FAILED" | (string & {});
export type QueryStatusMessage = "Query processing is complete." | "Query processing is in-progress." | "An internal error occurred while processing the query. Try again at a later time." | "Query is pending human review." | "Query contains restricted or unsupported content." | (string & {});
export interface ResponseVersion {
    responseText: string;
    timestamp: Date;
}
export type ResponseVersionList = ResponseVersion[];
export interface QuerySummary {
    queryIdentifier: number;
    query: string;
    response?: string | undefined;
    reviewType?: ReviewType | undefined;
    citations?: Citation[] | undefined;
    status: QueryStatus;
    statusMessage: QueryStatusMessage;
    createdAt: Date;
    updatedResponseVersions?: ResponseVersion[] | undefined;
}
export type QueriesList = QuerySummary[];
export interface ListComplianceInquiryQueriesResponse {
    queries?: QuerySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCustomerAgreementsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type CustomerAgreementIdAttribute = string;
export type CustomerAgreementState = "ACTIVE" | "CUSTOMER_TERMINATED" | "AWS_TERMINATED" | (string & {});
export type AgreementTerms = string[];
export type AgreementType = "CUSTOM" | "DEFAULT" | "MODIFIED" | (string & {});
export interface CustomerAgreementSummary {
    name?: string | undefined;
    arn?: string | undefined;
    id?: string | undefined;
    agreementArn?: string | undefined;
    awsAccountId?: string | undefined;
    organizationArn?: string | undefined;
    effectiveStart?: Date | undefined;
    effectiveEnd?: Date | undefined;
    state?: CustomerAgreementState | undefined;
    description?: string | undefined;
    acceptanceTerms?: string[] | undefined;
    terminateTerms?: string[] | undefined;
    type?: AgreementType | undefined;
}
export type CustomerAgreementList = CustomerAgreementSummary[];
export interface ListCustomerAgreementsResponse {
    customerAgreements: CustomerAgreementSummary[];
    nextToken?: string | undefined;
}
export interface ListReportsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ReportSummary {
    id?: string | undefined;
    name?: string | undefined;
    state?: PublishedState | undefined;
    arn?: string | undefined;
    version?: number | undefined;
    uploadState?: UploadState | undefined;
    description?: string | undefined;
    periodStart?: Date | undefined;
    periodEnd?: Date | undefined;
    series?: string | undefined;
    category?: string | undefined;
    companyName?: string | undefined;
    productName?: string | undefined;
    statusMessage?: string | undefined;
    acceptanceType?: AcceptanceType | undefined;
}
export type ReportsList = ReportSummary[];
export interface ListReportsResponse {
    reports?: ReportSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListReportVersionsRequest {
    reportId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListReportVersionsResponse {
    reports: ReportSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutAccountSettingsRequest {
    notificationSubscriptionStatus?: NotificationSubscriptionStatus | undefined;
}
export interface PutAccountSettingsResponse {
    accountSettings?: AccountSettings | undefined;
}
export type FeedbackRating = "THUMBS_UP" | "THUMBS_DOWN" | (string & {});
export type FeedbackReasonCode = "OTHER" | "PARTIAL_RESPONSE" | "IRRELEVANT_RESPONSE" | (string & {});
export type FeedbackReasonCodeList = FeedbackReasonCode[];
export type FeedbackCommentAttribute = string | redacted.Redacted<string>;
export interface PutComplianceInquiryFeedbackRequest {
    complianceInquiryId: string;
    queryIdentifier?: number | undefined;
    rating: FeedbackRating;
    responseRevisionId?: number | undefined;
    reasonCodes?: FeedbackReasonCode[] | undefined;
    comment?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
}
export interface PutComplianceInquiryFeedbackResponse {
    submittedAt: Date;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateComplianceInquiryError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new compliance inquiry.
 */
export declare const createComplianceInquiry: API.OperationMethod<CreateComplianceInquiryRequest & RegionInput, CreateComplianceInquiryResponse, CreateComplianceInquiryError, Credentials | HttpClient.HttpClient>;
export type ExportComplianceInquiryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Export a compliance inquiry report.
 */
export declare const exportComplianceInquiry: API.OperationMethod<ExportComplianceInquiryRequest & RegionInput, ExportComplianceInquiryResponse, ExportComplianceInquiryError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the account settings for Artifact.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest & RegionInput, GetAccountSettingsResponse, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetComplianceInquiryMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the metadata for a single compliance inquiry.
 */
export declare const getComplianceInquiryMetadata: API.OperationMethod<GetComplianceInquiryMetadataRequest & RegionInput, GetComplianceInquiryMetadataResponse, GetComplianceInquiryMetadataError, Credentials | HttpClient.HttpClient>;
export type GetReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the content for a single report.
 */
export declare const getReport: API.OperationMethod<GetReportRequest & RegionInput, GetReportResponse, GetReportError, Credentials | HttpClient.HttpClient>;
export type GetReportMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the metadata for a single report.
 */
export declare const getReportMetadata: API.OperationMethod<GetReportMetadataRequest & RegionInput, GetReportMetadataResponse, GetReportMetadataError, Credentials | HttpClient.HttpClient>;
export type GetTermForReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the Term content associated with a single report.
 */
export declare const getTermForReport: API.OperationMethod<GetTermForReportRequest & RegionInput, GetTermForReportResponse, GetTermForReportError, Credentials | HttpClient.HttpClient>;
export type ListComplianceInquiriesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List available compliance inquiries.
 */
export declare const listComplianceInquiries: API.PaginatedOperationMethod<ListComplianceInquiriesRequest & RegionInput, ListComplianceInquiriesResponse, ListComplianceInquiriesError, Credentials | HttpClient.HttpClient, InquirySummary>;
export type ListComplianceInquiryQueriesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List queries within a compliance inquiry.
 */
export declare const listComplianceInquiryQueries: API.PaginatedOperationMethod<ListComplianceInquiryQueriesRequest & RegionInput, ListComplianceInquiryQueriesResponse, ListComplianceInquiryQueriesError, Credentials | HttpClient.HttpClient, QuerySummary>;
export type ListCustomerAgreementsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List active customer-agreements applicable to calling identity.
 */
export declare const listCustomerAgreements: API.PaginatedOperationMethod<ListCustomerAgreementsRequest & RegionInput, ListCustomerAgreementsResponse, ListCustomerAgreementsError, Credentials | HttpClient.HttpClient, CustomerAgreementSummary>;
export type ListReportsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List available reports.
 */
export declare const listReports: API.PaginatedOperationMethod<ListReportsRequest & RegionInput, ListReportsResponse, ListReportsError, Credentials | HttpClient.HttpClient, ReportSummary>;
export type ListReportVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List available report versions for a given report.
 */
export declare const listReportVersions: API.PaginatedOperationMethod<ListReportVersionsRequest & RegionInput, ListReportVersionsResponse, ListReportVersionsError, Credentials | HttpClient.HttpClient, ReportSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Put the account settings for Artifact.
 */
export declare const putAccountSettings: API.OperationMethod<PutAccountSettingsRequest & RegionInput, PutAccountSettingsResponse, PutAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type PutComplianceInquiryFeedbackError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits feedback on a compliance inquiry response.
 */
export declare const putComplianceInquiryFeedback: API.OperationMethod<PutComplianceInquiryFeedbackRequest & RegionInput, PutComplianceInquiryFeedbackResponse, PutComplianceInquiryFeedbackError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=artifact.d.ts.map