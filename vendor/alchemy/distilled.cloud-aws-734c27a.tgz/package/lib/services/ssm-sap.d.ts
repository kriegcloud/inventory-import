import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type PermissionActionType = "RESTORE" | (string & {});
export type Arn = string;
export interface DeleteResourcePermissionInput {
    ActionType?: PermissionActionType | undefined;
    SourceResourceArn?: string | undefined;
    ResourceArn: string;
}
export interface DeleteResourcePermissionOutput {
    Policy?: string | undefined;
}
export type ApplicationId = string;
export interface DeregisterApplicationInput {
    ApplicationId: string;
}
export interface DeregisterApplicationOutput {
}
export type SsmSapArn = string;
export type AppRegistryArn = string;
export interface GetApplicationInput {
    ApplicationId?: string | undefined;
    ApplicationArn?: string | undefined;
    AppRegistryArn?: string | undefined;
}
export type ApplicationType = "HANA" | "SAP_ABAP" | (string & {});
export type ApplicationStatus = "ACTIVATED" | "STARTING" | "STOPPED" | "STOPPING" | "FAILED" | "REGISTERING" | "DELETING" | "UNKNOWN" | (string & {});
export type ApplicationDiscoveryStatus = "SUCCESS" | "REGISTRATION_FAILED" | "REFRESH_FAILED" | "REGISTERING" | "DELETING" | (string & {});
export type ComponentId = string;
export type ComponentIdList = string[];
export type ApplicationArnList = string[];
export interface Application {
    Id?: string | undefined;
    Type?: ApplicationType | undefined;
    Arn?: string | undefined;
    AppRegistryArn?: string | undefined;
    Status?: ApplicationStatus | undefined;
    DiscoveryStatus?: ApplicationDiscoveryStatus | undefined;
    Components?: string[] | undefined;
    LastUpdated?: Date | undefined;
    StatusMessage?: string | undefined;
    AssociatedApplicationArns?: string[] | undefined;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface GetApplicationOutput {
    Application?: Application | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetComponentInput {
    ApplicationId: string;
    ComponentId: string;
}
export type SID = string;
export type SAPInstanceNumber = string;
export type ComponentType = "HANA" | "HANA_NODE" | "ABAP" | "ASCS" | "DIALOG" | "WEBDISP" | "WD" | "ERS" | (string & {});
export type ComponentStatus = "ACTIVATED" | "STARTING" | "STOPPED" | "STOPPING" | "RUNNING" | "RUNNING_WITH_ERROR" | "UNDEFINED" | (string & {});
export type ReplicationMode = "PRIMARY" | "NONE" | "SYNC" | "SYNCMEM" | "ASYNC" | (string & {});
export type OperationMode = "PRIMARY" | "LOGREPLAY" | "DELTA_DATASHIPPING" | "LOGREPLAY_READACCESS" | "NONE" | (string & {});
export type ClusterStatus = "ONLINE" | "STANDBY" | "MAINTENANCE" | "OFFLINE" | "NONE" | (string & {});
export interface Resilience {
    HsrTier?: string | undefined;
    HsrReplicationMode?: ReplicationMode | undefined;
    HsrOperationMode?: OperationMode | undefined;
    ClusterStatus?: ClusterStatus | undefined;
    EnqueueReplication?: boolean | undefined;
}
export type AllocationType = "VPC_SUBNET" | "ELASTIC_IP" | "OVERLAY" | "UNKNOWN" | (string & {});
export interface IpAddressMember {
    IpAddress?: string | undefined;
    Primary?: boolean | undefined;
    AllocationType?: AllocationType | undefined;
}
export type IpAddressList = IpAddressMember[];
export interface AssociatedHost {
    Hostname?: string | undefined;
    Ec2InstanceId?: string | undefined;
    IpAddresses?: IpAddressMember[] | undefined;
    OsVersion?: string | undefined;
}
export type DatabaseId = string;
export type DatabaseIdList = string[];
export type HostRole = "LEADER" | "WORKER" | "STANDBY" | "UNKNOWN" | (string & {});
export interface Host {
    HostName?: string | undefined;
    HostIp?: string | undefined;
    EC2InstanceId?: string | undefined;
    InstanceId?: string | undefined;
    HostRole?: HostRole | undefined;
    OsVersion?: string | undefined;
}
export type HostList = Host[];
export type DatabaseConnectionMethod = "DIRECT" | "OVERLAY" | (string & {});
export interface DatabaseConnection {
    DatabaseConnectionMethod?: DatabaseConnectionMethod | undefined;
    DatabaseArn?: string | undefined;
    ConnectionIp?: string | undefined;
}
export interface Component {
    ComponentId?: string | undefined;
    Sid?: string | undefined;
    SystemNumber?: string | undefined;
    ParentComponent?: string | undefined;
    ChildComponents?: string[] | undefined;
    ApplicationId?: string | undefined;
    ComponentType?: ComponentType | undefined;
    Status?: ComponentStatus | undefined;
    SapHostname?: string | undefined;
    SapFeature?: string | undefined;
    SapKernelVersion?: string | undefined;
    HdbVersion?: string | undefined;
    Resilience?: Resilience | undefined;
    AssociatedHost?: AssociatedHost | undefined;
    Databases?: string[] | undefined;
    Hosts?: Host[] | undefined;
    PrimaryHost?: string | undefined;
    DatabaseConnection?: DatabaseConnection | undefined;
    LastUpdated?: Date | undefined;
    Arn?: string | undefined;
}
export interface GetComponentOutput {
    Component?: Component | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type OperationId = string;
export interface GetConfigurationCheckOperationInput {
    OperationId: string;
}
export type OperationStatus = "INPROGRESS" | "SUCCESS" | "ERROR" | (string & {});
export type ConfigurationCheckType = "SAP_CHECK_01" | "SAP_CHECK_02" | "SAP_CHECK_03" | (string & {});
export interface RuleStatusCounts {
    Failed?: number | undefined;
    Warning?: number | undefined;
    Info?: number | undefined;
    Passed?: number | undefined;
    Unknown?: number | undefined;
}
export interface ConfigurationCheckOperation {
    Id?: string | undefined;
    ApplicationId?: string | undefined;
    Status?: OperationStatus | undefined;
    StatusMessage?: string | undefined;
    ConfigurationCheckId?: ConfigurationCheckType | undefined;
    ConfigurationCheckName?: string | undefined;
    ConfigurationCheckDescription?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    RuleStatusCounts?: RuleStatusCounts | undefined;
}
export interface GetConfigurationCheckOperationOutput {
    ConfigurationCheckOperation?: ConfigurationCheckOperation | undefined;
}
export interface GetDatabaseInput {
    ApplicationId?: string | undefined;
    ComponentId?: string | undefined;
    DatabaseId?: string | undefined;
    DatabaseArn?: string | undefined;
}
export type DatabaseName = string;
export type CredentialType = "ADMIN" | (string & {});
export type SecretId = string | redacted.Redacted<string>;
export interface ApplicationCredential {
    DatabaseName: string;
    CredentialType: CredentialType;
    SecretId: string | redacted.Redacted<string>;
}
export type ApplicationCredentialList = ApplicationCredential[];
export type DatabaseType = "SYSTEM" | "TENANT" | (string & {});
export type DatabaseStatus = "RUNNING" | "STARTING" | "STOPPED" | "WARNING" | "UNKNOWN" | "ERROR" | "STOPPING" | (string & {});
export type ComponentArnList = string[];
export interface Database {
    ApplicationId?: string | undefined;
    ComponentId?: string | undefined;
    Credentials?: ApplicationCredential[] | undefined;
    DatabaseId?: string | undefined;
    DatabaseName?: string | undefined;
    DatabaseType?: DatabaseType | undefined;
    Arn?: string | undefined;
    Status?: DatabaseStatus | undefined;
    PrimaryHost?: string | undefined;
    SQLPort?: number | undefined;
    LastUpdated?: Date | undefined;
    ConnectedComponentArns?: string[] | undefined;
}
export interface GetDatabaseOutput {
    Database?: Database | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetOperationInput {
    OperationId: string;
}
export type OperationType = string;
export type OperationProperties = {
    [key: string]: string | null | undefined;
};
export type ResourceType = string;
export type ResourceId = string;
export interface Operation {
    Id?: string | undefined;
    Type?: string | undefined;
    Status?: OperationStatus | undefined;
    StatusMessage?: string | undefined;
    Properties?: {
        [key: string]: string | null | undefined;
    } | undefined;
    ResourceType?: string | undefined;
    ResourceId?: string | undefined;
    ResourceArn?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export interface GetOperationOutput {
    Operation?: Operation | undefined;
}
export interface GetResourcePermissionInput {
    ActionType?: PermissionActionType | undefined;
    ResourceArn: string;
}
export interface GetResourcePermissionOutput {
    Policy?: string | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export type FilterName = string;
export type FilterValue = string;
export type FilterOperator = "Equals" | "GreaterThanOrEquals" | "LessThanOrEquals" | (string & {});
export interface Filter {
    Name: string;
    Value: string;
    Operator: FilterOperator;
}
export type FilterList = Filter[];
export interface ListApplicationsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface ApplicationSummary {
    Id?: string | undefined;
    DiscoveryStatus?: ApplicationDiscoveryStatus | undefined;
    Type?: ApplicationType | undefined;
    Arn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ApplicationSummaryList = ApplicationSummary[];
export interface ListApplicationsOutput {
    Applications?: ApplicationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListComponentsInput {
    ApplicationId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ComponentSummary {
    ApplicationId?: string | undefined;
    ComponentId?: string | undefined;
    ComponentType?: ComponentType | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arn?: string | undefined;
}
export type ComponentSummaryList = ComponentSummary[];
export interface ListComponentsOutput {
    Components?: ComponentSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConfigurationCheckDefinitionsInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ApplicationTypeList = ApplicationType[];
export interface ConfigurationCheckDefinition {
    Id?: ConfigurationCheckType | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    ApplicableApplicationTypes?: ApplicationType[] | undefined;
}
export type ConfigurationCheckDefinitionList = ConfigurationCheckDefinition[];
export interface ListConfigurationCheckDefinitionsOutput {
    ConfigurationChecks?: ConfigurationCheckDefinition[] | undefined;
    NextToken?: string | undefined;
}
export type ConfigurationCheckOperationListingMode = "ALL_OPERATIONS" | "LATEST_PER_CHECK" | (string & {});
export interface ListConfigurationCheckOperationsInput {
    ApplicationId: string;
    ListMode?: ConfigurationCheckOperationListingMode | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type ConfigurationCheckOperationList = ConfigurationCheckOperation[];
export interface ListConfigurationCheckOperationsOutput {
    ConfigurationCheckOperations?: ConfigurationCheckOperation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDatabasesInput {
    ApplicationId?: string | undefined;
    ComponentId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DatabaseSummary {
    ApplicationId?: string | undefined;
    ComponentId?: string | undefined;
    DatabaseId?: string | undefined;
    DatabaseType?: DatabaseType | undefined;
    Arn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DatabaseSummaryList = DatabaseSummary[];
export interface ListDatabasesOutput {
    Databases?: DatabaseSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOperationEventsInput {
    OperationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type OperationEventResourceType = string;
export interface Resource {
    ResourceArn?: string | undefined;
    ResourceType?: string | undefined;
}
export type OperationEventStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export interface OperationEvent {
    Description?: string | undefined;
    Resource?: Resource | undefined;
    Status?: OperationEventStatus | undefined;
    StatusMessage?: string | undefined;
    Timestamp?: Date | undefined;
}
export type OperationEventList = OperationEvent[];
export interface ListOperationEventsOutput {
    OperationEvents?: OperationEvent[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOperationsInput {
    ApplicationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type OperationList = Operation[];
export interface ListOperationsOutput {
    Operations?: Operation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSubCheckResultsInput {
    OperationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SubCheckResultId = string;
export type SubCheckReferencesList = string[];
export interface SubCheckResult {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    References?: string[] | undefined;
}
export type SubCheckResultList = SubCheckResult[];
export interface ListSubCheckResultsOutput {
    SubCheckResults?: SubCheckResult[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSubCheckRuleResultsInput {
    SubCheckResultId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type RuleResultId = string;
export type RuleResultStatus = "PASSED" | "FAILED" | "WARNING" | "INFO" | "UNKNOWN" | (string & {});
export type RuleResultMetadataKey = string;
export type RuleResultMetadataValue = string;
export type RuleResultMetadata = {
    [key: string]: string | undefined;
};
export interface RuleResult {
    Id?: string | undefined;
    Description?: string | undefined;
    Status?: RuleResultStatus | undefined;
    Message?: string | undefined;
    Metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RuleResultList = RuleResult[];
export interface ListSubCheckRuleResultsOutput {
    RuleResults?: RuleResult[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutResourcePermissionInput {
    ActionType: PermissionActionType;
    SourceResourceArn: string;
    ResourceArn: string;
}
export interface PutResourcePermissionOutput {
    Policy?: string | undefined;
}
export type InstanceId = string;
export type InstanceList = string[];
export interface ComponentInfo {
    ComponentType: ComponentType;
    Sid: string;
    Ec2InstanceId: string;
}
export type ComponentInfoList = ComponentInfo[];
export interface RegisterApplicationInput {
    ApplicationId: string;
    ApplicationType: ApplicationType;
    Instances: string[];
    SapInstanceNumber?: string | undefined;
    Sid?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Credentials?: ApplicationCredential[] | undefined;
    DatabaseArn?: string | undefined;
    ComponentsInfo?: ComponentInfo[] | undefined;
}
export interface RegisterApplicationOutput {
    Application?: Application | undefined;
    OperationId?: string | undefined;
}
export interface StartApplicationInput {
    ApplicationId: string;
}
export interface StartApplicationOutput {
    OperationId?: string | undefined;
}
export interface StartApplicationRefreshInput {
    ApplicationId: string;
}
export interface StartApplicationRefreshOutput {
    OperationId?: string | undefined;
}
export type ConfigurationCheckTypeList = ConfigurationCheckType[];
export interface StartConfigurationChecksInput {
    ApplicationId: string;
    ConfigurationCheckIds?: ConfigurationCheckType[] | undefined;
}
export interface StartConfigurationChecksOutput {
    ConfigurationCheckOperations?: ConfigurationCheckOperation[] | undefined;
}
export type ConnectedEntityType = "DBMS" | (string & {});
export interface StopApplicationInput {
    ApplicationId: string;
    StopConnectedEntity?: ConnectedEntityType | undefined;
    IncludeEc2InstanceShutdown?: boolean | undefined;
}
export interface StopApplicationOutput {
    OperationId?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type BackintMode = "AWSBackup" | (string & {});
export interface BackintConfig {
    BackintMode: BackintMode;
    EnsureNoBackupInProcess: boolean;
}
export interface UpdateApplicationSettingsInput {
    ApplicationId: string;
    CredentialsToAddOrUpdate?: ApplicationCredential[] | undefined;
    CredentialsToRemove?: ApplicationCredential[] | undefined;
    Backint?: BackintConfig | undefined;
    DatabaseArn?: string | undefined;
}
export type OperationIdList = string[];
export interface UpdateApplicationSettingsOutput {
    Message?: string | undefined;
    OperationIds?: string[] | undefined;
}
export type DeleteResourcePermissionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes permissions associated with the target database.
 */
export declare const deleteResourcePermission: API.OperationMethod<DeleteResourcePermissionInput & RegionInput, DeleteResourcePermissionOutput, DeleteResourcePermissionError, Credentials | HttpClient.HttpClient>;
export type DeregisterApplicationError = InternalServerException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deregister an SAP application with AWS Systems Manager for SAP. This action does not aU+FB00ect the existing setup of your SAP workloads on Amazon EC2.
 */
export declare const deregisterApplication: API.OperationMethod<DeregisterApplicationInput & RegionInput, DeregisterApplicationOutput, DeregisterApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Gets an application registered with AWS Systems Manager for SAP. It also returns the components of the application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationInput & RegionInput, GetApplicationOutput, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = InternalServerException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Gets the component of an application registered with AWS Systems Manager for SAP.
 */
export declare const getComponent: API.OperationMethod<GetComponentInput & RegionInput, GetComponentOutput, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationCheckOperationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Gets the details of a configuration check operation by specifying the operation ID.
 */
export declare const getConfigurationCheckOperation: API.OperationMethod<GetConfigurationCheckOperationInput & RegionInput, GetConfigurationCheckOperationOutput, GetConfigurationCheckOperationError, Credentials | HttpClient.HttpClient>;
export type GetDatabaseError = InternalServerException | ValidationException | CommonErrors;
/**
 * Gets the SAP HANA database of an application registered with AWS Systems Manager for SAP.
 */
export declare const getDatabase: API.OperationMethod<GetDatabaseInput & RegionInput, GetDatabaseOutput, GetDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetOperationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Gets the details of an operation by specifying the operation ID.
 */
export declare const getOperation: API.OperationMethod<GetOperationInput & RegionInput, GetOperationOutput, GetOperationError, Credentials | HttpClient.HttpClient>;
export type GetResourcePermissionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets permissions associated with the target database.
 */
export declare const getResourcePermission: API.OperationMethod<GetResourcePermissionInput & RegionInput, GetResourcePermissionOutput, GetResourcePermissionError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all the applications registered with AWS Systems Manager for SAP.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsInput & RegionInput, ListApplicationsOutput, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListComponentsError = InternalServerException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all the components registered with AWS Systems Manager for SAP.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsInput & RegionInput, ListComponentsOutput, ListComponentsError, Credentials | HttpClient.HttpClient, ComponentSummary>;
export type ListConfigurationCheckDefinitionsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all configuration check types supported by AWS Systems Manager for SAP.
 */
export declare const listConfigurationCheckDefinitions: API.PaginatedOperationMethod<ListConfigurationCheckDefinitionsInput & RegionInput, ListConfigurationCheckDefinitionsOutput, ListConfigurationCheckDefinitionsError, Credentials | HttpClient.HttpClient, ConfigurationCheckDefinition>;
export type ListConfigurationCheckOperationsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the configuration check operations performed by AWS Systems Manager for SAP.
 */
export declare const listConfigurationCheckOperations: API.PaginatedOperationMethod<ListConfigurationCheckOperationsInput & RegionInput, ListConfigurationCheckOperationsOutput, ListConfigurationCheckOperationsError, Credentials | HttpClient.HttpClient, ConfigurationCheckOperation>;
export type ListDatabasesError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the SAP HANA databases of an application registered with AWS Systems Manager for SAP.
 */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesInput & RegionInput, ListDatabasesOutput, ListDatabasesError, Credentials | HttpClient.HttpClient, DatabaseSummary>;
export type ListOperationEventsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of operations events.
 *
 * Available parameters include `OperationID`, as well as optional parameters `MaxResults`, `NextToken`, and `Filters`.
 */
export declare const listOperationEvents: API.PaginatedOperationMethod<ListOperationEventsInput & RegionInput, ListOperationEventsOutput, ListOperationEventsError, Credentials | HttpClient.HttpClient, OperationEvent>;
export type ListOperationsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the operations performed by AWS Systems Manager for SAP.
 */
export declare const listOperations: API.PaginatedOperationMethod<ListOperationsInput & RegionInput, ListOperationsOutput, ListOperationsError, Credentials | HttpClient.HttpClient, Operation>;
export type ListSubCheckResultsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the sub-check results of a specified configuration check operation.
 */
export declare const listSubCheckResults: API.PaginatedOperationMethod<ListSubCheckResultsInput & RegionInput, ListSubCheckResultsOutput, ListSubCheckResultsError, Credentials | HttpClient.HttpClient, SubCheckResult>;
export type ListSubCheckRuleResultsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the rules of a specified sub-check belonging to a configuration check operation.
 */
export declare const listSubCheckRuleResults: API.PaginatedOperationMethod<ListSubCheckRuleResultsInput & RegionInput, ListSubCheckRuleResultsOutput, ListSubCheckRuleResultsError, Credentials | HttpClient.HttpClient, RuleResult>;
export type ListTagsForResourceError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all tags on an SAP HANA application and/or database registered with AWS Systems Manager for SAP.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutResourcePermissionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds permissions to the target database.
 */
export declare const putResourcePermission: API.OperationMethod<PutResourcePermissionInput & RegionInput, PutResourcePermissionOutput, PutResourcePermissionError, Credentials | HttpClient.HttpClient>;
export type RegisterApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Register an SAP application with AWS Systems Manager for SAP. You must meet the following requirements before registering.
 *
 * The SAP application you want to register with AWS Systems Manager for SAP is running on Amazon EC2.
 *
 * AWS Systems Manager Agent must be setup on an Amazon EC2 instance along with the required IAM permissions.
 *
 * Amazon EC2 instance(s) must have access to the secrets created in AWS Secrets Manager to manage SAP applications and components.
 */
export declare const registerApplication: API.OperationMethod<RegisterApplicationInput & RegionInput, RegisterApplicationOutput, RegisterApplicationError, Credentials | HttpClient.HttpClient>;
export type StartApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Request is an operation which starts an application.
 *
 * Parameter `ApplicationId` is required.
 */
export declare const startApplication: API.OperationMethod<StartApplicationInput & RegionInput, StartApplicationOutput, StartApplicationError, Credentials | HttpClient.HttpClient>;
export type StartApplicationRefreshError = ConflictException | InternalServerException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Refreshes a registered application.
 */
export declare const startApplicationRefresh: API.OperationMethod<StartApplicationRefreshInput & RegionInput, StartApplicationRefreshOutput, StartApplicationRefreshError, Credentials | HttpClient.HttpClient>;
export type StartConfigurationChecksError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Initiates configuration check operations against a specified application.
 */
export declare const startConfigurationChecks: API.OperationMethod<StartConfigurationChecksInput & RegionInput, StartConfigurationChecksOutput, StartConfigurationChecksError, Credentials | HttpClient.HttpClient>;
export type StopApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Request is an operation to stop an application.
 *
 * Parameter `ApplicationId` is required. Parameters `StopConnectedEntity` and `IncludeEc2InstanceShutdown` are optional.
 */
export declare const stopApplication: API.OperationMethod<StopApplicationInput & RegionInput, StopApplicationOutput, StopApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates tag for a resource by specifying the ARN.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete the tags for a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationSettingsError = ConflictException | InternalServerException | ResourceNotFoundException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates the settings of an application registered with AWS Systems Manager for SAP.
 */
export declare const updateApplicationSettings: API.OperationMethod<UpdateApplicationSettingsInput & RegionInput, UpdateApplicationSettingsOutput, UpdateApplicationSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ssm-sap.d.ts.map