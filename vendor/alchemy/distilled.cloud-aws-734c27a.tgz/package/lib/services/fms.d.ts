import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalErrorException_base: S.TaggedErrorClass<"InternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidOperationException_base: S.TaggedErrorClass<"InvalidOperationException", {
    readonly message: any;
}>;
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidTypeException_base: S.TaggedErrorClass<"InvalidTypeException", {
    readonly message: any;
}>;
export declare class InvalidTypeException extends /*@__PURE__*/ InvalidTypeException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type AWSAccountId = string;
export interface AssociateAdminAccountRequest {
    AdminAccount: string;
}
export interface AssociateAdminAccountResponse {
}
export type ThirdPartyFirewall = "PALO_ALTO_NETWORKS_CLOUD_NGFW" | "FORTIGATE_CLOUD_NATIVE_FIREWALL" | (string & {});
export interface AssociateThirdPartyFirewallRequest {
    ThirdPartyFirewall: ThirdPartyFirewall;
}
export type ThirdPartyFirewallAssociationStatus = "ONBOARDING" | "ONBOARD_COMPLETE" | "OFFBOARDING" | "OFFBOARD_COMPLETE" | "NOT_EXIST" | (string & {});
export interface AssociateThirdPartyFirewallResponse {
    ThirdPartyFirewallStatus?: ThirdPartyFirewallAssociationStatus | undefined;
}
export type Identifier = string;
export type IdentifierList = string[];
export interface BatchAssociateResourceRequest {
    ResourceSetIdentifier: string;
    Items: string[];
}
export type FailedItemReason = "NOT_VALID_ARN" | "NOT_VALID_PARTITION" | "NOT_VALID_REGION" | "NOT_VALID_SERVICE" | "NOT_VALID_RESOURCE_TYPE" | "NOT_VALID_ACCOUNT_ID" | (string & {});
export interface FailedItem {
    URI?: string | undefined;
    Reason?: FailedItemReason | undefined;
}
export type FailedItemList = FailedItem[];
export interface BatchAssociateResourceResponse {
    ResourceSetIdentifier: string;
    FailedItems: FailedItem[];
}
export interface BatchDisassociateResourceRequest {
    ResourceSetIdentifier: string;
    Items: string[];
}
export interface BatchDisassociateResourceResponse {
    ResourceSetIdentifier: string;
    FailedItems: FailedItem[];
}
export type ListId = string;
export interface DeleteAppsListRequest {
    ListId: string;
}
export interface DeleteAppsListResponse {
}
export interface DeleteNotificationChannelRequest {
}
export interface DeleteNotificationChannelResponse {
}
export type PolicyId = string;
export interface DeletePolicyRequest {
    PolicyId: string;
    DeleteAllPolicyResources?: boolean | undefined;
}
export interface DeletePolicyResponse {
}
export interface DeleteProtocolsListRequest {
    ListId: string;
}
export interface DeleteProtocolsListResponse {
}
export type Base62Id = string;
export interface DeleteResourceSetRequest {
    Identifier: string;
}
export interface DeleteResourceSetResponse {
}
export interface DisassociateAdminAccountRequest {
}
export interface DisassociateAdminAccountResponse {
}
export interface DisassociateThirdPartyFirewallRequest {
    ThirdPartyFirewall: ThirdPartyFirewall;
}
export interface DisassociateThirdPartyFirewallResponse {
    ThirdPartyFirewallStatus?: ThirdPartyFirewallAssociationStatus | undefined;
}
export interface GetAdminAccountRequest {
}
export type AccountRoleStatus = "READY" | "CREATING" | "PENDING_DELETION" | "DELETING" | "DELETED" | (string & {});
export interface GetAdminAccountResponse {
    AdminAccount?: string | undefined;
    RoleStatus?: AccountRoleStatus | undefined;
}
export interface GetAdminScopeRequest {
    AdminAccount: string;
}
export type AccountIdList = string[];
export interface AccountScope {
    Accounts?: string[] | undefined;
    AllAccountsEnabled?: boolean | undefined;
    ExcludeSpecifiedAccounts?: boolean | undefined;
}
export type OrganizationalUnitId = string;
export type OrganizationalUnitIdList = string[];
export interface OrganizationalUnitScope {
    OrganizationalUnits?: string[] | undefined;
    AllOrganizationalUnitsEnabled?: boolean | undefined;
    ExcludeSpecifiedOrganizationalUnits?: boolean | undefined;
}
export type AWSRegion = string;
export type AWSRegionList = string[];
export interface RegionScope {
    Regions?: string[] | undefined;
    AllRegionsEnabled?: boolean | undefined;
}
export type SecurityServiceType = "WAF" | "WAFV2" | "SHIELD_ADVANCED" | "SECURITY_GROUPS_COMMON" | "SECURITY_GROUPS_CONTENT_AUDIT" | "SECURITY_GROUPS_USAGE_AUDIT" | "NETWORK_FIREWALL" | "DNS_FIREWALL" | "THIRD_PARTY_FIREWALL" | "IMPORT_NETWORK_FIREWALL" | "NETWORK_ACL_COMMON" | (string & {});
export type SecurityServiceTypeList = SecurityServiceType[];
export interface PolicyTypeScope {
    PolicyTypes?: SecurityServiceType[] | undefined;
    AllPolicyTypesEnabled?: boolean | undefined;
}
export interface AdminScope {
    AccountScope?: AccountScope | undefined;
    OrganizationalUnitScope?: OrganizationalUnitScope | undefined;
    RegionScope?: RegionScope | undefined;
    PolicyTypeScope?: PolicyTypeScope | undefined;
}
export type OrganizationStatus = "ONBOARDING" | "ONBOARDING_COMPLETE" | "OFFBOARDING" | "OFFBOARDING_COMPLETE" | (string & {});
export interface GetAdminScopeResponse {
    AdminScope?: AdminScope | undefined;
    Status?: OrganizationStatus | undefined;
}
export interface GetAppsListRequest {
    ListId: string;
    DefaultList?: boolean | undefined;
}
export type ResourceName = string;
export type UpdateToken = string;
export type Protocol = string;
export type IPPortNumber = number;
export interface App {
    AppName: string;
    Protocol: string;
    Port: number;
}
export type AppsList = App[];
export type PreviousListVersion = string;
export type PreviousAppsList = {
    [key: string]: App[] | undefined;
};
export interface AppsListData {
    ListId?: string | undefined;
    ListName: string;
    ListUpdateToken?: string | undefined;
    CreateTime?: Date | undefined;
    LastUpdateTime?: Date | undefined;
    AppsList: App[];
    PreviousAppsList?: {
        [key: string]: App[] | undefined;
    } | undefined;
}
export type ResourceArn = string;
export interface GetAppsListResponse {
    AppsList?: AppsListData | undefined;
    AppsListArn?: string | undefined;
}
export interface GetComplianceDetailRequest {
    PolicyId: string;
    MemberAccount: string;
}
export type ResourceId = string;
export type ViolationReason = "WEB_ACL_MISSING_RULE_GROUP" | "RESOURCE_MISSING_WEB_ACL" | "RESOURCE_INCORRECT_WEB_ACL" | "RESOURCE_MISSING_SHIELD_PROTECTION" | "RESOURCE_MISSING_WEB_ACL_OR_SHIELD_PROTECTION" | "RESOURCE_MISSING_SECURITY_GROUP" | "RESOURCE_VIOLATES_AUDIT_SECURITY_GROUP" | "SECURITY_GROUP_UNUSED" | "SECURITY_GROUP_REDUNDANT" | "FMS_CREATED_SECURITY_GROUP_EDITED" | "MISSING_FIREWALL" | "MISSING_FIREWALL_SUBNET_IN_AZ" | "MISSING_EXPECTED_ROUTE_TABLE" | "NETWORK_FIREWALL_POLICY_MODIFIED" | "FIREWALL_SUBNET_IS_OUT_OF_SCOPE" | "INTERNET_GATEWAY_MISSING_EXPECTED_ROUTE" | "FIREWALL_SUBNET_MISSING_EXPECTED_ROUTE" | "UNEXPECTED_FIREWALL_ROUTES" | "UNEXPECTED_TARGET_GATEWAY_ROUTES" | "TRAFFIC_INSPECTION_CROSSES_AZ_BOUNDARY" | "INVALID_ROUTE_CONFIGURATION" | "MISSING_TARGET_GATEWAY" | "INTERNET_TRAFFIC_NOT_INSPECTED" | "BLACK_HOLE_ROUTE_DETECTED" | "BLACK_HOLE_ROUTE_DETECTED_IN_FIREWALL_SUBNET" | "RESOURCE_MISSING_DNS_FIREWALL" | "ROUTE_HAS_OUT_OF_SCOPE_ENDPOINT" | "FIREWALL_SUBNET_MISSING_VPCE_ENDPOINT" | "INVALID_NETWORK_ACL_ENTRY" | "WEB_ACL_CONFIGURATION_OR_SCOPE_OF_USE" | (string & {});
export type ResourceType = string;
export type LengthBoundedString = string;
export type ComplianceViolatorMetadata = {
    [key: string]: string | undefined;
};
export interface ComplianceViolator {
    ResourceId?: string | undefined;
    ViolationReason?: ViolationReason | undefined;
    ResourceType?: string | undefined;
    Metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ComplianceViolators = ComplianceViolator[];
export type DependentServiceName = "AWSCONFIG" | "AWSWAF" | "AWSSHIELD_ADVANCED" | "AWSVPC" | (string & {});
export type DetailedInfo = string;
export type IssueInfoMap = {
    [key in DependentServiceName]?: string | undefined;
};
export interface PolicyComplianceDetail {
    PolicyOwner?: string | undefined;
    PolicyId?: string | undefined;
    MemberAccount?: string | undefined;
    Violators?: ComplianceViolator[] | undefined;
    EvaluationLimitExceeded?: boolean | undefined;
    ExpiredAt?: Date | undefined;
    IssueInfoMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetComplianceDetailResponse {
    PolicyComplianceDetail?: PolicyComplianceDetail | undefined;
}
export interface GetNotificationChannelRequest {
}
export interface GetNotificationChannelResponse {
    SnsTopicArn?: string | undefined;
    SnsRoleName?: string | undefined;
}
export interface GetPolicyRequest {
    PolicyId: string;
}
export type PolicyUpdateToken = string;
export type ManagedServiceData = string;
export type FirewallDeploymentModel = "CENTRALIZED" | "DISTRIBUTED" | (string & {});
export interface NetworkFirewallPolicy {
    FirewallDeploymentModel?: FirewallDeploymentModel | undefined;
}
export interface ThirdPartyFirewallPolicy {
    FirewallDeploymentModel?: FirewallDeploymentModel | undefined;
}
export type IntegerObject = number;
export interface NetworkAclIcmpTypeCode {
    Code?: number | undefined;
    Type?: number | undefined;
}
export type IPPortNumberInteger = number;
export interface NetworkAclPortRange {
    From?: number | undefined;
    To?: number | undefined;
}
export type LengthBoundedNonEmptyString = string;
export type NetworkAclRuleAction = "allow" | "deny" | (string & {});
export interface NetworkAclEntry {
    IcmpTypeCode?: NetworkAclIcmpTypeCode | undefined;
    Protocol: string;
    PortRange?: NetworkAclPortRange | undefined;
    CidrBlock?: string | undefined;
    Ipv6CidrBlock?: string | undefined;
    RuleAction: NetworkAclRuleAction;
    Egress: boolean;
}
export type NetworkAclEntries = NetworkAclEntry[];
export interface NetworkAclEntrySet {
    FirstEntries?: NetworkAclEntry[] | undefined;
    ForceRemediateForFirstEntries: boolean;
    LastEntries?: NetworkAclEntry[] | undefined;
    ForceRemediateForLastEntries: boolean;
}
export interface NetworkAclCommonPolicy {
    NetworkAclEntrySet: NetworkAclEntrySet;
}
export interface PolicyOption {
    NetworkFirewallPolicy?: NetworkFirewallPolicy | undefined;
    ThirdPartyFirewallPolicy?: ThirdPartyFirewallPolicy | undefined;
    NetworkAclCommonPolicy?: NetworkAclCommonPolicy | undefined;
}
export interface SecurityServicePolicyData {
    Type: SecurityServiceType;
    ManagedServiceData?: string | undefined;
    PolicyOption?: PolicyOption | undefined;
}
export type ResourceTypeList = string[];
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value?: string | undefined;
}
export type ResourceTags = ResourceTag[];
export type CustomerPolicyScopeIdType = "ACCOUNT" | "ORG_UNIT" | (string & {});
export type CustomerPolicyScopeId = string;
export type CustomerPolicyScopeIdList = string[];
export type CustomerPolicyScopeMap = {
    [key in CustomerPolicyScopeIdType]?: string[] | undefined;
};
export type ResourceSetIds = string[];
export type ResourceDescription = string;
export type CustomerPolicyStatus = "ACTIVE" | "OUT_OF_ADMIN_SCOPE" | (string & {});
export type ResourceTagLogicalOperator = "AND" | "OR" | (string & {});
export interface Policy {
    PolicyId?: string | undefined;
    PolicyName: string;
    PolicyUpdateToken?: string | undefined;
    SecurityServicePolicyData: SecurityServicePolicyData;
    ResourceType: string;
    ResourceTypeList?: string[] | undefined;
    ResourceTags?: ResourceTag[] | undefined;
    ExcludeResourceTags: boolean;
    RemediationEnabled: boolean;
    DeleteUnusedFMManagedResources?: boolean | undefined;
    IncludeMap?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ExcludeMap?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ResourceSetIds?: string[] | undefined;
    PolicyDescription?: string | undefined;
    PolicyStatus?: CustomerPolicyStatus | undefined;
    ResourceTagLogicalOperator?: ResourceTagLogicalOperator | undefined;
}
export interface GetPolicyResponse {
    Policy?: Policy | undefined;
    PolicyArn?: string | undefined;
}
export type PaginationToken = string;
export type PaginationMaxResults = number;
export interface GetProtectionStatusRequest {
    PolicyId: string;
    MemberAccountId?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ProtectionData = string;
export interface GetProtectionStatusResponse {
    AdminAccountId?: string | undefined;
    ServiceType?: SecurityServiceType | undefined;
    Data?: string | undefined;
    NextToken?: string | undefined;
}
export interface GetProtocolsListRequest {
    ListId: string;
    DefaultList?: boolean | undefined;
}
export type ProtocolsList = string[];
export type PreviousProtocolsList = {
    [key: string]: string[] | undefined;
};
export interface ProtocolsListData {
    ListId?: string | undefined;
    ListName: string;
    ListUpdateToken?: string | undefined;
    CreateTime?: Date | undefined;
    LastUpdateTime?: Date | undefined;
    ProtocolsList: string[];
    PreviousProtocolsList?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface GetProtocolsListResponse {
    ProtocolsList?: ProtocolsListData | undefined;
    ProtocolsListArn?: string | undefined;
}
export interface GetResourceSetRequest {
    Identifier: string;
}
export type Name = string;
export type Description = string;
export type ResourceSetStatus = "ACTIVE" | "OUT_OF_ADMIN_SCOPE" | (string & {});
export interface ResourceSet {
    Id?: string | undefined;
    Name: string;
    Description?: string | undefined;
    UpdateToken?: string | undefined;
    ResourceTypeList: string[];
    LastUpdateTime?: Date | undefined;
    ResourceSetStatus?: ResourceSetStatus | undefined;
}
export interface GetResourceSetResponse {
    ResourceSet: ResourceSet;
    ResourceSetArn: string;
}
export interface GetThirdPartyFirewallAssociationStatusRequest {
    ThirdPartyFirewall: ThirdPartyFirewall;
}
export type MarketplaceSubscriptionOnboardingStatus = "NO_SUBSCRIPTION" | "NOT_COMPLETE" | "COMPLETE" | (string & {});
export interface GetThirdPartyFirewallAssociationStatusResponse {
    ThirdPartyFirewallStatus?: ThirdPartyFirewallAssociationStatus | undefined;
    MarketplaceOnboardingStatus?: MarketplaceSubscriptionOnboardingStatus | undefined;
}
export interface GetViolationDetailsRequest {
    PolicyId: string;
    MemberAccount: string;
    ResourceId: string;
    ResourceType: string;
}
export type ViolationTarget = string;
export type ReferenceRule = string;
export type TargetViolationReason = string;
export type TargetViolationReasons = string[];
export interface PartialMatch {
    Reference?: string | undefined;
    TargetViolationReasons?: string[] | undefined;
}
export type PartialMatches = PartialMatch[];
export type RemediationActionType = "REMOVE" | "MODIFY" | (string & {});
export type RemediationActionDescription = string;
export type CIDR = string;
export interface SecurityGroupRuleDescription {
    IPV4Range?: string | undefined;
    IPV6Range?: string | undefined;
    PrefixListId?: string | undefined;
    Protocol?: string | undefined;
    FromPort?: number | undefined;
    ToPort?: number | undefined;
}
export interface SecurityGroupRemediationAction {
    RemediationActionType?: RemediationActionType | undefined;
    Description?: string | undefined;
    RemediationResult?: SecurityGroupRuleDescription | undefined;
    IsDefaultAction?: boolean | undefined;
}
export type SecurityGroupRemediationActions = SecurityGroupRemediationAction[];
export interface AwsVPCSecurityGroupViolation {
    ViolationTarget?: string | undefined;
    ViolationTargetDescription?: string | undefined;
    PartialMatches?: PartialMatch[] | undefined;
    PossibleSecurityGroupRemediationActions?: SecurityGroupRemediationAction[] | undefined;
}
export type ResourceIdList = string[];
export interface AwsEc2NetworkInterfaceViolation {
    ViolationTarget?: string | undefined;
    ViolatingSecurityGroups?: string[] | undefined;
}
export type AwsEc2NetworkInterfaceViolations = AwsEc2NetworkInterfaceViolation[];
export interface AwsEc2InstanceViolation {
    ViolationTarget?: string | undefined;
    AwsEc2NetworkInterfaceViolations?: AwsEc2NetworkInterfaceViolation[] | undefined;
}
export interface NetworkFirewallMissingFirewallViolation {
    ViolationTarget?: string | undefined;
    VPC?: string | undefined;
    AvailabilityZone?: string | undefined;
    TargetViolationReason?: string | undefined;
}
export interface NetworkFirewallMissingSubnetViolation {
    ViolationTarget?: string | undefined;
    VPC?: string | undefined;
    AvailabilityZone?: string | undefined;
    TargetViolationReason?: string | undefined;
}
export interface NetworkFirewallMissingExpectedRTViolation {
    ViolationTarget?: string | undefined;
    VPC?: string | undefined;
    AvailabilityZone?: string | undefined;
    CurrentRouteTable?: string | undefined;
    ExpectedRouteTable?: string | undefined;
}
export type NetworkFirewallResourceName = string;
export type StatelessRuleGroupPriority = number;
export interface StatelessRuleGroup {
    RuleGroupName?: string | undefined;
    ResourceId?: string | undefined;
    Priority?: number | undefined;
}
export type StatelessRuleGroupList = StatelessRuleGroup[];
export type NetworkFirewallAction = string;
export type NetworkFirewallActionList = string[];
export type PriorityNumber = number;
export type NetworkFirewallOverrideAction = "DROP_TO_ALERT" | (string & {});
export interface NetworkFirewallStatefulRuleGroupOverride {
    Action?: NetworkFirewallOverrideAction | undefined;
}
export interface StatefulRuleGroup {
    RuleGroupName?: string | undefined;
    ResourceId?: string | undefined;
    Priority?: number | undefined;
    Override?: NetworkFirewallStatefulRuleGroupOverride | undefined;
}
export type StatefulRuleGroupList = StatefulRuleGroup[];
export type RuleOrder = "STRICT_ORDER" | "DEFAULT_ACTION_ORDER" | (string & {});
export type StreamExceptionPolicy = "DROP" | "CONTINUE" | "REJECT" | "FMS_IGNORE" | (string & {});
export interface StatefulEngineOptions {
    RuleOrder?: RuleOrder | undefined;
    StreamExceptionPolicy?: StreamExceptionPolicy | undefined;
}
export interface NetworkFirewallPolicyDescription {
    StatelessRuleGroups?: StatelessRuleGroup[] | undefined;
    StatelessDefaultActions?: string[] | undefined;
    StatelessFragmentDefaultActions?: string[] | undefined;
    StatelessCustomActions?: string[] | undefined;
    StatefulRuleGroups?: StatefulRuleGroup[] | undefined;
    StatefulDefaultActions?: string[] | undefined;
    StatefulEngineOptions?: StatefulEngineOptions | undefined;
}
export interface NetworkFirewallPolicyModifiedViolation {
    ViolationTarget?: string | undefined;
    CurrentPolicyDescription?: NetworkFirewallPolicyDescription | undefined;
    ExpectedPolicyDescription?: NetworkFirewallPolicyDescription | undefined;
}
export type DestinationType = "IPV4" | "IPV6" | "PREFIX_LIST" | (string & {});
export type TargetType = "GATEWAY" | "CARRIER_GATEWAY" | "INSTANCE" | "LOCAL_GATEWAY" | "NAT_GATEWAY" | "NETWORK_INTERFACE" | "VPC_ENDPOINT" | "VPC_PEERING_CONNECTION" | "EGRESS_ONLY_INTERNET_GATEWAY" | "TRANSIT_GATEWAY" | (string & {});
export interface Route {
    DestinationType?: DestinationType | undefined;
    TargetType?: TargetType | undefined;
    Destination?: string | undefined;
    Target?: string | undefined;
}
export type Routes = Route[];
export type LengthBoundedStringList = string[];
export interface ExpectedRoute {
    IpV4Cidr?: string | undefined;
    PrefixListId?: string | undefined;
    IpV6Cidr?: string | undefined;
    ContributingSubnets?: string[] | undefined;
    AllowedTargets?: string[] | undefined;
    RouteTableId?: string | undefined;
}
export type ExpectedRoutes = ExpectedRoute[];
export interface NetworkFirewallInternetTrafficNotInspectedViolation {
    SubnetId?: string | undefined;
    SubnetAvailabilityZone?: string | undefined;
    RouteTableId?: string | undefined;
    ViolatingRoutes?: Route[] | undefined;
    IsRouteTableUsedInDifferentAZ?: boolean | undefined;
    CurrentFirewallSubnetRouteTable?: string | undefined;
    ExpectedFirewallEndpoint?: string | undefined;
    FirewallSubnetId?: string | undefined;
    ExpectedFirewallSubnetRoutes?: ExpectedRoute[] | undefined;
    ActualFirewallSubnetRoutes?: Route[] | undefined;
    InternetGatewayId?: string | undefined;
    CurrentInternetGatewayRouteTable?: string | undefined;
    ExpectedInternetGatewayRoutes?: ExpectedRoute[] | undefined;
    ActualInternetGatewayRoutes?: Route[] | undefined;
    VpcId?: string | undefined;
}
export interface NetworkFirewallInvalidRouteConfigurationViolation {
    AffectedSubnets?: string[] | undefined;
    RouteTableId?: string | undefined;
    IsRouteTableUsedInDifferentAZ?: boolean | undefined;
    ViolatingRoute?: Route | undefined;
    CurrentFirewallSubnetRouteTable?: string | undefined;
    ExpectedFirewallEndpoint?: string | undefined;
    ActualFirewallEndpoint?: string | undefined;
    ExpectedFirewallSubnetId?: string | undefined;
    ActualFirewallSubnetId?: string | undefined;
    ExpectedFirewallSubnetRoutes?: ExpectedRoute[] | undefined;
    ActualFirewallSubnetRoutes?: Route[] | undefined;
    InternetGatewayId?: string | undefined;
    CurrentInternetGatewayRouteTable?: string | undefined;
    ExpectedInternetGatewayRoutes?: ExpectedRoute[] | undefined;
    ActualInternetGatewayRoutes?: Route[] | undefined;
    VpcId?: string | undefined;
}
export interface NetworkFirewallBlackHoleRouteDetectedViolation {
    ViolationTarget?: string | undefined;
    RouteTableId?: string | undefined;
    VpcId?: string | undefined;
    ViolatingRoutes?: Route[] | undefined;
}
export interface NetworkFirewallUnexpectedFirewallRoutesViolation {
    FirewallSubnetId?: string | undefined;
    ViolatingRoutes?: Route[] | undefined;
    RouteTableId?: string | undefined;
    FirewallEndpoint?: string | undefined;
    VpcId?: string | undefined;
}
export interface NetworkFirewallUnexpectedGatewayRoutesViolation {
    GatewayId?: string | undefined;
    ViolatingRoutes?: Route[] | undefined;
    RouteTableId?: string | undefined;
    VpcId?: string | undefined;
}
export interface NetworkFirewallMissingExpectedRoutesViolation {
    ViolationTarget?: string | undefined;
    ExpectedRoutes?: ExpectedRoute[] | undefined;
    VpcId?: string | undefined;
}
export type DnsRuleGroupPriority = number;
export type DnsRuleGroupPriorities = number[];
export interface DnsRuleGroupPriorityConflictViolation {
    ViolationTarget?: string | undefined;
    ViolationTargetDescription?: string | undefined;
    ConflictingPriority?: number | undefined;
    ConflictingPolicyId?: string | undefined;
    UnavailablePriorities?: number[] | undefined;
}
export interface DnsDuplicateRuleGroupViolation {
    ViolationTarget?: string | undefined;
    ViolationTargetDescription?: string | undefined;
}
export type BasicInteger = number;
export interface DnsRuleGroupLimitExceededViolation {
    ViolationTarget?: string | undefined;
    ViolationTargetDescription?: string | undefined;
    NumberOfRuleGroupsAlreadyAssociated?: number | undefined;
}
export interface FirewallSubnetIsOutOfScopeViolation {
    FirewallSubnetId?: string | undefined;
    VpcId?: string | undefined;
    SubnetAvailabilityZone?: string | undefined;
    SubnetAvailabilityZoneId?: string | undefined;
    VpcEndpointId?: string | undefined;
}
export interface RouteHasOutOfScopeEndpointViolation {
    SubnetId?: string | undefined;
    VpcId?: string | undefined;
    RouteTableId?: string | undefined;
    ViolatingRoutes?: Route[] | undefined;
    SubnetAvailabilityZone?: string | undefined;
    SubnetAvailabilityZoneId?: string | undefined;
    CurrentFirewallSubnetRouteTable?: string | undefined;
    FirewallSubnetId?: string | undefined;
    FirewallSubnetRoutes?: Route[] | undefined;
    InternetGatewayId?: string | undefined;
    CurrentInternetGatewayRouteTable?: string | undefined;
    InternetGatewayRoutes?: Route[] | undefined;
}
export interface ThirdPartyFirewallMissingFirewallViolation {
    ViolationTarget?: string | undefined;
    VPC?: string | undefined;
    AvailabilityZone?: string | undefined;
    TargetViolationReason?: string | undefined;
}
export interface ThirdPartyFirewallMissingSubnetViolation {
    ViolationTarget?: string | undefined;
    VPC?: string | undefined;
    AvailabilityZone?: string | undefined;
    TargetViolationReason?: string | undefined;
}
export interface ThirdPartyFirewallMissingExpectedRouteTableViolation {
    ViolationTarget?: string | undefined;
    VPC?: string | undefined;
    AvailabilityZone?: string | undefined;
    CurrentRouteTable?: string | undefined;
    ExpectedRouteTable?: string | undefined;
}
export interface FirewallSubnetMissingVPCEndpointViolation {
    FirewallSubnetId?: string | undefined;
    VpcId?: string | undefined;
    SubnetAvailabilityZone?: string | undefined;
    SubnetAvailabilityZoneId?: string | undefined;
}
export type IntegerObjectMinimum0 = number;
export type EntryType = "FMS_MANAGED_FIRST_ENTRY" | "FMS_MANAGED_LAST_ENTRY" | "CUSTOM_ENTRY" | (string & {});
export interface EntryDescription {
    EntryDetail?: NetworkAclEntry | undefined;
    EntryRuleNumber?: number | undefined;
    EntryType?: EntryType | undefined;
}
export type EntriesWithConflicts = EntryDescription[];
export type EntryViolationReason = "MISSING_EXPECTED_ENTRY" | "INCORRECT_ENTRY_ORDER" | "ENTRY_CONFLICT" | (string & {});
export type EntryViolationReasons = EntryViolationReason[];
export interface EntryViolation {
    ExpectedEntry?: EntryDescription | undefined;
    ExpectedEvaluationOrder?: string | undefined;
    ActualEvaluationOrder?: string | undefined;
    EntryAtExpectedEvaluationOrder?: EntryDescription | undefined;
    EntriesWithConflicts?: EntryDescription[] | undefined;
    EntryViolationReasons?: EntryViolationReason[] | undefined;
}
export type EntryViolations = EntryViolation[];
export interface InvalidNetworkAclEntriesViolation {
    Vpc?: string | undefined;
    Subnet?: string | undefined;
    SubnetAvailabilityZone?: string | undefined;
    CurrentAssociatedNetworkAcl?: string | undefined;
    EntryViolations?: EntryViolation[] | undefined;
}
export interface ActionTarget {
    ResourceId?: string | undefined;
    Description?: string | undefined;
}
export interface EC2CreateRouteAction {
    Description?: string | undefined;
    DestinationCidrBlock?: string | undefined;
    DestinationPrefixListId?: string | undefined;
    DestinationIpv6CidrBlock?: string | undefined;
    VpcEndpointId?: ActionTarget | undefined;
    GatewayId?: ActionTarget | undefined;
    RouteTableId: ActionTarget;
}
export interface EC2ReplaceRouteAction {
    Description?: string | undefined;
    DestinationCidrBlock?: string | undefined;
    DestinationPrefixListId?: string | undefined;
    DestinationIpv6CidrBlock?: string | undefined;
    GatewayId?: ActionTarget | undefined;
    RouteTableId: ActionTarget;
}
export interface EC2DeleteRouteAction {
    Description?: string | undefined;
    DestinationCidrBlock?: string | undefined;
    DestinationPrefixListId?: string | undefined;
    DestinationIpv6CidrBlock?: string | undefined;
    RouteTableId: ActionTarget;
}
export interface EC2CopyRouteTableAction {
    Description?: string | undefined;
    VpcId: ActionTarget;
    RouteTableId: ActionTarget;
}
export interface EC2ReplaceRouteTableAssociationAction {
    Description?: string | undefined;
    AssociationId: ActionTarget;
    RouteTableId: ActionTarget;
}
export interface EC2AssociateRouteTableAction {
    Description?: string | undefined;
    RouteTableId: ActionTarget;
    SubnetId?: ActionTarget | undefined;
    GatewayId?: ActionTarget | undefined;
}
export interface EC2CreateRouteTableAction {
    Description?: string | undefined;
    VpcId: ActionTarget;
}
export interface FMSPolicyUpdateFirewallCreationConfigAction {
    Description?: string | undefined;
    FirewallCreationConfig?: string | undefined;
}
export interface CreateNetworkAclAction {
    Description?: string | undefined;
    Vpc?: ActionTarget | undefined;
    FMSCanRemediate?: boolean | undefined;
}
export interface ReplaceNetworkAclAssociationAction {
    Description?: string | undefined;
    AssociationId?: ActionTarget | undefined;
    NetworkAclId?: ActionTarget | undefined;
    FMSCanRemediate?: boolean | undefined;
}
export type EntriesDescription = EntryDescription[];
export interface CreateNetworkAclEntriesAction {
    Description?: string | undefined;
    NetworkAclId?: ActionTarget | undefined;
    NetworkAclEntriesToBeCreated?: EntryDescription[] | undefined;
    FMSCanRemediate?: boolean | undefined;
}
export interface DeleteNetworkAclEntriesAction {
    Description?: string | undefined;
    NetworkAclId?: ActionTarget | undefined;
    NetworkAclEntriesToBeDeleted?: EntryDescription[] | undefined;
    FMSCanRemediate?: boolean | undefined;
}
export interface RemediationAction {
    Description?: string | undefined;
    EC2CreateRouteAction?: EC2CreateRouteAction | undefined;
    EC2ReplaceRouteAction?: EC2ReplaceRouteAction | undefined;
    EC2DeleteRouteAction?: EC2DeleteRouteAction | undefined;
    EC2CopyRouteTableAction?: EC2CopyRouteTableAction | undefined;
    EC2ReplaceRouteTableAssociationAction?: EC2ReplaceRouteTableAssociationAction | undefined;
    EC2AssociateRouteTableAction?: EC2AssociateRouteTableAction | undefined;
    EC2CreateRouteTableAction?: EC2CreateRouteTableAction | undefined;
    FMSPolicyUpdateFirewallCreationConfigAction?: FMSPolicyUpdateFirewallCreationConfigAction | undefined;
    CreateNetworkAclAction?: CreateNetworkAclAction | undefined;
    ReplaceNetworkAclAssociationAction?: ReplaceNetworkAclAssociationAction | undefined;
    CreateNetworkAclEntriesAction?: CreateNetworkAclEntriesAction | undefined;
    DeleteNetworkAclEntriesAction?: DeleteNetworkAclEntriesAction | undefined;
}
export interface RemediationActionWithOrder {
    RemediationAction?: RemediationAction | undefined;
    Order?: number | undefined;
}
export type OrderedRemediationActions = RemediationActionWithOrder[];
export interface PossibleRemediationAction {
    Description?: string | undefined;
    OrderedRemediationActions: RemediationActionWithOrder[];
    IsDefaultAction?: boolean | undefined;
}
export type PossibleRemediationActionList = PossibleRemediationAction[];
export interface PossibleRemediationActions {
    Description?: string | undefined;
    Actions?: PossibleRemediationAction[] | undefined;
}
export interface WebACLHasIncompatibleConfigurationViolation {
    WebACLArn?: string | undefined;
    Description?: string | undefined;
}
export type ResourceArnList = string[];
export interface WebACLHasOutOfScopeResourcesViolation {
    WebACLArn?: string | undefined;
    OutOfScopeResourceList?: string[] | undefined;
}
export interface ResourceViolation {
    AwsVPCSecurityGroupViolation?: AwsVPCSecurityGroupViolation | undefined;
    AwsEc2NetworkInterfaceViolation?: AwsEc2NetworkInterfaceViolation | undefined;
    AwsEc2InstanceViolation?: AwsEc2InstanceViolation | undefined;
    NetworkFirewallMissingFirewallViolation?: NetworkFirewallMissingFirewallViolation | undefined;
    NetworkFirewallMissingSubnetViolation?: NetworkFirewallMissingSubnetViolation | undefined;
    NetworkFirewallMissingExpectedRTViolation?: NetworkFirewallMissingExpectedRTViolation | undefined;
    NetworkFirewallPolicyModifiedViolation?: NetworkFirewallPolicyModifiedViolation | undefined;
    NetworkFirewallInternetTrafficNotInspectedViolation?: NetworkFirewallInternetTrafficNotInspectedViolation | undefined;
    NetworkFirewallInvalidRouteConfigurationViolation?: NetworkFirewallInvalidRouteConfigurationViolation | undefined;
    NetworkFirewallBlackHoleRouteDetectedViolation?: NetworkFirewallBlackHoleRouteDetectedViolation | undefined;
    NetworkFirewallUnexpectedFirewallRoutesViolation?: NetworkFirewallUnexpectedFirewallRoutesViolation | undefined;
    NetworkFirewallUnexpectedGatewayRoutesViolation?: NetworkFirewallUnexpectedGatewayRoutesViolation | undefined;
    NetworkFirewallMissingExpectedRoutesViolation?: NetworkFirewallMissingExpectedRoutesViolation | undefined;
    DnsRuleGroupPriorityConflictViolation?: DnsRuleGroupPriorityConflictViolation | undefined;
    DnsDuplicateRuleGroupViolation?: DnsDuplicateRuleGroupViolation | undefined;
    DnsRuleGroupLimitExceededViolation?: DnsRuleGroupLimitExceededViolation | undefined;
    FirewallSubnetIsOutOfScopeViolation?: FirewallSubnetIsOutOfScopeViolation | undefined;
    RouteHasOutOfScopeEndpointViolation?: RouteHasOutOfScopeEndpointViolation | undefined;
    ThirdPartyFirewallMissingFirewallViolation?: ThirdPartyFirewallMissingFirewallViolation | undefined;
    ThirdPartyFirewallMissingSubnetViolation?: ThirdPartyFirewallMissingSubnetViolation | undefined;
    ThirdPartyFirewallMissingExpectedRouteTableViolation?: ThirdPartyFirewallMissingExpectedRouteTableViolation | undefined;
    FirewallSubnetMissingVPCEndpointViolation?: FirewallSubnetMissingVPCEndpointViolation | undefined;
    InvalidNetworkAclEntriesViolation?: InvalidNetworkAclEntriesViolation | undefined;
    PossibleRemediationActions?: PossibleRemediationActions | undefined;
    WebACLHasIncompatibleConfigurationViolation?: WebACLHasIncompatibleConfigurationViolation | undefined;
    WebACLHasOutOfScopeResourcesViolation?: WebACLHasOutOfScopeResourcesViolation | undefined;
}
export type ResourceViolations = ResourceViolation[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface ViolationDetail {
    PolicyId: string;
    MemberAccount: string;
    ResourceId: string;
    ResourceType: string;
    ResourceViolations: ResourceViolation[];
    ResourceTags?: Tag[] | undefined;
    ResourceDescription?: string | undefined;
}
export interface GetViolationDetailsResponse {
    ViolationDetail?: ViolationDetail | undefined;
}
export interface ListAdminAccountsForOrganizationRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AdminAccountSummary {
    AdminAccount?: string | undefined;
    DefaultAdmin?: boolean | undefined;
    Status?: OrganizationStatus | undefined;
}
export type AdminAccountSummaryList = AdminAccountSummary[];
export interface ListAdminAccountsForOrganizationResponse {
    AdminAccounts?: AdminAccountSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAdminsManagingAccountRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListAdminsManagingAccountResponse {
    AdminAccounts?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAppsListsRequest {
    DefaultLists?: boolean | undefined;
    NextToken?: string | undefined;
    MaxResults: number;
}
export interface AppsListDataSummary {
    ListArn?: string | undefined;
    ListId?: string | undefined;
    ListName?: string | undefined;
    AppsList?: App[] | undefined;
}
export type AppsListsData = AppsListDataSummary[];
export interface ListAppsListsResponse {
    AppsLists?: AppsListDataSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListComplianceStatusRequest {
    PolicyId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type PolicyComplianceStatusType = "COMPLIANT" | "NON_COMPLIANT" | (string & {});
export type ResourceCount = number;
export interface EvaluationResult {
    ComplianceStatus?: PolicyComplianceStatusType | undefined;
    ViolatorCount?: number | undefined;
    EvaluationLimitExceeded?: boolean | undefined;
}
export type EvaluationResults = EvaluationResult[];
export interface PolicyComplianceStatus {
    PolicyOwner?: string | undefined;
    PolicyId?: string | undefined;
    PolicyName?: string | undefined;
    MemberAccount?: string | undefined;
    EvaluationResults?: EvaluationResult[] | undefined;
    LastUpdated?: Date | undefined;
    IssueInfoMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PolicyComplianceStatusList = PolicyComplianceStatus[];
export interface ListComplianceStatusResponse {
    PolicyComplianceStatusList?: PolicyComplianceStatus[] | undefined;
    NextToken?: string | undefined;
}
export type AWSAccountIdList = string[];
export interface ListDiscoveredResourcesRequest {
    MemberAccountIds: string[];
    ResourceType: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DiscoveredResource {
    URI?: string | undefined;
    AccountId?: string | undefined;
    Type?: string | undefined;
    Name?: string | undefined;
}
export type DiscoveredResourceList = DiscoveredResource[];
export interface ListDiscoveredResourcesResponse {
    Items?: DiscoveredResource[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMemberAccountsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type MemberAccounts = string[];
export interface ListMemberAccountsResponse {
    MemberAccounts?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPoliciesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface PolicySummary {
    PolicyArn?: string | undefined;
    PolicyId?: string | undefined;
    PolicyName?: string | undefined;
    ResourceType?: string | undefined;
    SecurityServiceType?: SecurityServiceType | undefined;
    RemediationEnabled?: boolean | undefined;
    DeleteUnusedFMManagedResources?: boolean | undefined;
    PolicyStatus?: CustomerPolicyStatus | undefined;
}
export type PolicySummaryList = PolicySummary[];
export interface ListPoliciesResponse {
    PolicyList?: PolicySummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProtocolsListsRequest {
    DefaultLists?: boolean | undefined;
    NextToken?: string | undefined;
    MaxResults: number;
}
export interface ProtocolsListDataSummary {
    ListArn?: string | undefined;
    ListId?: string | undefined;
    ListName?: string | undefined;
    ProtocolsList?: string[] | undefined;
}
export type ProtocolsListsData = ProtocolsListDataSummary[];
export interface ListProtocolsListsResponse {
    ProtocolsLists?: ProtocolsListDataSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListResourceSetResourcesRequest {
    Identifier: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Resource {
    URI: string;
    AccountId?: string | undefined;
}
export type ResourceList = Resource[];
export interface ListResourceSetResourcesResponse {
    Items: Resource[];
    NextToken?: string | undefined;
}
export interface ListResourceSetsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ResourceSetSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    LastUpdateTime?: Date | undefined;
    ResourceSetStatus?: ResourceSetStatus | undefined;
}
export type ResourceSetSummaryList = ResourceSetSummary[];
export interface ListResourceSetsResponse {
    ResourceSets?: ResourceSetSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    TagList?: Tag[] | undefined;
}
export interface ListThirdPartyFirewallFirewallPoliciesRequest {
    ThirdPartyFirewall: ThirdPartyFirewall;
    NextToken?: string | undefined;
    MaxResults: number;
}
export type FirewallPolicyId = string;
export type FirewallPolicyName = string;
export interface ThirdPartyFirewallFirewallPolicy {
    FirewallPolicyId?: string | undefined;
    FirewallPolicyName?: string | undefined;
}
export type ThirdPartyFirewallFirewallPolicies = ThirdPartyFirewallFirewallPolicy[];
export interface ListThirdPartyFirewallFirewallPoliciesResponse {
    ThirdPartyFirewallFirewallPolicies?: ThirdPartyFirewallFirewallPolicy[] | undefined;
    NextToken?: string | undefined;
}
export interface PutAdminAccountRequest {
    AdminAccount: string;
    AdminScope?: AdminScope | undefined;
}
export interface PutAdminAccountResponse {
}
export interface PutAppsListRequest {
    AppsList: AppsListData;
    TagList?: Tag[] | undefined;
}
export interface PutAppsListResponse {
    AppsList?: AppsListData | undefined;
    AppsListArn?: string | undefined;
}
export interface PutNotificationChannelRequest {
    SnsTopicArn: string;
    SnsRoleName: string;
}
export interface PutNotificationChannelResponse {
}
export interface PutPolicyRequest {
    Policy: Policy;
    TagList?: Tag[] | undefined;
}
export interface PutPolicyResponse {
    Policy?: Policy | undefined;
    PolicyArn?: string | undefined;
}
export interface PutProtocolsListRequest {
    ProtocolsList: ProtocolsListData;
    TagList?: Tag[] | undefined;
}
export interface PutProtocolsListResponse {
    ProtocolsList?: ProtocolsListData | undefined;
    ProtocolsListArn?: string | undefined;
}
export interface PutResourceSetRequest {
    ResourceSet: ResourceSet;
    TagList?: Tag[] | undefined;
}
export interface PutResourceSetResponse {
    ResourceSet: ResourceSet;
    ResourceSetArn: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    TagList: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ErrorMessage = string;
export type AssociateAdminAccountError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Sets a Firewall Manager default administrator account. The Firewall Manager default administrator account can manage third-party firewalls and has full administrative scope that allows administration of all policy types, accounts, organizational units, and Regions. This account must be a member account of the organization in Organizations whose resources you want to protect.
 *
 * For information about working with Firewall Manager administrator accounts, see Managing Firewall Manager administrators in the *Firewall Manager Developer Guide*.
 */
export declare const associateAdminAccount: API.OperationMethod<AssociateAdminAccountRequest & RegionInput, AssociateAdminAccountResponse, AssociateAdminAccountError, Credentials | HttpClient.HttpClient>;
export type AssociateThirdPartyFirewallError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Sets the Firewall Manager policy administrator as a tenant administrator of a third-party firewall service. A tenant is an instance of the third-party firewall service that's associated with your Amazon Web Services customer account.
 */
export declare const associateThirdPartyFirewall: API.OperationMethod<AssociateThirdPartyFirewallRequest & RegionInput, AssociateThirdPartyFirewallResponse, AssociateThirdPartyFirewallError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associate resources to a Firewall Manager resource set.
 */
export declare const batchAssociateResource: API.OperationMethod<BatchAssociateResourceRequest & RegionInput, BatchAssociateResourceResponse, BatchAssociateResourceError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates resources from a Firewall Manager resource set.
 */
export declare const batchDisassociateResource: API.OperationMethod<BatchDisassociateResourceRequest & RegionInput, BatchDisassociateResourceResponse, BatchDisassociateResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteAppsListError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Permanently deletes an Firewall Manager applications list.
 */
export declare const deleteAppsList: API.OperationMethod<DeleteAppsListRequest & RegionInput, DeleteAppsListResponse, DeleteAppsListError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationChannelError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Firewall Manager association with the IAM role and the Amazon Simple
 * Notification Service (SNS) topic that is used to record Firewall Manager SNS logs.
 */
export declare const deleteNotificationChannel: API.OperationMethod<DeleteNotificationChannelRequest & RegionInput, DeleteNotificationChannelResponse, DeleteNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Permanently deletes an Firewall Manager policy.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest & RegionInput, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteProtocolsListError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Permanently deletes an Firewall Manager protocols list.
 */
export declare const deleteProtocolsList: API.OperationMethod<DeleteProtocolsListRequest & RegionInput, DeleteProtocolsListResponse, DeleteProtocolsListError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceSetError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified ResourceSet.
 */
export declare const deleteResourceSet: API.OperationMethod<DeleteResourceSetRequest & RegionInput, DeleteResourceSetResponse, DeleteResourceSetError, Credentials | HttpClient.HttpClient>;
export type DisassociateAdminAccountError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates an Firewall Manager administrator account. To set a different account as an Firewall Manager administrator, submit a PutAdminAccount request. To set an account as a default administrator account, you must submit an AssociateAdminAccount request.
 *
 * Disassociation of the default administrator account follows the first in, last out principle. If you are the default administrator, all Firewall Manager administrators within the organization must first disassociate their accounts before you can disassociate your account.
 */
export declare const disassociateAdminAccount: API.OperationMethod<DisassociateAdminAccountRequest & RegionInput, DisassociateAdminAccountResponse, DisassociateAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateThirdPartyFirewallError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a Firewall Manager policy administrator from a third-party firewall tenant. When you call `DisassociateThirdPartyFirewall`, the third-party firewall vendor deletes all of the firewalls that are associated with the account.
 */
export declare const disassociateThirdPartyFirewall: API.OperationMethod<DisassociateThirdPartyFirewallRequest & RegionInput, DisassociateThirdPartyFirewallResponse, DisassociateThirdPartyFirewallError, Credentials | HttpClient.HttpClient>;
export type GetAdminAccountError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the Organizations account that is associated with Firewall Manager
 * as the Firewall Manager default administrator.
 */
export declare const getAdminAccount: API.OperationMethod<GetAdminAccountRequest & RegionInput, GetAdminAccountResponse, GetAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetAdminScopeError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified account's administrative scope. The administrative scope defines the resources that an Firewall Manager administrator can manage.
 */
export declare const getAdminScope: API.OperationMethod<GetAdminScopeRequest & RegionInput, GetAdminScopeResponse, GetAdminScopeError, Credentials | HttpClient.HttpClient>;
export type GetAppsListError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified Firewall Manager applications list.
 */
export declare const getAppsList: API.OperationMethod<GetAppsListRequest & RegionInput, GetAppsListResponse, GetAppsListError, Credentials | HttpClient.HttpClient>;
export type GetComplianceDetailError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns detailed compliance information about the specified member account. Details
 * include resources that are in and out of compliance with the specified policy.
 *
 * The reasons for resources being considered compliant depend on the Firewall Manager policy type.
 */
export declare const getComplianceDetail: API.OperationMethod<GetComplianceDetailRequest & RegionInput, GetComplianceDetailResponse, GetComplianceDetailError, Credentials | HttpClient.HttpClient>;
export type GetNotificationChannelError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Information
 * about the Amazon Simple Notification Service (SNS) topic that is used to
 * record Firewall Manager SNS logs.
 */
export declare const getNotificationChannel: API.OperationMethod<GetNotificationChannelRequest & RegionInput, GetNotificationChannelResponse, GetNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = InternalErrorException | InvalidOperationException | InvalidTypeException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified Firewall Manager policy.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest & RegionInput, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProtectionStatusError = InternalErrorException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * If you created a Shield Advanced policy, returns policy-level attack summary information
 * in the event of a potential DDoS attack. Other policy types are currently unsupported.
 */
export declare const getProtectionStatus: API.OperationMethod<GetProtectionStatusRequest & RegionInput, GetProtectionStatusResponse, GetProtectionStatusError, Credentials | HttpClient.HttpClient>;
export type GetProtocolsListError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified Firewall Manager protocols list.
 */
export declare const getProtocolsList: API.OperationMethod<GetProtocolsListRequest & RegionInput, GetProtocolsListResponse, GetProtocolsListError, Credentials | HttpClient.HttpClient>;
export type GetResourceSetError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about a specific resource set.
 */
export declare const getResourceSet: API.OperationMethod<GetResourceSetRequest & RegionInput, GetResourceSetResponse, GetResourceSetError, Credentials | HttpClient.HttpClient>;
export type GetThirdPartyFirewallAssociationStatusError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * The onboarding status of a Firewall Manager admin account to third-party firewall vendor tenant.
 */
export declare const getThirdPartyFirewallAssociationStatus: API.OperationMethod<GetThirdPartyFirewallAssociationStatusRequest & RegionInput, GetThirdPartyFirewallAssociationStatusResponse, GetThirdPartyFirewallAssociationStatusError, Credentials | HttpClient.HttpClient>;
export type GetViolationDetailsError = InternalErrorException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves violations for a resource based on the specified Firewall Manager policy and Amazon Web Services account.
 */
export declare const getViolationDetails: API.OperationMethod<GetViolationDetailsRequest & RegionInput, GetViolationDetailsResponse, GetViolationDetailsError, Credentials | HttpClient.HttpClient>;
export type ListAdminAccountsForOrganizationError = InternalErrorException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a `AdminAccounts` object that lists the Firewall Manager administrators within the organization that are onboarded to Firewall Manager by AssociateAdminAccount.
 *
 * This operation can be called only from the organization's management account.
 */
export declare const listAdminAccountsForOrganization: API.PaginatedOperationMethod<ListAdminAccountsForOrganizationRequest & RegionInput, ListAdminAccountsForOrganizationResponse, ListAdminAccountsForOrganizationError, Credentials | HttpClient.HttpClient, AdminAccountSummary>;
export type ListAdminsManagingAccountError = InternalErrorException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the accounts that are managing the specified Organizations member account. This is useful for any member account so that they can view the accounts who are managing their account. This operation only returns the managing administrators that have the requested account within their AdminScope.
 */
export declare const listAdminsManagingAccount: API.PaginatedOperationMethod<ListAdminsManagingAccountRequest & RegionInput, ListAdminsManagingAccountResponse, ListAdminsManagingAccountError, Credentials | HttpClient.HttpClient, AWSAccountId>;
export type ListAppsListsError = InternalErrorException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of `AppsListDataSummary` objects.
 */
export declare const listAppsLists: API.PaginatedOperationMethod<ListAppsListsRequest & RegionInput, ListAppsListsResponse, ListAppsListsError, Credentials | HttpClient.HttpClient, AppsListDataSummary>;
export type ListComplianceStatusError = InternalErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of `PolicyComplianceStatus` objects. Use
 * `PolicyComplianceStatus` to get a summary of which member accounts are protected
 * by the specified policy.
 */
export declare const listComplianceStatus: API.PaginatedOperationMethod<ListComplianceStatusRequest & RegionInput, ListComplianceStatusResponse, ListComplianceStatusError, Credentials | HttpClient.HttpClient, PolicyComplianceStatus>;
export type ListDiscoveredResourcesError = InternalErrorException | InvalidInputException | InvalidOperationException | CommonErrors;
/**
 * Returns an array of resources in the organization's accounts that are available to be associated with a resource set.
 */
export declare const listDiscoveredResources: API.OperationMethod<ListDiscoveredResourcesRequest & RegionInput, ListDiscoveredResourcesResponse, ListDiscoveredResourcesError, Credentials | HttpClient.HttpClient>;
export type ListMemberAccountsError = InternalErrorException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a `MemberAccounts` object that lists the member accounts in the
 * administrator's Amazon Web Services organization.
 *
 * Either an Firewall Manager administrator or the organization's management account can make this request.
 */
export declare const listMemberAccounts: API.PaginatedOperationMethod<ListMemberAccountsRequest & RegionInput, ListMemberAccountsResponse, ListMemberAccountsError, Credentials | HttpClient.HttpClient, AWSAccountId>;
export type ListPoliciesError = InternalErrorException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of `PolicySummary` objects.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest & RegionInput, ListPoliciesResponse, ListPoliciesError, Credentials | HttpClient.HttpClient, PolicySummary>;
export type ListProtocolsListsError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of `ProtocolsListDataSummary` objects.
 */
export declare const listProtocolsLists: API.PaginatedOperationMethod<ListProtocolsListsRequest & RegionInput, ListProtocolsListsResponse, ListProtocolsListsError, Credentials | HttpClient.HttpClient, ProtocolsListDataSummary>;
export type ListResourceSetResourcesError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of resources that are currently associated to a resource set.
 */
export declare const listResourceSetResources: API.OperationMethod<ListResourceSetResourcesRequest & RegionInput, ListResourceSetResourcesResponse, ListResourceSetResourcesError, Credentials | HttpClient.HttpClient>;
export type ListResourceSetsError = InternalErrorException | InvalidInputException | InvalidOperationException | CommonErrors;
/**
 * Returns an array of `ResourceSetSummary` objects.
 */
export declare const listResourceSets: API.OperationMethod<ListResourceSetsRequest & RegionInput, ListResourceSetsResponse, ListResourceSetsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the list of tags for the specified Amazon Web Services resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListThirdPartyFirewallFirewallPoliciesError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of all of the third-party firewall policies that are associated with the third-party firewall administrator's account.
 */
export declare const listThirdPartyFirewallFirewallPolicies: API.PaginatedOperationMethod<ListThirdPartyFirewallFirewallPoliciesRequest & RegionInput, ListThirdPartyFirewallFirewallPoliciesResponse, ListThirdPartyFirewallFirewallPoliciesError, Credentials | HttpClient.HttpClient, ThirdPartyFirewallFirewallPolicy>;
export type PutAdminAccountError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | CommonErrors;
/**
 * Creates or updates an Firewall Manager administrator account. The account must be a member of the organization that was onboarded to Firewall Manager by AssociateAdminAccount. Only the organization's management account can create an Firewall Manager administrator account. When you create an Firewall Manager administrator account, the service checks to see if the account is already a delegated administrator within Organizations. If the account isn't a delegated administrator, Firewall Manager calls Organizations to delegate the account within Organizations. For more information about administrator accounts within Organizations, see
 * Managing the Amazon Web Services Accounts in Your Organization.
 */
export declare const putAdminAccount: API.OperationMethod<PutAdminAccountRequest & RegionInput, PutAdminAccountResponse, PutAdminAccountError, Credentials | HttpClient.HttpClient>;
export type PutAppsListError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an Firewall Manager applications list.
 */
export declare const putAppsList: API.OperationMethod<PutAppsListRequest & RegionInput, PutAppsListResponse, PutAppsListError, Credentials | HttpClient.HttpClient>;
export type PutNotificationChannelError = InternalErrorException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Designates the IAM role and Amazon Simple Notification Service (SNS) topic that
 * Firewall Manager uses to record SNS logs.
 *
 * To perform this action outside of the console, you must first configure the SNS topic's access policy to allow the `SnsRoleName` to publish SNS logs. If the `SnsRoleName` provided is a role other than the `AWSServiceRoleForFMS` service-linked role, this role must have a trust relationship configured to allow the Firewall Manager service principal `fms.amazonaws.com` to assume this role. For information about configuring an SNS access policy, see
 * Service roles for Firewall Manager in the *Firewall Manager Developer Guide*.
 */
export declare const putNotificationChannel: API.OperationMethod<PutNotificationChannelRequest & RegionInput, PutNotificationChannelResponse, PutNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type PutPolicyError = InternalErrorException | InvalidInputException | InvalidOperationException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an Firewall Manager policy.
 *
 * A Firewall Manager policy is specific to the individual policy type. If you want to enforce multiple
 * policy types across accounts, you can create multiple policies. You can create more than one
 * policy for each type.
 *
 * If you add a new account to an organization that you created with Organizations, Firewall Manager
 * automatically applies the policy to the resources in that account that are within scope of
 * the policy.
 *
 * Firewall Manager provides the following types of policies:
 *
 * - **WAF policy** - This policy applies WAF web ACL
 * protections to specified accounts and resources.
 *
 * - **Shield Advanced policy** - This policy applies Shield Advanced
 * protection to specified accounts and resources.
 *
 * - **Security Groups policy** - This type of policy gives you
 * control over security groups that are in use throughout your organization in
 * Organizations and lets you enforce a baseline set of rules across your organization.
 *
 * - **Network ACL policy** - This type of policy gives you
 * control over the network ACLs that are in use throughout your organization in
 * Organizations and lets you enforce a baseline set of first and last network ACL rules across your organization.
 *
 * - **Network Firewall policy** - This policy applies
 * Network Firewall protection to your organization's VPCs.
 *
 * - **DNS Firewall policy** - This policy applies
 * Amazon Route 53 Resolver DNS Firewall protections to your organization's VPCs.
 *
 * - **Third-party firewall policy** - This policy applies third-party firewall protections. Third-party firewalls are available by subscription through the Amazon Web Services Marketplace console at Amazon Web Services Marketplace.
 *
 * - **Palo Alto Networks Cloud NGFW policy** - This policy applies Palo Alto Networks Cloud Next Generation Firewall (NGFW) protections and Palo Alto Networks Cloud NGFW rulestacks to your organization's VPCs.
 *
 * - **Fortigate CNF policy** - This policy applies
 * Fortigate Cloud Native Firewall (CNF) protections. Fortigate CNF is a cloud-centered solution that blocks Zero-Day threats and secures cloud infrastructures with industry-leading advanced threat prevention, smart web application firewalls (WAF), and API protection.
 */
export declare const putPolicy: API.OperationMethod<PutPolicyRequest & RegionInput, PutPolicyResponse, PutPolicyError, Credentials | HttpClient.HttpClient>;
export type PutProtocolsListError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an Firewall Manager protocols list.
 */
export declare const putProtocolsList: API.OperationMethod<PutProtocolsListRequest & RegionInput, PutProtocolsListResponse, PutProtocolsListError, Credentials | HttpClient.HttpClient>;
export type PutResourceSetError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | CommonErrors;
/**
 * Creates the resource set.
 *
 * An Firewall Manager resource set defines the resources to import into an Firewall Manager policy from another Amazon Web Services service.
 */
export declare const putResourceSet: API.OperationMethod<PutResourceSetRequest & RegionInput, PutResourceSetResponse, PutResourceSetError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more tags to an Amazon Web Services resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalErrorException | InvalidInputException | InvalidOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from an Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=fms.d.ts.map