/**
 * AWS restJson1 Protocol Implementation
 *
 * https://smithy.io/2.0/aws/protocols/aws-restjson1-protocol.html
 *
 * Key characteristics:
 * - JSON payloads with HTTP binding traits
 * - jsonName trait for custom property names
 * - Default timestamp format is epoch-seconds
 */
import { type ProtocolImpl } from "@distilled.cloud/s3/client/protocol";
export declare const restJson1Protocol: ProtocolImpl;
//# sourceMappingURL=rest-json.d.ts.map