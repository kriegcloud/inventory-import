import * as Effect from "effect/Effect";
import type * as FileSystem from "effect/FileSystem";
import * as FilePath from "effect/Path";
import * as Result from "effect/Result";
import type * as Aggregate from "../../Aggregate.ts";
import type { Interpreter } from "./Interpreter.ts";
import * as Source from "./Source.ts";
import * as Symbolic from "./Symbolic.ts";
import type { Eval, Module, Node, Site, V } from "./Value.ts";
import * as Value from "./Value.ts";
/** A command class, as far as the prover reads it. */
export interface CommandClass {
    readonly tag: string;
    readonly fields: Readonly<Record<string, unknown>>;
}
/** The aggregate's definition, as written: the object passed to `Domain.Aggregate`. */
export interface Definition {
    readonly module: Module;
    readonly node: Node;
    readonly name: string;
    readonly state: unknown;
}
/** Every input of one command, as the symbolic values the code ran on. */
export interface Inputs {
    readonly state: V;
    readonly command: V;
    readonly id: V;
    readonly commandId: V;
    readonly version: V;
    readonly now: V;
}
export type Outcome = 
/** The command was rejected, or recorded nothing: the state is what it was. */
{
    readonly _tag: "Unchanged";
    readonly rejection?: V;
}
/** The state after the command's events, and each invariant on it as a formula. */
 | {
    readonly _tag: "Changed";
    /** What the command recorded, and the state that leaves. */
    readonly events: ReadonlyArray<V>;
    readonly after: V;
    readonly checks: ReadonlyArray<Check>;
    /** That the new state is one the state's schema allows, as a formula. */
    readonly fits: string;
    /**
     * The parts of the new state that are not what they were, and have a
     * check the prover does not read: nothing says the new value passes it.
     */
    readonly unread: ReadonlyArray<Symbolic.Unread>;
} | {
    readonly _tag: "Stopped";
    readonly error: Value.NotTranslated;
} | {
    readonly _tag: "Infeasible";
};
export interface Path {
    readonly run: Value.Run;
    readonly inputs: Inputs | undefined;
    readonly outcome: Outcome;
}
/** The property of the definition with this name, e.g. `decide`. */
export declare const property: (definition: {
    readonly node: Node;
}, name: string) => Node | undefined;
export declare const siteOf: (definition: {
    readonly module: Module;
    readonly node: Node;
}) => Site;
/** Outside `decide`, a failure is not a rejection: nothing the prover reads does that. */
export declare const strict: <A>(eval_: Eval<A>, site: Site, what: string) => Eval<A>;
/** One of the definition's objects of functions: `decide`, `evolve` or `invariants`. */
export declare const handlers: (interpreter: Interpreter, definition: Definition, name: string) => Eval<V>;
/** The aggregate's `initial` state, as its file writes it. */
export declare const initial: (interpreter: Interpreter, definition: Definition) => Eval<V>;
/** An id as the solver's text: `undefined` for a value that is not one. */
export declare const addressOf: (id: V | undefined) => string | undefined;
/** The id of the instance a command is for, as the aggregate's `keyOf` reads it from the command. */
export declare const keyOf: (interpreter: Interpreter, definition: Definition, command: V) => Eval<V>;
/** What one command does to a state. */
export type Applied = {
    readonly _tag: "Rejected";
    readonly rejection: V;
}
/** The command recorded nothing: the state is what it was. */
 | {
    readonly _tag: "Unchanged";
} | {
    readonly _tag: "Changed";
    readonly events: ReadonlyArray<V>;
    readonly state: V;
};
export interface Step {
    readonly inputs: Inputs;
    readonly applied: Applied;
}
/**
 * Decide one command on a state and fold its events, in the interpreter's
 * current run. The command's fields, its time and the request contexts it
 * reads are fresh inputs, named after `label`.
 */
export declare const step: (interpreter: Interpreter, definition: Definition, command: CommandClass, state: V, version: V, label: string, 
/**
 * With several instances in one run: which one the command addresses, and
 * the command itself when other code built it.
 */
on?: {
    readonly id: V;
    readonly given?: V;
}) => Eval<Step>;
/** The id a command is sent with and the time it is handled at, as inputs. */
export declare const stamp: (label: string, run: Value.Run) => {
    readonly commandId: V;
    readonly now: V;
};
/** A state after events, each folded with the aggregate's `evolve`. `command` is what gave them. */
export declare const folded: (interpreter: Interpreter, definition: Definition, command: string, state: V, events: ReadonlyArray<V>, on: {
    readonly id: V;
    readonly stream: V;
    readonly version: V;
    readonly now: V;
    readonly commandId: V;
}) => Eval<V>;
/** A decision's definition, as written: the object passed to `Domain.Decision`. */
export interface DecisionDefinition {
    readonly module: Module;
    readonly node: Node;
    /** The tag of the command it implements. */
    readonly name: string;
}
/** One instance a decision reads: its aggregate, and what is known of it before the decision. */
export interface Slot {
    readonly definition: Definition;
    readonly id: V;
    readonly state: V;
    readonly version: V;
}
/** What a decision recorded on one of the instances it read, and the state that leaves. */
export interface Part {
    /** The instance's place among the ones the decision read. */
    readonly slot: number;
    readonly before: V;
    readonly events: ReadonlyArray<V>;
    readonly state: V;
}
export type Decided = {
    readonly _tag: "Rejected";
    readonly rejection: V;
}
/** The decision recorded nothing: every state is what it was. */
 | {
    readonly _tag: "Unchanged";
} | {
    readonly _tag: "Changed";
    /** Every event, in the order `decide` recorded them. */
    readonly events: ReadonlyArray<V>;
    /** One part for each instance something was recorded on. */
    readonly parts: ReadonlyArray<Part>;
};
export interface DecisionStep {
    readonly inputs: {
        readonly command: V;
        readonly commandId: V;
        readonly now: V;
    };
    /** The instances read, in the order `keyOf` names them, each once. */
    readonly slots: ReadonlyArray<Slot>;
    /** For each name in `reads`: the place of its instance, or of each of its instances. */
    readonly names: Readonly<Record<string, number | ReadonlyArray<number>>>;
    readonly applied: Decided;
}
/**
 * Decide one command across the instances it names and fold what it records
 * on each, in the interpreter's current run. `slotOf` says which instance an
 * id is: two names can stand for the same one, and it then gets one state.
 */
export declare const decided: (interpreter: Interpreter, decision: DecisionDefinition, command: CommandClass, label: string, slotOf: (name: string, id: V) => Eval<{
    readonly index: number;
    readonly slot: Slot;
}>, given?: V) => Eval<DecisionStep>;
/**
 * A decision's own transitions on the step it took, each as a formula: what
 * holds of every instance it read, before and after, together.
 */
export declare const decisionChecks: (interpreter: Interpreter, decision: DecisionDefinition, step: DecisionStep) => Eval<ReadonlyArray<Check>>;
/** The names of the transitions a decision declares. */
export declare const decisionRuleNames: (decision: DecisionDefinition) => ReadonlyArray<string>;
/** The `holds` of a relation, as its file writes it inside `Domain.Relation({ ... })`. */
export declare const relationNode: (model: Definition, name: string) => Node | undefined;
/** The names of the relations a model's file declares where the prover can read them. */
export declare const relationNames: (model: Definition) => ReadonlyArray<string>;
/** A relation on one instance for each of its names, as a formula. It may split the path. */
export declare const relationHolds: (interpreter: Interpreter, model: Definition, name: string, on: Readonly<Record<string, {
    readonly id: V;
    readonly state: V;
}>>) => Eval<string>;
/**
 * Any state an aggregate's schema allows that satisfies each of its
 * invariants the prover can read: what a proof starts an instance from.
 */
export declare const assumed: (interpreter: Interpreter, definition: Definition, name: string) => Eval<V>;
/** A file and every file it imports, directly or not: the ones that load. */
export declare const reach: (loader: Source.Loader, file: string) => Effect.Effect<Module[], Source.LoadError, never>;
/** An aggregate's definition, in whichever of the files declares it. */
export declare const aggregateIn: (modules: ReadonlyArray<Module>, aggregate: Aggregate.Any) => Definition | undefined;
/**
 * A decision's definition, in whichever of the files declares it: the object
 * passed to `Domain.Decision` after the command it implements.
 */
export declare const decisionIn: (interpreter: Interpreter, modules: readonly Module[], decision: {
    readonly decisionName: string;
    readonly command: unknown;
}) => Effect.Effect<DecisionDefinition | undefined, never, never>;
export interface Check {
    readonly name: string;
    readonly condition: Result.Result<string, Value.NotTranslated>;
}
/** The step a command took, as a transition is given it. */
export interface Taken {
    readonly before: V;
    readonly command: V;
    readonly events: ReadonlyArray<V>;
}
/**
 * Every invariant on a state, as a formula, and with the step that left the
 * state, every transition on that step. Each may split the path. One named
 * in `proved` is not read again: it is true.
 */
export declare const checks: (interpreter: Interpreter, definition: Definition, state: V, taken?: Taken, proved?: ReadonlySet<string>, 
/** The property the rules are under: a model also has `eventually`. */
key?: string) => Eval<ReadonlyArray<Check>>;
/**
 * Run one command along one path: assume every invariant on any state the
 * schema allows, decide the command, fold its events, and say what each
 * invariant is on the state that results.
 */
export declare const path: (interpreter: Interpreter, definition: Definition, command: CommandClass, prefix: ReadonlyArray<number>) => Effect.Effect<Path>;
/** The part of a value a path of properties leads to. */
export declare const at: (value: V | undefined, path: ReadonlyArray<string>) => V | undefined;
/** Whether a part of the state is what it was: the same input, or the same value written again. */
export declare const same: (a: V | undefined, b: V | undefined) => boolean;
/** The names under one of the definition's objects of rules, e.g. `invariants`. */
export declare const namesOf: (definition: Definition, key: string) => ReadonlyArray<string>;
/**
 * An invariant or a transition of the definition, as its file writes it: the
 * function, or what stands where one would be.
 */
export declare const ruleNode: (definition: Definition, name: string) => Node | undefined;
/** The rules under one of the definition's objects of rules, each with the node that writes it. */
export declare const written: (definition: Definition, key: string) => ReadonlyArray<readonly [string, Node]>;
/** A node's text, as its file writes it. */
export declare const textOf: (definition: Definition, node: Node) => string;
/** The names of the invariants the definition declares. */
export declare const invariantNames: (definition: Definition) => ReadonlyArray<string>;
/** The names of the transitions the definition declares. */
export declare const transitionNames: (definition: Definition) => ReadonlyArray<string>;
/** The names of everything a command must keep: the invariants, then the transitions. */
export declare const ruleNames: (definition: Definition) => ReadonlyArray<string>;
/**
 * The invariants and transitions a class has that the definition read from
 * its file does not declare, and the names both use.
 */
export declare const unread: (definition: Definition, declared: {
    readonly invariants?: {
        readonly [name: string]: unknown;
    } | undefined;
    readonly transitions?: {
        readonly [name: string]: unknown;
    } | undefined;
}) => ReadonlyArray<string>;
/**
 * The object passed to `Domain.Aggregate(name, { ... })`,
 * `Domain.Model(name, { ... })` or `Domain.View(name, { ... })` in a file: the
 * one with the property `key`, which an event or a command of the same name
 * does not have.
 */
export declare const find: (program: Node, name: string, 
/** `evolve` for an aggregate: one that only takes part in decisions has no `decide`. */
key: "evolve" | "aggregates" | "from" | "rollup" | "of") => Node | undefined;
/** Read the file an aggregate is declared in: its definition, and a loader for what it imports. */
export declare const load: (aggregate: Aggregate.Any, source: URL | string, reading?: Source.Reading) => Effect.Effect<{
    readonly loader: Source.Loader;
    readonly definition: Definition;
}, Source.LoadError, FileSystem.FileSystem | FilePath.Path>;
//# sourceMappingURL=Paths.d.ts.map