/**
 * What the prover reads, by name: every library function and value it has a
 * model for, every method of a string and of an array, and every module
 * whose functions it runs as they are on values the code writes. The tests
 * hold a case for each name, compared with the real code.
 */
export declare const surface: () => {
    library: ReadonlyArray<string>;
    strings: ReadonlyArray<string>;
    arrays: ReadonlyArray<string>;
    computed: readonly string[];
    /** Every form of the language, by name: the ones the prover reads, and the ones it stops at. */
    syntax: {
        read: string[];
        unread: string[];
    };
};
/**
 * The forms of the language a source text is written with, by the names
 * `surface().syntax` gives them. A piece of syntax that is on neither list
 * is `undeclared <its type>`.
 */
export declare const forms: (source: string) => Promise<ReadonlySet<string>>;
/** A source text as the tree the prover reads: what a test walks to find how a table calls a function. */
export declare const parse: (source: string) => Promise<unknown>;
//# sourceMappingURL=Surface.d.ts.map