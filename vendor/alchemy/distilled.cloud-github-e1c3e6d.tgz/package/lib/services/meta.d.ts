import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface GetRequest {
}
export interface ApiOverviewSshKeyFingerprints {
    SHA256_RSA?: string | undefined;
    SHA256_DSA?: string | undefined;
    SHA256_ECDSA?: string | undefined;
    SHA256_ED25519?: string | undefined;
}
export type ApiOverviewSshKeysList = Array<string>;
export type ApiOverviewHooksList = Array<string>;
export type ApiOverviewGithubEnterpriseImporterList = Array<string>;
export type ApiOverviewWebList = Array<string>;
/** Public destination IP ranges in CIDR notation for shared GitHub-managed ingress infrastructure. These ranges may serve multiple GitHub services and are not outbound source ranges. Use them alongside the relevant product-specific network requirements. Omitted when no ranges are available. */
export type ApiOverviewSharedIngressList = Array<string>;
export type ApiOverviewApiList = Array<string>;
export type ApiOverviewGitList = Array<string>;
export type ApiOverviewPackagesList = Array<string>;
export type ApiOverviewPagesList = Array<string>;
export type ApiOverviewImporterList = Array<string>;
export type ApiOverviewActionsList = Array<string>;
export type ApiOverviewActionsMacosList = Array<string>;
export type ApiOverviewCodespacesList = Array<string>;
export type ApiOverviewDependabotList = Array<string>;
export type ApiOverviewCopilotList = Array<string>;
export type ApiOverviewCommitSigningKeysList = Array<string>;
export type ApiOverviewDomainsWebsiteList = Array<string>;
export type ApiOverviewDomainsCodespacesList = Array<string>;
export type ApiOverviewDomainsCopilotList = Array<string>;
export type ApiOverviewDomainsPackagesList = Array<string>;
export type ApiOverviewDomainsStorageList = Array<string>;
export type ApiOverviewDomainsActionsList = Array<string>;
export type ApiOverviewDomainsActionsInboundFullDomainsList = Array<string>;
export type ApiOverviewDomainsActionsInboundWildcardDomainsList = Array<string>;
export interface ApiOverviewDomainsActionsInbound {
    full_domains?: ApiOverviewDomainsActionsInboundFullDomainsList | undefined;
    wildcard_domains?: ApiOverviewDomainsActionsInboundWildcardDomainsList | undefined;
}
export type ApiOverviewDomainsArtifactAttestationsServicesList = Array<string>;
export interface ApiOverviewDomainsArtifactAttestations {
    trust_domain?: string | undefined;
    services?: ApiOverviewDomainsArtifactAttestationsServicesList | undefined;
}
export interface ApiOverviewDomains {
    website?: ApiOverviewDomainsWebsiteList | undefined;
    codespaces?: ApiOverviewDomainsCodespacesList | undefined;
    copilot?: ApiOverviewDomainsCopilotList | undefined;
    packages?: ApiOverviewDomainsPackagesList | undefined;
    storage?: ApiOverviewDomainsStorageList | undefined;
    actions?: ApiOverviewDomainsActionsList | undefined;
    actions_inbound?: ApiOverviewDomainsActionsInbound | undefined;
    artifact_attestations?: ApiOverviewDomainsArtifactAttestations | undefined;
}
/** Api Overview */
export interface ApiOverview {
    verifiable_password_authentication: boolean;
    ssh_key_fingerprints?: ApiOverviewSshKeyFingerprints | undefined;
    ssh_keys?: ApiOverviewSshKeysList | undefined;
    hooks?: ApiOverviewHooksList | undefined;
    github_enterprise_importer?: ApiOverviewGithubEnterpriseImporterList | undefined;
    web?: ApiOverviewWebList | undefined;
    /** Public destination IP ranges in CIDR notation for shared GitHub-managed ingress infrastructure. These ranges may serve multiple GitHub services and are not outbound source ranges. Use them alongside the relevant product-specific network requirements. Omitted when no ranges are available. */
    shared_ingress?: ApiOverviewSharedIngressList | undefined;
    api?: ApiOverviewApiList | undefined;
    git?: ApiOverviewGitList | undefined;
    packages?: ApiOverviewPackagesList | undefined;
    pages?: ApiOverviewPagesList | undefined;
    importer?: ApiOverviewImporterList | undefined;
    actions?: ApiOverviewActionsList | undefined;
    actions_macos?: ApiOverviewActionsMacosList | undefined;
    codespaces?: ApiOverviewCodespacesList | undefined;
    dependabot?: ApiOverviewDependabotList | undefined;
    copilot?: ApiOverviewCopilotList | undefined;
    commit_signing_keys?: ApiOverviewCommitSigningKeysList | undefined;
    domains?: ApiOverviewDomains | undefined;
}
export interface GetAllVersionsRequest {
}
export type GetAllVersionsResponseBodyList = Array<string>;
export type GetAllVersionsResponse = GetAllVersionsResponseBodyList;
export interface GetOctocatRequest {
    /** The words to show in Octocat's speech bubble */
    s?: string | undefined;
}
export interface GetOctocatResponse {
}
export interface GetZenRequest {
}
export interface GetZenResponse {
}
export interface Root2Request {
}
export interface Root {
    current_user_url: string;
    current_user_authorizations_html_url: string;
    authorizations_url: string;
    code_search_url: string;
    commit_search_url: string;
    emails_url: string;
    emojis_url: string;
    events_url: string;
    feeds_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    hub_url?: string | undefined;
    issue_search_url: string;
    issues_url: string;
    keys_url: string;
    label_search_url: string;
    notifications_url: string;
    organization_url: string;
    organization_repositories_url: string;
    organization_teams_url: string;
    public_gists_url: string;
    rate_limit_url: string;
    repository_url: string;
    repository_search_url: string;
    current_user_repositories_url: string;
    starred_url: string;
    starred_gists_url: string;
    topic_search_url?: string | undefined;
    user_url: string;
    user_organizations_url: string;
    user_repositories_url: string;
    user_search_url: string;
}
export type GetError = GithubOpError;
/** Get GitHub meta information Returns meta information about GitHub, including a list of GitHub's IP addresses. For more information, see "[About GitHub's IP addresses](https://docs.github.com/articles/about-github-s-ip-addresses/)." The API's response also includes a list of GitHub's domain names, and the public keys used by GitHub to sign commits made through the web UI. The values shown in the documentation's response are example values. You must always query the API directly to get the latest values. > [!NOTE] > This endpoint returns both IPv4 and IPv6 addresses. However, not all features support IPv6. You should refer to the specific documentation for each feature to determine if IPv6 is supported. */
export declare const get: API.OperationMethod<GetRequest, ApiOverview, GetError, GithubOpContext>;
export type GetAllVersionsError = GithubOpError;
/** Get all API versions Get all supported GitHub API versions. */
export declare const getAllVersions: API.OperationMethod<GetAllVersionsRequest, GetAllVersionsResponse, GetAllVersionsError, GithubOpContext>;
export type GetOctocatError = GithubOpError;
/** Get Octocat Get the octocat as ASCII art */
export declare const getOctocat: API.OperationMethod<GetOctocatRequest, GetOctocatResponse, GetOctocatError, GithubOpContext>;
export type GetZenError = GithubOpError;
/** Get the Zen of GitHub Get a random sentence from the Zen of GitHub */
export declare const getZen: API.OperationMethod<GetZenRequest, GetZenResponse, GetZenError, GithubOpContext>;
export type Root2Error = GithubOpError;
/** GitHub API Root Get Hypermedia links to resources accessible in GitHub's REST API */
export declare const root2: API.OperationMethod<Root2Request, Root, Root2Error, GithubOpContext>;
//# sourceMappingURL=meta.d.ts.map