import * as Schema from "effect/Schema";
declare const VaultError_base: Schema.Class<VaultError, Schema.TaggedStruct<"VaultError", {
    readonly subject: Schema.String;
    readonly reason: Schema.String;
}>, import("effect/Cause").YieldableError>;
/** The Vault or its key store failed: a key could not be read, or a box is not one of this vault's. */
export declare class VaultError extends VaultError_base {
    get message(): string;
}
export {};
//# sourceMappingURL=VaultError.d.ts.map