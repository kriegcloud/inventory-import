import { WebhookHost } from "alchemy/WebhookHost";
import * as Layer from "effect/Layer";
import { RepositoryEventSource } from "./RepositoryEventSource.ts";
/**
 * GitHub event source on any {@link WebhookHost}.
 *
 * Deploy-time: provisions a {@link Webhook} on the repository whose delivery
 * URL points at the host (at a deterministic per-repo path). The webhook
 * secret (the caller's `secret`, or a generated random one when omitted) is
 * bound onto the host via an `Output` accessor so the runtime can verify
 * delivery signatures.
 *
 * Runtime: claims requests on the repository's delivery path, verifies the
 * `HMAC-SHA256` signature against the bound secret, and forwards each
 * delivery to the subscriber. Requests on any other path fall through to the
 * host's own handler.
 *
 * Every Cloudflare Worker is a {@link WebhookHost}, so this is the only layer
 * to provide.
 *
 * @layer
 * @product Webhook
 * @provides GitHub.RepositoryEventSource
 */
export declare const RepositoryEventSourceLive: Layer.Layer<RepositoryEventSource, never, WebhookHost>;
//# sourceMappingURL=RepositoryEventSourceLive.d.ts.map