/**
 * Storage and retention of the Effect Cluster host: where each instance
 * keeps its keys, and the sweep that removes the rows only dedupe needs.
 *
 * @internal
 */
import type { InputGateShape } from "alchemy/Workers/InputGate";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import type { SqlClient } from "effect/sql/SqlClient";
import type { ObjectStorage } from "../DurableObjects.ts";
/** Where every instance keeps its storage: one row per key, in the cluster's database. */
export declare const TABLE = "alchemy_domain_objects";
/** The prefix of Effect Cluster's own tables, as a runner's bootstrap creates them. */
export declare const CLUSTER_TABLE_PREFIX = "cluster";
/**
 * Domain's storage for one entity id over the cluster's Postgres. Every
 * operation goes through the instance's input gate, as on Cloudflare. Each
 * row keeps when it was last written (`at`), for retention.
 */
export declare const objectStorage: (sql: SqlClient, object: string, gate: InputGateShape) => ObjectStorage;
/**
 * Create the storage table, or add what a newer host needs to it. Runners
 * start together, so one at a time: the others wait on the lock.
 *
 * A table that has everything gets no DDL: `ALTER TABLE` and `CREATE INDEX`
 * lock the table even when they change nothing, so every runner that starts
 * would wait for the open transactions of the others and hold their queries.
 */
export declare const migrate: (sql: SqlClient) => Effect.Effect<void, never, never>;
/**
 * How long the host keeps rows that only dedupe needs. `"forever"` keeps
 * them.
 */
export interface Retention {
    /**
     * Receipts of accepted commands and committed decisions. A command or
     * decision sent again after this time is decided again.
     * @default "30 days"
     */
    readonly receipts?: Duration.Input | "forever";
    /**
     * The marks that a policy instance ran a delivery. A delivery that arrives
     * again after this time runs again.
     * @default "7 days"
     */
    readonly deliveries?: Duration.Input | "forever";
    /**
     * Cancelled scheduled commands. After this time, `unschedule` answers
     * `NotScheduled` instead of `AlreadyCancelled`.
     * @default "7 days"
     */
    readonly cancelled?: Duration.Input | "forever";
    /**
     * Processed cluster messages to the host's entity (its persisted wakes)
     * and their replies. Effect Cluster never deletes them. Saga messages are
     * left to the workflow engine.
     * @default "7 days"
     */
    readonly messages?: Duration.Input | "forever";
    /**
     * How often each runner sweeps.
     * @default "1 hour"
     */
    readonly interval?: Duration.Input;
}
/** The windows a sweep applies, in milliseconds; `undefined` keeps rows forever. */
export declare const windows: (retention?: Retention) => {
    receipts: number | undefined;
    deliveries: number | undefined;
    cancelled: number | undefined;
    messages: number | undefined;
};
/**
 * Delete the rows of the host entity `entity` that `retention` no longer
 * keeps. Safe to run on every runner at once.
 */
export declare const sweep: (sql: SqlClient, entity: string, retention?: Retention) => Effect.Effect<void, import("effect/sql/SqlError").SqlError, never>;
//# sourceMappingURL=internal.d.ts.map