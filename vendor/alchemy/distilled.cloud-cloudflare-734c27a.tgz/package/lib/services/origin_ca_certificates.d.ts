import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CertificateAlreadyRevoked_base: S.TaggedErrorClass<"CertificateAlreadyRevoked", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CertificateAlreadyRevoked extends /*@__PURE__*/ CertificateAlreadyRevoked_base {
}
declare const CertificateNotFound_base: S.TaggedErrorClass<"CertificateNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CertificateNotFound extends /*@__PURE__*/ CertificateNotFound_base {
}
declare const CertificateRevocationFailed_base: S.TaggedErrorClass<"CertificateRevocationFailed", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CertificateRevocationFailed extends /*@__PURE__*/ CertificateRevocationFailed_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HostnameNotAuthorized_base: S.TaggedErrorClass<"HostnameNotAuthorized", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class HostnameNotAuthorized extends /*@__PURE__*/ HostnameNotAuthorized_base {
}
export type CreateRequestHostnamesList = Array<string>;
export type CreateRequestRequestType = "origin-rsa" | "origin-ecc" | "keyless-certificate";
export type CreateRequestRequestedValidity = 7 | 30 | 90 | 365 | 730 | 1095 | 5475;
export interface CreateOriginCaCertificateRequest {
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr: string;
    /** Array of hostnames or wildcard names bound to the certificate. Hostnames must be fully qualified domain names (FQDNs) belonging to zones on your account (e.g., `example.com` or `sub.example.com`). Wildcards are supported only as a `*.` prefix for a single level (e.g., `*.example.com`). Double wildcards (`*.*.example.com`) and interior wildcards (`foo.*.example.com`) are not allowed. The wildcard suffix must be a multi-label domain (`*.example.com` is valid, but `*.com` is not). Unicode/IDN hostnames are accepted and automatically converted to punycode. */
    hostnames: CreateRequestHostnamesList;
    /** Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers). */
    requestType: CreateRequestRequestType | (string & {});
    /** The number of days for which the certificate should be valid. */
    requestedValidity?: CreateRequestRequestedValidity | (number & {}) | undefined;
    /** Identifier of the zone whose keyless servers the certificate is for. Required when `request_type` is `keyless-certificate`; ignored otherwise. */
    zoneId?: string | undefined;
}
export type CreateResponseHostnamesList = Array<string>;
export type CreateResponseRequestType = "origin-rsa" | "origin-ecc" | "keyless-certificate";
export type CreateResponseRequestedValidity = 7 | 30 | 90 | 365 | 730 | 1095 | 5475;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOriginCaCertificateResponse {
    /** The x509 serial number of the Origin CA certificate. */
    id?: string | null | undefined;
    /** The Origin CA certificate. Will be newline-encoded. */
    certificate?: string | null | undefined;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null | undefined;
    /** When the certificate will expire. */
    expiresOn?: string | null | undefined;
    /** Array of hostnames or wildcard names bound to the certificate. Hostnames must be fully qualified domain names (FQDNs) belonging to zones on your account (e.g., `example.com` or `sub.example.com`). Wildcards are supported only as a `*.` prefix for a single level (e.g., `*.example.com`). Double wildcards (`*.*.example.com`) and interior wildcards (`foo.*.example.com`) are not allowed. The wildcard suffix must be a multi-label domain (`*.example.com` is valid, but `*.com` is not). Unicode/IDN hostnames are accepted and automatically converted to punycode. */
    hostnames?: CreateResponseHostnamesList | null | undefined;
    /** Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers). */
    requestType?: CreateResponseRequestType | null | undefined;
    /** The number of days for which the certificate was requested to be valid. Only returned in the Create Certificate response, where it echoes the requested value. Not returned when getting or listing certificates. */
    requestedValidity?: CreateResponseRequestedValidity | null | undefined;
    /** When the certificate was revoked; absent while the certificate is live. */
    revokedAt?: string | null | undefined;
}
export interface DeleteOriginCaCertificateRequest {
    /** The x509 serial number of the Origin CA certificate. */
    certificateId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOriginCaCertificateResponse {
    /** The x509 serial number of the Origin CA certificate. */
    id?: string | null | undefined;
    /** When the certificate was revoked. */
    revokedAt?: string | null | undefined;
}
export interface GetOriginCaCertificateRequest {
    /** The x509 serial number of the Origin CA certificate. */
    certificateId: string;
}
export type GetResponseHostnamesList = Array<string>;
export type GetResponseRequestType = "origin-rsa" | "origin-ecc" | "keyless-certificate";
export type GetResponseRequestedValidity = 7 | 30 | 90 | 365 | 730 | 1095 | 5475;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOriginCaCertificateResponse {
    /** The x509 serial number of the Origin CA certificate. */
    id?: string | null | undefined;
    /** The Origin CA certificate. Will be newline-encoded. */
    certificate?: string | null | undefined;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null | undefined;
    /** When the certificate will expire. */
    expiresOn?: string | null | undefined;
    /** Array of hostnames or wildcard names bound to the certificate. Hostnames must be fully qualified domain names (FQDNs) belonging to zones on your account (e.g., `example.com` or `sub.example.com`). Wildcards are supported only as a `*.` prefix for a single level (e.g., `*.example.com`). Double wildcards (`*.*.example.com`) and interior wildcards (`foo.*.example.com`) are not allowed. The wildcard suffix must be a multi-label domain (`*.example.com` is valid, but `*.com` is not). Unicode/IDN hostnames are accepted and automatically converted to punycode. */
    hostnames?: GetResponseHostnamesList | null | undefined;
    /** Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers). */
    requestType?: GetResponseRequestType | null | undefined;
    /** The number of days for which the certificate was requested to be valid. Only returned in the Create Certificate response, where it echoes the requested value. Not returned when getting or listing certificates. */
    requestedValidity?: GetResponseRequestedValidity | null | undefined;
    /** When the certificate was revoked; absent while the certificate is live. */
    revokedAt?: string | null | undefined;
}
export interface ListOriginCaCertificatesRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of records per page. */
    perPage?: number | undefined;
}
export type ListResultItemHostnamesList = Array<string>;
export type ListResultItemRequestType = "origin-rsa" | "origin-ecc" | "keyless-certificate";
export type ListResultItemRequestedValidity = 7 | 30 | 90 | 365 | 730 | 1095 | 5475;
export interface ListResultItem {
    /** The x509 serial number of the Origin CA certificate. */
    id?: string | null | undefined;
    /** The Origin CA certificate. Will be newline-encoded. */
    certificate?: string | null | undefined;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null | undefined;
    /** When the certificate will expire. */
    expiresOn?: string | null | undefined;
    /** Array of hostnames or wildcard names bound to the certificate. Hostnames must be fully qualified domain names (FQDNs) belonging to zones on your account (e.g., `example.com` or `sub.example.com`). Wildcards are supported only as a `*.` prefix for a single level (e.g., `*.example.com`). Double wildcards (`*.*.example.com`) and interior wildcards (`foo.*.example.com`) are not allowed. The wildcard suffix must be a multi-label domain (`*.example.com` is valid, but `*.com` is not). Unicode/IDN hostnames are accepted and automatically converted to punycode. */
    hostnames?: ListResultItemHostnamesList | null | undefined;
    /** Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers). */
    requestType?: ListResultItemRequestType | null | undefined;
    /** The number of days for which the certificate was requested to be valid. Only returned in the Create Certificate response, where it echoes the requested value. Not returned when getting or listing certificates. */
    requestedValidity?: ListResultItemRequestedValidity | null | undefined;
    /** When the certificate was revoked; absent while the certificate is live. */
    revokedAt?: string | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListOriginCaCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type CreateOriginCaCertificateError = HostnameNotAuthorized | Forbidden | CloudflareOpError;
/** Create an Origin CA certificate. For `keyless-certificate` requests, `zone_id` is required and the response contains only `id`, `certificate`, and `expires_on`. You can use an Origin CA Key as your User Service Key or an API token when calling this endpoint ([see above](#requests)). */
export declare const createOriginCaCertificate: API.OperationMethod<CreateOriginCaCertificateRequest, CreateOriginCaCertificateResponse, CreateOriginCaCertificateError, CloudflareOpContext>;
export type DeleteOriginCaCertificateError = CertificateNotFound | CertificateAlreadyRevoked | CertificateRevocationFailed | Forbidden | CloudflareOpError;
/** Revoke an existing Origin CA certificate by its serial number. You can use an Origin CA Key as your User Service Key or an API token when calling this endpoint ([see above](#requests)). */
export declare const deleteOriginCaCertificate: API.OperationMethod<DeleteOriginCaCertificateRequest, DeleteOriginCaCertificateResponse, DeleteOriginCaCertificateError, CloudflareOpContext>;
export type GetOriginCaCertificateError = CertificateNotFound | Forbidden | CloudflareOpError;
/** Get an existing Origin CA certificate by its serial number. You can use an Origin CA Key as your User Service Key or an API token when calling this endpoint ([see above](#requests)). */
export declare const getOriginCaCertificate: API.OperationMethod<GetOriginCaCertificateRequest, GetOriginCaCertificateResponse, GetOriginCaCertificateError, CloudflareOpContext>;
export type ListOriginCaCertificatesError = Forbidden | CloudflareOpError;
/** List all existing Origin CA certificates for a given zone. Revoked certificates are not included. You can use an Origin CA Key as your User Service Key or an API token when calling this endpoint ([see above](#requests)). */
export declare const listOriginCaCertificates: API.PaginatedOperationMethod<ListOriginCaCertificatesRequest, ListOriginCaCertificatesResponse, ListOriginCaCertificatesError, CloudflareOpContext, ListResultItem>;
//# sourceMappingURL=origin_ca_certificates.d.ts.map