import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The type of repositories to attach the configuration to. `selected` means the configuration will be attached to only the repositories specified by `selected_repository_ids` */
export type AttachConfigurationRequestScope = "all" | "all_without_configurations" | "public" | "private_or_internal" | "selected";
/** An array of repository IDs to attach the configuration to. You can only provide a list of repository ids when the `scope` is set to `selected`. */
export type AttachConfigurationRequestSelectedRepositoryIdsList = Array<number>;
export interface AttachConfigurationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
    /** The type of repositories to attach the configuration to. `selected` means the configuration will be attached to only the repositories specified by `selected_repository_ids` */
    scope: AttachConfigurationRequestScope | (string & {});
    /** An array of repository IDs to attach the configuration to. You can only provide a list of repository ids when the `scope` is set to `selected`. */
    selected_repository_ids?: AttachConfigurationRequestSelectedRepositoryIdsList | undefined;
}
export interface AttachConfigurationResponse {
}
/** The type of repositories to attach the configuration to. */
export type AttachEnterpriseConfigurationRequestScope = "all" | "all_without_configurations";
export interface AttachEnterpriseConfigurationRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
    /** The type of repositories to attach the configuration to. */
    scope: AttachEnterpriseConfigurationRequestScope | (string & {});
}
export interface AttachEnterpriseConfigurationResponse {
}
/** The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. > [!WARNING] > `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. */
export type CreateConfigurationRequestAdvancedSecurity = "enabled" | "disabled" | "code_security" | "secret_protection";
/** The enablement status of GitHub Code Security features. */
export type CreateConfigurationRequestCodeSecurity = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependency Graph */
export type CreateConfigurationRequestDependencyGraph = "enabled" | "disabled" | "not_set";
/** The enablement status of Automatic dependency submission */
export type CreateConfigurationRequestDependencyGraphAutosubmitAction = "enabled" | "disabled" | "not_set";
/** Feature options for Automatic dependency submission */
export interface CreateConfigurationRequestDependencyGraphAutosubmitActionOptions {
    /** Whether to use runners labeled with 'dependency-submission' or standard GitHub runners. */
    labeled_runners?: boolean | undefined;
}
/** The enablement status of Dependabot alerts */
export type CreateConfigurationRequestDependabotAlerts = "enabled" | "disabled" | "not_set";
/** The enablement status of reachability analysis for Dependabot. Only available for organizations with access to reachability analysis. Requires Dependabot alerts to be enabled when set to `enabled`. Must be `disabled` when Dependabot alerts is `disabled`. `not_set` leaves existing repository settings unchanged. */
export type CreateConfigurationRequestDependabotReachability = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependabot security updates */
export type CreateConfigurationRequestDependabotSecurityUpdates = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependabot delegated alert dismissal. Requires Dependabot alerts to be enabled. */
export type CreateConfigurationRequestDependabotDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** Security Configuration feature options for code scanning */
export interface CodeScanningOptions {
    /** Whether to allow repos which use advanced setup */
    allow_advanced?: boolean | null | undefined;
}
/** The enablement status of code scanning default setup */
export type CreateConfigurationRequestCodeScanningDefaultSetup = "enabled" | "disabled" | "not_set";
/** Whether to use labeled runners or standard GitHub runners. */
export type CodeScanningDefaultSetupOptionsRunnerType = "standard" | "labeled" | "not_set";
/** Feature options for code scanning default setup */
export interface CodeScanningDefaultSetupOptions {
    /** Whether to use labeled runners or standard GitHub runners. */
    runner_type?: CodeScanningDefaultSetupOptionsRunnerType | (string & {}) | undefined;
    /** The label of the runner to use for code scanning default setup when runner_type is 'labeled'. */
    runner_label?: string | null | undefined;
}
/** The enablement status of code scanning delegated alert dismissal */
export type CreateConfigurationRequestCodeScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of GitHub Secret Protection features. */
export type CreateConfigurationRequestSecretProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning */
export type CreateConfigurationRequestSecretScanning = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning push protection */
export type CreateConfigurationRequestSecretScanningPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning delegated bypass */
export type CreateConfigurationRequestSecretScanningDelegatedBypass = "enabled" | "disabled" | "not_set";
/** The type of the bypass reviewer */
export type CreateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type CreateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface CreateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: CreateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItemReviewerType | (string & {});
    /** The bypass mode for the reviewer */
    mode?: CreateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItemMode | (string & {}) | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type CreateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersList = Array<CreateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItem>;
/** Feature options for secret scanning delegated bypass */
export interface CreateConfigurationRequestSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: CreateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
/** The enablement status of secret scanning validity checks */
export type CreateConfigurationRequestSecretScanningValidityChecks = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning non provider patterns */
export type CreateConfigurationRequestSecretScanningNonProviderPatterns = "enabled" | "disabled" | "not_set";
/** The enablement status of Copilot secret scanning */
export type CreateConfigurationRequestSecretScanningGenericSecrets = "enabled" | "disabled" | "not_set";
/** The enablement status of generic secrets push protection */
export type CreateConfigurationRequestSecretScanningGenericSecretsPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning delegated alert dismissal */
export type CreateConfigurationRequestSecretScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning extended metadata */
export type CreateConfigurationRequestSecretScanningExtendedMetadata = "enabled" | "disabled" | "not_set";
/** The enablement status of private vulnerability reporting */
export type CreateConfigurationRequestPrivateVulnerabilityReporting = "enabled" | "disabled" | "not_set";
/** The enforcement status for a security configuration */
export type CreateConfigurationRequestEnforcement = "enforced" | "unenforced";
export interface CreateConfigurationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the code security configuration. Must be unique within the organization. */
    name: string;
    /** A description of the code security configuration */
    description?: string | undefined;
    /** The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. > [!WARNING] > `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. */
    advanced_security?: CreateConfigurationRequestAdvancedSecurity | (string & {}) | undefined;
    /** The enablement status of GitHub Code Security features. */
    code_security?: CreateConfigurationRequestCodeSecurity | (string & {}) | undefined;
    /** The enablement status of Dependency Graph */
    dependency_graph?: CreateConfigurationRequestDependencyGraph | (string & {}) | undefined;
    /** The enablement status of Automatic dependency submission */
    dependency_graph_autosubmit_action?: CreateConfigurationRequestDependencyGraphAutosubmitAction | (string & {}) | undefined;
    /** Feature options for Automatic dependency submission */
    dependency_graph_autosubmit_action_options?: CreateConfigurationRequestDependencyGraphAutosubmitActionOptions | undefined;
    /** The enablement status of Dependabot alerts */
    dependabot_alerts?: CreateConfigurationRequestDependabotAlerts | (string & {}) | undefined;
    /** The enablement status of reachability analysis for Dependabot. Only available for organizations with access to reachability analysis. Requires Dependabot alerts to be enabled when set to `enabled`. Must be `disabled` when Dependabot alerts is `disabled`. `not_set` leaves existing repository settings unchanged. */
    dependabot_reachability?: CreateConfigurationRequestDependabotReachability | (string & {}) | undefined;
    /** The enablement status of Dependabot security updates */
    dependabot_security_updates?: CreateConfigurationRequestDependabotSecurityUpdates | (string & {}) | undefined;
    /** The enablement status of Dependabot delegated alert dismissal. Requires Dependabot alerts to be enabled. */
    dependabot_delegated_alert_dismissal?: CreateConfigurationRequestDependabotDelegatedAlertDismissal | (string & {}) | undefined;
    code_scanning_options?: CodeScanningOptions | null | undefined;
    /** The enablement status of code scanning default setup */
    code_scanning_default_setup?: CreateConfigurationRequestCodeScanningDefaultSetup | (string & {}) | undefined;
    code_scanning_default_setup_options?: CodeScanningDefaultSetupOptions | null | undefined;
    /** The enablement status of code scanning delegated alert dismissal */
    code_scanning_delegated_alert_dismissal?: CreateConfigurationRequestCodeScanningDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of GitHub Secret Protection features. */
    secret_protection?: CreateConfigurationRequestSecretProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning */
    secret_scanning?: CreateConfigurationRequestSecretScanning | (string & {}) | undefined;
    /** The enablement status of secret scanning push protection */
    secret_scanning_push_protection?: CreateConfigurationRequestSecretScanningPushProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning delegated bypass */
    secret_scanning_delegated_bypass?: CreateConfigurationRequestSecretScanningDelegatedBypass | (string & {}) | undefined;
    /** Feature options for secret scanning delegated bypass */
    secret_scanning_delegated_bypass_options?: CreateConfigurationRequestSecretScanningDelegatedBypassOptions | undefined;
    /** The enablement status of secret scanning validity checks */
    secret_scanning_validity_checks?: CreateConfigurationRequestSecretScanningValidityChecks | (string & {}) | undefined;
    /** The enablement status of secret scanning non provider patterns */
    secret_scanning_non_provider_patterns?: CreateConfigurationRequestSecretScanningNonProviderPatterns | (string & {}) | undefined;
    /** The enablement status of Copilot secret scanning */
    secret_scanning_generic_secrets?: CreateConfigurationRequestSecretScanningGenericSecrets | (string & {}) | undefined;
    /** The enablement status of generic secrets push protection */
    secret_scanning_generic_secrets_push_protection?: CreateConfigurationRequestSecretScanningGenericSecretsPushProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning delegated alert dismissal */
    secret_scanning_delegated_alert_dismissal?: CreateConfigurationRequestSecretScanningDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of secret scanning extended metadata */
    secret_scanning_extended_metadata?: CreateConfigurationRequestSecretScanningExtendedMetadata | (string & {}) | undefined;
    /** The enablement status of private vulnerability reporting */
    private_vulnerability_reporting?: CreateConfigurationRequestPrivateVulnerabilityReporting | (string & {}) | undefined;
    /** The enforcement status for a security configuration */
    enforcement?: CreateConfigurationRequestEnforcement | (string & {}) | undefined;
}
/** The type of the code security configuration. */
export type CodeSecurityConfigurationTargetType = "global" | "organization" | "enterprise";
/** The enablement status of GitHub Advanced Security */
export type CodeSecurityConfigurationAdvancedSecurity = "enabled" | "disabled" | "code_security" | "secret_protection";
/** The enablement status of Dependency Graph */
export type CodeSecurityConfigurationDependencyGraph = "enabled" | "disabled" | "not_set";
/** The enablement status of Automatic dependency submission */
export type CodeSecurityConfigurationDependencyGraphAutosubmitAction = "enabled" | "disabled" | "not_set";
/** Feature options for Automatic dependency submission */
export type CodeSecurityConfigurationDependencyGraphAutosubmitActionOptions = CreateConfigurationRequestDependencyGraphAutosubmitActionOptions;
/** The enablement status of Dependabot alerts */
export type CodeSecurityConfigurationDependabotAlerts = "enabled" | "disabled" | "not_set";
/** The enablement status of reachability analysis for Dependabot. Only returned for organizations and enterprises with access to reachability analysis. */
export type CodeSecurityConfigurationDependabotReachability = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependabot security updates */
export type CodeSecurityConfigurationDependabotSecurityUpdates = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependabot delegated alert dismissal */
export type CodeSecurityConfigurationDependabotDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** Feature options for code scanning */
export type CodeSecurityConfigurationCodeScanningOptions = CodeScanningOptions;
/** The enablement status of code scanning default setup */
export type CodeSecurityConfigurationCodeScanningDefaultSetup = "enabled" | "disabled" | "not_set";
/** Whether to use labeled runners or standard GitHub runners. */
export type CodeSecurityConfigurationCodeScanningDefaultSetupOptionsRunnerType = "standard" | "labeled" | "not_set";
/** Feature options for code scanning default setup */
export interface CodeSecurityConfigurationCodeScanningDefaultSetupOptions {
    /** Whether to use labeled runners or standard GitHub runners. */
    runner_type?: CodeSecurityConfigurationCodeScanningDefaultSetupOptionsRunnerType | null | undefined;
    /** The label of the runner to use for code scanning when runner_type is 'labeled'. */
    runner_label?: string | null | undefined;
}
/** The enablement status of code scanning delegated alert dismissal */
export type CodeSecurityConfigurationCodeScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning */
export type CodeSecurityConfigurationSecretScanning = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning push protection */
export type CodeSecurityConfigurationSecretScanningPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning delegated bypass */
export type CodeSecurityConfigurationSecretScanningDelegatedBypass = "enabled" | "disabled" | "not_set";
/** The type of the bypass reviewer */
export type CodeSecurityConfigurationSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type CodeSecurityConfigurationSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface CodeSecurityConfigurationSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: CodeSecurityConfigurationSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: CodeSecurityConfigurationSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
    /** The ID of the security configuration associated with this bypass reviewer */
    security_configuration_id?: number | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type CodeSecurityConfigurationSecretScanningDelegatedBypassOptionsReviewersList = Array<CodeSecurityConfigurationSecretScanningDelegatedBypassOptionsReviewersItem>;
/** Feature options for secret scanning delegated bypass */
export interface CodeSecurityConfigurationSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: CodeSecurityConfigurationSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
/** The enablement status of secret scanning validity checks */
export type CodeSecurityConfigurationSecretScanningValidityChecks = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning non-provider patterns */
export type CodeSecurityConfigurationSecretScanningNonProviderPatterns = "enabled" | "disabled" | "not_set";
/** The enablement status of Copilot secret scanning */
export type CodeSecurityConfigurationSecretScanningGenericSecrets = "enabled" | "disabled" | "not_set";
/** The enablement status of generic secrets push protection */
export type CodeSecurityConfigurationSecretScanningGenericSecretsPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning delegated alert dismissal */
export type CodeSecurityConfigurationSecretScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning extended metadata */
export type CodeSecurityConfigurationSecretScanningExtendedMetadata = "enabled" | "disabled" | "not_set";
/** The enablement status of private vulnerability reporting */
export type CodeSecurityConfigurationPrivateVulnerabilityReporting = "enabled" | "disabled" | "not_set";
/** The enforcement status for a security configuration */
export type CodeSecurityConfigurationEnforcement = "enforced" | "unenforced" | "enterprise_enforced";
/** A code security configuration */
export interface CodeSecurityConfiguration {
    /** The ID of the code security configuration */
    id?: number | undefined;
    /** The name of the code security configuration. Must be unique within the organization. */
    name?: string | undefined;
    /** The type of the code security configuration. */
    target_type?: CodeSecurityConfigurationTargetType | undefined;
    /** A description of the code security configuration */
    description?: string | null | undefined;
    /** The enablement status of GitHub Advanced Security */
    advanced_security?: CodeSecurityConfigurationAdvancedSecurity | undefined;
    /** The enablement status of Dependency Graph */
    dependency_graph?: CodeSecurityConfigurationDependencyGraph | undefined;
    /** The enablement status of Automatic dependency submission */
    dependency_graph_autosubmit_action?: CodeSecurityConfigurationDependencyGraphAutosubmitAction | undefined;
    /** Feature options for Automatic dependency submission */
    dependency_graph_autosubmit_action_options?: CreateConfigurationRequestDependencyGraphAutosubmitActionOptions | undefined;
    /** The enablement status of Dependabot alerts */
    dependabot_alerts?: CodeSecurityConfigurationDependabotAlerts | undefined;
    /** The enablement status of reachability analysis for Dependabot. Only returned for organizations and enterprises with access to reachability analysis. */
    dependabot_reachability?: CodeSecurityConfigurationDependabotReachability | undefined;
    /** The enablement status of Dependabot security updates */
    dependabot_security_updates?: CodeSecurityConfigurationDependabotSecurityUpdates | undefined;
    /** The enablement status of Dependabot delegated alert dismissal */
    dependabot_delegated_alert_dismissal?: CodeSecurityConfigurationDependabotDelegatedAlertDismissal | null | undefined;
    /** Feature options for code scanning */
    code_scanning_options?: CodeScanningOptions | null | undefined;
    /** The enablement status of code scanning default setup */
    code_scanning_default_setup?: CodeSecurityConfigurationCodeScanningDefaultSetup | undefined;
    /** Feature options for code scanning default setup */
    code_scanning_default_setup_options?: CodeSecurityConfigurationCodeScanningDefaultSetupOptions | null | undefined;
    /** The enablement status of code scanning delegated alert dismissal */
    code_scanning_delegated_alert_dismissal?: CodeSecurityConfigurationCodeScanningDelegatedAlertDismissal | undefined;
    /** The enablement status of secret scanning */
    secret_scanning?: CodeSecurityConfigurationSecretScanning | undefined;
    /** The enablement status of secret scanning push protection */
    secret_scanning_push_protection?: CodeSecurityConfigurationSecretScanningPushProtection | undefined;
    /** The enablement status of secret scanning delegated bypass */
    secret_scanning_delegated_bypass?: CodeSecurityConfigurationSecretScanningDelegatedBypass | undefined;
    /** Feature options for secret scanning delegated bypass */
    secret_scanning_delegated_bypass_options?: CodeSecurityConfigurationSecretScanningDelegatedBypassOptions | undefined;
    /** The enablement status of secret scanning validity checks */
    secret_scanning_validity_checks?: CodeSecurityConfigurationSecretScanningValidityChecks | undefined;
    /** The enablement status of secret scanning non-provider patterns */
    secret_scanning_non_provider_patterns?: CodeSecurityConfigurationSecretScanningNonProviderPatterns | undefined;
    /** The enablement status of Copilot secret scanning */
    secret_scanning_generic_secrets?: CodeSecurityConfigurationSecretScanningGenericSecrets | undefined;
    /** The enablement status of generic secrets push protection */
    secret_scanning_generic_secrets_push_protection?: CodeSecurityConfigurationSecretScanningGenericSecretsPushProtection | undefined;
    /** The enablement status of secret scanning delegated alert dismissal */
    secret_scanning_delegated_alert_dismissal?: CodeSecurityConfigurationSecretScanningDelegatedAlertDismissal | undefined;
    /** The enablement status of secret scanning extended metadata */
    secret_scanning_extended_metadata?: CodeSecurityConfigurationSecretScanningExtendedMetadata | undefined;
    /** The enablement status of private vulnerability reporting */
    private_vulnerability_reporting?: CodeSecurityConfigurationPrivateVulnerabilityReporting | undefined;
    /** The enforcement status for a security configuration */
    enforcement?: CodeSecurityConfigurationEnforcement | undefined;
    /** The URL of the configuration */
    url?: string | undefined;
    /** The URL of the configuration */
    html_url?: string | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
}
/** The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. > [!WARNING] > `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. */
export type CreateConfigurationForEnterpriseRequestAdvancedSecurity = "enabled" | "disabled" | "code_security" | "secret_protection";
/** The enablement status of GitHub Code Security features. */
export type CreateConfigurationForEnterpriseRequestCodeSecurity = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependency Graph */
export type CreateConfigurationForEnterpriseRequestDependencyGraph = "enabled" | "disabled" | "not_set";
/** The enablement status of Automatic dependency submission */
export type CreateConfigurationForEnterpriseRequestDependencyGraphAutosubmitAction = "enabled" | "disabled" | "not_set";
/** Feature options for Automatic dependency submission */
export type CreateConfigurationForEnterpriseRequestDependencyGraphAutosubmitActionOptions = CreateConfigurationRequestDependencyGraphAutosubmitActionOptions;
/** The enablement status of Dependabot alerts */
export type CreateConfigurationForEnterpriseRequestDependabotAlerts = "enabled" | "disabled" | "not_set";
/** The enablement status of reachability analysis for Dependabot. Only available for enterprises with access to reachability analysis. Requires Dependabot alerts to be enabled when set to `enabled`. Must be `disabled` when Dependabot alerts is `disabled`. `not_set` leaves existing repository settings unchanged. */
export type CreateConfigurationForEnterpriseRequestDependabotReachability = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependabot security updates */
export type CreateConfigurationForEnterpriseRequestDependabotSecurityUpdates = "enabled" | "disabled" | "not_set";
/** The enablement status of code scanning default setup */
export type CreateConfigurationForEnterpriseRequestCodeScanningDefaultSetup = "enabled" | "disabled" | "not_set";
/** The enablement status of code scanning delegated alert dismissal */
export type CreateConfigurationForEnterpriseRequestCodeScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of GitHub Secret Protection features. */
export type CreateConfigurationForEnterpriseRequestSecretProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning */
export type CreateConfigurationForEnterpriseRequestSecretScanning = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning push protection */
export type CreateConfigurationForEnterpriseRequestSecretScanningPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning validity checks */
export type CreateConfigurationForEnterpriseRequestSecretScanningValidityChecks = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning non provider patterns */
export type CreateConfigurationForEnterpriseRequestSecretScanningNonProviderPatterns = "enabled" | "disabled" | "not_set";
/** The enablement status of Copilot secret scanning */
export type CreateConfigurationForEnterpriseRequestSecretScanningGenericSecrets = "enabled" | "disabled" | "not_set";
/** The enablement status of generic secrets push protection */
export type CreateConfigurationForEnterpriseRequestSecretScanningGenericSecretsPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning delegated alert dismissal */
export type CreateConfigurationForEnterpriseRequestSecretScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning extended metadata */
export type CreateConfigurationForEnterpriseRequestSecretScanningExtendedMetadata = "enabled" | "disabled" | "not_set";
/** The enablement status of private vulnerability reporting */
export type CreateConfigurationForEnterpriseRequestPrivateVulnerabilityReporting = "enabled" | "disabled" | "not_set";
/** The enforcement status for a security configuration */
export type CreateConfigurationForEnterpriseRequestEnforcement = "enforced" | "unenforced" | "enterprise_enforced";
export interface CreateConfigurationForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The name of the code security configuration. Must be unique within the enterprise. */
    name: string;
    /** A description of the code security configuration */
    description?: string | undefined;
    /** The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. > [!WARNING] > `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. */
    advanced_security?: CreateConfigurationForEnterpriseRequestAdvancedSecurity | (string & {}) | undefined;
    /** The enablement status of GitHub Code Security features. */
    code_security?: CreateConfigurationForEnterpriseRequestCodeSecurity | (string & {}) | undefined;
    /** The enablement status of Dependency Graph */
    dependency_graph?: CreateConfigurationForEnterpriseRequestDependencyGraph | (string & {}) | undefined;
    /** The enablement status of Automatic dependency submission */
    dependency_graph_autosubmit_action?: CreateConfigurationForEnterpriseRequestDependencyGraphAutosubmitAction | (string & {}) | undefined;
    /** Feature options for Automatic dependency submission */
    dependency_graph_autosubmit_action_options?: CreateConfigurationRequestDependencyGraphAutosubmitActionOptions | undefined;
    /** The enablement status of Dependabot alerts */
    dependabot_alerts?: CreateConfigurationForEnterpriseRequestDependabotAlerts | (string & {}) | undefined;
    /** The enablement status of reachability analysis for Dependabot. Only available for enterprises with access to reachability analysis. Requires Dependabot alerts to be enabled when set to `enabled`. Must be `disabled` when Dependabot alerts is `disabled`. `not_set` leaves existing repository settings unchanged. */
    dependabot_reachability?: CreateConfigurationForEnterpriseRequestDependabotReachability | (string & {}) | undefined;
    /** The enablement status of Dependabot security updates */
    dependabot_security_updates?: CreateConfigurationForEnterpriseRequestDependabotSecurityUpdates | (string & {}) | undefined;
    code_scanning_options?: CodeScanningOptions | null | undefined;
    /** The enablement status of code scanning default setup */
    code_scanning_default_setup?: CreateConfigurationForEnterpriseRequestCodeScanningDefaultSetup | (string & {}) | undefined;
    code_scanning_default_setup_options?: CodeScanningDefaultSetupOptions | null | undefined;
    /** The enablement status of code scanning delegated alert dismissal */
    code_scanning_delegated_alert_dismissal?: CreateConfigurationForEnterpriseRequestCodeScanningDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of GitHub Secret Protection features. */
    secret_protection?: CreateConfigurationForEnterpriseRequestSecretProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning */
    secret_scanning?: CreateConfigurationForEnterpriseRequestSecretScanning | (string & {}) | undefined;
    /** The enablement status of secret scanning push protection */
    secret_scanning_push_protection?: CreateConfigurationForEnterpriseRequestSecretScanningPushProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning validity checks */
    secret_scanning_validity_checks?: CreateConfigurationForEnterpriseRequestSecretScanningValidityChecks | (string & {}) | undefined;
    /** The enablement status of secret scanning non provider patterns */
    secret_scanning_non_provider_patterns?: CreateConfigurationForEnterpriseRequestSecretScanningNonProviderPatterns | (string & {}) | undefined;
    /** The enablement status of Copilot secret scanning */
    secret_scanning_generic_secrets?: CreateConfigurationForEnterpriseRequestSecretScanningGenericSecrets | (string & {}) | undefined;
    /** The enablement status of generic secrets push protection */
    secret_scanning_generic_secrets_push_protection?: CreateConfigurationForEnterpriseRequestSecretScanningGenericSecretsPushProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning delegated alert dismissal */
    secret_scanning_delegated_alert_dismissal?: CreateConfigurationForEnterpriseRequestSecretScanningDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of secret scanning extended metadata */
    secret_scanning_extended_metadata?: CreateConfigurationForEnterpriseRequestSecretScanningExtendedMetadata | (string & {}) | undefined;
    /** The enablement status of private vulnerability reporting */
    private_vulnerability_reporting?: CreateConfigurationForEnterpriseRequestPrivateVulnerabilityReporting | (string & {}) | undefined;
    /** The enforcement status for a security configuration */
    enforcement?: CreateConfigurationForEnterpriseRequestEnforcement | (string & {}) | undefined;
}
export interface DeleteConfigurationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
}
export interface DeleteConfigurationResponse {
}
export interface DeleteConfigurationForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
}
export interface DeleteConfigurationForEnterpriseResponse {
}
/** An array of repository IDs to detach from configurations. Up to 250 IDs can be provided. */
export type DetachConfigurationRequestSelectedRepositoryIdsList = Array<number>;
export interface DetachConfigurationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** An array of repository IDs to detach from configurations. Up to 250 IDs can be provided. */
    selected_repository_ids: DetachConfigurationRequestSelectedRepositoryIdsList;
}
export interface DetachConfigurationResponse {
}
export interface GetConfigurationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
}
export interface GetConfigurationForRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** The attachment status of the code security configuration on the repository. */
export type CodeSecurityConfigurationForRepositoryStatus = "attached" | "attaching" | "detached" | "removed" | "enforced" | "failed" | "updating" | "removed_by_enterprise" | "enterprise_enforced";
/** Code security configuration associated with a repository and attachment status */
export interface CodeSecurityConfigurationForRepository {
    /** The attachment status of the code security configuration on the repository. */
    status?: CodeSecurityConfigurationForRepositoryStatus | undefined;
    configuration?: CodeSecurityConfiguration | undefined;
}
export interface GetConfigurationsForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
}
export type GetConfigurationsForEnterpriseResponseBodyList = Array<CodeSecurityConfiguration>;
export type GetConfigurationsForEnterpriseResponse = GetConfigurationsForEnterpriseResponseBodyList;
export type GetConfigurationsForOrgRequestTargetType = "global" | "all";
export interface GetConfigurationsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The target type of the code security configuration */
    target_type?: GetConfigurationsForOrgRequestTargetType | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
}
export type GetConfigurationsForOrgResponseBodyList = Array<CodeSecurityConfiguration>;
export type GetConfigurationsForOrgResponse = GetConfigurationsForOrgResponseBodyList;
export interface GetDefaultConfigurationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The visibility of newly created repositories for which the code security configuration will be applied to by default */
export type CodeSecurityDefaultConfigurationsItemDefaultForNewRepos = "public" | "private_and_internal" | "all";
export interface CodeSecurityDefaultConfigurationsItem {
    /** The visibility of newly created repositories for which the code security configuration will be applied to by default */
    default_for_new_repos?: CodeSecurityDefaultConfigurationsItemDefaultForNewRepos | undefined;
    configuration?: CodeSecurityConfiguration | undefined;
}
/** A list of default code security configurations */
export type CodeSecurityDefaultConfigurations = Array<CodeSecurityDefaultConfigurationsItem>;
export type GetDefaultConfigurationsResponse = CodeSecurityDefaultConfigurations;
export interface GetDefaultConfigurationsForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
}
export type GetDefaultConfigurationsForEnterpriseResponse = CodeSecurityDefaultConfigurations;
export interface GetRepositoriesForConfigurationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** A comma-separated list of statuses. If specified, only repositories with these attachment statuses will be returned. Can be: `all`, `attached`, `attaching`, `detached`, `removed`, `enforced`, `failed`, `updating`, `removed_by_enterprise`, `enterprise_enforced` */
    status?: string | undefined;
}
/** The attachment status of the code security configuration on the repository. */
export type CodeSecurityConfigurationRepositoriesStatus = "attached" | "attaching" | "detached" | "removed" | "enforced" | "failed" | "updating" | "removed_by_enterprise" | "enterprise_enforced";
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** A GitHub repository. */
export interface SimpleRepository {
    /** A unique identifier of the repository. */
    id: number;
    /** The GraphQL identifier of the repository. */
    node_id: string;
    /** The name of the repository. */
    name: string;
    /** The full, globally unique, name of the repository. */
    full_name: string;
    owner: SimpleUser;
    /** Whether the repository is private. */
    private: boolean;
    /** The URL to view the repository on GitHub.com. */
    html_url: string;
    /** The repository description. */
    description: string | null;
    /** Whether the repository is a fork. */
    fork: boolean;
    /** The URL to get more information about the repository from the GitHub API. */
    url: string;
    /** A template for the API URL to download the repository as an archive. */
    archive_url: string;
    /** A template for the API URL to list the available assignees for issues in the repository. */
    assignees_url: string;
    /** A template for the API URL to create or retrieve a raw Git blob in the repository. */
    blobs_url: string;
    /** A template for the API URL to get information about branches in the repository. */
    branches_url: string;
    /** A template for the API URL to get information about collaborators of the repository. */
    collaborators_url: string;
    /** A template for the API URL to get information about comments on the repository. */
    comments_url: string;
    /** A template for the API URL to get information about commits on the repository. */
    commits_url: string;
    /** A template for the API URL to compare two commits or refs. */
    compare_url: string;
    /** A template for the API URL to get the contents of the repository. */
    contents_url: string;
    /** A template for the API URL to list the contributors to the repository. */
    contributors_url: string;
    /** The API URL to list the deployments of the repository. */
    deployments_url: string;
    /** The API URL to list the downloads on the repository. */
    downloads_url: string;
    /** The API URL to list the events of the repository. */
    events_url: string;
    /** The API URL to list the forks of the repository. */
    forks_url: string;
    /** A template for the API URL to get information about Git commits of the repository. */
    git_commits_url: string;
    /** A template for the API URL to get information about Git refs of the repository. */
    git_refs_url: string;
    /** A template for the API URL to get information about Git tags of the repository. */
    git_tags_url: string;
    /** A template for the API URL to get information about issue comments on the repository. */
    issue_comment_url: string;
    /** A template for the API URL to get information about issue events on the repository. */
    issue_events_url: string;
    /** A template for the API URL to get information about issues on the repository. */
    issues_url: string;
    /** A template for the API URL to get information about deploy keys on the repository. */
    keys_url: string;
    /** A template for the API URL to get information about labels of the repository. */
    labels_url: string;
    /** The API URL to get information about the languages of the repository. */
    languages_url: string;
    /** The API URL to merge branches in the repository. */
    merges_url: string;
    /** A template for the API URL to get information about milestones of the repository. */
    milestones_url: string;
    /** A template for the API URL to get information about notifications on the repository. */
    notifications_url: string;
    /** A template for the API URL to get information about pull requests on the repository. */
    pulls_url: string;
    /** A template for the API URL to get information about releases on the repository. */
    releases_url: string;
    /** The API URL to list the stargazers on the repository. */
    stargazers_url: string;
    /** A template for the API URL to get information about statuses of a commit. */
    statuses_url: string;
    /** The API URL to list the subscribers on the repository. */
    subscribers_url: string;
    /** The API URL to subscribe to notifications for this repository. */
    subscription_url: string;
    /** The API URL to get information about tags on the repository. */
    tags_url: string;
    /** The API URL to list the teams on the repository. */
    teams_url: string;
    /** A template for the API URL to create or retrieve a raw Git tree of the repository. */
    trees_url: string;
    /** The API URL to list the hooks on the repository. */
    hooks_url: string;
}
/** Repositories associated with a code security configuration and attachment status */
export interface CodeSecurityConfigurationRepositories {
    /** The attachment status of the code security configuration on the repository. */
    status?: CodeSecurityConfigurationRepositoriesStatus | undefined;
    repository?: SimpleRepository | undefined;
}
export type GetRepositoriesForConfigurationResponseBodyList = Array<CodeSecurityConfigurationRepositories>;
export type GetRepositoriesForConfigurationResponse = GetRepositoriesForConfigurationResponseBodyList;
export interface GetRepositoriesForEnterpriseConfigurationRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** A comma-separated list of statuses. If specified, only repositories with these attachment statuses will be returned. Can be: `all`, `attached`, `attaching`, `removed`, `enforced`, `failed`, `updating`, `removed_by_enterprise`, `enterprise_enforced` */
    status?: string | undefined;
}
export type GetRepositoriesForEnterpriseConfigurationResponseBodyList = Array<CodeSecurityConfigurationRepositories>;
export type GetRepositoriesForEnterpriseConfigurationResponse = GetRepositoriesForEnterpriseConfigurationResponseBodyList;
export interface GetSingleConfigurationForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
}
/** Specify which types of repository this security configuration should be applied to by default. */
export type SetConfigurationAsDefaultRequestDefaultForNewRepos = "all" | "none" | "private_and_internal" | "public";
export interface SetConfigurationAsDefaultRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
    /** Specify which types of repository this security configuration should be applied to by default. */
    default_for_new_repos?: SetConfigurationAsDefaultRequestDefaultForNewRepos | (string & {}) | undefined;
}
/** Specifies which types of repository this security configuration is applied to by default. */
export type SetConfigurationAsDefaultResponseDefaultForNewRepos = "all" | "none" | "private_and_internal" | "public";
export interface SetConfigurationAsDefaultResponse {
    /** Specifies which types of repository this security configuration is applied to by default. */
    default_for_new_repos?: SetConfigurationAsDefaultResponseDefaultForNewRepos | undefined;
    configuration?: CodeSecurityConfiguration | undefined;
}
/** Specify which types of repository this security configuration should be applied to by default. */
export type SetConfigurationAsDefaultForEnterpriseRequestDefaultForNewRepos = "all" | "none" | "private_and_internal" | "public";
export interface SetConfigurationAsDefaultForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
    /** Specify which types of repository this security configuration should be applied to by default. */
    default_for_new_repos?: SetConfigurationAsDefaultForEnterpriseRequestDefaultForNewRepos | (string & {}) | undefined;
}
/** Specifies which types of repository this security configuration is applied to by default. */
export type SetConfigurationAsDefaultForEnterpriseResponseDefaultForNewRepos = "all" | "none" | "private_and_internal" | "public";
export interface SetConfigurationAsDefaultForEnterpriseResponse {
    /** Specifies which types of repository this security configuration is applied to by default. */
    default_for_new_repos?: SetConfigurationAsDefaultForEnterpriseResponseDefaultForNewRepos | undefined;
    configuration?: CodeSecurityConfiguration | undefined;
}
/** The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. > [!WARNING] > `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. */
export type UpdateConfigurationRequestAdvancedSecurity = "enabled" | "disabled" | "code_security" | "secret_protection";
/** The enablement status of GitHub Code Security features. */
export type UpdateConfigurationRequestCodeSecurity = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependency Graph */
export type UpdateConfigurationRequestDependencyGraph = "enabled" | "disabled" | "not_set";
/** The enablement status of Automatic dependency submission */
export type UpdateConfigurationRequestDependencyGraphAutosubmitAction = "enabled" | "disabled" | "not_set";
/** Feature options for Automatic dependency submission */
export type UpdateConfigurationRequestDependencyGraphAutosubmitActionOptions = CreateConfigurationRequestDependencyGraphAutosubmitActionOptions;
/** The enablement status of Dependabot alerts */
export type UpdateConfigurationRequestDependabotAlerts = "enabled" | "disabled" | "not_set";
/** The enablement status of reachability analysis for Dependabot. Only available for organizations with access to reachability analysis. Requires Dependabot alerts to be enabled when set to `enabled`. Must be `disabled` when Dependabot alerts is `disabled`. `not_set` leaves existing repository settings unchanged. Omit this field to preserve the configuration's current value. */
export type UpdateConfigurationRequestDependabotReachability = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependabot security updates */
export type UpdateConfigurationRequestDependabotSecurityUpdates = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependabot delegated alert dismissal. Requires Dependabot alerts to be enabled. */
export type UpdateConfigurationRequestDependabotDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of code scanning default setup */
export type UpdateConfigurationRequestCodeScanningDefaultSetup = "enabled" | "disabled" | "not_set";
/** The enablement status of code scanning delegated alert dismissal */
export type UpdateConfigurationRequestCodeScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of GitHub Secret Protection features. */
export type UpdateConfigurationRequestSecretProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning */
export type UpdateConfigurationRequestSecretScanning = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning push protection */
export type UpdateConfigurationRequestSecretScanningPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning delegated bypass */
export type UpdateConfigurationRequestSecretScanningDelegatedBypass = "enabled" | "disabled" | "not_set";
/** The type of the bypass reviewer */
export type UpdateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type UpdateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface UpdateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: UpdateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItemReviewerType | (string & {});
    /** The bypass mode for the reviewer */
    mode?: UpdateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItemMode | (string & {}) | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type UpdateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersList = Array<UpdateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersItem>;
/** Feature options for secret scanning delegated bypass */
export interface UpdateConfigurationRequestSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: UpdateConfigurationRequestSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
/** The enablement status of secret scanning validity checks */
export type UpdateConfigurationRequestSecretScanningValidityChecks = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning non-provider patterns */
export type UpdateConfigurationRequestSecretScanningNonProviderPatterns = "enabled" | "disabled" | "not_set";
/** The enablement status of Copilot secret scanning */
export type UpdateConfigurationRequestSecretScanningGenericSecrets = "enabled" | "disabled" | "not_set";
/** The enablement status of generic secrets push protection */
export type UpdateConfigurationRequestSecretScanningGenericSecretsPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning delegated alert dismissal */
export type UpdateConfigurationRequestSecretScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning extended metadata */
export type UpdateConfigurationRequestSecretScanningExtendedMetadata = "enabled" | "disabled" | "not_set";
/** The enablement status of private vulnerability reporting */
export type UpdateConfigurationRequestPrivateVulnerabilityReporting = "enabled" | "disabled" | "not_set";
/** The enforcement status for a security configuration */
export type UpdateConfigurationRequestEnforcement = "enforced" | "unenforced";
export interface UpdateConfigurationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
    /** The name of the code security configuration. Must be unique within the organization. */
    name?: string | undefined;
    /** A description of the code security configuration */
    description?: string | undefined;
    /** The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. > [!WARNING] > `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. */
    advanced_security?: UpdateConfigurationRequestAdvancedSecurity | (string & {}) | undefined;
    /** The enablement status of GitHub Code Security features. */
    code_security?: UpdateConfigurationRequestCodeSecurity | (string & {}) | undefined;
    /** The enablement status of Dependency Graph */
    dependency_graph?: UpdateConfigurationRequestDependencyGraph | (string & {}) | undefined;
    /** The enablement status of Automatic dependency submission */
    dependency_graph_autosubmit_action?: UpdateConfigurationRequestDependencyGraphAutosubmitAction | (string & {}) | undefined;
    /** Feature options for Automatic dependency submission */
    dependency_graph_autosubmit_action_options?: CreateConfigurationRequestDependencyGraphAutosubmitActionOptions | undefined;
    /** The enablement status of Dependabot alerts */
    dependabot_alerts?: UpdateConfigurationRequestDependabotAlerts | (string & {}) | undefined;
    /** The enablement status of reachability analysis for Dependabot. Only available for organizations with access to reachability analysis. Requires Dependabot alerts to be enabled when set to `enabled`. Must be `disabled` when Dependabot alerts is `disabled`. `not_set` leaves existing repository settings unchanged. Omit this field to preserve the configuration's current value. */
    dependabot_reachability?: UpdateConfigurationRequestDependabotReachability | (string & {}) | undefined;
    /** The enablement status of Dependabot security updates */
    dependabot_security_updates?: UpdateConfigurationRequestDependabotSecurityUpdates | (string & {}) | undefined;
    /** The enablement status of Dependabot delegated alert dismissal. Requires Dependabot alerts to be enabled. */
    dependabot_delegated_alert_dismissal?: UpdateConfigurationRequestDependabotDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of code scanning default setup */
    code_scanning_default_setup?: UpdateConfigurationRequestCodeScanningDefaultSetup | (string & {}) | undefined;
    code_scanning_default_setup_options?: CodeScanningDefaultSetupOptions | null | undefined;
    code_scanning_options?: CodeScanningOptions | null | undefined;
    /** The enablement status of code scanning delegated alert dismissal */
    code_scanning_delegated_alert_dismissal?: UpdateConfigurationRequestCodeScanningDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of GitHub Secret Protection features. */
    secret_protection?: UpdateConfigurationRequestSecretProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning */
    secret_scanning?: UpdateConfigurationRequestSecretScanning | (string & {}) | undefined;
    /** The enablement status of secret scanning push protection */
    secret_scanning_push_protection?: UpdateConfigurationRequestSecretScanningPushProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning delegated bypass */
    secret_scanning_delegated_bypass?: UpdateConfigurationRequestSecretScanningDelegatedBypass | (string & {}) | undefined;
    /** Feature options for secret scanning delegated bypass */
    secret_scanning_delegated_bypass_options?: UpdateConfigurationRequestSecretScanningDelegatedBypassOptions | undefined;
    /** The enablement status of secret scanning validity checks */
    secret_scanning_validity_checks?: UpdateConfigurationRequestSecretScanningValidityChecks | (string & {}) | undefined;
    /** The enablement status of secret scanning non-provider patterns */
    secret_scanning_non_provider_patterns?: UpdateConfigurationRequestSecretScanningNonProviderPatterns | (string & {}) | undefined;
    /** The enablement status of Copilot secret scanning */
    secret_scanning_generic_secrets?: UpdateConfigurationRequestSecretScanningGenericSecrets | (string & {}) | undefined;
    /** The enablement status of generic secrets push protection */
    secret_scanning_generic_secrets_push_protection?: UpdateConfigurationRequestSecretScanningGenericSecretsPushProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning delegated alert dismissal */
    secret_scanning_delegated_alert_dismissal?: UpdateConfigurationRequestSecretScanningDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of secret scanning extended metadata */
    secret_scanning_extended_metadata?: UpdateConfigurationRequestSecretScanningExtendedMetadata | (string & {}) | undefined;
    /** The enablement status of private vulnerability reporting */
    private_vulnerability_reporting?: UpdateConfigurationRequestPrivateVulnerabilityReporting | (string & {}) | undefined;
    /** The enforcement status for a security configuration */
    enforcement?: UpdateConfigurationRequestEnforcement | (string & {}) | undefined;
}
/** The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. > [!WARNING] > `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. */
export type UpdateEnterpriseConfigurationRequestAdvancedSecurity = "enabled" | "disabled" | "code_security" | "secret_protection";
/** The enablement status of GitHub Code Security features. */
export type UpdateEnterpriseConfigurationRequestCodeSecurity = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependency Graph */
export type UpdateEnterpriseConfigurationRequestDependencyGraph = "enabled" | "disabled" | "not_set";
/** The enablement status of Automatic dependency submission */
export type UpdateEnterpriseConfigurationRequestDependencyGraphAutosubmitAction = "enabled" | "disabled" | "not_set";
/** Feature options for Automatic dependency submission */
export type UpdateEnterpriseConfigurationRequestDependencyGraphAutosubmitActionOptions = CreateConfigurationRequestDependencyGraphAutosubmitActionOptions;
/** The enablement status of Dependabot alerts */
export type UpdateEnterpriseConfigurationRequestDependabotAlerts = "enabled" | "disabled" | "not_set";
/** The enablement status of reachability analysis for Dependabot. Only available for enterprises with access to reachability analysis. Requires Dependabot alerts to be enabled when set to `enabled`. Must be `disabled` when Dependabot alerts is `disabled`. `not_set` leaves existing repository settings unchanged. Omit this field to preserve the configuration's current value. */
export type UpdateEnterpriseConfigurationRequestDependabotReachability = "enabled" | "disabled" | "not_set";
/** The enablement status of Dependabot security updates */
export type UpdateEnterpriseConfigurationRequestDependabotSecurityUpdates = "enabled" | "disabled" | "not_set";
/** The enablement status of code scanning default setup */
export type UpdateEnterpriseConfigurationRequestCodeScanningDefaultSetup = "enabled" | "disabled" | "not_set";
/** The enablement status of code scanning delegated alert dismissal */
export type UpdateEnterpriseConfigurationRequestCodeScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of GitHub Secret Protection features. */
export type UpdateEnterpriseConfigurationRequestSecretProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning */
export type UpdateEnterpriseConfigurationRequestSecretScanning = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning push protection */
export type UpdateEnterpriseConfigurationRequestSecretScanningPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning validity checks */
export type UpdateEnterpriseConfigurationRequestSecretScanningValidityChecks = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning non-provider patterns */
export type UpdateEnterpriseConfigurationRequestSecretScanningNonProviderPatterns = "enabled" | "disabled" | "not_set";
/** The enablement status of Copilot secret scanning */
export type UpdateEnterpriseConfigurationRequestSecretScanningGenericSecrets = "enabled" | "disabled" | "not_set";
/** The enablement status of generic secrets push protection */
export type UpdateEnterpriseConfigurationRequestSecretScanningGenericSecretsPushProtection = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning delegated alert dismissal */
export type UpdateEnterpriseConfigurationRequestSecretScanningDelegatedAlertDismissal = "enabled" | "disabled" | "not_set";
/** The enablement status of secret scanning extended metadata */
export type UpdateEnterpriseConfigurationRequestSecretScanningExtendedMetadata = "enabled" | "disabled" | "not_set";
/** The enablement status of private vulnerability reporting */
export type UpdateEnterpriseConfigurationRequestPrivateVulnerabilityReporting = "enabled" | "disabled" | "not_set";
/** The enforcement status for a security configuration */
export type UpdateEnterpriseConfigurationRequestEnforcement = "enforced" | "unenforced" | "enterprise_enforced";
export interface UpdateEnterpriseConfigurationRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The unique identifier of the code security configuration. */
    configuration_id: number;
    /** The name of the code security configuration. Must be unique across the enterprise. */
    name?: string | undefined;
    /** A description of the code security configuration */
    description?: string | undefined;
    /** The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features. > [!WARNING] > `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features. */
    advanced_security?: UpdateEnterpriseConfigurationRequestAdvancedSecurity | (string & {}) | undefined;
    /** The enablement status of GitHub Code Security features. */
    code_security?: UpdateEnterpriseConfigurationRequestCodeSecurity | (string & {}) | undefined;
    /** The enablement status of Dependency Graph */
    dependency_graph?: UpdateEnterpriseConfigurationRequestDependencyGraph | (string & {}) | undefined;
    /** The enablement status of Automatic dependency submission */
    dependency_graph_autosubmit_action?: UpdateEnterpriseConfigurationRequestDependencyGraphAutosubmitAction | (string & {}) | undefined;
    /** Feature options for Automatic dependency submission */
    dependency_graph_autosubmit_action_options?: CreateConfigurationRequestDependencyGraphAutosubmitActionOptions | undefined;
    /** The enablement status of Dependabot alerts */
    dependabot_alerts?: UpdateEnterpriseConfigurationRequestDependabotAlerts | (string & {}) | undefined;
    /** The enablement status of reachability analysis for Dependabot. Only available for enterprises with access to reachability analysis. Requires Dependabot alerts to be enabled when set to `enabled`. Must be `disabled` when Dependabot alerts is `disabled`. `not_set` leaves existing repository settings unchanged. Omit this field to preserve the configuration's current value. */
    dependabot_reachability?: UpdateEnterpriseConfigurationRequestDependabotReachability | (string & {}) | undefined;
    /** The enablement status of Dependabot security updates */
    dependabot_security_updates?: UpdateEnterpriseConfigurationRequestDependabotSecurityUpdates | (string & {}) | undefined;
    /** The enablement status of code scanning default setup */
    code_scanning_default_setup?: UpdateEnterpriseConfigurationRequestCodeScanningDefaultSetup | (string & {}) | undefined;
    code_scanning_default_setup_options?: CodeScanningDefaultSetupOptions | null | undefined;
    code_scanning_options?: CodeScanningOptions | null | undefined;
    /** The enablement status of code scanning delegated alert dismissal */
    code_scanning_delegated_alert_dismissal?: UpdateEnterpriseConfigurationRequestCodeScanningDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of GitHub Secret Protection features. */
    secret_protection?: UpdateEnterpriseConfigurationRequestSecretProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning */
    secret_scanning?: UpdateEnterpriseConfigurationRequestSecretScanning | (string & {}) | undefined;
    /** The enablement status of secret scanning push protection */
    secret_scanning_push_protection?: UpdateEnterpriseConfigurationRequestSecretScanningPushProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning validity checks */
    secret_scanning_validity_checks?: UpdateEnterpriseConfigurationRequestSecretScanningValidityChecks | (string & {}) | undefined;
    /** The enablement status of secret scanning non-provider patterns */
    secret_scanning_non_provider_patterns?: UpdateEnterpriseConfigurationRequestSecretScanningNonProviderPatterns | (string & {}) | undefined;
    /** The enablement status of Copilot secret scanning */
    secret_scanning_generic_secrets?: UpdateEnterpriseConfigurationRequestSecretScanningGenericSecrets | (string & {}) | undefined;
    /** The enablement status of generic secrets push protection */
    secret_scanning_generic_secrets_push_protection?: UpdateEnterpriseConfigurationRequestSecretScanningGenericSecretsPushProtection | (string & {}) | undefined;
    /** The enablement status of secret scanning delegated alert dismissal */
    secret_scanning_delegated_alert_dismissal?: UpdateEnterpriseConfigurationRequestSecretScanningDelegatedAlertDismissal | (string & {}) | undefined;
    /** The enablement status of secret scanning extended metadata */
    secret_scanning_extended_metadata?: UpdateEnterpriseConfigurationRequestSecretScanningExtendedMetadata | (string & {}) | undefined;
    /** The enablement status of private vulnerability reporting */
    private_vulnerability_reporting?: UpdateEnterpriseConfigurationRequestPrivateVulnerabilityReporting | (string & {}) | undefined;
    /** The enforcement status for a security configuration */
    enforcement?: UpdateEnterpriseConfigurationRequestEnforcement | (string & {}) | undefined;
}
export type AttachConfigurationError = GithubOpError;
/** Attach a configuration to repositories Attach a code security configuration to a set of repositories. If the repositories specified are already attached to a configuration, they will be re-attached to the provided configuration. If insufficient GHAS licenses are available to attach the configuration to a repository, only free features will be enabled. The authenticated user must be an administrator or security manager for the organization to use this endpoint. Directly applying an enterprise-enforced configuration also requires permission to manage the enterprise's code security settings. Without it, the request returns `403` and no repositories change. When applying a different configuration, repositories with active enterprise-enforced attachments are skipped unless the authenticated user can manage the enterprise's code security settings; the remaining repositories are updated. The request still returns `202` if every repository is skipped. OAuth app tokens and classic PATs require the `write:org` scope. Directly applying an enterprise-enforced configuration also requires `admin:enterprise` and is not supported by fine-grained PATs or GitHub App access tokens. */
export declare const attachConfiguration: API.OperationMethod<AttachConfigurationRequest, AttachConfigurationResponse, AttachConfigurationError, GithubOpContext>;
export type AttachEnterpriseConfigurationError = GithubOpError;
/** Attach an enterprise configuration to repositories Attaches an enterprise code security configuration to repositories. If the repositories specified are already attached to a configuration, they will be re-attached to the provided configuration. If insufficient GHAS licenses are available to attach the configuration to a repository, only free features will be enabled. The authenticated user must be an administrator for the enterprise to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. */
export declare const attachEnterpriseConfiguration: API.OperationMethod<AttachEnterpriseConfigurationRequest, AttachEnterpriseConfigurationResponse, AttachEnterpriseConfigurationError, GithubOpContext>;
export type CreateConfigurationError = GithubOpError;
/** Create a code security configuration Creates a code security configuration in an organization. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest, CodeSecurityConfiguration, CreateConfigurationError, GithubOpContext>;
export type CreateConfigurationForEnterpriseError = GithubOpError;
/** Create a code security configuration for an enterprise Creates a code security configuration in an enterprise. The authenticated user must be an administrator of the enterprise in order to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. */
export declare const createConfigurationForEnterprise: API.OperationMethod<CreateConfigurationForEnterpriseRequest, CodeSecurityConfiguration, CreateConfigurationForEnterpriseError, GithubOpContext>;
export type DeleteConfigurationError = GithubOpError;
/** Delete a code security configuration Deletes the desired code security configuration from an organization. Repositories attached to the configuration will retain their settings but will no longer be associated with the configuration. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest, DeleteConfigurationResponse, DeleteConfigurationError, GithubOpContext>;
export type DeleteConfigurationForEnterpriseError = GithubOpError;
/** Delete a code security configuration for an enterprise Deletes a code security configuration from an enterprise. Repositories attached to the configuration will retain their settings but will no longer be associated with the configuration. The authenticated user must be an administrator for the enterprise to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. */
export declare const deleteConfigurationForEnterprise: API.OperationMethod<DeleteConfigurationForEnterpriseRequest, DeleteConfigurationForEnterpriseResponse, DeleteConfigurationForEnterpriseError, GithubOpContext>;
export type DetachConfigurationError = GithubOpError;
/** Detach configurations from repositories Detach code security configuration(s) from a set of repositories. Repositories will retain their settings but will no longer be associated with the configuration. The authenticated user must be an administrator or security manager for the organization to use this endpoint. Repositories with active enterprise-enforced attachments are skipped unless the authenticated user can manage the enterprise's code security settings; the rest are detached. Inactive enterprise-enforced attachments, such as failed attachments, are detached. The request still returns `204` if every repository is skipped. OAuth app tokens and classic PATs require the `write:org` scope. Managing enterprise-enforced configurations also requires `admin:enterprise` and is not supported by fine-grained PATs or GitHub App access tokens. */
export declare const detachConfiguration: API.OperationMethod<DetachConfigurationRequest, DetachConfigurationResponse, DetachConfigurationError, GithubOpContext>;
export type GetConfigurationError = GithubOpError;
/** Get a code security configuration Gets a code security configuration available in an organization. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest, CodeSecurityConfiguration, GetConfigurationError, GithubOpContext>;
export type GetConfigurationForRepositoryError = GithubOpError;
/** Get the code security configuration associated with a repository Get the code security configuration that manages a repository's code security settings. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getConfigurationForRepository: API.OperationMethod<GetConfigurationForRepositoryRequest, CodeSecurityConfigurationForRepository, GetConfigurationForRepositoryError, GithubOpContext>;
export type GetConfigurationsForEnterpriseError = GithubOpError;
/** Get code security configurations for an enterprise Lists all code security configurations available in an enterprise. The authenticated user must be an administrator of the enterprise in order to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope to use this endpoint. */
export declare const getConfigurationsForEnterprise: API.OperationMethod<GetConfigurationsForEnterpriseRequest, GetConfigurationsForEnterpriseResponse, GetConfigurationsForEnterpriseError, GithubOpContext>;
export type GetConfigurationsForOrgError = GithubOpError;
/** Get code security configurations for an organization Lists all code security configurations available in an organization. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const getConfigurationsForOrg: API.OperationMethod<GetConfigurationsForOrgRequest, GetConfigurationsForOrgResponse, GetConfigurationsForOrgError, GithubOpContext>;
export type GetDefaultConfigurationsError = GithubOpError;
/** Get default code security configurations Lists the default code security configurations for an organization. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const getDefaultConfigurations: API.OperationMethod<GetDefaultConfigurationsRequest, GetDefaultConfigurationsResponse, GetDefaultConfigurationsError, GithubOpContext>;
export type GetDefaultConfigurationsForEnterpriseError = GithubOpError;
/** Get default code security configurations for an enterprise Lists the default code security configurations for an enterprise. The authenticated user must be an administrator of the enterprise in order to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope to use this endpoint. */
export declare const getDefaultConfigurationsForEnterprise: API.OperationMethod<GetDefaultConfigurationsForEnterpriseRequest, GetDefaultConfigurationsForEnterpriseResponse, GetDefaultConfigurationsForEnterpriseError, GithubOpContext>;
export type GetRepositoriesForConfigurationError = GithubOpError;
/** Get repositories associated with a code security configuration Lists the repositories associated with a code security configuration in an organization. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const getRepositoriesForConfiguration: API.OperationMethod<GetRepositoriesForConfigurationRequest, GetRepositoriesForConfigurationResponse, GetRepositoriesForConfigurationError, GithubOpContext>;
export type GetRepositoriesForEnterpriseConfigurationError = GithubOpError;
/** Get repositories associated with an enterprise code security configuration Lists the repositories associated with an enterprise code security configuration in an organization. The authenticated user must be an administrator of the enterprise in order to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope to use this endpoint. */
export declare const getRepositoriesForEnterpriseConfiguration: API.OperationMethod<GetRepositoriesForEnterpriseConfigurationRequest, GetRepositoriesForEnterpriseConfigurationResponse, GetRepositoriesForEnterpriseConfigurationError, GithubOpContext>;
export type GetSingleConfigurationForEnterpriseError = GithubOpError;
/** Retrieve a code security configuration of an enterprise Gets a code security configuration available in an enterprise. The authenticated user must be an administrator of the enterprise in order to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:enterprise` scope to use this endpoint. */
export declare const getSingleConfigurationForEnterprise: API.OperationMethod<GetSingleConfigurationForEnterpriseRequest, CodeSecurityConfiguration, GetSingleConfigurationForEnterpriseError, GithubOpContext>;
export type SetConfigurationAsDefaultError = GithubOpError;
/** Set a code security configuration as a default for an organization Sets a code security configuration as a default to be applied to new repositories in your organization. This configuration will be applied to the matching repository type (all, none, public, private and internal) by default when they are created. The authenticated user must be an administrator or security manager for the organization to use this endpoint. Setting an enterprise-enforced configuration as the default also requires permission to manage the enterprise's code security settings. A default set with this endpoint is an organization default, even if the configuration is owned or enforced by the enterprise. An enterprise-enforced configuration set as an enterprise-level default for the same repository visibility takes precedence. OAuth app tokens and classic PATs require the `write:org` scope; setting an enterprise-enforced configuration as the default also requires `admin:enterprise`. Fine-grained PATs and GitHub App access tokens cannot perform that action. */
export declare const setConfigurationAsDefault: API.OperationMethod<SetConfigurationAsDefaultRequest, SetConfigurationAsDefaultResponse, SetConfigurationAsDefaultError, GithubOpContext>;
export type SetConfigurationAsDefaultForEnterpriseError = GithubOpError;
/** Set a code security configuration as a default for an enterprise Sets a code security configuration as a default to be applied to new repositories in your enterprise. This configuration will be applied by default to the matching repository type when created, but only for organizations within the enterprise that do not already have a default code security configuration set. The authenticated user must be an administrator for the enterprise to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. */
export declare const setConfigurationAsDefaultForEnterprise: API.OperationMethod<SetConfigurationAsDefaultForEnterpriseRequest, SetConfigurationAsDefaultForEnterpriseResponse, SetConfigurationAsDefaultForEnterpriseError, GithubOpContext>;
export type UpdateConfigurationError = GithubOpError;
/** Update a code security configuration Updates a code security configuration in an organization. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const updateConfiguration: API.OperationMethod<UpdateConfigurationRequest, CodeSecurityConfiguration, UpdateConfigurationError, GithubOpContext>;
export type UpdateEnterpriseConfigurationError = GithubOpError;
/** Update a custom code security configuration for an enterprise Updates a code security configuration in an enterprise. The authenticated user must be an administrator of the enterprise in order to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. */
export declare const updateEnterpriseConfiguration: API.OperationMethod<UpdateEnterpriseConfigurationRequest, CodeSecurityConfiguration, UpdateEnterpriseConfigurationError, GithubOpContext>;
//# sourceMappingURL=code_security.d.ts.map