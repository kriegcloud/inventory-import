# @distilled.cloud/aws

Effect-native AWS SDK generated from [Smithy](https://smithy.io) models with full protocol support. Covers S3, Lambda, DynamoDB, SQS, IAM, EC2, and 200+ services with exhaustive error typing.

## Installation

```bash
npm install @distilled.cloud/aws effect
```

Only need S3, or an S3-compatible store such as Cloudflare R2? Install
[`@distilled.cloud/s3`](../s3) instead: the S3 client and the runtime it
needs, without the other services or the credential providers. This package
builds on it, and `@distilled.cloud/aws/s3` re-exports it.

## Quick Start

```typescript
import { Effect, Layer } from "effect";
import * as Stream from "effect/Stream";
import * as FetchHttpClient from "effect/http/FetchHttpClient";
import * as Lambda from "@distilled.cloud/aws/lambda";
import * as S3 from "@distilled.cloud/aws/s3";
import { Credentials, Region } from "@distilled.cloud/aws";

const program = Effect.gen(function* () {
  yield* S3.putObject({
    Bucket: "my-bucket",
    Key: "hello.txt",
    Body: "Hello, World!",
  });

  const result = yield* S3.getObject({
    Bucket: "my-bucket",
    Key: "hello.txt",
  });

  const functions = yield* Lambda.listFunctions
    .items({})
    .pipe(Stream.take(10), Stream.runCollect);

  return result.ContentType;
});

const AwsLive = Layer.mergeAll(
  FetchHttpClient.layer,
  Region.fromEnv(),
  Credentials.fromChain(),
);

program.pipe(Effect.provide(AwsLive), Effect.runPromise);
```

## Configuration

### Region

`Region.fromEnv()` reads from the `AWS_REGION` environment variable (falls back to `AWS_DEFAULT_REGION`):

```bash
AWS_REGION=us-east-1
```

`Region.of("eu-west-1")` sets the region for every call in a scope. One call can set its own with `region`, which wins over the layer:

```typescript
S3.getObject({ Bucket: "my-bucket", Key: "a.txt", region: "eu-west-1" });
```

### Credentials

`Credentials.fromChain()` uses the standard AWS credential provider chain, which tries each source in order until one succeeds:

1. **Environment variables** — `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, and optionally `AWS_SESSION_TOKEN`
2. **Shared credentials file** — `~/.aws/credentials` (supports multiple profiles via `AWS_PROFILE`)
3. **SSO** — `aws sso login --profile your-profile` (reads cached SSO tokens)
4. **Container metadata** — ECS task role credentials
5. **EC2 instance metadata** — IMDS instance profile credentials
6. **Token file** — `AWS_WEB_IDENTITY_TOKEN_FILE` for OIDC federation (EKS)

You can also use a specific provider directly:

```typescript
// Environment variables only
Credentials.fromEnv()

// SSO profile (run `aws sso login` first)
Credentials.fromSSO("my-profile")

// Shared credentials file (~/.aws/credentials)
Credentials.fromIni()

// Static credentials (each value a Redacted string)
Credentials.fromCredentials({
  accessKeyId: Redacted.make("AKIA..."),
  secretAccessKey: Redacted.make("..."),
})

// A role assumed with an OIDC token; pass an Effect for a token that refreshes
Credentials.fromWebToken({
  roleArn: "arn:aws:iam::123456789012:role/Web",
  webIdentityToken: Redacted.make(oidcToken),
})
```

Credentials are cached and automatically refreshed 5 minutes before expiration.

## Error Handling

All operations return typed errors for pattern matching:

```typescript
S3.getObject({ Bucket: "my-bucket", Key: "missing.txt" }).pipe(
  Effect.catchTags({
    NoSuchKey: () => Effect.succeed(null),
    AccessDenied: (e) => Effect.fail(new Error(`Access denied: ${e.message}`)),
  }),
);
```

## Service events

`@distilled.cloud/aws/ses-events` types the events SES sends: bounces,
complaints, deliveries, opens, clicks and the rest. It comes from the
EventBridge `aws.events` schema registry. The module is types only. `Event` is
the union of every event an EventBridge rule can deliver, narrowed by
`detail-type`. An event's `detail` (`EmailBounced`, `EmailComplaintReceived`, …)
is also the record SES publishes to SNS and Firehose.

```typescript
import type * as SesEvents from "@distilled.cloud/aws/ses-events";

const onEvent = (event: SesEvents.Event) => {
  switch (event["detail-type"]) {
    case "Email Bounced":
      return event.detail.bounce.bounceType === "Permanent"
        ? event.detail.bounce.bouncedRecipients.map((r) => r.emailAddress)
        : [];
    case "Email Complaint Received":
      return event.detail.complaint.complainedRecipients.map((r) => r.emailAddress);
    default:
      return [];
  }
};
```

## Protocols

Supports all AWS protocols: REST-XML (S3), REST-JSON (Lambda), AWS JSON 1.0/1.1 (DynamoDB, KMS), AWS Query (IAM, STS), and EC2 Query.

## License

MIT
