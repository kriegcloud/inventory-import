/**
 * `@distilled.cloud/aws/Credentials` for the browser: the `Credentials`
 * service and the providers that need neither a file system nor a child
 * process. Each layer is defined in its provider's own file.
 */
export * from "./credentials-service.ts";
export type { Secret } from "./credential-providers/credential-source.ts";
export { createCredentialChain, propertyProviderChain, } from "./credential-providers/create-credential-chain.ts";
export { fromCredentials, type StaticCredentials, } from "./credential-providers/from-credentials.ts";
export { fromEnv } from "./credential-providers/from-env.ts";
import { type SdkError } from "@distilled.cloud/core/sdk-error";
import * as Layer from "effect/Layer";
import type * as __from_cognito_identity_pool from "./credential-providers/from-cognito-identity-pool.ts";
import type * as __from_cognito_identity from "./credential-providers/from-cognito-identity.ts";
import type * as __from_container_metadata from "./credential-providers/from-container-metadata.ts";
import type * as __from_http from "./credential-providers/from-http.ts";
import type * as __from_instance_metadata from "./credential-providers/from-instance-metadata.ts";
import type * as __from_temporary_credentials from "./credential-providers/from-temporary-credentials.ts";
import type * as __from_web_token from "./credential-providers/from-web-token.ts";
/** A provider loaded on first use: building its layer also fails if its module can't load. */
type WithLoadError<F> = F extends (...args: infer A) => Layer.Layer<infer S, infer E, infer R> ? (...args: A) => Layer.Layer<S, E | SdkError, R> : never;
export declare const fromCognitoIdentityPool: WithLoadError<typeof __from_cognito_identity_pool.fromCognitoIdentityPool>;
export declare const fromCognitoIdentity: WithLoadError<typeof __from_cognito_identity.fromCognitoIdentity>;
export declare const fromContainerMetadata: WithLoadError<typeof __from_container_metadata.fromContainerMetadata>;
export declare const fromHttp: WithLoadError<typeof __from_http.fromHttp>;
export declare const fromInstanceMetadata: WithLoadError<typeof __from_instance_metadata.fromInstanceMetadata>;
export declare const fromTemporaryCredentials: WithLoadError<typeof __from_temporary_credentials.fromTemporaryCredentials>;
export declare const fromWebToken: WithLoadError<typeof __from_web_token.fromWebToken>;
//# sourceMappingURL=credentials.browser.d.ts.map