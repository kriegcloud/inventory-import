import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as AST from "effect/SchemaAST";
import type * as Stream from "effect/Stream";
import { rawResponseRootSymbol } from "./annotations.ts";
import * as API from "./api.ts";
import { unwrapRedactedDeep } from "./plain-values.ts";
import { sensitiveValueSymbol, wrapSensitive } from "./sensitive.ts";
import type { UnknownErrorProps } from "./unknown-error.ts";
export { sensitiveValueSymbol };
/**
 * Marks a string member, map value or list element as sensitive (mirrors
 * `smithy.api#sensitive`). The REST protocol wraps decoded values in
 * `Redacted` on the way out (an untyped `S.Unknown` value whole) and
 * accepts `string | Redacted<string>` on the way in (unwrapped before
 * serialization). Takes an ignored argument so generators can inline the
 * smithy trait value (`T.SensitiveValue({})`).
 */
export declare const SensitiveValue: (_value?: unknown) => import("./trait.ts").Annotation;
export declare const rawResponseSymbol: unique symbol;
/**
 * Marks the sole output member that carries a bare (array/scalar) response
 * body (mirrors `com.distilled.openapi#rawResponse`).
 */
export declare const RawResponse: (_value?: unknown) => import("./trait.ts").Annotation;
/**
 * Marks a response schema whose ENTIRE value is the response body (the
 * generator's `rootPipe` for synthesized bare-payload wrappers): the emitted
 * response type IS the payload type and the protocol returns the mapped body
 * directly.
 */
export { rawResponseRootSymbol };
export declare const RawResponseRoot: () => import("./trait.ts").Annotation;
export declare const binaryResponseSymbol: unique symbol;
/** Decode a successful raw binary response as bytes, without text conversion. */
export declare const BinaryResponse: () => import("./trait.ts").Annotation;
export { unwrapRedactedDeep };
export { wrapSensitive };
/**
 * Whether any member, map value or list element reachable from `ast` is
 * marked {@link SensitiveValue}. Such an output is decoded through
 * {@link wrapSensitive}, and its parse errors withhold the response body (see
 * {@link checkSuccess}, which every REST-style protocol's success path uses).
 */
export declare const hasSensitiveMember: (ast: AST.AST) => boolean;
/** What the wire said about a failure, for the `unknownError` fallback. */
export interface RestErrorInfo {
    readonly status: number;
    /** Error code from the envelope (services vary between string and number). */
    readonly code?: string | number;
    readonly message: string;
    /** Parsed JSON body, or the raw text when the body wasn't JSON. */
    readonly body: unknown;
    readonly headers: Record<string, string | undefined>;
}
/**
 * The core {@link UnknownErrorProps} of a failure, for an SDK's
 * `unknownError`: `new UnknownNeonError(unknownErrorProps(info))`. A number
 * code becomes its string.
 */
export declare const unknownErrorProps: (info: RestErrorInfo) => UnknownErrorProps;
/**
 * A 2xx body that failed strict validation, or a non-JSON 2xx body for an
 * output with sensitive members, for the `parseError` option.
 */
export interface RestParseErrorInfo {
    /** `"[REDACTED]"` when the output has sensitive members. */
    readonly body: unknown;
    readonly cause: unknown;
}
export interface RestErrorEnvelope {
    readonly code?: string | number;
    readonly message?: string;
}
export interface RestProtocolOptions<C> {
    /**
     * Resolve credentials ON THE CALLING FIBER -- evaluated per request, never
     * at layer build time, so context-provided credentials and token refreshes
     * are picked up. Either an effect, or -- for the distilled
     * credentials-service convention -- the `Credentials` service key whose
     * value is that effect (read from the calling fiber's context; an
     * already-resolved `Effect.succeed` value costs no extra fiber step). Its
     * error/requirement channels are
     * erased at the protocol boundary (Protocol effects carry none) and
     * reintroduced for callers by the generated `<Sdk>OpError` /
     * `<Sdk>OpContext` annotations.
     */
    readonly credentials: Effect.Effect<C, any, any> | Context.Key<any, Effect.Effect<C, any, any>>;
    /**
     * API base URL from the resolved credentials. Receives the operation's
     * route so APIs with more than one endpoint (e.g. S2's account vs
     * per-basin hosts, chosen by path) can route per request; single-endpoint
     * providers ignore the argument. `server` is the operation's host name
     * (`T.Http({ server })`) for APIs that serve some operations from another
     * host; map it to a base URL from the credentials. A THROWN error (e.g. a
     * required scope missing from the credentials) is caught and surfaced on
     * the calling effect's error channel rather than dying as a defect.
     */
    readonly baseUrl: (credentials: C, target: {
        readonly uri: string;
        readonly method: string;
        readonly server?: string | undefined;
    }) => string;
    /** Auth (and any fixed) headers from the resolved credentials. */
    readonly headers: (credentials: C) => Record<string, string>;
    /**
     * Extract `{ code?, message? }` from a parsed non-2xx JSON body. Default:
     * lenient `{ code?, message? | error? }` (covers the common REST error
     * envelopes).
     */
    readonly errorEnvelope?: (body: unknown) => RestErrorEnvelope | undefined;
    /**
     * JSON pointer to the object that holds a failure's fields when the
     * provider nests them, e.g. `"/error"` for `{ error: { status, details } }`.
     * A typed error's declared fields are read there first, then at the top
     * level of the body.
     */
    readonly errorFieldsAt?: string;
    /**
     * HTTP status -> error class constructed as `new Cls({ message, retryAfter
     * })`. Default: core `HTTP_STATUS_MAP`. Consulted after per-op typed error
     * matching; unmapped 5xx fall back to `InternalServerError`, everything
     * else to {@link unknownError}.
     */
    readonly statusMap?: Readonly<Record<number, new (args: any) => any>>;
    /**
     * The provider's own reading of a failure, consulted before per-op typed
     * matching and the status map: return the error to fail with, or
     * `undefined` to decode the failure as usual. For rules a status alone
     * can't express, e.g. a 403 that is a rate limit because of its headers.
     */
    readonly classifyError?: (info: RestErrorInfo) => unknown;
    /**
     * Fallback error for failures nothing else matched: the SDK's
     * `Unknown<Sdk>Error`, built from {@link unknownErrorProps}. Only non-5xx
     * statuses reach it (unmapped 5xx are `InternalServerError`), so the class
     * carries no retryable category.
     */
    readonly unknownError: (info: RestErrorInfo) => unknown;
    /**
     * The SDK's `<Sdk>ParseError`, raised when a 2xx body does not match the
     * operation's output schema in strict mode (see
     * `core/response-validation`), and in every mode when a 2xx body for an
     * output with sensitive members is not JSON. `body` is the parsed JSON, or
     * the raw text when the body wasn't JSON, and `"[REDACTED]"` for an output
     * with sensitive members; `cause` is the schema error, or `"Invalid JSON
     * response"`.
     */
    readonly parseError: (info: RestParseErrorInfo) => unknown;
    /** Transform the parsed 2xx JSON before decoding (e.g. stripNulls). */
    readonly transformResponse?: (body: unknown) => unknown;
    /** Passed through to `buildRequest` (member-header transforms). */
    readonly mapMemberHeader?: (name: string, value: string) => string;
    /** Passed through to `buildRequest` (wire names for unmodeled input keys). */
    readonly unknownKeyToWire?: (key: string) => string;
    /** Passed through to `buildRequest`: send `{}` when a bodied call has no body members. */
    readonly emptyJsonBody?: boolean;
}
/** The body of a streamed 2xx response, for {@link StreamFraming.stream}. */
export interface FramedBody {
    readonly body: Stream.Stream<Uint8Array, unknown>;
    /**
     * Decode one parsed frame as one element of the output's `items`, as a
     * 2xx body decodes (key mapping, strict validation, `Redacted`).
     */
    readonly item: (json: unknown, text: string) => Effect.Effect<unknown, unknown>;
    /** The SDK's parse error for a frame that is not JSON. */
    readonly invalid: (text: string) => unknown;
}
/** A plain call's framed body, read whole: the output JSON, or not JSON. */
export interface CollectedBody {
    readonly json: unknown;
    readonly nonJson: boolean;
}
/**
 * How a server-streaming operation's body is framed (`API.makeStreaming`,
 * output `{ items }`): its `framing` config, e.g. `ndjson` from
 * core/ndjson. An operation without one can't stream (`.stream()` fails
 * with `SdkError`, see `API.cannotStream`).
 */
export interface StreamFraming {
    /**
     * A plain call's whole body as `{ items }`, or `undefined` when the
     * response's `Content-Type` is not this framing (decoded as usual).
     */
    readonly collect: (text: string, contentType: string | undefined) => CollectedBody | undefined;
    /**
     * Each frame as it arrives, through `item`. `open` sends the request and
     * fails with the operation's typed error on a failed status.
     */
    readonly stream: (open: Effect.Effect<FramedBody, unknown>) => Stream.Stream<unknown, unknown>;
}
/** A 2xx body a protocol read, for {@link checkSuccess}. */
export interface SuccessBody {
    /** The value to check and return: the body mapped onto the output's TS names. */
    readonly value: unknown;
    /** What a parse error reports as `body` for an output without sensitive members. */
    readonly body: unknown;
    /** Whether the body was not JSON. */
    readonly nonJson: boolean;
}
/** The outcome of {@link checkSuccess}: the value, or the parse error's fields. */
export type SuccessCheck = {
    readonly ok: true;
    readonly value: unknown;
} | {
    readonly ok: false;
    readonly error: RestParseErrorInfo;
};
/**
 * Check a 2xx body against the operation's output schema and deliver its
 * sensitive values as `Redacted`. Every REST-style protocol ends its success
 * path here, so all of them treat a body that can hold a secret alike:
 *
 * - The checked value comes back through {@link wrapSensitive}.
 * - A mismatch (validating modes, see `core/response-validation`) reports
 *   `read.body` and the schema error.
 * - For an output with sensitive members ({@link hasSensitiveMember}), a
 *   non-JSON body fails in every mode with `"Invalid JSON response"`, and a
 *   mismatch reports `body: "[REDACTED]"` and the schema error without the
 *   value it found (`withholdActual`).
 *
 * Synchronous, for protocols that already hold the calling fiber's context;
 * {@link validateSuccess} is the `Effect` form.
 */
export declare const checkSuccess: (context: Context.Context<any>, outputAst: AST.AST, read: SuccessBody) => SuccessCheck;
/**
 * {@link checkSuccess} on the calling fiber, failing with `parseError` (the
 * SDK's `<Sdk>ParseError`) built from the withheld-or-not fields.
 */
export declare const validateSuccess: <E>(outputAst: AST.AST, read: SuccessBody, parseError: (info: RestParseErrorInfo) => E) => Effect.Effect<unknown, E>;
/**
 * Build a `Layer<Protocol>` for a simple REST JSON API. Assign the result to
 * a module-level const in the provider's `protocol.ts` -- `API.make` memoizes
 * protocol layers by value identity.
 */
export declare const makeRestProtocol: <C>(options: RestProtocolOptions<C>) => Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol-rest.d.ts.map