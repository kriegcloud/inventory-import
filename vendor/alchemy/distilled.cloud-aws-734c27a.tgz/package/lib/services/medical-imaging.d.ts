import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const NotAcceptableException_base: S.TaggedErrorClass<"NotAcceptableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotAcceptableException extends /*@__PURE__*/ NotAcceptableException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DatastoreId = string;
export type ImageSetId = string;
export type ImageSetExternalVersionId = string;
export type CopiableAttributes = string | redacted.Redacted<string>;
export interface MetadataCopies {
    copiableAttributes: string | redacted.Redacted<string>;
}
export interface CopySourceImageSetInformation {
    latestVersionId: string;
    DICOMCopies?: MetadataCopies | undefined;
}
export interface CopyDestinationImageSet {
    imageSetId: string;
    latestVersionId: string;
}
export interface CopyImageSetInformation {
    sourceImageSet: CopySourceImageSetInformation;
    destinationImageSet?: CopyDestinationImageSet | undefined;
}
export interface CopyImageSetRequest {
    datastoreId: string;
    sourceImageSetId: string;
    copyImageSetInformation: CopyImageSetInformation;
    force?: boolean | undefined;
    promoteToPrimary?: boolean | undefined;
}
export type ImageSetState = "ACTIVE" | "LOCKED" | "DELETED" | (string & {});
export type ImageSetWorkflowStatus = "CREATED" | "COPIED" | "COPYING" | "COPYING_WITH_READ_ONLY_ACCESS" | "COPY_FAILED" | "UPDATING" | "UPDATING_FOR_STUDY_CONSISTENCY" | "UPDATED" | "UPDATE_FAILED" | "DELETING" | "DELETED" | "IMPORTING" | "IMPORTED" | "IMPORT_FAILED" | (string & {});
export type Arn = string;
export interface CopySourceImageSetProperties {
    imageSetId: string;
    latestVersionId: string;
    imageSetState?: ImageSetState | undefined;
    imageSetWorkflowStatus?: ImageSetWorkflowStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    imageSetArn?: string | undefined;
}
export interface CopyDestinationImageSetProperties {
    imageSetId: string;
    latestVersionId: string;
    imageSetState?: ImageSetState | undefined;
    imageSetWorkflowStatus?: ImageSetWorkflowStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    imageSetArn?: string | undefined;
}
export interface CopyImageSetResponse {
    datastoreId: string;
    sourceImageSetProperties: CopySourceImageSetProperties;
    destinationImageSetProperties: CopyDestinationImageSetProperties;
}
export type DatastoreName = string;
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type KmsKeyArn = string;
export type LambdaArn = string;
export type LosslessStorageFormat = "HTJ2K" | "JPEG_2000_LOSSLESS" | (string & {});
export interface CreateDatastoreRequest {
    datastoreName?: string | undefined;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
    lambdaAuthorizerArn?: string | undefined;
    losslessStorageFormat?: LosslessStorageFormat | undefined;
}
export type DatastoreStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "DELETED" | (string & {});
export interface CreateDatastoreResponse {
    datastoreId: string;
    datastoreStatus: DatastoreStatus;
}
export interface DeleteDatastoreRequest {
    datastoreId: string;
}
export interface DeleteDatastoreResponse {
    datastoreId: string;
    datastoreStatus: DatastoreStatus;
}
export interface DeleteImageSetRequest {
    datastoreId: string;
    imageSetId: string;
}
export interface DeleteImageSetResponse {
    datastoreId: string;
    imageSetId: string;
    imageSetState: ImageSetState;
    imageSetWorkflowStatus: ImageSetWorkflowStatus;
}
export interface GetDatastoreRequest {
    datastoreId: string;
}
export interface DatastoreProperties {
    datastoreId: string;
    datastoreName: string;
    datastoreStatus: DatastoreStatus;
    kmsKeyArn?: string | undefined;
    lambdaAuthorizerArn?: string | undefined;
    losslessStorageFormat?: LosslessStorageFormat | undefined;
    datastoreArn?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetDatastoreResponse {
    datastoreProperties: DatastoreProperties;
}
export type JobId = string;
export interface GetDICOMImportJobRequest {
    datastoreId: string;
    jobId: string;
}
export type JobName = string;
export type JobStatus = "SUBMITTED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type RoleArn = string;
export type S3Uri = string;
export type Message = string;
export type DICOMStudyInstanceUID = string | redacted.Redacted<string>;
export type DICOMSeriesInstanceUID = string | redacted.Redacted<string>;
export type MetadataFilePath = string;
export interface DicomMetadataMapping {
    studyInstanceUID: string | redacted.Redacted<string>;
    seriesInstanceUID?: string | redacted.Redacted<string> | undefined;
    metadataFilePath: string;
}
export type DicomMetadataMappings = DicomMetadataMapping[];
export interface DicomJsonMetadataImportConfiguration {
    dicomMetadataMappings: DicomMetadataMapping[];
}
export type ImportConfiguration = {
    dicomJsonMetadataImportConfiguration: DicomJsonMetadataImportConfiguration;
};
export interface DICOMImportJobProperties {
    jobId: string;
    jobName: string;
    jobStatus: JobStatus;
    datastoreId: string;
    dataAccessRoleArn: string;
    endedAt?: Date | undefined;
    submittedAt?: Date | undefined;
    inputS3Uri: string;
    outputS3Uri: string;
    message?: string | undefined;
    importConfiguration?: ImportConfiguration | undefined;
}
export interface GetDICOMImportJobResponse {
    jobProperties: DICOMImportJobProperties;
}
export type ImageFrameId = string;
export interface ImageFrameInformation {
    imageFrameId: string;
}
export interface GetImageFrameRequest {
    datastoreId: string;
    imageSetId: string;
    imageFrameInformation: ImageFrameInformation;
}
export interface GetImageFrameResponse {
    imageFrameBlob: T.StreamingOutputBody;
    contentType?: string | undefined;
}
export interface GetImageSetRequest {
    datastoreId: string;
    imageSetId: string;
    versionId?: string | undefined;
}
export interface Overrides {
    forced?: boolean | undefined;
}
export type StorageTier = "FREQUENT_ACCESS" | "ARCHIVE_INSTANT_ACCESS" | (string & {});
export interface GetImageSetResponse {
    datastoreId: string;
    imageSetId: string;
    versionId: string;
    imageSetState: ImageSetState;
    imageSetWorkflowStatus?: ImageSetWorkflowStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    deletedAt?: Date | undefined;
    message?: string | undefined;
    imageSetArn?: string | undefined;
    overrides?: Overrides | undefined;
    isPrimary?: boolean | undefined;
    lastAccessedAt?: Date | undefined;
    storageTier?: StorageTier | undefined;
}
export interface GetImageSetMetadataRequest {
    datastoreId: string;
    imageSetId: string;
    versionId?: string | undefined;
}
export interface GetImageSetMetadataResponse {
    imageSetMetadataBlob: T.StreamingOutputBody;
    contentType?: string | undefined;
    contentEncoding?: string | undefined;
}
export type NextToken = string;
export interface ListDatastoresRequest {
    datastoreStatus?: DatastoreStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DatastoreSummary {
    datastoreId: string;
    datastoreName: string;
    datastoreStatus: DatastoreStatus;
    datastoreArn?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type DatastoreSummaries = DatastoreSummary[];
export interface ListDatastoresResponse {
    datastoreSummaries?: DatastoreSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDICOMImportJobsRequest {
    datastoreId: string;
    jobStatus?: JobStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DICOMImportJobSummary {
    jobId: string;
    jobName: string;
    jobStatus: JobStatus;
    datastoreId: string;
    dataAccessRoleArn?: string | undefined;
    endedAt?: Date | undefined;
    submittedAt?: Date | undefined;
    message?: string | undefined;
}
export type DICOMImportJobSummaries = DICOMImportJobSummary[];
export interface ListDICOMImportJobsResponse {
    jobSummaries: DICOMImportJobSummary[];
    nextToken?: string | undefined;
}
export interface ListImageSetVersionsRequest {
    datastoreId: string;
    imageSetId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ImageSetProperties {
    imageSetId: string;
    versionId: string;
    imageSetState: ImageSetState;
    ImageSetWorkflowStatus?: ImageSetWorkflowStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    deletedAt?: Date | undefined;
    message?: string | undefined;
    overrides?: Overrides | undefined;
    isPrimary?: boolean | undefined;
}
export type ImageSetPropertiesList = ImageSetProperties[];
export interface ListImageSetVersionsResponse {
    imageSetPropertiesList: ImageSetProperties[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export type DICOMPatientId = string | redacted.Redacted<string>;
export type DICOMAccessionNumber = string | redacted.Redacted<string>;
export type DICOMStudyId = string | redacted.Redacted<string>;
export type DICOMStudyDate = string | redacted.Redacted<string>;
export type DICOMStudyTime = string | redacted.Redacted<string>;
export interface DICOMStudyDateAndTime {
    DICOMStudyDate: string | redacted.Redacted<string>;
    DICOMStudyTime?: string | redacted.Redacted<string> | undefined;
}
export type SearchByAttributeValue = {
    DICOMPatientId: string | redacted.Redacted<string>;
    DICOMAccessionNumber?: undefined;
    DICOMStudyId?: undefined;
    DICOMStudyInstanceUID?: undefined;
    DICOMSeriesInstanceUID?: undefined;
    createdAt?: undefined;
    updatedAt?: undefined;
    DICOMStudyDateAndTime?: undefined;
    isPrimary?: undefined;
} | {
    DICOMPatientId?: undefined;
    DICOMAccessionNumber: string | redacted.Redacted<string>;
    DICOMStudyId?: undefined;
    DICOMStudyInstanceUID?: undefined;
    DICOMSeriesInstanceUID?: undefined;
    createdAt?: undefined;
    updatedAt?: undefined;
    DICOMStudyDateAndTime?: undefined;
    isPrimary?: undefined;
} | {
    DICOMPatientId?: undefined;
    DICOMAccessionNumber?: undefined;
    DICOMStudyId: string | redacted.Redacted<string>;
    DICOMStudyInstanceUID?: undefined;
    DICOMSeriesInstanceUID?: undefined;
    createdAt?: undefined;
    updatedAt?: undefined;
    DICOMStudyDateAndTime?: undefined;
    isPrimary?: undefined;
} | {
    DICOMPatientId?: undefined;
    DICOMAccessionNumber?: undefined;
    DICOMStudyId?: undefined;
    DICOMStudyInstanceUID: string | redacted.Redacted<string>;
    DICOMSeriesInstanceUID?: undefined;
    createdAt?: undefined;
    updatedAt?: undefined;
    DICOMStudyDateAndTime?: undefined;
    isPrimary?: undefined;
} | {
    DICOMPatientId?: undefined;
    DICOMAccessionNumber?: undefined;
    DICOMStudyId?: undefined;
    DICOMStudyInstanceUID?: undefined;
    DICOMSeriesInstanceUID: string | redacted.Redacted<string>;
    createdAt?: undefined;
    updatedAt?: undefined;
    DICOMStudyDateAndTime?: undefined;
    isPrimary?: undefined;
} | {
    DICOMPatientId?: undefined;
    DICOMAccessionNumber?: undefined;
    DICOMStudyId?: undefined;
    DICOMStudyInstanceUID?: undefined;
    DICOMSeriesInstanceUID?: undefined;
    createdAt: Date;
    updatedAt?: undefined;
    DICOMStudyDateAndTime?: undefined;
    isPrimary?: undefined;
} | {
    DICOMPatientId?: undefined;
    DICOMAccessionNumber?: undefined;
    DICOMStudyId?: undefined;
    DICOMStudyInstanceUID?: undefined;
    DICOMSeriesInstanceUID?: undefined;
    createdAt?: undefined;
    updatedAt: Date;
    DICOMStudyDateAndTime?: undefined;
    isPrimary?: undefined;
} | {
    DICOMPatientId?: undefined;
    DICOMAccessionNumber?: undefined;
    DICOMStudyId?: undefined;
    DICOMStudyInstanceUID?: undefined;
    DICOMSeriesInstanceUID?: undefined;
    createdAt?: undefined;
    updatedAt?: undefined;
    DICOMStudyDateAndTime: DICOMStudyDateAndTime;
    isPrimary?: undefined;
} | {
    DICOMPatientId?: undefined;
    DICOMAccessionNumber?: undefined;
    DICOMStudyId?: undefined;
    DICOMStudyInstanceUID?: undefined;
    DICOMSeriesInstanceUID?: undefined;
    createdAt?: undefined;
    updatedAt?: undefined;
    DICOMStudyDateAndTime?: undefined;
    isPrimary: boolean;
};
export type SearchByAttributeValues = SearchByAttributeValue[];
export type Operator = "EQUAL" | "BETWEEN" | (string & {});
export interface SearchFilter {
    values: SearchByAttributeValue[];
    operator: Operator;
}
export type SearchFilters = SearchFilter[];
export type SortOrder = "ASC" | "DESC" | (string & {});
export type SortField = "updatedAt" | "createdAt" | "DICOMStudyDateAndTime" | (string & {});
export interface Sort {
    sortOrder: SortOrder;
    sortField: SortField;
}
export interface SearchCriteria {
    filters?: SearchFilter[] | undefined;
    sort?: Sort | undefined;
}
export interface SearchImageSetsRequest {
    datastoreId: string;
    searchCriteria?: SearchCriteria | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type DICOMPatientName = string | redacted.Redacted<string>;
export type DICOMPatientBirthDate = string | redacted.Redacted<string>;
export type DICOMPatientSex = string | redacted.Redacted<string>;
export type DICOMStudyDescription = string | redacted.Redacted<string>;
export type DICOMNumberOfStudyRelatedSeries = number;
export type DICOMNumberOfStudyRelatedInstances = number;
export type DICOMSeriesModality = string | redacted.Redacted<string>;
export type DICOMSeriesBodyPart = string | redacted.Redacted<string>;
export type DICOMSeriesNumber = number;
export interface DICOMTags {
    DICOMPatientId?: string | redacted.Redacted<string> | undefined;
    DICOMPatientName?: string | redacted.Redacted<string> | undefined;
    DICOMPatientBirthDate?: string | redacted.Redacted<string> | undefined;
    DICOMPatientSex?: string | redacted.Redacted<string> | undefined;
    DICOMStudyInstanceUID?: string | redacted.Redacted<string> | undefined;
    DICOMStudyId?: string | redacted.Redacted<string> | undefined;
    DICOMStudyDescription?: string | redacted.Redacted<string> | undefined;
    DICOMNumberOfStudyRelatedSeries?: number | undefined;
    DICOMNumberOfStudyRelatedInstances?: number | undefined;
    DICOMAccessionNumber?: string | redacted.Redacted<string> | undefined;
    DICOMSeriesInstanceUID?: string | redacted.Redacted<string> | undefined;
    DICOMSeriesModality?: string | redacted.Redacted<string> | undefined;
    DICOMSeriesBodyPart?: string | redacted.Redacted<string> | undefined;
    DICOMSeriesNumber?: number | undefined;
    DICOMStudyDate?: string | redacted.Redacted<string> | undefined;
    DICOMStudyTime?: string | redacted.Redacted<string> | undefined;
}
export interface ImageSetsMetadataSummary {
    imageSetId: string;
    version?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    lastAccessedAt?: Date | undefined;
    storageTier?: StorageTier | undefined;
    DICOMTags?: DICOMTags | undefined;
    isPrimary?: boolean | undefined;
}
export type ImageSetsMetadataSummaries = ImageSetsMetadataSummary[];
export interface SearchImageSetsResponse {
    imageSetsMetadataSummaries: ImageSetsMetadataSummary[];
    sort?: Sort | undefined;
    nextToken?: string | undefined;
}
export type AwsAccountId = string;
export interface StartDICOMImportJobRequest {
    jobName?: string | undefined;
    dataAccessRoleArn: string;
    clientToken: string;
    datastoreId: string;
    inputS3Uri: string;
    outputS3Uri: string;
    inputOwnerAccountId?: string | undefined;
    importConfiguration?: ImportConfiguration | undefined;
}
export interface StartDICOMImportJobResponse {
    datastoreId: string;
    jobId: string;
    jobStatus: JobStatus;
    submittedAt: Date;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type DICOMAttribute = Uint8Array | redacted.Redacted<Uint8Array>;
export interface DICOMUpdates {
    removableAttributes?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    updatableAttributes?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export type MetadataUpdates = {
    DICOMUpdates: DICOMUpdates;
    revertToVersionId?: undefined;
} | {
    DICOMUpdates?: undefined;
    revertToVersionId: string;
};
export interface UpdateImageSetMetadataRequest {
    datastoreId: string;
    imageSetId: string;
    latestVersionId: string;
    force?: boolean | undefined;
    includeStudyImageSets?: boolean | undefined;
    updateImageSetMetadataUpdates: MetadataUpdates;
}
export interface UpdateImageSetMetadataResponse {
    datastoreId: string;
    imageSetId: string;
    latestVersionId: string;
    imageSetState: ImageSetState;
    imageSetWorkflowStatus?: ImageSetWorkflowStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    message?: string | undefined;
}
export type CopyImageSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Copy an image set.
 */
export declare const copyImageSet: API.OperationMethod<CopyImageSetRequest & RegionInput, CopyImageSetResponse, CopyImageSetError, Credentials | HttpClient.HttpClient>;
export type CreateDatastoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a data store.
 */
export declare const createDatastore: API.OperationMethod<CreateDatastoreRequest & RegionInput, CreateDatastoreResponse, CreateDatastoreError, Credentials | HttpClient.HttpClient>;
export type DeleteDatastoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a data store.
 *
 * Before a data store can be deleted, you must first delete all image sets within it.
 */
export declare const deleteDatastore: API.OperationMethod<DeleteDatastoreRequest & RegionInput, DeleteDatastoreResponse, DeleteDatastoreError, Credentials | HttpClient.HttpClient>;
export type DeleteImageSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an image set.
 */
export declare const deleteImageSet: API.OperationMethod<DeleteImageSetRequest & RegionInput, DeleteImageSetResponse, DeleteImageSetError, Credentials | HttpClient.HttpClient>;
export type GetDatastoreError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get data store properties.
 */
export declare const getDatastore: API.OperationMethod<GetDatastoreRequest & RegionInput, GetDatastoreResponse, GetDatastoreError, Credentials | HttpClient.HttpClient>;
export type GetDICOMImportJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the import job properties to learn more about the job or job progress.
 *
 * The `jobStatus` refers to the execution of the import job. Therefore, an import job can return a `jobStatus` as `COMPLETED` even if validation issues are discovered during the import process. If a `jobStatus` returns as `COMPLETED`, we still recommend you review the output manifests written to S3, as they provide details on the success or failure of individual P10 object imports.
 */
export declare const getDICOMImportJob: API.OperationMethod<GetDICOMImportJobRequest & RegionInput, GetDICOMImportJobResponse, GetDICOMImportJobError, Credentials | HttpClient.HttpClient>;
export type GetImageFrameError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | NotAcceptableException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an image frame (pixel data) for an image set.
 */
export declare const getImageFrame: API.OperationMethod<GetImageFrameRequest & RegionInput, GetImageFrameResponse, GetImageFrameError, Credentials | HttpClient.HttpClient>;
export type GetImageSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get image set properties.
 */
export declare const getImageSet: API.OperationMethod<GetImageSetRequest & RegionInput, GetImageSetResponse, GetImageSetError, Credentials | HttpClient.HttpClient>;
export type GetImageSetMetadataError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get metadata attributes for an image set.
 */
export declare const getImageSetMetadata: API.OperationMethod<GetImageSetMetadataRequest & RegionInput, GetImageSetMetadataResponse, GetImageSetMetadataError, Credentials | HttpClient.HttpClient>;
export type ListDatastoresError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List data stores.
 */
export declare const listDatastores: API.PaginatedOperationMethod<ListDatastoresRequest & RegionInput, ListDatastoresResponse, ListDatastoresError, Credentials | HttpClient.HttpClient, DatastoreSummary>;
export type ListDICOMImportJobsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List import jobs created for a specific data store.
 */
export declare const listDICOMImportJobs: API.PaginatedOperationMethod<ListDICOMImportJobsRequest & RegionInput, ListDICOMImportJobsResponse, ListDICOMImportJobsError, Credentials | HttpClient.HttpClient, DICOMImportJobSummary>;
export type ListImageSetVersionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List image set versions.
 */
export declare const listImageSetVersions: API.PaginatedOperationMethod<ListImageSetVersionsRequest & RegionInput, ListImageSetVersionsResponse, ListImageSetVersionsError, Credentials | HttpClient.HttpClient, ImageSetProperties>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags associated with a medical imaging resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SearchImageSetsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Search image sets based on defined input attributes.
 *
 * `SearchImageSets` accepts a single search query parameter and returns a paginated response of all image sets that have the matching criteria. All date range queries must be input as `(lowerBound, upperBound)`.
 *
 * By default, `SearchImageSets` uses the `updatedAt` field for sorting in descending order from newest to oldest.
 */
export declare const searchImageSets: API.PaginatedOperationMethod<SearchImageSetsRequest & RegionInput, SearchImageSetsResponse, SearchImageSetsError, Credentials | HttpClient.HttpClient, ImageSetsMetadataSummary>;
export type StartDICOMImportJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start importing bulk data into an `ACTIVE` data store. The import job imports DICOM P10 files or enhances existing DICOM files with JSON metadata. The `importConfiguration` parameter specifies the import type. The data is found in the S3 prefix specified by the `inputS3Uri` parameter. The import job stores processing results in the file specified by the `outputS3Uri` parameter.
 */
export declare const startDICOMImportJob: API.OperationMethod<StartDICOMImportJobRequest & RegionInput, StartDICOMImportJobResponse, StartDICOMImportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a user-specifed key and value tag to a medical imaging resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a medical imaging resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateImageSetMetadataError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update image set metadata attributes.
 */
export declare const updateImageSetMetadata: API.OperationMethod<UpdateImageSetMetadataRequest & RegionInput, UpdateImageSetMetadataResponse, UpdateImageSetMetadataError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=medical-imaging.d.ts.map