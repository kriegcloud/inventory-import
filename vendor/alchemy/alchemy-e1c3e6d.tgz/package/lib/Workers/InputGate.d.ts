/**
 * Cloudflare's input gate, for Durable Object engines whose storage is
 * asynchronous.
 *
 * On Cloudflare, a Durable Object's calls interleave whenever one waits on
 * something, but never around storage: while a storage operation is in
 * flight no other call proceeds, so a `get` followed by a `put`, with only
 * plain code between them, can't lose an update. An engine that runs calls
 * concurrently over async storage (Rivet) loses that guarantee. This gate
 * restores it.
 *
 * The gate is held by a call, not a fiber: every fiber a call forks shares
 * it. A call takes the gate at its first storage operation and keeps it
 * while it keeps doing storage. Once it waits on anything else (a `fetch`,
 * another Durable Object, a sleep), the gate passes to the next call
 * waiting for storage. Calls still overlap while they wait on the outside
 * world; they only line up around storage.
 *
 * The bridge runs each request, each alarm and the instance's construction
 * as a call. Work a call hands to `waitUntil` and fibers it forks stay part
 * of it after it returns, so a background loop started by the constructor
 * is gated as one long call.
 *
 * It's opt-in: provide the {@link InputGate} Layer (`Workers.InputGate`,
 * from `alchemy/Workers`) to a Durable Object
 * class's outer Effect, and the Durable Object bridge gives each of its
 * instances a gate. Storage goes through the gate where the engine wraps
 * its operations in {@link gateStorage}. Cloudflare has a gate of its own,
 * so it's for engines without one (Rivet).
 *
 * @module
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
export interface InputGateShape {
    /**
     * Run one call. The call's fibers share one place in the gate, and the
     * call never yields to the scheduler on its own, so a `get` and a `put`
     * separated by plain code stay together.
     */
    readonly call: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
    /**
     * Run one storage operation. Waits while another call holds the gate,
     * then holds it until the call next waits on something that isn't
     * storage.
     */
    readonly storage: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
    /**
     * Hold the gate for the whole of `effect`, whatever it waits on (a
     * transaction). A call made back into this instance from inside waits
     * until `effect` finishes, so don't call out from it.
     */
    readonly exclusive: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
}
declare const InstanceInputGate_base: Context.ServiceClass<InstanceInputGate, "alchemy/Workers/InstanceInputGate", InputGateShape>;
/** One Durable Object instance's input gate. */
export declare class InstanceInputGate extends InstanceInputGate_base {
}
/** Build a gate for one instance. */
export declare const makeInputGate: Effect.Effect<InputGateShape>;
/**
 * Cloudflare's input gate, for a Durable Object on an engine without one.
 *
 * Without it, an instance's calls run fully in parallel, storage included:
 * make a change atomic with a transaction. Provide it to a class's outer
 * Effect and each instance gets its own gate, so storage behaves as on
 * Cloudflare: while one call does storage, no other call's storage runs,
 * and a `get` followed by a `put`, with only plain code between them, can't
 * lose an update. Calls still overlap while they wait on anything else.
 *
 * Each storage operation then waits its turn, so give it to code written
 * for Cloudflare's gate, and use transactions everywhere else.
 *
 * ### Running Cloudflare code unchanged
 * **Example:** A get-then-put counter on Rivet that loses no updates
 * ```typescript
 * import * as Workers from "alchemy/Workers";
 *
 * export default class Counter extends Rivet.DurableObject<Counter>()(
 *   "Counter",
 *   { main: import.meta.url },
 *   Effect.gen(function* () {
 *     return Effect.gen(function* () {
 *       const state = yield* Rivet.DurableObjectState;
 *       return {
 *         increment: () =>
 *           Effect.gen(function* () {
 *             const count = ((yield* state.storage.get<number>("count")) ?? 0) + 1;
 *             yield* state.storage.put("count", count);
 *             return count;
 *           }),
 *       };
 *     });
 *   }).pipe(Effect.provide(Layer.mergeAll(Default, Workers.InputGate))),
 * ) {}
 * ```
 */
export declare const InputGate: Layer.Layer<never>;
/** Run one call through the instance's gate, when it has one. */
export declare const gateCall: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/** Run one storage operation through the instance's gate, when it has one. */
export declare const gateStorage: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/** Hold the instance's gate for the whole of `effect`, when it has one. */
export declare const gateExclusive: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
export {};
//# sourceMappingURL=InputGate.d.ts.map