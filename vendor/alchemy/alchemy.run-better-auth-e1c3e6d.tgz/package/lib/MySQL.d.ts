import { type ConnectionSource } from "@alchemy.run/sql/ConnectionSource";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type { PoolOptions } from "mysql2/promise";
import { Database, type DatabaseService } from "./Database.ts";
import { type SqlLayerOptions } from "./Postgres.ts";
export interface MySQLOptions extends SqlLayerOptions {
    readonly pool?: Omit<PoolOptions, "uri">;
}
/**
 * Build the MySQL {@link DatabaseService}. Better Auth's Kysely path
 * expects the `mysql2/promise` pool: it passes the pool itself as the
 * MysqlDialect config, and the promise pool's `.pool` property is the
 * callback pool Kysely drives.
 *
 * @internal
 */
export declare const makeMySQLService: (source: ConnectionSource, options: MySQLOptions | undefined) => Effect.Effect<DatabaseService>;
/**
 * Generic TCP MySQL database layer for Better Auth, from a connection
 * string.
 *
 * Works with PlanetScale MySQL, Cloudflare Hyperdrive MySQL origins, AWS
 * RDS MySQL, or any literal URL. One `mysql2` pool per execution, closed
 * when the event settles.
 *
 *
 * ### Connecting to PlanetScale MySQL
 * PlanetScale requires TLS — pass it in the URL's `ssl` query parameter
 * (mysql2 parses it as JSON).
 * **Example:** PlanetScale MySQL with TLS
 * ```typescript
 * import { BetterAuth } from "@alchemy.run/better-auth";
 * import { MySQL } from "@alchemy.run/better-auth/MySQL";
 *
 * const password = yield* Planetscale.MySQLPassword("auth-db", {
 *   database,
 *   role: "admin",
 * });
 * const url =
 *   `mysql://${password.username}:...@${password.host}/${database.name}` +
 *   `?ssl=${encodeURIComponent('{"rejectUnauthorized":true}')}`;
 *
 * Effect.gen(function* () {
 *   const auth = yield* BetterAuth({ emailAndPassword: { enabled: true } });
 *   return { fetch: ... };
 * }).pipe(Effect.provide(MySQL(url)))
 * ```
 *
 * @layer
 * @provides BetterAuth.Database
 * @peer mysql2
 * @product MySQL
 */
export declare const MySQL: (url: ConnectionSource, options?: MySQLOptions) => Layer.Layer<Database>;
//# sourceMappingURL=MySQL.d.ts.map