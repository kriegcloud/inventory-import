import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** Adds one or more email addresses to your GitHub account. Must contain at least one email address. **Note:** Alternatively, you can pass a single email address or an `array` of emails addresses directly, but we recommend that you pass an object using the `emails` key. */
export type AddEmailForAuthenticatedUserRequestBodyCase0EmailsList = Array<string>;
export interface AddEmailForAuthenticatedUserRequestBodyCase0 {
    /** Adds one or more email addresses to your GitHub account. Must contain at least one email address. **Note:** Alternatively, you can pass a single email address or an `array` of emails addresses directly, but we recommend that you pass an object using the `emails` key. */
    emails: AddEmailForAuthenticatedUserRequestBodyCase0EmailsList;
}
export type AddEmailForAuthenticatedUserRequestBodyCase1List = Array<string>;
export type AddEmailForAuthenticatedUserRequestBody = AddEmailForAuthenticatedUserRequestBodyCase0 | AddEmailForAuthenticatedUserRequestBodyCase1List | string;
export interface AddEmailForAuthenticatedUserRequest {
    body?: AddEmailForAuthenticatedUserRequestBody | undefined;
}
/** Email */
export interface Email {
    email: string;
    primary: boolean;
    verified: boolean;
    visibility: string | null;
}
export type AddEmailForAuthenticatedUserResponseBodyList = Array<Email>;
export type AddEmailForAuthenticatedUserResponse = AddEmailForAuthenticatedUserResponseBodyList;
/** Full URLs for the social media profiles to add. */
export type AddSocialAccountForAuthenticatedUserRequestAccountUrlsList = Array<string>;
export interface AddSocialAccountForAuthenticatedUserRequest {
    /** Full URLs for the social media profiles to add. */
    account_urls: AddSocialAccountForAuthenticatedUserRequestAccountUrlsList;
}
/** Social media account */
export interface SocialAccount {
    provider: string;
    url: string;
}
export type AddSocialAccountForAuthenticatedUserResponseBodyList = Array<SocialAccount>;
export type AddSocialAccountForAuthenticatedUserResponse = AddSocialAccountForAuthenticatedUserResponseBodyList;
export interface BlockRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export interface BlockResponse {
}
export interface CheckBlockedRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export interface CheckBlockedResponse {
}
export interface CheckFollowingForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    target_user: string;
}
export interface CheckFollowingForUserResponse {
}
export interface CheckPersonIsFollowedByAuthenticatedRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export interface CheckPersonIsFollowedByAuthenticatedResponse {
}
export interface CreateGpgKeyForAuthenticatedUserRequest {
    /** A descriptive name for the new key. */
    name?: string | undefined;
    /** A GPG key in ASCII-armored format. */
    armored_public_key: string;
}
export interface GpgKeyEmailsItem {
    email?: string | undefined;
    verified?: boolean | undefined;
}
export type GpgKeyEmailsList = Array<GpgKeyEmailsItem>;
export type GpgKeySubkeysItemEmailsItem = GpgKeyEmailsItem;
export type GpgKeySubkeysItemEmailsList = Array<GpgKeyEmailsItem>;
export type GpgKeySubkeysItemSubkeysList = Array<unknown>;
export interface GpgKeySubkeysItem {
    id?: number | undefined;
    primary_key_id?: number | undefined;
    key_id?: string | undefined;
    public_key?: string | undefined;
    emails?: GpgKeySubkeysItemEmailsList | undefined;
    subkeys?: GpgKeySubkeysItemSubkeysList | undefined;
    can_sign?: boolean | undefined;
    can_encrypt_comms?: boolean | undefined;
    can_encrypt_storage?: boolean | undefined;
    can_certify?: boolean | undefined;
    created_at?: string | undefined;
    expires_at?: string | null | undefined;
    raw_key?: string | null | undefined;
    revoked?: boolean | undefined;
}
export type GpgKeySubkeysList = Array<GpgKeySubkeysItem>;
/** A unique encryption key */
export interface GpgKey {
    id: number;
    name?: string | null | undefined;
    primary_key_id: number | null;
    key_id: string;
    public_key: string;
    emails: GpgKeyEmailsList;
    subkeys: GpgKeySubkeysList;
    can_sign: boolean;
    can_encrypt_comms: boolean;
    can_encrypt_storage: boolean;
    can_certify: boolean;
    created_at: string;
    expires_at: string | null;
    revoked: boolean;
    raw_key: string | null;
}
export interface CreatePublicSshKeyForAuthenticatedUserRequest {
    /** A descriptive name for the new key. */
    title?: string | undefined;
    /** The public SSH key to add to your GitHub account. */
    key: string;
}
/** Key */
export interface Key {
    key: string;
    id: number;
    url: string;
    title: string;
    created_at: string;
    verified: boolean;
    read_only: boolean;
    last_used?: string | null | undefined;
}
export interface CreateSshSigningKeyForAuthenticatedUserRequest {
    /** A descriptive name for the new key. */
    title?: string | undefined;
    /** The public SSH key to add to your GitHub account. For more information, see "[Checking for existing SSH keys](https://docs.github.com/authentication/connecting-to-github-with-ssh/checking-for-existing-ssh-keys)." */
    key: string;
}
/** A public SSH key used to sign Git commits */
export interface SshSigningKey {
    key: string;
    id: number;
    title: string;
    created_at: string;
}
/** List of subject digests associated with the artifact attestations to delete. */
export type DeleteAttestationsBulkRequestBodyCase0SubjectDigestsList = Array<string>;
export interface DeleteAttestationsBulkRequestBodyCase0 {
    /** List of subject digests associated with the artifact attestations to delete. */
    subject_digests: DeleteAttestationsBulkRequestBodyCase0SubjectDigestsList;
}
/** List of unique IDs associated with the artifact attestations to delete. */
export type DeleteAttestationsBulkRequestBodyCase1AttestationIdsList = Array<number>;
export interface DeleteAttestationsBulkRequestBodyCase1 {
    /** List of unique IDs associated with the artifact attestations to delete. */
    attestation_ids: DeleteAttestationsBulkRequestBodyCase1AttestationIdsList;
}
/** The request body must include either `subject_digests` or `attestation_ids`, but not both. */
export type DeleteAttestationsBulkRequestBody = DeleteAttestationsBulkRequestBodyCase0 | DeleteAttestationsBulkRequestBodyCase1;
export interface DeleteAttestationsBulkRequest {
    /** The handle for the GitHub user account. */
    username: string;
    body: DeleteAttestationsBulkRequestBody;
}
export interface DeleteAttestationsBulkResponse {
}
export interface DeleteAttestationsByIdRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** Attestation ID */
    attestation_id: number;
}
export interface DeleteAttestationsByIdResponse {
}
export interface DeleteAttestationsBySubjectDigestRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** Subject Digest */
    subject_digest: string;
}
export interface DeleteAttestationsBySubjectDigestResponse {
}
/** Email addresses associated with the GitHub user account. */
export type DeleteEmailForAuthenticatedUserRequestBodyCase0EmailsList = Array<string>;
/** Deletes one or more email addresses from your GitHub account. Must contain at least one email address. **Note:** Alternatively, you can pass a single email address or an `array` of emails addresses directly, but we recommend that you pass an object using the `emails` key. */
export interface DeleteEmailForAuthenticatedUserRequestBodyCase0 {
    /** Email addresses associated with the GitHub user account. */
    emails: DeleteEmailForAuthenticatedUserRequestBodyCase0EmailsList;
}
export type DeleteEmailForAuthenticatedUserRequestBodyCase1List = Array<string>;
export type DeleteEmailForAuthenticatedUserRequestBody = DeleteEmailForAuthenticatedUserRequestBodyCase0 | DeleteEmailForAuthenticatedUserRequestBodyCase1List | string;
export interface DeleteEmailForAuthenticatedUserRequest {
    body?: DeleteEmailForAuthenticatedUserRequestBody | undefined;
}
export interface DeleteEmailForAuthenticatedUserResponse {
}
export interface DeleteGpgKeyForAuthenticatedUserRequest {
    /** The unique identifier of the GPG key. */
    gpg_key_id: number;
}
export interface DeleteGpgKeyForAuthenticatedUserResponse {
}
export interface DeletePublicSshKeyForAuthenticatedUserRequest {
    /** The unique identifier of the key. */
    key_id: number;
}
export interface DeletePublicSshKeyForAuthenticatedUserResponse {
}
/** Full URLs for the social media profiles to delete. */
export type DeleteSocialAccountForAuthenticatedUserRequestAccountUrlsList = Array<string>;
export interface DeleteSocialAccountForAuthenticatedUserRequest {
    /** Full URLs for the social media profiles to delete. */
    account_urls: DeleteSocialAccountForAuthenticatedUserRequestAccountUrlsList;
}
export interface DeleteSocialAccountForAuthenticatedUserResponse {
}
export interface DeleteSshSigningKeyForAuthenticatedUserRequest {
    /** The unique identifier of the SSH signing key. */
    ssh_signing_key_id: number;
}
export interface DeleteSshSigningKeyForAuthenticatedUserResponse {
}
export interface FollowRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export interface FollowResponse {
}
export interface GetAuthenticatedRequest {
}
export interface PrivateUserPlan {
    collaborators: number;
    name: string;
    space: number;
    private_repos: number;
}
/** Private User */
export interface PrivateUser {
    login: string;
    id: number;
    user_view_type?: string | undefined;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    name: string | null;
    company: string | null;
    blog: string | null;
    location: string | null;
    email: string | null;
    notification_email?: string | null | undefined;
    hireable: boolean | null;
    bio: string | null;
    twitter_username?: string | null | undefined;
    public_repos: number;
    public_gists: number;
    followers: number;
    following: number;
    created_at: string;
    updated_at: string;
    private_gists: number;
    total_private_repos: number;
    owned_private_repos: number;
    disk_usage: number;
    collaborators: number;
    two_factor_authentication: boolean;
    plan?: PrivateUserPlan | undefined;
    business_plus?: boolean | undefined;
    ldap_dn?: string | undefined;
}
export type PublicUserPlan = PrivateUserPlan;
/** Public User */
export interface PublicUser {
    login: string;
    id: number;
    user_view_type?: string | undefined;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    name: string | null;
    company: string | null;
    blog: string | null;
    location: string | null;
    email: string | null;
    notification_email?: string | null | undefined;
    hireable: boolean | null;
    bio: string | null;
    twitter_username?: string | null | undefined;
    public_repos: number;
    public_gists: number;
    followers: number;
    following: number;
    created_at: string;
    updated_at: string;
    plan?: PrivateUserPlan | undefined;
    private_gists?: number | undefined;
    total_private_repos?: number | undefined;
    owned_private_repos?: number | undefined;
    disk_usage?: number | undefined;
    collaborators?: number | undefined;
}
export type GetAuthenticatedResponseBody = PrivateUser | PublicUser;
export type GetAuthenticatedResponse = GetAuthenticatedResponseBody;
export interface GetByIdRequest {
    /** account_id parameter */
    account_id: number;
}
export type GetByIdResponseBody = PrivateUser | PublicUser;
export type GetByIdResponse = GetByIdResponseBody;
export interface GetByUsernameRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export type GetByUsernameResponseBody = PrivateUser | PublicUser;
export type GetByUsernameResponse = GetByUsernameResponseBody;
export type GetContextForUserRequestSubjectType = "organization" | "repository" | "issue" | "pull_request";
export interface GetContextForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** Identifies which additional information you'd like to receive about the person's hovercard. Can be `organization`, `repository`, `issue`, `pull_request`. **Required** when using `subject_id`. */
    subject_type?: GetContextForUserRequestSubjectType | (string & {}) | undefined;
    /** Uses the ID for the `subject_type` you specified. **Required** when using `subject_type`. */
    subject_id?: string | undefined;
}
export interface HovercardContextsItem {
    message: string;
    octicon: string;
}
export type HovercardContextsList = Array<HovercardContextsItem>;
/** Hovercard */
export interface Hovercard {
    contexts: HovercardContextsList;
}
export interface GetGpgKeyForAuthenticatedUserRequest {
    /** The unique identifier of the GPG key. */
    gpg_key_id: number;
}
export interface GetPublicSshKeyForAuthenticatedUserRequest {
    /** The unique identifier of the key. */
    key_id: number;
}
export interface GetSshSigningKeyForAuthenticatedUserRequest {
    /** The unique identifier of the SSH signing key. */
    ssh_signing_key_id: number;
}
export interface ListRequest {
    /** A user ID. Only return users with an ID greater than this ID. */
    since?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export type ListResponseBodyList = Array<SimpleUser>;
export type ListResponse = ListResponseBodyList;
export interface ListAttestationsRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** Subject Digest */
    subject_digest: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** Optional filter for fetching attestations with a given predicate type. This option accepts `provenance`, `sbom`, `release`, or freeform text for custom predicate types. */
    predicate_type?: string | undefined;
}
export type ListAttestationsResponseAttestationsItemBundleVerificationMaterialMap = {
    [key: string]: unknown | undefined;
};
export type ListAttestationsResponseAttestationsItemBundleDsseEnvelopeMap = {
    [key: string]: unknown | undefined;
};
/** The attestation's Sigstore Bundle. Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information. */
export interface ListAttestationsResponseAttestationsItemBundle {
    mediaType?: string | undefined;
    verificationMaterial?: ListAttestationsResponseAttestationsItemBundleVerificationMaterialMap | undefined;
    dsseEnvelope?: ListAttestationsResponseAttestationsItemBundleDsseEnvelopeMap | undefined;
}
export interface ListAttestationsResponseAttestationsItem {
    /** The attestation's Sigstore Bundle. Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information. */
    bundle?: ListAttestationsResponseAttestationsItemBundle | undefined;
    repository_id?: number | undefined;
    bundle_url?: string | undefined;
    initiator?: string | undefined;
}
export type ListAttestationsResponseAttestationsList = Array<ListAttestationsResponseAttestationsItem>;
export interface ListAttestationsResponse {
    attestations?: ListAttestationsResponseAttestationsList | undefined;
}
/** List of subject digests to fetch attestations for. */
export type ListAttestationsBulkRequestSubjectDigestsList = Array<string>;
export interface ListAttestationsBulkRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** List of subject digests to fetch attestations for. */
    subject_digests: ListAttestationsBulkRequestSubjectDigestsList;
    /** Optional filter for fetching attestations with a given predicate type. This option accepts `provenance`, `sbom`, `release`, or freeform text for custom predicate types. */
    predicate_type?: string | undefined;
}
export type ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundleVerificationMaterialMap = {
    [key: string]: unknown | undefined;
};
export type ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundleDsseEnvelopeMap = {
    [key: string]: unknown | undefined;
};
/** The bundle of the attestation. */
export interface ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundle {
    mediaType?: string | undefined;
    verificationMaterial?: ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundleVerificationMaterialMap | undefined;
    dsseEnvelope?: ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundleDsseEnvelopeMap | undefined;
}
export interface ListAttestationsBulkResponseAttestationsSubjectDigestsValueItem {
    /** The bundle of the attestation. */
    bundle?: ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundle | undefined;
    repository_id?: number | undefined;
    bundle_url?: string | undefined;
}
export type ListAttestationsBulkResponseAttestationsSubjectDigestsValueList = Array<ListAttestationsBulkResponseAttestationsSubjectDigestsValueItem>;
/** Mapping of subject digest to bundles. */
export type ListAttestationsBulkResponseAttestationsSubjectDigestsMap = {
    [key: string]: ListAttestationsBulkResponseAttestationsSubjectDigestsValueList | null | undefined;
};
/** Information about the current page. */
export interface ListAttestationsBulkResponsePageInfo {
    /** Indicates whether there is a next page. */
    has_next?: boolean | undefined;
    /** Indicates whether there is a previous page. */
    has_previous?: boolean | undefined;
    /** The cursor to the next page. */
    next?: string | undefined;
    /** The cursor to the previous page. */
    previous?: string | undefined;
}
export interface ListAttestationsBulkResponse {
    /** Mapping of subject digest to bundles. */
    attestations_subject_digests?: ListAttestationsBulkResponseAttestationsSubjectDigestsMap | undefined;
    /** Information about the current page. */
    page_info?: ListAttestationsBulkResponsePageInfo | undefined;
}
export interface ListBlockedByAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListBlockedByAuthenticatedUserResponseBodyList = Array<SimpleUser>;
export type ListBlockedByAuthenticatedUserResponse = ListBlockedByAuthenticatedUserResponseBodyList;
export interface ListEmailsForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListEmailsForAuthenticatedUserResponseBodyList = Array<Email>;
export type ListEmailsForAuthenticatedUserResponse = ListEmailsForAuthenticatedUserResponseBodyList;
export interface ListFollowedByAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListFollowedByAuthenticatedUserResponseBodyList = Array<SimpleUser>;
export type ListFollowedByAuthenticatedUserResponse = ListFollowedByAuthenticatedUserResponseBodyList;
export interface ListFollowersForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListFollowersForAuthenticatedUserResponseBodyList = Array<SimpleUser>;
export type ListFollowersForAuthenticatedUserResponse = ListFollowersForAuthenticatedUserResponseBodyList;
export interface ListFollowersForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListFollowersForUserResponseBodyList = Array<SimpleUser>;
export type ListFollowersForUserResponse = ListFollowersForUserResponseBodyList;
export interface ListFollowingForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListFollowingForUserResponseBodyList = Array<SimpleUser>;
export type ListFollowingForUserResponse = ListFollowingForUserResponseBodyList;
export interface ListGpgKeysForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListGpgKeysForAuthenticatedUserResponseBodyList = Array<GpgKey>;
export type ListGpgKeysForAuthenticatedUserResponse = ListGpgKeysForAuthenticatedUserResponseBodyList;
export interface ListGpgKeysForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListGpgKeysForUserResponseBodyList = Array<GpgKey>;
export type ListGpgKeysForUserResponse = ListGpgKeysForUserResponseBodyList;
export interface ListPublicEmailsForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPublicEmailsForAuthenticatedUserResponseBodyList = Array<Email>;
export type ListPublicEmailsForAuthenticatedUserResponse = ListPublicEmailsForAuthenticatedUserResponseBodyList;
export interface ListPublicKeysForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Key Simple */
export interface KeySimple {
    id: number;
    key: string;
    created_at?: string | undefined;
    last_used?: string | null | undefined;
}
export type ListPublicKeysForUserResponseBodyList = Array<KeySimple>;
export type ListPublicKeysForUserResponse = ListPublicKeysForUserResponseBodyList;
export interface ListPublicSshKeysForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPublicSshKeysForAuthenticatedUserResponseBodyList = Array<Key>;
export type ListPublicSshKeysForAuthenticatedUserResponse = ListPublicSshKeysForAuthenticatedUserResponseBodyList;
export interface ListSocialAccountsForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSocialAccountsForAuthenticatedUserResponseBodyList = Array<SocialAccount>;
export type ListSocialAccountsForAuthenticatedUserResponse = ListSocialAccountsForAuthenticatedUserResponseBodyList;
export interface ListSocialAccountsForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSocialAccountsForUserResponseBodyList = Array<SocialAccount>;
export type ListSocialAccountsForUserResponse = ListSocialAccountsForUserResponseBodyList;
export interface ListSshSigningKeysForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSshSigningKeysForAuthenticatedUserResponseBodyList = Array<SshSigningKey>;
export type ListSshSigningKeysForAuthenticatedUserResponse = ListSshSigningKeysForAuthenticatedUserResponseBodyList;
export interface ListSshSigningKeysForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSshSigningKeysForUserResponseBodyList = Array<SshSigningKey>;
export type ListSshSigningKeysForUserResponse = ListSshSigningKeysForUserResponseBodyList;
/** Denotes whether an email is publicly visible. */
export type SetPrimaryEmailVisibilityForAuthenticatedUserRequestVisibility = "public" | "private";
export interface SetPrimaryEmailVisibilityForAuthenticatedUserRequest {
    /** Denotes whether an email is publicly visible. */
    visibility: SetPrimaryEmailVisibilityForAuthenticatedUserRequestVisibility | (string & {});
}
export type SetPrimaryEmailVisibilityForAuthenticatedUserResponseBodyList = Array<Email>;
export type SetPrimaryEmailVisibilityForAuthenticatedUserResponse = SetPrimaryEmailVisibilityForAuthenticatedUserResponseBodyList;
export interface UnblockRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export interface UnblockResponse {
}
export interface UnfollowRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export interface UnfollowResponse {
}
export interface UpdateAuthenticatedRequest {
    /** The new name of the user. */
    name?: string | undefined;
    /** The publicly visible email address of the user. */
    email?: string | undefined;
    /** The new blog URL of the user. */
    blog?: string | undefined;
    /** The new Twitter username of the user. */
    twitter_username?: string | null | undefined;
    /** The new company of the user. */
    company?: string | undefined;
    /** The new location of the user. */
    location?: string | undefined;
    /** The new hiring availability of the user. */
    hireable?: boolean | undefined;
    /** The new short biography of the user. */
    bio?: string | undefined;
}
export type AddEmailForAuthenticatedUserError = GithubOpError;
/** Add an email address for the authenticated user OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const addEmailForAuthenticatedUser: API.OperationMethod<AddEmailForAuthenticatedUserRequest, AddEmailForAuthenticatedUserResponse, AddEmailForAuthenticatedUserError, GithubOpContext>;
export type AddSocialAccountForAuthenticatedUserError = GithubOpError;
/** Add social accounts for the authenticated user Add one or more social accounts to the authenticated user's profile. OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const addSocialAccountForAuthenticatedUser: API.OperationMethod<AddSocialAccountForAuthenticatedUserRequest, AddSocialAccountForAuthenticatedUserResponse, AddSocialAccountForAuthenticatedUserError, GithubOpContext>;
export type BlockError = GithubOpError;
/** Block a user Blocks the given user and returns a 204. If the authenticated user cannot block the given user a 422 is returned. */
export declare const block: API.OperationMethod<BlockRequest, BlockResponse, BlockError, GithubOpContext>;
export type CheckBlockedError = GithubOpError;
/** Check if a user is blocked by the authenticated user Returns a 204 if the given user is blocked by the authenticated user. Returns a 404 if the given user is not blocked by the authenticated user, or if the given user account has been identified as spam by GitHub. */
export declare const checkBlocked: API.OperationMethod<CheckBlockedRequest, CheckBlockedResponse, CheckBlockedError, GithubOpContext>;
export type CheckFollowingForUserError = GithubOpError;
/** Check if a user follows another user */
export declare const checkFollowingForUser: API.OperationMethod<CheckFollowingForUserRequest, CheckFollowingForUserResponse, CheckFollowingForUserError, GithubOpContext>;
export type CheckPersonIsFollowedByAuthenticatedError = GithubOpError;
/** Check if a person is followed by the authenticated user */
export declare const checkPersonIsFollowedByAuthenticated: API.OperationMethod<CheckPersonIsFollowedByAuthenticatedRequest, CheckPersonIsFollowedByAuthenticatedResponse, CheckPersonIsFollowedByAuthenticatedError, GithubOpContext>;
export type CreateGpgKeyForAuthenticatedUserError = GithubOpError;
/** Create a GPG key for the authenticated user Adds a GPG key to the authenticated user's GitHub account. OAuth app tokens and personal access tokens (classic) need the `write:gpg_key` scope to use this endpoint. */
export declare const createGpgKeyForAuthenticatedUser: API.OperationMethod<CreateGpgKeyForAuthenticatedUserRequest, GpgKey, CreateGpgKeyForAuthenticatedUserError, GithubOpContext>;
export type CreatePublicSshKeyForAuthenticatedUserError = GithubOpError;
/** Create a public SSH key for the authenticated user Adds a public SSH key to the authenticated user's GitHub account. OAuth app tokens and personal access tokens (classic) need the `write:public_key` scope to use this endpoint. */
export declare const createPublicSshKeyForAuthenticatedUser: API.OperationMethod<CreatePublicSshKeyForAuthenticatedUserRequest, Key, CreatePublicSshKeyForAuthenticatedUserError, GithubOpContext>;
export type CreateSshSigningKeyForAuthenticatedUserError = GithubOpError;
/** Create a SSH signing key for the authenticated user Creates an SSH signing key for the authenticated user's GitHub account. OAuth app tokens and personal access tokens (classic) need the `write:ssh_signing_key` scope to use this endpoint. */
export declare const createSshSigningKeyForAuthenticatedUser: API.OperationMethod<CreateSshSigningKeyForAuthenticatedUserRequest, SshSigningKey, CreateSshSigningKeyForAuthenticatedUserError, GithubOpContext>;
export type DeleteAttestationsBulkError = GithubOpError;
/** Delete attestations in bulk Delete artifact attestations in bulk by either subject digests or unique ID. */
export declare const deleteAttestationsBulk: API.OperationMethod<DeleteAttestationsBulkRequest, DeleteAttestationsBulkResponse, DeleteAttestationsBulkError, GithubOpContext>;
export type DeleteAttestationsByIdError = GithubOpError;
/** Delete attestations by ID Delete an artifact attestation by unique ID that is associated with a repository owned by a user. */
export declare const deleteAttestationsById: API.OperationMethod<DeleteAttestationsByIdRequest, DeleteAttestationsByIdResponse, DeleteAttestationsByIdError, GithubOpContext>;
export type DeleteAttestationsBySubjectDigestError = GithubOpError;
/** Delete attestations by subject digest Delete an artifact attestation by subject digest. */
export declare const deleteAttestationsBySubjectDigest: API.OperationMethod<DeleteAttestationsBySubjectDigestRequest, DeleteAttestationsBySubjectDigestResponse, DeleteAttestationsBySubjectDigestError, GithubOpContext>;
export type DeleteEmailForAuthenticatedUserError = GithubOpError;
/** Delete an email address for the authenticated user OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const deleteEmailForAuthenticatedUser: API.OperationMethod<DeleteEmailForAuthenticatedUserRequest, DeleteEmailForAuthenticatedUserResponse, DeleteEmailForAuthenticatedUserError, GithubOpContext>;
export type DeleteGpgKeyForAuthenticatedUserError = GithubOpError;
/** Delete a GPG key for the authenticated user Removes a GPG key from the authenticated user's GitHub account. OAuth app tokens and personal access tokens (classic) need the `admin:gpg_key` scope to use this endpoint. */
export declare const deleteGpgKeyForAuthenticatedUser: API.OperationMethod<DeleteGpgKeyForAuthenticatedUserRequest, DeleteGpgKeyForAuthenticatedUserResponse, DeleteGpgKeyForAuthenticatedUserError, GithubOpContext>;
export type DeletePublicSshKeyForAuthenticatedUserError = GithubOpError;
/** Delete a public SSH key for the authenticated user Removes a public SSH key from the authenticated user's GitHub account. OAuth app tokens and personal access tokens (classic) need the `admin:public_key` scope to use this endpoint. */
export declare const deletePublicSshKeyForAuthenticatedUser: API.OperationMethod<DeletePublicSshKeyForAuthenticatedUserRequest, DeletePublicSshKeyForAuthenticatedUserResponse, DeletePublicSshKeyForAuthenticatedUserError, GithubOpContext>;
export type DeleteSocialAccountForAuthenticatedUserError = GithubOpError;
/** Delete social accounts for the authenticated user Deletes one or more social accounts from the authenticated user's profile. OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const deleteSocialAccountForAuthenticatedUser: API.OperationMethod<DeleteSocialAccountForAuthenticatedUserRequest, DeleteSocialAccountForAuthenticatedUserResponse, DeleteSocialAccountForAuthenticatedUserError, GithubOpContext>;
export type DeleteSshSigningKeyForAuthenticatedUserError = GithubOpError;
/** Delete an SSH signing key for the authenticated user Deletes an SSH signing key from the authenticated user's GitHub account. OAuth app tokens and personal access tokens (classic) need the `admin:ssh_signing_key` scope to use this endpoint. */
export declare const deleteSshSigningKeyForAuthenticatedUser: API.OperationMethod<DeleteSshSigningKeyForAuthenticatedUserRequest, DeleteSshSigningKeyForAuthenticatedUserResponse, DeleteSshSigningKeyForAuthenticatedUserError, GithubOpContext>;
export type FollowError = GithubOpError;
/** Follow a user Note that you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP verbs](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)." OAuth app tokens and personal access tokens (classic) need the `user:follow` scope to use this endpoint. */
export declare const follow: API.OperationMethod<FollowRequest, FollowResponse, FollowError, GithubOpContext>;
export type GetAuthenticatedError = GithubOpError;
/** Get the authenticated user OAuth app tokens and personal access tokens (classic) need the `read:user` scope, or the broader `user` scope, for this endpoint to return the private user response. The private user response includes additional fields such as `private_gists`, `total_private_repos`, `owned_private_repos`, `disk_usage`, `collaborators`, and `two_factor_authentication`. Tokens without these scopes receive the public user response. The private and public user response types are unrelated to the [private profile](https://docs.github.com/account-and-profile/concepts/personal-profile#private-profiles) setting. A token without scopes still authenticates as the token's owner, so values subject to private profile visibility, such as `followers` and `following`, may differ from an unauthenticated response. For enterprise-managed users, if their email is unverified, this endpoint will return a placeholder email in the format `email+shortcode@domain.com` instead of their actual email. This placeholder email [may cause issues with some third-party apps](https://github.blog/changelog/2024-08-01-enterprise-managed-user-accounts-now-require-email-verification/). Once the user has [verified their email address](https://docs.github.com/account-and-profile/how-tos/email-preferences/verifying-your-email-address), the endpoint will return their real email. */
export declare const getAuthenticated: API.OperationMethod<GetAuthenticatedRequest, GetAuthenticatedResponse, GetAuthenticatedError, GithubOpContext>;
export type GetByIdError = GithubOpError;
/** Get a user using their ID Provides publicly available information about someone with a GitHub account. This method takes their durable user `ID` instead of their `login`, which can change over time. If you are requesting information about an [Enterprise Managed User](https://docs.github.com/enterprise-cloud@latest/admin/managing-iam/understanding-iam-for-enterprises/about-enterprise-managed-users), or a GitHub App bot that is installed in an organization that uses Enterprise Managed Users, your requests must be authenticated as a user or GitHub App that has access to the organization to view that account's information. If you are not authorized, the request will return a `404 Not Found` status. The `email` key in the following response is the publicly visible email address from your GitHub [profile page](https://github.com/settings/profile). When setting up your profile, you can select a primary email address to be public which provides an email entry for this endpoint. If you do not set a public email address for `email`, then it will have a value of `null`. You only see publicly visible email addresses when authenticated with GitHub. For more information, see [Authentication](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#authentication). The Emails API enables you to list all of your email addresses, and toggle a primary email to be visible publicly. For more information, see [Emails API](https://docs.github.com/rest/users/emails). */
export declare const getById: API.OperationMethod<GetByIdRequest, GetByIdResponse, GetByIdError, GithubOpContext>;
export type GetByUsernameError = GithubOpError;
/** Get a user Provides publicly available information about someone with a GitHub account. If the specified user has a [private profile](https://docs.github.com/account-and-profile/concepts/personal-profile#private-profiles), the `followers` and `following` values are `0` unless the request is authenticated as that user. A request authenticated as the specified user returns the actual values even if the token has no OAuth scopes. The `events_url` value is a URI template. Replace `{/privacy}` with `/public` to retrieve only public events. Omit it to retrieve public events and, when authenticated as the user, private events. For more information, see "[List events for the authenticated user](https://docs.github.com/rest/activity/events#list-events-for-the-authenticated-user)." If you are requesting information about an [Enterprise Managed User](https://docs.github.com/enterprise-cloud@latest/admin/managing-iam/understanding-iam-for-enterprises/about-enterprise-managed-users), or a GitHub App bot that is installed in an organization that uses Enterprise Managed Users, your requests must be authenticated as a user or GitHub App that has access to the organization to view that account's information. If you are not authorized, the request will return a `404 Not Found` status. The `email` key in the following response is the publicly visible email address from your GitHub [profile page](https://github.com/settings/profile). When setting up your profile, you can select a primary email address to be public which provides an email entry for this endpoint. If you do not set a public email address for `email`, then it will have a value of `null`. You only see publicly visible email addresses when authenticated with GitHub. For more information, see [Authentication](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#authentication). The Emails API enables you to list all of your email addresses, and toggle a primary email to be visible publicly. For more information, see [Emails API](https://docs.github.com/rest/users/emails). */
export declare const getByUsername: API.OperationMethod<GetByUsernameRequest, GetByUsernameResponse, GetByUsernameError, GithubOpContext>;
export type GetContextForUserError = GithubOpError;
/** Get contextual information for a user Provides hovercard information. You can find out more about someone in relation to their pull requests, issues, repositories, and organizations. The `subject_type` and `subject_id` parameters provide context for the person's hovercard, which returns more information than without the parameters. For example, if you wanted to find out more about `octocat` who owns the `Spoon-Knife` repository, you would use a `subject_type` value of `repository` and a `subject_id` value of `1300192` (the ID of the `Spoon-Knife` repository). OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getContextForUser: API.OperationMethod<GetContextForUserRequest, Hovercard, GetContextForUserError, GithubOpContext>;
export type GetGpgKeyForAuthenticatedUserError = GithubOpError;
/** Get a GPG key for the authenticated user View extended details for a single GPG key. OAuth app tokens and personal access tokens (classic) need the `read:gpg_key` scope to use this endpoint. */
export declare const getGpgKeyForAuthenticatedUser: API.OperationMethod<GetGpgKeyForAuthenticatedUserRequest, GpgKey, GetGpgKeyForAuthenticatedUserError, GithubOpContext>;
export type GetPublicSshKeyForAuthenticatedUserError = GithubOpError;
/** Get a public SSH key for the authenticated user View extended details for a single public SSH key. OAuth app tokens and personal access tokens (classic) need the `read:public_key` scope to use this endpoint. */
export declare const getPublicSshKeyForAuthenticatedUser: API.OperationMethod<GetPublicSshKeyForAuthenticatedUserRequest, Key, GetPublicSshKeyForAuthenticatedUserError, GithubOpContext>;
export type GetSshSigningKeyForAuthenticatedUserError = GithubOpError;
/** Get an SSH signing key for the authenticated user Gets extended details for an SSH signing key. OAuth app tokens and personal access tokens (classic) need the `read:ssh_signing_key` scope to use this endpoint. */
export declare const getSshSigningKeyForAuthenticatedUser: API.OperationMethod<GetSshSigningKeyForAuthenticatedUserRequest, SshSigningKey, GetSshSigningKeyForAuthenticatedUserError, GithubOpContext>;
export type ListError = GithubOpError;
/** List users Lists all users, in the order that they signed up on GitHub. This list includes personal user accounts and organization accounts. Note: Pagination is powered exclusively by the `since` parameter. Use the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers) to get the URL for the next page of users. */
export declare const list: API.OperationMethod<ListRequest, ListResponse, ListError, GithubOpContext>;
export type ListAttestationsError = GithubOpError;
/** List attestations List a collection of artifact attestations with a given subject digest that are associated with repositories owned by a user. The collection of attestations returned by this endpoint is filtered according to the authenticated user's permissions; if the authenticated user cannot read a repository, the attestations associated with that repository will not be included in the response. In addition, when using a fine-grained access token the `attestations:read` permission is required. **Please note:** in order to offer meaningful security benefits, an attestation's signature and timestamps **must** be cryptographically verified, and the identity of the attestation signer **must** be validated. Attestations can be verified using the [GitHub CLI `attestation verify` command](https://cli.github.com/manual/gh_attestation_verify). For more information, see [our guide on how to use artifact attestations to establish a build's provenance](https://docs.github.com/actions/security-guides/using-artifact-attestations-to-establish-provenance-for-builds). */
export declare const listAttestations: API.OperationMethod<ListAttestationsRequest, ListAttestationsResponse, ListAttestationsError, GithubOpContext>;
export type ListAttestationsBulkError = GithubOpError;
/** List attestations by bulk subject digests List a collection of artifact attestations associated with any entry in a list of subject digests owned by a user. The collection of attestations returned by this endpoint is filtered according to the authenticated user's permissions; if the authenticated user cannot read a repository, the attestations associated with that repository will not be included in the response. In addition, when using a fine-grained access token the `attestations:read` permission is required. **Please note:** in order to offer meaningful security benefits, an attestation's signature and timestamps **must** be cryptographically verified, and the identity of the attestation signer **must** be validated. Attestations can be verified using the [GitHub CLI `attestation verify` command](https://cli.github.com/manual/gh_attestation_verify). For more information, see [our guide on how to use artifact attestations to establish a build's provenance](https://docs.github.com/actions/security-guides/using-artifact-attestations-to-establish-provenance-for-builds). */
export declare const listAttestationsBulk: API.OperationMethod<ListAttestationsBulkRequest, ListAttestationsBulkResponse, ListAttestationsBulkError, GithubOpContext>;
export type ListBlockedByAuthenticatedUserError = GithubOpError;
/** List users blocked by the authenticated user List the users you've blocked on your personal account. */
export declare const listBlockedByAuthenticatedUser: API.PaginatedOperationMethod<ListBlockedByAuthenticatedUserRequest, ListBlockedByAuthenticatedUserResponse, ListBlockedByAuthenticatedUserError, GithubOpContext, SimpleUser>;
export type ListEmailsForAuthenticatedUserError = GithubOpError;
/** List email addresses for the authenticated user Lists all of your email addresses, and specifies which one is visible to the public. OAuth app tokens and personal access tokens (classic) need the `user:email` scope to use this endpoint. For enterprise-managed users, if their email is unverified, this endpoint will return a placeholder email in the format `email+shortcode@domain.com` instead of their actual email. This placeholder email [may cause issues with some third-party apps](https://github.blog/changelog/2024-08-01-enterprise-managed-user-accounts-now-require-email-verification/). Once the user has [verified their email address](https://docs.github.com/account-and-profile/how-tos/email-preferences/verifying-your-email-address), the endpoint will return their real email. */
export declare const listEmailsForAuthenticatedUser: API.PaginatedOperationMethod<ListEmailsForAuthenticatedUserRequest, ListEmailsForAuthenticatedUserResponse, ListEmailsForAuthenticatedUserError, GithubOpContext, Email>;
export type ListFollowedByAuthenticatedUserError = GithubOpError;
/** List the people the authenticated user follows Lists the people who the authenticated user follows. */
export declare const listFollowedByAuthenticatedUser: API.PaginatedOperationMethod<ListFollowedByAuthenticatedUserRequest, ListFollowedByAuthenticatedUserResponse, ListFollowedByAuthenticatedUserError, GithubOpContext, SimpleUser>;
export type ListFollowersForAuthenticatedUserError = GithubOpError;
/** List followers of the authenticated user Lists the people following the authenticated user. */
export declare const listFollowersForAuthenticatedUser: API.PaginatedOperationMethod<ListFollowersForAuthenticatedUserRequest, ListFollowersForAuthenticatedUserResponse, ListFollowersForAuthenticatedUserError, GithubOpContext, SimpleUser>;
export type ListFollowersForUserError = GithubOpError;
/** List followers of a user Lists the people following the specified user. If the specified user has a [private profile](https://docs.github.com/account-and-profile/concepts/personal-profile#private-profiles), this endpoint returns an empty list unless the request is authenticated as that user. A request authenticated as the specified user returns the list even if the token has no OAuth scopes. */
export declare const listFollowersForUser: API.PaginatedOperationMethod<ListFollowersForUserRequest, ListFollowersForUserResponse, ListFollowersForUserError, GithubOpContext, SimpleUser>;
export type ListFollowingForUserError = GithubOpError;
/** List the people a user follows Lists the people who the specified user follows. If the specified user has a [private profile](https://docs.github.com/account-and-profile/concepts/personal-profile#private-profiles), this endpoint returns an empty list unless the request is authenticated as that user. A request authenticated as the specified user returns the list even if the token has no OAuth scopes. */
export declare const listFollowingForUser: API.PaginatedOperationMethod<ListFollowingForUserRequest, ListFollowingForUserResponse, ListFollowingForUserError, GithubOpContext, SimpleUser>;
export type ListGpgKeysForAuthenticatedUserError = GithubOpError;
/** List GPG keys for the authenticated user Lists the current user's GPG keys. OAuth app tokens and personal access tokens (classic) need the `read:gpg_key` scope to use this endpoint. */
export declare const listGpgKeysForAuthenticatedUser: API.PaginatedOperationMethod<ListGpgKeysForAuthenticatedUserRequest, ListGpgKeysForAuthenticatedUserResponse, ListGpgKeysForAuthenticatedUserError, GithubOpContext, GpgKey>;
export type ListGpgKeysForUserError = GithubOpError;
/** List GPG keys for a user Lists the GPG keys for a user. This information is accessible by anyone. */
export declare const listGpgKeysForUser: API.PaginatedOperationMethod<ListGpgKeysForUserRequest, ListGpgKeysForUserResponse, ListGpgKeysForUserError, GithubOpContext, GpgKey>;
export type ListPublicEmailsForAuthenticatedUserError = GithubOpError;
/** List public email addresses for the authenticated user Lists your publicly visible email address, which you can set with the [Set primary email visibility for the authenticated user](https://docs.github.com/rest/users/emails#set-primary-email-visibility-for-the-authenticated-user) endpoint. OAuth app tokens and personal access tokens (classic) need the `user:email` scope to use this endpoint. */
export declare const listPublicEmailsForAuthenticatedUser: API.PaginatedOperationMethod<ListPublicEmailsForAuthenticatedUserRequest, ListPublicEmailsForAuthenticatedUserResponse, ListPublicEmailsForAuthenticatedUserError, GithubOpContext, Email>;
export type ListPublicKeysForUserError = GithubOpError;
/** List public keys for a user Lists the _verified_ public SSH keys for a user. This is accessible by anyone. */
export declare const listPublicKeysForUser: API.PaginatedOperationMethod<ListPublicKeysForUserRequest, ListPublicKeysForUserResponse, ListPublicKeysForUserError, GithubOpContext, KeySimple>;
export type ListPublicSshKeysForAuthenticatedUserError = GithubOpError;
/** List public SSH keys for the authenticated user Lists the public SSH keys for the authenticated user's GitHub account. OAuth app tokens and personal access tokens (classic) need the `read:public_key` scope to use this endpoint. */
export declare const listPublicSshKeysForAuthenticatedUser: API.PaginatedOperationMethod<ListPublicSshKeysForAuthenticatedUserRequest, ListPublicSshKeysForAuthenticatedUserResponse, ListPublicSshKeysForAuthenticatedUserError, GithubOpContext, Key>;
export type ListSocialAccountsForAuthenticatedUserError = GithubOpError;
/** List social accounts for the authenticated user Lists all of your social accounts. */
export declare const listSocialAccountsForAuthenticatedUser: API.PaginatedOperationMethod<ListSocialAccountsForAuthenticatedUserRequest, ListSocialAccountsForAuthenticatedUserResponse, ListSocialAccountsForAuthenticatedUserError, GithubOpContext, SocialAccount>;
export type ListSocialAccountsForUserError = GithubOpError;
/** List social accounts for a user Lists social media accounts for a user. This endpoint is accessible by anyone. */
export declare const listSocialAccountsForUser: API.PaginatedOperationMethod<ListSocialAccountsForUserRequest, ListSocialAccountsForUserResponse, ListSocialAccountsForUserError, GithubOpContext, SocialAccount>;
export type ListSshSigningKeysForAuthenticatedUserError = GithubOpError;
/** List SSH signing keys for the authenticated user Lists the SSH signing keys for the authenticated user's GitHub account. OAuth app tokens and personal access tokens (classic) need the `read:ssh_signing_key` scope to use this endpoint. */
export declare const listSshSigningKeysForAuthenticatedUser: API.PaginatedOperationMethod<ListSshSigningKeysForAuthenticatedUserRequest, ListSshSigningKeysForAuthenticatedUserResponse, ListSshSigningKeysForAuthenticatedUserError, GithubOpContext, SshSigningKey>;
export type ListSshSigningKeysForUserError = GithubOpError;
/** List SSH signing keys for a user Lists the SSH signing keys for a user. This operation is accessible by anyone. */
export declare const listSshSigningKeysForUser: API.PaginatedOperationMethod<ListSshSigningKeysForUserRequest, ListSshSigningKeysForUserResponse, ListSshSigningKeysForUserError, GithubOpContext, SshSigningKey>;
export type SetPrimaryEmailVisibilityForAuthenticatedUserError = GithubOpError;
/** Set primary email visibility for the authenticated user Sets the visibility for your primary email addresses. */
export declare const setPrimaryEmailVisibilityForAuthenticatedUser: API.OperationMethod<SetPrimaryEmailVisibilityForAuthenticatedUserRequest, SetPrimaryEmailVisibilityForAuthenticatedUserResponse, SetPrimaryEmailVisibilityForAuthenticatedUserError, GithubOpContext>;
export type UnblockError = GithubOpError;
/** Unblock a user Unblocks the given user and returns a 204. */
export declare const unblock: API.OperationMethod<UnblockRequest, UnblockResponse, UnblockError, GithubOpContext>;
export type UnfollowError = GithubOpError;
/** Unfollow a user OAuth app tokens and personal access tokens (classic) need the `user:follow` scope to use this endpoint. */
export declare const unfollow: API.OperationMethod<UnfollowRequest, UnfollowResponse, UnfollowError, GithubOpContext>;
export type UpdateAuthenticatedError = GithubOpError;
/** Update the authenticated user **Note:** If your email is set to private and you send an `email` parameter as part of this request to update your profile, your privacy settings are still enforced: the email address will not be displayed on your public profile or via the API. */
export declare const updateAuthenticated: API.OperationMethod<UpdateAuthenticatedRequest, PrivateUser, UpdateAuthenticatedError, GithubOpContext>;
//# sourceMappingURL=users.d.ts.map