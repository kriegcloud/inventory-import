import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The rendering mode. */
export type RenderRequestMode = "markdown" | "gfm";
export interface RenderRequest {
    /** The Markdown text to render in HTML. */
    text: string;
    /** The rendering mode. */
    mode?: RenderRequestMode | (string & {}) | undefined;
    /** The repository context to use when creating references in `gfm` mode. For example, setting `context` to `octo-org/octo-repo` will change the text `#42` into an HTML link to issue 42 in the `octo-org/octo-repo` repository. */
    context?: string | undefined;
}
export interface RenderResponse {
}
export interface RenderRawRequest {
}
export interface RenderRawResponse {
}
export type RenderError = GithubOpError;
/** Render a Markdown document Depending on what is rendered in the Markdown, you may need to provide additional token scopes for labels, such as `issues:read` or `pull_requests:read`. */
export declare const render: API.OperationMethod<RenderRequest, RenderResponse, RenderError, GithubOpContext>;
export type RenderRawError = GithubOpError;
/** Render a Markdown document in raw mode You must send Markdown as plain text (using a `Content-Type` header of `text/plain` or `text/x-markdown`) to this endpoint, rather than using JSON format. In raw mode, [GitHub Flavored Markdown](https://github.github.com/gfm/) is not supported and Markdown will be rendered in plain format like a README.md file. Markdown content must be 400 KB or less. */
export declare const renderRaw: API.OperationMethod<RenderRawRequest, RenderRawResponse, RenderRawError, GithubOpContext>;
//# sourceMappingURL=markdown.d.ts.map