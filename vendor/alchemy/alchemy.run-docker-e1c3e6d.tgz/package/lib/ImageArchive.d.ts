/**
 * Image archives: a Docker build context built for one platform and saved
 * with `docker save`, for hosts with no registry between the deploy and the
 * machine that runs it (a VM that loads the archive into its own Docker).
 */
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import { Docker } from "./Docker.ts";
export interface ImageArchiveSource {
    /** The Docker build context directory. */
    context: string;
    /**
     * The Dockerfile, relative to the context unless absolute.
     * @default "Dockerfile"
     */
    dockerfile?: string;
    /** The platform the archive's image is built for, e.g. `linux/amd64`. */
    platform: string;
}
/**
 * A content hash of the inputs an archive is built from: the context's
 * files (after `.dockerignore`), the Dockerfile and the platform. It
 * changes exactly when the archive's image would.
 */
export declare const hashImageArchive: (source: ImageArchiveSource) => Effect.Effect<string, import("./BuildHash.ts").BuildHashInvalidProps | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
/**
 * Build `source` and save its image to an archive at `output`, tagged
 * `tag`, the name `docker load` reports where the archive is loaded.
 * Resolves to the archive's bytes.
 */
export declare const buildImageArchive: (source: ImageArchiveSource, options: {
    readonly tag: string;
    readonly output: string;
}) => Effect.Effect<Uint8Array<ArrayBufferLike>, import("./BuildHash.ts").BuildHashInvalidProps | import("./RegistryError.ts").DockerImagePublicationError, Docker | FileSystem.FileSystem | Path.Path>;
/**
 * Shell lines that load the archive at `archive` into Docker and set the
 * shell variable `IMAGE` to the image it holds.
 */
export declare const loadImageArchiveScript: (archive: string) => string;
//# sourceMappingURL=ImageArchive.d.ts.map