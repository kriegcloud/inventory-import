import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GatewayId = string;
export type LinkId = string;
export type ResponderErrorMaskingAction = "NO_BID" | "PASSTHROUGH" | (string & {});
export type ResponderErrorMaskingLoggingType = "NONE" | "METRIC" | "RESPONSE" | (string & {});
export type ResponderErrorMaskingLoggingTypes = ResponderErrorMaskingLoggingType[];
export interface ResponderErrorMaskingForHttpCode {
    httpCode: string;
    action: ResponderErrorMaskingAction;
    loggingTypes: ResponderErrorMaskingLoggingType[];
    responseLoggingPercentage?: number | undefined;
}
export type ResponderErrorMasking = ResponderErrorMaskingForHttpCode[];
export type CustomerProvidedId = string;
export interface LinkAttributes {
    responderErrorMasking?: ResponderErrorMaskingForHttpCode[] | undefined;
    customerProvidedId?: string | undefined;
}
export interface LinkApplicationLogSampling {
    errorLog: number;
    filterLog: number;
}
export interface LinkApplicationLogConfiguration {
    sampling: LinkApplicationLogSampling;
}
export interface LinkLogSettings {
    applicationLogs: LinkApplicationLogConfiguration;
}
export type LinkTimeoutInMillis = number;
export interface AcceptLinkRequest {
    gatewayId: string;
    linkId: string;
    attributes?: LinkAttributes | undefined;
    logSettings: LinkLogSettings;
    timeoutInMillis?: number | undefined;
}
export type LinkStatus = "PENDING_CREATION" | "PENDING_REQUEST" | "REQUESTED" | "ACCEPTED" | "ACTIVE" | "REJECTED" | "FAILED" | "PENDING_DELETION" | "DELETED" | "PENDING_UPDATE" | "PENDING_ISOLATION" | "ISOLATED" | "PENDING_RESTORATION" | (string & {});
export type LinkDirection = "RESPONSE" | "REQUEST" | (string & {});
export type Version = string;
export type FlowModuleName = string;
export type FlowModuleNameList = string[];
export interface NoBidModuleParameters {
    reason?: string | undefined;
    reasonCode?: number | undefined;
    passThroughPercentage?: number | undefined;
}
export type FilterType = "INCLUDE" | "EXCLUDE" | (string & {});
export type ValueList = string[];
export interface FilterCriterion {
    path: string;
    values: string[];
}
export type FilterCriteria = FilterCriterion[];
export interface Filter {
    criteria: FilterCriterion[];
}
export type FilterConfiguration = Filter[];
export interface NoBidAction {
    noBidReasonCode?: number | undefined;
}
export interface HeaderTagAction {
    name: string;
    value: string;
}
export type Action = {
    noBid: NoBidAction;
    headerTag?: undefined;
} | {
    noBid?: undefined;
    headerTag: HeaderTagAction;
};
export interface OpenRtbAttributeModuleParameters {
    filterType: FilterType;
    filterConfiguration: Filter[];
    action: Action;
    holdbackPercentage: number;
}
export interface RateLimiterModuleParameters {
    tps?: number | undefined;
}
export type ModuleParameters = {
    noBid: NoBidModuleParameters;
    openRtbAttribute?: undefined;
    rateLimiter?: undefined;
} | {
    noBid?: undefined;
    openRtbAttribute: OpenRtbAttributeModuleParameters;
    rateLimiter?: undefined;
} | {
    noBid?: undefined;
    openRtbAttribute?: undefined;
    rateLimiter: RateLimiterModuleParameters;
};
export interface ModuleConfiguration {
    version?: string | undefined;
    name: string;
    dependsOn?: string[] | undefined;
    moduleParameters?: ModuleParameters | undefined;
}
export type ModuleConfigurationList = ModuleConfiguration[];
export type ConnectivityType = "DEFAULT" | "PUBLIC_INGRESS" | "PUBLIC_EGRESS" | "EXTERNAL_INBOUND" | (string & {});
export interface AcceptLinkResponse {
    gatewayId: string;
    peerGatewayId: string;
    status: LinkStatus;
    createdAt: Date;
    updatedAt: Date;
    direction?: LinkDirection | undefined;
    flowModules?: ModuleConfiguration[] | undefined;
    pendingFlowModules?: ModuleConfiguration[] | undefined;
    attributes?: LinkAttributes | undefined;
    logSettings?: LinkLogSettings | undefined;
    connectivityType?: ConnectivityType | undefined;
    linkId: string;
}
export type AcmCertificateArn = string;
export interface AssociateCertificateRequest {
    gatewayId: string;
    acmCertificateArn: string;
    clientToken: string;
}
export type CertificateAssociationStatus = "PENDING_ASSOCIATION" | "ASSOCIATED" | "PENDING_DISASSOCIATION" | "DISASSOCIATED" | "FAILED" | (string & {});
export interface AssociateCertificateResponse {
    gatewayId: string;
    acmCertificateArn: string;
    status: CertificateAssociationStatus;
}
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateInboundExternalLinkRequest {
    clientToken: string;
    gatewayId: string;
    attributes?: LinkAttributes | undefined;
    logSettings: LinkLogSettings;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DomainName = string;
export interface CreateInboundExternalLinkResponse {
    gatewayId: string;
    linkId: string;
    status: LinkStatus;
    domainName: string;
}
export interface CreateLinkRequest {
    gatewayId: string;
    peerGatewayId: string;
    attributes?: LinkAttributes | undefined;
    httpResponderAllowed?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    logSettings: LinkLogSettings;
    timeoutInMillis?: number | undefined;
}
export interface CreateLinkResponse {
    gatewayId: string;
    peerGatewayId: string;
    status: LinkStatus;
    createdAt: Date;
    updatedAt: Date;
    direction?: LinkDirection | undefined;
    flowModules?: ModuleConfiguration[] | undefined;
    pendingFlowModules?: ModuleConfiguration[] | undefined;
    attributes?: LinkAttributes | undefined;
    logSettings?: LinkLogSettings | undefined;
    connectivityType?: ConnectivityType | undefined;
    linkId: string;
    customerProvidedId?: string | undefined;
}
export type RulePriority = number;
export interface QueryStringKeyValuePair {
    key: string;
    value: string;
}
export interface RuleCondition {
    hostHeader?: string | undefined;
    hostHeaderWildcard?: string | undefined;
    pathPrefix?: string | undefined;
    pathExact?: string | undefined;
    queryStringEquals?: QueryStringKeyValuePair | undefined;
    queryStringExists?: string | undefined;
}
export interface CreateLinkRoutingRuleRequest {
    clientToken: string;
    gatewayId: string;
    linkId: string;
    priority: number;
    conditions: RuleCondition;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RuleId = string;
export type RuleStatus = "CREATION_IN_PROGRESS" | "ACTIVE" | "UPDATE_IN_PROGRESS" | "DELETION_IN_PROGRESS" | "DELETED" | "FAILED" | (string & {});
export interface CreateLinkRoutingRuleResponse {
    ruleId: string;
    status: RuleStatus;
    createdAt: Date;
}
export type URL = string;
export interface CreateOutboundExternalLinkRequest {
    clientToken: string;
    gatewayId: string;
    attributes?: LinkAttributes | undefined;
    publicEndpoint: string;
    logSettings: LinkLogSettings;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateOutboundExternalLinkResponse {
    gatewayId: string;
    linkId: string;
    status: LinkStatus;
}
export type VpcId = string;
export type SubnetId = string;
export type SubnetIdList = string[];
export type SecurityGroupId = string;
export type SecurityGroupIdList = string[];
export interface CreateRequesterGatewayRequest {
    vpcId: string;
    subnetIds: string[];
    securityGroupIds: string[];
    clientToken: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RequesterGatewayStatus = "PENDING_CREATION" | "ACTIVE" | "PENDING_DELETION" | "DELETED" | "ERROR" | "PENDING_UPDATE" | "ISOLATED" | "PENDING_ISOLATION" | "PENDING_RESTORATION" | (string & {});
export interface CreateRequesterGatewayResponse {
    gatewayId: string;
    domainName: string;
    status: RequesterGatewayStatus;
}
export type Protocol = "HTTP" | "HTTPS" | (string & {});
export type ProtocolList = Protocol[];
export interface ListenerConfig {
    protocols: Protocol[];
}
export type Base64EncodedCertificateChain = string | redacted.Redacted<string>;
export type CertificateAuthorityCertificates = (string | redacted.Redacted<string>)[];
export interface TrustStoreConfiguration {
    certificateAuthorityCertificates: (string | redacted.Redacted<string>)[];
}
export type AutoScalingGroupName = string;
export type AutoScalingGroupNameList = string[];
export type StatusCodeMatcher = string;
export interface HealthCheckConfig {
    port: number;
    path: string;
    protocol?: Protocol | undefined;
    timeoutMs?: number | undefined;
    intervalSeconds?: number | undefined;
    statusCodeMatcher?: string | undefined;
    healthyThresholdCount?: number | undefined;
    unhealthyThresholdCount?: number | undefined;
}
export interface AutoScalingGroupsConfiguration {
    autoScalingGroupNames: string[];
    roleArn: string;
    healthCheckConfig?: HealthCheckConfig | undefined;
}
export type KubernetesEndpointsResourceName = string;
export type KubernetesNamespace = string;
export type URI = string;
export type KubernetesClusterName = string;
export interface EksEndpointsConfiguration {
    endpointsResourceName: string;
    endpointsResourceNamespace: string;
    clusterApiServerEndpointUri: string;
    clusterApiServerCaCertificateChain: string | redacted.Redacted<string>;
    clusterName: string;
    roleArn: string;
}
export type ManagedEndpointConfiguration = {
    autoScalingGroups: AutoScalingGroupsConfiguration;
    eksEndpoints?: undefined;
} | {
    autoScalingGroups?: undefined;
    eksEndpoints: EksEndpointsConfiguration;
};
export type GatewayType = "EXTERNAL" | "INTERNAL" | (string & {});
export type ClientRoutingPolicy = "AVAILABILITY_ZONE_AFFINITY" | "ANY_AVAILABILITY_ZONE" | (string & {});
export interface CreateResponderGatewayRequest {
    vpcId: string;
    subnetIds: string[];
    securityGroupIds: string[];
    domainName?: string | undefined;
    port: number;
    protocol: Protocol;
    listenerConfig?: ListenerConfig | undefined;
    trustStoreConfiguration?: TrustStoreConfiguration | undefined;
    managedEndpointConfiguration?: ManagedEndpointConfiguration | undefined;
    clientToken: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    gatewayType?: GatewayType | undefined;
    clientRoutingPolicy?: ClientRoutingPolicy | undefined;
}
export type ResponderGatewayStatus = "PENDING_CREATION" | "ACTIVE" | "PENDING_DELETION" | "DELETED" | "ERROR" | "PENDING_UPDATE" | "ISOLATED" | "PENDING_ISOLATION" | "PENDING_RESTORATION" | (string & {});
export interface CreateResponderGatewayResponse {
    gatewayId: string;
    status: ResponderGatewayStatus;
    listenerConfig?: ListenerConfig | undefined;
    externalInboundEndpoint?: string | undefined;
    clientRoutingPolicy?: ClientRoutingPolicy | undefined;
}
export interface DeleteInboundExternalLinkRequest {
    gatewayId: string;
    linkId: string;
}
export interface DeleteInboundExternalLinkResponse {
    linkId: string;
    status: LinkStatus;
}
export interface DeleteLinkRequest {
    gatewayId: string;
    linkId: string;
}
export interface DeleteLinkResponse {
    linkId: string;
    status: LinkStatus;
}
export interface DeleteLinkRoutingRuleRequest {
    gatewayId: string;
    linkId: string;
    ruleId: string;
}
export interface DeleteLinkRoutingRuleResponse {
    ruleId: string;
    status: RuleStatus;
}
export interface DeleteOutboundExternalLinkRequest {
    gatewayId: string;
    linkId: string;
}
export interface DeleteOutboundExternalLinkResponse {
    linkId: string;
    status: LinkStatus;
}
export interface DeleteRequesterGatewayRequest {
    gatewayId: string;
}
export interface DeleteRequesterGatewayResponse {
    gatewayId: string;
    status: RequesterGatewayStatus;
}
export interface DeleteResponderGatewayRequest {
    gatewayId: string;
}
export interface DeleteResponderGatewayResponse {
    gatewayId: string;
    status: ResponderGatewayStatus;
}
export interface DisassociateCertificateRequest {
    gatewayId: string;
    acmCertificateArn: string;
}
export interface DisassociateCertificateResponse {
    gatewayId: string;
    acmCertificateArn: string;
    status: CertificateAssociationStatus;
}
export interface GetCertificateAssociationRequest {
    gatewayId: string;
    acmCertificateArn: string;
}
export interface GetCertificateAssociationResponse {
    gatewayId: string;
    acmCertificateArn: string;
    status: CertificateAssociationStatus;
    associatedAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetInboundExternalLinkRequest {
    gatewayId: string;
    linkId: string;
}
export interface GetInboundExternalLinkResponse {
    gatewayId: string;
    linkId: string;
    status: LinkStatus;
    domainName: string;
    flowModules?: ModuleConfiguration[] | undefined;
    pendingFlowModules?: ModuleConfiguration[] | undefined;
    attributes?: LinkAttributes | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    logSettings?: LinkLogSettings | undefined;
    connectivityType?: ConnectivityType | undefined;
}
export interface GetLinkRequest {
    gatewayId: string;
    linkId: string;
}
export interface GetLinkResponse {
    gatewayId: string;
    peerGatewayId: string;
    status: LinkStatus;
    createdAt: Date;
    updatedAt: Date;
    direction?: LinkDirection | undefined;
    flowModules?: ModuleConfiguration[] | undefined;
    pendingFlowModules?: ModuleConfiguration[] | undefined;
    attributes?: LinkAttributes | undefined;
    logSettings?: LinkLogSettings | undefined;
    connectivityType?: ConnectivityType | undefined;
    linkId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    httpResponderAllowed?: boolean | undefined;
    timeoutInMillis?: number | undefined;
}
export interface GetLinkRoutingRuleRequest {
    gatewayId: string;
    linkId: string;
    ruleId: string;
}
export interface GetLinkRoutingRuleResponse {
    gatewayId: string;
    linkId: string;
    ruleId: string;
    priority: number;
    conditions: RuleCondition;
    status: RuleStatus;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetOutboundExternalLinkRequest {
    gatewayId: string;
    linkId: string;
}
export interface GetOutboundExternalLinkResponse {
    gatewayId: string;
    linkId: string;
    status: LinkStatus;
    publicEndpoint: string;
    flowModules?: ModuleConfiguration[] | undefined;
    pendingFlowModules?: ModuleConfiguration[] | undefined;
    attributes?: LinkAttributes | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    logSettings?: LinkLogSettings | undefined;
    connectivityType?: ConnectivityType | undefined;
}
export interface GetRequesterGatewayRequest {
    gatewayId: string;
}
export interface GetRequesterGatewayResponse {
    status: RequesterGatewayStatus;
    domainName: string;
    description?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds: string[];
    gatewayId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    activeLinksCount?: number | undefined;
    totalLinksCount?: number | undefined;
}
export interface GetResponderGatewayRequest {
    gatewayId: string;
}
export interface GetResponderGatewayResponse {
    vpcId: string;
    subnetIds: string[];
    securityGroupIds: string[];
    status: ResponderGatewayStatus;
    description?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    domainName?: string | undefined;
    port: number;
    protocol: Protocol;
    listenerConfig?: ListenerConfig | undefined;
    trustStoreConfiguration?: TrustStoreConfiguration | undefined;
    managedEndpointConfiguration?: ManagedEndpointConfiguration | undefined;
    gatewayId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    activeLinksCount?: number | undefined;
    totalLinksCount?: number | undefined;
    linksRequestedCount?: number | undefined;
    gatewayType?: GatewayType | undefined;
    externalInboundEndpoint?: string | undefined;
    clientRoutingPolicy?: ClientRoutingPolicy | undefined;
}
export interface ListCertificateAssociationsRequest {
    gatewayId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CertificateAssociationSummary {
    acmCertificateArn: string;
    status: CertificateAssociationStatus;
    associatedAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type CertificateAssociationSummaryList = CertificateAssociationSummary[];
export interface ListCertificateAssociationsResponse {
    certificateAssociations: CertificateAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListLinkRoutingRulesRequest {
    gatewayId: string;
    linkId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface LinkRoutingRuleSummary {
    ruleId: string;
    priority: number;
    conditions: RuleCondition;
    status: RuleStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type LinkRoutingRuleList = LinkRoutingRuleSummary[];
export interface ListLinkRoutingRulesResponse {
    rules?: LinkRoutingRuleSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListLinksRequest {
    gatewayId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListLinksResponseStructure {
    gatewayId: string;
    peerGatewayId: string;
    status: LinkStatus;
    createdAt: Date;
    updatedAt: Date;
    direction?: LinkDirection | undefined;
    flowModules?: ModuleConfiguration[] | undefined;
    pendingFlowModules?: ModuleConfiguration[] | undefined;
    attributes?: LinkAttributes | undefined;
    logSettings?: LinkLogSettings | undefined;
    connectivityType?: ConnectivityType | undefined;
    linkId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    publicEndpoint?: string | undefined;
}
export type LinkList = ListLinksResponseStructure[];
export interface ListLinksResponse {
    links?: ListLinksResponseStructure[] | undefined;
    nextToken?: string | undefined;
}
export interface ListRequesterGatewaysRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type GatewayIdList = string[];
export interface ListRequesterGatewaysResponse {
    gatewayIds?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListResponderGatewaysRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListResponderGatewaysResponse {
    gatewayIds?: string[] | undefined;
    nextToken?: string | undefined;
}
export type RtbTaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RejectLinkRequest {
    gatewayId: string;
    linkId: string;
}
export interface RejectLinkResponse {
    gatewayId: string;
    peerGatewayId: string;
    status: LinkStatus;
    createdAt: Date;
    updatedAt: Date;
    direction?: LinkDirection | undefined;
    flowModules?: ModuleConfiguration[] | undefined;
    pendingFlowModules?: ModuleConfiguration[] | undefined;
    attributes?: LinkAttributes | undefined;
    logSettings?: LinkLogSettings | undefined;
    connectivityType?: ConnectivityType | undefined;
    linkId: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateLinkRequest {
    gatewayId: string;
    linkId: string;
    logSettings?: LinkLogSettings | undefined;
    timeoutInMillis?: number | undefined;
}
export interface UpdateLinkResponse {
    linkId: string;
    status: LinkStatus;
}
export interface UpdateLinkModuleFlowRequest {
    clientToken: string;
    gatewayId: string;
    linkId: string;
    modules: ModuleConfiguration[];
}
export interface UpdateLinkModuleFlowResponse {
    gatewayId: string;
    linkId: string;
    status: LinkStatus;
}
export interface UpdateLinkRoutingRuleRequest {
    gatewayId: string;
    linkId: string;
    ruleId: string;
    priority: number;
    conditions: RuleCondition;
}
export interface UpdateLinkRoutingRuleResponse {
    ruleId: string;
    status: RuleStatus;
    updatedAt: Date;
}
export interface UpdateRequesterGatewayRequest {
    clientToken: string;
    gatewayId: string;
    description?: string | undefined;
}
export interface UpdateRequesterGatewayResponse {
    gatewayId: string;
    status: RequesterGatewayStatus;
}
export interface UpdateResponderGatewayRequest {
    domainName?: string | undefined;
    port: number;
    protocol: Protocol;
    listenerConfig?: ListenerConfig | undefined;
    trustStoreConfiguration?: TrustStoreConfiguration | undefined;
    managedEndpointConfiguration?: ManagedEndpointConfiguration | undefined;
    clientToken: string;
    gatewayId: string;
    description?: string | undefined;
    clientRoutingPolicy?: ClientRoutingPolicy | undefined;
}
export interface UpdateResponderGatewayResponse {
    gatewayId: string;
    status: ResponderGatewayStatus;
    clientRoutingPolicy?: ClientRoutingPolicy | undefined;
}
export type AcceptLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Accepts a link request between gateways.
 *
 * When a requester gateway requests to link with a responder gateway, the responder can use this operation to accept the link request and establish the connection.
 */
export declare const acceptLink: API.OperationMethod<AcceptLinkRequest & RegionInput, AcceptLinkResponse, AcceptLinkError, Credentials | HttpClient.HttpClient>;
export type AssociateCertificateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an ACM certificate with a responder gateway.
 */
export declare const associateCertificate: API.OperationMethod<AssociateCertificateRequest & RegionInput, AssociateCertificateResponse, AssociateCertificateError, Credentials | HttpClient.HttpClient>;
export type CreateInboundExternalLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an inbound external link.
 */
export declare const createInboundExternalLink: API.OperationMethod<CreateInboundExternalLinkRequest & RegionInput, CreateInboundExternalLinkResponse, CreateInboundExternalLinkError, Credentials | HttpClient.HttpClient>;
export type CreateLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new link between gateways.
 *
 * Establishes a connection that allows gateways to communicate and exchange bid requests and responses.
 */
export declare const createLink: API.OperationMethod<CreateLinkRequest & RegionInput, CreateLinkResponse, CreateLinkError, Credentials | HttpClient.HttpClient>;
export type CreateLinkRoutingRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a routing rule for a link.
 *
 * Routing rules use priority-based evaluation where lower priority numbers are evaluated first. Each rule specifies conditions that must all match for the rule to apply.
 */
export declare const createLinkRoutingRule: API.OperationMethod<CreateLinkRoutingRuleRequest & RegionInput, CreateLinkRoutingRuleResponse, CreateLinkRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type CreateOutboundExternalLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an outbound external link.
 */
export declare const createOutboundExternalLink: API.OperationMethod<CreateOutboundExternalLinkRequest & RegionInput, CreateOutboundExternalLinkResponse, CreateOutboundExternalLinkError, Credentials | HttpClient.HttpClient>;
export type CreateRequesterGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a requester gateway.
 */
export declare const createRequesterGateway: API.OperationMethod<CreateRequesterGatewayRequest & RegionInput, CreateRequesterGatewayResponse, CreateRequesterGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateResponderGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a responder gateway.
 *
 * A domain name or managed endpoint is required.
 */
export declare const createResponderGateway: API.OperationMethod<CreateResponderGatewayRequest & RegionInput, CreateResponderGatewayResponse, CreateResponderGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteInboundExternalLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an inbound external link.
 */
export declare const deleteInboundExternalLink: API.OperationMethod<DeleteInboundExternalLinkRequest & RegionInput, DeleteInboundExternalLinkResponse, DeleteInboundExternalLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a link between gateways.
 *
 * Permanently removes the connection between gateways. This action cannot be undone.
 */
export declare const deleteLink: API.OperationMethod<DeleteLinkRequest & RegionInput, DeleteLinkResponse, DeleteLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteLinkRoutingRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a routing rule from a link.
 */
export declare const deleteLinkRoutingRule: API.OperationMethod<DeleteLinkRoutingRuleRequest & RegionInput, DeleteLinkRoutingRuleResponse, DeleteLinkRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteOutboundExternalLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an outbound external link.
 */
export declare const deleteOutboundExternalLink: API.OperationMethod<DeleteOutboundExternalLinkRequest & RegionInput, DeleteOutboundExternalLinkResponse, DeleteOutboundExternalLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteRequesterGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a requester gateway.
 */
export declare const deleteRequesterGateway: API.OperationMethod<DeleteRequesterGatewayRequest & RegionInput, DeleteRequesterGatewayResponse, DeleteRequesterGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteResponderGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a responder gateway.
 */
export declare const deleteResponderGateway: API.OperationMethod<DeleteResponderGatewayRequest & RegionInput, DeleteResponderGatewayResponse, DeleteResponderGatewayError, Credentials | HttpClient.HttpClient>;
export type DisassociateCertificateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a certificate association from a responder gateway.
 */
export declare const disassociateCertificate: API.OperationMethod<DisassociateCertificateRequest & RegionInput, DisassociateCertificateResponse, DisassociateCertificateError, Credentials | HttpClient.HttpClient>;
export type GetCertificateAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a certificate association with a responder gateway.
 */
export declare const getCertificateAssociation: API.OperationMethod<GetCertificateAssociationRequest & RegionInput, GetCertificateAssociationResponse, GetCertificateAssociationError, Credentials | HttpClient.HttpClient>;
export type GetInboundExternalLinkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an inbound external link.
 */
export declare const getInboundExternalLink: API.OperationMethod<GetInboundExternalLinkRequest & RegionInput, GetInboundExternalLinkResponse, GetInboundExternalLinkError, Credentials | HttpClient.HttpClient>;
export type GetLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a link between gateways.
 *
 * Returns detailed information about the link configuration, status, and associated gateways.
 */
export declare const getLink: API.OperationMethod<GetLinkRequest & RegionInput, GetLinkResponse, GetLinkError, Credentials | HttpClient.HttpClient>;
export type GetLinkRoutingRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a routing rule for a link.
 */
export declare const getLinkRoutingRule: API.OperationMethod<GetLinkRoutingRuleRequest & RegionInput, GetLinkRoutingRuleResponse, GetLinkRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type GetOutboundExternalLinkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an outbound external link.
 */
export declare const getOutboundExternalLink: API.OperationMethod<GetOutboundExternalLinkRequest & RegionInput, GetOutboundExternalLinkResponse, GetOutboundExternalLinkError, Credentials | HttpClient.HttpClient>;
export type GetRequesterGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a requester gateway.
 */
export declare const getRequesterGateway: API.OperationMethod<GetRequesterGatewayRequest & RegionInput, GetRequesterGatewayResponse, GetRequesterGatewayError, Credentials | HttpClient.HttpClient>;
export type GetResponderGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a responder gateway.
 */
export declare const getResponderGateway: API.OperationMethod<GetResponderGatewayRequest & RegionInput, GetResponderGatewayResponse, GetResponderGatewayError, Credentials | HttpClient.HttpClient>;
export type ListCertificateAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the certificate associations for a responder gateway.
 */
export declare const listCertificateAssociations: API.PaginatedOperationMethod<ListCertificateAssociationsRequest & RegionInput, ListCertificateAssociationsResponse, ListCertificateAssociationsError, Credentials | HttpClient.HttpClient, CertificateAssociationSummary>;
export type ListLinkRoutingRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the routing rules for a link.
 */
export declare const listLinkRoutingRules: API.PaginatedOperationMethod<ListLinkRoutingRulesRequest & RegionInput, ListLinkRoutingRulesResponse, ListLinkRoutingRulesError, Credentials | HttpClient.HttpClient, LinkRoutingRuleSummary>;
export type ListLinksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists links associated with gateways.
 *
 * Returns a list of all links for the specified gateways, including their status and configuration details.
 */
export declare const listLinks: API.PaginatedOperationMethod<ListLinksRequest & RegionInput, ListLinksResponse, ListLinksError, Credentials | HttpClient.HttpClient, ListLinksResponseStructure>;
export type ListRequesterGatewaysError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists requester gateways.
 */
export declare const listRequesterGateways: API.PaginatedOperationMethod<ListRequesterGatewaysRequest & RegionInput, ListRequesterGatewaysResponse, ListRequesterGatewaysError, Credentials | HttpClient.HttpClient, GatewayId>;
export type ListResponderGatewaysError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists reponder gateways.
 */
export declare const listResponderGateways: API.PaginatedOperationMethod<ListResponderGatewaysRequest & RegionInput, ListResponderGatewaysResponse, ListResponderGatewaysError, Credentials | HttpClient.HttpClient, GatewayId>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RejectLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rejects a link request between gateways.
 *
 * When a requester gateway requests to link with a responder gateway, the responder can use this operation to decline the link request.
 */
export declare const rejectLink: API.OperationMethod<RejectLinkRequest & RegionInput, RejectLinkResponse, RejectLinkError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag or tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a link between gateways.
 *
 * Allows you to modify settings and parameters for an existing link.
 */
export declare const updateLink: API.OperationMethod<UpdateLinkRequest & RegionInput, UpdateLinkResponse, UpdateLinkError, Credentials | HttpClient.HttpClient>;
export type UpdateLinkModuleFlowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a link module flow.
 */
export declare const updateLinkModuleFlow: API.OperationMethod<UpdateLinkModuleFlowRequest & RegionInput, UpdateLinkModuleFlowResponse, UpdateLinkModuleFlowError, Credentials | HttpClient.HttpClient>;
export type UpdateLinkRoutingRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a routing rule for a link.
 */
export declare const updateLinkRoutingRule: API.OperationMethod<UpdateLinkRoutingRuleRequest & RegionInput, UpdateLinkRoutingRuleResponse, UpdateLinkRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateRequesterGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a requester gateway.
 */
export declare const updateRequesterGateway: API.OperationMethod<UpdateRequesterGatewayRequest & RegionInput, UpdateRequesterGatewayResponse, UpdateRequesterGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateResponderGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the description, Auto Scaling group managed endpoint configuration, trust store configuration, and client routing policy of a responder gateway. This operation also updates the `protocols` list in the listener configuration.
 *
 * You cannot change the `domainName`, `port`, and `protocol` values that you set when you create a responder gateway. To change any of them, delete the gateway and create a new one.
 */
export declare const updateResponderGateway: API.OperationMethod<UpdateResponderGatewayRequest & RegionInput, UpdateResponderGatewayResponse, UpdateResponderGatewayError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=rtbfabric.d.ts.map