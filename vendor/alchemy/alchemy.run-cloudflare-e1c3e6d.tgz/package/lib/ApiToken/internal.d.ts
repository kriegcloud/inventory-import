import * as Redacted from "effect/Redacted";
export declare const uniqueTokens: <T extends {
    id?: string | null;
}>(tokens: ReadonlyArray<T>) => T[];
/**
 * A created token's value as `Redacted`. Distilled marks it sensitive, so
 * newer versions already return it `Redacted`; older ones return a string.
 */
export declare const redactTokenValue: (value: string | Redacted.Redacted<string>) => Redacted.Redacted<string>;
//# sourceMappingURL=internal.d.ts.map