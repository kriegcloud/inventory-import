import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const DefaultUndefinedFault_base: S.TaggedErrorClass<"DefaultUndefinedFault", {
    readonly message: any;
}>;
export declare class DefaultUndefinedFault extends /*@__PURE__*/ DefaultUndefinedFault_base {
}
declare const DomainAlreadyExistsFault_base: S.TaggedErrorClass<"DomainAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DomainAlreadyExistsFault extends /*@__PURE__*/ DomainAlreadyExistsFault_base {
}
declare const DomainDeprecatedFault_base: S.TaggedErrorClass<"DomainDeprecatedFault", {
    readonly message: any;
}>;
export declare class DomainDeprecatedFault extends /*@__PURE__*/ DomainDeprecatedFault_base {
}
declare const LimitExceededFault_base: S.TaggedErrorClass<"LimitExceededFault", {
    readonly message: any;
}>;
export declare class LimitExceededFault extends /*@__PURE__*/ LimitExceededFault_base {
}
declare const OperationNotPermittedFault_base: S.TaggedErrorClass<"OperationNotPermittedFault", {
    readonly message: any;
}>;
export declare class OperationNotPermittedFault extends /*@__PURE__*/ OperationNotPermittedFault_base {
}
declare const TooManyTagsFault_base: S.TaggedErrorClass<"TooManyTagsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsFault extends /*@__PURE__*/ TooManyTagsFault_base {
}
declare const TypeAlreadyExistsFault_base: S.TaggedErrorClass<"TypeAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TypeAlreadyExistsFault extends /*@__PURE__*/ TypeAlreadyExistsFault_base {
}
declare const TypeDeprecatedFault_base: S.TaggedErrorClass<"TypeDeprecatedFault", {
    readonly message: any;
}>;
export declare class TypeDeprecatedFault extends /*@__PURE__*/ TypeDeprecatedFault_base {
}
declare const TypeNotDeprecatedFault_base: S.TaggedErrorClass<"TypeNotDeprecatedFault", {
    readonly message: any;
}>;
export declare class TypeNotDeprecatedFault extends /*@__PURE__*/ TypeNotDeprecatedFault_base {
}
declare const UnknownResourceFault_base: S.TaggedErrorClass<"UnknownResourceFault", {
    readonly message: any;
}>;
export declare class UnknownResourceFault extends /*@__PURE__*/ UnknownResourceFault_base {
}
declare const WorkflowExecutionAlreadyStartedFault_base: S.TaggedErrorClass<"WorkflowExecutionAlreadyStartedFault", {
    readonly message: any;
}>;
export declare class WorkflowExecutionAlreadyStartedFault extends /*@__PURE__*/ WorkflowExecutionAlreadyStartedFault_base {
}
export type DomainName = string;
export interface ExecutionTimeFilter {
    oldestDate: Date;
    latestDate?: Date | undefined;
}
export type WorkflowId = string;
export interface WorkflowExecutionFilter {
    workflowId: string;
}
export type Name = string;
export type VersionOptional = string;
export interface WorkflowTypeFilter {
    name: string;
    version?: string | undefined;
}
export type Tag = string;
export interface TagFilter {
    tag: string;
}
export type CloseStatus = "COMPLETED" | "FAILED" | "CANCELED" | "TERMINATED" | "CONTINUED_AS_NEW" | "TIMED_OUT" | (string & {});
export interface CloseStatusFilter {
    status: CloseStatus;
}
export interface CountClosedWorkflowExecutionsInput {
    domain: string;
    startTimeFilter?: ExecutionTimeFilter | undefined;
    closeTimeFilter?: ExecutionTimeFilter | undefined;
    executionFilter?: WorkflowExecutionFilter | undefined;
    typeFilter?: WorkflowTypeFilter | undefined;
    tagFilter?: TagFilter | undefined;
    closeStatusFilter?: CloseStatusFilter | undefined;
}
export type Count = number;
export type Truncated = boolean;
export interface WorkflowExecutionCount {
    count: number;
    truncated?: boolean | undefined;
}
export interface CountOpenWorkflowExecutionsInput {
    domain: string;
    startTimeFilter: ExecutionTimeFilter;
    typeFilter?: WorkflowTypeFilter | undefined;
    tagFilter?: TagFilter | undefined;
    executionFilter?: WorkflowExecutionFilter | undefined;
}
export interface TaskList {
    name: string;
}
export interface CountPendingActivityTasksInput {
    domain: string;
    taskList: TaskList;
}
export interface PendingTaskCount {
    count: number;
    truncated?: boolean | undefined;
}
export interface CountPendingDecisionTasksInput {
    domain: string;
    taskList: TaskList;
}
export type Version = string;
export interface ActivityType {
    name: string;
    version: string;
}
export interface DeleteActivityTypeInput {
    domain: string;
    activityType: ActivityType;
}
export interface DeleteActivityTypeResponse {
}
export interface WorkflowType {
    name: string;
    version: string;
}
export interface DeleteWorkflowTypeInput {
    domain: string;
    workflowType: WorkflowType;
}
export interface DeleteWorkflowTypeResponse {
}
export interface DeprecateActivityTypeInput {
    domain: string;
    activityType: ActivityType;
}
export interface DeprecateActivityTypeResponse {
}
export interface DeprecateDomainInput {
    name: string;
}
export interface DeprecateDomainResponse {
}
export interface DeprecateWorkflowTypeInput {
    domain: string;
    workflowType: WorkflowType;
}
export interface DeprecateWorkflowTypeResponse {
}
export interface DescribeActivityTypeInput {
    domain: string;
    activityType: ActivityType;
}
export type RegistrationStatus = "REGISTERED" | "DEPRECATED" | (string & {});
export type Description = string;
export interface ActivityTypeInfo {
    activityType: ActivityType;
    status: RegistrationStatus;
    description?: string | undefined;
    creationDate: Date;
    deprecationDate?: Date | undefined;
}
export type DurationInSecondsOptional = string;
export type TaskPriority = string;
export interface ActivityTypeConfiguration {
    defaultTaskStartToCloseTimeout?: string | undefined;
    defaultTaskHeartbeatTimeout?: string | undefined;
    defaultTaskList?: TaskList | undefined;
    defaultTaskPriority?: string | undefined;
    defaultTaskScheduleToStartTimeout?: string | undefined;
    defaultTaskScheduleToCloseTimeout?: string | undefined;
}
export interface ActivityTypeDetail {
    typeInfo: ActivityTypeInfo;
    configuration: ActivityTypeConfiguration;
}
export interface DescribeDomainInput {
    name: string;
}
export type Arn = string;
export interface DomainInfo {
    name: string;
    status: RegistrationStatus;
    description?: string | undefined;
    arn?: string | undefined;
}
export type DurationInDays = string;
export interface DomainConfiguration {
    workflowExecutionRetentionPeriodInDays: string;
}
export interface DomainDetail {
    domainInfo: DomainInfo;
    configuration: DomainConfiguration;
}
export type WorkflowRunId = string;
export interface WorkflowExecution {
    workflowId: string;
    runId: string;
}
export interface DescribeWorkflowExecutionInput {
    domain: string;
    execution: WorkflowExecution;
}
export type ExecutionStatus = "OPEN" | "CLOSED" | (string & {});
export type TagList = string[];
export type Canceled = boolean;
export interface WorkflowExecutionInfo {
    execution: WorkflowExecution;
    workflowType: WorkflowType;
    startTimestamp: Date;
    closeTimestamp?: Date | undefined;
    executionStatus: ExecutionStatus;
    closeStatus?: CloseStatus | undefined;
    parent?: WorkflowExecution | undefined;
    tagList?: string[] | undefined;
    cancelRequested?: boolean | undefined;
}
export type DurationInSeconds = string;
export type ChildPolicy = "TERMINATE" | "REQUEST_CANCEL" | "ABANDON" | (string & {});
export interface WorkflowExecutionConfiguration {
    taskStartToCloseTimeout: string;
    executionStartToCloseTimeout: string;
    taskList: TaskList;
    taskPriority?: string | undefined;
    childPolicy: ChildPolicy;
    lambdaRole?: string | undefined;
}
export type OpenDecisionTasksCount = number;
export interface WorkflowExecutionOpenCounts {
    openActivityTasks: number;
    openDecisionTasks: number;
    openTimers: number;
    openChildWorkflowExecutions: number;
    openLambdaFunctions?: number | undefined;
}
export type Data = string;
export interface WorkflowExecutionDetail {
    executionInfo: WorkflowExecutionInfo;
    executionConfiguration: WorkflowExecutionConfiguration;
    openCounts: WorkflowExecutionOpenCounts;
    latestActivityTaskTimestamp?: Date | undefined;
    latestExecutionContext?: string | undefined;
}
export interface DescribeWorkflowTypeInput {
    domain: string;
    workflowType: WorkflowType;
}
export interface WorkflowTypeInfo {
    workflowType: WorkflowType;
    status: RegistrationStatus;
    description?: string | undefined;
    creationDate: Date;
    deprecationDate?: Date | undefined;
}
export interface WorkflowTypeConfiguration {
    defaultTaskStartToCloseTimeout?: string | undefined;
    defaultExecutionStartToCloseTimeout?: string | undefined;
    defaultTaskList?: TaskList | undefined;
    defaultTaskPriority?: string | undefined;
    defaultChildPolicy?: ChildPolicy | undefined;
    defaultLambdaRole?: string | undefined;
}
export interface WorkflowTypeDetail {
    typeInfo: WorkflowTypeInfo;
    configuration: WorkflowTypeConfiguration;
}
export type PageToken = string;
export type PageSize = number;
export type ReverseOrder = boolean;
export interface GetWorkflowExecutionHistoryInput {
    domain: string;
    execution: WorkflowExecution;
    nextPageToken?: string | undefined;
    maximumPageSize?: number | undefined;
    reverseOrder?: boolean | undefined;
}
export type EventType = "WorkflowExecutionStarted" | "WorkflowExecutionCancelRequested" | "WorkflowExecutionCompleted" | "CompleteWorkflowExecutionFailed" | "WorkflowExecutionFailed" | "FailWorkflowExecutionFailed" | "WorkflowExecutionTimedOut" | "WorkflowExecutionCanceled" | "CancelWorkflowExecutionFailed" | "WorkflowExecutionContinuedAsNew" | "ContinueAsNewWorkflowExecutionFailed" | "WorkflowExecutionTerminated" | "DecisionTaskScheduled" | "DecisionTaskStarted" | "DecisionTaskCompleted" | "DecisionTaskTimedOut" | "ActivityTaskScheduled" | "ScheduleActivityTaskFailed" | "ActivityTaskStarted" | "ActivityTaskCompleted" | "ActivityTaskFailed" | "ActivityTaskTimedOut" | "ActivityTaskCanceled" | "ActivityTaskCancelRequested" | "RequestCancelActivityTaskFailed" | "WorkflowExecutionSignaled" | "MarkerRecorded" | "RecordMarkerFailed" | "TimerStarted" | "StartTimerFailed" | "TimerFired" | "TimerCanceled" | "CancelTimerFailed" | "StartChildWorkflowExecutionInitiated" | "StartChildWorkflowExecutionFailed" | "ChildWorkflowExecutionStarted" | "ChildWorkflowExecutionCompleted" | "ChildWorkflowExecutionFailed" | "ChildWorkflowExecutionTimedOut" | "ChildWorkflowExecutionCanceled" | "ChildWorkflowExecutionTerminated" | "SignalExternalWorkflowExecutionInitiated" | "SignalExternalWorkflowExecutionFailed" | "ExternalWorkflowExecutionSignaled" | "RequestCancelExternalWorkflowExecutionInitiated" | "RequestCancelExternalWorkflowExecutionFailed" | "ExternalWorkflowExecutionCancelRequested" | "LambdaFunctionScheduled" | "LambdaFunctionStarted" | "LambdaFunctionCompleted" | "LambdaFunctionFailed" | "LambdaFunctionTimedOut" | "ScheduleLambdaFunctionFailed" | "StartLambdaFunctionFailed" | (string & {});
export type EventId = number;
export type WorkflowRunIdOptional = string;
export interface WorkflowExecutionStartedEventAttributes {
    input?: string | undefined;
    executionStartToCloseTimeout?: string | undefined;
    taskStartToCloseTimeout?: string | undefined;
    childPolicy: ChildPolicy;
    taskList: TaskList;
    taskPriority?: string | undefined;
    workflowType: WorkflowType;
    tagList?: string[] | undefined;
    continuedExecutionRunId?: string | undefined;
    parentWorkflowExecution?: WorkflowExecution | undefined;
    parentInitiatedEventId?: number | undefined;
    lambdaRole?: string | undefined;
}
export interface WorkflowExecutionCompletedEventAttributes {
    result?: string | undefined;
    decisionTaskCompletedEventId: number;
}
export type CompleteWorkflowExecutionFailedCause = "UNHANDLED_DECISION" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface CompleteWorkflowExecutionFailedEventAttributes {
    cause: CompleteWorkflowExecutionFailedCause;
    decisionTaskCompletedEventId: number;
}
export type FailureReason = string;
export interface WorkflowExecutionFailedEventAttributes {
    reason?: string | undefined;
    details?: string | undefined;
    decisionTaskCompletedEventId: number;
}
export type FailWorkflowExecutionFailedCause = "UNHANDLED_DECISION" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface FailWorkflowExecutionFailedEventAttributes {
    cause: FailWorkflowExecutionFailedCause;
    decisionTaskCompletedEventId: number;
}
export type WorkflowExecutionTimeoutType = "START_TO_CLOSE" | (string & {});
export interface WorkflowExecutionTimedOutEventAttributes {
    timeoutType: WorkflowExecutionTimeoutType;
    childPolicy: ChildPolicy;
}
export interface WorkflowExecutionCanceledEventAttributes {
    details?: string | undefined;
    decisionTaskCompletedEventId: number;
}
export type CancelWorkflowExecutionFailedCause = "UNHANDLED_DECISION" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface CancelWorkflowExecutionFailedEventAttributes {
    cause: CancelWorkflowExecutionFailedCause;
    decisionTaskCompletedEventId: number;
}
export interface WorkflowExecutionContinuedAsNewEventAttributes {
    input?: string | undefined;
    decisionTaskCompletedEventId: number;
    newExecutionRunId: string;
    executionStartToCloseTimeout?: string | undefined;
    taskList: TaskList;
    taskPriority?: string | undefined;
    taskStartToCloseTimeout?: string | undefined;
    childPolicy: ChildPolicy;
    tagList?: string[] | undefined;
    workflowType: WorkflowType;
    lambdaRole?: string | undefined;
}
export type ContinueAsNewWorkflowExecutionFailedCause = "UNHANDLED_DECISION" | "WORKFLOW_TYPE_DEPRECATED" | "WORKFLOW_TYPE_DOES_NOT_EXIST" | "DEFAULT_EXECUTION_START_TO_CLOSE_TIMEOUT_UNDEFINED" | "DEFAULT_TASK_START_TO_CLOSE_TIMEOUT_UNDEFINED" | "DEFAULT_TASK_LIST_UNDEFINED" | "DEFAULT_CHILD_POLICY_UNDEFINED" | "CONTINUE_AS_NEW_WORKFLOW_EXECUTION_RATE_EXCEEDED" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface ContinueAsNewWorkflowExecutionFailedEventAttributes {
    cause: ContinueAsNewWorkflowExecutionFailedCause;
    decisionTaskCompletedEventId: number;
}
export type TerminateReason = string;
export type WorkflowExecutionTerminatedCause = "CHILD_POLICY_APPLIED" | "EVENT_LIMIT_EXCEEDED" | "OPERATOR_INITIATED" | (string & {});
export interface WorkflowExecutionTerminatedEventAttributes {
    reason?: string | undefined;
    details?: string | undefined;
    childPolicy: ChildPolicy;
    cause?: WorkflowExecutionTerminatedCause | undefined;
}
export type WorkflowExecutionCancelRequestedCause = "CHILD_POLICY_APPLIED" | (string & {});
export interface WorkflowExecutionCancelRequestedEventAttributes {
    externalWorkflowExecution?: WorkflowExecution | undefined;
    externalInitiatedEventId?: number | undefined;
    cause?: WorkflowExecutionCancelRequestedCause | undefined;
}
export interface DecisionTaskScheduledEventAttributes {
    taskList: TaskList;
    taskPriority?: string | undefined;
    startToCloseTimeout?: string | undefined;
    scheduleToStartTimeout?: string | undefined;
}
export type Identity = string;
export interface DecisionTaskStartedEventAttributes {
    identity?: string | undefined;
    scheduledEventId: number;
}
export interface DecisionTaskCompletedEventAttributes {
    executionContext?: string | undefined;
    scheduledEventId: number;
    startedEventId: number;
    taskList?: TaskList | undefined;
    taskListScheduleToStartTimeout?: string | undefined;
}
export type DecisionTaskTimeoutType = "START_TO_CLOSE" | "SCHEDULE_TO_START" | (string & {});
export interface DecisionTaskTimedOutEventAttributes {
    timeoutType: DecisionTaskTimeoutType;
    scheduledEventId: number;
    startedEventId: number;
}
export type ActivityId = string;
export interface ActivityTaskScheduledEventAttributes {
    activityType: ActivityType;
    activityId: string;
    input?: string | undefined;
    control?: string | undefined;
    scheduleToStartTimeout?: string | undefined;
    scheduleToCloseTimeout?: string | undefined;
    startToCloseTimeout?: string | undefined;
    taskList: TaskList;
    taskPriority?: string | undefined;
    decisionTaskCompletedEventId: number;
    heartbeatTimeout?: string | undefined;
}
export interface ActivityTaskStartedEventAttributes {
    identity?: string | undefined;
    scheduledEventId: number;
}
export interface ActivityTaskCompletedEventAttributes {
    result?: string | undefined;
    scheduledEventId: number;
    startedEventId: number;
}
export interface ActivityTaskFailedEventAttributes {
    reason?: string | undefined;
    details?: string | undefined;
    scheduledEventId: number;
    startedEventId: number;
}
export type ActivityTaskTimeoutType = "START_TO_CLOSE" | "SCHEDULE_TO_START" | "SCHEDULE_TO_CLOSE" | "HEARTBEAT" | (string & {});
export type LimitedData = string;
export interface ActivityTaskTimedOutEventAttributes {
    timeoutType: ActivityTaskTimeoutType;
    scheduledEventId: number;
    startedEventId: number;
    details?: string | undefined;
}
export interface ActivityTaskCanceledEventAttributes {
    details?: string | undefined;
    scheduledEventId: number;
    startedEventId: number;
    latestCancelRequestedEventId?: number | undefined;
}
export interface ActivityTaskCancelRequestedEventAttributes {
    decisionTaskCompletedEventId: number;
    activityId: string;
}
export type SignalName = string;
export interface WorkflowExecutionSignaledEventAttributes {
    signalName: string;
    input?: string | undefined;
    externalWorkflowExecution?: WorkflowExecution | undefined;
    externalInitiatedEventId?: number | undefined;
}
export type MarkerName = string;
export interface MarkerRecordedEventAttributes {
    markerName: string;
    details?: string | undefined;
    decisionTaskCompletedEventId: number;
}
export type RecordMarkerFailedCause = "OPERATION_NOT_PERMITTED" | (string & {});
export interface RecordMarkerFailedEventAttributes {
    markerName: string;
    cause: RecordMarkerFailedCause;
    decisionTaskCompletedEventId: number;
}
export type TimerId = string;
export interface TimerStartedEventAttributes {
    timerId: string;
    control?: string | undefined;
    startToFireTimeout: string;
    decisionTaskCompletedEventId: number;
}
export interface TimerFiredEventAttributes {
    timerId: string;
    startedEventId: number;
}
export interface TimerCanceledEventAttributes {
    timerId: string;
    startedEventId: number;
    decisionTaskCompletedEventId: number;
}
export interface StartChildWorkflowExecutionInitiatedEventAttributes {
    workflowId: string;
    workflowType: WorkflowType;
    control?: string | undefined;
    input?: string | undefined;
    executionStartToCloseTimeout?: string | undefined;
    taskList: TaskList;
    taskPriority?: string | undefined;
    decisionTaskCompletedEventId: number;
    childPolicy: ChildPolicy;
    taskStartToCloseTimeout?: string | undefined;
    tagList?: string[] | undefined;
    lambdaRole?: string | undefined;
}
export interface ChildWorkflowExecutionStartedEventAttributes {
    workflowExecution: WorkflowExecution;
    workflowType: WorkflowType;
    initiatedEventId: number;
}
export interface ChildWorkflowExecutionCompletedEventAttributes {
    workflowExecution: WorkflowExecution;
    workflowType: WorkflowType;
    result?: string | undefined;
    initiatedEventId: number;
    startedEventId: number;
}
export interface ChildWorkflowExecutionFailedEventAttributes {
    workflowExecution: WorkflowExecution;
    workflowType: WorkflowType;
    reason?: string | undefined;
    details?: string | undefined;
    initiatedEventId: number;
    startedEventId: number;
}
export interface ChildWorkflowExecutionTimedOutEventAttributes {
    workflowExecution: WorkflowExecution;
    workflowType: WorkflowType;
    timeoutType: WorkflowExecutionTimeoutType;
    initiatedEventId: number;
    startedEventId: number;
}
export interface ChildWorkflowExecutionCanceledEventAttributes {
    workflowExecution: WorkflowExecution;
    workflowType: WorkflowType;
    details?: string | undefined;
    initiatedEventId: number;
    startedEventId: number;
}
export interface ChildWorkflowExecutionTerminatedEventAttributes {
    workflowExecution: WorkflowExecution;
    workflowType: WorkflowType;
    initiatedEventId: number;
    startedEventId: number;
}
export interface SignalExternalWorkflowExecutionInitiatedEventAttributes {
    workflowId: string;
    runId?: string | undefined;
    signalName: string;
    input?: string | undefined;
    decisionTaskCompletedEventId: number;
    control?: string | undefined;
}
export interface ExternalWorkflowExecutionSignaledEventAttributes {
    workflowExecution: WorkflowExecution;
    initiatedEventId: number;
}
export type SignalExternalWorkflowExecutionFailedCause = "UNKNOWN_EXTERNAL_WORKFLOW_EXECUTION" | "SIGNAL_EXTERNAL_WORKFLOW_EXECUTION_RATE_EXCEEDED" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface SignalExternalWorkflowExecutionFailedEventAttributes {
    workflowId: string;
    runId?: string | undefined;
    cause: SignalExternalWorkflowExecutionFailedCause;
    initiatedEventId: number;
    decisionTaskCompletedEventId: number;
    control?: string | undefined;
}
export interface ExternalWorkflowExecutionCancelRequestedEventAttributes {
    workflowExecution: WorkflowExecution;
    initiatedEventId: number;
}
export interface RequestCancelExternalWorkflowExecutionInitiatedEventAttributes {
    workflowId: string;
    runId?: string | undefined;
    decisionTaskCompletedEventId: number;
    control?: string | undefined;
}
export type RequestCancelExternalWorkflowExecutionFailedCause = "UNKNOWN_EXTERNAL_WORKFLOW_EXECUTION" | "REQUEST_CANCEL_EXTERNAL_WORKFLOW_EXECUTION_RATE_EXCEEDED" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface RequestCancelExternalWorkflowExecutionFailedEventAttributes {
    workflowId: string;
    runId?: string | undefined;
    cause: RequestCancelExternalWorkflowExecutionFailedCause;
    initiatedEventId: number;
    decisionTaskCompletedEventId: number;
    control?: string | undefined;
}
export type ScheduleActivityTaskFailedCause = "ACTIVITY_TYPE_DEPRECATED" | "ACTIVITY_TYPE_DOES_NOT_EXIST" | "ACTIVITY_ID_ALREADY_IN_USE" | "OPEN_ACTIVITIES_LIMIT_EXCEEDED" | "ACTIVITY_CREATION_RATE_EXCEEDED" | "DEFAULT_SCHEDULE_TO_CLOSE_TIMEOUT_UNDEFINED" | "DEFAULT_TASK_LIST_UNDEFINED" | "DEFAULT_SCHEDULE_TO_START_TIMEOUT_UNDEFINED" | "DEFAULT_START_TO_CLOSE_TIMEOUT_UNDEFINED" | "DEFAULT_HEARTBEAT_TIMEOUT_UNDEFINED" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface ScheduleActivityTaskFailedEventAttributes {
    activityType: ActivityType;
    activityId: string;
    cause: ScheduleActivityTaskFailedCause;
    decisionTaskCompletedEventId: number;
}
export type RequestCancelActivityTaskFailedCause = "ACTIVITY_ID_UNKNOWN" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface RequestCancelActivityTaskFailedEventAttributes {
    activityId: string;
    cause: RequestCancelActivityTaskFailedCause;
    decisionTaskCompletedEventId: number;
}
export type StartTimerFailedCause = "TIMER_ID_ALREADY_IN_USE" | "OPEN_TIMERS_LIMIT_EXCEEDED" | "TIMER_CREATION_RATE_EXCEEDED" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface StartTimerFailedEventAttributes {
    timerId: string;
    cause: StartTimerFailedCause;
    decisionTaskCompletedEventId: number;
}
export type CancelTimerFailedCause = "TIMER_ID_UNKNOWN" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface CancelTimerFailedEventAttributes {
    timerId: string;
    cause: CancelTimerFailedCause;
    decisionTaskCompletedEventId: number;
}
export type StartChildWorkflowExecutionFailedCause = "WORKFLOW_TYPE_DOES_NOT_EXIST" | "WORKFLOW_TYPE_DEPRECATED" | "OPEN_CHILDREN_LIMIT_EXCEEDED" | "OPEN_WORKFLOWS_LIMIT_EXCEEDED" | "CHILD_CREATION_RATE_EXCEEDED" | "WORKFLOW_ALREADY_RUNNING" | "DEFAULT_EXECUTION_START_TO_CLOSE_TIMEOUT_UNDEFINED" | "DEFAULT_TASK_LIST_UNDEFINED" | "DEFAULT_TASK_START_TO_CLOSE_TIMEOUT_UNDEFINED" | "DEFAULT_CHILD_POLICY_UNDEFINED" | "OPERATION_NOT_PERMITTED" | (string & {});
export interface StartChildWorkflowExecutionFailedEventAttributes {
    workflowType: WorkflowType;
    cause: StartChildWorkflowExecutionFailedCause;
    workflowId: string;
    initiatedEventId: number;
    decisionTaskCompletedEventId: number;
    control?: string | undefined;
}
export type FunctionId = string;
export type FunctionName = string;
export type FunctionInput = string;
export interface LambdaFunctionScheduledEventAttributes {
    id: string;
    name: string;
    control?: string | undefined;
    input?: string | undefined;
    startToCloseTimeout?: string | undefined;
    decisionTaskCompletedEventId: number;
}
export interface LambdaFunctionStartedEventAttributes {
    scheduledEventId: number;
}
export interface LambdaFunctionCompletedEventAttributes {
    scheduledEventId: number;
    startedEventId: number;
    result?: string | undefined;
}
export interface LambdaFunctionFailedEventAttributes {
    scheduledEventId: number;
    startedEventId: number;
    reason?: string | undefined;
    details?: string | undefined;
}
export type LambdaFunctionTimeoutType = "START_TO_CLOSE" | (string & {});
export interface LambdaFunctionTimedOutEventAttributes {
    scheduledEventId: number;
    startedEventId: number;
    timeoutType?: LambdaFunctionTimeoutType | undefined;
}
export type ScheduleLambdaFunctionFailedCause = "ID_ALREADY_IN_USE" | "OPEN_LAMBDA_FUNCTIONS_LIMIT_EXCEEDED" | "LAMBDA_FUNCTION_CREATION_RATE_EXCEEDED" | "LAMBDA_SERVICE_NOT_AVAILABLE_IN_REGION" | (string & {});
export interface ScheduleLambdaFunctionFailedEventAttributes {
    id: string;
    name: string;
    cause: ScheduleLambdaFunctionFailedCause;
    decisionTaskCompletedEventId: number;
}
export type StartLambdaFunctionFailedCause = "ASSUME_ROLE_FAILED" | (string & {});
export type CauseMessage = string;
export interface StartLambdaFunctionFailedEventAttributes {
    scheduledEventId?: number | undefined;
    cause?: StartLambdaFunctionFailedCause | undefined;
    message?: string | undefined;
}
export interface HistoryEvent {
    eventTimestamp: Date;
    eventType: EventType;
    eventId: number;
    workflowExecutionStartedEventAttributes?: WorkflowExecutionStartedEventAttributes | undefined;
    workflowExecutionCompletedEventAttributes?: WorkflowExecutionCompletedEventAttributes | undefined;
    completeWorkflowExecutionFailedEventAttributes?: CompleteWorkflowExecutionFailedEventAttributes | undefined;
    workflowExecutionFailedEventAttributes?: WorkflowExecutionFailedEventAttributes | undefined;
    failWorkflowExecutionFailedEventAttributes?: FailWorkflowExecutionFailedEventAttributes | undefined;
    workflowExecutionTimedOutEventAttributes?: WorkflowExecutionTimedOutEventAttributes | undefined;
    workflowExecutionCanceledEventAttributes?: WorkflowExecutionCanceledEventAttributes | undefined;
    cancelWorkflowExecutionFailedEventAttributes?: CancelWorkflowExecutionFailedEventAttributes | undefined;
    workflowExecutionContinuedAsNewEventAttributes?: WorkflowExecutionContinuedAsNewEventAttributes | undefined;
    continueAsNewWorkflowExecutionFailedEventAttributes?: ContinueAsNewWorkflowExecutionFailedEventAttributes | undefined;
    workflowExecutionTerminatedEventAttributes?: WorkflowExecutionTerminatedEventAttributes | undefined;
    workflowExecutionCancelRequestedEventAttributes?: WorkflowExecutionCancelRequestedEventAttributes | undefined;
    decisionTaskScheduledEventAttributes?: DecisionTaskScheduledEventAttributes | undefined;
    decisionTaskStartedEventAttributes?: DecisionTaskStartedEventAttributes | undefined;
    decisionTaskCompletedEventAttributes?: DecisionTaskCompletedEventAttributes | undefined;
    decisionTaskTimedOutEventAttributes?: DecisionTaskTimedOutEventAttributes | undefined;
    activityTaskScheduledEventAttributes?: ActivityTaskScheduledEventAttributes | undefined;
    activityTaskStartedEventAttributes?: ActivityTaskStartedEventAttributes | undefined;
    activityTaskCompletedEventAttributes?: ActivityTaskCompletedEventAttributes | undefined;
    activityTaskFailedEventAttributes?: ActivityTaskFailedEventAttributes | undefined;
    activityTaskTimedOutEventAttributes?: ActivityTaskTimedOutEventAttributes | undefined;
    activityTaskCanceledEventAttributes?: ActivityTaskCanceledEventAttributes | undefined;
    activityTaskCancelRequestedEventAttributes?: ActivityTaskCancelRequestedEventAttributes | undefined;
    workflowExecutionSignaledEventAttributes?: WorkflowExecutionSignaledEventAttributes | undefined;
    markerRecordedEventAttributes?: MarkerRecordedEventAttributes | undefined;
    recordMarkerFailedEventAttributes?: RecordMarkerFailedEventAttributes | undefined;
    timerStartedEventAttributes?: TimerStartedEventAttributes | undefined;
    timerFiredEventAttributes?: TimerFiredEventAttributes | undefined;
    timerCanceledEventAttributes?: TimerCanceledEventAttributes | undefined;
    startChildWorkflowExecutionInitiatedEventAttributes?: StartChildWorkflowExecutionInitiatedEventAttributes | undefined;
    childWorkflowExecutionStartedEventAttributes?: ChildWorkflowExecutionStartedEventAttributes | undefined;
    childWorkflowExecutionCompletedEventAttributes?: ChildWorkflowExecutionCompletedEventAttributes | undefined;
    childWorkflowExecutionFailedEventAttributes?: ChildWorkflowExecutionFailedEventAttributes | undefined;
    childWorkflowExecutionTimedOutEventAttributes?: ChildWorkflowExecutionTimedOutEventAttributes | undefined;
    childWorkflowExecutionCanceledEventAttributes?: ChildWorkflowExecutionCanceledEventAttributes | undefined;
    childWorkflowExecutionTerminatedEventAttributes?: ChildWorkflowExecutionTerminatedEventAttributes | undefined;
    signalExternalWorkflowExecutionInitiatedEventAttributes?: SignalExternalWorkflowExecutionInitiatedEventAttributes | undefined;
    externalWorkflowExecutionSignaledEventAttributes?: ExternalWorkflowExecutionSignaledEventAttributes | undefined;
    signalExternalWorkflowExecutionFailedEventAttributes?: SignalExternalWorkflowExecutionFailedEventAttributes | undefined;
    externalWorkflowExecutionCancelRequestedEventAttributes?: ExternalWorkflowExecutionCancelRequestedEventAttributes | undefined;
    requestCancelExternalWorkflowExecutionInitiatedEventAttributes?: RequestCancelExternalWorkflowExecutionInitiatedEventAttributes | undefined;
    requestCancelExternalWorkflowExecutionFailedEventAttributes?: RequestCancelExternalWorkflowExecutionFailedEventAttributes | undefined;
    scheduleActivityTaskFailedEventAttributes?: ScheduleActivityTaskFailedEventAttributes | undefined;
    requestCancelActivityTaskFailedEventAttributes?: RequestCancelActivityTaskFailedEventAttributes | undefined;
    startTimerFailedEventAttributes?: StartTimerFailedEventAttributes | undefined;
    cancelTimerFailedEventAttributes?: CancelTimerFailedEventAttributes | undefined;
    startChildWorkflowExecutionFailedEventAttributes?: StartChildWorkflowExecutionFailedEventAttributes | undefined;
    lambdaFunctionScheduledEventAttributes?: LambdaFunctionScheduledEventAttributes | undefined;
    lambdaFunctionStartedEventAttributes?: LambdaFunctionStartedEventAttributes | undefined;
    lambdaFunctionCompletedEventAttributes?: LambdaFunctionCompletedEventAttributes | undefined;
    lambdaFunctionFailedEventAttributes?: LambdaFunctionFailedEventAttributes | undefined;
    lambdaFunctionTimedOutEventAttributes?: LambdaFunctionTimedOutEventAttributes | undefined;
    scheduleLambdaFunctionFailedEventAttributes?: ScheduleLambdaFunctionFailedEventAttributes | undefined;
    startLambdaFunctionFailedEventAttributes?: StartLambdaFunctionFailedEventAttributes | undefined;
}
export type HistoryEventList = HistoryEvent[];
export interface History {
    events: HistoryEvent[];
    nextPageToken?: string | undefined;
}
export interface ListActivityTypesInput {
    domain: string;
    name?: string | undefined;
    registrationStatus: RegistrationStatus;
    nextPageToken?: string | undefined;
    maximumPageSize?: number | undefined;
    reverseOrder?: boolean | undefined;
}
export type ActivityTypeInfoList = ActivityTypeInfo[];
export interface ActivityTypeInfos {
    typeInfos: ActivityTypeInfo[];
    nextPageToken?: string | undefined;
}
export interface ListClosedWorkflowExecutionsInput {
    domain: string;
    startTimeFilter?: ExecutionTimeFilter | undefined;
    closeTimeFilter?: ExecutionTimeFilter | undefined;
    executionFilter?: WorkflowExecutionFilter | undefined;
    closeStatusFilter?: CloseStatusFilter | undefined;
    typeFilter?: WorkflowTypeFilter | undefined;
    tagFilter?: TagFilter | undefined;
    nextPageToken?: string | undefined;
    maximumPageSize?: number | undefined;
    reverseOrder?: boolean | undefined;
}
export type WorkflowExecutionInfoList = WorkflowExecutionInfo[];
export interface WorkflowExecutionInfos {
    executionInfos: WorkflowExecutionInfo[];
    nextPageToken?: string | undefined;
}
export interface ListDomainsInput {
    nextPageToken?: string | undefined;
    registrationStatus: RegistrationStatus;
    maximumPageSize?: number | undefined;
    reverseOrder?: boolean | undefined;
}
export type DomainInfoList = DomainInfo[];
export interface DomainInfos {
    domainInfos: DomainInfo[];
    nextPageToken?: string | undefined;
}
export interface ListOpenWorkflowExecutionsInput {
    domain: string;
    startTimeFilter: ExecutionTimeFilter;
    typeFilter?: WorkflowTypeFilter | undefined;
    tagFilter?: TagFilter | undefined;
    nextPageToken?: string | undefined;
    maximumPageSize?: number | undefined;
    reverseOrder?: boolean | undefined;
    executionFilter?: WorkflowExecutionFilter | undefined;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    key: string;
    value?: string | undefined;
}
export type ResourceTagList = ResourceTag[];
export interface ListTagsForResourceOutput {
    tags?: ResourceTag[] | undefined;
}
export interface ListWorkflowTypesInput {
    domain: string;
    name?: string | undefined;
    registrationStatus: RegistrationStatus;
    nextPageToken?: string | undefined;
    maximumPageSize?: number | undefined;
    reverseOrder?: boolean | undefined;
}
export type WorkflowTypeInfoList = WorkflowTypeInfo[];
export interface WorkflowTypeInfos {
    typeInfos: WorkflowTypeInfo[];
    nextPageToken?: string | undefined;
}
export interface PollForActivityTaskInput {
    domain: string;
    taskList: TaskList;
    identity?: string | undefined;
}
export type TaskToken = string;
export interface ActivityTask {
    taskToken: string;
    activityId: string;
    startedEventId: number;
    workflowExecution: WorkflowExecution;
    activityType: ActivityType;
    input?: string | undefined;
}
export type StartAtPreviousStartedEvent = boolean;
export interface PollForDecisionTaskInput {
    domain: string;
    taskList: TaskList;
    identity?: string | undefined;
    nextPageToken?: string | undefined;
    maximumPageSize?: number | undefined;
    reverseOrder?: boolean | undefined;
    startAtPreviousStartedEvent?: boolean | undefined;
}
export interface DecisionTask {
    taskToken: string;
    startedEventId: number;
    workflowExecution: WorkflowExecution;
    workflowType: WorkflowType;
    events: HistoryEvent[];
    nextPageToken?: string | undefined;
    previousStartedEventId?: number | undefined;
}
export interface RecordActivityTaskHeartbeatInput {
    taskToken: string;
    details?: string | undefined;
}
export interface ActivityTaskStatus {
    cancelRequested: boolean;
}
export interface RegisterActivityTypeInput {
    domain: string;
    name: string;
    version: string;
    description?: string | undefined;
    defaultTaskStartToCloseTimeout?: string | undefined;
    defaultTaskHeartbeatTimeout?: string | undefined;
    defaultTaskList?: TaskList | undefined;
    defaultTaskPriority?: string | undefined;
    defaultTaskScheduleToStartTimeout?: string | undefined;
    defaultTaskScheduleToCloseTimeout?: string | undefined;
}
export interface RegisterActivityTypeResponse {
}
export interface RegisterDomainInput {
    name: string;
    description?: string | undefined;
    workflowExecutionRetentionPeriodInDays: string;
    tags?: ResourceTag[] | undefined;
}
export interface RegisterDomainResponse {
}
export interface RegisterWorkflowTypeInput {
    domain: string;
    name: string;
    version: string;
    description?: string | undefined;
    defaultTaskStartToCloseTimeout?: string | undefined;
    defaultExecutionStartToCloseTimeout?: string | undefined;
    defaultTaskList?: TaskList | undefined;
    defaultTaskPriority?: string | undefined;
    defaultChildPolicy?: ChildPolicy | undefined;
    defaultLambdaRole?: string | undefined;
}
export interface RegisterWorkflowTypeResponse {
}
export interface RequestCancelWorkflowExecutionInput {
    domain: string;
    workflowId: string;
    runId?: string | undefined;
}
export interface RequestCancelWorkflowExecutionResponse {
}
export interface RespondActivityTaskCanceledInput {
    taskToken: string;
    details?: string | undefined;
}
export interface RespondActivityTaskCanceledResponse {
}
export interface RespondActivityTaskCompletedInput {
    taskToken: string;
    result?: string | undefined;
}
export interface RespondActivityTaskCompletedResponse {
}
export interface RespondActivityTaskFailedInput {
    taskToken: string;
    reason?: string | undefined;
    details?: string | undefined;
}
export interface RespondActivityTaskFailedResponse {
}
export type DecisionType = "ScheduleActivityTask" | "RequestCancelActivityTask" | "CompleteWorkflowExecution" | "FailWorkflowExecution" | "CancelWorkflowExecution" | "ContinueAsNewWorkflowExecution" | "RecordMarker" | "StartTimer" | "CancelTimer" | "SignalExternalWorkflowExecution" | "RequestCancelExternalWorkflowExecution" | "StartChildWorkflowExecution" | "ScheduleLambdaFunction" | (string & {});
export interface ScheduleActivityTaskDecisionAttributes {
    activityType: ActivityType;
    activityId: string;
    control?: string | undefined;
    input?: string | undefined;
    scheduleToCloseTimeout?: string | undefined;
    taskList?: TaskList | undefined;
    taskPriority?: string | undefined;
    scheduleToStartTimeout?: string | undefined;
    startToCloseTimeout?: string | undefined;
    heartbeatTimeout?: string | undefined;
}
export interface RequestCancelActivityTaskDecisionAttributes {
    activityId: string;
}
export interface CompleteWorkflowExecutionDecisionAttributes {
    result?: string | undefined;
}
export interface FailWorkflowExecutionDecisionAttributes {
    reason?: string | undefined;
    details?: string | undefined;
}
export interface CancelWorkflowExecutionDecisionAttributes {
    details?: string | undefined;
}
export interface ContinueAsNewWorkflowExecutionDecisionAttributes {
    input?: string | undefined;
    executionStartToCloseTimeout?: string | undefined;
    taskList?: TaskList | undefined;
    taskPriority?: string | undefined;
    taskStartToCloseTimeout?: string | undefined;
    childPolicy?: ChildPolicy | undefined;
    tagList?: string[] | undefined;
    workflowTypeVersion?: string | undefined;
    lambdaRole?: string | undefined;
}
export interface RecordMarkerDecisionAttributes {
    markerName: string;
    details?: string | undefined;
}
export interface StartTimerDecisionAttributes {
    timerId: string;
    control?: string | undefined;
    startToFireTimeout: string;
}
export interface CancelTimerDecisionAttributes {
    timerId: string;
}
export interface SignalExternalWorkflowExecutionDecisionAttributes {
    workflowId: string;
    runId?: string | undefined;
    signalName: string;
    input?: string | undefined;
    control?: string | undefined;
}
export interface RequestCancelExternalWorkflowExecutionDecisionAttributes {
    workflowId: string;
    runId?: string | undefined;
    control?: string | undefined;
}
export interface StartChildWorkflowExecutionDecisionAttributes {
    workflowType: WorkflowType;
    workflowId: string;
    control?: string | undefined;
    input?: string | undefined;
    executionStartToCloseTimeout?: string | undefined;
    taskList?: TaskList | undefined;
    taskPriority?: string | undefined;
    taskStartToCloseTimeout?: string | undefined;
    childPolicy?: ChildPolicy | undefined;
    tagList?: string[] | undefined;
    lambdaRole?: string | undefined;
}
export interface ScheduleLambdaFunctionDecisionAttributes {
    id: string;
    name: string;
    control?: string | undefined;
    input?: string | undefined;
    startToCloseTimeout?: string | undefined;
}
export interface Decision {
    decisionType: DecisionType;
    scheduleActivityTaskDecisionAttributes?: ScheduleActivityTaskDecisionAttributes | undefined;
    requestCancelActivityTaskDecisionAttributes?: RequestCancelActivityTaskDecisionAttributes | undefined;
    completeWorkflowExecutionDecisionAttributes?: CompleteWorkflowExecutionDecisionAttributes | undefined;
    failWorkflowExecutionDecisionAttributes?: FailWorkflowExecutionDecisionAttributes | undefined;
    cancelWorkflowExecutionDecisionAttributes?: CancelWorkflowExecutionDecisionAttributes | undefined;
    continueAsNewWorkflowExecutionDecisionAttributes?: ContinueAsNewWorkflowExecutionDecisionAttributes | undefined;
    recordMarkerDecisionAttributes?: RecordMarkerDecisionAttributes | undefined;
    startTimerDecisionAttributes?: StartTimerDecisionAttributes | undefined;
    cancelTimerDecisionAttributes?: CancelTimerDecisionAttributes | undefined;
    signalExternalWorkflowExecutionDecisionAttributes?: SignalExternalWorkflowExecutionDecisionAttributes | undefined;
    requestCancelExternalWorkflowExecutionDecisionAttributes?: RequestCancelExternalWorkflowExecutionDecisionAttributes | undefined;
    startChildWorkflowExecutionDecisionAttributes?: StartChildWorkflowExecutionDecisionAttributes | undefined;
    scheduleLambdaFunctionDecisionAttributes?: ScheduleLambdaFunctionDecisionAttributes | undefined;
}
export type DecisionList = Decision[];
export interface RespondDecisionTaskCompletedInput {
    taskToken: string;
    decisions?: Decision[] | undefined;
    executionContext?: string | undefined;
    taskList?: TaskList | undefined;
    taskListScheduleToStartTimeout?: string | undefined;
}
export interface RespondDecisionTaskCompletedResponse {
}
export interface SignalWorkflowExecutionInput {
    domain: string;
    workflowId: string;
    runId?: string | undefined;
    signalName: string;
    input?: string | undefined;
}
export interface SignalWorkflowExecutionResponse {
}
export interface StartWorkflowExecutionInput {
    domain: string;
    workflowId: string;
    workflowType: WorkflowType;
    taskList?: TaskList | undefined;
    taskPriority?: string | undefined;
    input?: string | undefined;
    executionStartToCloseTimeout?: string | undefined;
    tagList?: string[] | undefined;
    taskStartToCloseTimeout?: string | undefined;
    childPolicy?: ChildPolicy | undefined;
    lambdaRole?: string | undefined;
}
export interface Run {
    runId?: string | undefined;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: ResourceTag[];
}
export interface TagResourceResponse {
}
export interface TerminateWorkflowExecutionInput {
    domain: string;
    workflowId: string;
    runId?: string | undefined;
    reason?: string | undefined;
    details?: string | undefined;
    childPolicy?: ChildPolicy | undefined;
}
export interface TerminateWorkflowExecutionResponse {
}
export interface UndeprecateActivityTypeInput {
    domain: string;
    activityType: ActivityType;
}
export interface UndeprecateActivityTypeResponse {
}
export interface UndeprecateDomainInput {
    name: string;
}
export interface UndeprecateDomainResponse {
}
export interface UndeprecateWorkflowTypeInput {
    domain: string;
    workflowType: WorkflowType;
}
export interface UndeprecateWorkflowTypeResponse {
}
export type ResourceTagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ErrorMessage = string;
export type CountClosedWorkflowExecutionsError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns the number of closed workflow executions within the given domain that meet the
 * specified filtering criteria.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `tagFilter.tag`: String constraint. The key is
 * `swf:tagFilter.tag`.
 *
 * - `typeFilter.name`: String constraint. The key is
 * `swf:typeFilter.name`.
 *
 * - `typeFilter.version`: String constraint. The key is
 * `swf:typeFilter.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const countClosedWorkflowExecutions: API.OperationMethod<CountClosedWorkflowExecutionsInput & RegionInput, WorkflowExecutionCount, CountClosedWorkflowExecutionsError, Credentials | HttpClient.HttpClient>;
export type CountOpenWorkflowExecutionsError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns the number of open workflow executions within the given domain that meet the
 * specified filtering criteria.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `tagFilter.tag`: String constraint. The key is
 * `swf:tagFilter.tag`.
 *
 * - `typeFilter.name`: String constraint. The key is
 * `swf:typeFilter.name`.
 *
 * - `typeFilter.version`: String constraint. The key is
 * `swf:typeFilter.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const countOpenWorkflowExecutions: API.OperationMethod<CountOpenWorkflowExecutionsInput & RegionInput, WorkflowExecutionCount, CountOpenWorkflowExecutionsError, Credentials | HttpClient.HttpClient>;
export type CountPendingActivityTasksError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns the estimated number of activity tasks in the specified task list. The count
 * returned is an approximation and isn't guaranteed to be exact. If you specify a task list that
 * no activity task was ever scheduled in then `0` is returned.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the `taskList.name` parameter by using a
 * `Condition` element with the `swf:taskList.name` key to allow the
 * action to access only certain task lists.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const countPendingActivityTasks: API.OperationMethod<CountPendingActivityTasksInput & RegionInput, PendingTaskCount, CountPendingActivityTasksError, Credentials | HttpClient.HttpClient>;
export type CountPendingDecisionTasksError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns the estimated number of decision tasks in the specified task list. The count
 * returned is an approximation and isn't guaranteed to be exact. If you specify a task list that
 * no decision task was ever scheduled in then `0` is returned.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the `taskList.name` parameter by using a
 * `Condition` element with the `swf:taskList.name` key to allow the
 * action to access only certain task lists.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const countPendingDecisionTasks: API.OperationMethod<CountPendingDecisionTasksInput & RegionInput, PendingTaskCount, CountPendingDecisionTasksError, Credentials | HttpClient.HttpClient>;
export type DeleteActivityTypeError = OperationNotPermittedFault | TypeNotDeprecatedFault | UnknownResourceFault | CommonErrors;
/**
 * Deletes the specified *activity type*.
 *
 * Note: Prior to deletion, activity types must first be **deprecated**.
 *
 * After an activity type has been deleted, you cannot schedule new activities of that type. Activities that started before the type was deleted will continue to run.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `activityType.name`: String constraint. The key is
 * `swf:activityType.name`.
 *
 * - `activityType.version`: String constraint. The key is
 * `swf:activityType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const deleteActivityType: API.OperationMethod<DeleteActivityTypeInput & RegionInput, DeleteActivityTypeResponse, DeleteActivityTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowTypeError = OperationNotPermittedFault | TypeNotDeprecatedFault | UnknownResourceFault | CommonErrors;
/**
 * Deletes the specified *workflow type*.
 *
 * Note: Prior to deletion, workflow types must first be **deprecated**.
 *
 * After a workflow type has been deleted, you cannot create new executions of that type. Executions that
 * started before the type was deleted will continue to run.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `workflowType.name`: String constraint. The key is
 * `swf:workflowType.name`.
 *
 * - `workflowType.version`: String constraint. The key is
 * `swf:workflowType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const deleteWorkflowType: API.OperationMethod<DeleteWorkflowTypeInput & RegionInput, DeleteWorkflowTypeResponse, DeleteWorkflowTypeError, Credentials | HttpClient.HttpClient>;
export type DeprecateActivityTypeError = OperationNotPermittedFault | TypeDeprecatedFault | UnknownResourceFault | CommonErrors;
/**
 * Deprecates the specified *activity type*. After an activity type has
 * been deprecated, you cannot create new tasks of that activity type. Tasks of this type that
 * were scheduled before the type was deprecated continue to run.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `activityType.name`: String constraint. The key is
 * `swf:activityType.name`.
 *
 * - `activityType.version`: String constraint. The key is
 * `swf:activityType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const deprecateActivityType: API.OperationMethod<DeprecateActivityTypeInput & RegionInput, DeprecateActivityTypeResponse, DeprecateActivityTypeError, Credentials | HttpClient.HttpClient>;
export type DeprecateDomainError = DomainDeprecatedFault | OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Deprecates the specified domain. After a domain has been deprecated it cannot be used
 * to create new workflow executions or register new types. However, you can still use visibility
 * actions on this domain. Deprecating a domain also deprecates all activity and workflow types
 * registered in the domain. Executions that were started before the domain was deprecated
 * continues to run.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const deprecateDomain: API.OperationMethod<DeprecateDomainInput & RegionInput, DeprecateDomainResponse, DeprecateDomainError, Credentials | HttpClient.HttpClient>;
export type DeprecateWorkflowTypeError = OperationNotPermittedFault | TypeDeprecatedFault | UnknownResourceFault | CommonErrors;
/**
 * Deprecates the specified *workflow type*. After a workflow type has
 * been deprecated, you cannot create new executions of that type. Executions that were started
 * before the type was deprecated continues to run. A deprecated workflow type may still be used
 * when calling visibility actions.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `workflowType.name`: String constraint. The key is
 * `swf:workflowType.name`.
 *
 * - `workflowType.version`: String constraint. The key is
 * `swf:workflowType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const deprecateWorkflowType: API.OperationMethod<DeprecateWorkflowTypeInput & RegionInput, DeprecateWorkflowTypeResponse, DeprecateWorkflowTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeActivityTypeError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns information about the specified activity type. This includes configuration
 * settings provided when the type was registered and other general information about the
 * type.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `activityType.name`: String constraint. The key is
 * `swf:activityType.name`.
 *
 * - `activityType.version`: String constraint. The key is
 * `swf:activityType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const describeActivityType: API.OperationMethod<DescribeActivityTypeInput & RegionInput, ActivityTypeDetail, DescribeActivityTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns information about the specified domain, including description and
 * status.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const describeDomain: API.OperationMethod<DescribeDomainInput & RegionInput, DomainDetail, DescribeDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkflowExecutionError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns information about the specified workflow execution including its type and some
 * statistics.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const describeWorkflowExecution: API.OperationMethod<DescribeWorkflowExecutionInput & RegionInput, WorkflowExecutionDetail, DescribeWorkflowExecutionError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkflowTypeError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns information about the specified *workflow type*. This
 * includes configuration settings specified when the type was registered and other information
 * such as creation date, current status, etc.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `workflowType.name`: String constraint. The key is
 * `swf:workflowType.name`.
 *
 * - `workflowType.version`: String constraint. The key is
 * `swf:workflowType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const describeWorkflowType: API.OperationMethod<DescribeWorkflowTypeInput & RegionInput, WorkflowTypeDetail, DescribeWorkflowTypeError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowExecutionHistoryError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns the history of the specified workflow execution. The results may be split into
 * multiple pages. To retrieve subsequent pages, make the call again using the
 * `nextPageToken` returned by the initial call.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const getWorkflowExecutionHistory: API.PaginatedOperationMethod<GetWorkflowExecutionHistoryInput & RegionInput, History, GetWorkflowExecutionHistoryError, Credentials | HttpClient.HttpClient, HistoryEvent>;
export type ListActivityTypesError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns information about all activities registered in the specified domain that match
 * the specified name and registration status. The result includes information like creation
 * date, current status of the activity, etc. The results may be split into multiple pages. To
 * retrieve subsequent pages, make the call again using the `nextPageToken` returned
 * by the initial call.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const listActivityTypes: API.PaginatedOperationMethod<ListActivityTypesInput & RegionInput, ActivityTypeInfos, ListActivityTypesError, Credentials | HttpClient.HttpClient, ActivityTypeInfo>;
export type ListClosedWorkflowExecutionsError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns a list of closed workflow executions in the specified domain that meet the
 * filtering criteria. The results may be split into multiple pages. To retrieve subsequent
 * pages, make the call again using the nextPageToken returned by the initial call.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `tagFilter.tag`: String constraint. The key is
 * `swf:tagFilter.tag`.
 *
 * - `typeFilter.name`: String constraint. The key is
 * `swf:typeFilter.name`.
 *
 * - `typeFilter.version`: String constraint. The key is
 * `swf:typeFilter.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const listClosedWorkflowExecutions: API.PaginatedOperationMethod<ListClosedWorkflowExecutionsInput & RegionInput, WorkflowExecutionInfos, ListClosedWorkflowExecutionsError, Credentials | HttpClient.HttpClient, WorkflowExecutionInfo>;
export type ListDomainsError = OperationNotPermittedFault | CommonErrors;
/**
 * Returns the list of domains registered in the account. The results may be split into
 * multiple pages. To retrieve subsequent pages, make the call again using the nextPageToken
 * returned by the initial call.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains. The element must be set to
 * `arn:aws:swf::AccountID:domain/*`, where *AccountID* is
 * the account ID, with no dashes.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsInput & RegionInput, DomainInfos, ListDomainsError, Credentials | HttpClient.HttpClient, DomainInfo>;
export type ListOpenWorkflowExecutionsError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns a list of open workflow executions in the specified domain that meet the
 * filtering criteria. The results may be split into multiple pages. To retrieve subsequent
 * pages, make the call again using the nextPageToken returned by the initial call.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `tagFilter.tag`: String constraint. The key is
 * `swf:tagFilter.tag`.
 *
 * - `typeFilter.name`: String constraint. The key is
 * `swf:typeFilter.name`.
 *
 * - `typeFilter.version`: String constraint. The key is
 * `swf:typeFilter.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const listOpenWorkflowExecutions: API.PaginatedOperationMethod<ListOpenWorkflowExecutionsInput & RegionInput, WorkflowExecutionInfos, ListOpenWorkflowExecutionsError, Credentials | HttpClient.HttpClient, WorkflowExecutionInfo>;
export type ListTagsForResourceError = LimitExceededFault | OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * List tags for a given domain.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkflowTypesError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Returns information about workflow types in the specified domain. The results may be
 * split into multiple pages that can be retrieved by making the call repeatedly.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const listWorkflowTypes: API.PaginatedOperationMethod<ListWorkflowTypesInput & RegionInput, WorkflowTypeInfos, ListWorkflowTypesError, Credentials | HttpClient.HttpClient, WorkflowTypeInfo>;
export type PollForActivityTaskError = LimitExceededFault | OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Used by workers to get an ActivityTask from the specified activity
 * `taskList`. This initiates a long poll, where the service holds the HTTP
 * connection open and responds as soon as a task becomes available. The maximum time the service
 * holds on to the request before responding is 60 seconds. If no task is available within 60
 * seconds, the poll returns an empty result. An empty result, in this context, means that an
 * ActivityTask is returned, but that the value of taskToken is an empty string. If a task is
 * returned, the worker should use its type to identify and process it correctly.
 *
 * Workers should set their client side socket timeout to at least 70 seconds (10
 * seconds higher than the maximum time service may hold the poll request).
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the `taskList.name` parameter by using a
 * `Condition` element with the `swf:taskList.name` key to allow the
 * action to access only certain task lists.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const pollForActivityTask: API.OperationMethod<PollForActivityTaskInput & RegionInput, ActivityTask, PollForActivityTaskError, Credentials | HttpClient.HttpClient>;
export type PollForDecisionTaskError = LimitExceededFault | OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Used by deciders to get a DecisionTask from the specified decision
 * `taskList`. A decision task may be returned for any open workflow execution that
 * is using the specified task list. The task includes a paginated view of the history of the
 * workflow execution. The decider should use the workflow type and the history to determine how
 * to properly handle the task.
 *
 * This action initiates a long poll, where the service holds the HTTP connection open and
 * responds as soon a task becomes available. If no decision task is available in the specified
 * task list before the timeout of 60 seconds expires, an empty result is returned. An empty
 * result, in this context, means that a DecisionTask is returned, but that the value of
 * taskToken is an empty string.
 *
 * Deciders should set their client side socket timeout to at least 70 seconds (10
 * seconds higher than the timeout).
 *
 * Because the number of workflow history events for a single workflow execution might
 * be very large, the result returned might be split up across a number of pages. To retrieve
 * subsequent pages, make additional calls to `PollForDecisionTask` using the
 * `nextPageToken` returned by the initial call. Note that you do
 * *not* call `GetWorkflowExecutionHistory` with this
 * `nextPageToken`. Instead, call `PollForDecisionTask`
 * again.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the `taskList.name` parameter by using a
 * `Condition` element with the `swf:taskList.name` key to allow the
 * action to access only certain task lists.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const pollForDecisionTask: API.PaginatedOperationMethod<PollForDecisionTaskInput & RegionInput, DecisionTask, PollForDecisionTaskError, Credentials | HttpClient.HttpClient, HistoryEvent>;
export type RecordActivityTaskHeartbeatError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Used by activity workers to report to the service that the ActivityTask represented by the specified `taskToken` is still making progress. The worker
 * can also specify details of the progress, for example percent complete, using the
 * `details` parameter. This action can also be used by the worker as a mechanism to
 * check if cancellation is being requested for the activity task. If a cancellation is being
 * attempted for the specified task, then the boolean `cancelRequested` flag returned
 * by the service is set to `true`.
 *
 * This action resets the `taskHeartbeatTimeout` clock. The
 * `taskHeartbeatTimeout` is specified in RegisterActivityType.
 *
 * This action doesn't in itself create an event in the workflow execution history.
 * However, if the task times out, the workflow execution history contains a
 * `ActivityTaskTimedOut` event that contains the information from the last
 * heartbeat generated by the activity worker.
 *
 * The `taskStartToCloseTimeout` of an activity type is the maximum duration
 * of an activity task, regardless of the number of RecordActivityTaskHeartbeat requests received. The `taskStartToCloseTimeout` is also specified in RegisterActivityType.
 *
 * This operation is only useful for long-lived activities to report liveliness of the
 * task and to determine if a cancellation is being attempted.
 *
 * If the `cancelRequested` flag returns `true`, a cancellation is
 * being attempted. If the worker can cancel the activity, it should respond with RespondActivityTaskCanceled. Otherwise, it should ignore the cancellation
 * request.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const recordActivityTaskHeartbeat: API.OperationMethod<RecordActivityTaskHeartbeatInput & RegionInput, ActivityTaskStatus, RecordActivityTaskHeartbeatError, Credentials | HttpClient.HttpClient>;
export type RegisterActivityTypeError = LimitExceededFault | OperationNotPermittedFault | TypeAlreadyExistsFault | UnknownResourceFault | CommonErrors;
/**
 * Registers a new *activity type* along with its configuration
 * settings in the specified domain.
 *
 * A `TypeAlreadyExists` fault is returned if the type already exists in the
 * domain. You cannot change any configuration settings of the type after its registration, and
 * it must be registered as a new version.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `defaultTaskList.name`: String constraint. The key is
 * `swf:defaultTaskList.name`.
 *
 * - `name`: String constraint. The key is `swf:name`.
 *
 * - `version`: String constraint. The key is
 * `swf:version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const registerActivityType: API.OperationMethod<RegisterActivityTypeInput & RegionInput, RegisterActivityTypeResponse, RegisterActivityTypeError, Credentials | HttpClient.HttpClient>;
export type RegisterDomainError = DomainAlreadyExistsFault | LimitExceededFault | OperationNotPermittedFault | TooManyTagsFault | CommonErrors;
/**
 * Registers a new domain.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - You cannot use an IAM policy to control domain access for this action. The name of
 * the domain being registered is available as the resource of this action.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const registerDomain: API.OperationMethod<RegisterDomainInput & RegionInput, RegisterDomainResponse, RegisterDomainError, Credentials | HttpClient.HttpClient>;
export type RegisterWorkflowTypeError = LimitExceededFault | OperationNotPermittedFault | TypeAlreadyExistsFault | UnknownResourceFault | CommonErrors;
/**
 * Registers a new *workflow type* and its configuration settings in
 * the specified domain.
 *
 * The retention period for the workflow history is set by the RegisterDomain action.
 *
 * If the type already exists, then a `TypeAlreadyExists` fault is returned.
 * You cannot change the configuration settings of a workflow type once it is registered and it
 * must be registered as a new version.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `defaultTaskList.name`: String constraint. The key is
 * `swf:defaultTaskList.name`.
 *
 * - `name`: String constraint. The key is `swf:name`.
 *
 * - `version`: String constraint. The key is
 * `swf:version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const registerWorkflowType: API.OperationMethod<RegisterWorkflowTypeInput & RegionInput, RegisterWorkflowTypeResponse, RegisterWorkflowTypeError, Credentials | HttpClient.HttpClient>;
export type RequestCancelWorkflowExecutionError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Records a `WorkflowExecutionCancelRequested` event in the currently running
 * workflow execution identified by the given domain, workflowId, and runId. This logically
 * requests the cancellation of the workflow execution as a whole. It is up to the decider to
 * take appropriate actions when it receives an execution history with this event.
 *
 * If the runId isn't specified, the `WorkflowExecutionCancelRequested` event
 * is recorded in the history of the current open workflow execution with the specified
 * workflowId in the domain.
 *
 * Because this action allows the workflow to properly clean up and gracefully close, it
 * should be used instead of TerminateWorkflowExecution when
 * possible.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const requestCancelWorkflowExecution: API.OperationMethod<RequestCancelWorkflowExecutionInput & RegionInput, RequestCancelWorkflowExecutionResponse, RequestCancelWorkflowExecutionError, Credentials | HttpClient.HttpClient>;
export type RespondActivityTaskCanceledError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Used by workers to tell the service that the ActivityTask identified
 * by the `taskToken` was successfully canceled. Additional `details` can
 * be provided using the `details` argument.
 *
 * These `details` (if provided) appear in the
 * `ActivityTaskCanceled` event added to the workflow history.
 *
 * Only use this operation if the `canceled` flag of a RecordActivityTaskHeartbeat request returns `true` and if the
 * activity can be safely undone or abandoned.
 *
 * A task is considered open from the time that it is scheduled until it is closed.
 * Therefore a task is reported as open while a worker is processing it. A task is closed after
 * it has been specified in a call to RespondActivityTaskCompleted,
 * RespondActivityTaskCanceled, RespondActivityTaskFailed, or the task has
 * timed
 * out.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const respondActivityTaskCanceled: API.OperationMethod<RespondActivityTaskCanceledInput & RegionInput, RespondActivityTaskCanceledResponse, RespondActivityTaskCanceledError, Credentials | HttpClient.HttpClient>;
export type RespondActivityTaskCompletedError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Used by workers to tell the service that the ActivityTask identified
 * by the `taskToken` completed successfully with a `result` (if provided).
 * The `result` appears in the `ActivityTaskCompleted` event in the
 * workflow history.
 *
 * If the requested task doesn't complete successfully, use RespondActivityTaskFailed instead. If the worker finds that the task is
 * canceled through the `canceled` flag returned by RecordActivityTaskHeartbeat, it should cancel the task, clean up and then call
 * RespondActivityTaskCanceled.
 *
 * A task is considered open from the time that it is scheduled until it is closed.
 * Therefore a task is reported as open while a worker is processing it. A task is closed after
 * it has been specified in a call to RespondActivityTaskCompleted, RespondActivityTaskCanceled, RespondActivityTaskFailed, or the
 * task has timed
 * out.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const respondActivityTaskCompleted: API.OperationMethod<RespondActivityTaskCompletedInput & RegionInput, RespondActivityTaskCompletedResponse, RespondActivityTaskCompletedError, Credentials | HttpClient.HttpClient>;
export type RespondActivityTaskFailedError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Used by workers to tell the service that the ActivityTask identified
 * by the `taskToken` has failed with `reason` (if specified). The
 * `reason` and `details` appear in the `ActivityTaskFailed`
 * event added to the workflow history.
 *
 * A task is considered open from the time that it is scheduled until it is closed.
 * Therefore a task is reported as open while a worker is processing it. A task is closed after
 * it has been specified in a call to RespondActivityTaskCompleted, RespondActivityTaskCanceled, RespondActivityTaskFailed, or the task has timed
 * out.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const respondActivityTaskFailed: API.OperationMethod<RespondActivityTaskFailedInput & RegionInput, RespondActivityTaskFailedResponse, RespondActivityTaskFailedError, Credentials | HttpClient.HttpClient>;
export type RespondDecisionTaskCompletedError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Used by deciders to tell the service that the DecisionTask identified
 * by the `taskToken` has successfully completed. The `decisions` argument
 * specifies the list of decisions made while processing the task.
 *
 * A `DecisionTaskCompleted` event is added to the workflow history. The
 * `executionContext` specified is attached to the event in the workflow execution
 * history.
 *
 * **Access Control**
 *
 * If an IAM policy grants permission to use `RespondDecisionTaskCompleted`, it
 * can express permissions for the list of decisions in the `decisions` parameter.
 * Each of the decisions has one or more parameters, much like a regular API call. To allow for
 * policies to be as readable as possible, you can express permissions on decisions as if they
 * were actual API calls, including applying conditions to some parameters. For more information,
 * see Using
 * IAM to Manage Access to Amazon SWF Workflows in the
 * *Amazon SWF Developer Guide*.
 */
export declare const respondDecisionTaskCompleted: API.OperationMethod<RespondDecisionTaskCompletedInput & RegionInput, RespondDecisionTaskCompletedResponse, RespondDecisionTaskCompletedError, Credentials | HttpClient.HttpClient>;
export type SignalWorkflowExecutionError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Records a `WorkflowExecutionSignaled` event in the workflow execution
 * history and creates a decision task for the workflow execution identified by the given domain,
 * workflowId and runId. The event is recorded with the specified user defined signalName and
 * input (if provided).
 *
 * If a runId isn't specified, then the `WorkflowExecutionSignaled` event is
 * recorded in the history of the current open workflow with the matching workflowId in the
 * domain.
 *
 * If the specified workflow execution isn't open, this method fails with
 * `UnknownResource`.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const signalWorkflowExecution: API.OperationMethod<SignalWorkflowExecutionInput & RegionInput, SignalWorkflowExecutionResponse, SignalWorkflowExecutionError, Credentials | HttpClient.HttpClient>;
export type StartWorkflowExecutionError = DefaultUndefinedFault | LimitExceededFault | OperationNotPermittedFault | TypeDeprecatedFault | UnknownResourceFault | WorkflowExecutionAlreadyStartedFault | CommonErrors;
/**
 * Starts an execution of the workflow type in the specified domain using the provided
 * `workflowId` and input data.
 *
 * This action returns the newly started workflow execution.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `tagList.member.0`: The key is `swf:tagList.member.0`.
 *
 * - `tagList.member.1`: The key is `swf:tagList.member.1`.
 *
 * - `tagList.member.2`: The key is `swf:tagList.member.2`.
 *
 * - `tagList.member.3`: The key is `swf:tagList.member.3`.
 *
 * - `tagList.member.4`: The key is `swf:tagList.member.4`.
 *
 * - `taskList`: String constraint. The key is
 * `swf:taskList.name`.
 *
 * - `workflowType.name`: String constraint. The key is
 * `swf:workflowType.name`.
 *
 * - `workflowType.version`: String constraint. The key is
 * `swf:workflowType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const startWorkflowExecution: API.OperationMethod<StartWorkflowExecutionInput & RegionInput, Run, StartWorkflowExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = LimitExceededFault | OperationNotPermittedFault | TooManyTagsFault | UnknownResourceFault | CommonErrors;
/**
 * Add a tag to a Amazon SWF domain.
 *
 * Amazon SWF supports a maximum of 50 tags per resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateWorkflowExecutionError = OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Records a `WorkflowExecutionTerminated` event and forces closure of the
 * workflow execution identified by the given domain, runId, and workflowId. The child policy,
 * registered with the workflow type or specified when starting this execution, is applied to any
 * open child workflow executions of this workflow execution.
 *
 * If the identified workflow execution was in progress, it is terminated
 * immediately.
 *
 * If a runId isn't specified, then the `WorkflowExecutionTerminated` event
 * is recorded in the history of the current open workflow with the matching workflowId in the
 * domain.
 *
 * You should consider using RequestCancelWorkflowExecution action
 * instead because it allows the workflow to gracefully close while TerminateWorkflowExecution doesn't.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const terminateWorkflowExecution: API.OperationMethod<TerminateWorkflowExecutionInput & RegionInput, TerminateWorkflowExecutionResponse, TerminateWorkflowExecutionError, Credentials | HttpClient.HttpClient>;
export type UndeprecateActivityTypeError = OperationNotPermittedFault | TypeAlreadyExistsFault | UnknownResourceFault | CommonErrors;
/**
 * Undeprecates a previously deprecated *activity type*. After an activity type has
 * been undeprecated, you can create new tasks of that activity type.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `activityType.name`: String constraint. The key is
 * `swf:activityType.name`.
 *
 * - `activityType.version`: String constraint. The key is
 * `swf:activityType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const undeprecateActivityType: API.OperationMethod<UndeprecateActivityTypeInput & RegionInput, UndeprecateActivityTypeResponse, UndeprecateActivityTypeError, Credentials | HttpClient.HttpClient>;
export type UndeprecateDomainError = DomainAlreadyExistsFault | OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Undeprecates a previously deprecated domain. After a domain has been undeprecated it can be used
 * to create new workflow executions or register new types.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - You cannot use an IAM policy to constrain this action's parameters.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const undeprecateDomain: API.OperationMethod<UndeprecateDomainInput & RegionInput, UndeprecateDomainResponse, UndeprecateDomainError, Credentials | HttpClient.HttpClient>;
export type UndeprecateWorkflowTypeError = OperationNotPermittedFault | TypeAlreadyExistsFault | UnknownResourceFault | CommonErrors;
/**
 * Undeprecates a previously deprecated *workflow type*. After a workflow type has
 * been undeprecated, you can create new executions of that type.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * exactly reflect recent updates and changes.
 *
 * **Access Control**
 *
 * You can use IAM policies to control this action's access to Amazon SWF resources as
 * follows:
 *
 * - Use a `Resource` element with the domain name to limit the action to
 * only specified domains.
 *
 * - Use an `Action` element to allow or deny permission to call this
 * action.
 *
 * - Constrain the following parameters by using a `Condition` element with
 * the appropriate keys.
 *
 * - `workflowType.name`: String constraint. The key is
 * `swf:workflowType.name`.
 *
 * - `workflowType.version`: String constraint. The key is
 * `swf:workflowType.version`.
 *
 * If the caller doesn't have sufficient permissions to invoke the action, or the
 * parameter values fall outside the specified constraints, the action fails. The associated
 * event attribute's `cause` parameter is set to `OPERATION_NOT_PERMITTED`.
 * For details and example IAM policies, see Using IAM to Manage Access to Amazon SWF
 * Workflows in the *Amazon SWF Developer Guide*.
 */
export declare const undeprecateWorkflowType: API.OperationMethod<UndeprecateWorkflowTypeInput & RegionInput, UndeprecateWorkflowTypeResponse, UndeprecateWorkflowTypeError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = LimitExceededFault | OperationNotPermittedFault | UnknownResourceFault | CommonErrors;
/**
 * Remove a tag from a Amazon SWF domain.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=swf.d.ts.map