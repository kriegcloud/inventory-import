import type { MigrationDialect } from "./Format.ts";
/** Matches drizzle-kit v1 migration directories: `YYYYMMDDHHMMSS_name`. */
export declare const DRIZZLE_DIR_PATTERN: RegExp;
/**
 * Parse a 14-digit `YYYYMMDDHHMMSS` prefix into UTC millis (drizzle's
 * `formatToMillis`). Returns undefined when the name has no such prefix.
 */
export declare const timestampPrefixMillis: (name: string) => number | undefined;
/**
 * Stringify a scalar value a driver returned (or a bookkeeping parameter).
 * Binary values (e.g. mysql `Buffer`s) decode as UTF-8.
 */
export declare const scalarText: (value: unknown) => string;
/**
 * Render a parameter as a SQL literal. Only used for Alchemy's own
 * bookkeeping queries (names, hashes, millis, ISO dates) against executors
 * without native parameter support (the D1 HTTP API and the local workerd
 * tunnel).
 */
export declare const sqlLiteral: (value: unknown, dialect?: MigrationDialect) => string;
/**
 * Inline `?` (sqlite/mysql) or `$n` (postgres) placeholders as SQL
 * literals. String scanning respects quoted spans so literal `?`s inside
 * strings survive.
 */
export declare const inlineSqlParams: (sql: string, params: ReadonlyArray<unknown>, dialect: MigrationDialect) => string;
/** Quote an identifier for the given dialect. */
export declare const quoteIdentifier: (identifier: string, dialect: MigrationDialect) => string;
/**
 * A bookkeeping column reference. GoogleSQL reserves `hash`, so its
 * columns are always quoted; other dialects keep the bare names.
 */
export declare const bookkeepingColumns: (dialect: MigrationDialect, ...columns: ReadonlyArray<string>) => string;
//# sourceMappingURL=Utils.d.ts.map