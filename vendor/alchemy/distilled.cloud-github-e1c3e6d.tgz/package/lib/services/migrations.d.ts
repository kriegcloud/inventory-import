import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface DeleteArchiveForAuthenticatedUserRequest {
    /** The unique identifier of the migration. */
    migration_id: number;
}
export interface DeleteArchiveForAuthenticatedUserResponse {
}
export interface DeleteArchiveForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the migration. */
    migration_id: number;
}
export interface DeleteArchiveForOrgResponse {
}
export interface DownloadArchiveForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the migration. */
    migration_id: number;
}
export interface DownloadArchiveForOrgResponse {
}
export interface GetArchiveForAuthenticatedUserRequest {
    /** The unique identifier of the migration. */
    migration_id: number;
}
export interface GetArchiveForAuthenticatedUserResponse {
}
export type GetStatusForAuthenticatedUserRequestExcludeList = Array<string>;
export interface GetStatusForAuthenticatedUserRequest {
    /** The unique identifier of the migration. */
    migration_id: number;
    exclude?: GetStatusForAuthenticatedUserRequestExcludeList | undefined;
}
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: NullableSimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
/** The repositories included in the migration. Only returned for export migrations. */
export type MigrationRepositoriesList = Array<Repository>;
/** Exclude related items from being returned in the response in order to improve performance of the request. The array can include any of: `"repositories"`. */
export type MigrationExcludeList = Array<string>;
/** A migration. */
export interface Migration {
    id: number;
    owner: NullableSimpleUser | null;
    guid: string;
    state: string;
    lock_repositories: boolean;
    exclude_metadata: boolean;
    exclude_git_data: boolean;
    exclude_attachments: boolean;
    exclude_releases: boolean;
    exclude_owner_projects: boolean;
    org_metadata_only: boolean;
    /** The repositories included in the migration. Only returned for export migrations. */
    repositories: MigrationRepositoriesList;
    url: string;
    created_at: string;
    updated_at: string;
    node_id: string;
    archive_url?: string | undefined;
    /** Exclude related items from being returned in the response in order to improve performance of the request. The array can include any of: `"repositories"`. */
    exclude?: MigrationExcludeList | undefined;
}
/** Allowed values that can be passed to the exclude param. */
export type GetStatusForOrgRequestExcludeItem = "repositories";
export type GetStatusForOrgRequestExcludeList = Array<GetStatusForOrgRequestExcludeItem | (string & {})>;
export interface GetStatusForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the migration. */
    migration_id: number;
    /** Exclude attributes from the API response to improve performance */
    exclude?: GetStatusForOrgRequestExcludeList | undefined;
}
export interface ListForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForAuthenticatedUserResponseBodyList = Array<Migration>;
export type ListForAuthenticatedUserResponse = ListForAuthenticatedUserResponseBodyList;
/** Allowed values that can be passed to the exclude param. */
export type ListForOrgRequestExcludeItem = "repositories";
export type ListForOrgRequestExcludeList = Array<ListForOrgRequestExcludeItem | (string & {})>;
export interface ListForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Exclude attributes from the API response to improve performance */
    exclude?: ListForOrgRequestExcludeList | undefined;
}
export type ListForOrgResponseBodyList = Array<Migration>;
export type ListForOrgResponse = ListForOrgResponseBodyList;
export interface ListReposForAuthenticatedUserRequest {
    /** The unique identifier of the migration. */
    migration_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: NullableSimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
export type ListReposForAuthenticatedUserResponseBodyList = Array<MinimalRepository>;
export type ListReposForAuthenticatedUserResponse = ListReposForAuthenticatedUserResponseBodyList;
export interface ListReposForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the migration. */
    migration_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReposForOrgResponseBodyList = Array<MinimalRepository>;
export type ListReposForOrgResponse = ListReposForOrgResponseBodyList;
/** Allowed values that can be passed to the exclude param. */
export type StartForAuthenticatedUserRequestExcludeItem = "repositories";
/** Exclude attributes from the API response to improve performance */
export type StartForAuthenticatedUserRequestExcludeList = Array<StartForAuthenticatedUserRequestExcludeItem | (string & {})>;
export type StartForAuthenticatedUserRequestRepositoriesList = Array<string>;
export interface StartForAuthenticatedUserRequest {
    /** Lock the repositories being migrated at the start of the migration */
    lock_repositories?: boolean | undefined;
    /** Indicates whether metadata should be excluded and only git source should be included for the migration. */
    exclude_metadata?: boolean | undefined;
    /** Indicates whether the repository git data should be excluded from the migration. */
    exclude_git_data?: boolean | undefined;
    /** Do not include attachments in the migration */
    exclude_attachments?: boolean | undefined;
    /** Do not include releases in the migration */
    exclude_releases?: boolean | undefined;
    /** Indicates whether projects owned by the organization or users should be excluded. */
    exclude_owner_projects?: boolean | undefined;
    /** Indicates whether this should only include organization metadata (repositories array should be empty and will ignore other flags). */
    org_metadata_only?: boolean | undefined;
    /** Exclude attributes from the API response to improve performance */
    exclude?: StartForAuthenticatedUserRequestExcludeList | undefined;
    repositories: StartForAuthenticatedUserRequestRepositoriesList;
}
/** A list of arrays indicating which repositories should be migrated. */
export type StartForOrgRequestRepositoriesList = Array<string>;
export type StartForOrgRequestExcludeItem = "repositories";
/** Exclude related items from being returned in the response in order to improve performance of the request. */
export type StartForOrgRequestExcludeList = Array<StartForOrgRequestExcludeItem | (string & {})>;
export interface StartForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** A list of arrays indicating which repositories should be migrated. */
    repositories: StartForOrgRequestRepositoriesList;
    /** Indicates whether repositories should be locked (to prevent manipulation) while migrating data. */
    lock_repositories?: boolean | undefined;
    /** Indicates whether metadata should be excluded and only git source should be included for the migration. */
    exclude_metadata?: boolean | undefined;
    /** Indicates whether the repository git data should be excluded from the migration. */
    exclude_git_data?: boolean | undefined;
    /** Indicates whether attachments should be excluded from the migration (to reduce migration archive file size). */
    exclude_attachments?: boolean | undefined;
    /** Indicates whether releases should be excluded from the migration (to reduce migration archive file size). */
    exclude_releases?: boolean | undefined;
    /** Indicates whether projects owned by the organization or users should be excluded. from the migration. */
    exclude_owner_projects?: boolean | undefined;
    /** Indicates whether this should only include organization metadata (repositories array should be empty and will ignore other flags). */
    org_metadata_only?: boolean | undefined;
    /** Exclude related items from being returned in the response in order to improve performance of the request. */
    exclude?: StartForOrgRequestExcludeList | undefined;
}
export interface UnlockRepoForAuthenticatedUserRequest {
    /** The unique identifier of the migration. */
    migration_id: number;
    /** repo_name parameter */
    repo_name: string;
}
export interface UnlockRepoForAuthenticatedUserResponse {
}
export interface UnlockRepoForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the migration. */
    migration_id: number;
    /** repo_name parameter */
    repo_name: string;
}
export interface UnlockRepoForOrgResponse {
}
export type DeleteArchiveForAuthenticatedUserError = GithubOpError;
/** Delete a user migration archive Deletes a previous migration archive. Downloadable migration archives are automatically deleted after seven days. Migration metadata, which is returned in the [List user migrations](https://docs.github.com/rest/migrations/users#list-user-migrations) and [Get a user migration status](https://docs.github.com/rest/migrations/users#get-a-user-migration-status) endpoints, will continue to be available even after an archive is deleted. */
export declare const deleteArchiveForAuthenticatedUser: API.OperationMethod<DeleteArchiveForAuthenticatedUserRequest, DeleteArchiveForAuthenticatedUserResponse, DeleteArchiveForAuthenticatedUserError, GithubOpContext>;
export type DeleteArchiveForOrgError = GithubOpError;
/** Delete an organization migration archive Deletes a previous migration archive. Migration archives are automatically deleted after seven days. */
export declare const deleteArchiveForOrg: API.OperationMethod<DeleteArchiveForOrgRequest, DeleteArchiveForOrgResponse, DeleteArchiveForOrgError, GithubOpContext>;
export type DownloadArchiveForOrgError = GithubOpError;
/** Download an organization migration archive Fetches the URL to a migration archive. */
export declare const downloadArchiveForOrg: API.OperationMethod<DownloadArchiveForOrgRequest, DownloadArchiveForOrgResponse, DownloadArchiveForOrgError, GithubOpContext>;
export type GetArchiveForAuthenticatedUserError = GithubOpError;
/** Download a user migration archive Fetches the URL to download the migration archive as a `tar.gz` file. Depending on the resources your repository uses, the migration archive can contain JSON files with data for these objects: * attachments * bases * commit\_comments * issue\_comments * issue\_events * issues * milestones * organizations * projects * protected\_branches * pull\_request\_reviews * pull\_requests * releases * repositories * review\_comments * schema * users The archive will also contain an `attachments` directory that includes all attachment files uploaded to GitHub.com and a `repositories` directory that contains the repository's Git data. */
export declare const getArchiveForAuthenticatedUser: API.OperationMethod<GetArchiveForAuthenticatedUserRequest, GetArchiveForAuthenticatedUserResponse, GetArchiveForAuthenticatedUserError, GithubOpContext>;
export type GetStatusForAuthenticatedUserError = GithubOpError;
/** Get a user migration status Fetches a single user migration. The response includes the `state` of the migration, which can be one of the following values: * `pending` - the migration hasn't started yet. * `exporting` - the migration is in progress. * `exported` - the migration finished successfully. * `failed` - the migration failed. Once the migration has been `exported` you can [download the migration archive](https://docs.github.com/rest/migrations/users#download-a-user-migration-archive). */
export declare const getStatusForAuthenticatedUser: API.OperationMethod<GetStatusForAuthenticatedUserRequest, Migration, GetStatusForAuthenticatedUserError, GithubOpContext>;
export type GetStatusForOrgError = GithubOpError;
/** Get an organization migration status Fetches the status of a migration. The `state` of a migration can be one of the following values: * `pending`, which means the migration hasn't started yet. * `exporting`, which means the migration is in progress. * `exported`, which means the migration finished successfully. * `failed`, which means the migration failed. */
export declare const getStatusForOrg: API.OperationMethod<GetStatusForOrgRequest, Migration, GetStatusForOrgError, GithubOpContext>;
export type ListForAuthenticatedUserError = GithubOpError;
/** List user migrations Lists all migrations a user has started. */
export declare const listForAuthenticatedUser: API.PaginatedOperationMethod<ListForAuthenticatedUserRequest, ListForAuthenticatedUserResponse, ListForAuthenticatedUserError, GithubOpContext, Migration>;
export type ListForOrgError = GithubOpError;
/** List organization migrations Lists the most recent migrations, including both exports (which can be started through the REST API) and imports (which cannot be started using the REST API). A list of `repositories` is only returned for export migrations. */
export declare const listForOrg: API.PaginatedOperationMethod<ListForOrgRequest, ListForOrgResponse, ListForOrgError, GithubOpContext, Migration>;
export type ListReposForAuthenticatedUserError = GithubOpError;
/** List repositories for a user migration Lists all the repositories for this user migration. */
export declare const listReposForAuthenticatedUser: API.PaginatedOperationMethod<ListReposForAuthenticatedUserRequest, ListReposForAuthenticatedUserResponse, ListReposForAuthenticatedUserError, GithubOpContext, MinimalRepository>;
export type ListReposForOrgError = GithubOpError;
/** List repositories in an organization migration List all the repositories for this organization migration. */
export declare const listReposForOrg: API.PaginatedOperationMethod<ListReposForOrgRequest, ListReposForOrgResponse, ListReposForOrgError, GithubOpContext, MinimalRepository>;
export type StartForAuthenticatedUserError = GithubOpError;
/** Start a user migration Initiates the generation of a user migration archive. */
export declare const startForAuthenticatedUser: API.OperationMethod<StartForAuthenticatedUserRequest, Migration, StartForAuthenticatedUserError, GithubOpContext>;
export type StartForOrgError = GithubOpError;
/** Start an organization migration Initiates the generation of a migration archive. */
export declare const startForOrg: API.OperationMethod<StartForOrgRequest, Migration, StartForOrgError, GithubOpContext>;
export type UnlockRepoForAuthenticatedUserError = GithubOpError;
/** Unlock a user repository Unlocks a repository. You can lock repositories when you [start a user migration](https://docs.github.com/rest/migrations/users#start-a-user-migration). Once the migration is complete you can unlock each repository to begin using it again or [delete the repository](https://docs.github.com/rest/repos/repos#delete-a-repository) if you no longer need the source data. Returns a status of `404 Not Found` if the repository is not locked. */
export declare const unlockRepoForAuthenticatedUser: API.OperationMethod<UnlockRepoForAuthenticatedUserRequest, UnlockRepoForAuthenticatedUserResponse, UnlockRepoForAuthenticatedUserError, GithubOpContext>;
export type UnlockRepoForOrgError = GithubOpError;
/** Unlock an organization repository Unlocks a repository that was locked for migration. You should unlock each migrated repository and [delete them](https://docs.github.com/rest/repos/repos#delete-a-repository) when the migration is complete and you no longer need the source data. */
export declare const unlockRepoForOrg: API.OperationMethod<UnlockRepoForOrgRequest, UnlockRepoForOrgResponse, UnlockRepoForOrgError, GithubOpContext>;
//# sourceMappingURL=migrations.d.ts.map