import * as DateTime from "effect/DateTime";
import type { Asked, Story } from "./ModelSearch.ts";
/** One step of a `Story`, as data: what the text and the real steps are both made from. */
export type Op = {
    readonly _tag: "Provide";
    readonly name: string;
    readonly tag: unknown;
    readonly value: unknown;
} | {
    readonly _tag: "Clock";
    readonly at: DateTime.Utc;
} | {
    readonly _tag: "When";
    readonly aggregate: string;
    readonly id: string;
    readonly command: unknown;
} | {
    readonly _tag: "Rejected";
    readonly rejection: unknown;
} | {
    readonly _tag: "Call";
    readonly asked: Asked;
} | {
    readonly _tag: "Answer";
    readonly asked: Asked;
} | {
    readonly _tag: "Then";
    readonly aggregate: string;
    readonly id: string;
    readonly events: ReadonlyArray<unknown>;
} | {
    readonly _tag: "Note";
    readonly text: string;
};
/**
 * A story the explorer found, as the steps of a `Story`. A story stops where
 * what it shows happened; a `Story` has to account for everything the model
 * does, so the steps go on to the end of the sequence the story is the start
 * of.
 */
export declare const ops: (shown: Story) => ReadonlyArray<Op>;
/**
 * Whether a story needs something a `Story` does not do: an event delivered
 * twice, a saga's step run twice, or a scheduled command that runs late.
 */
export declare const redelivers: (shown: Story) => boolean;
/**
 * A story the explorer found, as the code of a `Story` test: paste it in,
 * import what it names, and the sequence runs on the whole model in memory.
 */
export declare const script: (story: Story) => string;
//# sourceMappingURL=Script.d.ts.map