import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const NotSupportedOperationException_base: S.TaggedErrorClass<"NotSupportedOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotSupportedOperationException extends /*@__PURE__*/ NotSupportedOperationException_base {
}
declare const RangeNotSatisfiableException_base: S.TaggedErrorClass<"RangeNotSatisfiableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RangeNotSatisfiableException extends /*@__PURE__*/ RangeNotSatisfiableException_base {
}
declare const RequestTimeoutException_base: S.TaggedErrorClass<"RequestTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestTimeoutException extends /*@__PURE__*/ RequestTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SequenceStoreId = string;
export type UploadId = string;
export interface AbortMultipartReadSetUploadRequest {
    sequenceStoreId: string;
    uploadId: string;
}
export interface AbortMultipartReadSetUploadResponse {
}
export interface AcceptShareRequest {
    shareId: string;
}
export type ShareStatus = string;
export interface AcceptShareResponse {
    status?: string | undefined;
}
export type ReadSetId = string;
export type ReadSetIdList = string[];
export interface BatchDeleteReadSetRequest {
    ids: string[];
    sequenceStoreId: string;
}
export interface ReadSetBatchError {
    id: string;
    code: string;
    message: string;
}
export type ReadSetBatchErrorList = ReadSetBatchError[];
export interface BatchDeleteReadSetResponse {
    errors?: ReadSetBatchError[] | undefined;
}
export type ResourceId = string;
export interface CancelAnnotationImportRequest {
    jobId: string;
}
export interface CancelAnnotationImportResponse {
}
export type RunId = string;
export interface CancelRunRequest {
    id: string;
}
export interface CancelRunResponse {
}
export type BatchId = string;
export interface CancelRunBatchRequest {
    batchId: string;
}
export interface CancelRunBatchResponse {
}
export interface CancelVariantImportRequest {
    jobId: string;
}
export interface CancelVariantImportResponse {
}
export type ReadSetPartSource = string;
export interface CompleteReadSetUploadPartListItem {
    partNumber: number;
    partSource: string;
    checksum: string;
}
export type CompleteReadSetUploadPartList = CompleteReadSetUploadPartListItem[];
export interface CompleteMultipartReadSetUploadRequest {
    sequenceStoreId: string;
    uploadId: string;
    parts: CompleteReadSetUploadPartListItem[];
}
export interface CompleteMultipartReadSetUploadResponse {
    readSetId: string;
}
export type ReferenceArn = string;
export type ReferenceItem = {
    referenceArn: string;
};
export type StoreName = string;
export type Description = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type VersionName = string;
export type EncryptionType = string;
export interface SseConfig {
    type: string;
    keyArn?: string | undefined;
}
export type StoreFormat = string;
export type AnnotationType = string;
export type FormatToHeaderKey = string;
export type FormatToHeader = {
    [key: string]: string | undefined;
};
export type SchemaValueType = string;
export type SchemaItem = {
    [key: string]: string | undefined;
};
export type Schema = {
    [key: string]: string | undefined;
}[];
export interface TsvStoreOptions {
    annotationType?: string | undefined;
    formatToHeader?: {
        [key: string]: string | undefined;
    } | undefined;
    schema?: {
        [key: string]: string | undefined;
    }[] | undefined;
}
export type StoreOptions = {
    tsvStoreOptions: TsvStoreOptions;
};
export interface CreateAnnotationStoreRequest {
    reference?: ReferenceItem | undefined;
    name?: string | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    versionName?: string | undefined;
    sseConfig?: SseConfig | undefined;
    storeFormat: string;
    storeOptions?: StoreOptions | undefined;
}
export type StoreStatus = string;
export type CreationTime = Date;
export interface CreateAnnotationStoreResponse {
    id: string;
    reference?: ReferenceItem | undefined;
    storeFormat?: string | undefined;
    storeOptions?: StoreOptions | undefined;
    status: string;
    name: string;
    versionName: string;
    creationTime: Date;
}
export interface TsvVersionOptions {
    annotationType?: string | undefined;
    formatToHeader?: {
        [key: string]: string | undefined;
    } | undefined;
    schema?: {
        [key: string]: string | undefined;
    }[] | undefined;
}
export type VersionOptions = {
    tsvVersionOptions: TsvVersionOptions;
};
export interface CreateAnnotationStoreVersionRequest {
    name: string;
    versionName: string;
    description?: string | undefined;
    versionOptions?: VersionOptions | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VersionStatus = string;
export interface CreateAnnotationStoreVersionResponse {
    id: string;
    versionName: string;
    storeId: string;
    versionOptions?: VersionOptions | undefined;
    name: string;
    status: string;
    creationTime: Date;
}
export type ConfigurationName = string;
export type ConfigurationDescription = string;
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type SubnetId = string;
export type SubnetIds = string[];
export type AwsAccountId = string;
export interface VpcConfig {
    securityGroupIds?: string[] | undefined;
    subnetIds?: string[] | undefined;
    vpcOwnerAccountId?: string | undefined;
}
export interface RunConfigurations {
    vpcConfig?: VpcConfig | undefined;
}
export type ConfigurationRequestId = string;
export interface CreateConfigurationRequest {
    name: string;
    description?: string | undefined;
    runConfigurations: RunConfigurations;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    requestId: string;
}
export type ConfigurationArn = string;
export type ConfigurationUuid = string;
export type VpcId = string;
export interface VpcConfigResponse {
    securityGroupIds?: string[] | undefined;
    subnetIds?: string[] | undefined;
    vpcId?: string | undefined;
    vpcOwnerAccountId?: string | undefined;
}
export interface RunConfigurationsResponse {
    vpcConfig?: VpcConfigResponse | undefined;
}
export type ConfigurationStatus = string;
export type ConfigurationTimestamp = Date;
export interface CreateConfigurationResponse {
    arn?: string | undefined;
    uuid?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    runConfigurations?: RunConfigurationsResponse | undefined;
    status?: string | undefined;
    creationTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ClientToken = string;
export type FileType = string;
export type SubjectId = string;
export type SampleId = string;
export type GeneratedFrom = string;
export type ReadSetName = string;
export type ReadSetDescription = string;
export interface CreateMultipartReadSetUploadRequest {
    sequenceStoreId: string;
    clientToken?: string | undefined;
    sourceFileType: string;
    subjectId: string;
    sampleId: string;
    generatedFrom?: string | undefined;
    referenceArn?: string | undefined;
    name: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateMultipartReadSetUploadResponse {
    sequenceStoreId: string;
    uploadId: string;
    sourceFileType: string;
    subjectId: string;
    sampleId: string;
    generatedFrom?: string | undefined;
    referenceArn: string;
    name?: string | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    creationTime: Date;
}
export type ReferenceStoreName = string;
export type ReferenceStoreDescription = string;
export interface CreateReferenceStoreRequest {
    name: string;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export type ReferenceStoreId = string;
export type ReferenceStoreArn = string;
export interface CreateReferenceStoreResponse {
    id: string;
    arn: string;
    name?: string | undefined;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    creationTime: Date;
}
export type CacheBehavior = string;
export type S3UriForBucketOrObject = string;
export type UserCustomDescription = string;
export type UserCustomName = string;
export type RunCacheRequestId = string;
export interface CreateRunCacheRequest {
    cacheBehavior?: string | undefined;
    cacheS3Location: string;
    description?: string | undefined;
    name?: string | undefined;
    requestId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    cacheBucketOwnerId?: string | undefined;
}
export type RunCacheArn = string;
export type RunCacheId = string;
export type RunCacheStatus = string;
export interface CreateRunCacheResponse {
    arn?: string | undefined;
    id?: string | undefined;
    status?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RunGroupName = string;
export type RunGroupRequestId = string;
export interface CreateRunGroupRequest {
    name?: string | undefined;
    maxCpus?: number | undefined;
    maxRuns?: number | undefined;
    maxDuration?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    requestId: string;
    maxGpus?: number | undefined;
}
export type RunGroupArn = string;
export type RunGroupId = string;
export interface CreateRunGroupResponse {
    arn?: string | undefined;
    id?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SequenceStoreName = string;
export type SequenceStoreDescription = string;
export type FallbackLocation = string;
export type ETagAlgorithmFamily = string;
export type PropagatedSetLevelTags = string[];
export type AccessLogLocation = string;
export interface S3AccessConfig {
    accessLogLocation?: string | undefined;
}
export interface CreateSequenceStoreRequest {
    name: string;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
    fallbackLocation?: string | undefined;
    eTagAlgorithmFamily?: string | undefined;
    propagatedSetLevelTags?: string[] | undefined;
    s3AccessConfig?: S3AccessConfig | undefined;
}
export type SequenceStoreArn = string;
export type SequenceStoreStatus = string;
export type SequenceStoreStatusMessage = string;
export type S3Uri = string;
export type S3AccessPointArn = string;
export interface SequenceStoreS3Access {
    s3Uri?: string | undefined;
    s3AccessPointArn?: string | undefined;
    accessLogLocation?: string | undefined;
}
export interface CreateSequenceStoreResponse {
    id: string;
    arn: string;
    name?: string | undefined;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    creationTime: Date;
    fallbackLocation?: string | undefined;
    eTagAlgorithmFamily?: string | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    propagatedSetLevelTags?: string[] | undefined;
    s3Access?: SequenceStoreS3Access | undefined;
}
export type ShareName = string;
export interface CreateShareRequest {
    resourceArn: string;
    principalSubscriber: string;
    shareName?: string | undefined;
}
export interface CreateShareResponse {
    shareId?: string | undefined;
    status?: string | undefined;
    shareName?: string | undefined;
}
export interface CreateVariantStoreRequest {
    reference: ReferenceItem;
    name?: string | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    sseConfig?: SseConfig | undefined;
}
export interface CreateVariantStoreResponse {
    id: string;
    reference?: ReferenceItem | undefined;
    status: string;
    name: string;
    creationTime: Date;
}
export type WorkflowName = string;
export type WorkflowDescription = string;
export type WorkflowEngine = string;
export type WorkflowDefinition = string;
export type WorkflowMain = string;
export type WorkflowParameterName = string;
export type WorkflowParameterDescription = string;
export interface WorkflowParameter {
    description?: string | undefined;
    optional?: boolean | undefined;
}
export type WorkflowParameterTemplate = {
    [key: string]: WorkflowParameter | undefined;
};
export type WorkflowRequestId = string;
export type Accelerators = string;
export type StorageType = string;
export type Uri = string;
export type EcrRepositoryPrefix = string;
export type UpstreamRepositoryPrefix = string;
export type SecretArn = string;
export interface RegistryMapping {
    upstreamRegistryUrl?: string | undefined;
    ecrRepositoryPrefix?: string | undefined;
    upstreamRepositoryPrefix?: string | undefined;
    ecrAccountId?: string | undefined;
    credentialArn?: string | undefined;
}
export type RegistryMappingsList = RegistryMapping[];
export interface ImageMapping {
    sourceImage?: string | undefined;
    destinationImage?: string | undefined;
}
export type ImageMappingsList = ImageMapping[];
export interface ContainerRegistryMap {
    registryMappings?: RegistryMapping[] | undefined;
    imageMappings?: ImageMapping[] | undefined;
}
export type ReadmeMarkdown = string;
export type ParameterTemplatePath = string;
export type ReadmePath = string;
export type ConnectionArn = string;
export type FullRepositoryId = string;
export type SourceReferenceType = string;
export type SourceReferenceValue = string;
export interface SourceReference {
    type: string;
    value: string;
}
export type ExcludeFilePatternList = string[];
export interface DefinitionRepository {
    connectionArn: string;
    fullRepositoryId: string;
    sourceReference?: SourceReference | undefined;
    excludeFilePatterns?: string[] | undefined;
}
export type WorkflowBucketOwnerId = string;
export type S3UriForObject = string;
export interface CreateWorkflowRequest {
    name?: string | undefined;
    description?: string | undefined;
    engine?: string | undefined;
    definitionZip?: Uint8Array | undefined;
    definitionUri?: string | undefined;
    main?: string | undefined;
    parameterTemplate?: {
        [key: string]: WorkflowParameter | undefined;
    } | undefined;
    storageCapacity?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    requestId: string;
    accelerators?: string | undefined;
    storageType?: string | undefined;
    containerRegistryMap?: ContainerRegistryMap | undefined;
    containerRegistryMapUri?: string | undefined;
    readmeMarkdown?: string | undefined;
    parameterTemplatePath?: string | undefined;
    readmePath?: string | undefined;
    definitionRepository?: DefinitionRepository | undefined;
    workflowBucketOwnerId?: string | undefined;
    readmeUri?: string | undefined;
}
export type WorkflowArn = string;
export type WorkflowId = string;
export type WorkflowStatus = string;
export type WorkflowUuid = string;
export interface CreateWorkflowResponse {
    arn?: string | undefined;
    id?: string | undefined;
    status?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    uuid?: string | undefined;
}
export type WorkflowVersionName = string;
export type WorkflowVersionDescription = string;
export interface CreateWorkflowVersionRequest {
    workflowId: string;
    versionName: string;
    definitionZip?: Uint8Array | undefined;
    definitionUri?: string | undefined;
    accelerators?: string | undefined;
    description?: string | undefined;
    engine?: string | undefined;
    main?: string | undefined;
    parameterTemplate?: {
        [key: string]: WorkflowParameter | undefined;
    } | undefined;
    requestId: string;
    storageType?: string | undefined;
    storageCapacity?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    workflowBucketOwnerId?: string | undefined;
    containerRegistryMap?: ContainerRegistryMap | undefined;
    containerRegistryMapUri?: string | undefined;
    readmeMarkdown?: string | undefined;
    parameterTemplatePath?: string | undefined;
    readmePath?: string | undefined;
    definitionRepository?: DefinitionRepository | undefined;
    readmeUri?: string | undefined;
}
export type WorkflowVersionArn = string;
export interface CreateWorkflowVersionResponse {
    arn?: string | undefined;
    workflowId?: string | undefined;
    versionName?: string | undefined;
    status?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    uuid?: string | undefined;
}
export interface DeleteAnnotationStoreRequest {
    name: string;
    force?: boolean | undefined;
}
export interface DeleteAnnotationStoreResponse {
    status: string;
}
export type VersionList = string[];
export interface DeleteAnnotationStoreVersionsRequest {
    name: string;
    versions: string[];
    force?: boolean | undefined;
}
export interface VersionDeleteError {
    versionName: string;
    message: string;
}
export type VersionDeleteErrorList = VersionDeleteError[];
export interface DeleteAnnotationStoreVersionsResponse {
    errors?: VersionDeleteError[] | undefined;
}
export interface DeleteBatchRequest {
    batchId: string;
}
export interface DeleteBatchResponse {
}
export interface DeleteConfigurationRequest {
    name: string;
}
export interface DeleteConfigurationResponse {
}
export type ReferenceId = string;
export interface DeleteReferenceRequest {
    id: string;
    referenceStoreId: string;
}
export interface DeleteReferenceResponse {
}
export interface DeleteReferenceStoreRequest {
    id: string;
}
export interface DeleteReferenceStoreResponse {
}
export interface DeleteRunRequest {
    id: string;
}
export interface DeleteRunResponse {
}
export interface DeleteRunBatchRequest {
    batchId: string;
}
export interface DeleteRunBatchResponse {
}
export interface DeleteRunCacheRequest {
    id: string;
}
export interface DeleteRunCacheResponse {
}
export interface DeleteRunGroupRequest {
    id: string;
}
export interface DeleteRunGroupResponse {
}
export interface DeleteS3AccessPolicyRequest {
    s3AccessPointArn: string;
}
export interface DeleteS3AccessPolicyResponse {
}
export interface DeleteSequenceStoreRequest {
    id: string;
}
export interface DeleteSequenceStoreResponse {
}
export interface DeleteShareRequest {
    shareId: string;
}
export interface DeleteShareResponse {
    status?: string | undefined;
}
export interface DeleteVariantStoreRequest {
    name: string;
    force?: boolean | undefined;
}
export interface DeleteVariantStoreResponse {
    status: string;
}
export interface DeleteWorkflowRequest {
    id: string;
}
export interface DeleteWorkflowResponse {
}
export interface DeleteWorkflowVersionRequest {
    workflowId: string;
    versionName: string;
}
export interface DeleteWorkflowVersionResponse {
}
export interface GetAnnotationImportRequest {
    jobId: string;
}
export type Arn = string;
export type JobStatus = string;
export type JobStatusMsg = string;
export type UpdateTime = Date;
export type CompletionTime = Date;
export interface AnnotationImportItemDetail {
    source: string;
    jobStatus: string;
}
export type AnnotationImportItemDetails = AnnotationImportItemDetail[];
export type RunLeftNormalization = boolean;
export type Separator = string;
export type Encoding = string;
export type Quote = string;
export type QuoteAll = boolean;
export type EscapeChar = string;
export type EscapeQuotes = boolean;
export type CommentChar = string;
export type Header = boolean;
export type LineSep = string;
export interface ReadOptions {
    sep?: string | undefined;
    encoding?: string | undefined;
    quote?: string | undefined;
    quoteAll?: boolean | undefined;
    escape?: string | undefined;
    escapeQuotes?: boolean | undefined;
    comment?: string | undefined;
    header?: boolean | undefined;
    lineSep?: string | undefined;
}
export interface TsvOptions {
    readOptions?: ReadOptions | undefined;
}
export interface VcfOptions {
    ignoreQualField?: boolean | undefined;
    ignoreFilterField?: boolean | undefined;
}
export type FormatOptions = {
    tsvOptions: TsvOptions;
    vcfOptions?: undefined;
} | {
    tsvOptions?: undefined;
    vcfOptions: VcfOptions;
};
export type AnnotationFieldMap = {
    [key: string]: string | undefined;
};
export interface GetAnnotationImportResponse {
    id: string;
    destinationName: string;
    versionName: string;
    roleArn: string;
    status: string;
    statusMessage: string;
    creationTime: Date;
    updateTime: Date;
    completionTime: Date;
    items: AnnotationImportItemDetail[];
    runLeftNormalization: boolean;
    formatOptions: FormatOptions;
    annotationFields?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetAnnotationStoreRequest {
    name: string;
}
export type StatusMessage = string;
export interface GetAnnotationStoreResponse {
    id: string;
    reference: ReferenceItem;
    status: string;
    storeArn: string;
    name: string;
    description: string;
    sseConfig: SseConfig;
    creationTime: Date;
    updateTime: Date;
    tags: {
        [key: string]: string | undefined;
    };
    storeOptions?: StoreOptions | undefined;
    storeFormat?: string | undefined;
    statusMessage: string;
    storeSizeBytes: number;
    numVersions: number;
}
export interface GetAnnotationStoreVersionRequest {
    name: string;
    versionName: string;
}
export interface GetAnnotationStoreVersionResponse {
    storeId: string;
    id: string;
    status: string;
    versionArn: string;
    name: string;
    versionName: string;
    description: string;
    creationTime: Date;
    updateTime: Date;
    tags: {
        [key: string]: string | undefined;
    };
    versionOptions?: VersionOptions | undefined;
    statusMessage: string;
    versionSizeBytes: number;
}
export interface GetBatchRequest {
    batchId: string;
}
export type BatchArn = string;
export type BatchUuid = string;
export type BatchName = string;
export type BatchStatus = string;
export type WorkflowType = string;
export type RunRoleArn = string;
export type RunName = string;
export type NumericIdInArn = string;
export type RunParameters = unknown;
export type RunOutputUri = string;
export type RunLogLevel = string;
export type RunRetentionMode = string;
export type WorkflowOwnerId = string;
export type NetworkingMode = string;
export type SessionPolicy = string;
export type EngineSettings = unknown;
export type ScratchStorageMode = string;
export interface DefaultRunSetting {
    workflowId: string;
    workflowType?: string | undefined;
    roleArn: string;
    name?: string | undefined;
    cacheId?: string | undefined;
    cacheBehavior?: string | undefined;
    runGroupId?: string | undefined;
    priority?: number | undefined;
    parameters?: any | undefined;
    storageCapacity?: number | undefined;
    outputUri?: string | undefined;
    logLevel?: string | undefined;
    runTags?: {
        [key: string]: string | undefined;
    } | undefined;
    retentionMode?: string | undefined;
    storageType?: string | undefined;
    workflowOwnerId?: string | undefined;
    outputBucketOwnerId?: string | undefined;
    workflowVersionName?: string | undefined;
    networkingMode?: string | undefined;
    configurationName?: string | undefined;
    sessionPolicy?: string | undefined;
    engineSettings?: any | undefined;
    scratchStorageMode?: string | undefined;
}
export interface SubmissionSummary {
    successfulStartSubmissionCount?: number | undefined;
    failedStartSubmissionCount?: number | undefined;
    pendingStartSubmissionCount?: number | undefined;
    successfulCancelSubmissionCount?: number | undefined;
    failedCancelSubmissionCount?: number | undefined;
    successfulDeleteSubmissionCount?: number | undefined;
    failedDeleteSubmissionCount?: number | undefined;
}
export interface RunSummary {
    pendingRunCount?: number | undefined;
    startingRunCount?: number | undefined;
    runningRunCount?: number | undefined;
    stoppingRunCount?: number | undefined;
    completedRunCount?: number | undefined;
    deletedRunCount?: number | undefined;
    failedRunCount?: number | undefined;
    cancelledRunCount?: number | undefined;
}
export type BatchTimestamp = Date;
export interface GetBatchResponse {
    id?: string | undefined;
    arn?: string | undefined;
    uuid?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    totalRuns?: number | undefined;
    defaultRunSetting?: DefaultRunSetting | undefined;
    submissionSummary?: SubmissionSummary | undefined;
    runSummary?: RunSummary | undefined;
    creationTime?: Date | undefined;
    submittedTime?: Date | undefined;
    processedTime?: Date | undefined;
    failedTime?: Date | undefined;
    failureReason?: string | undefined;
}
export interface GetConfigurationRequest {
    name: string;
}
export interface GetConfigurationResponse {
    arn?: string | undefined;
    uuid?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    runConfigurations?: RunConfigurationsResponse | undefined;
    status?: string | undefined;
    creationTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ReadSetFile = string;
export interface GetReadSetRequest {
    id: string;
    sequenceStoreId: string;
    file?: string | undefined;
    partNumber: number;
}
export interface GetReadSetResponse {
    payload?: T.StreamingOutputBody | undefined;
}
export type ActivationJobId = string;
export interface GetReadSetActivationJobRequest {
    id: string;
    sequenceStoreId: string;
}
export type ReadSetActivationJobStatus = string;
export type JobStatusMessage = string;
export type ReadSetActivationJobItemStatus = string;
export interface ActivateReadSetSourceItem {
    readSetId: string;
    status: string;
    statusMessage?: string | undefined;
}
export type ActivateReadSetSourceList = ActivateReadSetSourceItem[];
export interface GetReadSetActivationJobResponse {
    id: string;
    sequenceStoreId: string;
    status: string;
    statusMessage?: string | undefined;
    creationTime: Date;
    completionTime?: Date | undefined;
    sources?: ActivateReadSetSourceItem[] | undefined;
}
export type ExportJobId = string;
export interface GetReadSetExportJobRequest {
    sequenceStoreId: string;
    id: string;
}
export type S3Destination = string;
export type ReadSetExportJobStatus = string;
export type ReadSetExportJobItemStatus = string;
export interface ExportReadSetDetail {
    id: string;
    status: string;
    statusMessage?: string | undefined;
}
export type ExportReadSetDetailList = ExportReadSetDetail[];
export interface GetReadSetExportJobResponse {
    id: string;
    sequenceStoreId: string;
    destination: string;
    status: string;
    statusMessage?: string | undefined;
    creationTime: Date;
    completionTime?: Date | undefined;
    readSets?: ExportReadSetDetail[] | undefined;
}
export type ImportJobId = string;
export interface GetReadSetImportJobRequest {
    id: string;
    sequenceStoreId: string;
}
export type RoleArn = string;
export type ReadSetImportJobStatus = string;
export interface SourceFiles {
    source1: string;
    source2?: string | undefined;
}
export type ReadSetImportJobItemStatus = string;
export interface ImportReadSetSourceItem {
    sourceFiles: SourceFiles;
    sourceFileType: string;
    status: string;
    statusMessage?: string | undefined;
    subjectId: string;
    sampleId: string;
    generatedFrom?: string | undefined;
    referenceArn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    readSetId?: string | undefined;
}
export type ImportReadSetSourceList = ImportReadSetSourceItem[];
export interface GetReadSetImportJobResponse {
    id: string;
    sequenceStoreId: string;
    roleArn: string;
    status: string;
    statusMessage?: string | undefined;
    creationTime: Date;
    completionTime?: Date | undefined;
    sources: ImportReadSetSourceItem[];
}
export interface GetReadSetMetadataRequest {
    id: string;
    sequenceStoreId: string;
}
export type ReadSetArn = string;
export type ReadSetStatus = string;
export interface SequenceInformation {
    totalReadCount?: number | undefined;
    totalBaseCount?: number | undefined;
    generatedFrom?: string | undefined;
    alignment?: string | undefined;
}
export interface ReadSetS3Access {
    s3Uri?: string | undefined;
}
export interface FileInformation {
    totalParts?: number | undefined;
    partSize?: number | undefined;
    contentLength?: number | undefined;
    s3Access?: ReadSetS3Access | undefined;
}
export interface ReadSetFiles {
    source1?: FileInformation | undefined;
    source2?: FileInformation | undefined;
    index?: FileInformation | undefined;
}
export type ReadSetStatusMessage = string;
export type CreationType = string;
export type ETagAlgorithm = string;
export interface ETag {
    algorithm?: string | undefined;
    source1?: string | undefined;
    source2?: string | undefined;
}
export type CreationJobId = string;
export interface GetReadSetMetadataResponse {
    id: string;
    arn: string;
    sequenceStoreId: string;
    subjectId?: string | undefined;
    sampleId?: string | undefined;
    status: string;
    name?: string | undefined;
    description?: string | undefined;
    fileType: string;
    creationTime: Date;
    sequenceInformation?: SequenceInformation | undefined;
    referenceArn?: string | undefined;
    files?: ReadSetFiles | undefined;
    statusMessage?: string | undefined;
    creationType?: string | undefined;
    etag?: ETag | undefined;
    creationJobId?: string | undefined;
}
export type Range = string;
export type ReferenceFile = string;
export interface GetReferenceRequest {
    id: string;
    referenceStoreId: string;
    range?: string | undefined;
    partNumber: number;
    file?: string | undefined;
}
export interface GetReferenceResponse {
    payload?: T.StreamingOutputBody | undefined;
}
export interface GetReferenceImportJobRequest {
    id: string;
    referenceStoreId: string;
}
export type ReferenceImportJobStatus = string;
export type ReferenceImportJobItemStatus = string;
export type ReferenceName = string;
export type ReferenceDescription = string;
export interface ImportReferenceSourceItem {
    sourceFile?: string | undefined;
    status: string;
    statusMessage?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    referenceId?: string | undefined;
}
export type ImportReferenceSourceList = ImportReferenceSourceItem[];
export interface GetReferenceImportJobResponse {
    id: string;
    referenceStoreId: string;
    roleArn: string;
    status: string;
    statusMessage?: string | undefined;
    creationTime: Date;
    completionTime?: Date | undefined;
    sources: ImportReferenceSourceItem[];
}
export interface GetReferenceMetadataRequest {
    id: string;
    referenceStoreId: string;
}
export type Md5 = string;
export type ReferenceStatus = string;
export interface ReferenceFiles {
    source?: FileInformation | undefined;
    index?: FileInformation | undefined;
}
export type ReferenceCreationType = string;
export interface GetReferenceMetadataResponse {
    id: string;
    arn: string;
    referenceStoreId: string;
    md5: string;
    status?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    creationTime: Date;
    updateTime: Date;
    files?: ReferenceFiles | undefined;
    creationType?: string | undefined;
    creationJobId?: string | undefined;
}
export interface GetReferenceStoreRequest {
    id: string;
}
export interface GetReferenceStoreResponse {
    id: string;
    arn: string;
    name?: string | undefined;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    creationTime: Date;
}
export type RunExport = string;
export type RunExportList = string[];
export interface GetRunRequest {
    id: string;
    export?: string[] | undefined;
}
export type RunArn = string;
export type EngineVersion = string;
export type RunStatus = string;
export type WorkflowDigest = string;
export type RunResourceDigestKey = string;
export type RunResourceDigest = string;
export type RunResourceDigests = {
    [key: string]: string | undefined;
};
export type RunStartedBy = string;
export type RunTimestamp = Date;
export type RunStatusMessage = string;
export type RunFailureReason = string;
export type EngineLogStream = string;
export type RunLogStream = string;
export interface RunLogLocation {
    engineLogStream?: string | undefined;
    runLogStream?: string | undefined;
}
export type RunUuid = string;
export interface ConfigurationDetails {
    name?: string | undefined;
    arn?: string | undefined;
    uuid?: string | undefined;
}
export type RunOutputUriPrefixMode = string;
export interface GetRunResponse {
    arn?: string | undefined;
    id?: string | undefined;
    cacheId?: string | undefined;
    cacheBehavior?: string | undefined;
    engineVersion?: string | undefined;
    status?: string | undefined;
    workflowId?: string | undefined;
    workflowType?: string | undefined;
    runId?: string | undefined;
    roleArn?: string | undefined;
    name?: string | undefined;
    runGroupId?: string | undefined;
    batchId?: string | undefined;
    priority?: number | undefined;
    definition?: string | undefined;
    digest?: string | undefined;
    parameters?: any | undefined;
    storageCapacity?: number | undefined;
    outputUri?: string | undefined;
    logLevel?: string | undefined;
    resourceDigests?: {
        [key: string]: string | undefined;
    } | undefined;
    startedBy?: string | undefined;
    creationTime?: Date | undefined;
    startTime?: Date | undefined;
    stopTime?: Date | undefined;
    statusMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    accelerators?: string | undefined;
    retentionMode?: string | undefined;
    failureReason?: string | undefined;
    logLocation?: RunLogLocation | undefined;
    uuid?: string | undefined;
    runOutputUri?: string | undefined;
    storageType?: string | undefined;
    workflowOwnerId?: string | undefined;
    workflowVersionName?: string | undefined;
    workflowUuid?: string | undefined;
    networkingMode?: string | undefined;
    scratchStorageMode?: string | undefined;
    configuration?: ConfigurationDetails | undefined;
    vpcConfig?: VpcConfigResponse | undefined;
    engineSettings?: any | undefined;
    sessionPolicy?: string | undefined;
    outputUriPrefixMode?: string | undefined;
}
export interface GetRunCacheRequest {
    id: string;
}
export type RunCacheTimestamp = Date;
export interface GetRunCacheResponse {
    arn?: string | undefined;
    cacheBehavior?: string | undefined;
    cacheBucketOwnerId?: string | undefined;
    cacheS3Uri?: string | undefined;
    creationTime?: Date | undefined;
    description?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetRunGroupRequest {
    id: string;
}
export type RunGroupTimestamp = Date;
export interface GetRunGroupResponse {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    maxCpus?: number | undefined;
    maxRuns?: number | undefined;
    maxDuration?: number | undefined;
    creationTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    maxGpus?: number | undefined;
}
export type TaskId = string;
export interface GetRunTaskRequest {
    id: string;
    taskId: string;
}
export type TaskStatus = string;
export type TaskName = string;
export type TaskTimestamp = Date;
export type TaskStatusMessage = string;
export type TaskLogStream = string;
export type TaskInstanceType = string;
export type TaskFailureReason = string;
export type TaskImageDigest = string;
export interface ImageDetails {
    image?: string | undefined;
    imageDigest?: string | undefined;
    sourceImage?: string | undefined;
}
export type TaskUuid = string;
export interface GetRunTaskResponse {
    taskId?: string | undefined;
    status?: string | undefined;
    name?: string | undefined;
    cpus?: number | undefined;
    cacheHit?: boolean | undefined;
    cacheS3Uri?: string | undefined;
    memory?: number | undefined;
    creationTime?: Date | undefined;
    startTime?: Date | undefined;
    stopTime?: Date | undefined;
    statusMessage?: string | undefined;
    logStream?: string | undefined;
    gpus?: number | undefined;
    instanceType?: string | undefined;
    failureReason?: string | undefined;
    imageDetails?: ImageDetails | undefined;
    uuid?: string | undefined;
}
export interface GetS3AccessPolicyRequest {
    s3AccessPointArn: string;
}
export type StoreId = string;
export type StoreType = "SEQUENCE_STORE" | "REFERENCE_STORE" | (string & {});
export type S3AccessPolicy = string;
export interface GetS3AccessPolicyResponse {
    s3AccessPointArn?: string | undefined;
    storeId?: string | undefined;
    storeType?: StoreType | undefined;
    updateTime?: Date | undefined;
    s3AccessPolicy: string;
}
export interface GetSequenceStoreRequest {
    id: string;
}
export interface GetSequenceStoreResponse {
    id: string;
    arn: string;
    name?: string | undefined;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    creationTime: Date;
    fallbackLocation?: string | undefined;
    s3Access?: SequenceStoreS3Access | undefined;
    eTagAlgorithmFamily?: string | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    propagatedSetLevelTags?: string[] | undefined;
    updateTime?: Date | undefined;
}
export interface GetShareRequest {
    shareId: string;
}
export interface ShareDetails {
    shareId?: string | undefined;
    resourceArn?: string | undefined;
    resourceId?: string | undefined;
    principalSubscriber?: string | undefined;
    ownerId?: string | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    shareName?: string | undefined;
    creationTime?: Date | undefined;
    updateTime?: Date | undefined;
}
export interface GetShareResponse {
    share?: ShareDetails | undefined;
}
export interface GetVariantImportRequest {
    jobId: string;
}
export interface VariantImportItemDetail {
    source: string;
    jobStatus: string;
    statusMessage?: string | undefined;
}
export type VariantImportItemDetails = VariantImportItemDetail[];
export interface GetVariantImportResponse {
    id: string;
    destinationName: string;
    roleArn: string;
    status: string;
    statusMessage: string;
    creationTime: Date;
    updateTime: Date;
    completionTime?: Date | undefined;
    items: VariantImportItemDetail[];
    runLeftNormalization: boolean;
    annotationFields?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetVariantStoreRequest {
    name: string;
}
export interface GetVariantStoreResponse {
    id: string;
    reference: ReferenceItem;
    status: string;
    storeArn: string;
    name: string;
    description: string;
    sseConfig: SseConfig;
    creationTime: Date;
    updateTime: Date;
    tags: {
        [key: string]: string | undefined;
    };
    statusMessage: string;
    storeSizeBytes: number;
}
export type WorkflowExport = string;
export type WorkflowExportList = string[];
export interface GetWorkflowRequest {
    id: string;
    type?: string | undefined;
    export?: string[] | undefined;
    workflowOwnerId?: string | undefined;
}
export type WorkflowTimestamp = Date;
export type WorkflowStatusMessage = string;
export type WorkflowMetadataKey = string;
export type WorkflowMetadataValue = string;
export type WorkflowMetadata = {
    [key: string]: string | undefined;
};
export type ReadmeS3PresignedUrl = string;
export interface DefinitionRepositoryDetails {
    connectionArn?: string | undefined;
    fullRepositoryId?: string | undefined;
    sourceReference?: SourceReference | undefined;
    providerType?: string | undefined;
    providerEndpoint?: string | undefined;
}
export type WorkflowProfileName = string;
export type WorkflowProfileList = string[];
export type WorkflowProfileParameterTemplates = {
    [key: string]: {
        [key: string]: WorkflowParameter | undefined;
    } | undefined;
};
export interface GetWorkflowResponse {
    arn?: string | undefined;
    id?: string | undefined;
    status?: string | undefined;
    type?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    engine?: string | undefined;
    definition?: string | undefined;
    main?: string | undefined;
    digest?: string | undefined;
    parameterTemplate?: {
        [key: string]: WorkflowParameter | undefined;
    } | undefined;
    storageCapacity?: number | undefined;
    creationTime?: Date | undefined;
    statusMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    accelerators?: string | undefined;
    storageType?: string | undefined;
    uuid?: string | undefined;
    containerRegistryMap?: (ContainerRegistryMap & {
        registryMappings: (RegistryMapping & {
            upstreamRegistryUrl: Uri;
            ecrRepositoryPrefix: EcrRepositoryPrefix;
        })[];
    }) | undefined;
    readme?: string | undefined;
    definitionRepositoryDetails?: DefinitionRepositoryDetails | undefined;
    readmePath?: string | undefined;
    profiles?: string[] | undefined;
    profileParameterTemplates?: {
        [key: string]: {
            [key: string]: WorkflowParameter | undefined;
        } | undefined;
    } | undefined;
}
export interface GetWorkflowVersionRequest {
    workflowId: string;
    versionName: string;
    type?: string | undefined;
    export?: string[] | undefined;
    workflowOwnerId?: string | undefined;
}
export interface GetWorkflowVersionResponse {
    arn?: string | undefined;
    workflowId?: string | undefined;
    versionName?: string | undefined;
    accelerators?: string | undefined;
    creationTime?: Date | undefined;
    description?: string | undefined;
    definition?: string | undefined;
    digest?: string | undefined;
    engine?: string | undefined;
    main?: string | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    parameterTemplate?: {
        [key: string]: WorkflowParameter | undefined;
    } | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    storageType?: string | undefined;
    storageCapacity?: number | undefined;
    type?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    uuid?: string | undefined;
    workflowBucketOwnerId?: string | undefined;
    containerRegistryMap?: (ContainerRegistryMap & {
        registryMappings: (RegistryMapping & {
            upstreamRegistryUrl: Uri;
            ecrRepositoryPrefix: EcrRepositoryPrefix;
        })[];
    }) | undefined;
    readme?: string | undefined;
    definitionRepositoryDetails?: DefinitionRepositoryDetails | undefined;
    readmePath?: string | undefined;
    profiles?: string[] | undefined;
    profileParameterTemplates?: {
        [key: string]: {
            [key: string]: WorkflowParameter | undefined;
        } | undefined;
    } | undefined;
}
export type ResourceIdentifier = string;
export type IdList = string[];
export interface ListAnnotationImportJobsFilter {
    status?: string | undefined;
    storeName?: string | undefined;
}
export interface ListAnnotationImportJobsRequest {
    maxResults?: number | undefined;
    ids?: string[] | undefined;
    nextToken?: string | undefined;
    filter?: ListAnnotationImportJobsFilter | undefined;
}
export interface AnnotationImportJobItem {
    id: string;
    destinationName: string;
    versionName: string;
    roleArn: string;
    status: string;
    creationTime: Date;
    updateTime: Date;
    completionTime?: Date | undefined;
    runLeftNormalization?: boolean | undefined;
    annotationFields?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AnnotationImportJobItems = AnnotationImportJobItem[];
export interface ListAnnotationImportJobsResponse {
    annotationImportJobs?: AnnotationImportJobItem[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAnnotationStoresFilter {
    status?: string | undefined;
}
export interface ListAnnotationStoresRequest {
    ids?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: ListAnnotationStoresFilter | undefined;
}
export interface AnnotationStoreItem {
    id: string;
    reference: ReferenceItem;
    status: string;
    storeArn: string;
    name: string;
    storeFormat: string;
    description: string;
    sseConfig: SseConfig;
    creationTime: Date;
    updateTime: Date;
    statusMessage: string;
    storeSizeBytes: number;
}
export type AnnotationStoreItems = AnnotationStoreItem[];
export interface ListAnnotationStoresResponse {
    annotationStores?: AnnotationStoreItem[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAnnotationStoreVersionsFilter {
    status?: string | undefined;
}
export interface ListAnnotationStoreVersionsRequest {
    name: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: ListAnnotationStoreVersionsFilter | undefined;
}
export interface AnnotationStoreVersionItem {
    storeId: string;
    id: string;
    status: string;
    versionArn: string;
    name: string;
    versionName: string;
    description: string;
    creationTime: Date;
    updateTime: Date;
    statusMessage: string;
    versionSizeBytes: number;
}
export type AnnotationStoreVersionItems = AnnotationStoreVersionItem[];
export interface ListAnnotationStoreVersionsResponse {
    annotationStoreVersions?: AnnotationStoreVersionItem[] | undefined;
    nextToken?: string | undefined;
}
export type ListToken = string;
export interface ListBatchRequest {
    maxItems?: number | undefined;
    startingToken?: string | undefined;
    status?: string | undefined;
    name?: string | undefined;
    runGroupId?: string | undefined;
}
export interface BatchListItem {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    createdAt?: Date | undefined;
    totalRuns?: number | undefined;
    workflowId?: string | undefined;
}
export type BatchList = BatchListItem[];
export interface ListBatchResponse {
    items?: BatchListItem[] | undefined;
    nextToken?: string | undefined;
}
export type ConfigurationListToken = string;
export interface ListConfigurationsRequest {
    maxResults?: number | undefined;
    startingToken?: string | undefined;
}
export interface ConfigurationListItem {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    status?: string | undefined;
    creationTime?: Date | undefined;
}
export type ConfigurationList = ConfigurationListItem[];
export interface ListConfigurationsResponse {
    items?: ConfigurationListItem[] | undefined;
    nextToken?: string | undefined;
}
export type NextToken = string;
export interface ListMultipartReadSetUploadsRequest {
    sequenceStoreId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface MultipartReadSetUploadListItem {
    sequenceStoreId: string;
    uploadId: string;
    sourceFileType: string;
    subjectId: string;
    sampleId: string;
    generatedFrom: string;
    referenceArn: string;
    name?: string | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    creationTime: Date;
}
export type MultipartReadSetUploadList = MultipartReadSetUploadListItem[];
export interface ListMultipartReadSetUploadsResponse {
    nextToken?: string | undefined;
    uploads?: MultipartReadSetUploadListItem[] | undefined;
}
export interface ActivateReadSetFilter {
    status?: string | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
}
export interface ListReadSetActivationJobsRequest {
    sequenceStoreId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: ActivateReadSetFilter | undefined;
}
export interface ActivateReadSetJobItem {
    id: string;
    sequenceStoreId: string;
    status: string;
    creationTime: Date;
    completionTime?: Date | undefined;
}
export type ActivateReadSetJobList = ActivateReadSetJobItem[];
export interface ListReadSetActivationJobsResponse {
    nextToken?: string | undefined;
    activationJobs?: ActivateReadSetJobItem[] | undefined;
}
export interface ExportReadSetFilter {
    status?: string | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
}
export interface ListReadSetExportJobsRequest {
    sequenceStoreId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: ExportReadSetFilter | undefined;
}
export interface ExportReadSetJobDetail {
    id: string;
    sequenceStoreId: string;
    destination: string;
    status: string;
    creationTime: Date;
    completionTime?: Date | undefined;
}
export type ExportReadSetJobDetailList = ExportReadSetJobDetail[];
export interface ListReadSetExportJobsResponse {
    nextToken?: string | undefined;
    exportJobs?: ExportReadSetJobDetail[] | undefined;
}
export interface ImportReadSetFilter {
    status?: string | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
}
export interface ListReadSetImportJobsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sequenceStoreId: string;
    filter?: ImportReadSetFilter | undefined;
}
export interface ImportReadSetJobItem {
    id: string;
    sequenceStoreId: string;
    roleArn: string;
    status: string;
    creationTime: Date;
    completionTime?: Date | undefined;
}
export type ImportReadSetJobList = ImportReadSetJobItem[];
export interface ListReadSetImportJobsResponse {
    nextToken?: string | undefined;
    importJobs?: ImportReadSetJobItem[] | undefined;
}
export type ReferenceArnFilter = string;
export interface ReadSetFilter {
    name?: string | undefined;
    status?: string | undefined;
    referenceArn?: string | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
    sampleId?: string | undefined;
    subjectId?: string | undefined;
    generatedFrom?: string | undefined;
    creationType?: string | undefined;
}
export interface ListReadSetsRequest {
    sequenceStoreId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: ReadSetFilter | undefined;
}
export interface ReadSetListItem {
    id: string;
    arn: string;
    sequenceStoreId: string;
    subjectId?: string | undefined;
    sampleId?: string | undefined;
    status: string;
    name?: string | undefined;
    description?: string | undefined;
    referenceArn?: string | undefined;
    fileType: string;
    sequenceInformation?: SequenceInformation | undefined;
    creationTime: Date;
    statusMessage?: string | undefined;
    creationType?: string | undefined;
    etag?: ETag | undefined;
}
export type ReadSetList = ReadSetListItem[];
export interface ListReadSetsResponse {
    nextToken?: string | undefined;
    readSets: ReadSetListItem[];
}
export interface ReadSetUploadPartListFilter {
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
}
export interface ListReadSetUploadPartsRequest {
    sequenceStoreId: string;
    uploadId: string;
    partSource: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: ReadSetUploadPartListFilter | undefined;
}
export interface ReadSetUploadPartListItem {
    partNumber: number;
    partSize: number;
    partSource: string;
    checksum: string;
    creationTime?: Date | undefined;
    lastUpdatedTime?: Date | undefined;
}
export type ReadSetUploadPartList = ReadSetUploadPartListItem[];
export interface ListReadSetUploadPartsResponse {
    nextToken?: string | undefined;
    parts?: ReadSetUploadPartListItem[] | undefined;
}
export interface ImportReferenceFilter {
    status?: string | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
}
export interface ListReferenceImportJobsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    referenceStoreId: string;
    filter?: ImportReferenceFilter | undefined;
}
export interface ImportReferenceJobItem {
    id: string;
    referenceStoreId: string;
    roleArn: string;
    status: string;
    creationTime: Date;
    completionTime?: Date | undefined;
}
export type ImportReferenceJobList = ImportReferenceJobItem[];
export interface ListReferenceImportJobsResponse {
    nextToken?: string | undefined;
    importJobs?: ImportReferenceJobItem[] | undefined;
}
export interface ReferenceFilter {
    name?: string | undefined;
    md5?: string | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
}
export interface ListReferencesRequest {
    referenceStoreId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: ReferenceFilter | undefined;
}
export interface ReferenceListItem {
    id: string;
    arn: string;
    referenceStoreId: string;
    md5: string;
    status?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    creationTime: Date;
    updateTime: Date;
}
export type ReferenceList = ReferenceListItem[];
export interface ListReferencesResponse {
    nextToken?: string | undefined;
    references: ReferenceListItem[];
}
export interface ReferenceStoreFilter {
    name?: string | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
}
export interface ListReferenceStoresRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: ReferenceStoreFilter | undefined;
}
export interface ReferenceStoreDetail {
    arn: string;
    id: string;
    name?: string | undefined;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    creationTime: Date;
}
export type ReferenceStoreDetailList = ReferenceStoreDetail[];
export interface ListReferenceStoresResponse {
    nextToken?: string | undefined;
    referenceStores: ReferenceStoreDetail[];
}
export interface ListRunCachesRequest {
    maxResults?: number | undefined;
    startingToken?: string | undefined;
}
export interface RunCacheListItem {
    arn?: string | undefined;
    cacheBehavior?: string | undefined;
    cacheS3Uri?: string | undefined;
    creationTime?: Date | undefined;
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
}
export type RunCacheList = RunCacheListItem[];
export interface ListRunCachesResponse {
    items?: RunCacheListItem[] | undefined;
    nextToken?: string | undefined;
}
export type RunGroupListToken = string;
export interface ListRunGroupsRequest {
    name?: string | undefined;
    startingToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface RunGroupListItem {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    maxCpus?: number | undefined;
    maxRuns?: number | undefined;
    maxDuration?: number | undefined;
    creationTime?: Date | undefined;
    maxGpus?: number | undefined;
}
export type RunGroupList = RunGroupListItem[];
export interface ListRunGroupsResponse {
    items?: RunGroupListItem[] | undefined;
    nextToken?: string | undefined;
}
export type RunListToken = string;
export interface ListRunsRequest {
    name?: string | undefined;
    runGroupId?: string | undefined;
    batchId?: string | undefined;
    startingToken?: string | undefined;
    maxResults?: number | undefined;
    status?: string | undefined;
}
export interface RunListItem {
    arn?: string | undefined;
    id?: string | undefined;
    status?: string | undefined;
    workflowId?: string | undefined;
    batchId?: string | undefined;
    name?: string | undefined;
    priority?: number | undefined;
    storageCapacity?: number | undefined;
    creationTime?: Date | undefined;
    startTime?: Date | undefined;
    stopTime?: Date | undefined;
    storageType?: string | undefined;
    workflowVersionName?: string | undefined;
    workflowName?: string | undefined;
}
export type RunList = RunListItem[];
export interface ListRunsResponse {
    items?: RunListItem[] | undefined;
    nextToken?: string | undefined;
}
export type SubmissionStatus = string;
export interface ListRunsInBatchRequest {
    batchId: string;
    maxItems?: number | undefined;
    startingToken?: string | undefined;
    submissionStatus?: string | undefined;
    runSettingId?: string | undefined;
    runId?: string | undefined;
}
export type RunSettingId = string;
export type SubmissionFailureReason = string;
export type SubmissionFailureMessage = string;
export interface RunBatchListItem {
    runSettingId?: string | undefined;
    runId?: string | undefined;
    runInternalUuid?: string | undefined;
    runArn?: string | undefined;
    submissionStatus?: string | undefined;
    submissionFailureReason?: string | undefined;
    submissionFailureMessage?: string | undefined;
}
export type RunBatchList = RunBatchListItem[];
export interface ListRunsInBatchResponse {
    runs?: RunBatchListItem[] | undefined;
    nextToken?: string | undefined;
}
export type TaskListToken = string;
export interface ListRunTasksRequest {
    id: string;
    status?: string | undefined;
    startingToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface TaskListItem {
    taskId?: string | undefined;
    status?: string | undefined;
    name?: string | undefined;
    cpus?: number | undefined;
    cacheHit?: boolean | undefined;
    cacheS3Uri?: string | undefined;
    memory?: number | undefined;
    creationTime?: Date | undefined;
    startTime?: Date | undefined;
    stopTime?: Date | undefined;
    gpus?: number | undefined;
    instanceType?: string | undefined;
    uuid?: string | undefined;
}
export type TaskList = TaskListItem[];
export interface ListRunTasksResponse {
    items?: TaskListItem[] | undefined;
    nextToken?: string | undefined;
}
export interface SequenceStoreFilter {
    name?: string | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
    status?: string | undefined;
    updatedAfter?: Date | undefined;
    updatedBefore?: Date | undefined;
}
export interface ListSequenceStoresRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: SequenceStoreFilter | undefined;
}
export interface SequenceStoreDetail {
    arn: string;
    id: string;
    name?: string | undefined;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    creationTime: Date;
    fallbackLocation?: string | undefined;
    eTagAlgorithmFamily?: string | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    updateTime?: Date | undefined;
}
export type SequenceStoreDetailList = SequenceStoreDetail[];
export interface ListSequenceStoresResponse {
    nextToken?: string | undefined;
    sequenceStores: SequenceStoreDetail[];
}
export type ResourceOwner = string;
export type ArnList = string[];
export type StatusList = string[];
export type ShareResourceType = string;
export type TypeList = string[];
export interface Filter {
    resourceArns?: string[] | undefined;
    status?: string[] | undefined;
    type?: string[] | undefined;
}
export interface ListSharesRequest {
    resourceOwner: string;
    filter?: Filter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ShareDetailsList = ShareDetails[];
export interface ListSharesResponse {
    shares: ShareDetails[];
    nextToken?: string | undefined;
}
export type TagArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface ListVariantImportJobsFilter {
    status?: string | undefined;
    storeName?: string | undefined;
}
export interface ListVariantImportJobsRequest {
    maxResults?: number | undefined;
    ids?: string[] | undefined;
    nextToken?: string | undefined;
    filter?: ListVariantImportJobsFilter | undefined;
}
export interface VariantImportJobItem {
    id: string;
    destinationName: string;
    roleArn: string;
    status: string;
    creationTime: Date;
    updateTime: Date;
    completionTime?: Date | undefined;
    runLeftNormalization?: boolean | undefined;
    annotationFields?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VariantImportJobItems = VariantImportJobItem[];
export interface ListVariantImportJobsResponse {
    variantImportJobs?: VariantImportJobItem[] | undefined;
    nextToken?: string | undefined;
}
export interface ListVariantStoresFilter {
    status?: string | undefined;
}
export interface ListVariantStoresRequest {
    maxResults?: number | undefined;
    ids?: string[] | undefined;
    nextToken?: string | undefined;
    filter?: ListVariantStoresFilter | undefined;
}
export interface VariantStoreItem {
    id: string;
    reference: ReferenceItem;
    status: string;
    storeArn: string;
    name: string;
    description: string;
    sseConfig: SseConfig;
    creationTime: Date;
    updateTime: Date;
    statusMessage: string;
    storeSizeBytes: number;
}
export type VariantStoreItems = VariantStoreItem[];
export interface ListVariantStoresResponse {
    variantStores?: VariantStoreItem[] | undefined;
    nextToken?: string | undefined;
}
export type WorkflowListToken = string;
export interface ListWorkflowsRequest {
    type?: string | undefined;
    name?: string | undefined;
    startingToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface WorkflowListItem {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    type?: string | undefined;
    digest?: string | undefined;
    creationTime?: Date | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type WorkflowList = WorkflowListItem[];
export interface ListWorkflowsResponse {
    items?: WorkflowListItem[] | undefined;
    nextToken?: string | undefined;
}
export type WorkflowVersionListToken = string;
export interface ListWorkflowVersionsRequest {
    workflowId: string;
    type?: string | undefined;
    workflowOwnerId?: string | undefined;
    startingToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface WorkflowVersionListItem {
    arn?: string | undefined;
    workflowId?: string | undefined;
    versionName?: string | undefined;
    description?: string | undefined;
    status?: string | undefined;
    type?: string | undefined;
    digest?: string | undefined;
    creationTime?: Date | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type WorkflowVersionList = WorkflowVersionListItem[];
export interface ListWorkflowVersionsResponse {
    items?: WorkflowVersionListItem[] | undefined;
    nextToken?: string | undefined;
}
export interface PutS3AccessPolicyRequest {
    s3AccessPointArn: string;
    s3AccessPolicy: string;
}
export interface PutS3AccessPolicyResponse {
    s3AccessPointArn?: string | undefined;
    storeId?: string | undefined;
    storeType?: StoreType | undefined;
}
export interface AnnotationImportItemSource {
    source: string;
}
export type AnnotationImportItemSources = AnnotationImportItemSource[];
export interface StartAnnotationImportRequest {
    destinationName: string;
    roleArn: string;
    items: AnnotationImportItemSource[];
    versionName?: string | undefined;
    formatOptions?: FormatOptions | undefined;
    runLeftNormalization?: boolean | undefined;
    annotationFields?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartAnnotationImportResponse {
    jobId: string;
}
export interface StartReadSetActivationJobSourceItem {
    readSetId: string;
}
export type StartReadSetActivationJobSourceList = StartReadSetActivationJobSourceItem[];
export interface StartReadSetActivationJobRequest {
    sequenceStoreId: string;
    clientToken?: string | undefined;
    sources: StartReadSetActivationJobSourceItem[];
}
export interface StartReadSetActivationJobResponse {
    id: string;
    sequenceStoreId: string;
    status: string;
    creationTime: Date;
}
export interface ExportReadSet {
    readSetId: string;
}
export type ExportReadSetList = ExportReadSet[];
export interface StartReadSetExportJobRequest {
    sequenceStoreId: string;
    destination: string;
    roleArn: string;
    clientToken?: string | undefined;
    sources: ExportReadSet[];
}
export interface StartReadSetExportJobResponse {
    id: string;
    sequenceStoreId: string;
    destination: string;
    status: string;
    creationTime: Date;
}
export interface StartReadSetImportJobSourceItem {
    sourceFiles: SourceFiles;
    sourceFileType: string;
    subjectId: string;
    sampleId: string;
    generatedFrom?: string | undefined;
    referenceArn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StartReadSetImportJobSourceList = StartReadSetImportJobSourceItem[];
export interface StartReadSetImportJobRequest {
    sequenceStoreId: string;
    roleArn: string;
    clientToken?: string | undefined;
    sources: StartReadSetImportJobSourceItem[];
}
export interface StartReadSetImportJobResponse {
    id: string;
    sequenceStoreId: string;
    roleArn: string;
    status: string;
    creationTime: Date;
}
export interface StartReferenceImportJobSourceItem {
    sourceFile: string;
    name: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StartReferenceImportJobSourceList = StartReferenceImportJobSourceItem[];
export interface StartReferenceImportJobRequest {
    referenceStoreId: string;
    roleArn: string;
    clientToken?: string | undefined;
    sources: StartReferenceImportJobSourceItem[];
}
export interface StartReferenceImportJobResponse {
    id: string;
    referenceStoreId: string;
    roleArn: string;
    status: string;
    creationTime: Date;
}
export type RunRequestId = string;
export interface StartRunRequest {
    workflowId?: string | undefined;
    workflowType?: string | undefined;
    runId?: string | undefined;
    roleArn: string;
    name?: string | undefined;
    cacheId?: string | undefined;
    cacheBehavior?: string | undefined;
    runGroupId?: string | undefined;
    priority?: number | undefined;
    parameters?: any | undefined;
    storageCapacity?: number | undefined;
    outputUri: string;
    logLevel?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    requestId: string;
    retentionMode?: string | undefined;
    storageType?: string | undefined;
    workflowOwnerId?: string | undefined;
    workflowVersionName?: string | undefined;
    networkingMode?: string | undefined;
    scratchStorageMode?: string | undefined;
    configurationName?: string | undefined;
    sessionPolicy?: string | undefined;
    engineSettings?: any | undefined;
    outputUriPrefixMode?: string | undefined;
}
export interface StartRunResponse {
    arn?: string | undefined;
    id?: string | undefined;
    status?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    uuid?: string | undefined;
    runOutputUri?: string | undefined;
    configuration?: ConfigurationDetails | undefined;
    networkingMode?: string | undefined;
}
export type BatchRequestId = string;
export interface InlineSetting {
    runSettingId: string;
    name?: string | undefined;
    outputUri?: string | undefined;
    priority?: number | undefined;
    parameters?: any | undefined;
    outputBucketOwnerId?: string | undefined;
    runTags?: {
        [key: string]: string | undefined;
    } | undefined;
    engineSettings?: any | undefined;
}
export type InlineSettings = InlineSetting[];
export type S3UriSettings = string;
export type BatchRunSettings = {
    inlineSettings: InlineSetting[];
    s3UriSettings?: undefined;
} | {
    inlineSettings?: undefined;
    s3UriSettings: string;
};
export interface StartRunBatchRequest {
    batchName?: string | undefined;
    requestId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    defaultRunSetting: DefaultRunSetting;
    batchRunSettings: BatchRunSettings;
}
export interface StartRunBatchResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    uuid?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface VariantImportItemSource {
    source: string;
}
export type VariantImportItemSources = VariantImportItemSource[];
export interface StartVariantImportRequest {
    destinationName: string;
    roleArn: string;
    items: VariantImportItemSource[];
    runLeftNormalization?: boolean | undefined;
    annotationFields?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartVariantImportResponse {
    jobId: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAnnotationStoreRequest {
    name: string;
    description?: string | undefined;
}
export interface UpdateAnnotationStoreResponse {
    id: string;
    reference: ReferenceItem;
    status: string;
    name: string;
    description: string;
    creationTime: Date;
    updateTime: Date;
    storeOptions?: StoreOptions | undefined;
    storeFormat?: string | undefined;
}
export interface UpdateAnnotationStoreVersionRequest {
    name: string;
    versionName: string;
    description?: string | undefined;
}
export interface UpdateAnnotationStoreVersionResponse {
    storeId: string;
    id: string;
    status: string;
    name: string;
    versionName: string;
    description: string;
    creationTime: Date;
    updateTime: Date;
}
export interface UpdateRunCacheRequest {
    cacheBehavior?: string | undefined;
    description?: string | undefined;
    id: string;
    name?: string | undefined;
}
export interface UpdateRunCacheResponse {
}
export interface UpdateRunGroupRequest {
    id: string;
    name?: string | undefined;
    maxCpus?: number | undefined;
    maxRuns?: number | undefined;
    maxDuration?: number | undefined;
    maxGpus?: number | undefined;
}
export interface UpdateRunGroupResponse {
}
export interface UpdateSequenceStoreRequest {
    id: string;
    name?: string | undefined;
    description?: string | undefined;
    clientToken?: string | undefined;
    fallbackLocation?: string | undefined;
    propagatedSetLevelTags?: string[] | undefined;
    s3AccessConfig?: S3AccessConfig | undefined;
}
export interface UpdateSequenceStoreResponse {
    id: string;
    arn: string;
    name?: string | undefined;
    description?: string | undefined;
    sseConfig?: SseConfig | undefined;
    creationTime: Date;
    updateTime?: Date | undefined;
    propagatedSetLevelTags?: string[] | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    fallbackLocation?: string | undefined;
    s3Access?: SequenceStoreS3Access | undefined;
    eTagAlgorithmFamily?: string | undefined;
}
export interface UpdateVariantStoreRequest {
    name: string;
    description?: string | undefined;
}
export interface UpdateVariantStoreResponse {
    id: string;
    reference: ReferenceItem;
    status: string;
    name: string;
    description: string;
    creationTime: Date;
    updateTime: Date;
}
export interface UpdateWorkflowRequest {
    id: string;
    name?: string | undefined;
    description?: string | undefined;
    storageType?: string | undefined;
    storageCapacity?: number | undefined;
    readmeMarkdown?: string | undefined;
}
export interface UpdateWorkflowResponse {
}
export interface UpdateWorkflowVersionRequest {
    workflowId: string;
    versionName: string;
    description?: string | undefined;
    storageType?: string | undefined;
    storageCapacity?: number | undefined;
    readmeMarkdown?: string | undefined;
}
export interface UpdateWorkflowVersionResponse {
}
export interface UploadReadSetPartRequest {
    sequenceStoreId: string;
    uploadId: string;
    partSource: string;
    partNumber: number;
    payload: T.StreamingInputBody;
}
export interface UploadReadSetPartResponse {
    checksum: string;
}
export type AbortMultipartReadSetUploadError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a multipart read set upload into a sequence store and returns a response with no body if the operation is successful. To confirm that a multipart read set upload has been stopped, use the `ListMultipartReadSetUploads` API operation to view all active multipart read set uploads.
 */
export declare const abortMultipartReadSetUpload: API.OperationMethod<AbortMultipartReadSetUploadRequest & RegionInput, AbortMultipartReadSetUploadResponse, AbortMultipartReadSetUploadError, Credentials | HttpClient.HttpClient>;
export type AcceptShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Accept a resource share request.
 */
export declare const acceptShare: API.OperationMethod<AcceptShareRequest & RegionInput, AcceptShareResponse, AcceptShareError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteReadSetError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes one or more read sets. If the operation is successful, it returns a response with no body. If there is an error with deleting one of the read sets, the operation returns an error list. If the operation successfully deletes only a subset of files, it will return an error list for the remaining files that fail to be deleted. There is a limit of 100 read sets that can be deleted in each `BatchDeleteReadSet` API call.
 */
export declare const batchDeleteReadSet: API.OperationMethod<BatchDeleteReadSetRequest & RegionInput, BatchDeleteReadSetResponse, BatchDeleteReadSetError, Credentials | HttpClient.HttpClient>;
export type CancelAnnotationImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Cancels an annotation import job.
 */
export declare const cancelAnnotationImportJob: API.OperationMethod<CancelAnnotationImportRequest & RegionInput, CancelAnnotationImportResponse, CancelAnnotationImportJobError, Credentials | HttpClient.HttpClient>;
export type CancelRunError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a run using its ID and returns a response with no body if the operation is successful. To confirm that the run has been cancelled, use the `ListRuns` API operation to check that it is no longer listed.
 */
export declare const cancelRun: API.OperationMethod<CancelRunRequest & RegionInput, CancelRunResponse, CancelRunError, Credentials | HttpClient.HttpClient>;
export type CancelRunBatchError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels all runs within a specified batch. This operation prevents not-yet-submitted runs from starting and submits `CancelRun` requests for runs that have already started.
 *
 * Cancel is only allowed on batches in `PENDING`, `SUBMITTING`, or `INPROGRESS` state. Cancel operations are non-atomic and may be partially successful. Use `GetBatch` to review `successfulCancelSubmissionCount` and `failedCancelSubmissionCount` in the `submissionSummary`. Only one cancel or delete operation per batch is allowed at a time.
 */
export declare const cancelRunBatch: API.OperationMethod<CancelRunBatchRequest & RegionInput, CancelRunBatchResponse, CancelRunBatchError, Credentials | HttpClient.HttpClient>;
export type CancelVariantImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Cancels a variant import job.
 */
export declare const cancelVariantImportJob: API.OperationMethod<CancelVariantImportRequest & RegionInput, CancelVariantImportResponse, CancelVariantImportJobError, Credentials | HttpClient.HttpClient>;
export type CompleteMultipartReadSetUploadError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Completes a multipart read set upload into a sequence store after you have initiated the upload process with `CreateMultipartReadSetUpload` and uploaded all read set parts using `UploadReadSetPart`. You must specify the parts you uploaded using the parts parameter. If the operation is successful, it returns the read set ID(s) of the uploaded read set(s).
 *
 * For more information, see Direct upload to a sequence store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const completeMultipartReadSetUpload: API.OperationMethod<CompleteMultipartReadSetUploadRequest & RegionInput, CompleteMultipartReadSetUploadResponse, CompleteMultipartReadSetUploadError, Credentials | HttpClient.HttpClient>;
export type CreateAnnotationStoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Creates an annotation store.
 */
export declare const createAnnotationStore: API.OperationMethod<CreateAnnotationStoreRequest & RegionInput, CreateAnnotationStoreResponse, CreateAnnotationStoreError, Credentials | HttpClient.HttpClient>;
export type CreateAnnotationStoreVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new version of an annotation store.
 */
export declare const createAnnotationStoreVersion: API.OperationMethod<CreateAnnotationStoreVersionRequest & RegionInput, CreateAnnotationStoreVersionResponse, CreateAnnotationStoreVersionError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new configuration.
 */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest & RegionInput, CreateConfigurationResponse, CreateConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateMultipartReadSetUploadError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a multipart read set upload for uploading partitioned source files into a sequence store. You can directly import source files from an EC2 instance and other local compute, or from an S3 bucket. To separate these source files into parts, use the `split` operation. Each part cannot be larger than 100 MB. If the operation is successful, it provides an `uploadId` which is required by the `UploadReadSetPart` API operation to upload parts into a sequence store.
 *
 * To continue uploading a multipart read set into your sequence store, you must use the `UploadReadSetPart` API operation to upload each part individually following the steps below:
 *
 * - Specify the `uploadId` obtained from the previous call to `CreateMultipartReadSetUpload`.
 *
 * - Upload parts for that `uploadId`.
 *
 * When you have finished uploading parts, use the `CompleteMultipartReadSetUpload` API to complete the multipart read set upload and to retrieve the final read set IDs in the response.
 *
 * To learn more about creating parts and the `split` operation, see Direct upload to a sequence store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const createMultipartReadSetUpload: API.OperationMethod<CreateMultipartReadSetUploadRequest & RegionInput, CreateMultipartReadSetUploadResponse, CreateMultipartReadSetUploadError, Credentials | HttpClient.HttpClient>;
export type CreateReferenceStoreError = AccessDeniedException | InternalServerException | RequestTimeoutException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a reference store and returns metadata in JSON format. Reference stores are used to store reference genomes in FASTA format. A reference store is created when the first reference genome is imported. To import additional reference genomes from an Amazon S3 bucket, use the `StartReferenceImportJob` API operation.
 *
 * For more information, see Creating a HealthOmics reference store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const createReferenceStore: API.OperationMethod<CreateReferenceStoreRequest & RegionInput, CreateReferenceStoreResponse, CreateReferenceStoreError, Credentials | HttpClient.HttpClient>;
export type CreateRunCacheError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a run cache to store and reference task outputs from completed private runs. Specify an Amazon S3 location where Amazon Web Services HealthOmics saves the cached data. This data must be immediately accessible and not in an archived state. You can save intermediate task files to a run cache if they are declared as task outputs in the workflow definition file.
 *
 * For more information, see Call caching and Creating a run cache in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const createRunCache: API.OperationMethod<CreateRunCacheRequest & RegionInput, CreateRunCacheResponse, CreateRunCacheError, Credentials | HttpClient.HttpClient>;
export type CreateRunGroupError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a run group to limit the compute resources for the runs that are added to the group. Returns an ARN, ID, and tags for the run group.
 */
export declare const createRunGroup: API.OperationMethod<CreateRunGroupRequest & RegionInput, CreateRunGroupResponse, CreateRunGroupError, Credentials | HttpClient.HttpClient>;
export type CreateSequenceStoreError = AccessDeniedException | InternalServerException | RequestTimeoutException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a sequence store and returns its metadata. Sequence stores are used to store sequence data files called read sets that are saved in FASTQ, BAM, uBAM, or CRAM formats. For aligned formats (BAM and CRAM), a sequence store can only use one reference genome. For unaligned formats (FASTQ and uBAM), a reference genome is not required. You can create multiple sequence stores per region per account.
 *
 * The following are optional parameters you can specify for your sequence store:
 *
 * - Use `s3AccessConfig` to configure your sequence store with S3 access logs (recommended).
 *
 * - Use `sseConfig` to define your own KMS key for encryption.
 *
 * - Use `eTagAlgorithmFamily` to define which algorithm to use for the HealthOmics eTag on objects.
 *
 * - Use `fallbackLocation` to define a backup location for storing files that have failed a direct upload.
 *
 * - Use `propagatedSetLevelTags` to configure tags that propagate to all objects in your store.
 *
 * For more information, see Creating a HealthOmics sequence store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const createSequenceStore: API.OperationMethod<CreateSequenceStoreRequest & RegionInput, CreateSequenceStoreResponse, CreateSequenceStoreError, Credentials | HttpClient.HttpClient>;
export type CreateShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a cross-account shared resource. The resource owner makes an offer to share the resource with the principal subscriber (an Amazon Web Services user with a different account than the resource owner).
 *
 * The following resources support cross-account sharing:
 *
 * - HealthOmics variant stores
 *
 * - HealthOmics annotation stores
 *
 * - Private workflows
 */
export declare const createShare: API.OperationMethod<CreateShareRequest & RegionInput, CreateShareResponse, CreateShareError, Credentials | HttpClient.HttpClient>;
export type CreateVariantStoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Creates a variant store.
 */
export declare const createVariantStore: API.OperationMethod<CreateVariantStoreRequest & RegionInput, CreateVariantStoreResponse, CreateVariantStoreError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a private workflow. Before you create a private workflow, you must create and configure these required resources:
 *
 * - *Workflow definition file:* A workflow definition file written in WDL, Nextflow, or CWL. The workflow definition specifies the inputs and outputs for runs that use the workflow. It also includes specifications for the runs and run tasks for your workflow, including compute and memory requirements. The workflow definition file must be in `.zip` format. For more information, see Workflow definition files in Amazon Web Services HealthOmics.
 *
 * - You can use Amazon Q CLI to build and validate your workflow definition files in WDL, Nextflow, and CWL. For more information, see Example prompts for Amazon Q CLI and the Amazon Web Services HealthOmics Agentic generative AI tutorial on GitHub.
 *
 * - *(Optional) Parameter template file:* A parameter template file written in JSON. Create the file to define the run parameters, or Amazon Web Services HealthOmics generates the parameter template for you. For more information, see Parameter template files for HealthOmics workflows.
 *
 * - *ECR container images:* Create container images for the workflow in a private ECR repository, or synchronize images from a supported upstream registry with your Amazon ECR private repository.
 *
 * - *(Optional) Sentieon licenses:* Request a Sentieon license to use the Sentieon software in private workflows.
 *
 * For more information, see Creating or updating a private workflow in Amazon Web Services HealthOmics in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const createWorkflow: API.OperationMethod<CreateWorkflowRequest & RegionInput, CreateWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowVersionError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new workflow version for the workflow that you specify with the `workflowId` parameter.
 *
 * When you create a new version of a workflow, you need to specify the configuration for the new version. It doesn't inherit any configuration values from the workflow.
 *
 * Provide a version name that is unique for this workflow. You cannot change the name after HealthOmics creates the version.
 *
 * Don't include any personally identifiable information (PII) in the version name. Version names appear in the workflow version ARN.
 *
 * For more information, see Workflow versioning in Amazon Web Services HealthOmics in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const createWorkflowVersion: API.OperationMethod<CreateWorkflowVersionRequest & RegionInput, CreateWorkflowVersionResponse, CreateWorkflowVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteAnnotationStoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Deletes an annotation store.
 */
export declare const deleteAnnotationStore: API.OperationMethod<DeleteAnnotationStoreRequest & RegionInput, DeleteAnnotationStoreResponse, DeleteAnnotationStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteAnnotationStoreVersionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes one or multiple versions of an annotation store.
 */
export declare const deleteAnnotationStoreVersions: API.OperationMethod<DeleteAnnotationStoreVersionsRequest & RegionInput, DeleteAnnotationStoreVersionsResponse, DeleteAnnotationStoreVersionsError, Credentials | HttpClient.HttpClient>;
export type DeleteBatchError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a run batch resource and its associated metadata. This operation does not delete the individual workflow runs. To delete the runs, call `DeleteRunBatch` before calling `DeleteBatch`.
 *
 * `DeleteBatch` requires the batch to be in a terminal state: `PROCESSED`, `FAILED`, `CANCELLED`, `RUNS_DELETE_FAILED`, or `RUNS_DELETED`. After `DeleteBatch` completes, the batch metadata is no longer accessible. You cannot call `GetBatch`, `ListRunsInBatch`, `DeleteRunBatch`, or `CancelRunBatch` on a deleted batch.
 */
export declare const deleteBatch: API.OperationMethod<DeleteBatchRequest & RegionInput, DeleteBatchResponse, DeleteBatchError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an existing configuration.
 */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest & RegionInput, DeleteConfigurationResponse, DeleteConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteReferenceError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a reference genome and returns a response with no body if the operation is successful. The read set associated with the reference genome must first be deleted before deleting the reference genome. After the reference genome is deleted, you can delete the reference store using the `DeleteReferenceStore` API operation.
 *
 * For more information, see Deleting HealthOmics reference and sequence stores in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const deleteReference: API.OperationMethod<DeleteReferenceRequest & RegionInput, DeleteReferenceResponse, DeleteReferenceError, Credentials | HttpClient.HttpClient>;
export type DeleteReferenceStoreError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a reference store and returns a response with no body if the operation is successful. You can only delete a reference store when it does not contain any reference genomes. To empty a reference store, use `DeleteReference`.
 *
 * For more information about your workflow status, see Deleting HealthOmics reference and sequence stores in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const deleteReferenceStore: API.OperationMethod<DeleteReferenceStoreRequest & RegionInput, DeleteReferenceStoreResponse, DeleteReferenceStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteRunError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a run and returns a response with no body if the operation is successful. You can only delete a run that has reached a `COMPLETED`, `FAILED`, or `CANCELLED` stage. A completed run has delivered an output, or was cancelled and resulted in no output. When you delete a run, only the metadata associated with the run is deleted. The run outputs remain in Amazon S3 and logs remain in CloudWatch.
 *
 * To verify that the workflow is deleted:
 *
 * - Use `ListRuns` to confirm the workflow no longer appears in the list.
 *
 * - Use `GetRun` to verify the workflow cannot be found.
 */
export declare const deleteRun: API.OperationMethod<DeleteRunRequest & RegionInput, DeleteRunResponse, DeleteRunError, Credentials | HttpClient.HttpClient>;
export type DeleteRunBatchError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the individual workflow runs within a batch. This operation is separate from `DeleteBatch`, which removes the batch metadata.
 *
 * Delete is only allowed on batches in `PROCESSED` or `CANCELLED` state. Delete operations are non-atomic and may be partially successful. Use `GetBatch` to review `successfulDeleteSubmissionCount` and `failedDeleteSubmissionCount` in the `submissionSummary`. Only one cancel or delete operation per batch is allowed at a time.
 */
export declare const deleteRunBatch: API.OperationMethod<DeleteRunBatchRequest & RegionInput, DeleteRunBatchResponse, DeleteRunBatchError, Credentials | HttpClient.HttpClient>;
export type DeleteRunCacheError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a run cache and returns a response with no body if the operation is successful. This action removes the cache metadata stored in the service account, but does not delete the data in Amazon S3. You can access the cache data in Amazon S3, for inspection or to troubleshoot issues. You can remove old cache data using standard S3 `Delete` operations.
 *
 * For more information, see Deleting a run cache in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const deleteRunCache: API.OperationMethod<DeleteRunCacheRequest & RegionInput, DeleteRunCacheResponse, DeleteRunCacheError, Credentials | HttpClient.HttpClient>;
export type DeleteRunGroupError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a run group and returns a response with no body if the operation is successful.
 *
 * To verify that the run group is deleted:
 *
 * - Use `ListRunGroups` to confirm the workflow no longer appears in the list.
 *
 * - Use `GetRunGroup` to verify the workflow cannot be found.
 */
export declare const deleteRunGroup: API.OperationMethod<DeleteRunGroupRequest & RegionInput, DeleteRunGroupResponse, DeleteRunGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteS3AccessPolicyError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an access policy for the specified store.
 */
export declare const deleteS3AccessPolicy: API.OperationMethod<DeleteS3AccessPolicyRequest & RegionInput, DeleteS3AccessPolicyResponse, DeleteS3AccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSequenceStoreError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a sequence store and returns a response with no body if the operation is successful. You can only delete a sequence store when it does not contain any read sets.
 *
 * Use the `BatchDeleteReadSet` API operation to ensure that all read sets in the sequence store are deleted. When a sequence store is deleted, all tags associated with the store are also deleted.
 *
 * For more information, see Deleting HealthOmics reference and sequence stores in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const deleteSequenceStore: API.OperationMethod<DeleteSequenceStoreRequest & RegionInput, DeleteSequenceStoreResponse, DeleteSequenceStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a resource share. If you are the resource owner, the subscriber will no longer have access to the shared resource. If you are the subscriber, this operation deletes your access to the share.
 */
export declare const deleteShare: API.OperationMethod<DeleteShareRequest & RegionInput, DeleteShareResponse, DeleteShareError, Credentials | HttpClient.HttpClient>;
export type DeleteVariantStoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Deletes a variant store.
 */
export declare const deleteVariantStore: API.OperationMethod<DeleteVariantStoreRequest & RegionInput, DeleteVariantStoreResponse, DeleteVariantStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a workflow by specifying its ID. This operation returns a response with no body if the deletion is successful.
 *
 * To verify that the workflow is deleted:
 *
 * - Use `ListWorkflows` to confirm the workflow no longer appears in the list.
 *
 * - Use `GetWorkflow` to verify the workflow cannot be found.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest & RegionInput, DeleteWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowVersionError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a workflow version. Deleting a workflow version doesn't affect any ongoing runs that are using the workflow version.
 *
 * For more information, see Workflow versioning in Amazon Web Services HealthOmics in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const deleteWorkflowVersion: API.OperationMethod<DeleteWorkflowVersionRequest & RegionInput, DeleteWorkflowVersionResponse, DeleteWorkflowVersionError, Credentials | HttpClient.HttpClient>;
export type GetAnnotationImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Gets information about an annotation import job.
 */
export declare const getAnnotationImportJob: API.OperationMethod<GetAnnotationImportRequest & RegionInput, GetAnnotationImportResponse, GetAnnotationImportJobError, Credentials | HttpClient.HttpClient>;
export type GetAnnotationStoreError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Gets information about an annotation store.
 */
export declare const getAnnotationStore: API.OperationMethod<GetAnnotationStoreRequest & RegionInput, GetAnnotationStoreResponse, GetAnnotationStoreError, Credentials | HttpClient.HttpClient>;
export type GetAnnotationStoreVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the metadata for an annotation store version.
 */
export declare const getAnnotationStoreVersion: API.OperationMethod<GetAnnotationStoreVersionRequest & RegionInput, GetAnnotationStoreVersionResponse, GetAnnotationStoreVersionError, Credentials | HttpClient.HttpClient>;
export type GetBatchError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details and current status for a specific run batch, including submission progress and run execution counts.
 */
export declare const getBatch: API.OperationMethod<GetBatchRequest & RegionInput, GetBatchResponse, GetBatchError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve configuration details for specified name.
 */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest & RegionInput, GetConfigurationResponse, GetConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetReadSetError = AccessDeniedException | ConflictException | InternalServerException | RangeNotSatisfiableException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information from parts of a read set and returns the read set in the same format that it was uploaded. You must have read sets uploaded to your sequence store in order to run this operation.
 */
export declare const getReadSet: API.OperationMethod<GetReadSetRequest & RegionInput, GetReadSetResponse, GetReadSetError, Credentials | HttpClient.HttpClient>;
export type GetReadSetActivationJobError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed information about the status of a read set activation job in JSON format.
 */
export declare const getReadSetActivationJob: API.OperationMethod<GetReadSetActivationJobRequest & RegionInput, GetReadSetActivationJobResponse, GetReadSetActivationJobError, Credentials | HttpClient.HttpClient>;
export type GetReadSetExportJobError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves status information about a read set export job and returns the data in JSON format. Use this operation to actively monitor the progress of an export job.
 */
export declare const getReadSetExportJob: API.OperationMethod<GetReadSetExportJobRequest & RegionInput, GetReadSetExportJobResponse, GetReadSetExportJobError, Credentials | HttpClient.HttpClient>;
export type GetReadSetImportJobError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets detailed and status information about a read set import job and returns the data in JSON format.
 */
export declare const getReadSetImportJob: API.OperationMethod<GetReadSetImportJobRequest & RegionInput, GetReadSetImportJobResponse, GetReadSetImportJobError, Credentials | HttpClient.HttpClient>;
export type GetReadSetMetadataError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the metadata for a read set from a sequence store in JSON format. This operation does not return tags. To retrieve the list of tags for a read set, use the `ListTagsForResource` API operation.
 */
export declare const getReadSetMetadata: API.OperationMethod<GetReadSetMetadataRequest & RegionInput, GetReadSetMetadataResponse, GetReadSetMetadataError, Credentials | HttpClient.HttpClient>;
export type GetReferenceError = AccessDeniedException | InternalServerException | RangeNotSatisfiableException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Downloads parts of data from a reference genome and returns the reference file in the same format that it was uploaded.
 *
 * For more information, see Creating a HealthOmics reference store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const getReference: API.OperationMethod<GetReferenceRequest & RegionInput, GetReferenceResponse, GetReferenceError, Credentials | HttpClient.HttpClient>;
export type GetReferenceImportJobError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Monitors the status of a reference import job. This operation can be called after calling the `StartReferenceImportJob` operation.
 */
export declare const getReferenceImportJob: API.OperationMethod<GetReferenceImportJobRequest & RegionInput, GetReferenceImportJobResponse, GetReferenceImportJobError, Credentials | HttpClient.HttpClient>;
export type GetReferenceMetadataError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves metadata for a reference genome. This operation returns the number of parts, part size, and MD5 of an entire file. This operation does not return tags. To retrieve the list of tags for a read set, use the `ListTagsForResource` API operation.
 */
export declare const getReferenceMetadata: API.OperationMethod<GetReferenceMetadataRequest & RegionInput, GetReferenceMetadataResponse, GetReferenceMetadataError, Credentials | HttpClient.HttpClient>;
export type GetReferenceStoreError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a reference store.
 */
export declare const getReferenceStore: API.OperationMethod<GetReferenceStoreRequest & RegionInput, GetReferenceStoreResponse, GetReferenceStoreError, Credentials | HttpClient.HttpClient>;
export type GetRunError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets detailed information about a specific run using its ID.
 *
 * Amazon Web Services HealthOmics stores a configurable number of runs, as determined by service limits, that are available to the console and API. If `GetRun` does not return the requested run, you can find all run logs in the CloudWatch logs. For more information about viewing the run logs, see CloudWatch logs in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const getRun: API.OperationMethod<GetRunRequest & RegionInput, GetRunResponse, GetRunError, Credentials | HttpClient.HttpClient>;
export type GetRunCacheError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about the specified run cache using its ID.
 *
 * For more information, see Call caching for Amazon Web Services HealthOmics runs in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const getRunCache: API.OperationMethod<GetRunCacheRequest & RegionInput, GetRunCacheResponse, GetRunCacheError, Credentials | HttpClient.HttpClient>;
export type GetRunGroupError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a run group and returns its metadata.
 */
export declare const getRunGroup: API.OperationMethod<GetRunGroupRequest & RegionInput, GetRunGroupResponse, GetRunGroupError, Credentials | HttpClient.HttpClient>;
export type GetRunTaskError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets detailed information about a run task using its ID.
 */
export declare const getRunTask: API.OperationMethod<GetRunTaskRequest & RegionInput, GetRunTaskResponse, GetRunTaskError, Credentials | HttpClient.HttpClient>;
export type GetS3AccessPolicyError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about an access policy on a given store.
 */
export declare const getS3AccessPolicy: API.OperationMethod<GetS3AccessPolicyRequest & RegionInput, GetS3AccessPolicyResponse, GetS3AccessPolicyError, Credentials | HttpClient.HttpClient>;
export type GetSequenceStoreError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves metadata for a sequence store using its ID and returns it in JSON format.
 */
export declare const getSequenceStore: API.OperationMethod<GetSequenceStoreRequest & RegionInput, GetSequenceStoreResponse, GetSequenceStoreError, Credentials | HttpClient.HttpClient>;
export type GetShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the metadata for the specified resource share.
 */
export declare const getShare: API.OperationMethod<GetShareRequest & RegionInput, GetShareResponse, GetShareError, Credentials | HttpClient.HttpClient>;
export type GetVariantImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Gets information about a variant import job.
 */
export declare const getVariantImportJob: API.OperationMethod<GetVariantImportRequest & RegionInput, GetVariantImportResponse, GetVariantImportJobError, Credentials | HttpClient.HttpClient>;
export type GetVariantStoreError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Gets information about a variant store.
 */
export declare const getVariantStore: API.OperationMethod<GetVariantStoreRequest & RegionInput, GetVariantStoreResponse, GetVariantStoreError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all information about a workflow using its ID.
 *
 * If a workflow is shared with you, you cannot export the workflow.
 *
 * For more information about your workflow status, see Verify the workflow status in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest & RegionInput, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowVersionError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a workflow version. For more information, see Workflow versioning in Amazon Web Services HealthOmics in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const getWorkflowVersion: API.OperationMethod<GetWorkflowVersionRequest & RegionInput, GetWorkflowVersionResponse, GetWorkflowVersionError, Credentials | HttpClient.HttpClient>;
export type ListAnnotationImportJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Retrieves a list of annotation import jobs.
 */
export declare const listAnnotationImportJobs: API.PaginatedOperationMethod<ListAnnotationImportJobsRequest & RegionInput, ListAnnotationImportJobsResponse, ListAnnotationImportJobsError, Credentials | HttpClient.HttpClient, AnnotationImportJobItem>;
export type ListAnnotationStoresError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Retrieves a list of annotation stores.
 */
export declare const listAnnotationStores: API.PaginatedOperationMethod<ListAnnotationStoresRequest & RegionInput, ListAnnotationStoresResponse, ListAnnotationStoresError, Credentials | HttpClient.HttpClient, AnnotationStoreItem>;
export type ListAnnotationStoreVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the versions of an annotation store.
 */
export declare const listAnnotationStoreVersions: API.PaginatedOperationMethod<ListAnnotationStoreVersionsRequest & RegionInput, ListAnnotationStoreVersionsResponse, ListAnnotationStoreVersionsError, Credentials | HttpClient.HttpClient, AnnotationStoreVersionItem>;
export type ListBatchError = AccessDeniedException | InternalServerException | RequestTimeoutException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of run batches in your account, with optional filtering by status, name, or run group. Results are paginated. Only one filter per call is supported.
 */
export declare const listBatch: API.PaginatedOperationMethod<ListBatchRequest & RegionInput, ListBatchResponse, ListBatchError, Credentials | HttpClient.HttpClient, BatchListItem>;
export type ListConfigurationsError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all configurations for the account.
 */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsRequest & RegionInput, ListConfigurationsResponse, ListConfigurationsError, Credentials | HttpClient.HttpClient, ConfigurationListItem>;
export type ListMultipartReadSetUploadsError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists in-progress multipart read set uploads for a sequence store and returns it in a JSON formatted output. Multipart read set uploads are initiated by the `CreateMultipartReadSetUploads` API operation. This operation returns a response with no body when the upload is complete.
 */
export declare const listMultipartReadSetUploads: API.PaginatedOperationMethod<ListMultipartReadSetUploadsRequest & RegionInput, ListMultipartReadSetUploadsResponse, ListMultipartReadSetUploadsError, Credentials | HttpClient.HttpClient, MultipartReadSetUploadListItem>;
export type ListReadSetActivationJobsError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of read set activation jobs and returns the metadata in a JSON formatted output. To extract metadata from a read set activation job, use the `GetReadSetActivationJob` API operation.
 */
export declare const listReadSetActivationJobs: API.PaginatedOperationMethod<ListReadSetActivationJobsRequest & RegionInput, ListReadSetActivationJobsResponse, ListReadSetActivationJobsError, Credentials | HttpClient.HttpClient, ActivateReadSetJobItem>;
export type ListReadSetExportJobsError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of read set export jobs in a JSON formatted response. This API operation is used to check the status of a read set export job initiated by the `StartReadSetExportJob` API operation.
 */
export declare const listReadSetExportJobs: API.PaginatedOperationMethod<ListReadSetExportJobsRequest & RegionInput, ListReadSetExportJobsResponse, ListReadSetExportJobsError, Credentials | HttpClient.HttpClient, ExportReadSetJobDetail>;
export type ListReadSetImportJobsError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of read set import jobs and returns the data in JSON format.
 */
export declare const listReadSetImportJobs: API.PaginatedOperationMethod<ListReadSetImportJobsRequest & RegionInput, ListReadSetImportJobsResponse, ListReadSetImportJobsError, Credentials | HttpClient.HttpClient, ImportReadSetJobItem>;
export type ListReadSetsError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of read sets from a sequence store ID and returns the metadata in JSON format.
 */
export declare const listReadSets: API.PaginatedOperationMethod<ListReadSetsRequest & RegionInput, ListReadSetsResponse, ListReadSetsError, Credentials | HttpClient.HttpClient, ReadSetListItem>;
export type ListReadSetUploadPartsError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all parts in a multipart read set upload for a sequence store and returns the metadata in a JSON formatted output.
 */
export declare const listReadSetUploadParts: API.PaginatedOperationMethod<ListReadSetUploadPartsRequest & RegionInput, ListReadSetUploadPartsResponse, ListReadSetUploadPartsError, Credentials | HttpClient.HttpClient, ReadSetUploadPartListItem>;
export type ListReferenceImportJobsError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the metadata of one or more reference import jobs for a reference store.
 */
export declare const listReferenceImportJobs: API.PaginatedOperationMethod<ListReferenceImportJobsRequest & RegionInput, ListReferenceImportJobsResponse, ListReferenceImportJobsError, Credentials | HttpClient.HttpClient, ImportReferenceJobItem>;
export type ListReferencesError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the metadata of one or more reference genomes in a reference store.
 *
 * For more information, see Creating a reference store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const listReferences: API.PaginatedOperationMethod<ListReferencesRequest & RegionInput, ListReferencesResponse, ListReferencesError, Credentials | HttpClient.HttpClient, ReferenceListItem>;
export type ListReferenceStoresError = AccessDeniedException | InternalServerException | RequestTimeoutException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of reference stores linked to your account and returns their metadata in JSON format.
 *
 * For more information, see Creating a reference store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const listReferenceStores: API.PaginatedOperationMethod<ListReferenceStoresRequest & RegionInput, ListReferenceStoresResponse, ListReferenceStoresError, Credentials | HttpClient.HttpClient, ReferenceStoreDetail>;
export type ListRunCachesError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of your run caches and the metadata for each cache.
 */
export declare const listRunCaches: API.PaginatedOperationMethod<ListRunCachesRequest & RegionInput, ListRunCachesResponse, ListRunCachesError, Credentials | HttpClient.HttpClient, RunCacheListItem>;
export type ListRunGroupsError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all run groups and returns the metadata for each run group.
 */
export declare const listRunGroups: API.PaginatedOperationMethod<ListRunGroupsRequest & RegionInput, ListRunGroupsResponse, ListRunGroupsError, Credentials | HttpClient.HttpClient, RunGroupListItem>;
export type ListRunsError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of runs and returns each run's metadata and status.
 *
 * Amazon Web Services HealthOmics stores a configurable number of runs, as determined by service limits, that are available to the console and API. If the `ListRuns` response doesn't include specific runs that you expected, you can find all run logs in the CloudWatch logs. For more information about viewing the run logs, see CloudWatch logs in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const listRuns: API.PaginatedOperationMethod<ListRunsRequest & RegionInput, ListRunsResponse, ListRunsError, Credentials | HttpClient.HttpClient, RunListItem>;
export type ListRunsInBatchError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of individual workflow runs within a specific batch. Use this operation to map each `runSettingId` to its HealthOmics-generated `runId`, and to check the submission status of each run. Only one filter per call is supported.
 */
export declare const listRunsInBatch: API.PaginatedOperationMethod<ListRunsInBatchRequest & RegionInput, ListRunsInBatchResponse, ListRunsInBatchError, Credentials | HttpClient.HttpClient, RunBatchListItem>;
export type ListRunTasksError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tasks and status information within their specified run. Use this operation to monitor runs and to identify which specific tasks have failed.
 */
export declare const listRunTasks: API.PaginatedOperationMethod<ListRunTasksRequest & RegionInput, ListRunTasksResponse, ListRunTasksError, Credentials | HttpClient.HttpClient, TaskListItem>;
export type ListSequenceStoresError = AccessDeniedException | InternalServerException | RequestTimeoutException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of sequence stores and returns each sequence store's metadata.
 *
 * For more information, see Creating a HealthOmics sequence store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const listSequenceStores: API.PaginatedOperationMethod<ListSequenceStoresRequest & RegionInput, ListSequenceStoresResponse, ListSequenceStoresError, Credentials | HttpClient.HttpClient, SequenceStoreDetail>;
export type ListSharesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource shares associated with an account. Use the filter parameter to retrieve a specific subset of the shares.
 */
export declare const listShares: API.PaginatedOperationMethod<ListSharesRequest & RegionInput, ListSharesResponse, ListSharesError, Credentials | HttpClient.HttpClient, ShareDetails>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVariantImportJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Retrieves a list of variant import jobs.
 */
export declare const listVariantImportJobs: API.PaginatedOperationMethod<ListVariantImportJobsRequest & RegionInput, ListVariantImportJobsResponse, ListVariantImportJobsError, Credentials | HttpClient.HttpClient, VariantImportJobItem>;
export type ListVariantStoresError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Retrieves a list of variant stores.
 */
export declare const listVariantStores: API.PaginatedOperationMethod<ListVariantStoresRequest & RegionInput, ListVariantStoresResponse, ListVariantStoresError, Credentials | HttpClient.HttpClient, VariantStoreItem>;
export type ListWorkflowsError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of existing workflows. You can filter for specific workflows by their name and type. Using the type parameter, specify `PRIVATE` to retrieve a list of private workflows or specify `READY2RUN` for a list of all Ready2Run workflows. If you do not specify the type of workflow, this operation returns a list of existing workflows.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest & RegionInput, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, WorkflowListItem>;
export type ListWorkflowVersionsError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the workflow versions for the specified workflow. For more information, see Workflow versioning in Amazon Web Services HealthOmics in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const listWorkflowVersions: API.PaginatedOperationMethod<ListWorkflowVersionsRequest & RegionInput, ListWorkflowVersionsResponse, ListWorkflowVersionsError, Credentials | HttpClient.HttpClient, WorkflowVersionListItem>;
export type PutS3AccessPolicyError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds an access policy to the specified store.
 */
export declare const putS3AccessPolicy: API.OperationMethod<PutS3AccessPolicyRequest & RegionInput, PutS3AccessPolicyResponse, PutS3AccessPolicyError, Credentials | HttpClient.HttpClient>;
export type StartAnnotationImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Starts an annotation import job.
 */
export declare const startAnnotationImportJob: API.OperationMethod<StartAnnotationImportRequest & RegionInput, StartAnnotationImportResponse, StartAnnotationImportJobError, Credentials | HttpClient.HttpClient>;
export type StartReadSetActivationJobError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Activates an archived read set and returns its metadata in a JSON formatted output. Amazon Web Services HealthOmics automatically archives unused read sets after 30 days. To monitor the status of your read set activation job, use the `GetReadSetActivationJob` operation.
 *
 * To learn more, see Activating read sets in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const startReadSetActivationJob: API.OperationMethod<StartReadSetActivationJobRequest & RegionInput, StartReadSetActivationJobResponse, StartReadSetActivationJobError, Credentials | HttpClient.HttpClient>;
export type StartReadSetExportJobError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a read set export job. When the export job is finished, the read set is exported to an Amazon S3 bucket which can be retrieved using the `GetReadSetExportJob` API operation.
 *
 * To monitor the status of the export job, use the `ListReadSetExportJobs` API operation.
 */
export declare const startReadSetExportJob: API.OperationMethod<StartReadSetExportJobRequest & RegionInput, StartReadSetExportJobResponse, StartReadSetExportJobError, Credentials | HttpClient.HttpClient>;
export type StartReadSetImportJobError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports a read set from the sequence store. Read set import jobs support a maximum of 100 read sets of different types. Monitor the progress of your read set import job by calling the `GetReadSetImportJob` API operation.
 */
export declare const startReadSetImportJob: API.OperationMethod<StartReadSetImportJobRequest & RegionInput, StartReadSetImportJobResponse, StartReadSetImportJobError, Credentials | HttpClient.HttpClient>;
export type StartReferenceImportJobError = AccessDeniedException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports a reference genome from Amazon S3 into a specified reference store. You can have multiple reference genomes in a reference store. You can only import reference genomes one at a time into each reference store. Monitor the status of your reference import job by using the `GetReferenceImportJob` API operation.
 */
export declare const startReferenceImportJob: API.OperationMethod<StartReferenceImportJobRequest & RegionInput, StartReferenceImportJobResponse, StartReferenceImportJobError, Credentials | HttpClient.HttpClient>;
export type StartRunError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new run and returns details about the run, or duplicates an existing run. A run is a single invocation of a workflow. If you provide request IDs, Amazon Web Services HealthOmics identifies duplicate requests and starts the run only once. Monitor the progress of the run by calling the `GetRun` API operation.
 *
 * To start a new run, the following inputs are required:
 *
 * - A service role ARN (`roleArn`).
 *
 * - The run's workflow ID (`workflowId`, not the `uuid` or `runId`).
 *
 * - An Amazon S3 location (`outputUri`) where the run outputs will be saved.
 *
 * - All required workflow parameters (`parameter`), which can include optional parameters from the parameter template. The run cannot include any parameters that are not defined in the parameter template. To see all possible parameters, use the `GetRun` API operation.
 *
 * - For runs with a `STATIC` (default) storage type, specify the required storage capacity (in gibibytes). A storage capacity value is not required for runs that use `DYNAMIC` storage.
 *
 * `StartRun` can also duplicate an existing run using the run's default values. You can modify these default values and/or add other optional inputs. To duplicate a run, the following inputs are required:
 *
 * - A service role ARN (`roleArn`).
 *
 * - The ID of the run to duplicate (`runId`).
 *
 * - An Amazon S3 location where the run outputs will be saved (`outputUri`).
 *
 * To learn more about the optional parameters for `StartRun`, see Starting a run in the *Amazon Web Services HealthOmics User Guide*.
 *
 * Use the `retentionMode` input to control how long the metadata for each run is stored in CloudWatch. There are two retention modes:
 *
 * - Specify `REMOVE` to automatically remove the oldest runs when you reach the maximum service retention limit for runs. It is recommended that you use the `REMOVE` mode to initiate major run requests so that your runs do not fail when you reach the limit.
 *
 * - The `retentionMode` is set to the `RETAIN` mode by default, which allows you to manually remove runs after reaching the maximum service retention limit. Under this setting, you cannot create additional runs until you remove the excess runs.
 *
 * To learn more about the retention modes, see Run retention mode in the *Amazon Web Services HealthOmics User Guide*.
 *
 * You can use Amazon Q CLI to analyze run logs and make performance optimization recommendations. To get started, see the Amazon Web Services HealthOmics MCP server on GitHub.
 */
export declare const startRun: API.OperationMethod<StartRunRequest & RegionInput, StartRunResponse, StartRunError, Credentials | HttpClient.HttpClient>;
export type StartRunBatchError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a batch of workflow runs. You can group up to 100,000 runs into a single batch that share a common configuration defined in `defaultRunSetting`. Per-run overrides can be provided either inline via `inlineSettings` (up to 100 runs) or via a JSON file stored in Amazon S3 via `s3UriSettings` (up to 100,000 runs).
 *
 * `StartRunBatch` validates common fields synchronously and returns immediately with a batch ID and status `CREATING`. The batch transitions to `PENDING` once initial setup completes. Runs are then submitted gradually and asynchronously at a rate governed by your `StartRun` throughput quota.
 */
export declare const startRunBatch: API.OperationMethod<StartRunBatchRequest & RegionInput, StartRunBatchResponse, StartRunBatchError, Credentials | HttpClient.HttpClient>;
export type StartVariantImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Starts a variant import job.
 */
export declare const startVariantImportJob: API.OperationMethod<StartVariantImportRequest & RegionInput, StartVariantImportResponse, StartVariantImportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tags a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnnotationStoreError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Updates an annotation store.
 */
export declare const updateAnnotationStore: API.OperationMethod<UpdateAnnotationStoreRequest & RegionInput, UpdateAnnotationStoreResponse, UpdateAnnotationStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateAnnotationStoreVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the description of an annotation store version.
 */
export declare const updateAnnotationStoreVersion: API.OperationMethod<UpdateAnnotationStoreVersionRequest & RegionInput, UpdateAnnotationStoreVersionResponse, UpdateAnnotationStoreVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateRunCacheError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a run cache using its ID and returns a response with no body if the operation is successful. You can update the run cache description, name, or the default run cache behavior with `CACHE_ON_FAILURE` or `CACHE_ALWAYS`. To confirm that your run cache settings have been properly updated, use the `GetRunCache` API operation.
 *
 * For more information, see How call caching works in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const updateRunCache: API.OperationMethod<UpdateRunCacheRequest & RegionInput, UpdateRunCacheResponse, UpdateRunCacheError, Credentials | HttpClient.HttpClient>;
export type UpdateRunGroupError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the settings of a run group and returns a response with no body if the operation is successful.
 *
 * You can update the following settings with `UpdateRunGroup`:
 *
 * - Maximum number of CPUs
 *
 * - Run time (measured in minutes)
 *
 * - Number of GPUs
 *
 * - Number of concurrent runs
 *
 * - Group name
 *
 * To confirm that the settings have been successfully updated, use the `ListRunGroups` or `GetRunGroup` API operations to verify that the desired changes have been made.
 */
export declare const updateRunGroup: API.OperationMethod<UpdateRunGroupRequest & RegionInput, UpdateRunGroupResponse, UpdateRunGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateSequenceStoreError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update one or more parameters for the sequence store.
 */
export declare const updateSequenceStore: API.OperationMethod<UpdateSequenceStoreRequest & RegionInput, UpdateSequenceStoreResponse, UpdateSequenceStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateVariantStoreError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Web Services HealthOmics variant stores and annotation stores are no longer open to new customers. Existing customers can continue to use the service as normal. For more information, see Amazon Web Services HealthOmics variant store and annotation store availability change.
 *
 * Updates a variant store.
 */
export declare const updateVariantStore: API.OperationMethod<UpdateVariantStoreRequest & RegionInput, UpdateVariantStoreResponse, UpdateVariantStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information about a workflow.
 *
 * You can update the following workflow information:
 *
 * - Name
 *
 * - Description
 *
 * - Default storage type
 *
 * - Default storage capacity (with workflow ID)
 *
 * This operation returns a response with no body if the operation is successful. You can check the workflow updates by calling the `GetWorkflow` API operation.
 *
 * For more information, see Update a private workflow in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const updateWorkflow: API.OperationMethod<UpdateWorkflowRequest & RegionInput, UpdateWorkflowResponse, UpdateWorkflowError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowVersionError = AccessDeniedException | ConflictException | InternalServerException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information about the workflow version. For more information, see Workflow versioning in Amazon Web Services HealthOmics in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const updateWorkflowVersion: API.OperationMethod<UpdateWorkflowVersionRequest & RegionInput, UpdateWorkflowVersionResponse, UpdateWorkflowVersionError, Credentials | HttpClient.HttpClient>;
export type UploadReadSetPartError = AccessDeniedException | InternalServerException | NotSupportedOperationException | RequestTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Uploads a specific part of a read set into a sequence store. When you a upload a read set part with a part number that already exists, the new part replaces the existing one. This operation returns a JSON formatted response containing a string identifier that is used to confirm that parts are being added to the intended upload.
 *
 * For more information, see Direct upload to a sequence store in the *Amazon Web Services HealthOmics User Guide*.
 */
export declare const uploadReadSetPart: API.OperationMethod<UploadReadSetPartRequest & RegionInput, UploadReadSetPartResponse, UploadReadSetPartError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=omics.d.ts.map