/**
 * R2's S3-compatible API with the credentials this SDK already holds.
 * `@distilled.cloud/cloudflare/r2` re-exports it.
 *
 * `layerS3` provides `@distilled.cloud/s3`'s `Credentials` and `Endpoint`
 * from the Cloudflare `Credentials`:
 *
 * - The keys: R2 accepts an API token as S3 keys. The token's id (from
 *   `/user/tokens/verify`, or `/accounts/{account_id}/tokens/verify` for an
 *   account-owned token) is the access key id, and the SHA-256 of the token
 *   is the secret access key.
 * - The endpoint: `https://<account_id>[.<jurisdiction>].r2.cloudflarestorage.com`,
 *   for the credentials' `accountId`, or else the one account the token can
 *   reach, and the `Jurisdiction` layer (default: Cloudflare's default
 *   jurisdiction).
 *
 * Both are looked up on the first S3 call and kept.
 *
 * @example
 * ```ts
 * import * as S3 from "@distilled.cloud/s3";
 * import * as R2 from "@distilled.cloud/cloudflare/r2";
 *
 * const keys = S3.listObjectsV2({ Bucket: "my-bucket" }).pipe(
 *   Effect.provide(R2.layerS3()),
 * );
 * ```
 */
import * as CoreCrypto from "@distilled.cloud/core/crypto";
import { loadModule, type SdkError } from "@distilled.cloud/core/sdk-error";
import type * as S3Credentials from "@distilled.cloud/s3/Credentials";
import type * as S3Endpoint from "@distilled.cloud/s3/Endpoint";
import * as Context from "effect/Context";
import * as Data from "effect/Data";
import * as Effect from "effect/Effect";
import type * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import { Credentials } from "./credentials.ts";
import { Jurisdiction } from "./jurisdiction.ts";
import type { InvalidApiToken } from "./services/user.ts";

/** The Cloudflare credentials could not be turned into R2 S3 keys or an endpoint. */
export class S3CredentialsError
  extends /*@__PURE__*/ Data.TaggedError("CloudflareR2S3CredentialsError")<{
    message: string;
    cause?: unknown;
  }> {}

// Every S3 operation's error type includes it in programs that use this module.
declare module "@distilled.cloud/s3/Credentials" {
  interface ProviderErrors {
    cloudflare: S3CredentialsError;
  }
}

const loadFailure = (e: SdkError) =>
  new S3CredentialsError({ message: `the R2 S3 layer could not load: ${e.message}`, cause: e });

interface Resolved {
  readonly keys: S3Credentials.ResolvedCredentials;
  readonly endpoint: string;
}

/**
 * Verify an API token at the endpoint for its kind, for its id. An
 * account-owned token (`cfat_`) verifies only at the account endpoint, a user
 * token (`cfut_`) only at the user one. A token from before the prefixes
 * tries the user endpoint and moves to the account endpoint only on its
 * `InvalidApiToken` (401, code 1000), which is what an account-owned token
 * gets there; any other failure (a 503, throttling) is the caller's.
 */
const verifyApiToken = <A, E1, E2, R1, R2>(
  token: string,
  verify: {
    readonly user: Effect.Effect<A, E1 | InvalidApiToken, R1>;
    readonly account: Effect.Effect<A, E2, R2>;
  },
): Effect.Effect<A, E1 | E2 | InvalidApiToken, R1 | R2> =>
  token.startsWith("cfat_")
    ? verify.account
    : token.startsWith("cfut_")
      ? verify.user
      : verify.user.pipe(Effect.catchTag("InvalidApiToken", () => verify.account));

/**
 * `@distilled.cloud/s3`'s `Credentials` (region `auto`) and `Endpoint` for
 * the R2 buckets of the account the Cloudflare `Credentials` act on.
 */
export const layerS3 = (): Layer.Layer<
  S3Credentials.Credentials | S3Endpoint.Endpoint,
  S3CredentialsError,
  Credentials | HttpClient.HttpClient
> =>
  // The S3 runtime and the account APIs load when the layer is built, so
  // importing `r2` costs neither.
  Layer.unwrap(
    Effect.gen(function* () {
      const [{ Credentials: S3Keys }, { Endpoint }] = yield* loadModule(() =>
        Promise.all([
          import("@distilled.cloud/s3/Credentials"),
          import("@distilled.cloud/s3/Endpoint"),
        ]),
      ).pipe(Effect.mapError(loadFailure));
      const context = yield* Effect.context<Credentials | HttpClient.HttpClient>();
      const resolve = Effect.gen(function* () {
        const credentials = yield* yield* Credentials;
        if (credentials.type !== "apiToken")
          return yield* new S3CredentialsError({
            message: `R2's S3 API signs with an API token; the Cloudflare credentials are ${credentials.type === "apiKey" ? "a global API key" : "an OAuth token"}.`,
          });
        const [Accounts, User] = yield* loadModule(() =>
          Promise.all([import("./services/accounts.ts"), import("./services/user.ts")]),
        ).pipe(Effect.mapError(loadFailure));
        const accountId = credentials.accountId ?? (yield* onlyAccount(Accounts.listAccounts({})));
        const token = yield* verifyApiToken(Redacted.value(credentials.apiToken), {
          user: User.verifyToken({}),
          account: Accounts.verifyToken({ accountId }),
        });
        const crypto = yield* CoreCrypto.Crypto;
        const secret = yield* crypto.sha256(Redacted.value(credentials.apiToken));
        return {
          keys: {
            accessKeyId: Redacted.make(token.id),
            secretAccessKey: Redacted.make(CoreCrypto.hex(secret)),
            sessionToken: undefined,
            region: "auto",
          },
          endpoint: endpoint(accountId, Context.getOrUndefined(context, Jurisdiction) ?? "default"),
        } satisfies Resolved;
      }).pipe(
        Effect.provideContext(context),
        Effect.mapError((cause) =>
          cause instanceof S3CredentialsError
            ? cause
            : new S3CredentialsError({
                message: "Could not look up the Cloudflare API token's id or account.",
                cause,
              }),
        ),
      );
      // Successes only: a failed lookup is tried again on the next call.
      let resolved: Resolved | undefined;
      const cached = Effect.suspend(() =>
        resolved
          ? Effect.succeed(resolved)
          : Effect.tap(resolve, (r) => Effect.sync(() => (resolved = r))),
      );
      return Layer.mergeAll(
        Layer.succeed(
          S3Keys,
          Effect.map(cached, (r) => r.keys),
        ),
        Layer.succeed(
          Endpoint,
          Effect.map(cached, (r) => r.endpoint),
        ),
      );
    }),
  );

/** An account's R2 S3 endpoint in a jurisdiction. */
const endpoint = (accountId: string, jurisdiction: string) =>
  `https://${accountId}${jurisdiction === "default" ? "" : `.${jurisdiction}`}.r2.cloudflarestorage.com`;

/** The id of the one account `accounts` lists, or why there is no single one. */
const onlyAccount = <E, R>(
  accounts: Effect.Effect<
    { readonly result: ReadonlyArray<{ readonly id: string; readonly name: string }> },
    E,
    R
  >,
) =>
  Effect.flatMap(accounts, ({ result }) =>
    result.length === 1
      ? Effect.succeed(result[0]!.id)
      : Effect.fail(
          new S3CredentialsError({
            message:
              result.length === 0
                ? "The Cloudflare API token reaches no account."
                : `The Cloudflare API token reaches ${result.length} accounts (${result.map((a) => a.name).join(", ")}); set accountId in the Cloudflare credentials (CLOUDFLARE_ACCOUNT_ID).`,
          }),
        ),
  );
