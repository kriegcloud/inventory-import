import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface CheckIsStarredRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
}
export interface CheckIsStarredResponse {
}
export interface CreateRequestFilesValue {
    /** Content of the file */
    content: string;
}
/** Names and content for the files that make up the gist */
export type CreateRequestFilesMap = {
    [key: string]: CreateRequestFilesValue | undefined;
};
export type CreateRequestPublicCase1 = "true" | "false";
export type CreateRequestPublic = boolean | CreateRequestPublicCase1;
export interface CreateRequest {
    /** Description of the gist */
    description?: string | undefined;
    /** Names and content for the files that make up the gist */
    files: CreateRequestFilesMap;
    public?: CreateRequestPublic | undefined;
}
export interface PublicUserPlan {
    collaborators: number;
    name: string;
    space: number;
    private_repos: number;
}
/** Public User */
export interface PublicUser {
    login: string;
    id: number;
    user_view_type?: string | undefined;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    name: string | null;
    company: string | null;
    blog: string | null;
    location: string | null;
    email: string | null;
    notification_email?: string | null | undefined;
    hireable: boolean | null;
    bio: string | null;
    twitter_username?: string | null | undefined;
    public_repos: number;
    public_gists: number;
    followers: number;
    following: number;
    created_at: string;
    updated_at: string;
    plan?: PublicUserPlan | undefined;
    private_gists?: number | undefined;
    total_private_repos?: number | undefined;
    owned_private_repos?: number | undefined;
    disk_usage?: number | undefined;
    collaborators?: number | undefined;
}
export interface GistSimpleForksItem {
    id?: string | undefined;
    url?: string | undefined;
    user?: PublicUser | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
}
export type GistSimpleForksList = Array<GistSimpleForksItem>;
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export interface GistHistoryChangeStatus {
    total?: number | undefined;
    additions?: number | undefined;
    deletions?: number | undefined;
}
/** Gist History */
export interface GistHistory {
    user?: NullableSimpleUser | null | undefined;
    version?: string | undefined;
    committed_at?: string | undefined;
    change_status?: GistHistoryChangeStatus | undefined;
    url?: string | undefined;
}
export type GistSimpleHistoryList = Array<GistHistory>;
export interface GistSimpleForkOfFilesValue {
    filename?: string | undefined;
    type?: string | undefined;
    language?: string | undefined;
    raw_url?: string | undefined;
    size?: number | undefined;
}
export type GistSimpleForkOfFilesMap = {
    [key: string]: GistSimpleForkOfFilesValue | undefined;
};
export type GistSimpleForkOfForksList = Array<unknown>;
export type GistSimpleForkOfHistoryList = Array<unknown>;
/** Gist */
export interface GistSimpleForkOf {
    url: string;
    forks_url: string;
    commits_url: string;
    id: string;
    node_id: string;
    git_pull_url: string;
    git_push_url: string;
    html_url: string;
    files: GistSimpleForkOfFilesMap;
    public: boolean;
    created_at: string;
    updated_at: string;
    description: string | null;
    comments: number;
    comments_enabled?: boolean | undefined;
    user: NullableSimpleUser | null;
    comments_url: string;
    owner?: NullableSimpleUser | null | undefined;
    truncated?: boolean | undefined;
    forks?: GistSimpleForkOfForksList | undefined;
    history?: GistSimpleForkOfHistoryList | undefined;
}
export interface GistSimpleFilesValue {
    filename?: string | undefined;
    type?: string | undefined;
    language?: string | undefined;
    raw_url?: string | undefined;
    size?: number | undefined;
    truncated?: boolean | undefined;
    content?: string | undefined;
    /** The encoding used for `content`. Currently, `"utf-8"` and `"base64"` are supported. */
    encoding?: string | undefined;
}
export type GistSimpleFilesMap = {
    [key: string]: GistSimpleFilesValue | null | undefined;
};
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
/** Gist Simple */
export interface GistSimple {
    forks?: GistSimpleForksList | null | undefined;
    history?: GistSimpleHistoryList | null | undefined;
    /** Gist */
    fork_of?: GistSimpleForkOf | null | undefined;
    url?: string | undefined;
    forks_url?: string | undefined;
    commits_url?: string | undefined;
    id?: string | undefined;
    node_id?: string | undefined;
    git_pull_url?: string | undefined;
    git_push_url?: string | undefined;
    html_url?: string | undefined;
    files?: GistSimpleFilesMap | undefined;
    public?: boolean | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
    description?: string | null | undefined;
    comments?: number | undefined;
    comments_enabled?: boolean | undefined;
    user?: string | null | undefined;
    comments_url?: string | undefined;
    owner?: NullableSimpleUser | undefined;
    truncated?: boolean | undefined;
}
export interface CreateCommentRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    /** The comment text. */
    body: string;
}
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
/** A comment made to a gist. */
export interface GistComment {
    id: number;
    node_id: string;
    url: string;
    /** The comment text. */
    body: string;
    user: NullableSimpleUser | null;
    created_at: string;
    updated_at: string;
    author_association: AuthorAssociation;
}
export interface DeleteRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
}
export interface DeleteResponse {
}
export interface DeleteCommentRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface DeleteCommentResponse {
}
export interface ForkRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
}
export interface BaseGistFilesValue {
    filename?: string | undefined;
    type?: string | undefined;
    language?: string | undefined;
    raw_url?: string | undefined;
    size?: number | undefined;
    /** The encoding used for `content`. Currently, `"utf-8"` and `"base64"` are supported. */
    encoding?: string | undefined;
}
export type BaseGistFilesMap = {
    [key: string]: BaseGistFilesValue | undefined;
};
export type BaseGistForksList = Array<unknown>;
export type BaseGistHistoryList = Array<unknown>;
/** Base Gist */
export interface BaseGist {
    url: string;
    forks_url: string;
    commits_url: string;
    id: string;
    node_id: string;
    git_pull_url: string;
    git_push_url: string;
    html_url: string;
    files: BaseGistFilesMap;
    public: boolean;
    created_at: string;
    updated_at: string;
    description: string | null;
    comments: number;
    comments_enabled?: boolean | undefined;
    user: NullableSimpleUser | null;
    comments_url: string;
    owner?: NullableSimpleUser | undefined;
    truncated?: boolean | undefined;
    forks?: BaseGistForksList | undefined;
    history?: BaseGistHistoryList | undefined;
}
export interface GetRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
}
export interface GetCommentRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface GetRevisionRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    sha: string;
}
export interface ListRequest {
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListResponseBodyList = Array<BaseGist>;
export type ListResponse = ListResponseBodyList;
export interface ListCommentsRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListCommentsResponseBodyList = Array<GistComment>;
export type ListCommentsResponse = ListCommentsResponseBodyList;
export interface ListCommitsRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type GistCommitChangeStatus = GistHistoryChangeStatus;
/** Gist Commit */
export interface GistCommit {
    url: string;
    version: string;
    user: NullableSimpleUser | null;
    change_status: GistHistoryChangeStatus;
    committed_at: string;
}
export type ListCommitsResponseBodyList = Array<GistCommit>;
export type ListCommitsResponse = ListCommitsResponseBodyList;
export interface ListForksRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForksResponseBodyList = Array<GistSimple>;
export type ListForksResponse = ListForksResponseBodyList;
export interface ListForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForUserResponseBodyList = Array<BaseGist>;
export type ListForUserResponse = ListForUserResponseBodyList;
export interface ListPublicRequest {
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPublicResponseBodyList = Array<BaseGist>;
export type ListPublicResponse = ListPublicResponseBodyList;
export interface ListStarredRequest {
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListStarredResponseBodyList = Array<BaseGist>;
export type ListStarredResponse = ListStarredResponseBodyList;
export interface StarRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
}
export interface StarResponse {
}
export interface UnstarRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
}
export interface UnstarResponse {
}
export interface UpdateRequestFilesValue {
    /** The new content of the file. */
    content?: string | undefined;
    /** The new filename for the file. */
    filename?: string | null | undefined;
}
/** The gist files to be updated, renamed, or deleted. Each `key` must match the current filename (including extension) of the targeted gist file. For example: `hello.py`. To delete a file, set the whole file to null. For example: `hello.py : null`. The file will also be deleted if the specified object does not contain at least one of `content` or `filename`. */
export type UpdateRequestFilesMap = {
    [key: string]: UpdateRequestFilesValue | null | undefined;
};
export interface UpdateRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    /** The description of the gist. */
    description?: string | undefined;
    /** The gist files to be updated, renamed, or deleted. Each `key` must match the current filename (including extension) of the targeted gist file. For example: `hello.py`. To delete a file, set the whole file to null. For example: `hello.py : null`. The file will also be deleted if the specified object does not contain at least one of `content` or `filename`. */
    files?: UpdateRequestFilesMap | undefined;
}
export interface UpdateCommentRequest {
    /** The unique identifier of the gist. */
    gist_id: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The comment text. */
    body: string;
}
export type CheckIsStarredError = GithubOpError;
/** Check if a gist is starred */
export declare const checkIsStarred: API.OperationMethod<CheckIsStarredRequest, CheckIsStarredResponse, CheckIsStarredError, GithubOpContext>;
export type CreateError = GithubOpError;
/** Create a gist Allows you to add a new gist with one or more files. > [!NOTE] > Don't name your files "gistfile" with a numerical suffix. This is the format of the automatic naming scheme that Gist uses internally. */
export declare const create: API.OperationMethod<CreateRequest, GistSimple, CreateError, GithubOpContext>;
export type CreateCommentError = GithubOpError;
/** Create a gist comment Creates a comment on a gist. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type. */
export declare const createComment: API.OperationMethod<CreateCommentRequest, GistComment, CreateCommentError, GithubOpContext>;
export type DeleteError = GithubOpError;
/** Delete a gist */
export declare const Delete: API.OperationMethod<DeleteRequest, DeleteResponse, DeleteError, GithubOpContext>;
export type DeleteCommentError = GithubOpError;
/** Delete a gist comment */
export declare const deleteComment: API.OperationMethod<DeleteCommentRequest, DeleteCommentResponse, DeleteCommentError, GithubOpContext>;
export type ForkError = GithubOpError;
/** Fork a gist */
export declare const fork: API.OperationMethod<ForkRequest, BaseGist, ForkError, GithubOpContext>;
export type GetError = GithubOpError;
/** Get a gist Gets a specified gist. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type. */
export declare const get: API.OperationMethod<GetRequest, GistSimple, GetError, GithubOpContext>;
export type GetCommentError = GithubOpError;
/** Get a gist comment Gets a comment on a gist. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type. */
export declare const getComment: API.OperationMethod<GetCommentRequest, GistComment, GetCommentError, GithubOpContext>;
export type GetRevisionError = GithubOpError;
/** Get a gist revision Gets a specified gist revision. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type. */
export declare const getRevision: API.OperationMethod<GetRevisionRequest, GistSimple, GetRevisionError, GithubOpContext>;
export type ListError = GithubOpError;
/** List gists for the authenticated user Lists the authenticated user's gists or if called anonymously, this endpoint returns all public gists: */
export declare const list: API.PaginatedOperationMethod<ListRequest, ListResponse, ListError, GithubOpContext, BaseGist>;
export type ListCommentsError = GithubOpError;
/** List gist comments Lists the comments on a gist. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type. */
export declare const listComments: API.PaginatedOperationMethod<ListCommentsRequest, ListCommentsResponse, ListCommentsError, GithubOpContext, GistComment>;
export type ListCommitsError = GithubOpError;
/** List gist commits */
export declare const listCommits: API.PaginatedOperationMethod<ListCommitsRequest, ListCommitsResponse, ListCommitsError, GithubOpContext, GistCommit>;
export type ListForksError = GithubOpError;
/** List gist forks */
export declare const listForks: API.PaginatedOperationMethod<ListForksRequest, ListForksResponse, ListForksError, GithubOpContext, GistSimple>;
export type ListForUserError = GithubOpError;
/** List gists for a user Lists public gists for the specified user: */
export declare const listForUser: API.PaginatedOperationMethod<ListForUserRequest, ListForUserResponse, ListForUserError, GithubOpContext, BaseGist>;
export type ListPublicError = GithubOpError;
/** List public gists List public gists sorted by most recently updated to least recently updated. Note: With [pagination](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api), you can fetch up to 3000 gists. For example, you can fetch 100 pages with 30 gists per page or 30 pages with 100 gists per page. */
export declare const listPublic: API.PaginatedOperationMethod<ListPublicRequest, ListPublicResponse, ListPublicError, GithubOpContext, BaseGist>;
export type ListStarredError = GithubOpError;
/** List starred gists List the authenticated user's starred gists: */
export declare const listStarred: API.PaginatedOperationMethod<ListStarredRequest, ListStarredResponse, ListStarredError, GithubOpContext, BaseGist>;
export type StarError = GithubOpError;
/** Star a gist Note that you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)." */
export declare const star: API.OperationMethod<StarRequest, StarResponse, StarError, GithubOpContext>;
export type UnstarError = GithubOpError;
/** Unstar a gist */
export declare const unstar: API.OperationMethod<UnstarRequest, UnstarResponse, UnstarError, GithubOpContext>;
export type UpdateError = GithubOpError;
/** Update a gist Allows you to update a gist's description and to update, delete, or rename gist files. Files from the previous version of the gist that aren't explicitly changed during an edit are unchanged. At least one of `description` or `files` is required. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type. */
export declare const update: API.OperationMethod<UpdateRequest, GistSimple, UpdateError, GithubOpContext>;
export type UpdateCommentError = GithubOpError;
/** Update a gist comment Updates a comment on a gist. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown. This is the default if you do not pass any specific media type. */
export declare const updateComment: API.OperationMethod<UpdateCommentRequest, GistComment, UpdateCommentError, GithubOpContext>;
//# sourceMappingURL=gists.d.ts.map