import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly resourceName: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AccountIdString = string;
export type AccountIdList = string[];
export interface BatchGetInvoiceProfileRequest {
    AccountIds: string[];
}
export type BasicStringWithoutSpace = string;
export type BasicString = string;
export interface ReceiverAddress {
    AddressLine1?: string | undefined;
    AddressLine2?: string | undefined;
    AddressLine3?: string | undefined;
    DistrictOrCounty?: string | undefined;
    City?: string | undefined;
    StateOrRegion?: string | undefined;
    CountryCode?: string | undefined;
    CompanyName?: string | undefined;
    PostalCode?: string | undefined;
}
export type SensitiveBasicStringWithoutSpace = string | redacted.Redacted<string>;
export interface InvoiceProfile {
    AccountId?: string | undefined;
    ReceiverName?: string | undefined;
    ReceiverAddress?: ReceiverAddress | undefined;
    ReceiverEmail?: string | redacted.Redacted<string> | undefined;
    Issuer?: string | undefined;
    TaxRegistrationNumber?: string | redacted.Redacted<string> | undefined;
}
export type ProfileList = InvoiceProfile[];
export interface BatchGetInvoiceProfileResponse {
    Profiles?: InvoiceProfile[] | undefined;
}
export type InvoiceUnitName = string;
export type DescriptionString = string;
export type TaxInheritanceDisabledFlag = boolean;
export type RuleAccountIdList = string[];
export interface InvoiceUnitRule {
    LinkedAccounts?: string[] | undefined;
    BillSourceAccounts?: string[] | undefined;
}
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value: string;
}
export type ResourceTagList = ResourceTag[];
export interface CreateInvoiceUnitRequest {
    Name: string;
    InvoiceReceiver: string;
    Description?: string | undefined;
    TaxInheritanceDisabled?: boolean | undefined;
    Rule: InvoiceUnitRule;
    ResourceTags?: ResourceTag[] | undefined;
    ClientToken?: string | undefined;
}
export type InvoiceUnitArnString = string;
export interface CreateInvoiceUnitResponse {
    InvoiceUnitArn?: string | undefined;
}
export type ProcurementPortalName = "SAP_BUSINESS_NETWORK" | "COUPA" | (string & {});
export type BuyerDomain = "NetworkID" | (string & {});
export type SupplierDomain = "NetworkID" | (string & {});
export type InvoiceUnitArns = string[];
export type SellerOfRecords = string[];
export interface ProcurementPortalPreferenceSelector {
    InvoiceUnitArns?: string[] | undefined;
    SellerOfRecords?: string[] | undefined;
}
export interface TestEnvPreferenceInput {
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    ProcurementPortalSharedSecret?: string | undefined;
    ProcurementPortalInstanceEndpoint?: string | undefined;
}
export type EinvoiceDeliveryDocumentType = "AWS_CLOUD_INVOICE" | "AWS_CLOUD_CREDIT_MEMO" | "AWS_MARKETPLACE_INVOICE" | "AWS_MARKETPLACE_CREDIT_MEMO" | "AWS_REQUEST_FOR_PAYMENT" | (string & {});
export type EinvoiceDeliveryDocumentTypes = EinvoiceDeliveryDocumentType[];
export type EinvoiceDeliveryAttachmentType = "INVOICE_PDF" | "RFP_PDF" | (string & {});
export type EinvoiceDeliveryAttachmentTypes = EinvoiceDeliveryAttachmentType[];
export type Protocol = "CXML" | (string & {});
export type PurchaseOrderDataSourceType = "ASSOCIATED_PURCHASE_ORDER_REQUIRED" | "PURCHASE_ORDER_NOT_REQUIRED" | (string & {});
export interface PurchaseOrderDataSource {
    EinvoiceDeliveryDocumentType?: EinvoiceDeliveryDocumentType | undefined;
    PurchaseOrderDataSourceType?: PurchaseOrderDataSourceType | undefined;
}
export type PurchaseOrderDataSources = PurchaseOrderDataSource[];
export type ConnectionTestingMethod = "PROD_ENV_DOLLAR_TEST" | "TEST_ENV_REPLAY_TEST" | (string & {});
export interface EinvoiceDeliveryPreference {
    EinvoiceDeliveryDocumentTypes: EinvoiceDeliveryDocumentType[];
    EinvoiceDeliveryAttachmentTypes?: EinvoiceDeliveryAttachmentType[] | undefined;
    Protocol: Protocol;
    PurchaseOrderDataSources: PurchaseOrderDataSource[];
    ConnectionTestingMethod: ConnectionTestingMethod;
    EinvoiceDeliveryActivationDate: Date;
}
export interface MarketplacePunchOutPreference {
    ApprovalRequestRedirectUrl?: string | undefined;
}
export type EmailString = string;
export interface Contact {
    Name?: string | undefined;
    Email?: string | undefined;
}
export type Contacts = Contact[];
export interface CreateProcurementPortalPreferenceRequest {
    ProcurementPortalName: ProcurementPortalName;
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    Selector?: ProcurementPortalPreferenceSelector | undefined;
    ProcurementPortalSharedSecret?: string | redacted.Redacted<string> | undefined;
    ProcurementPortalInstanceEndpoint?: string | undefined;
    TestEnvPreference?: TestEnvPreferenceInput | undefined;
    EinvoiceDeliveryEnabled: boolean;
    EinvoiceDeliveryPreference?: EinvoiceDeliveryPreference | undefined;
    PurchaseOrderRetrievalEnabled: boolean;
    MarketplacePunchOutEnabled?: boolean | undefined;
    MarketplacePunchOutPreference?: MarketplacePunchOutPreference | undefined;
    Contacts: Contact[];
    ResourceTags?: ResourceTag[] | undefined;
    ClientToken?: string | undefined;
}
export type ProcurementPortalPreferenceArnString = string;
export interface CreateProcurementPortalPreferenceResponse {
    ProcurementPortalPreferenceArn: string;
}
export interface DeleteInvoiceUnitRequest {
    InvoiceUnitArn: string;
    ClientToken?: string | undefined;
}
export interface DeleteInvoiceUnitResponse {
    InvoiceUnitArn?: string | undefined;
}
export interface DeleteProcurementPortalPreferenceRequest {
    ProcurementPortalPreferenceArn: string;
    ClientToken?: string | undefined;
}
export interface DeleteProcurementPortalPreferenceResponse {
    ProcurementPortalPreferenceArn: string;
}
export type StringWithoutNewLine = string;
export interface GetInvoicePDFRequest {
    InvoiceId: string;
}
export type SupplementalDocumentType = "GOVERNMENT_INVOICE" | "TAX_E_INVOICE" | "PAYMENT_RECEIPT" | "SUPPLEMENT" | (string & {});
export interface SupplementalDocument {
    DocumentType?: SupplementalDocumentType | undefined;
    DocumentId?: string | undefined;
    DocumentUrl?: string | undefined;
    DocumentUrlExpirationDate?: Date | undefined;
}
export type SupplementalDocuments = SupplementalDocument[];
export interface InvoicePDF {
    InvoiceId?: string | undefined;
    DocumentUrl?: string | undefined;
    DocumentUrlExpirationDate?: Date | undefined;
    SupplementalDocuments?: SupplementalDocument[] | undefined;
}
export interface GetInvoicePDFResponse {
    InvoicePDF?: InvoicePDF | undefined;
}
export type AsOfTimestamp = Date;
export interface GetInvoiceUnitRequest {
    InvoiceUnitArn: string;
    AsOf?: Date | undefined;
}
export type LastModifiedTimestamp = Date;
export interface GetInvoiceUnitResponse {
    InvoiceUnitArn?: string | undefined;
    InvoiceReceiver?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    TaxInheritanceDisabled?: boolean | undefined;
    Rule?: InvoiceUnitRule | undefined;
    LastModified?: Date | undefined;
}
export interface GetProcurementPortalPreferenceRequest {
    ProcurementPortalPreferenceArn: string;
}
export interface TestEnvPreference {
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    ProcurementPortalSharedSecret?: string | undefined;
    ProcurementPortalInstanceEndpoint?: string | undefined;
    PurchaseOrderRetrievalEndpoint?: string | undefined;
}
export type ProcurementPortalPreferenceStatus = "PENDING_VERIFICATION" | "VALIDATED" | "TEST_INITIALIZED" | "TEST_INITIALIZATION_FAILED" | "TEST_FAILED" | "ACTIVE" | "SUSPENDED" | (string & {});
export interface ProcurementPortalPreference {
    AwsAccountId: string;
    ProcurementPortalPreferenceArn: string;
    ProcurementPortalName: ProcurementPortalName;
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    Selector?: ProcurementPortalPreferenceSelector | undefined;
    ProcurementPortalSharedSecret?: string | undefined;
    ProcurementPortalInstanceEndpoint?: string | undefined;
    PurchaseOrderRetrievalEndpoint?: string | undefined;
    TestEnvPreference?: TestEnvPreference | undefined;
    EinvoiceDeliveryEnabled: boolean;
    EinvoiceDeliveryPreference?: EinvoiceDeliveryPreference | undefined;
    PurchaseOrderRetrievalEnabled: boolean;
    MarketplacePunchOutEnabled?: boolean | undefined;
    MarketplacePunchOutPreference?: MarketplacePunchOutPreference | undefined;
    Contacts?: Contact[] | undefined;
    EinvoiceDeliveryPreferenceStatus?: ProcurementPortalPreferenceStatus | undefined;
    EinvoiceDeliveryPreferenceStatusReason?: string | undefined;
    PurchaseOrderRetrievalPreferenceStatus?: ProcurementPortalPreferenceStatus | undefined;
    PurchaseOrderRetrievalPreferenceStatusReason?: string | undefined;
    Version: number;
    CreateDate: Date;
    LastUpdateDate: Date;
}
export interface GetProcurementPortalPreferenceResponse {
    ProcurementPortalPreference: ProcurementPortalPreference;
}
export type ListInvoiceSummariesResourceType = "ACCOUNT_ID" | "INVOICE_ID" | (string & {});
export interface InvoiceSummariesSelector {
    ResourceType: ListInvoiceSummariesResourceType;
    Value: string;
}
export interface DateInterval {
    StartDate: Date;
    EndDate: Date;
}
export type Month = number;
export type Year = number;
export interface BillingPeriod {
    Month: number;
    Year: number;
}
export type ReceiverRole = "SELLER" | "RESELLER" | "BUYER" | (string & {});
export interface InvoiceSummariesFilter {
    TimeInterval?: DateInterval | undefined;
    BillingPeriod?: BillingPeriod | undefined;
    InvoicingEntity?: string | undefined;
    ReceiverRole?: ReceiverRole | undefined;
}
export type NextTokenString = string;
export type InvoiceSummariesMaxResults = number;
export interface ListInvoiceSummariesRequest {
    Selector: InvoiceSummariesSelector;
    Filter?: InvoiceSummariesFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type BillSourceAccountList = string[];
export type BillingEntity = "AWS" | "AWS_MARKETPLACE" | (string & {});
export interface Entity {
    InvoicingEntity?: string | undefined;
    BillingEntity?: BillingEntity | undefined;
}
export type InvoiceFrequency = "ONE_TIME" | "RECURRING" | (string & {});
export type BillType = "ANNIVERSARY" | "PURCHASE" | "REFUND" | (string & {});
export type InvoiceType = "INVOICE" | "CREDIT_MEMO" | "PAYMENT_RECEIPT" | (string & {});
export type EinvoiceDeliveryStatus = "DELIVERED" | "NOT_DELIVERED" | (string & {});
export type TaxAuthorityStatus = "ISSUED" | "CANCELLED" | (string & {});
export type CurrencyCode = string;
export interface DiscountsBreakdownAmount {
    Description?: string | undefined;
    Amount?: string | undefined;
    Rate?: string | undefined;
}
export type DiscountsBreakdownAmountList = DiscountsBreakdownAmount[];
export interface DiscountsBreakdown {
    Breakdown?: DiscountsBreakdownAmount[] | undefined;
    TotalAmount?: string | undefined;
}
export interface TaxesBreakdownAmount {
    Description?: string | undefined;
    Amount?: string | undefined;
    Rate?: string | undefined;
}
export type TaxesBreakdownAmountList = TaxesBreakdownAmount[];
export interface TaxesBreakdown {
    Breakdown?: TaxesBreakdownAmount[] | undefined;
    TotalAmount?: string | undefined;
}
export interface FeesBreakdownAmount {
    Description?: string | undefined;
    Amount?: string | undefined;
    Rate?: string | undefined;
}
export type FeesBreakdownAmountList = FeesBreakdownAmount[];
export interface FeesBreakdown {
    Breakdown?: FeesBreakdownAmount[] | undefined;
    TotalAmount?: string | undefined;
}
export interface AmountBreakdown {
    SubTotalAmount?: string | undefined;
    Discounts?: DiscountsBreakdown | undefined;
    Taxes?: TaxesBreakdown | undefined;
    Fees?: FeesBreakdown | undefined;
}
export interface CurrencyExchangeDetails {
    SourceCurrencyCode?: string | undefined;
    TargetCurrencyCode?: string | undefined;
    Rate?: string | undefined;
}
export interface InvoiceCurrencyAmount {
    TotalAmount?: string | undefined;
    TotalAmountBeforeTax?: string | undefined;
    CurrencyCode?: string | undefined;
    AmountBreakdown?: AmountBreakdown | undefined;
    CurrencyExchangeDetails?: CurrencyExchangeDetails | undefined;
}
export interface InvoiceSummary {
    AccountId?: string | undefined;
    InvoiceId?: string | undefined;
    IssuedDate?: Date | undefined;
    DueDate?: Date | undefined;
    BillSourceAccounts?: string[] | undefined;
    BillSourceAccountsTotalCount?: number | undefined;
    ReceiverRole?: ReceiverRole | undefined;
    Entity?: Entity | undefined;
    BillingPeriod?: BillingPeriod | undefined;
    InvoiceFrequency?: InvoiceFrequency | undefined;
    BillType?: BillType | undefined;
    InvoiceType?: InvoiceType | undefined;
    CommercialInvoiceId?: string | undefined;
    OriginalInvoiceId?: string | undefined;
    PurchaseOrderNumber?: string | undefined;
    EinvoiceDeliveryStatus?: EinvoiceDeliveryStatus | undefined;
    TaxAuthorityStatus?: TaxAuthorityStatus | undefined;
    BaseCurrencyAmount?: InvoiceCurrencyAmount | undefined;
    TaxCurrencyAmount?: InvoiceCurrencyAmount | undefined;
    PaymentCurrencyAmount?: InvoiceCurrencyAmount | undefined;
}
export type InvoiceSummaries = InvoiceSummary[];
export interface ListInvoiceSummariesResponse {
    InvoiceSummaries: InvoiceSummary[];
    NextToken?: string | undefined;
}
export type InvoiceUnitNames = string[];
export interface Filters {
    Names?: string[] | undefined;
    InvoiceReceivers?: string[] | undefined;
    Accounts?: string[] | undefined;
    BillSourceAccounts?: string[] | undefined;
}
export type MaxResultsInteger = number;
export interface ListInvoiceUnitsRequest {
    Filters?: Filters | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AsOf?: Date | undefined;
}
export interface InvoiceUnit {
    InvoiceUnitArn?: string | undefined;
    InvoiceReceiver?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    TaxInheritanceDisabled?: boolean | undefined;
    Rule?: InvoiceUnitRule | undefined;
    LastModified?: Date | undefined;
}
export type InvoiceUnits = InvoiceUnit[];
export interface ListInvoiceUnitsResponse {
    InvoiceUnits?: InvoiceUnit[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResults = number;
export interface ListProcurementPortalPreferencesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ProcurementPortalPreferenceSummary {
    AwsAccountId: string;
    ProcurementPortalPreferenceArn: string;
    ProcurementPortalName: ProcurementPortalName;
    BuyerDomain: BuyerDomain;
    BuyerIdentifier: string;
    SupplierDomain: SupplierDomain;
    SupplierIdentifier: string;
    Selector?: ProcurementPortalPreferenceSelector | undefined;
    EinvoiceDeliveryEnabled: boolean;
    PurchaseOrderRetrievalEnabled: boolean;
    MarketplacePunchOutEnabled?: boolean | undefined;
    EinvoiceDeliveryPreferenceStatus?: ProcurementPortalPreferenceStatus | undefined;
    EinvoiceDeliveryPreferenceStatusReason?: string | undefined;
    PurchaseOrderRetrievalPreferenceStatus?: ProcurementPortalPreferenceStatus | undefined;
    PurchaseOrderRetrievalPreferenceStatusReason?: string | undefined;
    Version: number;
    CreateDate: Date;
    LastUpdateDate: Date;
}
export type ProcurementPortalPreferenceSummaries = ProcurementPortalPreferenceSummary[];
export interface ListProcurementPortalPreferencesResponse {
    ProcurementPortalPreferences?: ProcurementPortalPreferenceSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProcurementPortalsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ProcurementPortalIdString = string;
export interface InvoiceConfiguration {
    DocumentTypes?: EinvoiceDeliveryDocumentType[] | undefined;
    AttachmentTypes?: EinvoiceDeliveryAttachmentType[] | undefined;
}
export interface FeatureConfigurations {
    InvoiceConfiguration?: InvoiceConfiguration | undefined;
}
export interface ProcurementPortal {
    PortalIdentifier: string;
    PortalName: ProcurementPortalName;
    PortalDisplayName?: string | undefined;
    DefaultFeatureConfigurations?: FeatureConfigurations | undefined;
}
export type ProcurementPortals = ProcurementPortal[];
export interface ListProcurementPortalsResponse {
    ProcurementPortals: ProcurementPortal[];
    NextToken?: string | undefined;
}
export interface ListProcurementPortalSuppliersRequest {
    PortalIdentifier: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type SupplierIdString = string;
export type CountryCode = string;
export type ProcurementPortalEnv = "PROD" | "TEST" | (string & {});
export interface ProcurementPortalSupplier {
    SupplierIdentifier: string;
    SellerOfRecord?: string | undefined;
    CountryCode?: string | undefined;
    Environment?: ProcurementPortalEnv | undefined;
}
export type ProcurementPortalSuppliers = ProcurementPortalSupplier[];
export interface ListProcurementPortalSuppliersResponse {
    ProcurementPortalSuppliers: ProcurementPortalSupplier[];
    NextToken?: string | undefined;
}
export type TagrisArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTag[] | undefined;
}
export interface PutProcurementPortalPreferenceRequest {
    ProcurementPortalPreferenceArn: string;
    Selector?: ProcurementPortalPreferenceSelector | undefined;
    ProcurementPortalSharedSecret?: string | redacted.Redacted<string> | undefined;
    ProcurementPortalInstanceEndpoint?: string | undefined;
    TestEnvPreference?: TestEnvPreferenceInput | undefined;
    EinvoiceDeliveryEnabled: boolean;
    EinvoiceDeliveryPreference?: EinvoiceDeliveryPreference | undefined;
    PurchaseOrderRetrievalEnabled: boolean;
    MarketplacePunchOutEnabled?: boolean | undefined;
    MarketplacePunchOutPreference?: MarketplacePunchOutPreference | undefined;
    Contacts: Contact[];
    ClientToken?: string | undefined;
}
export interface PutProcurementPortalPreferenceResponse {
    ProcurementPortalPreferenceArn: string;
}
export interface SendProcurementPortalValidationRequest {
    ProcurementPortalPreferenceArn: string;
    ClientToken?: string | undefined;
}
export interface SendProcurementPortalValidationResponse {
    ProcurementPortalPreferenceArn: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    ResourceTags: ResourceTag[];
}
export interface TagResourceResponse {
}
export type ResourceTagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    ResourceTagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateInvoiceUnitRequest {
    InvoiceUnitArn: string;
    Description?: string | undefined;
    TaxInheritanceDisabled?: boolean | undefined;
    Rule?: InvoiceUnitRule | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateInvoiceUnitResponse {
    InvoiceUnitArn?: string | undefined;
}
export interface UpdateProcurementPortalPreferenceStatusRequest {
    ProcurementPortalPreferenceArn: string;
    EinvoiceDeliveryPreferenceStatus?: ProcurementPortalPreferenceStatus | undefined;
    EinvoiceDeliveryPreferenceStatusReason?: string | undefined;
    PurchaseOrderRetrievalPreferenceStatus?: ProcurementPortalPreferenceStatus | undefined;
    PurchaseOrderRetrievalPreferenceStatusReason?: string | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateProcurementPortalPreferenceStatusResponse {
    ProcurementPortalPreferenceArn: string;
}
export interface VerifyProcurementPortalValidationRequest {
    ProcurementPortalPreferenceArn: string;
    Code: string;
    ClientToken?: string | undefined;
}
export interface VerifyProcurementPortalValidationResponse {
    ProcurementPortalPreferenceArn: string;
}
export type ValidationExceptionReason = "nonMemberPresent" | "maxAccountsExceeded" | "maxInvoiceUnitsExceeded" | "duplicateInvoiceUnit" | "mutualExclusionError" | "accountMembershipError" | "taxSettingsError" | "expiredNextToken" | "invalidNextToken" | "invalidInput" | "fieldValidationFailed" | "cannotParse" | "unknownOperation" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchGetInvoiceProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This gets the invoice profile associated with a set of accounts. The accounts must be linked accounts under the requester management account organization.
 */
export declare const batchGetInvoiceProfile: API.OperationMethod<BatchGetInvoiceProfileRequest & RegionInput, BatchGetInvoiceProfileResponse, BatchGetInvoiceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateInvoiceUnitError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This creates a new invoice unit with the provided definition.
 */
export declare const createInvoiceUnit: API.OperationMethod<CreateInvoiceUnitRequest & RegionInput, CreateInvoiceUnitResponse, CreateInvoiceUnitError, Credentials | HttpClient.HttpClient>;
export type CreateProcurementPortalPreferenceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Creates a procurement portal preference configuration for e-invoice delivery and purchase order retrieval. This preference defines how invoices are delivered to a procurement portal and how purchase orders are retrieved.
 */
export declare const createProcurementPortalPreference: API.OperationMethod<CreateProcurementPortalPreferenceRequest & RegionInput, CreateProcurementPortalPreferenceResponse, CreateProcurementPortalPreferenceError, Credentials | HttpClient.HttpClient>;
export type DeleteInvoiceUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This deletes an invoice unit with the provided invoice unit ARN.
 */
export declare const deleteInvoiceUnit: API.OperationMethod<DeleteInvoiceUnitRequest & RegionInput, DeleteInvoiceUnitResponse, DeleteInvoiceUnitError, Credentials | HttpClient.HttpClient>;
export type DeleteProcurementPortalPreferenceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Deletes an existing procurement portal preference. This action cannot be undone. Active e-invoice delivery and PO retrieval configurations will be terminated.
 */
export declare const deleteProcurementPortalPreference: API.OperationMethod<DeleteProcurementPortalPreferenceRequest & RegionInput, DeleteProcurementPortalPreferenceResponse, DeleteProcurementPortalPreferenceError, Credentials | HttpClient.HttpClient>;
export type GetInvoicePDFError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a URL to download the invoice document and supplemental documents associated with an invoice. The URLs are pre-signed and have expiration time. For special cases like Brazil, where Amazon Web Services generated invoice identifiers and government provided identifiers do not match, use the Amazon Web Services generated invoice identifier when making API requests. To grant IAM permission to use this operation, the caller needs the `invoicing:GetInvoicePDF` policy action.
 */
export declare const getInvoicePDF: API.OperationMethod<GetInvoicePDFRequest & RegionInput, GetInvoicePDFResponse, GetInvoicePDFError, Credentials | HttpClient.HttpClient>;
export type GetInvoiceUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This retrieves the invoice unit definition.
 */
export declare const getInvoiceUnit: API.OperationMethod<GetInvoiceUnitRequest & RegionInput, GetInvoiceUnitResponse, GetInvoiceUnitError, Credentials | HttpClient.HttpClient>;
export type GetProcurementPortalPreferenceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Retrieves the details of a specific procurement portal preference configuration.
 */
export declare const getProcurementPortalPreference: API.OperationMethod<GetProcurementPortalPreferenceRequest & RegionInput, GetProcurementPortalPreferenceResponse, GetProcurementPortalPreferenceError, Credentials | HttpClient.HttpClient>;
export type ListInvoiceSummariesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves your invoice details programmatically, without line item details.
 */
export declare const listInvoiceSummaries: API.PaginatedOperationMethod<ListInvoiceSummariesRequest & RegionInput, ListInvoiceSummariesResponse, ListInvoiceSummariesError, Credentials | HttpClient.HttpClient, InvoiceSummary>;
export type ListInvoiceUnitsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This fetches a list of all invoice unit definitions for a given account, as of the provided `AsOf` date.
 */
export declare const listInvoiceUnits: API.PaginatedOperationMethod<ListInvoiceUnitsRequest & RegionInput, ListInvoiceUnitsResponse, ListInvoiceUnitsError, Credentials | HttpClient.HttpClient, InvoiceUnit>;
export type ListProcurementPortalPreferencesError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Retrieves a list of procurement portal preferences associated with the Amazon Web Services account.
 */
export declare const listProcurementPortalPreferences: API.PaginatedOperationMethod<ListProcurementPortalPreferencesRequest & RegionInput, ListProcurementPortalPreferencesResponse, ListProcurementPortalPreferencesError, Credentials | HttpClient.HttpClient, ProcurementPortalPreferenceSummary>;
export type ListProcurementPortalsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the Amazon Web Services-supported procurement portals for e-invoice delivery and purchase order retrieval. Each entry includes the portal identifier, name, and default feature configurations, which define the supported document and attachment types. For faster, more reliable responses, use pagination.
 */
export declare const listProcurementPortals: API.PaginatedOperationMethod<ListProcurementPortalsRequest & RegionInput, ListProcurementPortalsResponse, ListProcurementPortalsError, Credentials | HttpClient.HttpClient, ProcurementPortal>;
export type ListProcurementPortalSuppliersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the suppliers configured for a specified procurement portal, including supplier identifiers and associated metadata. For faster, more reliable responses, use pagination.
 */
export declare const listProcurementPortalSuppliers: API.PaginatedOperationMethod<ListProcurementPortalSuppliersRequest & RegionInput, ListProcurementPortalSuppliersResponse, ListProcurementPortalSuppliersError, Credentials | HttpClient.HttpClient, ProcurementPortalSupplier>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutProcurementPortalPreferenceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Updates an existing procurement portal preference configuration. This operation can modify settings for e-invoice delivery and purchase order retrieval.
 */
export declare const putProcurementPortalPreference: API.OperationMethod<PutProcurementPortalPreferenceRequest & RegionInput, PutProcurementPortalPreferenceResponse, PutProcurementPortalPreferenceError, Credentials | HttpClient.HttpClient>;
export type SendProcurementPortalValidationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Sends a validation request for a procurement portal preference. This operation initiates the validation process by issuing a validation code that confirms ownership and connectivity of the configured procurement portal endpoint. Use `VerifyProcurementPortalValidation` to submit the received code and complete validation.
 */
export declare const sendProcurementPortalValidation: API.OperationMethod<SendProcurementPortalValidationRequest & RegionInput, SendProcurementPortalValidationResponse, SendProcurementPortalValidationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateInvoiceUnitError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * You can update the invoice unit configuration at any time, and Amazon Web Services will use the latest configuration at the end of the month.
 */
export declare const updateInvoiceUnit: API.OperationMethod<UpdateInvoiceUnitRequest & RegionInput, UpdateInvoiceUnitResponse, UpdateInvoiceUnitError, Credentials | HttpClient.HttpClient>;
export type UpdateProcurementPortalPreferenceStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Updates the status of a procurement portal preference, including the activation state of e-invoice delivery and purchase order retrieval features.
 */
export declare const updateProcurementPortalPreferenceStatus: API.OperationMethod<UpdateProcurementPortalPreferenceStatusRequest & RegionInput, UpdateProcurementPortalPreferenceStatusResponse, UpdateProcurementPortalPreferenceStatusError, Credentials | HttpClient.HttpClient>;
export type VerifyProcurementPortalValidationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * * **This feature API is subject to changing at any time. For more information, see the Amazon Web Services Service Terms (Betas and Previews).** *
 *
 * Submits a validation code to complete the validation of a procurement portal preference. Use this operation after calling `SendProcurementPortalValidation` to confirm ownership and connectivity of the configured procurement portal endpoint.
 */
export declare const verifyProcurementPortalValidation: API.OperationMethod<VerifyProcurementPortalValidationRequest & RegionInput, VerifyProcurementPortalValidationResponse, VerifyProcurementPortalValidationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=invoicing.d.ts.map