import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const BadRequest_base: S.TaggedErrorClass<"BadRequest", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The image preparation request is invalid. */
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const ContainerApplicationCreateUnavailable_base: S.TaggedErrorClass<"ContainerApplicationCreateUnavailable", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
/** Cloudflare temporarily refuses to create an application (`can't create application at this time`); the same request succeeds when retried. */
export declare class ContainerApplicationCreateUnavailable extends /*@__PURE__*/ ContainerApplicationCreateUnavailable_base {
}
declare const ContainerApplicationNotFound_base: S.TaggedErrorClass<"ContainerApplicationNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ContainerApplicationNotFound extends /*@__PURE__*/ ContainerApplicationNotFound_base {
}
declare const ContainerImagePreparationInvalidImage_base: S.TaggedErrorClass<"ContainerImagePreparationInvalidImage", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The image is invalid or does not exist in this account. */
export declare class ContainerImagePreparationInvalidImage extends /*@__PURE__*/ ContainerImagePreparationInvalidImage_base {
}
declare const DurableObjectAlreadyHasApplication_base: S.TaggedErrorClass<"DurableObjectAlreadyHasApplication", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class DurableObjectAlreadyHasApplication extends /*@__PURE__*/ DurableObjectAlreadyHasApplication_base {
}
declare const DurableObjectCheckError_base: S.TaggedErrorClass<"DurableObjectCheckError", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class DurableObjectCheckError extends /*@__PURE__*/ DurableObjectCheckError_base {
}
declare const DurableObjectNamespaceNotFound_base: S.TaggedErrorClass<"DurableObjectNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
/** The Durable Object namespace is not visible to the containers API. Right after a Worker upload creates the namespace this is transient; retry. */
export declare class DurableObjectNamespaceNotFound extends /*@__PURE__*/ DurableObjectNamespaceNotFound_base {
}
declare const DurableObjectNotContainerEnabled_base: S.TaggedErrorClass<"DurableObjectNotContainerEnabled", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class DurableObjectNotContainerEnabled extends /*@__PURE__*/ DurableObjectNotContainerEnabled_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/** The image preparation request is forbidden. */
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
export interface UserSSHPublicKey {
    /** An SSH public key. */
    publicKey: string;
    /** Optional human readable name for this key. */
    name?: string | null | undefined;
}
export type UserSSHPublicKeyList = Array<UserSSHPublicKey>;
export type StringList = Array<string>;
export interface EnvironmentVariable {
    /** An environment variable name. */
    name: string;
    /** An environment variable value. */
    value: string;
}
export type EnvironmentVariableList = Array<EnvironmentVariable>;
export type ContainerInstanceType = "lite" | "dev" | "basic" | "standard" | "standard-1" | "standard-2" | "standard-3" | "standard-4";
export interface ContainerApplicationLogs {
    enabled?: boolean | null | undefined;
}
export interface ContainerApplicationObservability {
    /** Observability logging settings. */
    logs?: ContainerApplicationLogs | null | undefined;
}
export type DocumentList = Array<unknown>;
export type ContainerNetworkAssignIp = "none" | "predefined";
export type ContainerNetworkMode = "private" | "public";
/** Network configuration for a container deployment. Transcribed from the live API: it rejects unknown keys (`unrecognized key: "assignipv4"`). */
export interface ContainerNetwork {
    /** Whether to assign an IPv4 address. `predefined` requests public reachability: the API infers `mode: public` when `mode` is omitted, and rejects it combined with `mode: private`. */
    assignIpv4?: ContainerNetworkAssignIp | (string & {}) | null | undefined;
    /** Whether to assign an IPv6 address. Same rules as `assign_ipv4`. */
    assignIpv6?: ContainerNetworkAssignIp | (string & {}) | null | undefined;
    /** Network mode. Some accounts only permit `private`. */
    mode?: ContainerNetworkMode | (string & {}) | null | undefined;
}
export interface WranglerSSHConfiguration {
    enabled?: boolean | null | undefined;
    port?: number | null | undefined;
}
export interface ContainerConfiguration {
    /** Image url. */
    image: string;
    authorizedKeys?: UserSSHPublicKeyList | undefined;
    /** The command that runs when the container starts, passed to the entrypoint. You can override this at run-time. If you override only the command, it gets passed to the default entrypoint specified in the image. */
    command?: StringList | undefined;
    /** The entry point for the container, specifying the executable to run when the container starts. You can override this at run-time. If you do, the default command from the image is ignored. Specify both entrypoint and command at run-time to completely replace the image defaults. */
    entrypoint?: StringList | undefined;
    /** Container environment variables. */
    environmentVariables?: EnvironmentVariableList | undefined;
    /** The instance type configures vCPU, memory, and disk. */
    instanceType?: ContainerInstanceType | (string & {}) | undefined;
    /** Settings for deployment observability such as logging. */
    observability?: ContainerApplicationObservability | undefined;
    vcpu?: number | undefined;
    memory?: string | undefined;
    memoryMib?: number | undefined;
    disk?: unknown | undefined;
    secrets?: DocumentList | undefined;
    labels?: DocumentList | undefined;
    ports?: DocumentList | undefined;
    network?: ContainerNetwork | undefined;
    checks?: DocumentList | undefined;
    dns?: unknown | undefined;
    sshPublicKeyIds?: StringList | undefined;
    wranglerSsh?: WranglerSSHConfiguration | undefined;
    experimentalFlags?: StringList | undefined;
}
export type ContainerSchedulingPolicy = "default" | "durable_object";
export interface ScheduledApplicationConstraints {
    /** Restricts placement to datacenters in the selected jurisdiction. Choose "eu", "fedramp", or "us". When combined with regions, EU supports EEUR and WEUR while FedRAMP and US support ENAM and WNAM. */
    jurisdiction?: string | null | undefined;
    regions?: StringList | null | undefined;
    /** Placement tier. Not in the API reference. Wrangler's ApplicationConstraints has it (https://github.com/cloudflare/workers-sdk/blob/main/packages/containers-shared/src/client/models/ApplicationConstraints.ts). */
    tier?: number | null | undefined;
}
export interface DurableObjectsRef {
    /** The namespace ID of the durable object namespace to use for this application. */
    namespaceId: string;
}
export interface DurableObjectScriptAndClass {
    /** The class name of the durable object. */
    className: string;
    /** The script name where the durable object class is defined. */
    scriptName: string;
}
export type DurableObjectsConfiguration = DurableObjectsRef | DurableObjectScriptAndClass;
export interface CreateContainerApplicationRequest {
    accountId: string;
    /** Defines the deployment configuration for every deployment in this application. */
    configuration: ContainerConfiguration;
    /** The initial number of deployments to create. */
    instances?: number | undefined;
    /** Sets the maximum number of instances that the application can run. */
    maxInstances?: number | undefined;
    /** The name for this application. */
    name: string;
    /** Selects a scheduler-backed application. Use `default` when the Containers scheduler should maintain the requested number of instances and manage deployment configuration, placement, scaling, versions, and rollouts. */
    schedulingPolicy: ContainerSchedulingPolicy | (string & {});
    /** The jurisdiction of a Durable Object-managed application's primary control-plane object. Set this when creating the application; it cannot be changed afterwards. Other placement constraints are not supported by this scheduling policy. */
    constraints?: ScheduledApplicationConstraints | undefined;
    /** Optionally associates this scheduler-backed application with a Durable Object namespace. */
    durableObjects?: DurableObjectsConfiguration | undefined;
    /** Top-level observability settings for the application. This field is mutually exclusive with configuration.observability. */
    observability?: ContainerApplicationObservability | undefined;
    /** Grace period for active instances to stay alive before becoming eligible for shutdown signal due to a rollout, in seconds. Defaults to 0. */
    rolloutActiveGracePeriod?: number | undefined;
    /** Not in the API reference. Wrangler's CreateApplicationRequest has it (https://github.com/cloudflare/workers-sdk/blob/main/packages/containers-shared/src/client/models/CreateApplicationRequest.ts). */
    affinities?: unknown | undefined;
}
export type DurableObjectSchedulingPolicy = "durable_object";
export interface DurableObjectContainerConfiguration {
    authorizedKeys?: UserSSHPublicKeyList | null | undefined;
    /** Configuration properties for connecting with SSH to a container using Wrangler. */
    wranglerSsh?: WranglerSSHConfiguration | null | undefined;
    experimentalFlags?: StringList | null | undefined;
}
export type ContainerJurisdiction = "eu" | "fedramp" | "us";
export interface DurableObjectApplicationConstraints {
    jurisdiction: ContainerJurisdiction | (string & {});
}
export interface DurableObjectApplicationHealthInstances {
    /** Number of instances whose runtime reports running or stopping. */
    active: number;
    /** Number of instances whose runtime reports starting. */
    starting: number;
}
export type DurableObjectApplicationHealthSummary = "pending";
export interface DurableObjectApplicationHealth {
    /** Counts of observed non-terminal instances. */
    instances: DurableObjectApplicationHealthInstances;
    /** Present as pending until the first activity sweep completes; omitted afterward. */
    summary?: DurableObjectApplicationHealthSummary | null | undefined;
}
export interface DurableObjectContainerApplication {
    /** An Application ID represents an identifier of an application. */
    id: string;
    /** A unique identifier for the user's account. */
    accountId: string;
    /** UTC timestamp string in ISO 8601 format. */
    createdAt: string;
    /** Durable object configuration using a namespace ID. */
    durableObjects: DurableObjectsRef;
    /** The application name. */
    name: string;
    /** Selects a Durable Object-managed application. Each Durable Object creates and manages the lifecycle of its container instance. Configure application-wide observability settings here. Deployment configuration, scaling, placement constraints, versions, and rollouts do not apply. */
    schedulingPolicy: DurableObjectSchedulingPolicy;
    /** UTC timestamp string in ISO 8601 format. */
    updatedAt: string;
    /** Application-wide settings for a Durable Object-managed application. */
    configuration?: DurableObjectContainerConfiguration | null | undefined;
    /** The jurisdiction of a Durable Object-managed application's primary control-plane object. Set this when creating the application; it cannot be changed afterwards. Other placement constraints are not supported by this scheduling policy. */
    constraints?: DurableObjectApplicationConstraints | null | undefined;
    /** Aggregate current activity for the latest observed placement of each instance. Runtime snapshots feed periodic background sweeps. Counts refresh after each complete sweep. Instance listings retain their separate three-month history for failure discovery. */
    health?: DurableObjectApplicationHealth | null | undefined;
    /** Application-wide logging settings for a Durable Object-managed application. The application publishes these settings to its runtime metadata. Updating them does not create a deployment or rollout. */
    observability?: ContainerApplicationObservability | null | undefined;
}
export interface ContainerApplicationConfiguration {
    authorizedKeys?: UserSSHPublicKeyList | null | undefined;
    /** The command that runs when the container starts, passed to the entrypoint. You can override this at run-time. If you override only the command, it gets passed to the default entrypoint specified in the image. */
    command?: StringList | null | undefined;
    /** The entry point for the container, specifying the executable to run when the container starts. You can override this at run-time. If you do, the default command from the image is ignored. Specify both entrypoint and command at run-time to completely replace the image defaults. */
    entrypoint?: StringList | null | undefined;
    /** Container environment variables. */
    environmentVariables?: EnvironmentVariableList | null | undefined;
    /** Image url. */
    image?: string | null | undefined;
    /** The instance type configures vCPU, memory, and disk. */
    instanceType?: ContainerInstanceType | (string & {}) | null | undefined;
    /** Settings for deployment observability such as logging. */
    observability?: ContainerApplicationObservability | null | undefined;
    vcpu?: number | null | undefined;
    memory?: string | null | undefined;
    memoryMib?: number | null | undefined;
    disk?: unknown | null | undefined;
    secrets?: DocumentList | null | undefined;
    labels?: DocumentList | null | undefined;
    ports?: DocumentList | null | undefined;
    network?: ContainerNetwork | null | undefined;
    checks?: DocumentList | null | undefined;
    dns?: unknown | null | undefined;
    sshPublicKeyIds?: StringList | null | undefined;
    wranglerSsh?: WranglerSSHConfiguration | null | undefined;
    experimentalFlags?: StringList | null | undefined;
}
export type DocumentMap = {
    [key: string]: unknown | undefined;
};
export type ContainerApplicationEventName = "SchedulerPlaced" | "NetworkingIPAssigned" | "VMStarted" | "ImagePulled" | "ImagePullError" | "VMFailedToStart" | "NetworkingIPAssignmentFailed" | "VMRunning" | "VMStopping" | "VMStopped" | "VMFailed" | "RuntimeStartFailed" | "SSHStarted" | "ServiceHealthUpdates" | "CheckUpdate" | "DurableObjectConnected" | "ContainerStarted";
export type ContainerApplicationEventType = "Info" | "Error" | "Warn" | "UserError" | "SystemError";
export interface ContainerApplicationEvent {
    id: string;
    details: DocumentMap;
    message: string;
    /** Name of the event that describes the kind event that happened. */
    name: ContainerApplicationEventName;
    statusChange: DocumentMap;
    /** UTC timestamp string in ISO 8601 format. */
    time: string;
    type: ContainerApplicationEventType;
}
export interface ContainerApplicationHealthError {
    /** An event within a Placement or a Job. */
    event: ContainerApplicationEvent;
    /** An instance ID represents an identifier of an instance configuration that maintains an underlying placement. */
    instanceId: string;
}
export type ContainerApplicationHealthErrorList = Array<ContainerApplicationHealthError>;
export interface ScheduledApplicationHealthInstances {
    /** Number of instances whose runtime reports the container as running (container_status = "running"). This is a subset of the placements that remain up: an instance that is already bound to a Durable Object and serving traffic is counted under "assigned" until its container_status catches up to "running", so container_status can briefly lag Durable Object attachment under churn. To estimate running, Durable-Object-bound instances, sum "active" + "assigned" rather than reading "active" alone. */
    active: number;
    /** Number of instances bound to a Durable Object with a running placement whose container_status remains behind "running". These count as live, serving instances; "active" + "assigned" approximates the running, Durable-Object-bound count. */
    assigned: number;
}
export type ScheduledApplicationHealthSummary = "healthy" | "degraded" | "unhealthy" | "pending";
export interface ScheduledApplicationHealth {
    errors: ContainerApplicationHealthErrorList;
    /** Shows a count of application instance states. */
    instances: ScheduledApplicationHealthInstances;
    /** High-level health assessment. Only populated for "new_instances" strategy. Based on a sample of target-version instances rather than a full count. */
    summary?: ScheduledApplicationHealthSummary | null | undefined;
}
export interface ScheduledContainerApplication {
    /** An Application ID represents an identifier of an application. */
    id: string;
    /** A unique identifier for the user's account. */
    accountId: string;
    /** User-specified container configuration. */
    configuration: ContainerApplicationConfiguration;
    /** UTC timestamp string in ISO 8601 format. */
    createdAt: string;
    /** Number of deployments to create. */
    instances: number;
    /** The application name. */
    name: string;
    /** The scheduling policy to use for an application. */
    schedulingPolicy: ContainerSchedulingPolicy;
    /** UTC timestamp string in ISO 8601 format. */
    updatedAt: string;
    version: number;
    /** An identifier for a specific rollout within an application. */
    activeRolloutId?: string | null | undefined;
    constraints?: ScheduledApplicationConstraints | null | undefined;
    /** Durable object configuration stored on and returned from a Cloudchamber application. */
    durableObjects?: DurableObjectsRef | null | undefined;
    health?: ScheduledApplicationHealth | null | undefined;
    /** Maximum number of instances the application allows. This is relevant for applications that auto-scale. */
    maxInstances?: number | null | undefined;
    /** Top-level observability settings for the application. This field is mutually exclusive with configuration.observability. */
    observability?: ContainerApplicationObservability | null | undefined;
    /** Grace period for active instances to stay alive before becoming eligible for shutdown signal due to a rollout, in seconds. Defaults to 0. */
    rolloutActiveGracePeriod?: number | null | undefined;
    /** Not in the API reference. Wrangler's Application model has it (https://github.com/cloudflare/workers-sdk/blob/main/packages/containers-shared/src/client/models/Application.ts). */
    affinities?: unknown | null | undefined;
}
export type ContainerApplicationItem = DurableObjectContainerApplication | ScheduledContainerApplication;
export type CreateContainerApplicationResponse = ContainerApplicationItem;
export type CreateContainerApplicationRolloutRequestStrategy = "rolling" | "new_instances";
export type CreateContainerApplicationRolloutRequestKind = "full_auto" | "full_manual";
export type CreateContainerApplicationRolloutRequestStepPercentage = 5 | 10 | 20 | 25 | 50 | 100;
export interface CreateContainerApplicationRolloutRequestStepsItemStepSize {
    /** Percentage of instances affected in this step. Min 10% and Max 100%. */
    percentage: number;
}
export interface CreateContainerApplicationRolloutRequestStepsItem {
    /** Description of the rollout step. */
    description: string;
    stepSize: CreateContainerApplicationRolloutRequestStepsItemStepSize;
}
export type CreateContainerApplicationRolloutRequestStepsList = Array<CreateContainerApplicationRolloutRequestStepsItem>;
export interface CreateContainerApplicationRolloutRequest {
    accountId: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
    /** Description of the rollout process. */
    description: string;
    /** Strategy used for the rollout. */
    strategy: CreateContainerApplicationRolloutRequestStrategy | (string & {});
    /** User-specified container configuration changes. */
    targetConfiguration: ContainerApplicationConfiguration;
    /** Kind of the rollout process. Defaults to "full_auto". */
    kind?: CreateContainerApplicationRolloutRequestKind | (string & {}) | undefined;
    /** Initial target version percentage (0-100). Version sync actively replaces instances to match. Required when strategy is "new_instances" and kind is "full_manual". When strategy is "new_instances" and kind is "full_auto", omitted percentage starts at 10% or the smallest percentage that targets at least one instance. Unused for "rolling". */
    percentage?: number | undefined;
    /** Percentage of rollout to increase in each step when "steps" is absent. Applicable values: 5, 10, 20, 25, 50, 100. These create rollouts with 20, 10, 5, 4, 2, 1 steps respectively. Only valid for "rolling" strategy. */
    stepPercentage?: CreateContainerApplicationRolloutRequestStepPercentage | (number & {}) | undefined;
    /** Steps defining the rollout process, used when "step_percentage" is absent. Specify only one of "step_percentage" or "steps" when creating a rollout. "steps" allow granular control over each step. Only valid for "rolling" strategy. */
    steps?: CreateContainerApplicationRolloutRequestStepsList | undefined;
}
export type CreateContainerApplicationRolloutResponseKind = "full_auto" | "full_manual" | "durable_objects_auto";
export type CreateContainerApplicationRolloutResponseStatus = "pending" | "progressing" | "completed" | "reverted" | "replaced";
export type CreateContainerApplicationRolloutResponseStrategy = "rolling" | "new_instances";
export interface CreateContainerApplicationRolloutResponseProgressVersionDistribution {
    /** Expected number of instances remaining on the current (old) version based on the current percentage split. Only populated for "rolling" strategy. */
    currentVersionInstances?: number | null | undefined;
    /** The percentage of new instances being scheduled on the current version (100 - target_version_percentage). Only populated for "new_instances" strategy. */
    currentVersionPercentage?: number | null | undefined;
    /** Expected number of instances scheduled for the target (new) version based on the current percentage split. Only populated for "rolling" strategy. */
    targetVersionInstances?: number | null | undefined;
    /** The active percentage of new instances being scheduled on the target version. For "rolling", this reflects the step_size.percentage of the current active step. For "new_instances", this reflects the user-set percentage. */
    targetVersionPercentage?: number | null | undefined;
}
export interface CreateContainerApplicationRolloutResponseProgress {
    /** Current step being executed in the rollout process. Initialized to 0. */
    currentStep: number;
    /** Total number of instances the rollout affects. */
    totalInstances: number;
    /** Total number of steps in the rollout. */
    totalSteps: number;
    /** Number of instances updated in the rollout process. */
    updatedInstances: number;
    /** Expected distribution of instances per version, based on the current percentage split. Populated during active rollouts. Values derive from the version percentage weights rather than actual running instance counts. */
    versionDistribution?: CreateContainerApplicationRolloutResponseProgressVersionDistribution | null | undefined;
}
export type CreateContainerApplicationRolloutResponseStepsItemStatus = "pending" | "progressing" | "reverting" | "completed" | "reverted";
export type CreateContainerApplicationRolloutResponseStepsItemStepSize = CreateContainerApplicationRolloutRequestStepsItemStepSize;
export interface CreateContainerApplicationRolloutResponseStepsItem {
    /** The sequential order of the rollout step, automatically assigned starting from 1, based on the total number of steps in the rollout process. */
    id: number;
    /** Description of the rollout step. */
    description: string;
    /** Status of the rollout step. */
    status: CreateContainerApplicationRolloutResponseStepsItemStatus;
    stepSize: CreateContainerApplicationRolloutRequestStepsItemStepSize;
    /** UTC timestamp string in ISO 8601 format. */
    completedAt?: string | null | undefined;
    /** Reason for the step's current status. */
    reason?: string | null | undefined;
    /** UTC timestamp string in ISO 8601 format. */
    startedAt?: string | null | undefined;
}
export type CreateContainerApplicationRolloutResponseStepsList = Array<CreateContainerApplicationRolloutResponseStepsItem>;
export interface CreateContainerApplicationRolloutResponseVersionDistribution {
    /** Percentage of instances on the current (old) version. */
    currentVersionPercentage: number;
    /** Percentage of instances on the target (new) version. */
    targetVersionPercentage: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateContainerApplicationRolloutResponse {
    /** An identifier for a specific rollout within an application. */
    id: string;
    /** UTC timestamp string in ISO 8601 format. */
    createdAt: string;
    /** User-specified container configuration changes. */
    currentConfiguration: ContainerApplicationConfiguration;
    /** Current application version before the rollout. */
    currentVersion: number;
    description: string;
    health: ScheduledApplicationHealth;
    /** Kind of the rollout process. */
    kind: CreateContainerApplicationRolloutResponseKind;
    /** Timestamp of the most recent update to status, health, or progress. */
    lastUpdatedAt: string;
    /** Current status of the rollout. */
    status: CreateContainerApplicationRolloutResponseStatus;
    /** The rollout strategy. */
    strategy: CreateContainerApplicationRolloutResponseStrategy;
    /** User-specified container configuration changes. */
    targetConfiguration: ContainerApplicationConfiguration;
    /** Target application version after the rollout is complete and applied to all current instances. */
    targetVersion: number;
    /** Current target version percentage (0-100). Only present for "new_instances" strategy. */
    percentage?: number | null | undefined;
    /** Progress details of an application rollout. */
    progress?: CreateContainerApplicationRolloutResponseProgress | null | undefined;
    /** Timestamp when the rollout started. */
    startedAt?: string | null | undefined;
    steps?: CreateContainerApplicationRolloutResponseStepsList | null | undefined;
    /** Version percentage distribution. Only present for "new_instances" strategy. For "rolling" strategy, see progress.version_distribution instead. */
    versionDistribution?: CreateContainerApplicationRolloutResponseVersionDistribution | null | undefined;
}
export interface CreateContainerRegistryRequestAuthPrivateCredential {
    /** Name of the secret within the store. */
    secretName: string;
    /** Identifier of the Secrets Store containing the secret. */
    storeId: string;
}
export interface CreateContainerRegistryRequestAuth {
    /** A reference to the private registry credential in Secrets Store. The referenced secret must have the `containers` scope. Raw secret values are not accepted. */
    privateCredential: CreateContainerRegistryRequestAuthPrivateCredential;
    /** The non-secret part of the registry credential: an AWS access key ID for ECR, a username for Docker Hub, or a service account email for Google Artifact Registry. */
    publicCredential: string;
}
export type CreateContainerRegistryRequestKind = "ECR" | "DockerHub" | "GAR";
export interface CreateContainerRegistryRequest {
    accountId: string;
    /** Credentials for authenticating to a private external image registry. Store the private credential in [Secrets Store](https://developers.cloudflare.com/secrets-store/) before calling the API. Refer to [Image management](https://developers.cloudflare.com/containers/platform-details/image-management/) for the credential required by each supported registry provider. */
    auth: CreateContainerRegistryRequestAuth;
    /** Hostname of the private registry, without a scheme or image path. Supported hostnames are `docker.io`, AWS ECR hostnames, and Google Artifact Registry `*-docker.pkg.dev` hostnames. */
    domain: string;
    /** Registry provider. This must match `domain`: `DockerHub` for `docker.io`, `ECR` for AWS ECR, or `GAR` for Google Artifact Registry. */
    kind: CreateContainerRegistryRequestKind | (string & {});
    /** Omit this field or set it to `false`. Public Docker Hub images do not require registry configuration and cannot be added with this endpoint. */
    isPublic?: boolean | undefined;
}
export type ContainerRegistryKind = "ECR" | "DockerHub" | "GAR" | "default";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateContainerRegistryResponse {
    /** UTC timestamp string in ISO 8601 format. */
    createdAt: string;
    /** A string representation of a domain name. See RFC-1034 (https://www.ietf.org/rfc/rfc1034.txt). Consider that the limit of a domain name is min 3 and max 253 ASCII characters. */
    domain: string;
    /** The type of registry that is being configured. */
    kind?: ContainerRegistryKind | null | undefined;
    /** Public component of the registry credentials. For managed registries this is a base64-encoded public key; for external registries the format depends on the registry provider. */
    publicKey?: string | null | undefined;
}
export type CreateContainerRegistryCredentialsRequestPermissionsItem = "pull" | "push" | "list";
export type CreateContainerRegistryCredentialsRequestPermissionsList = Array<CreateContainerRegistryCredentialsRequestPermissionsItem | (string & {})>;
export interface CreateContainerRegistryCredentialsRequest {
    accountId: string;
    /** The domain to get credentials for. */
    domain: string;
    /** The number of minutes Cloudflare managed registry credentials stay valid. Required for managed registries and must remain positive. Cloudflare ignores this value for external registries. */
    expirationMinutes?: number | undefined;
    /** The permissions for Cloudflare managed registry credentials. Required for managed registries. Cloudflare ignores this value for external registries. */
    permissions?: CreateContainerRegistryCredentialsRequestPermissionsList | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateContainerRegistryCredentialsResponse {
    /** A unique identifier for the user's account. */
    accountId: string;
    /** The password to use when authenticating to the image registry. */
    password: string;
    /** The domain of the image registry these credentials target. */
    registryHost: string;
    /** The username to use when authenticating to the image registry. */
    username: string;
}
export interface CreateDurableObjectContainerApplicationRequest {
    accountId: string;
    name: string;
    schedulingPolicy: DurableObjectSchedulingPolicy;
    durableObjects: DurableObjectsConfiguration;
    configuration?: DurableObjectContainerConfiguration | undefined;
    constraints?: DurableObjectApplicationConstraints | undefined;
    observability?: ContainerApplicationObservability | undefined;
}
export type CreateDurableObjectContainerApplicationResponse = ContainerApplicationItem;
export interface DeleteContainerApplicationRequest {
    accountId: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteContainerApplicationResponse {
    message?: string | null | undefined;
}
export interface DeleteContainerRegistryRequest {
    accountId: string;
    /** The domain to delete. */
    domain: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteContainerRegistryResponse {
    /** A string representation of a domain name. See RFC-1034 (https://www.ietf.org/rfc/rfc1034.txt). Consider that the limit of a domain name is min 3 and max 253 ASCII characters. */
    domain: string;
}
export interface GetContainerApplicationRequest {
    accountId: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
}
export type GetContainerApplicationResponse = ContainerApplicationItem;
export interface GetContainerApplicationInstanceRequest {
    accountId: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
    /** A container instance ID (64-character hex Durable Object actor ID). */
    instanceId: string;
}
export type ContainerInstanceState = "provisioning" | "running" | "failed" | "stopping" | "stopped" | "unhealthy" | "inactive" | "unknown";
export interface ContainerInstanceStatus {
    /** The current lifecycle state of a container instance. */
    state: ContainerInstanceState;
    /** UTC timestamp string in ISO 8601 format. */
    updatedAt: string;
    /** The process exit code, when the runtime reports one. */
    exitCode?: number | null | undefined;
}
export interface ContainerInstanceResources {
    /** Disk allocated to the container instance, in decimal MB. */
    disk: number;
    /** Memory allocated to the container instance, in MiB. */
    memory: number;
    /** Number of virtual CPUs allocated to the container instance. */
    vcpu: number;
}
export interface ContainerInstanceLocation {
    /** Unique location code used to identify locations on a logical level. */
    name: string;
    /** Represents a group of datacenters. Choose one of "AFR", "APAC", "EEUR", "ENAM", "WNAM", "ME", "OC", "SAM", or "WEUR". */
    region: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetContainerApplicationInstanceResponse {
    /** A container instance ID (64-character hex Durable Object actor ID). */
    id: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
    /** The image for the current container placement, when one is available. */
    image: string;
    /** The latest known status of a container instance. */
    status: ContainerInstanceStatus;
    /** The resources allocated to the container instance. */
    configuration?: ContainerInstanceResources | null | undefined;
    /** The location of the instance's current container placement. */
    location?: ContainerInstanceLocation | null | undefined;
    /** The customer-provided instance name, when available. Its UTF-8 encoding uses at most 1,024 bytes. */
    name?: string | null | undefined;
    /** The time at which the current container placement started, when one exists. */
    startedAt?: string | null | undefined;
}
export interface GetContainerIdentityRequest {
    accountId: string;
}
export type GetContainerIdentityResponse = unknown;
export type ContainerInstanceStateFilter = "active" | "not-active";
export interface ListContainerApplicationInstancesRequest {
    accountId: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
    /** Filter instances by a case-sensitive name prefix, falling back to the actor ID when no name is known. Keep the same prefix when using a page token. */
    namePrefix?: string | undefined;
    /** Opaque token from a previous response to retrieve the next page. */
    pageToken?: string | undefined;
    /** Maximum number of instances to return per page. Defaults to 100. */
    perPage?: number | undefined;
    /** Filters instances by lifecycle state. `active` includes provisioning, running, and stopping instances; `not-active` includes stopped and failed instances. When omitted, all instances are returned. */
    state?: ContainerInstanceStateFilter | (string & {}) | undefined;
}
export interface ContainerInstance {
    /** A container instance ID (64-character hex Durable Object actor ID). */
    id: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
    /** The image for the current container placement, when one is available. */
    image: string;
    /** The latest known status of a container instance. */
    status: ContainerInstanceStatus;
    /** The resources allocated to the container instance. */
    configuration?: ContainerInstanceResources | null | undefined;
    /** The location of the instance's current container placement. */
    location?: ContainerInstanceLocation | null | undefined;
    /** The customer-provided instance name, when available. Its UTF-8 encoding uses at most 1,024 bytes. */
    name?: string | null | undefined;
    /** The time at which the current container placement started, when one exists. */
    startedAt?: string | null | undefined;
}
export type ContainerInstanceList = Array<ContainerInstance>;
export interface ListContainerApplicationInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ContainerInstanceList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListContainerApplicationsRequest {
    accountId: string;
    /** Filter applications by image. */
    image?: string | undefined;
    /** Filter applications by name. */
    name?: string | undefined;
    /** Opaque token from a previous response to retrieve the next page. */
    pageToken?: string | undefined;
    /** Maximum number of applications to return per page. Defaults to all, or 100 when `page_token` is set. */
    perPage?: number | undefined;
}
export type ContainerApplicationItemList = Array<ContainerApplicationItem>;
export type ListContainerApplicationsResponse = ContainerApplicationItemList;
export interface ListContainerApplicationVersionsRequest {
    accountId: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
}
export interface ContainerApplicationVersion {
    /** User-specified container configuration changes. */
    configuration: ContainerApplicationConfiguration;
    percentage: number;
    version: number;
}
export type ContainerApplicationVersionList = Array<ContainerApplicationVersion>;
export type ListContainerApplicationVersionsResponse = ContainerApplicationVersionList;
export interface ListContainerRegistriesRequest {
    accountId: string;
}
export interface ContainerRegistry {
    /** UTC timestamp string in ISO 8601 format. */
    createdAt: string;
    /** A string representation of a domain name. See RFC-1034 (https://www.ietf.org/rfc/rfc1034.txt). Consider that the limit of a domain name is min 3 and max 253 ASCII characters. */
    domain: string;
    /** The type of registry that is being configured. */
    kind?: ContainerRegistryKind | null | undefined;
    /** Public component of the registry credentials. For managed registries this is a base64-encoded public key; for external registries the format depends on the registry provider. */
    publicKey?: string | null | undefined;
}
export type ContainerRegistryList = Array<ContainerRegistry>;
export type ListContainerRegistriesResponse = ContainerRegistryList;
export interface PrepareContainerImageRequest {
    accountId: string;
    /** Image url. */
    image: string;
}
export type ContainerImagePreparationStatus = "pending" | "ready" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PrepareContainerImageResponse {
    /** Image url. */
    image: string;
    /** Current durable preparation state for a container image. */
    status: ContainerImagePreparationStatus;
    /** Digest of the prepared runtime artifact when status is ready. */
    artifactDigest?: string | null | undefined;
    /** Human-readable pending or terminal error detail. */
    reason?: string | null | undefined;
}
export interface UpdateContainerApplicationRequest {
    accountId: string;
    /** An Application ID represents an identifier of an application. */
    applicationId: string;
    /** Application configuration fields you can change without creating a rollout. */
    configuration?: ContainerApplicationConfiguration | undefined;
    constraints?: ScheduledApplicationConstraints | undefined;
    /** Maximum number of instances that an autoscaling application can run. */
    maxInstances?: number | undefined;
    /** Top-level application observability settings. Scheduler-backed applications hot-reload these settings across existing instances. An existing Durable Object-managed application accepts only `logs.enabled` and publishes these settings to runtime metadata without creating deployments or rollouts. */
    observability?: ContainerApplicationObservability | undefined;
    /** Grace period for active instances to stay alive before becoming eligible for shutdown signal due to a rollout, in seconds. Defaults to 0. */
    rolloutActiveGracePeriod?: number | undefined;
    instances?: number | undefined;
    schedulingPolicy?: ContainerSchedulingPolicy | (string & {}) | undefined;
    /** Not in the API reference. Wrangler's ModifyApplicationRequestBody has it (https://github.com/cloudflare/workers-sdk/blob/main/packages/containers-shared/src/client/models/ModifyApplicationRequestBody.ts). */
    affinities?: unknown | undefined;
}
export type UpdateContainerApplicationResponse = ContainerApplicationItem;
export type CreateContainerApplicationError = InvalidRoute | DurableObjectAlreadyHasApplication | DurableObjectNotContainerEnabled | DurableObjectCheckError | DurableObjectNamespaceNotFound | ContainerApplicationCreateUnavailable | CloudflareOpError;
/** Create a Containers application. Use `scheduling_policy: "default"` for a scheduler-backed application. The Containers scheduler maintains the requested instance count and manages deployment configuration, placement, scaling, versions, and rollouts. Use `scheduling_policy: "durable_object"` for a Durable Object-managed application. Each Durable Object creates and manages the lifecycle of its container instance. Supply `name`, `scheduling_policy`, and `durable_objects`, with optional `configuration` and optional top-level `observability` settings. Deployment configuration, scaling, constraints, versions, and rollouts do not apply. */
export declare const createContainerApplication: API.OperationMethod<CreateContainerApplicationRequest, CreateContainerApplicationResponse, CreateContainerApplicationError, CloudflareOpContext>;
export type CreateContainerApplicationRolloutError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
/** Creates a rollout to update the application's configuration across instances with minimal downtime. Rollouts apply only to scheduler-backed applications with `scheduling_policy: "default"`. Versions and rollouts do not apply to applications with `scheduling_policy: "durable_object"`. */
export declare const createContainerApplicationRollout: API.OperationMethod<CreateContainerApplicationRolloutRequest, CreateContainerApplicationRolloutResponse, CreateContainerApplicationRolloutError, CloudflareOpContext>;
export type CreateContainerRegistryError = CloudflareOpError;
/** Registers credentials for a supported private external image registry so Containers can pull images from it. This endpoint does not create a registry or upload an image. Public Docker Hub images and images in the Cloudflare managed registry do not require this configuration. Refer to [Image management](https://developers.cloudflare.com/containers/platform-details/image-management/) for supported registries and instructions for storing registry credentials. */
export declare const createContainerRegistry: API.OperationMethod<CreateContainerRegistryRequest, CreateContainerRegistryResponse, CreateContainerRegistryError, CloudflareOpContext>;
export type CreateContainerRegistryCredentialsError = InvalidRoute | CloudflareOpError;
/** Generates credentials for accessing a configured container image registry. */
export declare const createContainerRegistryCredentials: API.OperationMethod<CreateContainerRegistryCredentialsRequest, CreateContainerRegistryCredentialsResponse, CreateContainerRegistryCredentialsError, CloudflareOpContext>;
export type CreateDurableObjectContainerApplicationError = InvalidRoute | DurableObjectAlreadyHasApplication | DurableObjectNotContainerEnabled | DurableObjectCheckError | DurableObjectNamespaceNotFound | CloudflareOpError;
/** Create a Durable Object-managed application. Requires an existing SQLite Durable Object namespace; the application ID is the namespace ID. */
export declare const createDurableObjectContainerApplication: API.OperationMethod<CreateDurableObjectContainerApplicationRequest, CreateDurableObjectContainerApplicationResponse, CreateDurableObjectContainerApplicationError, CloudflareOpContext>;
export type DeleteContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
/** Deletes a single application by id. */
export declare const deleteContainerApplication: API.OperationMethod<DeleteContainerApplicationRequest, DeleteContainerApplicationResponse, DeleteContainerApplicationError, CloudflareOpContext>;
export type DeleteContainerRegistryError = CloudflareOpError;
/** Delete a registry from the account, this will prevent Containers from pulling images from the registry. */
export declare const deleteContainerRegistry: API.OperationMethod<DeleteContainerRegistryRequest, DeleteContainerRegistryResponse, DeleteContainerRegistryError, CloudflareOpContext>;
export type GetContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
/** Returns a single application by id. */
export declare const getContainerApplication: API.OperationMethod<GetContainerApplicationRequest, GetContainerApplicationResponse, GetContainerApplicationError, CloudflareOpContext>;
export type GetContainerApplicationInstanceError = CloudflareOpError;
/** Returns a container instance belonging to an application. */
export declare const getContainerApplicationInstance: API.OperationMethod<GetContainerApplicationInstanceRequest, GetContainerApplicationInstanceResponse, GetContainerApplicationInstanceError, CloudflareOpContext>;
export type GetContainerIdentityError = InvalidRoute | CloudflareOpError;
export declare const getContainerIdentity: API.OperationMethod<GetContainerIdentityRequest, GetContainerIdentityResponse, GetContainerIdentityError, CloudflareOpContext>;
export type ListContainerApplicationInstancesError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
/** Lists container instances belonging to an application. */
export declare const listContainerApplicationInstances: API.PaginatedOperationMethod<ListContainerApplicationInstancesRequest, ListContainerApplicationInstancesResponse, ListContainerApplicationInstancesError, CloudflareOpContext, ContainerInstance>;
export type ListContainerApplicationsError = InvalidRoute | CloudflareOpError;
/** Lists all the applications that are associated with your account. */
export declare const listContainerApplications: API.OperationMethod<ListContainerApplicationsRequest, ListContainerApplicationsResponse, ListContainerApplicationsError, CloudflareOpContext>;
export type ListContainerApplicationVersionsError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
/** Returns all versions for a scheduler-backed application with `scheduling_policy: "default"`. Versions and rollouts do not apply to applications with `scheduling_policy: "durable_object"`. */
export declare const listContainerApplicationVersions: API.OperationMethod<ListContainerApplicationVersionsRequest, ListContainerApplicationVersionsResponse, ListContainerApplicationVersionsError, CloudflareOpContext>;
export type ListContainerRegistriesError = CloudflareOpError;
/** Get the list of configured registries in the account. */
export declare const listContainerRegistries: API.OperationMethod<ListContainerRegistriesRequest, ListContainerRegistriesResponse, ListContainerRegistriesError, CloudflareOpContext>;
export type PrepareContainerImageError = ContainerImagePreparationInvalidImage | BadRequest | Forbidden | CloudflareOpError;
/** Idempotently starts or observes preparation of the runtime artifacts required to run one digest-pinned managed container image on Cloudflare's network. Returns 202 while durable preparation continues and 200 when the image is ready or preparation has reached a terminal error. */
export declare const prepareContainerImage: API.OperationMethod<PrepareContainerImageRequest, PrepareContainerImageResponse, PrepareContainerImageError, CloudflareOpContext>;
export type UpdateContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
/** Modifies a single application by id. Durable Object-managed application settings are published to runtime metadata without creating deployments or rollouts. Top-level `observability` for these applications supports only `logs.enabled`. The supported fields depend on the existing application's scheduling policy. For scheduler-backed applications, changes that replace instance deployment configuration, including the image, require a rollout. */
export declare const updateContainerApplication: API.OperationMethod<UpdateContainerApplicationRequest, UpdateContainerApplicationResponse, UpdateContainerApplicationError, CloudflareOpContext>;
//# sourceMappingURL=containers.d.ts.map