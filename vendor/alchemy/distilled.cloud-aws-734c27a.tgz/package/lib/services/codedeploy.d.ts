import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AlarmsLimitExceededException_base: S.TaggedErrorClass<"AlarmsLimitExceededException", {
    readonly message: any;
}>;
export declare class AlarmsLimitExceededException extends /*@__PURE__*/ AlarmsLimitExceededException_base {
}
declare const ApplicationAlreadyExistsException_base: S.TaggedErrorClass<"ApplicationAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ApplicationAlreadyExistsException extends /*@__PURE__*/ ApplicationAlreadyExistsException_base {
}
declare const ApplicationDoesNotExistException_base: S.TaggedErrorClass<"ApplicationDoesNotExistException", {
    readonly message: any;
}>;
export declare class ApplicationDoesNotExistException extends /*@__PURE__*/ ApplicationDoesNotExistException_base {
}
declare const ApplicationLimitExceededException_base: S.TaggedErrorClass<"ApplicationLimitExceededException", {
    readonly message: any;
}>;
export declare class ApplicationLimitExceededException extends /*@__PURE__*/ ApplicationLimitExceededException_base {
}
declare const ApplicationNameRequiredException_base: S.TaggedErrorClass<"ApplicationNameRequiredException", {
    readonly message: any;
}>;
export declare class ApplicationNameRequiredException extends /*@__PURE__*/ ApplicationNameRequiredException_base {
}
declare const ArnNotSupportedException_base: S.TaggedErrorClass<"ArnNotSupportedException", {
    readonly message: any;
}>;
export declare class ArnNotSupportedException extends /*@__PURE__*/ ArnNotSupportedException_base {
}
declare const BatchLimitExceededException_base: S.TaggedErrorClass<"BatchLimitExceededException", {
    readonly message: any;
}>;
export declare class BatchLimitExceededException extends /*@__PURE__*/ BatchLimitExceededException_base {
}
declare const BucketNameFilterRequiredException_base: S.TaggedErrorClass<"BucketNameFilterRequiredException", {
    readonly message: any;
}>;
export declare class BucketNameFilterRequiredException extends /*@__PURE__*/ BucketNameFilterRequiredException_base {
}
declare const DeploymentAlreadyCompletedException_base: S.TaggedErrorClass<"DeploymentAlreadyCompletedException", {
    readonly message: any;
}>;
export declare class DeploymentAlreadyCompletedException extends /*@__PURE__*/ DeploymentAlreadyCompletedException_base {
}
declare const DeploymentConfigAlreadyExistsException_base: S.TaggedErrorClass<"DeploymentConfigAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DeploymentConfigAlreadyExistsException extends /*@__PURE__*/ DeploymentConfigAlreadyExistsException_base {
}
declare const DeploymentConfigDoesNotExistException_base: S.TaggedErrorClass<"DeploymentConfigDoesNotExistException", {
    readonly message: any;
}>;
export declare class DeploymentConfigDoesNotExistException extends /*@__PURE__*/ DeploymentConfigDoesNotExistException_base {
}
declare const DeploymentConfigInUseException_base: S.TaggedErrorClass<"DeploymentConfigInUseException", {
    readonly message: any;
}>;
export declare class DeploymentConfigInUseException extends /*@__PURE__*/ DeploymentConfigInUseException_base {
}
declare const DeploymentConfigLimitExceededException_base: S.TaggedErrorClass<"DeploymentConfigLimitExceededException", {
    readonly message: any;
}>;
export declare class DeploymentConfigLimitExceededException extends /*@__PURE__*/ DeploymentConfigLimitExceededException_base {
}
declare const DeploymentConfigNameRequiredException_base: S.TaggedErrorClass<"DeploymentConfigNameRequiredException", {
    readonly message: any;
}>;
export declare class DeploymentConfigNameRequiredException extends /*@__PURE__*/ DeploymentConfigNameRequiredException_base {
}
declare const DeploymentDoesNotExistException_base: S.TaggedErrorClass<"DeploymentDoesNotExistException", {
    readonly message: any;
}>;
export declare class DeploymentDoesNotExistException extends /*@__PURE__*/ DeploymentDoesNotExistException_base {
}
declare const DeploymentGroupAlreadyExistsException_base: S.TaggedErrorClass<"DeploymentGroupAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DeploymentGroupAlreadyExistsException extends /*@__PURE__*/ DeploymentGroupAlreadyExistsException_base {
}
declare const DeploymentGroupDoesNotExistException_base: S.TaggedErrorClass<"DeploymentGroupDoesNotExistException", {
    readonly message: any;
}>;
export declare class DeploymentGroupDoesNotExistException extends /*@__PURE__*/ DeploymentGroupDoesNotExistException_base {
}
declare const DeploymentGroupLimitExceededException_base: S.TaggedErrorClass<"DeploymentGroupLimitExceededException", {
    readonly message: any;
}>;
export declare class DeploymentGroupLimitExceededException extends /*@__PURE__*/ DeploymentGroupLimitExceededException_base {
}
declare const DeploymentGroupNameRequiredException_base: S.TaggedErrorClass<"DeploymentGroupNameRequiredException", {
    readonly message: any;
}>;
export declare class DeploymentGroupNameRequiredException extends /*@__PURE__*/ DeploymentGroupNameRequiredException_base {
}
declare const DeploymentIdRequiredException_base: S.TaggedErrorClass<"DeploymentIdRequiredException", {
    readonly message: any;
}>;
export declare class DeploymentIdRequiredException extends /*@__PURE__*/ DeploymentIdRequiredException_base {
}
declare const DeploymentIsNotInReadyStateException_base: S.TaggedErrorClass<"DeploymentIsNotInReadyStateException", {
    readonly message: any;
}>;
export declare class DeploymentIsNotInReadyStateException extends /*@__PURE__*/ DeploymentIsNotInReadyStateException_base {
}
declare const DeploymentLimitExceededException_base: S.TaggedErrorClass<"DeploymentLimitExceededException", {
    readonly message: any;
}>;
export declare class DeploymentLimitExceededException extends /*@__PURE__*/ DeploymentLimitExceededException_base {
}
declare const DeploymentNotStartedException_base: S.TaggedErrorClass<"DeploymentNotStartedException", {
    readonly message: any;
}>;
export declare class DeploymentNotStartedException extends /*@__PURE__*/ DeploymentNotStartedException_base {
}
declare const DeploymentTargetDoesNotExistException_base: S.TaggedErrorClass<"DeploymentTargetDoesNotExistException", {
    readonly message: any;
}>;
export declare class DeploymentTargetDoesNotExistException extends /*@__PURE__*/ DeploymentTargetDoesNotExistException_base {
}
declare const DeploymentTargetIdRequiredException_base: S.TaggedErrorClass<"DeploymentTargetIdRequiredException", {
    readonly message: any;
}>;
export declare class DeploymentTargetIdRequiredException extends /*@__PURE__*/ DeploymentTargetIdRequiredException_base {
}
declare const DeploymentTargetListSizeExceededException_base: S.TaggedErrorClass<"DeploymentTargetListSizeExceededException", {
    readonly message: any;
}>;
export declare class DeploymentTargetListSizeExceededException extends /*@__PURE__*/ DeploymentTargetListSizeExceededException_base {
}
declare const DescriptionTooLongException_base: S.TaggedErrorClass<"DescriptionTooLongException", {
    readonly message: any;
}>;
export declare class DescriptionTooLongException extends /*@__PURE__*/ DescriptionTooLongException_base {
}
declare const ECSServiceMappingLimitExceededException_base: S.TaggedErrorClass<"ECSServiceMappingLimitExceededException", {
    readonly message: any;
}>;
export declare class ECSServiceMappingLimitExceededException extends /*@__PURE__*/ ECSServiceMappingLimitExceededException_base {
}
declare const GitHubAccountTokenDoesNotExistException_base: S.TaggedErrorClass<"GitHubAccountTokenDoesNotExistException", {
    readonly message: any;
}>;
export declare class GitHubAccountTokenDoesNotExistException extends /*@__PURE__*/ GitHubAccountTokenDoesNotExistException_base {
}
declare const GitHubAccountTokenNameRequiredException_base: S.TaggedErrorClass<"GitHubAccountTokenNameRequiredException", {
    readonly message: any;
}>;
export declare class GitHubAccountTokenNameRequiredException extends /*@__PURE__*/ GitHubAccountTokenNameRequiredException_base {
}
declare const IamArnRequiredException_base: S.TaggedErrorClass<"IamArnRequiredException", {
    readonly message: any;
}>;
export declare class IamArnRequiredException extends /*@__PURE__*/ IamArnRequiredException_base {
}
declare const IamSessionArnAlreadyRegisteredException_base: S.TaggedErrorClass<"IamSessionArnAlreadyRegisteredException", {
    readonly message: any;
}>;
export declare class IamSessionArnAlreadyRegisteredException extends /*@__PURE__*/ IamSessionArnAlreadyRegisteredException_base {
}
declare const IamUserArnAlreadyRegisteredException_base: S.TaggedErrorClass<"IamUserArnAlreadyRegisteredException", {
    readonly message: any;
}>;
export declare class IamUserArnAlreadyRegisteredException extends /*@__PURE__*/ IamUserArnAlreadyRegisteredException_base {
}
declare const IamUserArnRequiredException_base: S.TaggedErrorClass<"IamUserArnRequiredException", {
    readonly message: any;
}>;
export declare class IamUserArnRequiredException extends /*@__PURE__*/ IamUserArnRequiredException_base {
}
declare const InstanceDoesNotExistException_base: S.TaggedErrorClass<"InstanceDoesNotExistException", {
    readonly message: any;
}>;
export declare class InstanceDoesNotExistException extends /*@__PURE__*/ InstanceDoesNotExistException_base {
}
declare const InstanceIdRequiredException_base: S.TaggedErrorClass<"InstanceIdRequiredException", {
    readonly message: any;
}>;
export declare class InstanceIdRequiredException extends /*@__PURE__*/ InstanceIdRequiredException_base {
}
declare const InstanceLimitExceededException_base: S.TaggedErrorClass<"InstanceLimitExceededException", {
    readonly message: any;
}>;
export declare class InstanceLimitExceededException extends /*@__PURE__*/ InstanceLimitExceededException_base {
}
declare const InstanceNameAlreadyRegisteredException_base: S.TaggedErrorClass<"InstanceNameAlreadyRegisteredException", {
    readonly message: any;
}>;
export declare class InstanceNameAlreadyRegisteredException extends /*@__PURE__*/ InstanceNameAlreadyRegisteredException_base {
}
declare const InstanceNameRequiredException_base: S.TaggedErrorClass<"InstanceNameRequiredException", {
    readonly message: any;
}>;
export declare class InstanceNameRequiredException extends /*@__PURE__*/ InstanceNameRequiredException_base {
}
declare const InstanceNotRegisteredException_base: S.TaggedErrorClass<"InstanceNotRegisteredException", {
    readonly message: any;
}>;
export declare class InstanceNotRegisteredException extends /*@__PURE__*/ InstanceNotRegisteredException_base {
}
declare const InvalidAlarmConfigException_base: S.TaggedErrorClass<"InvalidAlarmConfigException", {
    readonly message: any;
}>;
export declare class InvalidAlarmConfigException extends /*@__PURE__*/ InvalidAlarmConfigException_base {
}
declare const InvalidApplicationNameException_base: S.TaggedErrorClass<"InvalidApplicationNameException", {
    readonly message: any;
}>;
export declare class InvalidApplicationNameException extends /*@__PURE__*/ InvalidApplicationNameException_base {
}
declare const InvalidArnException_base: S.TaggedErrorClass<"InvalidArnException", {
    readonly message: any;
}>;
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidAutoRollbackConfigException_base: S.TaggedErrorClass<"InvalidAutoRollbackConfigException", {
    readonly message: any;
}>;
export declare class InvalidAutoRollbackConfigException extends /*@__PURE__*/ InvalidAutoRollbackConfigException_base {
}
declare const InvalidAutoScalingGroupException_base: S.TaggedErrorClass<"InvalidAutoScalingGroupException", {
    readonly message: any;
}>;
export declare class InvalidAutoScalingGroupException extends /*@__PURE__*/ InvalidAutoScalingGroupException_base {
}
declare const InvalidAutoScalingGroupProcessToSuspendException_base: S.TaggedErrorClass<"InvalidAutoScalingGroupProcessToSuspendException", {
    readonly message: any;
}>;
export declare class InvalidAutoScalingGroupProcessToSuspendException extends /*@__PURE__*/ InvalidAutoScalingGroupProcessToSuspendException_base {
}
declare const InvalidBlueGreenDeploymentConfigurationException_base: S.TaggedErrorClass<"InvalidBlueGreenDeploymentConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidBlueGreenDeploymentConfigurationException extends /*@__PURE__*/ InvalidBlueGreenDeploymentConfigurationException_base {
}
declare const InvalidBucketNameFilterException_base: S.TaggedErrorClass<"InvalidBucketNameFilterException", {
    readonly message: any;
}>;
export declare class InvalidBucketNameFilterException extends /*@__PURE__*/ InvalidBucketNameFilterException_base {
}
declare const InvalidComputePlatformException_base: S.TaggedErrorClass<"InvalidComputePlatformException", {
    readonly message: any;
}>;
export declare class InvalidComputePlatformException extends /*@__PURE__*/ InvalidComputePlatformException_base {
}
declare const InvalidDeployedStateFilterException_base: S.TaggedErrorClass<"InvalidDeployedStateFilterException", {
    readonly message: any;
}>;
export declare class InvalidDeployedStateFilterException extends /*@__PURE__*/ InvalidDeployedStateFilterException_base {
}
declare const InvalidDeploymentConfigNameException_base: S.TaggedErrorClass<"InvalidDeploymentConfigNameException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentConfigNameException extends /*@__PURE__*/ InvalidDeploymentConfigNameException_base {
}
declare const InvalidDeploymentGroupNameException_base: S.TaggedErrorClass<"InvalidDeploymentGroupNameException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentGroupNameException extends /*@__PURE__*/ InvalidDeploymentGroupNameException_base {
}
declare const InvalidDeploymentIdException_base: S.TaggedErrorClass<"InvalidDeploymentIdException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentIdException extends /*@__PURE__*/ InvalidDeploymentIdException_base {
}
declare const InvalidDeploymentInstanceTypeException_base: S.TaggedErrorClass<"InvalidDeploymentInstanceTypeException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentInstanceTypeException extends /*@__PURE__*/ InvalidDeploymentInstanceTypeException_base {
}
declare const InvalidDeploymentStatusException_base: S.TaggedErrorClass<"InvalidDeploymentStatusException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentStatusException extends /*@__PURE__*/ InvalidDeploymentStatusException_base {
}
declare const InvalidDeploymentStyleException_base: S.TaggedErrorClass<"InvalidDeploymentStyleException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentStyleException extends /*@__PURE__*/ InvalidDeploymentStyleException_base {
}
declare const InvalidDeploymentTargetIdException_base: S.TaggedErrorClass<"InvalidDeploymentTargetIdException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentTargetIdException extends /*@__PURE__*/ InvalidDeploymentTargetIdException_base {
}
declare const InvalidDeploymentWaitTypeException_base: S.TaggedErrorClass<"InvalidDeploymentWaitTypeException", {
    readonly message: any;
}>;
export declare class InvalidDeploymentWaitTypeException extends /*@__PURE__*/ InvalidDeploymentWaitTypeException_base {
}
declare const InvalidEC2TagCombinationException_base: S.TaggedErrorClass<"InvalidEC2TagCombinationException", {
    readonly message: any;
}>;
export declare class InvalidEC2TagCombinationException extends /*@__PURE__*/ InvalidEC2TagCombinationException_base {
}
declare const InvalidEC2TagException_base: S.TaggedErrorClass<"InvalidEC2TagException", {
    readonly message: any;
}>;
export declare class InvalidEC2TagException extends /*@__PURE__*/ InvalidEC2TagException_base {
}
declare const InvalidECSServiceException_base: S.TaggedErrorClass<"InvalidECSServiceException", {
    readonly message: any;
}>;
export declare class InvalidECSServiceException extends /*@__PURE__*/ InvalidECSServiceException_base {
}
declare const InvalidExternalIdException_base: S.TaggedErrorClass<"InvalidExternalIdException", {
    readonly message: any;
}>;
export declare class InvalidExternalIdException extends /*@__PURE__*/ InvalidExternalIdException_base {
}
declare const InvalidFileExistsBehaviorException_base: S.TaggedErrorClass<"InvalidFileExistsBehaviorException", {
    readonly message: any;
}>;
export declare class InvalidFileExistsBehaviorException extends /*@__PURE__*/ InvalidFileExistsBehaviorException_base {
}
declare const InvalidGitHubAccountTokenException_base: S.TaggedErrorClass<"InvalidGitHubAccountTokenException", {
    readonly message: any;
}>;
export declare class InvalidGitHubAccountTokenException extends /*@__PURE__*/ InvalidGitHubAccountTokenException_base {
}
declare const InvalidGitHubAccountTokenNameException_base: S.TaggedErrorClass<"InvalidGitHubAccountTokenNameException", {
    readonly message: any;
}>;
export declare class InvalidGitHubAccountTokenNameException extends /*@__PURE__*/ InvalidGitHubAccountTokenNameException_base {
}
declare const InvalidIamSessionArnException_base: S.TaggedErrorClass<"InvalidIamSessionArnException", {
    readonly message: any;
}>;
export declare class InvalidIamSessionArnException extends /*@__PURE__*/ InvalidIamSessionArnException_base {
}
declare const InvalidIamUserArnException_base: S.TaggedErrorClass<"InvalidIamUserArnException", {
    readonly message: any;
}>;
export declare class InvalidIamUserArnException extends /*@__PURE__*/ InvalidIamUserArnException_base {
}
declare const InvalidIgnoreApplicationStopFailuresValueException_base: S.TaggedErrorClass<"InvalidIgnoreApplicationStopFailuresValueException", {
    readonly message: any;
}>;
export declare class InvalidIgnoreApplicationStopFailuresValueException extends /*@__PURE__*/ InvalidIgnoreApplicationStopFailuresValueException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidInstanceNameException_base: S.TaggedErrorClass<"InvalidInstanceNameException", {
    readonly message: any;
}>;
export declare class InvalidInstanceNameException extends /*@__PURE__*/ InvalidInstanceNameException_base {
}
declare const InvalidInstanceStatusException_base: S.TaggedErrorClass<"InvalidInstanceStatusException", {
    readonly message: any;
}>;
export declare class InvalidInstanceStatusException extends /*@__PURE__*/ InvalidInstanceStatusException_base {
}
declare const InvalidInstanceTypeException_base: S.TaggedErrorClass<"InvalidInstanceTypeException", {
    readonly message: any;
}>;
export declare class InvalidInstanceTypeException extends /*@__PURE__*/ InvalidInstanceTypeException_base {
}
declare const InvalidKeyPrefixFilterException_base: S.TaggedErrorClass<"InvalidKeyPrefixFilterException", {
    readonly message: any;
}>;
export declare class InvalidKeyPrefixFilterException extends /*@__PURE__*/ InvalidKeyPrefixFilterException_base {
}
declare const InvalidLifecycleEventHookExecutionIdException_base: S.TaggedErrorClass<"InvalidLifecycleEventHookExecutionIdException", {
    readonly message: any;
}>;
export declare class InvalidLifecycleEventHookExecutionIdException extends /*@__PURE__*/ InvalidLifecycleEventHookExecutionIdException_base {
}
declare const InvalidLifecycleEventHookExecutionStatusException_base: S.TaggedErrorClass<"InvalidLifecycleEventHookExecutionStatusException", {
    readonly message: any;
}>;
export declare class InvalidLifecycleEventHookExecutionStatusException extends /*@__PURE__*/ InvalidLifecycleEventHookExecutionStatusException_base {
}
declare const InvalidLoadBalancerInfoException_base: S.TaggedErrorClass<"InvalidLoadBalancerInfoException", {
    readonly message: any;
}>;
export declare class InvalidLoadBalancerInfoException extends /*@__PURE__*/ InvalidLoadBalancerInfoException_base {
}
declare const InvalidMinimumHealthyHostValueException_base: S.TaggedErrorClass<"InvalidMinimumHealthyHostValueException", {
    readonly message: any;
}>;
export declare class InvalidMinimumHealthyHostValueException extends /*@__PURE__*/ InvalidMinimumHealthyHostValueException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidOnPremisesTagCombinationException_base: S.TaggedErrorClass<"InvalidOnPremisesTagCombinationException", {
    readonly message: any;
}>;
export declare class InvalidOnPremisesTagCombinationException extends /*@__PURE__*/ InvalidOnPremisesTagCombinationException_base {
}
declare const InvalidOperationException_base: S.TaggedErrorClass<"InvalidOperationException", {
    readonly message: any;
}>;
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidRegistrationStatusException_base: S.TaggedErrorClass<"InvalidRegistrationStatusException", {
    readonly message: any;
}>;
export declare class InvalidRegistrationStatusException extends /*@__PURE__*/ InvalidRegistrationStatusException_base {
}
declare const InvalidRevisionException_base: S.TaggedErrorClass<"InvalidRevisionException", {
    readonly message: any;
}>;
export declare class InvalidRevisionException extends /*@__PURE__*/ InvalidRevisionException_base {
}
declare const InvalidRoleException_base: S.TaggedErrorClass<"InvalidRoleException", {
    readonly message: any;
}>;
export declare class InvalidRoleException extends /*@__PURE__*/ InvalidRoleException_base {
}
declare const InvalidSortByException_base: S.TaggedErrorClass<"InvalidSortByException", {
    readonly message: any;
}>;
export declare class InvalidSortByException extends /*@__PURE__*/ InvalidSortByException_base {
}
declare const InvalidSortOrderException_base: S.TaggedErrorClass<"InvalidSortOrderException", {
    readonly message: any;
}>;
export declare class InvalidSortOrderException extends /*@__PURE__*/ InvalidSortOrderException_base {
}
declare const InvalidTagException_base: S.TaggedErrorClass<"InvalidTagException", {
    readonly message: any;
}>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const InvalidTagFilterException_base: S.TaggedErrorClass<"InvalidTagFilterException", {
    readonly message: any;
}>;
export declare class InvalidTagFilterException extends /*@__PURE__*/ InvalidTagFilterException_base {
}
declare const InvalidTagsToAddException_base: S.TaggedErrorClass<"InvalidTagsToAddException", {
    readonly message: any;
}>;
export declare class InvalidTagsToAddException extends /*@__PURE__*/ InvalidTagsToAddException_base {
}
declare const InvalidTargetFilterNameException_base: S.TaggedErrorClass<"InvalidTargetFilterNameException", {
    readonly message: any;
}>;
export declare class InvalidTargetFilterNameException extends /*@__PURE__*/ InvalidTargetFilterNameException_base {
}
declare const InvalidTargetGroupPairException_base: S.TaggedErrorClass<"InvalidTargetGroupPairException", {
    readonly message: any;
}>;
export declare class InvalidTargetGroupPairException extends /*@__PURE__*/ InvalidTargetGroupPairException_base {
}
declare const InvalidTargetInstancesException_base: S.TaggedErrorClass<"InvalidTargetInstancesException", {
    readonly message: any;
}>;
export declare class InvalidTargetInstancesException extends /*@__PURE__*/ InvalidTargetInstancesException_base {
}
declare const InvalidTimeRangeException_base: S.TaggedErrorClass<"InvalidTimeRangeException", {
    readonly message: any;
}>;
export declare class InvalidTimeRangeException extends /*@__PURE__*/ InvalidTimeRangeException_base {
}
declare const InvalidTrafficRoutingConfigurationException_base: S.TaggedErrorClass<"InvalidTrafficRoutingConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidTrafficRoutingConfigurationException extends /*@__PURE__*/ InvalidTrafficRoutingConfigurationException_base {
}
declare const InvalidTriggerConfigException_base: S.TaggedErrorClass<"InvalidTriggerConfigException", {
    readonly message: any;
}>;
export declare class InvalidTriggerConfigException extends /*@__PURE__*/ InvalidTriggerConfigException_base {
}
declare const InvalidUpdateOutdatedInstancesOnlyValueException_base: S.TaggedErrorClass<"InvalidUpdateOutdatedInstancesOnlyValueException", {
    readonly message: any;
}>;
export declare class InvalidUpdateOutdatedInstancesOnlyValueException extends /*@__PURE__*/ InvalidUpdateOutdatedInstancesOnlyValueException_base {
}
declare const InvalidZonalDeploymentConfigurationException_base: S.TaggedErrorClass<"InvalidZonalDeploymentConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidZonalDeploymentConfigurationException extends /*@__PURE__*/ InvalidZonalDeploymentConfigurationException_base {
}
declare const LifecycleEventAlreadyCompletedException_base: S.TaggedErrorClass<"LifecycleEventAlreadyCompletedException", {
    readonly message: any;
}>;
export declare class LifecycleEventAlreadyCompletedException extends /*@__PURE__*/ LifecycleEventAlreadyCompletedException_base {
}
declare const LifecycleHookLimitExceededException_base: S.TaggedErrorClass<"LifecycleHookLimitExceededException", {
    readonly message: any;
}>;
export declare class LifecycleHookLimitExceededException extends /*@__PURE__*/ LifecycleHookLimitExceededException_base {
}
declare const MultipleIamArnsProvidedException_base: S.TaggedErrorClass<"MultipleIamArnsProvidedException", {
    readonly message: any;
}>;
export declare class MultipleIamArnsProvidedException extends /*@__PURE__*/ MultipleIamArnsProvidedException_base {
}
declare const OperationNotSupportedException_base: S.TaggedErrorClass<"OperationNotSupportedException", {
    readonly message: any;
}>;
export declare class OperationNotSupportedException extends /*@__PURE__*/ OperationNotSupportedException_base {
}
declare const ResourceArnRequiredException_base: S.TaggedErrorClass<"ResourceArnRequiredException", {
    readonly message: any;
}>;
export declare class ResourceArnRequiredException extends /*@__PURE__*/ ResourceArnRequiredException_base {
}
declare const ResourceValidationException_base: S.TaggedErrorClass<"ResourceValidationException", {
    readonly message: any;
}>;
export declare class ResourceValidationException extends /*@__PURE__*/ ResourceValidationException_base {
}
declare const RevisionDoesNotExistException_base: S.TaggedErrorClass<"RevisionDoesNotExistException", {
    readonly message: any;
}>;
export declare class RevisionDoesNotExistException extends /*@__PURE__*/ RevisionDoesNotExistException_base {
}
declare const RevisionRequiredException_base: S.TaggedErrorClass<"RevisionRequiredException", {
    readonly message: any;
}>;
export declare class RevisionRequiredException extends /*@__PURE__*/ RevisionRequiredException_base {
}
declare const RoleRequiredException_base: S.TaggedErrorClass<"RoleRequiredException", {
    readonly message: any;
}>;
export declare class RoleRequiredException extends /*@__PURE__*/ RoleRequiredException_base {
}
declare const TagLimitExceededException_base: S.TaggedErrorClass<"TagLimitExceededException", {
    readonly message: any;
}>;
export declare class TagLimitExceededException extends /*@__PURE__*/ TagLimitExceededException_base {
}
declare const TagRequiredException_base: S.TaggedErrorClass<"TagRequiredException", {
    readonly message: any;
}>;
export declare class TagRequiredException extends /*@__PURE__*/ TagRequiredException_base {
}
declare const TagSetListLimitExceededException_base: S.TaggedErrorClass<"TagSetListLimitExceededException", {
    readonly message: any;
}>;
export declare class TagSetListLimitExceededException extends /*@__PURE__*/ TagSetListLimitExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TriggerTargetsLimitExceededException_base: S.TaggedErrorClass<"TriggerTargetsLimitExceededException", {
    readonly message: any;
}>;
export declare class TriggerTargetsLimitExceededException extends /*@__PURE__*/ TriggerTargetsLimitExceededException_base {
}
declare const UnsupportedActionForDeploymentTypeException_base: S.TaggedErrorClass<"UnsupportedActionForDeploymentTypeException", {
    readonly message: any;
}>;
export declare class UnsupportedActionForDeploymentTypeException extends /*@__PURE__*/ UnsupportedActionForDeploymentTypeException_base {
}
export type Key = string;
export type Value = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export type InstanceName = string;
export type InstanceNameList = string[];
export interface AddTagsToOnPremisesInstancesInput {
    tags: Tag[];
    instanceNames: string[];
}
export interface AddTagsToOnPremisesInstancesResponse {
}
export type ApplicationName = string;
export type RevisionLocationType = "S3" | "GitHub" | "String" | "AppSpecContent" | (string & {});
export type S3Bucket = string;
export type S3Key = string;
export type BundleType = "tar" | "tgz" | "zip" | "YAML" | "JSON" | (string & {});
export type VersionId = string;
export type ETag = string;
export interface S3Location {
    bucket?: string | undefined;
    key?: string | undefined;
    bundleType?: BundleType | undefined;
    version?: string | undefined;
    eTag?: string | undefined;
}
export type Repository = string;
export type CommitId = string;
export interface GitHubLocation {
    repository?: string | undefined;
    commitId?: string | undefined;
}
export type RawStringContent = string;
export type RawStringSha256 = string;
export interface RawString {
    content?: string | undefined;
    sha256?: string | undefined;
}
export interface AppSpecContent {
    content?: string | undefined;
    sha256?: string | undefined;
}
export interface RevisionLocation {
    revisionType?: RevisionLocationType | undefined;
    s3Location?: S3Location | undefined;
    gitHubLocation?: GitHubLocation | undefined;
    string?: RawString | undefined;
    appSpecContent?: AppSpecContent | undefined;
}
export type RevisionLocationList = RevisionLocation[];
export interface BatchGetApplicationRevisionsInput {
    applicationName: string;
    revisions: RevisionLocation[];
}
export type ErrorMessage = string;
export type Description = string;
export type DeploymentGroupName = string;
export type DeploymentGroupsList = string[];
export interface GenericRevisionInfo {
    description?: string | undefined;
    deploymentGroups?: string[] | undefined;
    firstUsedTime?: Date | undefined;
    lastUsedTime?: Date | undefined;
    registerTime?: Date | undefined;
}
export interface RevisionInfo {
    revisionLocation?: RevisionLocation | undefined;
    genericRevisionInfo?: GenericRevisionInfo | undefined;
}
export type RevisionInfoList = RevisionInfo[];
export interface BatchGetApplicationRevisionsOutput {
    applicationName?: string | undefined;
    errorMessage?: string | undefined;
    revisions?: RevisionInfo[] | undefined;
}
export type ApplicationsList = string[];
export interface BatchGetApplicationsInput {
    applicationNames: string[];
}
export type ApplicationId = string;
export type GitHubAccountTokenName = string;
export type ComputePlatform = "Server" | "Lambda" | "ECS" | (string & {});
export interface ApplicationInfo {
    applicationId?: string | undefined;
    applicationName?: string | undefined;
    createTime?: Date | undefined;
    linkedToGitHub?: boolean | undefined;
    gitHubAccountName?: string | undefined;
    computePlatform?: ComputePlatform | undefined;
}
export type ApplicationsInfoList = ApplicationInfo[];
export interface BatchGetApplicationsOutput {
    applicationsInfo?: ApplicationInfo[] | undefined;
}
export interface BatchGetDeploymentGroupsInput {
    applicationName: string;
    deploymentGroupNames: string[];
}
export type DeploymentGroupId = string;
export type DeploymentConfigName = string;
export type EC2TagFilterType = "KEY_ONLY" | "VALUE_ONLY" | "KEY_AND_VALUE" | (string & {});
export interface EC2TagFilter {
    Key?: string | undefined;
    Value?: string | undefined;
    Type?: EC2TagFilterType | undefined;
}
export type EC2TagFilterList = EC2TagFilter[];
export type TagFilterType = "KEY_ONLY" | "VALUE_ONLY" | "KEY_AND_VALUE" | (string & {});
export interface TagFilter {
    Key?: string | undefined;
    Value?: string | undefined;
    Type?: TagFilterType | undefined;
}
export type TagFilterList = TagFilter[];
export type AutoScalingGroupName = string;
export type AutoScalingGroupHook = string;
export interface AutoScalingGroup {
    name?: string | undefined;
    hook?: string | undefined;
    terminationHook?: string | undefined;
}
export type AutoScalingGroupList = AutoScalingGroup[];
export type Role = string;
export type TriggerName = string;
export type TriggerTargetArn = string;
export type TriggerEventType = "DeploymentStart" | "DeploymentSuccess" | "DeploymentFailure" | "DeploymentStop" | "DeploymentRollback" | "DeploymentReady" | "InstanceStart" | "InstanceSuccess" | "InstanceFailure" | "InstanceReady" | (string & {});
export type TriggerEventTypeList = TriggerEventType[];
export interface TriggerConfig {
    triggerName?: string | undefined;
    triggerTargetArn?: string | undefined;
    triggerEvents?: TriggerEventType[] | undefined;
}
export type TriggerConfigList = TriggerConfig[];
export type AlarmName = string;
export interface Alarm {
    name?: string | undefined;
}
export type AlarmList = Alarm[];
export interface AlarmConfiguration {
    enabled?: boolean | undefined;
    ignorePollAlarmFailure?: boolean | undefined;
    alarms?: Alarm[] | undefined;
}
export type AutoRollbackEvent = "DEPLOYMENT_FAILURE" | "DEPLOYMENT_STOP_ON_ALARM" | "DEPLOYMENT_STOP_ON_REQUEST" | (string & {});
export type AutoRollbackEventsList = AutoRollbackEvent[];
export interface AutoRollbackConfiguration {
    enabled?: boolean | undefined;
    events?: AutoRollbackEvent[] | undefined;
}
export type DeploymentType = "IN_PLACE" | "BLUE_GREEN" | (string & {});
export type DeploymentOption = "WITH_TRAFFIC_CONTROL" | "WITHOUT_TRAFFIC_CONTROL" | (string & {});
export interface DeploymentStyle {
    deploymentType?: DeploymentType | undefined;
    deploymentOption?: DeploymentOption | undefined;
}
export type OutdatedInstancesStrategy = "UPDATE" | "IGNORE" | (string & {});
export type InstanceAction = "TERMINATE" | "KEEP_ALIVE" | (string & {});
export type Duration = number;
export interface BlueInstanceTerminationOption {
    action?: InstanceAction | undefined;
    terminationWaitTimeInMinutes?: number | undefined;
}
export type DeploymentReadyAction = "CONTINUE_DEPLOYMENT" | "STOP_DEPLOYMENT" | (string & {});
export interface DeploymentReadyOption {
    actionOnTimeout?: DeploymentReadyAction | undefined;
    waitTimeInMinutes?: number | undefined;
}
export type GreenFleetProvisioningAction = "DISCOVER_EXISTING" | "COPY_AUTO_SCALING_GROUP" | (string & {});
export interface GreenFleetProvisioningOption {
    action?: GreenFleetProvisioningAction | undefined;
}
export interface BlueGreenDeploymentConfiguration {
    terminateBlueInstancesOnDeploymentSuccess?: BlueInstanceTerminationOption | undefined;
    deploymentReadyOption?: DeploymentReadyOption | undefined;
    greenFleetProvisioningOption?: GreenFleetProvisioningOption | undefined;
}
export type ELBName = string;
export interface ELBInfo {
    name?: string | undefined;
}
export type ELBInfoList = ELBInfo[];
export type TargetGroupName = string;
export interface TargetGroupInfo {
    name?: string | undefined;
}
export type TargetGroupInfoList = TargetGroupInfo[];
export type ListenerArn = string;
export type ListenerArnList = string[];
export interface TrafficRoute {
    listenerArns?: string[] | undefined;
}
export interface TargetGroupPairInfo {
    targetGroups?: TargetGroupInfo[] | undefined;
    prodTrafficRoute?: TrafficRoute | undefined;
    testTrafficRoute?: TrafficRoute | undefined;
}
export type TargetGroupPairInfoList = TargetGroupPairInfo[];
export interface LoadBalancerInfo {
    elbInfoList?: ELBInfo[] | undefined;
    targetGroupInfoList?: TargetGroupInfo[] | undefined;
    targetGroupPairInfoList?: TargetGroupPairInfo[] | undefined;
}
export type DeploymentId = string;
export type DeploymentStatus = "Created" | "Queued" | "InProgress" | "Baking" | "Succeeded" | "Failed" | "Stopped" | "Ready" | (string & {});
export interface LastDeploymentInfo {
    deploymentId?: string | undefined;
    status?: DeploymentStatus | undefined;
    endTime?: Date | undefined;
    createTime?: Date | undefined;
}
export type EC2TagSetList = EC2TagFilter[][];
export interface EC2TagSet {
    ec2TagSetList?: EC2TagFilter[][] | undefined;
}
export type OnPremisesTagSetList = TagFilter[][];
export interface OnPremisesTagSet {
    onPremisesTagSetList?: TagFilter[][] | undefined;
}
export type ECSServiceName = string;
export type ECSClusterName = string;
export interface ECSService {
    serviceName?: string | undefined;
    clusterName?: string | undefined;
}
export type ECSServiceList = ECSService[];
export type AutoScalingGroupProcess = "Terminate" | "AZRebalance" | "InstanceRefresh" | "ScheduledActions" | (string & {});
export type AutoScalingGroupProcessesToSuspendList = AutoScalingGroupProcess[];
export interface EC2DeploymentOptions {
    autoScalingGroupProcessesToSuspend?: AutoScalingGroupProcess[] | undefined;
}
export interface DeploymentGroupInfo {
    applicationName?: string | undefined;
    deploymentGroupId?: string | undefined;
    deploymentGroupName?: string | undefined;
    deploymentConfigName?: string | undefined;
    ec2TagFilters?: EC2TagFilter[] | undefined;
    onPremisesInstanceTagFilters?: TagFilter[] | undefined;
    autoScalingGroups?: AutoScalingGroup[] | undefined;
    serviceRoleArn?: string | undefined;
    targetRevision?: RevisionLocation | undefined;
    triggerConfigurations?: TriggerConfig[] | undefined;
    alarmConfiguration?: AlarmConfiguration | undefined;
    autoRollbackConfiguration?: AutoRollbackConfiguration | undefined;
    deploymentStyle?: DeploymentStyle | undefined;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy | undefined;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration | undefined;
    loadBalancerInfo?: LoadBalancerInfo | undefined;
    lastSuccessfulDeployment?: LastDeploymentInfo | undefined;
    lastAttemptedDeployment?: LastDeploymentInfo | undefined;
    ec2TagSet?: EC2TagSet | undefined;
    onPremisesTagSet?: OnPremisesTagSet | undefined;
    computePlatform?: ComputePlatform | undefined;
    ecsServices?: ECSService[] | undefined;
    ec2DeploymentOptions?: EC2DeploymentOptions | undefined;
    terminationHookEnabled?: boolean | undefined;
}
export type DeploymentGroupInfoList = DeploymentGroupInfo[];
export interface BatchGetDeploymentGroupsOutput {
    deploymentGroupsInfo?: DeploymentGroupInfo[] | undefined;
    errorMessage?: string | undefined;
}
export type InstanceId = string;
export type InstancesList = string[];
export interface BatchGetDeploymentInstancesInput {
    deploymentId: string;
    instanceIds: string[];
}
export type InstanceStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | "Ready" | (string & {});
export type LifecycleEventName = string;
export type LifecycleErrorCode = "Success" | "ScriptMissing" | "ScriptNotExecutable" | "ScriptTimedOut" | "ScriptFailed" | "UnknownError" | (string & {});
export type ScriptName = string;
export type LifecycleMessage = string;
export type LogTail = string;
export interface Diagnostics {
    errorCode?: LifecycleErrorCode | undefined;
    scriptName?: string | undefined;
    message?: string | undefined;
    logTail?: string | undefined;
}
export type LifecycleEventStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | (string & {});
export interface LifecycleEvent {
    lifecycleEventName?: string | undefined;
    diagnostics?: Diagnostics | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    status?: LifecycleEventStatus | undefined;
}
export type LifecycleEventList = LifecycleEvent[];
export type InstanceType = "Blue" | "Green" | (string & {});
export interface InstanceSummary {
    deploymentId?: string | undefined;
    instanceId?: string | undefined;
    status?: InstanceStatus | undefined;
    lastUpdatedAt?: Date | undefined;
    lifecycleEvents?: LifecycleEvent[] | undefined;
    instanceType?: InstanceType | undefined;
}
export type InstanceSummaryList = InstanceSummary[];
export interface BatchGetDeploymentInstancesOutput {
    instancesSummary?: InstanceSummary[] | undefined;
    errorMessage?: string | undefined;
}
export type DeploymentsList = string[];
export interface BatchGetDeploymentsInput {
    deploymentIds: string[];
}
export type ErrorCode = "AGENT_ISSUE" | "ALARM_ACTIVE" | "APPLICATION_MISSING" | "AUTOSCALING_VALIDATION_ERROR" | "AUTO_SCALING_CONFIGURATION" | "AUTO_SCALING_IAM_ROLE_PERMISSIONS" | "CODEDEPLOY_RESOURCE_CANNOT_BE_FOUND" | "CUSTOMER_APPLICATION_UNHEALTHY" | "DEPLOYMENT_GROUP_MISSING" | "ECS_UPDATE_ERROR" | "ELASTIC_LOAD_BALANCING_INVALID" | "ELB_INVALID_INSTANCE" | "HEALTH_CONSTRAINTS" | "HEALTH_CONSTRAINTS_INVALID" | "HOOK_EXECUTION_FAILURE" | "IAM_ROLE_MISSING" | "IAM_ROLE_PERMISSIONS" | "INTERNAL_ERROR" | "INVALID_ECS_SERVICE" | "INVALID_LAMBDA_CONFIGURATION" | "INVALID_LAMBDA_FUNCTION" | "INVALID_REVISION" | "MANUAL_STOP" | "MISSING_BLUE_GREEN_DEPLOYMENT_CONFIGURATION" | "MISSING_ELB_INFORMATION" | "MISSING_GITHUB_TOKEN" | "NO_EC2_SUBSCRIPTION" | "NO_INSTANCES" | "OVER_MAX_INSTANCES" | "RESOURCE_LIMIT_EXCEEDED" | "REVISION_MISSING" | "THROTTLED" | "TIMEOUT" | "CLOUDFORMATION_STACK_FAILURE" | (string & {});
export interface ErrorInformation {
    code?: ErrorCode | undefined;
    message?: string | undefined;
}
export type InstanceCount = number;
export interface DeploymentOverview {
    Pending?: number | undefined;
    InProgress?: number | undefined;
    Succeeded?: number | undefined;
    Failed?: number | undefined;
    Skipped?: number | undefined;
    Ready?: number | undefined;
}
export type DeploymentCreator = "user" | "autoscaling" | "codeDeployRollback" | "CodeDeploy" | "CodeDeployAutoUpdate" | "CloudFormation" | "CloudFormationRollback" | "autoscalingTermination" | (string & {});
export interface RollbackInfo {
    rollbackDeploymentId?: string | undefined;
    rollbackTriggeringDeploymentId?: string | undefined;
    rollbackMessage?: string | undefined;
}
export type AutoScalingGroupNameList = string[];
export interface TargetInstances {
    tagFilters?: EC2TagFilter[] | undefined;
    autoScalingGroups?: string[] | undefined;
    ec2TagSet?: EC2TagSet | undefined;
}
export type AdditionalDeploymentStatusInfo = string;
export type FileExistsBehavior = "DISALLOW" | "OVERWRITE" | "RETAIN" | (string & {});
export type DeploymentMode = "STANDARD" | "RESTART" | (string & {});
export type DeploymentStatusMessageList = string[];
export type ExternalId = string;
export interface RelatedDeployments {
    autoUpdateOutdatedInstancesRootDeploymentId?: string | undefined;
    autoUpdateOutdatedInstancesDeploymentIds?: string[] | undefined;
}
export interface DeploymentInfo {
    applicationName?: string | undefined;
    deploymentGroupName?: string | undefined;
    deploymentConfigName?: string | undefined;
    deploymentId?: string | undefined;
    previousRevision?: RevisionLocation | undefined;
    revision?: RevisionLocation | undefined;
    status?: DeploymentStatus | undefined;
    errorInformation?: ErrorInformation | undefined;
    createTime?: Date | undefined;
    startTime?: Date | undefined;
    completeTime?: Date | undefined;
    deploymentOverview?: DeploymentOverview | undefined;
    description?: string | undefined;
    creator?: DeploymentCreator | undefined;
    ignoreApplicationStopFailures?: boolean | undefined;
    autoRollbackConfiguration?: AutoRollbackConfiguration | undefined;
    updateOutdatedInstancesOnly?: boolean | undefined;
    rollbackInfo?: RollbackInfo | undefined;
    deploymentStyle?: DeploymentStyle | undefined;
    targetInstances?: TargetInstances | undefined;
    instanceTerminationWaitTimeStarted?: boolean | undefined;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration | undefined;
    loadBalancerInfo?: LoadBalancerInfo | undefined;
    additionalDeploymentStatusInfo?: string | undefined;
    fileExistsBehavior?: FileExistsBehavior | undefined;
    deploymentMode?: DeploymentMode | undefined;
    deploymentStatusMessages?: string[] | undefined;
    computePlatform?: ComputePlatform | undefined;
    externalId?: string | undefined;
    relatedDeployments?: RelatedDeployments | undefined;
    overrideAlarmConfiguration?: AlarmConfiguration | undefined;
    ec2DeploymentOptions?: EC2DeploymentOptions | undefined;
}
export type DeploymentsInfoList = DeploymentInfo[];
export interface BatchGetDeploymentsOutput {
    deploymentsInfo?: DeploymentInfo[] | undefined;
}
export type TargetId = string;
export type TargetIdList = string[];
export interface BatchGetDeploymentTargetsInput {
    deploymentId: string;
    targetIds: string[];
}
export type DeploymentTargetType = "InstanceTarget" | "LambdaTarget" | "ECSTarget" | "CloudFormationTarget" | (string & {});
export type TargetArn = string;
export type TargetStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | "Ready" | (string & {});
export type TargetLabel = "Blue" | "Green" | (string & {});
export interface InstanceTarget {
    deploymentId?: string | undefined;
    targetId?: string | undefined;
    targetArn?: string | undefined;
    status?: TargetStatus | undefined;
    lastUpdatedAt?: Date | undefined;
    lifecycleEvents?: LifecycleEvent[] | undefined;
    instanceLabel?: TargetLabel | undefined;
}
export type LambdaFunctionName = string;
export type LambdaFunctionAlias = string;
export type Version = string;
export type TrafficWeight = number;
export interface LambdaFunctionInfo {
    functionName?: string | undefined;
    functionAlias?: string | undefined;
    currentVersion?: string | undefined;
    targetVersion?: string | undefined;
    targetVersionWeight?: number | undefined;
}
export interface LambdaTarget {
    deploymentId?: string | undefined;
    targetId?: string | undefined;
    targetArn?: string | undefined;
    status?: TargetStatus | undefined;
    lastUpdatedAt?: Date | undefined;
    lifecycleEvents?: LifecycleEvent[] | undefined;
    lambdaFunctionInfo?: LambdaFunctionInfo | undefined;
}
export type ECSTaskSetIdentifier = string;
export type ECSTaskSetCount = number;
export type ECSTaskSetStatus = string;
export interface ECSTaskSet {
    identifer?: string | undefined;
    desiredCount?: number | undefined;
    pendingCount?: number | undefined;
    runningCount?: number | undefined;
    status?: string | undefined;
    trafficWeight?: number | undefined;
    targetGroup?: TargetGroupInfo | undefined;
    taskSetLabel?: TargetLabel | undefined;
}
export type ECSTaskSetList = ECSTaskSet[];
export interface ECSTarget {
    deploymentId?: string | undefined;
    targetId?: string | undefined;
    targetArn?: string | undefined;
    lastUpdatedAt?: Date | undefined;
    lifecycleEvents?: LifecycleEvent[] | undefined;
    status?: TargetStatus | undefined;
    taskSetsInfo?: ECSTaskSet[] | undefined;
}
export type CloudFormationResourceType = string;
export interface CloudFormationTarget {
    deploymentId?: string | undefined;
    targetId?: string | undefined;
    lastUpdatedAt?: Date | undefined;
    lifecycleEvents?: LifecycleEvent[] | undefined;
    status?: TargetStatus | undefined;
    resourceType?: string | undefined;
    targetVersionWeight?: number | undefined;
}
export interface DeploymentTarget {
    deploymentTargetType?: DeploymentTargetType | undefined;
    instanceTarget?: InstanceTarget | undefined;
    lambdaTarget?: LambdaTarget | undefined;
    ecsTarget?: ECSTarget | undefined;
    cloudFormationTarget?: CloudFormationTarget | undefined;
}
export type DeploymentTargetList = DeploymentTarget[];
export interface BatchGetDeploymentTargetsOutput {
    deploymentTargets?: DeploymentTarget[] | undefined;
}
export interface BatchGetOnPremisesInstancesInput {
    instanceNames: string[];
}
export type IamSessionArn = string;
export type IamUserArn = string;
export type InstanceArn = string;
export interface InstanceInfo {
    instanceName?: string | undefined;
    iamSessionArn?: string | undefined;
    iamUserArn?: string | undefined;
    instanceArn?: string | undefined;
    registerTime?: Date | undefined;
    deregisterTime?: Date | undefined;
    tags?: Tag[] | undefined;
}
export type InstanceInfoList = InstanceInfo[];
export interface BatchGetOnPremisesInstancesOutput {
    instanceInfos?: InstanceInfo[] | undefined;
}
export type DeploymentWaitType = "READY_WAIT" | "TERMINATION_WAIT" | (string & {});
export interface ContinueDeploymentInput {
    deploymentId?: string | undefined;
    deploymentWaitType?: DeploymentWaitType | undefined;
}
export interface ContinueDeploymentResponse {
}
export interface CreateApplicationInput {
    applicationName: string;
    computePlatform?: ComputePlatform | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateApplicationOutput {
    applicationId?: string | undefined;
}
export interface CreateDeploymentInput {
    applicationName: string;
    deploymentGroupName?: string | undefined;
    revision?: RevisionLocation | undefined;
    deploymentConfigName?: string | undefined;
    description?: string | undefined;
    ignoreApplicationStopFailures?: boolean | undefined;
    targetInstances?: TargetInstances | undefined;
    autoRollbackConfiguration?: AutoRollbackConfiguration | undefined;
    updateOutdatedInstancesOnly?: boolean | undefined;
    fileExistsBehavior?: FileExistsBehavior | undefined;
    deploymentMode?: DeploymentMode | undefined;
    overrideAlarmConfiguration?: AlarmConfiguration | undefined;
    ec2DeploymentOptions?: EC2DeploymentOptions | undefined;
}
export interface CreateDeploymentOutput {
    deploymentId?: string | undefined;
}
export type MinimumHealthyHostsType = "HOST_COUNT" | "FLEET_PERCENT" | (string & {});
export type MinimumHealthyHostsValue = number;
export interface MinimumHealthyHosts {
    type?: MinimumHealthyHostsType | undefined;
    value?: number | undefined;
}
export type TrafficRoutingType = "TimeBasedCanary" | "TimeBasedLinear" | "AllAtOnce" | (string & {});
export type Percentage = number;
export type WaitTimeInMins = number;
export interface TimeBasedCanary {
    canaryPercentage?: number | undefined;
    canaryInterval?: number | undefined;
}
export interface TimeBasedLinear {
    linearPercentage?: number | undefined;
    linearInterval?: number | undefined;
}
export interface TrafficRoutingConfig {
    type?: TrafficRoutingType | undefined;
    timeBasedCanary?: TimeBasedCanary | undefined;
    timeBasedLinear?: TimeBasedLinear | undefined;
}
export type WaitTimeInSeconds = number;
export type MinimumHealthyHostsPerZoneType = "HOST_COUNT" | "FLEET_PERCENT" | (string & {});
export type MinimumHealthyHostsPerZoneValue = number;
export interface MinimumHealthyHostsPerZone {
    type?: MinimumHealthyHostsPerZoneType | undefined;
    value?: number | undefined;
}
export interface ZonalConfig {
    firstZoneMonitorDurationInSeconds?: number | undefined;
    monitorDurationInSeconds?: number | undefined;
    minimumHealthyHostsPerZone?: MinimumHealthyHostsPerZone | undefined;
}
export interface CreateDeploymentConfigInput {
    deploymentConfigName: string;
    minimumHealthyHosts?: MinimumHealthyHosts | undefined;
    trafficRoutingConfig?: TrafficRoutingConfig | undefined;
    computePlatform?: ComputePlatform | undefined;
    zonalConfig?: ZonalConfig | undefined;
}
export type DeploymentConfigId = string;
export interface CreateDeploymentConfigOutput {
    deploymentConfigId?: string | undefined;
}
export interface CreateDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
    deploymentConfigName?: string | undefined;
    ec2TagFilters?: EC2TagFilter[] | undefined;
    onPremisesInstanceTagFilters?: TagFilter[] | undefined;
    autoScalingGroups?: string[] | undefined;
    serviceRoleArn: string;
    triggerConfigurations?: TriggerConfig[] | undefined;
    alarmConfiguration?: AlarmConfiguration | undefined;
    autoRollbackConfiguration?: AutoRollbackConfiguration | undefined;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy | undefined;
    deploymentStyle?: DeploymentStyle | undefined;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration | undefined;
    loadBalancerInfo?: LoadBalancerInfo | undefined;
    ec2TagSet?: EC2TagSet | undefined;
    ecsServices?: ECSService[] | undefined;
    onPremisesTagSet?: OnPremisesTagSet | undefined;
    tags?: Tag[] | undefined;
    ec2DeploymentOptions?: EC2DeploymentOptions | undefined;
    terminationHookEnabled?: boolean | undefined;
}
export interface CreateDeploymentGroupOutput {
    deploymentGroupId?: string | undefined;
}
export interface DeleteApplicationInput {
    applicationName: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteDeploymentConfigInput {
    deploymentConfigName: string;
}
export interface DeleteDeploymentConfigResponse {
}
export interface DeleteDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
}
export interface DeleteDeploymentGroupOutput {
    hooksNotCleanedUp?: AutoScalingGroup[] | undefined;
}
export interface DeleteGitHubAccountTokenInput {
    tokenName?: string | undefined;
}
export interface DeleteGitHubAccountTokenOutput {
    tokenName?: string | undefined;
}
export interface DeleteResourcesByExternalIdInput {
    externalId?: string | undefined;
}
export interface DeleteResourcesByExternalIdOutput {
}
export interface DeregisterOnPremisesInstanceInput {
    instanceName: string;
}
export interface DeregisterOnPremisesInstanceResponse {
}
export interface GetApplicationInput {
    applicationName: string;
}
export interface GetApplicationOutput {
    application?: ApplicationInfo | undefined;
}
export interface GetApplicationRevisionInput {
    applicationName: string;
    revision: RevisionLocation;
}
export interface GetApplicationRevisionOutput {
    applicationName?: string | undefined;
    revision?: RevisionLocation | undefined;
    revisionInfo?: GenericRevisionInfo | undefined;
}
export interface GetDeploymentInput {
    deploymentId: string;
}
export interface GetDeploymentOutput {
    deploymentInfo?: DeploymentInfo | undefined;
}
export interface GetDeploymentConfigInput {
    deploymentConfigName: string;
}
export interface DeploymentConfigInfo {
    deploymentConfigId?: string | undefined;
    deploymentConfigName?: string | undefined;
    minimumHealthyHosts?: MinimumHealthyHosts | undefined;
    createTime?: Date | undefined;
    computePlatform?: ComputePlatform | undefined;
    trafficRoutingConfig?: TrafficRoutingConfig | undefined;
    zonalConfig?: ZonalConfig | undefined;
}
export interface GetDeploymentConfigOutput {
    deploymentConfigInfo?: DeploymentConfigInfo | undefined;
}
export interface GetDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
}
export interface GetDeploymentGroupOutput {
    deploymentGroupInfo?: DeploymentGroupInfo | undefined;
}
export interface GetDeploymentInstanceInput {
    deploymentId: string;
    instanceId: string;
}
export interface GetDeploymentInstanceOutput {
    instanceSummary?: InstanceSummary | undefined;
}
export interface GetDeploymentTargetInput {
    deploymentId: string;
    targetId: string;
}
export interface GetDeploymentTargetOutput {
    deploymentTarget?: DeploymentTarget | undefined;
}
export interface GetOnPremisesInstanceInput {
    instanceName: string;
}
export interface GetOnPremisesInstanceOutput {
    instanceInfo?: InstanceInfo | undefined;
}
export type ApplicationRevisionSortBy = "registerTime" | "firstUsedTime" | "lastUsedTime" | (string & {});
export type SortOrder = "ascending" | "descending" | (string & {});
export type ListStateFilterAction = "include" | "exclude" | "ignore" | (string & {});
export type NextToken = string;
export interface ListApplicationRevisionsInput {
    applicationName: string;
    sortBy?: ApplicationRevisionSortBy | undefined;
    sortOrder?: SortOrder | undefined;
    s3Bucket?: string | undefined;
    s3KeyPrefix?: string | undefined;
    deployed?: ListStateFilterAction | undefined;
    nextToken?: string | undefined;
}
export interface ListApplicationRevisionsOutput {
    revisions?: RevisionLocation[] | undefined;
    nextToken?: string | undefined;
}
export interface ListApplicationsInput {
    nextToken?: string | undefined;
}
export interface ListApplicationsOutput {
    applications?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDeploymentConfigsInput {
    nextToken?: string | undefined;
}
export type DeploymentConfigsList = string[];
export interface ListDeploymentConfigsOutput {
    deploymentConfigsList?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDeploymentGroupsInput {
    applicationName: string;
    nextToken?: string | undefined;
}
export interface ListDeploymentGroupsOutput {
    applicationName?: string | undefined;
    deploymentGroups?: string[] | undefined;
    nextToken?: string | undefined;
}
export type InstanceStatusList = InstanceStatus[];
export type InstanceTypeList = InstanceType[];
export interface ListDeploymentInstancesInput {
    deploymentId: string;
    nextToken?: string | undefined;
    instanceStatusFilter?: InstanceStatus[] | undefined;
    instanceTypeFilter?: InstanceType[] | undefined;
}
export interface ListDeploymentInstancesOutput {
    instancesList?: string[] | undefined;
    nextToken?: string | undefined;
}
export type DeploymentStatusList = DeploymentStatus[];
export interface TimeRange {
    start?: Date | undefined;
    end?: Date | undefined;
}
export interface ListDeploymentsInput {
    applicationName?: string | undefined;
    deploymentGroupName?: string | undefined;
    externalId?: string | undefined;
    includeOnlyStatuses?: DeploymentStatus[] | undefined;
    createTimeRange?: TimeRange | undefined;
    nextToken?: string | undefined;
}
export interface ListDeploymentsOutput {
    deployments?: string[] | undefined;
    nextToken?: string | undefined;
}
export type TargetFilterName = "TargetStatus" | "ServerInstanceLabel" | (string & {});
export type FilterValue = string;
export type FilterValueList = string[];
export type TargetFilters = {
    [key in TargetFilterName]?: string[] | undefined;
};
export interface ListDeploymentTargetsInput {
    deploymentId: string;
    nextToken?: string | undefined;
    targetFilters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface ListDeploymentTargetsOutput {
    targetIds?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListGitHubAccountTokenNamesInput {
    nextToken?: string | undefined;
}
export type GitHubAccountTokenNameList = string[];
export interface ListGitHubAccountTokenNamesOutput {
    tokenNameList?: string[] | undefined;
    nextToken?: string | undefined;
}
export type RegistrationStatus = "Registered" | "Deregistered" | (string & {});
export interface ListOnPremisesInstancesInput {
    registrationStatus?: RegistrationStatus | undefined;
    tagFilters?: TagFilter[] | undefined;
    nextToken?: string | undefined;
}
export interface ListOnPremisesInstancesOutput {
    instanceNames?: string[] | undefined;
    nextToken?: string | undefined;
}
export type Arn = string;
export interface ListTagsForResourceInput {
    ResourceArn: string;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceOutput {
    Tags?: Tag[] | undefined;
    NextToken?: string | undefined;
}
export type LifecycleEventHookExecutionId = string;
export interface PutLifecycleEventHookExecutionStatusInput {
    deploymentId?: string | undefined;
    lifecycleEventHookExecutionId?: string | undefined;
    status?: LifecycleEventStatus | undefined;
}
export interface PutLifecycleEventHookExecutionStatusOutput {
    lifecycleEventHookExecutionId?: string | undefined;
}
export interface RegisterApplicationRevisionInput {
    applicationName: string;
    description?: string | undefined;
    revision: RevisionLocation;
}
export interface RegisterApplicationRevisionResponse {
}
export interface RegisterOnPremisesInstanceInput {
    instanceName: string;
    iamSessionArn?: string | undefined;
    iamUserArn?: string | undefined;
}
export interface RegisterOnPremisesInstanceResponse {
}
export interface RemoveTagsFromOnPremisesInstancesInput {
    tags: Tag[];
    instanceNames: string[];
}
export interface RemoveTagsFromOnPremisesInstancesResponse {
}
export interface SkipWaitTimeForInstanceTerminationInput {
    deploymentId?: string | undefined;
}
export interface SkipWaitTimeForInstanceTerminationResponse {
}
export interface StopDeploymentInput {
    deploymentId: string;
    autoRollbackEnabled?: boolean | undefined;
}
export type StopStatus = "Pending" | "Succeeded" | (string & {});
export type Message = string;
export interface StopDeploymentOutput {
    status?: StopStatus | undefined;
    statusMessage?: string | undefined;
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateApplicationInput {
    applicationName?: string | undefined;
    newApplicationName?: string | undefined;
}
export interface UpdateApplicationResponse {
}
export interface UpdateDeploymentGroupInput {
    applicationName: string;
    currentDeploymentGroupName: string;
    newDeploymentGroupName?: string | undefined;
    deploymentConfigName?: string | undefined;
    ec2TagFilters?: EC2TagFilter[] | undefined;
    onPremisesInstanceTagFilters?: TagFilter[] | undefined;
    autoScalingGroups?: string[] | undefined;
    serviceRoleArn?: string | undefined;
    triggerConfigurations?: TriggerConfig[] | undefined;
    alarmConfiguration?: AlarmConfiguration | undefined;
    autoRollbackConfiguration?: AutoRollbackConfiguration | undefined;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy | undefined;
    deploymentStyle?: DeploymentStyle | undefined;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration | undefined;
    loadBalancerInfo?: LoadBalancerInfo | undefined;
    ec2TagSet?: EC2TagSet | undefined;
    ecsServices?: ECSService[] | undefined;
    onPremisesTagSet?: OnPremisesTagSet | undefined;
    ec2DeploymentOptions?: EC2DeploymentOptions | undefined;
    terminationHookEnabled?: boolean | undefined;
}
export interface UpdateDeploymentGroupOutput {
    hooksNotCleanedUp?: AutoScalingGroup[] | undefined;
}
export type AddTagsToOnPremisesInstancesError = InstanceLimitExceededException | InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | InvalidTagException | TagLimitExceededException | TagRequiredException | CommonErrors;
/**
 * Adds tags to on-premises instances.
 */
export declare const addTagsToOnPremisesInstances: API.OperationMethod<AddTagsToOnPremisesInstancesInput & RegionInput, AddTagsToOnPremisesInstancesResponse, AddTagsToOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type BatchGetApplicationRevisionsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | InvalidApplicationNameException | InvalidRevisionException | RevisionRequiredException | CommonErrors;
/**
 * Gets information about one or more application revisions. The maximum number of
 * application revisions that can be returned is 25.
 */
export declare const batchGetApplicationRevisions: API.OperationMethod<BatchGetApplicationRevisionsInput & RegionInput, BatchGetApplicationRevisionsOutput, BatchGetApplicationRevisionsError, Credentials | HttpClient.HttpClient>;
export type BatchGetApplicationsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | InvalidApplicationNameException | CommonErrors;
/**
 * Gets information about one or more applications. The maximum number of applications
 * that can be returned is 100.
 */
export declare const batchGetApplications: API.OperationMethod<BatchGetApplicationsInput & RegionInput, BatchGetApplicationsOutput, BatchGetApplicationsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentGroupsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | DeploymentConfigDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | CommonErrors;
/**
 * Gets information about one or more deployment groups.
 */
export declare const batchGetDeploymentGroups: API.OperationMethod<BatchGetDeploymentGroupsInput & RegionInput, BatchGetDeploymentGroupsOutput, BatchGetDeploymentGroupsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentInstancesError = BatchLimitExceededException | DeploymentDoesNotExistException | DeploymentIdRequiredException | InstanceIdRequiredException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidInstanceNameException | CommonErrors;
/**
 * This method works, but is deprecated. Use `BatchGetDeploymentTargets`
 * instead.
 *
 * Returns an array of one or more instances associated with a deployment. This method
 * works with EC2/On-premises and Lambda compute platforms. The newer
 * `BatchGetDeploymentTargets` works with all compute platforms. The maximum
 * number of instances that can be returned is 25.
 */
export declare const batchGetDeploymentInstances: API.OperationMethod<BatchGetDeploymentInstancesInput & RegionInput, BatchGetDeploymentInstancesOutput, BatchGetDeploymentInstancesError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentsError = BatchLimitExceededException | DeploymentIdRequiredException | InvalidDeploymentIdException | CommonErrors;
/**
 * Gets information about one or more deployments. The maximum number of deployments that
 * can be returned is 25.
 */
export declare const batchGetDeployments: API.OperationMethod<BatchGetDeploymentsInput & RegionInput, BatchGetDeploymentsOutput, BatchGetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentTargetsError = DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | DeploymentTargetDoesNotExistException | DeploymentTargetIdRequiredException | DeploymentTargetListSizeExceededException | InstanceDoesNotExistException | InvalidDeploymentIdException | InvalidDeploymentTargetIdException | CommonErrors;
/**
 * Returns an array of one or more targets associated with a deployment. This method
 * works with all compute types and should be used instead of the deprecated
 * `BatchGetDeploymentInstances`. The maximum number of targets that can be
 * returned is 25.
 *
 * The type of targets returned depends on the deployment's compute platform or
 * deployment method:
 *
 * - **EC2/On-premises**: Information about Amazon EC2 instance targets.
 *
 * - **Lambda**: Information about
 * Lambda functions targets.
 *
 * - **Amazon ECS**: Information about Amazon ECS service targets.
 *
 * - **CloudFormation**: Information about
 * targets of blue/green deployments initiated by a CloudFormation stack
 * update.
 */
export declare const batchGetDeploymentTargets: API.OperationMethod<BatchGetDeploymentTargetsInput & RegionInput, BatchGetDeploymentTargetsOutput, BatchGetDeploymentTargetsError, Credentials | HttpClient.HttpClient>;
export type BatchGetOnPremisesInstancesError = BatchLimitExceededException | InstanceNameRequiredException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about one or more on-premises instances. The maximum number of
 * on-premises instances that can be returned is 25.
 */
export declare const batchGetOnPremisesInstances: API.OperationMethod<BatchGetOnPremisesInstancesInput & RegionInput, BatchGetOnPremisesInstancesOutput, BatchGetOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type ContinueDeploymentError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentIsNotInReadyStateException | InvalidDeploymentIdException | InvalidDeploymentStatusException | InvalidDeploymentWaitTypeException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * For a blue/green deployment, starts the process of rerouting traffic from instances in
 * the original environment to instances in the replacement environment without waiting for
 * a specified wait time to elapse. (Traffic rerouting, which is achieved by registering
 * instances in the replacement environment with the load balancer, can start as soon as
 * all instances have a status of Ready.)
 */
export declare const continueDeployment: API.OperationMethod<ContinueDeploymentInput & RegionInput, ContinueDeploymentResponse, ContinueDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ApplicationAlreadyExistsException | ApplicationLimitExceededException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidComputePlatformException | InvalidTagsToAddException | ThrottlingException | CommonErrors;
/**
 * Creates an application.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationInput & RegionInput, CreateApplicationOutput, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | DeploymentLimitExceededException | DescriptionTooLongException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidAutoScalingGroupProcessToSuspendException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidECSServiceException | InvalidFileExistsBehaviorException | InvalidGitHubAccountTokenException | InvalidIgnoreApplicationStopFailuresValueException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidRevisionException | InvalidRoleException | InvalidTargetInstancesException | InvalidTrafficRoutingConfigurationException | InvalidUpdateOutdatedInstancesOnlyValueException | RevisionDoesNotExistException | RevisionRequiredException | ThrottlingException | CommonErrors;
/**
 * Deploys an application revision through the specified deployment group.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentInput & RegionInput, CreateDeploymentOutput, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentConfigError = DeploymentConfigAlreadyExistsException | DeploymentConfigLimitExceededException | DeploymentConfigNameRequiredException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | InvalidMinimumHealthyHostValueException | InvalidTrafficRoutingConfigurationException | InvalidZonalDeploymentConfigurationException | CommonErrors;
/**
 * Creates a deployment configuration.
 */
export declare const createDeploymentConfig: API.OperationMethod<CreateDeploymentConfigInput & RegionInput, CreateDeploymentConfigOutput, CreateDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentGroupError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupAlreadyExistsException | DeploymentGroupLimitExceededException | DeploymentGroupNameRequiredException | ECSServiceMappingLimitExceededException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidAutoScalingGroupProcessToSuspendException | InvalidBlueGreenDeploymentConfigurationException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStyleException | InvalidEC2TagCombinationException | InvalidEC2TagException | InvalidECSServiceException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidOnPremisesTagCombinationException | InvalidRoleException | InvalidTagException | InvalidTagsToAddException | InvalidTargetGroupPairException | InvalidTrafficRoutingConfigurationException | InvalidTriggerConfigException | LifecycleHookLimitExceededException | RoleRequiredException | TagSetListLimitExceededException | ThrottlingException | TriggerTargetsLimitExceededException | CommonErrors;
/**
 * Creates a deployment group to which application revisions are deployed.
 */
export declare const createDeploymentGroup: API.OperationMethod<CreateDeploymentGroupInput & RegionInput, CreateDeploymentGroupOutput, CreateDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = ApplicationNameRequiredException | InvalidApplicationNameException | InvalidRoleException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationInput & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentConfigError = DeploymentConfigInUseException | DeploymentConfigNameRequiredException | InvalidDeploymentConfigNameException | InvalidOperationException | CommonErrors;
/**
 * Deletes a deployment configuration.
 *
 * A deployment configuration cannot be deleted if it is currently in use. Predefined
 * configurations cannot be deleted.
 */
export declare const deleteDeploymentConfig: API.OperationMethod<DeleteDeploymentConfigInput & RegionInput, DeleteDeploymentConfigResponse, DeleteDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentGroupError = ApplicationNameRequiredException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | InvalidRoleException | CommonErrors;
/**
 * Deletes a deployment group.
 */
export declare const deleteDeploymentGroup: API.OperationMethod<DeleteDeploymentGroupInput & RegionInput, DeleteDeploymentGroupOutput, DeleteDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGitHubAccountTokenError = GitHubAccountTokenDoesNotExistException | GitHubAccountTokenNameRequiredException | InvalidGitHubAccountTokenNameException | OperationNotSupportedException | ResourceValidationException | CommonErrors;
/**
 * Deletes a GitHub account connection.
 */
export declare const deleteGitHubAccountToken: API.OperationMethod<DeleteGitHubAccountTokenInput & RegionInput, DeleteGitHubAccountTokenOutput, DeleteGitHubAccountTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcesByExternalIdError = CommonErrors;
/**
 * Deletes resources linked to an external ID. This action only applies if you have
 * configured blue/green deployments through CloudFormation.
 *
 * It is not necessary to call this action directly. CloudFormation calls it
 * on your behalf when it needs to delete stack resources. This action is offered
 * publicly in case you need to delete resources to comply with General Data Protection
 * Regulation (GDPR) requirements.
 */
export declare const deleteResourcesByExternalId: API.OperationMethod<DeleteResourcesByExternalIdInput & RegionInput, DeleteResourcesByExternalIdOutput, DeleteResourcesByExternalIdError, Credentials | HttpClient.HttpClient>;
export type DeregisterOnPremisesInstanceError = InstanceNameRequiredException | InvalidInstanceNameException | CommonErrors;
/**
 * Deregisters an on-premises instance.
 */
export declare const deregisterOnPremisesInstance: API.OperationMethod<DeregisterOnPremisesInstanceInput & RegionInput, DeregisterOnPremisesInstanceResponse, DeregisterOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | CommonErrors;
/**
 * Gets information about an application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationInput & RegionInput, GetApplicationOutput, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationRevisionError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidRevisionException | RevisionDoesNotExistException | RevisionRequiredException | CommonErrors;
/**
 * Gets information about an application revision.
 */
export declare const getApplicationRevision: API.OperationMethod<GetApplicationRevisionInput & RegionInput, GetApplicationRevisionOutput, GetApplicationRevisionError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | CommonErrors;
/**
 * Gets information about a deployment.
 *
 * The `content` property of the `appSpecContent` object in
 * the returned revision is always null. Use `GetApplicationRevision` and
 * the `sha256` property of the returned `appSpecContent` object
 * to get the content of the deployment's AppSpec file.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentInput & RegionInput, GetDeploymentOutput, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentConfigError = DeploymentConfigDoesNotExistException | DeploymentConfigNameRequiredException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | CommonErrors;
/**
 * Gets information about a deployment configuration.
 */
export declare const getDeploymentConfig: API.OperationMethod<GetDeploymentConfigInput & RegionInput, GetDeploymentConfigOutput, GetDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentGroupError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | CommonErrors;
/**
 * Gets information about a deployment group.
 */
export declare const getDeploymentGroup: API.OperationMethod<GetDeploymentGroupInput & RegionInput, GetDeploymentGroupOutput, GetDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentInstanceError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InstanceDoesNotExistException | InstanceIdRequiredException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about an instance as part of a deployment.
 */
export declare const getDeploymentInstance: API.OperationMethod<GetDeploymentInstanceInput & RegionInput, GetDeploymentInstanceOutput, GetDeploymentInstanceError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentTargetError = DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | DeploymentTargetDoesNotExistException | DeploymentTargetIdRequiredException | InvalidDeploymentIdException | InvalidDeploymentTargetIdException | InvalidInstanceNameException | CommonErrors;
/**
 * Returns information about a deployment target.
 */
export declare const getDeploymentTarget: API.OperationMethod<GetDeploymentTargetInput & RegionInput, GetDeploymentTargetOutput, GetDeploymentTargetError, Credentials | HttpClient.HttpClient>;
export type GetOnPremisesInstanceError = InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about an on-premises instance.
 */
export declare const getOnPremisesInstance: API.OperationMethod<GetOnPremisesInstanceInput & RegionInput, GetOnPremisesInstanceOutput, GetOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type ListApplicationRevisionsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BucketNameFilterRequiredException | InvalidApplicationNameException | InvalidBucketNameFilterException | InvalidDeployedStateFilterException | InvalidKeyPrefixFilterException | InvalidNextTokenException | InvalidSortByException | InvalidSortOrderException | CommonErrors;
/**
 * Lists information about revisions for an application.
 */
export declare const listApplicationRevisions: API.PaginatedOperationMethod<ListApplicationRevisionsInput & RegionInput, ListApplicationRevisionsOutput, ListApplicationRevisionsError, Credentials | HttpClient.HttpClient, RevisionLocation>;
export type ListApplicationsError = InvalidNextTokenException | CommonErrors;
/**
 * Lists the applications registered with the user or Amazon Web Services account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsInput & RegionInput, ListApplicationsOutput, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationName>;
export type ListDeploymentConfigsError = InvalidNextTokenException | CommonErrors;
/**
 * Lists the deployment configurations with the user or Amazon Web Services account.
 */
export declare const listDeploymentConfigs: API.PaginatedOperationMethod<ListDeploymentConfigsInput & RegionInput, ListDeploymentConfigsOutput, ListDeploymentConfigsError, Credentials | HttpClient.HttpClient, DeploymentConfigName>;
export type ListDeploymentGroupsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidNextTokenException | CommonErrors;
/**
 * Lists the deployment groups for an application registered with the Amazon Web Services
 * user or Amazon Web Services account.
 */
export declare const listDeploymentGroups: API.PaginatedOperationMethod<ListDeploymentGroupsInput & RegionInput, ListDeploymentGroupsOutput, ListDeploymentGroupsError, Credentials | HttpClient.HttpClient, DeploymentGroupName>;
export type ListDeploymentInstancesError = ApplicationDoesNotExistException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidDeploymentInstanceTypeException | InvalidInstanceStatusException | InvalidInstanceTypeException | InvalidNextTokenException | InvalidTargetFilterNameException | CommonErrors;
/**
 * The newer `BatchGetDeploymentTargets` should be used instead because
 * it works with all compute types. `ListDeploymentInstances` throws an
 * exception if it is used with a compute platform other than EC2/On-premises or
 * Lambda.
 *
 * Lists the instance for a deployment associated with the user or Amazon Web Services account.
 */
export declare const listDeploymentInstances: API.PaginatedOperationMethod<ListDeploymentInstancesInput & RegionInput, ListDeploymentInstancesOutput, ListDeploymentInstancesError, Credentials | HttpClient.HttpClient, InstanceId>;
export type ListDeploymentsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStatusException | InvalidExternalIdException | InvalidInputException | InvalidNextTokenException | InvalidTimeRangeException | CommonErrors;
/**
 * Lists the deployments in a deployment group for an application registered with the
 * user or Amazon Web Services account.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsInput & RegionInput, ListDeploymentsOutput, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentId>;
export type ListDeploymentTargetsError = ApplicationDoesNotExistException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidDeploymentIdException | InvalidDeploymentInstanceTypeException | InvalidInstanceStatusException | InvalidInstanceTypeException | InvalidNextTokenException | InvalidTargetFilterNameException | CommonErrors;
/**
 * Returns an array of target IDs that are associated a deployment.
 */
export declare const listDeploymentTargets: API.OperationMethod<ListDeploymentTargetsInput & RegionInput, ListDeploymentTargetsOutput, ListDeploymentTargetsError, Credentials | HttpClient.HttpClient>;
export type ListGitHubAccountTokenNamesError = InvalidNextTokenException | OperationNotSupportedException | ResourceValidationException | CommonErrors;
/**
 * Lists the names of stored connections to GitHub accounts.
 */
export declare const listGitHubAccountTokenNames: API.OperationMethod<ListGitHubAccountTokenNamesInput & RegionInput, ListGitHubAccountTokenNamesOutput, ListGitHubAccountTokenNamesError, Credentials | HttpClient.HttpClient>;
export type ListOnPremisesInstancesError = InvalidNextTokenException | InvalidRegistrationStatusException | InvalidTagFilterException | CommonErrors;
/**
 * Gets a list of names for one or more on-premises instances.
 *
 * Unless otherwise specified, both registered and deregistered on-premises instance
 * names are listed. To list only registered or deregistered on-premises instance names,
 * use the registration status parameter.
 */
export declare const listOnPremisesInstances: API.OperationMethod<ListOnPremisesInstancesInput & RegionInput, ListOnPremisesInstancesOutput, ListOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ArnNotSupportedException | InvalidArnException | ResourceArnRequiredException | CommonErrors;
/**
 * Returns a list of tags for the resource identified by a specified Amazon Resource
 * Name (ARN). Tags are used to organize and categorize your CodeDeploy resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutLifecycleEventHookExecutionStatusError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | InvalidLifecycleEventHookExecutionIdException | InvalidLifecycleEventHookExecutionStatusException | LifecycleEventAlreadyCompletedException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * Sets the result of a Lambda validation function. The function validates
 * lifecycle hooks during a deployment that uses the Lambda or Amazon ECS compute platform. For Lambda deployments, the available
 * lifecycle hooks are `BeforeAllowTraffic` and `AfterAllowTraffic`.
 * For Amazon ECS deployments, the available lifecycle hooks are
 * `BeforeInstall`, `AfterInstall`,
 * `AfterAllowTestTraffic`, `BeforeAllowTraffic`, and
 * `AfterAllowTraffic`. Lambda validation functions return
 * `Succeeded` or `Failed`. For more information, see AppSpec 'hooks' Section for an Lambda Deployment and
 * AppSpec 'hooks' Section for an Amazon ECS Deployment.
 */
export declare const putLifecycleEventHookExecutionStatus: API.OperationMethod<PutLifecycleEventHookExecutionStatusInput & RegionInput, PutLifecycleEventHookExecutionStatusOutput, PutLifecycleEventHookExecutionStatusError, Credentials | HttpClient.HttpClient>;
export type RegisterApplicationRevisionError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DescriptionTooLongException | InvalidApplicationNameException | InvalidRevisionException | RevisionRequiredException | CommonErrors;
/**
 * Registers with CodeDeploy a revision for the specified application.
 */
export declare const registerApplicationRevision: API.OperationMethod<RegisterApplicationRevisionInput & RegionInput, RegisterApplicationRevisionResponse, RegisterApplicationRevisionError, Credentials | HttpClient.HttpClient>;
export type RegisterOnPremisesInstanceError = IamArnRequiredException | IamSessionArnAlreadyRegisteredException | IamUserArnAlreadyRegisteredException | IamUserArnRequiredException | InstanceNameAlreadyRegisteredException | InstanceNameRequiredException | InvalidIamSessionArnException | InvalidIamUserArnException | InvalidInstanceNameException | MultipleIamArnsProvidedException | CommonErrors;
/**
 * Registers an on-premises instance.
 *
 * Only one IAM ARN (an IAM session ARN or IAM user ARN) is supported in the request. You cannot use both.
 */
export declare const registerOnPremisesInstance: API.OperationMethod<RegisterOnPremisesInstanceInput & RegionInput, RegisterOnPremisesInstanceResponse, RegisterOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromOnPremisesInstancesError = InstanceLimitExceededException | InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | InvalidTagException | TagLimitExceededException | TagRequiredException | CommonErrors;
/**
 * Removes one or more tags from one or more on-premises instances.
 */
export declare const removeTagsFromOnPremisesInstances: API.OperationMethod<RemoveTagsFromOnPremisesInstancesInput & RegionInput, RemoveTagsFromOnPremisesInstancesResponse, RemoveTagsFromOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type SkipWaitTimeForInstanceTerminationError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidDeploymentIdException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * In a blue/green deployment, overrides any specified wait time and starts terminating
 * instances immediately after the traffic routing is complete.
 */
export declare const skipWaitTimeForInstanceTermination: API.OperationMethod<SkipWaitTimeForInstanceTerminationInput & RegionInput, SkipWaitTimeForInstanceTerminationResponse, SkipWaitTimeForInstanceTerminationError, Credentials | HttpClient.HttpClient>;
export type StopDeploymentError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * Attempts to stop an ongoing deployment.
 */
export declare const stopDeployment: API.OperationMethod<StopDeploymentInput & RegionInput, StopDeploymentOutput, StopDeploymentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ApplicationDoesNotExistException | ArnNotSupportedException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | InvalidArnException | InvalidTagsToAddException | ResourceArnRequiredException | TagRequiredException | CommonErrors;
/**
 * Associates the list of tags in the input `Tags` parameter with the
 * resource identified by the `ResourceArn` input parameter.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ApplicationDoesNotExistException | ArnNotSupportedException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | InvalidArnException | InvalidTagsToAddException | ResourceArnRequiredException | TagRequiredException | CommonErrors;
/**
 * Disassociates a resource from a list of tags. The resource is identified by the
 * `ResourceArn` input parameter. The tags are identified by the list of
 * keys in the `TagKeys` input parameter.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = ApplicationAlreadyExistsException | ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | CommonErrors;
/**
 * Changes the name of an application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationInput & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentGroupError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupAlreadyExistsException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | ECSServiceMappingLimitExceededException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidAutoScalingGroupProcessToSuspendException | InvalidBlueGreenDeploymentConfigurationException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStyleException | InvalidEC2TagCombinationException | InvalidEC2TagException | InvalidECSServiceException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidOnPremisesTagCombinationException | InvalidRoleException | InvalidTagException | InvalidTargetGroupPairException | InvalidTrafficRoutingConfigurationException | InvalidTriggerConfigException | LifecycleHookLimitExceededException | TagSetListLimitExceededException | ThrottlingException | TriggerTargetsLimitExceededException | CommonErrors;
/**
 * Changes information about a deployment group.
 */
export declare const updateDeploymentGroup: API.OperationMethod<UpdateDeploymentGroupInput & RegionInput, UpdateDeploymentGroupOutput, UpdateDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codedeploy.d.ts.map