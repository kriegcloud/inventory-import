import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ActiveSessionsExceededException_base: S.TaggedErrorClass<"ActiveSessionsExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ActiveSessionsExceededException extends /*@__PURE__*/ ActiveSessionsExceededException_base {
}
declare const ActiveStatementsExceededException_base: S.TaggedErrorClass<"ActiveStatementsExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ActiveStatementsExceededException extends /*@__PURE__*/ ActiveStatementsExceededException_base {
}
declare const ActiveWaitingRequestsExceededException_base: S.TaggedErrorClass<"ActiveWaitingRequestsExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ActiveWaitingRequestsExceededException extends /*@__PURE__*/ ActiveWaitingRequestsExceededException_base {
}
declare const BatchExecuteStatementException_base: S.TaggedErrorClass<"BatchExecuteStatementException", {
    readonly message: any;
    readonly StatementId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class BatchExecuteStatementException extends /*@__PURE__*/ BatchExecuteStatementException_base {
}
declare const DatabaseConnectionException_base: S.TaggedErrorClass<"DatabaseConnectionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DatabaseConnectionException extends /*@__PURE__*/ DatabaseConnectionException_base {
}
declare const ExecuteStatementException_base: S.TaggedErrorClass<"ExecuteStatementException", {
    readonly message: any;
    readonly StatementId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ExecuteStatementException extends /*@__PURE__*/ ExecuteStatementException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const QueryTimeoutException_base: S.TaggedErrorClass<"QueryTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryTimeoutException extends /*@__PURE__*/ QueryTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type StatementString = string;
export type SqlList = string[];
export type ClusterIdentifierString = string;
export type SecretArn = string;
export type StatementNameString = string;
export type ParameterName = string;
export type ParameterValue = string;
export interface SqlParameter {
    name: string;
    value: string;
}
export type SqlParametersList = SqlParameter[];
export type WorkgroupNameString = string;
export type ClientToken = string;
export type ResultFormatString = string;
export type SessionAliveSeconds = number;
export type UUID = string;
export type ExecutionMode = string;
export type WaitTimeSeconds = number;
export interface BatchExecuteStatementInput {
    Sqls: string[];
    ClusterIdentifier?: string | undefined;
    SecretArn?: string | undefined;
    DbUser?: string | undefined;
    Database?: string | undefined;
    WithEvent?: boolean | undefined;
    StatementName?: string | undefined;
    Parameters?: SqlParameter[] | undefined;
    WorkgroupName?: string | undefined;
    ClientToken?: string | undefined;
    ResultFormat?: string | undefined;
    SessionKeepAliveSeconds?: number | undefined;
    SessionId?: string | undefined;
    ExecutionMode?: string | undefined;
    WaitTimeSeconds?: number | undefined;
}
export type DbGroupList = string[];
export type StatementStatusString = string;
export type BoxedLong = number;
export type BoxedBoolean = boolean;
export interface BatchExecuteStatementOutput {
    Id?: string | undefined;
    CreatedAt?: Date | undefined;
    ClusterIdentifier?: string | undefined;
    DbUser?: string | undefined;
    DbGroups?: string[] | undefined;
    Database?: string | undefined;
    SecretArn?: string | undefined;
    WorkgroupName?: string | undefined;
    SessionId?: string | undefined;
    Status?: string | undefined;
    RedshiftPid?: number | undefined;
    HasResultSet?: boolean | undefined;
}
export interface CancelStatementRequest {
    Id: string;
}
export interface CancelStatementResponse {
    Status?: boolean | undefined;
}
export interface DescribeStatementRequest {
    Id: string;
    WaitTimeSeconds?: number | undefined;
}
export type StatusString = string;
export interface SubStatementData {
    Id: string;
    Duration?: number | undefined;
    Error?: string | undefined;
    Status?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    QueryString?: string | undefined;
    ResultRows?: number | undefined;
    ResultSize?: number | undefined;
    RedshiftQueryId?: number | undefined;
    RedshiftQueryUuid?: string | undefined;
    HasResultSet?: boolean | undefined;
}
export type SubStatementList = SubStatementData[];
export interface DescribeStatementResponse {
    Id: string;
    SecretArn?: string | undefined;
    DbUser?: string | undefined;
    Database?: string | undefined;
    ClusterIdentifier?: string | undefined;
    Duration?: number | undefined;
    Error?: string | undefined;
    Status?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    RedshiftPid?: number | undefined;
    HasResultSet?: boolean | undefined;
    QueryString?: string | undefined;
    ResultRows?: number | undefined;
    ResultSize?: number | undefined;
    RedshiftQueryId?: number | undefined;
    RedshiftQueryUuid?: string | undefined;
    QueryParameters?: SqlParameter[] | undefined;
    SubStatements?: SubStatementData[] | undefined;
    WorkgroupName?: string | undefined;
    ResultFormat?: string | undefined;
    SessionId?: string | undefined;
    ExecutionMode?: string | undefined;
}
export type PageSize = number;
export interface DescribeTableRequest {
    ClusterIdentifier?: string | undefined;
    SecretArn?: string | undefined;
    DbUser?: string | undefined;
    Database: string;
    ConnectedDatabase?: string | undefined;
    Schema?: string | undefined;
    Table?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkgroupName?: string | undefined;
}
export interface ColumnMetadata {
    isCaseSensitive?: boolean | undefined;
    isCurrency?: boolean | undefined;
    isSigned?: boolean | undefined;
    label?: string | undefined;
    name?: string | undefined;
    nullable?: number | undefined;
    precision?: number | undefined;
    scale?: number | undefined;
    schemaName?: string | undefined;
    tableName?: string | undefined;
    typeName?: string | undefined;
    length?: number | undefined;
    columnDefault?: string | undefined;
}
export type ColumnList = ColumnMetadata[];
export interface DescribeTableResponse {
    TableName?: string | undefined;
    ColumnList?: ColumnMetadata[] | undefined;
    NextToken?: string | undefined;
}
export interface ExecuteStatementInput {
    Sql: string;
    ClusterIdentifier?: string | undefined;
    SecretArn?: string | undefined;
    DbUser?: string | undefined;
    Database?: string | undefined;
    WithEvent?: boolean | undefined;
    StatementName?: string | undefined;
    Parameters?: SqlParameter[] | undefined;
    WorkgroupName?: string | undefined;
    ClientToken?: string | undefined;
    ResultFormat?: string | undefined;
    SessionKeepAliveSeconds?: number | undefined;
    SessionId?: string | undefined;
    WaitTimeSeconds?: number | undefined;
}
export interface ExecuteStatementOutput {
    Id?: string | undefined;
    CreatedAt?: Date | undefined;
    ClusterIdentifier?: string | undefined;
    DbUser?: string | undefined;
    DbGroups?: string[] | undefined;
    Database?: string | undefined;
    SecretArn?: string | undefined;
    WorkgroupName?: string | undefined;
    SessionId?: string | undefined;
    Status?: string | undefined;
    RedshiftPid?: number | undefined;
    HasResultSet?: boolean | undefined;
}
export interface GetStatementResultRequest {
    Id: string;
    NextToken?: string | undefined;
    WaitTimeSeconds?: number | undefined;
}
export type BoxedDouble = number;
export type Field = {
    isNull: boolean;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue: boolean;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue: number;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue: number;
    stringValue?: undefined;
    blobValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue: string;
    blobValue?: undefined;
} | {
    isNull?: undefined;
    booleanValue?: undefined;
    longValue?: undefined;
    doubleValue?: undefined;
    stringValue?: undefined;
    blobValue: Uint8Array;
};
export type FieldList = Field[];
export type SqlRecords = Field[][];
export type ColumnMetadataList = ColumnMetadata[];
export interface GetStatementResultResponse {
    Records: Field[][];
    ColumnMetadata?: ColumnMetadata[] | undefined;
    TotalNumRows?: number | undefined;
    NextToken?: string | undefined;
}
export interface GetStatementResultV2Request {
    Id: string;
    NextToken?: string | undefined;
    WaitTimeSeconds?: number | undefined;
}
export type QueryRecords = {
    CSVRecords: string;
};
export type FormattedSqlRecords = QueryRecords[];
export interface GetStatementResultV2Response {
    Records: QueryRecords[];
    ColumnMetadata?: ColumnMetadata[] | undefined;
    TotalNumRows?: number | undefined;
    ResultFormat?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListDatabasesRequest {
    ClusterIdentifier?: string | undefined;
    Database?: string | undefined;
    SecretArn?: string | undefined;
    DbUser?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkgroupName?: string | undefined;
}
export type DatabaseList = string[];
export interface ListDatabasesResponse {
    Databases?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSchemasRequest {
    ClusterIdentifier?: string | undefined;
    SecretArn?: string | undefined;
    DbUser?: string | undefined;
    Database: string;
    ConnectedDatabase?: string | undefined;
    SchemaPattern?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkgroupName?: string | undefined;
}
export type SchemaList = string[];
export interface ListSchemasResponse {
    Schemas?: string[] | undefined;
    NextToken?: string | undefined;
}
export type ListStatementsLimit = number;
export type SessionStatusString = string;
export interface ListSessionsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SessionId?: string | undefined;
    Status?: string | undefined;
    RoleLevel?: boolean | undefined;
    ClusterIdentifier?: string | undefined;
    WorkgroupName?: string | undefined;
    Database?: string | undefined;
}
export interface SessionData {
    SessionId: string;
    Status: string;
    CreatedAt: Date;
    UpdatedAt?: Date | undefined;
    Database?: string | undefined;
    DbUser?: string | undefined;
    ClusterIdentifier?: string | undefined;
    WorkgroupName?: string | undefined;
    SessionAliveSeconds?: number | undefined;
    SessionTtl?: Date | undefined;
    CurrentStatementId?: string | undefined;
}
export type SessionList = SessionData[];
export interface ListSessionsResponse {
    Sessions: SessionData[];
    NextToken?: string | undefined;
}
export interface ListStatementsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    StatementName?: string | undefined;
    Status?: string | undefined;
    RoleLevel?: boolean | undefined;
    Database?: string | undefined;
    ClusterIdentifier?: string | undefined;
    WorkgroupName?: string | undefined;
}
export type StatementStringList = string[];
export interface StatementData {
    Id: string;
    QueryString?: string | undefined;
    QueryStrings?: string[] | undefined;
    SecretArn?: string | undefined;
    Status?: string | undefined;
    StatementName?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    QueryParameters?: SqlParameter[] | undefined;
    IsBatchStatement?: boolean | undefined;
    ResultFormat?: string | undefined;
    SessionId?: string | undefined;
}
export type StatementList = StatementData[];
export interface ListStatementsResponse {
    Statements: StatementData[];
    NextToken?: string | undefined;
}
export interface ListTablesRequest {
    ClusterIdentifier?: string | undefined;
    SecretArn?: string | undefined;
    DbUser?: string | undefined;
    Database: string;
    ConnectedDatabase?: string | undefined;
    SchemaPattern?: string | undefined;
    TablePattern?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    WorkgroupName?: string | undefined;
}
export interface TableMember {
    name?: string | undefined;
    type?: string | undefined;
    schema?: string | undefined;
}
export type TableList = TableMember[];
export interface ListTablesResponse {
    Tables?: TableMember[] | undefined;
    NextToken?: string | undefined;
}
export type BatchExecuteStatementError = ActiveSessionsExceededException | ActiveStatementsExceededException | BatchExecuteStatementException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Runs one or more SQL statements, which can be data manipulation language (DML) or data definition language (DDL). Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const batchExecuteStatement: API.OperationMethod<BatchExecuteStatementInput & RegionInput, BatchExecuteStatementOutput, BatchExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type CancelStatementError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a running query. To be canceled, a query must be running.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const cancelStatement: API.OperationMethod<CancelStatementRequest & RegionInput, CancelStatementResponse, CancelStatementError, Credentials | HttpClient.HttpClient>;
export type DescribeStatementError = ActiveWaitingRequestsExceededException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the details about a specific instance when a query was run by the Amazon Redshift Data API. The information includes when the query started, when it finished, the query status, the number of rows returned, and the SQL statement.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const describeStatement: API.OperationMethod<DescribeStatementRequest & RegionInput, DescribeStatementResponse, DescribeStatementError, Credentials | HttpClient.HttpClient>;
export type DescribeTableError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the detailed information about a table from metadata in the cluster. The information includes its columns. A token is returned to page through the column list. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const describeTable: API.PaginatedOperationMethod<DescribeTableRequest & RegionInput, DescribeTableResponse, DescribeTableError, Credentials | HttpClient.HttpClient, ColumnMetadata>;
export type ExecuteStatementError = ActiveSessionsExceededException | ActiveStatementsExceededException | ExecuteStatementException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Runs an SQL statement, which can be data manipulation language (DML) or data definition language (DDL). This statement must be a single SQL statement. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const executeStatement: API.OperationMethod<ExecuteStatementInput & RegionInput, ExecuteStatementOutput, ExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type GetStatementResultError = ActiveWaitingRequestsExceededException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetches the temporarily cached result of an SQL statement in JSON format. The `ExecuteStatement` or `BatchExecuteStatement` operation that ran the SQL statement must have specified `ResultFormat` as `JSON` , or let the format default to JSON. A token is returned to page through the statement results.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const getStatementResult: API.PaginatedOperationMethod<GetStatementResultRequest & RegionInput, GetStatementResultResponse, GetStatementResultError, Credentials | HttpClient.HttpClient, Field[]>;
export type GetStatementResultV2Error = ActiveWaitingRequestsExceededException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetches the temporarily cached result of an SQL statement in CSV format. The `ExecuteStatement` or `BatchExecuteStatement` operation that ran the SQL statement must have specified `ResultFormat` as `CSV`. A token is returned to page through the statement results.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const getStatementResultV2: API.PaginatedOperationMethod<GetStatementResultV2Request & RegionInput, GetStatementResultV2Response, GetStatementResultV2Error, Credentials | HttpClient.HttpClient, QueryRecords>;
export type ListDatabasesError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the databases in a cluster. A token is returned to page through the database list. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const listDatabases: API.PaginatedOperationMethod<ListDatabasesRequest & RegionInput, ListDatabasesResponse, ListDatabasesError, Credentials | HttpClient.HttpClient, string>;
export type ListSchemasError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the schemas in a database. A token is returned to page through the schema list. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasRequest & RegionInput, ListSchemasResponse, ListSchemasError, Credentials | HttpClient.HttpClient, string>;
export type ListSessionsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the sessions that the caller created in the last 24 hours. By default, only sessions with a status of `AVAILABLE` or `BUSY` are returned. You can filter the results by session status, compute target (cluster or serverless workgroup), or database. To retrieve the metadata for a single session, provide the `SessionId` parameter. Use `NextToken` to page through the session list.
 *
 * Returns only the sessions that the caller created. When identity-enhanced role sessions are used, you must provide either the `ClusterIdentifier` or `WorkgroupName` parameter to ensure that the IAM Identity Center user can only access the Amazon Redshift IAM Identity Center applications they are assigned. For more information, see Trusted identity propagation overview.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest & RegionInput, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, SessionData>;
export type ListStatementsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List of SQL statements. By default, only finished statements are shown. A token is returned to page through the statement list.
 *
 * When you use identity-enhanced role sessions to list statements, you must provide either the `cluster-identifier` or `workgroup-name` parameter. This ensures that the IdC user can only access the Amazon Redshift IdC applications they are assigned. For more information, see Trusted identity propagation overview.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const listStatements: API.PaginatedOperationMethod<ListStatementsRequest & RegionInput, ListStatementsResponse, ListStatementsError, Credentials | HttpClient.HttpClient, StatementData>;
export type ListTablesError = DatabaseConnectionException | InternalServerException | QueryTimeoutException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the tables in a database. If neither `SchemaPattern` nor `TablePattern` are specified, then all tables in the database are returned. A token is returned to page through the table list. Depending on the authorization method, use one of the following combinations of request parameters:
 *
 * - Secrets Manager - when connecting to a cluster, provide the `secret-arn` of a secret stored in Secrets Manager which has `username` and `password`. The specified secret contains credentials to connect to the `database` you specify. When you are connecting to a cluster, you also supply the database name, If you provide a cluster identifier (`dbClusterIdentifier`), it must match the cluster identifier stored in the secret. When you are connecting to a serverless workgroup, you also supply the database name.
 *
 * - Temporary credentials - when connecting to your data warehouse, choose one of the following options:
 *
 * - When connecting to a serverless workgroup, specify the workgroup name and database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift-serverless:GetCredentials` operation is required.
 *
 * - When connecting to a cluster as an IAM identity, specify the cluster identifier and the database name. The database user name is derived from the IAM identity. For example, `arn:iam::123456789012:user:foo` has the database user name `IAM:foo`. Also, permission to call the `redshift:GetClusterCredentialsWithIAM` operation is required.
 *
 * - When connecting to a cluster as a database user, specify the cluster identifier, the database name, and the database user name. Also, permission to call the `redshift:GetClusterCredentials` operation is required.
 *
 * For more information about the Amazon Redshift Data API and CLI usage examples, see Using the Amazon Redshift Data API in the *Amazon Redshift Management Guide*.
 */
export declare const listTables: API.PaginatedOperationMethod<ListTablesRequest & RegionInput, ListTablesResponse, ListTablesError, Credentials | HttpClient.HttpClient, TableMember>;
export {};
//# sourceMappingURL=redshift-data.d.ts.map