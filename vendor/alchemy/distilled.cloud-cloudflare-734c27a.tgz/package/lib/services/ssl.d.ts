import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AdvancedCertificateManagerRequired_base: S.TaggedErrorClass<"AdvancedCertificateManagerRequired", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class AdvancedCertificateManagerRequired extends /*@__PURE__*/ AdvancedCertificateManagerRequired_base {
}
declare const CertificatePackNotDeletable_base: S.TaggedErrorClass<"CertificatePackNotDeletable", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CertificatePackNotDeletable extends /*@__PURE__*/ CertificatePackNotDeletable_base {
}
declare const CertificatePackNotFound_base: S.TaggedErrorClass<"CertificatePackNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CertificatePackNotFound extends /*@__PURE__*/ CertificatePackNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export type AnalyzeCreateRequestBundleMethod = "ubiquitous" | "optimal" | "force";
export interface CreateAnalyzeRequest {
    /** Identifier. */
    zoneId: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: AnalyzeCreateRequestBundleMethod | (string & {}) | undefined;
    /** The zone's SSL certificate or certificate and the intermediate(s). */
    certificate?: string | undefined;
}
export type CreateAnalyzeResponse = unknown;
export type CertificatePacksCreateRequestCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export type CertificatePacksCreateRequestHostsList = Array<string>;
export type CertificatePacksCreateRequestType = "advanced";
export type CertificatePacksCreateRequestValidationMethod = "txt" | "http" | "email";
export type CertificatePacksCreateRequestValidityDays = 14 | 30 | 90 | 365;
export interface CreateCertificatePackRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority: CertificatePacksCreateRequestCertificateAuthority | (string & {});
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksCreateRequestHostsList;
    /** Type of certificate pack. */
    type: CertificatePacksCreateRequestType | (string & {});
    /** Validation Method selected for the order. */
    validationMethod: CertificatePacksCreateRequestValidationMethod | (string & {});
    /** Validity Days selected for the order. */
    validityDays: CertificatePacksCreateRequestValidityDays | (number & {});
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | undefined;
}
export type CertificatePacksCreateResponseHostsList = Array<string>;
export type CertificatePacksCreateResponseStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type CertificatePacksCreateResponseType = "mh_custom" | "managed_hostname" | "sni_custom" | "universal" | "advanced" | "total_tls" | "keyless" | "legacy_custom";
export type CertificatePacksCreateResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export type CertificatePacksCreateResponseValidationMethod = "txt" | "http" | "email";
export type CertificatePacksCreateResponseValidityDays = 14 | 30 | 90 | 365;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCertificatePackResponse {
    /** The unique identifier for a certificate_pack. */
    id: string;
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksCreateResponseHostsList;
    /** Status of certificate pack. */
    status: CertificatePacksCreateResponseStatus;
    /** Type of certificate pack. */
    type: CertificatePacksCreateResponseType;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority?: CertificatePacksCreateResponseCertificateAuthority | null | undefined;
    /** Validation Method selected for the order. */
    validationMethod?: CertificatePacksCreateResponseValidationMethod | null | undefined;
    /** Validity Days selected for the order. */
    validityDays?: CertificatePacksCreateResponseValidityDays | null | undefined;
}
export interface DeleteCertificatePackRequest {
    /** Identifier. */
    zoneId: string;
    /** The unique identifier for a certificate_pack. */
    certificatePackId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCertificatePackResponse {
    /** The unique identifier for a certificate_pack. */
    id?: string | null | undefined;
}
export interface GetAutomaticUpgraderRequest {
    zoneId: string;
}
export type GetAutomaticUpgraderResponseValue = "auto" | "custom";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAutomaticUpgraderResponse {
    id: string;
    /** Whether this setting can be updated or not. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
    /** Current setting of the automatic SSL/TLS. */
    value: GetAutomaticUpgraderResponseValue;
    /** Next time this zone will be scanned by the Automatic SSL/TLS. */
    nextScheduledScan?: string | null | undefined;
}
export interface GetAutoOriginTlsKexRequest {
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAutoOriginTlsKexResponse {
    id: string;
    /** Whether Auto-Origin TLS KEX selection is enabled for the zone. */
    enabled: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
}
export interface GetCertificatePackRequest {
    /** Identifier. */
    zoneId: string;
    /** The unique identifier for a certificate_pack. */
    certificatePackId: string;
}
export type CertificatePacksGetResponseCertificatesItemHostsList = Array<string>;
export type CertificatePacksGetResponseCertificatesItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface CertificatePacksGetResponseCertificatesItemGeoRestrictions {
    label?: CertificatePacksGetResponseCertificatesItemGeoRestrictionsLabel | null | undefined;
}
export interface CertificatePacksGetResponseCertificatesItem {
    /** Certificate identifier. */
    id: string;
    /** Hostnames covered by this certificate. */
    hosts: CertificatePacksGetResponseCertificatesItemHostsList;
    /** Certificate status. */
    status: string;
    /** Certificate bundle method. */
    bundleMethod?: string | null | undefined;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null | undefined;
    /** Specify the region where your private key can be held locally. */
    geoRestrictions?: CertificatePacksGetResponseCertificatesItemGeoRestrictions | null | undefined;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null | undefined;
    /** When the certificate was last modified. */
    modifiedOn?: string | null | undefined;
    /** The order/priority in which the certificate will be used. */
    priority?: number | null | undefined;
    /** The type of hash used for the certificate. */
    signature?: string | null | undefined;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null | undefined;
    /** Identifier. */
    zoneId?: string | null | undefined;
}
export type CertificatePacksGetResponseCertificatesList = Array<CertificatePacksGetResponseCertificatesItem>;
export type CertificatePacksGetResponseHostsList = Array<string>;
export type CertificatePacksGetResponseStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type CertificatePacksGetResponseType = "mh_custom" | "managed_hostname" | "sni_custom" | "universal" | "advanced" | "total_tls" | "keyless" | "legacy_custom";
export type CertificatePacksGetResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export type CertificatePacksGetResponseDcvDelegationRecordsItemEmailsList = Array<string>;
export interface CertificatePacksGetResponseDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null | undefined;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null | undefined;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksGetResponseDcvDelegationRecordsItemEmailsList | null | undefined;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null | undefined;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null | undefined;
    /** Status of the validation record. */
    status?: string | null | undefined;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null | undefined;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null | undefined;
}
export type CertificatePacksGetResponseDcvDelegationRecordsList = Array<CertificatePacksGetResponseDcvDelegationRecordsItem>;
export interface CertificatePacksGetResponseValidationErrorsItem {
    /** A domain validation error. */
    message?: string | null | undefined;
}
export type CertificatePacksGetResponseValidationErrorsList = Array<CertificatePacksGetResponseValidationErrorsItem>;
export type CertificatePacksGetResponseValidationMethod = "txt" | "http" | "email" | "cname";
export type CertificatePacksGetResponseValidationRecordsItemEmailsList = Array<string>;
export interface CertificatePacksGetResponseValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null | undefined;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null | undefined;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksGetResponseValidationRecordsItemEmailsList | null | undefined;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null | undefined;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null | undefined;
    /** Status of the validation record. */
    status?: string | null | undefined;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null | undefined;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null | undefined;
}
export type CertificatePacksGetResponseValidationRecordsList = Array<CertificatePacksGetResponseValidationRecordsItem>;
export type CertificatePacksGetResponseValidityDays = 14 | 30 | 90 | 365;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCertificatePackResponse {
    /** The unique identifier for a certificate_pack. */
    id: string;
    /** Array of certificates in this pack. */
    certificates: CertificatePacksGetResponseCertificatesList;
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksGetResponseHostsList;
    /** Status of certificate pack. */
    status: CertificatePacksGetResponseStatus;
    /** Type of certificate pack. */
    type: CertificatePacksGetResponseType;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority?: CertificatePacksGetResponseCertificateAuthority | null | undefined;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | null | undefined;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CertificatePacksGetResponseDcvDelegationRecordsList | null | undefined;
    /** Identifier of the primary certificate in a pack. */
    primaryCertificate?: string | null | undefined;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CertificatePacksGetResponseValidationErrorsList | null | undefined;
    /** Validation Method selected for the order. */
    validationMethod?: CertificatePacksGetResponseValidationMethod | null | undefined;
    /** Certificates' validation records. */
    validationRecords?: CertificatePacksGetResponseValidationRecordsList | null | undefined;
    /** Validity Days selected for the order. */
    validityDays?: CertificatePacksGetResponseValidityDays | null | undefined;
}
export interface GetCertificatePackQuotaRequest {
    /** Identifier. */
    zoneId: string;
}
export interface CertificatePacksQuotaGetResponseAdvanced {
    /** Quantity Allocated. */
    allocated?: number | null | undefined;
    /** Quantity Used. */
    used?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCertificatePackQuotaResponse {
    advanced?: CertificatePacksQuotaGetResponseAdvanced | null | undefined;
}
export interface GetRecommendationRequest {
    zoneId: string;
}
export type GetRecommendationResponseValue = "auto" | "custom";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRecommendationResponse {
    id: string;
    /** Whether this setting can be updated or not. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
    /** Current setting of the automatic SSL/TLS. */
    value: GetRecommendationResponseValue;
    /** Next time this zone will be scanned by the Automatic SSL/TLS. */
    nextScheduledScan?: string | null | undefined;
}
export interface GetUniversalSettingRequest {
    /** Identifier. */
    zoneId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUniversalSettingResponse {
    /** Disabling Universal SSL removes any currently active Universal SSL certificates for your zone from the edge and prevents any future Universal SSL certificates from being ordered. If there are no advanced certificates or custom certificates uploaded for the domain, visitors will be unable to access the domain over HTTPS. */
    enabled?: boolean | null | undefined;
}
export interface GetVerificationRequest {
    /** Identifier. */
    zoneId: string;
    /** Immediately retry SSL Verification. */
    retry?: boolean | undefined;
}
export type VerificationGetResultItemCertificateStatus = "initializing" | "authorizing" | "active" | "expired" | "issuing" | "timing_out" | "pending_deployment";
export type VerificationGetResultItemSignature = "ECDSAWithSHA256" | "SHA1WithRSA" | "SHA256WithRSA";
export type VerificationGetResultItemValidationMethod = "http" | "cname" | "txt";
export type VerificationGetResultItemVerificationInfoRecordName = "record_name" | "http_url" | "cname" | "txt_name";
export type VerificationGetResultItemVerificationInfoRecordTarget = "record_value" | "http_body" | "cname_target" | "txt_value";
export interface VerificationGetResultItemVerificationInfo {
    /** Name of CNAME record. */
    recordName?: VerificationGetResultItemVerificationInfoRecordName | null | undefined;
    /** Target of CNAME record. */
    recordTarget?: VerificationGetResultItemVerificationInfoRecordTarget | null | undefined;
}
export type VerificationGetResultItemVerificationType = "cname" | "meta tag";
export interface VerificationGetResultItem {
    /** Current status of certificate. */
    certificateStatus: VerificationGetResultItemCertificateStatus;
    /** Certificate Authority is manually reviewing the order. */
    brandCheck?: boolean | null | undefined;
    /** Certificate Pack UUID. */
    certPackUuid?: string | null | undefined;
    /** Certificate's signature algorithm. */
    signature?: VerificationGetResultItemSignature | null | undefined;
    /** Validation method in use for a certificate pack order. */
    validationMethod?: VerificationGetResultItemValidationMethod | null | undefined;
    /** Certificate's required verification information. */
    verificationInfo?: VerificationGetResultItemVerificationInfo | null | undefined;
    /** Status of the required verification information, omitted if verification status is unknown. */
    verificationStatus?: boolean | null | undefined;
    /** Method of verification. */
    verificationType?: VerificationGetResultItemVerificationType | null | undefined;
}
export type VerificationGetResultList = Array<VerificationGetResultItem>;
export type GetVerificationResponse = VerificationGetResultList;
export type CertificatePacksListRequestDeploy = "staging" | "production";
export type CertificatePacksListRequestStatus = "all";
export interface ListCertificatePacksRequest {
    /** Identifier. */
    zoneId: string;
    /** Specify the deployment environment for the certificate packs. */
    deploy?: CertificatePacksListRequestDeploy | (string & {}) | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of certificate packs per page. */
    perPage?: number | undefined;
    /** Include Certificate Packs of all statuses, not just active ones. */
    status?: CertificatePacksListRequestStatus | (string & {}) | undefined;
}
export type CertificatePacksListResultItemCertificatesItemHostsList = Array<string>;
export type CertificatePacksListResultItemCertificatesItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface CertificatePacksListResultItemCertificatesItemGeoRestrictions {
    label?: CertificatePacksListResultItemCertificatesItemGeoRestrictionsLabel | null | undefined;
}
export interface CertificatePacksListResultItemCertificatesItem {
    /** Certificate identifier. */
    id: string;
    /** Hostnames covered by this certificate. */
    hosts: CertificatePacksListResultItemCertificatesItemHostsList;
    /** Certificate status. */
    status: string;
    /** Certificate bundle method. */
    bundleMethod?: string | null | undefined;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null | undefined;
    /** Specify the region where your private key can be held locally. */
    geoRestrictions?: CertificatePacksListResultItemCertificatesItemGeoRestrictions | null | undefined;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null | undefined;
    /** When the certificate was last modified. */
    modifiedOn?: string | null | undefined;
    /** The order/priority in which the certificate will be used. */
    priority?: number | null | undefined;
    /** The type of hash used for the certificate. */
    signature?: string | null | undefined;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null | undefined;
    /** Identifier. */
    zoneId?: string | null | undefined;
}
export type CertificatePacksListResultItemCertificatesList = Array<CertificatePacksListResultItemCertificatesItem>;
export type CertificatePacksListResultItemHostsList = Array<string>;
export type CertificatePacksListResultItemStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type CertificatePacksListResultItemType = "mh_custom" | "managed_hostname" | "sni_custom" | "universal" | "advanced" | "total_tls" | "keyless" | "legacy_custom";
export type CertificatePacksListResultItemCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export type CertificatePacksListResultItemDcvDelegationRecordsItemEmailsList = Array<string>;
export interface CertificatePacksListResultItemDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null | undefined;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null | undefined;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksListResultItemDcvDelegationRecordsItemEmailsList | null | undefined;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null | undefined;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null | undefined;
    /** Status of the validation record. */
    status?: string | null | undefined;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null | undefined;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null | undefined;
}
export type CertificatePacksListResultItemDcvDelegationRecordsList = Array<CertificatePacksListResultItemDcvDelegationRecordsItem>;
export type CertificatePacksListResultItemValidationErrorsItem = CertificatePacksGetResponseValidationErrorsItem;
export type CertificatePacksListResultItemValidationErrorsList = Array<CertificatePacksGetResponseValidationErrorsItem>;
export type CertificatePacksListResultItemValidationMethod = "txt" | "http" | "email";
export type CertificatePacksListResultItemValidationRecordsItemEmailsList = Array<string>;
export interface CertificatePacksListResultItemValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null | undefined;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null | undefined;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksListResultItemValidationRecordsItemEmailsList | null | undefined;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null | undefined;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null | undefined;
    /** Status of the validation record. */
    status?: string | null | undefined;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null | undefined;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null | undefined;
}
export type CertificatePacksListResultItemValidationRecordsList = Array<CertificatePacksListResultItemValidationRecordsItem>;
export type CertificatePacksListResultItemValidityDays = 14 | 30 | 90 | 365;
export interface CertificatePacksListResultItem {
    /** The unique identifier for a certificate_pack. */
    id: string;
    /** Array of certificates in this pack. */
    certificates: CertificatePacksListResultItemCertificatesList;
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksListResultItemHostsList;
    /** Status of certificate pack. */
    status: CertificatePacksListResultItemStatus;
    /** Type of certificate pack. */
    type: CertificatePacksListResultItemType;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority?: CertificatePacksListResultItemCertificateAuthority | null | undefined;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | null | undefined;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CertificatePacksListResultItemDcvDelegationRecordsList | null | undefined;
    /** Identifier of the primary certificate in a pack. */
    primaryCertificate?: string | null | undefined;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CertificatePacksListResultItemValidationErrorsList | null | undefined;
    /** Validation Method selected for the order. */
    validationMethod?: CertificatePacksListResultItemValidationMethod | null | undefined;
    /** Certificates' validation records. */
    validationRecords?: CertificatePacksListResultItemValidationRecordsList | null | undefined;
    /** Validity Days selected for the order. */
    validityDays?: CertificatePacksListResultItemValidityDays | null | undefined;
}
export type CertificatePacksListResultList = Array<CertificatePacksListResultItem>;
export interface ListCertificatePacksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CertificatePacksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type PatchAutomaticUpgraderRequestValue = "auto" | "custom";
export interface PatchAutomaticUpgraderRequest {
    zoneId: string;
    /** Controls enablement of Automatic SSL/TLS. */
    value: PatchAutomaticUpgraderRequestValue | (string & {});
}
export type PatchAutomaticUpgraderResponseValue = "auto" | "custom";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAutomaticUpgraderResponse {
    id: string;
    /** Whether this setting can be updated or not. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
    /** Current setting of the automatic SSL/TLS. */
    value: PatchAutomaticUpgraderResponseValue;
    /** Next time this zone will be scanned by the Automatic SSL/TLS. */
    nextScheduledScan?: string | null | undefined;
}
export interface PatchAutoOriginTlsKexRequest {
    zoneId: string;
    /** Controls enablement of Auto-Origin TLS KEX selection for the zone. */
    enabled: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAutoOriginTlsKexResponse {
    id: string;
    /** Whether Auto-Origin TLS KEX selection is enabled for the zone. */
    enabled: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
}
export interface PatchCertificatePackRequest {
    /** Identifier. */
    zoneId: string;
    /** The unique identifier for a certificate_pack. */
    certificatePackId: string;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | undefined;
}
export type CertificatePacksEditResponseCertificatesItemHostsList = Array<string>;
export type CertificatePacksEditResponseCertificatesItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export interface CertificatePacksEditResponseCertificatesItemGeoRestrictions {
    label?: CertificatePacksEditResponseCertificatesItemGeoRestrictionsLabel | null | undefined;
}
export interface CertificatePacksEditResponseCertificatesItem {
    /** Certificate identifier. */
    id: string;
    /** Hostnames covered by this certificate. */
    hosts: CertificatePacksEditResponseCertificatesItemHostsList;
    /** Certificate status. */
    status: string;
    /** Certificate bundle method. */
    bundleMethod?: string | null | undefined;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null | undefined;
    /** Specify the region where your private key can be held locally. */
    geoRestrictions?: CertificatePacksEditResponseCertificatesItemGeoRestrictions | null | undefined;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null | undefined;
    /** When the certificate was last modified. */
    modifiedOn?: string | null | undefined;
    /** The order/priority in which the certificate will be used. */
    priority?: number | null | undefined;
    /** The type of hash used for the certificate. */
    signature?: string | null | undefined;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null | undefined;
    /** Identifier. */
    zoneId?: string | null | undefined;
}
export type CertificatePacksEditResponseCertificatesList = Array<CertificatePacksEditResponseCertificatesItem>;
export type CertificatePacksEditResponseHostsList = Array<string>;
export type CertificatePacksEditResponseStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export type CertificatePacksEditResponseType = "mh_custom" | "managed_hostname" | "sni_custom" | "universal" | "advanced" | "total_tls" | "keyless" | "legacy_custom";
export type CertificatePacksEditResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export type CertificatePacksEditResponseDcvDelegationRecordsItemEmailsList = Array<string>;
export interface CertificatePacksEditResponseDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null | undefined;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null | undefined;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksEditResponseDcvDelegationRecordsItemEmailsList | null | undefined;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null | undefined;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null | undefined;
    /** Status of the validation record. */
    status?: string | null | undefined;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null | undefined;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null | undefined;
}
export type CertificatePacksEditResponseDcvDelegationRecordsList = Array<CertificatePacksEditResponseDcvDelegationRecordsItem>;
export type CertificatePacksEditResponseValidationErrorsItem = CertificatePacksGetResponseValidationErrorsItem;
export type CertificatePacksEditResponseValidationErrorsList = Array<CertificatePacksGetResponseValidationErrorsItem>;
export type CertificatePacksEditResponseValidationMethod = "txt" | "http" | "email";
export type CertificatePacksEditResponseValidationRecordsItemEmailsList = Array<string>;
export interface CertificatePacksEditResponseValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null | undefined;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null | undefined;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksEditResponseValidationRecordsItemEmailsList | null | undefined;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null | undefined;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null | undefined;
    /** Status of the validation record. */
    status?: string | null | undefined;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null | undefined;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null | undefined;
}
export type CertificatePacksEditResponseValidationRecordsList = Array<CertificatePacksEditResponseValidationRecordsItem>;
export type CertificatePacksEditResponseValidityDays = 14 | 30 | 90 | 365;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCertificatePackResponse {
    /** The unique identifier for a certificate_pack. */
    id: string;
    /** Array of certificates in this pack. */
    certificates: CertificatePacksEditResponseCertificatesList;
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksEditResponseHostsList;
    /** Status of certificate pack. */
    status: CertificatePacksEditResponseStatus;
    /** Type of certificate pack. */
    type: CertificatePacksEditResponseType;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority?: CertificatePacksEditResponseCertificateAuthority | null | undefined;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | null | undefined;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CertificatePacksEditResponseDcvDelegationRecordsList | null | undefined;
    /** Identifier of the primary certificate in a pack. */
    primaryCertificate?: string | null | undefined;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CertificatePacksEditResponseValidationErrorsList | null | undefined;
    /** Validation Method selected for the order. */
    validationMethod?: CertificatePacksEditResponseValidationMethod | null | undefined;
    /** Certificates' validation records. */
    validationRecords?: CertificatePacksEditResponseValidationRecordsList | null | undefined;
    /** Validity Days selected for the order. */
    validityDays?: CertificatePacksEditResponseValidityDays | null | undefined;
}
export interface PatchUniversalSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** Disabling Universal SSL removes any currently active Universal SSL certificates for your zone from the edge and prevents any future Universal SSL certificates from being ordered. If there are no advanced certificates or custom certificates uploaded for the domain, visitors will be unable to access the domain over HTTPS. */
    enabled?: boolean | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchUniversalSettingResponse {
    /** Disabling Universal SSL removes any currently active Universal SSL certificates for your zone from the edge and prevents any future Universal SSL certificates from being ordered. If there are no advanced certificates or custom certificates uploaded for the domain, visitors will be unable to access the domain over HTTPS. */
    enabled?: boolean | null | undefined;
}
export type VerificationEditRequestValidationMethod = "http" | "cname" | "txt" | "email";
export interface PatchVerificationRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate Pack UUID. */
    certificatePackId: string;
    /** Desired validation method. */
    validationMethod: VerificationEditRequestValidationMethod | (string & {});
}
export type VerificationEditResponseValidationMethod = "http" | "cname" | "txt" | "email";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchVerificationResponse {
    /** Result status. */
    status?: string | null | undefined;
    /** Desired validation method. */
    validationMethod?: VerificationEditResponseValidationMethod | null | undefined;
}
export type CreateAnalyzeError = CloudflareOpError;
/** Returns the set of hostnames, the signature algorithm, and the expiration date of the certificate. */
export declare const createAnalyze: API.OperationMethod<CreateAnalyzeRequest, CreateAnalyzeResponse, CreateAnalyzeError, CloudflareOpContext>;
export type CreateCertificatePackError = AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** For a given zone, order an advanced certificate pack. */
export declare const createCertificatePack: API.OperationMethod<CreateCertificatePackRequest, CreateCertificatePackResponse, CreateCertificatePackError, CloudflareOpContext>;
export type DeleteCertificatePackError = CertificatePackNotFound | Forbidden | CertificatePackNotDeletable | CloudflareOpError;
/** For a given zone, delete an advanced certificate pack. */
export declare const deleteCertificatePack: API.OperationMethod<DeleteCertificatePackRequest, DeleteCertificatePackResponse, DeleteCertificatePackError, CloudflareOpContext>;
export type GetAutomaticUpgraderError = CloudflareOpError;
/** If the system is enabled, the response will include next_scheduled_scan, representing the next time this zone will be scanned and the zone's ssl/tls encryption mode is potentially upgraded by the system. If the system is disabled, next_scheduled_scan will not be present in the response body. */
export declare const getAutomaticUpgrader: API.OperationMethod<GetAutomaticUpgraderRequest, GetAutomaticUpgraderResponse, GetAutomaticUpgraderError, CloudflareOpContext>;
export type GetAutoOriginTlsKexError = CloudflareOpError;
/** When enabled, Cloudflare automatically selects the preferred TLS key-exchange algorithm to use when establishing the TLS connection to the zone's origin, picking from the algorithms permitted by the zone's `origin_tls_compliance_modes` setting. When disabled, the default key-exchange ordering is used. */
export declare const getAutoOriginTlsKex: API.OperationMethod<GetAutoOriginTlsKexRequest, GetAutoOriginTlsKexResponse, GetAutoOriginTlsKexError, CloudflareOpContext>;
export type GetCertificatePackError = CertificatePackNotFound | Forbidden | CloudflareOpError;
/** For a given zone, get a certificate pack. */
export declare const getCertificatePack: API.OperationMethod<GetCertificatePackRequest, GetCertificatePackResponse, GetCertificatePackError, CloudflareOpContext>;
export type GetCertificatePackQuotaError = CloudflareOpError;
/** For a given zone, list certificate pack quotas. */
export declare const getCertificatePackQuota: API.OperationMethod<GetCertificatePackQuotaRequest, GetCertificatePackQuotaResponse, GetCertificatePackQuotaError, CloudflareOpContext>;
export type GetRecommendationError = CloudflareOpError;
/** Retrieve the SSL/TLS Recommender's recommendation for a zone. */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest, GetRecommendationResponse, GetRecommendationError, CloudflareOpContext>;
export type GetUniversalSettingError = Forbidden | CloudflareOpError;
/** Get Universal SSL Settings for a Zone. */
export declare const getUniversalSetting: API.OperationMethod<GetUniversalSettingRequest, GetUniversalSettingResponse, GetUniversalSettingError, CloudflareOpContext>;
export type GetVerificationError = CloudflareOpError;
/** Get SSL Verification Info for a Zone. */
export declare const getVerification: API.OperationMethod<GetVerificationRequest, GetVerificationResponse, GetVerificationError, CloudflareOpContext>;
export type ListCertificatePacksError = Forbidden | CloudflareOpError;
/** For a given zone, list all active certificate packs. */
export declare const listCertificatePacks: API.PaginatedOperationMethod<ListCertificatePacksRequest, ListCertificatePacksResponse, ListCertificatePacksError, CloudflareOpContext, CertificatePacksListResultItem>;
export type PatchAutomaticUpgraderError = CloudflareOpError;
/** The automatic system is enabled when this endpoint is hit with value in the request body is set to "auto", and disabled when the request body value is set to "custom". */
export declare const patchAutomaticUpgrader: API.OperationMethod<PatchAutomaticUpgraderRequest, PatchAutomaticUpgraderResponse, PatchAutomaticUpgraderError, CloudflareOpContext>;
export type PatchAutoOriginTlsKexError = CloudflareOpError;
/** Enable or disable Auto-Origin TLS KEX selection for the zone by sending `{"enabled": true}` or `{"enabled": false}`. When enabled, Cloudflare runs a periodic scan of the zone's origins to determine the preferred key-exchange algorithm and writes that preference to the edge so it is sent first in the TLS ClientHello to the origin. */
export declare const patchAutoOriginTlsKex: API.OperationMethod<PatchAutoOriginTlsKexRequest, PatchAutoOriginTlsKexResponse, PatchAutoOriginTlsKexError, CloudflareOpContext>;
export type PatchCertificatePackError = CertificatePackNotFound | Forbidden | CloudflareOpError;
/** For a given zone, restart validation or add cloudflare branding for an advanced certificate pack. The former is only a validation operation for a Certificate Pack in a validation_timed_out status. */
export declare const patchCertificatePack: API.OperationMethod<PatchCertificatePackRequest, PatchCertificatePackResponse, PatchCertificatePackError, CloudflareOpContext>;
export type PatchUniversalSettingError = Forbidden | CloudflareOpError;
/** Patch Universal SSL Settings for a Zone. */
export declare const patchUniversalSetting: API.OperationMethod<PatchUniversalSettingRequest, PatchUniversalSettingResponse, PatchUniversalSettingError, CloudflareOpContext>;
export type PatchVerificationError = CloudflareOpError;
/** Edit SSL validation method for a certificate pack. A PATCH request will request an immediate validation check on any certificate, and return the updated status. If a validation method is provided, the validation will be immediately attempted using that method. */
export declare const patchVerification: API.OperationMethod<PatchVerificationRequest, PatchVerificationResponse, PatchVerificationError, CloudflareOpContext>;
//# sourceMappingURL=ssl.d.ts.map