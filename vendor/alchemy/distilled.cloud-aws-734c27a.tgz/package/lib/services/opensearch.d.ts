import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BaseException_base: S.TaggedErrorClass<"BaseException", {
    readonly message: any;
}>;
export declare class BaseException extends /*@__PURE__*/ BaseException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyFailureException_base: S.TaggedErrorClass<"DependencyFailureException", {
    readonly message: any;
}>;
export declare class DependencyFailureException extends /*@__PURE__*/ DependencyFailureException_base {
}
declare const DisabledOperationException_base: S.TaggedErrorClass<"DisabledOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DisabledOperationException extends /*@__PURE__*/ DisabledOperationException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidPaginationTokenException_base: S.TaggedErrorClass<"InvalidPaginationTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const InvalidTypeException_base: S.TaggedErrorClass<"InvalidTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidTypeException extends /*@__PURE__*/ InvalidTypeException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SlotNotAvailableException_base: S.TaggedErrorClass<"SlotNotAvailableException", {
    readonly SlotSuggestions: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class SlotNotAvailableException extends /*@__PURE__*/ SlotNotAvailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ConnectionId = string;
export interface AcceptInboundConnectionRequest {
    ConnectionId: string;
}
export type OwnerId = string;
export type DomainName = string;
export type Region = string;
export interface AWSDomainInformation {
    OwnerId?: string | undefined;
    DomainName: string;
    Region?: string | undefined;
}
export interface DomainInformationContainer {
    AWSDomainInformation?: AWSDomainInformation | undefined;
}
export type InboundConnectionStatusCode = "PENDING_ACCEPTANCE" | "APPROVED" | "PROVISIONING" | "ACTIVE" | "REJECTING" | "REJECTED" | "DELETING" | "DELETED" | (string & {});
export type ConnectionStatusMessage = string;
export interface InboundConnectionStatus {
    StatusCode?: InboundConnectionStatusCode | undefined;
    Message?: string | undefined;
}
export type ConnectionMode = "DIRECT" | "VPC_ENDPOINT" | (string & {});
export interface InboundConnection {
    LocalDomainInfo?: DomainInformationContainer | undefined;
    RemoteDomainInfo?: DomainInformationContainer | undefined;
    ConnectionId?: string | undefined;
    ConnectionStatus?: InboundConnectionStatus | undefined;
    ConnectionMode?: ConnectionMode | undefined;
}
export interface AcceptInboundConnectionResponse {
    Connection?: InboundConnection | undefined;
}
export type DataSourceName = string;
export type RoleArn = string;
export interface S3GlueDataCatalog {
    RoleArn?: string | undefined;
}
export type DataSourceType = {
    S3GlueDataCatalog: S3GlueDataCatalog;
};
export type DataSourceDescription = string;
export interface AddDataSourceRequest {
    DomainName: string;
    Name: string;
    DataSourceType: DataSourceType;
    Description?: string | undefined;
}
export interface AddDataSourceResponse {
    Message?: string | undefined;
}
export type DirectQueryDataSourceName = string;
export type DirectQueryDataSourceRoleArn = string;
export interface CloudWatchDirectQueryDataSource {
    RoleArn: string;
}
export interface SecurityLakeDirectQueryDataSource {
    RoleArn: string;
}
export type AMPWorkspaceArn = string;
export interface PrometheusDirectQueryDataSource {
    RoleArn: string;
    WorkspaceArn: string;
}
export type DirectQueryDataSourceType = {
    CloudWatchLog: CloudWatchDirectQueryDataSource;
    SecurityLake?: undefined;
    Prometheus?: undefined;
} | {
    CloudWatchLog?: undefined;
    SecurityLake: SecurityLakeDirectQueryDataSource;
    Prometheus?: undefined;
} | {
    CloudWatchLog?: undefined;
    SecurityLake?: undefined;
    Prometheus: PrometheusDirectQueryDataSource;
};
export type DirectQueryDataSourceDescription = string;
export type ARN = string;
export type DirectQueryOpenSearchARNList = string[];
export type PolicyDocument = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface AddDirectQueryDataSourceRequest {
    DataSourceName: string;
    DataSourceType: DirectQueryDataSourceType;
    Description?: string | undefined;
    OpenSearchArns?: string[] | undefined;
    DataSourceAccessPolicy?: string | undefined;
    TagList?: Tag[] | undefined;
}
export interface AddDirectQueryDataSourceResponse {
    DataSourceArn?: string | undefined;
}
export type DomainArn = string;
export interface AddReplicationPeerRequest {
    DomainName: string;
    PeerDomainArn: string;
    DryRun?: boolean | undefined;
}
export type ReplicationStatus = "PENDING_SETUP" | "ACTIVE" | "SWITCHING_OVER" | "FAILING_OVER" | "PENDING_REMOVAL" | "DETACHED" | "EJECTED" | "FAILED" | (string & {});
export interface AddReplicationPeerResponse {
    DomainArn?: string | undefined;
    Status?: ReplicationStatus | undefined;
}
export interface AddTagsRequest {
    ARN: string;
    TagList: Tag[];
}
export interface AddTagsResponse {
}
export type PackageID = string;
export type PackageIDList = string[];
export interface KeyStoreAccessOption {
    KeyAccessRoleArn?: string | undefined;
    KeyStoreAccessEnabled: boolean;
}
export interface PackageAssociationConfiguration {
    KeyStoreAccessOption?: KeyStoreAccessOption | undefined;
}
export interface AssociatePackageRequest {
    PackageID: string;
    DomainName: string;
    PrerequisitePackageIDList?: string[] | undefined;
    AssociationConfiguration?: PackageAssociationConfiguration | undefined;
}
export type PackageName = string;
export type PackageType = "TXT-DICTIONARY" | "ZIP-PLUGIN" | "PACKAGE-LICENSE" | "PACKAGE-CONFIG" | (string & {});
export type LastUpdated = Date;
export type DomainPackageStatus = "ASSOCIATING" | "ASSOCIATION_FAILED" | "ACTIVE" | "DISSOCIATING" | "DISSOCIATION_FAILED" | (string & {});
export type PackageVersion = string;
export type ReferencePath = string;
export type ErrorType = string;
export type ErrorMessage = string;
export interface ErrorDetails {
    ErrorType?: string | undefined;
    ErrorMessage?: string | undefined;
}
export interface DomainPackageDetails {
    PackageID?: string | undefined;
    PackageName?: string | undefined;
    PackageType?: PackageType | undefined;
    LastUpdated?: Date | undefined;
    DomainName?: string | undefined;
    DomainPackageStatus?: DomainPackageStatus | undefined;
    PackageVersion?: string | undefined;
    PrerequisitePackageIDList?: string[] | undefined;
    ReferencePath?: string | undefined;
    ErrorDetails?: ErrorDetails | undefined;
    AssociationConfiguration?: PackageAssociationConfiguration | undefined;
}
export interface AssociatePackageResponse {
    DomainPackageDetails?: DomainPackageDetails | undefined;
}
export interface PackageDetailsForAssociation {
    PackageID: string;
    PrerequisitePackageIDList?: string[] | undefined;
    AssociationConfiguration?: PackageAssociationConfiguration | undefined;
}
export type PackageDetailsForAssociationList = PackageDetailsForAssociation[];
export interface AssociatePackagesRequest {
    PackageList: PackageDetailsForAssociation[];
    DomainName: string;
}
export type DomainPackageDetailsList = DomainPackageDetails[];
export interface AssociatePackagesResponse {
    DomainPackageDetailsList?: DomainPackageDetails[] | undefined;
}
export type Id = string;
export interface WorkspaceConfigurationInput {
    name: string;
    workspaceType: string;
}
export type ClientToken = string;
export interface AttachDataSourceRequest {
    id: string;
    dataSourceArn: string;
    workspaceId?: string | undefined;
    workspaceConfiguration?: WorkspaceConfigurationInput | undefined;
    clientToken?: string | undefined;
}
export type DataSourceAttachmentStatus = "PENDING" | "ATTACHED" | "FAILED" | (string & {});
export interface AttachDataSourceResponse {
    attachmentId?: string | undefined;
    id?: string | undefined;
    arn?: string | undefined;
    dataSourceArn?: string | undefined;
    status?: DataSourceAttachmentStatus | undefined;
}
export type AWSAccount = string;
export type AWSServicePrincipal = "application.opensearchservice.amazonaws.com" | (string & {});
export type RegionsList = string[];
export interface ServiceOptions {
    SupportedRegions?: string[] | undefined;
}
export interface AuthorizeVpcEndpointAccessRequest {
    DomainName: string;
    Account?: string | undefined;
    Service?: AWSServicePrincipal | undefined;
    ServiceOptions?: ServiceOptions | undefined;
}
export type PrincipalType = "AWS_ACCOUNT" | "AWS_SERVICE" | (string & {});
export interface AuthorizedPrincipal {
    PrincipalType?: PrincipalType | undefined;
    Principal?: string | undefined;
    ServiceOptions?: ServiceOptions | undefined;
}
export interface AuthorizeVpcEndpointAccessResponse {
    AuthorizedPrincipal: AuthorizedPrincipal;
}
export type DryRun = boolean;
export interface CancelDomainConfigChangeRequest {
    DomainName: string;
    DryRun?: boolean | undefined;
}
export type GUID = string;
export type GUIDList = string[];
export interface CancelledChangeProperty {
    PropertyName?: string | undefined;
    CancelledValue?: string | undefined;
    ActiveValue?: string | undefined;
}
export type CancelledChangePropertyList = CancelledChangeProperty[];
export interface CancelDomainConfigChangeResponse {
    CancelledChangeIds?: string[] | undefined;
    CancelledChangeProperties?: CancelledChangeProperty[] | undefined;
    DryRun?: boolean | undefined;
}
export interface CancelServiceSoftwareUpdateRequest {
    DomainName: string;
}
export type DeploymentStatus = "PENDING_UPDATE" | "IN_PROGRESS" | "COMPLETED" | "NOT_ELIGIBLE" | "ELIGIBLE" | (string & {});
export type DeploymentCloseDateTimeStamp = Date;
export interface ServiceSoftwareOptions {
    CurrentVersion?: string | undefined;
    NewVersion?: string | undefined;
    UpdateAvailable?: boolean | undefined;
    Cancellable?: boolean | undefined;
    UpdateStatus?: DeploymentStatus | undefined;
    Description?: string | undefined;
    AutomatedUpdateDate?: Date | undefined;
    OptionalDeployment?: boolean | undefined;
}
export interface CancelServiceSoftwareUpdateResponse {
    ServiceSoftwareOptions?: ServiceSoftwareOptions | undefined;
}
export type MetadataCategory = string;
export type MetadataCategoryList = string[];
export interface CompareDomainConfigurationRequest {
    SourceDomainArn: string;
    TargetDomainArn: string;
    Categories: string[];
}
export type DiffStatus = "compared" | "error" | (string & {});
export type DiffCount = number;
export type DiffItemName = string;
export type DiffItemNameList = string[];
export type DiffFieldPath = string;
export type DiffFieldValue = string;
export type DiffFieldPolicy = "redacted" | (string & {});
export interface DivergentField {
    Path?: string | undefined;
    SourceValue?: string | undefined;
    TargetValue?: string | undefined;
    Policy?: DiffFieldPolicy | undefined;
}
export type DivergentFieldList = DivergentField[];
export interface DivergentItem {
    Name?: string | undefined;
    Fields?: DivergentField[] | undefined;
}
export type DivergentItemList = DivergentItem[];
export interface DiffItems {
    SourceOnly?: string[] | undefined;
    TargetOnly?: string[] | undefined;
    Diverged?: DivergentItem[] | undefined;
}
export interface CategoryDiffResult {
    Status?: DiffStatus | undefined;
    InSync?: number | undefined;
    SourceOnly?: number | undefined;
    TargetOnly?: number | undefined;
    Diverged?: number | undefined;
    Items?: DiffItems | undefined;
    Truncated?: boolean | undefined;
}
export type CompareDomainConfigurationCategoryMap = {
    [key: string]: CategoryDiffResult | undefined;
};
export interface CompareDomainConfigurationResponse {
    SourceDomainArn?: string | undefined;
    TargetDomainArn?: string | undefined;
    Categories?: {
        [key: string]: CategoryDiffResult | undefined;
    } | undefined;
}
export type ApplicationName = string;
export interface DataSource {
    dataSourceArn?: string | undefined;
    dataSourceDescription?: string | undefined;
    iamRoleForDataSourceArn?: string | undefined;
}
export type DataSources = DataSource[];
export interface IamIdentityCenterOptionsInput {
    enabled?: boolean | undefined;
    iamIdentityCenterInstanceArn?: string | undefined;
    iamRoleForIdentityCenterApplicationArn?: string | undefined;
}
export type AppConfigType = "opensearchDashboards.dashboardAdmin.users" | "opensearchDashboards.dashboardAdmin.groups" | (string & {});
export type AppConfigValue = string;
export interface AppConfig {
    key?: AppConfigType | undefined;
    value?: string | undefined;
}
export type AppConfigs = AppConfig[];
export type KmsKeyArn = string;
export interface CreateApplicationRequest {
    clientToken?: string | undefined;
    name: string;
    dataSources?: DataSource[] | undefined;
    iamIdentityCenterOptions?: IamIdentityCenterOptionsInput | undefined;
    appConfigs?: AppConfig[] | undefined;
    tagList?: Tag[] | undefined;
    kmsKeyArn?: string | undefined;
}
export interface IamIdentityCenterOptions {
    enabled?: boolean | undefined;
    iamIdentityCenterInstanceArn?: string | undefined;
    iamRoleForIdentityCenterApplicationArn?: string | undefined;
    iamIdentityCenterApplicationArn?: string | undefined;
}
export interface CreateApplicationResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    dataSources?: DataSource[] | undefined;
    iamIdentityCenterOptions?: IamIdentityCenterOptions | undefined;
    appConfigs?: AppConfig[] | undefined;
    tagList?: Tag[] | undefined;
    createdAt?: Date | undefined;
    kmsKeyArn?: string | undefined;
}
export type VersionString = string;
export type OpenSearchPartitionInstanceType = "m3.medium.search" | "m3.large.search" | "m3.xlarge.search" | "m3.2xlarge.search" | "m4.large.search" | "m4.xlarge.search" | "m4.2xlarge.search" | "m4.4xlarge.search" | "m4.10xlarge.search" | "m5.large.search" | "m5.xlarge.search" | "m5.2xlarge.search" | "m5.4xlarge.search" | "m5.12xlarge.search" | "m5.24xlarge.search" | "r5.large.search" | "r5.xlarge.search" | "r5.2xlarge.search" | "r5.4xlarge.search" | "r5.12xlarge.search" | "r5.24xlarge.search" | "c5.large.search" | "c5.xlarge.search" | "c5.2xlarge.search" | "c5.4xlarge.search" | "c5.9xlarge.search" | "c5.18xlarge.search" | "t3.nano.search" | "t3.micro.search" | "t3.small.search" | "t3.medium.search" | "t3.large.search" | "t3.xlarge.search" | "t3.2xlarge.search" | "or1.medium.search" | "or1.large.search" | "or1.xlarge.search" | "or1.2xlarge.search" | "or1.4xlarge.search" | "or1.8xlarge.search" | "or1.12xlarge.search" | "or1.16xlarge.search" | "ultrawarm1.medium.search" | "ultrawarm1.large.search" | "ultrawarm1.xlarge.search" | "t2.micro.search" | "t2.small.search" | "t2.medium.search" | "r3.large.search" | "r3.xlarge.search" | "r3.2xlarge.search" | "r3.4xlarge.search" | "r3.8xlarge.search" | "i2.xlarge.search" | "i2.2xlarge.search" | "d2.xlarge.search" | "d2.2xlarge.search" | "d2.4xlarge.search" | "d2.8xlarge.search" | "c4.large.search" | "c4.xlarge.search" | "c4.2xlarge.search" | "c4.4xlarge.search" | "c4.8xlarge.search" | "r4.large.search" | "r4.xlarge.search" | "r4.2xlarge.search" | "r4.4xlarge.search" | "r4.8xlarge.search" | "r4.16xlarge.search" | "i3.large.search" | "i3.xlarge.search" | "i3.2xlarge.search" | "i3.4xlarge.search" | "i3.8xlarge.search" | "i3.16xlarge.search" | "r6g.large.search" | "r6g.xlarge.search" | "r6g.2xlarge.search" | "r6g.4xlarge.search" | "r6g.8xlarge.search" | "r6g.12xlarge.search" | "m6g.large.search" | "m6g.xlarge.search" | "m6g.2xlarge.search" | "m6g.4xlarge.search" | "m6g.8xlarge.search" | "m6g.12xlarge.search" | "c6g.large.search" | "c6g.xlarge.search" | "c6g.2xlarge.search" | "c6g.4xlarge.search" | "c6g.8xlarge.search" | "c6g.12xlarge.search" | "r6gd.large.search" | "r6gd.xlarge.search" | "r6gd.2xlarge.search" | "r6gd.4xlarge.search" | "r6gd.8xlarge.search" | "r6gd.12xlarge.search" | "r6gd.16xlarge.search" | "t4g.small.search" | "t4g.medium.search" | (string & {});
export type IntegerClass = number;
export interface ZoneAwarenessConfig {
    AvailabilityZoneCount?: number | undefined;
}
export type OpenSearchWarmPartitionInstanceType = "ultrawarm1.medium.search" | "ultrawarm1.large.search" | "ultrawarm1.xlarge.search" | (string & {});
export interface ColdStorageOptions {
    Enabled: boolean;
}
export type NodeOptionsNodeType = "coordinator" | (string & {});
export interface NodeConfig {
    Enabled?: boolean | undefined;
    Type?: OpenSearchPartitionInstanceType | undefined;
    Count?: number | undefined;
}
export interface NodeOption {
    NodeType?: NodeOptionsNodeType | undefined;
    NodeConfig?: NodeConfig | undefined;
}
export type NodeOptionsList = NodeOption[];
export interface ClusterConfig {
    InstanceType?: OpenSearchPartitionInstanceType | undefined;
    InstanceCount?: number | undefined;
    DedicatedMasterEnabled?: boolean | undefined;
    ZoneAwarenessEnabled?: boolean | undefined;
    ZoneAwarenessConfig?: ZoneAwarenessConfig | undefined;
    DedicatedMasterType?: OpenSearchPartitionInstanceType | undefined;
    DedicatedMasterCount?: number | undefined;
    WarmEnabled?: boolean | undefined;
    WarmType?: OpenSearchWarmPartitionInstanceType | undefined;
    WarmCount?: number | undefined;
    ColdStorageOptions?: ColdStorageOptions | undefined;
    MultiAZWithStandbyEnabled?: boolean | undefined;
    NodeOptions?: NodeOption[] | undefined;
}
export type VolumeType = "standard" | "gp2" | "io1" | "gp3" | (string & {});
export interface EBSOptions {
    EBSEnabled?: boolean | undefined;
    VolumeType?: VolumeType | undefined;
    VolumeSize?: number | undefined;
    Iops?: number | undefined;
    Throughput?: number | undefined;
}
export type IPAddressType = "ipv4" | "dualstack" | (string & {});
export interface SnapshotOptions {
    AutomatedSnapshotStartHour?: number | undefined;
}
export type StringList = string[];
export interface VPCOptions {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    EgressEnabled?: boolean | undefined;
}
export type UserPoolId = string;
export type IdentityPoolId = string;
export interface CognitoOptions {
    Enabled?: boolean | undefined;
    UserPoolId?: string | undefined;
    IdentityPoolId?: string | undefined;
    RoleArn?: string | undefined;
}
export type KmsKeyId = string;
export type EncryptionMode = "DISK" | "NATIVE" | (string & {});
export interface EncryptionAtRestOptions {
    Enabled?: boolean | undefined;
    KmsKeyId?: string | undefined;
    EncryptionMode?: EncryptionMode | undefined;
}
export interface NodeToNodeEncryptionOptions {
    Enabled?: boolean | undefined;
}
export type AdvancedOptions = {
    [key: string]: string | undefined;
};
export type LogType = "INDEX_SLOW_LOGS" | "SEARCH_SLOW_LOGS" | "ES_APPLICATION_LOGS" | "AUDIT_LOGS" | (string & {});
export type CloudWatchLogsLogGroupArn = string;
export interface LogPublishingOption {
    CloudWatchLogsLogGroupArn?: string | undefined;
    Enabled?: boolean | undefined;
}
export type LogPublishingOptions = {
    [key in LogType]?: LogPublishingOption | undefined;
};
export type TLSSecurityPolicy = "Policy-Min-TLS-1-0-2019-07" | "Policy-Min-TLS-1-2-2019-07" | "Policy-Min-TLS-1-2-PFS-2023-10" | "Policy-Min-TLS-1-2-RFC9151-FIPS-2024-08" | "Policy-Min-TLS-1-2-FIPS-PQ-2026-10" | (string & {});
export type DomainNameFqdn = string;
export interface DomainEndpointOptions {
    EnforceHTTPS?: boolean | undefined;
    TLSSecurityPolicy?: TLSSecurityPolicy | undefined;
    CustomEndpointEnabled?: boolean | undefined;
    CustomEndpoint?: string | undefined;
    CustomEndpointCertificateArn?: string | undefined;
}
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export interface MasterUserOptions {
    MasterUserARN?: string | undefined;
    MasterUserName?: string | redacted.Redacted<string> | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
}
export type SAMLMetadata = string;
export type SAMLEntityId = string;
export interface SAMLIdp {
    MetadataContent: string;
    EntityId: string;
}
export type BackendRole = string;
export interface SAMLOptionsInput {
    Enabled?: boolean | undefined;
    Idp?: SAMLIdp | undefined;
    MasterUserName?: string | redacted.Redacted<string> | undefined;
    MasterBackendRole?: string | undefined;
    SubjectKey?: string | undefined;
    RolesKey?: string | undefined;
    SessionTimeoutMinutes?: number | undefined;
}
export type SubjectKey = string;
export type RolesKey = string;
export type JwksUrl = string;
export interface JWTOptionsInput {
    Enabled?: boolean | undefined;
    SubjectKey?: string | undefined;
    RolesKey?: string | undefined;
    JwksUrl?: string | undefined;
    PublicKey?: string | undefined;
}
export type IAMFederationSubjectKey = string;
export type IAMFederationRolesKey = string;
export interface IAMFederationOptionsInput {
    Enabled?: boolean | undefined;
    SubjectKey?: string | undefined;
    RolesKey?: string | undefined;
}
export interface AdvancedSecurityOptionsInput {
    Enabled?: boolean | undefined;
    InternalUserDatabaseEnabled?: boolean | undefined;
    MasterUserOptions?: MasterUserOptions | undefined;
    SAMLOptions?: SAMLOptionsInput | undefined;
    JWTOptions?: JWTOptionsInput | undefined;
    IAMFederationOptions?: IAMFederationOptionsInput | undefined;
    AnonymousAuthEnabled?: boolean | undefined;
}
export type IdentityCenterInstanceARN = string;
export type SubjectKeyIdCOption = "UserName" | "UserId" | "Email" | (string & {});
export type RolesKeyIdCOption = "GroupName" | "GroupId" | (string & {});
export interface IdentityCenterOptionsInput {
    EnabledAPIAccess?: boolean | undefined;
    IdentityCenterInstanceARN?: string | undefined;
    IdentityCenterInstanceRegion?: string | undefined;
    SubjectKey?: SubjectKeyIdCOption | undefined;
    RolesKey?: RolesKeyIdCOption | undefined;
}
export type AutoTuneDesiredState = "ENABLED" | "DISABLED" | (string & {});
export type StartAt = Date;
export type DurationValue = number;
export type TimeUnit = "HOURS" | (string & {});
export interface Duration {
    Value?: number | undefined;
    Unit?: TimeUnit | undefined;
}
export interface AutoTuneMaintenanceSchedule {
    StartAt?: Date | undefined;
    Duration?: Duration | undefined;
    CronExpressionForRecurrence?: string | undefined;
}
export type AutoTuneMaintenanceScheduleList = AutoTuneMaintenanceSchedule[];
export interface AutoTuneOptionsInput {
    DesiredState?: AutoTuneDesiredState | undefined;
    MaintenanceSchedules?: AutoTuneMaintenanceSchedule[] | undefined;
    UseOffPeakWindow?: boolean | undefined;
}
export type StartTimeHours = number;
export type StartTimeMinutes = number;
export interface WindowStartTime {
    Hours: number;
    Minutes: number;
}
export interface OffPeakWindow {
    WindowStartTime?: WindowStartTime | undefined;
}
export interface OffPeakWindowOptions {
    Enabled?: boolean | undefined;
    OffPeakWindow?: OffPeakWindow | undefined;
}
export interface SoftwareUpdateOptions {
    AutoSoftwareUpdateEnabled?: boolean | undefined;
    UseLatestServiceSoftwareForBlueGreen?: boolean | undefined;
}
export type NaturalLanguageQueryGenerationDesiredState = "ENABLED" | "DISABLED" | (string & {});
export interface NaturalLanguageQueryGenerationOptionsInput {
    DesiredState?: NaturalLanguageQueryGenerationDesiredState | undefined;
}
export interface S3VectorsEngine {
    Enabled?: boolean | undefined;
}
export interface ServerlessVectorAcceleration {
    Enabled?: boolean | undefined;
}
export interface AIMLOptionsInput {
    NaturalLanguageQueryGenerationOptions?: NaturalLanguageQueryGenerationOptionsInput | undefined;
    S3VectorsEngine?: S3VectorsEngine | undefined;
    ServerlessVectorAcceleration?: ServerlessVectorAcceleration | undefined;
}
export type DeploymentStrategy = "Default" | "CapacityOptimized" | (string & {});
export interface DeploymentStrategyOptions {
    DeploymentStrategy: DeploymentStrategy;
}
export interface AutomatedSnapshotPauseRequestOptions {
    Enabled: boolean;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type DomainUseCase = "SEARCH" | "VECTOR" | "OBSERVABILITY" | "MIXED" | (string & {});
export type EngineMode = "GENERAL" | "OPTIMIZED" | (string & {});
export interface CreateDomainRequest {
    DomainName: string;
    EngineVersion?: string | undefined;
    ClusterConfig?: ClusterConfig | undefined;
    EBSOptions?: EBSOptions | undefined;
    AccessPolicies?: string | undefined;
    IPAddressType?: IPAddressType | undefined;
    SnapshotOptions?: SnapshotOptions | undefined;
    VPCOptions?: VPCOptions | undefined;
    CognitoOptions?: CognitoOptions | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions | undefined;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    } | undefined;
    DomainEndpointOptions?: DomainEndpointOptions | undefined;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsInput | undefined;
    IdentityCenterOptions?: IdentityCenterOptionsInput | undefined;
    TagList?: Tag[] | undefined;
    AutoTuneOptions?: AutoTuneOptionsInput | undefined;
    OffPeakWindowOptions?: OffPeakWindowOptions | undefined;
    SoftwareUpdateOptions?: SoftwareUpdateOptions | undefined;
    AIMLOptions?: AIMLOptionsInput | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOptions | undefined;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseRequestOptions | undefined;
    UseCase?: DomainUseCase | undefined;
    EngineMode?: EngineMode | undefined;
}
export type DomainId = string;
export type ServiceUrl = string;
export type EndpointsMap = {
    [key: string]: string | undefined;
};
export type HostedZoneId = string;
export interface VPCDerivedInfo {
    VPCId?: string | undefined;
    SubnetIds?: string[] | undefined;
    AvailabilityZones?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    EgressEnabled?: boolean | undefined;
}
export interface SAMLOptionsOutput {
    Enabled?: boolean | undefined;
    Idp?: SAMLIdp | undefined;
    SubjectKey?: string | undefined;
    RolesKey?: string | undefined;
    SessionTimeoutMinutes?: number | undefined;
}
export interface JWTOptionsOutput {
    Enabled?: boolean | undefined;
    SubjectKey?: string | undefined;
    RolesKey?: string | undefined;
    JwksUrl?: string | undefined;
    PublicKey?: string | undefined;
}
export interface IAMFederationOptionsOutput {
    Enabled?: boolean | undefined;
    SubjectKey?: string | undefined;
    RolesKey?: string | undefined;
}
export type DisableTimestamp = Date;
export interface AdvancedSecurityOptions {
    Enabled?: boolean | undefined;
    InternalUserDatabaseEnabled?: boolean | undefined;
    SAMLOptions?: SAMLOptionsOutput | undefined;
    JWTOptions?: JWTOptionsOutput | undefined;
    IAMFederationOptions?: IAMFederationOptionsOutput | undefined;
    AnonymousAuthDisableDate?: Date | undefined;
    AnonymousAuthEnabled?: boolean | undefined;
}
export type IdentityCenterApplicationARN = string;
export type IdentityStoreId = string;
export interface IdentityCenterOptions {
    EnabledAPIAccess?: boolean | undefined;
    IdentityCenterInstanceARN?: string | undefined;
    IdentityCenterInstanceRegion?: string | undefined;
    SubjectKey?: SubjectKeyIdCOption | undefined;
    RolesKey?: RolesKeyIdCOption | undefined;
    IdentityCenterApplicationARN?: string | undefined;
    IdentityStoreId?: string | undefined;
}
export type AutoTuneState = "ENABLED" | "DISABLED" | "ENABLE_IN_PROGRESS" | "DISABLE_IN_PROGRESS" | "DISABLED_AND_ROLLBACK_SCHEDULED" | "DISABLED_AND_ROLLBACK_IN_PROGRESS" | "DISABLED_AND_ROLLBACK_COMPLETE" | "DISABLED_AND_ROLLBACK_ERROR" | "ERROR" | (string & {});
export interface AutoTuneOptionsOutput {
    State?: AutoTuneState | undefined;
    ErrorMessage?: string | undefined;
    UseOffPeakWindow?: boolean | undefined;
}
export type Message = string;
export type ConfigChangeStatus = "Pending" | "Initializing" | "Validating" | "ValidationFailed" | "ApplyingChanges" | "Completed" | "PendingUserInput" | "Cancelled" | (string & {});
export type InitiatedBy = "CUSTOMER" | "SERVICE" | (string & {});
export type UpdateTimestamp = Date;
export interface ChangeProgressDetails {
    ChangeId?: string | undefined;
    Message?: string | undefined;
    ConfigChangeStatus?: ConfigChangeStatus | undefined;
    InitiatedBy?: InitiatedBy | undefined;
    StartTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type DomainProcessingStatusType = "Creating" | "Active" | "Modifying" | "UpgradingEngineVersion" | "UpdatingServiceSoftware" | "Isolated" | "Deleting" | (string & {});
export type PropertyValueType = "PLAIN_TEXT" | "STRINGIFIED_JSON" | (string & {});
export interface ModifyingProperties {
    Name?: string | undefined;
    ActiveValue?: string | undefined;
    PendingValue?: string | undefined;
    ValueType?: PropertyValueType | undefined;
}
export type ModifyingPropertiesList = ModifyingProperties[];
export type NaturalLanguageQueryGenerationCurrentState = "NOT_ENABLED" | "ENABLE_COMPLETE" | "ENABLE_IN_PROGRESS" | "ENABLE_FAILED" | "DISABLE_COMPLETE" | "DISABLE_IN_PROGRESS" | "DISABLE_FAILED" | (string & {});
export interface NaturalLanguageQueryGenerationOptionsOutput {
    DesiredState?: NaturalLanguageQueryGenerationDesiredState | undefined;
    CurrentState?: NaturalLanguageQueryGenerationCurrentState | undefined;
}
export interface AIMLOptionsOutput {
    NaturalLanguageQueryGenerationOptions?: NaturalLanguageQueryGenerationOptionsOutput | undefined;
    S3VectorsEngine?: S3VectorsEngine | undefined;
    ServerlessVectorAcceleration?: ServerlessVectorAcceleration | undefined;
}
export type PauseState = "Active" | "Completed" | "Scheduled" | "Disabled" | (string & {});
export interface AutomatedSnapshotPauseOptions {
    Enabled: boolean;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    State?: PauseState | undefined;
}
export interface DomainStatus {
    DomainId: string;
    DomainName: string;
    ARN: string;
    Created?: boolean | undefined;
    Deleted?: boolean | undefined;
    Endpoint?: string | undefined;
    EndpointV2?: string | undefined;
    Endpoints?: {
        [key: string]: string | undefined;
    } | undefined;
    DomainEndpointV2HostedZoneId?: string | undefined;
    Processing?: boolean | undefined;
    UpgradeProcessing?: boolean | undefined;
    EngineVersion?: string | undefined;
    ClusterConfig: ClusterConfig;
    EBSOptions?: EBSOptions | undefined;
    AccessPolicies?: string | undefined;
    IPAddressType?: IPAddressType | undefined;
    SnapshotOptions?: SnapshotOptions | undefined;
    VPCOptions?: VPCDerivedInfo | undefined;
    CognitoOptions?: CognitoOptions | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions | undefined;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    } | undefined;
    ServiceSoftwareOptions?: ServiceSoftwareOptions | undefined;
    DomainEndpointOptions?: DomainEndpointOptions | undefined;
    AdvancedSecurityOptions?: AdvancedSecurityOptions | undefined;
    IdentityCenterOptions?: IdentityCenterOptions | undefined;
    AutoTuneOptions?: AutoTuneOptionsOutput | undefined;
    ChangeProgressDetails?: ChangeProgressDetails | undefined;
    OffPeakWindowOptions?: OffPeakWindowOptions | undefined;
    SoftwareUpdateOptions?: SoftwareUpdateOptions | undefined;
    DomainProcessingStatus?: DomainProcessingStatusType | undefined;
    ModifyingProperties?: ModifyingProperties[] | undefined;
    AIMLOptions?: AIMLOptionsOutput | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOptions | undefined;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseOptions | undefined;
    UseCase?: DomainUseCase | undefined;
    EngineMode?: EngineMode | undefined;
}
export interface CreateDomainResponse {
    DomainStatus?: DomainStatus | undefined;
}
export type IndexName = string;
export type IndexSchema = unknown;
export interface CreateIndexRequest {
    DomainName: string;
    IndexName: string;
    IndexSchema: any;
}
export type IndexStatus = "CREATED" | "UPDATED" | "DELETED" | (string & {});
export interface CreateIndexResponse {
    Status: IndexStatus;
}
export type ConnectionAlias = string;
export type Endpoint = string;
export type SkipUnavailableStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CrossClusterSearchConnectionProperties {
    SkipUnavailable?: SkipUnavailableStatus | undefined;
}
export interface ConnectionProperties {
    Endpoint?: string | undefined;
    CrossClusterSearch?: CrossClusterSearchConnectionProperties | undefined;
}
export interface CreateOutboundConnectionRequest {
    LocalDomainInfo: DomainInformationContainer;
    RemoteDomainInfo: DomainInformationContainer;
    ConnectionAlias: string;
    ConnectionMode?: ConnectionMode | undefined;
    ConnectionProperties?: ConnectionProperties | undefined;
}
export type OutboundConnectionStatusCode = "VALIDATING" | "VALIDATION_FAILED" | "PENDING_ACCEPTANCE" | "APPROVED" | "PROVISIONING" | "ACTIVE" | "REJECTING" | "REJECTED" | "DELETING" | "DELETED" | (string & {});
export interface OutboundConnectionStatus {
    StatusCode?: OutboundConnectionStatusCode | undefined;
    Message?: string | undefined;
}
export interface CreateOutboundConnectionResponse {
    LocalDomainInfo?: DomainInformationContainer | undefined;
    RemoteDomainInfo?: DomainInformationContainer | undefined;
    ConnectionAlias?: string | undefined;
    ConnectionStatus?: OutboundConnectionStatus | undefined;
    ConnectionId?: string | undefined;
    ConnectionMode?: ConnectionMode | undefined;
    ConnectionProperties?: ConnectionProperties | undefined;
}
export type PackageDescription = string;
export type S3BucketName = string;
export type S3Key = string;
export interface PackageSource {
    S3BucketName?: string | undefined;
    S3Key?: string | undefined;
}
export type RequirementLevel = "REQUIRED" | "OPTIONAL" | "NONE" | (string & {});
export type LicenseFilepath = string;
export interface PackageConfiguration {
    LicenseRequirement: RequirementLevel;
    LicenseFilepath?: string | undefined;
    ConfigurationRequirement: RequirementLevel;
    RequiresRestartForConfigurationUpdate?: boolean | undefined;
}
export type EngineVersion = string;
export interface PackageVendingOptions {
    VendingEnabled: boolean;
}
export interface PackageEncryptionOptions {
    KmsKeyIdentifier?: string | undefined;
    EncryptionEnabled: boolean;
}
export interface CreatePackageRequest {
    PackageName: string;
    PackageType: PackageType;
    PackageDescription?: string | undefined;
    PackageSource: PackageSource;
    PackageConfiguration?: PackageConfiguration | undefined;
    EngineVersion?: string | undefined;
    PackageVendingOptions?: PackageVendingOptions | undefined;
    PackageEncryptionOptions?: PackageEncryptionOptions | undefined;
}
export type PackageStatus = "COPYING" | "COPY_FAILED" | "VALIDATING" | "VALIDATION_FAILED" | "AVAILABLE" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export type CreatedAt = Date;
export type PluginName = string;
export type PluginDescription = string;
export type PluginVersion = string;
export type PluginClassName = string;
export type UncompressedPluginSizeInBytes = number;
export interface PluginProperties {
    Name?: string | undefined;
    Description?: string | undefined;
    Version?: string | undefined;
    ClassName?: string | undefined;
    UncompressedSizeInBytes?: number | undefined;
}
export type PackageUser = string;
export type PackageUserList = string[];
export type PackageOwner = string;
export interface PackageDetails {
    PackageID?: string | undefined;
    PackageName?: string | undefined;
    PackageType?: PackageType | undefined;
    PackageDescription?: string | undefined;
    PackageStatus?: PackageStatus | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    AvailablePackageVersion?: string | undefined;
    ErrorDetails?: ErrorDetails | undefined;
    EngineVersion?: string | undefined;
    AvailablePluginProperties?: PluginProperties | undefined;
    AvailablePackageConfiguration?: PackageConfiguration | undefined;
    AllowListedUserList?: string[] | undefined;
    PackageOwner?: string | undefined;
    PackageVendingOptions?: PackageVendingOptions | undefined;
    PackageEncryptionOptions?: PackageEncryptionOptions | undefined;
}
export interface CreatePackageResponse {
    PackageDetails?: PackageDetails | undefined;
}
export interface CreateVpcEndpointRequest {
    DomainArn: string;
    VpcOptions: VPCOptions;
    ClientToken?: string | undefined;
}
export type VpcEndpointId = string;
export type VpcEndpointStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface VpcEndpoint {
    VpcEndpointId?: string | undefined;
    VpcEndpointOwner?: string | undefined;
    DomainArn?: string | undefined;
    VpcOptions?: VPCDerivedInfo | undefined;
    Status?: VpcEndpointStatus | undefined;
    Endpoint?: string | undefined;
}
export interface CreateVpcEndpointResponse {
    VpcEndpoint: VpcEndpoint;
}
export interface DeleteApplicationRequest {
    id: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteDataSourceRequest {
    DomainName: string;
    Name: string;
}
export interface DeleteDataSourceResponse {
    Message?: string | undefined;
}
export interface DeleteDirectQueryDataSourceRequest {
    DataSourceName: string;
}
export interface DeleteDirectQueryDataSourceResponse {
}
export interface DeleteDomainRequest {
    DomainName: string;
}
export interface DeleteDomainResponse {
    DomainStatus?: DomainStatus | undefined;
}
export interface DeleteInboundConnectionRequest {
    ConnectionId: string;
}
export interface DeleteInboundConnectionResponse {
    Connection?: InboundConnection | undefined;
}
export interface DeleteIndexRequest {
    DomainName: string;
    IndexName: string;
}
export interface DeleteIndexResponse {
    Status: IndexStatus;
}
export interface DeleteOutboundConnectionRequest {
    ConnectionId: string;
}
export interface OutboundConnection {
    LocalDomainInfo?: DomainInformationContainer | undefined;
    RemoteDomainInfo?: DomainInformationContainer | undefined;
    ConnectionId?: string | undefined;
    ConnectionAlias?: string | undefined;
    ConnectionStatus?: OutboundConnectionStatus | undefined;
    ConnectionMode?: ConnectionMode | undefined;
    ConnectionProperties?: ConnectionProperties | undefined;
}
export interface DeleteOutboundConnectionResponse {
    Connection?: OutboundConnection | undefined;
}
export interface DeletePackageRequest {
    PackageID: string;
}
export interface DeletePackageResponse {
    PackageDetails?: PackageDetails | undefined;
}
export interface DeleteVpcEndpointRequest {
    VpcEndpointId: string;
}
export interface VpcEndpointSummary {
    VpcEndpointId?: string | undefined;
    VpcEndpointOwner?: string | undefined;
    DomainArn?: string | undefined;
    Status?: VpcEndpointStatus | undefined;
}
export interface DeleteVpcEndpointResponse {
    VpcEndpointSummary: VpcEndpointSummary;
}
export type ApplicationId = string;
export type CapabilityName = string;
export interface DeregisterCapabilityRequest {
    applicationId: string;
    capabilityName: string;
}
export type CapabilityStatus = "creating" | "create_failed" | "active" | "updating" | "update_failed" | "deleting" | "delete_failed" | (string & {});
export interface DeregisterCapabilityResponse {
    status?: CapabilityStatus | undefined;
}
export interface DescribeDataSourceAttachmentRequest {
    id: string;
    dataSourceArn: string;
}
export interface DescribeDataSourceAttachmentResponse {
    attachmentId?: string | undefined;
    id?: string | undefined;
    arn?: string | undefined;
    dataSourceArn?: string | undefined;
    status?: DataSourceAttachmentStatus | undefined;
}
export interface DescribeDomainRequest {
    DomainName: string;
}
export interface DescribeDomainResponse {
    DomainStatus: DomainStatus;
}
export type MaxResults = number;
export type NextToken = string;
export interface DescribeDomainAutoTunesRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AutoTuneType = "SCHEDULED_ACTION" | (string & {});
export type AutoTuneDate = Date;
export type ScheduledAutoTuneActionType = "JVM_HEAP_SIZE_TUNING" | "JVM_YOUNG_GEN_TUNING" | (string & {});
export type ScheduledAutoTuneDescription = string;
export type ScheduledAutoTuneSeverityType = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export interface ScheduledAutoTuneDetails {
    Date?: Date | undefined;
    ActionType?: ScheduledAutoTuneActionType | undefined;
    Action?: string | undefined;
    Severity?: ScheduledAutoTuneSeverityType | undefined;
}
export interface AutoTuneDetails {
    ScheduledAutoTuneDetails?: ScheduledAutoTuneDetails | undefined;
}
export interface AutoTune {
    AutoTuneType?: AutoTuneType | undefined;
    AutoTuneDetails?: AutoTuneDetails | undefined;
}
export type AutoTuneList = AutoTune[];
export interface DescribeDomainAutoTunesResponse {
    AutoTunes?: AutoTune[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeDomainChangeProgressRequest {
    DomainName: string;
    ChangeId?: string | undefined;
}
export type OverallChangeStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED" | (string & {});
export type TotalNumberOfStages = number;
export type ChangeProgressStageName = string;
export type ChangeProgressStageStatus = string;
export type Description = string;
export interface ChangeProgressStage {
    Name?: string | undefined;
    Status?: string | undefined;
    Description?: string | undefined;
    LastUpdated?: Date | undefined;
}
export type ChangeProgressStageList = ChangeProgressStage[];
export type TrafficPercent = number;
export interface TrafficPercents {
    PrimaryReadTrafficPercent: number;
    CloneReadTrafficPercent: number;
}
export type ClonedBlueGreenScheduledActionType = "AutomaticCutoverToPrimaryCluster" | "DeletePrimaryCluster" | (string & {});
export interface ClonedBlueGreenScheduledAction {
    Action?: ClonedBlueGreenScheduledActionType | undefined;
    ScheduledTime?: Date | undefined;
}
export interface ClonedBlueGreenUpgradeDetails {
    TrafficSplit?: TrafficPercents | undefined;
    ScheduledAction?: ClonedBlueGreenScheduledAction | undefined;
    RetentionInHours?: number | undefined;
}
export type ValidationFailureSeverity = "Critical" | "Warning" | (string & {});
export interface ValidationFailure {
    Code?: string | undefined;
    Message?: string | undefined;
    Severity?: ValidationFailureSeverity | undefined;
}
export type ValidationFailures = ValidationFailure[];
export type AcceptedWarningsList = string[];
export interface ChangeProgressStatusDetails {
    ChangeId?: string | undefined;
    StartTime?: Date | undefined;
    Status?: OverallChangeStatus | undefined;
    PendingProperties?: string[] | undefined;
    CompletedProperties?: string[] | undefined;
    TotalNumberOfStages?: number | undefined;
    ChangeProgressStages?: ChangeProgressStage[] | undefined;
    LastUpdatedTime?: Date | undefined;
    ConfigChangeStatus?: ConfigChangeStatus | undefined;
    InitiatedBy?: InitiatedBy | undefined;
    ClonedBlueGreenUpgradeDetails?: ClonedBlueGreenUpgradeDetails | undefined;
    ValidationFailures?: ValidationFailure[] | undefined;
    AcceptedWarnings?: string[] | undefined;
}
export interface DescribeDomainChangeProgressResponse {
    ChangeProgressStatus?: ChangeProgressStatusDetails | undefined;
}
export interface DescribeDomainConfigRequest {
    DomainName: string;
}
export type UIntValue = number;
export type OptionState = "RequiresIndexDocuments" | "Processing" | "Active" | (string & {});
export interface OptionStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number | undefined;
    State: OptionState;
    PendingDeletion?: boolean | undefined;
}
export interface VersionStatus {
    Options: string;
    Status: OptionStatus;
}
export interface ClusterConfigStatus {
    Options: ClusterConfig;
    Status: OptionStatus;
}
export interface EBSOptionsStatus {
    Options: EBSOptions;
    Status: OptionStatus;
}
export interface AccessPoliciesStatus {
    Options: string;
    Status: OptionStatus;
}
export interface IPAddressTypeStatus {
    Options: IPAddressType;
    Status: OptionStatus;
}
export interface SnapshotOptionsStatus {
    Options: SnapshotOptions;
    Status: OptionStatus;
}
export interface VPCDerivedInfoStatus {
    Options: VPCDerivedInfo;
    Status: OptionStatus;
}
export interface CognitoOptionsStatus {
    Options: CognitoOptions;
    Status: OptionStatus;
}
export interface EncryptionAtRestOptionsStatus {
    Options: EncryptionAtRestOptions;
    Status: OptionStatus;
}
export interface NodeToNodeEncryptionOptionsStatus {
    Options: NodeToNodeEncryptionOptions;
    Status: OptionStatus;
}
export interface AdvancedOptionsStatus {
    Options: {
        [key: string]: string | undefined;
    };
    Status: OptionStatus;
}
export interface LogPublishingOptionsStatus {
    Options?: {
        [key: string]: LogPublishingOption | undefined;
    } | undefined;
    Status?: OptionStatus | undefined;
}
export interface DomainEndpointOptionsStatus {
    Options: DomainEndpointOptions;
    Status: OptionStatus;
}
export interface AdvancedSecurityOptionsStatus {
    Options: AdvancedSecurityOptions;
    Status: OptionStatus;
}
export interface IdentityCenterOptionsStatus {
    Options: IdentityCenterOptions;
    Status: OptionStatus;
}
export type RollbackOnDisable = "NO_ROLLBACK" | "DEFAULT_ROLLBACK" | (string & {});
export interface AutoTuneOptions {
    DesiredState?: AutoTuneDesiredState | undefined;
    RollbackOnDisable?: RollbackOnDisable | undefined;
    MaintenanceSchedules?: AutoTuneMaintenanceSchedule[] | undefined;
    UseOffPeakWindow?: boolean | undefined;
}
export interface AutoTuneStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number | undefined;
    State: AutoTuneState;
    ErrorMessage?: string | undefined;
    PendingDeletion?: boolean | undefined;
}
export interface AutoTuneOptionsStatus {
    Options?: AutoTuneOptions | undefined;
    Status?: AutoTuneStatus | undefined;
}
export interface OffPeakWindowOptionsStatus {
    Options?: OffPeakWindowOptions | undefined;
    Status?: OptionStatus | undefined;
}
export interface SoftwareUpdateOptionsStatus {
    Options?: SoftwareUpdateOptions | undefined;
    Status?: OptionStatus | undefined;
}
export interface AIMLOptionsStatus {
    Options?: AIMLOptionsOutput | undefined;
    Status?: OptionStatus | undefined;
}
export interface DeploymentStrategyOptionsStatus {
    Options: DeploymentStrategyOptions;
    Status: OptionStatus;
}
export interface AutomatedSnapshotPauseOptionsStatus {
    Options: AutomatedSnapshotPauseOptions;
    Status: OptionStatus;
}
export interface UseCaseStatus {
    Options: DomainUseCase;
    Status: OptionStatus;
}
export interface EngineModeStatus {
    Options: EngineMode;
    Status: OptionStatus;
}
export interface DomainConfig {
    EngineVersion?: VersionStatus | undefined;
    ClusterConfig?: ClusterConfigStatus | undefined;
    EBSOptions?: EBSOptionsStatus | undefined;
    AccessPolicies?: AccessPoliciesStatus | undefined;
    IPAddressType?: IPAddressTypeStatus | undefined;
    SnapshotOptions?: SnapshotOptionsStatus | undefined;
    VPCOptions?: VPCDerivedInfoStatus | undefined;
    CognitoOptions?: CognitoOptionsStatus | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptionsStatus | undefined;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptionsStatus | undefined;
    AdvancedOptions?: AdvancedOptionsStatus | undefined;
    LogPublishingOptions?: LogPublishingOptionsStatus | undefined;
    DomainEndpointOptions?: DomainEndpointOptionsStatus | undefined;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsStatus | undefined;
    IdentityCenterOptions?: IdentityCenterOptionsStatus | undefined;
    AutoTuneOptions?: AutoTuneOptionsStatus | undefined;
    ChangeProgressDetails?: ChangeProgressDetails | undefined;
    OffPeakWindowOptions?: OffPeakWindowOptionsStatus | undefined;
    SoftwareUpdateOptions?: SoftwareUpdateOptionsStatus | undefined;
    ModifyingProperties?: ModifyingProperties[] | undefined;
    AIMLOptions?: AIMLOptionsStatus | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOptionsStatus | undefined;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseOptionsStatus | undefined;
    UseCase?: UseCaseStatus | undefined;
    EngineMode?: EngineModeStatus | undefined;
}
export interface DescribeDomainConfigResponse {
    DomainConfig: DomainConfig;
}
export interface DescribeDomainHealthRequest {
    DomainName: string;
}
export type DomainState = "Active" | "Processing" | "NotAvailable" | (string & {});
export type NumberOfAZs = string;
export type NumberOfNodes = string;
export type MasterNodeStatus = "Available" | "UnAvailable" | (string & {});
export type DomainHealth = "Red" | "Yellow" | "Green" | "NotAvailable" | (string & {});
export type NumberOfShards = string;
export type AvailabilityZone = string;
export type ZoneStatus = "Active" | "StandBy" | "NotAvailable" | (string & {});
export interface AvailabilityZoneInfo {
    AvailabilityZoneName?: string | undefined;
    ZoneStatus?: ZoneStatus | undefined;
    ConfiguredDataNodeCount?: string | undefined;
    AvailableDataNodeCount?: string | undefined;
    TotalShards?: string | undefined;
    TotalUnAssignedShards?: string | undefined;
}
export type AvailabilityZoneInfoList = AvailabilityZoneInfo[];
export interface EnvironmentInfo {
    AvailabilityZoneInformation?: AvailabilityZoneInfo[] | undefined;
}
export type EnvironmentInfoList = EnvironmentInfo[];
export interface DescribeDomainHealthResponse {
    DomainState?: DomainState | undefined;
    AvailabilityZoneCount?: string | undefined;
    ActiveAvailabilityZoneCount?: string | undefined;
    StandByAvailabilityZoneCount?: string | undefined;
    DataNodeCount?: string | undefined;
    DedicatedMaster?: boolean | undefined;
    MasterEligibleNodeCount?: string | undefined;
    WarmNodeCount?: string | undefined;
    MasterNode?: MasterNodeStatus | undefined;
    ClusterHealth?: DomainHealth | undefined;
    TotalShards?: string | undefined;
    TotalUnAssignedShards?: string | undefined;
    EnvironmentInformation?: EnvironmentInfo[] | undefined;
}
export interface DescribeDomainNodesRequest {
    DomainName: string;
}
export type NodeId = string;
export type NodeType = "Data" | "Ultrawarm" | "Master" | "Warm" | (string & {});
export type NodeStatus = "Active" | "StandBy" | "NotAvailable" | (string & {});
export type StorageTypeName = string;
export type VolumeSize = string;
export interface DomainNodesStatus {
    NodeId?: string | undefined;
    NodeType?: NodeType | undefined;
    AvailabilityZone?: string | undefined;
    InstanceType?: OpenSearchPartitionInstanceType | undefined;
    NodeStatus?: NodeStatus | undefined;
    StorageType?: string | undefined;
    StorageVolumeType?: VolumeType | undefined;
    StorageSize?: string | undefined;
}
export type DomainNodesStatusList = DomainNodesStatus[];
export interface DescribeDomainNodesResponse {
    DomainNodesStatusList?: DomainNodesStatus[] | undefined;
}
export interface DescribeDomainReplicationRequest {
    DomainName: string;
}
export type ReplicationRole = "PRIMARY" | "SECONDARY" | (string & {});
export type ReplicationStatusMessage = string;
export interface ReplicationPeer {
    PeerDomainArn?: string | undefined;
    PeerRole?: ReplicationRole | undefined;
    Status?: ReplicationStatus | undefined;
    StatusMessage?: string | undefined;
}
export type ReplicationPeerList = ReplicationPeer[];
export interface DescribeDomainReplicationResponse {
    DomainArn?: string | undefined;
    Role?: ReplicationRole | undefined;
    Peers?: ReplicationPeer[] | undefined;
}
export type DomainNameList = string[];
export interface DescribeDomainsRequest {
    DomainNames: string[];
}
export type DomainStatusList = DomainStatus[];
export interface DescribeDomainsResponse {
    DomainStatusList: DomainStatus[];
}
export interface DescribeDryRunProgressRequest {
    DomainName: string;
    DryRunId?: string | undefined;
    LoadDryRunConfig?: boolean | undefined;
}
export interface DryRunProgressStatus {
    DryRunId: string;
    DryRunStatus: string;
    CreationDate: string;
    UpdateDate: string;
    ValidationFailures?: ValidationFailure[] | undefined;
    AcceptedWarnings?: string[] | undefined;
}
export type DeploymentType = string;
export interface DryRunResults {
    DeploymentType?: string | undefined;
    Message?: string | undefined;
}
export interface DescribeDryRunProgressResponse {
    DryRunProgressStatus?: DryRunProgressStatus | undefined;
    DryRunConfig?: DomainStatus | undefined;
    DryRunResults?: DryRunResults | undefined;
}
export type NonEmptyString = string;
export type ValueStringList = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type FilterList = Filter[];
export interface DescribeInboundConnectionsRequest {
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InboundConnections = InboundConnection[];
export interface DescribeInboundConnectionsResponse {
    Connections?: InboundConnection[] | undefined;
    NextToken?: string | undefined;
}
export type InsightEntityType = "Account" | "DomainName" | (string & {});
export type InsightEntityValue = string;
export interface InsightEntity {
    Type: InsightEntityType;
    Value?: string | undefined;
}
export interface DescribeInsightDetailsRequest {
    Entity: InsightEntity;
    InsightId: string;
    ShowHtmlContent?: boolean | undefined;
}
export type InsightFieldType = "text" | "metric" | (string & {});
export interface InsightField {
    Name: string;
    Type: InsightFieldType;
    Value: string;
}
export type InsightFieldList = InsightField[];
export interface DescribeInsightDetailsResponse {
    Fields: InsightField[];
}
export interface DescribeInstanceTypeLimitsRequest {
    DomainName?: string | undefined;
    InstanceType: OpenSearchPartitionInstanceType;
    EngineVersion: string;
}
export type InstanceRole = string;
export type StorageSubTypeName = string;
export type LimitName = string;
export type LimitValue = string;
export type LimitValueList = string[];
export interface StorageTypeLimit {
    LimitName?: string | undefined;
    LimitValues?: string[] | undefined;
}
export type StorageTypeLimitList = StorageTypeLimit[];
export interface StorageType {
    StorageTypeName?: string | undefined;
    StorageSubTypeName?: string | undefined;
    StorageTypeLimits?: StorageTypeLimit[] | undefined;
}
export type StorageTypeList = StorageType[];
export type MinimumInstanceCount = number;
export type MaximumInstanceCount = number;
export interface InstanceCountLimits {
    MinimumInstanceCount?: number | undefined;
    MaximumInstanceCount?: number | undefined;
}
export interface InstanceLimits {
    InstanceCountLimits?: InstanceCountLimits | undefined;
}
export interface AdditionalLimit {
    LimitName?: string | undefined;
    LimitValues?: string[] | undefined;
}
export type AdditionalLimitList = AdditionalLimit[];
export interface Limits {
    StorageTypes?: StorageType[] | undefined;
    InstanceLimits?: InstanceLimits | undefined;
    AdditionalLimits?: AdditionalLimit[] | undefined;
}
export type LimitsByRole = {
    [key: string]: Limits | undefined;
};
export interface DescribeInstanceTypeLimitsResponse {
    LimitsByRole?: {
        [key: string]: Limits | undefined;
    } | undefined;
}
export interface DescribeOutboundConnectionsRequest {
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type OutboundConnections = OutboundConnection[];
export interface DescribeOutboundConnectionsResponse {
    Connections?: OutboundConnection[] | undefined;
    NextToken?: string | undefined;
}
export type DescribePackagesFilterName = "PackageID" | "PackageName" | "PackageStatus" | "PackageType" | "EngineVersion" | "PackageOwner" | (string & {});
export type DescribePackagesFilterValue = string;
export type DescribePackagesFilterValues = string[];
export interface DescribePackagesFilter {
    Name?: DescribePackagesFilterName | undefined;
    Value?: string[] | undefined;
}
export type DescribePackagesFilterList = DescribePackagesFilter[];
export interface DescribePackagesRequest {
    Filters?: DescribePackagesFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PackageDetailsList = PackageDetails[];
export interface DescribePackagesResponse {
    PackageDetailsList?: PackageDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeReservedInstanceOfferingsRequest {
    ReservedInstanceOfferingId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ReservedInstancePaymentOption = "ALL_UPFRONT" | "PARTIAL_UPFRONT" | "NO_UPFRONT" | (string & {});
export interface RecurringCharge {
    RecurringChargeAmount?: number | undefined;
    RecurringChargeFrequency?: string | undefined;
}
export type RecurringChargeList = RecurringCharge[];
export interface ReservedInstanceOffering {
    ReservedInstanceOfferingId?: string | undefined;
    InstanceType?: OpenSearchPartitionInstanceType | undefined;
    Duration?: number | undefined;
    FixedPrice?: number | undefined;
    UsagePrice?: number | undefined;
    CurrencyCode?: string | undefined;
    PaymentOption?: ReservedInstancePaymentOption | undefined;
    RecurringCharges?: RecurringCharge[] | undefined;
}
export type ReservedInstanceOfferingList = ReservedInstanceOffering[];
export interface DescribeReservedInstanceOfferingsResponse {
    NextToken?: string | undefined;
    ReservedInstanceOfferings?: ReservedInstanceOffering[] | undefined;
}
export interface DescribeReservedInstancesRequest {
    ReservedInstanceId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ReservationToken = string;
export interface ReservedInstance {
    ReservationName?: string | undefined;
    ReservedInstanceId?: string | undefined;
    BillingSubscriptionId?: number | undefined;
    ReservedInstanceOfferingId?: string | undefined;
    InstanceType?: OpenSearchPartitionInstanceType | undefined;
    StartTime?: Date | undefined;
    Duration?: number | undefined;
    FixedPrice?: number | undefined;
    UsagePrice?: number | undefined;
    CurrencyCode?: string | undefined;
    InstanceCount?: number | undefined;
    State?: string | undefined;
    PaymentOption?: ReservedInstancePaymentOption | undefined;
    RecurringCharges?: RecurringCharge[] | undefined;
}
export type ReservedInstanceList = ReservedInstance[];
export interface DescribeReservedInstancesResponse {
    NextToken?: string | undefined;
    ReservedInstances?: ReservedInstance[] | undefined;
}
export type VpcEndpointIdList = string[];
export interface DescribeVpcEndpointsRequest {
    VpcEndpointIds: string[];
}
export type VpcEndpoints = VpcEndpoint[];
export type VpcEndpointErrorCode = "ENDPOINT_NOT_FOUND" | "SERVER_ERROR" | (string & {});
export interface VpcEndpointError {
    VpcEndpointId?: string | undefined;
    ErrorCode?: VpcEndpointErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type VpcEndpointErrorList = VpcEndpointError[];
export interface DescribeVpcEndpointsResponse {
    VpcEndpoints: VpcEndpoint[];
    VpcEndpointErrors: VpcEndpointError[];
}
export interface DetachDataSourceRequest {
    id: string;
    dataSourceArn: string;
}
export interface DetachDataSourceResponse {
    id?: string | undefined;
    arn?: string | undefined;
    dataSourceArn?: string | undefined;
}
export interface DissociatePackageRequest {
    PackageID: string;
    DomainName: string;
}
export interface DissociatePackageResponse {
    DomainPackageDetails?: DomainPackageDetails | undefined;
}
export interface DissociatePackagesRequest {
    PackageList: string[];
    DomainName: string;
}
export interface DissociatePackagesResponse {
    DomainPackageDetailsList?: DomainPackageDetails[] | undefined;
}
export interface FailoverReplicationRequest {
    DomainName: string;
    PeerDomainArn: string;
    AllowDataLoss: boolean;
}
export interface FailoverReplicationResponse {
    DomainArn?: string | undefined;
    Status?: ReplicationStatus | undefined;
}
export interface GetApplicationRequest {
    id: string;
}
export type ApplicationStatus = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | "FAILED" | (string & {});
export interface GetApplicationResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    endpoint?: string | undefined;
    status?: ApplicationStatus | undefined;
    iamIdentityCenterOptions?: IamIdentityCenterOptions | undefined;
    dataSources?: DataSource[] | undefined;
    appConfigs?: AppConfig[] | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    kmsKeyArn?: string | undefined;
}
export interface GetCapabilityRequest {
    applicationId: string;
    capabilityName: string;
}
export interface AIConfig {
}
export type CapabilityExtendedResponseConfig = {
    aiConfig: AIConfig;
};
export type CapabilityFailureReason = "KMS_KEY_INSUFFICIENT_PERMISSION" | (string & {});
export type CapabilityFailureDetails = string;
export interface CapabilityFailure {
    reason?: CapabilityFailureReason | undefined;
    details?: string | undefined;
}
export type CapabilityFailures = CapabilityFailure[];
export interface GetCapabilityResponse {
    capabilityName?: string | undefined;
    applicationId?: string | undefined;
    status?: CapabilityStatus | undefined;
    capabilityConfig?: CapabilityExtendedResponseConfig | undefined;
    failures?: CapabilityFailure[] | undefined;
}
export interface GetCompatibleVersionsRequest {
    DomainName?: string | undefined;
}
export type VersionList = string[];
export interface CompatibleVersionsMap {
    SourceVersion?: string | undefined;
    TargetVersions?: string[] | undefined;
}
export type CompatibleVersionsList = CompatibleVersionsMap[];
export interface GetCompatibleVersionsResponse {
    CompatibleVersions?: CompatibleVersionsMap[] | undefined;
}
export interface GetDataSourceRequest {
    DomainName: string;
    Name: string;
}
export type DataSourceStatus = "ACTIVE" | "DISABLED" | (string & {});
export interface GetDataSourceResponse {
    DataSourceType?: DataSourceType | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Status?: DataSourceStatus | undefined;
}
export interface GetDefaultApplicationSettingRequest {
}
export interface GetDefaultApplicationSettingResponse {
    applicationArn?: string | undefined;
}
export interface GetDirectQueryDataSourceRequest {
    DataSourceName: string;
}
export interface GetDirectQueryDataSourceResponse {
    DataSourceName?: string | undefined;
    DataSourceType?: DirectQueryDataSourceType | undefined;
    Description?: string | undefined;
    OpenSearchArns?: string[] | undefined;
    DataSourceAccessPolicy?: string | undefined;
    DataSourceArn?: string | undefined;
}
export type RequestId = string;
export interface GetDomainMaintenanceStatusRequest {
    DomainName: string;
    MaintenanceId: string;
}
export type MaintenanceStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "TIMED_OUT" | (string & {});
export type MaintenanceStatusMessage = string;
export type MaintenanceType = "REBOOT_NODE" | "RESTART_SEARCH_PROCESS" | "RESTART_DASHBOARD" | (string & {});
export interface GetDomainMaintenanceStatusResponse {
    Status?: MaintenanceStatus | undefined;
    StatusMessage?: string | undefined;
    NodeId?: string | undefined;
    Action?: MaintenanceType | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetIndexRequest {
    DomainName: string;
    IndexName: string;
}
export interface GetIndexResponse {
    IndexSchema: any;
}
export interface GetMigrationRequest {
    migrationId: string;
}
export interface MigrationSource {
    datasourceArn: string;
}
export interface MigrationError {
    code?: string | undefined;
    message?: string | undefined;
}
export interface GetMigrationResponse {
    migrationId?: string | undefined;
    status?: string | undefined;
    applicationId?: string | undefined;
    source?: MigrationSource | undefined;
    exportedCount?: number | undefined;
    importedCount?: number | undefined;
    error?: MigrationError | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetPackageVersionHistoryRequest {
    PackageID: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type CommitMessage = string;
export interface PackageVersionHistory {
    PackageVersion?: string | undefined;
    CommitMessage?: string | undefined;
    CreatedAt?: Date | undefined;
    PluginProperties?: PluginProperties | undefined;
    PackageConfiguration?: PackageConfiguration | undefined;
}
export type PackageVersionHistoryList = PackageVersionHistory[];
export interface GetPackageVersionHistoryResponse {
    PackageID?: string | undefined;
    PackageVersionHistoryList?: PackageVersionHistory[] | undefined;
    NextToken?: string | undefined;
}
export interface GetUpgradeHistoryRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type UpgradeName = string;
export type StartTimestamp = Date;
export type UpgradeStatus = "IN_PROGRESS" | "SUCCEEDED" | "SUCCEEDED_WITH_ISSUES" | "FAILED" | (string & {});
export type UpgradeStep = "PRE_UPGRADE_CHECK" | "SNAPSHOT" | "UPGRADE" | (string & {});
export type Issue = string;
export type Issues = string[];
export interface UpgradeStepItem {
    UpgradeStep?: UpgradeStep | undefined;
    UpgradeStepStatus?: UpgradeStatus | undefined;
    Issues?: string[] | undefined;
    ProgressPercent?: number | undefined;
}
export type UpgradeStepsList = UpgradeStepItem[];
export interface UpgradeHistory {
    UpgradeName?: string | undefined;
    StartTimestamp?: Date | undefined;
    UpgradeStatus?: UpgradeStatus | undefined;
    StepsList?: UpgradeStepItem[] | undefined;
}
export type UpgradeHistoryList = UpgradeHistory[];
export interface GetUpgradeHistoryResponse {
    UpgradeHistories?: UpgradeHistory[] | undefined;
    NextToken?: string | undefined;
}
export interface GetUpgradeStatusRequest {
    DomainName: string;
}
export interface GetUpgradeStatusResponse {
    UpgradeStep?: UpgradeStep | undefined;
    StepStatus?: UpgradeStatus | undefined;
    UpgradeName?: string | undefined;
}
export type InsightFeedbackEntityType = "DomainName" | (string & {});
export interface InsightFeedbackEntity {
    Type: InsightFeedbackEntityType;
    Value: string;
}
export type InsightFeedbackThumbs = "Up" | "Down" | (string & {});
export type InsightFeedbackText = string;
export interface InsightFeedbackRequest {
    Entity: InsightFeedbackEntity;
    InsightId: string;
    Thumbs: InsightFeedbackThumbs;
    FeedbackText?: string | undefined;
}
export type InsightResponseStatus = "SUCCESS" | "ERROR" | (string & {});
export interface InsightFeedbackResponse {
    Status?: InsightResponseStatus | undefined;
}
export type ApplicationStatuses = ApplicationStatus[];
export interface ListApplicationsRequest {
    nextToken?: string | undefined;
    statuses?: ApplicationStatus[] | undefined;
    maxResults?: number | undefined;
}
export interface ApplicationSummary {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    endpoint?: string | undefined;
    status?: ApplicationStatus | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type ApplicationSummaries = ApplicationSummary[];
export interface ListApplicationsResponse {
    ApplicationSummaries?: ApplicationSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataSourceAttachmentsRequest {
    id: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DataSourceAttachmentSummary {
    attachmentId?: string | undefined;
    dataSourceArn?: string | undefined;
    status?: DataSourceAttachmentStatus | undefined;
}
export type DataSourceAttachmentSummaryList = DataSourceAttachmentSummary[];
export interface ListDataSourceAttachmentsResponse {
    attachments?: DataSourceAttachmentSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataSourcesRequest {
    DomainName: string;
}
export interface DataSourceDetails {
    DataSourceType?: DataSourceType | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Status?: DataSourceStatus | undefined;
}
export type DataSourceList = DataSourceDetails[];
export interface ListDataSourcesResponse {
    DataSources?: DataSourceDetails[] | undefined;
}
export interface ListDirectQueryDataSourcesRequest {
    NextToken?: string | undefined;
}
export interface DirectQueryDataSource {
    DataSourceName?: string | undefined;
    DataSourceType?: DirectQueryDataSourceType | undefined;
    Description?: string | undefined;
    OpenSearchArns?: string[] | undefined;
    DataSourceArn?: string | undefined;
    TagList?: Tag[] | undefined;
}
export type DirectQueryDataSourceList = DirectQueryDataSource[];
export interface ListDirectQueryDataSourcesResponse {
    NextToken?: string | undefined;
    DirectQueryDataSources?: DirectQueryDataSource[] | undefined;
}
export interface ListDomainMaintenancesRequest {
    DomainName: string;
    Action?: MaintenanceType | undefined;
    Status?: MaintenanceStatus | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DomainMaintenanceDetails {
    MaintenanceId?: string | undefined;
    DomainName?: string | undefined;
    Action?: MaintenanceType | undefined;
    NodeId?: string | undefined;
    Status?: MaintenanceStatus | undefined;
    StatusMessage?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type DomainMaintenanceList = DomainMaintenanceDetails[];
export interface ListDomainMaintenancesResponse {
    DomainMaintenances?: DomainMaintenanceDetails[] | undefined;
    NextToken?: string | undefined;
}
export type EngineType = "OpenSearch" | "Elasticsearch" | (string & {});
export interface ListDomainNamesRequest {
    EngineType?: EngineType | undefined;
}
export interface DomainInfo {
    DomainName?: string | undefined;
    EngineType?: EngineType | undefined;
}
export type DomainInfoList = DomainInfo[];
export interface ListDomainNamesResponse {
    DomainNames?: DomainInfo[] | undefined;
}
export interface ListDomainsForPackageRequest {
    PackageID: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListDomainsForPackageResponse {
    DomainPackageDetailsList?: DomainPackageDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface InsightTimeRange {
    From: number;
    To: number;
}
export type InsightSortOrder = "ASC" | "DESC" | (string & {});
export type InsightPageSize = number;
export interface ListInsightsRequest {
    Entity: InsightEntity;
    TimeRange?: InsightTimeRange | undefined;
    SortOrder?: InsightSortOrder | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InsightType = "EVENT" | "RECOMMENDATION" | (string & {});
export type InsightPriorityLevel = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | (string & {});
export type InsightStatus = "ACTIVE" | "RESOLVED" | "DISMISSED" | (string & {});
export interface Insight {
    InsightId?: string | undefined;
    DisplayName?: string | undefined;
    Type?: InsightType | undefined;
    Priority?: InsightPriorityLevel | undefined;
    Status?: InsightStatus | undefined;
    CreationTime?: Date | undefined;
    UpdateTime?: Date | undefined;
    IsExperimental?: boolean | undefined;
}
export type InsightList = Insight[];
export interface ListInsightsResponse {
    Insights?: Insight[] | undefined;
    NextToken?: string | undefined;
}
export type InstanceTypeString = string;
export interface ListInstanceTypeDetailsRequest {
    EngineVersion: string;
    DomainName?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    RetrieveAZs?: boolean | undefined;
    InstanceType?: string | undefined;
}
export type InstanceRoleList = string[];
export type AvailabilityZoneList = string[];
export interface InstanceTypeDetails {
    InstanceType?: OpenSearchPartitionInstanceType | undefined;
    EncryptionEnabled?: boolean | undefined;
    CognitoEnabled?: boolean | undefined;
    AppLogsEnabled?: boolean | undefined;
    AdvancedSecurityEnabled?: boolean | undefined;
    WarmEnabled?: boolean | undefined;
    InstanceRole?: string[] | undefined;
    AvailabilityZones?: string[] | undefined;
}
export type InstanceTypeDetailsList = InstanceTypeDetails[];
export interface ListInstanceTypeDetailsResponse {
    InstanceTypeDetails?: InstanceTypeDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMigrationsRequest {
    applicationId: string;
    status?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface MigrationSummary {
    migrationId?: string | undefined;
    status?: string | undefined;
    applicationId?: string | undefined;
    source?: MigrationSource | undefined;
    exportedCount?: number | undefined;
    importedCount?: number | undefined;
    error?: MigrationError | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type MigrationSummaryList = MigrationSummary[];
export interface ListMigrationsResponse {
    migrations?: MigrationSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPackagesForDomainRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListPackagesForDomainResponse {
    DomainPackageDetailsList?: DomainPackageDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface ListScheduledActionsRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ActionType = "SERVICE_SOFTWARE_UPDATE" | "JVM_HEAP_SIZE_TUNING" | "JVM_YOUNG_GEN_TUNING" | (string & {});
export type ActionSeverity = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export type ScheduledBy = "CUSTOMER" | "SYSTEM" | (string & {});
export type ActionStatus = "PENDING_UPDATE" | "IN_PROGRESS" | "FAILED" | "COMPLETED" | "NOT_ELIGIBLE" | "ELIGIBLE" | (string & {});
export interface ScheduledAction {
    Id: string;
    Type: ActionType;
    Severity: ActionSeverity;
    ScheduledTime: number;
    Description?: string | undefined;
    ScheduledBy?: ScheduledBy | undefined;
    Status?: ActionStatus | undefined;
    Mandatory?: boolean | undefined;
    Cancellable?: boolean | undefined;
}
export type ScheduledActionsList = ScheduledAction[];
export interface ListScheduledActionsResponse {
    ScheduledActions?: ScheduledAction[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsRequest {
    ARN: string;
}
export interface ListTagsResponse {
    TagList?: Tag[] | undefined;
}
export interface ListVersionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListVersionsResponse {
    Versions?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListVpcEndpointAccessRequest {
    DomainName: string;
    NextToken?: string | undefined;
}
export type AuthorizedPrincipalList = AuthorizedPrincipal[];
export interface ListVpcEndpointAccessResponse {
    AuthorizedPrincipalList: AuthorizedPrincipal[];
    NextToken: string;
}
export interface ListVpcEndpointsRequest {
    NextToken?: string | undefined;
}
export type VpcEndpointSummaryList = VpcEndpointSummary[];
export interface ListVpcEndpointsResponse {
    VpcEndpointSummaryList: VpcEndpointSummary[];
    NextToken: string;
}
export interface ListVpcEndpointsForDomainRequest {
    DomainName: string;
    NextToken?: string | undefined;
}
export interface ListVpcEndpointsForDomainResponse {
    VpcEndpointSummaryList: VpcEndpointSummary[];
    NextToken: string;
}
export type InstanceCount = number;
export interface PurchaseReservedInstanceOfferingRequest {
    ReservedInstanceOfferingId: string;
    ReservationName: string;
    InstanceCount?: number | undefined;
}
export interface PurchaseReservedInstanceOfferingResponse {
    ReservedInstanceId?: string | undefined;
    ReservationName?: string | undefined;
}
export interface PutDefaultApplicationSettingRequest {
    applicationArn: string;
    setAsDefault: boolean;
}
export interface PutDefaultApplicationSettingResponse {
    applicationArn?: string | undefined;
}
export type CapabilityBaseRequestConfig = {
    aiConfig: AIConfig;
};
export interface RegisterCapabilityRequest {
    applicationId: string;
    capabilityName: string;
    capabilityConfig: CapabilityBaseRequestConfig;
}
export type CapabilityBaseResponseConfig = {
    aiConfig: AIConfig;
};
export interface RegisterCapabilityResponse {
    capabilityName?: string | undefined;
    applicationId?: string | undefined;
    status?: CapabilityStatus | undefined;
    capabilityConfig?: CapabilityBaseResponseConfig | undefined;
}
export interface RejectInboundConnectionRequest {
    ConnectionId: string;
}
export interface RejectInboundConnectionResponse {
    Connection?: InboundConnection | undefined;
}
export interface RemoveReplicationPeerRequest {
    DomainName: string;
    PeerDomainArn: string;
}
export interface RemoveReplicationPeerResponse {
    DomainArn?: string | undefined;
    Status?: ReplicationStatus | undefined;
}
export interface RemoveTagsRequest {
    ARN: string;
    TagKeys: string[];
}
export interface RemoveTagsResponse {
}
export interface RevokeVpcEndpointAccessRequest {
    DomainName: string;
    Account?: string | undefined;
    Service?: AWSServicePrincipal | undefined;
    ServiceOptions?: ServiceOptions | undefined;
}
export interface RevokeVpcEndpointAccessResponse {
}
export interface RollbackServiceSoftwareUpdateRequest {
    DomainName: string;
}
export interface RollbackServiceSoftwareOptions {
    CurrentVersion?: string | undefined;
    NewVersion?: string | undefined;
    RollbackAvailable?: boolean | undefined;
    Description?: string | undefined;
}
export interface RollbackServiceSoftwareUpdateResponse {
    RollbackServiceSoftwareOptions?: RollbackServiceSoftwareOptions | undefined;
}
export interface StartDomainMaintenanceRequest {
    DomainName: string;
    Action: MaintenanceType;
    NodeId?: string | undefined;
}
export interface StartDomainMaintenanceResponse {
    MaintenanceId?: string | undefined;
}
export interface MigrationWorkspace {
    workspaceId?: string | undefined;
    createWorkspace?: boolean | undefined;
    name?: string | undefined;
    type?: string | undefined;
}
export interface SavedObjectIdentifier {
    type: string;
    id: string;
}
export type SavedObjectIdentifierList = SavedObjectIdentifier[];
export interface ExportOptions {
    types?: string[] | undefined;
    objects?: SavedObjectIdentifier[] | undefined;
    includeReferencesDeep?: boolean | undefined;
}
export interface MigrationOptions {
    source: MigrationSource;
    workspace: MigrationWorkspace;
    exportOptions?: ExportOptions | undefined;
    conflictResolution?: string | undefined;
}
export interface StartMigrationRequest {
    applicationId: string;
    migrationOptions: MigrationOptions;
    clientToken?: string | undefined;
}
export interface StartMigrationResponse {
    migrationId?: string | undefined;
    status?: string | undefined;
}
export type ScheduleAt = "NOW" | "TIMESTAMP" | "OFF_PEAK_WINDOW" | (string & {});
export interface StartServiceSoftwareUpdateRequest {
    DomainName: string;
    ScheduleAt?: ScheduleAt | undefined;
    DesiredStartTime?: number | undefined;
}
export interface StartServiceSoftwareUpdateResponse {
    ServiceSoftwareOptions?: ServiceSoftwareOptions | undefined;
}
export interface SwitchoverReplicationRequest {
    DomainName: string;
    PeerDomainArn: string;
}
export interface SwitchoverReplicationResponse {
    DomainArn?: string | undefined;
    Status?: ReplicationStatus | undefined;
}
export interface UpdateApplicationRequest {
    id: string;
    dataSources?: DataSource[] | undefined;
    appConfigs?: AppConfig[] | undefined;
    iamIdentityCenterOptions?: IamIdentityCenterOptionsInput | undefined;
}
export interface UpdateApplicationResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    dataSources?: DataSource[] | undefined;
    iamIdentityCenterOptions?: IamIdentityCenterOptions | undefined;
    appConfigs?: AppConfig[] | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type TrafficStrategy = "ShiftReadTrafficPercent" | (string & {});
export interface TrafficSplitRequestOptions {
    Strategy: TrafficStrategy;
    CloneReadTrafficPercent: number;
}
export type CutoverTarget = "ClonedCluster" | "PrimaryCluster" | (string & {});
export interface CutoverRequestOptions {
    Target: CutoverTarget;
}
export type RetentionAction = "RollbackToPrimaryCluster" | "DeletePrimaryCluster" | (string & {});
export type RetentionOptions = {
    RetentionInHours: number;
    RetentionAction?: undefined;
} | {
    RetentionInHours?: undefined;
    RetentionAction: RetentionAction;
};
export interface UpdateCloneRequest {
    DomainName: string;
    TrafficSplitOptions?: TrafficSplitRequestOptions | undefined;
    CutoverOptions?: CutoverRequestOptions | undefined;
    RetentionOptions?: RetentionOptions | undefined;
}
export type CutoverStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export interface CutoverOptions {
    Target: CutoverTarget;
    Status: CutoverStatus;
}
export type TrafficSplitStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export interface TrafficSplitOptions {
    Current: TrafficPercents;
    Target: TrafficPercents;
    Status: TrafficSplitStatus;
}
export interface UpdateCloneResponse {
    DomainName: string;
    ChangeId: string;
    CutoverOptions?: CutoverOptions | undefined;
    TrafficSplitOptions?: TrafficSplitOptions | undefined;
    RetentionOptions?: RetentionOptions | undefined;
}
export interface UpdateDataSourceRequest {
    DomainName: string;
    Name: string;
    DataSourceType: DataSourceType;
    Description?: string | undefined;
    Status?: DataSourceStatus | undefined;
}
export interface UpdateDataSourceResponse {
    Message?: string | undefined;
}
export interface UpdateDirectQueryDataSourceRequest {
    DataSourceName: string;
    DataSourceType: DirectQueryDataSourceType;
    Description?: string | undefined;
    OpenSearchArns?: string[] | undefined;
    DataSourceAccessPolicy?: string | undefined;
}
export interface UpdateDirectQueryDataSourceResponse {
    DataSourceArn?: string | undefined;
}
export type DryRunMode = "Basic" | "Verbose" | (string & {});
export interface UpdateDomainConfigRequest {
    DomainName: string;
    ClusterConfig?: ClusterConfig | undefined;
    EBSOptions?: EBSOptions | undefined;
    SnapshotOptions?: SnapshotOptions | undefined;
    VPCOptions?: VPCOptions | undefined;
    CognitoOptions?: CognitoOptions | undefined;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    AccessPolicies?: string | undefined;
    IPAddressType?: IPAddressType | undefined;
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    } | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    DomainEndpointOptions?: DomainEndpointOptions | undefined;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions | undefined;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsInput | undefined;
    IdentityCenterOptions?: IdentityCenterOptionsInput | undefined;
    AutoTuneOptions?: AutoTuneOptions | undefined;
    DryRun?: boolean | undefined;
    DryRunMode?: DryRunMode | undefined;
    OffPeakWindowOptions?: OffPeakWindowOptions | undefined;
    SoftwareUpdateOptions?: SoftwareUpdateOptions | undefined;
    AIMLOptions?: AIMLOptionsInput | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOptions | undefined;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseRequestOptions | undefined;
    UseCase?: DomainUseCase | undefined;
    EngineMode?: EngineMode | undefined;
    AcceptedWarnings?: string[] | undefined;
}
export interface UpdateDomainConfigResponse {
    DomainConfig: DomainConfig;
    DryRunResults?: DryRunResults | undefined;
    DryRunProgressStatus?: DryRunProgressStatus | undefined;
}
export interface UpdateIndexRequest {
    DomainName: string;
    IndexName: string;
    IndexSchema: any;
}
export interface UpdateIndexResponse {
    Status: IndexStatus;
}
export interface UpdatePackageRequest {
    PackageID: string;
    PackageSource: PackageSource;
    PackageDescription?: string | undefined;
    CommitMessage?: string | undefined;
    PackageConfiguration?: PackageConfiguration | undefined;
    PackageEncryptionOptions?: PackageEncryptionOptions | undefined;
}
export interface UpdatePackageResponse {
    PackageDetails?: PackageDetails | undefined;
}
export type PackageScopeOperationEnum = "ADD" | "OVERRIDE" | "REMOVE" | (string & {});
export interface UpdatePackageScopeRequest {
    PackageID: string;
    Operation: PackageScopeOperationEnum;
    PackageUserList: string[];
}
export interface UpdatePackageScopeResponse {
    PackageID?: string | undefined;
    Operation?: PackageScopeOperationEnum | undefined;
    PackageUserList?: string[] | undefined;
}
export interface UpdateScheduledActionRequest {
    DomainName: string;
    ActionID: string;
    ActionType: ActionType;
    ScheduleAt: ScheduleAt;
    DesiredStartTime?: number | undefined;
}
export interface UpdateScheduledActionResponse {
    ScheduledAction?: ScheduledAction | undefined;
}
export interface UpdateVpcEndpointRequest {
    VpcEndpointId: string;
    VpcOptions: VPCOptions;
}
export interface UpdateVpcEndpointResponse {
    VpcEndpoint: VpcEndpoint;
}
export type DeploymentStrategyOverride = "ClonedBlueGreen" | (string & {});
export interface ClonedBlueGreenOptions {
    RetentionOptions?: RetentionOptions | undefined;
}
export interface DeploymentStrategyOverrideOptions {
    DeploymentStrategy: DeploymentStrategyOverride;
    ClonedBlueGreenOptions?: ClonedBlueGreenOptions | undefined;
}
export interface UpgradeDomainRequest {
    DomainName: string;
    TargetVersion: string;
    PerformCheckOnly?: boolean | undefined;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOverrideOptions | undefined;
}
export interface UpgradeDomainResponse {
    UpgradeId?: string | undefined;
    DomainName?: string | undefined;
    TargetVersion?: string | undefined;
    PerformCheckOnly?: boolean | undefined;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOverrideOptions | undefined;
    ChangeProgressDetails?: ChangeProgressDetails | undefined;
}
export type SlotList = number[];
export type AcceptInboundConnectionError = DisabledOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination Amazon OpenSearch Service domain owner to accept an inbound
 * cross-cluster search connection request. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const acceptInboundConnection: API.OperationMethod<AcceptInboundConnectionRequest & RegionInput, AcceptInboundConnectionResponse, AcceptInboundConnectionError, Credentials | HttpClient.HttpClient>;
export type AddDataSourceError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a new direct-query data source to the specified domain. For more information,
 * see Creating Amazon OpenSearch Service data source integrations with Amazon
 * S3.
 */
export declare const addDataSource: API.OperationMethod<AddDataSourceRequest & RegionInput, AddDataSourceResponse, AddDataSourceError, Credentials | HttpClient.HttpClient>;
export type AddDirectQueryDataSourceError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a new data source in Amazon OpenSearch Service so that you can perform direct
 * queries on external data.
 */
export declare const addDirectQueryDataSource: API.OperationMethod<AddDirectQueryDataSourceRequest & RegionInput, AddDirectQueryDataSourceResponse, AddDirectQueryDataSourceError, Credentials | HttpClient.HttpClient>;
export type AddReplicationPeerError = DisabledOperationException | InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts replicating a domain to a peer domain in another AWS Region. A domain can have one
 * peer. The domain you call becomes the primary and the peer becomes the secondary, which
 * receives a copy of the primary's indexes and serves read requests.
 *
 * Replication is established asynchronously. Use the `DescribeDomainReplication` operation to check whether the
 * relationship has reached the `ACTIVE` state.
 */
export declare const addReplicationPeer: API.OperationMethod<AddReplicationPeerRequest & RegionInput, AddReplicationPeerResponse, AddReplicationPeerError, Credentials | HttpClient.HttpClient>;
export type AddTagsError = BaseException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Attaches tags to an existing Amazon OpenSearch Service domain, data source, or
 * application.
 *
 * Tags are a set of case-sensitive key-value pairs. A domain, data source, or
 * application can have up to 10 tags. For more information, see Tagging Amazon OpenSearch Service resources.
 */
export declare const addTags: API.OperationMethod<AddTagsRequest & RegionInput, AddTagsResponse, AddTagsError, Credentials | HttpClient.HttpClient>;
export type AssociatePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates a package with an Amazon OpenSearch Service domain. For more information,
 * see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const associatePackage: API.OperationMethod<AssociatePackageRequest & RegionInput, AssociatePackageResponse, AssociatePackageError, Credentials | HttpClient.HttpClient>;
export type AssociatePackagesError = BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Operation in the Amazon OpenSearch Service API for associating multiple packages with
 * a domain simultaneously.
 */
export declare const associatePackages: API.OperationMethod<AssociatePackagesRequest & RegionInput, AssociatePackagesResponse, AssociatePackagesError, Credentials | HttpClient.HttpClient>;
export type AttachDataSourceError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Attaches a data source to an OpenSearch application. The data source must be an Amazon OpenSearch Service domain. If both the application and the data source are active, the attachment completes immediately with a status of `ATTACHED`. Otherwise, the operation returns `PENDING` and completes the attachment automatically once both become active. If the attachment cannot be completed, its status becomes `FAILED`. This operation is idempotent: If the data source is already attached or pending, the operation returns the existing attachment.
 */
export declare const attachDataSource: API.OperationMethod<AttachDataSourceRequest & RegionInput, AttachDataSourceResponse, AttachDataSourceError, Credentials | HttpClient.HttpClient>;
export type AuthorizeVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides access to an Amazon OpenSearch Service domain through the use of an interface
 * VPC endpoint.
 */
export declare const authorizeVpcEndpointAccess: API.OperationMethod<AuthorizeVpcEndpointAccessRequest & RegionInput, AuthorizeVpcEndpointAccessResponse, AuthorizeVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type CancelDomainConfigChangeError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a pending configuration change on an Amazon OpenSearch Service domain.
 */
export declare const cancelDomainConfigChange: API.OperationMethod<CancelDomainConfigChangeRequest & RegionInput, CancelDomainConfigChangeResponse, CancelDomainConfigChangeError, Credentials | HttpClient.HttpClient>;
export type CancelServiceSoftwareUpdateError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a scheduled service software update for an Amazon OpenSearch Service domain.
 * You can only perform this operation before the `AutomatedUpdateDate` and when
 * the domain's `UpdateStatus` is `PENDING_UPDATE`. For more
 * information, see Service
 * software updates in Amazon OpenSearch Service.
 */
export declare const cancelServiceSoftwareUpdate: API.OperationMethod<CancelServiceSoftwareUpdateRequest & RegionInput, CancelServiceSoftwareUpdateResponse, CancelServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type CompareDomainConfigurationError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Compares the metadata of two domains and reports where they differ. Use this operation to
 * check that a secondary domain is configured consistently with its primary before you rely on
 * it, because replication copies index data but does not copy domain metadata such as index
 * templates, ingest pipelines, or security roles.
 *
 * You choose which categories to compare. The response reports, for each category, how many
 * items match, how many exist on only one domain, and which fields diverge.
 */
export declare const compareDomainConfiguration: API.OperationMethod<CompareDomainConfigurationRequest & RegionInput, CompareDomainConfigurationResponse, CompareDomainConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | BaseException | ConflictException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Creates an OpenSearch UI application. For more information, see Using the OpenSearch user interface in Amazon OpenSearch Service.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates an Amazon OpenSearch Service domain. For more information, see Creating and
 * managing Amazon OpenSearch Service domains.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest & RegionInput, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = AccessDeniedException | DependencyFailureException | DisabledOperationException | InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an OpenSearch index with optional automatic semantic enrichment for specified text fields. Automatic semantic enrichment enables semantic search capabilities without requiring machine learning expertise, improving search relevance by up to 20% by understanding search intent and contextual meaning beyond keyword matching. The semantic enrichment process has zero impact on search latency as sparse encodings are stored directly within the index during indexing. For more information, see Automatic semantic enrichment.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest & RegionInput, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateOutboundConnectionError = DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a new cross-cluster search connection from a source Amazon OpenSearch Service domain
 * to a destination domain. For more information, see Cross-cluster search
 * for Amazon OpenSearch Service.
 */
export declare const createOutboundConnection: API.OperationMethod<CreateOutboundConnectionRequest & RegionInput, CreateOutboundConnectionResponse, CreateOutboundConnectionError, Credentials | HttpClient.HttpClient>;
export type CreatePackageError = AccessDeniedException | BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a package for use with Amazon OpenSearch Service domains. For more
 * information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const createPackage: API.OperationMethod<CreatePackageRequest & RegionInput, CreatePackageResponse, CreatePackageError, Credentials | HttpClient.HttpClient>;
export type CreateVpcEndpointError = BaseException | ConflictException | DisabledOperationException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Creates an Amazon OpenSearch Service-managed VPC endpoint.
 */
export declare const createVpcEndpoint: API.OperationMethod<CreateVpcEndpointRequest & RegionInput, CreateVpcEndpointResponse, CreateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a specified OpenSearch application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a direct-query data source. For more information, see Deleting
 * an Amazon OpenSearch Service data source with Amazon S3.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest & RegionInput, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectQueryDataSourceError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a previously configured direct query data source from Amazon OpenSearch
 * Service.
 */
export declare const deleteDirectQueryDataSource: API.OperationMethod<DeleteDirectQueryDataSourceRequest & RegionInput, DeleteDirectQueryDataSourceResponse, DeleteDirectQueryDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon OpenSearch Service domain and all of its data. You can't recover a
 * domain after you delete it.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest & RegionInput, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteInboundConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination Amazon OpenSearch Service domain owner to delete an existing
 * inbound cross-cluster search connection. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const deleteInboundConnection: API.OperationMethod<DeleteInboundConnectionRequest & RegionInput, DeleteInboundConnectionResponse, DeleteInboundConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = AccessDeniedException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch index. This operation permanently removes the index and cannot be undone.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest & RegionInput, DeleteIndexResponse, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteOutboundConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the source Amazon OpenSearch Service domain owner to delete an existing
 * outbound cross-cluster search connection. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const deleteOutboundConnection: API.OperationMethod<DeleteOutboundConnectionRequest & RegionInput, DeleteOutboundConnectionResponse, DeleteOutboundConnectionError, Credentials | HttpClient.HttpClient>;
export type DeletePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon OpenSearch Service package. For more information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const deletePackage: API.OperationMethod<DeletePackageRequest & RegionInput, DeletePackageResponse, DeletePackageError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcEndpointError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Amazon OpenSearch Service-managed interface VPC endpoint.
 */
export declare const deleteVpcEndpoint: API.OperationMethod<DeleteVpcEndpointRequest & RegionInput, DeleteVpcEndpointResponse, DeleteVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DeregisterCapabilityError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deregisters a capability from an OpenSearch UI application. This operation removes the capability and its associated configuration.
 */
export declare const deregisterCapability: API.OperationMethod<DeregisterCapabilityRequest & RegionInput, DeregisterCapabilityResponse, DeregisterCapabilityError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSourceAttachmentError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the current status and details of a specific data source attachment for an OpenSearch application. Throws a `ResourceNotFoundException` if no attachment record exists for the specified application and data source combination.
 */
export declare const describeDataSourceAttachment: API.OperationMethod<DescribeDataSourceAttachmentRequest & RegionInput, DescribeDataSourceAttachmentResponse, DescribeDataSourceAttachmentError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the domain configuration for the specified Amazon OpenSearch Service domain,
 * including the domain ID, domain service endpoint, and domain ARN.
 */
export declare const describeDomain: API.OperationMethod<DescribeDomainRequest & RegionInput, DescribeDomainResponse, DescribeDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainAutoTunesError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the list of optimizations that Auto-Tune has made to an Amazon OpenSearch
 * Service domain. For more information, see Auto-Tune for Amazon
 * OpenSearch Service.
 */
export declare const describeDomainAutoTunes: API.PaginatedOperationMethod<DescribeDomainAutoTunesRequest & RegionInput, DescribeDomainAutoTunesResponse, DescribeDomainAutoTunesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeDomainChangeProgressError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about the current blue/green deployment happening on an Amazon
 * OpenSearch Service domain. For more information, see Making configuration changes in Amazon OpenSearch Service.
 */
export declare const describeDomainChangeProgress: API.OperationMethod<DescribeDomainChangeProgressRequest & RegionInput, DescribeDomainChangeProgressResponse, DescribeDomainChangeProgressError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainConfigError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the configuration of an Amazon OpenSearch Service domain.
 */
export declare const describeDomainConfig: API.OperationMethod<DescribeDomainConfigRequest & RegionInput, DescribeDomainConfigResponse, DescribeDomainConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainHealthError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about domain and node health, the standby Availability Zone,
 * number of nodes per Availability Zone, and shard count per node.
 */
export declare const describeDomainHealth: API.OperationMethod<DescribeDomainHealthRequest & RegionInput, DescribeDomainHealthResponse, DescribeDomainHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainNodesError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about domain and nodes, including data nodes, master nodes,
 * ultrawarm nodes, Availability Zone(s), standby nodes, node configurations, and node
 * states.
 */
export declare const describeDomainNodes: API.OperationMethod<DescribeDomainNodesRequest & RegionInput, DescribeDomainNodesResponse, DescribeDomainNodesError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainReplicationError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the replication arrangement that a domain participates in, including the domain's
 * role and the state of its relationship with each peer.
 *
 * A domain that is not replicating is returned with an empty `Peers` list and no
 * `Role`. Returns `ResourceNotFoundException` if the domain does not
 * exist.
 */
export declare const describeDomainReplication: API.OperationMethod<DescribeDomainReplicationRequest & RegionInput, DescribeDomainReplicationResponse, DescribeDomainReplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainsError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Returns domain configuration information about the specified Amazon OpenSearch Service
 * domains.
 */
export declare const describeDomains: API.OperationMethod<DescribeDomainsRequest & RegionInput, DescribeDomainsResponse, DescribeDomainsError, Credentials | HttpClient.HttpClient>;
export type DescribeDryRunProgressError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the progress of a pre-update dry run analysis on an Amazon OpenSearch
 * Service domain. For more information, see Determining whether a change will cause a blue/green deployment.
 */
export declare const describeDryRunProgress: API.OperationMethod<DescribeDryRunProgressRequest & RegionInput, DescribeDryRunProgressResponse, DescribeDryRunProgressError, Credentials | HttpClient.HttpClient>;
export type DescribeInboundConnectionsError = DisabledOperationException | InvalidPaginationTokenException | CommonErrors;
/**
 * Lists all the inbound cross-cluster search connections for a destination (remote)
 * Amazon OpenSearch Service domain. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const describeInboundConnections: API.PaginatedOperationMethod<DescribeInboundConnectionsRequest & RegionInput, DescribeInboundConnectionsResponse, DescribeInboundConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeInsightDetailsError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the details of an existing insight for an Amazon OpenSearch Service domain.
 * Returns detailed fields associated with the specified insight, such as text descriptions
 * and metric data.
 */
export declare const describeInsightDetails: API.OperationMethod<DescribeInsightDetailsRequest & RegionInput, DescribeInsightDetailsResponse, DescribeInsightDetailsError, Credentials | HttpClient.HttpClient>;
export type DescribeInstanceTypeLimitsError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the instance count, storage, and master node limits for a given OpenSearch
 * or Elasticsearch version and instance type.
 */
export declare const describeInstanceTypeLimits: API.OperationMethod<DescribeInstanceTypeLimitsRequest & RegionInput, DescribeInstanceTypeLimitsResponse, DescribeInstanceTypeLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeOutboundConnectionsError = DisabledOperationException | InvalidPaginationTokenException | CommonErrors;
/**
 * Lists all the outbound cross-cluster connections for a local (source) Amazon
 * OpenSearch Service domain. For more information, see Cross-cluster search for Amazon OpenSearch Service.
 */
export declare const describeOutboundConnections: API.PaginatedOperationMethod<DescribeOutboundConnectionsRequest & RegionInput, DescribeOutboundConnectionsResponse, DescribeOutboundConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePackagesError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes all packages available to OpenSearch Service. For more information, see
 * Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const describePackages: API.PaginatedOperationMethod<DescribePackagesRequest & RegionInput, DescribePackagesResponse, DescribePackagesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReservedInstanceOfferingsError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the available Amazon OpenSearch Service Reserved Instance offerings for a
 * given Region. For more information, see Reserved Instances in Amazon
 * OpenSearch Service.
 */
export declare const describeReservedInstanceOfferings: API.PaginatedOperationMethod<DescribeReservedInstanceOfferingsRequest & RegionInput, DescribeReservedInstanceOfferingsResponse, DescribeReservedInstanceOfferingsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReservedInstancesError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the Amazon OpenSearch Service instances that you have reserved in a given
 * Region. For more information, see Reserved Instances in Amazon
 * OpenSearch Service.
 */
export declare const describeReservedInstances: API.PaginatedOperationMethod<DescribeReservedInstancesRequest & RegionInput, DescribeReservedInstancesResponse, DescribeReservedInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeVpcEndpointsError = BaseException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Describes one or more Amazon OpenSearch Service-managed VPC endpoints.
 */
export declare const describeVpcEndpoints: API.OperationMethod<DescribeVpcEndpointsRequest & RegionInput, DescribeVpcEndpointsResponse, DescribeVpcEndpointsError, Credentials | HttpClient.HttpClient>;
export type DetachDataSourceError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a data source from an OpenSearch application. The application must be in the `ACTIVE` state. This operation removes the data source saved object from the application and deletes the attachment record. Throws a `ConflictException` if the specified data source has a `PENDING` attachment, and a `ResourceNotFoundException` if the data source is not currently attached to the application.
 */
export declare const detachDataSource: API.OperationMethod<DetachDataSourceRequest & RegionInput, DetachDataSourceResponse, DetachDataSourceError, Credentials | HttpClient.HttpClient>;
export type DissociatePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a package from the specified Amazon OpenSearch Service domain. The package
 * can't be in use with any OpenSearch index for the dissociation to succeed. The package
 * is still available in OpenSearch Service for association later. For more information,
 * see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const dissociatePackage: API.OperationMethod<DissociatePackageRequest & RegionInput, DissociatePackageResponse, DissociatePackageError, Credentials | HttpClient.HttpClient>;
export type DissociatePackagesError = BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Dissociates multiple packages from a domain simultaneously.
 */
export declare const dissociatePackages: API.OperationMethod<DissociatePackagesRequest & RegionInput, DissociatePackagesResponse, DissociatePackagesError, Credentials | HttpClient.HttpClient>;
export type FailoverReplicationError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Promotes a secondary domain to primary without coordinating with the current primary. Use
 * this operation when the primary is unreachable and you cannot wait for it to recover.
 *
 * Writes that had not yet replicated when the primary became unreachable are lost. You must
 * set `AllowDataLoss` to acknowledge this. To promote a domain without losing writes,
 * use the `SwitchoverReplication` operation instead.
 *
 * Call this operation in the Region of the domain you want to promote.
 */
export declare const failoverReplication: API.OperationMethod<FailoverReplicationRequest & RegionInput, FailoverReplicationResponse, FailoverReplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration and status of an existing OpenSearch application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest & RegionInput, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetCapabilityError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about a registered capability for an OpenSearch UI application, including its configuration and current status.
 */
export declare const getCapability: API.OperationMethod<GetCapabilityRequest & RegionInput, GetCapabilityResponse, GetCapabilityError, Credentials | HttpClient.HttpClient>;
export type GetCompatibleVersionsError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a map of OpenSearch or Elasticsearch versions and the versions you can upgrade
 * them to.
 */
export declare const getCompatibleVersions: API.OperationMethod<GetCompatibleVersionsRequest & RegionInput, GetCompatibleVersionsResponse, GetCompatibleVersionsError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about a direct query data source.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceRequest & RegionInput, GetDataSourceResponse, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDefaultApplicationSettingError = AccessDeniedException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets the ARN of the current default application.
 *
 * If the default application isn't set, the operation returns a resource not found
 * error.
 */
export declare const getDefaultApplicationSetting: API.OperationMethod<GetDefaultApplicationSettingRequest & RegionInput, GetDefaultApplicationSettingResponse, GetDefaultApplicationSettingError, Credentials | HttpClient.HttpClient>;
export type GetDirectQueryDataSourceError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns detailed configuration information for a specific direct query data source in
 * Amazon OpenSearch Service.
 */
export declare const getDirectQueryDataSource: API.OperationMethod<GetDirectQueryDataSourceRequest & RegionInput, GetDirectQueryDataSourceResponse, GetDirectQueryDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDomainMaintenanceStatusError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * The status of the maintenance action.
 */
export declare const getDomainMaintenanceStatus: API.OperationMethod<GetDomainMaintenanceStatusRequest & RegionInput, GetDomainMaintenanceStatusResponse, GetDomainMaintenanceStatusError, Credentials | HttpClient.HttpClient>;
export type GetIndexError = AccessDeniedException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an OpenSearch index including its schema and semantic enrichment configuration. Use this operation to view the current index structure and semantic search settings.
 */
export declare const getIndex: API.OperationMethod<GetIndexRequest & RegionInput, GetIndexResponse, GetIndexError, Credentials | HttpClient.HttpClient>;
export type GetMigrationError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the current status and progress of a migration job, including the number of exported and imported objects and error details if the migration failed.
 */
export declare const getMigration: API.OperationMethod<GetMigrationRequest & RegionInput, GetMigrationResponse, GetMigrationError, Credentials | HttpClient.HttpClient>;
export type GetPackageVersionHistoryError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of Amazon OpenSearch Service package versions, along with their creation
 * time, commit message, and plugin properties (if the package is a zip plugin package). For more
 * information, see Custom packages for Amazon
 * OpenSearch Service.
 */
export declare const getPackageVersionHistory: API.PaginatedOperationMethod<GetPackageVersionHistoryRequest & RegionInput, GetPackageVersionHistoryResponse, GetPackageVersionHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUpgradeHistoryError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the complete history of the last 10 upgrades performed on an Amazon OpenSearch
 * Service domain.
 */
export declare const getUpgradeHistory: API.PaginatedOperationMethod<GetUpgradeHistoryRequest & RegionInput, GetUpgradeHistoryResponse, GetUpgradeHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUpgradeStatusError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the most recent status of the last upgrade or upgrade eligibility check performed on
 * an Amazon OpenSearch Service domain.
 */
export declare const getUpgradeStatus: API.OperationMethod<GetUpgradeStatusRequest & RegionInput, GetUpgradeStatusResponse, GetUpgradeStatusError, Credentials | HttpClient.HttpClient>;
export type InsightFeedbackError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Submits feedback for an existing insight in an Amazon OpenSearch Service domain.
 * Allows users to provide a thumbs up or thumbs down rating and optional text feedback
 * for a specific insight.
 */
export declare const insightFeedback: API.OperationMethod<InsightFeedbackRequest & RegionInput, InsightFeedbackResponse, InsightFeedbackError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = AccessDeniedException | BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all OpenSearch applications under your account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListDataSourceAttachmentsError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all data source attachments for an OpenSearch application, including attachments in all states (`PENDING`, `ATTACHED`, and `FAILED`).
 */
export declare const listDataSourceAttachments: API.OperationMethod<ListDataSourceAttachmentsRequest & RegionInput, ListDataSourceAttachmentsResponse, ListDataSourceAttachmentsError, Credentials | HttpClient.HttpClient>;
export type ListDataSourcesError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists direct-query data sources for a specific domain. For more information, see For
 * more information, see Working with
 * Amazon OpenSearch Service direct queries with Amazon S3.
 */
export declare const listDataSources: API.OperationMethod<ListDataSourcesRequest & RegionInput, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient>;
export type ListDirectQueryDataSourcesError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists an inventory of all the direct query data sources that you have configured
 * within Amazon OpenSearch Service.
 */
export declare const listDirectQueryDataSources: API.OperationMethod<ListDirectQueryDataSourcesRequest & RegionInput, ListDirectQueryDataSourcesResponse, ListDirectQueryDataSourcesError, Credentials | HttpClient.HttpClient>;
export type ListDomainMaintenancesError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * A list of maintenance actions for the domain.
 */
export declare const listDomainMaintenances: API.PaginatedOperationMethod<ListDomainMaintenancesRequest & RegionInput, ListDomainMaintenancesResponse, ListDomainMaintenancesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDomainNamesError = BaseException | ValidationException | CommonErrors;
/**
 * Returns the names of all Amazon OpenSearch Service domains owned by the current user
 * in the active Region.
 */
export declare const listDomainNames: API.OperationMethod<ListDomainNamesRequest & RegionInput, ListDomainNamesResponse, ListDomainNamesError, Credentials | HttpClient.HttpClient>;
export type ListDomainsForPackageError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all Amazon OpenSearch Service domains associated with a given package. For more
 * information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const listDomainsForPackage: API.PaginatedOperationMethod<ListDomainsForPackageRequest & RegionInput, ListDomainsForPackageResponse, ListDomainsForPackageError, Credentials | HttpClient.HttpClient, unknown>;
export type ListInsightsError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists insights for an Amazon OpenSearch Service domain or Amazon Web Services account.
 * Returns a paginated list of insights based on the specified entity, filters, time range,
 * and sort order.
 */
export declare const listInsights: API.OperationMethod<ListInsightsRequest & RegionInput, ListInsightsResponse, ListInsightsError, Credentials | HttpClient.HttpClient>;
export type ListInstanceTypeDetailsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all instance types and available features for a given OpenSearch or
 * Elasticsearch version.
 */
export declare const listInstanceTypeDetails: API.PaginatedOperationMethod<ListInstanceTypeDetailsRequest & RegionInput, ListInstanceTypeDetailsResponse, ListInstanceTypeDetailsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMigrationsError = AccessDeniedException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Lists migration jobs for an Amazon OpenSearch Service application. You can filter results by migration status. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listMigrations: API.OperationMethod<ListMigrationsRequest & RegionInput, ListMigrationsResponse, ListMigrationsError, Credentials | HttpClient.HttpClient>;
export type ListPackagesForDomainError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all packages associated with an Amazon OpenSearch Service domain. For more
 * information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const listPackagesForDomain: API.PaginatedOperationMethod<ListPackagesForDomainRequest & RegionInput, ListPackagesForDomainResponse, ListPackagesForDomainError, Credentials | HttpClient.HttpClient, unknown>;
export type ListScheduledActionsError = BaseException | InternalException | InvalidPaginationTokenException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a list of configuration changes that are scheduled for a domain. These
 * changes can be service
 * software updates or blue/green Auto-Tune enhancements.
 */
export declare const listScheduledActions: API.PaginatedOperationMethod<ListScheduledActionsRequest & RegionInput, ListScheduledActionsResponse, ListScheduledActionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns all resource tags for an Amazon OpenSearch Service domain, data source, or
 * application. For more information, see Tagging Amazon OpenSearch Service resources.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest & RegionInput, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ListVersionsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all versions of OpenSearch and Elasticsearch that Amazon OpenSearch Service
 * supports.
 */
export declare const listVersions: API.PaginatedOperationMethod<ListVersionsRequest & RegionInput, ListVersionsResponse, ListVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about each Amazon Web Services principal that is allowed to
 * access a given Amazon OpenSearch Service domain through the use of an interface VPC
 * endpoint.
 */
export declare const listVpcEndpointAccess: API.OperationMethod<ListVpcEndpointAccessRequest & RegionInput, ListVpcEndpointAccessResponse, ListVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsError = BaseException | DisabledOperationException | InternalException | CommonErrors;
/**
 * Retrieves all Amazon OpenSearch Service-managed VPC endpoints in the current Amazon Web Services account and Region.
 */
export declare const listVpcEndpoints: API.OperationMethod<ListVpcEndpointsRequest & RegionInput, ListVpcEndpointsResponse, ListVpcEndpointsError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsForDomainError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves all Amazon OpenSearch Service-managed VPC endpoints associated with a
 * particular domain.
 */
export declare const listVpcEndpointsForDomain: API.OperationMethod<ListVpcEndpointsForDomainRequest & RegionInput, ListVpcEndpointsForDomainResponse, ListVpcEndpointsForDomainError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedInstanceOfferingError = DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Allows you to purchase Amazon OpenSearch Service Reserved Instances.
 */
export declare const purchaseReservedInstanceOffering: API.OperationMethod<PurchaseReservedInstanceOfferingRequest & RegionInput, PurchaseReservedInstanceOfferingResponse, PurchaseReservedInstanceOfferingError, Credentials | HttpClient.HttpClient>;
export type PutDefaultApplicationSettingError = AccessDeniedException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Sets the default application to the application with the specified ARN.
 *
 * To remove the default application, use the `GetDefaultApplicationSetting`
 * operation to get the current default and then call the
 * `PutDefaultApplicationSetting` with the current applications ARN and the
 * `setAsDefault` parameter set to `false`.
 */
export declare const putDefaultApplicationSetting: API.OperationMethod<PutDefaultApplicationSettingRequest & RegionInput, PutDefaultApplicationSettingResponse, PutDefaultApplicationSettingError, Credentials | HttpClient.HttpClient>;
export type RegisterCapabilityError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Registers a capability for an OpenSearch UI application. Use this operation to enable specific capabilities, such as AI features, for a given application. The capability configuration defines the type and settings of the capability to register. For more information about the AI features, see Agentic AI for OpenSearch UI.
 */
export declare const registerCapability: API.OperationMethod<RegisterCapabilityRequest & RegionInput, RegisterCapabilityResponse, RegisterCapabilityError, Credentials | HttpClient.HttpClient>;
export type RejectInboundConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the remote Amazon OpenSearch Service domain owner to reject an inbound
 * cross-cluster connection request.
 */
export declare const rejectInboundConnection: API.OperationMethod<RejectInboundConnectionRequest & RegionInput, RejectInboundConnectionResponse, RejectInboundConnectionError, Credentials | HttpClient.HttpClient>;
export type RemoveReplicationPeerError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops replicating a domain to its peer. Replication ends for both domains, and each domain
 * keeps the data it holds at that point. Neither domain is deleted.
 */
export declare const removeReplicationPeer: API.OperationMethod<RemoveReplicationPeerRequest & RegionInput, RemoveReplicationPeerResponse, RemoveReplicationPeerError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Removes the specified set of tags from an Amazon OpenSearch Service domain, data
 * source, or application. For more information, see Tagging Amazon OpenSearch Service resources.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsRequest & RegionInput, RemoveTagsResponse, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type RevokeVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Revokes access to an Amazon OpenSearch Service domain that was provided through an
 * interface VPC endpoint.
 */
export declare const revokeVpcEndpointAccess: API.OperationMethod<RevokeVpcEndpointAccessRequest & RegionInput, RevokeVpcEndpointAccessResponse, RevokeVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type RollbackServiceSoftwareUpdateError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Rolls back a service software update for a domain to the previous version. For more
 * information, see Service
 * software updates in Amazon OpenSearch Service.
 */
export declare const rollbackServiceSoftwareUpdate: API.OperationMethod<RollbackServiceSoftwareUpdateRequest & RegionInput, RollbackServiceSoftwareUpdateResponse, RollbackServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type StartDomainMaintenanceError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts the node maintenance process on the data node. These processes can include a
 * node reboot, an Opensearch or Elasticsearch process restart, or a Dashboard or Kibana
 * restart.
 */
export declare const startDomainMaintenance: API.OperationMethod<StartDomainMaintenanceRequest & RegionInput, StartDomainMaintenanceResponse, StartDomainMaintenanceError, Credentials | HttpClient.HttpClient>;
export type StartMigrationError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Initiates a migration job to migrate saved objects from a data source to an Amazon OpenSearch Service application workspace. Saved objects include dashboards, visualizations, index patterns, and searches. You can specify export filters to control the scope of the migration and a conflict resolution strategy for handling existing objects in the target workspace.
 */
export declare const startMigration: API.OperationMethod<StartMigrationRequest & RegionInput, StartMigrationResponse, StartMigrationError, Credentials | HttpClient.HttpClient>;
export type StartServiceSoftwareUpdateError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Schedules a service software update for an Amazon OpenSearch Service domain. For more
 * information, see Service
 * software updates in Amazon OpenSearch Service.
 */
export declare const startServiceSoftwareUpdate: API.OperationMethod<StartServiceSoftwareUpdateRequest & RegionInput, StartServiceSoftwareUpdateResponse, StartServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type SwitchoverReplicationError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Promotes a secondary domain to primary, coordinating with the current primary so that no
 * writes are lost. Use this operation for planned role changes, such as testing your recovery
 * procedure or moving write traffic to another Region.
 *
 * Call this operation in the Region of the domain you want to promote. If the current primary
 * is unreachable, use the `FailoverReplication` operation
 * instead.
 */
export declare const switchoverReplication: API.OperationMethod<SwitchoverReplicationRequest & RegionInput, SwitchoverReplicationResponse, SwitchoverReplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AccessDeniedException | BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration and settings of an existing OpenSearch application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateCloneError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Manages a cloned blue/green upgrade that is in progress on a domain. Use it to shift a percentage of search traffic to the cloned cluster, to cut over to the cloned cluster or back to the primary cluster, or to change the retention period. Specify exactly one of `TrafficSplitOptions`, `CutoverOptions`, or `RetentionOptions` in each request.
 */
export declare const updateClone: API.OperationMethod<UpdateCloneRequest & RegionInput, UpdateCloneResponse, UpdateCloneError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = BaseException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a direct-query data source. For more information, see Working
 * with Amazon OpenSearch Service data source integrations with Amazon
 * S3.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest & RegionInput, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectQueryDataSourceError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration or properties of an existing direct query data source in
 * Amazon OpenSearch Service.
 */
export declare const updateDirectQueryDataSource: API.OperationMethod<UpdateDirectQueryDataSourceRequest & RegionInput, UpdateDirectQueryDataSourceResponse, UpdateDirectQueryDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainConfigError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies the cluster configuration of the specified Amazon OpenSearch Service
 * domain.
 */
export declare const updateDomainConfig: API.OperationMethod<UpdateDomainConfigRequest & RegionInput, UpdateDomainConfigResponse, UpdateDomainConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexError = AccessDeniedException | DependencyFailureException | DisabledOperationException | InternalException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing OpenSearch index schema and semantic enrichment configuration. This operation allows modification of field mappings and semantic search settings for text fields. Changes to semantic enrichment configuration will apply to newly ingested documents.
 */
export declare const updateIndex: API.OperationMethod<UpdateIndexRequest & RegionInput, UpdateIndexResponse, UpdateIndexError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageError = AccessDeniedException | BaseException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a package for use with Amazon OpenSearch Service domains. For more
 * information, see Custom packages
 * for Amazon OpenSearch Service.
 */
export declare const updatePackage: API.OperationMethod<UpdatePackageRequest & RegionInput, UpdatePackageResponse, UpdatePackageError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageScopeError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the scope of a package. Scope of the package defines users who can view and
 * associate a package.
 */
export declare const updatePackageScope: API.OperationMethod<UpdatePackageScopeRequest & RegionInput, UpdatePackageScopeResponse, UpdatePackageScopeError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduledActionError = BaseException | ConflictException | InternalException | LimitExceededException | ResourceNotFoundException | SlotNotAvailableException | ValidationException | CommonErrors;
/**
 * Reschedules a planned domain configuration change for a later time. This change can be
 * a scheduled service
 * software update or a blue/green Auto-Tune enhancement.
 */
export declare const updateScheduledAction: API.OperationMethod<UpdateScheduledActionRequest & RegionInput, UpdateScheduledActionResponse, UpdateScheduledActionError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcEndpointError = BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies an Amazon OpenSearch Service-managed interface VPC endpoint.
 */
export declare const updateVpcEndpoint: API.OperationMethod<UpdateVpcEndpointRequest & RegionInput, UpdateVpcEndpointResponse, UpdateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type UpgradeDomainError = BaseException | DisabledOperationException | InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Allows you to either upgrade your Amazon OpenSearch Service domain or perform an
 * upgrade eligibility check to a compatible version of OpenSearch or Elasticsearch.
 */
export declare const upgradeDomain: API.OperationMethod<UpgradeDomainRequest & RegionInput, UpgradeDomainResponse, UpgradeDomainError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=opensearch.d.ts.map