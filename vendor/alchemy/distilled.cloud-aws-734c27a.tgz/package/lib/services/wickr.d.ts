import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestError_base: S.TaggedErrorClass<"BadRequestError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestError extends /*@__PURE__*/ BadRequestError_base {
}
declare const ForbiddenError_base: S.TaggedErrorClass<"ForbiddenError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenError extends /*@__PURE__*/ ForbiddenError_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const RateLimitError_base: S.TaggedErrorClass<"RateLimitError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class RateLimitError extends /*@__PURE__*/ RateLimitError_base {
}
declare const ResourceNotFoundError_base: S.TaggedErrorClass<"ResourceNotFoundError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundError extends /*@__PURE__*/ ResourceNotFoundError_base {
}
declare const UnauthorizedError_base: S.TaggedErrorClass<"UnauthorizedError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedError extends /*@__PURE__*/ UnauthorizedError_base {
}
declare const ValidationError_base: S.TaggedErrorClass<"ValidationError", {
    readonly reasons: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
export type NetworkId = string;
export type SensitiveString = string | redacted.Redacted<string>;
export type SecurityGroupId = string;
export type SecurityGroupIdList = string[];
export interface BatchCreateUserRequestItem {
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    securityGroupIds: string[];
    username: string;
    inviteCode?: string | undefined;
    inviteCodeTtl?: number | undefined;
    codeValidation?: boolean | undefined;
}
export type BatchCreateUserRequestItems = BatchCreateUserRequestItem[];
export type ClientToken = string;
export interface BatchCreateUserRequest {
    networkId: string;
    users: BatchCreateUserRequestItem[];
    clientToken?: string | undefined;
}
export type UserId = string;
export interface User {
    userId?: string | undefined;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    username?: string | undefined;
    securityGroups?: string[] | undefined;
    isAdmin?: boolean | undefined;
    suspended?: boolean | undefined;
    status?: number | undefined;
    otpEnabled?: boolean | undefined;
    scimId?: string | undefined;
    type?: string | undefined;
    cell?: string | undefined;
    countryCode?: string | undefined;
    challengeFailures?: number | undefined;
    isInviteExpired?: boolean | undefined;
    isUser?: boolean | undefined;
    inviteCode?: string | undefined;
    codeValidation?: boolean | undefined;
    uname?: string | undefined;
}
export type Users = User[];
export interface BatchUserErrorResponseItem {
    field?: string | undefined;
    reason?: string | undefined;
    userId: string;
}
export type BatchUserErrorResponseItems = BatchUserErrorResponseItem[];
export interface BatchCreateUserResponse {
    message?: string | undefined;
    successful?: User[] | undefined;
    failed?: BatchUserErrorResponseItem[] | undefined;
}
export type UserIds = string[];
export interface BatchDeleteUserRequest {
    networkId: string;
    userIds: string[];
    clientToken?: string | undefined;
}
export interface BatchUserSuccessResponseItem {
    userId: string;
}
export type BatchUserSuccessResponseItems = BatchUserSuccessResponseItem[];
export interface BatchDeleteUserResponse {
    message?: string | undefined;
    successful?: BatchUserSuccessResponseItem[] | undefined;
    failed?: BatchUserErrorResponseItem[] | undefined;
}
export type Unames = string[];
export interface BatchLookupUserUnameRequest {
    networkId: string;
    unames: string[];
    clientToken?: string | undefined;
}
export type Uname = string;
export interface BatchUnameSuccessResponseItem {
    uname: string;
    username: string;
}
export type BatchUnameSuccessResponseItems = BatchUnameSuccessResponseItem[];
export interface BatchUnameErrorResponseItem {
    field?: string | undefined;
    reason?: string | undefined;
    uname: string;
}
export type BatchUnameErrorResponseItems = BatchUnameErrorResponseItem[];
export interface BatchLookupUserUnameResponse {
    message?: string | undefined;
    successful?: BatchUnameSuccessResponseItem[] | undefined;
    failed?: BatchUnameErrorResponseItem[] | undefined;
}
export interface BatchReinviteUserRequest {
    networkId: string;
    userIds: string[];
    clientToken?: string | undefined;
}
export interface BatchReinviteUserResponse {
    message?: string | undefined;
    successful?: BatchUserSuccessResponseItem[] | undefined;
    failed?: BatchUserErrorResponseItem[] | undefined;
}
export type AppIds = string[];
export interface BatchResetDevicesForUserRequest {
    networkId: string;
    userId: string;
    appIds: string[];
    clientToken?: string | undefined;
}
export interface BatchDeviceSuccessResponseItem {
    appId: string;
}
export type BatchDeviceSuccessResponseItems = BatchDeviceSuccessResponseItem[];
export interface BatchDeviceErrorResponseItem {
    field?: string | undefined;
    reason?: string | undefined;
    appId: string;
}
export type BatchDeviceErrorResponseItems = BatchDeviceErrorResponseItem[];
export interface BatchResetDevicesForUserResponse {
    message?: string | undefined;
    successful?: BatchDeviceSuccessResponseItem[] | undefined;
    failed?: BatchDeviceErrorResponseItem[] | undefined;
}
export interface BatchToggleUserSuspendStatusRequest {
    networkId: string;
    suspend: boolean;
    userIds: string[];
    clientToken?: string | undefined;
}
export interface BatchToggleUserSuspendStatusResponse {
    message?: string | undefined;
    successful?: BatchUserSuccessResponseItem[] | undefined;
    failed?: BatchUserErrorResponseItem[] | undefined;
}
export interface CreateBotRequest {
    networkId: string;
    username: string;
    displayName?: string | undefined;
    groupId: string;
    challenge: string | redacted.Redacted<string>;
}
export type BotId = string;
export interface CreateBotResponse {
    message?: string | undefined;
    botId: string;
    networkId?: string | undefined;
    username?: string | undefined;
    displayName?: string | undefined;
    groupId?: string | undefined;
}
export interface CreateDataRetentionBotRequest {
    networkId: string;
}
export interface CreateDataRetentionBotResponse {
    message?: string | undefined;
}
export interface CreateDataRetentionBotChallengeRequest {
    networkId: string;
}
export interface CreateDataRetentionBotChallengeResponse {
    challenge: string | redacted.Redacted<string>;
}
export type AccessLevel = "STANDARD" | "PREMIUM" | (string & {});
export interface CreateNetworkRequest {
    networkName: string;
    accessLevel: AccessLevel;
    enablePremiumFreeTrial?: boolean | undefined;
    encryptionKeyArn?: string | undefined;
}
export interface CreateNetworkResponse {
    networkId?: string | undefined;
    networkName?: string | undefined;
    encryptionKeyArn?: string | undefined;
}
export type PermittedNetworksList = string[];
export interface WickrAwsNetworks {
    region: string;
    networkId: string;
}
export type WickrAwsNetworksList = WickrAwsNetworks[];
export interface PermittedWickrEnterpriseNetwork {
    domain: string;
    networkId: string;
}
export type PermittedWickrEnterpriseNetworksList = PermittedWickrEnterpriseNetwork[];
export interface SecurityGroupSettingsRequest {
    lockoutThreshold?: number | undefined;
    permittedNetworks?: string[] | undefined;
    enableGuestFederation?: boolean | undefined;
    globalFederation?: boolean | undefined;
    federationMode?: number | undefined;
    enableRestrictedGlobalFederation?: boolean | undefined;
    permittedWickrAwsNetworks?: WickrAwsNetworks[] | undefined;
    permittedWickrEnterpriseNetworks?: PermittedWickrEnterpriseNetwork[] | undefined;
}
export interface CreateSecurityGroupRequest {
    networkId: string;
    name: string;
    securityGroupSettings: SecurityGroupSettingsRequest;
    clientToken?: string | undefined;
}
export type SecurityGroupStringList = string[];
export interface CallingSettings {
    canStart11Call?: boolean | undefined;
    canVideoCall?: boolean | undefined;
    forceTcpCall?: boolean | undefined;
}
export interface PasswordRequirements {
    lowercase?: number | undefined;
    minLength?: number | undefined;
    numbers?: number | undefined;
    symbols?: number | undefined;
    uppercase?: number | undefined;
}
export interface ShredderSettings {
    canProcessManually?: boolean | undefined;
    intensity?: number | undefined;
}
export interface SecurityGroupSettings {
    alwaysReauthenticate?: boolean | undefined;
    atakPackageValues?: string[] | undefined;
    calling?: CallingSettings | undefined;
    checkForUpdates?: boolean | undefined;
    enableAtak?: boolean | undefined;
    enableCrashReports?: boolean | undefined;
    enableFileDownload?: boolean | undefined;
    enableGuestFederation?: boolean | undefined;
    enableNotificationPreview?: boolean | undefined;
    enableOpenAccessOption?: boolean | undefined;
    enableRestrictedGlobalFederation?: boolean | undefined;
    filesEnabled?: boolean | undefined;
    forceDeviceLockout?: number | undefined;
    forceOpenAccess?: boolean | undefined;
    forceReadReceipts?: boolean | undefined;
    globalFederation?: boolean | undefined;
    isAtoEnabled?: boolean | undefined;
    isLinkPreviewEnabled?: boolean | undefined;
    locationAllowMaps?: boolean | undefined;
    locationEnabled?: boolean | undefined;
    maxAutoDownloadSize?: number | undefined;
    maxBor?: number | undefined;
    maxTtl?: number | undefined;
    messageForwardingEnabled?: boolean | undefined;
    passwordRequirements?: PasswordRequirements | undefined;
    presenceEnabled?: boolean | undefined;
    quickResponses?: string[] | undefined;
    showMasterRecoveryKey?: boolean | undefined;
    shredder?: ShredderSettings | undefined;
    ssoMaxIdleMinutes?: number | undefined;
    maxNonSsoSessionMinutes?: number | undefined;
    federationMode?: number | undefined;
    lockoutThreshold?: number | undefined;
    permittedNetworks?: string[] | undefined;
    permittedWickrAwsNetworks?: WickrAwsNetworks[] | undefined;
    permittedWickrEnterpriseNetworks?: PermittedWickrEnterpriseNetwork[] | undefined;
}
export interface SecurityGroup {
    activeMembers: number;
    botMembers: number;
    activeDirectoryGuid?: string | undefined;
    id: string;
    isDefault: boolean;
    name: string;
    modified: number;
    securityGroupSettings: SecurityGroupSettings;
}
export interface CreateSecurityGroupResponse {
    securityGroup: SecurityGroup;
}
export interface DeleteBotRequest {
    networkId: string;
    botId: string;
}
export interface DeleteBotResponse {
    message?: string | undefined;
}
export interface DeleteDataRetentionBotRequest {
    networkId: string;
}
export interface DeleteDataRetentionBotResponse {
    message?: string | undefined;
}
export interface DeleteNetworkRequest {
    networkId: string;
    clientToken?: string | undefined;
}
export interface DeleteNetworkResponse {
    message?: string | undefined;
}
export interface DeleteSecurityGroupRequest {
    networkId: string;
    groupId: string;
}
export interface DeleteSecurityGroupResponse {
    message?: string | undefined;
    networkId?: string | undefined;
    groupId?: string | undefined;
}
export interface GetBotRequest {
    networkId: string;
    botId: string;
}
export type BotStatus = 1 | 2 | (number & {});
export interface GetBotResponse {
    botId?: string | undefined;
    displayName?: string | undefined;
    username?: string | undefined;
    uname?: string | undefined;
    pubkey?: string | undefined;
    status?: BotStatus | undefined;
    groupId?: string | undefined;
    hasChallenge?: boolean | undefined;
    suspended?: boolean | undefined;
    lastLogin?: string | undefined;
}
export interface GetBotsCountRequest {
    networkId: string;
}
export interface GetBotsCountResponse {
    pending: number;
    active: number;
    total: number;
}
export interface GetDataRetentionBotRequest {
    networkId: string;
}
export interface GetDataRetentionBotResponse {
    botName?: string | undefined;
    botExists?: boolean | undefined;
    isBotActive?: boolean | undefined;
    isDataRetentionBotRegistered?: boolean | undefined;
    isDataRetentionServiceEnabled?: boolean | undefined;
    isPubkeyMsgAcked?: boolean | undefined;
}
export interface GetGuestUserHistoryCountRequest {
    networkId: string;
}
export interface GuestUserHistoryCount {
    month: string;
    count: string;
}
export type GuestUserHistoryCountList = GuestUserHistoryCount[];
export interface GetGuestUserHistoryCountResponse {
    history: GuestUserHistoryCount[];
}
export interface GetNetworkRequest {
    networkId: string;
}
export interface GetNetworkResponse {
    networkId: string;
    networkName: string;
    accessLevel: AccessLevel;
    awsAccountId: string;
    networkArn: string;
    standing?: number | undefined;
    freeTrialExpiration?: string | undefined;
    migrationState?: number | undefined;
    encryptionKeyArn?: string | undefined;
}
export interface GetNetworkSettingsRequest {
    networkId: string;
}
export interface Setting {
    optionName: string;
    value: string;
    type: string;
}
export type SettingsList = Setting[];
export interface GetNetworkSettingsResponse {
    settings: Setting[];
}
export interface GetOidcInfoRequest {
    networkId: string;
    clientId?: string | undefined;
    code?: string | undefined;
    grantType?: string | undefined;
    redirectUri?: string | undefined;
    url?: string | undefined;
    clientSecret?: string | redacted.Redacted<string> | undefined;
    codeVerifier?: string | undefined;
    certificate?: string | undefined;
}
export interface OidcConfigInfo {
    applicationName?: string | undefined;
    clientId?: string | undefined;
    companyId: string;
    scopes: string;
    issuer: string;
    clientSecret?: string | redacted.Redacted<string> | undefined;
    secret?: string | redacted.Redacted<string> | undefined;
    redirectUrl?: string | undefined;
    userId?: string | undefined;
    customUsername?: string | undefined;
    caCertificate?: string | undefined;
    applicationId?: number | undefined;
    ssoTokenBufferMinutes?: number | undefined;
    extraAuthParams?: string | undefined;
}
export interface OidcTokenInfo {
    codeVerifier?: string | undefined;
    codeChallenge?: string | undefined;
    accessToken?: string | undefined;
    idToken?: string | undefined;
    refreshToken?: string | undefined;
    tokenType?: string | undefined;
    expiresIn?: number | undefined;
}
export interface GetOidcInfoResponse {
    openidConnectInfo?: OidcConfigInfo | undefined;
    tokenInfo?: OidcTokenInfo | undefined;
}
export interface GetOpentdfConfigRequest {
    networkId: string;
}
export interface GetOpentdfConfigResponse {
    clientId: string;
    domain: string;
    clientSecret: string | redacted.Redacted<string>;
    provider: string;
}
export interface GetSecurityGroupRequest {
    networkId: string;
    groupId: string;
}
export interface GetSecurityGroupResponse {
    securityGroup: SecurityGroup;
}
export interface GetUserRequest {
    networkId: string;
    userId: string;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export interface GetUserResponse {
    userId: string;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    username?: string | undefined;
    isAdmin?: boolean | undefined;
    suspended?: boolean | undefined;
    status?: number | undefined;
    lastActivity?: number | undefined;
    lastLogin?: number | undefined;
    securityGroupIds?: string[] | undefined;
}
export interface GetUsersCountRequest {
    networkId: string;
}
export interface GetUsersCountResponse {
    pending: number;
    active: number;
    rejected: number;
    remaining: number;
    total: number;
}
export type SortDirection = "ASC" | "DESC" | (string & {});
export interface ListBlockedGuestUsersRequest {
    networkId: string;
    maxResults?: number | undefined;
    sortDirection?: SortDirection | undefined;
    sortFields?: string | undefined;
    username?: string | undefined;
    admin?: string | undefined;
    nextToken?: string | undefined;
}
export interface BlockedGuestUser {
    username: string;
    admin: string;
    modified: string;
    usernameHash: string;
}
export type BlockedGuestUserList = BlockedGuestUser[];
export interface ListBlockedGuestUsersResponse {
    nextToken?: string | undefined;
    blocklist: BlockedGuestUser[];
}
export interface ListBotsRequest {
    networkId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sortFields?: string | undefined;
    sortDirection?: SortDirection | undefined;
    displayName?: string | undefined;
    username?: string | undefined;
    status?: BotStatus | undefined;
    groupId?: string | undefined;
}
export interface Bot {
    botId?: string | undefined;
    displayName?: string | undefined;
    username?: string | undefined;
    uname?: string | undefined;
    pubkey?: string | undefined;
    status?: BotStatus | undefined;
    groupId?: string | undefined;
    hasChallenge?: boolean | undefined;
    suspended?: boolean | undefined;
    lastLogin?: string | undefined;
}
export type Bots = Bot[];
export interface ListBotsResponse {
    bots: Bot[];
    nextToken?: string | undefined;
}
export interface ListDevicesForUserRequest {
    networkId: string;
    userId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sortFields?: string | undefined;
    sortDirection?: SortDirection | undefined;
}
export interface BasicDeviceObject {
    appId?: string | undefined;
    created?: string | undefined;
    lastLogin?: string | undefined;
    statusText?: string | undefined;
    suspend?: boolean | undefined;
    type?: string | undefined;
}
export type Devices = BasicDeviceObject[];
export interface ListDevicesForUserResponse {
    nextToken?: string | undefined;
    devices: BasicDeviceObject[];
}
export interface ListGuestUsersRequest {
    networkId: string;
    maxResults?: number | undefined;
    sortDirection?: SortDirection | undefined;
    sortFields?: string | undefined;
    username?: string | undefined;
    billingPeriod?: string | undefined;
    nextToken?: string | undefined;
}
export interface GuestUser {
    billingPeriod: string;
    username: string;
    usernameHash: string;
}
export type GuestUserList = GuestUser[];
export interface ListGuestUsersResponse {
    nextToken?: string | undefined;
    guestlist: GuestUser[];
}
export interface ListNetworksRequest {
    maxResults?: number | undefined;
    sortFields?: string | undefined;
    sortDirection?: SortDirection | undefined;
    nextToken?: string | undefined;
}
export interface Network {
    networkId: string;
    networkName: string;
    accessLevel: AccessLevel;
    awsAccountId: string;
    networkArn: string;
    standing?: number | undefined;
    freeTrialExpiration?: string | undefined;
    migrationState?: number | undefined;
    encryptionKeyArn?: string | undefined;
}
export type NetworkList = Network[];
export interface ListNetworksResponse {
    networks: Network[];
    nextToken?: string | undefined;
}
export interface ListSecurityGroupsRequest {
    networkId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sortFields?: string | undefined;
    sortDirection?: SortDirection | undefined;
}
export type SecurityGroupList = SecurityGroup[];
export interface ListSecurityGroupsResponse {
    securityGroups?: SecurityGroup[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSecurityGroupUsersRequest {
    networkId: string;
    groupId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sortFields?: string | undefined;
    sortDirection?: SortDirection | undefined;
}
export interface ListSecurityGroupUsersResponse {
    users: User[];
    nextToken?: string | undefined;
}
export type UserStatus = 1 | 2 | (number & {});
export interface ListUsersRequest {
    networkId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sortFields?: string | undefined;
    sortDirection?: SortDirection | undefined;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    username?: string | undefined;
    status?: UserStatus | undefined;
    groupId?: string | undefined;
}
export interface ListUsersResponse {
    nextToken?: string | undefined;
    users?: User[] | undefined;
}
export interface RegisterOidcConfigRequest {
    networkId: string;
    companyId: string;
    customUsername?: string | undefined;
    extraAuthParams?: string | undefined;
    issuer: string;
    scopes: string;
    secret?: string | redacted.Redacted<string> | undefined;
    ssoTokenBufferMinutes?: number | undefined;
    userId?: string | undefined;
}
export interface RegisterOidcConfigResponse {
    applicationName?: string | undefined;
    clientId?: string | undefined;
    companyId: string;
    scopes: string;
    issuer: string;
    clientSecret?: string | redacted.Redacted<string> | undefined;
    secret?: string | redacted.Redacted<string> | undefined;
    redirectUrl?: string | undefined;
    userId?: string | undefined;
    customUsername?: string | undefined;
    caCertificate?: string | undefined;
    applicationId?: number | undefined;
    ssoTokenBufferMinutes?: number | undefined;
    extraAuthParams?: string | undefined;
}
export interface RegisterOidcConfigTestRequest {
    networkId: string;
    extraAuthParams?: string | undefined;
    issuer: string;
    scopes: string;
    certificate?: string | undefined;
}
export type StringList = string[];
export interface RegisterOidcConfigTestResponse {
    tokenEndpoint?: string | undefined;
    userinfoEndpoint?: string | undefined;
    responseTypesSupported?: string[] | undefined;
    scopesSupported?: string[] | undefined;
    issuer?: string | undefined;
    authorizationEndpoint?: string | undefined;
    endSessionEndpoint?: string | undefined;
    logoutEndpoint?: string | undefined;
    grantTypesSupported?: string[] | undefined;
    revocationEndpoint?: string | undefined;
    tokenEndpointAuthMethodsSupported?: string[] | undefined;
    microsoftMultiRefreshToken?: boolean | undefined;
}
export interface RegisterOpentdfConfigRequest {
    networkId: string;
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    domain: string;
    provider: string;
    dryRun?: boolean | undefined;
}
export interface RegisterOpentdfConfigResponse {
    clientId: string;
    domain: string;
    clientSecret: string | redacted.Redacted<string>;
    provider: string;
}
export interface UpdateBotRequest {
    networkId: string;
    botId: string;
    displayName?: string | undefined;
    groupId?: string | undefined;
    challenge?: string | redacted.Redacted<string> | undefined;
    suspend?: boolean | undefined;
}
export interface UpdateBotResponse {
    message?: string | undefined;
}
export type DataRetentionActionType = "ENABLE" | "DISABLE" | "PUBKEY_MSG_ACK" | (string & {});
export interface UpdateDataRetentionRequest {
    networkId: string;
    actionType: DataRetentionActionType;
}
export interface UpdateDataRetentionResponse {
    message?: string | undefined;
}
export interface UpdateGuestUserRequest {
    networkId: string;
    usernameHash: string;
    block: boolean;
}
export interface UpdateGuestUserResponse {
    message?: string | undefined;
}
export interface UpdateNetworkRequest {
    networkId: string;
    networkName: string;
    clientToken?: string | undefined;
    encryptionKeyArn?: string | undefined;
}
export interface UpdateNetworkResponse {
    message?: string | undefined;
}
export type Status = "DISABLED" | "ENABLED" | "FORCE_ENABLED" | (string & {});
export interface ReadReceiptConfig {
    status?: Status | undefined;
}
export interface ConsentPopupConfig {
    enabled: boolean;
    header?: string | undefined;
    content?: string | undefined;
    closeButtonLabel?: string | undefined;
}
export interface NetworkSettings {
    enableClientMetrics?: boolean | undefined;
    readReceiptConfig?: ReadReceiptConfig | undefined;
    dataRetention?: boolean | undefined;
    enableTrustedDataFormat?: boolean | undefined;
    consentPopup?: ConsentPopupConfig | undefined;
}
export interface UpdateNetworkSettingsRequest {
    networkId: string;
    settings: NetworkSettings;
}
export interface UpdateNetworkSettingsResponse {
    settings: Setting[];
}
export interface UpdateSecurityGroupRequest {
    networkId: string;
    groupId: string;
    name?: string | undefined;
    securityGroupSettings?: SecurityGroupSettings | undefined;
}
export interface UpdateSecurityGroupResponse {
    securityGroup: SecurityGroup;
}
export interface UpdateUserDetails {
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    username?: string | undefined;
    securityGroupIds?: string[] | undefined;
    inviteCode?: string | undefined;
    inviteCodeTtl?: number | undefined;
    codeValidation?: boolean | undefined;
}
export interface UpdateUserRequest {
    networkId: string;
    userId: string;
    userDetails?: UpdateUserDetails | undefined;
}
export interface UpdateUserResponse {
    userId: string;
    networkId: string;
    securityGroupIds?: string[] | undefined;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    middleName?: string | undefined;
    suspended: boolean;
    modified?: number | undefined;
    status?: number | undefined;
    inviteCode?: string | undefined;
    inviteExpiration?: number | undefined;
    codeValidation?: boolean | undefined;
}
export interface ErrorDetail {
    field?: string | undefined;
    reason?: string | undefined;
}
export type ErrorDetailList = ErrorDetail[];
export type BatchCreateUserError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Creates multiple users in a specified Wickr network. This operation allows you to provision multiple user accounts simultaneously, optionally specifying security groups, and validation requirements for each user.
 *
 * `codeValidation`, `inviteCode`, and `inviteCodeTtl` are restricted to networks under preview only.
 */
export declare const batchCreateUser: API.OperationMethod<BatchCreateUserRequest & RegionInput, BatchCreateUserResponse, BatchCreateUserError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteUserError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Deletes multiple users from a specified Wickr network. This operation permanently removes user accounts and their associated data from the network.
 */
export declare const batchDeleteUser: API.OperationMethod<BatchDeleteUserRequest & RegionInput, BatchDeleteUserResponse, BatchDeleteUserError, Credentials | HttpClient.HttpClient>;
export type BatchLookupUserUnameError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Looks up multiple user usernames from their unique username hashes (unames). This operation allows you to retrieve the email addresses associated with a list of username hashes.
 */
export declare const batchLookupUserUname: API.OperationMethod<BatchLookupUserUnameRequest & RegionInput, BatchLookupUserUnameResponse, BatchLookupUserUnameError, Credentials | HttpClient.HttpClient>;
export type BatchReinviteUserError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Resends invitation codes to multiple users who have pending invitations in a Wickr network. This operation is useful when users haven't accepted their initial invitations or when invitations have expired.
 */
export declare const batchReinviteUser: API.OperationMethod<BatchReinviteUserRequest & RegionInput, BatchReinviteUserResponse, BatchReinviteUserError, Credentials | HttpClient.HttpClient>;
export type BatchResetDevicesForUserError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Resets multiple devices for a specific user in a Wickr network. This operation forces the selected devices to log out and requires users to re-authenticate, which is useful for security purposes or when devices need to be revoked.
 */
export declare const batchResetDevicesForUser: API.OperationMethod<BatchResetDevicesForUserRequest & RegionInput, BatchResetDevicesForUserResponse, BatchResetDevicesForUserError, Credentials | HttpClient.HttpClient>;
export type BatchToggleUserSuspendStatusError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Suspends or unsuspends multiple users in a Wickr network. Suspended users cannot access the network until they are unsuspended. This operation is useful for temporarily restricting access without deleting user accounts.
 */
export declare const batchToggleUserSuspendStatus: API.OperationMethod<BatchToggleUserSuspendStatusRequest & RegionInput, BatchToggleUserSuspendStatusResponse, BatchToggleUserSuspendStatusError, Credentials | HttpClient.HttpClient>;
export type CreateBotError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Creates a new bot in a specified Wickr network. Bots are automated accounts that can send and receive messages, enabling integration with external systems and automation of tasks.
 */
export declare const createBot: API.OperationMethod<CreateBotRequest & RegionInput, CreateBotResponse, CreateBotError, Credentials | HttpClient.HttpClient>;
export type CreateDataRetentionBotError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Creates a data retention bot in a Wickr network. Data retention bots are specialized bots that handle message archiving and compliance by capturing and storing messages for regulatory or organizational requirements.
 */
export declare const createDataRetentionBot: API.OperationMethod<CreateDataRetentionBotRequest & RegionInput, CreateDataRetentionBotResponse, CreateDataRetentionBotError, Credentials | HttpClient.HttpClient>;
export type CreateDataRetentionBotChallengeError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Creates a new challenge password for the data retention bot. This password is used for authentication when the bot connects to the network.
 */
export declare const createDataRetentionBotChallenge: API.OperationMethod<CreateDataRetentionBotChallengeRequest & RegionInput, CreateDataRetentionBotChallengeResponse, CreateDataRetentionBotChallengeError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Creates a new Wickr network with specified access level and configuration. This operation provisions a new communication network for your organization.
 */
export declare const createNetwork: API.OperationMethod<CreateNetworkRequest & RegionInput, CreateNetworkResponse, CreateNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityGroupError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Creates a new security group in a Wickr network. Security groups allow you to organize users and control their permissions, features, and security settings.
 */
export declare const createSecurityGroup: API.OperationMethod<CreateSecurityGroupRequest & RegionInput, CreateSecurityGroupResponse, CreateSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteBotError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Deletes a bot from a specified Wickr network. This operation permanently removes the bot account and its associated data from the network.
 */
export declare const deleteBot: API.OperationMethod<DeleteBotRequest & RegionInput, DeleteBotResponse, DeleteBotError, Credentials | HttpClient.HttpClient>;
export type DeleteDataRetentionBotError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Deletes the data retention bot from a Wickr network. This operation permanently removes the bot and all its associated data from the database.
 */
export declare const deleteDataRetentionBot: API.OperationMethod<DeleteDataRetentionBotRequest & RegionInput, DeleteDataRetentionBotResponse, DeleteDataRetentionBotError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Deletes a Wickr network and all its associated resources, including users, bots, security groups, and settings. This operation is permanent and cannot be undone.
 */
export declare const deleteNetwork: API.OperationMethod<DeleteNetworkRequest & RegionInput, DeleteNetworkResponse, DeleteNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityGroupError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Deletes a security group from a Wickr network. This operation cannot be performed on the default security group.
 */
export declare const deleteSecurityGroup: API.OperationMethod<DeleteSecurityGroupRequest & RegionInput, DeleteSecurityGroupResponse, DeleteSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type GetBotError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves detailed information about a specific bot in a Wickr network, including its status, group membership, and authentication details.
 */
export declare const getBot: API.OperationMethod<GetBotRequest & RegionInput, GetBotResponse, GetBotError, Credentials | HttpClient.HttpClient>;
export type GetBotsCountError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves the count of bots in a Wickr network, categorized by their status (pending, active, and total).
 */
export declare const getBotsCount: API.OperationMethod<GetBotsCountRequest & RegionInput, GetBotsCountResponse, GetBotsCountError, Credentials | HttpClient.HttpClient>;
export type GetDataRetentionBotError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves information about the data retention bot in a Wickr network, including its status and whether the data retention service is enabled.
 */
export declare const getDataRetentionBot: API.OperationMethod<GetDataRetentionBotRequest & RegionInput, GetDataRetentionBotResponse, GetDataRetentionBotError, Credentials | HttpClient.HttpClient>;
export type GetGuestUserHistoryCountError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves historical guest user count data for a Wickr network, showing the number of guest users per billing period over the past 90 days.
 */
export declare const getGuestUserHistoryCount: API.OperationMethod<GetGuestUserHistoryCountRequest & RegionInput, GetGuestUserHistoryCountResponse, GetGuestUserHistoryCountError, Credentials | HttpClient.HttpClient>;
export type GetNetworkError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves detailed information about a specific Wickr network, including its configuration, access level, and status.
 */
export declare const getNetwork: API.OperationMethod<GetNetworkRequest & RegionInput, GetNetworkResponse, GetNetworkError, Credentials | HttpClient.HttpClient>;
export type GetNetworkSettingsError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves all network-level settings for a Wickr network, including client metrics, data retention, and other configuration options.
 */
export declare const getNetworkSettings: API.OperationMethod<GetNetworkSettingsRequest & RegionInput, GetNetworkSettingsResponse, GetNetworkSettingsError, Credentials | HttpClient.HttpClient>;
export type GetOidcInfoError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves the OpenID Connect (OIDC) configuration for a Wickr network, including SSO settings and optional token information if access token parameters are provided.
 */
export declare const getOidcInfo: API.OperationMethod<GetOidcInfoRequest & RegionInput, GetOidcInfoResponse, GetOidcInfoError, Credentials | HttpClient.HttpClient>;
export type GetOpentdfConfigError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves the OpenTDF integration configuration for a Wickr network.
 */
export declare const getOpentdfConfig: API.OperationMethod<GetOpentdfConfigRequest & RegionInput, GetOpentdfConfigResponse, GetOpentdfConfigError, Credentials | HttpClient.HttpClient>;
export type GetSecurityGroupError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves detailed information about a specific security group in a Wickr network, including its settings, member counts, and configuration.
 */
export declare const getSecurityGroup: API.OperationMethod<GetSecurityGroupRequest & RegionInput, GetSecurityGroupResponse, GetSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type GetUserError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves detailed information about a specific user in a Wickr network, including their profile, status, and activity history.
 */
export declare const getUser: API.OperationMethod<GetUserRequest & RegionInput, GetUserResponse, GetUserError, Credentials | HttpClient.HttpClient>;
export type GetUsersCountError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves the count of users in a Wickr network, categorized by their status (pending, active, rejected) and showing how many users can still be added.
 */
export declare const getUsersCount: API.OperationMethod<GetUsersCountRequest & RegionInput, GetUsersCountResponse, GetUsersCountError, Credentials | HttpClient.HttpClient>;
export type ListBlockedGuestUsersError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves a paginated list of guest users who have been blocked from a Wickr network. You can filter and sort the results.
 */
export declare const listBlockedGuestUsers: API.PaginatedOperationMethod<ListBlockedGuestUsersRequest & RegionInput, ListBlockedGuestUsersResponse, ListBlockedGuestUsersError, Credentials | HttpClient.HttpClient, BlockedGuestUser>;
export type ListBotsError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves a paginated list of bots in a specified Wickr network. You can filter and sort the results based on various criteria.
 */
export declare const listBots: API.PaginatedOperationMethod<ListBotsRequest & RegionInput, ListBotsResponse, ListBotsError, Credentials | HttpClient.HttpClient, Bot>;
export type ListDevicesForUserError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves a paginated list of devices associated with a specific user in a Wickr network. This operation returns information about all devices where the user has logged into Wickr.
 */
export declare const listDevicesForUser: API.PaginatedOperationMethod<ListDevicesForUserRequest & RegionInput, ListDevicesForUserResponse, ListDevicesForUserError, Credentials | HttpClient.HttpClient, BasicDeviceObject>;
export type ListGuestUsersError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves a paginated list of guest users who have communicated with your Wickr network. Guest users are external users from federated networks who can communicate with network members.
 */
export declare const listGuestUsers: API.PaginatedOperationMethod<ListGuestUsersRequest & RegionInput, ListGuestUsersResponse, ListGuestUsersError, Credentials | HttpClient.HttpClient, GuestUser>;
export type ListNetworksError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves a paginated list of all Wickr networks associated with your Amazon Web Services account. You can sort the results by network ID or name.
 */
export declare const listNetworks: API.PaginatedOperationMethod<ListNetworksRequest & RegionInput, ListNetworksResponse, ListNetworksError, Credentials | HttpClient.HttpClient, Network>;
export type ListSecurityGroupsError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves a paginated list of security groups in a specified Wickr network. You can sort the results by various criteria.
 */
export declare const listSecurityGroups: API.PaginatedOperationMethod<ListSecurityGroupsRequest & RegionInput, ListSecurityGroupsResponse, ListSecurityGroupsError, Credentials | HttpClient.HttpClient, SecurityGroup>;
export type ListSecurityGroupUsersError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves a paginated list of users who belong to a specific security group in a Wickr network.
 */
export declare const listSecurityGroupUsers: API.PaginatedOperationMethod<ListSecurityGroupUsersRequest & RegionInput, ListSecurityGroupUsersResponse, ListSecurityGroupUsersError, Credentials | HttpClient.HttpClient, User>;
export type ListUsersError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Retrieves a paginated list of users in a specified Wickr network. You can filter and sort the results based on various criteria such as name, status, or security group membership.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest & RegionInput, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, User>;
export type RegisterOidcConfigError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Registers and saves an OpenID Connect (OIDC) configuration for a Wickr network, enabling Single Sign-On (SSO) authentication through an identity provider.
 */
export declare const registerOidcConfig: API.OperationMethod<RegisterOidcConfigRequest & RegionInput, RegisterOidcConfigResponse, RegisterOidcConfigError, Credentials | HttpClient.HttpClient>;
export type RegisterOidcConfigTestError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Tests an OpenID Connect (OIDC) configuration for a Wickr network by validating the connection to the identity provider and retrieving its supported capabilities.
 */
export declare const registerOidcConfigTest: API.OperationMethod<RegisterOidcConfigTestRequest & RegionInput, RegisterOidcConfigTestResponse, RegisterOidcConfigTestError, Credentials | HttpClient.HttpClient>;
export type RegisterOpentdfConfigError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Registers and saves OpenTDF configuration for a Wickr network, enabling attribute-based access control for Wickr through an OpenTDF provider.
 */
export declare const registerOpentdfConfig: API.OperationMethod<RegisterOpentdfConfigRequest & RegionInput, RegisterOpentdfConfigResponse, RegisterOpentdfConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateBotError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Updates the properties of an existing bot in a Wickr network. This operation allows you to modify the bot's display name, security group, password, or suspension status.
 */
export declare const updateBot: API.OperationMethod<UpdateBotRequest & RegionInput, UpdateBotResponse, UpdateBotError, Credentials | HttpClient.HttpClient>;
export type UpdateDataRetentionError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Updates the data retention bot settings, allowing you to enable or disable the data retention service, or acknowledge the public key message.
 */
export declare const updateDataRetention: API.OperationMethod<UpdateDataRetentionRequest & RegionInput, UpdateDataRetentionResponse, UpdateDataRetentionError, Credentials | HttpClient.HttpClient>;
export type UpdateGuestUserError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Updates the block status of a guest user in a Wickr network. This operation allows you to block or unblock a guest user from accessing the network.
 */
export declare const updateGuestUser: API.OperationMethod<UpdateGuestUserRequest & RegionInput, UpdateGuestUserResponse, UpdateGuestUserError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Updates the properties of an existing Wickr network, such as its name or encryption key configuration.
 */
export declare const updateNetwork: API.OperationMethod<UpdateNetworkRequest & RegionInput, UpdateNetworkResponse, UpdateNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkSettingsError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Updates network-level settings for a Wickr network. You can modify settings such as client metrics, data retention, and other network-wide options.
 */
export declare const updateNetworkSettings: API.OperationMethod<UpdateNetworkSettingsRequest & RegionInput, UpdateNetworkSettingsResponse, UpdateNetworkSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityGroupError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Updates the properties of an existing security group in a Wickr network, such as its name or settings.
 */
export declare const updateSecurityGroup: API.OperationMethod<UpdateSecurityGroupRequest & RegionInput, UpdateSecurityGroupResponse, UpdateSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = BadRequestError | ForbiddenError | InternalServerError | RateLimitError | ResourceNotFoundError | UnauthorizedError | ValidationError | CommonErrors;
/**
 * Updates the properties of an existing user in a Wickr network. This operation allows you to modify the user's name, password, security group membership, and invite code settings.
 *
 * `codeValidation`, `inviteCode`, and `inviteCodeTtl` are restricted to networks under preview only.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=wickr.d.ts.map