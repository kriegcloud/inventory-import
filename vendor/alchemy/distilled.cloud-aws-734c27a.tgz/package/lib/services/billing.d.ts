import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BillingViewHealthStatusException_base: S.TaggedErrorClass<"BillingViewHealthStatusException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BillingViewHealthStatusException extends /*@__PURE__*/ BillingViewHealthStatusException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ArnString = string;
export type ContractDocumentId = string | redacted.Redacted<string>;
export interface AssociateContractRequest {
    contractArn: string;
    contractDocumentId: string | redacted.Redacted<string>;
}
export interface AssociateContractResponse {
}
export type BillingViewArn = string;
export type BillingViewSourceViewsList = string[];
export interface AssociateSourceViewsRequest {
    arn: string;
    sourceViews: string[];
}
export interface AssociateSourceViewsResponse {
    arn: string;
}
export type IdentifierString = string;
export type CancellationReason = string;
export interface CancelContractualInvestmentAttestationRequest {
    attestationId: string;
    contractArn: string;
    reason: string;
}
export interface CancelContractualInvestmentAttestationResponse {
}
export type BillingViewName = string | redacted.Redacted<string>;
export type BillingViewDescription = string | redacted.Redacted<string>;
export type Dimension = "LINKED_ACCOUNT" | (string & {});
export type Value = string;
export type Values = string[];
export interface DimensionValues {
    key: Dimension;
    values: string[];
}
export type TagKey = string;
export interface TagValues {
    key: string;
    values: string[];
}
export type CostCategoryName = string;
export interface CostCategoryValues {
    key: string;
    values: string[];
}
export interface TimeRange {
    beginDateInclusive?: Date | undefined;
    endDateInclusive?: Date | undefined;
}
export interface Expression {
    dimensions?: DimensionValues | undefined;
    tags?: TagValues | undefined;
    costCategories?: CostCategoryValues | undefined;
    timeRange?: TimeRange | undefined;
}
export type ClientToken = string;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    key: string;
    value?: string | undefined;
}
export type ResourceTagList = ResourceTag[];
export interface CreateBillingViewRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    sourceViews: string[];
    dataFilterExpression?: Expression | undefined;
    clientToken?: string | undefined;
    resourceTags?: ResourceTag[] | undefined;
}
export interface CreateBillingViewResponse {
    arn: string;
    createdAt?: Date | undefined;
}
export type SensitiveString = string | redacted.Redacted<string>;
export type SensitiveEmail = string | redacted.Redacted<string>;
export interface ApproverDetails {
    name: string | redacted.Redacted<string>;
    title: string | redacted.Redacted<string>;
    email: string | redacted.Redacted<string>;
}
export type CurrencyCode = string;
export type CurrencyAmount = string;
export interface Amount {
    currencyCode: string;
    currencyAmount: string;
}
export interface AttestationQuantity {
    attestationVolume: string;
    attestationUnit: string;
}
export type AttestationQuantities = AttestationQuantity[];
export type AttestationValue = {
    attestationAmount: Amount;
    attestationQuantities?: undefined;
} | {
    attestationAmount?: undefined;
    attestationQuantities: AttestationQuantity[];
};
export type AccountId = string;
export interface InvestmentDistribution {
    accountId: string;
    investmentAmount: Amount;
}
export type InvestmentDistributions = InvestmentDistribution[];
export interface AttestationDetails {
    attestationValue: AttestationValue;
    investmentDistributions?: InvestmentDistribution[] | undefined;
}
export interface AdditionalRecipient {
    email: string | redacted.Redacted<string>;
}
export type AdditionalRecipients = AdditionalRecipient[];
export type AttestationClientToken = string;
export interface CreateContractualInvestmentAttestationRequest {
    contractArn: string;
    investmentSummaryId: string;
    investmentId: string;
    contractDocumentId: string | redacted.Redacted<string>;
    approverDetails: ApproverDetails;
    investmentDisbursedAt?: Date | undefined;
    attestationDetails: AttestationDetails;
    additionalRecipients?: AdditionalRecipient[] | undefined;
    clientToken?: string | undefined;
}
export interface CreateContractualInvestmentAttestationResponse {
    attestationId: string;
}
export interface DeleteBillingViewRequest {
    arn: string;
    force?: boolean | undefined;
}
export interface DeleteBillingViewResponse {
    arn: string;
}
export interface DisassociateContractRequest {
    contractArn: string;
}
export interface DisassociateContractResponse {
}
export interface DisassociateSourceViewsRequest {
    arn: string;
    sourceViews: string[];
}
export interface DisassociateSourceViewsResponse {
    arn: string;
}
export type PageToken = string;
export type BillingFeature = "RI_SHARING" | "RI_SHARING_HISTORY" | "CREDIT_SHARING" | "CREDIT_SHARING_HISTORY" | "CREDIT_LEVEL_SHARING" | "BILLING_ALERTS" | "CREDIT_PREFERENCE_OPTIONS" | (string & {});
export type BillingFeatures = BillingFeature[];
export type BillingFeatureFilterName = "PREFERENCE_KEY" | (string & {});
export type BillingFeatureFilterValue = string;
export type BillingFeatureFilterValues = string[];
export interface BillingFeatureFilter {
    name?: BillingFeatureFilterName | undefined;
    value?: string[] | undefined;
}
export type BillingFeatureFilters = BillingFeatureFilter[];
export interface GetBillingPreferencesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    features: BillingFeature[];
    filters?: BillingFeatureFilter[] | undefined;
}
export type PreferenceKey = string;
export type PreferenceValue = "ENABLED" | "DISABLED" | (string & {});
export type AccountName = string;
export type BillingYear = number;
export type Month = number;
export interface BillingPeriod {
    year: number;
    month: number;
}
export interface BillingPreferenceSummary {
    feature: BillingFeature;
    key: string;
    value: PreferenceValue;
    accountName?: string | undefined;
    accountId?: string | undefined;
    billingPeriod?: BillingPeriod | undefined;
}
export type BillingPreferences = BillingPreferenceSummary[];
export interface GetBillingPreferencesResponse {
    billingPreferences: BillingPreferenceSummary[];
    nextToken?: string | undefined;
}
export interface GetBillingViewRequest {
    arn: string;
}
export type BillingViewType = "PRIMARY" | "BILLING_GROUP" | "CUSTOM" | "BILLING_TRANSFER" | "BILLING_TRANSFER_SHOWBACK" | (string & {});
export type BillingViewStatus = "HEALTHY" | "UNHEALTHY" | "CREATING" | "UPDATING" | (string & {});
export type BillingViewStatusReason = "SOURCE_VIEW_UNHEALTHY" | "SOURCE_VIEW_UPDATING" | "SOURCE_VIEW_ACCESS_DENIED" | "SOURCE_VIEW_NOT_FOUND" | "CYCLIC_DEPENDENCY" | "SOURCE_VIEW_DEPTH_EXCEEDED" | "AGGREGATE_SOURCE" | "VIEW_OWNER_NOT_MANAGEMENT_ACCOUNT" | (string & {});
export type BillingViewStatusReasons = BillingViewStatusReason[];
export interface BillingViewHealthStatus {
    statusCode?: BillingViewStatus | undefined;
    statusReasons?: BillingViewStatusReason[] | undefined;
}
export interface BillingViewElement {
    arn?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    billingViewType?: BillingViewType | undefined;
    ownerAccountId?: string | undefined;
    sourceAccountId?: string | undefined;
    dataFilterExpression?: Expression | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    derivedViewCount?: number | undefined;
    sourceViewCount?: number | undefined;
    viewDefinitionLastUpdatedAt?: Date | undefined;
    healthStatus?: BillingViewHealthStatus | undefined;
}
export interface GetBillingViewResponse {
    billingView: BillingViewElement;
}
export interface GetContractInformationRequest {
    contractArn: string;
}
export interface Interval {
    startDateInclusive: Date;
    endDateInclusive: Date;
}
export type AccountList = string[];
export interface LegalEntity {
    legalEntityName: string | redacted.Redacted<string>;
}
export type LegalEntities = LegalEntity[];
export type ContractRestriction = "ATTESTATION_SELF_SERVICE_BLOCKED" | (string & {});
export type ContractRestrictions = ContractRestriction[];
export interface PrivatePricingAddendum {
    contractArn: string;
    contractTerm: Interval;
    eligiblePayerAccounts: string[];
    investmentAccounts: string[];
    legalEntities: LegalEntity[];
    contractRestrictions?: ContractRestriction[] | undefined;
}
export type ContractDetails = {
    privatePricingAddendum: PrivatePricingAddendum;
};
export interface GetContractInformationResponse {
    contract: ContractDetails;
}
export interface GetCreditAllocationHistoryRequest {
    accountId: string;
    creditId?: number | undefined;
    startDate: Date;
    endDate: Date;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type CreditId = string;
export type BillingMonth = string;
export interface CreditAllocationHistoryEntry {
    creditId: string;
    creditAmount: Amount;
    description?: string | undefined;
    accountId: string;
    appliedServiceName: string;
    billingMonth: string;
    isEstimatedBill: boolean;
}
export type CreditAllocationHistoryList = CreditAllocationHistoryEntry[];
export type FailedMonthsList = string[];
export interface GetCreditAllocationHistoryResponse {
    creditAllocationHistoryList?: CreditAllocationHistoryEntry[] | undefined;
    partialResults: boolean;
    failedMonths?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface GetCreditsRequest {
    accountId: string;
    startDate: Date;
    endDate?: Date | undefined;
    payerAccountFlag?: boolean | undefined;
}
export type ProductName = string;
export type ProductNames = string[];
export type ApplicationType = "BEFORE_CROSS_SERVICE_DISCOUNTS" | "AFTER_DISCOUNTS" | (string & {});
export type ShareableAccountIds = string[];
export type CreditSharingType = "DEFAULT" | "DISABLED" | "CUSTOM" | "COST_CATEGORY_RULE" | (string & {});
export type CreditStatus = "ENABLED" | "DISABLED" | (string & {});
export type PurchaseType = string;
export type PurchaseTypeApplications = string[];
export interface CreditData {
    creditId: string;
    accountId: string;
    creditType: string;
    initialAmount: Amount;
    remainingAmount: Amount;
    estimatedAmount?: Amount | undefined;
    applicableProductNames?: string[] | undefined;
    description: string;
    startDate: Date;
    endDate?: Date | undefined;
    exhaustDate?: Date | undefined;
    applicationType?: ApplicationType | undefined;
    shareableAccounts?: string[] | undefined;
    accountHasCreditSharingEnabled?: boolean | undefined;
    creditConsoleVisibility?: string | undefined;
    creditSharingType?: CreditSharingType | undefined;
    costCategoryArn?: string | undefined;
    ruleName?: string | undefined;
    creditStatus?: CreditStatus | undefined;
    purchaseTypeApplications?: string[] | undefined;
}
export type CreditDataList = CreditData[];
export interface GetCreditsResponse {
    credits?: CreditData[] | undefined;
}
export type EnterpriseSupportBillingMonth = string;
export interface GetEnterpriseSupportChargeSummaryRequest {
    billingMonth: string;
}
export interface PricingPlanTier {
    tierMinimum: string;
    tierMaximum?: string | undefined;
    baseCharge: string;
    additionalPercentageOfAggregateCharges: string;
    aggregateChargesAdjustment: string;
    incremental: boolean;
    increment?: string | undefined;
    incrementCharge?: string | undefined;
}
export type PricingPlanTierList = PricingPlanTier[];
export interface PricingPlan {
    pricingPlanId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    startDate?: Date | undefined;
    endDate?: Date | undefined;
    planDiscountPercent?: string | undefined;
    discountAppliesToMinimumCharge?: boolean | undefined;
    minimumCharge?: string | undefined;
    tiered?: string | undefined;
    tiers: PricingPlanTier[];
}
export interface GetEnterpriseSupportChargeSummaryResponse {
    payerAccountId: string;
    billingMonth: string;
    billingPeriodStartDate: Date;
    billingPeriodEndDate: Date;
    isEstimated: boolean;
    billDate: Date;
    supportCharge: string;
    totalSupportCharge: string;
    supportDiscount: string;
    totalSupportEligibleSpend: string;
    totalSupportEligibleUsageSpend: string;
    totalSupportEligibleReservedInstanceSpend: string;
    totalSupportEligibleSavingsPlanSpend: string;
    supportChargePercentage: string;
    supportEffectivePricingPlan: PricingPlan;
}
export interface GetEnterpriseSupportContractDetailsRequest {
    billingMonth: string;
}
export interface ContractAccount {
    accountId: string;
    isGdn: boolean;
}
export type ContractAccountList = ContractAccount[];
export interface ChargeAccount {
    accountId: string;
    chargePercentage: string;
}
export type ChargeAccountList = ChargeAccount[];
export interface AdditionalCharge {
    description: string;
    amount?: string | undefined;
    chargeType?: string | undefined;
}
export type AdditionalChargeList = AdditionalCharge[];
export type PricingPlanList = PricingPlan[];
export interface GetEnterpriseSupportContractDetailsResponse {
    isContractActive?: boolean | undefined;
    supportAllocationMethod: string;
    supportReservedInstanceAmortizationStartDate?: Date | undefined;
    supportReservedInstanceTreatmentMethod?: string | undefined;
    supportSavingsPlansAmortizationStartDate?: Date | undefined;
    supportSavingsPlansTreatmentMethod?: string | undefined;
    supportProrateStartDate?: Date | undefined;
    contractPayerAccountIds: ContractAccount[];
    chargedPayerAccountIds: ChargeAccount[];
    additionalSupportCharge?: AdditionalCharge[] | undefined;
    additionalSupportEligibleUsageSpend?: AdditionalCharge[] | undefined;
    pricingPlans: PricingPlan[];
}
export type ResourceArn = string;
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export type PolicyDocument = string;
export interface GetResourcePolicyResponse {
    resourceArn: string;
    policy?: string | undefined;
}
export interface ActiveTimeRange {
    activeAfterInclusive: Date;
    activeBeforeInclusive: Date;
}
export type BillingViewArnList = string[];
export type BillingViewTypeList = BillingViewType[];
export type SearchOption = "STARTS_WITH" | (string & {});
export type SearchValue = string;
export interface StringSearch {
    searchOption: SearchOption;
    searchValue: string;
}
export type StringSearches = StringSearch[];
export type BillingViewsMaxResults = number;
export interface ListBillingViewsRequest {
    activeTimeRange?: ActiveTimeRange | undefined;
    arns?: string[] | undefined;
    billingViewTypes?: BillingViewType[] | undefined;
    names?: StringSearch[] | undefined;
    ownerAccountId?: string | undefined;
    sourceAccountId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BillingViewListElement {
    arn?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    ownerAccountId?: string | undefined;
    sourceAccountId?: string | undefined;
    billingViewType?: BillingViewType | undefined;
    healthStatus?: BillingViewHealthStatus | undefined;
}
export type BillingViewList = BillingViewListElement[];
export interface ListBillingViewsResponse {
    billingViews: BillingViewListElement[];
    nextToken?: string | undefined;
}
export interface BillingViewSegmentTimeRange {
    beginDateInclusive?: Date | undefined;
    endDateExclusive?: Date | undefined;
}
export interface ListBillingViewSegmentsRequest {
    timeRange?: BillingViewSegmentTimeRange | undefined;
    arn?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type BillingDomain = "BILLABLE" | "PRO_FORMA" | (string & {});
export interface BillingViewSegmentsListElement {
    domain?: BillingDomain | undefined;
    timeRange?: BillingViewSegmentTimeRange | undefined;
    billingTransferAccountId?: string | undefined;
    managementAccountId?: string | undefined;
    billingGroupPrimaryAccountId?: string | undefined;
}
export type BillingViewSegmentsList = BillingViewSegmentsListElement[];
export interface ListBillingViewSegmentsResponse {
    items: BillingViewSegmentsListElement[];
    nextToken?: string | undefined;
}
export type BusinessSupportBillingMonth = string;
export interface ListBusinessSupportAccountChargesRequest {
    billingMonth: string;
    accountId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BusinessSupportTierCharge {
    tierDescription: string;
    tierRate: string;
    usageSlice: string;
    tierCharge: string;
    chargePeriodStartDate?: Date | undefined;
    chargePeriodEndDate?: Date | undefined;
}
export type BusinessSupportTierChargeList = BusinessSupportTierCharge[];
export interface BusinessSupportDiscount {
    discountAmount?: string | undefined;
    discountPercentage?: string | undefined;
    discountType?: string | undefined;
    discountSource?: string | undefined;
}
export interface BusinessSupportServiceSpend {
    contributingService: string;
    itemType: string;
    description?: string | undefined;
    chargeAmount: string;
    currency: string;
}
export type BusinessSupportServiceSpendList = BusinessSupportServiceSpend[];
export interface BusinessSupportAccountCharge {
    accountId: string;
    supportPlanName: string;
    totalCharge: string;
    totalUsageBasis: string;
    tierCharges?: BusinessSupportTierCharge[] | undefined;
    supportDiscount?: BusinessSupportDiscount | undefined;
    supportEligibleSpendByService?: BusinessSupportServiceSpend[] | undefined;
}
export type BusinessSupportAccountChargeList = BusinessSupportAccountCharge[];
export interface ListBusinessSupportAccountChargesResponse {
    billingMonth: string;
    isEstimated: boolean;
    totalSupportCharge: string;
    totalSupportEligibleSpend: string;
    accountCount: number;
    accountCharges: BusinessSupportAccountCharge[];
    nextToken?: string | undefined;
}
export interface ListBusinessSupportSubscriptionHistoryRequest {
    billingMonth?: string | undefined;
    accountId?: string | undefined;
    startDate?: Date | undefined;
    endDate?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BusinessSupportSubscriptionContract {
    accountId: string;
    planName: string;
    contractStartDate: Date;
    contractEndDate: Date;
}
export type BusinessSupportSubscriptionContractList = BusinessSupportSubscriptionContract[];
export interface ListBusinessSupportSubscriptionHistoryResponse {
    subscriptionContracts: BusinessSupportSubscriptionContract[];
    nextToken?: string | undefined;
}
export interface ListContractsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ContractType = "Cross-Service" | "Service-Specific" | "Other" | (string & {});
export type AssociationStatus = "ASSOCIATED" | "NOT_ASSOCIATED" | (string & {});
export interface ContractSummary {
    contractArn: string;
    contractTerm: Interval;
    contractType?: ContractType | undefined;
    associationStatus: AssociationStatus;
    lastUpdatedAt?: Date | undefined;
}
export type ContractSummaries = ContractSummary[];
export interface ListContractsResponse {
    items: ContractSummary[];
    nextToken?: string | undefined;
}
export interface ListContractualInvestmentAttestationsRequest {
    contractArn: string;
    investmentSummaryId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type InvestmentAttestationStatus = "PENDING_REVIEW" | "PENDING_C_LEVEL_APPROVAL" | "PENDING_CANCELLATION" | "REJECTED" | "CANCELLED" | "DISBURSED" | (string & {});
export type RejectionReason = string;
export type RejectionReasons = string[];
export interface InvestmentAttestation {
    attestationId: string;
    investmentName: string;
    outcomeDescription: string;
    investmentSummaryId: string;
    investmentId: string;
    attestedAt: Date;
    updatedAt: Date;
    attestationStatus: InvestmentAttestationStatus;
    investmentDisbursedAt?: Date | undefined;
    attestedValue?: Amount | undefined;
    investmentDistributions?: InvestmentDistribution[] | undefined;
    rejectionReasons?: string[] | undefined;
    isCancellable?: boolean | undefined;
}
export type InvestmentAttestations = InvestmentAttestation[];
export interface ListContractualInvestmentAttestationsResponse {
    items: InvestmentAttestation[];
    nextToken?: string | undefined;
}
export interface ListContractualInvestmentsRequest {
    contractArn: string;
    investmentSummaryId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface MilestoneBasedInvestment {
    investmentId: string;
    investmentValue: Amount;
    investmentDisbursedAt: Date;
}
export interface InvestmentRestriction {
    amount: Amount;
}
export type InvestmentRestrictions = InvestmentRestriction[];
export type MultiplierType = "PERCENTAGE" | "CURRENCY_AMOUNT" | (string & {});
export interface InvestmentMultiplier {
    value: string;
    investmentAttestationInputUnit: string;
    multiplierType: MultiplierType;
}
export type InvestmentMultipliers = InvestmentMultiplier[];
export interface OutcomeBasedInvestment {
    investmentId: string;
    outcomeDescription: string;
    attestationWindow: Interval;
    investmentRestrictions?: InvestmentRestriction[] | undefined;
    investmentMultipliers?: InvestmentMultiplier[] | undefined;
    disbursedValue: Amount;
}
export type Investment = {
    milestoneBasedInvestment: MilestoneBasedInvestment;
    outcomeBasedInvestment?: undefined;
} | {
    milestoneBasedInvestment?: undefined;
    outcomeBasedInvestment: OutcomeBasedInvestment;
};
export type Investments = Investment[];
export interface ListContractualInvestmentsResponse {
    items: Investment[];
    nextToken?: string | undefined;
}
export interface ListContractualInvestmentSummariesRequest {
    contractArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type InvestmentType = "MILESTONE_BASED" | "OUTCOME_BASED" | (string & {});
export interface InvestmentSummary {
    investmentSummaryId: string;
    investmentName: string;
    investmentType: InvestmentType;
    maxAllowedInvestmentDisbursementValue?: Amount | undefined;
}
export type InvestmentSummaries = InvestmentSummary[];
export interface ListContractualInvestmentSummariesResponse {
    items: InvestmentSummary[];
    nextToken?: string | undefined;
}
export interface ListEnterpriseSupportLinkedAccountChargesRequest {
    billingMonth: string;
    accountId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface EnterpriseSupportTimePeriod {
    beginDate: Date;
    endDate?: Date | undefined;
}
export type TimePeriodList = EnterpriseSupportTimePeriod[];
export interface ServiceLevelAccountUsage {
    serviceCode?: string | undefined;
    totalSupportEligibleSpend?: string | undefined;
}
export type ServiceLevelAccountUsageList = ServiceLevelAccountUsage[];
export interface LinkedAccountCharge {
    accountId: string;
    payerAccountId: string;
    accountType?: string | undefined;
    billableSeconds: number;
    totalSeconds: number;
    totalSupportEligibleSpend: string;
    proratedTotalSupportEligibleSpend: string;
    linkedTimePeriods?: EnterpriseSupportTimePeriod[] | undefined;
    subscriptionTimePeriods?: EnterpriseSupportTimePeriod[] | undefined;
    totalSupportEligibleReservedInstanceSpend?: string | undefined;
    totalSupportEligibleSavingsPlanSpend?: string | undefined;
    supportEligibleSpendByService?: ServiceLevelAccountUsage[] | undefined;
}
export type LinkedAccountChargeList = LinkedAccountCharge[];
export interface ListEnterpriseSupportLinkedAccountChargesResponse {
    linkedAccount: LinkedAccountCharge[];
    nextToken?: string | undefined;
}
export interface ListSourceViewsForBillingViewRequest {
    arn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListSourceViewsForBillingViewResponse {
    sourceViews: string[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    resourceTags?: ResourceTag[] | undefined;
}
export type PromoCode = string;
export interface RedeemCreditsRequest {
    promoCode: string;
}
export interface RedeemCreditsResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    resourceTags: ResourceTag[];
}
export interface TagResourceResponse {
}
export type ResourceTagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    resourceTagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface BillingPreferenceForKey {
    key: string;
    value: PreferenceValue;
}
export type BillingPreferencesPerKey = BillingPreferenceForKey[];
export interface UpdateBillingPreferencesRequest {
    feature: BillingFeature;
    billingPreferencesPerKey: BillingPreferenceForKey[];
}
export interface UpdateBillingPreferencesResponse {
}
export interface UpdateBillingViewRequest {
    arn: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    dataFilterExpression?: Expression | undefined;
}
export interface UpdateBillingViewResponse {
    arn: string;
    updatedAt?: Date | undefined;
}
export type ErrorMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export type FieldName = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type ServiceCode = string;
export type QuotaCode = string;
export type AssociateContractError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Private Pricing contracts let eligible payer accounts manage private pricing agreements with Amazon Web Services. This operation associates a private pricing contract with the caller's Amazon Web Services account. The caller must be a payer (management) account listed on the contract. This operation is idempotent, so retrying a request that already succeeded is safe.
 */
export declare const associateContract: API.OperationMethod<AssociateContractRequest & RegionInput, AssociateContractResponse, AssociateContractError, Credentials | HttpClient.HttpClient>;
export type AssociateSourceViewsError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates one or more source billing views with an existing billing view. This allows creating aggregate billing views that combine data from multiple sources.
 */
export declare const associateSourceViews: API.OperationMethod<AssociateSourceViewsRequest & RegionInput, AssociateSourceViewsResponse, AssociateSourceViewsError, Credentials | HttpClient.HttpClient>;
export type CancelContractualInvestmentAttestationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a contractual investment attestation. This operation is idempotent, so retrying is safe. You can cancel an attestation only while it is still pending (its `isCancellable` value is `true`).
 */
export declare const cancelContractualInvestmentAttestation: API.OperationMethod<CancelContractualInvestmentAttestationRequest & RegionInput, CancelContractualInvestmentAttestationResponse, CancelContractualInvestmentAttestationError, Credentials | HttpClient.HttpClient>;
export type CreateBillingViewError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a billing view with the specified billing view attributes.
 */
export declare const createBillingView: API.OperationMethod<CreateBillingViewRequest & RegionInput, CreateBillingViewResponse, CreateBillingViewError, Credentials | HttpClient.HttpClient>;
export type CreateContractualInvestmentAttestationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an attestation that claims an investment award for a completed milestone or outcome within a private pricing contract. Supply a `clientToken` to make the request idempotent so a safe retry does not create a duplicate attestation. This operation starts an asynchronous review and returns an `attestationId` while the attestation is pending.
 */
export declare const createContractualInvestmentAttestation: API.OperationMethod<CreateContractualInvestmentAttestationRequest & RegionInput, CreateContractualInvestmentAttestationResponse, CreateContractualInvestmentAttestationError, Credentials | HttpClient.HttpClient>;
export type DeleteBillingViewError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified billing view.
 */
export declare const deleteBillingView: API.OperationMethod<DeleteBillingViewRequest & RegionInput, DeleteBillingViewResponse, DeleteBillingViewError, Credentials | HttpClient.HttpClient>;
export type DisassociateContractError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association between a private pricing contract and your Amazon Web Services account. The account must have been associated with the contract previously. This operation is idempotent, so retrying is safe.
 */
export declare const disassociateContract: API.OperationMethod<DisassociateContractRequest & RegionInput, DisassociateContractResponse, DisassociateContractError, Credentials | HttpClient.HttpClient>;
export type DisassociateSourceViewsError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the association between one or more source billing views and an existing billing view. This allows modifying the composition of aggregate billing views.
 */
export declare const disassociateSourceViews: API.OperationMethod<DisassociateSourceViewsRequest & RegionInput, DisassociateSourceViewsResponse, DisassociateSourceViewsError, Credentials | HttpClient.HttpClient>;
export type GetBillingPreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves billing preferences for the specified feature. Each feature controls a distinct billing capability: which accounts can share Reserved Instances or credits, whether billing alerts are enabled, the historical record of sharing changes, and per-credit options.
 */
export declare const getBillingPreferences: API.OperationMethod<GetBillingPreferencesRequest & RegionInput, GetBillingPreferencesResponse, GetBillingPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetBillingViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the metadata associated to the specified billing view ARN.
 */
export declare const getBillingView: API.OperationMethod<GetBillingViewRequest & RegionInput, GetBillingViewResponse, GetBillingViewError, Credentials | HttpClient.HttpClient>;
export type GetContractInformationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific private pricing contract, including its term (duration), eligible payer accounts, investment accounts, and legal entities. This operation is read-only.
 */
export declare const getContractInformation: API.OperationMethod<GetContractInformationRequest & RegionInput, GetContractInformationResponse, GetContractInformationError, Credentials | HttpClient.HttpClient>;
export type GetCreditAllocationHistoryError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the per-billing-month allocation history for credits applied to an Amazon Web Services account's bills. Traverses the consolidated billing family to capture cross-account credit applications. Supports pagination and optional filtering to a single credit.
 */
export declare const getCreditAllocationHistory: API.PaginatedOperationMethod<GetCreditAllocationHistoryRequest & RegionInput, GetCreditAllocationHistoryResponse, GetCreditAllocationHistoryError, Credentials | HttpClient.HttpClient, CreditAllocationHistoryEntry>;
export type GetCreditsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of Amazon Web Services account credits for the specified account. Each credit includes its identifier, type, monetary amounts, applicable products, expiration, sharing configuration, and current enabled status.
 *
 * When the caller is the management account of a consolidated billing family and `payerAccountFlag` is `true`, the response aggregates credits across the entire family. Otherwise, the response includes only credits owned by the account specified in `accountId`.
 */
export declare const getCredits: API.OperationMethod<GetCreditsRequest & RegionInput, GetCreditsResponse, GetCreditsError, Credentials | HttpClient.HttpClient>;
export type GetEnterpriseSupportChargeSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a summary of Enterprise Support data aggregated across all accounts in the Enterprise Support profile.
 */
export declare const getEnterpriseSupportChargeSummary: API.OperationMethod<GetEnterpriseSupportChargeSummaryRequest & RegionInput, GetEnterpriseSupportChargeSummaryResponse, GetEnterpriseSupportChargeSummaryError, Credentials | HttpClient.HttpClient>;
export type GetEnterpriseSupportContractDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Enterprise Support contract details.
 */
export declare const getEnterpriseSupportContractDetails: API.OperationMethod<GetEnterpriseSupportContractDetailsRequest & RegionInput, GetEnterpriseSupportContractDetailsResponse, GetEnterpriseSupportContractDetailsError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource-based policy document attached to the resource in `JSON` format.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListBillingViewsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the billing views available for a given time period.
 *
 * Every Amazon Web Services account has a unique `PRIMARY` billing view that represents the billing data available by default. Accounts that use Billing Conductor also have `BILLING_GROUP` billing views representing pro forma costs associated with each created billing group.
 */
export declare const listBillingViews: API.PaginatedOperationMethod<ListBillingViewsRequest & RegionInput, ListBillingViewsResponse, ListBillingViewsError, Credentials | HttpClient.HttpClient, BillingViewListElement>;
export type ListBillingViewSegmentsError = AccessDeniedException | BillingViewHealthStatusException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the segments of a billing view over a given time period. Each segment identifies the billing domain (`PRO_FORMA` or `BILLABLE`) and the account relationships that apply during its time range.
 *
 * If you don't provide an `arn`, the response includes segments for the caller's `PRIMARY` billing view.
 *
 * If a mid-period change occurs, the response includes multiple segments, each with its own time range. The response omits hidden segments, so the segments it returns might not cover the entire requested time period.
 */
export declare const listBillingViewSegments: API.PaginatedOperationMethod<ListBillingViewSegmentsRequest & RegionInput, ListBillingViewSegmentsResponse, ListBillingViewSegmentsError, Credentials | HttpClient.HttpClient, BillingViewSegmentsListElement>;
export type ListBusinessSupportAccountChargesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Business Support charges broken down at the linked account level for a given billing month.
 */
export declare const listBusinessSupportAccountCharges: API.PaginatedOperationMethod<ListBusinessSupportAccountChargesRequest & RegionInput, ListBusinessSupportAccountChargesResponse, ListBusinessSupportAccountChargesError, Credentials | HttpClient.HttpClient, BusinessSupportAccountCharge>;
export type ListBusinessSupportSubscriptionHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the history of Business Support subscription contracts across accounts.
 */
export declare const listBusinessSupportSubscriptionHistory: API.PaginatedOperationMethod<ListBusinessSupportSubscriptionHistoryRequest & RegionInput, ListBusinessSupportSubscriptionHistoryResponse, ListBusinessSupportSubscriptionHistoryError, Credentials | HttpClient.HttpClient, BusinessSupportSubscriptionContract>;
export type ListContractsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the private pricing contracts that your Amazon Web Services account is an eligible payer account of. This operation is read-only and paginated.
 */
export declare const listContracts: API.PaginatedOperationMethod<ListContractsRequest & RegionInput, ListContractsResponse, ListContractsError, Credentials | HttpClient.HttpClient, ContractSummary>;
export type ListContractualInvestmentAttestationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the investment attestations submitted under a specific private pricing contract. Use this operation to track attestation status, including the terminal statuses `DISBURSED`, `REJECTED`, and `CANCELLED`. This operation is read-only and paginated.
 */
export declare const listContractualInvestmentAttestations: API.PaginatedOperationMethod<ListContractualInvestmentAttestationsRequest & RegionInput, ListContractualInvestmentAttestationsResponse, ListContractualInvestmentAttestationsError, Credentials | HttpClient.HttpClient, InvestmentAttestation>;
export type ListContractualInvestmentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the investments within a specific investment summary. This operation is read-only and paginated.
 */
export declare const listContractualInvestments: API.PaginatedOperationMethod<ListContractualInvestmentsRequest & RegionInput, ListContractualInvestmentsResponse, ListContractualInvestmentsError, Credentials | HttpClient.HttpClient, Investment>;
export type ListContractualInvestmentSummariesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the investment summaries within a specific private pricing contract. This operation is read-only and paginated.
 */
export declare const listContractualInvestmentSummaries: API.PaginatedOperationMethod<ListContractualInvestmentSummariesRequest & RegionInput, ListContractualInvestmentSummariesResponse, ListContractualInvestmentSummariesError, Credentials | HttpClient.HttpClient, InvestmentSummary>;
export type ListEnterpriseSupportLinkedAccountChargesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns Support-eligible spend broken down at linked account level.
 */
export declare const listEnterpriseSupportLinkedAccountCharges: API.PaginatedOperationMethod<ListEnterpriseSupportLinkedAccountChargesRequest & RegionInput, ListEnterpriseSupportLinkedAccountChargesResponse, ListEnterpriseSupportLinkedAccountChargesError, Credentials | HttpClient.HttpClient, LinkedAccountCharge>;
export type ListSourceViewsForBillingViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the source views (managed Amazon Web Services billing views) associated with the billing view.
 */
export declare const listSourceViewsForBillingView: API.PaginatedOperationMethod<ListSourceViewsForBillingViewRequest & RegionInput, ListSourceViewsForBillingViewResponse, ListSourceViewsForBillingViewError, Credentials | HttpClient.HttpClient, BillingViewArn>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags associated with the billing view resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RedeemCreditsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Redeems an Amazon Web Services promotional credit code on behalf of the calling account. On success, a new credit is added to the account's credit ledger with the amount, validity period, and applicable products defined by the promotion. The credit is then automatically applied to subsequent bills according to the standard credit application order.
 */
export declare const redeemCredits: API.OperationMethod<RedeemCreditsRequest & RegionInput, RedeemCreditsResponse, RedeemCreditsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * An API operation for adding one or more tags (key-value pairs) to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from a resource. Specify only tag keys in your request. Don't specify the value.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBillingPreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates billing preferences for the specified feature. Each feature targets a distinct billing capability and has its own set of supported keys. The action sets the value for each provided key; keys not present in the request are unchanged.
 *
 * Sharing keys (`RI_SHARING`, `CREDIT_SHARING`, `CREDIT_LEVEL_SHARING`, and sharing keys under `CREDIT_PREFERENCE_OPTIONS`) may only be set by the management account of a consolidated billing family. The `credit/{creditId}/status` key may be set by member accounts for credits they own, or by the management account for any credit in the family.
 */
export declare const updateBillingPreferences: API.OperationMethod<UpdateBillingPreferencesRequest & RegionInput, UpdateBillingPreferencesResponse, UpdateBillingPreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateBillingViewError = AccessDeniedException | BillingViewHealthStatusException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * An API to update the attributes of the billing view.
 */
export declare const updateBillingView: API.OperationMethod<UpdateBillingViewRequest & RegionInput, UpdateBillingViewResponse, UpdateBillingViewError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=billing.d.ts.map