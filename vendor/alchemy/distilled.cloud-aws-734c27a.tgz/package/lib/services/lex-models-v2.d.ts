import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const PreconditionFailedException_base: S.TaggedErrorClass<"PreconditionFailedException", {
    readonly message: any;
}>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Id = string;
export type BotVersion = string;
export type LocaleId = string;
export type Phrase = string;
export type Weight = number;
export interface NewCustomVocabularyItem {
    phrase: string;
    weight?: number | undefined;
    displayAs?: string | undefined;
}
export type CreateCustomVocabularyItemsList = NewCustomVocabularyItem[];
export interface BatchCreateCustomVocabularyItemRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    customVocabularyItemList: NewCustomVocabularyItem[];
}
export type ItemId = string;
export type ErrorMessage = string;
export type ErrorCode = "DUPLICATE_INPUT" | "RESOURCE_DOES_NOT_EXIST" | "RESOURCE_ALREADY_EXISTS" | "INTERNAL_SERVER_FAILURE" | (string & {});
export interface FailedCustomVocabularyItem {
    itemId?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: ErrorCode | undefined;
}
export type FailedCustomVocabularyItems = FailedCustomVocabularyItem[];
export interface CustomVocabularyItem {
    itemId: string;
    phrase: string;
    weight?: number | undefined;
    displayAs?: string | undefined;
}
export type CustomVocabularyItems = CustomVocabularyItem[];
export interface BatchCreateCustomVocabularyItemResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    errors?: FailedCustomVocabularyItem[] | undefined;
    resources?: CustomVocabularyItem[] | undefined;
}
export interface CustomVocabularyEntryId {
    itemId: string;
}
export type DeleteCustomVocabularyItemsList = CustomVocabularyEntryId[];
export interface BatchDeleteCustomVocabularyItemRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    customVocabularyItemList: CustomVocabularyEntryId[];
}
export interface BatchDeleteCustomVocabularyItemResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    errors?: FailedCustomVocabularyItem[] | undefined;
    resources?: CustomVocabularyItem[] | undefined;
}
export type UpdateCustomVocabularyItemsList = CustomVocabularyItem[];
export interface BatchUpdateCustomVocabularyItemRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    customVocabularyItemList: CustomVocabularyItem[];
}
export interface BatchUpdateCustomVocabularyItemResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    errors?: FailedCustomVocabularyItem[] | undefined;
    resources?: CustomVocabularyItem[] | undefined;
}
export type DraftBotVersion = string;
export interface BuildBotLocaleRequest {
    botId: string;
    botVersion: string;
    localeId: string;
}
export type BotLocaleStatus = "Creating" | "Building" | "Built" | "ReadyExpressTesting" | "Failed" | "Deleting" | "NotBuilt" | "Importing" | "Processing" | (string & {});
export interface BuildBotLocaleResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botLocaleStatus?: BotLocaleStatus | undefined;
    lastBuildSubmittedDateTime?: Date | undefined;
}
export type Name = string;
export type Description = string;
export type RoleArn = string;
export type ChildDirected = boolean;
export interface DataPrivacy {
    childDirected: boolean;
}
export type SessionTTL = number;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type BotType = "Bot" | "BotNetwork" | (string & {});
export type BotAliasId = string;
export type BotAliasName = string;
export interface BotMember {
    botMemberId: string;
    botMemberName: string;
    botMemberAliasId: string;
    botMemberAliasName: string;
    botMemberVersion: string;
}
export type BotMembers = BotMember[];
export type BoxedBoolean = boolean;
export interface ErrorLogSettings {
    enabled: boolean;
}
export interface CreateBotRequest {
    botName: string;
    description?: string | undefined;
    roleArn: string;
    dataPrivacy: DataPrivacy;
    idleSessionTTLInSeconds: number;
    botTags?: {
        [key: string]: string | undefined;
    } | undefined;
    testBotAliasTags?: {
        [key: string]: string | undefined;
    } | undefined;
    botType?: BotType | undefined;
    botMembers?: BotMember[] | undefined;
    errorLogSettings?: ErrorLogSettings | undefined;
}
export type BotStatus = "Creating" | "Available" | "Inactive" | "Deleting" | "Failed" | "Versioning" | "Importing" | "Updating" | (string & {});
export interface CreateBotResponse {
    botId?: string | undefined;
    botName?: string | undefined;
    description?: string | undefined;
    roleArn?: string | undefined;
    dataPrivacy?: DataPrivacy | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    botStatus?: BotStatus | undefined;
    creationDateTime?: Date | undefined;
    botTags?: {
        [key: string]: string | undefined;
    } | undefined;
    testBotAliasTags?: {
        [key: string]: string | undefined;
    } | undefined;
    botType?: BotType | undefined;
    botMembers?: BotMember[] | undefined;
    errorLogSettings?: ErrorLogSettings | undefined;
}
export type NumericalBotVersion = string;
export type LambdaARN = string;
export type CodeHookInterfaceVersion = string;
export interface LambdaCodeHook {
    lambdaARN: string;
    codeHookInterfaceVersion: string;
}
export interface CodeHookSpecification {
    lambdaCodeHook: LambdaCodeHook;
}
export interface BotAliasLocaleSettings {
    enabled: boolean;
    codeHookSpecification?: CodeHookSpecification | undefined;
}
export type BotAliasLocaleSettingsMap = {
    [key: string]: BotAliasLocaleSettings | undefined;
};
export type CloudWatchLogGroupArn = string;
export type LogPrefix = string;
export interface CloudWatchLogGroupLogDestination {
    cloudWatchLogGroupArn: string;
    logPrefix: string;
}
export interface TextLogDestination {
    cloudWatch: CloudWatchLogGroupLogDestination;
}
export interface TextLogSetting {
    enabled: boolean;
    destination: TextLogDestination;
    selectiveLoggingEnabled?: boolean | undefined;
}
export type TextLogSettingsList = TextLogSetting[];
export type KmsKeyArn = string;
export type S3BucketArn = string;
export interface S3BucketLogDestination {
    kmsKeyArn?: string | undefined;
    s3BucketArn: string;
    logPrefix: string;
}
export interface AudioLogDestination {
    s3Bucket: S3BucketLogDestination;
}
export interface AudioLogSetting {
    enabled: boolean;
    destination: AudioLogDestination;
    selectiveLoggingEnabled?: boolean | undefined;
}
export type AudioLogSettingsList = AudioLogSetting[];
export interface ConversationLogSettings {
    textLogSettings?: TextLogSetting[] | undefined;
    audioLogSettings?: AudioLogSetting[] | undefined;
}
export interface SentimentAnalysisSettings {
    detectSentiment: boolean;
}
export interface CreateBotAliasRequest {
    botAliasName: string;
    description?: string | undefined;
    botVersion?: string | undefined;
    botAliasLocaleSettings?: {
        [key: string]: BotAliasLocaleSettings | undefined;
    } | undefined;
    conversationLogSettings?: ConversationLogSettings | undefined;
    sentimentAnalysisSettings?: SentimentAnalysisSettings | undefined;
    botId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type BotAliasStatus = "Creating" | "Available" | "Deleting" | "Failed" | (string & {});
export interface CreateBotAliasResponse {
    botAliasId?: string | undefined;
    botAliasName?: string | undefined;
    description?: string | undefined;
    botVersion?: string | undefined;
    botAliasLocaleSettings?: {
        [key: string]: BotAliasLocaleSettings | undefined;
    } | undefined;
    conversationLogSettings?: ConversationLogSettings | undefined;
    sentimentAnalysisSettings?: SentimentAnalysisSettings | undefined;
    botAliasStatus?: BotAliasStatus | undefined;
    botId?: string | undefined;
    creationDateTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConfidenceThreshold = number;
export type VoiceEngine = "standard" | "neural" | "long-form" | "generative" | (string & {});
export type VoiceId = string;
export interface VoiceSettings {
    engine?: VoiceEngine | undefined;
    voiceId: string;
}
export type BedrockModelArn = string;
export interface SpeechFoundationModel {
    modelArn: string;
    voiceId?: string | undefined;
}
export interface UnifiedSpeechSettings {
    speechFoundationModel: SpeechFoundationModel;
}
export type AudioFillerType = "MELODY_CHIPPER_CHIME" | "MELODY_CURIOUS_CRAWL" | "MELODY_RISING_RIPPLE" | "MELODY_PATIENT_PING" | "MELODY_PONDERING_PONG" | "TYPING_KINETIC_KEYS" | "TYPING_QUIET_QWERTY" | (string & {});
export type AudioFillerDelayInMilliseconds = number;
export type AudioFillerDurationInMilliseconds = number;
export type AudioFillerDeliveryDelayInMilliseconds = number;
export interface AudioFillerSettings {
    enabled?: boolean | undefined;
    audioType?: AudioFillerType | undefined;
    startDelayInMilliseconds?: number | undefined;
    minimumPlayDurationInMilliseconds?: number | undefined;
    responseDeliveryDelayInMilliseconds?: number | undefined;
}
export type SpeechModelPreference = "Standard" | "Neural" | "Deepgram" | "Advanced" | (string & {});
export type SecretsManagerSecretArn = string;
export type DeepgramModelId = string;
export interface DeepgramSpeechModelConfig {
    apiTokenSecretArn: string;
    modelId?: string | undefined;
}
export interface SpeechModelConfig {
    deepgramConfig?: DeepgramSpeechModelConfig | undefined;
}
export interface SpeechRecognitionSettings {
    speechModelPreference?: SpeechModelPreference | undefined;
    speechModelConfig?: SpeechModelConfig | undefined;
}
export type Enabled = boolean;
export type BedrockGuardrailIdentifier = string;
export type BedrockGuardrailVersion = string;
export interface BedrockGuardrailConfiguration {
    identifier: string;
    version: string;
}
export type BedrockTraceStatus = "ENABLED" | "DISABLED" | (string & {});
export type BedrockModelCustomPrompt = string;
export interface BedrockModelSpecification {
    modelArn: string;
    guardrail?: BedrockGuardrailConfiguration | undefined;
    traceStatus?: BedrockTraceStatus | undefined;
    customPrompt?: string | undefined;
}
export interface SlotResolutionImprovementSpecification {
    enabled: boolean;
    bedrockModelSpecification?: BedrockModelSpecification | undefined;
}
export type AssistedNluMode = "Primary" | "Fallback" | "DialogManager" | (string & {});
export type MaxDisambiguationIntents = number;
export type CustomDisambiguationMessage = string;
export interface IntentDisambiguationSettings {
    enabled: boolean;
    maxDisambiguationIntents?: number | undefined;
    customDisambiguationMessage?: string | undefined;
}
export interface NluImprovementSpecification {
    enabled: boolean;
    assistedNluMode?: AssistedNluMode | undefined;
    intentDisambiguationSettings?: IntentDisambiguationSettings | undefined;
}
export interface RuntimeSettings {
    slotResolutionImprovement?: SlotResolutionImprovementSpecification | undefined;
    nluImprovement?: NluImprovementSpecification | undefined;
}
export interface DescriptiveBotBuilderSpecification {
    enabled: boolean;
    bedrockModelSpecification?: BedrockModelSpecification | undefined;
}
export interface SampleUtteranceGenerationSpecification {
    enabled: boolean;
    bedrockModelSpecification?: BedrockModelSpecification | undefined;
}
export interface BuildtimeSettings {
    descriptiveBotBuilder?: DescriptiveBotBuilderSpecification | undefined;
    sampleUtteranceGeneration?: SampleUtteranceGenerationSpecification | undefined;
}
export interface GenerativeAISettings {
    runtimeSettings?: RuntimeSettings | undefined;
    buildtimeSettings?: BuildtimeSettings | undefined;
}
export type SpeechDetectionSensitivity = "Default" | "HighNoiseTolerance" | "MaximumNoiseTolerance" | (string & {});
export interface SpeakerDiarizationSettings {
    enabled: boolean;
}
export interface CreateBotLocaleRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    description?: string | undefined;
    nluIntentConfidenceThreshold: number;
    voiceSettings?: VoiceSettings | undefined;
    unifiedSpeechSettings?: UnifiedSpeechSettings | undefined;
    audioFillerSettings?: AudioFillerSettings | undefined;
    speechRecognitionSettings?: SpeechRecognitionSettings | undefined;
    generativeAISettings?: GenerativeAISettings | undefined;
    speechDetectionSensitivity?: SpeechDetectionSensitivity | undefined;
    speakerDiarizationSettings?: SpeakerDiarizationSettings | undefined;
}
export type LocaleName = string;
export interface CreateBotLocaleResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeName?: string | undefined;
    localeId?: string | undefined;
    description?: string | undefined;
    nluIntentConfidenceThreshold?: number | undefined;
    voiceSettings?: VoiceSettings | undefined;
    unifiedSpeechSettings?: UnifiedSpeechSettings | undefined;
    audioFillerSettings?: AudioFillerSettings | undefined;
    speechRecognitionSettings?: SpeechRecognitionSettings | undefined;
    botLocaleStatus?: BotLocaleStatus | undefined;
    creationDateTime?: Date | undefined;
    generativeAISettings?: GenerativeAISettings | undefined;
    speechDetectionSensitivity?: SpeechDetectionSensitivity | undefined;
    speakerDiarizationSettings?: SpeakerDiarizationSettings | undefined;
}
export type ReplicaRegion = string;
export interface CreateBotReplicaRequest {
    botId: string;
    replicaRegion: string;
}
export type BotReplicaStatus = "Enabling" | "Enabled" | "Deleting" | "Failed" | (string & {});
export interface CreateBotReplicaResponse {
    botId?: string | undefined;
    replicaRegion?: string | undefined;
    sourceRegion?: string | undefined;
    creationDateTime?: Date | undefined;
    botReplicaStatus?: BotReplicaStatus | undefined;
}
export interface BotVersionLocaleDetails {
    sourceBotVersion: string;
}
export type BotVersionLocaleSpecification = {
    [key: string]: BotVersionLocaleDetails | undefined;
};
export interface CreateBotVersionRequest {
    botId: string;
    description?: string | undefined;
    botVersionLocaleSpecification: {
        [key: string]: BotVersionLocaleDetails | undefined;
    };
}
export interface CreateBotVersionResponse {
    botId?: string | undefined;
    description?: string | undefined;
    botVersion?: string | undefined;
    botVersionLocaleSpecification?: {
        [key: string]: BotVersionLocaleDetails | undefined;
    } | undefined;
    botStatus?: BotStatus | undefined;
    creationDateTime?: Date | undefined;
}
export interface BotExportSpecification {
    botId: string;
    botVersion: string;
}
export interface BotLocaleExportSpecification {
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface CustomVocabularyExportSpecification {
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface TestSetExportSpecification {
    testSetId: string;
}
export interface ExportResourceSpecification {
    botExportSpecification?: BotExportSpecification | undefined;
    botLocaleExportSpecification?: BotLocaleExportSpecification | undefined;
    customVocabularyExportSpecification?: CustomVocabularyExportSpecification | undefined;
    testSetExportSpecification?: TestSetExportSpecification | undefined;
}
export type ImportExportFileFormat = "LexJson" | "TSV" | "CSV" | (string & {});
export type ImportExportFilePassword = string | redacted.Redacted<string>;
export interface CreateExportRequest {
    resourceSpecification: ExportResourceSpecification;
    fileFormat: ImportExportFileFormat;
    filePassword?: string | redacted.Redacted<string> | undefined;
}
export type ExportStatus = "InProgress" | "Completed" | "Failed" | "Deleting" | (string & {});
export interface CreateExportResponse {
    exportId?: string | undefined;
    resourceSpecification?: ExportResourceSpecification | undefined;
    fileFormat?: ImportExportFileFormat | undefined;
    exportStatus?: ExportStatus | undefined;
    creationDateTime?: Date | undefined;
}
export type DisplayName = string;
export type IntentSignature = string;
export type Utterance = string;
export interface SampleUtterance {
    utterance: string;
}
export type SampleUtterancesList = SampleUtterance[];
export interface DialogCodeHookSettings {
    enabled: boolean;
}
export type PlainTextMessageValue = string;
export interface PlainTextMessage {
    value: string;
}
export type CustomPayloadValue = string;
export interface CustomPayload {
    value: string;
}
export type SSMLMessageValue = string;
export interface SSMLMessage {
    value: string;
}
export type AttachmentTitle = string;
export type AttachmentUrl = string;
export type ButtonText = string;
export type ButtonValue = string;
export interface Button {
    text: string;
    value: string;
}
export type ButtonsList = Button[];
export interface ImageResponseCard {
    title: string;
    subtitle?: string | undefined;
    imageUrl?: string | undefined;
    buttons?: Button[] | undefined;
}
export interface Message {
    plainTextMessage?: PlainTextMessage | undefined;
    customPayload?: CustomPayload | undefined;
    ssmlMessage?: SSMLMessage | undefined;
    imageResponseCard?: ImageResponseCard | undefined;
}
export type MessageVariationsList = Message[];
export interface MessageGroup {
    message: Message;
    variations?: Message[] | undefined;
}
export type MessageGroupsList = MessageGroup[];
export interface ResponseSpecification {
    messageGroups: MessageGroup[];
    allowInterrupt?: boolean | undefined;
}
export type DialogActionType = "ElicitIntent" | "StartIntent" | "ElicitSlot" | "EvaluateConditional" | "InvokeDialogCodeHook" | "ConfirmIntent" | "FulfillIntent" | "CloseIntent" | "EndConversation" | (string & {});
export interface DialogAction {
    type: DialogActionType;
    slotToElicit?: string | undefined;
    suppressNextMessage?: boolean | undefined;
}
export type SlotShape = "Scalar" | "List" | (string & {});
export type NonEmptyString = string;
export interface SlotValue {
    interpretedValue?: string | undefined;
}
export type SlotValues = SlotValueOverride[];
export interface SlotValueOverride {
    shape?: SlotShape | undefined;
    value?: SlotValue | undefined;
    values?: SlotValueOverride[] | undefined;
}
export type SlotValueOverrideMap = {
    [key: string]: SlotValueOverride | undefined;
};
export interface IntentOverride {
    name?: string | undefined;
    slots?: {
        [key: string]: SlotValueOverride | undefined;
    } | undefined;
}
export type StringMap = {
    [key: string]: string | undefined;
};
export interface DialogState {
    dialogAction?: DialogAction | undefined;
    intent?: IntentOverride | undefined;
    sessionAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConditionExpression = string;
export interface Condition {
    expressionString: string;
}
export interface ConditionalBranch {
    name: string;
    condition: Condition;
    nextStep: DialogState;
    response?: ResponseSpecification | undefined;
}
export type ConditionalBranches = ConditionalBranch[];
export interface DefaultConditionalBranch {
    nextStep?: DialogState | undefined;
    response?: ResponseSpecification | undefined;
}
export interface ConditionalSpecification {
    active: boolean;
    conditionalBranches: ConditionalBranch[];
    defaultBranch: DefaultConditionalBranch;
}
export interface PostFulfillmentStatusSpecification {
    successResponse?: ResponseSpecification | undefined;
    failureResponse?: ResponseSpecification | undefined;
    timeoutResponse?: ResponseSpecification | undefined;
    successNextStep?: DialogState | undefined;
    successConditional?: ConditionalSpecification | undefined;
    failureNextStep?: DialogState | undefined;
    failureConditional?: ConditionalSpecification | undefined;
    timeoutNextStep?: DialogState | undefined;
    timeoutConditional?: ConditionalSpecification | undefined;
}
export type FulfillmentStartResponseDelay = number;
export interface FulfillmentStartResponseSpecification {
    delayInSeconds: number;
    messageGroups: MessageGroup[];
    allowInterrupt?: boolean | undefined;
}
export type FulfillmentUpdateResponseFrequency = number;
export interface FulfillmentUpdateResponseSpecification {
    frequencyInSeconds: number;
    messageGroups: MessageGroup[];
    allowInterrupt?: boolean | undefined;
}
export type FulfillmentTimeout = number;
export interface FulfillmentUpdatesSpecification {
    active: boolean;
    startResponse?: FulfillmentStartResponseSpecification | undefined;
    updateResponse?: FulfillmentUpdateResponseSpecification | undefined;
    timeoutInSeconds?: number | undefined;
}
export interface FulfillmentCodeHookSettings {
    enabled: boolean;
    postFulfillmentStatusSpecification?: PostFulfillmentStatusSpecification | undefined;
    fulfillmentUpdatesSpecification?: FulfillmentUpdatesSpecification | undefined;
    active?: boolean | undefined;
}
export type PromptMaxRetries = number;
export type MessageSelectionStrategy = "Random" | "Ordered" | (string & {});
export type PromptAttempt = "Initial" | "Retry1" | "Retry2" | "Retry3" | "Retry4" | "Retry5" | (string & {});
export interface AllowedInputTypes {
    allowAudioInput: boolean;
    allowDTMFInput: boolean;
}
export type TimeInMilliSeconds = number;
export interface AudioSpecification {
    maxLengthMs: number;
    endTimeoutMs: number;
}
export type MaxUtteranceDigits = number;
export type DTMFCharacter = string;
export interface DTMFSpecification {
    maxLength: number;
    endTimeoutMs: number;
    deletionCharacter: string;
    endCharacter: string;
}
export interface AudioAndDTMFInputSpecification {
    startTimeoutMs: number;
    audioSpecification?: AudioSpecification | undefined;
    dtmfSpecification?: DTMFSpecification | undefined;
}
export interface TextInputSpecification {
    startTimeoutMs: number;
}
export interface PromptAttemptSpecification {
    allowInterrupt?: boolean | undefined;
    allowedInputTypes: AllowedInputTypes;
    audioAndDTMFInputSpecification?: AudioAndDTMFInputSpecification | undefined;
    textInputSpecification?: TextInputSpecification | undefined;
}
export type PromptAttemptsSpecificationMap = {
    [key in PromptAttempt]?: PromptAttemptSpecification | undefined;
};
export interface PromptSpecification {
    messageGroups: MessageGroup[];
    maxRetries: number;
    allowInterrupt?: boolean | undefined;
    messageSelectionStrategy?: MessageSelectionStrategy | undefined;
    promptAttemptsSpecification?: {
        [key: string]: PromptAttemptSpecification | undefined;
    } | undefined;
}
export interface PostDialogCodeHookInvocationSpecification {
    successResponse?: ResponseSpecification | undefined;
    successNextStep?: DialogState | undefined;
    successConditional?: ConditionalSpecification | undefined;
    failureResponse?: ResponseSpecification | undefined;
    failureNextStep?: DialogState | undefined;
    failureConditional?: ConditionalSpecification | undefined;
    timeoutResponse?: ResponseSpecification | undefined;
    timeoutNextStep?: DialogState | undefined;
    timeoutConditional?: ConditionalSpecification | undefined;
}
export interface DialogCodeHookInvocationSetting {
    enableCodeHookInvocation: boolean;
    active: boolean;
    invocationLabel?: string | undefined;
    postCodeHookSpecification: PostDialogCodeHookInvocationSpecification;
}
export interface ElicitationCodeHookInvocationSetting {
    enableCodeHookInvocation: boolean;
    invocationLabel?: string | undefined;
}
export interface IntentConfirmationSetting {
    promptSpecification?: PromptSpecification | undefined;
    declinationResponse?: ResponseSpecification | undefined;
    active?: boolean | undefined;
    confirmationResponse?: ResponseSpecification | undefined;
    confirmationNextStep?: DialogState | undefined;
    confirmationConditional?: ConditionalSpecification | undefined;
    declinationNextStep?: DialogState | undefined;
    declinationConditional?: ConditionalSpecification | undefined;
    failureResponse?: ResponseSpecification | undefined;
    failureNextStep?: DialogState | undefined;
    failureConditional?: ConditionalSpecification | undefined;
    codeHook?: DialogCodeHookInvocationSetting | undefined;
    elicitationCodeHook?: ElicitationCodeHookInvocationSetting | undefined;
}
export interface IntentClosingSetting {
    closingResponse?: ResponseSpecification | undefined;
    active?: boolean | undefined;
    nextStep?: DialogState | undefined;
    conditional?: ConditionalSpecification | undefined;
}
export interface InputContext {
    name: string;
}
export type InputContextsList = InputContext[];
export type ContextTimeToLiveInSeconds = number;
export type ContextTurnsToLive = number;
export interface OutputContext {
    name: string;
    timeToLiveInSeconds: number;
    turnsToLive: number;
}
export type OutputContextsList = OutputContext[];
export type KendraIndexArn = string;
export type QueryFilterString = string;
export interface KendraConfiguration {
    kendraIndex: string;
    queryFilterStringEnabled?: boolean | undefined;
    queryFilterString?: string | undefined;
}
export interface InitialResponseSetting {
    initialResponse?: ResponseSpecification | undefined;
    nextStep?: DialogState | undefined;
    conditional?: ConditionalSpecification | undefined;
    codeHook?: DialogCodeHookInvocationSetting | undefined;
}
export type DomainEndpoint = string;
export type OSIndexName = string;
export type QuestionField = string;
export type AnswerField = string;
export interface ExactResponseFields {
    questionField: string;
    answerField: string;
}
export type IncludeField = string;
export type OSIncludeFields = string[];
export interface OpensearchConfiguration {
    domainEndpoint: string;
    indexName: string;
    exactResponse?: boolean | undefined;
    exactResponseFields?: ExactResponseFields | undefined;
    includeFields?: string[] | undefined;
}
export interface QnAKendraConfiguration {
    kendraIndex: string;
    queryFilterStringEnabled?: boolean | undefined;
    queryFilterString?: string | undefined;
    exactResponse?: boolean | undefined;
}
export type BedrockKnowledgeBaseArn = string;
export interface BedrockKnowledgeStoreExactResponseFields {
    answerField?: string | undefined;
}
export interface BedrockKnowledgeStoreConfiguration {
    bedrockKnowledgeBaseArn: string;
    exactResponse?: boolean | undefined;
    exactResponseFields?: BedrockKnowledgeStoreExactResponseFields | undefined;
}
export interface DataSourceConfiguration {
    opensearchConfiguration?: OpensearchConfiguration | undefined;
    kendraConfiguration?: QnAKendraConfiguration | undefined;
    bedrockKnowledgeStoreConfiguration?: BedrockKnowledgeStoreConfiguration | undefined;
}
export interface QnAIntentConfiguration {
    dataSourceConfiguration?: DataSourceConfiguration | undefined;
    bedrockModelConfiguration?: BedrockModelSpecification | undefined;
}
export type QInConnectAssistantARN = string;
export interface QInConnectAssistantConfiguration {
    assistantArn: string;
}
export interface QInConnectIntentConfiguration {
    qInConnectAssistantConfiguration?: QInConnectAssistantConfiguration | undefined;
}
export interface CreateIntentRequest {
    intentName: string;
    intentDisplayName?: string | undefined;
    description?: string | undefined;
    parentIntentSignature?: string | undefined;
    sampleUtterances?: SampleUtterance[] | undefined;
    dialogCodeHook?: DialogCodeHookSettings | undefined;
    fulfillmentCodeHook?: FulfillmentCodeHookSettings | undefined;
    intentConfirmationSetting?: IntentConfirmationSetting | undefined;
    intentClosingSetting?: IntentClosingSetting | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    botId: string;
    botVersion: string;
    localeId: string;
    initialResponseSetting?: InitialResponseSetting | undefined;
    qnAIntentConfiguration?: QnAIntentConfiguration | undefined;
    qInConnectIntentConfiguration?: QInConnectIntentConfiguration | undefined;
}
export interface CreateIntentResponse {
    intentId?: string | undefined;
    intentName?: string | undefined;
    intentDisplayName?: string | undefined;
    description?: string | undefined;
    parentIntentSignature?: string | undefined;
    sampleUtterances?: SampleUtterance[] | undefined;
    dialogCodeHook?: DialogCodeHookSettings | undefined;
    fulfillmentCodeHook?: FulfillmentCodeHookSettings | undefined;
    intentConfirmationSetting?: IntentConfirmationSetting | undefined;
    intentClosingSetting?: IntentClosingSetting | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    creationDateTime?: Date | undefined;
    initialResponseSetting?: InitialResponseSetting | undefined;
    qnAIntentConfiguration?: QnAIntentConfiguration | undefined;
    qInConnectIntentConfiguration?: QInConnectIntentConfiguration | undefined;
}
export type AmazonResourceName = string;
export type Policy = string;
export interface CreateResourcePolicyRequest {
    resourceArn: string;
    policy: string;
}
export type RevisionId = string;
export interface CreateResourcePolicyResponse {
    resourceArn?: string | undefined;
    revisionId?: string | undefined;
}
export type Effect = "Allow" | "Deny" | (string & {});
export type ServicePrincipal = string;
export type PrincipalArn = string;
export interface Principal {
    service?: string | undefined;
    arn?: string | undefined;
}
export type PrincipalList = Principal[];
export type Operation = string;
export type OperationList = string[];
export type ConditionOperator = string;
export type ConditionKey = string;
export type ConditionValue = string;
export type ConditionKeyValueMap = {
    [key: string]: string | undefined;
};
export type ConditionMap = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export interface CreateResourcePolicyStatementRequest {
    resourceArn: string;
    statementId: string;
    effect: Effect;
    principal: Principal[];
    action: string[];
    condition?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    expectedRevisionId?: string | undefined;
}
export interface CreateResourcePolicyStatementResponse {
    resourceArn?: string | undefined;
    revisionId?: string | undefined;
}
export type BuiltInOrCustomSlotTypeId = string;
export type SlotDefaultValueString = string;
export interface SlotDefaultValue {
    defaultValue: string;
}
export type SlotDefaultValueList = SlotDefaultValue[];
export interface SlotDefaultValueSpecification {
    defaultValueList: SlotDefaultValue[];
}
export type SlotConstraint = "Required" | "Optional" | (string & {});
export type StillWaitingResponseFrequency = number;
export type StillWaitingResponseTimeout = number;
export interface StillWaitingResponseSpecification {
    messageGroups: MessageGroup[];
    frequencyInSeconds: number;
    timeoutInSeconds: number;
    allowInterrupt?: boolean | undefined;
}
export interface WaitAndContinueSpecification {
    waitingResponse?: ResponseSpecification | undefined;
    continueResponse?: ResponseSpecification | undefined;
    stillWaitingResponse?: StillWaitingResponseSpecification | undefined;
    active?: boolean | undefined;
}
export interface SlotCaptureSetting {
    captureResponse?: ResponseSpecification | undefined;
    captureNextStep?: DialogState | undefined;
    captureConditional?: ConditionalSpecification | undefined;
    failureResponse?: ResponseSpecification | undefined;
    failureNextStep?: DialogState | undefined;
    failureConditional?: ConditionalSpecification | undefined;
    codeHook?: DialogCodeHookInvocationSetting | undefined;
    elicitationCodeHook?: ElicitationCodeHookInvocationSetting | undefined;
}
export type SlotResolutionStrategy = "EnhancedFallback" | "Default" | (string & {});
export interface SlotResolutionSetting {
    slotResolutionStrategy: SlotResolutionStrategy;
}
export interface SlotValueElicitationSetting {
    defaultValueSpecification?: SlotDefaultValueSpecification | undefined;
    slotConstraint: SlotConstraint;
    promptSpecification?: PromptSpecification | undefined;
    sampleUtterances?: SampleUtterance[] | undefined;
    waitAndContinueSpecification?: WaitAndContinueSpecification | undefined;
    slotCaptureSetting?: SlotCaptureSetting | undefined;
    slotResolutionSetting?: SlotResolutionSetting | undefined;
}
export type ObfuscationSettingType = "None" | "DefaultObfuscation" | (string & {});
export interface ObfuscationSetting {
    obfuscationSettingType: ObfuscationSettingType;
}
export interface MultipleValuesSetting {
    allowMultipleValues?: boolean | undefined;
}
export type SubSlotExpression = string;
export interface SubSlotValueElicitationSetting {
    defaultValueSpecification?: SlotDefaultValueSpecification | undefined;
    promptSpecification: PromptSpecification;
    sampleUtterances?: SampleUtterance[] | undefined;
    waitAndContinueSpecification?: WaitAndContinueSpecification | undefined;
}
export interface Specifications {
    slotTypeId: string;
    valueElicitationSetting: SubSlotValueElicitationSetting;
}
export type SubSlotSpecificationMap = {
    [key: string]: Specifications | undefined;
};
export interface SubSlotSetting {
    expression?: string | undefined;
    slotSpecifications?: {
        [key: string]: Specifications | undefined;
    } | undefined;
}
export interface CreateSlotRequest {
    slotName: string;
    description?: string | undefined;
    slotTypeId?: string | undefined;
    valueElicitationSetting: SlotValueElicitationSetting;
    obfuscationSetting?: ObfuscationSetting | undefined;
    botId: string;
    botVersion: string;
    localeId: string;
    intentId: string;
    multipleValuesSetting?: MultipleValuesSetting | undefined;
    subSlotSetting?: SubSlotSetting | undefined;
}
export interface CreateSlotResponse {
    slotId?: string | undefined;
    slotName?: string | undefined;
    description?: string | undefined;
    slotTypeId?: string | undefined;
    valueElicitationSetting?: SlotValueElicitationSetting | undefined;
    obfuscationSetting?: ObfuscationSetting | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    intentId?: string | undefined;
    creationDateTime?: Date | undefined;
    multipleValuesSetting?: MultipleValuesSetting | undefined;
    subSlotSetting?: SubSlotSetting | undefined;
}
export type Value = string;
export interface SampleValue {
    value: string;
}
export type SynonymList = SampleValue[];
export interface SlotTypeValue {
    sampleValue?: SampleValue | undefined;
    synonyms?: SampleValue[] | undefined;
}
export type SlotTypeValues = SlotTypeValue[];
export type SlotValueResolutionStrategy = "OriginalValue" | "TopResolution" | "Concatenation" | (string & {});
export type RegexPattern = string;
export interface SlotValueRegexFilter {
    pattern: string;
}
export type AudioRecognitionStrategy = "UseSlotValuesAsCustomVocabulary" | (string & {});
export interface AdvancedRecognitionSetting {
    audioRecognitionStrategy?: AudioRecognitionStrategy | undefined;
}
export interface SlotValueSelectionSetting {
    resolutionStrategy: SlotValueResolutionStrategy;
    regexFilter?: SlotValueRegexFilter | undefined;
    advancedRecognitionSetting?: AdvancedRecognitionSetting | undefined;
}
export type SlotTypeSignature = string;
export type S3BucketName = string;
export type S3ObjectPath = string;
export interface GrammarSlotTypeSource {
    s3BucketName: string;
    s3ObjectKey: string;
    kmsKeyArn?: string | undefined;
}
export interface GrammarSlotTypeSetting {
    source?: GrammarSlotTypeSource | undefined;
}
export interface ExternalSourceSetting {
    grammarSlotTypeSetting?: GrammarSlotTypeSetting | undefined;
}
export interface SubSlotTypeComposition {
    name: string;
    slotTypeId: string;
}
export type SubSlotTypeList = SubSlotTypeComposition[];
export interface CompositeSlotTypeSetting {
    subSlots?: SubSlotTypeComposition[] | undefined;
}
export interface CreateSlotTypeRequest {
    slotTypeName: string;
    description?: string | undefined;
    slotTypeValues?: SlotTypeValue[] | undefined;
    valueSelectionSetting?: SlotValueSelectionSetting | undefined;
    parentSlotTypeSignature?: string | undefined;
    botId: string;
    botVersion: string;
    localeId: string;
    externalSourceSetting?: ExternalSourceSetting | undefined;
    compositeSlotTypeSetting?: CompositeSlotTypeSetting | undefined;
}
export interface CreateSlotTypeResponse {
    slotTypeId?: string | undefined;
    slotTypeName?: string | undefined;
    description?: string | undefined;
    slotTypeValues?: SlotTypeValue[] | undefined;
    valueSelectionSetting?: SlotValueSelectionSetting | undefined;
    parentSlotTypeSignature?: string | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    creationDateTime?: Date | undefined;
    externalSourceSetting?: ExternalSourceSetting | undefined;
    compositeSlotTypeSetting?: CompositeSlotTypeSetting | undefined;
}
export interface TestSetDiscrepancyReportBotAliasTarget {
    botId: string;
    botAliasId: string;
    localeId: string;
}
export interface TestSetDiscrepancyReportResourceTarget {
    botAliasTarget?: TestSetDiscrepancyReportBotAliasTarget | undefined;
}
export interface CreateTestSetDiscrepancyReportRequest {
    testSetId: string;
    target: TestSetDiscrepancyReportResourceTarget;
}
export interface CreateTestSetDiscrepancyReportResponse {
    testSetDiscrepancyReportId?: string | undefined;
    creationDateTime?: Date | undefined;
    testSetId?: string | undefined;
    target?: TestSetDiscrepancyReportResourceTarget | undefined;
}
export interface CreateUploadUrlRequest {
}
export type PresignedS3Url = string;
export interface CreateUploadUrlResponse {
    importId?: string | undefined;
    uploadUrl?: string | undefined;
}
export type SkipResourceInUseCheck = boolean;
export interface DeleteBotRequest {
    botId: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteBotResponse {
    botId?: string | undefined;
    botStatus?: BotStatus | undefined;
}
export interface DeleteBotAliasRequest {
    botAliasId: string;
    botId: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteBotAliasResponse {
    botAliasId?: string | undefined;
    botId?: string | undefined;
    botAliasStatus?: BotAliasStatus | undefined;
}
export type UUID = string;
export interface DeleteBotAnalyzerRecommendationRequest {
    botId: string;
    botAnalyzerRequestId: string;
}
export interface DeleteBotAnalyzerRecommendationResponse {
}
export interface DeleteBotLocaleRequest {
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface DeleteBotLocaleResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botLocaleStatus?: BotLocaleStatus | undefined;
}
export interface DeleteBotReplicaRequest {
    botId: string;
    replicaRegion: string;
}
export interface DeleteBotReplicaResponse {
    botId?: string | undefined;
    replicaRegion?: string | undefined;
    botReplicaStatus?: BotReplicaStatus | undefined;
}
export interface DeleteBotVersionRequest {
    botId: string;
    botVersion: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteBotVersionResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    botStatus?: BotStatus | undefined;
}
export interface DeleteCustomVocabularyRequest {
    botId: string;
    botVersion: string;
    localeId: string;
}
export type CustomVocabularyStatus = "Ready" | "Deleting" | "Exporting" | "Importing" | "Creating" | (string & {});
export interface DeleteCustomVocabularyResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    customVocabularyStatus?: CustomVocabularyStatus | undefined;
}
export interface DeleteExportRequest {
    exportId: string;
}
export interface DeleteExportResponse {
    exportId?: string | undefined;
    exportStatus?: ExportStatus | undefined;
}
export interface DeleteImportRequest {
    importId: string;
}
export type ImportStatus = "InProgress" | "Completed" | "Failed" | "Deleting" | (string & {});
export interface DeleteImportResponse {
    importId?: string | undefined;
    importStatus?: ImportStatus | undefined;
}
export interface DeleteIntentRequest {
    intentId: string;
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface DeleteIntentResponse {
}
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
    expectedRevisionId?: string | undefined;
}
export interface DeleteResourcePolicyResponse {
    resourceArn?: string | undefined;
    revisionId?: string | undefined;
}
export interface DeleteResourcePolicyStatementRequest {
    resourceArn: string;
    statementId: string;
    expectedRevisionId?: string | undefined;
}
export interface DeleteResourcePolicyStatementResponse {
    resourceArn?: string | undefined;
    revisionId?: string | undefined;
}
export interface DeleteSlotRequest {
    slotId: string;
    botId: string;
    botVersion: string;
    localeId: string;
    intentId: string;
}
export interface DeleteSlotResponse {
}
export interface DeleteSlotTypeRequest {
    slotTypeId: string;
    botId: string;
    botVersion: string;
    localeId: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteSlotTypeResponse {
}
export interface DeleteTestSetRequest {
    testSetId: string;
}
export interface DeleteTestSetResponse {
}
export type SessionId = string;
export interface DeleteUtterancesRequest {
    botId: string;
    localeId?: string | undefined;
    sessionId?: string | undefined;
}
export interface DeleteUtterancesResponse {
}
export interface DescribeBotRequest {
    botId: string;
}
export type FailureReason = string;
export type FailureReasons = string[];
export interface DescribeBotResponse {
    botId?: string | undefined;
    botName?: string | undefined;
    description?: string | undefined;
    roleArn?: string | undefined;
    dataPrivacy?: DataPrivacy | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    botStatus?: BotStatus | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    botType?: BotType | undefined;
    botMembers?: BotMember[] | undefined;
    failureReasons?: string[] | undefined;
    errorLogSettings?: ErrorLogSettings | undefined;
}
export interface DescribeBotAliasRequest {
    botAliasId: string;
    botId: string;
}
export interface BotAliasHistoryEvent {
    botVersion?: string | undefined;
    startDate?: Date | undefined;
    endDate?: Date | undefined;
}
export type BotAliasHistoryEventsList = BotAliasHistoryEvent[];
export interface ParentBotNetwork {
    botId: string;
    botVersion: string;
}
export type ParentBotNetworks = ParentBotNetwork[];
export interface DescribeBotAliasResponse {
    botAliasId?: string | undefined;
    botAliasName?: string | undefined;
    description?: string | undefined;
    botVersion?: string | undefined;
    botAliasLocaleSettings?: {
        [key: string]: BotAliasLocaleSettings | undefined;
    } | undefined;
    conversationLogSettings?: ConversationLogSettings | undefined;
    sentimentAnalysisSettings?: SentimentAnalysisSettings | undefined;
    botAliasHistoryEvents?: BotAliasHistoryEvent[] | undefined;
    botAliasStatus?: BotAliasStatus | undefined;
    botId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    parentBotNetworks?: ParentBotNetwork[] | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface DescribeBotAnalyzerRecommendationRequest {
    botId: string;
    botAnalyzerRequestId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type BotAnalyzerStatus = "Processing" | "Available" | "Failed" | "Stopping" | "Stopped" | (string & {});
export interface IssueLocation {
    botLocale?: string | undefined;
    intentId?: string | undefined;
    slotId?: string | undefined;
}
export type Priority = "High" | "Medium" | "Low" | (string & {});
export interface BotAnalyzerRecommendation {
    issueLocation: IssueLocation;
    priority: Priority;
    issueDescription: string;
    proposedFix: string;
}
export type BotAnalyzerRecommendationList = BotAnalyzerRecommendation[];
export interface DescribeBotAnalyzerRecommendationResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botAnalyzerStatus?: BotAnalyzerStatus | undefined;
    creationDateTime?: Date | undefined;
    botAnalyzerRecommendationList?: BotAnalyzerRecommendation[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeBotLocaleRequest {
    botId: string;
    botVersion: string;
    localeId: string;
}
export type ResourceCount = number;
export type BotLocaleHistoryEventDescription = string;
export interface BotLocaleHistoryEvent {
    event: string;
    eventDate: Date;
}
export type BotLocaleHistoryEventsList = BotLocaleHistoryEvent[];
export type RecommendedAction = string;
export type RecommendedActions = string[];
export interface DescribeBotLocaleResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    localeName?: string | undefined;
    description?: string | undefined;
    nluIntentConfidenceThreshold?: number | undefined;
    voiceSettings?: VoiceSettings | undefined;
    unifiedSpeechSettings?: UnifiedSpeechSettings | undefined;
    audioFillerSettings?: AudioFillerSettings | undefined;
    speechRecognitionSettings?: SpeechRecognitionSettings | undefined;
    intentsCount?: number | undefined;
    slotTypesCount?: number | undefined;
    botLocaleStatus?: BotLocaleStatus | undefined;
    failureReasons?: string[] | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    lastBuildSubmittedDateTime?: Date | undefined;
    botLocaleHistoryEvents?: BotLocaleHistoryEvent[] | undefined;
    recommendedActions?: string[] | undefined;
    generativeAISettings?: GenerativeAISettings | undefined;
    speechDetectionSensitivity?: SpeechDetectionSensitivity | undefined;
    speakerDiarizationSettings?: SpeakerDiarizationSettings | undefined;
}
export interface DescribeBotRecommendationRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    botRecommendationId: string;
}
export type BotRecommendationStatus = "Processing" | "Deleting" | "Deleted" | "Downloading" | "Updating" | "Available" | "Failed" | "Stopping" | "Stopped" | (string & {});
export type ObjectPrefix = string;
export type ObjectPrefixes = string[];
export interface PathFormat {
    objectPrefixes?: string[] | undefined;
}
export type TranscriptFormat = "Lex" | (string & {});
export interface DateRangeFilter {
    startDateTime: Date;
    endDateTime: Date;
}
export interface LexTranscriptFilter {
    dateRangeFilter?: DateRangeFilter | undefined;
}
export interface TranscriptFilter {
    lexTranscriptFilter?: LexTranscriptFilter | undefined;
}
export interface S3BucketTranscriptSource {
    s3BucketName: string;
    pathFormat?: PathFormat | undefined;
    transcriptFormat: TranscriptFormat;
    transcriptFilter?: TranscriptFilter | undefined;
    kmsKeyArn?: string | undefined;
}
export interface TranscriptSourceSetting {
    s3BucketTranscriptSource?: S3BucketTranscriptSource | undefined;
}
export type FilePassword = string | redacted.Redacted<string>;
export interface EncryptionSetting {
    kmsKeyArn?: string | undefined;
    botLocaleExportPassword?: string | redacted.Redacted<string> | undefined;
    associatedTranscriptsPassword?: string | redacted.Redacted<string> | undefined;
}
export type Count = number;
export interface IntentStatistics {
    discoveredIntentCount?: number | undefined;
}
export interface SlotTypeStatistics {
    discoveredSlotTypeCount?: number | undefined;
}
export interface BotRecommendationResultStatistics {
    intents?: IntentStatistics | undefined;
    slotTypes?: SlotTypeStatistics | undefined;
}
export interface BotRecommendationResults {
    botLocaleExportUrl?: string | undefined;
    associatedTranscriptsUrl?: string | undefined;
    statistics?: BotRecommendationResultStatistics | undefined;
}
export interface DescribeBotRecommendationResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botRecommendationStatus?: BotRecommendationStatus | undefined;
    botRecommendationId?: string | undefined;
    failureReasons?: string[] | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    transcriptSourceSetting?: TranscriptSourceSetting | undefined;
    encryptionSetting?: EncryptionSetting | undefined;
    botRecommendationResults?: BotRecommendationResults | undefined;
}
export interface DescribeBotReplicaRequest {
    botId: string;
    replicaRegion: string;
}
export interface DescribeBotReplicaResponse {
    botId?: string | undefined;
    replicaRegion?: string | undefined;
    sourceRegion?: string | undefined;
    creationDateTime?: Date | undefined;
    botReplicaStatus?: BotReplicaStatus | undefined;
    failureReasons?: string[] | undefined;
}
export interface DescribeBotResourceGenerationRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    generationId: string;
}
export type GenerationStatus = "Failed" | "Complete" | "InProgress" | (string & {});
export type GenerationInput = string;
export interface DescribeBotResourceGenerationResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    generationId?: string | undefined;
    failureReasons?: string[] | undefined;
    generationStatus?: GenerationStatus | undefined;
    generationInputPrompt?: string | undefined;
    generatedBotLocaleUrl?: string | undefined;
    creationDateTime?: Date | undefined;
    modelArn?: string | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeBotVersionRequest {
    botId: string;
    botVersion: string;
}
export interface DescribeBotVersionResponse {
    botId?: string | undefined;
    botName?: string | undefined;
    botVersion?: string | undefined;
    description?: string | undefined;
    roleArn?: string | undefined;
    dataPrivacy?: DataPrivacy | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    botStatus?: BotStatus | undefined;
    failureReasons?: string[] | undefined;
    creationDateTime?: Date | undefined;
    parentBotNetworks?: ParentBotNetwork[] | undefined;
    botType?: BotType | undefined;
    botMembers?: BotMember[] | undefined;
}
export interface DescribeCustomVocabularyMetadataRequest {
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface DescribeCustomVocabularyMetadataResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    customVocabularyStatus?: CustomVocabularyStatus | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeExportRequest {
    exportId: string;
}
export interface DescribeExportResponse {
    exportId?: string | undefined;
    resourceSpecification?: ExportResourceSpecification | undefined;
    fileFormat?: ImportExportFileFormat | undefined;
    exportStatus?: ExportStatus | undefined;
    failureReasons?: string[] | undefined;
    downloadUrl?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeImportRequest {
    importId: string;
}
export interface BotImportSpecification {
    botName: string;
    roleArn: string;
    dataPrivacy: DataPrivacy;
    errorLogSettings?: ErrorLogSettings | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    botTags?: {
        [key: string]: string | undefined;
    } | undefined;
    testBotAliasTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface BotLocaleImportSpecification {
    botId: string;
    botVersion: string;
    localeId: string;
    nluIntentConfidenceThreshold?: number | undefined;
    voiceSettings?: VoiceSettings | undefined;
    speechRecognitionSettings?: SpeechRecognitionSettings | undefined;
    speechDetectionSensitivity?: SpeechDetectionSensitivity | undefined;
    unifiedSpeechSettings?: UnifiedSpeechSettings | undefined;
    audioFillerSettings?: AudioFillerSettings | undefined;
    speakerDiarizationSettings?: SpeakerDiarizationSettings | undefined;
}
export interface CustomVocabularyImportSpecification {
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface TestSetStorageLocation {
    s3BucketName: string;
    s3Path: string;
    kmsKeyArn?: string | undefined;
}
export interface TestSetImportInputLocation {
    s3BucketName: string;
    s3Path: string;
}
export type TestSetModality = "Text" | "Audio" | (string & {});
export interface TestSetImportResourceSpecification {
    testSetName: string;
    description?: string | undefined;
    roleArn: string;
    storageLocation: TestSetStorageLocation;
    importInputLocation: TestSetImportInputLocation;
    modality: TestSetModality;
    testSetTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ImportResourceSpecification {
    botImportSpecification?: BotImportSpecification | undefined;
    botLocaleImportSpecification?: BotLocaleImportSpecification | undefined;
    customVocabularyImportSpecification?: CustomVocabularyImportSpecification | undefined;
    testSetImportResourceSpecification?: TestSetImportResourceSpecification | undefined;
}
export type ImportedResourceId = string;
export type MergeStrategy = "Overwrite" | "FailOnConflict" | "Append" | (string & {});
export interface DescribeImportResponse {
    importId?: string | undefined;
    resourceSpecification?: ImportResourceSpecification | undefined;
    importedResourceId?: string | undefined;
    importedResourceName?: string | undefined;
    mergeStrategy?: MergeStrategy | undefined;
    importStatus?: ImportStatus | undefined;
    failureReasons?: string[] | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeIntentRequest {
    intentId: string;
    botId: string;
    botVersion: string;
    localeId: string;
}
export type PriorityValue = number;
export interface SlotPriority {
    priority: number;
    slotId: string;
}
export type SlotPrioritiesList = SlotPriority[];
export interface DescribeIntentResponse {
    intentId?: string | undefined;
    intentName?: string | undefined;
    intentDisplayName?: string | undefined;
    description?: string | undefined;
    parentIntentSignature?: string | undefined;
    sampleUtterances?: SampleUtterance[] | undefined;
    dialogCodeHook?: DialogCodeHookSettings | undefined;
    fulfillmentCodeHook?: FulfillmentCodeHookSettings | undefined;
    slotPriorities?: SlotPriority[] | undefined;
    intentConfirmationSetting?: IntentConfirmationSetting | undefined;
    intentClosingSetting?: IntentClosingSetting | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    initialResponseSetting?: InitialResponseSetting | undefined;
    qnAIntentConfiguration?: QnAIntentConfiguration | undefined;
    qInConnectIntentConfiguration?: QInConnectIntentConfiguration | undefined;
}
export interface DescribeResourcePolicyRequest {
    resourceArn: string;
}
export interface DescribeResourcePolicyResponse {
    resourceArn?: string | undefined;
    policy?: string | undefined;
    revisionId?: string | undefined;
}
export interface DescribeSlotRequest {
    slotId: string;
    botId: string;
    botVersion: string;
    localeId: string;
    intentId: string;
}
export interface DescribeSlotResponse {
    slotId?: string | undefined;
    slotName?: string | undefined;
    description?: string | undefined;
    slotTypeId?: string | undefined;
    valueElicitationSetting?: SlotValueElicitationSetting | undefined;
    obfuscationSetting?: ObfuscationSetting | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    intentId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    multipleValuesSetting?: MultipleValuesSetting | undefined;
    subSlotSetting?: SubSlotSetting | undefined;
}
export interface DescribeSlotTypeRequest {
    slotTypeId: string;
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface DescribeSlotTypeResponse {
    slotTypeId?: string | undefined;
    slotTypeName?: string | undefined;
    description?: string | undefined;
    slotTypeValues?: SlotTypeValue[] | undefined;
    valueSelectionSetting?: SlotValueSelectionSetting | undefined;
    parentSlotTypeSignature?: string | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    externalSourceSetting?: ExternalSourceSetting | undefined;
    compositeSlotTypeSetting?: CompositeSlotTypeSetting | undefined;
}
export interface DescribeTestExecutionRequest {
    testExecutionId: string;
}
export type TestExecutionStatus = "Pending" | "Waiting" | "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export interface BotAliasTestExecutionTarget {
    botId: string;
    botAliasId: string;
    localeId: string;
}
export interface TestExecutionTarget {
    botAliasTarget?: BotAliasTestExecutionTarget | undefined;
}
export type TestExecutionApiMode = "Streaming" | "NonStreaming" | (string & {});
export type TestExecutionModality = "Text" | "Audio" | (string & {});
export interface DescribeTestExecutionResponse {
    testExecutionId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    testExecutionStatus?: TestExecutionStatus | undefined;
    testSetId?: string | undefined;
    testSetName?: string | undefined;
    target?: TestExecutionTarget | undefined;
    apiMode?: TestExecutionApiMode | undefined;
    testExecutionModality?: TestExecutionModality | undefined;
    failureReasons?: string[] | undefined;
}
export interface DescribeTestSetRequest {
    testSetId: string;
}
export type TestSetStatus = "Importing" | "PendingAnnotation" | "Deleting" | "ValidationError" | "Ready" | (string & {});
export interface DescribeTestSetResponse {
    testSetId?: string | undefined;
    testSetName?: string | undefined;
    description?: string | undefined;
    modality?: TestSetModality | undefined;
    status?: TestSetStatus | undefined;
    roleArn?: string | undefined;
    numTurns?: number | undefined;
    storageLocation?: TestSetStorageLocation | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeTestSetDiscrepancyReportRequest {
    testSetDiscrepancyReportId: string;
}
export type TestSetDiscrepancyReportStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export interface TestSetIntentDiscrepancyItem {
    intentName: string;
    errorMessage: string;
}
export type TestSetIntentDiscrepancyList = TestSetIntentDiscrepancyItem[];
export interface TestSetSlotDiscrepancyItem {
    intentName: string;
    slotName: string;
    errorMessage: string;
}
export type TestSetSlotDiscrepancyList = TestSetSlotDiscrepancyItem[];
export interface TestSetDiscrepancyErrors {
    intentDiscrepancies: TestSetIntentDiscrepancyItem[];
    slotDiscrepancies: TestSetSlotDiscrepancyItem[];
}
export interface DescribeTestSetDiscrepancyReportResponse {
    testSetDiscrepancyReportId?: string | undefined;
    testSetId?: string | undefined;
    creationDateTime?: Date | undefined;
    target?: TestSetDiscrepancyReportResourceTarget | undefined;
    testSetDiscrepancyReportStatus?: TestSetDiscrepancyReportStatus | undefined;
    lastUpdatedDataTime?: Date | undefined;
    testSetDiscrepancyTopErrors?: TestSetDiscrepancyErrors | undefined;
    testSetDiscrepancyRawOutputUrl?: string | undefined;
    failureReasons?: string[] | undefined;
}
export interface DescribeTestSetGenerationRequest {
    testSetGenerationId: string;
}
export type TestSetGenerationStatus = "Generating" | "Ready" | "Failed" | "Pending" | (string & {});
export type ConversationLogsInputModeFilter = "Speech" | "Text" | (string & {});
export interface ConversationLogsDataSourceFilterBy {
    startTime: Date;
    endTime: Date;
    inputMode: ConversationLogsInputModeFilter;
}
export interface ConversationLogsDataSource {
    botId: string;
    botAliasId: string;
    localeId: string;
    filter: ConversationLogsDataSourceFilterBy;
}
export interface TestSetGenerationDataSource {
    conversationLogsDataSource?: ConversationLogsDataSource | undefined;
}
export interface DescribeTestSetGenerationResponse {
    testSetGenerationId?: string | undefined;
    testSetGenerationStatus?: TestSetGenerationStatus | undefined;
    failureReasons?: string[] | undefined;
    testSetId?: string | undefined;
    testSetName?: string | undefined;
    description?: string | undefined;
    storageLocation?: TestSetStorageLocation | undefined;
    generationDataSource?: TestSetGenerationDataSource | undefined;
    roleArn?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface GenerateBotElementRequest {
    intentId: string;
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface GenerateBotElementResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    intentId?: string | undefined;
    sampleUtterances?: SampleUtterance[] | undefined;
}
export interface GetTestExecutionArtifactsUrlRequest {
    testExecutionId: string;
}
export interface GetTestExecutionArtifactsUrlResponse {
    testExecutionId?: string | undefined;
    downloadArtifactsUrl?: string | undefined;
}
export type TimeDimension = "Hours" | "Days" | "Weeks" | (string & {});
export type TimeValue = number;
export interface RelativeAggregationDuration {
    timeDimension: TimeDimension;
    timeValue: number;
}
export interface UtteranceAggregationDuration {
    relativeAggregationDuration: RelativeAggregationDuration;
}
export type AggregatedUtterancesSortAttribute = "HitCount" | "MissedCount" | (string & {});
export type SortOrder = "Ascending" | "Descending" | (string & {});
export interface AggregatedUtterancesSortBy {
    attribute: AggregatedUtterancesSortAttribute;
    order: SortOrder;
}
export type AggregatedUtterancesFilterName = "Utterance" | (string & {});
export type FilterValue = string;
export type FilterValues = string[];
export type AggregatedUtterancesFilterOperator = "CO" | "EQ" | (string & {});
export interface AggregatedUtterancesFilter {
    name: AggregatedUtterancesFilterName;
    values: string[];
    operator: AggregatedUtterancesFilterOperator;
}
export type AggregatedUtterancesFilters = AggregatedUtterancesFilter[];
export interface ListAggregatedUtterancesRequest {
    botId: string;
    botAliasId?: string | undefined;
    botVersion?: string | undefined;
    localeId: string;
    aggregationDuration: UtteranceAggregationDuration;
    sortBy?: AggregatedUtterancesSortBy | undefined;
    filters?: AggregatedUtterancesFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type HitCount = number;
export type MissedCount = number;
export interface AggregatedUtterancesSummary {
    utterance?: string | undefined;
    hitCount?: number | undefined;
    missedCount?: number | undefined;
    utteranceFirstRecordedInAggregationDuration?: Date | undefined;
    utteranceLastRecordedInAggregationDuration?: Date | undefined;
    containsDataFromDeletedResources?: boolean | undefined;
}
export type AggregatedUtterancesSummaryList = AggregatedUtterancesSummary[];
export interface ListAggregatedUtterancesResponse {
    botId?: string | undefined;
    botAliasId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    aggregationDuration?: UtteranceAggregationDuration | undefined;
    aggregationWindowStartTime?: Date | undefined;
    aggregationWindowEndTime?: Date | undefined;
    aggregationLastRefreshedDateTime?: Date | undefined;
    aggregatedUtterancesSummaries?: AggregatedUtterancesSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBotAliasesRequest {
    botId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BotAliasSummary {
    botAliasId?: string | undefined;
    botAliasName?: string | undefined;
    description?: string | undefined;
    botVersion?: string | undefined;
    botAliasStatus?: BotAliasStatus | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type BotAliasSummaryList = BotAliasSummary[];
export interface ListBotAliasesResponse {
    botAliasSummaries?: BotAliasSummary[] | undefined;
    nextToken?: string | undefined;
    botId?: string | undefined;
}
export interface ListBotAliasReplicasRequest {
    botId: string;
    replicaRegion: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type BotAliasReplicationStatus = "Creating" | "Updating" | "Available" | "Deleting" | "Failed" | (string & {});
export interface BotAliasReplicaSummary {
    botAliasId?: string | undefined;
    botAliasReplicationStatus?: BotAliasReplicationStatus | undefined;
    botVersion?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReasons?: string[] | undefined;
}
export type BotAliasReplicaSummaryList = BotAliasReplicaSummary[];
export interface ListBotAliasReplicasResponse {
    botId?: string | undefined;
    sourceRegion?: string | undefined;
    replicaRegion?: string | undefined;
    botAliasReplicaSummaries?: BotAliasReplicaSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBotAnalyzerHistoryRequest {
    botId: string;
    localeId?: string | undefined;
    botVersion?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BotAnalyzerHistorySummary {
    botAnalyzerStatus: BotAnalyzerStatus;
    creationDateTime?: Date | undefined;
    botAnalyzerRequestId: string;
}
export type BotAnalyzerHistoryList = BotAnalyzerHistorySummary[];
export interface ListBotAnalyzerHistoryResponse {
    botId?: string | undefined;
    localeId?: string | undefined;
    botVersion?: string | undefined;
    botAnalyzerHistoryList?: BotAnalyzerHistorySummary[] | undefined;
    nextToken?: string | undefined;
}
export type BotLocaleSortAttribute = "BotLocaleName" | (string & {});
export interface BotLocaleSortBy {
    attribute: BotLocaleSortAttribute;
    order: SortOrder;
}
export type BotLocaleFilterName = "BotLocaleName" | (string & {});
export type BotLocaleFilterOperator = "CO" | "EQ" | (string & {});
export interface BotLocaleFilter {
    name: BotLocaleFilterName;
    values: string[];
    operator: BotLocaleFilterOperator;
}
export type BotLocaleFilters = BotLocaleFilter[];
export interface ListBotLocalesRequest {
    botId: string;
    botVersion: string;
    sortBy?: BotLocaleSortBy | undefined;
    filters?: BotLocaleFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BotLocaleSummary {
    localeId?: string | undefined;
    localeName?: string | undefined;
    description?: string | undefined;
    botLocaleStatus?: BotLocaleStatus | undefined;
    lastUpdatedDateTime?: Date | undefined;
    lastBuildSubmittedDateTime?: Date | undefined;
}
export type BotLocaleSummaryList = BotLocaleSummary[];
export interface ListBotLocalesResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    nextToken?: string | undefined;
    botLocaleSummaries?: BotLocaleSummary[] | undefined;
}
export interface ListBotRecommendationsRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BotRecommendationSummary {
    botRecommendationStatus: BotRecommendationStatus;
    botRecommendationId: string;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type BotRecommendationSummaryList = BotRecommendationSummary[];
export interface ListBotRecommendationsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botRecommendationSummaries?: BotRecommendationSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBotReplicasRequest {
    botId: string;
}
export interface BotReplicaSummary {
    replicaRegion?: string | undefined;
    creationDateTime?: Date | undefined;
    botReplicaStatus?: BotReplicaStatus | undefined;
    failureReasons?: string[] | undefined;
}
export type BotReplicaSummaryList = BotReplicaSummary[];
export interface ListBotReplicasResponse {
    botId?: string | undefined;
    sourceRegion?: string | undefined;
    botReplicaSummaries?: BotReplicaSummary[] | undefined;
}
export type GenerationSortByAttribute = "creationStartTime" | "lastUpdatedTime" | (string & {});
export interface GenerationSortBy {
    attribute: GenerationSortByAttribute;
    order: SortOrder;
}
export interface ListBotResourceGenerationsRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    sortBy?: GenerationSortBy | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GenerationSummary {
    generationId?: string | undefined;
    generationStatus?: GenerationStatus | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type GenerationSummaryList = GenerationSummary[];
export interface ListBotResourceGenerationsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    generationSummaries?: GenerationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type BotSortAttribute = "BotName" | (string & {});
export interface BotSortBy {
    attribute: BotSortAttribute;
    order: SortOrder;
}
export type BotFilterName = "BotName" | "BotType" | (string & {});
export type BotFilterOperator = "CO" | "EQ" | "NE" | (string & {});
export interface BotFilter {
    name: BotFilterName;
    values: string[];
    operator: BotFilterOperator;
}
export type BotFilters = BotFilter[];
export interface ListBotsRequest {
    sortBy?: BotSortBy | undefined;
    filters?: BotFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BotSummary {
    botId?: string | undefined;
    botName?: string | undefined;
    description?: string | undefined;
    botStatus?: BotStatus | undefined;
    latestBotVersion?: string | undefined;
    lastUpdatedDateTime?: Date | undefined;
    botType?: BotType | undefined;
}
export type BotSummaryList = BotSummary[];
export interface ListBotsResponse {
    botSummaries?: BotSummary[] | undefined;
    nextToken?: string | undefined;
}
export type BotVersionReplicaSortAttribute = "BotVersion" | (string & {});
export interface BotVersionReplicaSortBy {
    attribute: BotVersionReplicaSortAttribute;
    order: SortOrder;
}
export interface ListBotVersionReplicasRequest {
    botId: string;
    replicaRegion: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: BotVersionReplicaSortBy | undefined;
}
export type BotVersionReplicationStatus = "Creating" | "Available" | "Deleting" | "Failed" | (string & {});
export interface BotVersionReplicaSummary {
    botVersion?: string | undefined;
    botVersionReplicationStatus?: BotVersionReplicationStatus | undefined;
    creationDateTime?: Date | undefined;
    failureReasons?: string[] | undefined;
}
export type BotVersionReplicaSummaryList = BotVersionReplicaSummary[];
export interface ListBotVersionReplicasResponse {
    botId?: string | undefined;
    sourceRegion?: string | undefined;
    replicaRegion?: string | undefined;
    botVersionReplicaSummaries?: BotVersionReplicaSummary[] | undefined;
    nextToken?: string | undefined;
}
export type BotVersionSortAttribute = "BotVersion" | (string & {});
export interface BotVersionSortBy {
    attribute: BotVersionSortAttribute;
    order: SortOrder;
}
export interface ListBotVersionsRequest {
    botId: string;
    sortBy?: BotVersionSortBy | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BotVersionSummary {
    botName?: string | undefined;
    botVersion?: string | undefined;
    description?: string | undefined;
    botStatus?: BotStatus | undefined;
    creationDateTime?: Date | undefined;
}
export type BotVersionSummaryList = BotVersionSummary[];
export interface ListBotVersionsResponse {
    botId?: string | undefined;
    botVersionSummaries?: BotVersionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type BuiltInIntentSortAttribute = "IntentSignature" | (string & {});
export interface BuiltInIntentSortBy {
    attribute: BuiltInIntentSortAttribute;
    order: SortOrder;
}
export type BuiltInsMaxResults = number;
export interface ListBuiltInIntentsRequest {
    localeId: string;
    sortBy?: BuiltInIntentSortBy | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BuiltInIntentSummary {
    intentSignature?: string | undefined;
    description?: string | undefined;
}
export type BuiltInIntentSummaryList = BuiltInIntentSummary[];
export interface ListBuiltInIntentsResponse {
    builtInIntentSummaries?: BuiltInIntentSummary[] | undefined;
    nextToken?: string | undefined;
    localeId?: string | undefined;
}
export type BuiltInSlotTypeSortAttribute = "SlotTypeSignature" | (string & {});
export interface BuiltInSlotTypeSortBy {
    attribute: BuiltInSlotTypeSortAttribute;
    order: SortOrder;
}
export interface ListBuiltInSlotTypesRequest {
    localeId: string;
    sortBy?: BuiltInSlotTypeSortBy | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BuiltInSlotTypeSummary {
    slotTypeSignature?: string | undefined;
    description?: string | undefined;
}
export type BuiltInSlotTypeSummaryList = BuiltInSlotTypeSummary[];
export interface ListBuiltInSlotTypesResponse {
    builtInSlotTypeSummaries?: BuiltInSlotTypeSummary[] | undefined;
    nextToken?: string | undefined;
    localeId?: string | undefined;
}
export interface ListCustomVocabularyItemsRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListCustomVocabularyItemsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    customVocabularyItems?: CustomVocabularyItem[] | undefined;
    nextToken?: string | undefined;
}
export type ExportSortAttribute = "LastUpdatedDateTime" | (string & {});
export interface ExportSortBy {
    attribute: ExportSortAttribute;
    order: SortOrder;
}
export type ExportFilterName = "ExportResourceType" | (string & {});
export type ExportFilterOperator = "CO" | "EQ" | (string & {});
export interface ExportFilter {
    name: ExportFilterName;
    values: string[];
    operator: ExportFilterOperator;
}
export type ExportFilters = ExportFilter[];
export interface ListExportsRequest {
    botId?: string | undefined;
    botVersion?: string | undefined;
    sortBy?: ExportSortBy | undefined;
    filters?: ExportFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    localeId?: string | undefined;
}
export interface ExportSummary {
    exportId?: string | undefined;
    resourceSpecification?: ExportResourceSpecification | undefined;
    fileFormat?: ImportExportFileFormat | undefined;
    exportStatus?: ExportStatus | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type ExportSummaryList = ExportSummary[];
export interface ListExportsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    exportSummaries?: ExportSummary[] | undefined;
    nextToken?: string | undefined;
    localeId?: string | undefined;
}
export type ImportSortAttribute = "LastUpdatedDateTime" | (string & {});
export interface ImportSortBy {
    attribute: ImportSortAttribute;
    order: SortOrder;
}
export type ImportFilterName = "ImportResourceType" | (string & {});
export type ImportFilterOperator = "CO" | "EQ" | (string & {});
export interface ImportFilter {
    name: ImportFilterName;
    values: string[];
    operator: ImportFilterOperator;
}
export type ImportFilters = ImportFilter[];
export interface ListImportsRequest {
    botId?: string | undefined;
    botVersion?: string | undefined;
    sortBy?: ImportSortBy | undefined;
    filters?: ImportFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    localeId?: string | undefined;
}
export type ImportResourceType = "Bot" | "BotLocale" | "CustomVocabulary" | "TestSet" | (string & {});
export interface ImportSummary {
    importId?: string | undefined;
    importedResourceId?: string | undefined;
    importedResourceName?: string | undefined;
    importStatus?: ImportStatus | undefined;
    mergeStrategy?: MergeStrategy | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    importedResourceType?: ImportResourceType | undefined;
}
export type ImportSummaryList = ImportSummary[];
export interface ListImportsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    importSummaries?: ImportSummary[] | undefined;
    nextToken?: string | undefined;
    localeId?: string | undefined;
}
export type AnalyticsIntentMetricName = "Count" | "Success" | "Failure" | "Switched" | "Dropped" | (string & {});
export type AnalyticsMetricStatistic = "Sum" | "Avg" | "Max" | (string & {});
export type AnalyticsSortOrder = "Ascending" | "Descending" | (string & {});
export interface AnalyticsIntentMetric {
    name: AnalyticsIntentMetricName;
    statistic: AnalyticsMetricStatistic;
    order?: AnalyticsSortOrder | undefined;
}
export type AnalyticsIntentMetrics = AnalyticsIntentMetric[];
export type AnalyticsBinByName = "ConversationStartTime" | "UtteranceTimestamp" | (string & {});
export type AnalyticsInterval = "OneHour" | "OneDay" | (string & {});
export interface AnalyticsBinBySpecification {
    name: AnalyticsBinByName;
    interval: AnalyticsInterval;
    order?: AnalyticsSortOrder | undefined;
}
export type AnalyticsBinByList = AnalyticsBinBySpecification[];
export type AnalyticsIntentField = "IntentName" | "IntentEndState" | "IntentLevel" | (string & {});
export interface AnalyticsIntentGroupBySpecification {
    name: AnalyticsIntentField;
}
export type AnalyticsIntentGroupByList = AnalyticsIntentGroupBySpecification[];
export type AnalyticsIntentFilterName = "BotAliasId" | "BotVersion" | "LocaleId" | "Modality" | "Channel" | "SessionId" | "OriginatingRequestId" | "IntentName" | "IntentEndState" | (string & {});
export type AnalyticsFilterOperator = "EQ" | "GT" | "LT" | (string & {});
export type AnalyticsFilterValue = string;
export type AnalyticsFilterValues = string[];
export interface AnalyticsIntentFilter {
    name: AnalyticsIntentFilterName;
    operator: AnalyticsFilterOperator;
    values: string[];
}
export type AnalyticsIntentFilters = AnalyticsIntentFilter[];
export interface ListIntentMetricsRequest {
    botId: string;
    startDateTime: Date;
    endDateTime: Date;
    metrics: AnalyticsIntentMetric[];
    binBy?: AnalyticsBinBySpecification[] | undefined;
    groupBy?: AnalyticsIntentGroupBySpecification[] | undefined;
    filters?: AnalyticsIntentFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AnalyticsBinValue = number;
export interface AnalyticsBinKey {
    name?: AnalyticsBinByName | undefined;
    value?: number | undefined;
}
export type AnalyticsBinKeys = AnalyticsBinKey[];
export type AnalyticsGroupByValue = string;
export interface AnalyticsIntentGroupByKey {
    name?: AnalyticsIntentField | undefined;
    value?: string | undefined;
}
export type AnalyticsIntentGroupByKeys = AnalyticsIntentGroupByKey[];
export type AnalyticsMetricValue = number;
export interface AnalyticsIntentMetricResult {
    name?: AnalyticsIntentMetricName | undefined;
    statistic?: AnalyticsMetricStatistic | undefined;
    value?: number | undefined;
}
export type AnalyticsIntentMetricResults = AnalyticsIntentMetricResult[];
export interface AnalyticsIntentResult {
    binKeys?: AnalyticsBinKey[] | undefined;
    groupByKeys?: AnalyticsIntentGroupByKey[] | undefined;
    metricsResults?: AnalyticsIntentMetricResult[] | undefined;
}
export type AnalyticsIntentResults = AnalyticsIntentResult[];
export interface ListIntentMetricsResponse {
    botId?: string | undefined;
    results?: AnalyticsIntentResult[] | undefined;
    nextToken?: string | undefined;
}
export type AnalyticsPath = string;
export type AnalyticsCommonFilterName = "BotAliasId" | "BotVersion" | "LocaleId" | "Modality" | "Channel" | (string & {});
export interface AnalyticsPathFilter {
    name: AnalyticsCommonFilterName;
    operator: AnalyticsFilterOperator;
    values: string[];
}
export type AnalyticsPathFilters = AnalyticsPathFilter[];
export interface ListIntentPathsRequest {
    botId: string;
    startDateTime: Date;
    endDateTime: Date;
    intentPath: string;
    filters?: AnalyticsPathFilter[] | undefined;
}
export type AnalyticsNodeCount = number;
export type AnalyticsNodeLevel = number;
export type AnalyticsNodeType = "Inner" | "Exit" | (string & {});
export interface AnalyticsIntentNodeSummary {
    intentName?: string | undefined;
    intentPath?: string | undefined;
    intentCount?: number | undefined;
    intentLevel?: number | undefined;
    nodeType?: AnalyticsNodeType | undefined;
}
export type AnalyticsIntentNodeSummaries = AnalyticsIntentNodeSummary[];
export interface ListIntentPathsResponse {
    nodeSummaries?: AnalyticsIntentNodeSummary[] | undefined;
}
export type IntentSortAttribute = "IntentName" | "LastUpdatedDateTime" | (string & {});
export interface IntentSortBy {
    attribute: IntentSortAttribute;
    order: SortOrder;
}
export type IntentFilterName = "IntentName" | (string & {});
export type IntentFilterOperator = "CO" | "EQ" | (string & {});
export interface IntentFilter {
    name: IntentFilterName;
    values: string[];
    operator: IntentFilterOperator;
}
export type IntentFilters = IntentFilter[];
export interface ListIntentsRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    sortBy?: IntentSortBy | undefined;
    filters?: IntentFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface IntentSummary {
    intentId?: string | undefined;
    intentName?: string | undefined;
    intentDisplayName?: string | undefined;
    description?: string | undefined;
    parentIntentSignature?: string | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type IntentSummaryList = IntentSummary[];
export interface ListIntentsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    intentSummaries?: IntentSummary[] | undefined;
    nextToken?: string | undefined;
}
export type AnalyticsIntentStageMetricName = "Count" | "Success" | "Failed" | "Dropped" | "Retry" | (string & {});
export interface AnalyticsIntentStageMetric {
    name: AnalyticsIntentStageMetricName;
    statistic: AnalyticsMetricStatistic;
    order?: AnalyticsSortOrder | undefined;
}
export type AnalyticsIntentStageMetrics = AnalyticsIntentStageMetric[];
export type AnalyticsIntentStageField = "IntentStageName" | "SwitchedToIntent" | (string & {});
export interface AnalyticsIntentStageGroupBySpecification {
    name: AnalyticsIntentStageField;
}
export type AnalyticsIntentStageGroupByList = AnalyticsIntentStageGroupBySpecification[];
export type AnalyticsIntentStageFilterName = "BotAliasId" | "BotVersion" | "LocaleId" | "Modality" | "Channel" | "SessionId" | "OriginatingRequestId" | "IntentName" | "IntentStageName" | (string & {});
export interface AnalyticsIntentStageFilter {
    name: AnalyticsIntentStageFilterName;
    operator: AnalyticsFilterOperator;
    values: string[];
}
export type AnalyticsIntentStageFilters = AnalyticsIntentStageFilter[];
export interface ListIntentStageMetricsRequest {
    botId: string;
    startDateTime: Date;
    endDateTime: Date;
    metrics: AnalyticsIntentStageMetric[];
    binBy?: AnalyticsBinBySpecification[] | undefined;
    groupBy?: AnalyticsIntentStageGroupBySpecification[] | undefined;
    filters?: AnalyticsIntentStageFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AnalyticsIntentStageGroupByKey {
    name?: AnalyticsIntentStageField | undefined;
    value?: string | undefined;
}
export type AnalyticsIntentStageGroupByKeys = AnalyticsIntentStageGroupByKey[];
export interface AnalyticsIntentStageMetricResult {
    name?: AnalyticsIntentStageMetricName | undefined;
    statistic?: AnalyticsMetricStatistic | undefined;
    value?: number | undefined;
}
export type AnalyticsIntentStageMetricResults = AnalyticsIntentStageMetricResult[];
export interface AnalyticsIntentStageResult {
    binKeys?: AnalyticsBinKey[] | undefined;
    groupByKeys?: AnalyticsIntentStageGroupByKey[] | undefined;
    metricsResults?: AnalyticsIntentStageMetricResult[] | undefined;
}
export type AnalyticsIntentStageResults = AnalyticsIntentStageResult[];
export interface ListIntentStageMetricsResponse {
    botId?: string | undefined;
    results?: AnalyticsIntentStageResult[] | undefined;
    nextToken?: string | undefined;
}
export interface ListRecommendedIntentsRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    botRecommendationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SampleUtterancesCount = number;
export interface RecommendedIntentSummary {
    intentId?: string | undefined;
    intentName?: string | undefined;
    sampleUtterancesCount?: number | undefined;
}
export type RecommendedIntentSummaryList = RecommendedIntentSummary[];
export interface ListRecommendedIntentsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botRecommendationId?: string | undefined;
    summaryList?: RecommendedIntentSummary[] | undefined;
    nextToken?: string | undefined;
}
export type AnalyticsSessionSortByName = "ConversationStartTime" | "NumberOfTurns" | "Duration" | (string & {});
export interface SessionDataSortBy {
    name: AnalyticsSessionSortByName;
    order: AnalyticsSortOrder;
}
export type AnalyticsSessionFilterName = "BotAliasId" | "BotVersion" | "LocaleId" | "Modality" | "Channel" | "Duration" | "ConversationEndState" | "SessionId" | "OriginatingRequestId" | "IntentPath" | (string & {});
export interface AnalyticsSessionFilter {
    name: AnalyticsSessionFilterName;
    operator: AnalyticsFilterOperator;
    values: string[];
}
export type AnalyticsSessionFilters = AnalyticsSessionFilter[];
export interface ListSessionAnalyticsDataRequest {
    botId: string;
    startDateTime: Date;
    endDateTime: Date;
    sortBy?: SessionDataSortBy | undefined;
    filters?: AnalyticsSessionFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AnalyticsChannel = string;
export type AnalyticsSessionId = string;
export type AnalyticsLongValue = number;
export type ConversationEndState = "Success" | "Failure" | "Dropped" | (string & {});
export type AnalyticsModality = "Speech" | "Text" | "DTMF" | "MultiMode" | (string & {});
export interface InvokedIntentSample {
    intentName?: string | undefined;
}
export type InvokedIntentSamples = InvokedIntentSample[];
export type AnalyticsOriginatingRequestId = string;
export interface SessionSpecification {
    botAliasId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    channel?: string | undefined;
    sessionId?: string | undefined;
    conversationStartTime?: Date | undefined;
    conversationEndTime?: Date | undefined;
    conversationDurationSeconds?: number | undefined;
    conversationEndState?: ConversationEndState | undefined;
    mode?: AnalyticsModality | undefined;
    numberOfTurns?: number | undefined;
    invokedIntentSamples?: InvokedIntentSample[] | undefined;
    originatingRequestId?: string | undefined;
}
export type SessionSpecifications = SessionSpecification[];
export interface ListSessionAnalyticsDataResponse {
    botId?: string | undefined;
    nextToken?: string | undefined;
    sessions?: SessionSpecification[] | undefined;
}
export type AnalyticsSessionMetricName = "Count" | "Success" | "Failure" | "Dropped" | "Duration" | "TurnsPerConversation" | "Concurrency" | (string & {});
export interface AnalyticsSessionMetric {
    name: AnalyticsSessionMetricName;
    statistic: AnalyticsMetricStatistic;
    order?: AnalyticsSortOrder | undefined;
}
export type AnalyticsSessionMetrics = AnalyticsSessionMetric[];
export type AnalyticsSessionField = "ConversationEndState" | "LocaleId" | (string & {});
export interface AnalyticsSessionGroupBySpecification {
    name: AnalyticsSessionField;
}
export type AnalyticsSessionGroupByList = AnalyticsSessionGroupBySpecification[];
export interface ListSessionMetricsRequest {
    botId: string;
    startDateTime: Date;
    endDateTime: Date;
    metrics: AnalyticsSessionMetric[];
    binBy?: AnalyticsBinBySpecification[] | undefined;
    groupBy?: AnalyticsSessionGroupBySpecification[] | undefined;
    filters?: AnalyticsSessionFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AnalyticsSessionGroupByKey {
    name?: AnalyticsSessionField | undefined;
    value?: string | undefined;
}
export type AnalyticsSessionGroupByKeys = AnalyticsSessionGroupByKey[];
export interface AnalyticsSessionMetricResult {
    name?: AnalyticsSessionMetricName | undefined;
    statistic?: AnalyticsMetricStatistic | undefined;
    value?: number | undefined;
}
export type AnalyticsSessionMetricResults = AnalyticsSessionMetricResult[];
export interface AnalyticsSessionResult {
    binKeys?: AnalyticsBinKey[] | undefined;
    groupByKeys?: AnalyticsSessionGroupByKey[] | undefined;
    metricsResults?: AnalyticsSessionMetricResult[] | undefined;
}
export type AnalyticsSessionResults = AnalyticsSessionResult[];
export interface ListSessionMetricsResponse {
    botId?: string | undefined;
    results?: AnalyticsSessionResult[] | undefined;
    nextToken?: string | undefined;
}
export type SlotSortAttribute = "SlotName" | "LastUpdatedDateTime" | (string & {});
export interface SlotSortBy {
    attribute: SlotSortAttribute;
    order: SortOrder;
}
export type SlotFilterName = "SlotName" | (string & {});
export type SlotFilterOperator = "CO" | "EQ" | (string & {});
export interface SlotFilter {
    name: SlotFilterName;
    values: string[];
    operator: SlotFilterOperator;
}
export type SlotFilters = SlotFilter[];
export interface ListSlotsRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    intentId: string;
    sortBy?: SlotSortBy | undefined;
    filters?: SlotFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SlotSummary {
    slotId?: string | undefined;
    slotName?: string | undefined;
    description?: string | undefined;
    slotConstraint?: SlotConstraint | undefined;
    slotTypeId?: string | undefined;
    valueElicitationPromptSpecification?: PromptSpecification | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type SlotSummaryList = SlotSummary[];
export interface ListSlotsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    intentId?: string | undefined;
    slotSummaries?: SlotSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SlotTypeSortAttribute = "SlotTypeName" | "LastUpdatedDateTime" | (string & {});
export interface SlotTypeSortBy {
    attribute: SlotTypeSortAttribute;
    order: SortOrder;
}
export type SlotTypeFilterName = "SlotTypeName" | "ExternalSourceType" | (string & {});
export type SlotTypeFilterOperator = "CO" | "EQ" | (string & {});
export interface SlotTypeFilter {
    name: SlotTypeFilterName;
    values: string[];
    operator: SlotTypeFilterOperator;
}
export type SlotTypeFilters = SlotTypeFilter[];
export interface ListSlotTypesRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    sortBy?: SlotTypeSortBy | undefined;
    filters?: SlotTypeFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type SlotTypeCategory = "Custom" | "Extended" | "ExternalGrammar" | "Composite" | (string & {});
export interface SlotTypeSummary {
    slotTypeId?: string | undefined;
    slotTypeName?: string | undefined;
    description?: string | undefined;
    parentSlotTypeSignature?: string | undefined;
    lastUpdatedDateTime?: Date | undefined;
    slotTypeCategory?: SlotTypeCategory | undefined;
}
export type SlotTypeSummaryList = SlotTypeSummary[];
export interface ListSlotTypesResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    slotTypeSummaries?: SlotTypeSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TestResultTypeFilter = "OverallTestResults" | "ConversationLevelTestResults" | "IntentClassificationTestResults" | "SlotResolutionTestResults" | "UtteranceLevelResults" | (string & {});
export type TestResultMatchStatus = "Matched" | "Mismatched" | "ExecutionError" | (string & {});
export interface ConversationLevelTestResultsFilterBy {
    endToEndResult?: TestResultMatchStatus | undefined;
}
export interface TestExecutionResultFilterBy {
    resultTypeFilter: TestResultTypeFilter;
    conversationLevelTestResultsFilterBy?: ConversationLevelTestResultsFilterBy | undefined;
}
export interface ListTestExecutionResultItemsRequest {
    testExecutionId: string;
    resultFilterBy: TestExecutionResultFilterBy;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TestResultMatchStatusCountMap = {
    [key in TestResultMatchStatus]?: number | undefined;
};
export interface OverallTestResultItem {
    multiTurnConversation: boolean;
    totalResultCount: number;
    speechTranscriptionResultCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    endToEndResultCounts: {
        [key: string]: number | undefined;
    };
}
export type OverallTestResultItemList = OverallTestResultItem[];
export interface OverallTestResults {
    items: OverallTestResultItem[];
}
export type TestSetConversationId = string;
export interface ConversationLevelIntentClassificationResultItem {
    intentName: string;
    matchResult: TestResultMatchStatus;
}
export type ConversationLevelIntentClassificationResults = ConversationLevelIntentClassificationResultItem[];
export type TestResultSlotName = string;
export interface ConversationLevelSlotResolutionResultItem {
    intentName: string;
    slotName: string;
    matchResult: TestResultMatchStatus;
}
export type ConversationLevelSlotResolutionResults = ConversationLevelSlotResolutionResultItem[];
export interface ConversationLevelTestResultItem {
    conversationId: string;
    endToEndResult: TestResultMatchStatus;
    speechTranscriptionResult?: TestResultMatchStatus | undefined;
    intentClassificationResults: ConversationLevelIntentClassificationResultItem[];
    slotResolutionResults: ConversationLevelSlotResolutionResultItem[];
}
export type ConversationLevelTestResultItemList = ConversationLevelTestResultItem[];
export interface ConversationLevelTestResults {
    items: ConversationLevelTestResultItem[];
}
export interface IntentClassificationTestResultItemCounts {
    totalResultCount: number;
    speechTranscriptionResultCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    intentMatchResultCounts: {
        [key: string]: number | undefined;
    };
}
export interface IntentClassificationTestResultItem {
    intentName: string;
    multiTurnConversation: boolean;
    resultCounts: IntentClassificationTestResultItemCounts;
}
export type IntentClassificationTestResultItemList = IntentClassificationTestResultItem[];
export interface IntentClassificationTestResults {
    items: IntentClassificationTestResultItem[];
}
export interface SlotResolutionTestResultItemCounts {
    totalResultCount: number;
    speechTranscriptionResultCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    slotMatchResultCounts: {
        [key: string]: number | undefined;
    };
}
export interface SlotResolutionTestResultItem {
    slotName: string;
    resultCounts: SlotResolutionTestResultItemCounts;
}
export type SlotResolutionTestResultItems = SlotResolutionTestResultItem[];
export interface IntentLevelSlotResolutionTestResultItem {
    intentName: string;
    multiTurnConversation: boolean;
    slotResolutionResults: SlotResolutionTestResultItem[];
}
export type IntentLevelSlotResolutionTestResultItemList = IntentLevelSlotResolutionTestResultItem[];
export interface IntentLevelSlotResolutionTestResults {
    items: IntentLevelSlotResolutionTestResultItem[];
}
export type RecordNumber = number;
export type TestSetAgentPrompt = string;
export interface ExecutionErrorDetails {
    errorCode: string;
    errorMessage: string;
}
export interface AgentTurnResult {
    expectedAgentPrompt: string;
    actualAgentPrompt?: string | undefined;
    errorDetails?: ExecutionErrorDetails | undefined;
    actualElicitedSlot?: string | undefined;
    actualIntent?: string | undefined;
}
export type TestSetUtteranceText = string;
export type AudioFileS3Location = string;
export interface UtteranceAudioInputSpecification {
    audioFileS3Location: string;
}
export interface UtteranceInputSpecification {
    textInput?: string | undefined;
    audioInput?: UtteranceAudioInputSpecification | undefined;
}
export type ActiveContextName = string;
export interface ActiveContext {
    name: string;
}
export type ActiveContextList = ActiveContext[];
export type RuntimeHintPhrase = string;
export interface RuntimeHintValue {
    phrase: string;
}
export type RuntimeHintValuesList = RuntimeHintValue[];
export interface RuntimeHintDetails {
    runtimeHintValues?: RuntimeHintValue[] | undefined;
    subSlotHints?: {
        [key: string]: RuntimeHintDetails | undefined;
    } | undefined;
}
export type SlotHintsSlotMap = {
    [key: string]: RuntimeHintDetails | undefined;
};
export type SlotHintsIntentMap = {
    [key: string]: {
        [key: string]: RuntimeHintDetails | undefined;
    } | undefined;
};
export interface RuntimeHints {
    slotHints?: {
        [key: string]: {
            [key: string]: RuntimeHintDetails | undefined;
        } | undefined;
    } | undefined;
}
export interface InputSessionStateSpecification {
    sessionAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    activeContexts?: ActiveContext[] | undefined;
    runtimeHints?: RuntimeHints | undefined;
}
export interface UserTurnInputSpecification {
    utteranceInput: UtteranceInputSpecification;
    requestAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    sessionState?: InputSessionStateSpecification | undefined;
}
export type UserTurnSlotOutputList = UserTurnSlotOutput[];
export interface UserTurnSlotOutput {
    value?: string | undefined;
    values?: UserTurnSlotOutput[] | undefined;
    subSlots?: {
        [key: string]: UserTurnSlotOutput | undefined;
    } | undefined;
}
export type UserTurnSlotOutputMap = {
    [key: string]: UserTurnSlotOutput | undefined;
};
export interface UserTurnIntentOutput {
    name: string;
    slots?: {
        [key: string]: UserTurnSlotOutput | undefined;
    } | undefined;
}
export interface UserTurnOutputSpecification {
    intent: UserTurnIntentOutput;
    activeContexts?: ActiveContext[] | undefined;
    transcript?: string | undefined;
}
export interface ConversationLevelResultDetail {
    endToEndResult: TestResultMatchStatus;
    speechTranscriptionResult?: TestResultMatchStatus | undefined;
}
export interface UserTurnResult {
    input: UserTurnInputSpecification;
    expectedOutput: UserTurnOutputSpecification;
    actualOutput?: UserTurnOutputSpecification | undefined;
    errorDetails?: ExecutionErrorDetails | undefined;
    endToEndResult?: TestResultMatchStatus | undefined;
    intentMatchResult?: TestResultMatchStatus | undefined;
    slotMatchResult?: TestResultMatchStatus | undefined;
    speechTranscriptionResult?: TestResultMatchStatus | undefined;
    conversationLevelResult?: ConversationLevelResultDetail | undefined;
}
export interface TestSetTurnResult {
    agent?: AgentTurnResult | undefined;
    user?: UserTurnResult | undefined;
}
export interface UtteranceLevelTestResultItem {
    recordNumber: number;
    conversationId?: string | undefined;
    turnResult: TestSetTurnResult;
}
export type UtteranceLevelTestResultItemList = UtteranceLevelTestResultItem[];
export interface UtteranceLevelTestResults {
    items: UtteranceLevelTestResultItem[];
}
export interface TestExecutionResultItems {
    overallTestResults?: OverallTestResults | undefined;
    conversationLevelTestResults?: ConversationLevelTestResults | undefined;
    intentClassificationTestResults?: IntentClassificationTestResults | undefined;
    intentLevelSlotResolutionTestResults?: IntentLevelSlotResolutionTestResults | undefined;
    utteranceLevelTestResults?: UtteranceLevelTestResults | undefined;
}
export interface ListTestExecutionResultItemsResponse {
    testExecutionResults?: TestExecutionResultItems | undefined;
    nextToken?: string | undefined;
}
export type TestExecutionSortAttribute = "TestSetName" | "CreationDateTime" | (string & {});
export interface TestExecutionSortBy {
    attribute: TestExecutionSortAttribute;
    order: SortOrder;
}
export interface ListTestExecutionsRequest {
    sortBy?: TestExecutionSortBy | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface TestExecutionSummary {
    testExecutionId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    testExecutionStatus?: TestExecutionStatus | undefined;
    testSetId?: string | undefined;
    testSetName?: string | undefined;
    target?: TestExecutionTarget | undefined;
    apiMode?: TestExecutionApiMode | undefined;
    testExecutionModality?: TestExecutionModality | undefined;
}
export type TestExecutionSummaryList = TestExecutionSummary[];
export interface ListTestExecutionsResponse {
    testExecutions?: TestExecutionSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTestSetRecordsRequest {
    testSetId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TurnNumber = number;
export interface AgentTurnSpecification {
    agentPrompt: string;
}
export interface UserTurnSpecification {
    input: UserTurnInputSpecification;
    expected: UserTurnOutputSpecification;
}
export interface TurnSpecification {
    agentTurn?: AgentTurnSpecification | undefined;
    userTurn?: UserTurnSpecification | undefined;
}
export interface TestSetTurnRecord {
    recordNumber: number;
    conversationId?: string | undefined;
    turnNumber?: number | undefined;
    turnSpecification: TurnSpecification;
}
export type TestSetTurnRecordList = TestSetTurnRecord[];
export interface ListTestSetRecordsResponse {
    testSetRecords?: TestSetTurnRecord[] | undefined;
    nextToken?: string | undefined;
}
export type TestSetSortAttribute = "TestSetName" | "LastUpdatedDateTime" | (string & {});
export interface TestSetSortBy {
    attribute: TestSetSortAttribute;
    order: SortOrder;
}
export interface ListTestSetsRequest {
    sortBy?: TestSetSortBy | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface TestSetSummary {
    testSetId?: string | undefined;
    testSetName?: string | undefined;
    description?: string | undefined;
    modality?: TestSetModality | undefined;
    status?: TestSetStatus | undefined;
    roleArn?: string | undefined;
    numTurns?: number | undefined;
    storageLocation?: TestSetStorageLocation | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type TestSetSummaryList = TestSetSummary[];
export interface ListTestSetsResponse {
    testSets?: TestSetSummary[] | undefined;
    nextToken?: string | undefined;
}
export type AnalyticsUtteranceSortByName = "UtteranceTimestamp" | (string & {});
export interface UtteranceDataSortBy {
    name: AnalyticsUtteranceSortByName;
    order: AnalyticsSortOrder;
}
export type AnalyticsUtteranceFilterName = "BotAliasId" | "BotVersion" | "LocaleId" | "Modality" | "Channel" | "SessionId" | "OriginatingRequestId" | "UtteranceState" | "UtteranceText" | (string & {});
export interface AnalyticsUtteranceFilter {
    name: AnalyticsUtteranceFilterName;
    operator: AnalyticsFilterOperator;
    values: string[];
}
export type AnalyticsUtteranceFilters = AnalyticsUtteranceFilter[];
export interface ListUtteranceAnalyticsDataRequest {
    botId: string;
    startDateTime: Date;
    endDateTime: Date;
    sortBy?: UtteranceDataSortBy | undefined;
    filters?: AnalyticsUtteranceFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type UtteranceUnderstood = boolean;
export type IntentState = "Failed" | "Fulfilled" | "InProgress" | "ReadyForFulfillment" | "Waiting" | "FulfillmentInProgress" | (string & {});
export type UtteranceContentType = "PlainText" | "CustomPayload" | "SSML" | "ImageResponseCard" | (string & {});
export interface UtteranceBotResponse {
    content?: string | undefined;
    contentType?: UtteranceContentType | undefined;
    imageResponseCard?: ImageResponseCard | undefined;
}
export type UtteranceBotResponses = UtteranceBotResponse[];
export interface UtteranceSpecification {
    botAliasId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    sessionId?: string | undefined;
    channel?: string | undefined;
    mode?: AnalyticsModality | undefined;
    conversationStartTime?: Date | undefined;
    conversationEndTime?: Date | undefined;
    utterance?: string | undefined;
    utteranceTimestamp?: Date | undefined;
    audioVoiceDurationMillis?: number | undefined;
    utteranceUnderstood?: boolean | undefined;
    inputType?: string | undefined;
    outputType?: string | undefined;
    associatedIntentName?: string | undefined;
    associatedSlotName?: string | undefined;
    intentState?: IntentState | undefined;
    dialogActionType?: string | undefined;
    botResponseAudioVoiceId?: string | undefined;
    slotsFilledInSession?: string | undefined;
    utteranceRequestId?: string | undefined;
    botResponses?: UtteranceBotResponse[] | undefined;
}
export type UtteranceSpecifications = UtteranceSpecification[];
export interface ListUtteranceAnalyticsDataResponse {
    botId?: string | undefined;
    nextToken?: string | undefined;
    utterances?: UtteranceSpecification[] | undefined;
}
export type AnalyticsUtteranceMetricName = "Count" | "Missed" | "Detected" | "UtteranceTimestamp" | (string & {});
export interface AnalyticsUtteranceMetric {
    name: AnalyticsUtteranceMetricName;
    statistic: AnalyticsMetricStatistic;
    order?: AnalyticsSortOrder | undefined;
}
export type AnalyticsUtteranceMetrics = AnalyticsUtteranceMetric[];
export type AnalyticsUtteranceField = "UtteranceText" | "UtteranceState" | (string & {});
export interface AnalyticsUtteranceGroupBySpecification {
    name: AnalyticsUtteranceField;
}
export type AnalyticsUtteranceGroupByList = AnalyticsUtteranceGroupBySpecification[];
export type AnalyticsUtteranceAttributeName = "LastUsedIntent" | (string & {});
export interface AnalyticsUtteranceAttribute {
    name: AnalyticsUtteranceAttributeName;
}
export type AnalyticsUtteranceAttributes = AnalyticsUtteranceAttribute[];
export interface ListUtteranceMetricsRequest {
    botId: string;
    startDateTime: Date;
    endDateTime: Date;
    metrics: AnalyticsUtteranceMetric[];
    binBy?: AnalyticsBinBySpecification[] | undefined;
    groupBy?: AnalyticsUtteranceGroupBySpecification[] | undefined;
    attributes?: AnalyticsUtteranceAttribute[] | undefined;
    filters?: AnalyticsUtteranceFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AnalyticsUtteranceGroupByKey {
    name?: AnalyticsUtteranceField | undefined;
    value?: string | undefined;
}
export type AnalyticsUtteranceGroupByKeys = AnalyticsUtteranceGroupByKey[];
export interface AnalyticsUtteranceMetricResult {
    name?: AnalyticsUtteranceMetricName | undefined;
    statistic?: AnalyticsMetricStatistic | undefined;
    value?: number | undefined;
}
export type AnalyticsUtteranceMetricResults = AnalyticsUtteranceMetricResult[];
export interface AnalyticsUtteranceAttributeResult {
    lastUsedIntent?: string | undefined;
}
export type AnalyticsUtteranceAttributeResults = AnalyticsUtteranceAttributeResult[];
export interface AnalyticsUtteranceResult {
    binKeys?: AnalyticsBinKey[] | undefined;
    groupByKeys?: AnalyticsUtteranceGroupByKey[] | undefined;
    metricsResults?: AnalyticsUtteranceMetricResult[] | undefined;
    attributeResults?: AnalyticsUtteranceAttributeResult[] | undefined;
}
export type AnalyticsUtteranceResults = AnalyticsUtteranceResult[];
export interface ListUtteranceMetricsResponse {
    botId?: string | undefined;
    results?: AnalyticsUtteranceResult[] | undefined;
    nextToken?: string | undefined;
}
export type SearchOrder = "Ascending" | "Descending" | (string & {});
export type AssociatedTranscriptFilterName = "IntentId" | "SlotTypeId" | (string & {});
export interface AssociatedTranscriptFilter {
    name: AssociatedTranscriptFilterName;
    values: string[];
}
export type AssociatedTranscriptFilters = AssociatedTranscriptFilter[];
export type NextIndex = number;
export interface SearchAssociatedTranscriptsRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    botRecommendationId: string;
    searchOrder?: SearchOrder | undefined;
    filters: AssociatedTranscriptFilter[];
    maxResults?: number | undefined;
    nextIndex?: number | undefined;
}
export type Transcript = string;
export interface AssociatedTranscript {
    transcript?: string | undefined;
}
export type AssociatedTranscriptList = AssociatedTranscript[];
export interface SearchAssociatedTranscriptsResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botRecommendationId?: string | undefined;
    nextIndex?: number | undefined;
    associatedTranscripts?: AssociatedTranscript[] | undefined;
    totalResults?: number | undefined;
}
export type AnalysisScope = "BotLocale" | (string & {});
export interface StartBotAnalyzerRequest {
    botId: string;
    analysisScope: AnalysisScope;
    localeId?: string | undefined;
    botVersion?: string | undefined;
}
export interface StartBotAnalyzerResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botAnalyzerStatus?: BotAnalyzerStatus | undefined;
    botAnalyzerRequestId?: string | undefined;
    creationDateTime?: Date | undefined;
}
export interface StartBotRecommendationRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    transcriptSourceSetting: TranscriptSourceSetting;
    encryptionSetting?: EncryptionSetting | undefined;
}
export interface StartBotRecommendationResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botRecommendationStatus?: BotRecommendationStatus | undefined;
    botRecommendationId?: string | undefined;
    creationDateTime?: Date | undefined;
    transcriptSourceSetting?: TranscriptSourceSetting | undefined;
    encryptionSetting?: EncryptionSetting | undefined;
}
export interface StartBotResourceGenerationRequest {
    generationInputPrompt: string;
    botId: string;
    botVersion: string;
    localeId: string;
}
export interface StartBotResourceGenerationResponse {
    generationInputPrompt?: string | undefined;
    generationId?: string | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    generationStatus?: GenerationStatus | undefined;
    creationDateTime?: Date | undefined;
}
export interface StartImportRequest {
    importId: string;
    resourceSpecification: ImportResourceSpecification;
    mergeStrategy: MergeStrategy;
    filePassword?: string | redacted.Redacted<string> | undefined;
}
export interface StartImportResponse {
    importId?: string | undefined;
    resourceSpecification?: ImportResourceSpecification | undefined;
    mergeStrategy?: MergeStrategy | undefined;
    importStatus?: ImportStatus | undefined;
    creationDateTime?: Date | undefined;
}
export interface StartTestExecutionRequest {
    testSetId: string;
    target: TestExecutionTarget;
    apiMode: TestExecutionApiMode;
    testExecutionModality?: TestExecutionModality | undefined;
}
export interface StartTestExecutionResponse {
    testExecutionId?: string | undefined;
    creationDateTime?: Date | undefined;
    testSetId?: string | undefined;
    target?: TestExecutionTarget | undefined;
    apiMode?: TestExecutionApiMode | undefined;
    testExecutionModality?: TestExecutionModality | undefined;
}
export interface StartTestSetGenerationRequest {
    testSetName: string;
    description?: string | undefined;
    storageLocation: TestSetStorageLocation;
    generationDataSource: TestSetGenerationDataSource;
    roleArn: string;
    testSetTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartTestSetGenerationResponse {
    testSetGenerationId?: string | undefined;
    creationDateTime?: Date | undefined;
    testSetGenerationStatus?: TestSetGenerationStatus | undefined;
    testSetName?: string | undefined;
    description?: string | undefined;
    storageLocation?: TestSetStorageLocation | undefined;
    generationDataSource?: TestSetGenerationDataSource | undefined;
    roleArn?: string | undefined;
    testSetTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StopBotAnalyzerRequest {
    botId: string;
    botAnalyzerRequestId: string;
}
export interface StopBotAnalyzerResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botAnalyzerStatus?: BotAnalyzerStatus | undefined;
    botAnalyzerRequestId?: string | undefined;
}
export interface StopBotRecommendationRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    botRecommendationId: string;
}
export interface StopBotRecommendationResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botRecommendationStatus?: BotRecommendationStatus | undefined;
    botRecommendationId?: string | undefined;
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateBotRequest {
    botId: string;
    botName: string;
    description?: string | undefined;
    roleArn: string;
    dataPrivacy: DataPrivacy;
    idleSessionTTLInSeconds: number;
    botType?: BotType | undefined;
    botMembers?: BotMember[] | undefined;
    errorLogSettings?: ErrorLogSettings | undefined;
}
export interface UpdateBotResponse {
    botId?: string | undefined;
    botName?: string | undefined;
    description?: string | undefined;
    roleArn?: string | undefined;
    dataPrivacy?: DataPrivacy | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    botStatus?: BotStatus | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    botType?: BotType | undefined;
    botMembers?: BotMember[] | undefined;
    errorLogSettings?: ErrorLogSettings | undefined;
}
export interface UpdateBotAliasRequest {
    botAliasId: string;
    botAliasName: string;
    description?: string | undefined;
    botVersion?: string | undefined;
    botAliasLocaleSettings?: {
        [key: string]: BotAliasLocaleSettings | undefined;
    } | undefined;
    conversationLogSettings?: ConversationLogSettings | undefined;
    sentimentAnalysisSettings?: SentimentAnalysisSettings | undefined;
    botId: string;
}
export interface UpdateBotAliasResponse {
    botAliasId?: string | undefined;
    botAliasName?: string | undefined;
    description?: string | undefined;
    botVersion?: string | undefined;
    botAliasLocaleSettings?: {
        [key: string]: BotAliasLocaleSettings | undefined;
    } | undefined;
    conversationLogSettings?: ConversationLogSettings | undefined;
    sentimentAnalysisSettings?: SentimentAnalysisSettings | undefined;
    botAliasStatus?: BotAliasStatus | undefined;
    botId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface UpdateBotLocaleRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    description?: string | undefined;
    nluIntentConfidenceThreshold: number;
    voiceSettings?: VoiceSettings | undefined;
    unifiedSpeechSettings?: UnifiedSpeechSettings | undefined;
    audioFillerSettings?: AudioFillerSettings | undefined;
    speechRecognitionSettings?: SpeechRecognitionSettings | undefined;
    generativeAISettings?: GenerativeAISettings | undefined;
    speechDetectionSensitivity?: SpeechDetectionSensitivity | undefined;
    speakerDiarizationSettings?: SpeakerDiarizationSettings | undefined;
}
export interface UpdateBotLocaleResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    localeName?: string | undefined;
    description?: string | undefined;
    nluIntentConfidenceThreshold?: number | undefined;
    voiceSettings?: VoiceSettings | undefined;
    unifiedSpeechSettings?: UnifiedSpeechSettings | undefined;
    audioFillerSettings?: AudioFillerSettings | undefined;
    speechRecognitionSettings?: SpeechRecognitionSettings | undefined;
    botLocaleStatus?: BotLocaleStatus | undefined;
    failureReasons?: string[] | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    recommendedActions?: string[] | undefined;
    generativeAISettings?: GenerativeAISettings | undefined;
    speechDetectionSensitivity?: SpeechDetectionSensitivity | undefined;
    speakerDiarizationSettings?: SpeakerDiarizationSettings | undefined;
}
export interface UpdateBotRecommendationRequest {
    botId: string;
    botVersion: string;
    localeId: string;
    botRecommendationId: string;
    encryptionSetting: EncryptionSetting;
}
export interface UpdateBotRecommendationResponse {
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    botRecommendationStatus?: BotRecommendationStatus | undefined;
    botRecommendationId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    transcriptSourceSetting?: TranscriptSourceSetting | undefined;
    encryptionSetting?: EncryptionSetting | undefined;
}
export interface UpdateExportRequest {
    exportId: string;
    filePassword?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateExportResponse {
    exportId?: string | undefined;
    resourceSpecification?: ExportResourceSpecification | undefined;
    fileFormat?: ImportExportFileFormat | undefined;
    exportStatus?: ExportStatus | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface UpdateIntentRequest {
    intentId: string;
    intentName: string;
    intentDisplayName?: string | undefined;
    description?: string | undefined;
    parentIntentSignature?: string | undefined;
    sampleUtterances?: SampleUtterance[] | undefined;
    dialogCodeHook?: DialogCodeHookSettings | undefined;
    fulfillmentCodeHook?: FulfillmentCodeHookSettings | undefined;
    slotPriorities?: SlotPriority[] | undefined;
    intentConfirmationSetting?: IntentConfirmationSetting | undefined;
    intentClosingSetting?: IntentClosingSetting | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    botId: string;
    botVersion: string;
    localeId: string;
    initialResponseSetting?: InitialResponseSetting | undefined;
    qnAIntentConfiguration?: QnAIntentConfiguration | undefined;
    qInConnectIntentConfiguration?: QInConnectIntentConfiguration | undefined;
}
export interface UpdateIntentResponse {
    intentId?: string | undefined;
    intentName?: string | undefined;
    intentDisplayName?: string | undefined;
    description?: string | undefined;
    parentIntentSignature?: string | undefined;
    sampleUtterances?: SampleUtterance[] | undefined;
    dialogCodeHook?: DialogCodeHookSettings | undefined;
    fulfillmentCodeHook?: FulfillmentCodeHookSettings | undefined;
    slotPriorities?: SlotPriority[] | undefined;
    intentConfirmationSetting?: IntentConfirmationSetting | undefined;
    intentClosingSetting?: IntentClosingSetting | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    initialResponseSetting?: InitialResponseSetting | undefined;
    qnAIntentConfiguration?: QnAIntentConfiguration | undefined;
    qInConnectIntentConfiguration?: QInConnectIntentConfiguration | undefined;
}
export interface UpdateResourcePolicyRequest {
    resourceArn: string;
    policy: string;
    expectedRevisionId?: string | undefined;
}
export interface UpdateResourcePolicyResponse {
    resourceArn?: string | undefined;
    revisionId?: string | undefined;
}
export interface UpdateSlotRequest {
    slotId: string;
    slotName: string;
    description?: string | undefined;
    slotTypeId?: string | undefined;
    valueElicitationSetting: SlotValueElicitationSetting;
    obfuscationSetting?: ObfuscationSetting | undefined;
    botId: string;
    botVersion: string;
    localeId: string;
    intentId: string;
    multipleValuesSetting?: MultipleValuesSetting | undefined;
    subSlotSetting?: SubSlotSetting | undefined;
}
export interface UpdateSlotResponse {
    slotId?: string | undefined;
    slotName?: string | undefined;
    description?: string | undefined;
    slotTypeId?: string | undefined;
    valueElicitationSetting?: SlotValueElicitationSetting | undefined;
    obfuscationSetting?: ObfuscationSetting | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    intentId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    multipleValuesSetting?: MultipleValuesSetting | undefined;
    subSlotSetting?: SubSlotSetting | undefined;
}
export interface UpdateSlotTypeRequest {
    slotTypeId: string;
    slotTypeName: string;
    description?: string | undefined;
    slotTypeValues?: SlotTypeValue[] | undefined;
    valueSelectionSetting?: SlotValueSelectionSetting | undefined;
    parentSlotTypeSignature?: string | undefined;
    botId: string;
    botVersion: string;
    localeId: string;
    externalSourceSetting?: ExternalSourceSetting | undefined;
    compositeSlotTypeSetting?: CompositeSlotTypeSetting | undefined;
}
export interface UpdateSlotTypeResponse {
    slotTypeId?: string | undefined;
    slotTypeName?: string | undefined;
    description?: string | undefined;
    slotTypeValues?: SlotTypeValue[] | undefined;
    valueSelectionSetting?: SlotValueSelectionSetting | undefined;
    parentSlotTypeSignature?: string | undefined;
    botId?: string | undefined;
    botVersion?: string | undefined;
    localeId?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    externalSourceSetting?: ExternalSourceSetting | undefined;
    compositeSlotTypeSetting?: CompositeSlotTypeSetting | undefined;
}
export interface UpdateTestSetRequest {
    testSetId: string;
    testSetName: string;
    description?: string | undefined;
}
export interface UpdateTestSetResponse {
    testSetId?: string | undefined;
    testSetName?: string | undefined;
    description?: string | undefined;
    modality?: TestSetModality | undefined;
    status?: TestSetStatus | undefined;
    roleArn?: string | undefined;
    numTurns?: number | undefined;
    storageLocation?: TestSetStorageLocation | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type ExceptionMessage = string;
export type RetryAfterSeconds = number;
export type BatchCreateCustomVocabularyItemError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a batch of custom vocabulary items for a given bot locale's
 * custom vocabulary.
 */
export declare const batchCreateCustomVocabularyItem: API.OperationMethod<BatchCreateCustomVocabularyItemRequest & RegionInput, BatchCreateCustomVocabularyItemResponse, BatchCreateCustomVocabularyItemError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteCustomVocabularyItemError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a batch of custom vocabulary items for a given bot locale's
 * custom vocabulary.
 */
export declare const batchDeleteCustomVocabularyItem: API.OperationMethod<BatchDeleteCustomVocabularyItemRequest & RegionInput, BatchDeleteCustomVocabularyItemResponse, BatchDeleteCustomVocabularyItemError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateCustomVocabularyItemError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a batch of custom vocabulary items for a given bot locale's custom
 * vocabulary.
 */
export declare const batchUpdateCustomVocabularyItem: API.OperationMethod<BatchUpdateCustomVocabularyItemRequest & RegionInput, BatchUpdateCustomVocabularyItemResponse, BatchUpdateCustomVocabularyItemError, Credentials | HttpClient.HttpClient>;
export type BuildBotLocaleError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Builds a bot, its intents, and its slot types into a specific
 * locale. A bot can be built into multiple locales. At runtime the locale
 * is used to choose a specific build of the bot.
 */
export declare const buildBotLocale: API.OperationMethod<BuildBotLocaleRequest & RegionInput, BuildBotLocaleResponse, BuildBotLocaleError, Credentials | HttpClient.HttpClient>;
export type CreateBotError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Lex conversational bot.
 */
export declare const createBot: API.OperationMethod<CreateBotRequest & RegionInput, CreateBotResponse, CreateBotError, Credentials | HttpClient.HttpClient>;
export type CreateBotAliasError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an alias for the specified version of a bot. Use an alias to
 * enable you to change the version of a bot without updating applications
 * that use the bot.
 *
 * For example, you can create an alias called "PROD" that your
 * applications use to call the Amazon Lex bot.
 */
export declare const createBotAlias: API.OperationMethod<CreateBotAliasRequest & RegionInput, CreateBotAliasResponse, CreateBotAliasError, Credentials | HttpClient.HttpClient>;
export type CreateBotLocaleError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a locale in the bot. The locale contains the intents and
 * slot types that the bot uses in conversations with users in the
 * specified language and locale. You must add a locale to a bot before
 * you can add intents and slot types to the bot.
 */
export declare const createBotLocale: API.OperationMethod<CreateBotLocaleRequest & RegionInput, CreateBotLocaleResponse, CreateBotLocaleError, Credentials | HttpClient.HttpClient>;
export type CreateBotReplicaError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Action to create a replication of the source bot in the secondary region.
 */
export declare const createBotReplica: API.OperationMethod<CreateBotReplicaRequest & RegionInput, CreateBotReplicaResponse, CreateBotReplicaError, Credentials | HttpClient.HttpClient>;
export type CreateBotVersionError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an immutable version of the bot. When you create the first
 * version of a bot, Amazon Lex sets the version number to 1. Subsequent bot versions increase
 * in an increment of 1. The version number will always represent the total number
 * of versions created of the bot, not the current number of versions. If a bot version
 * is deleted, that bot version number will not be reused.
 */
export declare const createBotVersion: API.OperationMethod<CreateBotVersionRequest & RegionInput, CreateBotVersionResponse, CreateBotVersionError, Credentials | HttpClient.HttpClient>;
export type CreateExportError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a zip archive containing the contents of a bot or a bot
 * locale. The archive contains a directory structure that contains JSON
 * files that define the bot.
 *
 * You can create an archive that contains the complete definition of a
 * bot, or you can specify that the archive contain only the definition of
 * a single bot locale.
 *
 * For more information about exporting bots, and about the structure
 * of the export archive, see Importing and
 * exporting bots
 */
export declare const createExport: API.OperationMethod<CreateExportRequest & RegionInput, CreateExportResponse, CreateExportError, Credentials | HttpClient.HttpClient>;
export type CreateIntentError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an intent.
 *
 * To define the interaction between the user and your bot, you define
 * one or more intents. For example, for a pizza ordering bot you would
 * create an `OrderPizza` intent.
 *
 * When you create an intent, you must provide a name. You can
 * optionally provide the following:
 *
 * - Sample utterances. For example, "I want to order a pizza" and
 * "Can I order a pizza." You can't provide utterances for built-in
 * intents.
 *
 * - Information to be gathered. You specify slots for the
 * information that you bot requests from the user. You can specify
 * standard slot types, such as date and time, or custom slot types
 * for your application.
 *
 * - How the intent is fulfilled. You can provide a Lambda function
 * or configure the intent to return the intent information to your
 * client application. If you use a Lambda function, Amazon Lex invokes
 * the function when all of the intent information is
 * available.
 *
 * - A confirmation prompt to send to the user to confirm an
 * intent. For example, "Shall I order your pizza?"
 *
 * - A conclusion statement to send to the user after the intent is
 * fulfilled. For example, "I ordered your pizza."
 *
 * - A follow-up prompt that asks the user for additional activity.
 * For example, "Do you want a drink with your pizza?"
 */
export declare const createIntent: API.OperationMethod<CreateIntentRequest & RegionInput, CreateIntentResponse, CreateIntentError, Credentials | HttpClient.HttpClient>;
export type CreateResourcePolicyError = InternalServerException | PreconditionFailedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new resource policy with the specified policy
 * statements.
 */
export declare const createResourcePolicy: API.OperationMethod<CreateResourcePolicyRequest & RegionInput, CreateResourcePolicyResponse, CreateResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateResourcePolicyStatementError = ConflictException | InternalServerException | PreconditionFailedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a new resource policy statement to a bot or bot alias. If a
 * resource policy exists, the statement is added to the current resource
 * policy. If a policy doesn't exist, a new policy is created.
 *
 * You can't create a resource policy statement that allows
 * cross-account access.
 *
 * You need to add the `CreateResourcePolicy` or `UpdateResourcePolicy`
 * action to the bot role in order to call the API.
 */
export declare const createResourcePolicyStatement: API.OperationMethod<CreateResourcePolicyStatementRequest & RegionInput, CreateResourcePolicyStatementResponse, CreateResourcePolicyStatementError, Credentials | HttpClient.HttpClient>;
export type CreateSlotError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a slot in an intent. A slot is a variable needed to fulfill
 * an intent. For example, an `OrderPizza` intent might need
 * slots for size, crust, and number of pizzas. For each slot, you define
 * one or more utterances that Amazon Lex uses to elicit a response from the
 * user.
 */
export declare const createSlot: API.OperationMethod<CreateSlotRequest & RegionInput, CreateSlotResponse, CreateSlotError, Credentials | HttpClient.HttpClient>;
export type CreateSlotTypeError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom slot type
 *
 * To create a custom slot type, specify a name for the slot type and
 * a set of enumeration values, the values that a slot of this type can
 * assume.
 */
export declare const createSlotType: API.OperationMethod<CreateSlotTypeRequest & RegionInput, CreateSlotTypeResponse, CreateSlotTypeError, Credentials | HttpClient.HttpClient>;
export type CreateTestSetDiscrepancyReportError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a report that describes the differences between the bot and the test set.
 */
export declare const createTestSetDiscrepancyReport: API.OperationMethod<CreateTestSetDiscrepancyReportRequest & RegionInput, CreateTestSetDiscrepancyReportResponse, CreateTestSetDiscrepancyReportError, Credentials | HttpClient.HttpClient>;
export type CreateUploadUrlError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a pre-signed S3 write URL that you use to upload the zip
 * archive when importing a bot or a bot locale.
 */
export declare const createUploadUrl: API.OperationMethod<CreateUploadUrlRequest & RegionInput, CreateUploadUrlResponse, CreateUploadUrlError, Credentials | HttpClient.HttpClient>;
export type DeleteBotError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes all versions of a bot, including the `Draft`
 * version. To delete a specific version, use the
 * `DeleteBotVersion` operation.
 *
 * When you delete a bot, all of the resources contained in the bot are
 * also deleted. Deleting a bot removes all locales, intents, slot, and
 * slot types defined for the bot.
 *
 * If a bot has an alias, the `DeleteBot` operation returns
 * a `ResourceInUseException` exception. If you want to delete
 * the bot and the alias, set the `skipResourceInUseCheck`
 * parameter to `true`.
 */
export declare const deleteBot: API.OperationMethod<DeleteBotRequest & RegionInput, DeleteBotResponse, DeleteBotError, Credentials | HttpClient.HttpClient>;
export type DeleteBotAliasError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified bot alias.
 */
export declare const deleteBotAlias: API.OperationMethod<DeleteBotAliasRequest & RegionInput, DeleteBotAliasResponse, DeleteBotAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteBotAnalyzerRecommendationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Permanently deletes the recommendations and analysis results for a specific bot analysis request. This operation is provided for GDPR compliance and cannot be undone.
 *
 * After deletion, the analysis results cannot be retrieved. The analysis request ID will still appear in the history list, but attempting to describe the recommendations will return a `ResourceNotFoundException`.
 */
export declare const deleteBotAnalyzerRecommendation: API.OperationMethod<DeleteBotAnalyzerRecommendationRequest & RegionInput, DeleteBotAnalyzerRecommendationResponse, DeleteBotAnalyzerRecommendationError, Credentials | HttpClient.HttpClient>;
export type DeleteBotLocaleError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a locale from a bot.
 *
 * When you delete a locale, all intents, slots, and slot types defined
 * for the locale are also deleted.
 */
export declare const deleteBotLocale: API.OperationMethod<DeleteBotLocaleRequest & RegionInput, DeleteBotLocaleResponse, DeleteBotLocaleError, Credentials | HttpClient.HttpClient>;
export type DeleteBotReplicaError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to delete the replicated bot in the secondary region.
 */
export declare const deleteBotReplica: API.OperationMethod<DeleteBotReplicaRequest & RegionInput, DeleteBotReplicaResponse, DeleteBotReplicaError, Credentials | HttpClient.HttpClient>;
export type DeleteBotVersionError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific version of a bot. To delete all versions of a bot,
 * use the DeleteBot operation.
 */
export declare const deleteBotVersion: API.OperationMethod<DeleteBotVersionRequest & RegionInput, DeleteBotVersionResponse, DeleteBotVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomVocabularyError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a custom vocabulary from the specified locale
 * in the specified bot.
 */
export declare const deleteCustomVocabulary: API.OperationMethod<DeleteCustomVocabularyRequest & RegionInput, DeleteCustomVocabularyResponse, DeleteCustomVocabularyError, Credentials | HttpClient.HttpClient>;
export type DeleteExportError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a previous export and the associated files stored in an S3
 * bucket.
 */
export declare const deleteExport: API.OperationMethod<DeleteExportRequest & RegionInput, DeleteExportResponse, DeleteExportError, Credentials | HttpClient.HttpClient>;
export type DeleteImportError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a previous import and the associated file stored in an S3
 * bucket.
 */
export declare const deleteImport: API.OperationMethod<DeleteImportRequest & RegionInput, DeleteImportResponse, DeleteImportError, Credentials | HttpClient.HttpClient>;
export type DeleteIntentError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified intent.
 *
 * Deleting an intent also deletes the slots associated with the
 * intent.
 */
export declare const deleteIntent: API.OperationMethod<DeleteIntentRequest & RegionInput, DeleteIntentResponse, DeleteIntentError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerException | PreconditionFailedException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes an existing policy from a bot or bot alias. If the resource
 * doesn't have a policy attached, Amazon Lex returns an exception.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyStatementError = InternalServerException | PreconditionFailedException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a policy statement from a resource policy. If you delete the
 * last statement from a policy, the policy is deleted. If you specify a
 * statement ID that doesn't exist in the policy, or if the bot or bot
 * alias doesn't have a policy attached, Amazon Lex returns an
 * exception.
 *
 * You need to add the `DeleteResourcePolicy` or `UpdateResourcePolicy`
 * action to the bot role in order to call the API.
 */
export declare const deleteResourcePolicyStatement: API.OperationMethod<DeleteResourcePolicyStatementRequest & RegionInput, DeleteResourcePolicyStatementResponse, DeleteResourcePolicyStatementError, Credentials | HttpClient.HttpClient>;
export type DeleteSlotError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified slot from an intent.
 */
export declare const deleteSlot: API.OperationMethod<DeleteSlotRequest & RegionInput, DeleteSlotResponse, DeleteSlotError, Credentials | HttpClient.HttpClient>;
export type DeleteSlotTypeError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a slot type from a bot locale.
 *
 * If a slot is using the slot type, Amazon Lex throws a
 * `ResourceInUseException` exception. To avoid the
 * exception, set the `skipResourceInUseCheck` parameter to
 * `true`.
 */
export declare const deleteSlotType: API.OperationMethod<DeleteSlotTypeRequest & RegionInput, DeleteSlotTypeResponse, DeleteSlotTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteTestSetError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to delete the selected test set.
 */
export declare const deleteTestSet: API.OperationMethod<DeleteTestSetRequest & RegionInput, DeleteTestSetResponse, DeleteTestSetError, Credentials | HttpClient.HttpClient>;
export type DeleteUtterancesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes stored utterances.
 *
 * Amazon Lex stores the utterances that users send to your bot. Utterances
 * are stored for 15 days for use with the ListAggregatedUtterances operation, and
 * then stored indefinitely for use in improving the ability of your bot
 * to respond to user input..
 *
 * Use the `DeleteUtterances` operation to manually delete
 * utterances for a specific session. When you use the
 * `DeleteUtterances` operation, utterances stored for
 * improving your bot's ability to respond to user input are deleted
 * immediately. Utterances stored for use with the
 * `ListAggregatedUtterances` operation are deleted after 15
 * days.
 */
export declare const deleteUtterances: API.OperationMethod<DeleteUtterancesRequest & RegionInput, DeleteUtterancesResponse, DeleteUtterancesError, Credentials | HttpClient.HttpClient>;
export type DescribeBotError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides metadata information about a bot.
 */
export declare const describeBot: API.OperationMethod<DescribeBotRequest & RegionInput, DescribeBotResponse, DescribeBotError, Credentials | HttpClient.HttpClient>;
export type DescribeBotAliasError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information about a specific bot alias.
 */
export declare const describeBotAlias: API.OperationMethod<DescribeBotAliasRequest & RegionInput, DescribeBotAliasResponse, DescribeBotAliasError, Credentials | HttpClient.HttpClient>;
export type DescribeBotAnalyzerRecommendationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the analysis results and recommendations for bot optimization. The analysis must be in `Available` status before recommendations can be retrieved.
 *
 * Recommendations are returned with pagination support. Each recommendation includes the issue location, priority level, detailed description, and proposed fix.
 */
export declare const describeBotAnalyzerRecommendation: API.PaginatedOperationMethod<DescribeBotAnalyzerRecommendationRequest & RegionInput, DescribeBotAnalyzerRecommendationResponse, DescribeBotAnalyzerRecommendationError, Credentials | HttpClient.HttpClient, BotAnalyzerRecommendation>;
export type DescribeBotLocaleError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the settings that a bot has for a specific locale.
 */
export declare const describeBotLocale: API.OperationMethod<DescribeBotLocaleRequest & RegionInput, DescribeBotLocaleResponse, DescribeBotLocaleError, Credentials | HttpClient.HttpClient>;
export type DescribeBotRecommendationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides metadata information about a bot recommendation. This
 * information will enable you to get a description on the request inputs,
 * to download associated transcripts after processing is complete, and to
 * download intents and slot-types generated by the bot
 * recommendation.
 */
export declare const describeBotRecommendation: API.OperationMethod<DescribeBotRecommendationRequest & RegionInput, DescribeBotRecommendationResponse, DescribeBotRecommendationError, Credentials | HttpClient.HttpClient>;
export type DescribeBotReplicaError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Monitors the bot replication status through the UI console.
 */
export declare const describeBotReplica: API.OperationMethod<DescribeBotReplicaRequest & RegionInput, DescribeBotReplicaResponse, DescribeBotReplicaError, Credentials | HttpClient.HttpClient>;
export type DescribeBotResourceGenerationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a request to generate a bot through natural language description, made through
 * the `StartBotResource` API. Use the `generatedBotLocaleUrl`
 * to retrieve the Amazon S3 object containing the bot locale configuration. You can
 * then modify and import this configuration.
 */
export declare const describeBotResourceGeneration: API.OperationMethod<DescribeBotResourceGenerationRequest & RegionInput, DescribeBotResourceGenerationResponse, DescribeBotResourceGenerationError, Credentials | HttpClient.HttpClient>;
export type DescribeBotVersionError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides metadata about a version of a bot.
 */
export declare const describeBotVersion: API.OperationMethod<DescribeBotVersionRequest & RegionInput, DescribeBotVersionResponse, DescribeBotVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomVocabularyMetadataError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides metadata information about a custom vocabulary.
 */
export declare const describeCustomVocabularyMetadata: API.OperationMethod<DescribeCustomVocabularyMetadataRequest & RegionInput, DescribeCustomVocabularyMetadataResponse, DescribeCustomVocabularyMetadataError, Credentials | HttpClient.HttpClient>;
export type DescribeExportError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific export.
 */
export declare const describeExport: API.OperationMethod<DescribeExportRequest & RegionInput, DescribeExportResponse, DescribeExportError, Credentials | HttpClient.HttpClient>;
export type DescribeImportError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific import.
 */
export declare const describeImport: API.OperationMethod<DescribeImportRequest & RegionInput, DescribeImportResponse, DescribeImportError, Credentials | HttpClient.HttpClient>;
export type DescribeIntentError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns metadata about an intent.
 */
export declare const describeIntent: API.OperationMethod<DescribeIntentRequest & RegionInput, DescribeIntentResponse, DescribeIntentError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePolicyError = InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the resource policy and policy revision for a bot or bot
 * alias.
 */
export declare const describeResourcePolicy: API.OperationMethod<DescribeResourcePolicyRequest & RegionInput, DescribeResourcePolicyResponse, DescribeResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeSlotError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets metadata information about a slot.
 */
export declare const describeSlot: API.OperationMethod<DescribeSlotRequest & RegionInput, DescribeSlotResponse, DescribeSlotError, Credentials | HttpClient.HttpClient>;
export type DescribeSlotTypeError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets metadata information about a slot type.
 */
export declare const describeSlotType: API.OperationMethod<DescribeSlotTypeRequest & RegionInput, DescribeSlotTypeResponse, DescribeSlotTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeTestExecutionError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets metadata information about the test execution.
 */
export declare const describeTestExecution: API.OperationMethod<DescribeTestExecutionRequest & RegionInput, DescribeTestExecutionResponse, DescribeTestExecutionError, Credentials | HttpClient.HttpClient>;
export type DescribeTestSetError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets metadata information about the test set.
 */
export declare const describeTestSet: API.OperationMethod<DescribeTestSetRequest & RegionInput, DescribeTestSetResponse, DescribeTestSetError, Credentials | HttpClient.HttpClient>;
export type DescribeTestSetDiscrepancyReportError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets metadata information about the test set discrepancy report.
 */
export declare const describeTestSetDiscrepancyReport: API.OperationMethod<DescribeTestSetDiscrepancyReportRequest & RegionInput, DescribeTestSetDiscrepancyReportResponse, DescribeTestSetDiscrepancyReportError, Credentials | HttpClient.HttpClient>;
export type DescribeTestSetGenerationError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets metadata information about the test set generation.
 */
export declare const describeTestSetGeneration: API.OperationMethod<DescribeTestSetGenerationRequest & RegionInput, DescribeTestSetGenerationResponse, DescribeTestSetGenerationError, Credentials | HttpClient.HttpClient>;
export type GenerateBotElementError = ConflictException | InternalServerException | PreconditionFailedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates sample utterances for an intent.
 */
export declare const generateBotElement: API.OperationMethod<GenerateBotElementRequest & RegionInput, GenerateBotElementResponse, GenerateBotElementError, Credentials | HttpClient.HttpClient>;
export type GetTestExecutionArtifactsUrlError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The pre-signed Amazon S3 URL to download the test execution result artifacts.
 */
export declare const getTestExecutionArtifactsUrl: API.OperationMethod<GetTestExecutionArtifactsUrlRequest & RegionInput, GetTestExecutionArtifactsUrlResponse, GetTestExecutionArtifactsUrlError, Credentials | HttpClient.HttpClient>;
export type ListAggregatedUtterancesError = InternalServerException | PreconditionFailedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a list of utterances that users have sent to the
 * bot.
 *
 * Utterances are aggregated by the text of the utterance. For example,
 * all instances where customers used the phrase "I want to order pizza"
 * are aggregated into the same line in the response.
 *
 * You can see both detected utterances and missed utterances. A
 * detected utterance is where the bot properly recognized the utterance
 * and activated the associated intent. A missed utterance was not
 * recognized by the bot and didn't activate an intent.
 *
 * Utterances can be aggregated for a bot alias or for a bot version,
 * but not both at the same time.
 *
 * Utterances statistics are not generated under the following
 * conditions:
 *
 * - The `childDirected` field was set to true when the
 * bot was created.
 *
 * - You are using slot obfuscation with one or more slots.
 *
 * - You opted out of participating in improving Amazon Lex.
 */
export declare const listAggregatedUtterances: API.PaginatedOperationMethod<ListAggregatedUtterancesRequest & RegionInput, ListAggregatedUtterancesResponse, ListAggregatedUtterancesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotAliasesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a list of aliases for the specified bot.
 */
export declare const listBotAliases: API.PaginatedOperationMethod<ListBotAliasesRequest & RegionInput, ListBotAliasesResponse, ListBotAliasesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotAliasReplicasError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to list the replicated bots created from the source bot alias.
 */
export declare const listBotAliasReplicas: API.PaginatedOperationMethod<ListBotAliasReplicasRequest & RegionInput, ListBotAliasReplicasResponse, ListBotAliasReplicasError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotAnalyzerHistoryError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of historical bot analysis executions for a specific bot. You can filter the results by locale and bot version.
 *
 * The history includes all analysis executions regardless of their status, allowing you to track past analyses and their outcomes.
 */
export declare const listBotAnalyzerHistory: API.PaginatedOperationMethod<ListBotAnalyzerHistoryRequest & RegionInput, ListBotAnalyzerHistoryResponse, ListBotAnalyzerHistoryError, Credentials | HttpClient.HttpClient, BotAnalyzerHistorySummary>;
export type ListBotLocalesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of locales for the specified bot.
 */
export declare const listBotLocales: API.PaginatedOperationMethod<ListBotLocalesRequest & RegionInput, ListBotLocalesResponse, ListBotLocalesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotRecommendationsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a list of bot recommendations that meet the specified
 * criteria.
 */
export declare const listBotRecommendations: API.PaginatedOperationMethod<ListBotRecommendationsRequest & RegionInput, ListBotRecommendationsResponse, ListBotRecommendationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotReplicasError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to list the replicated bots.
 */
export declare const listBotReplicas: API.OperationMethod<ListBotReplicasRequest & RegionInput, ListBotReplicasResponse, ListBotReplicasError, Credentials | HttpClient.HttpClient>;
export type ListBotResourceGenerationsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the generation requests made for a bot locale.
 */
export declare const listBotResourceGenerations: API.PaginatedOperationMethod<ListBotResourceGenerationsRequest & RegionInput, ListBotResourceGenerationsResponse, ListBotResourceGenerationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotsError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of available bots.
 */
export declare const listBots: API.PaginatedOperationMethod<ListBotsRequest & RegionInput, ListBotsResponse, ListBotsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotVersionReplicasError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Contains information about all the versions replication statuses applicable for Global Resiliency.
 */
export declare const listBotVersionReplicas: API.PaginatedOperationMethod<ListBotVersionReplicasRequest & RegionInput, ListBotVersionReplicasResponse, ListBotVersionReplicasError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBotVersionsError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about all of the versions of a bot.
 *
 * The `ListBotVersions` operation returns a summary of each
 * version of a bot. For example, if a bot has three numbered versions,
 * the `ListBotVersions` operation returns for summaries, one
 * for each numbered version and one for the `DRAFT`
 * version.
 *
 * The `ListBotVersions` operation always returns at least
 * one version, the `DRAFT` version.
 */
export declare const listBotVersions: API.PaginatedOperationMethod<ListBotVersionsRequest & RegionInput, ListBotVersionsResponse, ListBotVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBuiltInIntentsError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of built-in intents provided by Amazon Lex that you can use
 * in your bot.
 *
 * To use a built-in intent as a the base for your own intent, include
 * the built-in intent signature in the `parentIntentSignature`
 * parameter when you call the `CreateIntent` operation. For
 * more information, see CreateIntent.
 */
export declare const listBuiltInIntents: API.PaginatedOperationMethod<ListBuiltInIntentsRequest & RegionInput, ListBuiltInIntentsResponse, ListBuiltInIntentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBuiltInSlotTypesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of built-in slot types that meet the specified
 * criteria.
 */
export declare const listBuiltInSlotTypes: API.PaginatedOperationMethod<ListBuiltInSlotTypesRequest & RegionInput, ListBuiltInSlotTypesResponse, ListBuiltInSlotTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCustomVocabularyItemsError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Paginated list of custom vocabulary items for a given bot locale's
 * custom vocabulary.
 */
export declare const listCustomVocabularyItems: API.PaginatedOperationMethod<ListCustomVocabularyItemsRequest & RegionInput, ListCustomVocabularyItemsResponse, ListCustomVocabularyItemsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExportsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the exports for a bot, bot locale, or custom vocabulary.
 * Exports are kept in the list for 7 days.
 */
export declare const listExports: API.PaginatedOperationMethod<ListExportsRequest & RegionInput, ListExportsResponse, ListExportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListImportsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the imports for a bot, bot locale, or custom vocabulary.
 * Imports are kept in the list for 7 days.
 */
export declare const listImports: API.PaginatedOperationMethod<ListImportsRequest & RegionInput, ListImportsResponse, ListImportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIntentMetricsError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves summary metrics for the intents in your bot. The following fields are required:
 *
 * - `metrics` - A list of AnalyticsIntentMetric objects. In each object, use the `name` field to specify the metric to calculate, the `statistic` field to specify whether to calculate the `Sum`, `Average`, or `Max` number, and the `order` field to specify whether to sort the results in `Ascending` or `Descending` order.
 *
 * - `startDateTime` and `endDateTime` - Define a time range for which you want to retrieve results.
 *
 * Of the optional fields, you can organize the results in the following ways:
 *
 * - Use the `filters` field to filter the results, the `groupBy` field to specify categories by which to group the results, and the `binBy` field to specify time intervals by which to group the results.
 *
 * - Use the `maxResults` field to limit the number of results to return in a single response and the `nextToken` field to return the next batch of results if the response does not return the full set of results.
 *
 * Note that an `order` field exists in both `binBy` and `metrics`. You can specify only one `order` in a given request.
 */
export declare const listIntentMetrics: API.PaginatedOperationMethod<ListIntentMetricsRequest & RegionInput, ListIntentMetricsResponse, ListIntentMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIntentPathsError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves summary statistics for a path of intents that users take over sessions with your bot. The following fields are required:
 *
 * - `startDateTime` and `endDateTime` - Define a time range for which you want to retrieve results.
 *
 * - `intentPath` - Define an order of intents for which you want to retrieve metrics. Separate intents in the path with a forward slash. For example, populate the `intentPath` field with `/BookCar/BookHotel` to see details about how many times users invoked the `BookCar` and `BookHotel` intents in that order.
 *
 * Use the optional `filters` field to filter the results.
 */
export declare const listIntentPaths: API.OperationMethod<ListIntentPathsRequest & RegionInput, ListIntentPathsResponse, ListIntentPathsError, Credentials | HttpClient.HttpClient>;
export type ListIntentsError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Get a list of intents that meet the specified criteria.
 */
export declare const listIntents: API.PaginatedOperationMethod<ListIntentsRequest & RegionInput, ListIntentsResponse, ListIntentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIntentStageMetricsError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves summary metrics for the stages within intents in your bot. The following fields are required:
 *
 * - `metrics` - A list of AnalyticsIntentStageMetric objects. In each object, use the `name` field to specify the metric to calculate, the `statistic` field to specify whether to calculate the `Sum`, `Average`, or `Max` number, and the `order` field to specify whether to sort the results in `Ascending` or `Descending` order.
 *
 * - `startDateTime` and `endDateTime` - Define a time range for which you want to retrieve results.
 *
 * Of the optional fields, you can organize the results in the following ways:
 *
 * - Use the `filters` field to filter the results, the `groupBy` field to specify categories by which to group the results, and the `binBy` field to specify time intervals by which to group the results.
 *
 * - Use the `maxResults` field to limit the number of results to return in a single response and the `nextToken` field to return the next batch of results if the response does not return the full set of results.
 *
 * Note that an `order` field exists in both `binBy` and `metrics`. You can only specify one `order` in a given request.
 */
export declare const listIntentStageMetrics: API.PaginatedOperationMethod<ListIntentStageMetricsRequest & RegionInput, ListIntentStageMetricsResponse, ListIntentStageMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRecommendedIntentsError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of recommended intents provided by the bot
 * recommendation that you can use in your bot. Intents in the
 * response are ordered by relevance.
 */
export declare const listRecommendedIntents: API.PaginatedOperationMethod<ListRecommendedIntentsRequest & RegionInput, ListRecommendedIntentsResponse, ListRecommendedIntentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSessionAnalyticsDataError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of metadata for individual user sessions with your bot. The `startDateTime` and `endDateTime` fields are required. These fields define a time range for which you want to retrieve results. Of the optional fields, you can organize the results in the following ways:
 *
 * - Use the `filters` field to filter the results and the `sortBy` field to specify the values by which to sort the results.
 *
 * - Use the `maxResults` field to limit the number of results to return in a single response and the `nextToken` field to return the next batch of results if the response does not return the full set of results.
 */
export declare const listSessionAnalyticsData: API.PaginatedOperationMethod<ListSessionAnalyticsDataRequest & RegionInput, ListSessionAnalyticsDataResponse, ListSessionAnalyticsDataError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSessionMetricsError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves summary metrics for the user sessions with your bot. The following fields are required:
 *
 * - `metrics` - A list of AnalyticsSessionMetric objects. In each object, use the `name` field to specify the metric to calculate, the `statistic` field to specify whether to calculate the `Sum`, `Average`, or `Max` number, and the `order` field to specify whether to sort the results in `Ascending` or `Descending` order.
 *
 * - `startDateTime` and `endDateTime` - Define a time range for which you want to retrieve results.
 *
 * Of the optional fields, you can organize the results in the following ways:
 *
 * - Use the `filters` field to filter the results, the `groupBy` field to specify categories by which to group the results, and the `binBy` field to specify time intervals by which to group the results.
 *
 * - Use the `maxResults` field to limit the number of results to return in a single response and the `nextToken` field to return the next batch of results if the response does not return the full set of results.
 *
 * Note that an `order` field exists in both `binBy` and `metrics`. Currently, you can specify it in either field, but not in both.
 */
export declare const listSessionMetrics: API.PaginatedOperationMethod<ListSessionMetricsRequest & RegionInput, ListSessionMetricsResponse, ListSessionMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSlotsError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of slots that match the specified criteria.
 */
export declare const listSlots: API.PaginatedOperationMethod<ListSlotsRequest & RegionInput, ListSlotsResponse, ListSlotsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSlotTypesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a list of slot types that match the specified criteria.
 */
export declare const listSlotTypes: API.PaginatedOperationMethod<ListSlotTypesRequest & RegionInput, ListSlotTypesResponse, ListSlotTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of tags associated with a resource. Only bots, bot
 * aliases, and bot channels can have tags associated with them.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTestExecutionResultItemsError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of test execution result items.
 */
export declare const listTestExecutionResultItems: API.PaginatedOperationMethod<ListTestExecutionResultItemsRequest & RegionInput, ListTestExecutionResultItemsResponse, ListTestExecutionResultItemsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTestExecutionsError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The list of test set executions.
 */
export declare const listTestExecutions: API.PaginatedOperationMethod<ListTestExecutionsRequest & RegionInput, ListTestExecutionsResponse, ListTestExecutionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTestSetRecordsError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The list of test set records.
 */
export declare const listTestSetRecords: API.PaginatedOperationMethod<ListTestSetRecordsRequest & RegionInput, ListTestSetRecordsResponse, ListTestSetRecordsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTestSetsError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The list of the test sets
 */
export declare const listTestSets: API.PaginatedOperationMethod<ListTestSetsRequest & RegionInput, ListTestSetsResponse, ListTestSetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListUtteranceAnalyticsDataError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * To use this API operation, your IAM role must have permissions to
 * perform the ListAggregatedUtterances operation, which provides access to
 * utterance-related analytics. See Viewing utterance
 * statistics for the IAM policy to apply to the IAM role.
 *
 * Retrieves a list of metadata for individual user utterances to your bot. The following fields are required:
 *
 * - `startDateTime` and `endDateTime` - Define a time range for which you want to retrieve results.
 *
 * Of the optional fields, you can organize the results in the following ways:
 *
 * - Use the `filters` field to filter the results and the `sortBy` field to specify the values by which to sort the results.
 *
 * - Use the `maxResults` field to limit the number of results to return in a single response and the `nextToken` field to return the next batch of results if the response does not return the full set of results.
 */
export declare const listUtteranceAnalyticsData: API.PaginatedOperationMethod<ListUtteranceAnalyticsDataRequest & RegionInput, ListUtteranceAnalyticsDataResponse, ListUtteranceAnalyticsDataError, Credentials | HttpClient.HttpClient, unknown>;
export type ListUtteranceMetricsError = InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * To use this API operation, your IAM role must have permissions to
 * perform the ListAggregatedUtterances operation, which provides access to
 * utterance-related analytics. See Viewing utterance
 * statistics for the IAM policy to apply to the IAM role.
 *
 * Retrieves summary metrics for the utterances in your bot. The following fields are required:
 *
 * - `metrics` - A list of AnalyticsUtteranceMetric objects. In each object, use the `name` field to specify the metric to calculate, the `statistic` field to specify whether to calculate the `Sum`, `Average`, or `Max` number, and the `order` field to specify whether to sort the results in `Ascending` or `Descending` order.
 *
 * - `startDateTime` and `endDateTime` - Define a time range for which you want to retrieve results.
 *
 * Of the optional fields, you can organize the results in the following ways:
 *
 * - Use the `filters` field to filter the results, the `groupBy` field to specify categories by which to group the results, and the `binBy` field to specify time intervals by which to group the results.
 *
 * - Use the `maxResults` field to limit the number of results to return in a single response and the `nextToken` field to return the next batch of results if the response does not return the full set of results.
 *
 * Note that an `order` field exists in both `binBy` and `metrics`. Currently, you can specify it in either field, but not in both.
 */
export declare const listUtteranceMetrics: API.PaginatedOperationMethod<ListUtteranceMetricsRequest & RegionInput, ListUtteranceMetricsResponse, ListUtteranceMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type SearchAssociatedTranscriptsError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Search for associated transcripts that meet the specified
 * criteria.
 */
export declare const searchAssociatedTranscripts: API.OperationMethod<SearchAssociatedTranscriptsRequest & RegionInput, SearchAssociatedTranscriptsResponse, SearchAssociatedTranscriptsError, Credentials | HttpClient.HttpClient>;
export type StartBotAnalyzerError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates an asynchronous analysis of your bot configuration using AI-powered analysis to identify potential issues and recommend improvements based on AWS best practices.
 *
 * The analysis examines your bot's configuration, including intents, utterances, slots, and conversation flows, to provide actionable recommendations for optimization.
 */
export declare const startBotAnalyzer: API.OperationMethod<StartBotAnalyzerRequest & RegionInput, StartBotAnalyzerResponse, StartBotAnalyzerError, Credentials | HttpClient.HttpClient>;
export type StartBotRecommendationError = ConflictException | InternalServerException | PreconditionFailedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this to provide your transcript data, and to start the bot
 * recommendation process.
 */
export declare const startBotRecommendation: API.OperationMethod<StartBotRecommendationRequest & RegionInput, StartBotRecommendationResponse, StartBotRecommendationError, Credentials | HttpClient.HttpClient>;
export type StartBotResourceGenerationError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a request for the descriptive bot builder to generate a bot locale configuration
 * based on the prompt you provide it. After you make this call, use the `DescribeBotResourceGeneration`
 * operation to check on the status of the generation and for the `generatedBotLocaleUrl` when the
 * generation is complete. Use that value to retrieve the Amazon S3 object containing the bot locale configuration. You can
 * then modify and import this configuration.
 */
export declare const startBotResourceGeneration: API.OperationMethod<StartBotResourceGenerationRequest & RegionInput, StartBotResourceGenerationResponse, StartBotResourceGenerationError, Credentials | HttpClient.HttpClient>;
export type StartImportError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts importing a bot, bot locale, or custom vocabulary from a zip
 * archive that you uploaded to an S3 bucket.
 */
export declare const startImport: API.OperationMethod<StartImportRequest & RegionInput, StartImportResponse, StartImportError, Credentials | HttpClient.HttpClient>;
export type StartTestExecutionError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to start test set execution.
 */
export declare const startTestExecution: API.OperationMethod<StartTestExecutionRequest & RegionInput, StartTestExecutionResponse, StartTestExecutionError, Credentials | HttpClient.HttpClient>;
export type StartTestSetGenerationError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to start the generation of test set.
 */
export declare const startTestSetGeneration: API.OperationMethod<StartTestSetGenerationRequest & RegionInput, StartTestSetGenerationResponse, StartTestSetGenerationError, Credentials | HttpClient.HttpClient>;
export type StopBotAnalyzerError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels an ongoing bot analysis execution. Once stopped, the analysis cannot be resumed and no recommendations will be generated.
 */
export declare const stopBotAnalyzer: API.OperationMethod<StopBotAnalyzerRequest & RegionInput, StopBotAnalyzerResponse, StopBotAnalyzerError, Credentials | HttpClient.HttpClient>;
export type StopBotRecommendationError = ConflictException | InternalServerException | PreconditionFailedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stop an already running Bot Recommendation request.
 */
export declare const stopBotRecommendation: API.OperationMethod<StopBotRecommendationRequest & RegionInput, StopBotRecommendationResponse, StopBotRecommendationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds the specified tags to the specified resource. If a tag key
 * already exists, the existing value is replaced with the new
 * value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a bot, bot alias, or bot channel.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBotError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing bot.
 */
export declare const updateBot: API.OperationMethod<UpdateBotRequest & RegionInput, UpdateBotResponse, UpdateBotError, Credentials | HttpClient.HttpClient>;
export type UpdateBotAliasError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing bot alias.
 */
export declare const updateBotAlias: API.OperationMethod<UpdateBotAliasRequest & RegionInput, UpdateBotAliasResponse, UpdateBotAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateBotLocaleError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the settings that a bot has for a specific locale.
 */
export declare const updateBotLocale: API.OperationMethod<UpdateBotLocaleRequest & RegionInput, UpdateBotLocaleResponse, UpdateBotLocaleError, Credentials | HttpClient.HttpClient>;
export type UpdateBotRecommendationError = ConflictException | InternalServerException | PreconditionFailedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing bot recommendation request.
 */
export declare const updateBotRecommendation: API.OperationMethod<UpdateBotRecommendationRequest & RegionInput, UpdateBotRecommendationResponse, UpdateBotRecommendationError, Credentials | HttpClient.HttpClient>;
export type UpdateExportError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the password used to protect an export zip archive.
 *
 * The password is not required. If you don't supply a password, Amazon Lex
 * generates a zip file that is not protected by a password. This is the
 * archive that is available at the pre-signed S3 URL provided by the
 * DescribeExport operation.
 */
export declare const updateExport: API.OperationMethod<UpdateExportRequest & RegionInput, UpdateExportResponse, UpdateExportError, Credentials | HttpClient.HttpClient>;
export type UpdateIntentError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the settings for an intent.
 */
export declare const updateIntent: API.OperationMethod<UpdateIntentRequest & RegionInput, UpdateIntentResponse, UpdateIntentError, Credentials | HttpClient.HttpClient>;
export type UpdateResourcePolicyError = InternalServerException | PreconditionFailedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Replaces the existing resource policy for a bot or bot alias with a
 * new one. If the policy doesn't exist, Amazon Lex returns an
 * exception.
 */
export declare const updateResourcePolicy: API.OperationMethod<UpdateResourcePolicyRequest & RegionInput, UpdateResourcePolicyResponse, UpdateResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateSlotError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the settings for a slot.
 */
export declare const updateSlot: API.OperationMethod<UpdateSlotRequest & RegionInput, UpdateSlotResponse, UpdateSlotError, Credentials | HttpClient.HttpClient>;
export type UpdateSlotTypeError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing slot type.
 */
export declare const updateSlotType: API.OperationMethod<UpdateSlotTypeRequest & RegionInput, UpdateSlotTypeResponse, UpdateSlotTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateTestSetError = ConflictException | InternalServerException | PreconditionFailedException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to update the test set.
 */
export declare const updateTestSet: API.OperationMethod<UpdateTestSetRequest & RegionInput, UpdateTestSetResponse, UpdateTestSetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lex-models-v2.d.ts.map