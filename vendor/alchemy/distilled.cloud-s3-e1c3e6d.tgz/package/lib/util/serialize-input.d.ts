/**
 * Input Serialization
 *
 * Binds input values to HTTP request parts (headers, path labels, query params)
 * based on Smithy HTTP trait annotations.
 */
import { InvalidInput } from "@distilled.cloud/core/protocol-http";
import type * as AST from "effect/SchemaAST";
import type { Request } from "../client/request.ts";
/**
 * Percent-encode a URI label value: everything except RFC 3986 unreserved
 * characters, so "/" becomes "%2F" (Smithy / AWS SDK `extendedEncodeURIComponent`).
 */
export declare const encodeLabel: (value: string) => string;
/**
 * Encode a greedy `{Label+}` value: each "/"-separated segment is encoded
 * with {@link encodeLabel} and the "/" separators are kept, so an S3 key
 * `a/b c` becomes `a/b%20c` and `/a` becomes `/a`.
 */
export declare const encodeGreedyLabel: (value: string) => string;
/**
 * The refusal for a path label value that would address another resource,
 * or `undefined`: a `.` or `..` value or greedy segment (core's
 * `invalidLabel`), or an empty value, which drops the segment (S3
 * `DeleteObject` with `Key: ""` would address the bucket). The AWS SDK for
 * JavaScript refuses an empty label too.
 */
export declare const invalidAwsLabel: (member: string, value: unknown, greedy: boolean) => InvalidInput | undefined;
/** The refusal for a host label value that would move the request to another host. */
export declare const invalidHostLabel: (member: string, value: string) => InvalidInput;
/**
 * Apply the @http trait (method, uri) to the request.
 */
export declare function applyHttpTrait(ast: AST.AST, request: Request): void;
/**
 * Bind input values to HTTP request based on trait annotations.
 *
 * This processes each input member and:
 * - Adds @httpHeader values to request.headers
 * - Substitutes @httpLabel values in request.path, or returns the
 *   {@link InvalidInput} of a value {@link invalidAwsLabel} refuses
 * - Adds @httpQuery values to request.query
 * - Adds @httpPrefixHeaders values to request.headers
 * - Collects @httpPayload for body serialization
 * - Collects remaining members as body content
 */
export declare function bindInputToRequest(ast: AST.AST, input: Record<string, unknown>, request: Request): {
    readonly payloadValue: unknown;
    readonly payloadAst: AST.AST | undefined;
    readonly bodyMembers: Record<string, unknown>;
    readonly hasBodyMembers: boolean;
} | InvalidInput;
//# sourceMappingURL=serialize-input.d.ts.map