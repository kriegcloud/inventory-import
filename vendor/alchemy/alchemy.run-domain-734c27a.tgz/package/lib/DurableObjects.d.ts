import { Callbacks } from "alchemy/Callback";
/**
 * A domain model on Durable Objects, for any runtime that hosts them:
 * Cloudflare, Rivet, Effect Cluster. Every aggregate instance, view key,
 * policy, projection key and stream key is one object, and this module is
 * everything those objects do. A platform supplies a {@link Host}: how to
 * declare a class of objects and call one by name, and, per instance, an
 * {@link ObjectState} (storage, an exclusive section, background work), its
 * `RuntimeContext`, and a `Callbacks` implementation.
 *
 * @module
 */
import type { HttpEffect } from "alchemy/Http";
import { RuntimeContext } from "alchemy/RuntimeContext";
import * as Context from "effect/Context";
import * as SecureRandom from "effect/crypto/SecureRandom";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
import * as Layer from "effect/Layer";
import * as Schedule from "effect/Schedule";
import * as Schema from "effect/Schema";
import type * as Scope from "effect/Scope";
import * as Backfill from "./Backfill.ts";
import { type HostedModel, Platform, Subscription } from "./Platform.ts";
/** Options for {@link ObjectStorage.list}. Keys come back in order. */
export interface ListOptions {
    /** Only keys that start with this prefix. */
    readonly prefix?: string;
    /** Only keys at or after this key. */
    readonly start?: string;
    /** Only keys after this key. */
    readonly startAfter?: string;
    /** Only keys before this key. */
    readonly end?: string;
    /** At most this many entries. */
    readonly limit?: number;
    /** Keys in descending order: `limit` counts from the end. */
    readonly reverse?: boolean;
}
/**
 * An object's own key-value storage. Values are structured-cloneable (plain
 * JSON is enough for everything Domain stores). Writes inside `transaction`
 * commit together, or not at all.
 */
export interface ObjectStorage {
    get<T>(key: string): Effect.Effect<T | undefined>;
    put<T>(key: string, value: T): Effect.Effect<void>;
    put<T>(entries: Record<string, T>): Effect.Effect<void>;
    delete(key: string): Effect.Effect<boolean>;
    delete(keys: ReadonlyArray<string>): Effect.Effect<number>;
    list<T>(options?: ListOptions): Effect.Effect<Map<string, T>>;
    transaction<A, E, R>(effect: Effect.Effect<A, E, R>): Effect.Effect<A, E, R>;
}
/** A live read's WebSocket, held by the object that owns its key. */
export interface ObjectSocket {
    send(message: string): Effect.Effect<void>;
    close(code: number, reason: string): Effect.Effect<void>;
    /** Keep a value with the socket, across hibernation where the host has it. */
    serializeAttachment(value: unknown): void;
    deserializeAttachment<T>(): T | null;
}
/** The instance an object's methods run against. */
export interface ObjectStateShape {
    readonly storage: ObjectStorage;
    /**
     * Run `effect` with every other event on this instance held back, as
     * Cloudflare's `blockConcurrencyWhile` does. Objects call each other only
     * outside it.
     */
    exclusive<A, E, R>(effect: Effect.Effect<A, E, R>): Effect.Effect<A, E, R>;
    /** Run `effect` in the background, keeping the instance alive until it ends. */
    waitUntil(effect: Effect.Effect<void>): Effect.Effect<void>;
    /**
     * Live reads pushed over WebSockets the object holds. Without it, live
     * reads are streamed responses that poll the object.
     */
    readonly sockets?: {
        /** Accept the current request's upgrade. */
        readonly accept: () => Effect.Effect<readonly [HttpServerResponse.HttpServerResponse, ObjectSocket]>;
        /** Every socket the instance holds. */
        readonly all: () => Effect.Effect<ReadonlyArray<ObjectSocket>>;
    };
}
declare const ObjectState_base: Context.ServiceClass<ObjectState, "alchemy/Domain/ObjectState", ObjectStateShape>;
/** The running object's state, which a host provides to every instance. */
export declare class ObjectState extends ObjectState_base {
}
/** One object: every method is a call that returns an Effect. */
export interface Stub {
    readonly [method: string]: (...args: ReadonlyArray<any>) => Effect.Effect<unknown, unknown>;
}
/** Every object of one class, by name. */
export interface Namespace {
    readonly getByName: (name: string) => Stub;
}
/** What an instance runs with. */
export type InstanceServices = ObjectState | RuntimeContext | Callbacks | Scope.Scope;
/**
 * An object's implementation: built once per instance, it returns the
 * instance's methods. The host calls them by name with JSON arguments, and
 * hands their JSON results back. A `fetch` method, when there is one, serves
 * the instance's HTTP requests (a live read's WebSocket upgrade).
 */
export type ObjectImpl = Effect.Effect<Record<string, unknown>, never, InstanceServices>;
/**
 * What a runtime supplies to host models on its Durable Objects. Class names
 * given to it are a model's own (`AccountAggregate`, `DepositsView`); the
 * host decides where they live (`Bank.AccountAggregate`).
 */
export interface Host<R = never> {
    /**
     * Declare a class of the model's objects while the model's Layer is built,
     * and return its namespace.
     */
    readonly declare: (model: HostedModel, name: string, impl: ObjectImpl) => Effect.Effect<Namespace, never, R>;
    /**
     * A class of the model by name, which code that doesn't build the model
     * (another isolate of the same deploy) can still reach. Optional.
     */
    readonly lookup?: (model: HostedModel, name: string) => Namespace | undefined;
    /** Called once per model when it is hosted, before any class is declared. */
    readonly hosted?: (model: HostedModel) => Effect.Effect<void, never, R>;
    /**
     * Forward a live read's WebSocket upgrade (the current request) to the
     * object named `key`. Hosts whose objects hold sockets supply it.
     */
    readonly connect?: (namespace: Namespace, key: string, subscription: Subscription) => HttpEffect;
    /**
     * Run the deploy's backfill of `targets`, and wait for it. Called while
     * deploying (not at runtime) when the deploy adds or rebuilds consumers.
     * Without it, each run starts on the first call after the deploy.
     */
    readonly backfill?: (model: HostedModel, 
    /** Every plan the model has for these targets. */
    plans: (targets: ReadonlyArray<string>) => Readonly<Record<string, Backfill.Plan>>) => Effect.Effect<(targets: ReadonlyArray<string>) => Effect.Effect<void, never, R>, never, R>;
    /** Models whose names collide on the same key fail to host: one per Worker, pool or class. */
    readonly claimKey: Effect.Effect<object, never, R>;
}
/**
 * How long to keep retrying a call that failed in transit: an instance being
 * reset reports an opaque error, and for a while after a deploy some instances
 * still run the previous code (whose classes don't implement our methods).
 * Backs off from 100ms to 2s, about a minute in total, so a call survives a
 * deploy's rollout.
 */
export declare const TRANSIT_RETRY: {
    readonly schedule: Schedule.Schedule<Duration.Duration, unknown, never, never>;
    readonly times: 35;
};
/**
 * Call an object. A call that fails in transit is retried: every Domain
 * object method is idempotent (sends dedupe by command id, deliveries by
 * checkpoint, schedules replace, reads are reads). A defect the object
 * reported, or a call that keeps failing, is a defect for the caller.
 */
export declare const unwrapDefects: <A>(call: Effect.Effect<unknown, unknown>) => Effect.Effect<A>;
/**
 * The class of a view or projection generation. A rebuilt consumer is a new
 * class (`DepositsViewV1`): it exists only in the code that rebuilds it, so
 * none of its objects can start on older code during a rollout, and the
 * previous generation's are left as they were (a shadow rebuild).
 */
export declare const consumerClass: (kind: "view" | "projection", name: string, generation: number) => string;
/**
 * The class of a consumer generation's run: its root, relays and scanners. A
 * class of its own, new with the deploy like the keys' class, so none of them
 * can start on older code; and apart from the keys, so a burst of keys that
 * runs an isolate out of memory doesn't reset the run that drives them.
 */
export declare const runClass: (keys: string) => string;
/** A consumer's generation from its target id: `view:Name#2` is 2. */
export declare const generationOfTarget: (target: string) => number;
/** The run class of a consumer, by target id. */
export declare const runClassOfTarget: (target: string) => string;
/** What a live read's WebSocket carries across hibernation. */
export declare const Attachment: Schema.Struct<{
    readonly key: Schema.String;
    readonly subscription: Schema.Struct<{
        readonly requestId: Schema.Union<readonly [Schema.String, Schema.Number]>;
        readonly mode: Schema.Literals<readonly ["watch", "events"]>;
        readonly where: Schema.optionalKey<Schema.Unknown>;
        readonly context: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly cursor: Schema.Number;
        readonly refused: Schema.optionalKey<Schema.Unknown>;
        readonly caughtUpSent: Schema.optionalKey<Schema.Boolean>;
        readonly validUntil: Schema.optionalKey<Schema.Number>;
    }>;
}>;
export type Attachment = typeof Attachment.Type;
/**
 * The header a host's `connect` sets on the upgrade it forwards to an object:
 * the {@link Attachment} as JSON. The host sets it, overwriting any a client
 * sent, so the object can trust it.
 */
export declare const SUBSCRIPTION_HEADER = "x-domain-subscription";
/** What a backfill needs to know of a consumer, in the deployed model. */
export type PlanOf = (target: string) => Backfill.Plan | undefined;
/** Every plan the model has for these targets, as an announcement carries them. */
export declare const plansOf: (targets: ReadonlyArray<string>, planOf: PlanOf) => Record<string, Backfill.Plan>;
/** The object of a consumer's class at the root of its run: it drives the run's passes. */
export declare const RUN_ROOT = "~run";
/**
 * The claim key of a host named `name` (a pool, or a class of objects) in
 * the runtime building the model. Two models with one name fail in one
 * runtime; a redeploy builds a new runtime, so the model it hosts replaces
 * the old one even when both are built in one process (a test, or a reload
 * in dev).
 *
 * @internal
 */
export declare const runtimeClaim: (name: string) => Effect.Effect<object>;
/**
 * The Domain {@link Platform} over a host's Durable Objects. Every aggregate,
 * view, policy, projection and stream becomes a class of objects, declared
 * while the model's Layer is built; one object per aggregate id, per view,
 * projection or stream key, and per policy key.
 *
 * Commands to one instance run one at a time, and their events, state and
 * outbox commit together. Deliveries to views and policies are at least once
 * and in order per source, and survive restarts. A view or projection added
 * in a later deploy receives the history recorded before it: every instance
 * lists itself in a directory of objects, and a run reads it and gives each
 * key of the new consumer its sources' events.
 *
 * The workflow engine sagas run on is the host's to provide.
 */
export declare const makePlatform: <R>(host: Host<R>) => Layer.Layer<Platform, never, R | SecureRandom.SecureRandom>;
/**
 * An object's name inside a host that keeps every class of a model in one
 * class of its own (Rivet, Effect Cluster): `Bank.AccountAggregate/a-1`.
 */
export declare const multiplexedName: (model: string, name: string, key: string) => string;
/** A model's class name: `Billing.AccountAggregate`. */
export declare const className: (modelName: string, name: string) => string;
/** Split a {@link multiplexedName} back into its class and key. */
export declare const parseMultiplexedName: (name: string) => {
    className: string;
    key: string;
} | undefined;
export {};
//# sourceMappingURL=DurableObjects.d.ts.map