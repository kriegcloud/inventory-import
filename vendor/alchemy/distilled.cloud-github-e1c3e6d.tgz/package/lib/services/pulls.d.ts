import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** An ordered list of pull request numbers to append to the stack, from the current top upward. */
export type AddPullRequestStackRequestPullRequestsList = Array<number>;
export interface AddPullRequestStackRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request stack. */
    stack_number: number;
    /** An ordered list of pull request numbers to append to the stack, from the current top upward. */
    pull_requests: AddPullRequestStackRequestPullRequestsList;
}
export interface AddPullRequestStackResponseBase {
    ref: string;
}
export interface PullRequestStackPullRequestHeadRepo {
    id: number;
    url: string;
    name: string;
}
export interface PullRequestStackPullRequestHead {
    ref: string;
    sha: string;
    repo: PullRequestStackPullRequestHeadRepo;
}
export type PullRequestStackPullRequestBaseRepo = PullRequestStackPullRequestHeadRepo;
export type PullRequestStackPullRequestBase = PullRequestStackPullRequestHead;
export type PullRequestStackPullRequestState = "open" | "closed";
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export interface PullRequestStackPullRequest {
    id: number;
    number: number;
    url: string;
    head: PullRequestStackPullRequestHead;
    base: PullRequestStackPullRequestHead;
    node_id: string;
    title: string;
    state: PullRequestStackPullRequestState;
    merged_at: string | null;
    draft: boolean;
    html_url: string;
    user: NullableSimpleUser | null;
}
export type AddPullRequestStackResponsePullRequestsList = Array<PullRequestStackPullRequest>;
export interface AddPullRequestStackResponse {
    id: number;
    number: number;
    node_id: string;
    url: string;
    base: AddPullRequestStackResponseBase;
    /** Whether the stack has any open pull request. False when all pull requests are merged or closed. */
    open: boolean;
    created_at: string;
    pull_requests: AddPullRequestStackResponsePullRequestsList;
}
export interface CheckIfMergedRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
}
export interface CheckIfMergedResponse {
}
export interface CreateRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The title of the new pull request. Required unless `issue` is specified. */
    title?: string | undefined;
    /** The name of the branch where your changes are implemented. For cross-repository pull requests in the same network, namespace `head` with a user like this: `username:branch`. */
    head: string;
    /** The name of the repository where the changes in the pull request were made. This field is required for cross-repository pull requests if both repositories are owned by the same organization. */
    head_repo?: string | undefined;
    /** The name of the branch you want the changes pulled into. This should be an existing branch on the current repository. You cannot submit a pull request to one repository that requests a merge to a base of another repository. */
    base: string;
    /** The contents of the pull request. */
    body?: string | undefined;
    /** Indicates whether [maintainers can modify](https://docs.github.com/articles/allowing-changes-to-a-pull-request-branch-created-from-a-fork/) the pull request. */
    maintainer_can_modify?: boolean | undefined;
    /** Indicates whether the pull request is a draft. See "[Draft Pull Requests](https://docs.github.com/articles/about-pull-requests#draft-pull-requests)" in the GitHub Help documentation to learn more. */
    draft?: boolean | undefined;
    /** An issue in the repository to convert to a pull request. The issue title, body, and comments will become the title, body, and comments on the new pull request. Required unless `title` is specified. */
    issue?: number | undefined;
}
/** State of this Pull Request. Either `open` or `closed`. */
export type PullRequestState = "open" | "closed";
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
export interface PullRequestLabelsItem {
    id: number;
    node_id: string;
    url: string;
    name: string;
    description: string | null;
    color: string;
    default: boolean;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by: NullableSimpleUser | null;
}
export type PullRequestLabelsList = Array<PullRequestLabelsItem>;
/** The state of the milestone. */
export type NullableMilestoneState = "open" | "closed";
/** A collection of related issues and pull requests. */
export interface NullableMilestone {
    url: string;
    html_url: string;
    labels_url: string;
    id: number;
    node_id: string;
    /** The number of the milestone. */
    number: number;
    /** The state of the milestone. */
    state: NullableMilestoneState;
    /** The title of the milestone. */
    title: string;
    description: string | null;
    creator: NullableSimpleUser | null;
    open_issues: number;
    closed_issues: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    due_on: string | null;
}
export type PullRequestAssigneesList = Array<NullableSimpleUser>;
export type PullRequestRequestedReviewersList = Array<NullableSimpleUser>;
/** The ownership type of the team */
export type TeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface TeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: TeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
export type PullRequestRequestedTeamsList = Array<TeamSimple>;
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: NullableSimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
export interface PullRequestHead {
    label: string;
    ref: string;
    repo: Repository;
    sha: string;
    user: NullableSimpleUser;
}
export type PullRequestBase = PullRequestHead;
/** Hypermedia Link */
export interface Link {
    href: string;
}
export interface PullRequestLinks {
    comments: Link;
    commits: Link;
    statuses: Link;
    html: Link;
    issue: Link;
    review_comments: Link;
    review_comment: Link;
    self: Link;
}
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
/** The merge method to use. */
export type AutoMergeMergeMethod = "merge" | "squash" | "rebase";
/** The status of auto merging a pull request. */
export interface AutoMerge {
    enabled_by: NullableSimpleUser;
    /** The merge method to use. */
    merge_method: AutoMergeMergeMethod;
    /** Title for the merge commit message. */
    commit_title: string;
    /** Commit message for the merge commit. */
    commit_message: string;
}
export interface PullRequestStackBase {
    /** The base ref of the stack this pull request belongs to. */
    ref: string;
    /** The base SHA of the stack this pull request belongs to. */
    sha: string;
}
/** The stack information associated with a pull request. */
export interface PullRequestStack {
    base: PullRequestStackBase;
    /** The total number of pull requests in the stack. */
    size?: number | undefined;
    /** The one-based position of this pull request within the stack, where 1 is the bottom of the stack. */
    position?: number | undefined;
    /** The ID of the stack that this pull request belongs to. */
    id?: number | undefined;
    /** The number of the stack that this pull request belongs to. */
    number?: number | undefined;
}
/** Pull requests let you tell others about changes you've pushed to a repository on GitHub. Once a pull request is sent, interested parties can review the set of changes, discuss potential modifications, and even push follow-up commits if necessary. */
export interface PullRequest {
    url: string;
    id: number;
    node_id: string;
    html_url: string;
    diff_url: string;
    patch_url: string;
    issue_url: string;
    commits_url: string;
    review_comments_url: string;
    review_comment_url: string;
    comments_url: string;
    statuses_url: string;
    /** Number uniquely identifying the pull request within its repository. */
    number: number;
    /** State of this Pull Request. Either `open` or `closed`. */
    state: PullRequestState;
    locked: boolean;
    /** The title of the pull request. */
    title: string;
    user: NullableSimpleUser;
    body: string | null;
    labels: PullRequestLabelsList;
    milestone: NullableMilestone | null;
    active_lock_reason?: string | null | undefined;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    merged_at: string | null;
    merge_commit_sha: string | null;
    assignee: NullableSimpleUser | null;
    assignees?: PullRequestAssigneesList | undefined;
    requested_reviewers?: PullRequestRequestedReviewersList | undefined;
    requested_teams?: PullRequestRequestedTeamsList | undefined;
    head: PullRequestHead;
    base: PullRequestHead;
    _links: PullRequestLinks;
    author_association: AuthorAssociation;
    auto_merge: AutoMerge | null;
    stack?: PullRequestStack | null | undefined;
    /** Indicates whether or not the pull request is a draft. */
    draft?: boolean | undefined;
    merged: boolean;
    mergeable: boolean | null;
    rebaseable?: boolean | null | undefined;
    mergeable_state: string;
    merged_by: NullableSimpleUser | null;
    comments: number;
    review_comments: number;
    /** Indicates whether maintainers can modify the pull request. */
    maintainer_can_modify: boolean;
    commits: number;
    additions: number;
    deletions: number;
    changed_files: number;
}
/** An ordered list of pull request numbers forming the stack from bottom to top. */
export type CreatePullRequestStackRequestPullRequestsList = Array<number>;
export interface CreatePullRequestStackRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** An ordered list of pull request numbers forming the stack from bottom to top. */
    pull_requests: CreatePullRequestStackRequestPullRequestsList;
}
export type CreatePullRequestStackResponseBase = AddPullRequestStackResponseBase;
export type CreatePullRequestStackResponsePullRequestsList = Array<PullRequestStackPullRequest>;
export interface CreatePullRequestStackResponse {
    id: number;
    number: number;
    node_id: string;
    url: string;
    base: AddPullRequestStackResponseBase;
    /** Whether the stack has any open pull request. False when all pull requests are merged or closed. */
    open: boolean;
    created_at: string;
    pull_requests: CreatePullRequestStackResponsePullRequestsList;
}
export interface CreateReplyForReviewCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The text of the review comment. */
    body: string;
}
/** The kind of contributing source. */
export type PullRequestReviewCommentCopilotCodeReviewSourcesItemKind = "SKILL" | "MCP" | "CUSTOM_INSTRUCTIONS";
export interface PullRequestReviewCommentCopilotCodeReviewSourcesItem {
    /** The kind of contributing source. */
    kind: PullRequestReviewCommentCopilotCodeReviewSourcesItemKind;
    /** The reported source name, or "custom instructions" for CUSTOM_INSTRUCTIONS. */
    name: string;
    /** The validated repository-relative source path, if available. Commit OIDs are not exposed. */
    path?: string | undefined;
}
/** Sources reported as contributing to this comment; may be incomplete. Not returned for issue timeline events. */
export type PullRequestReviewCommentCopilotCodeReviewSourcesList = Array<PullRequestReviewCommentCopilotCodeReviewSourcesItem>;
export type PullRequestReviewCommentLinksSelf = Link;
export type PullRequestReviewCommentLinksHtml = Link;
export type PullRequestReviewCommentLinksPullRequest = Link;
export interface PullRequestReviewCommentLinks {
    self: Link;
    html: Link;
    pull_request: Link;
}
/** The side of the first line of the range for a multi-line comment. */
export type PullRequestReviewCommentStartSide = "LEFT" | "RIGHT";
/** The side of the diff to which the comment applies. The side of the last line of the range for a multi-line comment */
export type PullRequestReviewCommentSide = "LEFT" | "RIGHT";
/** The level at which the comment is targeted, can be a diff line or a file. */
export type PullRequestReviewCommentSubjectType = "line" | "file";
export interface ReactionRollup {
    url: string;
    total_count: number;
    _1: number;
    _1_2: number;
    laugh: number;
    confused: number;
    heart: number;
    hooray: number;
    eyes: number;
    rocket: number;
}
/** Pull Request Review Comments are comments on a portion of the Pull Request's diff. */
export interface PullRequestReviewComment {
    /** Whether this comment was produced by Copilot code review. Not returned for issue timeline events. */
    is_copilot_code_review?: boolean | undefined;
    /** Sources reported as contributing to this comment; may be incomplete. Not returned for issue timeline events. */
    copilot_code_review_sources?: PullRequestReviewCommentCopilotCodeReviewSourcesList | undefined;
    /** URL for the pull request review comment */
    url: string;
    /** The ID of the pull request review to which the comment belongs. */
    pull_request_review_id: number | null;
    /** The ID of the pull request review comment. */
    id: number;
    /** The node ID of the pull request review comment. */
    node_id: string;
    /** The diff of the line that the comment refers to. */
    diff_hunk: string;
    /** The relative path of the file to which the comment applies. */
    path: string;
    /** The line index in the diff to which the comment applies. This field is closing down; use `line` instead. */
    position?: number | undefined;
    /** The index of the original line in the diff to which the comment applies. This field is closing down; use `original_line` instead. */
    original_position?: number | undefined;
    /** The SHA of the commit to which the comment applies. */
    commit_id: string;
    /** The SHA of the original commit to which the comment applies. */
    original_commit_id: string;
    /** The comment ID to reply to. */
    in_reply_to_id?: number | undefined;
    user: NullableSimpleUser | null;
    /** The text of the comment. */
    body: string;
    created_at: string;
    updated_at: string;
    /** HTML URL for the pull request review comment. */
    html_url: string;
    /** URL for the pull request that the review comment belongs to. */
    pull_request_url: string;
    author_association: AuthorAssociation;
    _links: PullRequestReviewCommentLinks;
    /** The first line of the range for a multi-line comment. */
    start_line?: number | null | undefined;
    /** The first line of the range for a multi-line comment. */
    original_start_line?: number | null | undefined;
    /** The side of the first line of the range for a multi-line comment. */
    start_side?: PullRequestReviewCommentStartSide | null | undefined;
    /** The line of the blob to which the comment applies. The last line of the range for a multi-line comment */
    line?: number | undefined;
    /** The line of the blob to which the comment applies. The last line of the range for a multi-line comment */
    original_line?: number | undefined;
    /** The side of the diff to which the comment applies. The side of the last line of the range for a multi-line comment */
    side?: PullRequestReviewCommentSide | undefined;
    /** The level at which the comment is targeted, can be a diff line or a file. */
    subject_type?: PullRequestReviewCommentSubjectType | undefined;
    reactions?: ReactionRollup | undefined;
    body_html?: string | undefined;
    body_text?: string | undefined;
}
/** The review action you want to perform. The review actions include: `APPROVE`, `REQUEST_CHANGES`, or `COMMENT`. By leaving this blank, you set the review action state to `PENDING`, which means you will need to [submit the pull request review](https://docs.github.com/rest/pulls/reviews#submit-a-review-for-a-pull-request) when you are ready. */
export type CreateReviewRequestEvent = "APPROVE" | "REQUEST_CHANGES" | "COMMENT";
export interface CreateReviewRequestCommentsItem {
    /** The relative path to the file that necessitates a review comment. */
    path: string;
    /** The position in the diff where you want to add a review comment. Note this value is not the same as the line number in the file. The `position` value equals the number of lines down from the first "@@" hunk header in the file you want to add a comment. The line just below the "@@" line is position 1, the next line is position 2, and so on. The position in the diff continues to increase through lines of whitespace and additional hunks until the beginning of a new file. */
    position?: number | undefined;
    /** Text of the review comment. */
    body: string;
    line?: number | undefined;
    side?: string | undefined;
    start_line?: number | undefined;
    start_side?: string | undefined;
}
/** Use the following table to specify the location, destination, and contents of the draft review comment. */
export type CreateReviewRequestCommentsList = Array<CreateReviewRequestCommentsItem>;
export interface CreateReviewRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The SHA of the commit that needs a review. Not using the latest commit SHA may render your review comment outdated if a subsequent commit modifies the line you specify as the `position`. Defaults to the most recent commit in the pull request when you do not specify a value. */
    commit_id?: string | undefined;
    /** **Required** when using `REQUEST_CHANGES` or `COMMENT` for the `event` parameter. The body text of the pull request review. */
    body?: string | undefined;
    /** The review action you want to perform. The review actions include: `APPROVE`, `REQUEST_CHANGES`, or `COMMENT`. By leaving this blank, you set the review action state to `PENDING`, which means you will need to [submit the pull request review](https://docs.github.com/rest/pulls/reviews#submit-a-review-for-a-pull-request) when you are ready. */
    event?: CreateReviewRequestEvent | (string & {}) | undefined;
    /** Use the following table to specify the location, destination, and contents of the draft review comment. */
    comments?: CreateReviewRequestCommentsList | undefined;
}
export type PullRequestReviewLinksHtml = Link;
export type PullRequestReviewLinksPullRequest = Link;
export interface PullRequestReviewLinks {
    html: Link;
    pull_request: Link;
}
/** Pull Request Reviews are reviews on pull requests. */
export interface PullRequestReview {
    /** Unique identifier of the review */
    id: number;
    node_id: string;
    user: NullableSimpleUser | null;
    /** The text of the review. */
    body: string;
    state: string;
    /** Whether this review was produced by Copilot code review. Bot authorship alone does not establish provenance. */
    is_copilot_code_review?: boolean | undefined;
    /** The persisted effective effort used to produce this Copilot code review, or null if unavailable. For more information, see [Review effort level](https://docs.github.com/copilot/concepts/agent-capabilities/agent-powered-workflows-and-operations/code-review#review-effort-level). */
    copilot_code_review_effort?: string | null | undefined;
    html_url: string;
    pull_request_url: string;
    _links: PullRequestReviewLinks;
    submitted_at?: string | undefined;
    /** A commit SHA for the review. If the commit object was garbage collected or forcibly deleted, then it no longer exists in Git and this value will be `null`. */
    commit_id: string | null;
    body_html?: string | undefined;
    body_text?: string | undefined;
    author_association: AuthorAssociation;
}
/** In a split diff view, the side of the diff that the pull request's changes appear on. Can be `LEFT` or `RIGHT`. Use `LEFT` for deletions that appear in red. Use `RIGHT` for additions that appear in green or unchanged lines that appear in white and are shown for context. For a multi-line comment, side represents whether the last line of the comment range is a deletion or addition. For more information, see "[Diff view options](https://docs.github.com/articles/about-comparing-branches-in-pull-requests#diff-view-options)" in the GitHub Help documentation. */
export type CreateReviewCommentRequestSide = "LEFT" | "RIGHT";
/** **Required when using multi-line comments unless using `in_reply_to`**. The `start_side` is the starting side of the diff that the comment applies to. Can be `LEFT` or `RIGHT`. To learn more about multi-line comments, see "[Commenting on a pull request](https://docs.github.com/articles/commenting-on-a-pull-request#adding-line-comments-to-a-pull-request)" in the GitHub Help documentation. See `side` in this table for additional context. */
export type CreateReviewCommentRequestStartSide = "LEFT" | "RIGHT" | "side";
/** The level at which the comment is targeted. */
export type CreateReviewCommentRequestSubjectType = "line" | "file";
export interface CreateReviewCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The text of the review comment. */
    body: string;
    /** The SHA of the commit needing a comment. Not using the latest commit SHA may render your comment outdated if a subsequent commit modifies the line you specify as the `position`. */
    commit_id: string;
    /** The relative path to the file that necessitates a comment. */
    path: string;
    /** **This parameter is closing down. Use `line` instead**. The position in the diff where you want to add a review comment. Note this value is not the same as the line number in the file. The position value equals the number of lines down from the first "@@" hunk header in the file you want to add a comment. The line just below the "@@" line is position 1, the next line is position 2, and so on. The position in the diff continues to increase through lines of whitespace and additional hunks until the beginning of a new file. */
    position?: number | undefined;
    /** In a split diff view, the side of the diff that the pull request's changes appear on. Can be `LEFT` or `RIGHT`. Use `LEFT` for deletions that appear in red. Use `RIGHT` for additions that appear in green or unchanged lines that appear in white and are shown for context. For a multi-line comment, side represents whether the last line of the comment range is a deletion or addition. For more information, see "[Diff view options](https://docs.github.com/articles/about-comparing-branches-in-pull-requests#diff-view-options)" in the GitHub Help documentation. */
    side?: CreateReviewCommentRequestSide | (string & {}) | undefined;
    /** **Required unless using `subject_type:file`**. The line of the blob in the pull request diff that the comment applies to. For a multi-line comment, the last line of the range that your comment applies to. */
    line?: number | undefined;
    /** **Required when using multi-line comments unless using `in_reply_to`**. The `start_line` is the first line in the pull request diff that your multi-line comment applies to. To learn more about multi-line comments, see "[Commenting on a pull request](https://docs.github.com/articles/commenting-on-a-pull-request#adding-line-comments-to-a-pull-request)" in the GitHub Help documentation. */
    start_line?: number | undefined;
    /** **Required when using multi-line comments unless using `in_reply_to`**. The `start_side` is the starting side of the diff that the comment applies to. Can be `LEFT` or `RIGHT`. To learn more about multi-line comments, see "[Commenting on a pull request](https://docs.github.com/articles/commenting-on-a-pull-request#adding-line-comments-to-a-pull-request)" in the GitHub Help documentation. See `side` in this table for additional context. */
    start_side?: CreateReviewCommentRequestStartSide | (string & {}) | undefined;
    /** The ID of the review comment to reply to. To find the ID of a review comment with ["List review comments on a pull request"](#list-review-comments-on-a-pull-request). When specified, all parameters other than `body` in the request body are ignored. */
    in_reply_to?: number | undefined;
    /** The level at which the comment is targeted. */
    subject_type?: CreateReviewCommentRequestSubjectType | (string & {}) | undefined;
}
export interface DeletePendingReviewRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The unique identifier of the review. */
    review_id: number;
}
export interface DeleteReviewCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface DeleteReviewCommentResponse {
}
export type DismissReviewRequestEvent = "DISMISS";
export interface DismissReviewRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The unique identifier of the review. */
    review_id: number;
    /** The message for the pull request review dismissal */
    message: string;
    event?: DismissReviewRequestEvent | (string & {}) | undefined;
}
export type GetRequestAccept = "application/vnd.github+json" | "application/vnd.github.diff" | "application/vnd.github.patch";
export interface GetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** A media type that returns text instead of JSON: `application/vnd.github.diff`, `application/vnd.github.patch`. */
    accept?: GetRequestAccept | (string & {}) | undefined;
}
export type GetResponseBody = PullRequest | string;
export type GetResponse = GetResponseBody;
export interface GetMergeAsyncResultRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The UUID of the asynchronous merge request, as returned when the merge was requested. */
    uuid: string;
}
export type PullRequestMergeAsyncResultStatus = "pending" | "merged" | "enqueued" | "failed";
export type PullRequestMergeAsyncResultDetailsCase0MergeMethod = "default" | "merge" | "squash" | "rebase";
export type PullRequestMergeAsyncResultDetailsCase0MergeAction = "default" | "merge_queue" | "direct_merge";
/** When the asynchronous merge request is pending */
export interface PullRequestMergeAsyncResultDetailsCase0 {
    message: string;
    uuid: string;
    merge_method: PullRequestMergeAsyncResultDetailsCase0MergeMethod;
    merge_action: PullRequestMergeAsyncResultDetailsCase0MergeAction;
    /** SHA that the pull request head must match for the enqueued merge to proceed. */
    expected_head_sha: string;
    /** Whether the asynchronous merge request will attempt to bypass repository rules that the authenticated actor is permitted to bypass. */
    bypass_rules?: boolean | undefined;
}
/** When the pull request is in a merge queue */
export interface PullRequestMergeAsyncResultDetailsCase1 {
    message: string;
}
/** When the asynchronous merge request failed */
export type PullRequestMergeAsyncResultDetailsCase2 = PullRequestMergeAsyncResultDetailsCase1;
/** When the pull request has been merged */
export interface PullRequestMergeAsyncResultDetailsCase3 {
    message: string;
    sha: string;
}
export type PullRequestMergeAsyncResultDetails = PullRequestMergeAsyncResultDetailsCase0 | PullRequestMergeAsyncResultDetailsCase1 | PullRequestMergeAsyncResultDetailsCase1 | PullRequestMergeAsyncResultDetailsCase3;
/** Pull Request Merge Async Result */
export interface PullRequestMergeAsyncResult {
    status: PullRequestMergeAsyncResultStatus;
    details: PullRequestMergeAsyncResultDetails;
}
export interface GetPullRequestStackRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request stack. */
    stack_number: number;
}
export type GetPullRequestStackResponseBase = AddPullRequestStackResponseBase;
export type GetPullRequestStackResponsePullRequestsList = Array<PullRequestStackPullRequest>;
export interface GetPullRequestStackResponse {
    id: number;
    number: number;
    node_id: string;
    url: string;
    base: AddPullRequestStackResponseBase;
    /** Whether the stack has any open pull request. False when all pull requests are merged or closed. */
    open: boolean;
    created_at: string;
    pull_requests: GetPullRequestStackResponsePullRequestsList;
}
export interface GetReviewRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The unique identifier of the review. */
    review_id: number;
}
export interface GetReviewCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export type ListRequestState = "open" | "closed" | "all";
export type ListRequestSort = "created" | "updated" | "popularity" | "long-running";
export type ListRequestDirection = "asc" | "desc";
export interface ListRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Either `open`, `closed`, or `all` to filter by state. */
    state?: ListRequestState | (string & {}) | undefined;
    /** Filter pulls by head user or head organization and branch name in the format of `user:ref-name` or `organization:ref-name`. For example: `github:new-script-format` or `octocat:test-branch`. */
    head?: string | undefined;
    /** Filter pulls by base branch name. Example: `gh-pages`. */
    base?: string | undefined;
    /** What to sort results by. `popularity` will sort by the number of comments. `long-running` will sort by date created and will limit the results to pull requests that have been open for more than a month and have had activity within the past month. */
    sort?: ListRequestSort | (string & {}) | undefined;
    /** The direction of the sort. Default: `desc` when sort is `created` or sort is not specified, otherwise `asc`. */
    direction?: ListRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface PullRequestSimpleLabelsItem {
    id: number;
    node_id: string;
    url: string;
    name: string;
    description: string;
    color: string;
    default: boolean;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by: NullableSimpleUser | null;
}
export type PullRequestSimpleLabelsList = Array<PullRequestSimpleLabelsItem>;
export type PullRequestSimpleAssigneesList = Array<NullableSimpleUser>;
export type PullRequestSimpleRequestedReviewersList = Array<NullableSimpleUser>;
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
export type PullRequestSimpleRequestedTeamsList = Array<Team>;
export interface PullRequestSimpleHead {
    label: string;
    ref: string;
    repo: Repository;
    sha: string;
    user: NullableSimpleUser | null;
}
export type PullRequestSimpleBase = PullRequestSimpleHead;
export type PullRequestSimpleLinks = PullRequestLinks;
/** Pull Request Simple */
export interface PullRequestSimple {
    url: string;
    id: number;
    node_id: string;
    html_url: string;
    diff_url: string;
    patch_url: string;
    issue_url: string;
    commits_url: string;
    review_comments_url: string;
    review_comment_url: string;
    comments_url: string;
    statuses_url: string;
    number: number;
    state: string;
    locked: boolean;
    title: string;
    user: NullableSimpleUser | null;
    body: string | null;
    labels: PullRequestSimpleLabelsList;
    milestone: NullableMilestone | null;
    active_lock_reason?: string | null | undefined;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    merged_at: string | null;
    merge_commit_sha: string | null;
    assignee: NullableSimpleUser | null;
    assignees?: PullRequestSimpleAssigneesList | undefined;
    requested_reviewers?: PullRequestSimpleRequestedReviewersList | undefined;
    requested_teams?: PullRequestSimpleRequestedTeamsList | undefined;
    head: PullRequestSimpleHead;
    base: PullRequestSimpleHead;
    _links: PullRequestLinks;
    author_association: AuthorAssociation;
    auto_merge: AutoMerge | null;
    stack?: PullRequestStack | null | undefined;
    /** Indicates whether or not the pull request is a draft. */
    draft?: boolean | undefined;
}
export type ListResponseBodyList = Array<PullRequestSimple>;
export type ListResponse = ListResponseBodyList;
export interface ListCommentsForReviewRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The unique identifier of the review. */
    review_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** The kind of contributing source. */
export type ReviewCommentCopilotCodeReviewSourcesItemKind = "SKILL" | "MCP" | "CUSTOM_INSTRUCTIONS";
export interface ReviewCommentCopilotCodeReviewSourcesItem {
    /** The kind of contributing source. */
    kind: ReviewCommentCopilotCodeReviewSourcesItemKind;
    /** The reported source name, or "custom instructions" for CUSTOM_INSTRUCTIONS. */
    name: string;
    /** The validated repository-relative source path, if available. Commit OIDs are not exposed. */
    path?: string | undefined;
}
/** Sources reported as contributing to this comment; may be incomplete. */
export type ReviewCommentCopilotCodeReviewSourcesList = Array<ReviewCommentCopilotCodeReviewSourcesItem>;
export type ReviewCommentLinks = PullRequestReviewCommentLinks;
/** The side of the first line of the range for a multi-line comment. */
export type ReviewCommentSide = "LEFT" | "RIGHT";
/** The side of the first line of the range for a multi-line comment. */
export type ReviewCommentStartSide = "LEFT" | "RIGHT";
/** The level at which the comment is targeted, can be a diff line or a file. */
export type ReviewCommentSubjectType = "line" | "file";
/** Legacy Review Comment */
export interface ReviewComment {
    /** Whether this comment was produced by Copilot code review. */
    is_copilot_code_review?: boolean | undefined;
    /** Sources reported as contributing to this comment; may be incomplete. */
    copilot_code_review_sources?: ReviewCommentCopilotCodeReviewSourcesList | undefined;
    url: string;
    pull_request_review_id: number | null;
    id: number;
    node_id: string;
    diff_hunk: string;
    path: string;
    position: number | null;
    original_position: number;
    commit_id: string;
    original_commit_id: string;
    in_reply_to_id?: number | undefined;
    user: NullableSimpleUser | null;
    body: string;
    created_at: string;
    updated_at: string;
    html_url: string;
    pull_request_url: string;
    author_association: AuthorAssociation;
    _links: PullRequestReviewCommentLinks;
    body_text?: string | undefined;
    body_html?: string | undefined;
    reactions?: ReactionRollup | undefined;
    /** The side of the first line of the range for a multi-line comment. */
    side?: ReviewCommentSide | undefined;
    /** The side of the first line of the range for a multi-line comment. */
    start_side?: ReviewCommentStartSide | null | undefined;
    /** The line of the blob to which the comment applies. The last line of the range for a multi-line comment */
    line?: number | undefined;
    /** The original line of the blob to which the comment applies. The last line of the range for a multi-line comment */
    original_line?: number | undefined;
    /** The first line of the range for a multi-line comment. */
    start_line?: number | null | undefined;
    /** The original first line of the range for a multi-line comment. */
    original_start_line?: number | null | undefined;
    /** The level at which the comment is targeted, can be a diff line or a file. */
    subject_type?: ReviewCommentSubjectType | undefined;
}
export type ListCommentsForReviewResponseBodyList = Array<ReviewComment>;
export type ListCommentsForReviewResponse = ListCommentsForReviewResponseBodyList;
export interface ListCommitsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Metaproperties for Git author/committer information. */
export interface NullableGitUser {
    name?: string | undefined;
    email?: string | undefined;
    date?: string | undefined;
}
export interface CommitCommitTree {
    sha: string;
    url: string;
}
export interface Verification {
    verified: boolean;
    reason: string;
    payload: string | null;
    signature: string | null;
    verified_at: string | null;
}
export interface CommitCommit {
    url: string;
    author: NullableGitUser | null;
    committer: NullableGitUser | null;
    message: string;
    comment_count: number;
    tree: CommitCommitTree;
    verification?: Verification | undefined;
}
export type CommitAuthor = NullableSimpleUser | unknown;
export type CommitCommitter = NullableSimpleUser | unknown;
export interface CommitParentsItem {
    sha: string;
    url: string;
    html_url?: string | undefined;
}
export type CommitParentsList = Array<CommitParentsItem>;
export interface CommitStats {
    additions?: number | undefined;
    deletions?: number | undefined;
    total?: number | undefined;
}
export type DiffEntryStatus = "added" | "removed" | "modified" | "renamed" | "copied" | "changed" | "unchanged";
/** Diff Entry */
export interface DiffEntry {
    sha: string | null;
    filename: string;
    status: DiffEntryStatus;
    additions: number;
    deletions: number;
    changes: number;
    blob_url: string;
    raw_url: string;
    contents_url: string;
    patch?: string | undefined;
    previous_filename?: string | undefined;
}
export type CommitFilesList = Array<DiffEntry>;
/** Commit */
export interface Commit {
    url: string;
    sha: string;
    node_id: string;
    html_url: string;
    comments_url: string;
    commit: CommitCommit;
    author: CommitAuthor | null;
    committer: CommitCommitter | null;
    parents: CommitParentsList;
    stats?: CommitStats | undefined;
    files?: CommitFilesList | undefined;
}
export type ListCommitsResponseBodyList = Array<Commit>;
export type ListCommitsResponse = ListCommitsResponseBodyList;
export interface ListFilesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListFilesResponseBodyList = Array<DiffEntry>;
export type ListFilesResponse = ListFilesResponseBodyList;
export interface ListPullRequestStacksRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Filter to the stack containing this repository pull request number. */
    pull_request?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type PullRequestStackMinimalBase = AddPullRequestStackResponseBase;
export type PullRequestStackMinimalPullRequestsItemState = "open" | "closed";
export interface PullRequestStackMinimalPullRequestsItemHead {
    ref: string;
    sha: string;
}
export interface PullRequestStackMinimalPullRequestsItem {
    number: number;
    state: PullRequestStackMinimalPullRequestsItemState;
    draft: boolean;
    merged_at: string | null;
    head: PullRequestStackMinimalPullRequestsItemHead;
}
export type PullRequestStackMinimalPullRequestsList = Array<PullRequestStackMinimalPullRequestsItem>;
export interface PullRequestStackMinimal {
    id: number;
    number: number;
    node_id: string;
    url: string;
    base: AddPullRequestStackResponseBase;
    /** Whether the stack has any open pull request. False when all pull requests are merged or closed. */
    open: boolean;
    created_at: string;
    pull_requests: PullRequestStackMinimalPullRequestsList;
}
export type ListPullRequestStacksResponseBodyList = Array<PullRequestStackMinimal>;
export type ListPullRequestStacksResponse = ListPullRequestStacksResponseBodyList;
export interface ListRequestedReviewersRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
}
export type PullRequestReviewRequestUsersList = Array<NullableSimpleUser>;
export type PullRequestReviewRequestTeamsList = Array<Team>;
/** Pull Request Review Request */
export interface PullRequestReviewRequest {
    users: PullRequestReviewRequestUsersList;
    teams: PullRequestReviewRequestTeamsList;
}
export type ListReviewCommentsRequestSort = "created" | "updated";
export type ListReviewCommentsRequestDirection = "asc" | "desc";
export interface ListReviewCommentsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The property to sort the results by. */
    sort?: ListReviewCommentsRequestSort | (string & {}) | undefined;
    /** The direction to sort results. Ignored without `sort` parameter. */
    direction?: ListReviewCommentsRequestDirection | (string & {}) | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReviewCommentsResponseBodyList = Array<PullRequestReviewComment>;
export type ListReviewCommentsResponse = ListReviewCommentsResponseBodyList;
export type ListReviewCommentsForRepoRequestSort = "created" | "updated" | "created_at";
export type ListReviewCommentsForRepoRequestDirection = "asc" | "desc";
export interface ListReviewCommentsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    sort?: ListReviewCommentsForRepoRequestSort | (string & {}) | undefined;
    /** The direction to sort results. Ignored without `sort` parameter. */
    direction?: ListReviewCommentsForRepoRequestDirection | (string & {}) | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReviewCommentsForRepoResponseBodyList = Array<PullRequestReviewComment>;
export type ListReviewCommentsForRepoResponse = ListReviewCommentsForRepoResponseBodyList;
export interface ListReviewsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReviewsResponseBodyList = Array<PullRequestReview>;
export type ListReviewsResponse = ListReviewsResponseBodyList;
/** The merge method to use. */
export type MergeRequestMergeMethod = "merge" | "squash" | "rebase";
export interface MergeRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** Title for the automatic commit message. */
    commit_title?: string | undefined;
    /** Extra detail to append to automatic commit message. */
    commit_message?: string | undefined;
    /** SHA that pull request head must match to allow merge. */
    sha?: string | undefined;
    /** The merge method to use. */
    merge_method?: MergeRequestMergeMethod | (string & {}) | undefined;
}
/** Pull Request Merge Result */
export interface PullRequestMergeResult {
    sha: string;
    merged: boolean;
    message: string;
}
/** The merge method to use for a direct merge. Only supported for direct merges. */
export type MergeAsyncRequestMergeMethod = "merge" | "squash" | "rebase";
/** The action that will be taken to merge the pull request. `direct_merge` merges the pull request directly without using a merge queue; `merge_queue` adds the pull request to a merge queue; `default` uses a merge queue if one is configured for the target branch, or merges directly otherwise. If omitted, defaults to `default`. */
export type MergeAsyncRequestMergeAction = "default" | "direct_merge" | "merge_queue";
export interface MergeAsyncRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** Title for the automatic commit message. Only supported for direct merges. */
    commit_title?: string | undefined;
    /** Extra detail to append to automatic commit message. Only supported for direct merges. */
    commit_message?: string | undefined;
    /** SHA that pull request head must match to allow merge. If not provided, the current head of the PR at the time of the request will be used; if the PR is pushed in between the merge being requested and being executed, the merge will be cancelled. */
    sha?: string | undefined;
    /** The merge method to use for a direct merge. Only supported for direct merges. */
    merge_method?: MergeAsyncRequestMergeMethod | (string & {}) | undefined;
    /** The action that will be taken to merge the pull request. `direct_merge` merges the pull request directly without using a merge queue; `merge_queue` adds the pull request to a merge queue; `default` uses a merge queue if one is configured for the target branch, or merges directly otherwise. If omitted, defaults to `default`. */
    merge_action?: MergeAsyncRequestMergeAction | (string & {}) | undefined;
    /** Whether to bypass repository rules that the authenticated actor is permitted to bypass. */
    bypass_rules?: boolean | undefined;
}
export interface PullRequestStacksUnstackRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request stack. */
    stack_number: number;
}
export type PullRequestStacksUnstackResponseBase = AddPullRequestStackResponseBase;
export type PullRequestStacksUnstackResponsePullRequestsList = Array<PullRequestStackPullRequest>;
export interface PullRequestStacksUnstackResponse {
    id: number;
    number: number;
    node_id: string;
    url: string;
    base: AddPullRequestStackResponseBase;
    /** Whether the stack has any open pull request. False when all pull requests are merged or closed. */
    open: boolean;
    created_at: string;
    pull_requests: PullRequestStacksUnstackResponsePullRequestsList;
}
/** An array of user `login`s that will be removed. */
export type RemoveRequestedReviewersRequestReviewersList = Array<string>;
/** An array of team `slug`s that will be removed. */
export type RemoveRequestedReviewersRequestTeamReviewersList = Array<string>;
export interface RemoveRequestedReviewersRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** An array of user `login`s that will be removed. */
    reviewers: RemoveRequestedReviewersRequestReviewersList;
    /** An array of team `slug`s that will be removed. */
    team_reviewers?: RemoveRequestedReviewersRequestTeamReviewersList | undefined;
}
export interface RequestCopilotCodeReviewRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The effort level to use for the Copilot code review. Omit to use the default effort level. Only effort levels available for the repository and actor are accepted. For more information, see [Review effort level](https://docs.github.com/copilot/concepts/agent-capabilities/agent-powered-workflows-and-operations/code-review#review-effort-level). */
    review_effort?: string | undefined;
}
/** The current state of the review request. */
export type CopilotCodeReviewRequestState = "PENDING";
/** A request for Copilot to review a pull request. */
export interface CopilotCodeReviewRequest {
    /** The global node ID of the review request. */
    node_id: string;
    /** The current state of the review request. */
    state: CopilotCodeReviewRequestState;
}
/** An array of user `login`s that will be requested. */
export type RequestReviewersRequestReviewersList = Array<string>;
/** An array of team `slug`s that will be requested. */
export type RequestReviewersRequestTeamReviewersList = Array<string>;
export interface RequestReviewersRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** An array of user `login`s that will be requested. */
    reviewers?: RequestReviewersRequestReviewersList | undefined;
    /** An array of team `slug`s that will be requested. */
    team_reviewers?: RequestReviewersRequestTeamReviewersList | undefined;
}
/** An array of user `login`s whose reviews will be rerequested. */
export type RerequestReviewersRequestReviewersList = Array<string>;
/** An array of team `slug`s whose reviews will be rerequested. */
export type RerequestReviewersRequestTeamReviewersList = Array<string>;
export interface RerequestReviewersRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** An array of user `login`s whose reviews will be rerequested. */
    reviewers?: RerequestReviewersRequestReviewersList | undefined;
    /** An array of team `slug`s whose reviews will be rerequested. */
    team_reviewers?: RerequestReviewersRequestTeamReviewersList | undefined;
}
/** The review action you want to perform. The review actions include: `APPROVE`, `REQUEST_CHANGES`, or `COMMENT`. When you leave this blank, the API returns _HTTP 422 (Unrecognizable entity)_ and sets the review action state to `PENDING`, which means you will need to re-submit the pull request review using a review action. */
export type SubmitReviewRequestEvent = "APPROVE" | "REQUEST_CHANGES" | "COMMENT";
export interface SubmitReviewRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The unique identifier of the review. */
    review_id: number;
    /** The body text of the pull request review */
    body?: string | undefined;
    /** The review action you want to perform. The review actions include: `APPROVE`, `REQUEST_CHANGES`, or `COMMENT`. When you leave this blank, the API returns _HTTP 422 (Unrecognizable entity)_ and sets the review action state to `PENDING`, which means you will need to re-submit the pull request review using a review action. */
    event: SubmitReviewRequestEvent | (string & {});
}
/** State of this Pull Request. Either `open` or `closed`. */
export type UpdateRequestState = "open" | "closed";
export interface UpdateRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The title of the pull request. */
    title?: string | undefined;
    /** The contents of the pull request. */
    body?: string | undefined;
    /** State of this Pull Request. Either `open` or `closed`. */
    state?: UpdateRequestState | (string & {}) | undefined;
    /** The name of the branch you want your changes pulled into. This should be an existing branch on the current repository. You cannot update the base branch on a pull request to point to another repository. */
    base?: string | undefined;
    /** Indicates whether [maintainers can modify](https://docs.github.com/articles/allowing-changes-to-a-pull-request-branch-created-from-a-fork/) the pull request. */
    maintainer_can_modify?: boolean | undefined;
}
export interface UpdateBranchRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The expected SHA of the pull request's HEAD ref. This is the most recent commit on the pull request's branch. If the expected SHA does not match the pull request's HEAD, you will receive a `422 Unprocessable Entity` status. You can use the "[List commits](https://docs.github.com/rest/commits/commits#list-commits)" endpoint to find the most recent commit SHA. Default: SHA of the pull request's current HEAD ref. */
    expected_head_sha?: string | undefined;
}
export interface UpdateBranchResponse {
}
export interface UpdateReviewRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The unique identifier of the review. */
    review_id: number;
    /** The body text of the pull request review. */
    body: string;
}
export interface UpdateReviewCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The text of the reply to the review comment. */
    body: string;
}
export type AddPullRequestStackError = GithubOpError;
/** Add pull requests to a pull request stack Appends an ordered list of pull request numbers onto the top of an existing stack. Provide only the pull requests you want to add, from the current top of the stack upward. The first new pull request's base ref must match the current top pull request's head ref. */
export declare const addPullRequestStack: API.OperationMethod<AddPullRequestStackRequest, AddPullRequestStackResponse, AddPullRequestStackError, GithubOpContext>;
export type CheckIfMergedError = GithubOpError;
/** Check if a pull request has been merged Checks if a pull request has been merged into the base branch. The HTTP status of the response indicates whether or not the pull request has been merged; the response body is empty. */
export declare const checkIfMerged: API.OperationMethod<CheckIfMergedRequest, CheckIfMergedResponse, CheckIfMergedError, GithubOpContext>;
export type CreateError = GithubOpError;
/** Create a pull request Draft pull requests are available in public repositories with GitHub Free and GitHub Free for organizations, GitHub Pro, and legacy per-repository billing plans, and in public and private repositories with GitHub Team and GitHub Enterprise Cloud. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. To open or update a pull request in a public repository, you must have write access to the head or the source branch. For organization-owned repositories, you must be a member of the organization that owns the repository to open or update a pull request. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const create: API.OperationMethod<CreateRequest, PullRequest, CreateError, GithubOpContext>;
export type CreatePullRequestStackError = GithubOpError;
/** Create a pull request stack Creates a stack from an ordered list of pull request numbers. Provide the pull request numbers from the bottom of the stack to the top. Each pull request's base ref must match the previous pull request's head ref. */
export declare const createPullRequestStack: API.OperationMethod<CreatePullRequestStackRequest, CreatePullRequestStackResponse, CreatePullRequestStackError, GithubOpContext>;
export type CreateReplyForReviewCommentError = GithubOpError;
/** Create a reply for a review comment Creates a reply to a review comment for a pull request. For the `comment_id`, provide the ID of the review comment you are replying to. This must be the ID of a _top-level review comment_, not a reply to that comment. Replies to replies are not supported. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const createReplyForReviewComment: API.OperationMethod<CreateReplyForReviewCommentRequest, PullRequestReviewComment, CreateReplyForReviewCommentError, GithubOpContext>;
export type CreateReviewError = GithubOpError;
/** Create a review for a pull request Creates a review on a specified pull request. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." Pull request reviews created in the `PENDING` state are not submitted and therefore do not include the `submitted_at` property in the response. To create a pending review for a pull request, leave the `event` parameter blank. For more information about submitting a `PENDING` review, see "[Submit a review for a pull request](https://docs.github.com/rest/pulls/reviews#submit-a-review-for-a-pull-request)." > [!NOTE] > To comment on a specific line in a file, you need to first determine the position of that line in the diff. To see a pull request diff, add the `application/vnd.github.v3.diff` media type to the `Accept` header of a call to the [Get a pull request](https://docs.github.com/rest/pulls/pulls#get-a-pull-request) endpoint. The `position` value equals the number of lines down from the first "@@" hunk header in the file you want to add a comment. The line just below the "@@" line is position 1, the next line is position 2, and so on. The position in the diff continues to increase through lines of whitespace and additional hunks until the beginning of a new file. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const createReview: API.OperationMethod<CreateReviewRequest, PullRequestReview, CreateReviewError, GithubOpContext>;
export type CreateReviewCommentError = GithubOpError;
/** Create a review comment for a pull request Creates a review comment on the diff of a specified pull request. To add a regular comment to a pull request timeline, see "[Create an issue comment](https://docs.github.com/rest/issues/comments#create-an-issue-comment)." If your comment applies to more than one line in the pull request diff, you should use the parameters `line`, `side`, and optionally `start_line` and `start_side` in your request. The `position` parameter is closing down. If you use `position`, the `line`, `side`, `start_line`, and `start_side` parameters are not required. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const createReviewComment: API.OperationMethod<CreateReviewCommentRequest, PullRequestReviewComment, CreateReviewCommentError, GithubOpContext>;
export type DeletePendingReviewError = GithubOpError;
/** Delete a pending review for a pull request Deletes a pull request review that has not been submitted. Submitted reviews cannot be deleted. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const deletePendingReview: API.OperationMethod<DeletePendingReviewRequest, PullRequestReview, DeletePendingReviewError, GithubOpContext>;
export type DeleteReviewCommentError = GithubOpError;
/** Delete a review comment for a pull request Deletes a review comment. */
export declare const deleteReviewComment: API.OperationMethod<DeleteReviewCommentRequest, DeleteReviewCommentResponse, DeleteReviewCommentError, GithubOpContext>;
export type DismissReviewError = GithubOpError;
/** Dismiss a review for a pull request Dismisses a specified review on a pull request. > [!NOTE] > To dismiss a pull request review on a [protected branch](https://docs.github.com/rest/branches/branch-protection), you must be a repository administrator or be included in the list of people or teams who can dismiss pull request reviews. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const dismissReview: API.OperationMethod<DismissReviewRequest, PullRequestReview, DismissReviewError, GithubOpContext>;
export type GetError = GithubOpError;
/** Get a pull request Draft pull requests are available in public repositories with GitHub Free and GitHub Free for organizations, GitHub Pro, and legacy per-repository billing plans, and in public and private repositories with GitHub Team and GitHub Enterprise Cloud. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Lists details of a pull request by providing its number. When you get, [create](https://docs.github.com/rest/pulls/pulls/#create-a-pull-request), or [edit](https://docs.github.com/rest/pulls/pulls#update-a-pull-request) a pull request, GitHub creates a merge commit to test whether the pull request can be automatically merged into the base branch. This test commit is not added to the base branch or the head branch. You can review the status of the test commit using the `mergeable` key. For more information, see "[Checking mergeability of pull requests](https://docs.github.com/rest/guides/getting-started-with-the-git-database-api#checking-mergeability-of-pull-requests)". The value of the `mergeable` attribute can be `true`, `false`, or `null`. If the value is `null`, then GitHub has started a background job to compute the mergeability. After giving the job time to complete, resubmit the request. When the job finishes, you will see a non-`null` value for the `mergeable` attribute in the response. If `mergeable` is `true`, then `merge_commit_sha` will be the SHA of the _test_ merge commit. The value of the `merge_commit_sha` attribute changes depending on the state of the pull request. Before merging a pull request, the `merge_commit_sha` attribute holds the SHA of the _test_ merge commit. After merging a pull request, the `merge_commit_sha` attribute changes depending on how you merged the pull request: * If merged as a [merge commit](https://docs.github.com/articles/about-merge-methods-on-github/), `merge_commit_sha` represents the SHA of the merge commit. * If merged via a [squash](https://docs.github.com/articles/about-merge-methods-on-github/#squashing-your-merge-commits), `merge_commit_sha` represents the SHA of the squashed commit on the base branch. * If [rebased](https://docs.github.com/articles/about-merge-methods-on-github/#rebasing-and-merging-your-commits), `merge_commit_sha` represents the commit that the base branch was updated to. Pass the appropriate [media type](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types) to fetch diff and patch formats. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. - **`application/vnd.github.diff`**: For more information, see "[git-diff](https://git-scm.com/docs/git-diff)" in the Git documentation. If a diff is corrupt, contact us through the [GitHub Support portal](https://support.github.com/). Include the repository name and pull request ID in your message. */
export declare const get: API.OperationMethod<GetRequest & {
    readonly accept?: "application/vnd.github+json" | undefined;
}, PullRequest, GetError, GithubOpContext> & API.OperationMethod<GetRequest & {
    readonly accept: "application/vnd.github.diff" | "application/vnd.github.patch";
}, string, GetError, GithubOpContext>;
export type GetMergeAsyncResultError = GithubOpError;
/** Get the result of an asynchronous merge Fetches the current result of an asynchronous merge request, identified by the UUID that was returned when the merge was requested. While the request's status is `pending`, the response includes the UUID, merge method, merge action, and expected head SHA of the request. Once the asynchronous request completes, its status is one of: - `merged`: The pull request was merged into the base branch. The response includes the merge commit OID. - `enqueued`: The pull request was added to a merge queue. - `failed`: The request failed. The response includes a message describing the failure. An `enqueued` result is final for the merge queue requests and does not mean the pull request has merged. This result does not change when the merge queue later merges the pull request. To get the eventual merge status, [check if a pull request has been merged](https://docs.github.com/rest/pulls/pulls#check-if-a-pull-request-has-been-merged). The result of an asynchronous merge request is retained for 24 hours after its most recent update. After this window the request expires and this endpoint returns a `404` response for its UUID. */
export declare const getMergeAsyncResult: API.OperationMethod<GetMergeAsyncResultRequest, PullRequestMergeAsyncResult, GetMergeAsyncResultError, GithubOpContext>;
export type GetPullRequestStackError = GithubOpError;
/** Get a pull request stack Gets a pull request stack by providing its stack number. */
export declare const getPullRequestStack: API.OperationMethod<GetPullRequestStackRequest, GetPullRequestStackResponse, GetPullRequestStackError, GithubOpContext>;
export type GetReviewError = GithubOpError;
/** Get a review for a pull request Retrieves a pull request review by its ID. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const getReview: API.OperationMethod<GetReviewRequest, PullRequestReview, GetReviewError, GithubOpContext>;
export type GetReviewCommentError = GithubOpError;
/** Get a review comment for a pull request Provides details for a specified review comment. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const getReviewComment: API.OperationMethod<GetReviewCommentRequest, PullRequestReviewComment, GetReviewCommentError, GithubOpContext>;
export type ListError = GithubOpError;
/** List pull requests Lists pull requests in a specified repository. Draft pull requests are available in public repositories with GitHub Free and GitHub Free for organizations, GitHub Pro, and legacy per-repository billing plans, and in public and private repositories with GitHub Team and GitHub Enterprise Cloud. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const list: API.PaginatedOperationMethod<ListRequest, ListResponse, ListError, GithubOpContext, PullRequestSimple>;
export type ListCommentsForReviewError = GithubOpError;
/** List comments for a pull request review Lists comments for a specific pull request review. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listCommentsForReview: API.PaginatedOperationMethod<ListCommentsForReviewRequest, ListCommentsForReviewResponse, ListCommentsForReviewError, GithubOpContext, ReviewComment>;
export type ListCommitsError = GithubOpError;
/** List commits on a pull request Lists a maximum of 250 commits for a pull request. To receive a complete commit list for pull requests with more than 250 commits, use the [List commits](https://docs.github.com/rest/commits/commits#list-commits) endpoint. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listCommits: API.PaginatedOperationMethod<ListCommitsRequest, ListCommitsResponse, ListCommitsError, GithubOpContext, Commit>;
export type ListFilesError = GithubOpError;
/** List pull requests files Lists the files in a specified pull request. > [!NOTE] > Responses include a maximum of 3000 files. The paginated response returns 30 files per page by default. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listFiles: API.PaginatedOperationMethod<ListFilesRequest, ListFilesResponse, ListFilesError, GithubOpContext, DiffEntry>;
export type ListPullRequestStacksError = GithubOpError;
/** List pull request stacks Lists pull request stacks in a repository. */
export declare const listPullRequestStacks: API.PaginatedOperationMethod<ListPullRequestStacksRequest, ListPullRequestStacksResponse, ListPullRequestStacksError, GithubOpContext, PullRequestStackMinimal>;
export type ListRequestedReviewersError = GithubOpError;
/** Get all requested reviewers for a pull request Gets the users or teams whose review is requested for a pull request. Once a requested reviewer submits a review, they are no longer considered a requested reviewer. Their review will instead be returned by the [List reviews for a pull request](https://docs.github.com/rest/pulls/reviews#list-reviews-for-a-pull-request) operation. */
export declare const listRequestedReviewers: API.OperationMethod<ListRequestedReviewersRequest, PullRequestReviewRequest, ListRequestedReviewersError, GithubOpContext>;
export type ListReviewCommentsError = GithubOpError;
/** List review comments on a pull request Lists all review comments for a specified pull request. By default, review comments are in ascending order by ID. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listReviewComments: API.PaginatedOperationMethod<ListReviewCommentsRequest, ListReviewCommentsResponse, ListReviewCommentsError, GithubOpContext, PullRequestReviewComment>;
export type ListReviewCommentsForRepoError = GithubOpError;
/** List review comments in a repository Lists review comments for all pull requests in a repository. By default, review comments are in ascending order by ID. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listReviewCommentsForRepo: API.PaginatedOperationMethod<ListReviewCommentsForRepoRequest, ListReviewCommentsForRepoResponse, ListReviewCommentsForRepoError, GithubOpContext, PullRequestReviewComment>;
export type ListReviewsError = GithubOpError;
/** List reviews for a pull request Lists all reviews for a specified pull request. The list of reviews returns in chronological order. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listReviews: API.PaginatedOperationMethod<ListReviewsRequest, ListReviewsResponse, ListReviewsError, GithubOpContext, PullRequestReview>;
export type MergeError = GithubOpError;
/** Merge a pull request > [!NOTE] > We recommend using the [asynchronous merge API](https://docs.github.com/rest/pulls/pulls#merge-a-pull-request-asynchronously) instead. This endpoint does not support stacked pull requests or merging with a merge queue. Merges a pull request into the base branch. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." */
export declare const merge: API.OperationMethod<MergeRequest, PullRequestMergeResult, MergeError, GithubOpContext>;
export type MergeAsyncError = GithubOpError;
/** Merge a pull request asynchronously Merges a pull request into the base branch in the background or adds it to a merge queue. Background processing allows certain types of errors to be retried and reduces the risk of timeouts for complex merges. This is the required API for merging stacked pull requests. For a stacked pull request, the operation includes all open downstack pull requests. A new asynchronous merge request returns a `202` response with a UUID that can be used to [fetch the result of the merge](https://docs.github.com/rest/pulls/pulls#get-the-result-of-an-asynchronous-merge). If another asynchronous merge request is already pending for this pull request, a `409` response returns that request's UUID and merge options instead. If the pull request is already merged or already in a merge queue, a `200` response is returned immediately. A `merged` result includes the merge commit OID. An `enqueued` result means the pull request was added to the merge queue, not that it has merged. If the pull request cannot be merged (e.g. because it is closed, or still a draft) this result will be returned immediately with a `400` response status. Branch protection rules and repository rules are not run at this stage, only basic pull request state checks are performed. */
export declare const mergeAsync: API.OperationMethod<MergeAsyncRequest, PullRequestMergeAsyncResult, MergeAsyncError, GithubOpContext>;
export type PullRequestStacksUnstackError = GithubOpError;
/** Remove pull requests from a pull request stack Removes the unmerged pull requests from a stack. Pull requests that cannot be unstacked (for example, those that are queued for merge) are left in place. When pull requests remain in the stack, the updated stack is returned with a `200`. When no pull requests remain, the stack is dissolved and a `204` is returned. */
export declare const pullRequestStacksUnstack: API.OperationMethod<PullRequestStacksUnstackRequest, PullRequestStacksUnstackResponse, PullRequestStacksUnstackError, GithubOpContext>;
export type RemoveRequestedReviewersError = GithubOpError;
/** Remove requested reviewers from a pull request Removes review requests from a pull request for a given set of users and/or teams. */
export declare const removeRequestedReviewers: API.OperationMethod<RemoveRequestedReviewersRequest, PullRequestSimple, RemoveRequestedReviewersError, GithubOpContext>;
export type RequestCopilotCodeReviewError = GithubOpError;
/** Request a Copilot code review for a pull request Requests a Copilot code review for a pull request. Every call expresses intent to start a new review: if no Copilot review has been requested yet, an initial request is created; if the most recent Copilot review has already completed (including if it was later dismissed or superseded), a new request is created automatically to continue the review lifecycle. If a Copilot code review request is already pending for the pull request, no new request is created and the response is `409`. If the actor or repository is not eligible for Copilot code review, the actor has no quota remaining, or the licensing organization is unavailable, no request is created and the response is `422` with a stable `failure_reason`. A `review_effort` is accepted only when that effort level is available for the repository and actor; an unrecognized or unavailable `review_effort` returns `422` with `failure_reason` `INVALID_REVIEW_EFFORT`. If the actor, repository owner, or requesting application owner has been flagged, the response is `403` with `failure_reason` `ACTOR_FLAGGED`. If the per-actor or per-owner request rate limit is exceeded, the response is `429` with `failure_reason` `RATE_LIMITED`. If Copilot code review cannot be serviced right now, the response is `503`. Existing human and team review requests on the pull request are left unchanged. */
export declare const requestCopilotCodeReview: API.OperationMethod<RequestCopilotCodeReviewRequest, CopilotCodeReviewRequest, RequestCopilotCodeReviewError, GithubOpContext>;
export type RequestReviewersError = GithubOpError;
/** Request reviewers for a pull request Requests reviews for a pull request from a given set of users and/or teams. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." */
export declare const requestReviewers: API.OperationMethod<RequestReviewersRequest, PullRequestSimple, RequestReviewersError, GithubOpContext>;
export type RerequestReviewersError = GithubOpError;
/** Rerequest reviewers for a pull request Rerequests reviews for a pull request from a given set of users and/or teams. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." */
export declare const rerequestReviewers: API.OperationMethod<RerequestReviewersRequest, PullRequestSimple, RerequestReviewersError, GithubOpContext>;
export type SubmitReviewError = GithubOpError;
/** Submit a review for a pull request Submits a pending review for a pull request. For more information about creating a pending review for a pull request, see "[Create a review for a pull request](https://docs.github.com/rest/pulls/reviews#create-a-review-for-a-pull-request)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const submitReview: API.OperationMethod<SubmitReviewRequest, PullRequestReview, SubmitReviewError, GithubOpContext>;
export type UpdateError = GithubOpError;
/** Update a pull request Draft pull requests are available in public repositories with GitHub Free and GitHub Free for organizations, GitHub Pro, and legacy per-repository billing plans, and in public and private repositories with GitHub Team and GitHub Enterprise Cloud. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. To open or update a pull request in a public repository, you must have write access to the head or the source branch. For organization-owned repositories, you must be a member of the organization that owns the repository to open or update a pull request. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const update: API.OperationMethod<UpdateRequest, PullRequest, UpdateError, GithubOpContext>;
export type UpdateBranchError = GithubOpError;
/** Update a pull request branch Updates the pull request branch with the latest upstream changes by merging HEAD from the base branch into the pull request branch. Note: If making a request on behalf of a GitHub App you must also have permissions to write the contents of the head repository. */
export declare const updateBranch: API.OperationMethod<UpdateBranchRequest, UpdateBranchResponse, UpdateBranchError, GithubOpContext>;
export type UpdateReviewError = GithubOpError;
/** Update a review for a pull request Updates the contents of a specified review summary comment. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const updateReview: API.OperationMethod<UpdateReviewRequest, PullRequestReview, UpdateReviewError, GithubOpContext>;
export type UpdateReviewCommentError = GithubOpError;
/** Update a review comment for a pull request Edits the content of a specified review comment. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const updateReviewComment: API.OperationMethod<UpdateReviewCommentRequest, PullRequestReviewComment, UpdateReviewCommentError, GithubOpContext>;
//# sourceMappingURL=pulls.d.ts.map