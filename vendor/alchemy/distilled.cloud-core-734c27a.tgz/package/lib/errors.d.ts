/**
 * Common error types shared across SDKs.
 *
 * Each SDK defines its own provider-specific errors (e.g., Unauthorized, NotFound)
 * using the category system. This module provides base error types and utilities
 * that are used across all SDKs.
 */
import * as Duration from "effect/Duration";
import * as Category from "./category.ts";
import * as Schema from "./schema-lite-typed.ts";
/**
 * Opaque schema for an Effect `Duration.Duration` value.
 *
 * Used on retryable errors to carry a server-provided wait hint (e.g. parsed
 * from `Retry-After` or the IETF `Ratelimit` header). Core does not encode/decode
 * this field over the wire -- it is constructed at runtime by `matchError` from
 * whatever the service actually returns (delay-seconds, HTTP-date, epoch, etc.)
 * and consumed at runtime by the retry policy.
 */
export declare const DurationSchema: import("effect/Schema").declare<Duration.Duration, Duration.Duration>;
/**
 * Fields every error built from an HTTP response declares: the parsed body
 * (the raw text when it wasn't JSON) and the response headers, for whatever
 * the SDK does not type -- a request ID, nested details.
 */
export declare const ResponseErrorFields: {
    body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
};
declare const Unauthorized_base: Schema.TaggedErrorClass<"Unauthorized", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/**
 * Unauthorized - Authentication failure (401).
 */
export declare class Unauthorized extends /*@__PURE__*/ Unauthorized_base {
}
declare const Forbidden_base: Schema.TaggedErrorClass<"Forbidden", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/**
 * Forbidden - Access denied (403).
 */
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const NotFound_base: Schema.TaggedErrorClass<"NotFound", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
/**
 * NotFound - Resource not found (404).
 */
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const BadRequest_base: Schema.TaggedErrorClass<"BadRequest", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/**
 * BadRequest - Invalid request (400).
 */
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const Conflict_base: Schema.TaggedErrorClass<"Conflict", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
/**
 * Conflict - Resource conflict (409).
 */
export declare class Conflict extends /*@__PURE__*/ Conflict_base {
}
declare const UnprocessableEntity_base: Schema.TaggedErrorClass<"UnprocessableEntity", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/**
 * UnprocessableEntity - Validation error (422).
 */
export declare class UnprocessableEntity extends /*@__PURE__*/ UnprocessableEntity_base {
}
declare const TooManyRequests_base: Schema.TaggedErrorClass<"TooManyRequests", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
    readonly retryAfter: import("effect/Schema").optional<import("effect/Schema").declare<Duration.Duration, Duration.Duration>>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/retryable": Category.RetryableInfo;
});
/**
 * TooManyRequests - Rate limited (429).
 */
export declare class TooManyRequests extends /*@__PURE__*/ TooManyRequests_base {
}
declare const Locked_base: Schema.TaggedErrorClass<"Locked", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
    readonly retryAfter: import("effect/Schema").optional<import("effect/Schema").declare<Duration.Duration, Duration.Duration>>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        LockedError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/retryable": Category.RetryableInfo;
});
/**
 * Locked - Resource locked (423).
 */
export declare class Locked extends /*@__PURE__*/ Locked_base {
}
declare const InternalServerError_base: Schema.TaggedErrorClass<"InternalServerError", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
    readonly code: import("effect/Schema").optional<import("effect/Schema").Number>;
    readonly retryAfter: import("effect/Schema").optional<import("effect/Schema").declare<Duration.Duration, Duration.Duration>>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/retryable": Category.RetryableInfo;
});
/**
 * InternalServerError - Server error.
 *
 * Mapped from HTTP 500 by default. Per-service patches may also pin it to a
 * specific in-band error code/message combination (e.g. Cloudflare returns a
 * 200 envelope carrying `{ code: 10002, message: "An unknown error has
 * occurred" }` for transient backend failures on some endpoints).
 */
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const BadGateway_base: Schema.TaggedErrorClass<"BadGateway", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
    readonly retryAfter: import("effect/Schema").optional<import("effect/Schema").declare<Duration.Duration, Duration.Duration>>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/retryable": Category.RetryableInfo;
});
/**
 * BadGateway - Bad gateway (502).
 */
export declare class BadGateway extends /*@__PURE__*/ BadGateway_base {
}
declare const ServiceUnavailable_base: Schema.TaggedErrorClass<"ServiceUnavailable", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
    readonly retryAfter: import("effect/Schema").optional<import("effect/Schema").declare<Duration.Duration, Duration.Duration>>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/retryable": Category.RetryableInfo;
});
/**
 * ServiceUnavailable - Service unavailable (503).
 */
export declare class ServiceUnavailable extends /*@__PURE__*/ ServiceUnavailable_base {
}
declare const GatewayTimeout_base: Schema.TaggedErrorClass<"GatewayTimeout", {
    readonly body: import("effect/Schema").optional<import("effect/Schema").Unknown>;
    readonly headers: import("effect/Schema").optional<Schema.$Record<import("effect/Schema").String, import("effect/Schema").String>>;
    readonly message: import("effect/Schema").String;
    readonly retryAfter: import("effect/Schema").optional<import("effect/Schema").declare<Duration.Duration, Duration.Duration>>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/retryable": Category.RetryableInfo;
});
/**
 * GatewayTimeout - HTTP request or gateway timeout (408, 504).
 */
export declare class GatewayTimeout extends /*@__PURE__*/ GatewayTimeout_base {
}
export { ConfigError } from "./config.ts";
export { InvalidInput } from "./protocol-http.ts";
export { SdkError } from "./sdk-error.ts";
export { UnknownErrorFields, type UnknownErrorProps } from "./unknown-error.ts";
/**
 * Mapping from HTTP status codes to common error classes.
 */
export declare const HTTP_STATUS_MAP: {
    readonly 400: typeof BadRequest;
    readonly 401: typeof Unauthorized;
    readonly 403: typeof Forbidden;
    readonly 404: typeof NotFound;
    readonly 408: typeof GatewayTimeout;
    readonly 409: typeof Conflict;
    readonly 422: typeof UnprocessableEntity;
    readonly 423: typeof Locked;
    readonly 429: typeof TooManyRequests;
    readonly 500: typeof InternalServerError;
    readonly 502: typeof BadGateway;
    readonly 503: typeof ServiceUnavailable;
    readonly 504: typeof GatewayTimeout;
};
/**
 * HTTP status codes that are considered "default" errors (always present).
 * These are excluded from per-operation error types since they're handled globally.
 */
export declare const DEFAULT_ERROR_STATUSES: Set<number>;
/**
 * HTTP status codes whose corresponding error class in {@link HTTP_STATUS_MAP}
 * declares a `retryAfter` field. The retry policy waits at least
 * `error.retryAfter` for these.
 *
 * `matchError` implementations should only pass `retryAfter` into the
 * constructor when the status is in this set; passing it on non-retryable
 * classes (BadRequest/Unauthorized/etc.) would silently retain it as a
 * stale field on the instance and pollute serialized output.
 */
export declare const RETRYABLE_HTTP_STATUSES: Set<number>;
/**
 * All common API error classes.
 */
export declare const API_ERRORS: readonly [typeof Unauthorized, typeof Forbidden, typeof NotFound, typeof BadRequest, typeof Conflict, typeof UnprocessableEntity, typeof TooManyRequests, typeof Locked, typeof InternalServerError, typeof BadGateway, typeof ServiceUnavailable, typeof GatewayTimeout];
/**
 * Default errors that apply to ALL operations.
 * These are infrastructure-level errors that can occur regardless of the operation.
 */
export declare const DEFAULT_ERRORS: readonly [typeof Unauthorized, typeof TooManyRequests, typeof InternalServerError, typeof BadGateway, typeof ServiceUnavailable, typeof GatewayTimeout];
export type DefaultErrors = InstanceType<(typeof DEFAULT_ERRORS)[number]>;
export declare const RETRYABLE: "@distilled/errors/retryable";
//# sourceMappingURL=errors.d.ts.map