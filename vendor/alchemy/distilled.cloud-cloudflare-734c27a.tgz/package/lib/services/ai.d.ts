import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AccountNotFound_base: S.TaggedErrorClass<"AccountNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class AccountNotFound extends /*@__PURE__*/ AccountNotFound_base {
}
declare const InputTooBig_base: S.TaggedErrorClass<"InputTooBig", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InputTooBig extends /*@__PURE__*/ InputTooBig_base {
}
declare const ModelNotFound_base: S.TaggedErrorClass<"ModelNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ModelNotFound extends /*@__PURE__*/ ModelNotFound_base {
}
declare const ModelNotSupported_base: S.TaggedErrorClass<"ModelNotSupported", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ModelNotSupported extends /*@__PURE__*/ ModelNotSupported_base {
}
declare const ModelSchemaNotFound_base: S.TaggedErrorClass<"ModelSchemaNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ModelSchemaNotFound extends /*@__PURE__*/ ModelSchemaNotFound_base {
}
export interface CreateFinetuneRequest {
    accountId: string;
    model: string;
    name: string;
    description?: string | undefined;
    public?: boolean | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateFinetuneResponse {
    id: string;
    createdAt: string;
    model: string;
    modifiedAt: string;
    name: string;
    public: boolean;
    description?: string | null | undefined;
}
export interface CreateFinetuneAssetRequest {
    accountId: string;
    finetuneId: string;
    /** File to upload. */
    file: unknown;
    /** Name of the file (adapter_config.json or adapter_model.safetensors). */
    fileName: string;
}
export interface CreateFinetuneAssetResponse {
}
export interface GetModelSchemaRequest {
    /** Cloudflare account ID used for this AI model request. */
    accountId: string;
    /** AI model identifier, including its namespace and model name. */
    model: string;
}
export interface ModelsSchemaGetResponseInput {
    additionalProperties: boolean;
    description: string;
    type: string;
}
export type ModelsSchemaGetResponseOutput = ModelsSchemaGetResponseInput;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetModelSchemaResponse {
    input: ModelsSchemaGetResponseInput;
    output: ModelsSchemaGetResponseInput;
}
export interface ListAuthorsRequest {
    accountId: string;
}
export type AuthorsListResultList = Array<unknown>;
export interface ListAuthorsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AuthorsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListFinetunePublicsRequest {
    accountId: string;
    /** Pagination Limit. */
    limit?: number | undefined;
    /** Pagination Offset. */
    offset?: number | undefined;
    /** Order By Column Name. */
    orderBy?: string | undefined;
}
export interface FinetunesPublicListResultItem {
    id: string;
    createdAt: string;
    model: string;
    modifiedAt: string;
    name: string;
    public: boolean;
    description?: string | null | undefined;
}
export type FinetunesPublicListResultList = Array<FinetunesPublicListResultItem>;
export interface ListFinetunePublicsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: FinetunesPublicListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListFinetunesRequest {
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListFinetunesResponse {
    id: string;
    createdAt: string;
    model: string;
    modifiedAt: string;
    name: string;
    description?: string | null | undefined;
}
export type ModelsListRequestFormat = "openrouter";
export interface ListModelsRequest {
    accountId: string;
    /** Filter by Author. */
    author?: string | undefined;
    /** If set, return models in the requested marketplace format instead of the default response. */
    format?: ModelsListRequestFormat | (string & {}) | undefined;
    /** Filter to hide experimental models. */
    hideExperimental?: boolean | undefined;
    /** If true, include models for up to three months after their deprecation date. Defaults to false. */
    includeDeprecated?: boolean | undefined;
    page?: number | undefined;
    perPage?: number | undefined;
    /** Search. */
    search?: string | undefined;
    /** Filter by Source Id. */
    source?: number | undefined;
    /** Filter by Task Name. */
    task?: string | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListModelsResponse {
}
export interface ListTasksRequest {
    accountId: string;
}
export type TasksListResultList = Array<unknown>;
export interface ListTasksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TasksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type RunRequestTextTextEmbeddingsCase1List = Array<string>;
export type RunRequestTextTextEmbeddings = string | RunRequestTextTextEmbeddingsCase1List;
export type RunRequestTextMultimodalEmbeddingsList = Array<string>;
export type RunRequestText = string | RunRequestTextTextEmbeddings | RunRequestTextMultimodalEmbeddingsList;
export type RunRequestImageTextToImageList = Array<number>;
export type RunRequestImage = string | RunRequestImageTextToImageList;
export type RunRequestMaskList = Array<number>;
export type RunRequestAudioList = Array<number>;
export type RunRequestResponseFormatType = "json_object" | "json_schema";
export interface RunRequestResponseFormat {
    jsonSchema?: unknown | undefined;
    type?: RunRequestResponseFormatType | (string & {}) | undefined;
}
export interface RunRequestMessagesTextGenerationItemContentCase1Item {
    /** Text content */
    text?: string | undefined;
    /** Type of the content (text) */
    type?: string | undefined;
}
export type RunRequestMessagesTextGenerationItemContentCase1List = Array<RunRequestMessagesTextGenerationItemContentCase1Item>;
export type RunRequestMessagesTextGenerationItemContent = string | RunRequestMessagesTextGenerationItemContentCase1List;
export interface RunRequestMessagesTextGenerationItem {
    /** The content of the message as a string. */
    content: RunRequestMessagesTextGenerationItemContent;
    /** The role of the message sender (e.g., 'user', 'assistant', 'system', 'tool'). */
    role: string;
}
export type RunRequestMessagesTextGenerationList = Array<RunRequestMessagesTextGenerationItem>;
export interface RunRequestMessagesImageTextToTextItemContentCase1ItemImageUrl {
    /** Image URI with data (e.g. data:image/jpeg;base64,/9j/...). */
    url: string;
}
export interface RunRequestMessagesImageTextToTextItemContentCase1Item {
    /** Type of the content part (e.g. 'text', 'image_url'). */
    type: string;
    /** Image URL object (when type is 'image_url'). */
    imageUrl?: RunRequestMessagesImageTextToTextItemContentCase1ItemImageUrl | undefined;
    /** Text content (when type is 'text'). */
    text?: string | undefined;
}
export type RunRequestMessagesImageTextToTextItemContentCase1List = Array<RunRequestMessagesImageTextToTextItemContentCase1Item>;
export type RunRequestMessagesImageTextToTextItemContent = string | RunRequestMessagesImageTextToTextItemContentCase1List;
export interface RunRequestMessagesImageTextToTextItem {
    /** The content of the message as a string. */
    content: RunRequestMessagesImageTextToTextItemContent;
    /** The role of the message sender (e.g., 'user', 'assistant', 'system', 'tool'). */
    role: string;
}
export type RunRequestMessagesImageTextToTextList = Array<RunRequestMessagesImageTextToTextItem>;
export type RunRequestMessages = RunRequestMessagesTextGenerationList | RunRequestMessagesImageTextToTextList;
export interface RunRequestFunctionsItem {
    code: string;
    name: string;
}
export type RunRequestFunctionsList = Array<RunRequestFunctionsItem>;
export interface RunRequestToolsItemCase0ParametersPropertiesValue {
    /** A description of the expected parameter. */
    description: string;
    /** The data type of the parameter. */
    type: string;
}
export type RunRequestToolsItemCase0ParametersPropertiesMap = {
    [key: string]: RunRequestToolsItemCase0ParametersPropertiesValue | undefined;
};
export type RunRequestToolsItemCase0ParametersRequiredList = Array<string>;
export interface RunRequestToolsItemCase0Parameters {
    /** Definitions of each parameter. */
    properties: RunRequestToolsItemCase0ParametersPropertiesMap;
    /** The type of the parameters object (usually 'object'). */
    type: string;
    /** List of required parameter names. */
    required?: RunRequestToolsItemCase0ParametersRequiredList | undefined;
}
export interface RunRequestToolsItemCase0 {
    /** A brief description of what the tool does. */
    description: string;
    /** The name of the tool. More descriptive the better. */
    name: string;
    /** Schema defining the parameters accepted by the tool. */
    parameters: RunRequestToolsItemCase0Parameters;
}
export type RunRequestToolsItemFunctionFunctionParametersPropertiesValue = RunRequestToolsItemCase0ParametersPropertiesValue;
export type RunRequestToolsItemFunctionFunctionParametersPropertiesMap = {
    [key: string]: RunRequestToolsItemCase0ParametersPropertiesValue | undefined;
};
export type RunRequestToolsItemFunctionFunctionParametersRequiredList = Array<string>;
export interface RunRequestToolsItemFunctionFunctionParameters {
    /** Definitions of each parameter. */
    properties: RunRequestToolsItemFunctionFunctionParametersPropertiesMap;
    /** The type of the parameters object (usually 'object'). */
    type: string;
    /** List of required parameter names. */
    required?: RunRequestToolsItemFunctionFunctionParametersRequiredList | undefined;
}
export interface RunRequestToolsItemFunctionFunction {
    /** A brief description of what the function does. */
    description: string;
    /** The name of the function. */
    name: string;
    /** Schema defining the parameters accepted by the function. */
    parameters: RunRequestToolsItemFunctionFunctionParameters;
}
export interface RunRequestToolsItemFunction {
    /** Details of the function tool. */
    function: RunRequestToolsItemFunctionFunction;
    /** Specifies the type of tool (e.g., 'function'). */
    type: string;
}
export type RunRequestToolsItem = RunRequestToolsItemCase0 | RunRequestToolsItemFunction;
export type RunRequestToolsList = Array<RunRequestToolsItem>;
export interface RunAiRequest {
    /** Cloudflare account ID used for this AI model request. */
    accountId: string;
    /** Workers AI model identifier, including its namespace and model name. */
    modelName: string;
    /** The text that you want to classify */
    text?: RunRequestText | undefined;
    /** A text description of the image you want to generate */
    prompt?: string | undefined;
    /** Controls how closely the generated image should adhere to the prompt; higher values make the image more aligned with the prompt */
    guidance?: number | undefined;
    /** The height of the generated image in pixels */
    height?: number | undefined;
    /** For use with img2img tasks. An array of integers that represent the image data constrained to 8-bit unsigned integer values */
    image?: RunRequestImage | undefined;
    /** For use with img2img tasks. A base64-encoded string of the input image */
    imageB64?: string | undefined;
    /** An array representing An array of integers that represent mask image data for inpainting constrained to 8-bit unsigned integer values */
    mask?: RunRequestMaskList | undefined;
    /** Text describing elements to avoid in the generated image */
    negativePrompt?: string | undefined;
    /** The number of diffusion steps; higher values can improve quality but take longer */
    numSteps?: number | undefined;
    /** Random seed for reproducibility of the image generation */
    seed?: number | undefined;
    /** A value between 0 and 1 indicating how strongly to apply the transformation during img2img tasks; lower values make the output closer to the input image */
    strength?: number | undefined;
    /** The width of the generated image in pixels */
    width?: number | undefined;
    /** The speech language (e.g., 'en' for English, 'fr' for French). Defaults to 'en' if not specified */
    lang?: string | undefined;
    /** An array of integers that represent the audio data constrained to 8-bit unsigned integer values */
    audio?: RunRequestAudioList | undefined;
    /** The language of the recorded audio */
    sourceLang?: string | undefined;
    /** The language to translate the transcription into. Currently only English is supported. */
    targetLang?: string | undefined;
    /** Decreases the likelihood of the model repeating the same lines verbatim. */
    frequencyPenalty?: number | undefined;
    /** Name of the LoRA (Low-Rank Adaptation) model to fine-tune the base model. */
    lora?: string | undefined;
    /** The maximum number of tokens to generate in the response. */
    maxTokens?: number | undefined;
    /** Increases the likelihood of the model introducing new topics. */
    presencePenalty?: number | undefined;
    /** If true, a chat template is not applied and you must adhere to the specific model's expected formatting. */
    raw?: boolean | undefined;
    /** Penalty for repeated tokens; higher values discourage repetition. */
    repetitionPenalty?: number | undefined;
    responseFormat?: RunRequestResponseFormat | undefined;
    /** If true, the response will be streamed back incrementally using SSE, Server Sent Events. */
    stream?: boolean | undefined;
    /** Controls the randomness of the output; higher values produce more random results. */
    temperature?: number | undefined;
    /** Limits the AI to choose from the top 'k' most probable words. Lower values make responses more focused; higher values introduce more variety and potential surprises. */
    topK?: number | undefined;
    /** Adjusts the creativity of the AI's responses by controlling how many possible words it considers. Lower values make outputs more predictable; higher values allow for more varied and creative responses. */
    topP?: number | undefined;
    /** An array of message objects representing the conversation history. */
    messages?: RunRequestMessages | undefined;
    functions?: RunRequestFunctionsList | undefined;
    /** A list of tools available for the assistant to use. */
    tools?: RunRequestToolsList | undefined;
    /** The text that you want the model to summarize */
    inputText?: string | undefined;
    /** The maximum length of the generated summary in tokens */
    maxLength?: number | undefined;
    /** Whether to ignore the EOS token and continue generating tokens after the EOS token is generated. */
    ignoreEos?: boolean | undefined;
}
export interface RunResultTextClassificationItem {
    /** The classification label assigned to the text (e.g., 'POSITIVE' or 'NEGATIVE') */
    label?: string | null | undefined;
    /** Confidence score indicating the likelihood that the text belongs to the specified label */
    score?: number | null | undefined;
}
export type RunResultTextClassificationList = Array<RunResultTextClassificationItem>;
export interface RunResultAudio {
    /** The generated audio in MP3 format, base64-encoded */
    audio?: string | null | undefined;
}
export type RunResultTextEmbeddingsDataItemList = Array<number>;
export type RunResultTextEmbeddingsDataList = Array<RunResultTextEmbeddingsDataItemList>;
export type RunResultTextEmbeddingsShapeList = Array<number>;
export interface RunResultTextEmbeddings {
    /** Embeddings of the requested text values */
    data?: RunResultTextEmbeddingsDataList | null | undefined;
    shape?: RunResultTextEmbeddingsShapeList | null | undefined;
}
export interface RunResultAutomaticSpeechRecognitionWordsItem {
    /** The ending second when the word completes */
    end?: number | null | undefined;
    /** The second this word begins in the recording */
    start?: number | null | undefined;
    word?: string | null | undefined;
}
export type RunResultAutomaticSpeechRecognitionWordsList = Array<RunResultAutomaticSpeechRecognitionWordsItem>;
export interface RunResultAutomaticSpeechRecognition {
    /** The transcription */
    text: string;
    vtt?: string | null | undefined;
    wordCount?: number | null | undefined;
    words?: RunResultAutomaticSpeechRecognitionWordsList | null | undefined;
}
export interface RunResultImageClassificationItem {
    /** The predicted category or class for the input image based on analysis */
    label?: string | null | undefined;
    /** A confidence value, between 0 and 1, indicating how certain the model is about the predicted label */
    score?: number | null | undefined;
}
export type RunResultImageClassificationList = Array<RunResultImageClassificationItem>;
export interface RunResultObjectDetectionItemBox {
    /** The x-coordinate of the bottom-right corner of the bounding box */
    xmax?: number | null | undefined;
    /** The x-coordinate of the top-left corner of the bounding box */
    xmin?: number | null | undefined;
    /** The y-coordinate of the bottom-right corner of the bounding box */
    ymax?: number | null | undefined;
    /** The y-coordinate of the top-left corner of the bounding box */
    ymin?: number | null | undefined;
}
export interface RunResultObjectDetectionItem {
    /** Coordinates defining the bounding box around the detected object */
    box?: RunResultObjectDetectionItemBox | null | undefined;
    /** The class label or name of the detected object */
    label?: string | null | undefined;
    /** Confidence score indicating the likelihood that the detection is correct */
    score?: number | null | undefined;
}
export type RunResultObjectDetectionList = Array<RunResultObjectDetectionItem>;
export interface RunResultCase8ToolCallsItem {
    /** The arguments passed to be passed to the tool call request */
    arguments?: unknown | null | undefined;
    /** The name of the tool to be called */
    name?: string | null | undefined;
}
export type RunResultCase8ToolCallsList = Array<RunResultCase8ToolCallsItem>;
export interface RunResultCase8Usage {
    /** Total number of tokens in output */
    completionTokens?: number | null | undefined;
    /** Total number of tokens in input */
    promptTokens?: number | null | undefined;
    /** Total number of input and output tokens */
    totalTokens?: number | null | undefined;
}
export interface RunResultCase8 {
    /** The generated text response from the model */
    response: string;
    /** An array of tool calls requests made during the response generation */
    toolCalls?: RunResultCase8ToolCallsList | null | undefined;
    /** Usage statistics for the inference request */
    usage?: RunResultCase8Usage | null | undefined;
}
export interface RunResultTranslation {
    /** The translated text in the target language */
    translatedText?: string | null | undefined;
}
export interface RunResultSummarization {
    /** The summarized version of the input text */
    summary?: string | null | undefined;
}
export interface RunResultImageToText {
    description?: string | null | undefined;
}
export type RunResultImageTextToText = RunResultImageToText;
export type RunResultMultimodalEmbeddingsDataItemList = Array<number>;
export type RunResultMultimodalEmbeddingsDataList = Array<RunResultMultimodalEmbeddingsDataItemList>;
export type RunResultMultimodalEmbeddingsShapeList = Array<number>;
export interface RunResultMultimodalEmbeddings {
    data?: RunResultMultimodalEmbeddingsDataList | null | undefined;
    shape?: RunResultMultimodalEmbeddingsShapeList | null | undefined;
}
export type RunResult = string | RunResultTextClassificationList | RunResultAudio | RunResultTextEmbeddings | RunResultAutomaticSpeechRecognition | RunResultImageClassificationList | RunResultObjectDetectionList | RunResultCase8 | RunResultTranslation | RunResultSummarization | RunResultImageToText | RunResultImageToText | RunResultMultimodalEmbeddings;
export type RunAiResponse = RunResult;
export interface SupportedToMarkdownRequest {
    /** Cloudflare account ID used for this AI model request. */
    accountId: string;
}
export interface ToMarkdownSupportedResultItem {
    extension: string;
    mimeType: string;
}
export type ToMarkdownSupportedResultList = Array<ToMarkdownSupportedResultItem>;
export interface SupportedToMarkdownResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ToMarkdownSupportedResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type ToMarkdownTransformRequestFileFilesList = Array<string>;
export interface ToMarkdownTransformRequestFile {
    /** Files to convert, supplied as multipart file uploads. */
    files: ToMarkdownTransformRequestFileFilesList;
}
export interface TransformToMarkdownRequest {
    /** Cloudflare account ID used for this AI model request. */
    accountId: string;
    file: ToMarkdownTransformRequestFile;
}
export interface ToMarkdownTransformResultItem {
    data: string;
    format: string;
    mimeType: string;
    name: string;
    tokens: string;
}
export type ToMarkdownTransformResultList = Array<ToMarkdownTransformResultItem>;
export type TransformToMarkdownResponse = ToMarkdownTransformResultList;
export type CreateFinetuneError = ModelNotSupported | AccountNotFound | CloudflareOpError;
/** Creates a new fine-tuning job for a Workers AI model using custom training data. */
export declare const createFinetune: API.OperationMethod<CreateFinetuneRequest, CreateFinetuneResponse, CreateFinetuneError, CloudflareOpContext>;
export type CreateFinetuneAssetError = ModelNotSupported | AccountNotFound | CloudflareOpError;
/** Uploads training data assets for a Workers AI fine-tuning job. */
export declare const createFinetuneAsset: API.OperationMethod<CreateFinetuneAssetRequest, CreateFinetuneAssetResponse, CreateFinetuneAssetError, CloudflareOpContext>;
export type GetModelSchemaError = ModelNotSupported | ModelSchemaNotFound | AccountNotFound | CloudflareOpError;
/** Retrieves the input and output JSON Schema definitions for an AI model. Use these definitions to determine the model-specific request fields and response format. */
export declare const getModelSchema: API.OperationMethod<GetModelSchemaRequest, GetModelSchemaResponse, GetModelSchemaError, CloudflareOpContext>;
export type ListAuthorsError = CloudflareOpError;
/** Searches Workers AI models by author or organization name. */
export declare const listAuthors: API.PaginatedOperationMethod<ListAuthorsRequest, ListAuthorsResponse, ListAuthorsError, CloudflareOpContext, unknown>;
export type ListFinetunePublicsError = CloudflareOpError;
/** Lists publicly available fine-tuned models that can be used with Workers AI. */
export declare const listFinetunePublics: API.PaginatedOperationMethod<ListFinetunePublicsRequest, ListFinetunePublicsResponse, ListFinetunePublicsError, CloudflareOpContext, FinetunesPublicListResultItem>;
export type ListFinetunesError = AccountNotFound | CloudflareOpError;
/** Lists all fine-tuning jobs created by the account, including status and metrics. */
export declare const listFinetunes: API.OperationMethod<ListFinetunesRequest, ListFinetunesResponse, ListFinetunesError, CloudflareOpContext>;
export type ListModelsError = CloudflareOpError;
/** Searches Workers AI models by name or description. */
export declare const listModels: API.OperationMethod<ListModelsRequest, ListModelsResponse, ListModelsError, CloudflareOpContext>;
export type ListTasksError = CloudflareOpError;
/** Searches Workers AI models by task type (e.g., text-generation, embeddings). */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksRequest, ListTasksResponse, ListTasksError, CloudflareOpContext, unknown>;
export type RunAiError = ModelNotFound | InputTooBig | CloudflareOpError;
/** Runs the Workers AI model specified in the URL path. Send the model's inputs directly in the request body, without a model/input/options wrapper. Accepts model-specific JSON or binary input. The response format depends on the model and the requested output. See the [model catalog](https://developers.cloudflare.com/workers-ai/models/) for supported models and their input formats. */
export declare const runAi: API.OperationMethod<RunAiRequest, RunAiResponse, RunAiError, CloudflareOpContext>;
export type SupportedToMarkdownError = CloudflareOpError;
/** Lists the file extensions and MIME types accepted by Workers AI's Markdown conversion endpoint. Use this list to check whether a file can be converted before uploading it. */
export declare const supportedToMarkdown: API.PaginatedOperationMethod<SupportedToMarkdownRequest, SupportedToMarkdownResponse, SupportedToMarkdownError, CloudflareOpContext, ToMarkdownSupportedResultItem>;
export type TransformToMarkdownError = CloudflareOpError;
/** Converts files uploaded as multipart form data into Markdown using Workers AI. Returns a conversion result for each file. Use the supported-formats endpoint to check accepted file types. */
export declare const transformToMarkdown: API.OperationMethod<TransformToMarkdownRequest, TransformToMarkdownResponse, TransformToMarkdownError, CloudflareOpContext>;
export declare const createAiToMarkdown: API.OperationMethod<TransformToMarkdownRequest, ToMarkdownTransformResultList, CloudflareOpError, CloudflareOpContext>;
export type CreateAiToMarkdownRequest = TransformToMarkdownRequest;
export type CreateAiToMarkdownResponse = TransformToMarkdownResponse;
export type CreateAiToMarkdownError = TransformToMarkdownError;
//# sourceMappingURL=ai.d.ts.map