import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type PipeName = string;
export type PipeDescription = string | redacted.Redacted<string>;
export type RequestedPipeState = string;
export type ArnOrUrl = string;
export type EventPattern = string | redacted.Redacted<string>;
export interface Filter {
    Pattern?: string | redacted.Redacted<string> | undefined;
}
export type FilterList = Filter[];
export interface FilterCriteria {
    Filters?: Filter[] | undefined;
}
export type LimitMax10000 = number;
export type Arn = string;
export interface DeadLetterConfig {
    Arn?: string | undefined;
}
export type OnPartialBatchItemFailureStreams = string;
export type MaximumBatchingWindowInSeconds = number;
export type MaximumRecordAgeInSeconds = number;
export type MaximumRetryAttemptsESM = number;
export type LimitMax10 = number;
export type KinesisStreamStartPosition = string;
export interface PipeSourceKinesisStreamParameters {
    BatchSize?: number | undefined;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    OnPartialBatchItemFailure?: string | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    MaximumRecordAgeInSeconds?: number | undefined;
    MaximumRetryAttempts?: number | undefined;
    ParallelizationFactor?: number | undefined;
    StartingPosition: string;
    StartingPositionTimestamp?: Date | undefined;
}
export type DynamoDBStreamStartPosition = string;
export interface PipeSourceDynamoDBStreamParameters {
    BatchSize?: number | undefined;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    OnPartialBatchItemFailure?: string | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    MaximumRecordAgeInSeconds?: number | undefined;
    MaximumRetryAttempts?: number | undefined;
    ParallelizationFactor?: number | undefined;
    StartingPosition: string;
}
export interface PipeSourceSqsQueueParameters {
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
}
export type SecretManagerArn = string;
export type MQBrokerAccessCredentials = {
    BasicAuth: string;
};
export type MQBrokerQueueName = string | redacted.Redacted<string>;
export interface PipeSourceActiveMQBrokerParameters {
    Credentials: MQBrokerAccessCredentials;
    QueueName: string | redacted.Redacted<string>;
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
}
export type URI = string | redacted.Redacted<string>;
export interface PipeSourceRabbitMQBrokerParameters {
    Credentials: MQBrokerAccessCredentials;
    QueueName: string | redacted.Redacted<string>;
    VirtualHost?: string | redacted.Redacted<string> | undefined;
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
}
export type KafkaTopicName = string | redacted.Redacted<string>;
export type MSKStartPosition = string;
export type MSKAccessCredentials = {
    SaslScram512Auth: string;
    ClientCertificateTlsAuth?: undefined;
} | {
    SaslScram512Auth?: undefined;
    ClientCertificateTlsAuth: string;
};
export interface PipeSourceManagedStreamingKafkaParameters {
    TopicName: string | redacted.Redacted<string>;
    StartingPosition?: string | undefined;
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    ConsumerGroupID?: string | redacted.Redacted<string> | undefined;
    Credentials?: MSKAccessCredentials | undefined;
}
export type SelfManagedKafkaStartPosition = string;
export type EndpointString = string | redacted.Redacted<string>;
export type KafkaBootstrapServers = (string | redacted.Redacted<string>)[];
export type SelfManagedKafkaAccessConfigurationCredentials = {
    BasicAuth: string;
    SaslScram512Auth?: undefined;
    SaslScram256Auth?: undefined;
    ClientCertificateTlsAuth?: undefined;
} | {
    BasicAuth?: undefined;
    SaslScram512Auth: string;
    SaslScram256Auth?: undefined;
    ClientCertificateTlsAuth?: undefined;
} | {
    BasicAuth?: undefined;
    SaslScram512Auth?: undefined;
    SaslScram256Auth: string;
    ClientCertificateTlsAuth?: undefined;
} | {
    BasicAuth?: undefined;
    SaslScram512Auth?: undefined;
    SaslScram256Auth?: undefined;
    ClientCertificateTlsAuth: string;
};
export type SubnetId = string | redacted.Redacted<string>;
export type SubnetIds = (string | redacted.Redacted<string>)[];
export type SecurityGroupId = string | redacted.Redacted<string>;
export type SecurityGroupIds = (string | redacted.Redacted<string>)[];
export interface SelfManagedKafkaAccessConfigurationVpc {
    Subnets?: (string | redacted.Redacted<string>)[] | undefined;
    SecurityGroup?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface PipeSourceSelfManagedKafkaParameters {
    TopicName: string | redacted.Redacted<string>;
    StartingPosition?: string | undefined;
    AdditionalBootstrapServers?: (string | redacted.Redacted<string>)[] | undefined;
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    ConsumerGroupID?: string | redacted.Redacted<string> | undefined;
    Credentials?: SelfManagedKafkaAccessConfigurationCredentials | undefined;
    ServerRootCaCertificate?: string | undefined;
    Vpc?: SelfManagedKafkaAccessConfigurationVpc | undefined;
}
export interface PipeSourceParameters {
    FilterCriteria?: FilterCriteria | undefined;
    KinesisStreamParameters?: PipeSourceKinesisStreamParameters | undefined;
    DynamoDBStreamParameters?: PipeSourceDynamoDBStreamParameters | undefined;
    SqsQueueParameters?: PipeSourceSqsQueueParameters | undefined;
    ActiveMQBrokerParameters?: PipeSourceActiveMQBrokerParameters | undefined;
    RabbitMQBrokerParameters?: PipeSourceRabbitMQBrokerParameters | undefined;
    ManagedStreamingKafkaParameters?: PipeSourceManagedStreamingKafkaParameters | undefined;
    SelfManagedKafkaParameters?: PipeSourceSelfManagedKafkaParameters | undefined;
}
export type OptionalArn = string;
export type InputTemplate = string | redacted.Redacted<string>;
export type PathParameter = string | redacted.Redacted<string>;
export type PathParameterList = (string | redacted.Redacted<string>)[];
export type HeaderKey = string;
export type HeaderValue = string | redacted.Redacted<string>;
export type HeaderParametersMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type QueryStringKey = string;
export type QueryStringValue = string | redacted.Redacted<string>;
export type QueryStringParametersMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface PipeEnrichmentHttpParameters {
    PathParameterValues?: (string | redacted.Redacted<string>)[] | undefined;
    HeaderParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    QueryStringParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export interface PipeEnrichmentParameters {
    InputTemplate?: string | redacted.Redacted<string> | undefined;
    HttpParameters?: PipeEnrichmentHttpParameters | undefined;
}
export type PipeTargetInvocationType = string;
export interface PipeTargetLambdaFunctionParameters {
    InvocationType?: string | undefined;
}
export interface PipeTargetStateMachineParameters {
    InvocationType?: string | undefined;
}
export type KinesisPartitionKey = string | redacted.Redacted<string>;
export interface PipeTargetKinesisStreamParameters {
    PartitionKey: string | redacted.Redacted<string>;
}
export type ArnOrJsonPath = string;
export type LimitMin1 = number;
export type LaunchType = string;
export type Subnet = string | redacted.Redacted<string>;
export type Subnets = (string | redacted.Redacted<string>)[];
export type SecurityGroup = string | redacted.Redacted<string>;
export type SecurityGroups = (string | redacted.Redacted<string>)[];
export type AssignPublicIp = string;
export interface AwsVpcConfiguration {
    Subnets: (string | redacted.Redacted<string>)[];
    SecurityGroups?: (string | redacted.Redacted<string>)[] | undefined;
    AssignPublicIp?: string | undefined;
}
export interface NetworkConfiguration {
    awsvpcConfiguration?: AwsVpcConfiguration | undefined;
}
export type CapacityProvider = string | redacted.Redacted<string>;
export type CapacityProviderStrategyItemWeight = number;
export type CapacityProviderStrategyItemBase = number;
export interface CapacityProviderStrategyItem {
    capacityProvider: string | redacted.Redacted<string>;
    weight?: number | undefined;
    base?: number | undefined;
}
export type CapacityProviderStrategy = CapacityProviderStrategyItem[];
export type PlacementConstraintType = string;
export type PlacementConstraintExpression = string | redacted.Redacted<string>;
export interface PlacementConstraint {
    type?: string | undefined;
    expression?: string | redacted.Redacted<string> | undefined;
}
export type PlacementConstraints = PlacementConstraint[];
export type PlacementStrategyType = string;
export type PlacementStrategyField = string | redacted.Redacted<string>;
export interface PlacementStrategy {
    type?: string | undefined;
    field?: string | redacted.Redacted<string> | undefined;
}
export type PlacementStrategies = PlacementStrategy[];
export type PropagateTags = string;
export type ReferenceId = string | redacted.Redacted<string>;
export type StringList = string[];
export interface EcsEnvironmentVariable {
    name?: string | undefined;
    value?: string | undefined;
}
export type EcsEnvironmentVariableList = EcsEnvironmentVariable[];
export type EcsEnvironmentFileType = string;
export interface EcsEnvironmentFile {
    type: string;
    value: string;
}
export type EcsEnvironmentFileList = EcsEnvironmentFile[];
export type EcsResourceRequirementType = string;
export interface EcsResourceRequirement {
    type: string;
    value: string;
}
export type EcsResourceRequirementsList = EcsResourceRequirement[];
export interface EcsContainerOverride {
    Command?: string[] | undefined;
    Cpu?: number | undefined;
    Environment?: EcsEnvironmentVariable[] | undefined;
    EnvironmentFiles?: EcsEnvironmentFile[] | undefined;
    Memory?: number | undefined;
    MemoryReservation?: number | undefined;
    Name?: string | undefined;
    ResourceRequirements?: EcsResourceRequirement[] | undefined;
}
export type EcsContainerOverrideList = EcsContainerOverride[];
export type EphemeralStorageSize = number;
export interface EcsEphemeralStorage {
    sizeInGiB: number;
}
export interface EcsInferenceAcceleratorOverride {
    deviceName?: string | undefined;
    deviceType?: string | undefined;
}
export type EcsInferenceAcceleratorOverrideList = EcsInferenceAcceleratorOverride[];
export interface EcsTaskOverride {
    ContainerOverrides?: EcsContainerOverride[] | undefined;
    Cpu?: string | undefined;
    EphemeralStorage?: EcsEphemeralStorage | undefined;
    ExecutionRoleArn?: string | undefined;
    InferenceAcceleratorOverrides?: EcsInferenceAcceleratorOverride[] | undefined;
    Memory?: string | undefined;
    TaskRoleArn?: string | undefined;
}
export type TagKey = string;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string;
    Value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export interface PipeTargetEcsTaskParameters {
    TaskDefinitionArn: string;
    TaskCount?: number | undefined;
    LaunchType?: string | undefined;
    NetworkConfiguration?: NetworkConfiguration | undefined;
    PlatformVersion?: string | undefined;
    Group?: string | undefined;
    CapacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    EnableECSManagedTags?: boolean | undefined;
    EnableExecuteCommand?: boolean | undefined;
    PlacementConstraints?: PlacementConstraint[] | undefined;
    PlacementStrategy?: PlacementStrategy[] | undefined;
    PropagateTags?: string | undefined;
    ReferenceId?: string | redacted.Redacted<string> | undefined;
    Overrides?: EcsTaskOverride | undefined;
    Tags?: Tag[] | undefined;
}
export type BatchArraySize = number;
export interface BatchArrayProperties {
    Size?: number | undefined;
}
export type BatchRetryAttempts = number;
export interface BatchRetryStrategy {
    Attempts?: number | undefined;
}
export interface BatchEnvironmentVariable {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type BatchEnvironmentVariableList = BatchEnvironmentVariable[];
export type BatchResourceRequirementType = string;
export interface BatchResourceRequirement {
    Type: string;
    Value: string;
}
export type BatchResourceRequirementsList = BatchResourceRequirement[];
export interface BatchContainerOverrides {
    Command?: string[] | undefined;
    Environment?: BatchEnvironmentVariable[] | undefined;
    InstanceType?: string | undefined;
    ResourceRequirements?: BatchResourceRequirement[] | undefined;
}
export type BatchJobDependencyType = string;
export interface BatchJobDependency {
    JobId?: string | undefined;
    Type?: string | undefined;
}
export type BatchDependsOn = BatchJobDependency[];
export type BatchParametersMap = {
    [key: string]: string | undefined;
};
export interface PipeTargetBatchJobParameters {
    JobDefinition: string;
    JobName: string;
    ArrayProperties?: BatchArrayProperties | undefined;
    RetryStrategy?: BatchRetryStrategy | undefined;
    ContainerOverrides?: BatchContainerOverrides | undefined;
    DependsOn?: BatchJobDependency[] | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MessageGroupId = string | redacted.Redacted<string>;
export type MessageDeduplicationId = string | redacted.Redacted<string>;
export interface PipeTargetSqsQueueParameters {
    MessageGroupId?: string | redacted.Redacted<string> | undefined;
    MessageDeduplicationId?: string | redacted.Redacted<string> | undefined;
}
export interface PipeTargetHttpParameters {
    PathParameterValues?: (string | redacted.Redacted<string>)[] | undefined;
    HeaderParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    QueryStringParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export type SecretManagerArnOrJsonPath = string;
export type Database = string | redacted.Redacted<string>;
export type DbUser = string | redacted.Redacted<string>;
export type StatementName = string | redacted.Redacted<string>;
export type Sql = string | redacted.Redacted<string>;
export type Sqls = (string | redacted.Redacted<string>)[];
export interface PipeTargetRedshiftDataParameters {
    SecretManagerArn?: string | undefined;
    Database: string | redacted.Redacted<string>;
    DbUser?: string | redacted.Redacted<string> | undefined;
    StatementName?: string | redacted.Redacted<string> | undefined;
    WithEvent?: boolean | undefined;
    Sqls: (string | redacted.Redacted<string>)[];
}
export type SageMakerPipelineParameterName = string | redacted.Redacted<string>;
export type SageMakerPipelineParameterValue = string | redacted.Redacted<string>;
export interface SageMakerPipelineParameter {
    Name: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type SageMakerPipelineParameterList = SageMakerPipelineParameter[];
export interface PipeTargetSageMakerPipelineParameters {
    PipelineParameterList?: SageMakerPipelineParameter[] | undefined;
}
export type EventBridgeEndpointId = string | redacted.Redacted<string>;
export type EventBridgeDetailType = string | redacted.Redacted<string>;
export type EventBridgeEventSource = string | redacted.Redacted<string>;
export type EventBridgeEventResourceList = string[];
export type JsonPath = string;
export interface PipeTargetEventBridgeEventBusParameters {
    EndpointId?: string | redacted.Redacted<string> | undefined;
    DetailType?: string | redacted.Redacted<string> | undefined;
    Source?: string | redacted.Redacted<string> | undefined;
    Resources?: string[] | undefined;
    Time?: string | undefined;
}
export type LogStreamName = string;
export interface PipeTargetCloudWatchLogsParameters {
    LogStreamName?: string | undefined;
    Timestamp?: string | undefined;
}
export type TimeValue = string;
export type EpochTimeUnit = string;
export type TimeFieldType = string;
export type TimestampFormat = string;
export type VersionValue = string;
export type DimensionValue = string;
export type DimensionValueType = string;
export type DimensionName = string;
export interface DimensionMapping {
    DimensionValue: string;
    DimensionValueType: string;
    DimensionName: string;
}
export type DimensionMappings = DimensionMapping[];
export type MeasureValue = string;
export type MeasureValueType = string;
export type MeasureName = string;
export interface SingleMeasureMapping {
    MeasureValue: string;
    MeasureValueType: string;
    MeasureName: string;
}
export type SingleMeasureMappings = SingleMeasureMapping[];
export type MultiMeasureName = string;
export type MultiMeasureAttributeName = string;
export interface MultiMeasureAttributeMapping {
    MeasureValue: string;
    MeasureValueType: string;
    MultiMeasureAttributeName: string;
}
export type MultiMeasureAttributeMappings = MultiMeasureAttributeMapping[];
export interface MultiMeasureMapping {
    MultiMeasureName: string;
    MultiMeasureAttributeMappings: MultiMeasureAttributeMapping[];
}
export type MultiMeasureMappings = MultiMeasureMapping[];
export interface PipeTargetTimestreamParameters {
    TimeValue: string;
    EpochTimeUnit?: string | undefined;
    TimeFieldType?: string | undefined;
    TimestampFormat?: string | undefined;
    VersionValue: string;
    DimensionMappings: DimensionMapping[];
    SingleMeasureMappings?: SingleMeasureMapping[] | undefined;
    MultiMeasureMappings?: MultiMeasureMapping[] | undefined;
}
export interface PipeTargetParameters {
    InputTemplate?: string | redacted.Redacted<string> | undefined;
    LambdaFunctionParameters?: PipeTargetLambdaFunctionParameters | undefined;
    StepFunctionStateMachineParameters?: PipeTargetStateMachineParameters | undefined;
    KinesisStreamParameters?: PipeTargetKinesisStreamParameters | undefined;
    EcsTaskParameters?: PipeTargetEcsTaskParameters | undefined;
    BatchJobParameters?: PipeTargetBatchJobParameters | undefined;
    SqsQueueParameters?: PipeTargetSqsQueueParameters | undefined;
    HttpParameters?: PipeTargetHttpParameters | undefined;
    RedshiftDataParameters?: PipeTargetRedshiftDataParameters | undefined;
    SageMakerPipelineParameters?: PipeTargetSageMakerPipelineParameters | undefined;
    EventBridgeEventBusParameters?: PipeTargetEventBridgeEventBusParameters | undefined;
    CloudWatchLogsParameters?: PipeTargetCloudWatchLogsParameters | undefined;
    TimestreamParameters?: PipeTargetTimestreamParameters | undefined;
}
export type RoleArn = string;
export type TagMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type S3OutputFormat = string;
export interface S3LogDestinationParameters {
    BucketName: string;
    BucketOwner: string;
    OutputFormat?: string | undefined;
    Prefix?: string | undefined;
}
export type FirehoseArn = string;
export interface FirehoseLogDestinationParameters {
    DeliveryStreamArn: string;
}
export type CloudwatchLogGroupArn = string;
export interface CloudwatchLogsLogDestinationParameters {
    LogGroupArn: string;
}
export type LogLevel = string;
export type IncludeExecutionDataOption = string;
export type IncludeExecutionData = string[];
export interface PipeLogConfigurationParameters {
    S3LogDestination?: S3LogDestinationParameters | undefined;
    FirehoseLogDestination?: FirehoseLogDestinationParameters | undefined;
    CloudwatchLogsLogDestination?: CloudwatchLogsLogDestinationParameters | undefined;
    Level: string;
    IncludeExecutionData?: string[] | undefined;
}
export type KmsKeyIdentifier = string;
export interface CreatePipeRequest {
    Name: string;
    Description?: string | redacted.Redacted<string> | undefined;
    DesiredState?: string | undefined;
    Source: string;
    SourceParameters?: PipeSourceParameters | undefined;
    Enrichment?: string | undefined;
    EnrichmentParameters?: PipeEnrichmentParameters | undefined;
    Target: string;
    TargetParameters?: PipeTargetParameters | undefined;
    RoleArn: string;
    Tags?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    LogConfiguration?: PipeLogConfigurationParameters | undefined;
    KmsKeyIdentifier?: string | undefined;
}
export type PipeArn = string;
export type PipeState = string;
export interface CreatePipeResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    DesiredState?: string | undefined;
    CurrentState?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface DeletePipeRequest {
    Name: string;
}
export type RequestedPipeStateDescribeResponse = string;
export interface DeletePipeResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    DesiredState?: string | undefined;
    CurrentState?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface DescribePipeRequest {
    Name: string;
}
export type PipeStateReason = string;
export interface S3LogDestination {
    BucketName?: string | undefined;
    Prefix?: string | undefined;
    BucketOwner?: string | undefined;
    OutputFormat?: string | undefined;
}
export interface FirehoseLogDestination {
    DeliveryStreamArn?: string | undefined;
}
export interface CloudwatchLogsLogDestination {
    LogGroupArn?: string | undefined;
}
export interface PipeLogConfiguration {
    S3LogDestination?: S3LogDestination | undefined;
    FirehoseLogDestination?: FirehoseLogDestination | undefined;
    CloudwatchLogsLogDestination?: CloudwatchLogsLogDestination | undefined;
    Level?: string | undefined;
    IncludeExecutionData?: string[] | undefined;
}
export interface DescribePipeResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    DesiredState?: string | undefined;
    CurrentState?: string | undefined;
    StateReason?: string | undefined;
    Source?: string | undefined;
    SourceParameters?: PipeSourceParameters | undefined;
    Enrichment?: string | undefined;
    EnrichmentParameters?: PipeEnrichmentParameters | undefined;
    Target?: string | undefined;
    TargetParameters?: PipeTargetParameters | undefined;
    RoleArn?: string | undefined;
    Tags?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LogConfiguration?: PipeLogConfiguration | undefined;
    KmsKeyIdentifier?: string | undefined;
}
export type ResourceArn = string;
export type NextToken = string | redacted.Redacted<string>;
export type LimitMax100 = number;
export interface ListPipesRequest {
    NamePrefix?: string | undefined;
    DesiredState?: string | undefined;
    CurrentState?: string | undefined;
    SourcePrefix?: string | undefined;
    TargetPrefix?: string | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
    Limit?: number | undefined;
}
export interface Pipe {
    Name?: string | undefined;
    Arn?: string | undefined;
    DesiredState?: string | undefined;
    CurrentState?: string | undefined;
    StateReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    Source?: string | undefined;
    Target?: string | undefined;
    Enrichment?: string | undefined;
}
export type PipeList = Pipe[];
export interface ListPipesResponse {
    Pipes?: Pipe[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export interface StartPipeRequest {
    Name: string;
}
export interface StartPipeResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    DesiredState?: string | undefined;
    CurrentState?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface StopPipeRequest {
    Name: string;
}
export interface StopPipeResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    DesiredState?: string | undefined;
    CurrentState?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdatePipeSourceKinesisStreamParameters {
    BatchSize?: number | undefined;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    OnPartialBatchItemFailure?: string | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    MaximumRecordAgeInSeconds?: number | undefined;
    MaximumRetryAttempts?: number | undefined;
    ParallelizationFactor?: number | undefined;
}
export interface UpdatePipeSourceDynamoDBStreamParameters {
    BatchSize?: number | undefined;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    OnPartialBatchItemFailure?: string | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    MaximumRecordAgeInSeconds?: number | undefined;
    MaximumRetryAttempts?: number | undefined;
    ParallelizationFactor?: number | undefined;
}
export interface UpdatePipeSourceSqsQueueParameters {
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
}
export interface UpdatePipeSourceActiveMQBrokerParameters {
    Credentials: MQBrokerAccessCredentials;
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
}
export interface UpdatePipeSourceRabbitMQBrokerParameters {
    Credentials: MQBrokerAccessCredentials;
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
}
export interface UpdatePipeSourceManagedStreamingKafkaParameters {
    BatchSize?: number | undefined;
    Credentials?: MSKAccessCredentials | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
}
export interface UpdatePipeSourceSelfManagedKafkaParameters {
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    Credentials?: SelfManagedKafkaAccessConfigurationCredentials | undefined;
    ServerRootCaCertificate?: string | undefined;
    Vpc?: SelfManagedKafkaAccessConfigurationVpc | undefined;
}
export interface UpdatePipeSourceParameters {
    FilterCriteria?: FilterCriteria | undefined;
    KinesisStreamParameters?: UpdatePipeSourceKinesisStreamParameters | undefined;
    DynamoDBStreamParameters?: UpdatePipeSourceDynamoDBStreamParameters | undefined;
    SqsQueueParameters?: UpdatePipeSourceSqsQueueParameters | undefined;
    ActiveMQBrokerParameters?: UpdatePipeSourceActiveMQBrokerParameters | undefined;
    RabbitMQBrokerParameters?: UpdatePipeSourceRabbitMQBrokerParameters | undefined;
    ManagedStreamingKafkaParameters?: UpdatePipeSourceManagedStreamingKafkaParameters | undefined;
    SelfManagedKafkaParameters?: UpdatePipeSourceSelfManagedKafkaParameters | undefined;
}
export interface UpdatePipeRequest {
    Name: string;
    Description?: string | redacted.Redacted<string> | undefined;
    DesiredState?: string | undefined;
    SourceParameters?: UpdatePipeSourceParameters | undefined;
    Enrichment?: string | undefined;
    EnrichmentParameters?: PipeEnrichmentParameters | undefined;
    Target?: string | undefined;
    TargetParameters?: PipeTargetParameters | undefined;
    RoleArn: string;
    LogConfiguration?: PipeLogConfigurationParameters | undefined;
    KmsKeyIdentifier?: string | undefined;
}
export interface UpdatePipeResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    DesiredState?: string | undefined;
    CurrentState?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ErrorMessage = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreatePipeError = ConflictException | InternalException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a pipe. Amazon EventBridge Pipes connect event sources to targets and reduces
 * the need for specialized knowledge and integration code.
 */
export declare const createPipe: API.OperationMethod<CreatePipeRequest & RegionInput, CreatePipeResponse, CreatePipeError, Credentials | HttpClient.HttpClient>;
export type DeletePipeError = ConflictException | InternalException | NotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an existing pipe. For more information about pipes, see Amazon EventBridge Pipes in the Amazon EventBridge User Guide.
 */
export declare const deletePipe: API.OperationMethod<DeletePipeRequest & RegionInput, DeletePipeResponse, DeletePipeError, Credentials | HttpClient.HttpClient>;
export type DescribePipeError = InternalException | NotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the information about an existing pipe. For more information about pipes, see Amazon EventBridge Pipes in the Amazon EventBridge User Guide.
 */
export declare const describePipe: API.OperationMethod<DescribePipeRequest & RegionInput, DescribePipeResponse, DescribePipeError, Credentials | HttpClient.HttpClient>;
export type ListPipesError = InternalException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the pipes associated with this account. For more information about pipes, see Amazon EventBridge Pipes in the Amazon EventBridge User Guide.
 */
export declare const listPipes: API.PaginatedOperationMethod<ListPipesRequest & RegionInput, ListPipesResponse, ListPipesError, Credentials | HttpClient.HttpClient, Pipe>;
export type ListTagsForResourceError = InternalException | NotFoundException | ValidationException | CommonErrors;
/**
 * Displays the tags associated with a pipe.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartPipeError = ConflictException | InternalException | NotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start an existing pipe.
 */
export declare const startPipe: API.OperationMethod<StartPipeRequest & RegionInput, StartPipeResponse, StartPipeError, Credentials | HttpClient.HttpClient>;
export type StopPipeError = ConflictException | InternalException | NotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stop an existing pipe.
 */
export declare const stopPipe: API.OperationMethod<StopPipeRequest & RegionInput, StopPipeResponse, StopPipeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalException | NotFoundException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified pipe. Tags can help you
 * organize and categorize your resources. You can also use them to scope user permissions by
 * granting a user permission to access or change only resources with certain tag
 * values.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly
 * as strings of characters.
 *
 * You can use the `TagResource` action with a pipe that already has tags. If
 * you specify a new tag key, this tag is appended to the list of tags associated with the
 * pipe. If you specify a tag key that is already associated with the pipe, the new tag value
 * that you specify replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a pipe.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalException | NotFoundException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified pipes.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePipeError = ConflictException | InternalException | NotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an existing pipe. When you call `UpdatePipe`, EventBridge only the
 * updates fields you have specified in the request; the rest remain unchanged. The exception
 * to this is if you modify any Amazon Web Services-service specific fields in the
 * `SourceParameters`, `EnrichmentParameters`, or
 * `TargetParameters` objects. For example,
 * `DynamoDBStreamParameters` or `EventBridgeEventBusParameters`.
 * EventBridge updates the fields in these objects atomically as one and overrides existing
 * values. This is by design, and means that if you don't specify an optional field in one of
 * these `Parameters` objects, EventBridge sets that field to its system-default
 * value during the update.
 *
 * For more information about pipes, see
 * Amazon EventBridge Pipes in the Amazon EventBridge User Guide.
 */
export declare const updatePipe: API.OperationMethod<UpdatePipeRequest & RegionInput, UpdatePipeResponse, UpdatePipeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pipes.d.ts.map