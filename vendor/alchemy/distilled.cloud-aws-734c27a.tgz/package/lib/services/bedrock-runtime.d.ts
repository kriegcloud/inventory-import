import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ModelErrorException_base: S.TaggedErrorClass<"ModelErrorException", {
    readonly message: any;
    readonly originalStatusCode: any;
    readonly resourceName: any;
}>;
export declare class ModelErrorException extends /*@__PURE__*/ ModelErrorException_base {
}
declare const ModelNotReadyException_base: S.TaggedErrorClass<"ModelNotReadyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ModelNotReadyException extends /*@__PURE__*/ ModelNotReadyException_base {
}
declare const ModelStreamErrorException_base: S.TaggedErrorClass<"ModelStreamErrorException", {
    readonly message: any;
    readonly originalStatusCode: any;
    readonly originalMessage: any;
}>;
export declare class ModelStreamErrorException extends /*@__PURE__*/ ModelStreamErrorException_base {
}
declare const ModelTimeoutException_base: S.TaggedErrorClass<"ModelTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class ModelTimeoutException extends /*@__PURE__*/ ModelTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GuardrailIdentifier = string;
export type GuardrailVersion = string;
export type GuardrailContentSource = "INPUT" | "OUTPUT" | (string & {});
export type GuardrailContentQualifier = "grounding_source" | "query" | "guard_content" | (string & {});
export type GuardrailContentQualifierList = GuardrailContentQualifier[];
export interface GuardrailTextBlock {
    text: string;
    qualifiers?: GuardrailContentQualifier[] | undefined;
}
export type GuardrailImageFormat = "png" | "jpeg" | (string & {});
export type GuardrailImageSource = {
    bytes: Uint8Array;
};
export interface GuardrailImageBlock {
    format: GuardrailImageFormat;
    source: GuardrailImageSource;
}
export type GuardrailContentBlock = {
    text: GuardrailTextBlock;
    image?: undefined;
} | {
    text?: undefined;
    image: GuardrailImageBlock;
};
export type GuardrailContentBlockList = GuardrailContentBlock[];
export type GuardrailOutputScope = "INTERVENTIONS" | "FULL" | (string & {});
export interface ApplyGuardrailRequest {
    guardrailIdentifier: string;
    guardrailVersion: string;
    source: GuardrailContentSource;
    content: GuardrailContentBlock[];
    outputScope?: GuardrailOutputScope | undefined;
}
export type GuardrailTopicPolicyUnitsProcessed = number;
export type GuardrailContentPolicyUnitsProcessed = number;
export type GuardrailWordPolicyUnitsProcessed = number;
export type GuardrailSensitiveInformationPolicyUnitsProcessed = number;
export type GuardrailSensitiveInformationPolicyFreeUnitsProcessed = number;
export type GuardrailContextualGroundingPolicyUnitsProcessed = number;
export type GuardrailContentPolicyImageUnitsProcessed = number;
export type GuardrailAutomatedReasoningPolicyUnitsProcessed = number;
export type GuardrailAutomatedReasoningPoliciesProcessed = number;
export interface GuardrailUsage {
    topicPolicyUnits: number;
    contentPolicyUnits: number;
    wordPolicyUnits: number;
    sensitiveInformationPolicyUnits: number;
    sensitiveInformationPolicyFreeUnits: number;
    contextualGroundingPolicyUnits: number;
    contentPolicyImageUnits?: number | undefined;
    automatedReasoningPolicyUnits?: number | undefined;
    automatedReasoningPolicies?: number | undefined;
}
export type GuardrailAction = "NONE" | "GUARDRAIL_INTERVENED" | (string & {});
export type GuardrailOutputText = string;
export interface GuardrailOutputContent {
    text?: string | undefined;
}
export type GuardrailOutputContentList = GuardrailOutputContent[];
export type GuardrailTopicType = "DENY" | (string & {});
export type GuardrailTopicPolicyAction = "BLOCKED" | "NONE" | (string & {});
export interface GuardrailTopic {
    name: string;
    type: GuardrailTopicType;
    action: GuardrailTopicPolicyAction;
    detected?: boolean | undefined;
}
export type GuardrailTopicList = GuardrailTopic[];
export interface GuardrailTopicPolicyAssessment {
    topics: GuardrailTopic[];
}
export type GuardrailContentFilterType = "INSULTS" | "HATE" | "SEXUAL" | "VIOLENCE" | "MISCONDUCT" | "PROMPT_ATTACK" | (string & {});
export type GuardrailContentFilterConfidence = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type GuardrailContentFilterStrength = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type GuardrailContentPolicyAction = "BLOCKED" | "NONE" | (string & {});
export interface GuardrailContentFilter {
    type: GuardrailContentFilterType;
    confidence: GuardrailContentFilterConfidence;
    filterStrength?: GuardrailContentFilterStrength | undefined;
    action: GuardrailContentPolicyAction;
    detected?: boolean | undefined;
}
export type GuardrailContentFilterList = GuardrailContentFilter[];
export interface GuardrailContentPolicyAssessment {
    filters: GuardrailContentFilter[];
}
export type GuardrailWordPolicyAction = "BLOCKED" | "NONE" | (string & {});
export interface GuardrailCustomWord {
    match: string;
    action: GuardrailWordPolicyAction;
    detected?: boolean | undefined;
}
export type GuardrailCustomWordList = GuardrailCustomWord[];
export type GuardrailManagedWordType = "PROFANITY" | (string & {});
export interface GuardrailManagedWord {
    match: string;
    type: GuardrailManagedWordType;
    action: GuardrailWordPolicyAction;
    detected?: boolean | undefined;
}
export type GuardrailManagedWordList = GuardrailManagedWord[];
export interface GuardrailWordPolicyAssessment {
    customWords: GuardrailCustomWord[];
    managedWordLists: GuardrailManagedWord[];
}
export type GuardrailPiiEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export type GuardrailSensitiveInformationPolicyAction = "ANONYMIZED" | "BLOCKED" | "NONE" | (string & {});
export interface GuardrailPiiEntityFilter {
    match: string;
    type: GuardrailPiiEntityType;
    action: GuardrailSensitiveInformationPolicyAction;
    detected?: boolean | undefined;
}
export type GuardrailPiiEntityFilterList = GuardrailPiiEntityFilter[];
export interface GuardrailRegexFilter {
    name?: string | undefined;
    match?: string | undefined;
    regex?: string | undefined;
    action: GuardrailSensitiveInformationPolicyAction;
    detected?: boolean | undefined;
}
export type GuardrailRegexFilterList = GuardrailRegexFilter[];
export interface GuardrailSensitiveInformationPolicyAssessment {
    piiEntities: GuardrailPiiEntityFilter[];
    regexes: GuardrailRegexFilter[];
}
export type GuardrailContextualGroundingFilterType = "GROUNDING" | "RELEVANCE" | (string & {});
export type GuardrailContextualGroundingPolicyAction = "BLOCKED" | "NONE" | (string & {});
export interface GuardrailContextualGroundingFilter {
    type: GuardrailContextualGroundingFilterType;
    threshold: number;
    score: number;
    action: GuardrailContextualGroundingPolicyAction;
    detected?: boolean | undefined;
}
export type GuardrailContextualGroundingFilters = GuardrailContextualGroundingFilter[];
export interface GuardrailContextualGroundingPolicyAssessment {
    filters?: GuardrailContextualGroundingFilter[] | undefined;
}
export type GuardrailAutomatedReasoningStatementLogicContent = string | redacted.Redacted<string>;
export type GuardrailAutomatedReasoningStatementNaturalLanguageContent = string | redacted.Redacted<string>;
export interface GuardrailAutomatedReasoningStatement {
    logic?: string | redacted.Redacted<string> | undefined;
    naturalLanguage?: string | redacted.Redacted<string> | undefined;
}
export type GuardrailAutomatedReasoningStatementList = GuardrailAutomatedReasoningStatement[];
export interface GuardrailAutomatedReasoningInputTextReference {
    text?: string | redacted.Redacted<string> | undefined;
}
export type GuardrailAutomatedReasoningInputTextReferenceList = GuardrailAutomatedReasoningInputTextReference[];
export type GuardrailAutomatedReasoningTranslationConfidence = number;
export interface GuardrailAutomatedReasoningTranslation {
    premises?: GuardrailAutomatedReasoningStatement[] | undefined;
    claims?: GuardrailAutomatedReasoningStatement[] | undefined;
    untranslatedPremises?: GuardrailAutomatedReasoningInputTextReference[] | undefined;
    untranslatedClaims?: GuardrailAutomatedReasoningInputTextReference[] | undefined;
    confidence?: number | undefined;
}
export interface GuardrailAutomatedReasoningScenario {
    statements?: GuardrailAutomatedReasoningStatement[] | undefined;
}
export type AutomatedReasoningRuleIdentifier = string;
export type GuardrailAutomatedReasoningPolicyVersionArn = string;
export interface GuardrailAutomatedReasoningRule {
    identifier?: string | undefined;
    policyVersionArn?: string | undefined;
}
export type GuardrailAutomatedReasoningRuleList = GuardrailAutomatedReasoningRule[];
export type GuardrailAutomatedReasoningLogicWarningType = "ALWAYS_FALSE" | "ALWAYS_TRUE" | (string & {});
export interface GuardrailAutomatedReasoningLogicWarning {
    type?: GuardrailAutomatedReasoningLogicWarningType | undefined;
    premises?: GuardrailAutomatedReasoningStatement[] | undefined;
    claims?: GuardrailAutomatedReasoningStatement[] | undefined;
}
export interface GuardrailAutomatedReasoningValidFinding {
    translation?: GuardrailAutomatedReasoningTranslation | undefined;
    claimsTrueScenario?: GuardrailAutomatedReasoningScenario | undefined;
    supportingRules?: GuardrailAutomatedReasoningRule[] | undefined;
    logicWarning?: GuardrailAutomatedReasoningLogicWarning | undefined;
}
export interface GuardrailAutomatedReasoningInvalidFinding {
    translation?: GuardrailAutomatedReasoningTranslation | undefined;
    contradictingRules?: GuardrailAutomatedReasoningRule[] | undefined;
    logicWarning?: GuardrailAutomatedReasoningLogicWarning | undefined;
}
export interface GuardrailAutomatedReasoningSatisfiableFinding {
    translation?: GuardrailAutomatedReasoningTranslation | undefined;
    claimsTrueScenario?: GuardrailAutomatedReasoningScenario | undefined;
    claimsFalseScenario?: GuardrailAutomatedReasoningScenario | undefined;
    logicWarning?: GuardrailAutomatedReasoningLogicWarning | undefined;
}
export interface GuardrailAutomatedReasoningImpossibleFinding {
    translation?: GuardrailAutomatedReasoningTranslation | undefined;
    contradictingRules?: GuardrailAutomatedReasoningRule[] | undefined;
    logicWarning?: GuardrailAutomatedReasoningLogicWarning | undefined;
}
export type GuardrailAutomatedReasoningTranslationList = GuardrailAutomatedReasoningTranslation[];
export interface GuardrailAutomatedReasoningTranslationOption {
    translations?: GuardrailAutomatedReasoningTranslation[] | undefined;
}
export type GuardrailAutomatedReasoningTranslationOptionList = GuardrailAutomatedReasoningTranslationOption[];
export type GuardrailAutomatedReasoningDifferenceScenarioList = GuardrailAutomatedReasoningScenario[];
export interface GuardrailAutomatedReasoningTranslationAmbiguousFinding {
    options?: GuardrailAutomatedReasoningTranslationOption[] | undefined;
    differenceScenarios?: GuardrailAutomatedReasoningScenario[] | undefined;
}
export interface GuardrailAutomatedReasoningTooComplexFinding {
}
export interface GuardrailAutomatedReasoningNoTranslationsFinding {
}
export type GuardrailAutomatedReasoningFinding = {
    valid: GuardrailAutomatedReasoningValidFinding;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid: GuardrailAutomatedReasoningInvalidFinding;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable: GuardrailAutomatedReasoningSatisfiableFinding;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible: GuardrailAutomatedReasoningImpossibleFinding;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous: GuardrailAutomatedReasoningTranslationAmbiguousFinding;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex: GuardrailAutomatedReasoningTooComplexFinding;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations: GuardrailAutomatedReasoningNoTranslationsFinding;
};
export type GuardrailAutomatedReasoningFindingList = GuardrailAutomatedReasoningFinding[];
export interface GuardrailAutomatedReasoningPolicyAssessment {
    findings?: GuardrailAutomatedReasoningFinding[] | undefined;
}
export type GuardrailProcessingLatency = number;
export type TextCharactersGuarded = number;
export type TextCharactersTotal = number;
export interface GuardrailTextCharactersCoverage {
    guarded?: number | undefined;
    total?: number | undefined;
}
export type ImagesGuarded = number;
export type ImagesTotal = number;
export interface GuardrailImageCoverage {
    guarded?: number | undefined;
    total?: number | undefined;
}
export interface GuardrailCoverage {
    textCharacters?: GuardrailTextCharactersCoverage | undefined;
    images?: GuardrailImageCoverage | undefined;
}
export interface GuardrailInvocationMetrics {
    guardrailProcessingLatency?: number | undefined;
    usage?: GuardrailUsage | undefined;
    guardrailCoverage?: GuardrailCoverage | undefined;
}
export type GuardrailId = string;
export type GuardrailArn = string;
export type GuardrailOrigin = "REQUEST" | "ACCOUNT_ENFORCED" | "ORGANIZATION_ENFORCED" | (string & {});
export type GuardrailOriginList = GuardrailOrigin[];
export type GuardrailOwnership = "SELF" | "CROSS_ACCOUNT" | (string & {});
export interface AppliedGuardrailDetails {
    guardrailId?: string | undefined;
    guardrailVersion?: string | undefined;
    guardrailArn?: string | undefined;
    guardrailOrigin?: GuardrailOrigin[] | undefined;
    guardrailOwnership?: GuardrailOwnership | undefined;
}
export interface GuardrailAssessment {
    topicPolicy?: GuardrailTopicPolicyAssessment | undefined;
    contentPolicy?: GuardrailContentPolicyAssessment | undefined;
    wordPolicy?: GuardrailWordPolicyAssessment | undefined;
    sensitiveInformationPolicy?: GuardrailSensitiveInformationPolicyAssessment | undefined;
    contextualGroundingPolicy?: GuardrailContextualGroundingPolicyAssessment | undefined;
    automatedReasoningPolicy?: GuardrailAutomatedReasoningPolicyAssessment | undefined;
    invocationMetrics?: GuardrailInvocationMetrics | undefined;
    appliedGuardrailDetails?: AppliedGuardrailDetails | undefined;
}
export type GuardrailAssessmentList = GuardrailAssessment[];
export interface ApplyGuardrailResponse {
    usage: GuardrailUsage;
    action: GuardrailAction;
    actionReason?: string | undefined;
    outputs: GuardrailOutputContent[];
    assessments: GuardrailAssessment[];
    guardrailCoverage?: GuardrailCoverage | undefined;
}
export type ConversationalModelId = string;
export type ConversationRole = "user" | "assistant" | "system" | (string & {});
export type ImageFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export type S3Uri = string;
export type AccountId = string;
export interface S3Location {
    uri: string;
    bucketOwner?: string | undefined;
}
export type ImageSource = {
    bytes: Uint8Array;
    s3Location?: undefined;
} | {
    bytes?: undefined;
    s3Location: S3Location;
};
export interface ErrorBlock {
    message?: string | undefined;
}
export interface ImageBlock {
    format: ImageFormat;
    source: ImageSource;
    error?: ErrorBlock | undefined;
}
export type DocumentFormat = "pdf" | "csv" | "doc" | "docx" | "xls" | "xlsx" | "html" | "txt" | "md" | (string & {});
export type DocumentContentBlock = {
    text: string;
};
export type DocumentContentBlocks = DocumentContentBlock[];
export type DocumentSource = {
    bytes: Uint8Array;
    s3Location?: undefined;
    text?: undefined;
    content?: undefined;
} | {
    bytes?: undefined;
    s3Location: S3Location;
    text?: undefined;
    content?: undefined;
} | {
    bytes?: undefined;
    s3Location?: undefined;
    text: string;
    content?: undefined;
} | {
    bytes?: undefined;
    s3Location?: undefined;
    text?: undefined;
    content: DocumentContentBlock[];
};
export interface CitationsConfig {
    enabled: boolean;
}
export interface DocumentBlock {
    format?: DocumentFormat | undefined;
    name: string;
    source: DocumentSource;
    context?: string | undefined;
    citations?: CitationsConfig | undefined;
}
export type VideoFormat = "mkv" | "mov" | "mp4" | "webm" | "flv" | "mpeg" | "mpg" | "wmv" | "three_gp" | (string & {});
export type VideoSource = {
    bytes: Uint8Array;
    s3Location?: undefined;
} | {
    bytes?: undefined;
    s3Location: S3Location;
};
export interface VideoBlock {
    format: VideoFormat;
    source: VideoSource;
}
export type AudioFormat = "mp3" | "opus" | "wav" | "aac" | "flac" | "mp4" | "ogg" | "mkv" | "mka" | "x-aac" | "m4a" | "mpeg" | "mpga" | "pcm" | "webm" | (string & {});
export type AudioSource = {
    bytes: Uint8Array;
    s3Location?: undefined;
} | {
    bytes?: undefined;
    s3Location: S3Location;
};
export interface AudioBlock {
    format: AudioFormat;
    source: AudioSource;
    error?: ErrorBlock | undefined;
}
export type ToolUseId = string;
export type ToolName = string;
export type ToolUseType = "server_tool_use" | (string & {});
export interface ToolUseBlock {
    toolUseId: string;
    name: string;
    input: any;
    type?: ToolUseType | undefined;
}
export interface SearchResultContentBlock {
    text: string;
}
export type SearchResultContentBlocks = SearchResultContentBlock[];
export interface SearchResultBlock {
    source: string;
    title: string;
    content: SearchResultContentBlock[];
    citations?: CitationsConfig | undefined;
}
export type ToolResultContentBlock = {
    json: any;
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    searchResult?: undefined;
} | {
    json?: undefined;
    text: string;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    searchResult?: undefined;
} | {
    json?: undefined;
    text?: undefined;
    image: ImageBlock;
    document?: undefined;
    video?: undefined;
    searchResult?: undefined;
} | {
    json?: undefined;
    text?: undefined;
    image?: undefined;
    document: DocumentBlock;
    video?: undefined;
    searchResult?: undefined;
} | {
    json?: undefined;
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video: VideoBlock;
    searchResult?: undefined;
} | {
    json?: undefined;
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    searchResult: SearchResultBlock;
};
export type ToolResultContentBlocks = ToolResultContentBlock[];
export type ToolResultStatus = "success" | "error" | (string & {});
export interface ToolResultBlock {
    toolUseId: string;
    content: ToolResultContentBlock[];
    status?: ToolResultStatus | undefined;
    type?: string | undefined;
}
export type GuardrailConverseContentQualifier = "grounding_source" | "query" | "guard_content" | (string & {});
export type GuardrailConverseContentQualifierList = GuardrailConverseContentQualifier[];
export interface GuardrailConverseTextBlock {
    text: string;
    qualifiers?: GuardrailConverseContentQualifier[] | undefined;
}
export type GuardrailConverseImageFormat = "png" | "jpeg" | (string & {});
export type GuardrailConverseImageSource = {
    bytes: Uint8Array;
};
export interface GuardrailConverseImageBlock {
    format: GuardrailConverseImageFormat;
    source: GuardrailConverseImageSource;
}
export type GuardrailConverseContentBlock = {
    text: GuardrailConverseTextBlock;
    image?: undefined;
} | {
    text?: undefined;
    image: GuardrailConverseImageBlock;
};
export type CachePointType = "default" | (string & {});
export type CacheTTL = "5m" | "1h" | (string & {});
export interface CachePointBlock {
    type: CachePointType;
    ttl?: CacheTTL | undefined;
}
export interface ReasoningTextBlock {
    text: string;
    signature?: string | undefined;
}
export type ReasoningContentBlock = {
    reasoningText: ReasoningTextBlock;
    redactedContent?: undefined;
} | {
    reasoningText?: undefined;
    redactedContent: Uint8Array;
};
export type CitationGeneratedContent = {
    text: string;
};
export type CitationGeneratedContentList = CitationGeneratedContent[];
export type CitationSourceContent = {
    text: string;
};
export type CitationSourceContentList = CitationSourceContent[];
export interface WebLocation {
    url?: string | undefined;
    domain?: string | undefined;
}
export interface DocumentCharLocation {
    documentIndex?: number | undefined;
    start?: number | undefined;
    end?: number | undefined;
}
export interface DocumentPageLocation {
    documentIndex?: number | undefined;
    start?: number | undefined;
    end?: number | undefined;
}
export interface DocumentChunkLocation {
    documentIndex?: number | undefined;
    start?: number | undefined;
    end?: number | undefined;
}
export interface SearchResultLocation {
    searchResultIndex?: number | undefined;
    start?: number | undefined;
    end?: number | undefined;
}
export type CitationLocation = {
    web: WebLocation;
    documentChar?: undefined;
    documentPage?: undefined;
    documentChunk?: undefined;
    searchResultLocation?: undefined;
} | {
    web?: undefined;
    documentChar: DocumentCharLocation;
    documentPage?: undefined;
    documentChunk?: undefined;
    searchResultLocation?: undefined;
} | {
    web?: undefined;
    documentChar?: undefined;
    documentPage: DocumentPageLocation;
    documentChunk?: undefined;
    searchResultLocation?: undefined;
} | {
    web?: undefined;
    documentChar?: undefined;
    documentPage?: undefined;
    documentChunk: DocumentChunkLocation;
    searchResultLocation?: undefined;
} | {
    web?: undefined;
    documentChar?: undefined;
    documentPage?: undefined;
    documentChunk?: undefined;
    searchResultLocation: SearchResultLocation;
};
export interface Citation {
    title?: string | undefined;
    source?: string | undefined;
    sourceContent?: CitationSourceContent[] | undefined;
    location?: CitationLocation | undefined;
}
export type Citations = Citation[];
export interface CitationsContentBlock {
    content?: CitationGeneratedContent[] | undefined;
    citations?: Citation[] | undefined;
}
export interface ToolReference {
    type?: string | undefined;
    name?: string | undefined;
    serverName?: string | undefined;
}
export interface ToolAdditionBlock {
    tool: ToolReference;
}
export interface ToolRemovalBlock {
    tool: ToolReference;
}
export type ContentBlock = {
    text: string;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image: ImageBlock;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document: DocumentBlock;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video: VideoBlock;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio: AudioBlock;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse: ToolUseBlock;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult: ToolResultBlock;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent: GuardrailConverseContentBlock;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint: CachePointBlock;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent: ReasoningContentBlock;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent: CitationsContentBlock;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult: SearchResultBlock;
    toolAddition?: undefined;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition: ToolAdditionBlock;
    toolRemoval?: undefined;
} | {
    text?: undefined;
    image?: undefined;
    document?: undefined;
    video?: undefined;
    audio?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    guardContent?: undefined;
    cachePoint?: undefined;
    reasoningContent?: undefined;
    citationsContent?: undefined;
    searchResult?: undefined;
    toolAddition?: undefined;
    toolRemoval: ToolRemovalBlock;
};
export type ContentBlocks = ContentBlock[];
export interface Message {
    role: ConversationRole;
    content: ContentBlock[];
}
export type Messages = Message[];
export type NonEmptyString = string;
export type SystemContentBlock = {
    text: string;
    guardContent?: undefined;
    cachePoint?: undefined;
} | {
    text?: undefined;
    guardContent: GuardrailConverseContentBlock;
    cachePoint?: undefined;
} | {
    text?: undefined;
    guardContent?: undefined;
    cachePoint: CachePointBlock;
};
export type SystemContentBlocks = SystemContentBlock[];
export type NonEmptyStringList = string[];
export interface InferenceConfiguration {
    maxTokens?: number | undefined;
    temperature?: number | undefined;
    topP?: number | undefined;
    stopSequences?: string[] | undefined;
}
export type ToolInputSchema = {
    json: any;
};
export interface ToolSpecification {
    name: string;
    description?: string | undefined;
    inputSchema: ToolInputSchema;
    strict?: boolean | undefined;
}
export interface SystemTool {
    name: string;
}
export type Tool = {
    toolSpec: ToolSpecification;
    systemTool?: undefined;
    cachePoint?: undefined;
} | {
    toolSpec?: undefined;
    systemTool: SystemTool;
    cachePoint?: undefined;
} | {
    toolSpec?: undefined;
    systemTool?: undefined;
    cachePoint: CachePointBlock;
};
export type Tools = Tool[];
export interface AutoToolChoice {
}
export interface AnyToolChoice {
}
export interface SpecificToolChoice {
    name: string;
}
export type ToolChoice = {
    auto: AutoToolChoice;
    any?: undefined;
    tool?: undefined;
} | {
    auto?: undefined;
    any: AnyToolChoice;
    tool?: undefined;
} | {
    auto?: undefined;
    any?: undefined;
    tool: SpecificToolChoice;
};
export interface ToolConfiguration {
    tools: Tool[];
    toolChoice?: ToolChoice | undefined;
}
export type GuardrailTrace = "enabled" | "disabled" | "enabled_full" | (string & {});
export interface GuardrailConfiguration {
    guardrailIdentifier?: string | undefined;
    guardrailVersion?: string | undefined;
    trace?: GuardrailTrace | undefined;
}
export type PromptVariableValues = {
    text: string;
};
export type PromptVariableMap = {
    [key: string]: PromptVariableValues | undefined;
};
export type AdditionalModelResponseFieldPaths = string[];
export type RequestMetadata = {
    [key: string]: string | undefined;
};
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency | undefined;
}
export type ServiceTierType = "priority" | "default" | "flex" | "reserved" | (string & {});
export interface ServiceTier {
    type: ServiceTierType;
}
export type OutputFormatType = "json_schema" | (string & {});
export interface JsonSchemaDefinition {
    schema: string;
    name?: string | undefined;
    description?: string | undefined;
}
export type OutputFormatStructure = {
    jsonSchema: JsonSchemaDefinition;
};
export interface OutputFormat {
    type: OutputFormatType;
    structure: OutputFormatStructure;
}
export interface OutputConfig {
    textFormat?: OutputFormat | undefined;
    effort?: string | undefined;
}
export interface ConverseRequest {
    modelId: string;
    messages?: Message[] | undefined;
    system?: SystemContentBlock[] | undefined;
    inferenceConfig?: InferenceConfiguration | undefined;
    toolConfig?: ToolConfiguration | undefined;
    guardrailConfig?: GuardrailConfiguration | undefined;
    additionalModelRequestFields?: any | undefined;
    promptVariables?: {
        [key: string]: PromptVariableValues | undefined;
    } | undefined;
    additionalModelResponseFieldPaths?: string[] | undefined;
    requestMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
    serviceTier?: ServiceTier | undefined;
    outputConfig?: OutputConfig | undefined;
}
export type ConverseOutput = {
    message: Message;
};
export type StopReason = "end_turn" | "tool_use" | "max_tokens" | "stop_sequence" | "guardrail_intervened" | "content_filtered" | "malformed_model_output" | "malformed_tool_use" | "model_context_window_exceeded" | (string & {});
export interface CacheDetail {
    ttl: CacheTTL;
    inputTokens: number;
}
export type CacheDetailsList = CacheDetail[];
export interface TokenUsage {
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
    cacheReadInputTokens?: number | undefined;
    cacheWriteInputTokens?: number | undefined;
    cacheDetails?: CacheDetail[] | undefined;
}
export interface ConverseMetrics {
    latencyMs: number;
}
export type ModelOutputs = string[];
export type GuardrailAssessmentMap = {
    [key: string]: GuardrailAssessment | undefined;
};
export type GuardrailAssessmentListMap = {
    [key: string]: GuardrailAssessment[] | undefined;
};
export interface GuardrailTraceAssessment {
    modelOutput?: string[] | undefined;
    inputAssessment?: {
        [key: string]: GuardrailAssessment | undefined;
    } | undefined;
    outputAssessments?: {
        [key: string]: GuardrailAssessment[] | undefined;
    } | undefined;
    actionReason?: string | undefined;
}
export type InvokedModelId = string;
export interface PromptRouterTrace {
    invokedModelId?: string | undefined;
}
export interface ConverseTrace {
    guardrail?: GuardrailTraceAssessment | undefined;
    promptRouter?: PromptRouterTrace | undefined;
}
export interface ConverseResponse {
    output: ConverseOutput;
    stopReason: StopReason;
    usage: TokenUsage;
    metrics: ConverseMetrics;
    additionalModelResponseFields?: any | undefined;
    trace?: ConverseTrace | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
    serviceTier?: ServiceTier | undefined;
}
export type GuardrailStreamProcessingMode = "sync" | "async" | (string & {});
export interface GuardrailStreamConfiguration {
    guardrailIdentifier?: string | undefined;
    guardrailVersion?: string | undefined;
    trace?: GuardrailTrace | undefined;
    streamProcessingMode?: GuardrailStreamProcessingMode | undefined;
}
export interface ConverseStreamRequest {
    modelId: string;
    messages?: Message[] | undefined;
    system?: SystemContentBlock[] | undefined;
    inferenceConfig?: InferenceConfiguration | undefined;
    toolConfig?: ToolConfiguration | undefined;
    guardrailConfig?: GuardrailStreamConfiguration | undefined;
    additionalModelRequestFields?: any | undefined;
    promptVariables?: {
        [key: string]: PromptVariableValues | undefined;
    } | undefined;
    additionalModelResponseFieldPaths?: string[] | undefined;
    requestMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
    serviceTier?: ServiceTier | undefined;
    outputConfig?: OutputConfig | undefined;
}
export interface MessageStartEvent {
    role: ConversationRole;
}
export interface ToolUseBlockStart {
    toolUseId: string;
    name: string;
    type?: ToolUseType | undefined;
}
export interface ToolResultBlockStart {
    toolUseId: string;
    type?: string | undefined;
    status?: ToolResultStatus | undefined;
}
export interface ImageBlockStart {
    format: ImageFormat;
}
export type ContentBlockStart = {
    toolUse: ToolUseBlockStart;
    toolResult?: undefined;
    image?: undefined;
} | {
    toolUse?: undefined;
    toolResult: ToolResultBlockStart;
    image?: undefined;
} | {
    toolUse?: undefined;
    toolResult?: undefined;
    image: ImageBlockStart;
};
export type NonNegativeInteger = number;
export interface ContentBlockStartEvent {
    start: ContentBlockStart;
    contentBlockIndex: number;
}
export interface ToolUseBlockDelta {
    input: string;
}
export type ToolResultBlockDelta = {
    text: string;
    json?: undefined;
} | {
    text?: undefined;
    json: any;
};
export type ToolResultBlocksDelta = ToolResultBlockDelta[];
export type ReasoningContentBlockDelta = {
    text: string;
    redactedContent?: undefined;
    signature?: undefined;
} | {
    text?: undefined;
    redactedContent: Uint8Array;
    signature?: undefined;
} | {
    text?: undefined;
    redactedContent?: undefined;
    signature: string;
};
export interface CitationSourceContentDelta {
    text?: string | undefined;
}
export type CitationSourceContentListDelta = CitationSourceContentDelta[];
export interface CitationsDelta {
    title?: string | undefined;
    source?: string | undefined;
    sourceContent?: CitationSourceContentDelta[] | undefined;
    location?: CitationLocation | undefined;
}
export interface ImageBlockDelta {
    source?: ImageSource | undefined;
    error?: ErrorBlock | undefined;
}
export type ContentBlockDelta = {
    text: string;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent?: undefined;
    citation?: undefined;
    image?: undefined;
} | {
    text?: undefined;
    toolUse: ToolUseBlockDelta;
    toolResult?: undefined;
    reasoningContent?: undefined;
    citation?: undefined;
    image?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult: ToolResultBlockDelta[];
    reasoningContent?: undefined;
    citation?: undefined;
    image?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent: ReasoningContentBlockDelta;
    citation?: undefined;
    image?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent?: undefined;
    citation: CitationsDelta;
    image?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent?: undefined;
    citation?: undefined;
    image: ImageBlockDelta;
};
export interface ContentBlockDeltaEvent {
    delta: ContentBlockDelta;
    contentBlockIndex: number;
}
export interface ContentBlockStopEvent {
    contentBlockIndex: number;
}
export interface MessageStopEvent {
    stopReason: StopReason;
    additionalModelResponseFields?: any | undefined;
}
export interface ConverseStreamMetrics {
    latencyMs: number;
}
export interface ConverseStreamTrace {
    guardrail?: GuardrailTraceAssessment | undefined;
    promptRouter?: PromptRouterTrace | undefined;
}
export interface ConverseStreamMetadataEvent {
    usage: TokenUsage;
    metrics: ConverseStreamMetrics;
    trace?: ConverseStreamTrace | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
    serviceTier?: ServiceTier | undefined;
}
export type NonBlankString = string;
export type StatusCode = number;
export type ConverseStreamOutput = {
    messageStart: MessageStartEvent;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart: ContentBlockStartEvent;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta: ContentBlockDeltaEvent;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop: ContentBlockStopEvent;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop: MessageStopEvent;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata: ConverseStreamMetadataEvent;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException: InternalServerException;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException: ValidationException;
    throttlingException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException: ThrottlingException;
    serviceUnavailableException?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    serviceUnavailableException: ServiceUnavailableException;
};
export interface ConverseStreamResponse {
    stream?: stream.Stream<ConverseStreamOutput, Error, never> | undefined;
}
export type FoundationModelVersionIdentifier = string;
export type Body = Uint8Array | redacted.Redacted<Uint8Array>;
export interface InvokeModelTokensRequest {
    body: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface ConverseTokensRequest {
    messages?: Message[] | undefined;
    system?: SystemContentBlock[] | undefined;
    toolConfig?: ToolConfiguration | undefined;
    additionalModelRequestFields?: any | undefined;
}
export type CountTokensInput = {
    invokeModel: InvokeModelTokensRequest;
    converse?: undefined;
} | {
    invokeModel?: undefined;
    converse: ConverseTokensRequest;
};
export interface CountTokensRequest {
    modelId: string;
    input: CountTokensInput;
}
export interface CountTokensResponse {
    inputTokens: number;
}
export type InvocationArn = string;
export interface GetAsyncInvokeRequest {
    invocationArn: string;
}
export type AsyncInvokeArn = string;
export type AsyncInvokeIdempotencyToken = string;
export type AsyncInvokeStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export type AsyncInvokeMessage = string | redacted.Redacted<string>;
export type KmsKeyId = string;
export interface AsyncInvokeS3OutputDataConfig {
    s3Uri: string;
    kmsKeyId?: string | undefined;
    bucketOwner?: string | undefined;
}
export type AsyncInvokeOutputDataConfig = {
    s3OutputDataConfig: AsyncInvokeS3OutputDataConfig;
};
export interface GetAsyncInvokeResponse {
    invocationArn: string;
    modelArn: string;
    clientRequestToken?: string | undefined;
    status: AsyncInvokeStatus;
    failureMessage?: string | redacted.Redacted<string> | undefined;
    submitTime: Date;
    lastModifiedTime?: Date | undefined;
    endTime?: Date | undefined;
    outputDataConfig: AsyncInvokeOutputDataConfig;
}
export type GuardrailChecksRole = "user" | "assistant" | "system" | (string & {});
export type GuardrailChecksTextContent = string | redacted.Redacted<string>;
export type GuardrailChecksContentBlock = {
    text: string | redacted.Redacted<string>;
};
export type GuardrailChecksContentBlockList = GuardrailChecksContentBlock[];
export interface GuardrailChecksMessage {
    role: GuardrailChecksRole;
    content: GuardrailChecksContentBlock[];
}
export type GuardrailChecksMessageList = GuardrailChecksMessage[];
export type GuardrailChecksContentFilterCategory = "VIOLENCE" | "HATE" | "SEXUAL" | "MISCONDUCT" | "INSULTS" | (string & {});
export interface GuardrailChecksContentFilterCategoryConfig {
    category: GuardrailChecksContentFilterCategory;
}
export type GuardrailChecksContentFilterCategoryConfigList = GuardrailChecksContentFilterCategoryConfig[];
export interface GuardrailChecksContentFilterConfig {
    categories: GuardrailChecksContentFilterCategoryConfig[];
}
export type GuardrailChecksPromptAttackCategory = "JAILBREAK" | "PROMPT_INJECTION" | "PROMPT_LEAKAGE" | (string & {});
export interface GuardrailChecksPromptAttackCategoryConfig {
    category: GuardrailChecksPromptAttackCategory;
}
export type GuardrailChecksPromptAttackCategoryConfigList = GuardrailChecksPromptAttackCategoryConfig[];
export interface GuardrailChecksPromptAttackConfig {
    categories: GuardrailChecksPromptAttackCategoryConfig[];
}
export type GuardrailChecksSensitiveInformationEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export interface GuardrailChecksSensitiveInformationEntityConfig {
    type: GuardrailChecksSensitiveInformationEntityType;
}
export type GuardrailChecksSensitiveInformationEntityConfigList = GuardrailChecksSensitiveInformationEntityConfig[];
export interface GuardrailChecksSensitiveInformationConfig {
    entities: GuardrailChecksSensitiveInformationEntityConfig[];
}
export interface GuardrailChecksConfig {
    contentFilter?: GuardrailChecksContentFilterConfig | undefined;
    promptAttack?: GuardrailChecksPromptAttackConfig | undefined;
    sensitiveInformation?: GuardrailChecksSensitiveInformationConfig | undefined;
}
export interface InvokeGuardrailChecksRequest {
    messages: GuardrailChecksMessage[];
    checks: GuardrailChecksConfig;
}
export interface GuardrailChecksContentFilterResultEntry {
    category: GuardrailChecksContentFilterCategory;
    severityScore: number;
}
export type GuardrailChecksContentFilterResultList = GuardrailChecksContentFilterResultEntry[];
export interface GuardrailChecksContentFilterResult {
    results: GuardrailChecksContentFilterResultEntry[];
}
export interface GuardrailChecksPromptAttackResultEntry {
    category: GuardrailChecksPromptAttackCategory;
    severityScore: number;
}
export type GuardrailChecksPromptAttackResultList = GuardrailChecksPromptAttackResultEntry[];
export interface GuardrailChecksPromptAttackResult {
    results: GuardrailChecksPromptAttackResultEntry[];
}
export interface GuardrailChecksSensitiveInformationResultEntry {
    type: GuardrailChecksSensitiveInformationEntityType;
    confidenceScore: number;
    beginOffset: number;
    endOffset: number;
    messageIndex: number;
    contentIndex: number;
}
export type GuardrailChecksSensitiveInformationResultList = GuardrailChecksSensitiveInformationResultEntry[];
export interface GuardrailChecksSensitiveInformationResult {
    results: GuardrailChecksSensitiveInformationResultEntry[];
    truncated?: boolean | undefined;
}
export interface GuardrailChecksResults {
    contentFilter?: GuardrailChecksContentFilterResult | undefined;
    promptAttack?: GuardrailChecksPromptAttackResult | undefined;
    sensitiveInformation?: GuardrailChecksSensitiveInformationResult | undefined;
}
export interface GuardrailChecksContentFilterUsage {
    textUnits: number;
}
export interface GuardrailChecksPromptAttackUsage {
    textUnits: number;
}
export interface GuardrailChecksSensitiveInformationUsage {
    textUnits: number;
}
export interface GuardrailChecksUsageResults {
    contentFilter?: GuardrailChecksContentFilterUsage | undefined;
    promptAttack?: GuardrailChecksPromptAttackUsage | undefined;
    sensitiveInformation?: GuardrailChecksSensitiveInformationUsage | undefined;
}
export interface InvokeGuardrailChecksResponse {
    results: GuardrailChecksResults;
    usage: GuardrailChecksUsageResults;
}
export type MimeType = string;
export type InvokeModelIdentifier = string;
export type Trace = "ENABLED" | "DISABLED" | "ENABLED_FULL" | (string & {});
export type RequestMetadataJson = string | redacted.Redacted<string>;
export interface InvokeModelRequest {
    body?: T.StreamingInputBody | undefined;
    contentType?: string | undefined;
    accept?: string | undefined;
    modelId: string;
    trace?: Trace | undefined;
    guardrailIdentifier?: string | undefined;
    guardrailVersion?: string | undefined;
    performanceConfigLatency?: PerformanceConfigLatency | undefined;
    serviceTier?: ServiceTierType | undefined;
    requestMetadata?: string | redacted.Redacted<string> | undefined;
}
export interface InvokeModelResponse {
    body: T.StreamingOutputBody;
    contentType: string;
    performanceConfigLatency?: PerformanceConfigLatency | undefined;
    serviceTier?: ServiceTierType | undefined;
}
export type PartBody = Uint8Array | redacted.Redacted<Uint8Array>;
export interface BidirectionalInputPayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export type InvokeModelWithBidirectionalStreamInput = {
    chunk: BidirectionalInputPayloadPart;
};
export interface InvokeModelWithBidirectionalStreamRequest {
    modelId: string;
    body: stream.Stream<InvokeModelWithBidirectionalStreamInput, Error, never>;
}
export interface BidirectionalOutputPayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export type InvokeModelWithBidirectionalStreamOutput = {
    chunk: BidirectionalOutputPayloadPart;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException: InternalServerException;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException: ValidationException;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException: ThrottlingException;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException: ModelTimeoutException;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException: ServiceUnavailableException;
};
export interface InvokeModelWithBidirectionalStreamResponse {
    body: stream.Stream<InvokeModelWithBidirectionalStreamOutput, Error, never>;
}
export interface InvokeModelWithResponseStreamRequest {
    body?: T.StreamingInputBody | undefined;
    contentType?: string | undefined;
    accept?: string | undefined;
    modelId: string;
    trace?: Trace | undefined;
    guardrailIdentifier?: string | undefined;
    guardrailVersion?: string | undefined;
    performanceConfigLatency?: PerformanceConfigLatency | undefined;
    serviceTier?: ServiceTierType | undefined;
    requestMetadata?: string | redacted.Redacted<string> | undefined;
}
export interface PayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export type ResponseStream = {
    chunk: PayloadPart;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException: InternalServerException;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException: ValidationException;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException: ThrottlingException;
    modelTimeoutException?: undefined;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException: ModelTimeoutException;
    serviceUnavailableException?: undefined;
} | {
    chunk?: undefined;
    internalServerException?: undefined;
    modelStreamErrorException?: undefined;
    validationException?: undefined;
    throttlingException?: undefined;
    modelTimeoutException?: undefined;
    serviceUnavailableException: ServiceUnavailableException;
};
export interface InvokeModelWithResponseStreamResponse {
    body: stream.Stream<ResponseStream, Error, never>;
    contentType: string;
    performanceConfigLatency?: PerformanceConfigLatency | undefined;
    serviceTier?: ServiceTierType | undefined;
}
export type MaxResults = number;
export type PaginationToken = string;
export type SortAsyncInvocationBy = "SubmissionTime" | (string & {});
export type SortOrder = "Ascending" | "Descending" | (string & {});
export interface ListAsyncInvokesRequest {
    submitTimeAfter?: Date | undefined;
    submitTimeBefore?: Date | undefined;
    statusEquals?: AsyncInvokeStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortAsyncInvocationBy | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface AsyncInvokeSummary {
    invocationArn: string;
    modelArn: string;
    clientRequestToken?: string | undefined;
    status?: AsyncInvokeStatus | undefined;
    failureMessage?: string | redacted.Redacted<string> | undefined;
    submitTime: Date;
    lastModifiedTime?: Date | undefined;
    endTime?: Date | undefined;
    outputDataConfig: AsyncInvokeOutputDataConfig;
}
export type AsyncInvokeSummaries = AsyncInvokeSummary[];
export interface ListAsyncInvokesResponse {
    nextToken?: string | undefined;
    asyncInvokeSummaries?: AsyncInvokeSummary[] | undefined;
}
export type AsyncInvokeIdentifier = string;
export type ModelInputPayload = unknown;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface StartAsyncInvokeRequest {
    clientRequestToken?: string | undefined;
    modelId: string;
    modelInput: any;
    outputDataConfig: AsyncInvokeOutputDataConfig;
    tags?: Tag[] | undefined;
}
export interface StartAsyncInvokeResponse {
    invocationArn: string;
}
export type ApplyGuardrailError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to apply a guardrail.
 *
 * For troubleshooting some of the common errors you might encounter when using the `ApplyGuardrail` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const applyGuardrail: API.OperationMethod<ApplyGuardrailRequest & RegionInput, ApplyGuardrailResponse, ApplyGuardrailError, Credentials | HttpClient.HttpClient>;
export type ConverseError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends messages to the specified Amazon Bedrock model. `Converse` provides a consistent interface that works with all models that support messages. This allows you to write code once and use it with different models. If a model has unique inference parameters, you can also pass those unique parameters to the model.
 *
 * Amazon Bedrock doesn't store any text, images, or documents that you provide as content. The data is only used to generate the response.
 *
 * You can submit a prompt by including it in the `messages` field, specifying the `modelId` of a foundation model or inference profile to run inference on it, and including any other fields that are relevant to your use case.
 *
 * You can also submit a prompt from Prompt management by specifying the ARN of the prompt version and including a map of variables to values in the `promptVariables` field. You can append more messages to the prompt by using the `messages` field. If you use a prompt from Prompt management, you can't include the following fields in the request: `additionalModelRequestFields`, `inferenceConfig`, `system`, or `toolConfig`. Instead, these fields must be defined through Prompt management. For more information, see Use a prompt from Prompt management.
 *
 * For information about the Converse API, see *Use the Converse API* in the *Amazon Bedrock User Guide*. To use a guardrail, see *Use a guardrail with the Converse API* in the *Amazon Bedrock User Guide*. To use a tool with a model, see *Tool use (Function calling)* in the *Amazon Bedrock User Guide*
 *
 * For example code, see *Converse API examples* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the base inference actions (InvokeModel and InvokeModelWithResponseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `Converse` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const converse: API.OperationMethod<ConverseRequest & RegionInput, ConverseResponse, ConverseError, Credentials | HttpClient.HttpClient>;
export type ConverseStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends messages to the specified Amazon Bedrock model and returns the response in a stream. `ConverseStream` provides a consistent API that works with all Amazon Bedrock models that support messages. This allows you to write code once and use it with different models. Should a model have unique inference parameters, you can also pass those unique parameters to the model.
 *
 * To find out if a model supports streaming, call GetFoundationModel and check the `responseStreamingSupported` field in the response.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `ConverseStream`.
 *
 * Amazon Bedrock doesn't store any text, images, or documents that you provide as content. The data is only used to generate the response.
 *
 * You can submit a prompt by including it in the `messages` field, specifying the `modelId` of a foundation model or inference profile to run inference on it, and including any other fields that are relevant to your use case.
 *
 * You can also submit a prompt from Prompt management by specifying the ARN of the prompt version and including a map of variables to values in the `promptVariables` field. You can append more messages to the prompt by using the `messages` field. If you use a prompt from Prompt management, you can't include the following fields in the request: `additionalModelRequestFields`, `inferenceConfig`, `system`, or `toolConfig`. Instead, these fields must be defined through Prompt management. For more information, see Use a prompt from Prompt management.
 *
 * For information about the Converse API, see *Use the Converse API* in the *Amazon Bedrock User Guide*. To use a guardrail, see *Use a guardrail with the Converse API* in the *Amazon Bedrock User Guide*. To use a tool with a model, see *Tool use (Function calling)* in the *Amazon Bedrock User Guide*
 *
 * For example code, see *Conversation streaming example* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModelWithResponseStream` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the base inference actions (InvokeModel and InvokeModelWithResponseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `ConverseStream` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const converseStream: API.OperationMethod<ConverseStreamRequest & RegionInput, ConverseStreamResponse, ConverseStreamError, Credentials | HttpClient.HttpClient>;
export type CountTokensError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the token count for a given inference request. This operation helps you estimate token usage before sending requests to foundation models by returning the token count that would be used if the same input were sent to the model in an inference request.
 *
 * Token counting is model-specific because different models use different tokenization strategies. The token count returned by this operation will match the token count that would be charged if the same input were sent to the model in an `InvokeModel` or `Converse` request.
 *
 * You can use this operation to:
 *
 * - Estimate costs before sending inference requests.
 *
 * - Optimize prompts to fit within token limits.
 *
 * - Plan for token usage in your applications.
 *
 * This operation accepts the same input formats as `InvokeModel` and `Converse`, allowing you to count tokens for both raw text inputs and structured conversation formats.
 *
 * The following operations are related to `CountTokens`:
 *
 * - InvokeModel - Sends inference requests to foundation models
 *
 * - Converse - Sends conversation-based inference requests to foundation models
 */
export declare const countTokens: API.OperationMethod<CountTokensRequest & RegionInput, CountTokensResponse, CountTokensError, Credentials | HttpClient.HttpClient>;
export type GetAsyncInvokeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve information about an asynchronous invocation.
 */
export declare const getAsyncInvoke: API.OperationMethod<GetAsyncInvokeRequest & RegionInput, GetAsyncInvokeResponse, GetAsyncInvokeError, Credentials | HttpClient.HttpClient>;
export type InvokeGuardrailChecksError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Evaluates messages against inline guardrail checks. You specify the check configurations directly in the request, and Amazon Bedrock returns per-check results with severity or confidence scores.
 */
export declare const invokeGuardrailChecks: API.OperationMethod<InvokeGuardrailChecksRequest & RegionInput, InvokeGuardrailChecksResponse, InvokeGuardrailChecksError, Credentials | HttpClient.HttpClient>;
export type InvokeModelError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes the specified Amazon Bedrock model to run inference using the prompt and inference parameters provided in the request body. You use model inference to generate text, images, and embeddings.
 *
 * For example code, see *Invoke model code examples* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `InvokeModel` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const invokeModel: API.OperationMethod<InvokeModelRequest & RegionInput, InvokeModelResponse, InvokeModelError, Credentials | HttpClient.HttpClient>;
export type InvokeModelWithBidirectionalStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelStreamErrorException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke the specified Amazon Bedrock model to run inference using the bidirectional stream. The response is returned in a stream that remains open for 8 minutes. A single session can contain multiple prompts and responses from the model. The prompts to the model are provided as audio files and the model's responses are spoken back to the user and transcribed.
 *
 * It is possible for users to interrupt the model's response with a new prompt, which will halt the response speech. The model will retain contextual awareness of the conversation while pivoting to respond to the new prompt.
 */
export declare const invokeModelWithBidirectionalStream: API.OperationMethod<InvokeModelWithBidirectionalStreamRequest & RegionInput, InvokeModelWithBidirectionalStreamResponse, InvokeModelWithBidirectionalStreamError, Credentials | HttpClient.HttpClient>;
export type InvokeModelWithResponseStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelStreamErrorException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke the specified Amazon Bedrock model to run inference using the prompt and inference parameters provided in the request body. The response is returned in a stream.
 *
 * To see if a model supports streaming, call GetFoundationModel and check the `responseStreamingSupported` field in the response.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `InvokeModelWithResponseStream`.
 *
 * For example code, see *Invoke model with streaming code example* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permissions to perform the `bedrock:InvokeModelWithResponseStream` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `InvokeModelWithResponseStream` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const invokeModelWithResponseStream: API.OperationMethod<InvokeModelWithResponseStreamRequest & RegionInput, InvokeModelWithResponseStreamResponse, InvokeModelWithResponseStreamError, Credentials | HttpClient.HttpClient>;
export type ListAsyncInvokesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists asynchronous invocations.
 */
export declare const listAsyncInvokes: API.PaginatedOperationMethod<ListAsyncInvokesRequest & RegionInput, ListAsyncInvokesResponse, ListAsyncInvokesError, Credentials | HttpClient.HttpClient, AsyncInvokeSummary>;
export type StartAsyncInvokeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an asynchronous invocation.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 */
export declare const startAsyncInvoke: API.OperationMethod<StartAsyncInvokeRequest & RegionInput, StartAsyncInvokeResponse, StartAsyncInvokeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-runtime.d.ts.map