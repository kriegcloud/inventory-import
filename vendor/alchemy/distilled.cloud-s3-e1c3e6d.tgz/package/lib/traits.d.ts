import type { SigningError } from "@distilled.cloud/aws4signer";
import type { InvalidInput } from "@distilled.cloud/core/protocol-http";
import * as S from "@distilled.cloud/core/schema-lite-typed";
import { all, type Annotation } from "@distilled.cloud/core/trait";
import * as Effect from "effect/Effect";
import type * as HttpClientRequest from "effect/http/HttpClientRequest";
import type * as AST from "effect/SchemaAST";
import * as Stream from "effect/Stream";
import type { Protocol, ProtocolImpl } from "./client/protocol.ts";
import type { Request as ProtocolRequest } from "./client/request.ts";
import type { ResolvedCredentials } from "./credentials.ts";
import { ErrorMessage, errorMessageSymbol } from "./error-message.ts";
/**
 * A protocol whose implementation module loads on the first request.
 *
 * Every generated service module names its wire protocol through these
 * traits, so importing them statically loaded all five protocol
 * implementations (with XML, event stream and customization code) into
 * every program: about 750 KB of heap, of which one protocol is used.
 * Consumers get the implementation's handler through `ready`.
 */
export declare const lazyProtocol: (load: () => Promise<ProtocolImpl>) => Protocol;
import type { RuleSetObject } from "./rules-engine/expression.ts";
export { all, type Annotation };
export { ErrorMessage, errorMessageSymbol };
/**
 * Any type that has an .annotate() method returning itself.
 * This includes Schema.Schema and Schema.PropertySignature (from S.optional).
 */
export type Annotatable = {
    annotate(annotations: any): Annotatable;
};
/** smithy.api#httpHeader - Bind member to an HTTP header */
export declare const httpHeaderSymbol: symbol;
export declare const HttpHeader: (name: string) => Annotation;
/** smithy.api#httpPayload - Bind member to the HTTP body */
export declare const httpPayloadSymbol: symbol;
export declare const HttpPayload: () => Annotation;
/** smithy.api#httpLabel - Bind member to a URI label (path parameter) */
export declare const httpLabelSymbol: symbol;
/**
 * HttpLabel trait - binds a member to a URI label (path parameter).
 * @param labelName - Optional. The name to use in the URI template. If provided, this name
 *                    is used for path substitution instead of the encoded property name.
 *                    This is needed when the property also has a JsonName that differs
 *                    from the URI template placeholder.
 */
export declare const HttpLabel: (labelName?: string) => Annotation;
/** smithy.api#httpQuery - Bind member to a query string parameter */
export declare const httpQuerySymbol: symbol;
export declare const HttpQuery: (name: string) => Annotation;
/** smithy.api#httpQueryParams - Bind map members to query string parameters */
export declare const httpQueryParamsSymbol: "distilled-aws/http-query-params";
export declare const HttpQueryParams: () => Annotation;
/** smithy.api#httpPrefixHeaders - Bind map members to prefixed HTTP headers */
export declare const httpPrefixHeadersSymbol: "distilled-aws/http-prefix-headers";
export declare const HttpPrefixHeaders: (prefix: string) => Annotation;
/**
 * smithy.api#mediaType - The media type of a header or payload member's
 * value (from its target shape): a payload's Content-Type.
 */
export declare const mediaTypeSymbol: "distilled-aws/media-type";
export declare const MediaType: (mediaType: string) => Annotation;
/** smithy.api#httpResponseCode - Bind member to the HTTP response status code */
export declare const httpResponseCodeSymbol: symbol;
export declare const HttpResponseCode: () => Annotation;
/** smithy.api#xmlName - Custom XML element name */
export declare const xmlNameSymbol: "distilled-aws/xml-name";
export declare const XmlName: (name: string) => Annotation;
/** smithy.api#xmlFlattened - Flatten list/map (no wrapper element) */
export declare const xmlFlattenedSymbol: "distilled-aws/xml-flattened";
export declare const XmlFlattened: () => Annotation;
/** smithy.api#sparse - List/map may contain null values */
export declare const sparseSymbol: "distilled-aws/sparse";
export declare const Sparse: () => Annotation;
/** smithy.api#xmlAttribute - Serialize as XML attribute instead of element */
export declare const xmlAttributeSymbol: "distilled-aws/xml-attribute";
export declare const XmlAttribute: () => Annotation;
/** smithy.api#xmlNamespace - XML namespace URI for the element */
export declare const xmlNamespaceSymbol: "distilled-aws/xml-namespace";
/** smithy.api#xmlNamespace `prefix` - the namespace is declared as `xmlns:prefix` */
export declare const xmlNamespacePrefixSymbol: "distilled-aws/xml-namespace-prefix";
export declare const XmlNamespace: (uri: string, prefix?: string) => Annotation;
/** smithy.api#jsonName - Custom JSON key name */
export declare const jsonNameSymbol: "distilled-aws/json-name";
/**
 * JsonName trait - uses Effect Schema's fromKey for automatic key renaming.
 *
 * When applied to a PropertySignature (from S.optional), pipes S.fromKey.
 * When applied to a Schema, wraps in S.propertySignature and pipes S.fromKey.
 *
 * This allows Effect Schema's encode/decode to handle key renaming automatically,
 * eliminating the need for manual renameKeys logic in protocols.
 */
export declare const JsonName: (name: string) => <A extends Annotatable>(schema: A) => A;
/** aws.protocols#ec2QueryName - Custom query key name for EC2 protocol */
export declare const ec2QueryNameSymbol: "distilled-aws/aws.protocols#ec2QueryName";
export declare const Ec2QueryName: (name: string) => Annotation;
/**
 * DateFromString - String <-> Date transformation via ISO 8601.
 * Use this instead of bare S.Date when the wire format is a string.
 */
export declare const DateFromString: S.Schema<Date>;
/** smithy.api#timestampFormat - Timestamp serialization format */
export declare const timestampFormatSymbol: "distilled-aws/timestamp-format";
export type TimestampFormatType = "date-time" | "http-date" | "epoch-seconds";
/**
 * TimestampFormat trait - applies both annotation and transform.
 * When piped to S.Date, transforms to the appropriate wire format.
 *
 * - "epoch-seconds": Date <-> number (Unix timestamp)
 * - "http-date": Date <-> string (RFC 7231)
 * - "date-time": Date <-> string (ISO 8601)
 */
export declare const TimestampFormat: (format: TimestampFormatType) => <A extends S.Top>(schema: A) => A;
/** smithy.api#http - HTTP binding for an operation (applied to request schema) */
export declare const httpSymbol: symbol;
export interface HttpTrait {
    method: "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "OPTIONS";
    uri: string;
}
export declare const Http: (trait: HttpTrait) => Annotation;
/** aws.api#service - AWS service identification */
export declare const awsApiServiceSymbol: "distilled-aws/aws.api#service";
export interface AwsApiServiceTrait {
    sdkId: string;
    arnNamespace?: string;
    cloudFormationName?: string;
    cloudTrailEventSource?: string;
    endpointPrefix?: string;
    /** The service shape name from the Smithy model (e.g., "TrentService" for KMS) - used for X-Amz-Target */
    serviceShapeName?: string;
}
export declare const AwsApiService: (trait: AwsApiServiceTrait) => Annotation;
/** aws.auth#sigv4 - SigV4 authentication configuration */
export declare const awsAuthSigv4Symbol: "distilled-aws/aws.auth#sigv4";
export interface AwsAuthSigv4Trait {
    name: string;
}
export declare const AwsAuthSigv4: (trait: AwsAuthSigv4Trait) => Annotation;
/**
 * Legacy Signature Version 2 authentication. SimpleDB (2009-04-15) is the
 * sole remaining SigV2-only service: its endpoint rejects SigV4
 * Authorization headers outright (`AuthFailure: access credentials are
 * missing`). SigV2 auth parameters ride in the form-encoded request body
 * (`AWSAccessKeyId`, `SignatureVersion=2`, `SignatureMethod=HmacSHA256`,
 * `Timestamp`, `SecurityToken`, `Signature`) rather than in headers.
 */
export declare const awsAuthSigv2Symbol: "distilled-aws/aws.auth#sigv2";
export interface AwsAuthSigv2Trait {
    name: string;
    /**
     * The signer, carried by the trait so only SigV2 services bundle it. The
     * trait's constructor ships with `@distilled.cloud/aws`.
     */
    readonly sign: (request: ProtocolRequest, endpoint: string, fullPath: string, credentials: ResolvedCredentials) => Effect.Effect<HttpClientRequest.HttpClientRequest, SigningError>;
}
/** Protocol annotation value - includes trait data and implementation */
export interface ProtocolAnnotationValue {
    protocol: Protocol;
}
/** Common symbol for discovering the protocol from any annotation */
export declare const protocolSymbol: "distilled-aws/protocol";
/**
 * Helper to create protocol annotations with embedded implementation.
 */
export declare function makeProtocolAnnotation<T extends object = object>(sym: string, protocol: Protocol, trait?: T): Annotation;
/** aws.protocols#restXml */
export declare const awsProtocolsRestXmlSymbol: "distilled-aws/aws.protocols#restXml";
export interface AwsProtocolsRestXmlTrait {
    noErrorWrapping?: boolean;
}
export declare const AwsProtocolsRestXml: (trait?: AwsProtocolsRestXmlTrait) => Annotation;
/** Middleware function type - applied to requests */
export type MiddlewareFn = (schema: S.Top, request: ProtocolRequest) => Effect.Effect<ProtocolRequest, InvalidInput>;
/** Middleware annotation value - includes trait data and implementation */
export interface MiddlewareAnnotationValue {
    middleware: MiddlewareFn;
}
/** Common symbol for discovering middleware from annotations */
export declare const middlewareSymbol: "distilled-aws/middleware";
/** aws.protocols#httpChecksum - HTTP checksum configuration with embedded middleware */
export declare const awsProtocolsHttpChecksumSymbol: "distilled-aws/aws.protocols#httpChecksum";
export interface AwsProtocolsHttpChecksumTrait {
    requestAlgorithmMember?: string;
    requestChecksumRequired?: boolean;
    responseAlgorithms?: string[];
}
export declare const AwsProtocolsHttpChecksum: (trait: AwsProtocolsHttpChecksumTrait) => Annotation;
/** smithy.api#requestCompression - gzip the request body, with embedded middleware */
export declare const requestCompressionSymbol: "distilled-aws/smithy.api#requestCompression";
export interface RequestCompressionTrait {
    encodings: string[];
}
export declare const RequestCompression: (trait: RequestCompressionTrait) => Annotation;
/** Service API version (from service shape's version property) */
export declare const serviceVersionSymbol: "distilled-aws/service-version";
export declare const ServiceVersion: (version: string) => Annotation;
/** smithy.rules#endpointRuleSet - Endpoint resolution rule set (legacy JSON) */
export declare const endpointRuleSetSymbol: "distilled-aws/smithy.rules#endpointRuleSet";
export declare const EndpointRuleSet: (ruleSet: unknown) => Annotation;
/** Endpoint resolver result type */
export type EndpointResolverResult = {
    type: "endpoint";
    endpoint: {
        url: string;
        properties: Record<string, unknown>;
        headers: Record<string, string[]>;
    };
} | {
    type: "error";
    message: string;
};
/** Runtime helpers for endpoint resolution */
export interface EndpointResolverHelpers {
    partition: (region: unknown) => unknown;
    parseArn: (value: unknown) => unknown;
    isVirtualHostableS3Bucket: (value: unknown, allowSubDomains?: unknown) => boolean;
    parseURL: (url: unknown) => unknown;
    substring: (input: unknown, start: unknown, stop: unknown, reverse: unknown) => unknown;
    uriEncode: (value: unknown) => unknown;
    isValidHostLabel: (value: unknown, allowSubDomains: unknown) => boolean;
    getAttr: (value: unknown, path: string) => unknown;
    resolveTemplates: <T>(value: T) => T;
}
/** Endpoint resolver function type */
export type EndpointResolverFn = (params: Record<string, unknown>, helpers: EndpointResolverHelpers) => EndpointResolverResult;
/**
 * What the rule set resolves to when `Region` is its only parameter, for
 * every region partitions.json names: the `endpoint` object as JSON, with
 * `{R}` for the region and `{D}` for its partition's DNS suffix. The
 * generator evaluates the rules for each named region and lists the regions
 * the template does not reproduce in `exceptions`; those, and regions named
 * by no partition, run the rules.
 */
export interface EndpointTemplate {
    readonly template: string;
    readonly exceptions: ReadonlyArray<string>;
}
/** Endpoint resolver - compiled function for endpoint resolution */
export declare const endpointResolverSymbol: "distilled-aws/endpoint-resolver";
export declare const EndpointResolver: (resolver: EndpointResolverFn, template?: string, exceptions?: ReadonlyArray<string>) => Annotation;
/** The Region-only endpoint template the generator attached to a resolver. */
export declare const getEndpointTemplate: (resolver: EndpointResolverFn) => EndpointTemplate | undefined;
/** smithy.rules#clientContextParams - Client-level endpoint parameters */
export declare const clientContextParamsSymbol: "distilled-aws/smithy.rules#clientContextParams";
export interface ClientContextParamDefinition {
    type: string;
    documentation?: string;
}
export declare const ClientContextParams: (params: Record<string, ClientContextParamDefinition>) => Annotation;
/** smithy.rules#contextParam - Endpoint routing context parameter */
export declare const contextParamSymbol: "distilled-aws/context-param";
export declare const ContextParam: (name: string) => Annotation;
/** smithy.rules#staticContextParams - Static endpoint parameters for an operation */
export declare const staticContextParamsSymbol: "distilled-aws/smithy.rules#staticContextParams";
export type StaticContextParamsDefinition = Record<string, {
    value: unknown;
}>;
export declare const StaticContextParams: (params: StaticContextParamsDefinition) => Annotation;
/** smithy.api#hostLabel - Bind member to a label in the endpoint hostPrefix */
export declare const hostLabelSymbol: "distilled-aws/host-label";
export declare const HostLabel: () => Annotation;
/** smithy.api#httpError - Custom HTTP status code for error responses */
export declare const httpErrorSymbol: "distilled-aws/http-error";
export declare const HttpError: (statusCode: number) => Annotation;
/** smithy.api#retryable - Indicates that an error MAY be retried by the client */
export declare const retryableSymbol: "distilled-aws/retryable";
export interface RetryableTrait {
    throttling?: boolean;
}
export declare const Retryable: (trait?: RetryableTrait) => Annotation;
/** smithy.api#httpChecksumRequired - Indicates operation requires Content-MD5 checksum */
export declare const httpChecksumRequiredSymbol: "distilled-aws/http-checksum-required";
export declare const HttpChecksumRequired: () => Annotation;
/** aws.protocols#awsQueryError - Custom error Code and HTTP response code for awsQuery protocol */
export declare const awsQueryErrorSymbol: "distilled-aws/aws.protocols#awsQueryError";
export interface AwsQueryErrorTrait {
    code: string;
    httpResponseCode: number;
}
export declare const AwsQueryError: (trait: AwsQueryErrorTrait) => Annotation;
/**
 * distilled patch trait - synthesizes a NEW error class from an existing wire
 * error plus a message predicate. Some AWS services overload a single wire
 * error (e.g. X-Ray's InvalidRequestException) for semantically distinct
 * failures that are only distinguishable by message text. The response parser
 * checks synthetic matchers BEFORE the plain wire-code lookup so the
 * synthetic tag specializes the base error.
 */
export declare const syntheticErrorSymbol: "distilled-aws/synthetic-error";
export interface SyntheticErrorTrait {
    /** The wire error code this synthetic error derives from (e.g., "InvalidRequestException") */
    from: string;
    /**
     * Message predicate: a plain string is an exact match; the object form
     * supports substring (`includes`) and regular-expression (`matches`)
     * predicates.
     */
    message: string | {
        includes?: string;
        matches?: string;
    };
}
export declare const SyntheticError: (trait: SyntheticErrorTrait) => Annotation;
/** aws.customizations#s3UnwrappedXmlOutput - S3 output not wrapped in operation-level XML node */
export declare const s3UnwrappedXmlOutputSymbol: "distilled-aws/aws.customizations#s3UnwrappedXmlOutput";
export declare const S3UnwrappedXmlOutput: () => Annotation;
/**
 * smithy.api#idempotencyToken - Marks a member as an idempotency token.
 * When set, the SDK will automatically generate a UUID if the value is not provided.
 */
export declare const idempotencyTokenSymbol: "distilled-aws/idempotency-token";
export declare const IdempotencyToken: () => Annotation;
/** Check if a PropertySignature has the idempotencyToken annotation */
export declare const hasIdempotencyToken: (prop: AST.PropertySignature) => boolean;
/** Check if an AST has the idempotencyToken annotation */
export declare const isIdempotencyToken: (ast: AST.AST) => boolean;
/**
 * Smithy blob type - binary data that encodes to base64 on the wire.
 * Used for non-streaming blobs in request/response bodies.
 */
export declare const Blob: S.Schema<Uint8Array<ArrayBufferLike>>;
/** smithy.api#streaming - Marks a type as streaming/blob (raw body, not serialized) */
export declare const streamingSymbol: "distilled-aws/streaming";
/**
 * Streaming trait - behavior depends on what it's applied to:
 * - On a blob: marks it as a streaming body (raw bytes)
 * - On a union: transforms it into a Stream of those event types
 */
export declare const Streaming: {
    <A>(schema: S.Schema<A> & {
        ast: {
            _tag: "Union";
        };
    }): S.Schema<Stream.Stream<A, Error, never>>;
    <A>(schema: S.Schema<A>): S.Schema<A>;
    (): <A>(schema: S.Schema<A>) => S.Schema<Stream.Stream<A, Error, never>> | S.Schema<A>;
};
/** Check if an AST represents a streaming/blob type */
export declare const isStreamingType: (ast: AST.AST) => boolean;
export declare const requiresLengthSymbol: "distilled-aws/requires-length";
export declare const RequiresLength: () => Annotation;
export declare const hasRequiresLength: (ast: AST.AST) => boolean;
/**
 * Streaming input body - accepts multiple source types.
 */
export type StreamingInputBody = string | Uint8Array<ArrayBufferLike> | ArrayBuffer | globalThis.Blob | ReadableStream<Uint8Array<ArrayBufferLike>> | Stream.Stream<Uint8Array<ArrayBufferLike>, unknown, unknown>;
/**
 * Schema for streaming input bodies.
 */
export declare const StreamingInput: import("effect/Schema").declare<StreamingInputBody, StreamingInputBody>;
/**
 * Streaming output body - always Effect Stream for composability.
 */
export declare const StreamingOutput: import("effect/Schema").declare<Stream.Stream<Uint8Array<ArrayBufferLike>, Error, never>, Stream.Stream<Uint8Array<ArrayBufferLike>, Error, never>>;
export type StreamingOutputBody = Stream.Stream<Uint8Array<ArrayBufferLike>, Error, never>;
/** Legacy StreamBody type */
export type StreamBody = string | Uint8Array<ArrayBufferLike> | ReadableStream;
export declare const StreamBody: () => import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").instanceOf<Uint8Array<ArrayBufferLike>, unknown>, import("effect/Schema").instanceOf<ReadableStream<unknown>, unknown>]>;
export declare const eventHeaderSymbol: "distilled-aws/event-header";
export declare const EventHeader: () => Annotation;
export declare const eventPayloadSymbol: "distilled-aws/event-payload";
export declare const EventPayload: () => Annotation;
/**
 * The event stream codec (binary framing, CRC32, payload parsers). It loads
 * on the first event stream, and only bundles that keep an event stream
 * schema reference it: `EventStream` / `InputEventStream` register the
 * loader for their event schema, and the protocols find it from there.
 */
export interface EventStreamCodec {
    readonly parseEventStream: typeof import("./eventstream/parser.ts").parseEventStream;
    readonly parseEventStreamToUnion: typeof import("./eventstream/parser.ts").parseEventStreamToUnion;
    readonly serializeInputEventStreamWithSchema: typeof import("./eventstream/serializer.ts").serializeInputEventStreamWithSchema;
}
/** A stream built by the event stream codec registered for `eventSchema`. */
export declare const eventStreamWith: <A, E>(eventSchema: unknown, f: (codec: EventStreamCodec) => Stream.Stream<A, E>) => Stream.Stream<A, E>;
/**
 * A request body built by the event stream codec registered for
 * `eventSchema`. The codec loads in the calling operation's fiber, so a
 * failed load fails the call with its `SdkError`.
 */
export declare const eventStreamBody: (eventSchema: unknown, f: (codec: EventStreamCodec) => Stream.Stream<Uint8Array, unknown>) => Effect.Effect<Stream.Stream<Uint8Array, unknown>>;
export declare const EventStream: <A>(eventSchema: S.Schema<A>) => S.Schema<Stream.Stream<A, Error, never>>;
export declare const inputEventStreamSymbol: "distilled-aws/input-event-stream";
export declare const InputEventStream: <A>(eventSchema: S.Schema<A>, eventPayloadMap?: Record<string, string>) => S.Schema<Stream.Stream<A, Error, never>>;
export declare const isInputEventStream: (ast: AST.AST) => boolean;
export declare const isOutputEventStream: (ast: AST.AST) => boolean;
export declare const getEventSchema: (ast: AST.AST) => S.Schema<unknown> | undefined;
export declare const getEventPayloadMap: (ast: AST.AST) => Record<string, string> | undefined;
/** How an `eventPayload` member is written to the frame payload. */
export type EventPayloadKind = "blob" | "string" | "structure";
/** Members of one event struct bound to the frame payload and headers. */
export interface EventMemberBindings {
    readonly payload?: {
        readonly name: string;
        readonly kind: EventPayloadKind;
    };
    readonly headers: readonly string[];
}
/**
 * Derive, per event type, which members of an event stream's event structs
 * carry `T.EventPayload()` / `T.EventHeader()` annotations, from the event
 * union schema (`S.Union([S.Struct({ EventName: EventStruct }), ...])`).
 *
 * Smithy's `eventPayload` trait means an event's wire payload IS that single
 * member's value (raw bytes for a blob, UTF-8 for a string, JSON for a
 * structure) rather than a JSON document of the event struct, and
 * `eventHeader` members travel as frame headers.
 */
export declare const getEventMemberBindings: (eventSchema: S.Schema<unknown>) => Record<string, EventMemberBindings> | undefined;
/**
 * Derive the event-type -> payload-member map for an OUTPUT event stream from
 * its event union schema (`T.EventStream(S.Union([...]))`), so the parser
 * binds the raw payload to that member (e.g. Lambda
 * `InvokeWithResponseStream`'s `PayloadChunk.Payload`) instead of
 * JSON-parsing it into struct fields.
 */
export declare const getOutputEventPayloadMap: (eventSchema: S.Schema<unknown>) => Record<string, string> | undefined;
export declare const getAnnotation: <T>(ast: AST.AST, symbol: string | symbol) => T | undefined;
export declare const getPropAnnotation: <T>(prop: AST.PropertySignature, symbol: string | symbol) => T | undefined;
/**
 * An annotation of the member itself: on the property, or on its schema
 * through an optional wrapper, but not on the shape it targets. A
 * structure's own `@xmlName` names it only as a document root.
 */
export declare const getMemberAnnotation: <T>(prop: AST.PropertySignature, symbol: string | symbol) => T | undefined;
/**
 * An annotation of this schema node, through an optional wrapper and an
 * encoding, without entering a suspended (structure) schema.
 */
export declare const getOwnAnnotation: <T>(ast: AST.AST, symbol: string | symbol) => T | undefined;
export declare const hasPropAnnotation: (prop: AST.PropertySignature, symbol: string | symbol) => boolean;
export declare const getPropAnnotations: (prop: AST.PropertySignature) => {
    header: string | undefined;
    payload: boolean | undefined;
    label: boolean | undefined;
    query: string | undefined;
    queryParams: boolean | undefined;
    prefixHeaders: string | undefined;
    responseCode: boolean | undefined;
    xmlName: string | undefined;
};
export declare const getAnnotations: (schema: AST.AST) => {
    header: string | undefined;
    body: string | undefined;
    streamBody: boolean | undefined;
    path: string | undefined;
    xmlName: string | undefined;
};
export declare const requestBodySymbol: symbol;
export declare const hasBodyAnnotation: (ast: AST.AST) => boolean;
export declare const getXmlName: (ast: AST.AST) => string | undefined;
export declare const hasAnnotation: (ast: AST.AST, symbol: string | symbol) => boolean;
export declare const getAnnotationUnwrap: <T>(ast: AST.AST, symbol: string | symbol) => T | undefined;
export declare const getHttpHeader: (prop: AST.PropertySignature) => string | undefined;
export declare const hasHttpLabel: (prop: AST.PropertySignature) => boolean;
export declare const getHttpLabelName: (prop: AST.PropertySignature) => string | undefined;
export declare const getHttpQuery: (prop: AST.PropertySignature) => string | undefined;
export declare const hasHttpQueryParams: (prop: AST.PropertySignature) => boolean;
export declare const getHttpPrefixHeaders: (prop: AST.PropertySignature) => string | undefined;
export declare const getMediaType: (prop: AST.PropertySignature) => string | undefined;
export declare const hasHttpPayload: (prop: AST.PropertySignature) => boolean;
export declare const hasXmlAttribute: (prop: AST.PropertySignature) => boolean;
export declare const getXmlNameProp: (prop: AST.PropertySignature) => string | undefined;
export declare const hasXmlFlattened: (prop: AST.PropertySignature) => boolean;
export declare const hasSparse: (prop: AST.PropertySignature) => boolean;
export declare const isSparse: (ast: AST.AST) => boolean;
export declare const getEc2QueryName: (prop: AST.PropertySignature) => string | undefined;
export declare const getHttpTrait: (ast: AST.AST) => HttpTrait | undefined;
export declare const getAwsApiService: (ast: AST.AST) => AwsApiServiceTrait | undefined;
export declare const getAwsAuthSigv4: (ast: AST.AST) => AwsAuthSigv4Trait | undefined;
export declare const getAwsAuthSigv2: (ast: AST.AST) => AwsAuthSigv2Trait | undefined;
export declare const getServiceVersion: (ast: AST.AST) => string | undefined;
export declare const hasRestXmlProtocol: (ast: AST.AST) => boolean;
export declare const getAwsProtocolsHttpChecksum: (ast: AST.AST) => AwsProtocolsHttpChecksumTrait | undefined;
export declare const getRequestCompression: (ast: AST.AST) => RequestCompressionTrait | undefined;
export declare const hasHttpChecksumRequired: (ast: AST.AST) => boolean;
export declare const getAwsQueryError: (ast: AST.AST) => AwsQueryErrorTrait | undefined;
/** smithy.api#httpError status code declared on an error shape */
export declare const getHttpError: (ast: AST.AST) => number | undefined;
export declare const getSyntheticError: (ast: AST.AST) => SyntheticErrorTrait | undefined;
/** True when this member is the error shape's canonical message. */
export declare const hasErrorMessage: (prop: AST.PropertySignature) => boolean;
export declare const getTimestampFormat: (prop: AST.PropertySignature) => TimestampFormatType | undefined;
export declare const getTimestampFormatFromAST: (ast: AST.AST) => TimestampFormatType | undefined;
export declare const hasS3UnwrappedXmlOutput: (ast: AST.AST) => boolean;
export declare const getEndpointRuleSet: (ast: AST.AST) => RuleSetObject | undefined;
export declare const getEndpointResolver: (ast: AST.AST) => EndpointResolverFn | undefined;
export declare const getClientContextParams: (ast: AST.AST) => Record<string, ClientContextParamDefinition> | undefined;
export declare const getContextParam: (prop: AST.PropertySignature) => string | undefined;
export declare const getStaticContextParams: (ast: AST.AST) => StaticContextParamsDefinition | undefined;
export declare const getProtocol: (ast: AST.AST) => Protocol | undefined;
export declare const getMiddleware: (ast: AST.AST) => MiddlewareFn[];
export interface PaginatedTrait {
    inputToken: string;
    outputToken: string;
    items?: string;
    pageSize?: string;
}
export declare const getPath: (obj: unknown, path: string) => unknown;
//# sourceMappingURL=traits.d.ts.map