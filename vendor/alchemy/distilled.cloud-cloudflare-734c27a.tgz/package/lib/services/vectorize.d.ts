import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Gone_base: S.TaggedErrorClass<"Gone", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Gone extends /*@__PURE__*/ Gone_base {
}
declare const IndexAlreadyExists_base: S.TaggedErrorClass<"IndexAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class IndexAlreadyExists extends /*@__PURE__*/ IndexAlreadyExists_base {
}
declare const IndexInvalidConfig_base: S.TaggedErrorClass<"IndexInvalidConfig", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class IndexInvalidConfig extends /*@__PURE__*/ IndexInvalidConfig_base {
}
declare const IndexInvalidName_base: S.TaggedErrorClass<"IndexInvalidName", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class IndexInvalidName extends /*@__PURE__*/ IndexInvalidName_base {
}
declare const MetadataIndexAlreadyExists_base: S.TaggedErrorClass<"MetadataIndexAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MetadataIndexAlreadyExists extends /*@__PURE__*/ MetadataIndexAlreadyExists_base {
}
declare const MetadataIndexInvalidType_base: S.TaggedErrorClass<"MetadataIndexInvalidType", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MetadataIndexInvalidType extends /*@__PURE__*/ MetadataIndexInvalidType_base {
}
declare const MetadataIndexNotFound_base: S.TaggedErrorClass<"MetadataIndexNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MetadataIndexNotFound extends /*@__PURE__*/ MetadataIndexNotFound_base {
}
declare const NotFound_base: S.TaggedErrorClass<"NotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
export type IndexesCreateRequestConfigIndexDimensionConfigurationMetric = "cosine" | "euclidean" | "dot-product";
export interface IndexesCreateRequestConfigIndexDimensionConfiguration {
    /** Specifies the number of dimensions for the index */
    dimensions: number;
    /** Specifies the type of metric to use calculating distance. */
    metric: IndexesCreateRequestConfigIndexDimensionConfigurationMetric | (string & {});
}
export type IndexesCreateRequestConfigVectorizeIndexPresetConfigurationPreset = "@cf/baai/bge-small-en-v1.5" | "@cf/baai/bge-base-en-v1.5" | "@cf/baai/bge-large-en-v1.5" | "openai/text-embedding-ada-002" | "cohere/embed-multilingual-v2.0";
export interface IndexesCreateRequestConfigVectorizeIndexPresetConfiguration {
    /** Specifies the preset to use for the index. */
    preset: IndexesCreateRequestConfigVectorizeIndexPresetConfigurationPreset | (string & {});
}
export type IndexesCreateRequestConfig = IndexesCreateRequestConfigIndexDimensionConfiguration | IndexesCreateRequestConfigVectorizeIndexPresetConfiguration;
export interface CreateIndexRequest {
    /** Identifier */
    accountId: string;
    /** Specifies the type of configuration to use for the index. */
    config: IndexesCreateRequestConfig;
    name: string;
    /** Specifies the description of the index. */
    description?: string | undefined;
}
export type IndexesCreateResponseConfigMetric = "cosine" | "euclidean" | "dot-product";
export type IndexesCreateResponseConfigPreset = "@cf/baai/bge-small-en-v1.5" | "@cf/baai/bge-base-en-v1.5" | "@cf/baai/bge-large-en-v1.5" | "openai/text-embedding-ada-002" | "cohere/embed-multilingual-v2.0";
export interface IndexesCreateResponseConfig {
    /** Specifies the number of dimensions for the index */
    dimensions: number;
    /** Specifies the type of metric to use calculating distance. */
    metric: IndexesCreateResponseConfigMetric;
    /** Specifies the preset to use for the index. */
    preset?: IndexesCreateResponseConfigPreset | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIndexResponse {
    config?: IndexesCreateResponseConfig | null | undefined;
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdOn?: string | null | undefined;
    /** Specifies the description of the index. */
    description?: string | null | undefined;
    /** Specifies the timestamp the resource was modified as an ISO8601 string. */
    modifiedOn?: string | null | undefined;
    name?: string | null | undefined;
}
export type IndexesMetadataIndexCreateRequestIndexType = "string" | "number" | "boolean";
export interface CreateIndexMetadataIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Specifies the type of metadata property to index. */
    indexType: IndexesMetadataIndexCreateRequestIndexType | (string & {});
    /** Specifies the metadata property to index. */
    propertyName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateIndexMetadataIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null | undefined;
}
export type IndexesDeleteByIdsRequestIdsList = Array<string>;
export interface DeleteByIdsIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** A list of vector identifiers to delete from the index indicated by the path. */
    ids?: IndexesDeleteByIdsRequestIdsList | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteByIdsIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null | undefined;
}
export interface DeleteIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
}
export type DeleteIndexResponse = unknown;
export interface DeleteIndexMetadataIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Specifies the metadata property for which the index must be deleted. */
    propertyName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteIndexMetadataIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null | undefined;
}
export type IndexesGetByIdsRequestIdsList = Array<string>;
export interface GetByIdsIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** A list of vector identifiers to retrieve from the index indicated by the path. */
    ids?: IndexesGetByIdsRequestIdsList | undefined;
}
export type IndexesGetByIdsResultItemValuesList = Array<number>;
export interface IndexesGetByIdsResultItem {
    /** Identifier for a Vector */
    id?: string | null | undefined;
    metadata?: unknown | null | undefined;
    namespace?: string | null | undefined;
    values?: IndexesGetByIdsResultItemValuesList | null | undefined;
}
export type IndexesGetByIdsResultList = Array<IndexesGetByIdsResultItem>;
export type GetByIdsIndexResponse = IndexesGetByIdsResultList;
export interface GetIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
}
export type IndexesGetResponseConfigMetric = "cosine" | "euclidean" | "dot-product";
export type IndexesGetResponseConfigPreset = "@cf/baai/bge-small-en-v1.5" | "@cf/baai/bge-base-en-v1.5" | "@cf/baai/bge-large-en-v1.5" | "openai/text-embedding-ada-002" | "cohere/embed-multilingual-v2.0";
export interface IndexesGetResponseConfig {
    /** Specifies the number of dimensions for the index */
    dimensions: number;
    /** Specifies the type of metric to use calculating distance. */
    metric: IndexesGetResponseConfigMetric;
    /** Specifies the preset to use for the index. */
    preset?: IndexesGetResponseConfigPreset | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetIndexResponse {
    config?: IndexesGetResponseConfig | null | undefined;
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdOn?: string | null | undefined;
    /** Specifies the description of the index. */
    description?: string | null | undefined;
    /** Specifies the timestamp the resource was modified as an ISO8601 string. */
    modifiedOn?: string | null | undefined;
    name?: string | null | undefined;
}
export interface GetIndexInfoRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetIndexInfoResponse {
    /** Specifies the number of dimensions for the index */
    dimensions?: number | null | undefined;
    /** Specifies the timestamp the last mutation batch was processed as an ISO8601 string. */
    processedUpToDatetime?: string | null | undefined;
    /** The unique identifier for the async mutation operation containing the changeset. */
    processedUpToMutation?: string | null | undefined;
    /** Specifies the number of vectors present in the index */
    vectorCount?: number | null | undefined;
}
export type IndexesInsertRequestUnparsableBehavior = "error" | "discard";
export interface InsertIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Behavior for ndjson parse failures. */
    unparsableBehavior?: IndexesInsertRequestUnparsableBehavior | (string & {}) | undefined;
    /** Vectors as newline-delimited JSON (application/x-ndjson), one vector object per line. */
    body: Blob | Uint8Array | ArrayBuffer | string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface InsertIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null | undefined;
}
export interface ListIndexesRequest {
    /** Identifier */
    accountId: string;
}
export type IndexesListResultItemConfigMetric = "cosine" | "euclidean" | "dot-product";
export type IndexesListResultItemConfigPreset = "@cf/baai/bge-small-en-v1.5" | "@cf/baai/bge-base-en-v1.5" | "@cf/baai/bge-large-en-v1.5" | "openai/text-embedding-ada-002" | "cohere/embed-multilingual-v2.0";
export interface IndexesListResultItemConfig {
    /** Specifies the number of dimensions for the index */
    dimensions: number;
    /** Specifies the type of metric to use calculating distance. */
    metric: IndexesListResultItemConfigMetric;
    /** Specifies the preset to use for the index. */
    preset?: IndexesListResultItemConfigPreset | null | undefined;
}
export interface IndexesListResultItem {
    config?: IndexesListResultItemConfig | null | undefined;
    /** Specifies the timestamp the resource was created as an ISO8601 string. */
    createdOn?: string | null | undefined;
    /** Specifies the description of the index. */
    description?: string | null | undefined;
    /** Specifies the timestamp the resource was modified as an ISO8601 string. */
    modifiedOn?: string | null | undefined;
    name?: string | null | undefined;
}
export type IndexesListResultList = Array<IndexesListResultItem>;
export interface ListIndexesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: IndexesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListIndexMetadataIndexesRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
}
export type IndexesMetadataIndexListResponseMetadataIndexesItemIndexType = "string" | "number" | "boolean";
export interface IndexesMetadataIndexListResponseMetadataIndexesItem {
    /** Specifies the type of indexed metadata property. */
    indexType?: IndexesMetadataIndexListResponseMetadataIndexesItemIndexType | null | undefined;
    /** Specifies the indexed metadata property. */
    propertyName?: string | null | undefined;
}
export type IndexesMetadataIndexListResponseMetadataIndexesList = Array<IndexesMetadataIndexListResponseMetadataIndexesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListIndexMetadataIndexesResponse {
    /** Array of indexed metadata properties. */
    metadataIndexes?: IndexesMetadataIndexListResponseMetadataIndexesList | null | undefined;
}
export interface ListVectorsIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Maximum number of vectors to return */
    count?: number | undefined;
    /** Cursor for pagination to get the next page of results */
    cursor?: string | undefined;
}
export interface IndexesListVectorsResponseVectorsItem {
    /** Identifier for a Vector */
    id: string;
}
export type IndexesListVectorsResponseVectorsList = Array<IndexesListVectorsResponseVectorsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListVectorsIndexResponse {
    /** Number of vectors returned in this response */
    count: number;
    /** Whether there are more vectors available beyond this response */
    isTruncated: boolean;
    /** Total number of vectors in the index */
    totalCount: number;
    /** Array of vector items */
    vectors: IndexesListVectorsResponseVectorsList;
    /** When the cursor expires as an ISO8601 string */
    cursorExpirationTimestamp?: string | null | undefined;
    /** Cursor for the next page of results */
    nextCursor?: string | null | undefined;
}
export type IndexesQueryRequestVectorList = Array<number>;
export type IndexesQueryRequestReturnMetadata = "none" | "indexed" | "all";
export interface QueryIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** The search vector that will be used to find the nearest neighbors. */
    vector: IndexesQueryRequestVectorList;
    /** A metadata filter expression used to limit nearest neighbor results. */
    filter?: unknown | undefined;
    /** Whether to return no metadata, indexed metadata or all metadata associated with the closest vectors. */
    returnMetadata?: IndexesQueryRequestReturnMetadata | (string & {}) | undefined;
    /** Whether to return the values associated with the closest vectors. */
    returnValues?: boolean | undefined;
    /** The number of nearest neighbors to find. */
    topK?: number | undefined;
}
export type IndexesQueryResponseMatchesItemValuesList = Array<number>;
export interface IndexesQueryResponseMatchesItem {
    /** Identifier for a Vector */
    id?: string | null | undefined;
    metadata?: unknown | null | undefined;
    namespace?: string | null | undefined;
    /** The score of the vector according to the index's distance metric */
    score?: number | null | undefined;
    values?: IndexesQueryResponseMatchesItemValuesList | null | undefined;
}
export type IndexesQueryResponseMatchesList = Array<IndexesQueryResponseMatchesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface QueryIndexResponse {
    /** Specifies the count of vectors returned by the search */
    count?: number | null | undefined;
    /** Array of vectors matched by the search */
    matches?: IndexesQueryResponseMatchesList | null | undefined;
}
export type IndexesUpsertRequestUnparsableBehavior = "error" | "discard";
export interface UpsertIndexRequest {
    /** Identifier */
    accountId: string;
    indexName: string;
    /** Behavior for ndjson parse failures. */
    unparsableBehavior?: IndexesUpsertRequestUnparsableBehavior | (string & {}) | undefined;
    /** Vectors as newline-delimited JSON (application/x-ndjson), one vector object per line. */
    body: Blob | Uint8Array | ArrayBuffer | string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpsertIndexResponse {
    /** The unique identifier for the async mutation operation containing the changeset. */
    mutationId?: string | null | undefined;
}
export type CreateIndexError = IndexAlreadyExists | IndexInvalidName | IndexInvalidConfig | CloudflareOpError;
/** Creates and returns a new Vectorize Index. */
export declare const createIndex: API.OperationMethod<CreateIndexRequest, CreateIndexResponse, CreateIndexError, CloudflareOpContext>;
export type CreateIndexMetadataIndexError = NotFound | MetadataIndexAlreadyExists | MetadataIndexInvalidType | CloudflareOpError;
/** Enable metadata filtering based on metadata property. Limited to 10 properties. */
export declare const createIndexMetadataIndex: API.OperationMethod<CreateIndexMetadataIndexRequest, CreateIndexMetadataIndexResponse, CreateIndexMetadataIndexError, CloudflareOpContext>;
export type DeleteByIdsIndexError = CloudflareOpError;
/** Delete a set of vectors from an index by their vector identifiers. */
export declare const deleteByIdsIndex: API.OperationMethod<DeleteByIdsIndexRequest, DeleteByIdsIndexResponse, DeleteByIdsIndexError, CloudflareOpContext>;
export type DeleteIndexError = NotFound | Gone | CloudflareOpError;
/** Deletes the specified Vectorize Index. */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest, DeleteIndexResponse, DeleteIndexError, CloudflareOpContext>;
export type DeleteIndexMetadataIndexError = NotFound | Gone | MetadataIndexNotFound | CloudflareOpError;
/** Allow Vectorize to delete the specified metadata index. */
export declare const deleteIndexMetadataIndex: API.OperationMethod<DeleteIndexMetadataIndexRequest, DeleteIndexMetadataIndexResponse, DeleteIndexMetadataIndexError, CloudflareOpContext>;
export type GetByIdsIndexError = CloudflareOpError;
/** Get a set of vectors from an index by their vector identifiers. */
export declare const getByIdsIndex: API.OperationMethod<GetByIdsIndexRequest, GetByIdsIndexResponse, GetByIdsIndexError, CloudflareOpContext>;
export type GetIndexError = NotFound | Gone | CloudflareOpError;
/** Returns the specified Vectorize Index. */
export declare const getIndex: API.OperationMethod<GetIndexRequest, GetIndexResponse, GetIndexError, CloudflareOpContext>;
export type GetIndexInfoError = CloudflareOpError;
/** Get information about a vectorize index. */
export declare const getIndexInfo: API.OperationMethod<GetIndexInfoRequest, GetIndexInfoResponse, GetIndexInfoError, CloudflareOpContext>;
export type InsertIndexError = CloudflareOpError;
/** Inserts vectors into the specified index and returns a mutation id corresponding to the vectors enqueued for insertion. */
export declare const insertIndex: API.OperationMethod<InsertIndexRequest, InsertIndexResponse, InsertIndexError, CloudflareOpContext>;
export type ListIndexesError = NotFound | Gone | CloudflareOpError;
/** Returns a list of Vectorize Indexes */
export declare const listIndexes: API.PaginatedOperationMethod<ListIndexesRequest, ListIndexesResponse, ListIndexesError, CloudflareOpContext, IndexesListResultItem>;
export type ListIndexMetadataIndexesError = NotFound | Gone | CloudflareOpError;
/** List Metadata Indexes for the specified Vectorize Index. */
export declare const listIndexMetadataIndexes: API.OperationMethod<ListIndexMetadataIndexesRequest, ListIndexMetadataIndexesResponse, ListIndexMetadataIndexesError, CloudflareOpContext>;
export type ListVectorsIndexError = CloudflareOpError;
/** Returns a paginated list of vector identifiers from the specified index. */
export declare const listVectorsIndex: API.OperationMethod<ListVectorsIndexRequest, ListVectorsIndexResponse, ListVectorsIndexError, CloudflareOpContext>;
export type QueryIndexError = CloudflareOpError;
/** Finds vectors closest to a given vector in an index. */
export declare const queryIndex: API.OperationMethod<QueryIndexRequest, QueryIndexResponse, QueryIndexError, CloudflareOpContext>;
export type UpsertIndexError = CloudflareOpError;
/** Upserts vectors into the specified index, creating them if they do not exist and returns a mutation id corresponding to the vectors enqueued for upsertion. */
export declare const upsertIndex: API.OperationMethod<UpsertIndexRequest, UpsertIndexResponse, UpsertIndexError, CloudflareOpContext>;
//# sourceMappingURL=vectorize.d.ts.map