import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import * as Alchemist from "../Alchemist/index.ts";
export declare const devKeepAlive: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
declare const makeExec: () => Effect.Effect<void, import("../Auth/AuthProvider.ts").AuthError | Config.ConfigError | import("../Auth/Demand.ts").CredentialsRequired | import("../Apply.ts").DestroyError | import("../Output.ts").InvalidReferenceError | import("../Output.ts").MissingSourceError | import("../Auth/AuthProvider.ts").NeedsReauth | import("effect/PlatformError").PlatformError | {
    readonly "~effect/Runtime/errorReported": false;
    readonly cause: unknown;
} | Alchemist.StackEntrypointError | import("../State/State.ts").StateStoreError, never>;
/** Fully wired sidecar CLI program. */
export declare const exec: () => Effect.Effect<void, Effect.Error<ReturnType<typeof makeExec>>>;
export {};
//# sourceMappingURL=exec.d.ts.map