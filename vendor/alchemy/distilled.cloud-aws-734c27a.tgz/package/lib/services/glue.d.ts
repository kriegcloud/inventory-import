import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const ColumnStatisticsTaskNotRunningException_base: S.TaggedErrorClass<"ColumnStatisticsTaskNotRunningException", {
    readonly message: any;
}>;
export declare class ColumnStatisticsTaskNotRunningException extends /*@__PURE__*/ ColumnStatisticsTaskNotRunningException_base {
}
declare const ColumnStatisticsTaskRunningException_base: S.TaggedErrorClass<"ColumnStatisticsTaskRunningException", {
    readonly message: any;
}>;
export declare class ColumnStatisticsTaskRunningException extends /*@__PURE__*/ ColumnStatisticsTaskRunningException_base {
}
declare const ColumnStatisticsTaskStoppingException_base: S.TaggedErrorClass<"ColumnStatisticsTaskStoppingException", {
    readonly message: any;
}>;
export declare class ColumnStatisticsTaskStoppingException extends /*@__PURE__*/ ColumnStatisticsTaskStoppingException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConcurrentRunsExceededException_base: S.TaggedErrorClass<"ConcurrentRunsExceededException", {
    readonly message: any;
}>;
export declare class ConcurrentRunsExceededException extends /*@__PURE__*/ ConcurrentRunsExceededException_base {
}
declare const ConditionCheckFailureException_base: S.TaggedErrorClass<"ConditionCheckFailureException", {
    readonly message: any;
}>;
export declare class ConditionCheckFailureException extends /*@__PURE__*/ ConditionCheckFailureException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CrawlerNotRunningException_base: S.TaggedErrorClass<"CrawlerNotRunningException", {
    readonly message: any;
}>;
export declare class CrawlerNotRunningException extends /*@__PURE__*/ CrawlerNotRunningException_base {
}
declare const CrawlerRunningException_base: S.TaggedErrorClass<"CrawlerRunningException", {
    readonly message: any;
}>;
export declare class CrawlerRunningException extends /*@__PURE__*/ CrawlerRunningException_base {
}
declare const CrawlerStoppingException_base: S.TaggedErrorClass<"CrawlerStoppingException", {
    readonly message: any;
}>;
export declare class CrawlerStoppingException extends /*@__PURE__*/ CrawlerStoppingException_base {
}
declare const EntityNotFoundException_base: S.TaggedErrorClass<"EntityNotFoundException", {
    readonly message: any;
    readonly FromFederationSource: any;
}>;
export declare class EntityNotFoundException extends /*@__PURE__*/ EntityNotFoundException_base {
}
declare const FederatedResourceAlreadyExistsException_base: S.TaggedErrorClass<"FederatedResourceAlreadyExistsException", {
    readonly message: any;
    readonly AssociatedGlueResource: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FederatedResourceAlreadyExistsException extends /*@__PURE__*/ FederatedResourceAlreadyExistsException_base {
}
declare const FederationSourceException_base: S.TaggedErrorClass<"FederationSourceException", {
    readonly FederationSourceErrorCode: any;
    readonly message: any;
}>;
export declare class FederationSourceException extends /*@__PURE__*/ FederationSourceException_base {
}
declare const FederationSourceRetryableException_base: S.TaggedErrorClass<"FederationSourceRetryableException", {
    readonly message: any;
}>;
export declare class FederationSourceRetryableException extends /*@__PURE__*/ FederationSourceRetryableException_base {
}
declare const GlueEncryptionException_base: S.TaggedErrorClass<"GlueEncryptionException", {
    readonly message: any;
}>;
export declare class GlueEncryptionException extends /*@__PURE__*/ GlueEncryptionException_base {
}
declare const GlueRoleNotAssumable_base: S.TaggedErrorClass<"GlueRoleNotAssumable", {
    readonly message: any;
    readonly FromFederationSource: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GlueRoleNotAssumable extends /*@__PURE__*/ GlueRoleNotAssumable_base {
}
declare const GlueS3TargetNotReady_base: S.TaggedErrorClass<"GlueS3TargetNotReady", {
    readonly message: any;
    readonly FromFederationSource: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GlueS3TargetNotReady extends /*@__PURE__*/ GlueS3TargetNotReady_base {
}
declare const IdempotentParameterMismatchException_base: S.TaggedErrorClass<"IdempotentParameterMismatchException", {
    readonly message: any;
}>;
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const IllegalBlueprintStateException_base: S.TaggedErrorClass<"IllegalBlueprintStateException", {
    readonly message: any;
}>;
export declare class IllegalBlueprintStateException extends /*@__PURE__*/ IllegalBlueprintStateException_base {
}
declare const IllegalSessionStateException_base: S.TaggedErrorClass<"IllegalSessionStateException", {
    readonly message: any;
}>;
export declare class IllegalSessionStateException extends /*@__PURE__*/ IllegalSessionStateException_base {
}
declare const IllegalWorkflowStateException_base: S.TaggedErrorClass<"IllegalWorkflowStateException", {
    readonly message: any;
}>;
export declare class IllegalWorkflowStateException extends /*@__PURE__*/ IllegalWorkflowStateException_base {
}
declare const InsufficientLakeFormationPermissions_base: S.TaggedErrorClass<"InsufficientLakeFormationPermissions", {
    readonly message: any;
}>;
export declare class InsufficientLakeFormationPermissions extends /*@__PURE__*/ InsufficientLakeFormationPermissions_base {
}
declare const IntegrationConflictOperationFault_base: S.TaggedErrorClass<"IntegrationConflictOperationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IntegrationConflictOperationFault extends /*@__PURE__*/ IntegrationConflictOperationFault_base {
}
declare const IntegrationNotFoundFault_base: S.TaggedErrorClass<"IntegrationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationNotFoundFault extends /*@__PURE__*/ IntegrationNotFoundFault_base {
}
declare const IntegrationQuotaExceededFault_base: S.TaggedErrorClass<"IntegrationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class IntegrationQuotaExceededFault extends /*@__PURE__*/ IntegrationQuotaExceededFault_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}>;
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
    readonly FromFederationSource: any;
}>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidIntegrationStateFault_base: S.TaggedErrorClass<"InvalidIntegrationStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidIntegrationStateFault extends /*@__PURE__*/ InvalidIntegrationStateFault_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
}>;
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const KMSKeyNotAccessibleFault_base: S.TaggedErrorClass<"KMSKeyNotAccessibleFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KMSKeyNotAccessibleFault extends /*@__PURE__*/ KMSKeyNotAccessibleFault_base {
}
declare const MaterializedViewRefreshTaskNotRunningException_base: S.TaggedErrorClass<"MaterializedViewRefreshTaskNotRunningException", {
    readonly message: any;
}>;
export declare class MaterializedViewRefreshTaskNotRunningException extends /*@__PURE__*/ MaterializedViewRefreshTaskNotRunningException_base {
}
declare const MaterializedViewRefreshTaskRunningException_base: S.TaggedErrorClass<"MaterializedViewRefreshTaskRunningException", {
    readonly message: any;
}>;
export declare class MaterializedViewRefreshTaskRunningException extends /*@__PURE__*/ MaterializedViewRefreshTaskRunningException_base {
}
declare const MaterializedViewRefreshTaskStoppingException_base: S.TaggedErrorClass<"MaterializedViewRefreshTaskStoppingException", {
    readonly message: any;
}>;
export declare class MaterializedViewRefreshTaskStoppingException extends /*@__PURE__*/ MaterializedViewRefreshTaskStoppingException_base {
}
declare const MLTransformNotReadyException_base: S.TaggedErrorClass<"MLTransformNotReadyException", {
    readonly message: any;
}>;
export declare class MLTransformNotReadyException extends /*@__PURE__*/ MLTransformNotReadyException_base {
}
declare const NoScheduleException_base: S.TaggedErrorClass<"NoScheduleException", {
    readonly message: any;
}>;
export declare class NoScheduleException extends /*@__PURE__*/ NoScheduleException_base {
}
declare const OperationNotSupportedException_base: S.TaggedErrorClass<"OperationNotSupportedException", {
    readonly message: any;
}>;
export declare class OperationNotSupportedException extends /*@__PURE__*/ OperationNotSupportedException_base {
}
declare const OperationTimeoutException_base: S.TaggedErrorClass<"OperationTimeoutException", {
    readonly message: any;
}>;
export declare class OperationTimeoutException extends /*@__PURE__*/ OperationTimeoutException_base {
}
declare const PermissionTypeMismatchException_base: S.TaggedErrorClass<"PermissionTypeMismatchException", {
    readonly message: any;
}>;
export declare class PermissionTypeMismatchException extends /*@__PURE__*/ PermissionTypeMismatchException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceNotReadyException_base: S.TaggedErrorClass<"ResourceNotReadyException", {
    readonly message: any;
}>;
export declare class ResourceNotReadyException extends /*@__PURE__*/ ResourceNotReadyException_base {
}
declare const ResourceNumberLimitExceededException_base: S.TaggedErrorClass<"ResourceNumberLimitExceededException", {
    readonly message: any;
}>;
export declare class ResourceNumberLimitExceededException extends /*@__PURE__*/ ResourceNumberLimitExceededException_base {
}
declare const SchedulerNotRunningException_base: S.TaggedErrorClass<"SchedulerNotRunningException", {
    readonly message: any;
}>;
export declare class SchedulerNotRunningException extends /*@__PURE__*/ SchedulerNotRunningException_base {
}
declare const SchedulerRunningException_base: S.TaggedErrorClass<"SchedulerRunningException", {
    readonly message: any;
}>;
export declare class SchedulerRunningException extends /*@__PURE__*/ SchedulerRunningException_base {
}
declare const SchedulerTransitioningException_base: S.TaggedErrorClass<"SchedulerTransitioningException", {
    readonly message: any;
}>;
export declare class SchedulerTransitioningException extends /*@__PURE__*/ SchedulerTransitioningException_base {
}
declare const SessionBusyException_base: S.TaggedErrorClass<"SessionBusyException", {
    readonly message: any;
}>;
export declare class SessionBusyException extends /*@__PURE__*/ SessionBusyException_base {
}
declare const TargetResourceNotFound_base: S.TaggedErrorClass<"TargetResourceNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TargetResourceNotFound extends /*@__PURE__*/ TargetResourceNotFound_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
declare const VersionMismatchException_base: S.TaggedErrorClass<"VersionMismatchException", {
    readonly message: any;
}>;
export declare class VersionMismatchException extends /*@__PURE__*/ VersionMismatchException_base {
}
export type AssetId = string;
export type IterableFormName = string;
export type ItemIdentifier = string;
export type GlossaryTermId = string;
export type GlossaryTermIdList = string[];
export type HashString = string;
export interface AssociateGlossaryTermsRequest {
    AssetIdentifier: string;
    IterableFormName?: string | undefined;
    ItemIdentifier?: string | undefined;
    GlossaryTermIdentifiers: string[];
    ClientToken?: string | undefined;
}
export interface AssociateGlossaryTermsResponse {
    AssetIdentifier?: string | undefined;
    IterableFormName?: string | undefined;
    ItemIdentifier?: string | undefined;
    GlossaryTerms?: string[] | undefined;
}
export type CatalogIdString = string;
export type NameString = string;
export type ValueString = string;
export type ValueStringList = string[];
export type ColumnTypeString = string;
export type CommentString = string;
export type KeyString = string;
export type ParametersMapValue = string;
export type ParametersMap = {
    [key: string]: string | undefined;
};
export interface Column {
    Name: string;
    Type?: string | undefined;
    Comment?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ColumnList = Column[];
export type LocationString = string;
export type LocationStringList = string[];
export type FormatString = string;
export interface SerDeInfo {
    Name?: string | undefined;
    SerializationLibrary?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NameStringList = string[];
export type IntegerFlag = number;
export interface Order {
    Column: string;
    SortOrder: number;
}
export type OrderList = Order[];
export type ColumnValuesString = string;
export type ColumnValueStringList = string[];
export type LocationMap = {
    [key: string]: string | undefined;
};
export interface SkewedInfo {
    SkewedColumnNames?: string[] | undefined;
    SkewedColumnValues?: string[] | undefined;
    SkewedColumnValueLocationMaps?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type GlueResourceArn = string;
export type SchemaRegistryNameString = string;
export interface SchemaId {
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    RegistryName?: string | undefined;
}
export type SchemaVersionIdString = string;
export type VersionLongNumber = number;
export interface SchemaReference {
    SchemaId?: SchemaId | undefined;
    SchemaVersionId?: string | undefined;
    SchemaVersionNumber?: number | undefined;
}
export interface StorageDescriptor {
    Columns?: Column[] | undefined;
    Location?: string | undefined;
    AdditionalLocations?: string[] | undefined;
    InputFormat?: string | undefined;
    OutputFormat?: string | undefined;
    Compressed?: boolean | undefined;
    NumberOfBuckets?: number | undefined;
    SerdeInfo?: SerDeInfo | undefined;
    BucketColumns?: string[] | undefined;
    SortColumns?: Order[] | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    SkewedInfo?: SkewedInfo | undefined;
    StoredAsSubDirectories?: boolean | undefined;
    SchemaReference?: SchemaReference | undefined;
}
export interface PartitionInput {
    Values?: string[] | undefined;
    LastAccessTime?: Date | undefined;
    StorageDescriptor?: StorageDescriptor | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    LastAnalyzedTime?: Date | undefined;
}
export type PartitionInputList = PartitionInput[];
export interface BatchCreatePartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionInputList: PartitionInput[];
}
export type DescriptionString = string;
export interface ErrorDetail {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export interface PartitionError {
    PartitionValues?: string[] | undefined;
    ErrorDetail?: ErrorDetail | undefined;
}
export type PartitionErrors = PartitionError[];
export interface BatchCreatePartitionResponse {
    Errors?: PartitionError[] | undefined;
}
export type DeleteConnectionNameList = string[];
export interface BatchDeleteConnectionRequest {
    CatalogId?: string | undefined;
    ConnectionNameList: string[];
}
export type ErrorByName = {
    [key: string]: ErrorDetail | undefined;
};
export interface BatchDeleteConnectionResponse {
    Succeeded?: string[] | undefined;
    Errors?: {
        [key: string]: ErrorDetail | undefined;
    } | undefined;
}
export interface PartitionValueList {
    Values: string[];
}
export type BatchDeletePartitionValueList = PartitionValueList[];
export interface BatchDeletePartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionsToDelete: PartitionValueList[];
}
export interface BatchDeletePartitionResponse {
    Errors?: PartitionError[] | undefined;
}
export type BatchDeleteTableNameList = string[];
export type TransactionIdString = string;
export interface BatchDeleteTableRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TablesToDelete: string[];
    TransactionId?: string | undefined;
}
export interface TableError {
    TableName?: string | undefined;
    ErrorDetail?: ErrorDetail | undefined;
}
export type TableErrors = TableError[];
export interface BatchDeleteTableResponse {
    Errors?: TableError[] | undefined;
}
export type VersionString = string;
export type BatchDeleteTableVersionList = string[];
export interface BatchDeleteTableVersionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    VersionIds: string[];
}
export interface TableVersionError {
    TableName?: string | undefined;
    VersionId?: string | undefined;
    ErrorDetail?: ErrorDetail | undefined;
}
export type TableVersionErrors = TableVersionError[];
export interface BatchDeleteTableVersionResponse {
    Errors?: TableVersionError[] | undefined;
}
export type OrchestrationNameString = string;
export type BatchGetBlueprintNames = string[];
export interface BatchGetBlueprintsRequest {
    Names: string[];
    IncludeBlueprint?: boolean | undefined;
    IncludeParameterSpec?: boolean | undefined;
}
export type Generic512CharString = string;
export type TimestampValue = Date;
export type BlueprintParameterSpec = string;
export type BlueprintStatus = "CREATING" | "ACTIVE" | "UPDATING" | "FAILED" | (string & {});
export type ErrorString = string;
export interface LastActiveDefinition {
    Description?: string | undefined;
    LastModifiedOn?: Date | undefined;
    ParameterSpec?: string | undefined;
    BlueprintLocation?: string | undefined;
    BlueprintServiceLocation?: string | undefined;
}
export interface Blueprint {
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    ParameterSpec?: string | undefined;
    BlueprintLocation?: string | undefined;
    BlueprintServiceLocation?: string | undefined;
    Status?: BlueprintStatus | undefined;
    ErrorMessage?: string | undefined;
    LastActiveDefinition?: LastActiveDefinition | undefined;
}
export type Blueprints = Blueprint[];
export type BlueprintNames = string[];
export interface BatchGetBlueprintsResponse {
    Blueprints?: Blueprint[] | undefined;
    MissingBlueprints?: string[] | undefined;
}
export type CrawlerNameList = string[];
export interface BatchGetCrawlersRequest {
    CrawlerNames: string[];
}
export type Role = string;
export type Path = string;
export type PathList = string[];
export type ConnectionName = string;
export type EventQueueArn = string;
export interface S3Target {
    Path?: string | undefined;
    Exclusions?: string[] | undefined;
    ConnectionName?: string | undefined;
    SampleSize?: number | undefined;
    EventQueueArn?: string | undefined;
    DlqEventQueueArn?: string | undefined;
}
export type S3TargetList = S3Target[];
export type JdbcMetadataEntry = "COMMENTS" | "RAWTYPES" | (string & {});
export type EnableAdditionalMetadata = JdbcMetadataEntry[];
export interface JdbcTarget {
    ConnectionName?: string | undefined;
    Path?: string | undefined;
    Exclusions?: string[] | undefined;
    EnableAdditionalMetadata?: JdbcMetadataEntry[] | undefined;
}
export type JdbcTargetList = JdbcTarget[];
export interface MongoDBTarget {
    ConnectionName?: string | undefined;
    Path?: string | undefined;
    ScanAll?: boolean | undefined;
}
export type MongoDBTargetList = MongoDBTarget[];
export interface DynamoDBTarget {
    Path?: string | undefined;
    scanAll?: boolean | undefined;
    scanRate?: number | undefined;
}
export type DynamoDBTargetList = DynamoDBTarget[];
export type CatalogTablesList = string[];
export interface CatalogTarget {
    DatabaseName: string;
    Tables: string[];
    ConnectionName?: string | undefined;
    EventQueueArn?: string | undefined;
    DlqEventQueueArn?: string | undefined;
}
export type CatalogTargetList = CatalogTarget[];
export interface DeltaTarget {
    DeltaTables?: string[] | undefined;
    ConnectionName?: string | undefined;
    WriteManifest?: boolean | undefined;
    CreateNativeDeltaTable?: boolean | undefined;
}
export type DeltaTargetList = DeltaTarget[];
export interface IcebergTarget {
    Paths?: string[] | undefined;
    ConnectionName?: string | undefined;
    Exclusions?: string[] | undefined;
    MaximumTraversalDepth?: number | undefined;
}
export type IcebergTargetList = IcebergTarget[];
export interface HudiTarget {
    Paths?: string[] | undefined;
    ConnectionName?: string | undefined;
    Exclusions?: string[] | undefined;
    MaximumTraversalDepth?: number | undefined;
}
export type HudiTargetList = HudiTarget[];
export interface CrawlerTargets {
    S3Targets?: S3Target[] | undefined;
    JdbcTargets?: JdbcTarget[] | undefined;
    MongoDBTargets?: MongoDBTarget[] | undefined;
    DynamoDBTargets?: DynamoDBTarget[] | undefined;
    CatalogTargets?: CatalogTarget[] | undefined;
    DeltaTargets?: DeltaTarget[] | undefined;
    IcebergTargets?: IcebergTarget[] | undefined;
    HudiTargets?: HudiTarget[] | undefined;
}
export type DatabaseName = string;
export type ClassifierNameList = string[];
export type RecrawlBehavior = "CRAWL_EVERYTHING" | "CRAWL_NEW_FOLDERS_ONLY" | "CRAWL_EVENT_MODE" | (string & {});
export interface RecrawlPolicy {
    RecrawlBehavior?: RecrawlBehavior | undefined;
}
export type UpdateBehavior = "LOG" | "UPDATE_IN_DATABASE" | (string & {});
export type DeleteBehavior = "LOG" | "DELETE_FROM_DATABASE" | "DEPRECATE_IN_DATABASE" | (string & {});
export interface SchemaChangePolicy {
    UpdateBehavior?: UpdateBehavior | undefined;
    DeleteBehavior?: DeleteBehavior | undefined;
}
export type CrawlerLineageSettings = "ENABLE" | "DISABLE" | (string & {});
export interface LineageConfiguration {
    CrawlerLineageSettings?: CrawlerLineageSettings | undefined;
}
export type CrawlerState = "READY" | "RUNNING" | "STOPPING" | (string & {});
export type TablePrefix = string;
export type CronExpression = string;
export type ScheduleState = "SCHEDULED" | "NOT_SCHEDULED" | "TRANSITIONING" | (string & {});
export interface Schedule {
    ScheduleExpression?: string | undefined;
    State?: ScheduleState | undefined;
}
export type MillisecondsCount = number;
export type LastCrawlStatus = "SUCCEEDED" | "CANCELLED" | "FAILED" | (string & {});
export type LogGroup = string;
export type LogStream = string;
export type MessagePrefix = string;
export interface LastCrawlInfo {
    Status?: LastCrawlStatus | undefined;
    ErrorMessage?: string | undefined;
    LogGroup?: string | undefined;
    LogStream?: string | undefined;
    MessagePrefix?: string | undefined;
    StartTime?: Date | undefined;
}
export type VersionId = number;
export type CrawlerConfiguration = string;
export type CrawlerSecurityConfiguration = string;
export type AccountId = string;
export interface LakeFormationConfiguration {
    UseLakeFormationCredentials?: boolean | undefined;
    AccountId?: string | undefined;
}
export interface Crawler {
    Name?: string | undefined;
    Role?: string | undefined;
    Targets?: CrawlerTargets | undefined;
    DatabaseName?: string | undefined;
    Description?: string | undefined;
    Classifiers?: string[] | undefined;
    RecrawlPolicy?: RecrawlPolicy | undefined;
    SchemaChangePolicy?: SchemaChangePolicy | undefined;
    LineageConfiguration?: LineageConfiguration | undefined;
    State?: CrawlerState | undefined;
    TablePrefix?: string | undefined;
    Schedule?: Schedule | undefined;
    CrawlElapsedTime?: number | undefined;
    CreationTime?: Date | undefined;
    LastUpdated?: Date | undefined;
    LastCrawl?: LastCrawlInfo | undefined;
    Version?: number | undefined;
    Configuration?: string | undefined;
    CrawlerSecurityConfiguration?: string | undefined;
    LakeFormationConfiguration?: LakeFormationConfiguration | undefined;
    CatalogId?: string | undefined;
}
export type CrawlerList = Crawler[];
export interface BatchGetCrawlersResponse {
    Crawlers?: Crawler[] | undefined;
    CrawlersNotFound?: string[] | undefined;
}
export type CustomEntityTypeNames = string[];
export interface BatchGetCustomEntityTypesRequest {
    Names: string[];
}
export type ContextWords = string[];
export interface CustomEntityType {
    Name: string;
    RegexString: string;
    ContextWords?: string[] | undefined;
}
export type CustomEntityTypes = CustomEntityType[];
export interface BatchGetCustomEntityTypesResponse {
    CustomEntityTypes?: CustomEntityType[] | undefined;
    CustomEntityTypesNotFound?: string[] | undefined;
}
export type DataQualityResultIds = string[];
export interface BatchGetDataQualityResultRequest {
    ResultIds: string[];
}
export type DataQualityEvaluationRunMode = "ON_DEMAND" | "EVALUATION_CONFIG" | (string & {});
export type GenericBoundedDouble = number;
export type GlueTableAdditionalOptions = {
    [key: string]: string | undefined;
};
export interface GlueTable {
    DatabaseName: string;
    TableName: string;
    CatalogId?: string | undefined;
    ConnectionName?: string | undefined;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PreProcessingQueryString = string;
export interface DataQualityGlueTable {
    DatabaseName: string;
    TableName: string;
    CatalogId?: string | undefined;
    ConnectionName?: string | undefined;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    PreProcessingQuery?: string | undefined;
}
export interface DataSource {
    GlueTable?: GlueTable | undefined;
    DataQualityGlueTable?: DataQualityGlueTable | undefined;
}
export type DataQualityRuleResultDescription = string | redacted.Redacted<string>;
export type DataQualityRuleResultStatus = "PASS" | "FAIL" | "ERROR" | (string & {});
export type EvaluatedMetricsMap = {
    [key: string]: number | undefined;
};
export type RuleMetricsMap = {
    [key: string]: number | undefined;
};
export type Labels = {
    [key: string]: string | undefined;
};
export interface DataQualityRuleResult {
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    EvaluationMessage?: string | redacted.Redacted<string> | undefined;
    Result?: DataQualityRuleResultStatus | undefined;
    EvaluatedMetrics?: {
        [key: string]: number | undefined;
    } | undefined;
    EvaluatedRule?: string | redacted.Redacted<string> | undefined;
    RuleMetrics?: {
        [key: string]: number | undefined;
    } | undefined;
    Labels?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DataQualityRuleResults = DataQualityRuleResult[];
export type BinEdges = string[];
export type Count = number[];
export interface DistributionData {
    BinEdges?: string[] | undefined;
    Count?: number[] | undefined;
    DataType?: string | undefined;
}
export type EvaluatedDistributionsMap = {
    [key: string]: DistributionData | undefined;
};
export interface DataQualityAnalyzerResult {
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    EvaluationMessage?: string | redacted.Redacted<string> | undefined;
    EvaluatedMetrics?: {
        [key: string]: number | undefined;
    } | undefined;
    EvaluatedDistributions?: {
        [key: string]: DistributionData | undefined;
    } | undefined;
}
export type DataQualityAnalyzerResults = DataQualityAnalyzerResult[];
export type DataQualityObservationDescription = string | redacted.Redacted<string>;
export interface DataQualityMetricValues {
    ActualValue?: number | undefined;
    ExpectedValue?: number | undefined;
    LowerLimit?: number | undefined;
    UpperLimit?: number | undefined;
}
export type NewRules = string[];
export interface MetricBasedObservation {
    MetricName?: string | undefined;
    StatisticId?: string | undefined;
    MetricValues?: DataQualityMetricValues | undefined;
    NewRules?: string[] | undefined;
}
export interface DataQualityObservation {
    Description?: string | redacted.Redacted<string> | undefined;
    MetricBasedObservation?: MetricBasedObservation | undefined;
}
export type DataQualityObservations = DataQualityObservation[];
export interface DataQualityAggregatedMetrics {
    TotalRowsProcessed?: number | undefined;
    TotalRowsPassed?: number | undefined;
    TotalRowsFailed?: number | undefined;
    TotalRulesProcessed?: number | undefined;
    TotalRulesPassed?: number | undefined;
    TotalRulesFailed?: number | undefined;
}
export interface DataQualityResult {
    ResultId?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    DataQualityEvaluationConfig?: string | undefined;
    ProfileId?: string | undefined;
    Score?: number | undefined;
    DataSource?: DataSource | undefined;
    RulesetName?: string | undefined;
    EvaluationContext?: string | undefined;
    StartedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    JobName?: string | undefined;
    JobRunId?: string | undefined;
    RulesetEvaluationRunId?: string | undefined;
    RuleResults?: DataQualityRuleResult[] | undefined;
    AnalyzerResults?: DataQualityAnalyzerResult[] | undefined;
    Observations?: DataQualityObservation[] | undefined;
    AggregatedMetrics?: DataQualityAggregatedMetrics | undefined;
}
export type DataQualityResultsList = DataQualityResult[];
export interface BatchGetDataQualityResultResponse {
    Results: DataQualityResult[];
    ResultsNotFound?: string[] | undefined;
}
export type DataQualityResultV2IdList = string[];
export interface BatchGetDataQualityResultV2Request {
    ResultIds: string[];
}
export type PublishDataQualityResultDimensions = {
    [key: string]: string | undefined;
};
export type PublishDataQualityResultTags = {
    [key: string]: string | undefined;
};
export type PublishDataQualityResultDescriptors = {
    [key: string]: string | undefined;
};
export interface DataQualityResultV2Item {
    ResultId: string;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    DataQualityEvaluationConfig?: string | undefined;
    DataSource?: DataSource | undefined;
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ExecutionStartedOn?: Date | undefined;
    ExecutionCompletedOn?: Date | undefined;
    ResultPublishedOn?: Date | undefined;
    Score?: number | undefined;
    RuleResults?: DataQualityRuleResult[] | undefined;
    AnalyzerResults?: DataQualityAnalyzerResult[] | undefined;
    Observations?: DataQualityObservation[] | undefined;
    EvaluationContext?: string | undefined;
    Descriptors?: {
        [key: string]: string | undefined;
    } | undefined;
    AggregatedMetrics?: DataQualityAggregatedMetrics | undefined;
    RulesetName?: string | undefined;
}
export type DataQualityResultV2List = DataQualityResultV2Item[];
export interface BatchGetDataQualityResultV2Response {
    Results: DataQualityResultV2Item[];
    ResultsNotFound?: string[] | undefined;
}
export type DataQualityRulesetEvaluationRunIdList = string[];
export interface BatchGetDataQualityRulesetEvaluationRunRequest {
    RunIds: string[];
}
export type RoleString = string;
export type Timeout = number;
export type UriString = string;
export type DQCompositeRuleEvaluationMethod = "COLUMN" | "ROW" | (string & {});
export type ResultTypeEnum = "ALL" | "PASSED_ONLY" | "FAILED_ONLY" | (string & {});
export interface CatalogTableConfigOptions {
    DatabaseName?: string | undefined;
    TableName?: string | undefined;
    S3Location?: string | undefined;
    CatalogId?: string | undefined;
}
export interface RowLevelResultsOptions {
    MaxRowsToWrite?: number | undefined;
    ResultType?: ResultTypeEnum | undefined;
    CatalogTableConfig?: CatalogTableConfigOptions | undefined;
}
export interface DistributionResultsOptions {
    WriteDistributionResultsEnabled?: boolean | undefined;
    CatalogTableConfig?: CatalogTableConfigOptions | undefined;
}
export interface ProfilingResultsOptions {
    WriteProfilingResultsEnabled?: boolean | undefined;
    CatalogTableConfig?: CatalogTableConfigOptions | undefined;
    DistributionResults?: DistributionResultsOptions | undefined;
}
export type ObservationConfiguration = "ALL" | "NONE" | (string & {});
export type ObservationMode = "SCHEDULED" | "FIXED" | (string & {});
export interface DataQualityRuleResultsOptions {
    WriteDataQualityRuleResultsEnabled?: boolean | undefined;
    CatalogTableConfig?: CatalogTableConfigOptions | undefined;
}
export interface ObservationResultsOptions {
    WriteObservationResultsEnabled?: boolean | undefined;
    CatalogTableConfig?: CatalogTableConfigOptions | undefined;
}
export interface DataQualityEvaluationRunAdditionalRunOptions {
    CloudWatchMetricsEnabled?: boolean | undefined;
    ResultsS3Prefix?: string | undefined;
    CompositeRuleEvaluationMethod?: DQCompositeRuleEvaluationMethod | undefined;
    CustomLogGroupPrefix?: string | undefined;
    RowLevelResults?: RowLevelResultsOptions | undefined;
    ProfilingResults?: ProfilingResultsOptions | undefined;
    ObservationScope?: ObservationConfiguration | undefined;
    ObservationMode?: ObservationMode | undefined;
    DataQualityRuleResults?: DataQualityRuleResultsOptions | undefined;
    ObservationResults?: ObservationResultsOptions | undefined;
}
export type TaskStatusType = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | "SUCCEEDED" | "FAILED" | "TIMEOUT" | (string & {});
export type ExecutionTime = number;
export type RulesetNames = string[];
export type DataQualityResultIdList = string[];
export type DataSourceMap = {
    [key: string]: DataSource | undefined;
};
export interface DataQualityRulesetEvaluationRun {
    RunId?: string | undefined;
    DataSource?: DataSource | undefined;
    Role?: string | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    AdditionalRunOptions?: DataQualityEvaluationRunAdditionalRunOptions | undefined;
    Status?: TaskStatusType | undefined;
    ErrorString?: string | undefined;
    StartedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    ExecutionTime?: number | undefined;
    RulesetNames?: string[] | undefined;
    ResultIds?: string[] | undefined;
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    } | undefined;
}
export type DataQualityRulesetEvaluationRunsList = DataQualityRulesetEvaluationRun[];
export interface BatchGetDataQualityRulesetEvaluationRunResponse {
    Runs?: DataQualityRulesetEvaluationRun[] | undefined;
    RunsNotFound?: string[] | undefined;
}
export type DevEndpointNames = string[];
export interface BatchGetDevEndpointsRequest {
    DevEndpointNames: string[];
}
export type RoleArn = string;
export type StringList = string[];
export type IntegerValue = number;
export type WorkerType = "Standard" | "G.1X" | "G.2X" | "G.4X" | "G.8X" | "G.025X" | "Z.2X" | "G.12X" | "G.16X" | "R.1X" | "R.2X" | "R.4X" | "R.8X" | (string & {});
export type GlueVersionString = string;
export type PublicKeysList = string[];
export type MapValue = {
    [key: string]: string | undefined;
};
export interface DevEndpoint {
    EndpointName?: string | undefined;
    RoleArn?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetId?: string | undefined;
    YarnEndpointAddress?: string | undefined;
    PrivateAddress?: string | undefined;
    ZeppelinRemoteSparkInterpreterPort?: number | undefined;
    PublicAddress?: string | undefined;
    Status?: string | undefined;
    WorkerType?: WorkerType | undefined;
    GlueVersion?: string | undefined;
    NumberOfWorkers?: number | undefined;
    NumberOfNodes?: number | undefined;
    AvailabilityZone?: string | undefined;
    VpcId?: string | undefined;
    ExtraPythonLibsS3Path?: string | undefined;
    ExtraJarsS3Path?: string | undefined;
    FailureReason?: string | undefined;
    LastUpdateStatus?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    LastModifiedTimestamp?: Date | undefined;
    PublicKey?: string | undefined;
    PublicKeys?: string[] | undefined;
    SecurityConfiguration?: string | undefined;
    Arguments?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DevEndpointList = DevEndpoint[];
export interface BatchGetDevEndpointsResponse {
    DevEndpoints?: DevEndpoint[] | undefined;
    DevEndpointsNotFound?: string[] | undefined;
}
export type ItemIdentifierList = string[];
export interface BatchGetIterableFormsRequest {
    AssetIdentifier: string;
    IterableFormName: string;
    ItemIdentifiers: string[];
}
export type ItemId = string;
export type ItemName = string;
export type AssetFormKey = string;
export type FormTypeId = string;
export type FormContent = string;
export interface AssetFormEntry {
    FormTypeId?: string | undefined;
    Content?: string | undefined;
}
export type AssetFormMap = {
    [key: string]: AssetFormEntry | undefined;
};
export interface IterableFormItem {
    ItemId?: string | undefined;
    ItemName?: string | undefined;
    GlossaryTerms?: string[] | undefined;
    Forms?: {
        [key: string]: AssetFormEntry | undefined;
    } | undefined;
    Attachments?: {
        [key: string]: AssetFormEntry | undefined;
    } | undefined;
}
export type IterableFormItemList = IterableFormItem[];
export type ItemErrorCode = string;
export type ItemErrorMessage = string;
export interface ItemError {
    ItemIdentifier?: string | undefined;
    Code?: string | undefined;
    Message?: string | undefined;
}
export type ItemErrorList = ItemError[];
export interface BatchGetIterableFormsResponse {
    Items?: IterableFormItem[] | undefined;
    Errors?: ItemError[] | undefined;
}
export type JobNameList = string[];
export interface BatchGetJobsRequest {
    JobNames: string[];
}
export type JobMode = "SCRIPT" | "VISUAL" | "NOTEBOOK" | (string & {});
export type MaxConcurrentRuns = number;
export interface ExecutionProperty {
    MaxConcurrentRuns?: number | undefined;
}
export type ScriptLocationString = string;
export type PythonVersionString = string;
export type RuntimeNameString = string;
export interface JobCommand {
    Name?: string | undefined;
    ScriptLocation?: string | undefined;
    PythonVersion?: string | undefined;
    Runtime?: string | undefined;
}
export type GenericMap = {
    [key: string]: string | undefined;
};
export type ConnectionString = string;
export type ConnectionStringList = string[];
export interface ConnectionsList {
    Connections?: string[] | undefined;
}
export type MaxRetries = number;
export type NotifyDelayAfter = number;
export interface NotificationProperty {
    NotifyDelayAfter?: number | undefined;
}
export type NodeId = string;
export type NodeName = string;
export type EnclosedInStringProperty = string;
export type EnclosedInStringPropertyWithQuote = string;
export type GlueStudioColumnNameString = string;
export interface GlueStudioSchemaColumn {
    Name: string;
    Type?: string | undefined;
    GlueStudioType?: string | undefined;
}
export type GlueStudioSchemaColumnList = GlueStudioSchemaColumn[];
export interface GlueSchema {
    Columns?: GlueStudioSchemaColumn[] | undefined;
}
export type GlueSchemas = GlueSchema[];
export interface AthenaConnectorSource {
    Name: string;
    ConnectionName: string;
    ConnectorName: string;
    ConnectionType: string;
    ConnectionTable?: string | undefined;
    SchemaName: string;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type BoxedNonNegativeLong = number;
export type EnclosedInStringProperties = string[];
export type JDBCDataType = "ARRAY" | "BIGINT" | "BINARY" | "BIT" | "BLOB" | "BOOLEAN" | "CHAR" | "CLOB" | "DATALINK" | "DATE" | "DECIMAL" | "DISTINCT" | "DOUBLE" | "FLOAT" | "INTEGER" | "JAVA_OBJECT" | "LONGNVARCHAR" | "LONGVARBINARY" | "LONGVARCHAR" | "NCHAR" | "NCLOB" | "NULL" | "NUMERIC" | "NVARCHAR" | "OTHER" | "REAL" | "REF" | "REF_CURSOR" | "ROWID" | "SMALLINT" | "SQLXML" | "STRUCT" | "TIME" | "TIME_WITH_TIMEZONE" | "TIMESTAMP" | "TIMESTAMP_WITH_TIMEZONE" | "TINYINT" | "VARBINARY" | "VARCHAR" | (string & {});
export type GlueRecordType = "DATE" | "STRING" | "TIMESTAMP" | "INT" | "FLOAT" | "LONG" | "BIGDECIMAL" | "BYTE" | "SHORT" | "DOUBLE" | (string & {});
export type JDBCDataTypeMapping = {
    [key in JDBCDataType]?: GlueRecordType | undefined;
};
export interface JDBCConnectorOptions {
    FilterPredicate?: string | undefined;
    PartitionColumn?: string | undefined;
    LowerBound?: number | undefined;
    UpperBound?: number | undefined;
    NumPartitions?: number | undefined;
    JobBookmarkKeys?: string[] | undefined;
    JobBookmarkKeysSortOrder?: string | undefined;
    DataTypeMapping?: {
        [key: string]: GlueRecordType | undefined;
    } | undefined;
}
export type SqlQuery = string;
export interface JDBCConnectorSource {
    Name: string;
    ConnectionName: string;
    ConnectorName: string;
    ConnectionType: string;
    AdditionalOptions?: JDBCConnectorOptions | undefined;
    ConnectionTable?: string | undefined;
    Query?: string | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type AdditionalOptions = {
    [key: string]: string | undefined;
};
export interface SparkConnectorSource {
    Name: string;
    ConnectionName: string;
    ConnectorName: string;
    ConnectionType: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface CatalogSource {
    Name: string;
    Database: string;
    Table: string;
    PartitionPredicate?: string | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface RedshiftSource {
    Name: string;
    Database: string;
    Table: string;
    RedshiftTmpDir?: string | undefined;
    TmpDirIAMRole?: string | undefined;
}
export type BoxedLong = number;
export interface S3SourceAdditionalOptions {
    BoundedSize?: number | undefined;
    BoundedFiles?: number | undefined;
}
export interface S3CatalogSource {
    Name: string;
    Database: string;
    Table: string;
    PartitionPredicate?: string | undefined;
    AdditionalOptions?: S3SourceAdditionalOptions | undefined;
}
export type CompressionType = "gzip" | "bzip2" | (string & {});
export type BoxedBoolean = boolean;
export type BoxedNonNegativeInt = number;
export interface S3DirectSourceAdditionalOptions {
    BoundedSize?: number | undefined;
    BoundedFiles?: number | undefined;
    EnableSamplePath?: boolean | undefined;
    SamplePath?: string | undefined;
}
export type Separator = "comma" | "ctrla" | "pipe" | "semicolon" | "tab" | (string & {});
export type QuoteChar = "quote" | "quillemet" | "single_quote" | "disabled" | (string & {});
export interface S3CsvSource {
    Name: string;
    Paths: string[];
    CompressionType?: CompressionType | undefined;
    Exclusions?: string[] | undefined;
    GroupSize?: string | undefined;
    GroupFiles?: string | undefined;
    Recurse?: boolean | undefined;
    MaxBand?: number | undefined;
    MaxFilesInBand?: number | undefined;
    AdditionalOptions?: S3DirectSourceAdditionalOptions | undefined;
    Separator: Separator;
    Escaper?: string | undefined;
    QuoteChar: QuoteChar;
    Multiline?: boolean | undefined;
    WithHeader?: boolean | undefined;
    WriteHeader?: boolean | undefined;
    SkipFirst?: boolean | undefined;
    OptimizePerformance?: boolean | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface S3JsonSource {
    Name: string;
    Paths: string[];
    CompressionType?: CompressionType | undefined;
    Exclusions?: string[] | undefined;
    GroupSize?: string | undefined;
    GroupFiles?: string | undefined;
    Recurse?: boolean | undefined;
    MaxBand?: number | undefined;
    MaxFilesInBand?: number | undefined;
    AdditionalOptions?: S3DirectSourceAdditionalOptions | undefined;
    JsonPath?: string | undefined;
    Multiline?: boolean | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type ParquetCompressionType = "snappy" | "lzo" | "gzip" | "brotli" | "lz4" | "uncompressed" | "none" | (string & {});
export interface S3ParquetSource {
    Name: string;
    Paths: string[];
    CompressionType?: ParquetCompressionType | undefined;
    Exclusions?: string[] | undefined;
    GroupSize?: string | undefined;
    GroupFiles?: string | undefined;
    Recurse?: boolean | undefined;
    MaxBand?: number | undefined;
    MaxFilesInBand?: number | undefined;
    AdditionalOptions?: S3DirectSourceAdditionalOptions | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface RelationalCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export interface DDBELTCatalogAdditionalOptions {
    DynamodbExport?: string | undefined;
    DynamodbUnnestDDBJson?: boolean | undefined;
}
export interface DynamoDBCatalogSource {
    Name: string;
    Database: string;
    Table: string;
    PitrEnabled?: boolean | undefined;
    AdditionalOptions?: DDBELTCatalogAdditionalOptions | undefined;
}
export type OneInput = string[];
export interface JDBCConnectorTarget {
    Name: string;
    Inputs: string[];
    ConnectionName: string;
    ConnectionTable: string;
    ConnectorName: string;
    ConnectionType: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface SparkConnectorTarget {
    Name: string;
    Inputs: string[];
    ConnectionName: string;
    ConnectorName: string;
    ConnectionType: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type GlueStudioPathList = string[][];
export interface BasicCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Database: string;
    Table: string;
}
export type EnclosedInStringPropertiesMinOne = string[];
export interface UpsertRedshiftTargetOptions {
    TableLocation?: string | undefined;
    ConnectionName?: string | undefined;
    UpsertKeys?: string[] | undefined;
}
export interface RedshiftTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
    RedshiftTmpDir?: string | undefined;
    TmpDirIAMRole?: string | undefined;
    UpsertRedshiftOptions?: UpsertRedshiftTargetOptions | undefined;
}
export type UpdateCatalogBehavior = "UPDATE_IN_DATABASE" | "LOG" | (string & {});
export interface CatalogSchemaChangePolicy {
    EnableUpdateCatalog?: boolean | undefined;
    UpdateBehavior?: UpdateCatalogBehavior | undefined;
}
export interface AutoDataQuality {
    IsEnabled?: boolean | undefined;
    EvaluationContext?: string | undefined;
}
export interface S3CatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Table: string;
    Database: string;
    SchemaChangePolicy?: CatalogSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
}
export type NumberTargetPartitionsString = string;
export interface DirectSchemaChangePolicy {
    EnableUpdateCatalog?: boolean | undefined;
    UpdateBehavior?: UpdateCatalogBehavior | undefined;
    Table?: string | undefined;
    Database?: string | undefined;
}
export interface S3GlueParquetTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Path: string;
    Compression?: ParquetCompressionType | undefined;
    NumberTargetPartitions?: string | undefined;
    SchemaChangePolicy?: DirectSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
}
export type TargetFormat = "json" | "csv" | "avro" | "orc" | "parquet" | "hudi" | "delta" | "iceberg" | "hyper" | "xml" | (string & {});
export interface S3DirectTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Path: string;
    Compression?: string | undefined;
    NumberTargetPartitions?: string | undefined;
    Format: TargetFormat;
    SchemaChangePolicy?: DirectSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface Mapping {
    ToKey?: string | undefined;
    FromPath?: string[] | undefined;
    FromType?: string | undefined;
    ToType?: string | undefined;
    Dropped?: boolean | undefined;
    Children?: Mapping[] | undefined;
}
export type Mappings = Mapping[];
export interface ApplyMapping {
    Name: string;
    Inputs: string[];
    Mapping: Mapping[];
}
export interface SelectFields {
    Name: string;
    Inputs: string[];
    Paths: string[][];
}
export interface DropFields {
    Name: string;
    Inputs: string[];
    Paths: string[][];
}
export interface RenameField {
    Name: string;
    Inputs: string[];
    SourcePath: string[];
    TargetPath: string[];
}
export type Topk = number;
export type Prob = number;
export interface Spigot {
    Name: string;
    Inputs: string[];
    Path: string;
    Topk?: number | undefined;
    Prob?: number | undefined;
}
export type TwoInputs = string[];
export type JoinType = "equijoin" | "left" | "right" | "outer" | "leftsemi" | "leftanti" | (string & {});
export interface JoinColumn {
    From: string;
    Keys: string[][];
}
export type JoinColumns = JoinColumn[];
export interface Join {
    Name: string;
    Inputs: string[];
    JoinType: JoinType;
    Columns: JoinColumn[];
}
export interface SplitFields {
    Name: string;
    Inputs: string[];
    Paths: string[][];
}
export type NonNegativeInt = number;
export interface SelectFromCollection {
    Name: string;
    Inputs: string[];
    Index: number;
}
export interface FillMissingValues {
    Name: string;
    Inputs: string[];
    ImputedPath: string;
    FilledPath?: string | undefined;
}
export type FilterLogicalOperator = "AND" | "OR" | (string & {});
export type FilterOperation = "EQ" | "LT" | "GT" | "LTE" | "GTE" | "REGEX" | "ISNULL" | (string & {});
export type FilterValueType = "COLUMNEXTRACTED" | "CONSTANT" | (string & {});
export interface FilterValue {
    Type: FilterValueType;
    Value: string[];
}
export type FilterValues = FilterValue[];
export interface FilterExpression {
    Operation: FilterOperation;
    Negated?: boolean | undefined;
    Values: FilterValue[];
}
export type FilterExpressions = FilterExpression[];
export interface Filter {
    Name: string;
    Inputs: string[];
    LogicalOperator: FilterLogicalOperator;
    Filters: FilterExpression[];
}
export type ManyInputs = string[];
export type ExtendedString = string;
export interface CustomCode {
    Name: string;
    Inputs: string[];
    Code: string;
    ClassName: string;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface SqlAlias {
    From: string;
    Alias: string;
}
export type SqlAliases = SqlAlias[];
export interface SparkSQL {
    Name: string;
    Inputs: string[];
    SqlQuery: string;
    SqlAliases: SqlAlias[];
    OutputSchemas?: GlueSchema[] | undefined;
}
export type BoxedPositiveInt = number;
export type StartingPosition = "latest" | "trim_horizon" | "earliest" | "timestamp" | (string & {});
export type Iso8601DateTime = Date;
export interface KinesisStreamingSourceOptions {
    EndpointUrl?: string | undefined;
    StreamName?: string | undefined;
    Classification?: string | undefined;
    Delimiter?: string | undefined;
    StartingPosition?: StartingPosition | undefined;
    MaxFetchTimeInMs?: number | undefined;
    MaxFetchRecordsPerShard?: number | undefined;
    MaxRecordPerRead?: number | undefined;
    AddIdleTimeBetweenReads?: boolean | undefined;
    IdleTimeBetweenReadsInMs?: number | undefined;
    DescribeShardInterval?: number | undefined;
    NumRetries?: number | undefined;
    RetryIntervalMs?: number | undefined;
    MaxRetryIntervalMs?: number | undefined;
    AvoidEmptyBatches?: boolean | undefined;
    StreamArn?: string | undefined;
    RoleArn?: string | undefined;
    RoleSessionName?: string | undefined;
    AddRecordTimestamp?: string | undefined;
    EmitConsumerLagMetrics?: string | undefined;
    StartingTimestamp?: Date | undefined;
    FanoutConsumerARN?: string | undefined;
}
export type PollingTime = number;
export type PositiveLong = number;
export interface StreamingDataPreviewOptions {
    PollingTime?: number | undefined;
    RecordPollingLimit?: number | undefined;
}
export interface DirectKinesisSource {
    Name: string;
    WindowSize?: number | undefined;
    DetectSchema?: boolean | undefined;
    StreamingOptions?: KinesisStreamingSourceOptions | undefined;
    DataPreviewOptions?: StreamingDataPreviewOptions | undefined;
}
export interface KafkaStreamingSourceOptions {
    BootstrapServers?: string | undefined;
    SecurityProtocol?: string | undefined;
    ConnectionName?: string | undefined;
    TopicName?: string | undefined;
    Assign?: string | undefined;
    SubscribePattern?: string | undefined;
    Classification?: string | undefined;
    Delimiter?: string | undefined;
    StartingOffsets?: string | undefined;
    EndingOffsets?: string | undefined;
    PollTimeoutMs?: number | undefined;
    NumRetries?: number | undefined;
    RetryIntervalMs?: number | undefined;
    MaxOffsetsPerTrigger?: number | undefined;
    MinPartitions?: number | undefined;
    IncludeHeaders?: boolean | undefined;
    AddRecordTimestamp?: string | undefined;
    EmitConsumerLagMetrics?: string | undefined;
    StartingTimestamp?: Date | undefined;
}
export interface DirectKafkaSource {
    Name: string;
    StreamingOptions?: KafkaStreamingSourceOptions | undefined;
    WindowSize?: number | undefined;
    DetectSchema?: boolean | undefined;
    DataPreviewOptions?: StreamingDataPreviewOptions | undefined;
}
export interface CatalogKinesisSource {
    Name: string;
    WindowSize?: number | undefined;
    DetectSchema?: boolean | undefined;
    Table: string;
    Database: string;
    StreamingOptions?: KinesisStreamingSourceOptions | undefined;
    DataPreviewOptions?: StreamingDataPreviewOptions | undefined;
}
export interface CatalogKafkaSource {
    Name: string;
    WindowSize?: number | undefined;
    DetectSchema?: boolean | undefined;
    Table: string;
    Database: string;
    StreamingOptions?: KafkaStreamingSourceOptions | undefined;
    DataPreviewOptions?: StreamingDataPreviewOptions | undefined;
}
export interface NullCheckBoxList {
    IsEmpty?: boolean | undefined;
    IsNullString?: boolean | undefined;
    IsNegOne?: boolean | undefined;
}
export type GenericLimitedString = string;
export interface Datatype {
    Id: string;
    Label: string;
}
export interface NullValueField {
    Value: string;
    Datatype: Datatype;
}
export type NullValueFields = NullValueField[];
export interface DropNullFields {
    Name: string;
    Inputs: string[];
    NullCheckBoxList?: NullCheckBoxList | undefined;
    NullTextList?: NullValueField[] | undefined;
}
export interface Merge {
    Name: string;
    Inputs: string[];
    Source: string;
    PrimaryKeys: string[][];
}
export type UnionType = "ALL" | "DISTINCT" | (string & {});
export interface Union {
    Name: string;
    Inputs: string[];
    UnionType: UnionType;
}
export type PiiType = "RowAudit" | "RowHashing" | "RowMasking" | "RowPartialMasking" | "ColumnAudit" | "ColumnHashing" | "ColumnMasking" | (string & {});
export type BoxedDoubleFraction = number;
export type MaskValue = string;
export interface PIIDetection {
    Name: string;
    Inputs: string[];
    PiiType: PiiType;
    EntityTypesToDetect: string[];
    OutputColumnName?: string | undefined;
    SampleFraction?: number | undefined;
    ThresholdFraction?: number | undefined;
    MaskValue?: string | undefined;
    RedactText?: string | undefined;
    RedactChar?: string | undefined;
    MatchPattern?: string | undefined;
    NumLeftCharsToExclude?: number | undefined;
    NumRightCharsToExclude?: number | undefined;
    DetectionParameters?: string | undefined;
    DetectionSensitivity?: string | undefined;
}
export type AggFunction = "avg" | "countDistinct" | "count" | "first" | "last" | "kurtosis" | "max" | "min" | "skewness" | "stddev_samp" | "stddev_pop" | "sum" | "sumDistinct" | "var_samp" | "var_pop" | (string & {});
export interface AggregateOperation {
    Column: string[];
    AggFunc: AggFunction;
}
export type AggregateOperations = AggregateOperation[];
export interface Aggregate {
    Name: string;
    Inputs: string[];
    Groups: string[][];
    Aggs: AggregateOperation[];
}
export type LimitedStringList = string[];
export type LimitedPathList = string[][];
export interface DropDuplicates {
    Name: string;
    Inputs: string[];
    Columns?: string[][] | undefined;
}
export interface GovernedCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Table: string;
    Database: string;
    SchemaChangePolicy?: CatalogSchemaChangePolicy | undefined;
}
export interface GovernedCatalogSource {
    Name: string;
    Database: string;
    Table: string;
    PartitionPredicate?: string | undefined;
    AdditionalOptions?: S3SourceAdditionalOptions | undefined;
}
export interface MicrosoftSQLServerCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export interface MySQLCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export interface OracleSQLCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export interface PostgreSQLCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export interface MicrosoftSQLServerCatalogTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
}
export interface MySQLCatalogTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
}
export interface OracleSQLCatalogTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
}
export interface PostgreSQLCatalogTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
}
export interface GroupFilters {
    GroupName: string;
    Filters: FilterExpression[];
    LogicalOperator: FilterLogicalOperator;
}
export type GroupFiltersList = GroupFilters[];
export interface Route {
    Name: string;
    Inputs: string[];
    GroupFiltersList: GroupFilters[];
}
export type ParamType = "str" | "int" | "float" | "complex" | "bool" | "list" | "null" | (string & {});
export interface TransformConfigParameter {
    Name: string;
    Type: ParamType;
    ValidationRule?: string | undefined;
    ValidationMessage?: string | undefined;
    Value?: string[] | undefined;
    ListType?: ParamType | undefined;
    IsOptional?: boolean | undefined;
}
export type TransformConfigParameterList = TransformConfigParameter[];
export interface DynamicTransform {
    Name: string;
    TransformName: string;
    Inputs: string[];
    Parameters?: TransformConfigParameter[] | undefined;
    FunctionName: string;
    Path: string;
    Version?: string | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type DQDLString = string;
export type DQTransformOutput = "PrimaryInput" | "EvaluationResults" | (string & {});
export interface DQResultsPublishingOptions {
    EvaluationContext?: string | undefined;
    ResultsS3Prefix?: string | undefined;
    CloudWatchMetricsEnabled?: boolean | undefined;
    ResultsPublishingEnabled?: boolean | undefined;
}
export type DQStopJobOnFailureTiming = "Immediate" | "AfterDataLoad" | (string & {});
export interface DQStopJobOnFailureOptions {
    StopJobOnFailureTiming?: DQStopJobOnFailureTiming | undefined;
}
export interface EvaluateDataQuality {
    Name: string;
    Inputs: string[];
    Ruleset: string;
    Output?: DQTransformOutput | undefined;
    PublishingOptions?: DQResultsPublishingOptions | undefined;
    StopJobOnFailureOptions?: DQStopJobOnFailureOptions | undefined;
}
export interface S3CatalogHudiSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalHudiOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface CatalogHudiSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalHudiOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface S3HudiSource {
    Name: string;
    Paths: string[];
    AdditionalHudiOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    AdditionalOptions?: S3DirectSourceAdditionalOptions | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface S3HudiCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Table: string;
    Database: string;
    AdditionalOptions: {
        [key: string]: string | undefined;
    };
    SchemaChangePolicy?: CatalogSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type HudiTargetCompressionType = "gzip" | "lzo" | "uncompressed" | "snappy" | (string & {});
export interface S3HudiDirectTarget {
    Name: string;
    Inputs: string[];
    Path: string;
    Compression: HudiTargetCompressionType;
    NumberTargetPartitions?: string | undefined;
    PartitionKeys?: string[][] | undefined;
    Format: TargetFormat;
    AdditionalOptions: {
        [key: string]: string | undefined;
    };
    SchemaChangePolicy?: DirectSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
}
export type JDBCConnectionType = "sqlserver" | "mysql" | "oracle" | "postgresql" | "redshift" | (string & {});
export interface DirectJDBCSource {
    Name: string;
    Database: string;
    Table: string;
    ConnectionName: string;
    ConnectionType: JDBCConnectionType;
    RedshiftTmpDir?: string | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface S3CatalogDeltaSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalDeltaOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface CatalogDeltaSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalDeltaOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface S3DeltaSource {
    Name: string;
    Paths: string[];
    AdditionalDeltaOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    AdditionalOptions?: S3DirectSourceAdditionalOptions | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface S3DeltaCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Table: string;
    Database: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    SchemaChangePolicy?: CatalogSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type DeltaTargetCompressionType = "uncompressed" | "snappy" | (string & {});
export interface S3DeltaDirectTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Path: string;
    Compression: DeltaTargetCompressionType;
    NumberTargetPartitions?: string | undefined;
    Format: TargetFormat;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    SchemaChangePolicy?: DirectSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
}
export interface Option {
    Value?: string | undefined;
    Label?: string | undefined;
    Description?: string | undefined;
}
export interface AmazonRedshiftAdvancedOption {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type AmazonRedshiftAdvancedOptions = AmazonRedshiftAdvancedOption[];
export type OptionList = Option[];
export interface AmazonRedshiftNodeData {
    AccessType?: string | undefined;
    SourceType?: string | undefined;
    Connection?: Option | undefined;
    Schema?: Option | undefined;
    Table?: Option | undefined;
    CatalogDatabase?: Option | undefined;
    CatalogTable?: Option | undefined;
    CatalogRedshiftSchema?: string | undefined;
    CatalogRedshiftTable?: string | undefined;
    TempDir?: string | undefined;
    IamRole?: Option | undefined;
    AdvancedOptions?: AmazonRedshiftAdvancedOption[] | undefined;
    SampleQuery?: string | undefined;
    PreAction?: string | undefined;
    PostAction?: string | undefined;
    Action?: string | undefined;
    TablePrefix?: string | undefined;
    Upsert?: boolean | undefined;
    MergeAction?: string | undefined;
    MergeWhenMatched?: string | undefined;
    MergeWhenNotMatched?: string | undefined;
    MergeClause?: string | undefined;
    CrawlerConnection?: string | undefined;
    TableSchema?: Option[] | undefined;
    StagingTable?: string | undefined;
    SelectedColumns?: Option[] | undefined;
}
export interface AmazonRedshiftSource {
    Name?: string | undefined;
    Data?: AmazonRedshiftNodeData | undefined;
}
export interface AmazonRedshiftTarget {
    Name?: string | undefined;
    Data?: AmazonRedshiftNodeData | undefined;
    Inputs?: string[] | undefined;
}
export type DQDLAliases = {
    [key: string]: string | undefined;
};
export type AdditionalOptionKeys = "performanceTuning.caching" | "observations.scope" | "compositeRuleEvaluation.method" | (string & {});
export type DQAdditionalOptions = {
    [key in AdditionalOptionKeys]?: string | undefined;
};
export interface EvaluateDataQualityMultiFrame {
    Name: string;
    Inputs: string[];
    AdditionalDataSources?: {
        [key: string]: string | undefined;
    } | undefined;
    Ruleset: string;
    PublishingOptions?: DQResultsPublishingOptions | undefined;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    StopJobOnFailureOptions?: DQStopJobOnFailureOptions | undefined;
}
export type RecipeVersion = string;
export interface RecipeReference {
    RecipeArn: string;
    RecipeVersion: string;
}
export type Operation = string;
export type ParameterName = string;
export type ParameterValue = string;
export type ParameterMap = {
    [key: string]: string | undefined;
};
export interface RecipeAction {
    Operation: string;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DatabrewCondition = string;
export type DatabrewConditionValue = string;
export type TargetColumn = string;
export interface ConditionExpression {
    Condition: string;
    Value?: string | undefined;
    TargetColumn: string;
}
export type ConditionExpressionList = ConditionExpression[];
export interface RecipeStep {
    Action: RecipeAction;
    ConditionExpressions?: ConditionExpression[] | undefined;
}
export type RecipeSteps = RecipeStep[];
export interface Recipe {
    Name: string;
    Inputs: string[];
    RecipeReference?: RecipeReference | undefined;
    RecipeSteps?: RecipeStep[] | undefined;
}
export interface SnowflakeNodeData {
    SourceType?: string | undefined;
    Connection?: Option | undefined;
    Schema?: string | undefined;
    Table?: string | undefined;
    Database?: string | undefined;
    TempDir?: string | undefined;
    IamRole?: Option | undefined;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    SampleQuery?: string | undefined;
    PreAction?: string | undefined;
    PostAction?: string | undefined;
    Action?: string | undefined;
    Upsert?: boolean | undefined;
    MergeAction?: string | undefined;
    MergeWhenMatched?: string | undefined;
    MergeWhenNotMatched?: string | undefined;
    MergeClause?: string | undefined;
    StagingTable?: string | undefined;
    SelectedColumns?: Option[] | undefined;
    AutoPushdown?: boolean | undefined;
    TableSchema?: Option[] | undefined;
}
export interface SnowflakeSource {
    Name: string;
    Data: SnowflakeNodeData;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface SnowflakeTarget {
    Name: string;
    Data: SnowflakeNodeData;
    Inputs?: string[] | undefined;
}
export type ConnectorOptions = {
    [key: string]: string | undefined;
};
export interface ConnectorDataSource {
    Name: string;
    ConnectionType: string;
    Data: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface ConnectorDataTarget {
    Name: string;
    ConnectionType: string;
    Data: {
        [key: string]: string | undefined;
    };
    Inputs?: string[] | undefined;
}
export interface S3CatalogIcebergSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalIcebergOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface CatalogIcebergSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalIcebergOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface S3IcebergCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Table: string;
    Database: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    SchemaChangePolicy?: CatalogSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
}
export type IcebergTargetCompressionType = "gzip" | "lzo" | "uncompressed" | "snappy" | (string & {});
export interface S3IcebergDirectTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][] | undefined;
    Path: string;
    Format: TargetFormat;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    SchemaChangePolicy?: DirectSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
    Compression: IcebergTargetCompressionType;
    NumberTargetPartitions?: string | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface S3ExcelSource {
    Name: string;
    Paths: string[];
    CompressionType?: ParquetCompressionType | undefined;
    Exclusions?: string[] | undefined;
    GroupSize?: string | undefined;
    GroupFiles?: string | undefined;
    Recurse?: boolean | undefined;
    MaxBand?: number | undefined;
    MaxFilesInBand?: number | undefined;
    AdditionalOptions?: S3DirectSourceAdditionalOptions | undefined;
    NumberRows?: number | undefined;
    SkipFooter?: number | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type HyperTargetCompressionType = "uncompressed" | (string & {});
export interface S3HyperDirectTarget {
    Name: string;
    Inputs: string[];
    Format?: TargetFormat | undefined;
    PartitionKeys?: string[][] | undefined;
    Path: string;
    Compression?: HyperTargetCompressionType | undefined;
    SchemaChangePolicy?: DirectSchemaChangePolicy | undefined;
    AutoDataQuality?: AutoDataQuality | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export type DdbExportType = "ddb" | "s3" | (string & {});
export interface DDBELTConnectionOptions {
    DynamodbExport?: DdbExportType | undefined;
    DynamodbUnnestDDBJson?: boolean | undefined;
    DynamodbTableArn: string;
    DynamodbS3Bucket?: string | undefined;
    DynamodbS3Prefix?: string | undefined;
    DynamodbS3BucketOwner?: string | undefined;
    DynamodbStsRoleArn?: string | undefined;
}
export interface DynamoDBELTConnectorSource {
    Name: string;
    ConnectionOptions?: DDBELTConnectionOptions | undefined;
    OutputSchemas?: GlueSchema[] | undefined;
}
export interface CodeGenConfigurationNode {
    AthenaConnectorSource?: AthenaConnectorSource | undefined;
    JDBCConnectorSource?: JDBCConnectorSource | undefined;
    SparkConnectorSource?: SparkConnectorSource | undefined;
    CatalogSource?: CatalogSource | undefined;
    RedshiftSource?: RedshiftSource | undefined;
    S3CatalogSource?: S3CatalogSource | undefined;
    S3CsvSource?: S3CsvSource | undefined;
    S3JsonSource?: S3JsonSource | undefined;
    S3ParquetSource?: S3ParquetSource | undefined;
    RelationalCatalogSource?: RelationalCatalogSource | undefined;
    DynamoDBCatalogSource?: DynamoDBCatalogSource | undefined;
    JDBCConnectorTarget?: JDBCConnectorTarget | undefined;
    SparkConnectorTarget?: SparkConnectorTarget | undefined;
    CatalogTarget?: BasicCatalogTarget | undefined;
    RedshiftTarget?: RedshiftTarget | undefined;
    S3CatalogTarget?: S3CatalogTarget | undefined;
    S3GlueParquetTarget?: S3GlueParquetTarget | undefined;
    S3DirectTarget?: S3DirectTarget | undefined;
    ApplyMapping?: ApplyMapping | undefined;
    SelectFields?: SelectFields | undefined;
    DropFields?: DropFields | undefined;
    RenameField?: RenameField | undefined;
    Spigot?: Spigot | undefined;
    Join?: Join | undefined;
    SplitFields?: SplitFields | undefined;
    SelectFromCollection?: SelectFromCollection | undefined;
    FillMissingValues?: FillMissingValues | undefined;
    Filter?: Filter | undefined;
    CustomCode?: CustomCode | undefined;
    SparkSQL?: SparkSQL | undefined;
    DirectKinesisSource?: DirectKinesisSource | undefined;
    DirectKafkaSource?: DirectKafkaSource | undefined;
    CatalogKinesisSource?: CatalogKinesisSource | undefined;
    CatalogKafkaSource?: CatalogKafkaSource | undefined;
    DropNullFields?: DropNullFields | undefined;
    Merge?: Merge | undefined;
    Union?: Union | undefined;
    PIIDetection?: PIIDetection | undefined;
    Aggregate?: Aggregate | undefined;
    DropDuplicates?: DropDuplicates | undefined;
    GovernedCatalogTarget?: GovernedCatalogTarget | undefined;
    GovernedCatalogSource?: GovernedCatalogSource | undefined;
    MicrosoftSQLServerCatalogSource?: MicrosoftSQLServerCatalogSource | undefined;
    MySQLCatalogSource?: MySQLCatalogSource | undefined;
    OracleSQLCatalogSource?: OracleSQLCatalogSource | undefined;
    PostgreSQLCatalogSource?: PostgreSQLCatalogSource | undefined;
    MicrosoftSQLServerCatalogTarget?: MicrosoftSQLServerCatalogTarget | undefined;
    MySQLCatalogTarget?: MySQLCatalogTarget | undefined;
    OracleSQLCatalogTarget?: OracleSQLCatalogTarget | undefined;
    PostgreSQLCatalogTarget?: PostgreSQLCatalogTarget | undefined;
    Route?: Route | undefined;
    DynamicTransform?: DynamicTransform | undefined;
    EvaluateDataQuality?: EvaluateDataQuality | undefined;
    S3CatalogHudiSource?: S3CatalogHudiSource | undefined;
    CatalogHudiSource?: CatalogHudiSource | undefined;
    S3HudiSource?: S3HudiSource | undefined;
    S3HudiCatalogTarget?: S3HudiCatalogTarget | undefined;
    S3HudiDirectTarget?: S3HudiDirectTarget | undefined;
    DirectJDBCSource?: DirectJDBCSource | undefined;
    S3CatalogDeltaSource?: S3CatalogDeltaSource | undefined;
    CatalogDeltaSource?: CatalogDeltaSource | undefined;
    S3DeltaSource?: S3DeltaSource | undefined;
    S3DeltaCatalogTarget?: S3DeltaCatalogTarget | undefined;
    S3DeltaDirectTarget?: S3DeltaDirectTarget | undefined;
    AmazonRedshiftSource?: AmazonRedshiftSource | undefined;
    AmazonRedshiftTarget?: AmazonRedshiftTarget | undefined;
    EvaluateDataQualityMultiFrame?: EvaluateDataQualityMultiFrame | undefined;
    Recipe?: Recipe | undefined;
    SnowflakeSource?: SnowflakeSource | undefined;
    SnowflakeTarget?: SnowflakeTarget | undefined;
    ConnectorDataSource?: ConnectorDataSource | undefined;
    ConnectorDataTarget?: ConnectorDataTarget | undefined;
    S3CatalogIcebergSource?: S3CatalogIcebergSource | undefined;
    CatalogIcebergSource?: CatalogIcebergSource | undefined;
    S3IcebergCatalogTarget?: S3IcebergCatalogTarget | undefined;
    S3IcebergDirectTarget?: S3IcebergDirectTarget | undefined;
    S3ExcelSource?: S3ExcelSource | undefined;
    S3HyperDirectTarget?: S3HyperDirectTarget | undefined;
    DynamoDBELTConnectorSource?: DynamoDBELTConnectorSource | undefined;
}
export type CodeGenConfigurationNodes = {
    [key: string]: CodeGenConfigurationNode | undefined;
};
export type ExecutionClass = "FLEX" | "STANDARD" | (string & {});
export type SourceControlProvider = "GITHUB" | "GITLAB" | "BITBUCKET" | "AWS_CODE_COMMIT" | (string & {});
export type SourceControlAuthStrategy = "PERSONAL_ACCESS_TOKEN" | "AWS_SECRETS_MANAGER" | (string & {});
export interface SourceControlDetails {
    Provider?: SourceControlProvider | undefined;
    Repository?: string | undefined;
    Owner?: string | undefined;
    Branch?: string | undefined;
    Folder?: string | undefined;
    LastCommitId?: string | undefined;
    AuthStrategy?: SourceControlAuthStrategy | undefined;
    AuthToken?: string | undefined;
}
export type MaintenanceWindow = string;
export type AutoUpgradeStatus = "OBSERVING" | "UPGRADING" | "UPGRADE_SUCCEEDED" | "UPGRADE_FAILED" | "STOPPED" | "WAITING_FOR_CONSENT" | (string & {});
export type IdString = string;
export interface AutoUpgradeMetadata {
    TargetVersion?: string | undefined;
    SourceVersion?: string | undefined;
    Status?: AutoUpgradeStatus | undefined;
    AnalysisId?: string | undefined;
}
export interface Job {
    Name?: string | undefined;
    JobMode?: JobMode | undefined;
    JobRunQueuingEnabled?: boolean | undefined;
    Description?: string | undefined;
    LogUri?: string | undefined;
    Role?: string | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    ExecutionProperty?: ExecutionProperty | undefined;
    Command?: JobCommand | undefined;
    DefaultArguments?: {
        [key: string]: string | undefined;
    } | undefined;
    NonOverridableArguments?: {
        [key: string]: string | undefined;
    } | undefined;
    Connections?: ConnectionsList | undefined;
    MaxRetries?: number | undefined;
    AllocatedCapacity?: number | undefined;
    Timeout?: number | undefined;
    MaxCapacity?: number | undefined;
    WorkerType?: WorkerType | undefined;
    NumberOfWorkers?: number | undefined;
    SecurityConfiguration?: string | undefined;
    NotificationProperty?: NotificationProperty | undefined;
    GlueVersion?: string | undefined;
    CodeGenConfigurationNodes?: {
        [key: string]: CodeGenConfigurationNode | undefined;
    } | undefined;
    ExecutionClass?: ExecutionClass | undefined;
    SourceControlDetails?: SourceControlDetails | undefined;
    MaintenanceWindow?: string | undefined;
    ProfileName?: string | undefined;
    AutoUpgradeMetadata?: AutoUpgradeMetadata | undefined;
}
export type JobList = Job[];
export interface BatchGetJobsResponse {
    Jobs?: Job[] | undefined;
    JobsNotFound?: string[] | undefined;
}
export type BatchGetPartitionValueList = PartitionValueList[];
export type AuditContextString = string;
export type ColumnNameString = string;
export type AuditColumnNamesList = string[];
export interface AuditContext {
    AdditionalAuditContext?: string | undefined;
    RequestedColumns?: string[] | undefined;
    AllColumnsRequested?: boolean | undefined;
}
export type NullableString = string;
export type ContextKey = string;
export type ContextValue = string;
export type AdditionalContextMap = {
    [key: string]: string | undefined;
};
export interface QuerySessionContext {
    QueryId?: string | undefined;
    QueryStartTime?: Date | undefined;
    ClusterId?: string | undefined;
    QueryAuthorizationId?: string | undefined;
    AdditionalContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface BatchGetPartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionsToGet: PartitionValueList[];
    AuditContext?: AuditContext | undefined;
    QuerySessionContext?: QuerySessionContext | undefined;
}
export interface Partition {
    Values?: string[] | undefined;
    DatabaseName?: string | undefined;
    TableName?: string | undefined;
    CreationTime?: Date | undefined;
    LastAccessTime?: Date | undefined;
    StorageDescriptor?: StorageDescriptor | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    LastAnalyzedTime?: Date | undefined;
    CatalogId?: string | undefined;
}
export type PartitionList = Partition[];
export interface BatchGetPartitionResponse {
    Partitions?: Partition[] | undefined;
    UnprocessedKeys?: PartitionValueList[] | undefined;
}
export type DatabaseNameString = string;
export type TableNameString = string;
export type TableOptimizerType = "compaction" | "retention" | "orphan_file_deletion" | (string & {});
export interface BatchGetTableOptimizerEntry {
    catalogId?: string | undefined;
    databaseName?: string | undefined;
    tableName?: string | undefined;
    type?: TableOptimizerType | undefined;
}
export type BatchGetTableOptimizerEntries = BatchGetTableOptimizerEntry[];
export interface BatchGetTableOptimizerRequest {
    Entries: BatchGetTableOptimizerEntry[];
}
export type ArnString = string;
export type GlueConnectionNameString = string;
export type TableOptimizerVpcConfiguration = {
    glueConnectionName: string;
};
export type CompactionStrategy = "binpack" | "sort" | "z-order" | (string & {});
export interface IcebergCompactionConfiguration {
    strategy?: CompactionStrategy | undefined;
    minInputFiles?: number | undefined;
    deleteFileThreshold?: number | undefined;
}
export interface CompactionConfiguration {
    icebergConfiguration?: IcebergCompactionConfiguration | undefined;
}
export interface IcebergRetentionConfiguration {
    snapshotRetentionPeriodInDays?: number | undefined;
    numberOfSnapshotsToRetain?: number | undefined;
    cleanExpiredFiles?: boolean | undefined;
    runRateInHours?: number | undefined;
}
export interface RetentionConfiguration {
    icebergConfiguration?: IcebergRetentionConfiguration | undefined;
}
export type MessageString = string;
export interface IcebergOrphanFileDeletionConfiguration {
    orphanFileRetentionPeriodInDays?: number | undefined;
    location?: string | undefined;
    runRateInHours?: number | undefined;
}
export interface OrphanFileDeletionConfiguration {
    icebergConfiguration?: IcebergOrphanFileDeletionConfiguration | undefined;
}
export interface TableOptimizerConfiguration {
    roleArn?: string | undefined;
    enabled?: boolean | undefined;
    vpcConfiguration?: TableOptimizerVpcConfiguration | undefined;
    compactionConfiguration?: CompactionConfiguration | undefined;
    retentionConfiguration?: RetentionConfiguration | undefined;
    orphanFileDeletionConfiguration?: OrphanFileDeletionConfiguration | undefined;
}
export type TableOptimizerEventType = "starting" | "completed" | "failed" | "in_progress" | (string & {});
export type TableOptimizerRunTimestamp = Date;
export interface RunMetrics {
    NumberOfBytesCompacted?: string | undefined;
    NumberOfFilesCompacted?: string | undefined;
    NumberOfDpus?: string | undefined;
    JobDurationInHour?: string | undefined;
}
export type MetricCounts = number;
export type DpuHours = number;
export type DpuCounts = number;
export type DpuDurationInHour = number;
export interface IcebergCompactionMetrics {
    NumberOfBytesCompacted?: number | undefined;
    NumberOfFilesCompacted?: number | undefined;
    DpuHours?: number | undefined;
    NumberOfDpus?: number | undefined;
    JobDurationInHour?: number | undefined;
}
export interface CompactionMetrics {
    IcebergMetrics?: IcebergCompactionMetrics | undefined;
}
export interface IcebergRetentionMetrics {
    NumberOfDataFilesDeleted?: number | undefined;
    NumberOfManifestFilesDeleted?: number | undefined;
    NumberOfManifestListsDeleted?: number | undefined;
    DpuHours?: number | undefined;
    NumberOfDpus?: number | undefined;
    JobDurationInHour?: number | undefined;
}
export interface RetentionMetrics {
    IcebergMetrics?: IcebergRetentionMetrics | undefined;
}
export interface IcebergOrphanFileDeletionMetrics {
    NumberOfOrphanFilesDeleted?: number | undefined;
    DpuHours?: number | undefined;
    NumberOfDpus?: number | undefined;
    JobDurationInHour?: number | undefined;
}
export interface OrphanFileDeletionMetrics {
    IcebergMetrics?: IcebergOrphanFileDeletionMetrics | undefined;
}
export interface TableOptimizerRun {
    eventType?: TableOptimizerEventType | undefined;
    startTimestamp?: Date | undefined;
    endTimestamp?: Date | undefined;
    metrics?: RunMetrics | undefined;
    error?: string | undefined;
    compactionMetrics?: CompactionMetrics | undefined;
    compactionStrategy?: CompactionStrategy | undefined;
    retentionMetrics?: RetentionMetrics | undefined;
    orphanFileDeletionMetrics?: OrphanFileDeletionMetrics | undefined;
}
export type ConfigurationSource = "catalog" | "table" | (string & {});
export interface TableOptimizer {
    type?: TableOptimizerType | undefined;
    configuration?: TableOptimizerConfiguration | undefined;
    lastRun?: TableOptimizerRun | undefined;
    configurationSource?: ConfigurationSource | undefined;
}
export interface BatchTableOptimizer {
    catalogId?: string | undefined;
    databaseName?: string | undefined;
    tableName?: string | undefined;
    tableOptimizer?: TableOptimizer | undefined;
}
export type BatchTableOptimizers = BatchTableOptimizer[];
export interface BatchGetTableOptimizerError_ {
    error?: ErrorDetail | undefined;
    catalogId?: string | undefined;
    databaseName?: string | undefined;
    tableName?: string | undefined;
    type?: TableOptimizerType | undefined;
}
export type BatchGetTableOptimizerErrors = BatchGetTableOptimizerError_[];
export interface BatchGetTableOptimizerResponse {
    TableOptimizers?: BatchTableOptimizer[] | undefined;
    Failures?: BatchGetTableOptimizerError_[] | undefined;
}
export type TriggerNameList = string[];
export interface BatchGetTriggersRequest {
    TriggerNames: string[];
}
export type TriggerType = "SCHEDULED" | "CONDITIONAL" | "ON_DEMAND" | "EVENT" | (string & {});
export type TriggerState = "CREATING" | "CREATED" | "ACTIVATING" | "ACTIVATED" | "DEACTIVATING" | "DEACTIVATED" | "DELETING" | "UPDATING" | (string & {});
export interface Action {
    JobName?: string | undefined;
    Arguments?: {
        [key: string]: string | undefined;
    } | undefined;
    Timeout?: number | undefined;
    SecurityConfiguration?: string | undefined;
    NotificationProperty?: NotificationProperty | undefined;
    CrawlerName?: string | undefined;
}
export type ActionList = Action[];
export type Logical = "AND" | "ANY" | (string & {});
export type LogicalOperator = "EQUALS" | (string & {});
export type JobRunState = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | "SUCCEEDED" | "FAILED" | "TIMEOUT" | "ERROR" | "WAITING" | "EXPIRED" | (string & {});
export type CrawlState = "RUNNING" | "CANCELLING" | "CANCELLED" | "SUCCEEDED" | "FAILED" | "ERROR" | (string & {});
export interface Condition {
    LogicalOperator?: LogicalOperator | undefined;
    JobName?: string | undefined;
    State?: JobRunState | undefined;
    CrawlerName?: string | undefined;
    CrawlState?: CrawlState | undefined;
}
export type ConditionList = Condition[];
export interface Predicate {
    Logical?: Logical | undefined;
    Conditions?: Condition[] | undefined;
}
export type BatchSize = number;
export type BatchWindow = number;
export interface EventBatchingCondition {
    BatchSize: number;
    BatchWindow?: number | undefined;
}
export interface Trigger {
    Name?: string | undefined;
    WorkflowName?: string | undefined;
    Id?: string | undefined;
    Type?: TriggerType | undefined;
    State?: TriggerState | undefined;
    Description?: string | undefined;
    Schedule?: string | undefined;
    Actions?: Action[] | undefined;
    Predicate?: Predicate | undefined;
    EventBatchingCondition?: EventBatchingCondition | undefined;
}
export type TriggerList = Trigger[];
export interface BatchGetTriggersResponse {
    Triggers?: Trigger[] | undefined;
    TriggersNotFound?: string[] | undefined;
}
export type WorkflowNames = string[];
export interface BatchGetWorkflowsRequest {
    Names: string[];
    IncludeGraph?: boolean | undefined;
}
export type WorkflowRunProperties = {
    [key: string]: string | undefined;
};
export type WorkflowRunStatus = "RUNNING" | "COMPLETED" | "STOPPING" | "STOPPED" | "ERROR" | (string & {});
export interface WorkflowRunStatistics {
    TotalActions?: number | undefined;
    TimeoutActions?: number | undefined;
    FailedActions?: number | undefined;
    StoppedActions?: number | undefined;
    SucceededActions?: number | undefined;
    RunningActions?: number | undefined;
    ErroredActions?: number | undefined;
    WaitingActions?: number | undefined;
}
export type NodeType = "CRAWLER" | "JOB" | "TRIGGER" | (string & {});
export interface TriggerNodeDetails {
    Trigger?: Trigger | undefined;
}
export type AttemptCount = number;
export interface Predecessor {
    JobName?: string | undefined;
    RunId?: string | undefined;
}
export type PredecessorList = Predecessor[];
export type OrchestrationMessageString = string;
export type OrchestrationPolicyJsonString = string;
export interface JobRun {
    Id?: string | undefined;
    Attempt?: number | undefined;
    PreviousRunId?: string | undefined;
    TriggerName?: string | undefined;
    JobName?: string | undefined;
    JobMode?: JobMode | undefined;
    JobRunQueuingEnabled?: boolean | undefined;
    StartedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    JobRunState?: JobRunState | undefined;
    Arguments?: {
        [key: string]: string | undefined;
    } | undefined;
    ErrorMessage?: string | undefined;
    PredecessorRuns?: Predecessor[] | undefined;
    AllocatedCapacity?: number | undefined;
    ExecutionTime?: number | undefined;
    Timeout?: number | undefined;
    MaxCapacity?: number | undefined;
    WorkerType?: WorkerType | undefined;
    NumberOfWorkers?: number | undefined;
    SecurityConfiguration?: string | undefined;
    LogGroupName?: string | undefined;
    NotificationProperty?: NotificationProperty | undefined;
    GlueVersion?: string | undefined;
    DPUSeconds?: number | undefined;
    ExecutionClass?: ExecutionClass | undefined;
    MaintenanceWindow?: string | undefined;
    ProfileName?: string | undefined;
    StateDetail?: string | undefined;
    ExecutionRoleSessionPolicy?: string | undefined;
}
export type JobRunList = JobRun[];
export interface JobNodeDetails {
    JobRuns?: JobRun[] | undefined;
}
export interface Crawl {
    State?: CrawlState | undefined;
    StartedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    ErrorMessage?: string | undefined;
    LogGroup?: string | undefined;
    LogStream?: string | undefined;
}
export type CrawlList = Crawl[];
export interface CrawlerNodeDetails {
    Crawls?: Crawl[] | undefined;
}
export interface Node {
    Type?: NodeType | undefined;
    Name?: string | undefined;
    UniqueId?: string | undefined;
    TriggerDetails?: TriggerNodeDetails | undefined;
    JobDetails?: JobNodeDetails | undefined;
    CrawlerDetails?: CrawlerNodeDetails | undefined;
}
export type NodeList = Node[];
export interface Edge {
    SourceId?: string | undefined;
    DestinationId?: string | undefined;
}
export type EdgeList = Edge[];
export interface WorkflowGraph {
    Nodes?: Node[] | undefined;
    Edges?: Edge[] | undefined;
}
export interface StartingEventBatchCondition {
    BatchSize?: number | undefined;
    BatchWindow?: number | undefined;
}
export interface WorkflowRun {
    Name?: string | undefined;
    WorkflowRunId?: string | undefined;
    PreviousRunId?: string | undefined;
    WorkflowRunProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    StartedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    Status?: WorkflowRunStatus | undefined;
    ErrorMessage?: string | undefined;
    Statistics?: WorkflowRunStatistics | undefined;
    Graph?: WorkflowGraph | undefined;
    StartingEventBatchCondition?: StartingEventBatchCondition | undefined;
}
export interface BlueprintDetails {
    BlueprintName?: string | undefined;
    RunId?: string | undefined;
}
export interface Workflow {
    Name?: string | undefined;
    Description?: string | undefined;
    DefaultRunProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    LastRun?: WorkflowRun | undefined;
    Graph?: WorkflowGraph | undefined;
    MaxConcurrentRuns?: number | undefined;
    BlueprintDetails?: BlueprintDetails | undefined;
}
export type Workflows = Workflow[];
export interface BatchGetWorkflowsResponse {
    Workflows?: Workflow[] | undefined;
    MissingWorkflows?: string[] | undefined;
}
export type InclusionAnnotationValue = "INCLUDE" | "EXCLUDE" | (string & {});
export interface DatapointInclusionAnnotation {
    ProfileId?: string | undefined;
    StatisticId?: string | undefined;
    InclusionAnnotation?: InclusionAnnotationValue | undefined;
}
export type InclusionAnnotationList = DatapointInclusionAnnotation[];
export interface BatchPutDataQualityStatisticAnnotationRequest {
    InclusionAnnotations: DatapointInclusionAnnotation[];
    ClientToken?: string | undefined;
}
export interface AnnotationError {
    ProfileId?: string | undefined;
    StatisticId?: string | undefined;
    FailureReason?: string | undefined;
}
export type AnnotationErrorList = AnnotationError[];
export interface BatchPutDataQualityStatisticAnnotationResponse {
    FailedInclusionAnnotations?: AnnotationError[] | undefined;
}
export type BatchStopJobRunJobRunIdList = string[];
export interface BatchStopJobRunRequest {
    JobName: string;
    JobRunIds: string[];
}
export interface BatchStopJobRunSuccessfulSubmission {
    JobName?: string | undefined;
    JobRunId?: string | undefined;
}
export type BatchStopJobRunSuccessfulSubmissionList = BatchStopJobRunSuccessfulSubmission[];
export interface BatchStopJobRunError_ {
    JobName?: string | undefined;
    JobRunId?: string | undefined;
    ErrorDetail?: ErrorDetail | undefined;
}
export type BatchStopJobRunErrorList = BatchStopJobRunError_[];
export interface BatchStopJobRunResponse {
    SuccessfulSubmissions?: BatchStopJobRunSuccessfulSubmission[] | undefined;
    Errors?: BatchStopJobRunError_[] | undefined;
}
export type BoundedPartitionValueList = string[];
export interface BatchUpdatePartitionRequestEntry {
    PartitionValueList: string[];
    PartitionInput: PartitionInput;
}
export type BatchUpdatePartitionRequestEntryList = BatchUpdatePartitionRequestEntry[];
export interface BatchUpdatePartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    Entries: BatchUpdatePartitionRequestEntry[];
}
export interface BatchUpdatePartitionFailureEntry {
    PartitionValueList?: string[] | undefined;
    ErrorDetail?: ErrorDetail | undefined;
}
export type BatchUpdatePartitionFailureList = BatchUpdatePartitionFailureEntry[];
export interface BatchUpdatePartitionResponse {
    Errors?: BatchUpdatePartitionFailureEntry[] | undefined;
}
export interface CancelDataQualityRuleRecommendationRunRequest {
    RunId: string;
}
export interface CancelDataQualityRuleRecommendationRunResponse {
}
export interface CancelDataQualityRulesetEvaluationRunRequest {
    RunId: string;
}
export interface CancelDataQualityRulesetEvaluationRunResponse {
}
export interface CancelMLTaskRunRequest {
    TransformId: string;
    TaskRunId: string;
}
export interface CancelMLTaskRunResponse {
    TransformId?: string | undefined;
    TaskRunId?: string | undefined;
    Status?: TaskStatusType | undefined;
}
export interface CancelStatementRequest {
    SessionId: string;
    Id: number;
    RequestOrigin?: string | undefined;
}
export interface CancelStatementResponse {
}
export type DataFormat = "AVRO" | "JSON" | "PROTOBUF" | (string & {});
export type SchemaDefinitionString = string;
export interface CheckSchemaVersionValidityInput {
    DataFormat: DataFormat;
    SchemaDefinition: string;
}
export type IsVersionValid = boolean;
export type SchemaValidationError = string;
export interface CheckSchemaVersionValidityResponse {
    Valid?: boolean | undefined;
    Error?: string | undefined;
}
export type OrchestrationS3Location = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateBlueprintRequest {
    Name: string;
    Description?: string | undefined;
    BlueprintLocation: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateBlueprintResponse {
    Name?: string | undefined;
}
export type CatalogNameString = string;
export type FederationIdentifier = string;
export interface FederatedCatalog {
    Identifier?: string | undefined;
    ConnectionName?: string | undefined;
    ConnectionType?: string | undefined;
}
export type ResourceArnString = string;
export interface TargetRedshiftCatalog {
    CatalogArn: string;
}
export type IAMRoleArn = string;
export interface DataLakeAccessProperties {
    DataLakeAccess?: boolean | undefined;
    DataTransferRole?: string | undefined;
    KmsKey?: string | undefined;
    CatalogType?: string | undefined;
}
export interface IcebergOptimizationProperties {
    RoleArn?: string | undefined;
    Compaction?: {
        [key: string]: string | undefined;
    } | undefined;
    Retention?: {
        [key: string]: string | undefined;
    } | undefined;
    OrphanFileDeletion?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CatalogProperties {
    DataLakeAccessProperties?: DataLakeAccessProperties | undefined;
    IcebergOptimizationProperties?: IcebergOptimizationProperties | undefined;
    CustomProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DataLakePrincipalString = string;
export interface DataLakePrincipal {
    DataLakePrincipalIdentifier?: string | undefined;
}
export type Permission = "ALL" | "SELECT" | "ALTER" | "DROP" | "DELETE" | "INSERT" | "CREATE_DATABASE" | "CREATE_TABLE" | "DATA_LOCATION_ACCESS" | (string & {});
export type PermissionList = Permission[];
export interface PrincipalPermissions {
    Principal?: DataLakePrincipal | undefined;
    Permissions?: Permission[] | undefined;
}
export type PrincipalPermissionsList = PrincipalPermissions[];
export type AllowFullTableExternalDataAccessEnum = "True" | "False" | (string & {});
export type OverwriteChildResourcePermissionsWithDefaultEnum = "Accept" | "Deny" | (string & {});
export interface CatalogInput {
    Description?: string | undefined;
    FederatedCatalog?: FederatedCatalog | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    TargetRedshiftCatalog?: TargetRedshiftCatalog | undefined;
    CatalogProperties?: CatalogProperties | undefined;
    CreateTableDefaultPermissions?: PrincipalPermissions[] | undefined;
    CreateDatabaseDefaultPermissions?: PrincipalPermissions[] | undefined;
    AllowFullTableExternalDataAccess?: AllowFullTableExternalDataAccessEnum | undefined;
    OverwriteChildResourcePermissionsWithDefault?: OverwriteChildResourcePermissionsWithDefaultEnum | undefined;
}
export interface CreateCatalogRequest {
    Name: string;
    CatalogInput: CatalogInput;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateCatalogResponse {
}
export type Classification = string;
export type GrokPattern = string;
export type CustomPatterns = string;
export interface CreateGrokClassifierRequest {
    Classification: string;
    Name: string;
    GrokPattern: string;
    CustomPatterns?: string | undefined;
}
export type RowTag = string;
export interface CreateXMLClassifierRequest {
    Classification: string;
    Name: string;
    RowTag?: string | undefined;
}
export type JsonPath = string;
export interface CreateJsonClassifierRequest {
    Name: string;
    JsonPath: string;
}
export type CsvColumnDelimiter = string;
export type CsvQuoteSymbol = string;
export type CsvHeaderOption = "UNKNOWN" | "PRESENT" | "ABSENT" | (string & {});
export type CsvHeader = string[];
export type CustomDatatypes = string[];
export type CsvSerdeOption = "OpenCSVSerDe" | "LazySimpleSerDe" | "None" | (string & {});
export interface CreateCsvClassifierRequest {
    Name: string;
    Delimiter?: string | undefined;
    QuoteSymbol?: string | undefined;
    ContainsHeader?: CsvHeaderOption | undefined;
    Header?: string[] | undefined;
    DisableValueTrimming?: boolean | undefined;
    AllowSingleColumn?: boolean | undefined;
    CustomDatatypeConfigured?: boolean | undefined;
    CustomDatatypes?: string[] | undefined;
    Serde?: CsvSerdeOption | undefined;
}
export interface CreateClassifierRequest {
    GrokClassifier?: CreateGrokClassifierRequest | undefined;
    XMLClassifier?: CreateXMLClassifierRequest | undefined;
    JsonClassifier?: CreateJsonClassifierRequest | undefined;
    CsvClassifier?: CreateCsvClassifierRequest | undefined;
}
export interface CreateClassifierResponse {
}
export type ColumnNameList = string[];
export type SampleSizePercentage = number;
export interface CreateColumnStatisticsTaskSettingsRequest {
    DatabaseName: string;
    TableName: string;
    Role: string;
    Schedule?: string | undefined;
    ColumnNameList?: string[] | undefined;
    SampleSize?: number | undefined;
    CatalogID?: string | undefined;
    SecurityConfiguration?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateColumnStatisticsTaskSettingsResponse {
}
export type ConnectionType = "JDBC" | "SFTP" | "MONGODB" | "KAFKA" | "NETWORK" | "MARKETPLACE" | "CUSTOM" | "SALESFORCE" | "VIEW_VALIDATION_REDSHIFT" | "VIEW_VALIDATION_ATHENA" | "GOOGLEADS" | "GOOGLESHEETS" | "GOOGLEANALYTICS4" | "SERVICENOW" | "MARKETO" | "SAPODATA" | "ZENDESK" | "JIRACLOUD" | "NETSUITEERP" | "HUBSPOT" | "FACEBOOKADS" | "INSTAGRAMADS" | "ZOHOCRM" | "SALESFORCEPARDOT" | "SALESFORCEMARKETINGCLOUD" | "ADOBEANALYTICS" | "SLACK" | "LINKEDIN" | "MIXPANEL" | "ASANA" | "STRIPE" | "SMARTSHEET" | "DATADOG" | "WOOCOMMERCE" | "INTERCOM" | "SNAPCHATADS" | "PAYPAL" | "QUICKBOOKS" | "FACEBOOKPAGEINSIGHTS" | "FRESHDESK" | "TWILIO" | "DOCUSIGNMONITOR" | "FRESHSALES" | "ZOOM" | "GOOGLESEARCHCONSOLE" | "SALESFORCECOMMERCECLOUD" | "SAPCONCUR" | "DYNATRACE" | "MICROSOFTDYNAMIC365FINANCEANDOPS" | "MICROSOFTTEAMS" | "BLACKBAUDRAISEREDGENXT" | "MAILCHIMP" | "GITLAB" | "PENDO" | "PRODUCTBOARD" | "CIRCLECI" | "PIPEDIVE" | "SENDGRID" | "AZURECOSMOS" | "AZURESQL" | "BIGQUERY" | "BLACKBAUD" | "CLOUDERAHIVE" | "CLOUDERAIMPALA" | "CLOUDWATCH" | "CLOUDWATCHMETRICS" | "CMDB" | "DATALAKEGEN2" | "DB2" | "DB2AS400" | "DOCUMENTDB" | "DOMO" | "DYNAMODB" | "GOOGLECLOUDSTORAGE" | "HBASE" | "KUSTOMER" | "MICROSOFTDYNAMICS365CRM" | "MONDAY" | "MYSQL" | "OKTA" | "OPENSEARCH" | "ORACLE" | "PIPEDRIVE" | "POSTGRESQL" | "SAPHANA" | "SQLSERVER" | "SYNAPSE" | "TERADATA" | "TERADATANOS" | "TIMESTREAM" | "TPCDS" | "VERTICA" | (string & {});
export type MatchCriteria = string[];
export type ConnectionPropertyKey = "HOST" | "PORT" | "USERNAME" | "PASSWORD" | "ENCRYPTED_PASSWORD" | "JDBC_DRIVER_JAR_URI" | "JDBC_DRIVER_CLASS_NAME" | "JDBC_ENGINE" | "JDBC_ENGINE_VERSION" | "CONFIG_FILES" | "INSTANCE_ID" | "JDBC_CONNECTION_URL" | "JDBC_ENFORCE_SSL" | "CUSTOM_JDBC_CERT" | "SKIP_CUSTOM_JDBC_CERT_VALIDATION" | "CUSTOM_JDBC_CERT_STRING" | "CONNECTION_URL" | "KAFKA_BOOTSTRAP_SERVERS" | "KAFKA_SSL_ENABLED" | "KAFKA_CUSTOM_CERT" | "KAFKA_SKIP_CUSTOM_CERT_VALIDATION" | "KAFKA_CLIENT_KEYSTORE" | "KAFKA_CLIENT_KEYSTORE_PASSWORD" | "KAFKA_CLIENT_KEY_PASSWORD" | "ENCRYPTED_KAFKA_CLIENT_KEYSTORE_PASSWORD" | "ENCRYPTED_KAFKA_CLIENT_KEY_PASSWORD" | "KAFKA_SASL_MECHANISM" | "KAFKA_SASL_PLAIN_USERNAME" | "KAFKA_SASL_PLAIN_PASSWORD" | "ENCRYPTED_KAFKA_SASL_PLAIN_PASSWORD" | "KAFKA_SASL_SCRAM_USERNAME" | "KAFKA_SASL_SCRAM_PASSWORD" | "KAFKA_SASL_SCRAM_SECRETS_ARN" | "ENCRYPTED_KAFKA_SASL_SCRAM_PASSWORD" | "KAFKA_SASL_GSSAPI_KEYTAB" | "KAFKA_SASL_GSSAPI_KRB5_CONF" | "KAFKA_SASL_GSSAPI_SERVICE" | "KAFKA_SASL_GSSAPI_PRINCIPAL" | "SECRET_ID" | "CONNECTOR_URL" | "CONNECTOR_TYPE" | "CONNECTOR_CLASS_NAME" | "ENDPOINT" | "ENDPOINT_TYPE" | "ROLE_ARN" | "REGION" | "WORKGROUP_NAME" | "CLUSTER_IDENTIFIER" | "DATABASE" | (string & {});
export type ConnectionProperties = {
    [key in ConnectionPropertyKey]?: string | undefined;
};
export type PropertyKey = string;
export type PropertyValue = string;
export type PropertyMap = {
    [key: string]: string | undefined;
};
export type SecurityGroupIdList = string[];
export interface PhysicalConnectionRequirements {
    SubnetId?: string | undefined;
    SecurityGroupIdList?: string[] | undefined;
    AvailabilityZone?: string | undefined;
}
export type AuthenticationType = "BASIC" | "OAUTH2" | "CUSTOM" | "IAM" | (string & {});
export type OAuth2GrantType = "AUTHORIZATION_CODE" | "CLIENT_CREDENTIALS" | "JWT_BEARER" | "REFRESH_TOKEN" | (string & {});
export type UserManagedClientApplicationClientId = string;
export type AWSManagedClientApplicationReference = string;
export interface OAuth2ClientApplication {
    UserManagedClientApplicationClientId?: string | undefined;
    AWSManagedClientApplicationReference?: string | undefined;
}
export type TokenUrl = string;
export type TokenUrlParameterKey = string;
export type TokenUrlParameterValue = string;
export type TokenUrlParametersMap = {
    [key: string]: string | undefined;
};
export type AuthorizationCode = string | redacted.Redacted<string>;
export type RedirectUri = string;
export interface AuthorizationCodeProperties {
    AuthorizationCode?: string | redacted.Redacted<string> | undefined;
    RedirectUri?: string | undefined;
}
export type UserManagedClientApplicationClientSecret = string | redacted.Redacted<string>;
export type AccessToken = string | redacted.Redacted<string>;
export type RefreshToken = string | redacted.Redacted<string>;
export type JwtToken = string | redacted.Redacted<string>;
export interface OAuth2Credentials {
    UserManagedClientApplicationClientSecret?: string | redacted.Redacted<string> | undefined;
    AccessToken?: string | redacted.Redacted<string> | undefined;
    RefreshToken?: string | redacted.Redacted<string> | undefined;
    JwtToken?: string | redacted.Redacted<string> | undefined;
}
export interface OAuth2PropertiesInput {
    OAuth2GrantType?: OAuth2GrantType | undefined;
    OAuth2ClientApplication?: OAuth2ClientApplication | undefined;
    TokenUrl?: string | undefined;
    TokenUrlParametersMap?: {
        [key: string]: string | undefined;
    } | undefined;
    AuthorizationCodeProperties?: AuthorizationCodeProperties | undefined;
    OAuth2Credentials?: OAuth2Credentials | undefined;
}
export type SecretArn = string;
export type KmsKeyArn = string;
export type Username = string;
export type Password = string | redacted.Redacted<string>;
export interface BasicAuthenticationCredentials {
    Username?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
}
export type CredentialKey = string;
export type CredentialValue = string;
export type CredentialMap = {
    [key: string]: string | undefined;
};
export interface AuthenticationConfigurationInput {
    AuthenticationType?: AuthenticationType | undefined;
    OAuth2Properties?: OAuth2PropertiesInput | undefined;
    SecretArn?: string | undefined;
    KmsKeyArn?: string | undefined;
    BasicAuthenticationCredentials?: BasicAuthenticationCredentials | undefined;
    CustomAuthenticationCredentials?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ComputeEnvironment = "SPARK" | "ATHENA" | "PYTHON" | (string & {});
export type ComputeEnvironmentList = ComputeEnvironment[];
export interface ConnectionInput {
    Name: string;
    Description?: string | undefined;
    ConnectionType: ConnectionType;
    MatchCriteria?: string[] | undefined;
    ConnectionProperties: {
        [key: string]: string | undefined;
    };
    SparkProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    AthenaProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    PythonProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    PhysicalConnectionRequirements?: PhysicalConnectionRequirements | undefined;
    AuthenticationConfiguration?: AuthenticationConfigurationInput | undefined;
    ValidateCredentials?: boolean | undefined;
    ValidateForComputeEnvironments?: ComputeEnvironment[] | undefined;
}
export interface CreateConnectionRequest {
    CatalogId?: string | undefined;
    ConnectionInput: ConnectionInput;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConnectionStatus = "READY" | "IN_PROGRESS" | "FAILED" | (string & {});
export interface CreateConnectionResponse {
    CreateConnectionStatus?: ConnectionStatus | undefined;
}
export interface CreateCrawlerRequest {
    Name: string;
    Role: string;
    DatabaseName?: string | undefined;
    Description?: string | undefined;
    Targets: CrawlerTargets;
    Schedule?: string | undefined;
    Classifiers?: string[] | undefined;
    TablePrefix?: string | undefined;
    SchemaChangePolicy?: SchemaChangePolicy | undefined;
    RecrawlPolicy?: RecrawlPolicy | undefined;
    LineageConfiguration?: LineageConfiguration | undefined;
    LakeFormationConfiguration?: LakeFormationConfiguration | undefined;
    Configuration?: string | undefined;
    CrawlerSecurityConfiguration?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    CatalogId?: string | undefined;
}
export interface CreateCrawlerResponse {
}
export interface CreateCustomEntityTypeRequest {
    Name: string;
    RegexString: string;
    ContextWords?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateCustomEntityTypeResponse {
    Name?: string | undefined;
}
export type URI = string;
export interface DatabaseIdentifier {
    CatalogId?: string | undefined;
    DatabaseName?: string | undefined;
    Region?: string | undefined;
}
export interface FederatedDatabase {
    Identifier?: string | undefined;
    ConnectionName?: string | undefined;
    ConnectionType?: string | undefined;
}
export interface DatabaseInput {
    Name: string;
    Description?: string | undefined;
    LocationUri?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    CreateTableDefaultPermissions?: PrincipalPermissions[] | undefined;
    TargetDatabase?: DatabaseIdentifier | undefined;
    FederatedDatabase?: FederatedDatabase | undefined;
}
export interface CreateDatabaseRequest {
    CatalogId?: string | undefined;
    DatabaseInput: DatabaseInput;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDatabaseResponse {
}
export type DataQualityEvaluationConfigLevel = "CATALOG" | "DATABASE" | "TABLE" | (string & {});
export interface DataQualityEvaluationConfigGlueTables {
    CatalogId: string;
    DatabaseName?: string | undefined;
    TableNamePattern?: string | undefined;
    PreProcessingQuery?: string | undefined;
    ConnectionName?: string | undefined;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DataQualityEvaluationConfigDataSource {
    GlueTables?: DataQualityEvaluationConfigGlueTables | undefined;
}
export type DataQualityEvaluationConfigManagedRuleset = "SIMPLE" | "ADVANCED" | (string & {});
export type DataQualityEvaluationConfigTrigger = "ONCE" | "SCHEDULE" | "METADATA_CHANGE" | (string & {});
export type DataQualityEvaluationConfigTriggers = DataQualityEvaluationConfigTrigger[];
export type DataQualityEvaluationConfigScheduleExpression = string;
export interface DataQualityEvaluationConfigAdditionalRunOptions {
    CloudWatchMetricsEnabled?: boolean | undefined;
    ResultsS3Prefix?: string | undefined;
    CompositeRuleEvaluationMethod?: DQCompositeRuleEvaluationMethod | undefined;
    RowLevelResults?: RowLevelResultsOptions | undefined;
    ProfilingResults?: ProfilingResultsOptions | undefined;
    ObservationScope?: ObservationConfiguration | undefined;
    ObservationMode?: ObservationMode | undefined;
    DataQualityRuleResults?: DataQualityRuleResultsOptions | undefined;
    ObservationResults?: ObservationResultsOptions | undefined;
    CustomLogGroupPrefix?: string | undefined;
}
export type ClientTokenString = string;
export interface CreateDataQualityEvaluationConfigRequest {
    Name: string;
    Level: DataQualityEvaluationConfigLevel;
    DataSource: DataQualityEvaluationConfigDataSource;
    RulesetName?: string | undefined;
    ManagedRulesetName?: DataQualityEvaluationConfigManagedRuleset | undefined;
    Triggers?: DataQualityEvaluationConfigTrigger[] | undefined;
    ScheduleExpression?: string | undefined;
    StartAt?: Date | undefined;
    EndAt?: Date | undefined;
    Role: string;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    AdditionalRunOptions?: DataQualityEvaluationConfigAdditionalRunOptions | undefined;
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export interface CreateDataQualityEvaluationConfigResponse {
    Name?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
}
export type DataQualityRulesetString = string;
export interface DataQualityTargetTable {
    TableName: string;
    DatabaseName: string;
    CatalogId?: string | undefined;
}
export interface CreateDataQualityRulesetRequest {
    Name: string;
    Description?: string | undefined;
    Ruleset: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TargetTable?: DataQualityTargetTable | undefined;
    DataQualitySecurityConfiguration?: string | undefined;
    ClientToken?: string | undefined;
}
export interface CreateDataQualityRulesetResponse {
    Name?: string | undefined;
}
export interface CreateDevEndpointRequest {
    EndpointName: string;
    RoleArn: string;
    SecurityGroupIds?: string[] | undefined;
    SubnetId?: string | undefined;
    PublicKey?: string | undefined;
    PublicKeys?: string[] | undefined;
    NumberOfNodes?: number | undefined;
    WorkerType?: WorkerType | undefined;
    GlueVersion?: string | undefined;
    NumberOfWorkers?: number | undefined;
    ExtraPythonLibsS3Path?: string | undefined;
    ExtraJarsS3Path?: string | undefined;
    SecurityConfiguration?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arguments?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDevEndpointResponse {
    EndpointName?: string | undefined;
    Status?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetId?: string | undefined;
    RoleArn?: string | undefined;
    YarnEndpointAddress?: string | undefined;
    ZeppelinRemoteSparkInterpreterPort?: number | undefined;
    NumberOfNodes?: number | undefined;
    WorkerType?: WorkerType | undefined;
    GlueVersion?: string | undefined;
    NumberOfWorkers?: number | undefined;
    AvailabilityZone?: string | undefined;
    VpcId?: string | undefined;
    ExtraPythonLibsS3Path?: string | undefined;
    ExtraJarsS3Path?: string | undefined;
    FailureReason?: string | undefined;
    SecurityConfiguration?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    Arguments?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type GlossaryName = string;
export type MetadataDescription = string;
export interface CreateGlossaryRequest {
    Name: string;
    Description?: string | undefined;
    ClientToken?: string | undefined;
}
export type GlossaryId = string;
export interface CreateGlossaryResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
}
export type GlossaryTermName = string;
export type GlossaryShortDescription = string;
export type GlossaryLongDescription = string;
export interface CreateGlossaryTermRequest {
    GlossaryIdentifier: string;
    Name: string;
    ShortDescription?: string | undefined;
    LongDescription?: string | undefined;
    ClientToken?: string | undefined;
}
export interface CreateGlossaryTermResponse {
    Id?: string | undefined;
    GlossaryId?: string | undefined;
    Name?: string | undefined;
    ShortDescription?: string | undefined;
    LongDescription?: string | undefined;
}
export type IdentityCenterInstanceArn = string;
export type IdentityCenterScope = string;
export type IdentityCenterScopesList = string[];
export interface CreateGlueIdentityCenterConfigurationRequest {
    InstanceArn: string;
    Scopes?: string[] | undefined;
    UserBackgroundSessionsEnabled?: boolean | undefined;
}
export type ApplicationArn = string;
export interface CreateGlueIdentityCenterConfigurationResponse {
    ApplicationArn?: string | undefined;
}
export type String128 = string;
export type String512 = string;
export type IntegrationDescription = string;
export type String2048 = string;
export type IntegrationString = string;
export type IntegrationAdditionalEncryptionContextMap = {
    [key: string]: string | undefined;
};
export interface Tag {
    key?: string | undefined;
    value?: string | undefined;
}
export type IntegrationTagsList = Tag[];
export type IntegrationSourcePropertiesMap = {
    [key: string]: string | undefined;
};
export type ContinuousSync = boolean;
export type TargetNamespace = string;
export interface IntegrationConfig {
    RefreshInterval?: string | undefined;
    SourceProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    ContinuousSync?: boolean | undefined;
    TargetNamespace?: string | undefined;
}
export interface CreateIntegrationRequest {
    IntegrationName: string;
    SourceArn: string;
    TargetArn: string;
    Description?: string | undefined;
    DataFilter?: string | undefined;
    KmsKeyId?: string | undefined;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
    IntegrationConfig?: IntegrationConfig | undefined;
}
export type IntegrationStatus = "CREATING" | "ACTIVE" | "MODIFYING" | "FAILED" | "DELETING" | "SYNCING" | "NEEDS_ATTENTION" | (string & {});
export type IntegrationTimestamp = Date;
export interface IntegrationError {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type IntegrationErrorList = IntegrationError[];
export interface CreateIntegrationResponse {
    SourceArn: string;
    TargetArn: string;
    IntegrationName: string;
    Description?: string | undefined;
    IntegrationArn: string;
    KmsKeyId?: string | undefined;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
    Status: IntegrationStatus;
    CreateTime: Date;
    Errors?: IntegrationError[] | undefined;
    DataFilter?: string | undefined;
    IntegrationConfig?: IntegrationConfig | undefined;
}
export interface SourceProcessingProperties {
    RoleArn?: string | undefined;
}
export interface TargetProcessingProperties {
    RoleArn?: string | undefined;
    KmsArn?: string | undefined;
    ConnectionName?: string | undefined;
    EventBusArn?: string | undefined;
}
export interface CreateIntegrationResourcePropertyRequest {
    ResourceArn: string;
    SourceProcessingProperties?: SourceProcessingProperties | undefined;
    TargetProcessingProperties?: TargetProcessingProperties | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateIntegrationResourcePropertyResponse {
    ResourceArn: string;
    ResourcePropertyArn?: string | undefined;
    SourceProcessingProperties?: SourceProcessingProperties | undefined;
    TargetProcessingProperties?: TargetProcessingProperties | undefined;
}
export type SourceTableFieldsList = string[];
export type PrimaryKeyList = string[];
export interface SourceTableConfig {
    Fields?: string[] | undefined;
    FilterPredicate?: string | undefined;
    PrimaryKey?: string[] | undefined;
    RecordUpdateField?: string | undefined;
}
export type UnnestSpec = "TOPLEVEL" | "FULL" | "NOUNNEST" | (string & {});
export interface IntegrationPartition {
    FieldName?: string | undefined;
    FunctionSpec?: string | undefined;
    ConversionSpec?: string | undefined;
}
export type IntegrationPartitionSpecList = IntegrationPartition[];
export interface TargetTableConfig {
    UnnestSpec?: UnnestSpec | undefined;
    PartitionSpec?: IntegrationPartition[] | undefined;
    TargetTableName?: string | undefined;
    IntegrationArn?: string | undefined;
}
export interface CreateIntegrationTablePropertiesRequest {
    ResourceArn: string;
    TableName: string;
    SourceTableConfig?: SourceTableConfig | undefined;
    TargetTableConfig?: TargetTableConfig | undefined;
}
export interface CreateIntegrationTablePropertiesResponse {
}
export interface CreateJobRequest {
    Name: string;
    JobMode?: JobMode | undefined;
    JobRunQueuingEnabled?: boolean | undefined;
    Description?: string | undefined;
    LogUri?: string | undefined;
    Role: string;
    ExecutionProperty?: ExecutionProperty | undefined;
    Command: JobCommand;
    DefaultArguments?: {
        [key: string]: string | undefined;
    } | undefined;
    NonOverridableArguments?: {
        [key: string]: string | undefined;
    } | undefined;
    Connections?: ConnectionsList | undefined;
    MaxRetries?: number | undefined;
    AllocatedCapacity?: number | undefined;
    Timeout?: number | undefined;
    MaxCapacity?: number | undefined;
    SecurityConfiguration?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    NotificationProperty?: NotificationProperty | undefined;
    GlueVersion?: string | undefined;
    NumberOfWorkers?: number | undefined;
    WorkerType?: WorkerType | undefined;
    CodeGenConfigurationNodes?: {
        [key: string]: CodeGenConfigurationNode | undefined;
    } | undefined;
    ExecutionClass?: ExecutionClass | undefined;
    SourceControlDetails?: SourceControlDetails | undefined;
    MaintenanceWindow?: string | undefined;
}
export interface CreateJobResponse {
    Name?: string | undefined;
}
export type GlueTables = GlueTable[];
export type TransformType = "FIND_MATCHES" | (string & {});
export interface FindMatchesParameters {
    PrimaryKeyColumnName?: string | undefined;
    PrecisionRecallTradeoff?: number | undefined;
    AccuracyCostTradeoff?: number | undefined;
    EnforceProvidedLabels?: boolean | undefined;
}
export interface TransformParameters {
    TransformType: TransformType;
    FindMatchesParameters?: FindMatchesParameters | undefined;
}
export type MLUserDataEncryptionModeString = "DISABLED" | "SSE-KMS" | (string & {});
export interface MLUserDataEncryption {
    MlUserDataEncryptionMode: MLUserDataEncryptionModeString;
    KmsKeyId?: string | undefined;
}
export interface TransformEncryption {
    MlUserDataEncryption?: MLUserDataEncryption | undefined;
    TaskRunSecurityConfigurationName?: string | undefined;
}
export interface CreateMLTransformRequest {
    Name: string;
    Description?: string | undefined;
    InputRecordTables: GlueTable[];
    Parameters: TransformParameters;
    Role: string;
    GlueVersion?: string | undefined;
    MaxCapacity?: number | undefined;
    WorkerType?: WorkerType | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    MaxRetries?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TransformEncryption?: TransformEncryption | undefined;
}
export interface CreateMLTransformResponse {
    TransformId?: string | undefined;
}
export interface CreatePartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionInput: PartitionInput;
}
export interface CreatePartitionResponse {
}
export type KeyList = string[];
export interface PartitionIndex {
    Keys: string[];
    IndexName: string;
}
export interface CreatePartitionIndexRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionIndex: PartitionIndex;
}
export interface CreatePartitionIndexResponse {
}
export interface CreateRegistryInput {
    RegistryName: string;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateRegistryResponse {
    RegistryArn?: string | undefined;
    RegistryName?: string | undefined;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RegistryId {
    RegistryName?: string | undefined;
    RegistryArn?: string | undefined;
}
export type Compatibility = "NONE" | "DISABLED" | "BACKWARD" | "BACKWARD_ALL" | "FORWARD" | "FORWARD_ALL" | "FULL" | "FULL_ALL" | (string & {});
export interface CreateSchemaInput {
    RegistryId?: RegistryId | undefined;
    SchemaName: string;
    DataFormat: DataFormat;
    Compatibility?: Compatibility | undefined;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    SchemaDefinition?: string | undefined;
}
export type SchemaCheckpointNumber = number;
export type SchemaStatus = "AVAILABLE" | "PENDING" | "DELETING" | (string & {});
export type SchemaVersionStatus = "AVAILABLE" | "PENDING" | "FAILURE" | "DELETING" | (string & {});
export interface CreateSchemaResponse {
    RegistryName?: string | undefined;
    RegistryArn?: string | undefined;
    SchemaName?: string | undefined;
    SchemaArn?: string | undefined;
    Description?: string | undefined;
    DataFormat?: DataFormat | undefined;
    Compatibility?: Compatibility | undefined;
    SchemaCheckpoint?: number | undefined;
    LatestSchemaVersion?: number | undefined;
    NextSchemaVersion?: number | undefined;
    SchemaStatus?: SchemaStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    SchemaVersionId?: string | undefined;
    SchemaVersionStatus?: SchemaVersionStatus | undefined;
}
export type CodeGenIdentifier = string;
export type CodeGenNodeType = string;
export type CodeGenArgName = string;
export type CodeGenArgValue = string;
export interface CodeGenNodeArg {
    Name: string;
    Value: string;
    Param?: boolean | undefined;
}
export type CodeGenNodeArgs = CodeGenNodeArg[];
export interface CodeGenNode {
    Id: string;
    NodeType: string;
    Args: CodeGenNodeArg[];
    LineNumber?: number | undefined;
}
export type DagNodes = CodeGenNode[];
export interface CodeGenEdge {
    Source: string;
    Target: string;
    TargetParameter?: string | undefined;
}
export type DagEdges = CodeGenEdge[];
export type Language = "PYTHON" | "SCALA" | (string & {});
export interface CreateScriptRequest {
    DagNodes?: CodeGenNode[] | undefined;
    DagEdges?: CodeGenEdge[] | undefined;
    Language?: Language | undefined;
}
export type PythonScript = string;
export type ScalaCode = string;
export interface CreateScriptResponse {
    PythonScript?: string | undefined;
    ScalaCode?: string | undefined;
}
export type S3EncryptionMode = "DISABLED" | "SSE-KMS" | "SSE-S3" | (string & {});
export interface S3Encryption {
    S3EncryptionMode?: S3EncryptionMode | undefined;
    KmsKeyArn?: string | undefined;
}
export type S3EncryptionList = S3Encryption[];
export type CloudWatchEncryptionMode = "DISABLED" | "SSE-KMS" | (string & {});
export interface CloudWatchEncryption {
    CloudWatchEncryptionMode?: CloudWatchEncryptionMode | undefined;
    KmsKeyArn?: string | undefined;
}
export type JobBookmarksEncryptionMode = "DISABLED" | "CSE-KMS" | (string & {});
export interface JobBookmarksEncryption {
    JobBookmarksEncryptionMode?: JobBookmarksEncryptionMode | undefined;
    KmsKeyArn?: string | undefined;
}
export type DataQualityEncryptionMode = "DISABLED" | "SSE-KMS" | (string & {});
export interface DataQualityEncryption {
    DataQualityEncryptionMode?: DataQualityEncryptionMode | undefined;
    KmsKeyArn?: string | undefined;
}
export interface EncryptionConfiguration {
    S3Encryption?: S3Encryption[] | undefined;
    CloudWatchEncryption?: CloudWatchEncryption | undefined;
    JobBookmarksEncryption?: JobBookmarksEncryption | undefined;
    DataQualityEncryption?: DataQualityEncryption | undefined;
}
export interface CreateSecurityConfigurationRequest {
    Name: string;
    EncryptionConfiguration: EncryptionConfiguration;
}
export interface CreateSecurityConfigurationResponse {
    Name?: string | undefined;
    CreatedTimestamp?: Date | undefined;
}
export type OrchestrationRoleArn = string;
export interface SessionCommand {
    Name?: string | undefined;
    PythonVersion?: string | undefined;
}
export type OrchestrationArgumentsValue = string;
export type OrchestrationArgumentsMap = {
    [key: string]: string | undefined;
};
export type SessionType = "LIVY" | "SPARK_CONNECT" | (string & {});
export interface CreateSessionRequest {
    Id: string;
    Description?: string | undefined;
    Role: string;
    Command: SessionCommand;
    Timeout?: number | undefined;
    IdleTimeout?: number | undefined;
    DefaultArguments?: {
        [key: string]: string | undefined;
    } | undefined;
    Connections?: ConnectionsList | undefined;
    MaxCapacity?: number | undefined;
    NumberOfWorkers?: number | undefined;
    WorkerType?: WorkerType | undefined;
    SecurityConfiguration?: string | undefined;
    GlueVersion?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestOrigin?: string | undefined;
    SessionType?: SessionType | undefined;
}
export type SessionStatus = "PROVISIONING" | "READY" | "FAILED" | "TIMEOUT" | "STOPPING" | "STOPPED" | (string & {});
export type DoubleValue = number;
export type IdleTimeout = number;
export interface Session {
    Id?: string | undefined;
    CreatedOn?: Date | undefined;
    Status?: SessionStatus | undefined;
    ErrorMessage?: string | undefined;
    Description?: string | undefined;
    Role?: string | undefined;
    Command?: SessionCommand | undefined;
    DefaultArguments?: {
        [key: string]: string | undefined;
    } | undefined;
    Connections?: ConnectionsList | undefined;
    Progress?: number | undefined;
    MaxCapacity?: number | undefined;
    SecurityConfiguration?: string | undefined;
    GlueVersion?: string | undefined;
    NumberOfWorkers?: number | undefined;
    WorkerType?: WorkerType | undefined;
    CompletedOn?: Date | undefined;
    ExecutionTime?: number | undefined;
    DPUSeconds?: number | undefined;
    IdleTimeout?: number | undefined;
    ProfileName?: string | undefined;
    SessionType?: SessionType | undefined;
}
export interface CreateSessionResponse {
    Session?: Session | undefined;
}
export type NonNegativeInteger = number;
export type ViewTextString = string;
export type TableTypeString = string;
export interface TableIdentifier {
    CatalogId?: string | undefined;
    DatabaseName?: string | undefined;
    Name?: string | undefined;
    Region?: string | undefined;
}
export interface FederatedTable {
    Identifier?: string | undefined;
    DatabaseIdentifier?: string | undefined;
    ConnectionName?: string | undefined;
    ConnectionType?: string | undefined;
}
export type ViewDialect = "REDSHIFT" | "ATHENA" | "SPARK" | (string & {});
export type ViewDialectVersionString = string;
export interface ViewRepresentationInput {
    Dialect?: ViewDialect | undefined;
    DialectVersion?: string | undefined;
    ViewOriginalText?: string | undefined;
    ValidationConnection?: string | undefined;
    ViewExpandedText?: string | undefined;
}
export type ViewRepresentationInputList = ViewRepresentationInput[];
export type TableVersionId = number;
export type RefreshSeconds = number;
export type LastRefreshType = "FULL" | "INCREMENTAL" | (string & {});
export type ViewSubObjectsList = string[];
export type ViewSubObjectVersionIdsList = number[];
export type SubObjectSourceType = "HIVE_PARQUET" | "HIVE_ORC" | "HIVE_CSV" | "HIVE_JSON" | "PLAIN_PARQUET" | "ICEBERG" | (string & {});
export interface SubObjectStatistics {
    SourceType?: SubObjectSourceType | undefined;
    GlueVersionId?: string | undefined;
    PartitionCount?: number | undefined;
    FileCount?: number | undefined;
    TotalFileBytes?: number | undefined;
}
export type SubObjectsStatisticsList = SubObjectStatistics[];
export type SparkPipelineInfoKey = string;
export type SparkPipelineInfoValue = string;
export type SparkPipelineInfoMap = {
    [key: string]: string | undefined;
};
export interface ViewDefinitionInput {
    IsProtected?: boolean | undefined;
    IsManaged?: boolean | undefined;
    Definer?: string | undefined;
    Representations?: ViewRepresentationInput[] | undefined;
    ViewVersionId?: number | undefined;
    ViewVersionToken?: string | undefined;
    RefreshSeconds?: number | undefined;
    LastRefreshType?: LastRefreshType | undefined;
    SubObjects?: string[] | undefined;
    SubObjectVersionIds?: number[] | undefined;
    SubObjectsStatistics?: SubObjectStatistics[] | undefined;
    SparkPipelineInfo?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TableInput {
    Name: string;
    Description?: string | undefined;
    Owner?: string | undefined;
    LastAccessTime?: Date | undefined;
    LastAnalyzedTime?: Date | undefined;
    Retention?: number | undefined;
    StorageDescriptor?: StorageDescriptor | undefined;
    PartitionKeys?: Column[] | undefined;
    ViewOriginalText?: string | undefined;
    ViewExpandedText?: string | undefined;
    TableType?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    TargetTable?: TableIdentifier | undefined;
    FederatedTable?: FederatedTable | undefined;
    ViewDefinition?: ViewDefinitionInput | undefined;
}
export type PartitionIndexList = PartitionIndex[];
export type MetadataOperation = "CREATE" | (string & {});
export type IntegerList = number[];
export type IcebergStructTypeEnum = "struct" | (string & {});
export type IcebergDocument = unknown;
export interface IcebergStructField {
    Id: number;
    Name: string;
    Type: any;
    Required: boolean;
    Doc?: string | undefined;
    InitialDefault?: any | undefined;
    WriteDefault?: any | undefined;
}
export type IcebergStructFieldList = IcebergStructField[];
export interface IcebergSchema {
    SchemaId?: number | undefined;
    IdentifierFieldIds?: number[] | undefined;
    Type?: IcebergStructTypeEnum | undefined;
    Fields: IcebergStructField[];
}
export type IcebergTransformString = string;
export interface IcebergPartitionField {
    SourceId: number;
    Transform: string;
    Name: string;
    FieldId?: number | undefined;
}
export type IcebergPartitionSpecFieldList = IcebergPartitionField[];
export interface IcebergPartitionSpec {
    Fields: IcebergPartitionField[];
    SpecId?: number | undefined;
}
export type IcebergSortDirection = "asc" | "desc" | (string & {});
export type IcebergNullOrder = "nulls-first" | "nulls-last" | (string & {});
export interface IcebergSortField {
    SourceId: number;
    Transform: string;
    Direction: IcebergSortDirection;
    NullOrder: IcebergNullOrder;
}
export type IcebergSortOrderFieldList = IcebergSortField[];
export interface IcebergSortOrder {
    OrderId: number;
    Fields: IcebergSortField[];
}
export type StringToStringMap = {
    [key: string]: string | undefined;
};
export interface CreateIcebergTableInput {
    Location: string;
    Schema: IcebergSchema;
    PartitionSpec?: IcebergPartitionSpec | undefined;
    WriteOrder?: IcebergSortOrder | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface IcebergInput {
    MetadataOperation: MetadataOperation;
    Version?: string | undefined;
    CreateIcebergTableInput?: CreateIcebergTableInput | undefined;
}
export interface OpenTableFormatInput {
    IcebergInput?: IcebergInput | undefined;
}
export interface CreateTableRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    Name?: string | undefined;
    TableInput?: TableInput | undefined;
    PartitionIndexes?: PartitionIndex[] | undefined;
    TransactionId?: string | undefined;
    OpenTableFormatInput?: OpenTableFormatInput | undefined;
}
export interface CreateTableResponse {
}
export interface CreateTableOptimizerRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
    TableOptimizerConfiguration: TableOptimizerConfiguration;
}
export interface CreateTableOptimizerResponse {
}
export interface CreateTriggerRequest {
    Name: string;
    WorkflowName?: string | undefined;
    Type: TriggerType;
    Schedule?: string | undefined;
    Predicate?: Predicate | undefined;
    Actions: Action[];
    Description?: string | undefined;
    StartOnCreation?: boolean | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    EventBatchingCondition?: EventBatchingCondition | undefined;
}
export interface CreateTriggerResponse {
    Name?: string | undefined;
}
export type ConfigValueString = string;
export type AllowedValuesStringList = string[];
export interface ConfigurationObject {
    DefaultValue?: string | undefined;
    AllowedValues?: string[] | undefined;
    MinValue?: string | undefined;
    MaxValue?: string | undefined;
}
export type ConfigurationMap = {
    [key: string]: ConfigurationObject | undefined;
};
export interface ProfileConfiguration {
    SessionConfiguration?: {
        [key: string]: ConfigurationObject | undefined;
    } | undefined;
    JobConfiguration?: {
        [key: string]: ConfigurationObject | undefined;
    } | undefined;
}
export interface CreateUsageProfileRequest {
    Name: string;
    Description?: string | undefined;
    Configuration: ProfileConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateUsageProfileResponse {
    Name?: string | undefined;
}
export type FunctionType = "REGULAR_FUNCTION" | "AGGREGATE_FUNCTION" | "STORED_PROCEDURE" | (string & {});
export type PrincipalType = "USER" | "ROLE" | "GROUP" | (string & {});
export type ResourceType = "JAR" | "FILE" | "ARCHIVE" | (string & {});
export interface ResourceUri {
    ResourceType?: ResourceType | undefined;
    Uri?: string | undefined;
    LastModified?: Date | undefined;
}
export type ResourceUriList = ResourceUri[];
export type GovernanceMode = "IAM_ONLY" | "LAKE_FORMATION" | (string & {});
export interface UserDefinedFunctionInput {
    FunctionName?: string | undefined;
    ClassName?: string | undefined;
    OwnerName?: string | undefined;
    FunctionType?: FunctionType | undefined;
    OwnerType?: PrincipalType | undefined;
    ResourceUris?: ResourceUri[] | undefined;
    ArtifactLocation?: string | undefined;
    GovernanceMode?: GovernanceMode | undefined;
}
export interface CreateUserDefinedFunctionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    FunctionInput: UserDefinedFunctionInput;
}
export interface CreateUserDefinedFunctionResponse {
}
export type WorkflowDescriptionString = string;
export interface CreateWorkflowRequest {
    Name: string;
    Description?: string | undefined;
    DefaultRunProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    MaxConcurrentRuns?: number | undefined;
}
export interface CreateWorkflowResponse {
    Name?: string | undefined;
}
export interface DeleteAssetRequest {
    Identifier: string;
}
export interface DeleteAssetResponse {
}
export type AssetTypeId = string;
export interface DeleteAssetTypeRequest {
    Identifier: string;
}
export interface DeleteAssetTypeResponse {
}
export type AttachmentName = string;
export interface DeleteAttachmentRequest {
    AssetIdentifier: string;
    IterableFormName?: string | undefined;
    ItemIdentifier?: string | undefined;
    AttachmentName: string;
}
export interface DeleteAttachmentResponse {
    AssetIdentifier?: string | undefined;
    IterableFormName?: string | undefined;
    ItemIdentifier?: string | undefined;
}
export interface DeleteBlueprintRequest {
    Name: string;
}
export interface DeleteBlueprintResponse {
    Name?: string | undefined;
}
export interface DeleteCatalogRequest {
    CatalogId: string;
}
export interface DeleteCatalogResponse {
}
export interface DeleteClassifierRequest {
    Name: string;
}
export interface DeleteClassifierResponse {
}
export interface DeleteColumnStatisticsForPartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    ColumnName: string;
}
export interface DeleteColumnStatisticsForPartitionResponse {
}
export interface DeleteColumnStatisticsForTableRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    ColumnName: string;
}
export interface DeleteColumnStatisticsForTableResponse {
}
export interface DeleteColumnStatisticsTaskSettingsRequest {
    DatabaseName: string;
    TableName: string;
    CatalogID?: string | undefined;
}
export interface DeleteColumnStatisticsTaskSettingsResponse {
}
export interface DeleteConnectionRequest {
    CatalogId?: string | undefined;
    ConnectionName: string;
}
export interface DeleteConnectionResponse {
}
export interface DeleteConnectionTypeRequest {
    ConnectionType: string;
}
export interface DeleteConnectionTypeResponse {
}
export interface DeleteCrawlerRequest {
    Name: string;
}
export interface DeleteCrawlerResponse {
}
export interface DeleteCustomEntityTypeRequest {
    Name: string;
}
export interface DeleteCustomEntityTypeResponse {
    Name?: string | undefined;
}
export interface DeleteDatabaseRequest {
    CatalogId?: string | undefined;
    Name: string;
}
export interface DeleteDatabaseResponse {
}
export interface DeleteDataQualityEvaluationConfigRequest {
    Name: string;
}
export interface DeleteDataQualityEvaluationConfigResponse {
}
export interface DeleteDataQualityRulesetRequest {
    Name: string;
}
export interface DeleteDataQualityRulesetResponse {
}
export interface DeleteDevEndpointRequest {
    EndpointName: string;
}
export interface DeleteDevEndpointResponse {
}
export interface DeleteFormTypeRequest {
    Identifier: string;
}
export interface DeleteFormTypeResponse {
}
export interface DeleteGlossaryRequest {
    Identifier: string;
}
export interface DeleteGlossaryResponse {
}
export interface DeleteGlossaryTermRequest {
    Identifier: string;
}
export interface DeleteGlossaryTermResponse {
}
export interface DeleteGlueIdentityCenterConfigurationRequest {
}
export interface DeleteGlueIdentityCenterConfigurationResponse {
}
export interface DeleteIntegrationRequest {
    IntegrationIdentifier: string;
}
export interface DeleteIntegrationResponse {
    SourceArn: string;
    TargetArn: string;
    IntegrationName: string;
    Description?: string | undefined;
    IntegrationArn: string;
    KmsKeyId?: string | undefined;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
    Status: IntegrationStatus;
    CreateTime: Date;
    Errors?: IntegrationError[] | undefined;
    DataFilter?: string | undefined;
}
export interface DeleteIntegrationResourcePropertyRequest {
    ResourceArn: string;
}
export interface DeleteIntegrationResourcePropertyResponse {
}
export interface DeleteIntegrationTablePropertiesRequest {
    ResourceArn: string;
    TableName: string;
}
export interface DeleteIntegrationTablePropertiesResponse {
}
export interface DeleteJobRequest {
    JobName: string;
}
export interface DeleteJobResponse {
    JobName?: string | undefined;
}
export interface DeleteMLTransformRequest {
    TransformId: string;
}
export interface DeleteMLTransformResponse {
    TransformId?: string | undefined;
}
export interface DeletePartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
}
export interface DeletePartitionResponse {
}
export interface DeletePartitionIndexRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    IndexName: string;
}
export interface DeletePartitionIndexResponse {
}
export interface DeleteRegistryInput {
    RegistryId: RegistryId;
}
export type RegistryStatus = "AVAILABLE" | "DELETING" | (string & {});
export interface DeleteRegistryResponse {
    RegistryName?: string | undefined;
    RegistryArn?: string | undefined;
    Status?: RegistryStatus | undefined;
}
export interface DeleteResourcePolicyRequest {
    PolicyHashCondition?: string | undefined;
    ResourceArn?: string | undefined;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteSchemaInput {
    SchemaId: SchemaId;
}
export interface DeleteSchemaResponse {
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    Status?: SchemaStatus | undefined;
}
export type VersionsString = string;
export interface DeleteSchemaVersionsInput {
    SchemaId: SchemaId;
    Versions: string;
}
export type ErrorCodeString = string;
export type ErrorMessageString = string;
export interface ErrorDetails {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export interface SchemaVersionErrorItem {
    VersionNumber?: number | undefined;
    ErrorDetails?: ErrorDetails | undefined;
}
export type SchemaVersionErrorList = SchemaVersionErrorItem[];
export interface DeleteSchemaVersionsResponse {
    SchemaVersionErrors?: SchemaVersionErrorItem[] | undefined;
}
export interface DeleteSecurityConfigurationRequest {
    Name: string;
}
export interface DeleteSecurityConfigurationResponse {
}
export interface DeleteSessionRequest {
    Id: string;
    RequestOrigin?: string | undefined;
}
export interface DeleteSessionResponse {
    Id?: string | undefined;
}
export interface DeleteTableRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    Name: string;
    TransactionId?: string | undefined;
}
export interface DeleteTableResponse {
}
export interface DeleteTableOptimizerRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
}
export interface DeleteTableOptimizerResponse {
}
export interface DeleteTableVersionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    VersionId: string;
}
export interface DeleteTableVersionResponse {
}
export interface DeleteTriggerRequest {
    Name: string;
}
export interface DeleteTriggerResponse {
    Name?: string | undefined;
}
export interface DeleteUsageProfileRequest {
    Name: string;
}
export interface DeleteUsageProfileResponse {
}
export interface DeleteUserDefinedFunctionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    FunctionName: string;
}
export interface DeleteUserDefinedFunctionResponse {
}
export interface DeleteWorkflowRequest {
    Name: string;
}
export interface DeleteWorkflowResponse {
    Name?: string | undefined;
}
export interface DescribeConnectionTypeRequest {
    ConnectionType: string;
}
export type Description = string;
export type AuthenticationTypes = AuthenticationType[];
export type DataOperation = "READ" | "WRITE" | (string & {});
export type DataOperations = DataOperation[];
export type ComputeEnvironments = ComputeEnvironment[];
export interface Capabilities {
    SupportedAuthenticationTypes: AuthenticationType[];
    SupportedDataOperations: DataOperation[];
    SupportedComputeEnvironments: ComputeEnvironment[];
}
export type PropertyName = string;
export type PropertyDescriptionString = string;
export type PropertyType = "USER_INPUT" | "SECRET" | "READ_ONLY" | "UNUSED" | "SECRET_OR_USER_INPUT" | (string & {});
export type PropertyTypes = PropertyType[];
export type AllowedValueDescriptionString = string;
export type AllowedValueValueString = string;
export interface AllowedValue {
    Description?: string | undefined;
    Value: string;
}
export type AllowedValues = AllowedValue[];
export type PropertyLocation = "HEADER" | "BODY" | "QUERY_PARAM" | "PATH" | (string & {});
export interface Property {
    Name: string;
    Description: string;
    Required: boolean;
    DefaultValue?: string | undefined;
    PropertyTypes: PropertyType[];
    AllowedValues?: AllowedValue[] | undefined;
    DataOperationScopes?: DataOperation[] | undefined;
    KeyOverride?: string | undefined;
    PropertyLocation?: PropertyLocation | undefined;
}
export type PropertiesMap = {
    [key: string]: Property | undefined;
};
export interface AuthConfiguration {
    AuthenticationType: Property;
    SecretArn?: Property | undefined;
    OAuth2Properties?: {
        [key: string]: Property | undefined;
    } | undefined;
    BasicAuthenticationProperties?: {
        [key: string]: Property | undefined;
    } | undefined;
    CustomAuthenticationProperties?: {
        [key: string]: Property | undefined;
    } | undefined;
}
export type ComputeEnvironmentName = string;
export type ComputeEnvironmentConfigurationDescriptionString = string;
export type PropertyNameOverrides = {
    [key: string]: string | undefined;
};
export type ListOfString = string[];
export interface ComputeEnvironmentConfiguration {
    Name: string;
    Description: string;
    ComputeEnvironment: ComputeEnvironment;
    SupportedAuthenticationTypes: AuthenticationType[];
    ConnectionOptions: {
        [key: string]: Property | undefined;
    };
    ConnectionPropertyNameOverrides: {
        [key: string]: string | undefined;
    };
    ConnectionOptionNameOverrides: {
        [key: string]: string | undefined;
    };
    ConnectionPropertiesRequiredOverrides: string[];
    PhysicalConnectionPropertiesRequired?: boolean | undefined;
}
export type ComputeEnvironmentConfigurationMap = {
    [key: string]: ComputeEnvironmentConfiguration | undefined;
};
export type HTTPMethod = "GET" | "POST" | (string & {});
export type PathString = string;
export type ConnectorPropertyKey = string;
export interface ConnectorProperty {
    Name: string;
    KeyOverride?: string | undefined;
    Required: boolean;
    DefaultValue?: string | undefined;
    AllowedValues?: string[] | undefined;
    PropertyLocation?: PropertyLocation | undefined;
    PropertyType: PropertyType;
    Format?: string | undefined;
}
export type ConnectorPropertyList = ConnectorProperty[];
export type JsonPathString = string;
export interface ResponseConfiguration {
    ResultPath: string;
    ErrorPath?: string | undefined;
}
export type DefaultValue = string;
export interface ResponseExtractionMapping {
    ContentPath?: string | undefined;
    HeaderKey?: string | undefined;
}
export interface ExtractedParameter {
    Key?: string | undefined;
    DefaultValue?: string | undefined;
    PropertyLocation?: PropertyLocation | undefined;
    Value?: ResponseExtractionMapping | undefined;
}
export interface CursorConfiguration {
    NextPage: ExtractedParameter;
    LimitParameter?: ExtractedParameter | undefined;
}
export interface OffsetConfiguration {
    OffsetParameter: ExtractedParameter;
    LimitParameter: ExtractedParameter;
}
export interface PaginationConfiguration {
    CursorConfiguration?: CursorConfiguration | undefined;
    OffsetConfiguration?: OffsetConfiguration | undefined;
}
export type FilterMode = "QUERY_PARAMS" | "FILTER_STRING" | (string & {});
export type ConnectionStringToStringMap = {
    [key: string]: string | undefined;
};
export interface BetweenConfiguration {
    LowBoundKey?: string | undefined;
    HighBoundKey?: string | undefined;
    Template?: string | undefined;
}
export interface FilterStringConfiguration {
    QueryParameterName: string;
    QuoteStringValues?: boolean | undefined;
    QuoteCharacter?: string | undefined;
}
export interface FilterConfiguration {
    FilterMode: FilterMode;
    OperatorMappings?: {
        [key: string]: string | undefined;
    } | undefined;
    DateTimeFormat?: string | undefined;
    StripQuotes?: boolean | undefined;
    BetweenConfiguration?: BetweenConfiguration | undefined;
    FilterStringConfiguration?: FilterStringConfiguration | undefined;
}
export interface SourceConfiguration {
    RequestMethod?: HTTPMethod | undefined;
    RequestPath?: string | undefined;
    RequestParameters?: ConnectorProperty[] | undefined;
    ResponseConfiguration?: ResponseConfiguration | undefined;
    PaginationConfiguration?: PaginationConfiguration | undefined;
    FilterConfiguration?: FilterConfiguration | undefined;
}
export type EntityConfigurationMapKeyString = string;
export type FieldDefinitionMapKeyString = string;
export type FieldDataType = "INT" | "SMALLINT" | "BIGINT" | "FLOAT" | "LONG" | "DATE" | "BOOLEAN" | "MAP" | "ARRAY" | "STRING" | "TIMESTAMP" | "DECIMAL" | "BYTE" | "SHORT" | "DOUBLE" | "STRUCT" | "BINARY" | "UNION" | (string & {});
export interface FilterOverrides {
    FieldName?: string | undefined;
    OperatorMappings?: {
        [key: string]: string | undefined;
    } | undefined;
    BetweenConfiguration?: BetweenConfiguration | undefined;
    DateTimeFormat?: string | undefined;
}
export interface FieldDefinition {
    Name: string;
    FieldDataType: FieldDataType;
    ResponseDateFormat?: string | undefined;
    IsPartitionable?: boolean | undefined;
    IsNullable?: boolean | undefined;
    IsQueryable?: boolean | undefined;
    IsOrderable?: boolean | undefined;
    FilterOverrides?: FilterOverrides | undefined;
}
export type FieldDefinitionMap = {
    [key: string]: FieldDefinition | undefined;
};
export interface EntityConfiguration {
    SourceConfiguration?: SourceConfiguration | undefined;
    Schema?: {
        [key: string]: FieldDefinition | undefined;
    } | undefined;
}
export type EntityConfigurationMap = {
    [key: string]: EntityConfiguration | undefined;
};
export interface RestConfiguration {
    GlobalSourceConfiguration?: SourceConfiguration | undefined;
    ValidationEndpointConfiguration?: SourceConfiguration | undefined;
    EntityConfigurations?: {
        [key: string]: EntityConfiguration | undefined;
    } | undefined;
}
export interface DescribeConnectionTypeResponse {
    ConnectionType?: string | undefined;
    Description?: string | undefined;
    Capabilities?: Capabilities | undefined;
    ConnectionProperties?: {
        [key: string]: Property | undefined;
    } | undefined;
    ConnectionOptions?: {
        [key: string]: Property | undefined;
    } | undefined;
    AuthenticationConfiguration?: AuthConfiguration | undefined;
    ComputeEnvironmentConfigurations?: {
        [key: string]: ComputeEnvironmentConfiguration | undefined;
    } | undefined;
    PhysicalConnectionRequirements?: {
        [key: string]: Property | undefined;
    } | undefined;
    AthenaConnectionProperties?: {
        [key: string]: Property | undefined;
    } | undefined;
    PythonConnectionProperties?: {
        [key: string]: Property | undefined;
    } | undefined;
    SparkConnectionProperties?: {
        [key: string]: Property | undefined;
    } | undefined;
    RestConfiguration?: RestConfiguration | undefined;
}
export type EntityName = string;
export type NextToken = string;
export type ApiVersion = string;
export interface DescribeEntityRequest {
    ConnectionName: string;
    CatalogId?: string | undefined;
    EntityName: string;
    NextToken?: string | undefined;
    DataStoreApiVersion?: string | undefined;
}
export type EntityFieldName = string;
export type FieldLabel = string;
export type FieldDescription = string;
export type FieldFilterOperator = "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "EQUAL_TO" | "NOT_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "LESS_THAN_OR_EQUAL_TO" | "CONTAINS" | "ORDER_BY" | (string & {});
export type FieldFilterOperatorsList = FieldFilterOperator[];
export type CustomProperties = {
    [key: string]: string | undefined;
};
export interface Field {
    FieldName?: string | undefined;
    Label?: string | undefined;
    Description?: string | undefined;
    FieldType?: FieldDataType | undefined;
    IsPrimaryKey?: boolean | undefined;
    IsNullable?: boolean | undefined;
    IsRetrievable?: boolean | undefined;
    IsFilterable?: boolean | undefined;
    IsPartitionable?: boolean | undefined;
    IsCreateable?: boolean | undefined;
    IsUpdateable?: boolean | undefined;
    IsUpsertable?: boolean | undefined;
    IsDefaultOnCreate?: boolean | undefined;
    SupportedValues?: string[] | undefined;
    SupportedFilterOperators?: FieldFilterOperator[] | undefined;
    ParentField?: string | undefined;
    NativeDataType?: string | undefined;
    CustomProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type FieldsList = Field[];
export interface DescribeEntityResponse {
    Fields?: Field[] | undefined;
    NextToken?: string | undefined;
}
export type IntegrationInteger = number;
export interface DescribeInboundIntegrationsRequest {
    IntegrationArn?: string | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
    TargetArn?: string | undefined;
}
export interface InboundIntegration {
    SourceArn: string;
    TargetArn: string;
    IntegrationArn: string;
    Status: IntegrationStatus;
    CreateTime: Date;
    IntegrationConfig?: IntegrationConfig | undefined;
    Errors?: IntegrationError[] | undefined;
}
export type InboundIntegrationsList = InboundIntegration[];
export interface DescribeInboundIntegrationsResponse {
    InboundIntegrations?: InboundIntegration[] | undefined;
    Marker?: string | undefined;
}
export type IntegrationFilterValues = string[];
export interface IntegrationFilter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type IntegrationFilterList = IntegrationFilter[];
export interface DescribeIntegrationsRequest {
    IntegrationIdentifier?: string | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
    Filters?: IntegrationFilter[] | undefined;
}
export interface Integration {
    SourceArn: string;
    TargetArn: string;
    Description?: string | undefined;
    IntegrationName: string;
    IntegrationArn: string;
    KmsKeyId?: string | undefined;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
    Status: IntegrationStatus;
    CreateTime: Date;
    IntegrationConfig?: IntegrationConfig | undefined;
    Errors?: IntegrationError[] | undefined;
    DataFilter?: string | undefined;
}
export type IntegrationsList = Integration[];
export interface DescribeIntegrationsResponse {
    Integrations?: Integration[] | undefined;
    Marker?: string | undefined;
}
export interface DisassociateGlossaryTermsRequest {
    AssetIdentifier: string;
    IterableFormName?: string | undefined;
    ItemIdentifier?: string | undefined;
    GlossaryTermIdentifiers: string[];
    ClientToken?: string | undefined;
}
export interface DisassociateGlossaryTermsResponse {
    AssetIdentifier?: string | undefined;
    IterableFormName?: string | undefined;
    ItemIdentifier?: string | undefined;
    GlossaryTerms?: string[] | undefined;
}
export interface GetAssetInput {
    Identifier: string;
}
export type AssetName = string;
export type AssetDescription = string;
export type CreatedAt = Date;
export type UpdatedAt = Date;
export type IterableFormKey = string;
export interface IterableFormEntry {
    FormTypeId?: string | undefined;
}
export type IterableFormMap = {
    [key: string]: IterableFormEntry | undefined;
};
export interface GetAssetOutput {
    Id: string;
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    AssetTypeId: string;
    GlossaryTerms?: string[] | undefined;
    Forms?: {
        [key: string]: AssetFormEntry | undefined;
    } | undefined;
    Attachments?: {
        [key: string]: AssetFormEntry | undefined;
    } | undefined;
    IterableForms?: {
        [key: string]: IterableFormEntry | undefined;
    } | undefined;
}
export interface GetAssetTypeRequest {
    Identifier: string;
}
export type AssetTypeName = string;
export type AssetTypeFormKey = string;
export interface AssetTypeFormReference {
    FormTypeIdentifier: string;
}
export type AssetTypeFormsMap = {
    [key: string]: AssetTypeFormReference | undefined;
};
export interface GetAssetTypeResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Forms?: {
        [key: string]: AssetTypeFormReference | undefined;
    } | undefined;
}
export interface GetBlueprintRequest {
    Name: string;
    IncludeBlueprint?: boolean | undefined;
    IncludeParameterSpec?: boolean | undefined;
}
export interface GetBlueprintResponse {
    Blueprint?: Blueprint | undefined;
}
export interface GetBlueprintRunRequest {
    BlueprintName: string;
    RunId: string;
}
export type BlueprintRunState = "RUNNING" | "SUCCEEDED" | "FAILED" | "ROLLING_BACK" | (string & {});
export type BlueprintParameters = string;
export type OrchestrationIAMRoleArn = string;
export interface BlueprintRun {
    BlueprintName?: string | undefined;
    RunId?: string | undefined;
    WorkflowName?: string | undefined;
    State?: BlueprintRunState | undefined;
    StartedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    ErrorMessage?: string | undefined;
    RollbackErrorMessage?: string | undefined;
    Parameters?: string | undefined;
    RoleArn?: string | undefined;
}
export interface GetBlueprintRunResponse {
    BlueprintRun?: BlueprintRun | undefined;
}
export type PageSize = number;
export interface GetBlueprintRunsRequest {
    BlueprintName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type BlueprintRuns = BlueprintRun[];
export interface GetBlueprintRunsResponse {
    BlueprintRuns?: BlueprintRun[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCatalogRequest {
    CatalogId: string;
}
export interface DataLakeAccessPropertiesOutput {
    DataLakeAccess?: boolean | undefined;
    DataTransferRole?: string | undefined;
    KmsKey?: string | undefined;
    ManagedWorkgroupName?: string | undefined;
    ManagedWorkgroupStatus?: string | undefined;
    RedshiftDatabaseName?: string | undefined;
    StatusMessage?: string | undefined;
    CatalogType?: string | undefined;
}
export interface IcebergOptimizationPropertiesOutput {
    RoleArn?: string | undefined;
    Compaction?: {
        [key: string]: string | undefined;
    } | undefined;
    Retention?: {
        [key: string]: string | undefined;
    } | undefined;
    OrphanFileDeletion?: {
        [key: string]: string | undefined;
    } | undefined;
    LastUpdatedTime?: Date | undefined;
}
export interface CatalogPropertiesOutput {
    DataLakeAccessProperties?: DataLakeAccessPropertiesOutput | undefined;
    IcebergOptimizationProperties?: IcebergOptimizationPropertiesOutput | undefined;
    CustomProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Catalog {
    CatalogId?: string | undefined;
    Name: string;
    ResourceArn?: string | undefined;
    Description?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    CreateTime?: Date | undefined;
    UpdateTime?: Date | undefined;
    TargetRedshiftCatalog?: TargetRedshiftCatalog | undefined;
    FederatedCatalog?: FederatedCatalog | undefined;
    CatalogProperties?: CatalogPropertiesOutput | undefined;
    CreateTableDefaultPermissions?: PrincipalPermissions[] | undefined;
    CreateDatabaseDefaultPermissions?: PrincipalPermissions[] | undefined;
    AllowFullTableExternalDataAccess?: AllowFullTableExternalDataAccessEnum | undefined;
}
export interface GetCatalogResponse {
    Catalog?: Catalog | undefined;
}
export interface GetCatalogImportStatusRequest {
    CatalogId?: string | undefined;
}
export interface CatalogImportStatus {
    ImportCompleted?: boolean | undefined;
    ImportTime?: Date | undefined;
    ImportedBy?: string | undefined;
}
export interface GetCatalogImportStatusResponse {
    ImportStatus?: CatalogImportStatus | undefined;
}
export type Token = string;
export interface GetCatalogsRequest {
    ParentCatalogId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Recursive?: boolean | undefined;
    IncludeRoot?: boolean | undefined;
    HasDatabases?: boolean | undefined;
}
export type CatalogList = Catalog[];
export interface GetCatalogsResponse {
    CatalogList: Catalog[];
    NextToken?: string | undefined;
}
export interface GetClassifierRequest {
    Name: string;
}
export interface GrokClassifier {
    Name: string;
    Classification: string;
    CreationTime?: Date | undefined;
    LastUpdated?: Date | undefined;
    Version?: number | undefined;
    GrokPattern: string;
    CustomPatterns?: string | undefined;
}
export interface XMLClassifier {
    Name: string;
    Classification: string;
    CreationTime?: Date | undefined;
    LastUpdated?: Date | undefined;
    Version?: number | undefined;
    RowTag?: string | undefined;
}
export interface JsonClassifier {
    Name: string;
    CreationTime?: Date | undefined;
    LastUpdated?: Date | undefined;
    Version?: number | undefined;
    JsonPath: string;
}
export interface CsvClassifier {
    Name: string;
    CreationTime?: Date | undefined;
    LastUpdated?: Date | undefined;
    Version?: number | undefined;
    Delimiter?: string | undefined;
    QuoteSymbol?: string | undefined;
    ContainsHeader?: CsvHeaderOption | undefined;
    Header?: string[] | undefined;
    DisableValueTrimming?: boolean | undefined;
    AllowSingleColumn?: boolean | undefined;
    CustomDatatypeConfigured?: boolean | undefined;
    CustomDatatypes?: string[] | undefined;
    Serde?: CsvSerdeOption | undefined;
}
export interface Classifier {
    GrokClassifier?: GrokClassifier | undefined;
    XMLClassifier?: XMLClassifier | undefined;
    JsonClassifier?: JsonClassifier | undefined;
    CsvClassifier?: CsvClassifier | undefined;
}
export interface GetClassifierResponse {
    Classifier?: Classifier | undefined;
}
export interface GetClassifiersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ClassifierList = Classifier[];
export interface GetClassifiersResponse {
    Classifiers?: Classifier[] | undefined;
    NextToken?: string | undefined;
}
export type GetColumnNamesList = string[];
export interface GetColumnStatisticsForPartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    ColumnNames: string[];
}
export type TypeString = string;
export type ColumnStatisticsType = "BOOLEAN" | "DATE" | "DECIMAL" | "DOUBLE" | "LONG" | "STRING" | "BINARY" | (string & {});
export type NonNegativeLong = number;
export interface BooleanColumnStatisticsData {
    NumberOfTrues: number;
    NumberOfFalses: number;
    NumberOfNulls: number;
}
export interface DateColumnStatisticsData {
    MinimumValue?: Date | undefined;
    MaximumValue?: Date | undefined;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export interface DecimalNumber {
    UnscaledValue: Uint8Array;
    Scale: number;
}
export interface DecimalColumnStatisticsData {
    MinimumValue?: DecimalNumber | undefined;
    MaximumValue?: DecimalNumber | undefined;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export interface DoubleColumnStatisticsData {
    MinimumValue?: number | undefined;
    MaximumValue?: number | undefined;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export interface LongColumnStatisticsData {
    MinimumValue?: number | undefined;
    MaximumValue?: number | undefined;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export type NonNegativeDouble = number;
export interface StringColumnStatisticsData {
    MaximumLength: number;
    AverageLength: number;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export interface BinaryColumnStatisticsData {
    MaximumLength: number;
    AverageLength: number;
    NumberOfNulls: number;
}
export interface ColumnStatisticsData {
    Type: ColumnStatisticsType;
    BooleanColumnStatisticsData?: BooleanColumnStatisticsData | undefined;
    DateColumnStatisticsData?: DateColumnStatisticsData | undefined;
    DecimalColumnStatisticsData?: DecimalColumnStatisticsData | undefined;
    DoubleColumnStatisticsData?: DoubleColumnStatisticsData | undefined;
    LongColumnStatisticsData?: LongColumnStatisticsData | undefined;
    StringColumnStatisticsData?: StringColumnStatisticsData | undefined;
    BinaryColumnStatisticsData?: BinaryColumnStatisticsData | undefined;
}
export interface ColumnStatistics {
    ColumnName: string;
    ColumnType: string;
    AnalyzedTime: Date;
    StatisticsData: ColumnStatisticsData;
}
export type ColumnStatisticsList = ColumnStatistics[];
export interface ColumnError {
    ColumnName?: string | undefined;
    Error?: ErrorDetail | undefined;
}
export type ColumnErrors = ColumnError[];
export interface GetColumnStatisticsForPartitionResponse {
    ColumnStatisticsList?: ColumnStatistics[] | undefined;
    Errors?: ColumnError[] | undefined;
}
export interface GetColumnStatisticsForTableRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    ColumnNames: string[];
}
export interface GetColumnStatisticsForTableResponse {
    ColumnStatisticsList?: ColumnStatistics[] | undefined;
    Errors?: ColumnError[] | undefined;
}
export interface GetColumnStatisticsTaskRunRequest {
    ColumnStatisticsTaskRunId: string;
}
export type TableName = string;
export type PositiveInteger = number;
export type ComputationType = "FULL" | "INCREMENTAL" | (string & {});
export type ColumnStatisticsState = "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "STOPPED" | (string & {});
export interface ColumnStatisticsTaskRun {
    CustomerId?: string | undefined;
    ColumnStatisticsTaskRunId?: string | undefined;
    DatabaseName?: string | undefined;
    TableName?: string | undefined;
    ColumnNameList?: string[] | undefined;
    CatalogID?: string | undefined;
    Role?: string | undefined;
    SampleSize?: number | undefined;
    SecurityConfiguration?: string | undefined;
    NumberOfWorkers?: number | undefined;
    WorkerType?: string | undefined;
    ComputationType?: ComputationType | undefined;
    Status?: ColumnStatisticsState | undefined;
    CreationTime?: Date | undefined;
    LastUpdated?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ErrorMessage?: string | undefined;
    DPUSeconds?: number | undefined;
}
export interface GetColumnStatisticsTaskRunResponse {
    ColumnStatisticsTaskRun?: ColumnStatisticsTaskRun | undefined;
}
export interface GetColumnStatisticsTaskRunsRequest {
    DatabaseName: string;
    TableName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    CatalogID?: string | undefined;
}
export type ColumnStatisticsTaskRunsList = ColumnStatisticsTaskRun[];
export interface GetColumnStatisticsTaskRunsResponse {
    ColumnStatisticsTaskRuns?: ColumnStatisticsTaskRun[] | undefined;
    NextToken?: string | undefined;
}
export interface GetColumnStatisticsTaskSettingsRequest {
    DatabaseName: string;
    TableName: string;
    CatalogID?: string | undefined;
}
export type ScheduleType = "CRON" | "AUTO" | (string & {});
export type SettingSource = "CATALOG" | "TABLE" | (string & {});
export type ExecutionStatus = "FAILED" | "STARTED" | (string & {});
export interface ExecutionAttempt {
    Status?: ExecutionStatus | undefined;
    ColumnStatisticsTaskRunId?: string | undefined;
    ExecutionTimestamp?: Date | undefined;
    ErrorMessage?: string | undefined;
}
export interface ColumnStatisticsTaskSettings {
    DatabaseName?: string | undefined;
    TableName?: string | undefined;
    Schedule?: Schedule | undefined;
    ColumnNameList?: string[] | undefined;
    CatalogID?: string | undefined;
    Role?: string | undefined;
    SampleSize?: number | undefined;
    SecurityConfiguration?: string | undefined;
    ScheduleType?: ScheduleType | undefined;
    SettingSource?: SettingSource | undefined;
    LastExecutionAttempt?: ExecutionAttempt | undefined;
}
export interface GetColumnStatisticsTaskSettingsResponse {
    ColumnStatisticsTaskSettings?: ColumnStatisticsTaskSettings | undefined;
}
export interface GetConnectionRequest {
    CatalogId?: string | undefined;
    Name: string;
    HidePassword?: boolean | undefined;
    ApplyOverrideForComputeEnvironment?: ComputeEnvironment | undefined;
}
export type LongValueString = string;
export interface OAuth2Properties {
    OAuth2GrantType?: OAuth2GrantType | undefined;
    OAuth2ClientApplication?: OAuth2ClientApplication | undefined;
    TokenUrl?: string | undefined;
    TokenUrlParametersMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface AuthenticationConfiguration {
    AuthenticationType?: AuthenticationType | undefined;
    SecretArn?: string | undefined;
    KmsKeyArn?: string | undefined;
    OAuth2Properties?: OAuth2Properties | undefined;
}
export type ConnectionSchemaVersion = number;
export interface Connection {
    Name?: string | undefined;
    Description?: string | undefined;
    ConnectionType?: ConnectionType | undefined;
    MatchCriteria?: string[] | undefined;
    ConnectionProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    SparkProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    AthenaProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    PythonProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    PhysicalConnectionRequirements?: PhysicalConnectionRequirements | undefined;
    CreationTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    LastUpdatedBy?: string | undefined;
    Status?: ConnectionStatus | undefined;
    StatusReason?: string | undefined;
    LastConnectionValidationTime?: Date | undefined;
    AuthenticationConfiguration?: AuthenticationConfiguration | undefined;
    ConnectionSchemaVersion?: number | undefined;
    CompatibleComputeEnvironments?: ComputeEnvironment[] | undefined;
}
export interface GetConnectionResponse {
    Connection?: Connection | undefined;
}
export interface GetConnectionsFilter {
    MatchCriteria?: string[] | undefined;
    ConnectionType?: ConnectionType | undefined;
    ConnectionSchemaVersion?: number | undefined;
}
export interface GetConnectionsRequest {
    CatalogId?: string | undefined;
    Filter?: GetConnectionsFilter | undefined;
    HidePassword?: boolean | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ConnectionList = Connection[];
export interface GetConnectionsResponse {
    ConnectionList?: Connection[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCrawlerRequest {
    Name: string;
}
export interface GetCrawlerResponse {
    Crawler?: Crawler | undefined;
}
export interface GetCrawlerMetricsRequest {
    CrawlerNameList?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface CrawlerMetrics {
    CrawlerName?: string | undefined;
    TimeLeftSeconds?: number | undefined;
    StillEstimating?: boolean | undefined;
    LastRuntimeSeconds?: number | undefined;
    MedianRuntimeSeconds?: number | undefined;
    TablesCreated?: number | undefined;
    TablesUpdated?: number | undefined;
    TablesDeleted?: number | undefined;
}
export type CrawlerMetricsList = CrawlerMetrics[];
export interface GetCrawlerMetricsResponse {
    CrawlerMetricsList?: CrawlerMetrics[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCrawlersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface GetCrawlersResponse {
    Crawlers?: Crawler[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCustomEntityTypeRequest {
    Name: string;
}
export interface GetCustomEntityTypeResponse {
    Name?: string | undefined;
    RegexString?: string | undefined;
    ContextWords?: string[] | undefined;
}
export type GlueResourceType = "JOB" | "SESSION" | (string & {});
export interface GetDashboardUrlRequest {
    ResourceId: string;
    ResourceType: GlueResourceType;
    RequestOrigin?: string | undefined;
}
export type SensitiveUrl = string | redacted.Redacted<string>;
export interface GetDashboardUrlResponse {
    Url: string | redacted.Redacted<string>;
}
export interface GetDatabaseRequest {
    CatalogId?: string | undefined;
    Name: string;
}
export interface Database {
    Name: string;
    Description?: string | undefined;
    LocationUri?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    CreateTime?: Date | undefined;
    CreateTableDefaultPermissions?: PrincipalPermissions[] | undefined;
    TargetDatabase?: DatabaseIdentifier | undefined;
    CatalogId?: string | undefined;
    FederatedDatabase?: FederatedDatabase | undefined;
}
export interface GetDatabaseResponse {
    Database?: Database | undefined;
}
export type CatalogGetterPageSize = number;
export type ResourceShareType = "FOREIGN" | "ALL" | "FEDERATED" | (string & {});
export type DatabaseAttributes = "NAME" | "TARGET_DATABASE" | (string & {});
export type DatabaseAttributesList = DatabaseAttributes[];
export interface GetDatabasesRequest {
    CatalogId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ResourceShareType?: ResourceShareType | undefined;
    AttributesToGet?: DatabaseAttributes[] | undefined;
}
export type DatabaseList = Database[];
export interface GetDatabasesResponse {
    DatabaseList: Database[];
    NextToken?: string | undefined;
}
export interface GetDataCatalogEncryptionSettingsRequest {
    CatalogId?: string | undefined;
}
export type CatalogEncryptionMode = "DISABLED" | "SSE-KMS" | "SSE-KMS-WITH-SERVICE-ROLE" | (string & {});
export interface EncryptionAtRest {
    CatalogEncryptionMode: CatalogEncryptionMode;
    SseAwsKmsKeyId?: string | undefined;
    CatalogEncryptionServiceRole?: string | undefined;
}
export interface ConnectionPasswordEncryption {
    ReturnConnectionPasswordEncrypted: boolean;
    AwsKmsKeyId?: string | undefined;
}
export interface DataCatalogEncryptionSettings {
    EncryptionAtRest?: EncryptionAtRest | undefined;
    ConnectionPasswordEncryption?: ConnectionPasswordEncryption | undefined;
}
export interface GetDataCatalogEncryptionSettingsResponse {
    DataCatalogEncryptionSettings?: DataCatalogEncryptionSettings | undefined;
}
export interface GetDataCatalogExportConfigurationInput {
}
export type ExportSetting = "ENABLED" | "DISABLED" | (string & {});
export type ExportStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | "FAILED" | (string & {});
export type SseAlgorithm = string;
export type KmsKeyArnString = string;
export interface ExportEncryptionConfiguration {
    SseAlgorithm?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export type S3TableBucketArn = string;
export interface GetDataCatalogExportConfigurationOutput {
    ExportSetting?: ExportSetting | undefined;
    Status?: ExportStatus | undefined;
    EncryptionConfiguration?: ExportEncryptionConfiguration | undefined;
    S3TableBucketArn?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetDataflowGraphRequest {
    PythonScript?: string | undefined;
}
export interface GetDataflowGraphResponse {
    DagNodes?: CodeGenNode[] | undefined;
    DagEdges?: CodeGenEdge[] | undefined;
}
export interface GetDataQualityEvaluationConfigRequest {
    Name: string;
}
export interface GetDataQualityEvaluationConfigResponse {
    Name?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    Level?: DataQualityEvaluationConfigLevel | undefined;
    DataSource?: DataQualityEvaluationConfigDataSource | undefined;
    RulesetName?: string | undefined;
    ManagedRulesetName?: DataQualityEvaluationConfigManagedRuleset | undefined;
    Triggers?: DataQualityEvaluationConfigTrigger[] | undefined;
    ScheduleExpression?: string | undefined;
    StartAt?: Date | undefined;
    EndAt?: Date | undefined;
    PauseRuns?: boolean | undefined;
    Role?: string | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    AdditionalRunOptions?: DataQualityEvaluationConfigAdditionalRunOptions | undefined;
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    } | undefined;
}
export interface GetDataQualityModelRequest {
    StatisticId?: string | undefined;
    ProfileId: string;
}
export type DataQualityModelStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export interface GetDataQualityModelResponse {
    Status?: DataQualityModelStatus | undefined;
    StartedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    FailureReason?: string | undefined;
}
export interface GetDataQualityModelResultRequest {
    StatisticId: string;
    ProfileId: string;
}
export interface StatisticModelResult {
    LowerBound?: number | undefined;
    UpperBound?: number | undefined;
    PredictedValue?: number | undefined;
    ActualValue?: number | undefined;
    Date?: Date | undefined;
    InclusionAnnotation?: InclusionAnnotationValue | undefined;
}
export type StatisticModelResults = StatisticModelResult[];
export interface GetDataQualityModelResultResponse {
    CompletedOn?: Date | undefined;
    Model?: StatisticModelResult[] | undefined;
}
export interface GetDataQualityResultRequest {
    ResultId: string;
}
export interface GetDataQualityResultResponse {
    ResultId?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    DataQualityEvaluationConfig?: string | undefined;
    ProfileId?: string | undefined;
    Score?: number | undefined;
    DataSource?: DataSource | undefined;
    RulesetName?: string | undefined;
    EvaluationContext?: string | undefined;
    StartedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    JobName?: string | undefined;
    JobRunId?: string | undefined;
    RulesetEvaluationRunId?: string | undefined;
    RuleResults?: DataQualityRuleResult[] | undefined;
    AnalyzerResults?: DataQualityAnalyzerResult[] | undefined;
    Observations?: DataQualityObservation[] | undefined;
    AggregatedMetrics?: DataQualityAggregatedMetrics | undefined;
}
export interface GetDataQualityResultV2Request {
    ResultId: string;
}
export interface GetDataQualityResultV2Response {
    ResultId?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    DataQualityEvaluationConfig?: string | undefined;
    DataSource?: DataSource | undefined;
    ProfileId?: string | undefined;
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ExecutionStartedOn?: Date | undefined;
    ExecutionCompletedOn?: Date | undefined;
    ResultPublishedOn?: Date | undefined;
    Score?: number | undefined;
    RuleResults?: DataQualityRuleResult[] | undefined;
    AnalyzerResults?: DataQualityAnalyzerResult[] | undefined;
    Observations?: DataQualityObservation[] | undefined;
    EvaluationContext?: string | undefined;
    Descriptors?: {
        [key: string]: string | undefined;
    } | undefined;
    AggregatedMetrics?: DataQualityAggregatedMetrics | undefined;
    RulesetName?: string | undefined;
}
export interface GetDataQualityRuleRecommendationRunRequest {
    RunId: string;
}
export interface DataQualityRuleRecommendationRunAdditionalRunOptions {
    CustomLogGroupPrefix?: string | undefined;
}
export type RecommendationMode = "BASIC" | "ADVANCED" | (string & {});
export interface GetDataQualityRuleRecommendationRunResponse {
    RunId?: string | undefined;
    DataSource?: DataSource | undefined;
    Role?: string | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    Status?: TaskStatusType | undefined;
    ErrorString?: string | undefined;
    StartedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    ExecutionTime?: number | undefined;
    RecommendedRuleset?: string | undefined;
    CreatedRulesetName?: string | undefined;
    DataQualitySecurityConfiguration?: string | undefined;
    AdditionalRunOptions?: DataQualityRuleRecommendationRunAdditionalRunOptions | undefined;
    RecommendationMode?: RecommendationMode | undefined;
}
export interface GetDataQualityRulesetRequest {
    Name: string;
}
export interface GetDataQualityRulesetResponse {
    Name?: string | undefined;
    Description?: string | undefined;
    Ruleset?: string | undefined;
    TargetTable?: DataQualityTargetTable | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    RecommendationRunId?: string | undefined;
    DataQualitySecurityConfiguration?: string | undefined;
}
export interface GetDataQualityRulesetEvaluationRunRequest {
    RunId: string;
}
export interface GetDataQualityRulesetEvaluationRunResponse {
    RunId?: string | undefined;
    DataSource?: DataSource | undefined;
    Role?: string | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    AdditionalRunOptions?: DataQualityEvaluationRunAdditionalRunOptions | undefined;
    Status?: TaskStatusType | undefined;
    ErrorString?: string | undefined;
    StartedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    ExecutionTime?: number | undefined;
    RulesetNames?: string[] | undefined;
    ResultIds?: string[] | undefined;
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    } | undefined;
}
export interface GetDevEndpointRequest {
    EndpointName: string;
}
export interface GetDevEndpointResponse {
    DevEndpoint?: DevEndpoint | undefined;
}
export interface GetDevEndpointsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface GetDevEndpointsResponse {
    DevEndpoints?: DevEndpoint[] | undefined;
    NextToken?: string | undefined;
}
export type OptionKey = string;
export type OptionValue = string;
export type ConnectionOptions = {
    [key: string]: string | undefined;
};
export type FilterPredicate = string;
export type Limit = number;
export type SelectedFields = string[];
export interface GetEntityRecordsRequest {
    ConnectionName?: string | undefined;
    CatalogId?: string | undefined;
    EntityName: string;
    NextToken?: string | undefined;
    DataStoreApiVersion?: string | undefined;
    ConnectionOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    FilterPredicate?: string | undefined;
    Limit: number;
    OrderBy?: string | undefined;
    SelectedFields?: string[] | undefined;
}
export type Record = unknown;
export type Records = any[];
export interface GetEntityRecordsResponse {
    Records?: any[] | undefined;
    NextToken?: string | undefined;
}
export interface GetFormTypeRequest {
    Identifier: string;
}
export type FormTypeName = string;
export type FormTypeSchema = string;
export interface GetFormTypeResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Schema?: string | undefined;
}
export interface GetGlossaryRequest {
    Identifier: string;
}
export interface GetGlossaryResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
}
export interface GetGlossaryTermRequest {
    Identifier: string;
}
export interface GetGlossaryTermResponse {
    Id?: string | undefined;
    GlossaryId?: string | undefined;
    Name?: string | undefined;
    ShortDescription?: string | undefined;
    LongDescription?: string | undefined;
}
export interface GetGlueIdentityCenterConfigurationRequest {
}
export type OrchestrationStringList = string[];
export interface GetGlueIdentityCenterConfigurationResponse {
    ApplicationArn?: string | undefined;
    InstanceArn?: string | undefined;
    Scopes?: string[] | undefined;
    UserBackgroundSessionsEnabled?: boolean | undefined;
}
export interface GetIntegrationResourcePropertyRequest {
    ResourceArn: string;
}
export interface GetIntegrationResourcePropertyResponse {
    ResourceArn?: string | undefined;
    ResourcePropertyArn?: string | undefined;
    SourceProcessingProperties?: SourceProcessingProperties | undefined;
    TargetProcessingProperties?: TargetProcessingProperties | undefined;
}
export interface GetIntegrationTablePropertiesRequest {
    ResourceArn: string;
    TableName: string;
}
export interface GetIntegrationTablePropertiesResponse {
    ResourceArn?: string | undefined;
    TableName?: string | undefined;
    SourceTableConfig?: SourceTableConfig | undefined;
    TargetTableConfig?: TargetTableConfig | undefined;
}
export interface GetJobRequest {
    JobName: string;
}
export interface GetJobResponse {
    Job?: Job | undefined;
}
export type JobName = string;
export type RunId = string;
export interface GetJobBookmarkRequest {
    JobName: string;
    RunId?: string | undefined;
}
export type JsonValue = string;
export interface JobBookmarkEntry {
    JobName?: string | undefined;
    Version?: number | undefined;
    Run?: number | undefined;
    Attempt?: number | undefined;
    PreviousRunId?: string | undefined;
    RunId?: string | undefined;
    JobBookmark?: string | undefined;
}
export interface GetJobBookmarkResponse {
    JobBookmarkEntry?: JobBookmarkEntry | undefined;
}
export interface GetJobRunRequest {
    JobName: string;
    RunId: string;
    PredecessorsIncluded?: boolean | undefined;
}
export interface GetJobRunResponse {
    JobRun?: JobRun | undefined;
}
export type OrchestrationPageSize200 = number;
export interface GetJobRunsRequest {
    JobName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface GetJobRunsResponse {
    JobRuns?: JobRun[] | undefined;
    NextToken?: string | undefined;
}
export interface GetJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface GetJobsResponse {
    Jobs?: Job[] | undefined;
    NextToken?: string | undefined;
}
export type Id = string;
export type Name = string;
export interface GetJobUpgradeAnalysisRequest {
    analysisId: string;
    jobName: string;
}
export type Status = "OBSERVING" | "WAITING_FOR_CONSENT" | "UPGRADING" | "SUCCEEDED" | "FAILED" | "TIMEOUT" | "STOPPED" | (string & {});
export type AnalysisType = "AUTO_UPGRADE" | (string & {});
export interface GetJobUpgradeAnalysisResponse {
    jobName: string;
    analysisId: string;
    status: Status;
    sourceVersion?: string | undefined;
    targetVersion: string;
    analysisType?: AnalysisType | undefined;
    autoUpgradeEvaluationSummary?: string | undefined;
    errorMessage?: string | undefined;
    autoUpgradeEligibilitySummary?: string | undefined;
}
export interface CatalogEntry {
    DatabaseName: string;
    TableName: string;
}
export type CatalogEntries = CatalogEntry[];
export interface Location {
    Jdbc?: CodeGenNodeArg[] | undefined;
    S3?: CodeGenNodeArg[] | undefined;
    DynamoDB?: CodeGenNodeArg[] | undefined;
}
export interface GetMappingRequest {
    Source: CatalogEntry;
    Sinks?: CatalogEntry[] | undefined;
    Location?: Location | undefined;
}
export type SchemaPathString = string;
export type FieldType = string;
export interface MappingEntry {
    SourceTable?: string | undefined;
    SourcePath?: string | undefined;
    SourceType?: string | undefined;
    TargetTable?: string | undefined;
    TargetPath?: string | undefined;
    TargetType?: string | undefined;
}
export type MappingList = MappingEntry[];
export interface GetMappingResponse {
    Mapping: MappingEntry[];
}
export type UUIDv4 = string;
export interface GetMaterializedViewRefreshTaskRunRequest {
    CatalogId: string;
    MaterializedViewRefreshTaskRunId: string;
}
export type MaterializedViewRefreshState = "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "STOPPED" | (string & {});
export type MaterializedViewRefreshType = "FULL" | "INCREMENTAL" | (string & {});
export type ByteCount = number;
export interface MaterializedViewRefreshTaskRun {
    CustomerId?: string | undefined;
    MaterializedViewRefreshTaskRunId?: string | undefined;
    DatabaseName?: string | undefined;
    TableName?: string | undefined;
    CatalogId?: string | undefined;
    Role?: string | undefined;
    Status?: MaterializedViewRefreshState | undefined;
    CreationTime?: Date | undefined;
    LastUpdated?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ErrorMessage?: string | undefined;
    DPUSeconds?: number | undefined;
    RefreshType?: MaterializedViewRefreshType | undefined;
    ProcessedBytes?: number | undefined;
}
export interface GetMaterializedViewRefreshTaskRunResponse {
    MaterializedViewRefreshTaskRun?: MaterializedViewRefreshTaskRun | undefined;
}
export interface GetMLTaskRunRequest {
    TransformId: string;
    TaskRunId: string;
}
export type TaskType = "EVALUATION" | "LABELING_SET_GENERATION" | "IMPORT_LABELS" | "EXPORT_LABELS" | "FIND_MATCHES" | (string & {});
export type ReplaceBoolean = boolean;
export interface ImportLabelsTaskRunProperties {
    InputS3Path?: string | undefined;
    Replace?: boolean | undefined;
}
export interface ExportLabelsTaskRunProperties {
    OutputS3Path?: string | undefined;
}
export interface LabelingSetGenerationTaskRunProperties {
    OutputS3Path?: string | undefined;
}
export interface FindMatchesTaskRunProperties {
    JobId?: string | undefined;
    JobName?: string | undefined;
    JobRunId?: string | undefined;
}
export interface TaskRunProperties {
    TaskType?: TaskType | undefined;
    ImportLabelsTaskRunProperties?: ImportLabelsTaskRunProperties | undefined;
    ExportLabelsTaskRunProperties?: ExportLabelsTaskRunProperties | undefined;
    LabelingSetGenerationTaskRunProperties?: LabelingSetGenerationTaskRunProperties | undefined;
    FindMatchesTaskRunProperties?: FindMatchesTaskRunProperties | undefined;
}
export interface GetMLTaskRunResponse {
    TransformId?: string | undefined;
    TaskRunId?: string | undefined;
    Status?: TaskStatusType | undefined;
    LogGroupName?: string | undefined;
    Properties?: TaskRunProperties | undefined;
    ErrorString?: string | undefined;
    StartedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    ExecutionTime?: number | undefined;
}
export type PaginationToken = string;
export interface TaskRunFilterCriteria {
    TaskRunType?: TaskType | undefined;
    Status?: TaskStatusType | undefined;
    StartedBefore?: Date | undefined;
    StartedAfter?: Date | undefined;
}
export type TaskRunSortColumnType = "TASK_RUN_TYPE" | "STATUS" | "STARTED" | (string & {});
export type SortDirectionType = "DESCENDING" | "ASCENDING" | (string & {});
export interface TaskRunSortCriteria {
    Column: TaskRunSortColumnType;
    SortDirection: SortDirectionType;
}
export interface GetMLTaskRunsRequest {
    TransformId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filter?: TaskRunFilterCriteria | undefined;
    Sort?: TaskRunSortCriteria | undefined;
}
export interface TaskRun {
    TransformId?: string | undefined;
    TaskRunId?: string | undefined;
    Status?: TaskStatusType | undefined;
    LogGroupName?: string | undefined;
    Properties?: TaskRunProperties | undefined;
    ErrorString?: string | undefined;
    StartedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    CompletedOn?: Date | undefined;
    ExecutionTime?: number | undefined;
}
export type TaskRunList = TaskRun[];
export interface GetMLTaskRunsResponse {
    TaskRuns?: TaskRun[] | undefined;
    NextToken?: string | undefined;
}
export interface GetMLTransformRequest {
    TransformId: string;
}
export type TransformStatusType = "NOT_READY" | "READY" | "DELETING" | (string & {});
export type RecordsCount = number;
export interface ConfusionMatrix {
    NumTruePositives?: number | undefined;
    NumFalsePositives?: number | undefined;
    NumTrueNegatives?: number | undefined;
    NumFalseNegatives?: number | undefined;
}
export interface ColumnImportance {
    ColumnName?: string | undefined;
    Importance?: number | undefined;
}
export type ColumnImportanceList = ColumnImportance[];
export interface FindMatchesMetrics {
    AreaUnderPRCurve?: number | undefined;
    Precision?: number | undefined;
    Recall?: number | undefined;
    F1?: number | undefined;
    ConfusionMatrix?: ConfusionMatrix | undefined;
    ColumnImportances?: ColumnImportance[] | undefined;
}
export interface EvaluationMetrics {
    TransformType: TransformType;
    FindMatchesMetrics?: FindMatchesMetrics | undefined;
}
export type LabelCount = number;
export interface SchemaColumn {
    Name?: string | undefined;
    DataType?: string | undefined;
}
export type TransformSchema = SchemaColumn[];
export interface GetMLTransformResponse {
    TransformId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Status?: TransformStatusType | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    InputRecordTables?: GlueTable[] | undefined;
    Parameters?: TransformParameters | undefined;
    EvaluationMetrics?: EvaluationMetrics | undefined;
    LabelCount?: number | undefined;
    Schema?: SchemaColumn[] | undefined;
    Role?: string | undefined;
    GlueVersion?: string | undefined;
    MaxCapacity?: number | undefined;
    WorkerType?: WorkerType | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    MaxRetries?: number | undefined;
    TransformEncryption?: TransformEncryption | undefined;
}
export interface TransformFilterCriteria {
    Name?: string | undefined;
    TransformType?: TransformType | undefined;
    Status?: TransformStatusType | undefined;
    GlueVersion?: string | undefined;
    CreatedBefore?: Date | undefined;
    CreatedAfter?: Date | undefined;
    LastModifiedBefore?: Date | undefined;
    LastModifiedAfter?: Date | undefined;
    Schema?: SchemaColumn[] | undefined;
}
export type TransformSortColumnType = "NAME" | "TRANSFORM_TYPE" | "STATUS" | "CREATED" | "LAST_MODIFIED" | (string & {});
export interface TransformSortCriteria {
    Column: TransformSortColumnType;
    SortDirection: SortDirectionType;
}
export interface GetMLTransformsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filter?: TransformFilterCriteria | undefined;
    Sort?: TransformSortCriteria | undefined;
}
export interface MLTransform {
    TransformId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Status?: TransformStatusType | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    InputRecordTables?: GlueTable[] | undefined;
    Parameters?: TransformParameters | undefined;
    EvaluationMetrics?: EvaluationMetrics | undefined;
    LabelCount?: number | undefined;
    Schema?: SchemaColumn[] | undefined;
    Role?: string | undefined;
    GlueVersion?: string | undefined;
    MaxCapacity?: number | undefined;
    WorkerType?: WorkerType | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    MaxRetries?: number | undefined;
    TransformEncryption?: TransformEncryption | undefined;
}
export type TransformList = MLTransform[];
export interface GetMLTransformsResponse {
    Transforms: MLTransform[];
    NextToken?: string | undefined;
}
export interface GetPartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    AuditContext?: AuditContext | undefined;
}
export interface GetPartitionResponse {
    Partition?: Partition | undefined;
}
export interface GetPartitionIndexesRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    NextToken?: string | undefined;
}
export interface KeySchemaElement {
    Name: string;
    Type: string;
}
export type KeySchemaElementList = KeySchemaElement[];
export type PartitionIndexStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export type BackfillErrorCode = "ENCRYPTED_PARTITION_ERROR" | "INTERNAL_ERROR" | "INVALID_PARTITION_TYPE_DATA_ERROR" | "MISSING_PARTITION_VALUE_ERROR" | "UNSUPPORTED_PARTITION_CHARACTER_ERROR" | (string & {});
export type BackfillErroredPartitionsList = PartitionValueList[];
export interface BackfillError {
    Code?: BackfillErrorCode | undefined;
    Partitions?: PartitionValueList[] | undefined;
}
export type BackfillErrors = BackfillError[];
export interface PartitionIndexDescriptor {
    IndexName: string;
    Keys: KeySchemaElement[];
    IndexStatus: PartitionIndexStatus;
    BackfillErrors?: BackfillError[] | undefined;
}
export type PartitionIndexDescriptorList = PartitionIndexDescriptor[];
export interface GetPartitionIndexesResponse {
    PartitionIndexDescriptorList?: PartitionIndexDescriptor[] | undefined;
    NextToken?: string | undefined;
}
export type PredicateString = string;
export type TotalSegmentsInteger = number;
export interface Segment {
    SegmentNumber: number;
    TotalSegments: number;
}
export type BooleanNullable = boolean;
export interface GetPartitionsRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    Expression?: string | undefined;
    NextToken?: string | undefined;
    Segment?: Segment | undefined;
    MaxResults?: number | undefined;
    ExcludeColumnSchema?: boolean | undefined;
    TransactionId?: string | undefined;
    QueryAsOfTime?: Date | undefined;
    AuditContext?: AuditContext | undefined;
}
export interface GetPartitionsResponse {
    Partitions?: Partition[] | undefined;
    NextToken?: string | undefined;
}
export type AdditionalPlanOptionsMap = {
    [key: string]: string | undefined;
};
export interface GetPlanRequest {
    Mapping: MappingEntry[];
    Source: CatalogEntry;
    Sinks?: CatalogEntry[] | undefined;
    Location?: Location | undefined;
    Language?: Language | undefined;
    AdditionalPlanOptionsMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetPlanResponse {
    PythonScript?: string | undefined;
    ScalaCode?: string | undefined;
}
export interface GetRegistryInput {
    RegistryId: RegistryId;
}
export type CreatedTimestamp = string;
export type UpdatedTimestamp = string;
export interface GetRegistryResponse {
    RegistryName?: string | undefined;
    RegistryArn?: string | undefined;
    Description?: string | undefined;
    Status?: RegistryStatus | undefined;
    CreatedTime?: string | undefined;
    UpdatedTime?: string | undefined;
}
export interface GetResourcePoliciesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type PolicyJsonString = string;
export interface GluePolicy {
    PolicyInJson?: string | undefined;
    PolicyHash?: string | undefined;
    CreateTime?: Date | undefined;
    UpdateTime?: Date | undefined;
}
export type GetResourcePoliciesResponseList = GluePolicy[];
export interface GetResourcePoliciesResponse {
    GetResourcePoliciesResponseList?: GluePolicy[] | undefined;
    NextToken?: string | undefined;
}
export interface GetResourcePolicyRequest {
    ResourceArn?: string | undefined;
}
export interface GetResourcePolicyResponse {
    PolicyInJson?: string | undefined;
    PolicyHash?: string | undefined;
    CreateTime?: Date | undefined;
    UpdateTime?: Date | undefined;
}
export interface GetSchemaInput {
    SchemaId: SchemaId;
}
export interface GetSchemaResponse {
    RegistryName?: string | undefined;
    RegistryArn?: string | undefined;
    SchemaName?: string | undefined;
    SchemaArn?: string | undefined;
    Description?: string | undefined;
    DataFormat?: DataFormat | undefined;
    Compatibility?: Compatibility | undefined;
    SchemaCheckpoint?: number | undefined;
    LatestSchemaVersion?: number | undefined;
    NextSchemaVersion?: number | undefined;
    SchemaStatus?: SchemaStatus | undefined;
    CreatedTime?: string | undefined;
    UpdatedTime?: string | undefined;
}
export interface GetSchemaByDefinitionInput {
    SchemaId: SchemaId;
    SchemaDefinition: string;
}
export interface GetSchemaByDefinitionResponse {
    SchemaVersionId?: string | undefined;
    SchemaArn?: string | undefined;
    DataFormat?: DataFormat | undefined;
    Status?: SchemaVersionStatus | undefined;
    CreatedTime?: string | undefined;
}
export type LatestSchemaVersionBoolean = boolean;
export interface SchemaVersionNumber {
    LatestVersion?: boolean | undefined;
    VersionNumber?: number | undefined;
}
export interface GetSchemaVersionInput {
    SchemaId?: SchemaId | undefined;
    SchemaVersionId?: string | undefined;
    SchemaVersionNumber?: SchemaVersionNumber | undefined;
}
export interface GetSchemaVersionResponse {
    SchemaVersionId?: string | undefined;
    SchemaDefinition?: string | undefined;
    DataFormat?: DataFormat | undefined;
    SchemaArn?: string | undefined;
    VersionNumber?: number | undefined;
    Status?: SchemaVersionStatus | undefined;
    CreatedTime?: string | undefined;
}
export type SchemaDiffType = "SYNTAX_DIFF" | (string & {});
export interface GetSchemaVersionsDiffInput {
    SchemaId: SchemaId;
    FirstSchemaVersionNumber: SchemaVersionNumber;
    SecondSchemaVersionNumber: SchemaVersionNumber;
    SchemaDiffType: SchemaDiffType;
}
export type SchemaDefinitionDiff = string;
export interface GetSchemaVersionsDiffResponse {
    Diff?: string | undefined;
}
export interface GetSecurityConfigurationRequest {
    Name: string;
}
export interface SecurityConfiguration {
    Name?: string | undefined;
    CreatedTimeStamp?: Date | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface GetSecurityConfigurationResponse {
    SecurityConfiguration?: SecurityConfiguration | undefined;
}
export interface GetSecurityConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SecurityConfigurationList = SecurityConfiguration[];
export interface GetSecurityConfigurationsResponse {
    SecurityConfigurations?: SecurityConfiguration[] | undefined;
    NextToken?: string | undefined;
}
export interface GetSessionRequest {
    Id: string;
    RequestOrigin?: string | undefined;
}
export interface GetSessionResponse {
    Session?: Session | undefined;
}
export interface GetSessionEndpointRequest {
    SessionId: string;
}
export type SparkConnectEndpointUrl = string;
export type SensitiveString = string | redacted.Redacted<string>;
export interface SessionEndpoint {
    Url: string;
    AuthToken: string | redacted.Redacted<string>;
    AuthTokenExpirationTime: Date;
}
export interface GetSessionEndpointResponse {
    SparkConnect: SessionEndpoint;
}
export interface GetStatementRequest {
    SessionId: string;
    Id: number;
    RequestOrigin?: string | undefined;
}
export type StatementState = "WAITING" | "RUNNING" | "AVAILABLE" | "CANCELLING" | "CANCELLED" | "ERROR" | (string & {});
export interface StatementOutputData {
    TextPlain?: string | undefined;
}
export interface StatementOutput {
    Data?: StatementOutputData | undefined;
    ExecutionCount?: number | undefined;
    Status?: StatementState | undefined;
    ErrorName?: string | undefined;
    ErrorValue?: string | undefined;
    Traceback?: string[] | undefined;
}
export type LongValue = number;
export interface Statement {
    Id?: number | undefined;
    Code?: string | undefined;
    State?: StatementState | undefined;
    Output?: StatementOutput | undefined;
    Progress?: number | undefined;
    StartedOn?: number | undefined;
    CompletedOn?: number | undefined;
}
export interface GetStatementResponse {
    Statement?: Statement | undefined;
}
export interface GetSystemLogsForJobRunRequest {
    JobName: string;
    RunId: string;
}
export type Url = string;
export interface GetSystemLogsForJobRunResponse {
    SystemLogsUrl?: string | undefined;
}
export interface GetSystemLogsForSessionRequest {
    Id: string;
}
export interface GetSystemLogsForSessionResponse {
    SystemLogsUrl?: string | undefined;
}
export type TableAttributes = "NAME" | "TABLE_TYPE" | "DEFAULT" | "LATEST_ICEBERG_METADATA" | (string & {});
export type TableAttributesList = TableAttributes[];
export interface GetTableRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    Name: string;
    TransactionId?: string | undefined;
    QueryAsOfTime?: Date | undefined;
    AuditContext?: AuditContext | undefined;
    IncludeStatusDetails?: boolean | undefined;
    AttributesToGet?: TableAttributes[] | undefined;
}
export interface ViewRepresentation {
    Dialect?: ViewDialect | undefined;
    DialectVersion?: string | undefined;
    ViewOriginalText?: string | undefined;
    ViewExpandedText?: string | undefined;
    ValidationConnection?: string | undefined;
    IsStale?: boolean | undefined;
}
export type ViewRepresentationList = ViewRepresentation[];
export interface ViewDefinition {
    IsProtected?: boolean | undefined;
    IsManaged?: boolean | undefined;
    Definer?: string | undefined;
    ViewVersionId?: number | undefined;
    ViewVersionToken?: string | undefined;
    RefreshSeconds?: number | undefined;
    LastRefreshType?: LastRefreshType | undefined;
    SubObjects?: string[] | undefined;
    SubObjectVersionIds?: number[] | undefined;
    SubObjectsStatistics?: SubObjectStatistics[] | undefined;
    Representations?: ViewRepresentation[] | undefined;
    SparkPipelineInfo?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TableIdString = string;
export type IcebergSchemaList = IcebergSchema[];
export type IcebergPartitionSpecList = IcebergPartitionSpec[];
export type IcebergSortOrderList = IcebergSortOrder[];
export interface IcebergTableMetadata {
    FormatVersion?: string | undefined;
    TableUuid?: string | undefined;
    Location?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    Schemas?: IcebergSchema[] | undefined;
    CurrentSchemaId?: number | undefined;
    LastColumnId?: number | undefined;
    PartitionSpecs?: IcebergPartitionSpec[] | undefined;
    DefaultSpecId?: number | undefined;
    LastPartitionId?: number | undefined;
    SortOrders?: IcebergSortOrder[] | undefined;
    DefaultSortOrderId?: number | undefined;
}
export type ResourceAction = "UPDATE" | "CREATE" | (string & {});
export type ResourceState = "QUEUED" | "IN_PROGRESS" | "SUCCESS" | "STOPPED" | "FAILED" | (string & {});
export interface ViewValidation {
    Dialect?: ViewDialect | undefined;
    DialectVersion?: string | undefined;
    ViewValidationText?: string | undefined;
    UpdateTime?: Date | undefined;
    State?: ResourceState | undefined;
    Error?: ErrorDetail | undefined;
}
export type ViewValidationList = ViewValidation[];
export interface StatusDetails {
    RequestedChange?: Table | undefined;
    ViewValidations?: ViewValidation[] | undefined;
}
export interface TableStatus {
    RequestedBy?: string | undefined;
    UpdatedBy?: string | undefined;
    RequestTime?: Date | undefined;
    UpdateTime?: Date | undefined;
    Action?: ResourceAction | undefined;
    State?: ResourceState | undefined;
    Error?: ErrorDetail | undefined;
    Details?: StatusDetails | undefined;
}
export interface RLSProperties {
    DefaultRLSPolicy?: string | undefined;
}
export interface Table {
    Name: string;
    DatabaseName?: string | undefined;
    Description?: string | undefined;
    Owner?: string | undefined;
    CreateTime?: Date | undefined;
    UpdateTime?: Date | undefined;
    LastAccessTime?: Date | undefined;
    LastAnalyzedTime?: Date | undefined;
    Retention?: number | undefined;
    StorageDescriptor?: StorageDescriptor | undefined;
    PartitionKeys?: Column[] | undefined;
    ViewOriginalText?: string | undefined;
    ViewExpandedText?: string | undefined;
    TableType?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    CreatedBy?: string | undefined;
    IsRegisteredWithLakeFormation?: boolean | undefined;
    TargetTable?: TableIdentifier | undefined;
    CatalogId?: string | undefined;
    VersionId?: string | undefined;
    FederatedTable?: FederatedTable | undefined;
    ViewDefinition?: ViewDefinition | undefined;
    IsMultiDialectView?: boolean | undefined;
    IsMaterializedView?: boolean | undefined;
    IcebergTableMetadata?: IcebergTableMetadata | undefined;
    Status?: TableStatus | undefined;
    RLSProperties?: RLSProperties | undefined;
}
export interface GetTableResponse {
    Table?: Table | undefined;
}
export interface GetTableOptimizerRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
}
export interface GetTableOptimizerResponse {
    CatalogId?: string | undefined;
    DatabaseName?: string | undefined;
    TableName?: string | undefined;
    TableOptimizer?: TableOptimizer | undefined;
}
export type FilterString = string;
export type TableResourceShareType = "FEDERATED" | "ALL" | (string & {});
export interface GetTablesRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    Expression?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    TransactionId?: string | undefined;
    QueryAsOfTime?: Date | undefined;
    AuditContext?: AuditContext | undefined;
    ResourceShareType?: TableResourceShareType | undefined;
    IncludeStatusDetails?: boolean | undefined;
    AttributesToGet?: TableAttributes[] | undefined;
}
export type TableList = Table[];
export interface GetTablesResponse {
    TableList?: Table[] | undefined;
    NextToken?: string | undefined;
}
export interface GetTableVersionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    VersionId?: string | undefined;
    AuditContext?: AuditContext | undefined;
}
export interface TableVersion {
    Table?: Table | undefined;
    VersionId?: string | undefined;
}
export interface GetTableVersionResponse {
    TableVersion?: TableVersion | undefined;
}
export interface GetTableVersionsRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AuditContext?: AuditContext | undefined;
}
export type GetTableVersionsList = TableVersion[];
export interface GetTableVersionsResponse {
    TableVersions?: TableVersion[] | undefined;
    NextToken?: string | undefined;
}
export interface GetTagsRequest {
    ResourceArn: string;
}
export interface GetTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetTriggerRequest {
    Name: string;
}
export interface GetTriggerResponse {
    Trigger?: Trigger | undefined;
}
export interface GetTriggersRequest {
    NextToken?: string | undefined;
    DependentJobName?: string | undefined;
    MaxResults?: number | undefined;
}
export interface GetTriggersResponse {
    Triggers?: Trigger[] | undefined;
    NextToken?: string | undefined;
}
export type PermissionType = "COLUMN_PERMISSION" | "CELL_FILTER_PERMISSION" | "NESTED_PERMISSION" | "NESTED_CELL_PERMISSION" | (string & {});
export type PermissionTypeList = PermissionType[];
export interface GetUnfilteredPartitionMetadataRequest {
    Region?: string | undefined;
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    AuditContext?: AuditContext | undefined;
    SupportedPermissionTypes: PermissionType[];
    QuerySessionContext?: QuerySessionContext | undefined;
}
export interface GetUnfilteredPartitionMetadataResponse {
    Partition?: Partition | undefined;
    AuthorizedColumns?: string[] | undefined;
    IsRegisteredWithLakeFormation?: boolean | undefined;
}
export interface GetUnfilteredPartitionsMetadataRequest {
    Region?: string | undefined;
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Expression?: string | undefined;
    AuditContext?: AuditContext | undefined;
    SupportedPermissionTypes: PermissionType[];
    NextToken?: string | undefined;
    Segment?: Segment | undefined;
    MaxResults?: number | undefined;
    QuerySessionContext?: QuerySessionContext | undefined;
}
export interface UnfilteredPartition {
    Partition?: Partition | undefined;
    AuthorizedColumns?: string[] | undefined;
    IsRegisteredWithLakeFormation?: boolean | undefined;
}
export type UnfilteredPartitionList = UnfilteredPartition[];
export interface GetUnfilteredPartitionsMetadataResponse {
    UnfilteredPartitions?: UnfilteredPartition[] | undefined;
    NextToken?: string | undefined;
}
export interface SupportedDialect {
    Dialect?: ViewDialect | undefined;
    DialectVersion?: string | undefined;
}
export interface GetUnfilteredTableMetadataRequest {
    Region?: string | undefined;
    CatalogId: string;
    DatabaseName: string;
    Name: string;
    AuditContext?: AuditContext | undefined;
    SupportedPermissionTypes: PermissionType[];
    ParentResourceArn?: string | undefined;
    RootResourceArn?: string | undefined;
    SupportedDialect?: SupportedDialect | undefined;
    Permissions?: Permission[] | undefined;
    QuerySessionContext?: QuerySessionContext | undefined;
}
export interface ColumnRowFilter {
    ColumnName?: string | undefined;
    RowFilterExpression?: string | undefined;
}
export type ColumnRowFilterList = ColumnRowFilter[];
export interface GetUnfilteredTableMetadataResponse {
    Table?: Table | undefined;
    AuthorizedColumns?: string[] | undefined;
    IsRegisteredWithLakeFormation?: boolean | undefined;
    CellFilters?: ColumnRowFilter[] | undefined;
    QueryAuthorizationId?: string | undefined;
    IsMultiDialectView?: boolean | undefined;
    IsMaterializedView?: boolean | undefined;
    ResourceArn?: string | undefined;
    IsProtected?: boolean | undefined;
    Permissions?: Permission[] | undefined;
    RowFilter?: string | undefined;
}
export interface GetUsageProfileRequest {
    Name: string;
}
export interface GetUsageProfileResponse {
    Name?: string | undefined;
    Description?: string | undefined;
    Configuration?: ProfileConfiguration | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
}
export interface GetUserDefinedFunctionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    FunctionName: string;
}
export interface UserDefinedFunction {
    FunctionName?: string | undefined;
    DatabaseName?: string | undefined;
    ClassName?: string | undefined;
    OwnerName?: string | undefined;
    FunctionType?: FunctionType | undefined;
    OwnerType?: PrincipalType | undefined;
    CreateTime?: Date | undefined;
    ResourceUris?: ResourceUri[] | undefined;
    ArtifactLocation?: string | undefined;
    GovernanceMode?: GovernanceMode | undefined;
    CatalogId?: string | undefined;
}
export interface GetUserDefinedFunctionResponse {
    UserDefinedFunction?: UserDefinedFunction | undefined;
}
export interface GetUserDefinedFunctionsRequest {
    CatalogId?: string | undefined;
    DatabaseName?: string | undefined;
    Pattern: string;
    FunctionType?: FunctionType | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type UserDefinedFunctionList = UserDefinedFunction[];
export interface GetUserDefinedFunctionsResponse {
    UserDefinedFunctions?: UserDefinedFunction[] | undefined;
    NextToken?: string | undefined;
}
export interface GetWorkflowRequest {
    Name: string;
    IncludeGraph?: boolean | undefined;
}
export interface GetWorkflowResponse {
    Workflow?: Workflow | undefined;
}
export interface GetWorkflowRunRequest {
    Name: string;
    RunId: string;
    IncludeGraph?: boolean | undefined;
}
export interface GetWorkflowRunResponse {
    Run?: WorkflowRun | undefined;
}
export interface GetWorkflowRunPropertiesRequest {
    Name: string;
    RunId: string;
}
export interface GetWorkflowRunPropertiesResponse {
    RunProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetWorkflowRunsRequest {
    Name: string;
    IncludeGraph?: boolean | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type WorkflowRuns = WorkflowRun[];
export interface GetWorkflowRunsResponse {
    Runs?: WorkflowRun[] | undefined;
    NextToken?: string | undefined;
}
export interface ImportCatalogToGlueRequest {
    CatalogId?: string | undefined;
}
export interface ImportCatalogToGlueResponse {
}
export interface ListAssetTypesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AssetTypeItem {
    Id?: string | undefined;
    Name?: string | undefined;
}
export type AssetTypeItemList = AssetTypeItem[];
export interface ListAssetTypesResponse {
    Items?: AssetTypeItem[] | undefined;
    NextToken?: string | undefined;
}
export type OrchestrationPageSize25 = number;
export interface ListBlueprintsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListBlueprintsResponse {
    Blueprints?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListColumnStatisticsTaskRunsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ColumnStatisticsTaskRunIdList = string[];
export interface ListColumnStatisticsTaskRunsResponse {
    ColumnStatisticsTaskRunIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResults = number;
export interface ListConnectionTypesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DisplayName = string;
export type Vendor = string;
export type UrlString = string;
export interface ConnectionTypeVariant {
    ConnectionTypeVariantName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    LogoUrl?: string | undefined;
}
export type ConnectionTypeVariantList = ConnectionTypeVariant[];
export interface ConnectionTypeBrief {
    ConnectionType?: ConnectionType | undefined;
    DisplayName?: string | undefined;
    Vendor?: string | undefined;
    Description?: string | undefined;
    Categories?: string[] | undefined;
    Capabilities?: Capabilities | undefined;
    LogoUrl?: string | undefined;
    ConnectionTypeVariants?: ConnectionTypeVariant[] | undefined;
}
export type ConnectionTypeList = ConnectionTypeBrief[];
export interface ListConnectionTypesResponse {
    ConnectionTypes?: ConnectionTypeBrief[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCrawlersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListCrawlersResponse {
    CrawlerNames?: string[] | undefined;
    NextToken?: string | undefined;
}
export type FieldName = "CRAWL_ID" | "STATE" | "START_TIME" | "END_TIME" | "DPU_HOUR" | (string & {});
export type FilterOperator = "GT" | "GE" | "LT" | "LE" | "EQ" | "NE" | (string & {});
export interface CrawlsFilter {
    FieldName?: FieldName | undefined;
    FilterOperator?: FilterOperator | undefined;
    FieldValue?: string | undefined;
}
export type CrawlsFilterList = CrawlsFilter[];
export interface ListCrawlsRequest {
    CrawlerName: string;
    MaxResults?: number | undefined;
    Filters?: CrawlsFilter[] | undefined;
    NextToken?: string | undefined;
}
export type CrawlId = string;
export type CrawlerHistoryState = "RUNNING" | "COMPLETED" | "FAILED" | "STOPPED" | (string & {});
export interface CrawlerHistory {
    CrawlId?: string | undefined;
    State?: CrawlerHistoryState | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Summary?: string | undefined;
    ErrorMessage?: string | undefined;
    LogGroup?: string | undefined;
    LogStream?: string | undefined;
    MessagePrefix?: string | undefined;
    DPUHour?: number | undefined;
}
export type CrawlerHistoryList = CrawlerHistory[];
export interface ListCrawlsResponse {
    Crawls?: CrawlerHistory[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCustomEntityTypesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListCustomEntityTypesResponse {
    CustomEntityTypes?: CustomEntityType[] | undefined;
    NextToken?: string | undefined;
}
export type DataQualityEvaluationConfigPageSize = number;
export interface ListDataQualityEvaluationConfigsRequest {
    Level?: DataQualityEvaluationConfigLevel | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DataQualityEvaluationConfigListGlueTables {
    CatalogId: string;
    DatabaseName?: string | undefined;
    TableNamePattern?: string | undefined;
}
export interface DataQualityEvaluationConfigListDataSource {
    GlueTables?: DataQualityEvaluationConfigListGlueTables | undefined;
}
export interface DataQualityEvaluationConfigListDetails {
    Name?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    Level?: DataQualityEvaluationConfigLevel | undefined;
    DataSource?: DataQualityEvaluationConfigListDataSource | undefined;
    RulesetName?: string | undefined;
    ManagedRulesetName?: DataQualityEvaluationConfigManagedRuleset | undefined;
    PauseRuns?: boolean | undefined;
}
export type DataQualityEvaluationConfigList = DataQualityEvaluationConfigListDetails[];
export interface ListDataQualityEvaluationConfigsResponse {
    DataQualityEvaluationConfigs?: DataQualityEvaluationConfigListDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface DataQualityResultFilterCriteria {
    DataSource?: DataSource | undefined;
    JobName?: string | undefined;
    JobRunId?: string | undefined;
    StartedAfter?: Date | undefined;
    StartedBefore?: Date | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    DataQualityEvaluationConfig?: string | undefined;
}
export interface ListDataQualityResultsRequest {
    Filter?: DataQualityResultFilterCriteria | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DataQualityResultDescription {
    ResultId?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    DataQualityEvaluationConfig?: string | undefined;
    DataSource?: DataSource | undefined;
    JobName?: string | undefined;
    JobRunId?: string | undefined;
    StartedOn?: Date | undefined;
}
export type DataQualityResultDescriptionList = DataQualityResultDescription[];
export interface ListDataQualityResultsResponse {
    Results: DataQualityResultDescription[];
    NextToken?: string | undefined;
}
export interface DataQualityResultsV2FilterCriteria {
    DataSource?: DataSource | undefined;
    PublishedAfter?: Date | undefined;
    PublishedBefore?: Date | undefined;
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
    EvaluationContext?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    DataQualityEvaluationConfig?: string | undefined;
}
export interface ListDataQualityResultsV2Request {
    Filter?: DataQualityResultsV2FilterCriteria | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DataQualityResultsV2Description {
    ResultId?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    DataQualityEvaluationConfig?: string | undefined;
    DataSource?: DataSource | undefined;
    ResultPublishedOn?: Date | undefined;
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
    EvaluationContext?: string | undefined;
    Descriptors?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DataQualityResultsV2DescriptionList = DataQualityResultsV2Description[];
export interface ListDataQualityResultsV2Response {
    Results: DataQualityResultsV2Description[];
    NextToken?: string | undefined;
}
export interface DataQualityRuleRecommendationRunFilter {
    DataSource: DataSource;
    StartedBefore?: Date | undefined;
    StartedAfter?: Date | undefined;
}
export interface ListDataQualityRuleRecommendationRunsRequest {
    Filter?: DataQualityRuleRecommendationRunFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DataQualityRuleRecommendationRunDescription {
    RunId?: string | undefined;
    Status?: TaskStatusType | undefined;
    StartedOn?: Date | undefined;
    DataSource?: DataSource | undefined;
    CreatedRulesetName?: string | undefined;
    RecommendationMode?: RecommendationMode | undefined;
}
export type DataQualityRuleRecommendationRunList = DataQualityRuleRecommendationRunDescription[];
export interface ListDataQualityRuleRecommendationRunsResponse {
    Runs?: DataQualityRuleRecommendationRunDescription[] | undefined;
    NextToken?: string | undefined;
}
export interface DataQualityRulesetEvaluationRunFilter {
    DataSource: DataSource;
    StartedBefore?: Date | undefined;
    StartedAfter?: Date | undefined;
    RulesetName?: string | undefined;
}
export interface ListDataQualityRulesetEvaluationRunsRequest {
    Filter?: DataQualityRulesetEvaluationRunFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DataQualityRulesetEvaluationRunDescription {
    RunId?: string | undefined;
    Status?: TaskStatusType | undefined;
    StartedOn?: Date | undefined;
    DataSource?: DataSource | undefined;
}
export type DataQualityRulesetEvaluationRunList = DataQualityRulesetEvaluationRunDescription[];
export interface ListDataQualityRulesetEvaluationRunsResponse {
    Runs?: DataQualityRulesetEvaluationRunDescription[] | undefined;
    NextToken?: string | undefined;
}
export interface DataQualityRulesetFilterCriteria {
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedBefore?: Date | undefined;
    CreatedAfter?: Date | undefined;
    LastModifiedBefore?: Date | undefined;
    LastModifiedAfter?: Date | undefined;
    TargetTable?: DataQualityTargetTable | undefined;
}
export interface ListDataQualityRulesetsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filter?: DataQualityRulesetFilterCriteria | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DataQualityRulesetListDetails {
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    TargetTable?: DataQualityTargetTable | undefined;
    RecommendationRunId?: string | undefined;
    RuleCount?: number | undefined;
}
export type DataQualityRulesetList = DataQualityRulesetListDetails[];
export interface ListDataQualityRulesetsResponse {
    Rulesets?: DataQualityRulesetListDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface TimestampFilter {
    RecordedBefore?: Date | undefined;
    RecordedAfter?: Date | undefined;
}
export interface ListDataQualityStatisticAnnotationsRequest {
    StatisticId?: string | undefined;
    ProfileId?: string | undefined;
    TimestampFilter?: TimestampFilter | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface TimestampedInclusionAnnotation {
    Value?: InclusionAnnotationValue | undefined;
    LastModifiedOn?: Date | undefined;
}
export interface StatisticAnnotation {
    ProfileId?: string | undefined;
    StatisticId?: string | undefined;
    StatisticRecordedOn?: Date | undefined;
    InclusionAnnotation?: TimestampedInclusionAnnotation | undefined;
}
export type AnnotationList = StatisticAnnotation[];
export interface ListDataQualityStatisticAnnotationsResponse {
    Annotations?: StatisticAnnotation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDataQualityStatisticsRequest {
    StatisticId?: string | undefined;
    ProfileId?: string | undefined;
    TimestampFilter?: TimestampFilter | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RunIdentifier {
    RunId?: string | undefined;
    JobRunId?: string | undefined;
}
export type StatisticNameString = string;
export type StatisticEvaluationLevel = "Dataset" | "Column" | "Multicolumn" | (string & {});
export type ReferenceDatasetsList = string[];
export type StatisticPropertiesMap = {
    [key: string]: string | undefined;
};
export interface StatisticSummary {
    StatisticId?: string | undefined;
    ProfileId?: string | undefined;
    RunIdentifier?: RunIdentifier | undefined;
    StatisticName?: string | undefined;
    DoubleValue?: number | undefined;
    DistributionValue?: DistributionData | undefined;
    EvaluationLevel?: StatisticEvaluationLevel | undefined;
    ColumnsReferenced?: string[] | undefined;
    ReferencedDatasets?: string[] | undefined;
    StatisticProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    RecordedOn?: Date | undefined;
    InclusionAnnotation?: TimestampedInclusionAnnotation | undefined;
}
export type StatisticSummaryList = StatisticSummary[];
export interface ListDataQualityStatisticsResponse {
    Statistics?: StatisticSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDevEndpointsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DevEndpointNameList = string[];
export interface ListDevEndpointsResponse {
    DevEndpointNames?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEntitiesRequest {
    ConnectionName?: string | undefined;
    CatalogId?: string | undefined;
    ParentEntityName?: string | undefined;
    NextToken?: string | undefined;
    DataStoreApiVersion?: string | undefined;
}
export type EntityLabel = string;
export type IsParentEntity = boolean;
export type EntityDescription = string;
export type Category = string;
export interface Entity {
    EntityName?: string | undefined;
    Label?: string | undefined;
    IsParentEntity?: boolean | undefined;
    Description?: string | undefined;
    Category?: string | undefined;
    CustomProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EntityList = Entity[];
export interface ListEntitiesResponse {
    Entities?: Entity[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFormTypesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface FormTypeItem {
    Id?: string | undefined;
    Name?: string | undefined;
}
export type FormTypeItemList = FormTypeItem[];
export interface ListFormTypesResponse {
    Items: FormTypeItem[];
    NextToken?: string | undefined;
}
export interface ListGlossariesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface GlossaryItem {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
}
export type GlossaryItemList = GlossaryItem[];
export interface ListGlossariesResponse {
    Items?: GlossaryItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGlossaryTermsRequest {
    GlossaryIdentifier: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface GlossaryTermItem {
    Id?: string | undefined;
    Name?: string | undefined;
    ShortDescription?: string | undefined;
}
export type GlossaryTermItemList = GlossaryTermItem[];
export interface ListGlossaryTermsResponse {
    Items?: GlossaryTermItem[] | undefined;
    NextToken?: string | undefined;
}
export type String4096 = string;
export type IntegrationResourcePropertyFilterValues = string[];
export interface IntegrationResourcePropertyFilter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type IntegrationResourcePropertyFilterList = IntegrationResourcePropertyFilter[];
export interface ListIntegrationResourcePropertiesRequest {
    Marker?: string | undefined;
    Filters?: IntegrationResourcePropertyFilter[] | undefined;
    MaxRecords?: number | undefined;
}
export interface IntegrationResourceProperty {
    ResourceArn: string;
    ResourcePropertyArn?: string | undefined;
    SourceProcessingProperties?: SourceProcessingProperties | undefined;
    TargetProcessingProperties?: TargetProcessingProperties | undefined;
}
export type IntegrationResourcePropertyList = IntegrationResourceProperty[];
export interface ListIntegrationResourcePropertiesResponse {
    IntegrationResourcePropertyList?: IntegrationResourceProperty[] | undefined;
    Marker?: string | undefined;
}
export type IntegrationTablePropertiesFilterValues = string[];
export interface IntegrationTablePropertiesFilter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type IntegrationTablePropertiesFilterList = IntegrationTablePropertiesFilter[];
export interface ListIntegrationTablePropertiesRequest {
    Marker?: string | undefined;
    Filters?: IntegrationTablePropertiesFilter[] | undefined;
    MaxRecords?: number | undefined;
}
export interface IntegrationTableProperties {
    ResourceArn: string;
    TableName: string;
    SourceTableConfig?: SourceTableConfig | undefined;
    TargetTableConfig?: TargetTableConfig | undefined;
}
export type IntegrationTablePropertiesList = IntegrationTableProperties[];
export interface ListIntegrationTablePropertiesResponse {
    IntegrationTablePropertiesList?: IntegrationTableProperties[] | undefined;
    Marker?: string | undefined;
}
export interface ListIterableFormsRequest {
    AssetIdentifier: string;
    IterableFormName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ItemDescription = string;
export interface IterableFormListItem {
    ItemId?: string | undefined;
    ItemName?: string | undefined;
    Description?: string | undefined;
    GlossaryTerms?: string[] | undefined;
}
export type IterableFormListItemList = IterableFormListItem[];
export interface ListIterableFormsResponse {
    Items?: IterableFormListItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListJobsResponse {
    JobNames?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMaterializedViewRefreshTaskRunsRequest {
    CatalogId: string;
    DatabaseName?: string | undefined;
    TableName?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type MaterializedViewRefreshTaskRunsList = MaterializedViewRefreshTaskRun[];
export interface ListMaterializedViewRefreshTaskRunsResponse {
    MaterializedViewRefreshTaskRuns?: MaterializedViewRefreshTaskRun[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMLTransformsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filter?: TransformFilterCriteria | undefined;
    Sort?: TransformSortCriteria | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TransformIdList = string[];
export interface ListMLTransformsResponse {
    TransformIds: string[];
    NextToken?: string | undefined;
}
export type MaxResultsNumber = number;
export type SchemaRegistryTokenString = string;
export interface ListRegistriesInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RegistryListItem {
    RegistryName?: string | undefined;
    RegistryArn?: string | undefined;
    Description?: string | undefined;
    Status?: RegistryStatus | undefined;
    CreatedTime?: string | undefined;
    UpdatedTime?: string | undefined;
}
export type RegistryListDefinition = RegistryListItem[];
export interface ListRegistriesResponse {
    Registries?: RegistryListItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSchemasInput {
    RegistryId?: RegistryId | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SchemaListItem {
    RegistryName?: string | undefined;
    SchemaName?: string | undefined;
    SchemaArn?: string | undefined;
    Description?: string | undefined;
    SchemaStatus?: SchemaStatus | undefined;
    CreatedTime?: string | undefined;
    UpdatedTime?: string | undefined;
}
export type SchemaListDefinition = SchemaListItem[];
export interface ListSchemasResponse {
    Schemas?: SchemaListItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSchemaVersionsInput {
    SchemaId: SchemaId;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SchemaVersionListItem {
    SchemaArn?: string | undefined;
    SchemaVersionId?: string | undefined;
    VersionNumber?: number | undefined;
    Status?: SchemaVersionStatus | undefined;
    CreatedTime?: string | undefined;
}
export type SchemaVersionList = SchemaVersionListItem[];
export interface ListSchemaVersionsResponse {
    Schemas?: SchemaVersionListItem[] | undefined;
    NextToken?: string | undefined;
}
export type OrchestrationToken = string;
export interface ListSessionsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestOrigin?: string | undefined;
}
export type SessionIdList = string[];
export type SessionList = Session[];
export interface ListSessionsResponse {
    Ids?: string[] | undefined;
    Sessions?: Session[] | undefined;
    NextToken?: string | undefined;
}
export interface ListStatementsRequest {
    SessionId: string;
    RequestOrigin?: string | undefined;
    NextToken?: string | undefined;
}
export type StatementList = Statement[];
export interface ListStatementsResponse {
    Statements?: Statement[] | undefined;
    NextToken?: string | undefined;
}
export type MaxListTableOptimizerRunsTokenResults = number;
export type ListTableOptimizerRunsToken = string;
export interface ListTableOptimizerRunsRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type TableOptimizerRuns = TableOptimizerRun[];
export interface ListTableOptimizerRunsResponse {
    CatalogId?: string | undefined;
    DatabaseName?: string | undefined;
    TableName?: string | undefined;
    NextToken?: string | undefined;
    TableOptimizerRuns?: TableOptimizerRun[] | undefined;
}
export interface ListTriggersRequest {
    NextToken?: string | undefined;
    DependentJobName?: string | undefined;
    MaxResults?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTriggersResponse {
    TriggerNames?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListUsageProfilesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface UsageProfileDefinition {
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
}
export type UsageProfileDefinitionList = UsageProfileDefinition[];
export interface ListUsageProfilesResponse {
    Profiles?: UsageProfileDefinition[] | undefined;
    NextToken?: string | undefined;
}
export interface ListWorkflowsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListWorkflowsResponse {
    Workflows?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ModifyIntegrationRequest {
    IntegrationIdentifier: string;
    Description?: string | undefined;
    DataFilter?: string | undefined;
    IntegrationConfig?: IntegrationConfig | undefined;
    IntegrationName?: string | undefined;
}
export interface ModifyIntegrationResponse {
    SourceArn: string;
    TargetArn: string;
    IntegrationName: string;
    Description?: string | undefined;
    IntegrationArn: string;
    KmsKeyId?: string | undefined;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
    Status: IntegrationStatus;
    CreateTime: Date;
    Errors?: IntegrationError[] | undefined;
    DataFilter?: string | undefined;
    IntegrationConfig?: IntegrationConfig | undefined;
}
export interface DataQualityConfigurationV2 {
    ObservationsEnabled?: ObservationConfiguration | undefined;
    ObservationMode?: ObservationMode | undefined;
}
export type DataQualityFlagsEnabled = {
    [key: string]: string | undefined;
};
export type DataQualityEngine = "SPARK" | "PYTHON" | (string & {});
export interface DataQualityTelemetry {
    VcpuHours?: number | undefined;
    FlagsEnabled?: {
        [key: string]: string | undefined;
    } | undefined;
    LibraryVersion?: string | undefined;
    SparkVersion?: string | undefined;
    HostRuntimeVersion?: string | undefined;
    Engine?: DataQualityEngine | undefined;
}
export interface PublishDataQualityResultV2Request {
    Dimensions: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ExecutionStartedOn?: Date | undefined;
    ExecutionCompletedOn?: Date | undefined;
    Score: number;
    RuleResults: DataQualityRuleResult[];
    AnalyzerResults?: DataQualityAnalyzerResult[] | undefined;
    Observations?: DataQualityObservation[] | undefined;
    AggregatedMetrics?: DataQualityAggregatedMetrics | undefined;
    Statistics?: StatisticSummary[] | undefined;
    RunConfiguration?: DataQualityConfigurationV2 | undefined;
    ClientToken?: string | undefined;
    EvaluationContext: string;
    Descriptors?: {
        [key: string]: string | undefined;
    } | undefined;
    RulesetName?: string | undefined;
    DataQualitySecurityConfiguration?: string | undefined;
    Telemetry?: DataQualityTelemetry | undefined;
}
export interface PublishDataQualityResultV2Response {
    ResultId: string;
}
export interface PutAssetRequest {
    AssetTypeId: string;
    Identifier: string;
    Name: string;
    Description?: string | undefined;
    Forms: {
        [key: string]: AssetFormEntry | undefined;
    };
    ClientToken?: string | undefined;
}
export interface PutAssetResponse {
    Id: string;
    Name: string;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    Forms?: {
        [key: string]: AssetFormEntry | undefined;
    } | undefined;
}
export interface PutAssetTypeRequest {
    Name: string;
    Forms: {
        [key: string]: AssetTypeFormReference | undefined;
    };
    ClientToken?: string | undefined;
}
export interface PutAssetTypeResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Forms?: {
        [key: string]: AssetTypeFormReference | undefined;
    } | undefined;
}
export interface PutAttachmentRequest {
    AssetIdentifier: string;
    IterableFormName?: string | undefined;
    ItemIdentifier?: string | undefined;
    AttachmentName: string;
    Content: string;
    FormTypeId: string;
    ClientToken?: string | undefined;
}
export interface PutAttachmentResponse {
    AssetIdentifier?: string | undefined;
    IterableFormName?: string | undefined;
    ItemIdentifier?: string | undefined;
    AttachmentName?: string | undefined;
    FormTypeId?: string | undefined;
}
export interface PutDataCatalogEncryptionSettingsRequest {
    CatalogId?: string | undefined;
    DataCatalogEncryptionSettings: DataCatalogEncryptionSettings;
}
export interface PutDataCatalogEncryptionSettingsResponse {
}
export interface PutDataCatalogExportConfigurationInput {
    ExportSetting: ExportSetting;
    EncryptionConfiguration?: ExportEncryptionConfiguration | undefined;
    ClientToken?: string | undefined;
}
export interface PutDataCatalogExportConfigurationOutput {
    ExportSetting?: ExportSetting | undefined;
    EncryptionConfiguration?: ExportEncryptionConfiguration | undefined;
}
export interface PutDataQualityProfileAnnotationRequest {
    ProfileId: string;
    InclusionAnnotation: InclusionAnnotationValue;
}
export interface PutDataQualityProfileAnnotationResponse {
}
export interface PutFormTypeRequest {
    Name: string;
    Schema: string;
    ClientToken?: string | undefined;
}
export interface PutFormTypeResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Schema?: string | undefined;
}
export type ExistCondition = "MUST_EXIST" | "NOT_EXIST" | "NONE" | (string & {});
export type EnableHybridValues = "TRUE" | "FALSE" | (string & {});
export interface PutResourcePolicyRequest {
    PolicyInJson: string;
    ResourceArn?: string | undefined;
    PolicyHashCondition?: string | undefined;
    PolicyExistsCondition?: ExistCondition | undefined;
    EnableHybrid?: EnableHybridValues | undefined;
}
export interface PutResourcePolicyResponse {
    PolicyHash?: string | undefined;
}
export type MetadataKeyString = string;
export type MetadataValueString = string;
export interface MetadataKeyValuePair {
    MetadataKey?: string | undefined;
    MetadataValue?: string | undefined;
}
export interface PutSchemaVersionMetadataInput {
    SchemaId?: SchemaId | undefined;
    SchemaVersionNumber?: SchemaVersionNumber | undefined;
    SchemaVersionId?: string | undefined;
    MetadataKeyValue: MetadataKeyValuePair;
}
export interface PutSchemaVersionMetadataResponse {
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    RegistryName?: string | undefined;
    LatestVersion?: boolean | undefined;
    VersionNumber?: number | undefined;
    SchemaVersionId?: string | undefined;
    MetadataKey?: string | undefined;
    MetadataValue?: string | undefined;
}
export interface PutWorkflowRunPropertiesRequest {
    Name: string;
    RunId: string;
    RunProperties: {
        [key: string]: string | undefined;
    };
}
export interface PutWorkflowRunPropertiesResponse {
}
export type MetadataList = MetadataKeyValuePair[];
export type QuerySchemaVersionMetadataMaxResults = number;
export interface QuerySchemaVersionMetadataInput {
    SchemaId?: SchemaId | undefined;
    SchemaVersionNumber?: SchemaVersionNumber | undefined;
    SchemaVersionId?: string | undefined;
    MetadataList?: MetadataKeyValuePair[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface OtherMetadataValueListItem {
    MetadataValue?: string | undefined;
    CreatedTime?: string | undefined;
}
export type OtherMetadataValueList = OtherMetadataValueListItem[];
export interface MetadataInfo {
    MetadataValue?: string | undefined;
    CreatedTime?: string | undefined;
    OtherMetadataValueList?: OtherMetadataValueListItem[] | undefined;
}
export type MetadataInfoMap = {
    [key: string]: MetadataInfo | undefined;
};
export interface QuerySchemaVersionMetadataResponse {
    MetadataInfoMap?: {
        [key: string]: MetadataInfo | undefined;
    } | undefined;
    SchemaVersionId?: string | undefined;
    NextToken?: string | undefined;
}
export type IntegrationType = "REST" | (string & {});
export interface ConnectionPropertiesConfiguration {
    Url?: ConnectorProperty | undefined;
    AdditionalRequestParameters?: ConnectorProperty[] | undefined;
}
export type ConnectorOAuth2GrantType = "CLIENT_CREDENTIALS" | "JWT_BEARER" | "AUTHORIZATION_CODE" | (string & {});
export type ContentType = "APPLICATION_JSON" | "URL_ENCODED" | (string & {});
export interface ClientCredentialsProperties {
    TokenUrl?: ConnectorProperty | undefined;
    RequestMethod?: HTTPMethod | undefined;
    ContentType?: ContentType | undefined;
    ClientId?: ConnectorProperty | undefined;
    ClientSecret?: ConnectorProperty | undefined;
    Scope?: ConnectorProperty | undefined;
    TokenUrlParameters?: ConnectorProperty[] | undefined;
}
export interface JWTBearerProperties {
    TokenUrl?: ConnectorProperty | undefined;
    RequestMethod?: HTTPMethod | undefined;
    ContentType?: ContentType | undefined;
    JwtToken?: ConnectorProperty | undefined;
    TokenUrlParameters?: ConnectorProperty[] | undefined;
}
export interface ConnectorAuthorizationCodeProperties {
    AuthorizationCodeUrl?: ConnectorProperty | undefined;
    AuthorizationCode?: ConnectorProperty | undefined;
    RedirectUri?: ConnectorProperty | undefined;
    TokenUrl?: ConnectorProperty | undefined;
    RequestMethod?: HTTPMethod | undefined;
    ContentType?: ContentType | undefined;
    ClientId?: ConnectorProperty | undefined;
    ClientSecret?: ConnectorProperty | undefined;
    Scope?: ConnectorProperty | undefined;
    Prompt?: ConnectorProperty | undefined;
    TokenUrlParameters?: ConnectorProperty[] | undefined;
}
export interface ConnectorOAuth2Properties {
    OAuth2GrantType: ConnectorOAuth2GrantType;
    ClientCredentialsProperties?: ClientCredentialsProperties | undefined;
    JWTBearerProperties?: JWTBearerProperties | undefined;
    AuthorizationCodeProperties?: ConnectorAuthorizationCodeProperties | undefined;
}
export interface BasicAuthenticationProperties {
    Username?: ConnectorProperty | undefined;
    Password?: ConnectorProperty | undefined;
}
export interface CustomAuthenticationProperties {
    AuthenticationParameters: ConnectorProperty[];
}
export interface ConnectorAuthenticationConfiguration {
    AuthenticationTypes: AuthenticationType[];
    OAuth2Properties?: ConnectorOAuth2Properties | undefined;
    BasicAuthenticationProperties?: BasicAuthenticationProperties | undefined;
    CustomAuthenticationProperties?: CustomAuthenticationProperties | undefined;
}
export interface RegisterConnectionTypeRequest {
    ConnectionType: string;
    IntegrationType: IntegrationType;
    Description?: string | undefined;
    ConnectionProperties: ConnectionPropertiesConfiguration;
    ConnectorAuthenticationConfiguration: ConnectorAuthenticationConfiguration;
    RestConfiguration: RestConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RegisterConnectionTypeResponse {
    ConnectionTypeArn?: string | undefined;
}
export interface RegisterSchemaVersionInput {
    SchemaId: SchemaId;
    SchemaDefinition: string;
}
export interface RegisterSchemaVersionResponse {
    SchemaVersionId?: string | undefined;
    VersionNumber?: number | undefined;
    Status?: SchemaVersionStatus | undefined;
}
export interface RemoveSchemaVersionMetadataInput {
    SchemaId?: SchemaId | undefined;
    SchemaVersionNumber?: SchemaVersionNumber | undefined;
    SchemaVersionId?: string | undefined;
    MetadataKeyValue: MetadataKeyValuePair;
}
export interface RemoveSchemaVersionMetadataResponse {
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    RegistryName?: string | undefined;
    LatestVersion?: boolean | undefined;
    VersionNumber?: number | undefined;
    SchemaVersionId?: string | undefined;
    MetadataKey?: string | undefined;
    MetadataValue?: string | undefined;
}
export interface ResetJobBookmarkRequest {
    JobName: string;
    RunId?: string | undefined;
}
export interface ResetJobBookmarkResponse {
    JobBookmarkEntry?: JobBookmarkEntry | undefined;
}
export type NodeIdList = string[];
export interface ResumeWorkflowRunRequest {
    Name: string;
    RunId: string;
    NodeIds: string[];
}
export interface ResumeWorkflowRunResponse {
    RunId?: string | undefined;
    NodeIds?: string[] | undefined;
}
export type OrchestrationStatementCodeString = string;
export interface RunStatementRequest {
    SessionId: string;
    Code: string;
    RequestOrigin?: string | undefined;
}
export interface RunStatementResponse {
    Id?: number | undefined;
}
export type SearchText = string;
export type SearchMaxResults = number;
export type SearchNextToken = string;
export type SearchAttribute = string;
export type SearchSortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface SearchSort {
    Attribute: string;
    Order?: SearchSortOrder | undefined;
}
export type SearchFilterClauseList = SearchFilterClause[];
export type SearchFilterOperator = "equals" | "greaterThan" | "greaterThanOrEquals" | "lessThan" | "lessThanOrEquals" | "notExists" | (string & {});
export type SearchFilterStringValue = string;
export type SearchFilterLongValue = number;
export type SearchFilterValue = {
    StringValue: string;
    LongValue?: undefined;
} | {
    StringValue?: undefined;
    LongValue: number;
};
export interface SearchAttributeFilter {
    Attribute: string;
    Operator: SearchFilterOperator;
    Value?: SearchFilterValue | undefined;
}
export type SearchMapKey = string;
export type SearchMapFilterValue = {
    StringValue: string;
};
export interface SearchMapFilter {
    Attribute: string;
    Key: string;
    Value: SearchMapFilterValue;
}
export type SearchFilterClause = {
    AndAllFilters: SearchFilterClause[];
    OrAnyFilters?: undefined;
    AttributeFilter?: undefined;
    MapFilter?: undefined;
} | {
    AndAllFilters?: undefined;
    OrAnyFilters: SearchFilterClause[];
    AttributeFilter?: undefined;
    MapFilter?: undefined;
} | {
    AndAllFilters?: undefined;
    OrAnyFilters?: undefined;
    AttributeFilter: SearchAttributeFilter;
    MapFilter?: undefined;
} | {
    AndAllFilters?: undefined;
    OrAnyFilters?: undefined;
    AttributeFilter?: undefined;
    MapFilter: SearchMapFilter;
};
export interface SearchAssetsInput {
    SearchText?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Sort?: SearchSort | undefined;
    FilterClause?: SearchFilterClause | undefined;
}
export type SearchResultName = string;
export interface SearchResultItem {
    Id?: string | undefined;
    AssetName?: string | undefined;
    AssetDescription?: string | undefined;
    UpdatedAt?: Date | undefined;
    AssetTypeId?: string | undefined;
}
export type SearchResultItemList = SearchResultItem[];
export interface SearchAssetsOutput {
    Items?: SearchResultItem[] | undefined;
    NextToken?: string | undefined;
}
export type Comparator = "EQUALS" | "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_EQUALS" | "LESS_THAN_EQUALS" | (string & {});
export interface PropertyPredicate {
    Key?: string | undefined;
    Value?: string | undefined;
    Comparator?: Comparator | undefined;
}
export type SearchPropertyPredicates = PropertyPredicate[];
export type Sort = "ASC" | "DESC" | (string & {});
export interface SortCriterion {
    FieldName?: string | undefined;
    Sort?: Sort | undefined;
}
export type SortCriteria = SortCriterion[];
export interface SearchTablesRequest {
    CatalogId?: string | undefined;
    NextToken?: string | undefined;
    Filters?: PropertyPredicate[] | undefined;
    SearchText?: string | undefined;
    SortCriteria?: SortCriterion[] | undefined;
    MaxResults?: number | undefined;
    ResourceShareType?: ResourceShareType | undefined;
    IncludeStatusDetails?: boolean | undefined;
}
export interface SearchTablesResponse {
    NextToken?: string | undefined;
    TableList?: Table[] | undefined;
}
export interface StartBlueprintRunRequest {
    BlueprintName: string;
    Parameters?: string | undefined;
    RoleArn: string;
}
export interface StartBlueprintRunResponse {
    RunId?: string | undefined;
}
export interface StartColumnStatisticsTaskRunRequest {
    DatabaseName: string;
    TableName: string;
    ColumnNameList?: string[] | undefined;
    Role: string;
    SampleSize?: number | undefined;
    CatalogID?: string | undefined;
    SecurityConfiguration?: string | undefined;
}
export interface StartColumnStatisticsTaskRunResponse {
    ColumnStatisticsTaskRunId?: string | undefined;
}
export interface StartColumnStatisticsTaskRunScheduleRequest {
    DatabaseName: string;
    TableName: string;
    CatalogID?: string | undefined;
}
export interface StartColumnStatisticsTaskRunScheduleResponse {
}
export interface StartCrawlerRequest {
    Name: string;
}
export interface StartCrawlerResponse {
}
export interface StartCrawlerScheduleRequest {
    CrawlerName: string;
}
export interface StartCrawlerScheduleResponse {
}
export interface StartDataQualityRuleRecommendationRunRequest {
    DataSource: DataSource;
    Role: string;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    CreatedRulesetName?: string | undefined;
    DataQualitySecurityConfiguration?: string | undefined;
    ClientToken?: string | undefined;
    AdditionalRunOptions?: DataQualityRuleRecommendationRunAdditionalRunOptions | undefined;
    RecommendationMode?: RecommendationMode | undefined;
}
export interface StartDataQualityRuleRecommendationRunResponse {
    RunId?: string | undefined;
}
export interface StartDataQualityRulesetEvaluationRunRequest {
    DataSource: DataSource;
    Role: string;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    ClientToken?: string | undefined;
    AdditionalRunOptions?: DataQualityEvaluationRunAdditionalRunOptions | undefined;
    RulesetNames: string[];
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    } | undefined;
}
export interface StartDataQualityRulesetEvaluationRunResponse {
    RunId?: string | undefined;
}
export interface StartExportLabelsTaskRunRequest {
    TransformId: string;
    OutputS3Path: string;
}
export interface StartExportLabelsTaskRunResponse {
    TaskRunId?: string | undefined;
}
export interface StartImportLabelsTaskRunRequest {
    TransformId: string;
    InputS3Path: string;
    ReplaceAllLabels?: boolean | undefined;
}
export interface StartImportLabelsTaskRunResponse {
    TaskRunId?: string | undefined;
}
export interface StartJobRunRequest {
    JobName: string;
    JobRunQueuingEnabled?: boolean | undefined;
    JobRunId?: string | undefined;
    Arguments?: {
        [key: string]: string | undefined;
    } | undefined;
    AllocatedCapacity?: number | undefined;
    Timeout?: number | undefined;
    MaxCapacity?: number | undefined;
    SecurityConfiguration?: string | undefined;
    NotificationProperty?: NotificationProperty | undefined;
    WorkerType?: WorkerType | undefined;
    NumberOfWorkers?: number | undefined;
    ExecutionClass?: ExecutionClass | undefined;
    ExecutionRoleSessionPolicy?: string | undefined;
}
export interface StartJobRunResponse {
    JobRunId?: string | undefined;
}
export type UpgradeConsent = "APPROVE" | "DECLINE" | (string & {});
export interface StartJobUpgradeAnalysisRequest {
    jobName: string;
    analysisId?: string | undefined;
    upgradeConsent?: UpgradeConsent | undefined;
}
export interface StartJobUpgradeAnalysisResponse {
    analysisId?: string | undefined;
    jobName?: string | undefined;
}
export interface StartMaterializedViewRefreshTaskRunRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    FullRefresh?: boolean | undefined;
}
export interface StartMaterializedViewRefreshTaskRunResponse {
    MaterializedViewRefreshTaskRunId?: string | undefined;
}
export interface StartMLEvaluationTaskRunRequest {
    TransformId: string;
}
export interface StartMLEvaluationTaskRunResponse {
    TaskRunId?: string | undefined;
}
export interface StartMLLabelingSetGenerationTaskRunRequest {
    TransformId: string;
    OutputS3Path: string;
}
export interface StartMLLabelingSetGenerationTaskRunResponse {
    TaskRunId?: string | undefined;
}
export interface StartTriggerRequest {
    Name: string;
}
export interface StartTriggerResponse {
    Name?: string | undefined;
}
export interface StartWorkflowRunRequest {
    Name: string;
    RunProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartWorkflowRunResponse {
    RunId?: string | undefined;
}
export interface StopColumnStatisticsTaskRunRequest {
    DatabaseName: string;
    TableName: string;
    CatalogID?: string | undefined;
}
export interface StopColumnStatisticsTaskRunResponse {
}
export interface StopColumnStatisticsTaskRunScheduleRequest {
    DatabaseName: string;
    TableName: string;
    CatalogID?: string | undefined;
}
export interface StopColumnStatisticsTaskRunScheduleResponse {
}
export interface StopCrawlerRequest {
    Name: string;
}
export interface StopCrawlerResponse {
}
export interface StopCrawlerScheduleRequest {
    CrawlerName: string;
}
export interface StopCrawlerScheduleResponse {
}
export interface StopJobUpgradeAnalysisRequest {
    jobName: string;
    analysisId: string;
}
export interface StopJobUpgradeAnalysisResponse {
}
export interface StopMaterializedViewRefreshTaskRunRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
}
export interface StopMaterializedViewRefreshTaskRunResponse {
}
export interface StopSessionRequest {
    Id: string;
    RequestOrigin?: string | undefined;
}
export interface StopSessionResponse {
    Id?: string | undefined;
}
export interface StopTriggerRequest {
    Name: string;
}
export interface StopTriggerResponse {
    Name?: string | undefined;
}
export interface StopWorkflowRunRequest {
    Name: string;
    RunId: string;
}
export interface StopWorkflowRunResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    TagsToAdd: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface TestConnectionInput {
    ConnectionType: ConnectionType;
    ConnectionProperties: {
        [key: string]: string | undefined;
    };
    AuthenticationConfiguration?: AuthenticationConfigurationInput | undefined;
}
export interface TestConnectionRequest {
    ConnectionName?: string | undefined;
    CatalogId?: string | undefined;
    TestConnectionInput?: TestConnectionInput | undefined;
}
export interface TestConnectionResponse {
}
export type TagKeysList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagsToRemove: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAssetRequest {
    Identifier: string;
    Name?: string | undefined;
    Description?: string | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateAssetResponse {
    Id: string;
    Name?: string | undefined;
    Description?: string | undefined;
    UpdatedAt?: Date | undefined;
}
export interface UpdateBlueprintRequest {
    Name: string;
    Description?: string | undefined;
    BlueprintLocation: string;
}
export interface UpdateBlueprintResponse {
    Name?: string | undefined;
}
export interface UpdateCatalogRequest {
    CatalogId: string;
    CatalogInput: CatalogInput;
}
export interface UpdateCatalogResponse {
}
export interface UpdateGrokClassifierRequest {
    Name: string;
    Classification?: string | undefined;
    GrokPattern?: string | undefined;
    CustomPatterns?: string | undefined;
}
export interface UpdateXMLClassifierRequest {
    Name: string;
    Classification?: string | undefined;
    RowTag?: string | undefined;
}
export interface UpdateJsonClassifierRequest {
    Name: string;
    JsonPath?: string | undefined;
}
export interface UpdateCsvClassifierRequest {
    Name: string;
    Delimiter?: string | undefined;
    QuoteSymbol?: string | undefined;
    ContainsHeader?: CsvHeaderOption | undefined;
    Header?: string[] | undefined;
    DisableValueTrimming?: boolean | undefined;
    AllowSingleColumn?: boolean | undefined;
    CustomDatatypeConfigured?: boolean | undefined;
    CustomDatatypes?: string[] | undefined;
    Serde?: CsvSerdeOption | undefined;
}
export interface UpdateClassifierRequest {
    GrokClassifier?: UpdateGrokClassifierRequest | undefined;
    XMLClassifier?: UpdateXMLClassifierRequest | undefined;
    JsonClassifier?: UpdateJsonClassifierRequest | undefined;
    CsvClassifier?: UpdateCsvClassifierRequest | undefined;
}
export interface UpdateClassifierResponse {
}
export type UpdateColumnStatisticsList = ColumnStatistics[];
export interface UpdateColumnStatisticsForPartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    ColumnStatisticsList: ColumnStatistics[];
}
export interface ColumnStatisticsError {
    ColumnStatistics?: ColumnStatistics | undefined;
    Error?: ErrorDetail | undefined;
}
export type ColumnStatisticsErrors = ColumnStatisticsError[];
export interface UpdateColumnStatisticsForPartitionResponse {
    Errors?: ColumnStatisticsError[] | undefined;
}
export interface UpdateColumnStatisticsForTableRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    ColumnStatisticsList: ColumnStatistics[];
}
export interface UpdateColumnStatisticsForTableResponse {
    Errors?: ColumnStatisticsError[] | undefined;
}
export interface UpdateColumnStatisticsTaskSettingsRequest {
    DatabaseName: string;
    TableName: string;
    Role?: string | undefined;
    Schedule?: string | undefined;
    ColumnNameList?: string[] | undefined;
    SampleSize?: number | undefined;
    CatalogID?: string | undefined;
    SecurityConfiguration?: string | undefined;
}
export interface UpdateColumnStatisticsTaskSettingsResponse {
}
export interface UpdateConnectionRequest {
    CatalogId?: string | undefined;
    Name: string;
    ConnectionInput: ConnectionInput;
}
export interface UpdateConnectionResponse {
}
export type DescriptionStringRemovable = string;
export interface UpdateCrawlerRequest {
    Name: string;
    Role?: string | undefined;
    DatabaseName?: string | undefined;
    Description?: string | undefined;
    Targets?: CrawlerTargets | undefined;
    Schedule?: string | undefined;
    Classifiers?: string[] | undefined;
    TablePrefix?: string | undefined;
    SchemaChangePolicy?: SchemaChangePolicy | undefined;
    RecrawlPolicy?: RecrawlPolicy | undefined;
    LineageConfiguration?: LineageConfiguration | undefined;
    LakeFormationConfiguration?: LakeFormationConfiguration | undefined;
    Configuration?: string | undefined;
    CrawlerSecurityConfiguration?: string | undefined;
    CatalogId?: string | undefined;
}
export interface UpdateCrawlerResponse {
}
export interface UpdateCrawlerScheduleRequest {
    CrawlerName: string;
    Schedule?: string | undefined;
}
export interface UpdateCrawlerScheduleResponse {
}
export interface UpdateDatabaseRequest {
    CatalogId?: string | undefined;
    Name: string;
    DatabaseInput: DatabaseInput;
}
export interface UpdateDatabaseResponse {
}
export interface UpdateDataQualityEvaluationConfigRequest {
    Name: string;
    DataSource?: DataQualityEvaluationConfigDataSource | undefined;
    RulesetName?: string | undefined;
    ManagedRulesetName?: DataQualityEvaluationConfigManagedRuleset | undefined;
    Triggers?: DataQualityEvaluationConfigTrigger[] | undefined;
    ScheduleExpression?: string | undefined;
    StartAt?: Date | undefined;
    EndAt?: Date | undefined;
    PauseRuns?: boolean | undefined;
    Role?: string | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    AdditionalRunOptions?: DataQualityEvaluationConfigAdditionalRunOptions | undefined;
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    } | undefined;
}
export interface UpdateDataQualityEvaluationConfigResponse {
    Name?: string | undefined;
    EvaluationRunMode?: DataQualityEvaluationRunMode | undefined;
    CreatedOn?: Date | undefined;
    LastModifiedOn?: Date | undefined;
    Level?: DataQualityEvaluationConfigLevel | undefined;
    DataSource?: DataQualityEvaluationConfigDataSource | undefined;
    RulesetName?: string | undefined;
    ManagedRulesetName?: DataQualityEvaluationConfigManagedRuleset | undefined;
    Triggers?: DataQualityEvaluationConfigTrigger[] | undefined;
    ScheduleExpression?: string | undefined;
    StartAt?: Date | undefined;
    EndAt?: Date | undefined;
    PauseRuns?: boolean | undefined;
    Role?: string | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    AdditionalRunOptions?: DataQualityEvaluationConfigAdditionalRunOptions | undefined;
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    } | undefined;
}
export interface UpdateDataQualityRulesetRequest {
    Name: string;
    Description?: string | undefined;
    Ruleset?: string | undefined;
}
export interface UpdateDataQualityRulesetResponse {
    Name?: string | undefined;
    Description?: string | undefined;
    Ruleset?: string | undefined;
}
export interface DevEndpointCustomLibraries {
    ExtraPythonLibsS3Path?: string | undefined;
    ExtraJarsS3Path?: string | undefined;
}
export interface UpdateDevEndpointRequest {
    EndpointName: string;
    PublicKey?: string | undefined;
    AddPublicKeys?: string[] | undefined;
    DeletePublicKeys?: string[] | undefined;
    CustomLibraries?: DevEndpointCustomLibraries | undefined;
    UpdateEtlLibraries?: boolean | undefined;
    DeleteArguments?: string[] | undefined;
    AddArguments?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateDevEndpointResponse {
}
export interface UpdateGlossaryRequest {
    Identifier: string;
    Name?: string | undefined;
    Description?: string | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateGlossaryResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateGlossaryTermRequest {
    Identifier: string;
    Name?: string | undefined;
    ShortDescription?: string | undefined;
    LongDescription?: string | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateGlossaryTermResponse {
    Id?: string | undefined;
    GlossaryId?: string | undefined;
    Name?: string | undefined;
    ShortDescription?: string | undefined;
    LongDescription?: string | undefined;
}
export interface UpdateGlueIdentityCenterConfigurationRequest {
    Scopes?: string[] | undefined;
    UserBackgroundSessionsEnabled?: boolean | undefined;
}
export interface UpdateGlueIdentityCenterConfigurationResponse {
}
export interface UpdateIntegrationResourcePropertyRequest {
    ResourceArn: string;
    SourceProcessingProperties?: SourceProcessingProperties | undefined;
    TargetProcessingProperties?: TargetProcessingProperties | undefined;
}
export interface UpdateIntegrationResourcePropertyResponse {
    ResourceArn?: string | undefined;
    ResourcePropertyArn?: string | undefined;
    SourceProcessingProperties?: SourceProcessingProperties | undefined;
    TargetProcessingProperties?: TargetProcessingProperties | undefined;
}
export interface UpdateIntegrationTablePropertiesRequest {
    ResourceArn: string;
    TableName: string;
    SourceTableConfig?: SourceTableConfig | undefined;
    TargetTableConfig?: TargetTableConfig | undefined;
}
export interface UpdateIntegrationTablePropertiesResponse {
}
export interface JobUpdate {
    JobMode?: JobMode | undefined;
    JobRunQueuingEnabled?: boolean | undefined;
    Description?: string | undefined;
    LogUri?: string | undefined;
    Role?: string | undefined;
    ExecutionProperty?: ExecutionProperty | undefined;
    Command?: JobCommand | undefined;
    DefaultArguments?: {
        [key: string]: string | undefined;
    } | undefined;
    NonOverridableArguments?: {
        [key: string]: string | undefined;
    } | undefined;
    Connections?: ConnectionsList | undefined;
    MaxRetries?: number | undefined;
    AllocatedCapacity?: number | undefined;
    Timeout?: number | undefined;
    MaxCapacity?: number | undefined;
    WorkerType?: WorkerType | undefined;
    NumberOfWorkers?: number | undefined;
    SecurityConfiguration?: string | undefined;
    NotificationProperty?: NotificationProperty | undefined;
    GlueVersion?: string | undefined;
    CodeGenConfigurationNodes?: {
        [key: string]: CodeGenConfigurationNode | undefined;
    } | undefined;
    ExecutionClass?: ExecutionClass | undefined;
    SourceControlDetails?: SourceControlDetails | undefined;
    MaintenanceWindow?: string | undefined;
}
export interface UpdateJobRequest {
    JobName: string;
    JobUpdate: JobUpdate;
}
export interface UpdateJobResponse {
    JobName?: string | undefined;
}
export type CommitIdString = string;
export type AuthTokenString = string;
export interface UpdateJobFromSourceControlRequest {
    JobName?: string | undefined;
    Provider?: SourceControlProvider | undefined;
    RepositoryName?: string | undefined;
    RepositoryOwner?: string | undefined;
    BranchName?: string | undefined;
    Folder?: string | undefined;
    CommitId?: string | undefined;
    AuthStrategy?: SourceControlAuthStrategy | undefined;
    AuthToken?: string | undefined;
}
export interface UpdateJobFromSourceControlResponse {
    JobName?: string | undefined;
}
export interface UpdateMLTransformRequest {
    TransformId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    Parameters?: TransformParameters | undefined;
    Role?: string | undefined;
    GlueVersion?: string | undefined;
    MaxCapacity?: number | undefined;
    WorkerType?: WorkerType | undefined;
    NumberOfWorkers?: number | undefined;
    Timeout?: number | undefined;
    MaxRetries?: number | undefined;
}
export interface UpdateMLTransformResponse {
    TransformId?: string | undefined;
}
export interface UpdatePartitionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    TableName: string;
    PartitionValueList: string[];
    PartitionInput: PartitionInput;
}
export interface UpdatePartitionResponse {
}
export interface UpdateRegistryInput {
    RegistryId: RegistryId;
    Description: string;
}
export interface UpdateRegistryResponse {
    RegistryName?: string | undefined;
    RegistryArn?: string | undefined;
}
export interface UpdateSchemaInput {
    SchemaId: SchemaId;
    SchemaVersionNumber?: SchemaVersionNumber | undefined;
    Compatibility?: Compatibility | undefined;
    Description?: string | undefined;
}
export interface UpdateSchemaResponse {
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    RegistryName?: string | undefined;
}
export interface UpdateSourceControlFromJobRequest {
    JobName?: string | undefined;
    Provider?: SourceControlProvider | undefined;
    RepositoryName?: string | undefined;
    RepositoryOwner?: string | undefined;
    BranchName?: string | undefined;
    Folder?: string | undefined;
    CommitId?: string | undefined;
    AuthStrategy?: SourceControlAuthStrategy | undefined;
    AuthToken?: string | undefined;
}
export interface UpdateSourceControlFromJobResponse {
    JobName?: string | undefined;
}
export type ViewUpdateAction = "ADD" | "REPLACE" | "ADD_OR_REPLACE" | "DROP" | (string & {});
export type IcebergUpdateAction = "add-schema" | "set-current-schema" | "add-spec" | "set-default-spec" | "add-sort-order" | "set-default-sort-order" | "set-location" | "set-properties" | "remove-properties" | "add-encryption-key" | "remove-encryption-key" | (string & {});
export type EncryptionKeyIdString = string;
export type EncryptedKeyMetadataString = string;
export interface IcebergEncryptedKey {
    KeyId: string;
    EncryptedKeyMetadata: string;
    EncryptedById?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface IcebergTableUpdate {
    Schema: IcebergSchema;
    PartitionSpec?: IcebergPartitionSpec | undefined;
    SortOrder?: IcebergSortOrder | undefined;
    Location: string;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    Action?: IcebergUpdateAction | undefined;
    EncryptionKey?: IcebergEncryptedKey | undefined;
    KeyId?: string | undefined;
}
export type IcebergTableUpdateList = IcebergTableUpdate[];
export interface UpdateIcebergTableInput {
    Updates: IcebergTableUpdate[];
}
export interface UpdateIcebergInput {
    UpdateIcebergTableInput: UpdateIcebergTableInput;
}
export interface UpdateOpenTableFormatInput {
    UpdateIcebergInput?: UpdateIcebergInput | undefined;
}
export interface UpdateTableRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    Name?: string | undefined;
    TableInput?: TableInput | undefined;
    SkipArchive?: boolean | undefined;
    TransactionId?: string | undefined;
    VersionId?: string | undefined;
    ViewUpdateAction?: ViewUpdateAction | undefined;
    Force?: boolean | undefined;
    UpdateOpenTableFormatInput?: UpdateOpenTableFormatInput | undefined;
}
export interface UpdateTableResponse {
}
export interface UpdateTableOptimizerRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
    TableOptimizerConfiguration: TableOptimizerConfiguration;
}
export interface UpdateTableOptimizerResponse {
}
export interface TriggerUpdate {
    Name?: string | undefined;
    Description?: string | undefined;
    Schedule?: string | undefined;
    Actions?: Action[] | undefined;
    Predicate?: Predicate | undefined;
    EventBatchingCondition?: EventBatchingCondition | undefined;
}
export interface UpdateTriggerRequest {
    Name: string;
    TriggerUpdate: TriggerUpdate;
}
export interface UpdateTriggerResponse {
    Trigger?: Trigger | undefined;
}
export interface UpdateUsageProfileRequest {
    Name: string;
    Description?: string | undefined;
    Configuration: ProfileConfiguration;
}
export interface UpdateUsageProfileResponse {
    Name?: string | undefined;
}
export interface UpdateUserDefinedFunctionRequest {
    CatalogId?: string | undefined;
    DatabaseName: string;
    FunctionName: string;
    FunctionInput: UserDefinedFunctionInput;
}
export interface UpdateUserDefinedFunctionResponse {
}
export interface UpdateWorkflowRequest {
    Name: string;
    Description?: string | undefined;
    DefaultRunProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    MaxConcurrentRuns?: number | undefined;
}
export interface UpdateWorkflowResponse {
    Name?: string | undefined;
}
export type FederationSourceErrorCode = "AccessDeniedException" | "EntityNotFoundException" | "InvalidCredentialsException" | "InvalidInputException" | "InvalidResponseException" | "OperationTimeoutException" | "OperationNotSupportedException" | "InternalServiceException" | "PartialFailureException" | "ThrottlingException" | (string & {});
export type IntegrationErrorMessage = string;
export type AssociateGlossaryTermsError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Associates one or more glossary terms with an asset in Glue Data Catalog.
 */
export declare const associateGlossaryTerms: API.OperationMethod<AssociateGlossaryTermsRequest & RegionInput, AssociateGlossaryTermsResponse, AssociateGlossaryTermsError, Credentials | HttpClient.HttpClient>;
export type BatchCreatePartitionError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates one or more partitions in a batch operation.
 */
export declare const batchCreatePartition: API.OperationMethod<BatchCreatePartitionRequest & RegionInput, BatchCreatePartitionResponse, BatchCreatePartitionError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteConnectionError = InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a list of connection definitions from the Data Catalog.
 */
export declare const batchDeleteConnection: API.OperationMethod<BatchDeleteConnectionRequest & RegionInput, BatchDeleteConnectionResponse, BatchDeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type BatchDeletePartitionError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes one or more partitions in a batch operation.
 */
export declare const batchDeletePartition: API.OperationMethod<BatchDeletePartitionRequest & RegionInput, BatchDeletePartitionResponse, BatchDeletePartitionError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteTableError = ConcurrentModificationException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | CommonErrors;
/**
 * Deletes multiple tables at once.
 *
 * After completing this operation, you no longer have access to the table versions and
 * partitions that belong to the deleted table. Glue deletes these "orphaned" resources
 * asynchronously in a timely manner, at the discretion of the service.
 *
 * To ensure the immediate deletion of all related resources, before calling
 * `BatchDeleteTable`, use `DeleteTableVersion` or
 * `BatchDeleteTableVersion`, and `DeletePartition` or
 * `BatchDeletePartition`, to delete any resources that belong to the
 * table.
 */
export declare const batchDeleteTable: API.OperationMethod<BatchDeleteTableRequest & RegionInput, BatchDeleteTableResponse, BatchDeleteTableError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteTableVersionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified batch of versions of a table.
 */
export declare const batchDeleteTableVersion: API.OperationMethod<BatchDeleteTableVersionRequest & RegionInput, BatchDeleteTableVersionResponse, BatchDeleteTableVersionError, Credentials | HttpClient.HttpClient>;
export type BatchGetBlueprintsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about a list of blueprints.
 */
export declare const batchGetBlueprints: API.OperationMethod<BatchGetBlueprintsRequest & RegionInput, BatchGetBlueprintsResponse, BatchGetBlueprintsError, Credentials | HttpClient.HttpClient>;
export type BatchGetCrawlersError = InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of crawler names. After calling the `ListCrawlers` operation, you can call this operation to access the data to which you have been granted permissions. This operation supports all IAM permissions, including permission conditions that uses tags.
 */
export declare const batchGetCrawlers: API.OperationMethod<BatchGetCrawlersRequest & RegionInput, BatchGetCrawlersResponse, BatchGetCrawlersError, Credentials | HttpClient.HttpClient>;
export type BatchGetCustomEntityTypesError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details for the custom patterns specified by a list of names.
 */
export declare const batchGetCustomEntityTypes: API.OperationMethod<BatchGetCustomEntityTypesRequest & RegionInput, BatchGetCustomEntityTypesResponse, BatchGetCustomEntityTypesError, Credentials | HttpClient.HttpClient>;
export type BatchGetDataQualityResultError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of data quality results for the specified result IDs.
 */
export declare const batchGetDataQualityResult: API.OperationMethod<BatchGetDataQualityResultRequest & RegionInput, BatchGetDataQualityResultResponse, BatchGetDataQualityResultError, Credentials | HttpClient.HttpClient>;
export type BatchGetDataQualityResultV2Error = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of data quality results for the specified result IDs. You can specify up to 100 result IDs in a single request.
 */
export declare const batchGetDataQualityResultV2: API.OperationMethod<BatchGetDataQualityResultV2Request & RegionInput, BatchGetDataQualityResultV2Response, BatchGetDataQualityResultV2Error, Credentials | HttpClient.HttpClient>;
export type BatchGetDataQualityRulesetEvaluationRunError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of multiple evaluation runs in a single request.
 */
export declare const batchGetDataQualityRulesetEvaluationRun: API.OperationMethod<BatchGetDataQualityRulesetEvaluationRunRequest & RegionInput, BatchGetDataQualityRulesetEvaluationRunResponse, BatchGetDataQualityRulesetEvaluationRunError, Credentials | HttpClient.HttpClient>;
export type BatchGetDevEndpointsError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of development endpoint names. After
 * calling the `ListDevEndpoints` operation, you can call this operation to access the
 * data to which you have been granted permissions. This operation supports all IAM permissions,
 * including permission conditions that uses tags.
 */
export declare const batchGetDevEndpoints: API.OperationMethod<BatchGetDevEndpointsRequest & RegionInput, BatchGetDevEndpointsResponse, BatchGetDevEndpointsError, Credentials | HttpClient.HttpClient>;
export type BatchGetIterableFormsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves multiple items from an iterable form on an asset in Glue Data Catalog in a single request.
 */
export declare const batchGetIterableForms: API.OperationMethod<BatchGetIterableFormsRequest & RegionInput, BatchGetIterableFormsResponse, BatchGetIterableFormsError, Credentials | HttpClient.HttpClient>;
export type BatchGetJobsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of job names. After calling the `ListJobs` operation, you can call this operation to access the data to which you have been granted permissions. This operation supports all IAM permissions, including permission conditions that uses tags.
 */
export declare const batchGetJobs: API.OperationMethod<BatchGetJobsRequest & RegionInput, BatchGetJobsResponse, BatchGetJobsError, Credentials | HttpClient.HttpClient>;
export type BatchGetPartitionError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | InvalidStateException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves partitions in a batch request.
 */
export declare const batchGetPartition: API.OperationMethod<BatchGetPartitionRequest & RegionInput, BatchGetPartitionResponse, BatchGetPartitionError, Credentials | HttpClient.HttpClient>;
export type BatchGetTableOptimizerError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Returns the configuration for the specified table optimizers.
 */
export declare const batchGetTableOptimizer: API.OperationMethod<BatchGetTableOptimizerRequest & RegionInput, BatchGetTableOptimizerResponse, BatchGetTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type BatchGetTriggersError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of trigger names. After calling the `ListTriggers` operation, you can call this operation to access the data to which you have been granted permissions. This operation supports all IAM permissions, including permission conditions that uses tags.
 */
export declare const batchGetTriggers: API.OperationMethod<BatchGetTriggersRequest & RegionInput, BatchGetTriggersResponse, BatchGetTriggersError, Credentials | HttpClient.HttpClient>;
export type BatchGetWorkflowsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of workflow names. After calling the `ListWorkflows` operation, you can call this operation to access the data to which you have been granted permissions. This operation supports all IAM permissions, including permission conditions that uses tags.
 */
export declare const batchGetWorkflows: API.OperationMethod<BatchGetWorkflowsRequest & RegionInput, BatchGetWorkflowsResponse, BatchGetWorkflowsError, Credentials | HttpClient.HttpClient>;
export type BatchPutDataQualityStatisticAnnotationError = EntityNotFoundException | InternalServiceException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Annotate datapoints over time for a specific data quality statistic.
 * The API requires both profileID and statisticID as part of the InclusionAnnotation input.
 * The API only works for a single statisticId across multiple profiles.
 */
export declare const batchPutDataQualityStatisticAnnotation: API.OperationMethod<BatchPutDataQualityStatisticAnnotationRequest & RegionInput, BatchPutDataQualityStatisticAnnotationResponse, BatchPutDataQualityStatisticAnnotationError, Credentials | HttpClient.HttpClient>;
export type BatchStopJobRunError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops one or more job runs for a specified job definition.
 */
export declare const batchStopJobRun: API.OperationMethod<BatchStopJobRunRequest & RegionInput, BatchStopJobRunResponse, BatchStopJobRunError, Credentials | HttpClient.HttpClient>;
export type BatchUpdatePartitionError = ConcurrentModificationException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates one or more partitions in a batch operation.
 */
export declare const batchUpdatePartition: API.OperationMethod<BatchUpdatePartitionRequest & RegionInput, BatchUpdatePartitionResponse, BatchUpdatePartitionError, Credentials | HttpClient.HttpClient>;
export type CancelDataQualityRuleRecommendationRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Cancels the specified recommendation run that was being used to generate rules.
 */
export declare const cancelDataQualityRuleRecommendationRun: API.OperationMethod<CancelDataQualityRuleRecommendationRunRequest & RegionInput, CancelDataQualityRuleRecommendationRunResponse, CancelDataQualityRuleRecommendationRunError, Credentials | HttpClient.HttpClient>;
export type CancelDataQualityRulesetEvaluationRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Cancels a run where a ruleset is being evaluated against a data source.
 */
export declare const cancelDataQualityRulesetEvaluationRun: API.OperationMethod<CancelDataQualityRulesetEvaluationRunRequest & RegionInput, CancelDataQualityRulesetEvaluationRunResponse, CancelDataQualityRulesetEvaluationRunError, Credentials | HttpClient.HttpClient>;
export type CancelMLTaskRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Cancels (stops) a task run. Machine learning task runs are asynchronous tasks that Glue runs on your behalf as part of various machine learning workflows. You can cancel a
 * machine learning task run at any time by calling `CancelMLTaskRun` with a task
 * run's parent transform's `TransformID` and the task run's `TaskRunId`.
 */
export declare const cancelMLTaskRun: API.OperationMethod<CancelMLTaskRunRequest & RegionInput, CancelMLTaskRunResponse, CancelMLTaskRunError, Credentials | HttpClient.HttpClient>;
export type CancelStatementError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Cancels the statement.
 */
export declare const cancelStatement: API.OperationMethod<CancelStatementRequest & RegionInput, CancelStatementResponse, CancelStatementError, Credentials | HttpClient.HttpClient>;
export type CheckSchemaVersionValidityError = AccessDeniedException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Validates the supplied schema. This call has no side effects, it simply validates using the supplied schema using `DataFormat` as the format. Since it does not take a schema set name, no compatibility checks are performed.
 */
export declare const checkSchemaVersionValidity: API.OperationMethod<CheckSchemaVersionValidityInput & RegionInput, CheckSchemaVersionValidityResponse, CheckSchemaVersionValidityError, Credentials | HttpClient.HttpClient>;
export type CreateBlueprintError = AlreadyExistsException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Registers a blueprint with Glue.
 */
export declare const createBlueprint: API.OperationMethod<CreateBlueprintRequest & RegionInput, CreateBlueprintResponse, CreateBlueprintError, Credentials | HttpClient.HttpClient>;
export type CreateCatalogError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | FederatedResourceAlreadyExistsException | FederationSourceException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new catalog in the Glue Data Catalog.
 */
export declare const createCatalog: API.OperationMethod<CreateCatalogRequest & RegionInput, CreateCatalogResponse, CreateCatalogError, Credentials | HttpClient.HttpClient>;
export type CreateClassifierError = AlreadyExistsException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates a classifier in the user's account. This can be a `GrokClassifier`, an
 * `XMLClassifier`, a `JsonClassifier`, or a `CsvClassifier`,
 * depending on which field of the request is present.
 */
export declare const createClassifier: API.OperationMethod<CreateClassifierRequest & RegionInput, CreateClassifierResponse, CreateClassifierError, Credentials | HttpClient.HttpClient>;
export type CreateColumnStatisticsTaskSettingsError = AccessDeniedException | AlreadyExistsException | ColumnStatisticsTaskRunningException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates settings for a column statistics task.
 */
export declare const createColumnStatisticsTaskSettings: API.OperationMethod<CreateColumnStatisticsTaskSettingsRequest & RegionInput, CreateColumnStatisticsTaskSettingsResponse, CreateColumnStatisticsTaskSettingsError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = AlreadyExistsException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a connection definition in the Data Catalog.
 *
 * Connections used for creating federated resources require the IAM `glue:PassConnection` permission.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest & RegionInput, CreateConnectionResponse, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateCrawlerError = AlreadyExistsException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | GlueRoleNotAssumable | GlueS3TargetNotReady | CommonErrors;
/**
 * Creates a new crawler with specified targets, role, configuration, and optional schedule.
 * At least one crawl target must be specified, in the `s3Targets` field, the
 * `jdbcTargets` field, or the `DynamoDBTargets` field.
 */
export declare const createCrawler: API.OperationMethod<CreateCrawlerRequest & RegionInput, CreateCrawlerResponse, CreateCrawlerError, Credentials | HttpClient.HttpClient>;
export type CreateCustomEntityTypeError = AccessDeniedException | AlreadyExistsException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a custom pattern that is used to detect sensitive data across the columns and rows of your structured data.
 *
 * Each custom pattern you create specifies a regular expression and an optional list of context words. If no context words are passed only a regular expression is checked.
 */
export declare const createCustomEntityType: API.OperationMethod<CreateCustomEntityTypeRequest & RegionInput, CreateCustomEntityTypeResponse, CreateCustomEntityTypeError, Credentials | HttpClient.HttpClient>;
export type CreateDatabaseError = AlreadyExistsException | ConcurrentModificationException | FederatedResourceAlreadyExistsException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new database in a Data Catalog.
 */
export declare const createDatabase: API.OperationMethod<CreateDatabaseRequest & RegionInput, CreateDatabaseResponse, CreateDatabaseError, Credentials | HttpClient.HttpClient>;
export type CreateDataQualityEvaluationConfigError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a data quality evaluation configuration, which evaluates the data quality of a collection of tables in the Glue Data Catalog once, on a schedule, or when table metadata changes. A configuration applies to a catalog, a database, or a single table, and evaluates every table in scope, including tables added later, without per-table setup.
 *
 * When configurations at more than one level apply to the same table, the most specific configuration applies. Each table is evaluated at most once an hour, whichever triggers you choose.
 */
export declare const createDataQualityEvaluationConfig: API.OperationMethod<CreateDataQualityEvaluationConfigRequest & RegionInput, CreateDataQualityEvaluationConfigResponse, CreateDataQualityEvaluationConfigError, Credentials | HttpClient.HttpClient>;
export type CreateDataQualityRulesetError = AlreadyExistsException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a data quality ruleset with DQDL rules applied to a specified Glue table.
 *
 * You create the ruleset using the Data Quality Definition Language (DQDL). For more information, see the Glue developer guide.
 */
export declare const createDataQualityRuleset: API.OperationMethod<CreateDataQualityRulesetRequest & RegionInput, CreateDataQualityRulesetResponse, CreateDataQualityRulesetError, Credentials | HttpClient.HttpClient>;
export type CreateDevEndpointError = AccessDeniedException | AlreadyExistsException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a new development endpoint.
 */
export declare const createDevEndpoint: API.OperationMethod<CreateDevEndpointRequest & RegionInput, CreateDevEndpointResponse, CreateDevEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateGlossaryError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates a business glossary in Glue Data Catalog. A glossary is a container for glossary terms that define business concepts.
 */
export declare const createGlossary: API.OperationMethod<CreateGlossaryRequest & RegionInput, CreateGlossaryResponse, CreateGlossaryError, Credentials | HttpClient.HttpClient>;
export type CreateGlossaryTermError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates a glossary term within a business glossary in Glue Data Catalog.
 */
export declare const createGlossaryTerm: API.OperationMethod<CreateGlossaryTermRequest & RegionInput, CreateGlossaryTermResponse, CreateGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type CreateGlueIdentityCenterConfigurationError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates a new Glue Identity Center configuration to enable integration between Glue and Amazon Web Services IAM
 * Identity Center for authentication and authorization.
 */
export declare const createGlueIdentityCenterConfiguration: API.OperationMethod<CreateGlueIdentityCenterConfigurationRequest & RegionInput, CreateGlueIdentityCenterConfigurationResponse, CreateGlueIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = AccessDeniedException | ConflictException | EntityNotFoundException | IntegrationConflictOperationFault | IntegrationQuotaExceededFault | InternalServerException | InternalServiceException | InvalidInputException | KMSKeyNotAccessibleFault | ResourceNotFoundException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a Zero-ETL integration in the caller's account between two resources with Amazon Resource Names (ARNs): the `SourceArn` and `TargetArn`.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationRequest & RegionInput, CreateIntegrationResponse, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationResourcePropertyError = AccessDeniedException | ConflictException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API can be used for setting up the `ResourceProperty` of the Glue connection (for the source) or Glue database ARN (for the target). These properties can include the role to access the connection or database. To set both source and target properties the same API needs to be invoked with the Glue connection ARN as `ResourceArn` with `SourceProcessingProperties` and the Glue database ARN as `ResourceArn` with `TargetProcessingProperties` respectively.
 */
export declare const createIntegrationResourceProperty: API.OperationMethod<CreateIntegrationResourcePropertyRequest & RegionInput, CreateIntegrationResourcePropertyResponse, CreateIntegrationResourcePropertyError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used to provide optional override properties for the the tables that need to be replicated. These properties can include properties for filtering and partitioning for the source and target tables. To set both source and target properties the same API need to be invoked with the Glue connection ARN as `ResourceArn` with `SourceTableConfig`, and the Glue database ARN as `ResourceArn` with `TargetTableConfig` respectively.
 */
export declare const createIntegrationTableProperties: API.OperationMethod<CreateIntegrationTablePropertiesRequest & RegionInput, CreateIntegrationTablePropertiesResponse, CreateIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = AlreadyExistsException | ConcurrentModificationException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | GlueRoleNotAssumable | CommonErrors;
/**
 * Creates a new job definition.
 */
export declare const createJob: API.OperationMethod<CreateJobRequest & RegionInput, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateMLTransformError = AccessDeniedException | AlreadyExistsException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates an Glue machine learning transform. This operation creates the transform and
 * all the necessary parameters to train it.
 *
 * Call this operation as the first step in the process of using a machine learning transform
 * (such as the `FindMatches` transform) for deduplicating data. You can provide an
 * optional `Description`, in addition to the parameters that you want to use for your
 * algorithm.
 *
 * You must also specify certain parameters for the tasks that Glue runs on your
 * behalf as part of learning from your data and creating a high-quality machine learning
 * transform. These parameters include `Role`, and optionally,
 * `AllocatedCapacity`, `Timeout`, and `MaxRetries`. For more
 * information, see Jobs.
 */
export declare const createMLTransform: API.OperationMethod<CreateMLTransformRequest & RegionInput, CreateMLTransformResponse, CreateMLTransformError, Credentials | HttpClient.HttpClient>;
export type CreatePartitionError = AlreadyExistsException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new partition.
 */
export declare const createPartition: API.OperationMethod<CreatePartitionRequest & RegionInput, CreatePartitionResponse, CreatePartitionError, Credentials | HttpClient.HttpClient>;
export type CreatePartitionIndexError = AlreadyExistsException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a specified partition index in an existing table.
 */
export declare const createPartitionIndex: API.OperationMethod<CreatePartitionIndexRequest & RegionInput, CreatePartitionIndexResponse, CreatePartitionIndexError, Credentials | HttpClient.HttpClient>;
export type CreateRegistryError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new registry which may be used to hold a collection of schemas.
 */
export declare const createRegistry: API.OperationMethod<CreateRegistryInput & RegionInput, CreateRegistryResponse, CreateRegistryError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new schema set and registers the schema definition. Returns an error if the schema set already exists without actually registering the version.
 *
 * When the schema set is created, a version checkpoint will be set to the first version. Compatibility mode "DISABLED" restricts any additional schema versions from being added after the first schema version. For all other compatibility modes, validation of compatibility settings will be applied only from the second version onwards when the `RegisterSchemaVersion` API is used.
 *
 * When this API is called without a `RegistryId`, this will create an entry for a "default-registry" in the registry database tables, if it is not already present.
 */
export declare const createSchema: API.OperationMethod<CreateSchemaInput & RegionInput, CreateSchemaResponse, CreateSchemaError, Credentials | HttpClient.HttpClient>;
export type CreateScriptError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Transforms a directed acyclic graph (DAG) into code.
 */
export declare const createScript: API.OperationMethod<CreateScriptRequest & RegionInput, CreateScriptResponse, CreateScriptError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityConfigurationError = AlreadyExistsException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new security configuration. A security configuration is a set of security properties that can be used by Glue. You can use a security configuration to encrypt data at rest. For information about using security configurations in Glue, see Encrypting Data Written by Crawlers, Jobs, and Development Endpoints.
 */
export declare const createSecurityConfiguration: API.OperationMethod<CreateSecurityConfigurationRequest & RegionInput, CreateSecurityConfigurationResponse, CreateSecurityConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateSessionError = AccessDeniedException | AlreadyExistsException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a new session.
 */
export declare const createSession: API.OperationMethod<CreateSessionRequest & RegionInput, CreateSessionResponse, CreateSessionError, Credentials | HttpClient.HttpClient>;
export type CreateTableError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new table definition in the Data Catalog.
 */
export declare const createTable: API.OperationMethod<CreateTableRequest & RegionInput, CreateTableResponse, CreateTableError, Credentials | HttpClient.HttpClient>;
export type CreateTableOptimizerError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new table optimizer for a specific function.
 */
export declare const createTableOptimizer: API.OperationMethod<CreateTableOptimizerRequest & RegionInput, CreateTableOptimizerResponse, CreateTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type CreateTriggerError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new trigger.
 *
 * Job arguments may be logged. Do not pass plaintext secrets as arguments. Retrieve secrets from a Glue Connection, Amazon Web Services Secrets Manager or other secret management mechanism if you intend to keep them within the Job.
 */
export declare const createTrigger: API.OperationMethod<CreateTriggerRequest & RegionInput, CreateTriggerResponse, CreateTriggerError, Credentials | HttpClient.HttpClient>;
export type CreateUsageProfileError = AlreadyExistsException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates an Glue usage profile.
 */
export declare const createUsageProfile: API.OperationMethod<CreateUsageProfileRequest & RegionInput, CreateUsageProfileResponse, CreateUsageProfileError, Credentials | HttpClient.HttpClient>;
export type CreateUserDefinedFunctionError = AlreadyExistsException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new function definition in the Data Catalog.
 */
export declare const createUserDefinedFunction: API.OperationMethod<CreateUserDefinedFunctionRequest & RegionInput, CreateUserDefinedFunctionResponse, CreateUserDefinedFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new workflow.
 */
export declare const createWorkflow: API.OperationMethod<CreateWorkflowRequest & RegionInput, CreateWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes an asset from Glue Data Catalog.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest & RegionInput, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetTypeError = AccessDeniedException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes an asset type from Glue Data Catalog.
 */
export declare const deleteAssetType: API.OperationMethod<DeleteAssetTypeRequest & RegionInput, DeleteAssetTypeResponse, DeleteAssetTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteAttachmentError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes a form attachment from an asset in Glue Data Catalog.
 */
export declare const deleteAttachment: API.OperationMethod<DeleteAttachmentRequest & RegionInput, DeleteAttachmentResponse, DeleteAttachmentError, Credentials | HttpClient.HttpClient>;
export type DeleteBlueprintError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes an existing blueprint.
 */
export declare const deleteBlueprint: API.OperationMethod<DeleteBlueprintRequest & RegionInput, DeleteBlueprintResponse, DeleteBlueprintError, Credentials | HttpClient.HttpClient>;
export type DeleteCatalogError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Removes the specified catalog from the Glue Data Catalog.
 *
 * After completing this operation, you no longer have access to the databases, tables (and all table versions and partitions that might belong to the tables) and the user-defined functions in the deleted catalog. Glue deletes these "orphaned" resources asynchronously in a timely manner, at the discretion of the service.
 *
 * To ensure the immediate deletion of all related resources before calling the `DeleteCatalog` operation, use `DeleteTableVersion` (or `BatchDeleteTableVersion`), `DeletePartition` (or `BatchDeletePartition`), `DeleteTable` (or `BatchDeleteTable`), `DeleteUserDefinedFunction` and `DeleteDatabase` to delete any resources that belong to the catalog.
 */
export declare const deleteCatalog: API.OperationMethod<DeleteCatalogRequest & RegionInput, DeleteCatalogResponse, DeleteCatalogError, Credentials | HttpClient.HttpClient>;
export type DeleteClassifierError = EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Removes a classifier from the Data Catalog.
 */
export declare const deleteClassifier: API.OperationMethod<DeleteClassifierRequest & RegionInput, DeleteClassifierResponse, DeleteClassifierError, Credentials | HttpClient.HttpClient>;
export type DeleteColumnStatisticsForPartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Delete the partition column statistics of a column.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `DeletePartition`.
 */
export declare const deleteColumnStatisticsForPartition: API.OperationMethod<DeleteColumnStatisticsForPartitionRequest & RegionInput, DeleteColumnStatisticsForPartitionResponse, DeleteColumnStatisticsForPartitionError, Credentials | HttpClient.HttpClient>;
export type DeleteColumnStatisticsForTableError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves table statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `DeleteTable`.
 */
export declare const deleteColumnStatisticsForTable: API.OperationMethod<DeleteColumnStatisticsForTableRequest & RegionInput, DeleteColumnStatisticsForTableResponse, DeleteColumnStatisticsForTableError, Credentials | HttpClient.HttpClient>;
export type DeleteColumnStatisticsTaskSettingsError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes settings for a column statistics task.
 */
export declare const deleteColumnStatisticsTaskSettings: API.OperationMethod<DeleteColumnStatisticsTaskSettingsRequest & RegionInput, DeleteColumnStatisticsTaskSettingsResponse, DeleteColumnStatisticsTaskSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a connection from the Data Catalog.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest & RegionInput, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Deletes a custom connection type in Glue.
 *
 * The connection type must exist and be registered before it can be deleted. This operation supports cleanup of connection type resources and helps maintain proper lifecycle management of custom connection types.
 */
export declare const deleteConnectionType: API.OperationMethod<DeleteConnectionTypeRequest & RegionInput, DeleteConnectionTypeResponse, DeleteConnectionTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteCrawlerError = CrawlerRunningException | EntityNotFoundException | OperationTimeoutException | SchedulerTransitioningException | CommonErrors;
/**
 * Removes a specified crawler from the Glue Data Catalog, unless the crawler state is
 * `RUNNING`.
 */
export declare const deleteCrawler: API.OperationMethod<DeleteCrawlerRequest & RegionInput, DeleteCrawlerResponse, DeleteCrawlerError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomEntityTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a custom pattern by specifying its name.
 */
export declare const deleteCustomEntityType: API.OperationMethod<DeleteCustomEntityTypeRequest & RegionInput, DeleteCustomEntityTypeResponse, DeleteCustomEntityTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteDatabaseError = ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | InternalServiceException | InvalidInputException | OperationTimeoutException | InsufficientLakeFormationPermissions | CommonErrors;
/**
 * Removes a specified database from a Data Catalog.
 *
 * After completing this operation, you no longer have access to the tables (and all table
 * versions and partitions that might belong to the tables) and the user-defined functions in
 * the deleted database. Glue deletes these "orphaned" resources asynchronously in a timely
 * manner, at the discretion of the service.
 *
 * To ensure the immediate deletion of all related resources, before calling
 * `DeleteDatabase`, use `DeleteTableVersion` or
 * `BatchDeleteTableVersion`, `DeletePartition` or
 * `BatchDeletePartition`, `DeleteUserDefinedFunction`, and
 * `DeleteTable` or `BatchDeleteTable`, to delete any resources that
 * belong to the database.
 */
export declare const deleteDatabase: API.OperationMethod<DeleteDatabaseRequest & RegionInput, DeleteDatabaseResponse, DeleteDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteDataQualityEvaluationConfigError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a data quality evaluation configuration.
 */
export declare const deleteDataQualityEvaluationConfig: API.OperationMethod<DeleteDataQualityEvaluationConfigRequest & RegionInput, DeleteDataQualityEvaluationConfigResponse, DeleteDataQualityEvaluationConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteDataQualityRulesetError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a data quality ruleset.
 */
export declare const deleteDataQualityRuleset: API.OperationMethod<DeleteDataQualityRulesetRequest & RegionInput, DeleteDataQualityRulesetResponse, DeleteDataQualityRulesetError, Credentials | HttpClient.HttpClient>;
export type DeleteDevEndpointError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified development endpoint.
 */
export declare const deleteDevEndpoint: API.OperationMethod<DeleteDevEndpointRequest & RegionInput, DeleteDevEndpointResponse, DeleteDevEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteFormTypeError = AccessDeniedException | ConcurrentModificationException | ConflictException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes a form type from Glue Data Catalog. A form type cannot be deleted if it is still referenced by an asset type.
 */
export declare const deleteFormType: API.OperationMethod<DeleteFormTypeRequest & RegionInput, DeleteFormTypeResponse, DeleteFormTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteGlossaryError = AccessDeniedException | ConcurrentModificationException | ConflictException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes a business glossary from Glue Data Catalog. A glossary cannot be deleted if it still contains glossary terms.
 */
export declare const deleteGlossary: API.OperationMethod<DeleteGlossaryRequest & RegionInput, DeleteGlossaryResponse, DeleteGlossaryError, Credentials | HttpClient.HttpClient>;
export type DeleteGlossaryTermError = AccessDeniedException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes a glossary term from Glue Data Catalog.
 */
export declare const deleteGlossaryTerm: API.OperationMethod<DeleteGlossaryTermRequest & RegionInput, DeleteGlossaryTermResponse, DeleteGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type DeleteGlueIdentityCenterConfigurationError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes the existing Glue Identity Center configuration, removing the integration between Glue and
 * Amazon Web Services IAM Identity Center.
 */
export declare const deleteGlueIdentityCenterConfiguration: API.OperationMethod<DeleteGlueIdentityCenterConfigurationRequest & RegionInput, DeleteGlueIdentityCenterConfigurationResponse, DeleteGlueIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = AccessDeniedException | ConflictException | EntityNotFoundException | IntegrationConflictOperationFault | IntegrationNotFoundFault | InternalServerException | InternalServiceException | InvalidInputException | InvalidIntegrationStateFault | InvalidStateException | ValidationException | CommonErrors;
/**
 * Deletes the specified Zero-ETL integration.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest & RegionInput, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationResourcePropertyError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used for deleting the `ResourceProperty` of the Glue connection (for the source) or Glue database ARN (for the target).
 */
export declare const deleteIntegrationResourceProperty: API.OperationMethod<DeleteIntegrationResourcePropertyRequest & RegionInput, DeleteIntegrationResourcePropertyResponse, DeleteIntegrationResourcePropertyError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the table properties that have been created for the tables that need to be replicated.
 */
export declare const deleteIntegrationTableProperties: API.OperationMethod<DeleteIntegrationTablePropertiesRequest & RegionInput, DeleteIntegrationTablePropertiesResponse, DeleteIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified job definition. If the job definition
 * is not found, no exception is thrown.
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest & RegionInput, DeleteJobResponse, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteMLTransformError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes an Glue machine learning transform. Machine learning transforms are a special
 * type of transform that use machine learning to learn the details of the transformation to be
 * performed by learning from examples provided by humans. These transformations are then saved
 * by Glue. If you no longer need a transform, you can delete it by calling
 * `DeleteMLTransforms`. However, any Glue jobs that still reference the deleted
 * transform will no longer succeed.
 */
export declare const deleteMLTransform: API.OperationMethod<DeleteMLTransformRequest & RegionInput, DeleteMLTransformResponse, DeleteMLTransformError, Credentials | HttpClient.HttpClient>;
export type DeletePartitionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified partition.
 */
export declare const deletePartition: API.OperationMethod<DeletePartitionRequest & RegionInput, DeletePartitionResponse, DeletePartitionError, Credentials | HttpClient.HttpClient>;
export type DeletePartitionIndexError = ConflictException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified partition index from an existing table.
 */
export declare const deletePartitionIndex: API.OperationMethod<DeletePartitionIndexRequest & RegionInput, DeletePartitionIndexResponse, DeletePartitionIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Delete the entire registry including schema and all of its versions. To get the status of the delete operation, you can call the `GetRegistry` API after the asynchronous call. Deleting a registry will deactivate all online operations for the registry such as the `UpdateRegistry`, `CreateSchema`, `UpdateSchema`, and `RegisterSchemaVersion` APIs.
 */
export declare const deleteRegistry: API.OperationMethod<DeleteRegistryInput & RegionInput, DeleteRegistryResponse, DeleteRegistryError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = ConditionCheckFailureException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified policy.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Deletes the entire schema set, including the schema set and all of its versions. To get the status of the delete operation, you can call `GetSchema` API after the asynchronous call. Deleting a registry will deactivate all online operations for the schema, such as the `GetSchemaByDefinition`, and `RegisterSchemaVersion` APIs.
 */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaInput & RegionInput, DeleteSchemaResponse, DeleteSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaVersionsError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Remove versions from the specified schema. A version number or range may be supplied. If the compatibility mode forbids deleting of a version that is necessary, such as BACKWARDS_FULL, an error is returned. Calling the `GetSchemaVersions` API after this call will list the status of the deleted versions.
 *
 * When the range of version numbers contain check pointed version, the API will return a 409 conflict and will not proceed with the deletion. You have to remove the checkpoint first using the `DeleteSchemaCheckpoint` API before using this API.
 *
 * You cannot use the `DeleteSchemaVersions` API to delete the first schema version in the schema set. The first schema version can only be deleted by the `DeleteSchema` API. This operation will also delete the attached `SchemaVersionMetadata` under the schema versions. Hard deletes will be enforced on the database.
 *
 * If the compatibility mode forbids deleting of a version that is necessary, such as BACKWARDS_FULL, an error is returned.
 */
export declare const deleteSchemaVersions: API.OperationMethod<DeleteSchemaVersionsInput & RegionInput, DeleteSchemaVersionsResponse, DeleteSchemaVersionsError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityConfigurationError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified security configuration.
 */
export declare const deleteSecurityConfiguration: API.OperationMethod<DeleteSecurityConfigurationRequest & RegionInput, DeleteSecurityConfigurationResponse, DeleteSecurityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteSessionError = AccessDeniedException | ConcurrentModificationException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes the session.
 */
export declare const deleteSession: API.OperationMethod<DeleteSessionRequest & RegionInput, DeleteSessionResponse, DeleteSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteTableError = ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | CommonErrors;
/**
 * Removes a table definition from the Data Catalog.
 *
 * After completing this operation, you no longer have access to the table versions and
 * partitions that belong to the deleted table. Glue deletes these "orphaned" resources
 * asynchronously in a timely manner, at the discretion of the service.
 *
 * To ensure the immediate deletion of all related resources, before calling
 * `DeleteTable`, use `DeleteTableVersion` or
 * `BatchDeleteTableVersion`, and `DeletePartition` or
 * `BatchDeletePartition`, to delete any resources that belong to the
 * table.
 */
export declare const deleteTable: API.OperationMethod<DeleteTableRequest & RegionInput, DeleteTableResponse, DeleteTableError, Credentials | HttpClient.HttpClient>;
export type DeleteTableOptimizerError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes an optimizer and all associated metadata for a table. The optimization will no longer be performed on the table.
 */
export declare const deleteTableOptimizer: API.OperationMethod<DeleteTableOptimizerRequest & RegionInput, DeleteTableOptimizerResponse, DeleteTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type DeleteTableVersionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified version of a table.
 */
export declare const deleteTableVersion: API.OperationMethod<DeleteTableVersionRequest & RegionInput, DeleteTableVersionResponse, DeleteTableVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteTriggerError = ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified trigger. If the trigger is not found, no
 * exception is thrown.
 */
export declare const deleteTrigger: API.OperationMethod<DeleteTriggerRequest & RegionInput, DeleteTriggerResponse, DeleteTriggerError, Credentials | HttpClient.HttpClient>;
export type DeleteUsageProfileError = InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * Deletes the Glue specified usage profile.
 */
export declare const deleteUsageProfile: API.OperationMethod<DeleteUsageProfileRequest & RegionInput, DeleteUsageProfileResponse, DeleteUsageProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteUserDefinedFunctionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes an existing function definition from the Data Catalog.
 */
export declare const deleteUserDefinedFunction: API.OperationMethod<DeleteUserDefinedFunctionRequest & RegionInput, DeleteUserDefinedFunctionResponse, DeleteUserDefinedFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a workflow.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest & RegionInput, DeleteWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionTypeError = AccessDeniedException | InternalServiceException | InvalidInputException | ValidationException | CommonErrors;
/**
 * The `DescribeConnectionType` API provides full details of the supported options for a given connection type in Glue. The response includes authentication configuration details that show supported authentication types and properties, and RestConfiguration for custom REST-based connection types registered via `RegisterConnectionType`.
 *
 * See also: `ListConnectionTypes`, `RegisterConnectionType`, `DeleteConnectionType`
 */
export declare const describeConnectionType: API.OperationMethod<DescribeConnectionTypeRequest & RegionInput, DescribeConnectionTypeResponse, DescribeConnectionTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeEntityError = AccessDeniedException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Provides details regarding the entity used with the connection type, with a description of the data model for each field in the selected entity.
 *
 * The response includes all the fields which make up the entity.
 */
export declare const describeEntity: API.PaginatedOperationMethod<DescribeEntityRequest & RegionInput, DescribeEntityResponse, DescribeEntityError, Credentials | HttpClient.HttpClient, Field>;
export type DescribeInboundIntegrationsError = AccessDeniedException | EntityNotFoundException | IntegrationNotFoundFault | InternalServerException | InternalServiceException | InvalidInputException | OperationNotSupportedException | TargetResourceNotFound | ValidationException | CommonErrors;
/**
 * Returns a list of inbound integrations for the specified integration.
 */
export declare const describeInboundIntegrations: API.OperationMethod<DescribeInboundIntegrationsRequest & RegionInput, DescribeInboundIntegrationsResponse, DescribeInboundIntegrationsError, Credentials | HttpClient.HttpClient>;
export type DescribeIntegrationsError = AccessDeniedException | EntityNotFoundException | IntegrationNotFoundFault | InternalServerException | InternalServiceException | InvalidInputException | ValidationException | CommonErrors;
/**
 * The API is used to retrieve a list of integrations.
 */
export declare const describeIntegrations: API.OperationMethod<DescribeIntegrationsRequest & RegionInput, DescribeIntegrationsResponse, DescribeIntegrationsError, Credentials | HttpClient.HttpClient>;
export type DisassociateGlossaryTermsError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Removes the association of one or more glossary terms from an asset in Glue Data Catalog.
 */
export declare const disassociateGlossaryTerms: API.OperationMethod<DisassociateGlossaryTermsRequest & RegionInput, DisassociateGlossaryTermsResponse, DisassociateGlossaryTermsError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata for an asset in Glue Data Catalog, including its forms, additional attachments, and associated glossary terms.
 */
export declare const getAsset: API.OperationMethod<GetAssetInput & RegionInput, GetAssetOutput, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetAssetTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves an asset type in Glue Data Catalog by its identifier.
 */
export declare const getAssetType: API.OperationMethod<GetAssetTypeRequest & RegionInput, GetAssetTypeResponse, GetAssetTypeError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of a blueprint.
 */
export declare const getBlueprint: API.OperationMethod<GetBlueprintRequest & RegionInput, GetBlueprintResponse, GetBlueprintError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintRunError = EntityNotFoundException | InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of a blueprint run.
 */
export declare const getBlueprintRun: API.OperationMethod<GetBlueprintRunRequest & RegionInput, GetBlueprintRunResponse, GetBlueprintRunError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintRunsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of blueprint runs for a specified blueprint.
 */
export declare const getBlueprintRuns: API.PaginatedOperationMethod<GetBlueprintRunsRequest & RegionInput, GetBlueprintRunsResponse, GetBlueprintRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCatalogError = AccessDeniedException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * The name of the Catalog to retrieve. This should be all lowercase.
 */
export declare const getCatalog: API.OperationMethod<GetCatalogRequest & RegionInput, GetCatalogResponse, GetCatalogError, Credentials | HttpClient.HttpClient>;
export type GetCatalogImportStatusError = InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the status of a migration operation.
 */
export declare const getCatalogImportStatus: API.OperationMethod<GetCatalogImportStatusRequest & RegionInput, GetCatalogImportStatusResponse, GetCatalogImportStatusError, Credentials | HttpClient.HttpClient>;
export type GetCatalogsError = AccessDeniedException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves all catalogs defined in a catalog in the Glue Data Catalog. For a Redshift-federated catalog use case, this operation returns the list of catalogs mapped to Redshift databases in the Redshift namespace catalog.
 */
export declare const getCatalogs: API.OperationMethod<GetCatalogsRequest & RegionInput, GetCatalogsResponse, GetCatalogsError, Credentials | HttpClient.HttpClient>;
export type GetClassifierError = EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Retrieve a classifier by name.
 */
export declare const getClassifier: API.OperationMethod<GetClassifierRequest & RegionInput, GetClassifierResponse, GetClassifierError, Credentials | HttpClient.HttpClient>;
export type GetClassifiersError = OperationTimeoutException | CommonErrors;
/**
 * Lists all classifier objects in the Data Catalog.
 */
export declare const getClassifiers: API.PaginatedOperationMethod<GetClassifiersRequest & RegionInput, GetClassifiersResponse, GetClassifiersError, Credentials | HttpClient.HttpClient, unknown>;
export type GetColumnStatisticsForPartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves partition statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `GetPartition`.
 */
export declare const getColumnStatisticsForPartition: API.OperationMethod<GetColumnStatisticsForPartitionRequest & RegionInput, GetColumnStatisticsForPartitionResponse, GetColumnStatisticsForPartitionError, Credentials | HttpClient.HttpClient>;
export type GetColumnStatisticsForTableError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves table statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `GetTable`.
 */
export declare const getColumnStatisticsForTable: API.OperationMethod<GetColumnStatisticsForTableRequest & RegionInput, GetColumnStatisticsForTableResponse, GetColumnStatisticsForTableError, Credentials | HttpClient.HttpClient>;
export type GetColumnStatisticsTaskRunError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Get the associated metadata/information for a task run, given a task run ID.
 */
export declare const getColumnStatisticsTaskRun: API.OperationMethod<GetColumnStatisticsTaskRunRequest & RegionInput, GetColumnStatisticsTaskRunResponse, GetColumnStatisticsTaskRunError, Credentials | HttpClient.HttpClient>;
export type GetColumnStatisticsTaskRunsError = OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about all runs associated with the specified table.
 */
export declare const getColumnStatisticsTaskRuns: API.PaginatedOperationMethod<GetColumnStatisticsTaskRunsRequest & RegionInput, GetColumnStatisticsTaskRunsResponse, GetColumnStatisticsTaskRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetColumnStatisticsTaskSettingsError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets settings for a column statistics task.
 */
export declare const getColumnStatisticsTaskSettings: API.OperationMethod<GetColumnStatisticsTaskSettingsRequest & RegionInput, GetColumnStatisticsTaskSettingsResponse, GetColumnStatisticsTaskSettingsError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = EntityNotFoundException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a connection definition from the Data Catalog.
 */
export declare const getConnection: API.OperationMethod<GetConnectionRequest & RegionInput, GetConnectionResponse, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type GetConnectionsError = EntityNotFoundException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of connection definitions from the Data Catalog.
 */
export declare const getConnections: API.PaginatedOperationMethod<GetConnectionsRequest & RegionInput, GetConnectionsResponse, GetConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCrawlerError = EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves metadata for a specified crawler.
 */
export declare const getCrawler: API.OperationMethod<GetCrawlerRequest & RegionInput, GetCrawlerResponse, GetCrawlerError, Credentials | HttpClient.HttpClient>;
export type GetCrawlerMetricsError = OperationTimeoutException | CommonErrors;
/**
 * Retrieves metrics about specified crawlers.
 */
export declare const getCrawlerMetrics: API.PaginatedOperationMethod<GetCrawlerMetricsRequest & RegionInput, GetCrawlerMetricsResponse, GetCrawlerMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCrawlersError = OperationTimeoutException | CommonErrors;
/**
 * Retrieves metadata for all crawlers defined in the customer
 * account.
 */
export declare const getCrawlers: API.PaginatedOperationMethod<GetCrawlersRequest & RegionInput, GetCrawlersResponse, GetCrawlersError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCustomEntityTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of a custom pattern by specifying its name.
 */
export declare const getCustomEntityType: API.OperationMethod<GetCustomEntityTypeRequest & RegionInput, GetCustomEntityTypeResponse, GetCustomEntityTypeError, Credentials | HttpClient.HttpClient>;
export type GetDashboardUrlError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | CommonErrors;
/**
 * Retrieves the URL for the Spark monitoring dashboard for a Glue resource.
 */
export declare const getDashboardUrl: API.OperationMethod<GetDashboardUrlRequest & RegionInput, GetDashboardUrlResponse, GetDashboardUrlError, Credentials | HttpClient.HttpClient>;
export type GetDatabaseError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the definition of a specified database.
 */
export declare const getDatabase: API.OperationMethod<GetDatabaseRequest & RegionInput, GetDatabaseResponse, GetDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetDatabasesError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves all databases defined in a given Data Catalog.
 */
export declare const getDatabases: API.PaginatedOperationMethod<GetDatabasesRequest & RegionInput, GetDatabasesResponse, GetDatabasesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDataCatalogEncryptionSettingsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the security configuration for a specified catalog.
 */
export declare const getDataCatalogEncryptionSettings: API.OperationMethod<GetDataCatalogEncryptionSettingsRequest & RegionInput, GetDataCatalogEncryptionSettingsResponse, GetDataCatalogEncryptionSettingsError, Credentials | HttpClient.HttpClient>;
export type GetDataCatalogExportConfigurationError = EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current export configuration for the Glue Data Catalog. The export configuration controls whether catalog metadata is exported to S3 Tables.
 */
export declare const getDataCatalogExportConfiguration: API.OperationMethod<GetDataCatalogExportConfigurationInput & RegionInput, GetDataCatalogExportConfigurationOutput, GetDataCatalogExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDataflowGraphError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Transforms a Python script into a directed acyclic graph (DAG).
 */
export declare const getDataflowGraph: API.OperationMethod<GetDataflowGraphRequest & RegionInput, GetDataflowGraphResponse, GetDataflowGraphError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityEvaluationConfigError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a data quality evaluation configuration.
 */
export declare const getDataQualityEvaluationConfig: API.OperationMethod<GetDataQualityEvaluationConfigRequest & RegionInput, GetDataQualityEvaluationConfigResponse, GetDataQualityEvaluationConfigError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityModelError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieve the training status of the model along with more information (CompletedOn, StartedOn, FailureReason).
 */
export declare const getDataQualityModel: API.OperationMethod<GetDataQualityModelRequest & RegionInput, GetDataQualityModelResponse, GetDataQualityModelError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityModelResultError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieve a statistic's predictions for a given Profile ID.
 */
export declare const getDataQualityModelResult: API.OperationMethod<GetDataQualityModelResultRequest & RegionInput, GetDataQualityModelResultResponse, GetDataQualityModelResultError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityResultError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the result of a data quality rule evaluation.
 */
export declare const getDataQualityResult: API.OperationMethod<GetDataQualityResultRequest & RegionInput, GetDataQualityResultResponse, GetDataQualityResultError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityResultV2Error = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the result of a data quality rule evaluation published from any supported data platform.
 */
export declare const getDataQualityResultV2: API.OperationMethod<GetDataQualityResultV2Request & RegionInput, GetDataQualityResultV2Response, GetDataQualityResultV2Error, Credentials | HttpClient.HttpClient>;
export type GetDataQualityRuleRecommendationRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets the specified recommendation run that was used to generate rules.
 */
export declare const getDataQualityRuleRecommendationRun: API.OperationMethod<GetDataQualityRuleRecommendationRunRequest & RegionInput, GetDataQualityRuleRecommendationRunResponse, GetDataQualityRuleRecommendationRunError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityRulesetError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns an existing ruleset by identifier or name.
 */
export declare const getDataQualityRuleset: API.OperationMethod<GetDataQualityRulesetRequest & RegionInput, GetDataQualityRulesetResponse, GetDataQualityRulesetError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityRulesetEvaluationRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specific run where a ruleset is evaluated against a data source.
 */
export declare const getDataQualityRulesetEvaluationRun: API.OperationMethod<GetDataQualityRulesetEvaluationRunRequest & RegionInput, GetDataQualityRulesetEvaluationRunResponse, GetDataQualityRulesetEvaluationRunError, Credentials | HttpClient.HttpClient>;
export type GetDevEndpointError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about a specified development endpoint.
 *
 * When you create a development endpoint in a virtual private cloud (VPC), Glue returns only
 * a private IP address, and the public IP address field is not populated. When you create a
 * non-VPC development endpoint, Glue returns only a public IP address.
 */
export declare const getDevEndpoint: API.OperationMethod<GetDevEndpointRequest & RegionInput, GetDevEndpointResponse, GetDevEndpointError, Credentials | HttpClient.HttpClient>;
export type GetDevEndpointsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves all the development endpoints in this Amazon Web Services account.
 *
 * When you create a development endpoint in a virtual private cloud (VPC), Glue returns only a private IP address
 * and the public IP address field is not populated. When you create a non-VPC development
 * endpoint, Glue returns only a public IP address.
 */
export declare const getDevEndpoints: API.PaginatedOperationMethod<GetDevEndpointsRequest & RegionInput, GetDevEndpointsResponse, GetDevEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetEntityRecordsError = AccessDeniedException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * This API is used to query preview data from a given connection type or from a native Amazon S3 based Glue Data Catalog.
 *
 * Returns records as an array of JSON blobs. Each record is formatted using Jackson JsonNode based on the field type defined by the `DescribeEntity` API.
 *
 * Spark connectors generate schemas according to the same data type mapping as in the `DescribeEntity` API. Spark connectors convert data to the appropriate data types matching the schema when returning rows.
 */
export declare const getEntityRecords: API.OperationMethod<GetEntityRecordsRequest & RegionInput, GetEntityRecordsResponse, GetEntityRecordsError, Credentials | HttpClient.HttpClient>;
export type GetFormTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves a form type in Glue Data Catalog by its identifier.
 */
export declare const getFormType: API.OperationMethod<GetFormTypeRequest & RegionInput, GetFormTypeResponse, GetFormTypeError, Credentials | HttpClient.HttpClient>;
export type GetGlossaryError = AccessDeniedException | EntityNotFoundException | InternalServiceException | ThrottlingException | CommonErrors;
/**
 * Retrieves a business glossary in Glue Data Catalog by its identifier.
 */
export declare const getGlossary: API.OperationMethod<GetGlossaryRequest & RegionInput, GetGlossaryResponse, GetGlossaryError, Credentials | HttpClient.HttpClient>;
export type GetGlossaryTermError = AccessDeniedException | EntityNotFoundException | InternalServiceException | ThrottlingException | CommonErrors;
/**
 * Retrieves a glossary term in Glue Data Catalog by its identifier.
 */
export declare const getGlossaryTerm: API.OperationMethod<GetGlossaryTermRequest & RegionInput, GetGlossaryTermResponse, GetGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type GetGlueIdentityCenterConfigurationError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the current Glue Identity Center configuration details, including the associated Identity Center instance and
 * application information.
 */
export declare const getGlueIdentityCenterConfiguration: API.OperationMethod<GetGlueIdentityCenterConfigurationRequest & RegionInput, GetGlueIdentityCenterConfigurationResponse, GetGlueIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResourcePropertyError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used for fetching the `ResourceProperty` of the Glue connection (for the source) or Glue database ARN (for the target)
 */
export declare const getIntegrationResourceProperty: API.OperationMethod<GetIntegrationResourcePropertyRequest & RegionInput, GetIntegrationResourcePropertyResponse, GetIntegrationResourcePropertyError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used to retrieve optional override properties for the tables that need to be replicated. These properties can include properties for filtering and partition for source and target tables.
 */
export declare const getIntegrationTableProperties: API.OperationMethod<GetIntegrationTablePropertiesRequest & RegionInput, GetIntegrationTablePropertiesResponse, GetIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type GetJobError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves an existing job definition.
 */
export declare const getJob: API.OperationMethod<GetJobRequest & RegionInput, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetJobBookmarkError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Returns information on a job bookmark entry.
 *
 * For more information about enabling and using job bookmarks, see:
 *
 * - Tracking processed data using job bookmarks
 *
 * - Job parameters used by Glue
 *
 * - Job structure
 */
export declare const getJobBookmark: API.OperationMethod<GetJobBookmarkRequest & RegionInput, GetJobBookmarkResponse, GetJobBookmarkError, Credentials | HttpClient.HttpClient>;
export type GetJobRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the metadata for a given job run. Job run history is accessible for 365 days for your workflow and job run.
 */
export declare const getJobRun: API.OperationMethod<GetJobRunRequest & RegionInput, GetJobRunResponse, GetJobRunError, Credentials | HttpClient.HttpClient>;
export type GetJobRunsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves metadata for all runs of a given job definition.
 *
 * `GetJobRuns` returns the job runs in chronological order, with the newest jobs returned first.
 */
export declare const getJobRuns: API.PaginatedOperationMethod<GetJobRunsRequest & RegionInput, GetJobRunsResponse, GetJobRunsError, Credentials | HttpClient.HttpClient, JobRun>;
export type GetJobsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves all current job definitions.
 */
export declare const getJobs: API.PaginatedOperationMethod<GetJobsRequest & RegionInput, GetJobsResponse, GetJobsError, Credentials | HttpClient.HttpClient, Job>;
export type GetJobUpgradeAnalysisError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | CommonErrors;
/**
 * Retrieves the current status and results of an upgrade analysis.
 */
export declare const getJobUpgradeAnalysis: API.OperationMethod<GetJobUpgradeAnalysisRequest & RegionInput, GetJobUpgradeAnalysisResponse, GetJobUpgradeAnalysisError, Credentials | HttpClient.HttpClient>;
export type GetMappingError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates mappings.
 */
export declare const getMapping: API.OperationMethod<GetMappingRequest & RegionInput, GetMappingResponse, GetMappingError, Credentials | HttpClient.HttpClient>;
export type GetMaterializedViewRefreshTaskRunError = AccessDeniedException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Get the associated metadata/information for a task run, given a task run ID.
 */
export declare const getMaterializedViewRefreshTaskRun: API.OperationMethod<GetMaterializedViewRefreshTaskRunRequest & RegionInput, GetMaterializedViewRefreshTaskRunResponse, GetMaterializedViewRefreshTaskRunError, Credentials | HttpClient.HttpClient>;
export type GetMLTaskRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets details for a specific task run on a machine learning transform. Machine learning
 * task runs are asynchronous tasks that Glue runs on your behalf as part of various machine
 * learning workflows. You can check the stats of any task run by calling
 * `GetMLTaskRun` with the `TaskRunID` and its parent transform's
 * `TransformID`.
 */
export declare const getMLTaskRun: API.OperationMethod<GetMLTaskRunRequest & RegionInput, GetMLTaskRunResponse, GetMLTaskRunError, Credentials | HttpClient.HttpClient>;
export type GetMLTaskRunsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets a list of runs for a machine learning transform. Machine learning task runs are
 * asynchronous tasks that Glue runs on your behalf as part of various machine learning
 * workflows. You can get a sortable, filterable list of machine learning task runs by calling
 * `GetMLTaskRuns` with their parent transform's `TransformID` and other
 * optional parameters as documented in this section.
 *
 * This operation returns a list of historic runs and must be paginated.
 */
export declare const getMLTaskRuns: API.PaginatedOperationMethod<GetMLTaskRunsRequest & RegionInput, GetMLTaskRunsResponse, GetMLTaskRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetMLTransformError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets an Glue machine learning transform artifact and all its corresponding metadata.
 * Machine learning transforms are a special type of transform that use machine learning to learn
 * the details of the transformation to be performed by learning from examples provided by
 * humans. These transformations are then saved by Glue. You can retrieve their metadata by
 * calling `GetMLTransform`.
 */
export declare const getMLTransform: API.OperationMethod<GetMLTransformRequest & RegionInput, GetMLTransformResponse, GetMLTransformError, Credentials | HttpClient.HttpClient>;
export type GetMLTransformsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets a sortable, filterable list of existing Glue machine learning transforms. Machine
 * learning transforms are a special type of transform that use machine learning to learn the
 * details of the transformation to be performed by learning from examples provided by humans.
 * These transformations are then saved by Glue, and you can retrieve their metadata by
 * calling `GetMLTransforms`.
 */
export declare const getMLTransforms: API.PaginatedOperationMethod<GetMLTransformsRequest & RegionInput, GetMLTransformsResponse, GetMLTransformsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetPartitionError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about a specified partition.
 */
export declare const getPartition: API.OperationMethod<GetPartitionRequest & RegionInput, GetPartitionResponse, GetPartitionError, Credentials | HttpClient.HttpClient>;
export type GetPartitionIndexesError = ConflictException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the partition indexes associated with a table.
 */
export declare const getPartitionIndexes: API.PaginatedOperationMethod<GetPartitionIndexesRequest & RegionInput, GetPartitionIndexesResponse, GetPartitionIndexesError, Credentials | HttpClient.HttpClient, PartitionIndexDescriptor>;
export type GetPartitionsError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | InvalidStateException | OperationTimeoutException | ResourceNotReadyException | CommonErrors;
/**
 * Retrieves information about the partitions in a table.
 */
export declare const getPartitions: API.PaginatedOperationMethod<GetPartitionsRequest & RegionInput, GetPartitionsResponse, GetPartitionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetPlanError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets code to perform a specified mapping.
 */
export declare const getPlan: API.OperationMethod<GetPlanRequest & RegionInput, GetPlanResponse, GetPlanError, Credentials | HttpClient.HttpClient>;
export type GetRegistryError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Describes the specified registry in detail.
 */
export declare const getRegistry: API.OperationMethod<GetRegistryInput & RegionInput, GetRegistryResponse, GetRegistryError, Credentials | HttpClient.HttpClient>;
export type GetResourcePoliciesError = GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the resource policies set on individual resources by Resource Access Manager
 * during cross-account permission grants. Also retrieves the Data Catalog resource
 * policy.
 *
 * If you enabled metadata encryption in Data Catalog settings, and you do not have
 * permission on the KMS key, the operation can't return the Data Catalog resource
 * policy.
 */
export declare const getResourcePolicies: API.PaginatedOperationMethod<GetResourcePoliciesRequest & RegionInput, GetResourcePoliciesResponse, GetResourcePoliciesError, Credentials | HttpClient.HttpClient, GluePolicy>;
export type GetResourcePolicyError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specified resource policy.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetSchemaError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Describes the specified schema in detail.
 */
export declare const getSchema: API.OperationMethod<GetSchemaInput & RegionInput, GetSchemaResponse, GetSchemaError, Credentials | HttpClient.HttpClient>;
export type GetSchemaByDefinitionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Retrieves a schema by the `SchemaDefinition`. The schema definition is sent to the Schema Registry, canonicalized, and hashed. If the hash is matched within the scope of the `SchemaName` or ARN (or the default registry, if none is supplied), that schema's metadata is returned. Otherwise, a 404 or NotFound error is returned. Schema versions in `Deleted` statuses will not be included in the results.
 */
export declare const getSchemaByDefinition: API.OperationMethod<GetSchemaByDefinitionInput & RegionInput, GetSchemaByDefinitionResponse, GetSchemaByDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetSchemaVersionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Get the specified schema by its unique ID assigned when a version of the schema is created or registered. Schema versions in Deleted status will not be included in the results.
 */
export declare const getSchemaVersion: API.OperationMethod<GetSchemaVersionInput & RegionInput, GetSchemaVersionResponse, GetSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type GetSchemaVersionsDiffError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Fetches the schema version difference in the specified difference type between two stored schema versions in the Schema Registry.
 *
 * This API allows you to compare two schema versions between two schema definitions under the same schema.
 */
export declare const getSchemaVersionsDiff: API.OperationMethod<GetSchemaVersionsDiffInput & RegionInput, GetSchemaVersionsDiffResponse, GetSchemaVersionsDiffError, Credentials | HttpClient.HttpClient>;
export type GetSecurityConfigurationError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specified security configuration.
 */
export declare const getSecurityConfiguration: API.OperationMethod<GetSecurityConfigurationRequest & RegionInput, GetSecurityConfigurationResponse, GetSecurityConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSecurityConfigurationsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of all security configurations.
 */
export declare const getSecurityConfigurations: API.PaginatedOperationMethod<GetSecurityConfigurationsRequest & RegionInput, GetSecurityConfigurationsResponse, GetSecurityConfigurationsError, Credentials | HttpClient.HttpClient, SecurityConfiguration>;
export type GetSessionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the session.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest & RegionInput, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type GetSessionEndpointError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * Returns the Spark Connect endpoint URL and authentication token for an interactive session.
 */
export declare const getSessionEndpoint: API.OperationMethod<GetSessionEndpointRequest & RegionInput, GetSessionEndpointResponse, GetSessionEndpointError, Credentials | HttpClient.HttpClient>;
export type GetStatementError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the statement.
 */
export declare const getStatement: API.OperationMethod<GetStatementRequest & RegionInput, GetStatementResponse, GetStatementError, Credentials | HttpClient.HttpClient>;
export type GetSystemLogsForJobRunError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the system logs for a job run.
 */
export declare const getSystemLogsForJobRun: API.OperationMethod<GetSystemLogsForJobRunRequest & RegionInput, GetSystemLogsForJobRunResponse, GetSystemLogsForJobRunError, Credentials | HttpClient.HttpClient>;
export type GetSystemLogsForSessionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Retrieves the system logs for an interactive session.
 */
export declare const getSystemLogsForSession: API.OperationMethod<GetSystemLogsForSessionRequest & RegionInput, GetSystemLogsForSessionResponse, GetSystemLogsForSessionError, Credentials | HttpClient.HttpClient>;
export type GetTableError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | CommonErrors;
/**
 * Retrieves the `Table` definition in a Data Catalog for
 * a specified table.
 */
export declare const getTable: API.OperationMethod<GetTableRequest & RegionInput, GetTableResponse, GetTableError, Credentials | HttpClient.HttpClient>;
export type GetTableOptimizerError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Returns the configuration of all optimizers associated with a specified table.
 */
export declare const getTableOptimizer: API.OperationMethod<GetTableOptimizerRequest & RegionInput, GetTableOptimizerResponse, GetTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type GetTablesError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the definitions of some or all of the tables in a given
 * `Database`.
 */
export declare const getTables: API.PaginatedOperationMethod<GetTablesRequest & RegionInput, GetTablesResponse, GetTablesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTableVersionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specified version of a table.
 */
export declare const getTableVersion: API.OperationMethod<GetTableVersionRequest & RegionInput, GetTableVersionResponse, GetTableVersionError, Credentials | HttpClient.HttpClient>;
export type GetTableVersionsError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of strings that identify available versions of
 * a specified table.
 */
export declare const getTableVersions: API.PaginatedOperationMethod<GetTableVersionsRequest & RegionInput, GetTableVersionsResponse, GetTableVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTagsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of tags associated with a resource.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest & RegionInput, GetTagsResponse, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetTriggerError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the definition of a trigger.
 */
export declare const getTrigger: API.OperationMethod<GetTriggerRequest & RegionInput, GetTriggerResponse, GetTriggerError, Credentials | HttpClient.HttpClient>;
export type GetTriggersError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets all the triggers associated with a job.
 */
export declare const getTriggers: API.PaginatedOperationMethod<GetTriggersRequest & RegionInput, GetTriggersResponse, GetTriggersError, Credentials | HttpClient.HttpClient, Trigger>;
export type GetUnfilteredPartitionMetadataError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | PermissionTypeMismatchException | CommonErrors;
/**
 * Retrieves partition metadata from the Data Catalog that contains unfiltered
 * metadata.
 *
 * For IAM authorization, the public IAM action associated with this API is `glue:GetPartition`.
 */
export declare const getUnfilteredPartitionMetadata: API.OperationMethod<GetUnfilteredPartitionMetadataRequest & RegionInput, GetUnfilteredPartitionMetadataResponse, GetUnfilteredPartitionMetadataError, Credentials | HttpClient.HttpClient>;
export type GetUnfilteredPartitionsMetadataError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | PermissionTypeMismatchException | CommonErrors;
/**
 * Retrieves partition metadata from the Data Catalog that contains unfiltered
 * metadata.
 *
 * For IAM authorization, the public IAM action associated with this API is `glue:GetPartitions`.
 */
export declare const getUnfilteredPartitionsMetadata: API.PaginatedOperationMethod<GetUnfilteredPartitionsMetadataRequest & RegionInput, GetUnfilteredPartitionsMetadataResponse, GetUnfilteredPartitionsMetadataError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUnfilteredTableMetadataError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | PermissionTypeMismatchException | CommonErrors;
/**
 * Allows a third-party analytical engine to retrieve unfiltered table metadata from the Data Catalog.
 *
 * For IAM authorization, the public IAM action associated with this API is `glue:GetTable`.
 */
export declare const getUnfilteredTableMetadata: API.OperationMethod<GetUnfilteredTableMetadataRequest & RegionInput, GetUnfilteredTableMetadataResponse, GetUnfilteredTableMetadataError, Credentials | HttpClient.HttpClient>;
export type GetUsageProfileError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about the specified Glue usage profile.
 */
export declare const getUsageProfile: API.OperationMethod<GetUsageProfileRequest & RegionInput, GetUsageProfileResponse, GetUsageProfileError, Credentials | HttpClient.HttpClient>;
export type GetUserDefinedFunctionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specified function definition from the Data Catalog.
 */
export declare const getUserDefinedFunction: API.OperationMethod<GetUserDefinedFunctionRequest & RegionInput, GetUserDefinedFunctionResponse, GetUserDefinedFunctionError, Credentials | HttpClient.HttpClient>;
export type GetUserDefinedFunctionsError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves multiple function definitions from the Data Catalog.
 */
export declare const getUserDefinedFunctions: API.PaginatedOperationMethod<GetUserDefinedFunctionsRequest & RegionInput, GetUserDefinedFunctionsResponse, GetUserDefinedFunctionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetWorkflowError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves resource metadata for a workflow.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest & RegionInput, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the metadata for a given workflow run. Job run history is accessible for 90 days for your workflow and job run.
 */
export declare const getWorkflowRun: API.OperationMethod<GetWorkflowRunRequest & RegionInput, GetWorkflowRunResponse, GetWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunPropertiesError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the workflow run properties which were set during the run.
 */
export declare const getWorkflowRunProperties: API.OperationMethod<GetWorkflowRunPropertiesRequest & RegionInput, GetWorkflowRunPropertiesResponse, GetWorkflowRunPropertiesError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves metadata for all runs of a given workflow.
 */
export declare const getWorkflowRuns: API.PaginatedOperationMethod<GetWorkflowRunsRequest & RegionInput, GetWorkflowRunsResponse, GetWorkflowRunsError, Credentials | HttpClient.HttpClient, WorkflowRun>;
export type ImportCatalogToGlueError = InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Imports an existing Amazon Athena Data Catalog to Glue.
 */
export declare const importCatalogToGlue: API.OperationMethod<ImportCatalogToGlueRequest & RegionInput, ImportCatalogToGlueResponse, ImportCatalogToGlueError, Credentials | HttpClient.HttpClient>;
export type ListAssetTypesError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists the asset types defined in Glue Data Catalog.
 */
export declare const listAssetTypes: API.PaginatedOperationMethod<ListAssetTypesRequest & RegionInput, ListAssetTypesResponse, ListAssetTypesError, Credentials | HttpClient.HttpClient, AssetTypeItem>;
export type ListBlueprintsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists all the blueprint names in an account.
 */
export declare const listBlueprints: API.PaginatedOperationMethod<ListBlueprintsRequest & RegionInput, ListBlueprintsResponse, ListBlueprintsError, Credentials | HttpClient.HttpClient, OrchestrationNameString>;
export type ListColumnStatisticsTaskRunsError = OperationTimeoutException | CommonErrors;
/**
 * List all task runs for a particular account.
 */
export declare const listColumnStatisticsTaskRuns: API.PaginatedOperationMethod<ListColumnStatisticsTaskRunsRequest & RegionInput, ListColumnStatisticsTaskRunsResponse, ListColumnStatisticsTaskRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConnectionTypesError = AccessDeniedException | InternalServiceException | CommonErrors;
/**
 * The `ListConnectionTypes` API provides a discovery mechanism to learn available connection types in Glue. The response contains a list of connection types with high-level details of what is supported for each connection type, including both built-in connection types and custom connection types registered via `RegisterConnectionType`. The connection types listed are the set of supported options for the `ConnectionType` value in the `CreateConnection` API.
 *
 * See also: `DescribeConnectionType`, `RegisterConnectionType`, `DeleteConnectionType`
 */
export declare const listConnectionTypes: API.PaginatedOperationMethod<ListConnectionTypesRequest & RegionInput, ListConnectionTypesResponse, ListConnectionTypesError, Credentials | HttpClient.HttpClient, ConnectionTypeBrief>;
export type ListCrawlersError = OperationTimeoutException | CommonErrors;
/**
 * Retrieves the names of all crawler resources in this Amazon Web Services account, or the
 * resources with the specified tag. This operation allows you to see which
 * resources are available in your account, and their names.
 *
 * This operation takes the optional `Tags` field, which you can use as a filter on
 * the response so that tagged resources can be retrieved as a group. If you choose to use tags
 * filtering, only resources with the tag are retrieved.
 */
export declare const listCrawlers: API.PaginatedOperationMethod<ListCrawlersRequest & RegionInput, ListCrawlersResponse, ListCrawlersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCrawlsError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns all the crawls of a specified crawler. Returns only the crawls that have occurred since the launch date of the crawler history feature, and only retains up to 12 months of crawls. Older crawls will not be returned.
 *
 * You may use this API to:
 *
 * - Retrive all the crawls of a specified crawler.
 *
 * - Retrieve all the crawls of a specified crawler within a limited count.
 *
 * - Retrieve all the crawls of a specified crawler in a specific time range.
 *
 * - Retrieve all the crawls of a specified crawler with a particular state, crawl ID, or DPU hour value.
 */
export declare const listCrawls: API.OperationMethod<ListCrawlsRequest & RegionInput, ListCrawlsResponse, ListCrawlsError, Credentials | HttpClient.HttpClient>;
export type ListCustomEntityTypesError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists all the custom patterns that have been created.
 */
export declare const listCustomEntityTypes: API.PaginatedOperationMethod<ListCustomEntityTypesRequest & RegionInput, ListCustomEntityTypesResponse, ListCustomEntityTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityEvaluationConfigsError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists the data quality evaluation configurations in your account, optionally filtered by level.
 */
export declare const listDataQualityEvaluationConfigs: API.PaginatedOperationMethod<ListDataQualityEvaluationConfigsRequest & RegionInput, ListDataQualityEvaluationConfigsResponse, ListDataQualityEvaluationConfigsError, Credentials | HttpClient.HttpClient, DataQualityEvaluationConfigListDetails>;
export type ListDataQualityResultsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns all data quality execution results for your account.
 */
export declare const listDataQualityResults: API.PaginatedOperationMethod<ListDataQualityResultsRequest & RegionInput, ListDataQualityResultsResponse, ListDataQualityResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityResultsV2Error = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a paginated list of data quality execution results for your account, filtered by the specified criteria. Use the `NextToken` parameter to retrieve additional results.
 */
export declare const listDataQualityResultsV2: API.PaginatedOperationMethod<ListDataQualityResultsV2Request & RegionInput, ListDataQualityResultsV2Response, ListDataQualityResultsV2Error, Credentials | HttpClient.HttpClient, DataQualityResultsV2Description>;
export type ListDataQualityRuleRecommendationRunsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists the recommendation runs meeting the filter criteria.
 */
export declare const listDataQualityRuleRecommendationRuns: API.PaginatedOperationMethod<ListDataQualityRuleRecommendationRunsRequest & RegionInput, ListDataQualityRuleRecommendationRunsResponse, ListDataQualityRuleRecommendationRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityRulesetEvaluationRunsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists all the runs meeting the filter criteria, where a ruleset is evaluated against a data source.
 */
export declare const listDataQualityRulesetEvaluationRuns: API.PaginatedOperationMethod<ListDataQualityRulesetEvaluationRunsRequest & RegionInput, ListDataQualityRulesetEvaluationRunsResponse, ListDataQualityRulesetEvaluationRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityRulesetsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a paginated list of rulesets for the specified list of Glue tables.
 */
export declare const listDataQualityRulesets: API.PaginatedOperationMethod<ListDataQualityRulesetsRequest & RegionInput, ListDataQualityRulesetsResponse, ListDataQualityRulesetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityStatisticAnnotationsError = InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Retrieve annotations for a data quality statistic.
 */
export declare const listDataQualityStatisticAnnotations: API.OperationMethod<ListDataQualityStatisticAnnotationsRequest & RegionInput, ListDataQualityStatisticAnnotationsResponse, ListDataQualityStatisticAnnotationsError, Credentials | HttpClient.HttpClient>;
export type ListDataQualityStatisticsError = EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Retrieves a list of data quality statistics.
 */
export declare const listDataQualityStatistics: API.OperationMethod<ListDataQualityStatisticsRequest & RegionInput, ListDataQualityStatisticsResponse, ListDataQualityStatisticsError, Credentials | HttpClient.HttpClient>;
export type ListDevEndpointsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the names of all `DevEndpoint` resources in this Amazon Web Services account, or the
 * resources with the specified tag. This operation allows you to see which resources are
 * available in your account, and their names.
 *
 * This operation takes the optional `Tags` field, which you can use as a filter on
 * the response so that tagged resources can be retrieved as a group. If you choose to use tags
 * filtering, only resources with the tag are retrieved.
 */
export declare const listDevEndpoints: API.PaginatedOperationMethod<ListDevEndpointsRequest & RegionInput, ListDevEndpointsResponse, ListDevEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntitiesError = AccessDeniedException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Returns the available entities supported by the connection type.
 */
export declare const listEntities: API.PaginatedOperationMethod<ListEntitiesRequest & RegionInput, ListEntitiesResponse, ListEntitiesError, Credentials | HttpClient.HttpClient, Entity>;
export type ListFormTypesError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists the form types defined in Glue Data Catalog.
 */
export declare const listFormTypes: API.PaginatedOperationMethod<ListFormTypesRequest & RegionInput, ListFormTypesResponse, ListFormTypesError, Credentials | HttpClient.HttpClient, FormTypeItem>;
export type ListGlossariesError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists business glossaries in Glue Data Catalog.
 */
export declare const listGlossaries: API.PaginatedOperationMethod<ListGlossariesRequest & RegionInput, ListGlossariesResponse, ListGlossariesError, Credentials | HttpClient.HttpClient, GlossaryItem>;
export type ListGlossaryTermsError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists glossary terms within a business glossary in Glue Data Catalog.
 */
export declare const listGlossaryTerms: API.PaginatedOperationMethod<ListGlossaryTermsRequest & RegionInput, ListGlossaryTermsResponse, ListGlossaryTermsError, Credentials | HttpClient.HttpClient, GlossaryTermItem>;
export type ListIntegrationResourcePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List integration resource properties for a single customer. It supports the filters, maxRecords and markers.
 */
export declare const listIntegrationResourceProperties: API.OperationMethod<ListIntegrationResourcePropertiesRequest & RegionInput, ListIntegrationResourcePropertiesResponse, ListIntegrationResourcePropertiesError, Credentials | HttpClient.HttpClient>;
export type ListIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the integration table properties in your account. This operation supports filtering and pagination.
 */
export declare const listIntegrationTableProperties: API.OperationMethod<ListIntegrationTablePropertiesRequest & RegionInput, ListIntegrationTablePropertiesResponse, ListIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type ListIterableFormsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists the items in an iterable form on an asset in Glue Data Catalog. For example, lists the columns of a table asset.
 */
export declare const listIterableForms: API.PaginatedOperationMethod<ListIterableFormsRequest & RegionInput, ListIterableFormsResponse, ListIterableFormsError, Credentials | HttpClient.HttpClient, IterableFormListItem>;
export type ListJobsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the names of all job resources in this Amazon Web Services account, or the resources with the specified tag. This operation allows you to see which resources are available in your account, and their names.
 *
 * This operation takes the optional `Tags` field, which you can use as a filter on
 * the response so that tagged resources can be retrieved as a group. If you choose to use tags
 * filtering, only resources with the tag are retrieved.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest & RegionInput, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, NameString>;
export type ListMaterializedViewRefreshTaskRunsError = AccessDeniedException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * List all task runs for a particular account.
 */
export declare const listMaterializedViewRefreshTaskRuns: API.PaginatedOperationMethod<ListMaterializedViewRefreshTaskRunsRequest & RegionInput, ListMaterializedViewRefreshTaskRunsResponse, ListMaterializedViewRefreshTaskRunsError, Credentials | HttpClient.HttpClient, MaterializedViewRefreshTaskRun>;
export type ListMLTransformsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a sortable, filterable list of existing Glue machine learning transforms in this Amazon Web Services account,
 * or the resources with the specified tag. This operation takes the optional `Tags` field, which you can use as
 * a filter of the responses so that tagged resources can be retrieved as a group. If you choose to use tag
 * filtering, only resources with the tags are retrieved.
 */
export declare const listMLTransforms: API.PaginatedOperationMethod<ListMLTransformsRequest & RegionInput, ListMLTransformsResponse, ListMLTransformsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRegistriesError = AccessDeniedException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Returns a list of registries that you have created, with minimal registry information. Registries in the `Deleting` status will not be included in the results. Empty results will be returned if there are no registries available.
 */
export declare const listRegistries: API.PaginatedOperationMethod<ListRegistriesInput & RegionInput, ListRegistriesResponse, ListRegistriesError, Credentials | HttpClient.HttpClient, RegistryListItem>;
export type ListSchemasError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Returns a list of schemas with minimal details. Schemas in Deleting status will not be included in the results. Empty results will be returned if there are no schemas available.
 *
 * When the `RegistryId` is not provided, all the schemas across registries will be part of the API response.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasInput & RegionInput, ListSchemasResponse, ListSchemasError, Credentials | HttpClient.HttpClient, SchemaListItem>;
export type ListSchemaVersionsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Returns a list of schema versions that you have created, with minimal information. Schema versions in Deleted status will not be included in the results. Empty results will be returned if there are no schema versions available.
 */
export declare const listSchemaVersions: API.PaginatedOperationMethod<ListSchemaVersionsInput & RegionInput, ListSchemaVersionsResponse, ListSchemaVersionsError, Credentials | HttpClient.HttpClient, SchemaVersionListItem>;
export type ListSessionsError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieve a list of sessions.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest & RegionInput, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStatementsError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists statements for the session.
 */
export declare const listStatements: API.OperationMethod<ListStatementsRequest & RegionInput, ListStatementsResponse, ListStatementsError, Credentials | HttpClient.HttpClient>;
export type ListTableOptimizerRunsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the history of previous optimizer runs for a specific table.
 */
export declare const listTableOptimizerRuns: API.PaginatedOperationMethod<ListTableOptimizerRunsRequest & RegionInput, ListTableOptimizerRunsResponse, ListTableOptimizerRunsError, Credentials | HttpClient.HttpClient, TableOptimizerRun>;
export type ListTriggersError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the names of all trigger resources in this Amazon Web Services account, or the resources with the specified tag. This operation allows you to see which resources are available in your account, and their names.
 *
 * This operation takes the optional `Tags` field, which you can use as a filter on
 * the response so that tagged resources can be retrieved as a group. If you choose to use tags
 * filtering, only resources with the tag are retrieved.
 */
export declare const listTriggers: API.PaginatedOperationMethod<ListTriggersRequest & RegionInput, ListTriggersResponse, ListTriggersError, Credentials | HttpClient.HttpClient, NameString>;
export type ListUsageProfilesError = InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * List all the Glue usage profiles.
 */
export declare const listUsageProfiles: API.PaginatedOperationMethod<ListUsageProfilesRequest & RegionInput, ListUsageProfilesResponse, ListUsageProfilesError, Credentials | HttpClient.HttpClient, UsageProfileDefinition>;
export type ListWorkflowsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists names of workflows created in the account.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest & RegionInput, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, NameString>;
export type ModifyIntegrationError = AccessDeniedException | ConflictException | EntityNotFoundException | IntegrationConflictOperationFault | IntegrationNotFoundFault | InternalServerException | InternalServiceException | InvalidInputException | InvalidIntegrationStateFault | InvalidStateException | ValidationException | CommonErrors;
/**
 * Modifies a Zero-ETL integration in the caller's account.
 */
export declare const modifyIntegration: API.OperationMethod<ModifyIntegrationRequest & RegionInput, ModifyIntegrationResponse, ModifyIntegrationError, Credentials | HttpClient.HttpClient>;
export type PublishDataQualityResultV2Error = IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * This operation is intended for internal use. Do not call it directly.
 *
 * AWS Glue Data Quality uses this operation to publish a data quality result.
 */
export declare const publishDataQualityResultV2: API.OperationMethod<PublishDataQualityResultV2Request & RegionInput, PublishDataQualityResultV2Response, PublishDataQualityResultV2Error, Credentials | HttpClient.HttpClient>;
export type PutAssetError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates or updates an asset in Glue Data Catalog. If the asset already exists, this operation updates it; otherwise, a new asset is created.
 */
export declare const putAsset: API.OperationMethod<PutAssetRequest & RegionInput, PutAssetResponse, PutAssetError, Credentials | HttpClient.HttpClient>;
export type PutAssetTypeError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates or updates an asset type in Glue Data Catalog. An asset type defines the structure of assets by specifying which forms they include. If an asset type with the given name already exists, it is updated.
 */
export declare const putAssetType: API.OperationMethod<PutAssetTypeRequest & RegionInput, PutAssetTypeResponse, PutAssetTypeError, Credentials | HttpClient.HttpClient>;
export type PutAttachmentError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Attaches a form to an asset or an iterable form item in Glue Data Catalog. If an attachment with the same name already exists, it is overwritten.
 */
export declare const putAttachment: API.OperationMethod<PutAttachmentRequest & RegionInput, PutAttachmentResponse, PutAttachmentError, Credentials | HttpClient.HttpClient>;
export type PutDataCatalogEncryptionSettingsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Sets the security configuration for a specified catalog. After the configuration has been
 * set, the specified encryption is applied to every catalog write thereafter.
 */
export declare const putDataCatalogEncryptionSettings: API.OperationMethod<PutDataCatalogEncryptionSettingsRequest & RegionInput, PutDataCatalogEncryptionSettingsResponse, PutDataCatalogEncryptionSettingsError, Credentials | HttpClient.HttpClient>;
export type PutDataCatalogExportConfigurationError = AccessDeniedException | ConflictException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates or updates the export configuration for the Glue Data Catalog. Use this operation to enable or disable the export of catalog metadata to S3 Tables.
 */
export declare const putDataCatalogExportConfiguration: API.OperationMethod<PutDataCatalogExportConfigurationInput & RegionInput, PutDataCatalogExportConfigurationOutput, PutDataCatalogExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutDataQualityProfileAnnotationError = EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Annotate all datapoints for a Profile.
 */
export declare const putDataQualityProfileAnnotation: API.OperationMethod<PutDataQualityProfileAnnotationRequest & RegionInput, PutDataQualityProfileAnnotationResponse, PutDataQualityProfileAnnotationError, Credentials | HttpClient.HttpClient>;
export type PutFormTypeError = AccessDeniedException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates or updates a form type in Glue Data Catalog. A form type defines the schema for structured metadata that can be attached to assets.
 */
export declare const putFormType: API.OperationMethod<PutFormTypeRequest & RegionInput, PutFormTypeResponse, PutFormTypeError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = ConditionCheckFailureException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Sets the Data Catalog resource policy for access control.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutSchemaVersionMetadataError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Puts the metadata key value pair for a specified schema version ID. A maximum of 10 key value pairs will be allowed per schema version. They can be added over one or more calls.
 */
export declare const putSchemaVersionMetadata: API.OperationMethod<PutSchemaVersionMetadataInput & RegionInput, PutSchemaVersionMetadataResponse, PutSchemaVersionMetadataError, Credentials | HttpClient.HttpClient>;
export type PutWorkflowRunPropertiesError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Puts the specified workflow run properties for the given workflow run. If a property already exists for the specified run, then it overrides the value otherwise adds the property to existing properties.
 */
export declare const putWorkflowRunProperties: API.OperationMethod<PutWorkflowRunPropertiesRequest & RegionInput, PutWorkflowRunPropertiesResponse, PutWorkflowRunPropertiesError, Credentials | HttpClient.HttpClient>;
export type QuerySchemaVersionMetadataError = AccessDeniedException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Queries for the schema version metadata information.
 */
export declare const querySchemaVersionMetadata: API.OperationMethod<QuerySchemaVersionMetadataInput & RegionInput, QuerySchemaVersionMetadataResponse, QuerySchemaVersionMetadataError, Credentials | HttpClient.HttpClient>;
export type RegisterConnectionTypeError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Registers a custom connection type in Glue based on the configuration provided. This operation enables customers to configure custom connectors for any data source with REST-based APIs, eliminating the need for building custom Lambda connectors.
 *
 * The registered connection type stores details about how requests and responses are interpreted by REST sources, including connection properties, authentication configuration, and REST configuration with entity definitions. Once registered, customers can create connections using this connection type and work with them the same way as natively supported Glue connectors.
 *
 * Supports multiple authentication types including Basic, OAuth2 (Client Credentials, JWT Bearer, Authorization Code), and Custom Auth configurations.
 */
export declare const registerConnectionType: API.OperationMethod<RegisterConnectionTypeRequest & RegionInput, RegisterConnectionTypeResponse, RegisterConnectionTypeError, Credentials | HttpClient.HttpClient>;
export type RegisterSchemaVersionError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Adds a new version to the existing schema. Returns an error if new version of schema does not meet the compatibility requirements of the schema set. This API will not create a new schema set and will return a 404 error if the schema set is not already present in the Schema Registry.
 *
 * If this is the first schema definition to be registered in the Schema Registry, this API will store the schema version and return immediately. Otherwise, this call has the potential to run longer than other operations due to compatibility modes. You can call the `GetSchemaVersion` API with the `SchemaVersionId` to check compatibility modes.
 *
 * If the same schema definition is already stored in Schema Registry as a version, the schema ID of the existing schema is returned to the caller.
 */
export declare const registerSchemaVersion: API.OperationMethod<RegisterSchemaVersionInput & RegionInput, RegisterSchemaVersionResponse, RegisterSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type RemoveSchemaVersionMetadataError = AccessDeniedException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Removes a key value pair from the schema version metadata for the specified schema version ID.
 */
export declare const removeSchemaVersionMetadata: API.OperationMethod<RemoveSchemaVersionMetadataInput & RegionInput, RemoveSchemaVersionMetadataResponse, RemoveSchemaVersionMetadataError, Credentials | HttpClient.HttpClient>;
export type ResetJobBookmarkError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Resets a bookmark entry.
 *
 * For more information about enabling and using job bookmarks, see:
 *
 * - Tracking processed data using job bookmarks
 *
 * - Job parameters used by Glue
 *
 * - Job structure
 */
export declare const resetJobBookmark: API.OperationMethod<ResetJobBookmarkRequest & RegionInput, ResetJobBookmarkResponse, ResetJobBookmarkError, Credentials | HttpClient.HttpClient>;
export type ResumeWorkflowRunError = ConcurrentRunsExceededException | EntityNotFoundException | IllegalWorkflowStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Restarts selected nodes of a previous partially completed workflow run and resumes the workflow run. The selected nodes and all nodes that are downstream from the selected nodes are run.
 */
export declare const resumeWorkflowRun: API.OperationMethod<ResumeWorkflowRunRequest & RegionInput, ResumeWorkflowRunResponse, ResumeWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type RunStatementError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | ResourceNumberLimitExceededException | SessionBusyException | ValidationException | CommonErrors;
/**
 * Executes the statement.
 */
export declare const runStatement: API.OperationMethod<RunStatementRequest & RegionInput, RunStatementResponse, RunStatementError, Credentials | HttpClient.HttpClient>;
export type SearchAssetsError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Searches for assets in Glue Data Catalog using full-text search, filters, sorting, and aggregations. Returns matching assets with relevance-ranked results.
 */
export declare const searchAssets: API.PaginatedOperationMethod<SearchAssetsInput & RegionInput, SearchAssetsOutput, SearchAssetsError, Credentials | HttpClient.HttpClient, SearchResultItem>;
export type SearchTablesError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Searches a set of tables based on properties in the table metadata as well as on the parent database. You can search against text or filter conditions.
 *
 * You can only get tables that you have access to based on the security policies defined in Lake Formation. You need at least a read-only access to the table for it to be returned. If you do not have access to all the columns in the table, these columns will not be searched against when returning the list of tables back to you. If you have access to the columns but not the data in the columns, those columns and the associated metadata for those columns will be included in the search.
 */
export declare const searchTables: API.PaginatedOperationMethod<SearchTablesRequest & RegionInput, SearchTablesResponse, SearchTablesError, Credentials | HttpClient.HttpClient, unknown>;
export type StartBlueprintRunError = EntityNotFoundException | IllegalBlueprintStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts a new run of the specified blueprint.
 */
export declare const startBlueprintRun: API.OperationMethod<StartBlueprintRunRequest & RegionInput, StartBlueprintRunResponse, StartBlueprintRunError, Credentials | HttpClient.HttpClient>;
export type StartColumnStatisticsTaskRunError = AccessDeniedException | ColumnStatisticsTaskRunningException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts a column statistics task run, for a specified table and columns.
 */
export declare const startColumnStatisticsTaskRun: API.OperationMethod<StartColumnStatisticsTaskRunRequest & RegionInput, StartColumnStatisticsTaskRunResponse, StartColumnStatisticsTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartColumnStatisticsTaskRunScheduleError = AccessDeniedException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Starts a column statistics task run schedule.
 */
export declare const startColumnStatisticsTaskRunSchedule: API.OperationMethod<StartColumnStatisticsTaskRunScheduleRequest & RegionInput, StartColumnStatisticsTaskRunScheduleResponse, StartColumnStatisticsTaskRunScheduleError, Credentials | HttpClient.HttpClient>;
export type StartCrawlerError = CrawlerRunningException | EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Starts a crawl using the specified crawler, regardless
 * of what is scheduled. If the crawler is already running, returns a
 * CrawlerRunningException.
 */
export declare const startCrawler: API.OperationMethod<StartCrawlerRequest & RegionInput, StartCrawlerResponse, StartCrawlerError, Credentials | HttpClient.HttpClient>;
export type StartCrawlerScheduleError = EntityNotFoundException | NoScheduleException | OperationTimeoutException | SchedulerRunningException | SchedulerTransitioningException | CommonErrors;
/**
 * Changes the schedule state of the specified crawler to
 * `SCHEDULED`, unless the crawler is already running or the
 * schedule state is already `SCHEDULED`.
 */
export declare const startCrawlerSchedule: API.OperationMethod<StartCrawlerScheduleRequest & RegionInput, StartCrawlerScheduleResponse, StartCrawlerScheduleError, Credentials | HttpClient.HttpClient>;
export type StartDataQualityRuleRecommendationRunError = ConflictException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Starts a recommendation run that is used to generate rules when you don't know what rules to write. Glue Data Quality analyzes the data and comes up with recommendations for a potential ruleset. You can then triage the ruleset and modify the generated ruleset to your liking.
 *
 * Recommendation runs are automatically deleted after 90 days.
 */
export declare const startDataQualityRuleRecommendationRun: API.OperationMethod<StartDataQualityRuleRecommendationRunRequest & RegionInput, StartDataQualityRuleRecommendationRunResponse, StartDataQualityRuleRecommendationRunError, Credentials | HttpClient.HttpClient>;
export type StartDataQualityRulesetEvaluationRunError = ConflictException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Once you have a ruleset definition (either recommended or your own), you call this operation to evaluate the ruleset against a data source (Glue table). The evaluation computes results which you can retrieve with the `GetDataQualityResult` API.
 */
export declare const startDataQualityRulesetEvaluationRun: API.OperationMethod<StartDataQualityRulesetEvaluationRunRequest & RegionInput, StartDataQualityRulesetEvaluationRunResponse, StartDataQualityRulesetEvaluationRunError, Credentials | HttpClient.HttpClient>;
export type StartExportLabelsTaskRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Begins an asynchronous task to export all labeled data for a particular transform. This
 * task is the only label-related API call that is not part of the typical active learning
 * workflow. You typically use `StartExportLabelsTaskRun` when you want to work with
 * all of your existing labels at the same time, such as when you want to remove or change labels
 * that were previously submitted as truth. This API operation accepts the
 * `TransformId` whose labels you want to export and an Amazon Simple Storage
 * Service (Amazon S3) path to export the labels to. The operation returns a
 * `TaskRunId`. You can check on the status of your task run by calling the
 * `GetMLTaskRun` API.
 */
export declare const startExportLabelsTaskRun: API.OperationMethod<StartExportLabelsTaskRunRequest & RegionInput, StartExportLabelsTaskRunResponse, StartExportLabelsTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartImportLabelsTaskRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Enables you to provide additional labels (examples of truth) to be used to teach the
 * machine learning transform and improve its quality. This API operation is generally used as
 * part of the active learning workflow that starts with the
 * `StartMLLabelingSetGenerationTaskRun` call and that ultimately results in
 * improving the quality of your machine learning transform.
 *
 * After the `StartMLLabelingSetGenerationTaskRun` finishes, Glue machine learning
 * will have generated a series of questions for humans to answer. (Answering these questions is
 * often called 'labeling' in the machine learning workflows). In the case of the
 * `FindMatches` transform, these questions are of the form, "What is the correct
 * way to group these rows together into groups composed entirely of matching records?" After the
 * labeling process is finished, users upload their answers/labels with a call to
 * `StartImportLabelsTaskRun`. After `StartImportLabelsTaskRun` finishes,
 * all future runs of the machine learning transform use the new and improved labels and perform
 * a higher-quality transformation.
 *
 * By default, `StartMLLabelingSetGenerationTaskRun` continually learns from and
 * combines all labels that you upload unless you set `Replace` to true. If you set
 * `Replace` to true, `StartImportLabelsTaskRun` deletes and forgets all
 * previously uploaded labels and learns only from the exact set that you upload. Replacing
 * labels can be helpful if you realize that you previously uploaded incorrect labels, and you
 * believe that they are having a negative effect on your transform quality.
 *
 * You can check on the status of your task run by calling the `GetMLTaskRun`
 * operation.
 */
export declare const startImportLabelsTaskRun: API.OperationMethod<StartImportLabelsTaskRunRequest & RegionInput, StartImportLabelsTaskRunResponse, StartImportLabelsTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartJobRunError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | GlueRoleNotAssumable | CommonErrors;
/**
 * Starts a job run using a job definition.
 */
export declare const startJobRun: API.OperationMethod<StartJobRunRequest & RegionInput, StartJobRunResponse, StartJobRunError, Credentials | HttpClient.HttpClient>;
export type StartJobUpgradeAnalysisError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Resumes an analysis that is waiting for upgrade consent.
 */
export declare const startJobUpgradeAnalysis: API.OperationMethod<StartJobUpgradeAnalysisRequest & RegionInput, StartJobUpgradeAnalysisResponse, StartJobUpgradeAnalysisError, Credentials | HttpClient.HttpClient>;
export type StartMaterializedViewRefreshTaskRunError = AccessDeniedException | EntityNotFoundException | InvalidInputException | MaterializedViewRefreshTaskRunningException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts a materialized view refresh task run for a specified materialized view.
 */
export declare const startMaterializedViewRefreshTaskRun: API.OperationMethod<StartMaterializedViewRefreshTaskRunRequest & RegionInput, StartMaterializedViewRefreshTaskRunResponse, StartMaterializedViewRefreshTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartMLEvaluationTaskRunError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | MLTransformNotReadyException | OperationTimeoutException | CommonErrors;
/**
 * Starts a task to estimate the quality of the transform.
 *
 * When you provide label sets as examples of truth, Glue machine learning uses some of
 * those examples to learn from them. The rest of the labels are used as a test to estimate
 * quality.
 *
 * Returns a unique identifier for the run. You can call `GetMLTaskRun` to get more
 * information about the stats of the `EvaluationTaskRun`.
 */
export declare const startMLEvaluationTaskRun: API.OperationMethod<StartMLEvaluationTaskRunRequest & RegionInput, StartMLEvaluationTaskRunResponse, StartMLEvaluationTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartMLLabelingSetGenerationTaskRunError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Starts the active learning workflow for your machine learning transform to improve the
 * transform's quality by generating label sets and adding labels.
 *
 * When the `StartMLLabelingSetGenerationTaskRun` finishes, Glue will have
 * generated a "labeling set" or a set of questions for humans to answer.
 *
 * In the case of the `FindMatches` transform, these questions are of the form,
 * "What is the correct way to group these rows together into groups composed entirely of
 * matching records?"
 *
 * After the labeling process is finished, you can upload your labels with a call to
 * `StartImportLabelsTaskRun`. After `StartImportLabelsTaskRun` finishes,
 * all future runs of the machine learning transform will use the new and improved labels and
 * perform a higher-quality transformation.
 *
 * Note: The role used to write the generated labeling set to the `OutputS3Path` is the role
 * associated with the Machine Learning Transform, specified in the `CreateMLTransform` API.
 */
export declare const startMLLabelingSetGenerationTaskRun: API.OperationMethod<StartMLLabelingSetGenerationTaskRunRequest & RegionInput, StartMLLabelingSetGenerationTaskRunResponse, StartMLLabelingSetGenerationTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartTriggerError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts an existing trigger. See Triggering
 * Jobs for information about how different types of trigger are
 * started.
 */
export declare const startTrigger: API.OperationMethod<StartTriggerRequest & RegionInput, StartTriggerResponse, StartTriggerError, Credentials | HttpClient.HttpClient>;
export type StartWorkflowRunError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts a new run of the specified workflow.
 */
export declare const startWorkflowRun: API.OperationMethod<StartWorkflowRunRequest & RegionInput, StartWorkflowRunResponse, StartWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type StopColumnStatisticsTaskRunError = ColumnStatisticsTaskNotRunningException | ColumnStatisticsTaskStoppingException | EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Stops a task run for the specified table.
 */
export declare const stopColumnStatisticsTaskRun: API.OperationMethod<StopColumnStatisticsTaskRunRequest & RegionInput, StopColumnStatisticsTaskRunResponse, StopColumnStatisticsTaskRunError, Credentials | HttpClient.HttpClient>;
export type StopColumnStatisticsTaskRunScheduleError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops a column statistics task run schedule.
 */
export declare const stopColumnStatisticsTaskRunSchedule: API.OperationMethod<StopColumnStatisticsTaskRunScheduleRequest & RegionInput, StopColumnStatisticsTaskRunScheduleResponse, StopColumnStatisticsTaskRunScheduleError, Credentials | HttpClient.HttpClient>;
export type StopCrawlerError = CrawlerNotRunningException | CrawlerStoppingException | EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * If the specified crawler is running, stops the crawl.
 */
export declare const stopCrawler: API.OperationMethod<StopCrawlerRequest & RegionInput, StopCrawlerResponse, StopCrawlerError, Credentials | HttpClient.HttpClient>;
export type StopCrawlerScheduleError = EntityNotFoundException | OperationTimeoutException | SchedulerNotRunningException | SchedulerTransitioningException | CommonErrors;
/**
 * Sets the schedule state of the specified crawler to
 * `NOT_SCHEDULED`, but does not stop the crawler if it is
 * already running.
 */
export declare const stopCrawlerSchedule: API.OperationMethod<StopCrawlerScheduleRequest & RegionInput, StopCrawlerScheduleResponse, StopCrawlerScheduleError, Credentials | HttpClient.HttpClient>;
export type StopJobUpgradeAnalysisError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | ThrottlingException | CommonErrors;
/**
 * Stops an in-progress upgrade analysis.
 */
export declare const stopJobUpgradeAnalysis: API.OperationMethod<StopJobUpgradeAnalysisRequest & RegionInput, StopJobUpgradeAnalysisResponse, StopJobUpgradeAnalysisError, Credentials | HttpClient.HttpClient>;
export type StopMaterializedViewRefreshTaskRunError = AccessDeniedException | InvalidInputException | MaterializedViewRefreshTaskNotRunningException | MaterializedViewRefreshTaskStoppingException | OperationTimeoutException | CommonErrors;
/**
 * Stops a materialized view refresh task run for a specified materialized view.
 */
export declare const stopMaterializedViewRefreshTaskRun: API.OperationMethod<StopMaterializedViewRefreshTaskRunRequest & RegionInput, StopMaterializedViewRefreshTaskRunResponse, StopMaterializedViewRefreshTaskRunError, Credentials | HttpClient.HttpClient>;
export type StopSessionError = AccessDeniedException | ConcurrentModificationException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops the session.
 */
export declare const stopSession: API.OperationMethod<StopSessionRequest & RegionInput, StopSessionResponse, StopSessionError, Credentials | HttpClient.HttpClient>;
export type StopTriggerError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops a specified trigger.
 */
export declare const stopTrigger: API.OperationMethod<StopTriggerRequest & RegionInput, StopTriggerResponse, StopTriggerError, Credentials | HttpClient.HttpClient>;
export type StopWorkflowRunError = EntityNotFoundException | IllegalWorkflowStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops the execution of the specified workflow run.
 */
export declare const stopWorkflowRun: API.OperationMethod<StopWorkflowRunRequest & RegionInput, StopWorkflowRunResponse, StopWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Adds tags to a resource. A tag is a label you can assign to an Amazon Web Services resource.
 * In Glue, you can tag only certain resources. For information about what
 * resources you can tag, see Amazon Web Services Tags in Glue.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestConnectionError = AccessDeniedException | ConflictException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Tests a connection to a service to validate the service credentials that you provide.
 *
 * You can either provide an existing connection name or a `TestConnectionInput` for testing a non-existing connection input. Providing both at the same time will cause an error.
 *
 * If the action is successful, the service sends back an HTTP 200 response.
 */
export declare const testConnection: API.OperationMethod<TestConnectionRequest & RegionInput, TestConnectionResponse, TestConnectionError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Updates the name and description of an existing asset in Glue Data Catalog. Only the fields that you provide are updated.
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest & RegionInput, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateBlueprintError = ConcurrentModificationException | EntityNotFoundException | IllegalBlueprintStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a registered blueprint.
 */
export declare const updateBlueprint: API.OperationMethod<UpdateBlueprintRequest & RegionInput, UpdateBlueprintResponse, UpdateBlueprintError, Credentials | HttpClient.HttpClient>;
export type UpdateCatalogError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing catalog's properties in the Glue Data Catalog.
 */
export declare const updateCatalog: API.OperationMethod<UpdateCatalogRequest & RegionInput, UpdateCatalogResponse, UpdateCatalogError, Credentials | HttpClient.HttpClient>;
export type UpdateClassifierError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | VersionMismatchException | CommonErrors;
/**
 * Modifies an existing classifier (a `GrokClassifier`,
 * an `XMLClassifier`, a `JsonClassifier`, or a `CsvClassifier`, depending on
 * which field is present).
 */
export declare const updateClassifier: API.OperationMethod<UpdateClassifierRequest & RegionInput, UpdateClassifierResponse, UpdateClassifierError, Credentials | HttpClient.HttpClient>;
export type UpdateColumnStatisticsForPartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates or updates partition statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `UpdatePartition`.
 */
export declare const updateColumnStatisticsForPartition: API.OperationMethod<UpdateColumnStatisticsForPartitionRequest & RegionInput, UpdateColumnStatisticsForPartitionResponse, UpdateColumnStatisticsForPartitionError, Credentials | HttpClient.HttpClient>;
export type UpdateColumnStatisticsForTableError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates or updates table statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `UpdateTable`.
 */
export declare const updateColumnStatisticsForTable: API.OperationMethod<UpdateColumnStatisticsForTableRequest & RegionInput, UpdateColumnStatisticsForTableResponse, UpdateColumnStatisticsForTableError, Credentials | HttpClient.HttpClient>;
export type UpdateColumnStatisticsTaskSettingsError = AccessDeniedException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | VersionMismatchException | CommonErrors;
/**
 * Updates settings for a column statistics task.
 */
export declare const updateColumnStatisticsTaskSettings: API.OperationMethod<UpdateColumnStatisticsTaskSettingsRequest & RegionInput, UpdateColumnStatisticsTaskSettingsResponse, UpdateColumnStatisticsTaskSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = EntityNotFoundException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a connection definition in the Data Catalog.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionRequest & RegionInput, UpdateConnectionResponse, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateCrawlerError = CrawlerRunningException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | VersionMismatchException | GlueRoleNotAssumable | GlueS3TargetNotReady | CommonErrors;
/**
 * Updates a crawler. If a crawler is
 * running, you must stop it using `StopCrawler` before updating
 * it.
 */
export declare const updateCrawler: API.OperationMethod<UpdateCrawlerRequest & RegionInput, UpdateCrawlerResponse, UpdateCrawlerError, Credentials | HttpClient.HttpClient>;
export type UpdateCrawlerScheduleError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | SchedulerTransitioningException | VersionMismatchException | CommonErrors;
/**
 * Updates the schedule of a crawler using a `cron` expression.
 */
export declare const updateCrawlerSchedule: API.OperationMethod<UpdateCrawlerScheduleRequest & RegionInput, UpdateCrawlerScheduleResponse, UpdateCrawlerScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateDatabaseError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing database definition in a Data Catalog.
 */
export declare const updateDatabase: API.OperationMethod<UpdateDatabaseRequest & RegionInput, UpdateDatabaseResponse, UpdateDatabaseError, Credentials | HttpClient.HttpClient>;
export type UpdateDataQualityEvaluationConfigError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a data quality evaluation configuration. Fields that you don't specify keep their current values.
 */
export declare const updateDataQualityEvaluationConfig: API.OperationMethod<UpdateDataQualityEvaluationConfigRequest & RegionInput, UpdateDataQualityEvaluationConfigResponse, UpdateDataQualityEvaluationConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateDataQualityRulesetError = AlreadyExistsException | EntityNotFoundException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Updates the specified data quality ruleset.
 */
export declare const updateDataQualityRuleset: API.OperationMethod<UpdateDataQualityRulesetRequest & RegionInput, UpdateDataQualityRulesetResponse, UpdateDataQualityRulesetError, Credentials | HttpClient.HttpClient>;
export type UpdateDevEndpointError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Updates a specified development endpoint.
 */
export declare const updateDevEndpoint: API.OperationMethod<UpdateDevEndpointRequest & RegionInput, UpdateDevEndpointResponse, UpdateDevEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateGlossaryError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Updates a business glossary in Glue Data Catalog.
 */
export declare const updateGlossary: API.OperationMethod<UpdateGlossaryRequest & RegionInput, UpdateGlossaryResponse, UpdateGlossaryError, Credentials | HttpClient.HttpClient>;
export type UpdateGlossaryTermError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Updates a glossary term in Glue Data Catalog.
 */
export declare const updateGlossaryTerm: API.OperationMethod<UpdateGlossaryTermRequest & RegionInput, UpdateGlossaryTermResponse, UpdateGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type UpdateGlueIdentityCenterConfigurationError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates the existing Glue Identity Center configuration, allowing modification of scopes and permissions for the integration.
 */
export declare const updateGlueIdentityCenterConfiguration: API.OperationMethod<UpdateGlueIdentityCenterConfigurationRequest & RegionInput, UpdateGlueIdentityCenterConfigurationResponse, UpdateGlueIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationResourcePropertyError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API can be used for updating the `ResourceProperty` of the Glue connection (for the source) or Glue database ARN (for the target). These properties can include the role to access the connection or database. Since the same resource can be used across multiple integrations, updating resource properties will impact all the integrations using it.
 */
export declare const updateIntegrationResourceProperty: API.OperationMethod<UpdateIntegrationResourcePropertyRequest & RegionInput, UpdateIntegrationResourcePropertyResponse, UpdateIntegrationResourcePropertyError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used to provide optional override properties for the tables that need to be replicated. These properties can include properties for filtering and partitioning for the source and target tables. To set both source and target properties the same API need to be invoked with the Glue connection ARN as `ResourceArn` with `SourceTableConfig`, and the Glue database ARN as `ResourceArn` with `TargetTableConfig` respectively.
 *
 * The override will be reflected across all the integrations using same `ResourceArn` and source table.
 */
export declare const updateIntegrationTableProperties: API.OperationMethod<UpdateIntegrationTablePropertiesRequest & RegionInput, UpdateIntegrationTablePropertiesResponse, UpdateIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type UpdateJobError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | GlueRoleNotAssumable | CommonErrors;
/**
 * Updates an existing job definition. The previous job definition is completely overwritten by this information.
 */
export declare const updateJob: API.OperationMethod<UpdateJobRequest & RegionInput, UpdateJobResponse, UpdateJobError, Credentials | HttpClient.HttpClient>;
export type UpdateJobFromSourceControlError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Synchronizes a job from the source control repository. This operation takes the job artifacts that are located in the remote repository and updates the Glue internal stores with these artifacts.
 *
 * This API supports optional parameters which take in the repository information.
 */
export declare const updateJobFromSourceControl: API.OperationMethod<UpdateJobFromSourceControlRequest & RegionInput, UpdateJobFromSourceControlResponse, UpdateJobFromSourceControlError, Credentials | HttpClient.HttpClient>;
export type UpdateMLTransformError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing machine learning transform. Call this operation to tune the algorithm parameters to achieve better results.
 *
 * After calling this operation, you can call the `StartMLEvaluationTaskRun`
 * operation to assess how well your new parameters achieved your goals (such as improving the
 * quality of your machine learning transform, or making it more cost-effective).
 */
export declare const updateMLTransform: API.OperationMethod<UpdateMLTransformRequest & RegionInput, UpdateMLTransformResponse, UpdateMLTransformError, Credentials | HttpClient.HttpClient>;
export type UpdatePartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a partition.
 */
export declare const updatePartition: API.OperationMethod<UpdatePartitionRequest & RegionInput, UpdatePartitionResponse, UpdatePartitionError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Updates an existing registry which is used to hold a collection of schemas. The updated properties relate to the registry, and do not modify any of the schemas within the registry.
 */
export declare const updateRegistry: API.OperationMethod<UpdateRegistryInput & RegionInput, UpdateRegistryResponse, UpdateRegistryError, Credentials | HttpClient.HttpClient>;
export type UpdateSchemaError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Updates the description, compatibility setting, or version checkpoint for a schema set.
 *
 * For updating the compatibility setting, the call will not validate compatibility for the entire set of schema versions with the new compatibility setting. If the value for `Compatibility` is provided, the `VersionNumber` (a checkpoint) is also required. The API will validate the checkpoint version number for consistency.
 *
 * If the value for the `VersionNumber` (checkpoint) is provided, `Compatibility` is optional and this can be used to set/reset a checkpoint for the schema.
 *
 * This update will happen only if the schema is in the AVAILABLE state.
 */
export declare const updateSchema: API.OperationMethod<UpdateSchemaInput & RegionInput, UpdateSchemaResponse, UpdateSchemaError, Credentials | HttpClient.HttpClient>;
export type UpdateSourceControlFromJobError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Synchronizes a job to the source control repository. This operation takes the job artifacts from the Glue internal stores and makes a commit to the remote repository that is configured on the job.
 *
 * This API supports optional parameters which take in the repository information.
 */
export declare const updateSourceControlFromJob: API.OperationMethod<UpdateSourceControlFromJobRequest & RegionInput, UpdateSourceControlFromJobResponse, UpdateSourceControlFromJobError, Credentials | HttpClient.HttpClient>;
export type UpdateTableError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Updates a metadata table in the Data Catalog.
 */
export declare const updateTable: API.OperationMethod<UpdateTableRequest & RegionInput, UpdateTableResponse, UpdateTableError, Credentials | HttpClient.HttpClient>;
export type UpdateTableOptimizerError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration for an existing table optimizer.
 */
export declare const updateTableOptimizer: API.OperationMethod<UpdateTableOptimizerRequest & RegionInput, UpdateTableOptimizerResponse, UpdateTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type UpdateTriggerError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a trigger definition.
 *
 * Job arguments may be logged. Do not pass plaintext secrets as arguments. Retrieve secrets from a Glue Connection, Amazon Web Services Secrets Manager or other secret management mechanism if you intend to keep them within the Job.
 */
export declare const updateTrigger: API.OperationMethod<UpdateTriggerRequest & RegionInput, UpdateTriggerResponse, UpdateTriggerError, Credentials | HttpClient.HttpClient>;
export type UpdateUsageProfileError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * Update an Glue usage profile.
 */
export declare const updateUsageProfile: API.OperationMethod<UpdateUsageProfileRequest & RegionInput, UpdateUsageProfileResponse, UpdateUsageProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateUserDefinedFunctionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing function definition in the Data Catalog.
 */
export declare const updateUserDefinedFunction: API.OperationMethod<UpdateUserDefinedFunctionRequest & RegionInput, UpdateUserDefinedFunctionResponse, UpdateUserDefinedFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing workflow.
 */
export declare const updateWorkflow: API.OperationMethod<UpdateWorkflowRequest & RegionInput, UpdateWorkflowResponse, UpdateWorkflowError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=glue.d.ts.map