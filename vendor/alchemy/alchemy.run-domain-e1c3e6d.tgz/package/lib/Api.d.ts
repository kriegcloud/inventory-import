import type { HttpEffect } from "alchemy/Http";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as Headers from "effect/http/Headers";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Rpc from "effect/rpc/Rpc";
import * as RpcClient from "effect/rpc/RpcClient";
import * as RpcClientError from "effect/rpc/RpcClientError";
import * as RpcGroup from "effect/rpc/RpcGroup";
import type * as RpcMiddleware from "effect/rpc/RpcMiddleware";
import * as Schema from "effect/Schema";
import type * as Scope from "effect/Scope";
import * as Socket from "effect/socket/Socket";
import * as Stream from "effect/Stream";
import type * as Aggregate from "./Aggregate.ts";
import type { Annotations } from "./Annotations.ts";
import * as Command from "./Command.ts";
import { type Filter } from "./Filter.ts";
import * as Key from "./Key.ts";
import * as Middleware from "./Middleware.ts";
import * as Model from "./Model.ts";
import * as Query from "./Query.ts";
import type * as Read from "./Read.ts";
import type * as DomainStream from "./Stream.ts";
import type * as View from "./View.ts";
/**
 * What an Api exposes: commands (writes); views and streams (reads of one
 * key); queries (reads across keys). An aggregate is never read directly: a
 * view projects what clients may see of it.
 */
export type Servable = Command.Any | View.Any | DomainStream.Any | Query.Any;
/** The names of the commands a model holds: their tags. */
export type CommandName<M extends Model.Any> = M["commands"][number]["tag"];
/** The names of the views a model holds. */
export type ViewName<M extends Model.Any> = M["views"][number]["viewName"];
/** The names of the streams a model holds. */
export type StreamName<M extends Model.Any> = M["streams"][number]["streamName"];
/** The names of the queries a model holds. */
export type QueryName<M extends Model.Any> = M["queries"][number]["queryName"];
/**
 * What {@link make} takes: the model, and the names of what of it the Api
 * serves. A kind it does not list is served whole: every command, view,
 * stream and query of the model. `[]` serves none of a kind.
 */
export interface Options<M extends Model.Any, C extends ReadonlyArray<CommandName<M>>, V extends ReadonlyArray<ViewName<M>>, S extends ReadonlyArray<StreamName<M>>, Q extends ReadonlyArray<QueryName<M>> = ReadonlyArray<QueryName<M>>> {
    /** The model the Api is over. */
    readonly model: M;
    /** The commands a client may send. Every command of the model by default. */
    readonly commands?: C;
    /** The views a client may read. Every view of the model by default. */
    readonly views?: V;
    /** The streams a client may read. Every stream of the model by default. */
    readonly streams?: S;
    /** The queries a client may ask. Every query of the model by default. */
    readonly queries?: Q;
}
/** What an Api over `M` serves, from the names it lists. */
export type ServedBy<M extends Model.Any, C extends ReadonlyArray<string>, V extends ReadonlyArray<string>, S extends ReadonlyArray<string>, Q extends ReadonlyArray<string> = ReadonlyArray<string>> = Extract<M["commands"][number], {
    readonly tag: C[number];
}> | Extract<M["views"][number], {
    readonly viewName: V[number];
}> | Extract<M["streams"][number], {
    readonly streamName: S[number];
}> | Extract<M["queries"][number], {
    readonly queryName: Q[number];
}>;
type Commands<E extends Servable> = Extract<E, Command.Any>;
type Views<E extends Servable> = Extract<E, View.Any>;
type Streams<E extends Servable> = Extract<E, DomainStream.Any>;
type Queries<E extends Servable> = Extract<E, Query.Any>;
type ContractOf<D> = D extends Read.AnyContract ? D : never;
type RejectionOf<D> = Aggregate.InstanceOf<NonNullable<ContractOf<D>["rejects"]>[number]>;
type MiddlewareOf<D> = NonNullable<ContractOf<D>["middleware"]>;
/** Everything a read can fail with: the declared rejections, the middleware's errors, transport. */
export type ReadError<D> = RejectionOf<D> | Middleware.Errors<MiddlewareOf<D>> | RpcClientError.RpcClientError;
interface CallOptions {
    readonly headers?: Headers.Input;
}
/** The typed client of a view exposed in an Api. */
export interface ViewClient<V extends View.Any> {
    /** The key's current state (`null` if it does not exist or the filter excludes it). */
    readonly get: (key: Key.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        /**
         * Wait until the view has applied these writes (commands' receipts).
         * Left out, the read waits for the commands this client sent; `[]`
         * waits for nothing.
         */
        readonly atLeast?: Query.AtLeastInput;
        readonly where?: Filter<View.StateOf<V>>;
    }) => Effect.Effect<View.StateOf<V> | null, ReadError<V["definition"]> | View.ConsistencyTimeout>;
    /**
     * The key's state with its cursor, then every change. Ends with a rejection
     * when `validate` stops allowing it.
     */
    readonly watch: (key: Key.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        readonly where?: Filter<View.StateOf<V>>;
    }) => Stream.Stream<Read.Snapshot<View.StateOf<V> | null>, ReadError<V["definition"]>>;
    /**
     * The events the key emitted, each with the state after it: history from
     * `after` (a cursor), a {@link Read.CaughtUp} frame, then live events.
     */
    readonly events: (key: Key.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        readonly after?: number;
        readonly where?: Filter<View.EventOf<V>>;
    }) => Stream.Stream<View.Entry<View.StateOf<V>, View.EventOf<V>, Key.IdOf<View.KeyOf<V>>> | Read.CaughtUp, ReadError<V["definition"]>>;
    /** A page of the key's emitted events. */
    readonly list: (key: Key.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        /**
         * Wait until the view has applied these writes (commands' receipts).
         * Left out, the read waits for the commands this client sent; `[]`
         * waits for nothing.
         */
        readonly atLeast?: Query.AtLeastInput;
        readonly where?: Filter<View.EventOf<V>>;
        readonly order?: "asc" | "desc";
        readonly take?: number;
        readonly after?: number;
    }) => Effect.Effect<View.Page<View.Entry<View.StateOf<V>, View.EventOf<V>, Key.IdOf<View.KeyOf<V>>>>, ReadError<V["definition"]> | View.ConsistencyTimeout>;
    /**
     * The key's state and the cursor it is valid at, read together. Render the
     * state, then follow `events(key, { after: cursor })`: every later change
     * arrives once, and none is missed.
     */
    readonly snapshot: (key: Key.IdOf<View.KeyOf<V>>, options?: CallOptions & {
        /**
         * Wait until the view has applied these writes (commands' receipts).
         * Left out, the read waits for the commands this client sent; `[]`
         * waits for nothing.
         */
        readonly atLeast?: Query.AtLeastInput;
        readonly where?: Filter<View.StateOf<V>>;
    }) => Effect.Effect<Read.Snapshot<View.StateOf<V> | null>, ReadError<V["definition"]> | View.ConsistencyTimeout>;
}
/** The typed client of a stream exposed in an Api. */
export interface StreamClient<S extends DomainStream.Any> {
    /** The key's latest entry, or `null` if nothing was appended. */
    readonly peek: (key: Key.IdOf<DomainStream.KeyOf<S>>, options?: CallOptions & {
        /**
         * Wait until the stream's writers have handled these writes (commands'
         * receipts). Left out, the read waits for the commands this client
         * sent; `[]` waits for nothing.
         */
        readonly atLeast?: Query.AtLeastInput;
    }) => Effect.Effect<DomainStream.Entry<DomainStream.EventOf<S>, Key.IdOf<DomainStream.KeyOf<S>>> | null, ReadError<S["definition"]> | View.ConsistencyTimeout>;
    /**
     * The key's latest entry (`null` before any) with its cursor, then each new
     * one. Ends with a rejection when `validate` stops allowing it.
     */
    readonly watch: (key: Key.IdOf<DomainStream.KeyOf<S>>, options?: CallOptions) => Stream.Stream<Read.Snapshot<DomainStream.Entry<DomainStream.EventOf<S>, Key.IdOf<DomainStream.KeyOf<S>>> | null>, ReadError<S["definition"]>>;
    /** The key's entries from `after` (a cursor), a {@link Read.CaughtUp} frame, then live ones. */
    readonly events: (key: Key.IdOf<DomainStream.KeyOf<S>>, options?: CallOptions & {
        readonly after?: number;
        readonly where?: Filter<DomainStream.EventOf<S>>;
    }) => Stream.Stream<DomainStream.Entry<DomainStream.EventOf<S>, Key.IdOf<DomainStream.KeyOf<S>>> | Read.CaughtUp, ReadError<S["definition"]>>;
    /** A page of the key's entries. */
    readonly list: (key: Key.IdOf<DomainStream.KeyOf<S>>, options?: CallOptions & {
        /**
         * Wait until the stream's writers have handled these writes (commands'
         * receipts). Left out, the read waits for the commands this client
         * sent; `[]` waits for nothing.
         */
        readonly atLeast?: Query.AtLeastInput;
        readonly where?: Filter<DomainStream.EventOf<S>>;
        readonly order?: "asc" | "desc";
        readonly take?: number;
        readonly after?: number;
    }) => Effect.Effect<View.Page<DomainStream.Entry<DomainStream.EventOf<S>, Key.IdOf<DomainStream.KeyOf<S>>>>, ReadError<S["definition"]> | View.ConsistencyTimeout>;
}
/** A committed event of an aggregate, as a client receives it. */
export interface Recorded<E, Id> {
    readonly event: E;
    readonly envelope: Aggregate.Envelope<Id>;
}
/** How a command is sent: its idempotency key and the call's headers. */
export interface CommandOptions extends CallOptions {
    /** A resend with the same id returns the first receipt instead of deciding again. */
    readonly commandId?: string;
    /**
     * When the command answers. `"eventual"` answers as soon as the events are
     * committed. `"strong"` answers once every view its events reach has
     * applied them: any read of a view after the answer includes the command.
     * If a view takes longer than 10 seconds the call fails with
     * `ConsistencyTimeout`, though the command is committed.
     * @default the client's `Domain.DefaultConsistency`, which is `"eventual"`
     */
    readonly consistency?: Command.Consistency;
}
/** A command's input and options. The input may be left out when it has no required field. */
type CommandArgs<Input> = {} extends Input ? [input?: Input, options?: CommandOptions] : [input: Input, options?: CommandOptions];
/** The typed client of a command exposed in an Api: `bank.WithdrawMoney(input, options)`. */
export type CommandClient<C extends Command.Any> = C["rpc"] extends Rpc.Rpc<infer _Tag, infer Payload, infer Success, infer Error, infer Middleware, infer _Requires> ? Payload["Type"] extends {
    readonly input: infer Input;
} ? (...args: CommandArgs<Input>) => Effect.Effect<Success["Type"], Error["Type"] | Middleware["error"]["Type"] | Middleware["~ClientError"] | RpcClientError.RpcClientError, Payload["EncodingServices"] | Success["DecodingServices"] | Error["DecodingServices"] | Middleware["error"]["DecodingServices"]> : never : never;
/**
 * Everything a query can fail with: its rejections, `ConsistencyTimeout` when
 * it has `waitsFor`, its middleware's errors, transport.
 */
export type QueryError<Q extends Query.Any> = Query.FailureOf<Q> | Middleware.Errors<Q["middleware"]> | RpcClientError.RpcClientError;
/** How a client asks a query. */
export interface QueryOptions extends CallOptions {
    /**
     * Wait until the query's projections have handled this write (a
     * command's receipt), or each of these writes, one receipt per command.
     * Left out, the query waits for the commands this client sent; `[]` waits
     * for nothing.
     */
    readonly atLeast?: Query.AtLeastInput;
    /** The cursor of the previous page, for a paged query. */
    readonly after?: string;
    /** Rows per page, for a paged query; capped by the query Layer's `take.max`. */
    readonly take?: number;
}
/** One entry of a paged query's pages. */
export type EntryOf<Q extends Query.Any> = Query.ResultOf<Q> extends Query.Page<infer Row> ? Row : never;
/**
 * The typed client of a query exposed in an Api: one method. A paged query's
 * method also streams its pages (`pages`) or its entries (`entries`), following
 * each cursor until the last page.
 */
export type QueryClient<Q extends Query.Any> = ((input: Query.InputOf<Q>, options?: QueryOptions) => Effect.Effect<Query.ResultOf<Q>, QueryError<Q>>) & (NonNullable<Q["definition"]["paged"]> extends true ? PagedQueryClient<Q> : {});
/** A paged query's Streams. `after` starts mid-way; `atLeast` waits before the first page. */
export interface PagedQueryClient<Q extends Query.Any> {
    /** Every page, from `after` (or the first) to the last. */
    readonly pages: (input: Query.InputOf<Q>, options?: QueryOptions) => Stream.Stream<Query.ResultOf<Q>, QueryError<Q>>;
    /** Every entry of every page, in order. */
    readonly entries: (input: Query.InputOf<Q>, options?: QueryOptions) => Stream.Stream<EntryOf<Q>, QueryError<Q>>;
}
/**
 * The typed client of an Api: commands and queries as methods
 * (`bank.WithdrawMoney(...)`, `bank.AccountLedger(...)`), views and
 * streams as namespaces (`bank.AccountSummary.watch(...)`).
 */
export type ApiClient<E extends Servable> = {
    readonly [C in Commands<E> as C["tag"]]: CommandClient<C>;
} & {
    readonly [Q in Queries<E> as Q["queryName"]]: QueryClient<Q>;
} & {
    readonly [V in Views<E> as V["viewName"]]: ViewClient<V>;
} & {
    readonly [S in Streams<E> as S["streamName"]]: StreamClient<S>;
};
/** Type-level identity of an Api's client service. */
export interface ClientKey<Name extends string> {
    readonly "~alchemy/Domain/Api/Client": Name;
}
/** What `yield* MyApi` gives a Worker: the Api served over HTTP. */
export interface ApiServer {
    /** Use as the Worker's `fetch`. Commands and reads over HTTP; live reads over WebSockets. */
    readonly fetch: HttpEffect;
}
/**
 * The class type returned by {@link make}. The class is itself an Effect:
 * `yield* MyApi` serves it, requiring the hosted Domain and the Layers of every
 * middleware what it serves declares.
 */
export interface ApiClass<Name extends string, Serves extends ReadonlyArray<Servable>> extends Effect.Effect<ApiServer, never, Model.Internals | MiddlewareServices<Serves>> {
    new (_: never): {};
    readonly kind: "Api";
    readonly annotations: Annotations;
    readonly apiName: Name;
    /** The model this Api is over. */
    readonly model: Model.Any;
    /** The commands, views, streams and queries this Api serves. */
    readonly serves: Serves;
    /** The command classes this Api exposes, in the order it lists them. */
    readonly commands: ReadonlyArray<Commands<Serves[number]>>;
    /**
     * One Schema for every rejection this Api's commands declare: a union of the
     * rejection classes, each once, decoding to class instances as the client
     * fails with them. `Schema.Never` when no command rejects.
     */
    readonly rejections: RejectionUnion<Commands<Serves[number]>["rejects"][number]>;
    /** The underlying Effect RPC group. */
    readonly group: RpcGroup.RpcGroup<Rpc.Any>;
    /**
     * A typed client. Provide a protocol: {@link protocolHttp},
     * {@link protocolWebSocket} or {@link protocolInProcess}.
     */
    readonly client: Effect.Effect<ApiClient<Serves[number]>, never, Scope.Scope | RpcClient.Protocol | MiddlewareClients<Serves>>;
    /** The client as a service, for code that uses it without owning the connection. */
    readonly Client: Context.Service<ClientKey<Name>, ApiClient<Serves[number]>>;
    /** Build {@link Client} for the life of the Layer, over the protocol provided to it. */
    readonly layerClient: Layer.Layer<ClientKey<Name>, never, RpcClient.Protocol | MiddlewareClients<Serves>>;
    /** {@link client} over {@link protocolHttp}. */
    readonly clientHttp: (url: string) => Effect.Effect<ApiClient<Serves[number]>, never, Scope.Scope | HttpClient.HttpClient | MiddlewareClients<Serves>>;
    /** {@link layerClient} over {@link protocolHttp}. */
    readonly layerClientHttp: (url: string) => Layer.Layer<ClientKey<Name>, never, HttpClient.HttpClient | MiddlewareClients<Serves>>;
    /** {@link client} over {@link protocolWebSocket}. */
    readonly clientWebSocket: (url: string) => Effect.Effect<ApiClient<Serves[number]>, never, Scope.Scope | HttpClient.HttpClient | Socket.WebSocketConstructor | MiddlewareClients<Serves>>;
    /** {@link layerClient} over {@link protocolWebSocket}. */
    readonly layerClientWebSocket: (url: string) => Layer.Layer<ClientKey<Name>, never, HttpClient.HttpClient | Socket.WebSocketConstructor | MiddlewareClients<Serves>>;
    /** {@link client} over {@link protocolInProcess}. In a Worker, build it per request. */
    readonly clientInProcess: Effect.Effect<ApiClient<Serves[number]>, never, Scope.Scope | Model.Internals | MiddlewareServices<Serves> | MiddlewareClients<Serves>>;
    /** {@link layerClient} over {@link protocolInProcess}. */
    readonly layerClientInProcess: Layer.Layer<ClientKey<Name>, never, Model.Internals | MiddlewareServices<Serves> | MiddlewareClients<Serves>>;
}
type EntryMiddleware<E> = E extends Command.Any | Query.Any ? E["middleware"][number] : E extends View.Any | DomainStream.Any ? NonNullable<E["definition"]["middleware"]>[number] : never;
/** The middleware services the server needs for every entry. */
type MiddlewareServices<Serves extends ReadonlyArray<Servable>> = EntryMiddleware<Serves[number]> extends infer M ? M extends RpcMiddleware.AnyService ? M["Identifier"] : never : never;
/** The client-side middleware every entry needs (e.g. attaching a session token). */
type MiddlewareClients<Serves extends ReadonlyArray<Servable>> = EntryMiddleware<Serves[number]> extends infer M ? M extends RpcMiddleware.AnyService ? M extends {
    readonly requiredForClient: true;
} ? RpcMiddleware.ForClient<M["Identifier"]> : never : never : never;
/**
 * The public surface of a domain for one kind of client: the commands it may
 * send, the views and streams it may read, and the queries it may ask. Nothing in an Api needs a handler. The class is an Effect: `yield* MyApi`
 * gives a Worker its `fetch`. Call it with a typed client over
 * `Domain.protocolHttp`, `Domain.protocolWebSocket` or
 * `Domain.protocolInProcess`, or with `clientHttp`, `clientWebSocket` or
 * `clientInProcess`, which provide them.
 *
 * ### Declaring an Api
 * **Example:** What customers may reach
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import { Account, DepositMoney, WithdrawMoney } from "./Account.ts";
 * import { AccountSummary } from "./AccountSummary.ts";
 * import { Bank } from "./Bank.ts";
 *
 * // Serving something Bank does not hold is a type error; nothing unlisted is served.
 * export class CustomerApi extends Domain.Api("CustomerApi", {
 *   model: Bank,
 *   commands: ["DepositMoney", "WithdrawMoney"],
 *   views: ["AccountSummary"],
 * }) {}
 * ```
 *
 * ### Serving it from a Worker
 * **Example:** The Api as a Worker's fetch
 * ```typescript
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 * import * as DomainCloudflare from "@alchemy.run/domain/Cloudflare";
 * import * as Effect from "effect/Effect";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankPolicies } from "./Bank.ts";
 * import { CustomerApi } from "./CustomerApi.ts";
 * import { SessionLive } from "./Session.ts";
 *
 * const BankLive = SessionLive.pipe(
 *   Layer.provideMerge(Bank.layer(BankPolicies)),
 *   Layer.provide(DomainCloudflare.layerDurableObjects()),
 * );
 *
 * export default class BankWorker extends Cloudflare.Worker<BankWorker>()(
 *   "BankWorker",
 *   { main: import.meta.url },
 *   Effect.gen(function* () {
 *     const api = yield* CustomerApi;
 *     return { fetch: api.fetch };
 *   }).pipe(Effect.provide(BankLive)),
 * ) {}
 * ```
 *
 * ### Calling it
 * `Domain.protocolWebSocket` sends commands, `get` and `list` over HTTP, and
 * opens a WebSocket for each `watch` and `events`, pushed by the object that
 * owns the key. `Domain.protocolHttp` sends everything over HTTP.
 *
 * **Example:** A typed client
 * ```typescript
 * const bank = yield* CustomerApi.client;
 * const { reply } = yield* bank.DepositMoney({ accountId, amount: 1_000 });
 * const summary = yield* bank.AccountSummary.get(accountId);
 * yield* bank.AccountSummary.watch(accountId).pipe(
 *   Stream.runForEach(({ state }) => Effect.log(state?.balance)),
 * );
 * ```
 *
 * ### Reading your own writes
 * A client remembers the commands it sent. Its `get`, `list`, `snapshot`,
 * `peek` and queries carry their receipts and wait until the view, stream or
 * projection has applied them. `atLeast` names other writes to wait for, and
 * `[]` waits for none.
 *
 * **Example:** A read right after a command
 * ```typescript
 * const bank = yield* CustomerApi.client;
 * yield* bank.DepositMoney({ accountId, amount: 1_000 });
 * const summary = yield* bank.AccountSummary.get(accountId); // includes the deposit
 * const now = yield* bank.AccountSummary.get(accountId, { atLeast: [] });
 * ```
 *
 * ### Calling it in process
 * `clientInProcess` serves the Api in the caller's process, through the
 * middleware of everything it serves, with nothing sent over a network. Code that has
 * already authenticated its caller provides a middleware Layer that trusts it.
 *
 * **Example:** A webhook that deposits as the system
 * ```typescript
 * const asSystem = Layer.succeed(Session, (effect) =>
 *   Effect.provideService(effect, CurrentActor, system("payments-webhook")),
 * );
 * const bank = yield* CustomerApi.clientInProcess.pipe(Effect.provide(asSystem));
 * yield* bank.DepositMoney({ accountId, amount: 1_000 });
 * ```
 *
 * ### Annotating Apis
 * The last argument is its annotations: data for what is built on the
 * model, read back as `X.annotations`. Add your own keys by augmenting
 * `Domain.Annotations`.
 *
 * Its `description` heads the CLI's root help and is the OpenAPI document's
 * `info.description`.
 *
 * **Example:** A description
 * ```typescript
 * export class CustomerApi extends Domain.Api(
 *   "CustomerApi",
 *   { model: Bank, commands: ["DepositMoney"], views: ["AccountSummary"] },
 *   { description: "The bank, as a customer reaches it." },
 * ) {}
 * ```
 *
 * @primitive
 */
export declare const make: <const Name extends string, M extends Model.Any, const C extends ReadonlyArray<CommandName<M>> = ReadonlyArray<CommandName<M>>, const V extends ReadonlyArray<ViewName<M>> = ReadonlyArray<ViewName<M>>, const S extends ReadonlyArray<StreamName<M>> = ReadonlyArray<StreamName<M>>, const Q extends ReadonlyArray<QueryName<M>> = ReadonlyArray<QueryName<M>>>(name: Name, options: Options<M, C, V, S, Q>, annotations?: Annotations) => ApiClass<Name, ReadonlyArray<ServedBy<M, C, V, S, Q>>>;
/**
 * The HTTP protocol for an Api client (NDJSON, so streams work). Live reads
 * are streamed responses, which the platform feeds by polling the key; use
 * {@link protocolWebSocket} to have them pushed instead. Requires an
 * `HttpClient`, e.g. `FetchHttpClient.layer`.
 */
export declare const protocolHttp: (url: string) => Layer.Layer<RpcClient.Protocol, never, HttpClient.HttpClient>;
/**
 * The protocol for a client in the same process as the model. It serves the
 * Api right there: the middleware of everything it serves runs, from the Layers
 * in scope, and nothing leaves memory. Requires the hosted Domain, like
 * serving the Api.
 * In a Worker, build it per request.
 */
export declare const protocolInProcess: <Name extends string, Serves extends ReadonlyArray<Servable>>(api: ApiClass<Name, Serves>) => Layer.Layer<RpcClient.Protocol, never, Model.Internals | MiddlewareServices<Serves>>;
/**
 * The WebSocket protocol for an Api client. Calls (commands, `get`, `list`)
 * go over HTTP like {@link protocolHttp}; every live read (`watch`,
 * `events`) opens its own WebSocket, which the Api hands to the instance that
 * owns the key (a Durable Object on Cloudflare, an actor on Rivet, an entity
 * on Effect Cluster). Each commit is pushed down the socket, so nothing
 * polls; on Cloudflare the object hibernates in between. A dropped socket
 * reconnects and resumes after the last value it delivered.
 *
 * A browser cannot set headers on a WebSocket, and a URL ends up in logs,
 * so headers client middleware attaches apply to calls only. A live read
 * authenticates with what its upgrade request carries: in a browser, the
 * cookies of the Api's origin, so serve the app and the Api from one origin
 * and keep sessions in an `HttpOnly`, `SameSite` cookie. Requires an
 * `HttpClient` and a `Socket.WebSocketConstructor`
 * (`Socket.layerWebSocketConstructorGlobal` in browsers and Workers).
 *
 * **Example:** Watching a view over a WebSocket
 * ```typescript
 * const BankConnection = CustomerApi.layerClient.pipe(
 *   Layer.provide(Domain.protocolWebSocket("https://bank.example.com/api")),
 *   Layer.provide(Layer.mergeAll(FetchHttpClient.layer, Socket.layerWebSocketConstructorGlobal)),
 * );
 * ```
 */
export declare const protocolWebSocket: (url: string) => Layer.Layer<RpcClient.Protocol, never, HttpClient.HttpClient | Socket.WebSocketConstructor>;
/** The Schema of a union of rejection classes; `Schema.Never` when there are none. */
type RejectionUnion<R> = [R] extends [never] ? typeof Schema.Never : Schema.Codec<Aggregate.InstanceOf<R>, Schema.Codec.Encoded<R>>;
/**
 * Any Api class. Use it to write code that works with every Api, such as a
 * helper that turns each command of an Api into a UI action. `ApiClass` does
 * not fit there: its client type is exact, so a concrete Api is not an
 * `ApiClass<string, ReadonlyArray<Servable>>`.
 *
 * **Example:** A helper for any Api
 * ```typescript
 * const tagsOf = <A extends Domain.Api.Any>(api: A): ReadonlyArray<Domain.Api.CommandsOf<A>["tag"]> =>
 *   api.commands.map((command) => command.tag);
 *
 * tagsOf(CustomerApi); // ["DepositMoney", "WithdrawMoney"]
 * ```
 */
export interface Any {
    readonly kind: "Api";
    readonly annotations: Annotations;
    readonly apiName: string;
    /** The model the Api is over. */
    readonly model: Model.Any;
    /** The commands, views, streams and queries the Api serves. */
    readonly serves: ReadonlyArray<Servable>;
    /** The command classes the Api exposes, in order. */
    readonly commands: ReadonlyArray<Command.Any>;
    /** One Schema for every rejection the Api's commands declare. */
    readonly rejections: Schema.Top;
    /** The Api's client service. */
    readonly Client: Context.Key<ClientKey<string>, unknown>;
}
/** The command classes an Api exposes. */
export type CommandsOf<A extends Any> = A["commands"][number];
/** The query classes an Api exposes. */
export type QueriesOf<A extends Any> = Extract<A["serves"][number], Query.Any>;
/** The rejection classes the commands of an Api declare. */
export type RejectionsOf<A extends Any> = CommandsOf<A>["rejects"][number];
/** The client an Api's `Client` service gives (`yield* MyApi.Client`). */
export type ClientOf<A extends Any> = A["Client"]["Service"];
export {};
//# sourceMappingURL=Api.d.ts.map