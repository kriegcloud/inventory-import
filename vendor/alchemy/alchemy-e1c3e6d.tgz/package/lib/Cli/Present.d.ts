import * as Effect from "effect/Effect";
import * as LogLevel from "effect/LogLevel";
/**
 * Print one line of plain renderer output: what the TUI would draw, for a
 * terminal without it. Renderers present events, they don't log them —
 * the events are already log records — so this writes to the console only,
 * prints nothing under `--log-format json`, where the records are the
 * output, and honors the console's `--log-level` floor like log lines do.
 */
export declare const present: (text: string, options?: {
    readonly resource?: string;
    readonly level?: LogLevel.Severity;
}) => Effect.Effect<void>;
//# sourceMappingURL=Present.d.ts.map