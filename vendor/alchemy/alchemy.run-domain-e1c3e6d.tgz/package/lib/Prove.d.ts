import * as Effect from "effect/Effect";
import type * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type * as Aggregate from "./Aggregate.ts";
import type * as Compaction from "./Compaction.ts";
import type * as Decision from "./Decision.ts";
import type { Verdict } from "./Prove/internal/Check.ts";
import * as Source from "./Prove/internal/Source.ts";
import * as Suggest from "./Prove/internal/Suggest.ts";
import type * as Rewrite from "./Rewrite.ts";
export type { Counterexample, Verdict } from "./Prove/internal/Check.ts";
export type { Suggestion } from "./Prove/internal/Suggest.ts";
export type { Reading } from "./Prove/internal/Source.ts";
export interface Options extends Source.Reading {
    /** The file the aggregate is declared in: `new URL("../src/Account.ts", import.meta.url)`, or a path. */
    readonly source: URL | string;
    /**
     * The decisions that record on the aggregate, each with the file it is
     * declared in. An aggregate that folds an event none of its own commands
     * records is proved only with the decision that records it.
     */
    readonly decisions?: ReadonlyArray<{
        readonly decision: Decision.Any;
        readonly source: URL | string;
    }>;
    /**
     * Look for an invariant to add where a proof fails from a state the rules
     * allow.
     * @default true
     */
    readonly suggest?: boolean;
}
/** Where a decision is declared. */
export interface DecisionOptions extends Source.Reading {
    /** The file the decision is declared in: `new URL("../src/Transfer.decision.ts", import.meta.url)`, or a path. */
    readonly source: URL | string;
}
declare const DecisionNotProved_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DecisionNotProved";
} & Readonly<A>;
/** At least one rule a decision must keep is not proved. The message is the report. */
export declare class DecisionNotProved extends DecisionNotProved_base<{
    readonly message: string;
    readonly report: DecisionReport;
}> {
}
export interface DecisionReport {
    /** The tag of the command the decision implements. */
    readonly decision: string;
    /** The aggregates it reads, each under the name `decide` reads it by. */
    readonly reads: ReadonlyArray<{
        readonly name: string;
        readonly aggregate: string;
    }>;
    /** The paths through the decision that were checked. */
    readonly paths: number;
    /** Whether every state the decision leaves is one its aggregate's schema allows. */
    readonly schema: Verdict;
    /**
     * Whether some states let the decision record an event. `false` when none
     * does, `undefined` when the prover could not tell.
     */
    readonly accepted: boolean | undefined;
    /**
     * Every rule the decision must keep: the invariants and transitions of the
     * aggregates it reads, named `Account.NeverOverdrawn`, then its own
     * transitions.
     */
    readonly rules: ReadonlyArray<{
        readonly name: string;
        readonly kind: "invariant" | "transition" | "decision";
        readonly verdict: Verdict;
    }>;
    /** The checks of the schemas the prover does not read. */
    readonly unread: ReadonlyArray<string>;
    /** What the decision writes to a part of a state whose schema has a check the prover does not read. */
    readonly unkept: ReadonlyArray<string>;
    /** What the proof takes for granted. */
    readonly assumptions: ReadonlyArray<string>;
}
declare const ProveError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ProveError";
} & Readonly<A>;
/** The prover could not start: a file did not load, or the solver is missing. */
export declare class ProveError extends ProveError_base<{
    readonly message: string;
}> {
}
declare const InvariantsNotProved_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvariantsNotProved";
} & Readonly<A>;
/** At least one invariant is not proved. The message is the report. */
export declare class InvariantsNotProved extends InvariantsNotProved_base<{
    readonly message: string;
    readonly report: Report;
}> {
}
export interface Report {
    readonly aggregate: string;
    /** Whether the aggregate's initial state is one its state's schema allows. */
    readonly initial: boolean;
    readonly commands: ReadonlyArray<{
        readonly command: string;
        /** The paths through the command that were checked. */
        readonly paths: number;
        /**
         * Whether every state the command leaves is one the state's schema allows.
         * Each proof starts from a state in the schema, so the proofs follow one
         * another only when every command keeps the state there.
         */
        readonly schema: Verdict;
        /**
         * Whether some state lets the command record an event. `false` when none
         * does: the command is proved to keep every invariant only because it
         * never does anything. `undefined` when the prover could not tell.
         */
        readonly accepted: boolean | undefined;
    }>;
    readonly invariants: ReadonlyArray<{
        readonly name: string;
        /** Whether the invariant holds on the aggregate's initial state. */
        readonly initial: boolean;
        readonly commands: ReadonlyArray<{
            readonly command: string;
            readonly verdict: Verdict;
            /** The paths through the command that were checked. */
            readonly paths: number;
        }>;
        /**
         * Where the proof fails from a state the rules allow: an invariant that
         * rules that state out and that every command keeps. With it written
         * down, this one is proved. `undefined` where no simple one does.
         */
        readonly suggested: Suggest.Suggestion | undefined;
    }>;
    /** The aggregate's transitions: what each command may do in one step. */
    readonly transitions: ReadonlyArray<{
        readonly name: string;
        readonly commands: ReadonlyArray<{
            readonly command: string;
            readonly verdict: Verdict;
            /** The paths through the command that were checked. */
            readonly paths: number;
        }>;
        /** An invariant that makes it proved, as for an invariant. */
        readonly suggested: Suggest.Suggestion | undefined;
    }>;
    /**
     * The checks of the state's and the commands' schemas the prover does not
     * read, each with the part it is on. A value such a check refuses may be
     * tried, so a counterexample that needs one is not confirmed.
     */
    readonly unread: ReadonlyArray<string>;
    /**
     * What a command writes to a part of the state whose schema has a check
     * the prover does not read: the new value is not proved to pass it.
     */
    readonly unkept: ReadonlyArray<string>;
    /**
     * The events the aggregate folds that none of its commands records, and no
     * decision given in `decisions` does: a decision records them, and nothing
     * here says what it does to the invariants.
     */
    readonly outside: ReadonlyArray<string>;
    /**
     * How far the prover's reading was held against the real code: on inputs
     * picked for each path through a command, the real `decide` and `evolve`
     * were run. `differs` names each path where they did something else.
     */
    readonly agreement: {
        /** The paths inputs were picked and run for. */
        readonly compared: number;
        /** The paths inputs take that could not be run on the real code. */
        readonly uncompared: number;
        /**
         * How many of those take the items of a hash set or a hash map in an
         * order the real one did not give for the items picked. The prover reads
         * every order, and the order the real one gives is compared on its own path.
         */
        readonly unordered: number;
        readonly differs: ReadonlyArray<string>;
    };
    /** What the proof takes for granted. */
    readonly assumptions: ReadonlyArray<string>;
}
/** What a decision's proof takes for granted of the platform that commits it. */
export declare const ATOMIC = "a decision's events commit on every instance it recorded on, or on none: how a platform commits them is not checked";
/** What a proof takes for granted of the functions the prover did not read. */
export declare const pure: (names: ReadonlyArray<string>) => ReadonlyArray<string>;
/**
 * Check every invariant of an aggregate against every command, and say what
 * was proved, what was broken, and what the prover could not read.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Prove.report(Account, {
 *   source: new URL("../src/Account/Account.aggregate.ts", import.meta.url),
 * });
 * console.log(Prove.render(report));
 * ```
 */
export declare const report: (aggregate: Aggregate.Any, options: Options) => Effect.Effect<Report, ProveError, FileSystem.FileSystem | Path.Path>;
/**
 * Whether a report proves every invariant for every command: each command
 * keeps the state in its schema and keeps every invariant, and each can
 * record an event from some state.
 */
export declare const proved: (report: Report) => boolean;
/**
 * Prove every invariant of an aggregate, or fail with the report.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("the account's invariants hold", () =>
 *   Prove.invariants(Account, {
 *     source: new URL("../src/Account/Account.aggregate.ts", import.meta.url),
 *   }).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare const invariants: (aggregate: Aggregate.Any, options: Options) => Effect.Effect<Report, ProveError | InvariantsNotProved, FileSystem.FileSystem | Path.Path>;
/** A report as text, one invariant after another. */
export declare const render: (report: Report) => string;
/** An invariant to add, as lines of a report. */
export declare const suggestion: (suggested: Suggest.Suggestion, indent: string) => ReadonlyArray<string>;
/** How far a report's reading was held against the real code, as a line. */
export declare const agreed: (agreement: {
    readonly compared: number;
    readonly uncompared: number;
    readonly unordered?: number;
    readonly differs: ReadonlyArray<string>;
}) => string;
/**
 * Check a decision against every rule it must keep, and say what was proved,
 * what was broken, and what the prover could not read. The rules are the
 * invariants and transitions of each aggregate it reads, on the instance it
 * recorded on, and its own transitions, on all of them together.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Prove.decisionReport(Transfer, {
 *   source: new URL("../src/Transfer/Transfer.decision.ts", import.meta.url),
 * });
 * console.log(Prove.renderDecision(report));
 * ```
 */
export declare const decisionReport: (decision: Decision.Any, options: DecisionOptions) => Effect.Effect<DecisionReport, ProveError, FileSystem.FileSystem | Path.Path>;
/**
 * Whether a report proves a decision: it keeps every state in its schema,
 * keeps every rule, and can record an event from some states.
 */
export declare const decisionProved: (report: DecisionReport) => boolean;
/**
 * Prove that a decision keeps every rule of the aggregates it reads, and its
 * own, or fail with the report.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("a transfer keeps both accounts' rules", () =>
 *   Prove.decision(Transfer, {
 *     source: new URL("../src/Transfer/Transfer.decision.ts", import.meta.url),
 *   }).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare const decision: (decision: Decision.Any, options: DecisionOptions) => Effect.Effect<DecisionReport, ProveError | DecisionNotProved, FileSystem.FileSystem | Path.Path>;
/** A decision's report as text, one rule after another. */
export declare const renderDecision: (report: DecisionReport) => string;
/** Where a compaction is declared. */
export interface CompactionOptions extends Source.Reading {
    /** The file the compaction is declared in: `new URL("../src/BringForward.compaction.ts", import.meta.url)`, or a path. */
    readonly source: URL | string;
}
declare const CompactionNotProved_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CompactionNotProved";
} & Readonly<A>;
/** A roll-up is not proved to lose nothing. The message is the report. */
export declare class CompactionNotProved extends CompactionNotProved_base<{
    readonly message: string;
    readonly report: CompactionReport;
}> {
}
export interface CompactionReport {
    readonly compaction: string;
    /** The aggregate whose instances it compacts. */
    readonly aggregate: string;
    /** The paths through the roll-up that were checked. */
    readonly paths: number;
    /**
     * Whether folding the roll-up from `initial` gives the state back, for
     * every state the aggregate's rules allow: what a view or an instance read
     * after the compaction is built from.
     */
    readonly lossless: Verdict;
    /** Whether folding the roll-up onto the state it was made from leaves that state. */
    readonly standing: Verdict;
    /** The checks of the state's schema the prover does not read. */
    readonly unread: ReadonlyArray<string>;
    /** What the proof takes for granted. */
    readonly assumptions: ReadonlyArray<string>;
}
/**
 * Check that a compaction's roll-up loses nothing, for every state its
 * aggregate's rules allow, and say what was proved and what was not. An
 * instance refuses a roll-up that would change its own state when it runs;
 * this says so before any instance meets one.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Prove.compactionReport(BringForward, {
 *   source: new URL("../src/Wallet/BringForward.compaction.ts", import.meta.url),
 * });
 * console.log(Prove.renderCompaction(report));
 * ```
 */
export declare const compactionReport: (compaction: Compaction.Any, options: CompactionOptions) => Effect.Effect<CompactionReport, ProveError, FileSystem.FileSystem | Path.Path>;
/** Whether a report proves a roll-up loses nothing, from `initial` and onto the state it is made from. */
export declare const compactionProved: (report: CompactionReport) => boolean;
/**
 * Prove that a compaction's roll-up loses nothing, or fail with the report.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("bringing a wallet forward loses nothing", () =>
 *   Prove.compaction(BringForward, {
 *     source: new URL("../src/Wallet/BringForward.compaction.ts", import.meta.url),
 *   }).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare const compaction: (compaction: Compaction.Any, options: CompactionOptions) => Effect.Effect<CompactionReport, ProveError | CompactionNotProved, FileSystem.FileSystem | Path.Path>;
/** A compaction's report as text. */
export declare const renderCompaction: (report: CompactionReport) => string;
/** Where a rewrite is declared, and what else records on its aggregate. */
export interface RewriteOptions extends Source.Reading {
    /** The file the rewrite is declared in: `new URL("../src/ForgetOwner.rewrite.ts", import.meta.url)`, or a path. */
    readonly source: URL | string;
    /**
     * The compactions of the rewrite's aggregate, each with the file it is
     * declared in: a roll-up is an event an instance holds, so the rewrite is
     * taken through it too.
     */
    readonly compactions?: ReadonlyArray<{
        readonly compaction: Compaction.Any;
        readonly source: URL | string;
    }>;
}
declare const RewriteNotProved_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "RewriteNotProved";
} & Readonly<A>;
/** A rewrite is not proved to keep its aggregate's invariants. The message is the report. */
export declare class RewriteNotProved extends RewriteNotProved_base<{
    readonly message: string;
    readonly report: RewriteReport;
}> {
}
export interface RewriteReport {
    readonly rewrite: string;
    /** The aggregate whose instances it rewrites. */
    readonly aggregate: string;
    /** Whether it removes the instance: nothing is left to break a rule. */
    readonly deletes: boolean;
    /**
     * The parts of the state the rewrite can leave other than they were: the
     * proof lets the rewritten history differ from the recorded one there, and
     * nowhere else. `undefined` where the prover could not tell, and let it
     * differ everywhere.
     */
    readonly differs: ReadonlyArray<string> | undefined;
    /** Each invariant, after each command's events and each roll-up as the rewrite leaves them. */
    readonly invariants: ReadonlyArray<{
        readonly name: string;
        readonly steps: ReadonlyArray<{
            /** The command that records the events, or the compaction whose roll-up they are. */
            readonly step: string;
            readonly verdict: Verdict;
            readonly paths: number;
        }>;
    }>;
    /** Whether the state the rewritten events fold to stays in the state's schema, by step. */
    readonly schema: ReadonlyArray<{
        readonly step: string;
        readonly verdict: Verdict;
    }>;
    /**
     * The events the aggregate folds that none of its commands records and no
     * roll-up given is: a decision records them, and the rewrite is not taken
     * through what a decision records.
     */
    readonly outside: ReadonlyArray<string>;
    /** What the proof takes for granted. */
    readonly assumptions: ReadonlyArray<string>;
}
/**
 * Check that a rewrite keeps every invariant of its aggregate, whatever
 * history an instance holds, and say what was proved and what was not. An
 * instance refuses a rewrite that would break an invariant when it runs;
 * this says so before any instance meets such a history.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Prove.rewriteReport(ForgetOwner, {
 *   source: new URL("../src/Account/ForgetOwner.rewrite.ts", import.meta.url),
 * });
 * console.log(Prove.renderRewrite(report));
 * ```
 */
export declare const rewriteReport: (rewrite: Rewrite.Any, options: RewriteOptions) => Effect.Effect<RewriteReport, ProveError, FileSystem.FileSystem | Path.Path>;
/** Whether a report proves a rewrite keeps every invariant and the state's schema, through every event. */
export declare const rewriteProved: (report: RewriteReport) => boolean;
/**
 * Prove that a rewrite keeps every invariant of its aggregate, or fail with
 * the report.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("forgetting an owner keeps the account's rules", () =>
 *   Prove.rewrite(ForgetOwner, {
 *     source: new URL("../src/Account/ForgetOwner.rewrite.ts", import.meta.url),
 *   }).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare const rewrite: (rewrite: Rewrite.Any, options: RewriteOptions) => Effect.Effect<RewriteReport, ProveError | RewriteNotProved, FileSystem.FileSystem | Path.Path>;
/** A rewrite's report as text, one invariant after another. */
export declare const renderRewrite: (report: RewriteReport) => string;
//# sourceMappingURL=Prove.d.ts.map