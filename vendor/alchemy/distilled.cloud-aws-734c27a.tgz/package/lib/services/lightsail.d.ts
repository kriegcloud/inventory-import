import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly code: any;
    readonly docs: any;
    readonly message: any;
    readonly tip: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AccountSetupInProgressException_base: S.TaggedErrorClass<"AccountSetupInProgressException", {
    readonly code: any;
    readonly docs: any;
    readonly message: any;
    readonly tip: any;
}>;
export declare class AccountSetupInProgressException extends /*@__PURE__*/ AccountSetupInProgressException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly code: any;
    readonly docs: any;
    readonly message: any;
    readonly tip: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly code: any;
    readonly docs: any;
    readonly message: any;
    readonly tip: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const OperationFailureException_base: S.TaggedErrorClass<"OperationFailureException", {
    readonly code: any;
    readonly docs: any;
    readonly message: any;
    readonly tip: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationFailureException extends /*@__PURE__*/ OperationFailureException_base {
}
declare const RegionSetupInProgressException_base: S.TaggedErrorClass<"RegionSetupInProgressException", {
    readonly code: any;
    readonly docs: any;
    readonly message: any;
    readonly tip: any;
}>;
export declare class RegionSetupInProgressException extends /*@__PURE__*/ RegionSetupInProgressException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly code: any;
    readonly docs: any;
    readonly message: any;
    readonly tip: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const UnauthenticatedException_base: S.TaggedErrorClass<"UnauthenticatedException", {
    readonly code: any;
    readonly docs: any;
    readonly message: any;
    readonly tip: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthenticatedException extends /*@__PURE__*/ UnauthenticatedException_base {
}
export type ResourceName = string;
export interface AllocateStaticIpRequest {
    staticIpName: string;
}
export type NonEmptyString = string;
export type ResourceType = "ContainerService" | "Instance" | "StaticIp" | "KeyPair" | "InstanceSnapshot" | "Domain" | "PeeredVpc" | "LoadBalancer" | "LoadBalancerTlsCertificate" | "Disk" | "DiskSnapshot" | "RelationalDatabase" | "RelationalDatabaseSnapshot" | "ExportSnapshotRecord" | "CloudFormationStackRecord" | "Alarm" | "ContactMethod" | "Distribution" | "Certificate" | "Bucket" | "Subdomain" | (string & {});
export type IsoDate = Date;
export type RegionName = "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "eu-central-1" | "eu-north-1" | "eu-south-2" | "ca-central-1" | "ap-east-1" | "ap-south-1" | "ap-southeast-1" | "ap-southeast-2" | "ap-northeast-1" | "ap-northeast-2" | "ap-southeast-3" | "ap-southeast-5" | "sa-east-1" | (string & {});
export interface ResourceLocation {
    availabilityZone?: string | undefined;
    regionName?: RegionName | undefined;
}
export type OperationType = "DeleteKnownHostKeys" | "DeleteInstance" | "CreateInstance" | "StopInstance" | "StartInstance" | "RebootInstance" | "OpenInstancePublicPorts" | "PutInstancePublicPorts" | "CloseInstancePublicPorts" | "AllocateStaticIp" | "ReleaseStaticIp" | "AttachStaticIp" | "DetachStaticIp" | "UpdateDomainEntry" | "DeleteDomainEntry" | "CreateDomain" | "DeleteDomain" | "CreateInstanceSnapshot" | "DeleteInstanceSnapshot" | "CreateInstancesFromSnapshot" | "CreateLoadBalancer" | "DeleteLoadBalancer" | "AttachInstancesToLoadBalancer" | "DetachInstancesFromLoadBalancer" | "UpdateLoadBalancerAttribute" | "CreateLoadBalancerTlsCertificate" | "DeleteLoadBalancerTlsCertificate" | "AttachLoadBalancerTlsCertificate" | "CreateDisk" | "DeleteDisk" | "AttachDisk" | "DetachDisk" | "CreateDiskSnapshot" | "DeleteDiskSnapshot" | "CreateDiskFromSnapshot" | "CreateRelationalDatabase" | "UpdateRelationalDatabase" | "DeleteRelationalDatabase" | "CreateRelationalDatabaseFromSnapshot" | "CreateRelationalDatabaseSnapshot" | "DeleteRelationalDatabaseSnapshot" | "UpdateRelationalDatabaseParameters" | "StartRelationalDatabase" | "RebootRelationalDatabase" | "StopRelationalDatabase" | "EnableAddOn" | "DisableAddOn" | "PutAlarm" | "GetAlarms" | "DeleteAlarm" | "TestAlarm" | "CreateContactMethod" | "GetContactMethods" | "SendContactMethodVerification" | "DeleteContactMethod" | "CreateDistribution" | "UpdateDistribution" | "DeleteDistribution" | "ResetDistributionCache" | "AttachCertificateToDistribution" | "DetachCertificateFromDistribution" | "UpdateDistributionBundle" | "SetIpAddressType" | "CreateCertificate" | "DeleteCertificate" | "CreateContainerService" | "UpdateContainerService" | "DeleteContainerService" | "CreateContainerServiceDeployment" | "CreateContainerServiceRegistryLogin" | "RegisterContainerImage" | "DeleteContainerImage" | "CreateBucket" | "DeleteBucket" | "CreateBucketAccessKey" | "DeleteBucketAccessKey" | "UpdateBucketBundle" | "UpdateBucket" | "SetResourceAccessForBucket" | "UpdateInstanceMetadataOptions" | "StartGUISession" | "StopGUISession" | "SetupInstanceHttps" | "GetProfile" | "CreateSubdomain" | "UpdateSubdomainAssociation" | "DeleteSubdomain" | (string & {});
export type OperationStatus = "NotStarted" | "Started" | "Failed" | "Completed" | "Succeeded" | (string & {});
export interface Operation {
    id?: string | undefined;
    resourceName?: string | undefined;
    resourceType?: ResourceType | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    isTerminal?: boolean | undefined;
    operationDetails?: string | undefined;
    operationType?: OperationType | undefined;
    status?: OperationStatus | undefined;
    statusChangedAt?: Date | undefined;
    errorCode?: string | undefined;
    errorDetails?: string | undefined;
}
export type OperationList = Operation[];
export interface AllocateStaticIpResult {
    operations?: Operation[] | undefined;
}
export interface AttachCertificateToDistributionRequest {
    distributionName: string;
    certificateName: string;
}
export interface AttachCertificateToDistributionResult {
    operation?: Operation | undefined;
}
export interface AttachDiskRequest {
    diskName: string;
    instanceName: string;
    diskPath: string;
    autoMounting?: boolean | undefined;
}
export interface AttachDiskResult {
    operations?: Operation[] | undefined;
}
export type ResourceNameList = string[];
export interface AttachInstancesToLoadBalancerRequest {
    loadBalancerName: string;
    instanceNames: string[];
}
export interface AttachInstancesToLoadBalancerResult {
    operations?: Operation[] | undefined;
}
export interface AttachLoadBalancerTlsCertificateRequest {
    loadBalancerName: string;
    certificateName: string;
}
export interface AttachLoadBalancerTlsCertificateResult {
    operations?: Operation[] | undefined;
}
export interface AttachStaticIpRequest {
    staticIpName: string;
    instanceName: string;
}
export interface AttachStaticIpResult {
    operations?: Operation[] | undefined;
}
export interface CheckSubdomainAvailabilityRequest {
    subdomainName: string;
    reserve?: boolean | undefined;
}
export interface CheckSubdomainAvailabilityResult {
    available?: boolean | undefined;
    reservationExpiresAt?: Date | undefined;
    subdomainName?: string | undefined;
}
export type Port = number;
export type NetworkProtocol = "tcp" | "all" | "udp" | "icmp" | "icmpv6" | (string & {});
export type StringList = string[];
export interface PortInfo {
    fromPort?: number | undefined;
    toPort?: number | undefined;
    protocol?: NetworkProtocol | undefined;
    cidrs?: string[] | undefined;
    ipv6Cidrs?: string[] | undefined;
    cidrListAliases?: string[] | undefined;
}
export interface CloseInstancePublicPortsRequest {
    portInfo: PortInfo;
    instanceName: string;
}
export interface CloseInstancePublicPortsResult {
    operation?: Operation | undefined;
}
export interface CopySnapshotRequest {
    sourceSnapshotName?: string | undefined;
    sourceResourceName?: string | undefined;
    restoreDate?: string | undefined;
    useLatestRestorableAutoSnapshot?: boolean | undefined;
    targetSnapshotName: string;
    sourceRegion: RegionName;
}
export interface CopySnapshotResult {
    operations?: Operation[] | undefined;
}
export type BucketName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key?: string | undefined;
    value?: string | undefined;
}
export type TagList = Tag[];
export interface CreateBucketRequest {
    bucketName: string;
    bundleId: string;
    tags?: Tag[] | undefined;
    enableObjectVersioning?: boolean | undefined;
}
export type AccessType = "public" | "private" | (string & {});
export interface AccessRules {
    getObject?: AccessType | undefined;
    allowPublicOverrides?: boolean | undefined;
}
export type PartnerIdList = string[];
export interface ResourceReceivingAccess {
    name?: string | undefined;
    resourceType?: string | undefined;
}
export type AccessReceiverList = ResourceReceivingAccess[];
export interface BucketState {
    code?: string | undefined;
    message?: string | undefined;
}
export type BucketAccessLogPrefix = string;
export interface BucketAccessLogConfig {
    enabled: boolean;
    destination?: string | undefined;
    prefix?: string | undefined;
}
export type BucketCorsRuleId = string;
export type BucketCorsAllowedMethod = string;
export type BucketCorsAllowedMethods = string[];
export type BucketCorsAllowedOrigins = string[];
export type BucketCorsAllowedHeaders = string[];
export type BucketCorsExposeHeaders = string[];
export interface BucketCorsRule {
    id?: string | undefined;
    allowedMethods: string[];
    allowedOrigins: string[];
    allowedHeaders?: string[] | undefined;
    exposeHeaders?: string[] | undefined;
    maxAgeSeconds?: number | undefined;
}
export type BucketCorsRules = BucketCorsRule[];
export interface BucketCorsConfig {
    rules?: BucketCorsRule[] | undefined;
}
export interface Bucket {
    resourceType?: string | undefined;
    accessRules?: AccessRules | undefined;
    arn?: string | undefined;
    bundleId?: string | undefined;
    createdAt?: Date | undefined;
    url?: string | undefined;
    location?: ResourceLocation | undefined;
    name?: string | undefined;
    supportCode?: string | undefined;
    tags?: Tag[] | undefined;
    objectVersioning?: string | undefined;
    ableToUpdateBundle?: boolean | undefined;
    readonlyAccessAccounts?: string[] | undefined;
    resourcesReceivingAccess?: ResourceReceivingAccess[] | undefined;
    state?: BucketState | undefined;
    accessLogConfig?: BucketAccessLogConfig | undefined;
    cors?: BucketCorsConfig | undefined;
}
export interface CreateBucketResult {
    bucket?: Bucket | undefined;
    operations?: Operation[] | undefined;
}
export interface CreateBucketAccessKeyRequest {
    bucketName: string;
}
export type IAMAccessKeyId = string | redacted.Redacted<string>;
export type SensitiveNonEmptyString = string | redacted.Redacted<string>;
export type StatusType = "Active" | "Inactive" | (string & {});
export interface AccessKeyLastUsed {
    lastUsedDate?: Date | undefined;
    region?: string | undefined;
    serviceName?: string | undefined;
}
export interface AccessKey {
    accessKeyId?: string | redacted.Redacted<string> | undefined;
    secretAccessKey?: string | redacted.Redacted<string> | undefined;
    status?: StatusType | undefined;
    createdAt?: Date | undefined;
    lastUsed?: AccessKeyLastUsed | undefined;
}
export interface CreateBucketAccessKeyResult {
    accessKey?: AccessKey | undefined;
    operations?: Operation[] | undefined;
}
export type CertificateName = string;
export type DomainName = string;
export type SubjectAlternativeNameList = string[];
export interface CreateCertificateRequest {
    certificateName: string;
    domainName: string;
    subjectAlternativeNames?: string[] | undefined;
    tags?: Tag[] | undefined;
}
export type CertificateStatus = "PENDING_VALIDATION" | "ISSUED" | "INACTIVE" | "EXPIRED" | "VALIDATION_TIMED_OUT" | "REVOKED" | "FAILED" | (string & {});
export type SerialNumber = string;
export interface ResourceRecord {
    name?: string | undefined;
    type?: string | undefined;
    value?: string | undefined;
}
export type DnsRecordCreationStateCode = "SUCCEEDED" | "STARTED" | "FAILED" | (string & {});
export interface DnsRecordCreationState {
    code?: DnsRecordCreationStateCode | undefined;
    message?: string | undefined;
}
export type CertificateDomainValidationStatus = "PENDING_VALIDATION" | "FAILED" | "SUCCESS" | (string & {});
export interface DomainValidationRecord {
    domainName?: string | undefined;
    resourceRecord?: ResourceRecord | undefined;
    dnsRecordCreationState?: DnsRecordCreationState | undefined;
    validationStatus?: CertificateDomainValidationStatus | undefined;
}
export type DomainValidationRecordList = DomainValidationRecord[];
export type RequestFailureReason = string;
export type InUseResourceCount = number;
export type KeyAlgorithm = string;
export type IssuerCA = string;
export type EligibleToRenew = string;
export type RenewalStatus = "PendingAutoRenewal" | "PendingValidation" | "Success" | "Failed" | (string & {});
export type RenewalStatusReason = string;
export interface RenewalSummary {
    domainValidationRecords?: DomainValidationRecord[] | undefined;
    renewalStatus?: RenewalStatus | undefined;
    renewalStatusReason?: string | undefined;
    updatedAt?: Date | undefined;
}
export type RevocationReason = string;
export interface Certificate {
    arn?: string | undefined;
    name?: string | undefined;
    domainName?: string | undefined;
    status?: CertificateStatus | undefined;
    serialNumber?: string | undefined;
    subjectAlternativeNames?: string[] | undefined;
    domainValidationRecords?: DomainValidationRecord[] | undefined;
    requestFailureReason?: string | undefined;
    inUseResourceCount?: number | undefined;
    keyAlgorithm?: string | undefined;
    createdAt?: Date | undefined;
    issuedAt?: Date | undefined;
    issuerCA?: string | undefined;
    notBefore?: Date | undefined;
    notAfter?: Date | undefined;
    eligibleToRenew?: string | undefined;
    renewalSummary?: RenewalSummary | undefined;
    revokedAt?: Date | undefined;
    revocationReason?: string | undefined;
    tags?: Tag[] | undefined;
    supportCode?: string | undefined;
}
export interface CertificateSummary {
    certificateArn?: string | undefined;
    certificateName?: string | undefined;
    domainName?: string | undefined;
    certificateDetail?: Certificate | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateCertificateResult {
    certificate?: CertificateSummary | undefined;
    operations?: Operation[] | undefined;
}
export type PortInfoSourceType = "DEFAULT" | "INSTANCE" | "NONE" | "CLOSED" | (string & {});
export interface InstanceEntry {
    sourceName: string;
    instanceType: string;
    portInfoSource: PortInfoSourceType;
    userData?: string | undefined;
    availabilityZone: string;
}
export type InstanceEntryList = InstanceEntry[];
export interface CreateCloudFormationStackRequest {
    instances: InstanceEntry[];
}
export interface CreateCloudFormationStackResult {
    operations?: Operation[] | undefined;
}
export type ContactProtocol = "Email" | "SMS" | (string & {});
export type StringMax256 = string;
export interface CreateContactMethodRequest {
    protocol: ContactProtocol;
    contactEndpoint: string;
    tags?: Tag[] | undefined;
}
export interface CreateContactMethodResult {
    operations?: Operation[] | undefined;
}
export type ContainerServiceName = string;
export type ContainerServicePowerName = "nano" | "micro" | "small" | "medium" | "large" | "xlarge" | (string & {});
export type ContainerServiceScale = number;
export type ContainerServicePublicDomainsList = string[];
export type ContainerServicePublicDomains = {
    [key: string]: string[] | undefined;
};
export type ContainerName = string;
export type Environment = {
    [key: string]: string | undefined;
};
export type ContainerServiceProtocol = "HTTP" | "HTTPS" | "TCP" | "UDP" | (string & {});
export type PortMap = {
    [key: string]: ContainerServiceProtocol | undefined;
};
export interface Container {
    image?: string | undefined;
    command?: string[] | undefined;
    environment?: {
        [key: string]: string | undefined;
    } | undefined;
    ports?: {
        [key: string]: ContainerServiceProtocol | undefined;
    } | undefined;
}
export type ContainerMap = {
    [key: string]: Container | undefined;
};
export interface ContainerServiceHealthCheckConfig {
    healthyThreshold?: number | undefined;
    unhealthyThreshold?: number | undefined;
    timeoutSeconds?: number | undefined;
    intervalSeconds?: number | undefined;
    path?: string | undefined;
    successCodes?: string | undefined;
}
export interface EndpointRequest {
    containerName: string;
    containerPort: number;
    healthCheck?: ContainerServiceHealthCheckConfig | undefined;
}
export interface ContainerServiceDeploymentRequest {
    containers?: {
        [key: string]: Container | undefined;
    } | undefined;
    publicEndpoint?: EndpointRequest | undefined;
}
export interface ContainerServiceECRImagePullerRoleRequest {
    isActive?: boolean | undefined;
}
export interface PrivateRegistryAccessRequest {
    ecrImagePullerRole?: ContainerServiceECRImagePullerRoleRequest | undefined;
}
export interface CreateContainerServiceRequest {
    serviceName: string;
    power: ContainerServicePowerName;
    scale: number;
    tags?: Tag[] | undefined;
    publicDomainNames?: {
        [key: string]: string[] | undefined;
    } | undefined;
    deployment?: ContainerServiceDeploymentRequest | undefined;
    privateRegistryAccess?: PrivateRegistryAccessRequest | undefined;
}
export type ContainerServiceState = "PENDING" | "READY" | "RUNNING" | "UPDATING" | "DELETING" | "DISABLED" | "DEPLOYING" | (string & {});
export type ContainerServiceStateDetailCode = "CREATING_SYSTEM_RESOURCES" | "CREATING_NETWORK_INFRASTRUCTURE" | "PROVISIONING_CERTIFICATE" | "PROVISIONING_SERVICE" | "CREATING_DEPLOYMENT" | "EVALUATING_HEALTH_CHECK" | "ACTIVATING_DEPLOYMENT" | "CERTIFICATE_LIMIT_EXCEEDED" | "UNKNOWN_ERROR" | (string & {});
export interface ContainerServiceStateDetail {
    code?: ContainerServiceStateDetailCode | undefined;
    message?: string | undefined;
}
export type ContainerServiceDeploymentState = "ACTIVATING" | "ACTIVE" | "INACTIVE" | "FAILED" | (string & {});
export interface ContainerServiceEndpoint {
    containerName?: string | undefined;
    containerPort?: number | undefined;
    healthCheck?: ContainerServiceHealthCheckConfig | undefined;
}
export interface ContainerServiceDeployment {
    version?: number | undefined;
    state?: ContainerServiceDeploymentState | undefined;
    containers?: {
        [key: string]: Container | undefined;
    } | undefined;
    publicEndpoint?: ContainerServiceEndpoint | undefined;
    createdAt?: Date | undefined;
}
export interface ContainerServiceECRImagePullerRole {
    isActive?: boolean | undefined;
    principalArn?: string | undefined;
}
export interface PrivateRegistryAccess {
    ecrImagePullerRole?: ContainerServiceECRImagePullerRole | undefined;
}
export interface ContainerService {
    containerServiceName?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    power?: ContainerServicePowerName | undefined;
    powerId?: string | undefined;
    state?: ContainerServiceState | undefined;
    stateDetail?: ContainerServiceStateDetail | undefined;
    scale?: number | undefined;
    currentDeployment?: ContainerServiceDeployment | undefined;
    nextDeployment?: ContainerServiceDeployment | undefined;
    isDisabled?: boolean | undefined;
    principalArn?: string | undefined;
    privateDomainName?: string | undefined;
    publicDomainNames?: {
        [key: string]: string[] | undefined;
    } | undefined;
    url?: string | undefined;
    privateRegistryAccess?: PrivateRegistryAccess | undefined;
}
export interface CreateContainerServiceResult {
    containerService?: ContainerService | undefined;
}
export interface CreateContainerServiceDeploymentRequest {
    serviceName: string;
    containers?: {
        [key: string]: Container | undefined;
    } | undefined;
    publicEndpoint?: EndpointRequest | undefined;
}
export interface CreateContainerServiceDeploymentResult {
    containerService?: ContainerService | undefined;
}
export interface CreateContainerServiceRegistryLoginRequest {
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface ContainerServiceRegistryLogin {
    username?: string | undefined;
    password?: string | redacted.Redacted<string> | undefined;
    expiresAt?: Date | undefined;
    registry?: string | undefined;
}
export interface CreateContainerServiceRegistryLoginResult {
    registryLogin?: ContainerServiceRegistryLogin | undefined;
}
export type AddOnType = "AutoSnapshot" | "StopInstanceOnIdle" | (string & {});
export type TimeOfDay = string;
export interface AutoSnapshotAddOnRequest {
    snapshotTimeOfDay?: string | undefined;
}
export interface StopInstanceOnIdleRequest {
    threshold?: string | undefined;
    duration?: string | undefined;
}
export interface AddOnRequest {
    addOnType: AddOnType;
    autoSnapshotAddOnRequest?: AutoSnapshotAddOnRequest | undefined;
    stopInstanceOnIdleRequest?: StopInstanceOnIdleRequest | undefined;
}
export type AddOnRequestList = AddOnRequest[];
export interface CreateDiskRequest {
    diskName: string;
    availabilityZone: string;
    sizeInGb: number;
    tags?: Tag[] | undefined;
    addOns?: AddOnRequest[] | undefined;
}
export interface CreateDiskResult {
    operations?: Operation[] | undefined;
}
export interface CreateDiskFromSnapshotRequest {
    diskName: string;
    diskSnapshotName?: string | undefined;
    availabilityZone: string;
    sizeInGb: number;
    tags?: Tag[] | undefined;
    addOns?: AddOnRequest[] | undefined;
    sourceDiskName?: string | undefined;
    restoreDate?: string | undefined;
    useLatestRestorableAutoSnapshot?: boolean | undefined;
}
export interface CreateDiskFromSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface CreateDiskSnapshotRequest {
    diskName?: string | undefined;
    diskSnapshotName: string;
    instanceName?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateDiskSnapshotResult {
    operations?: Operation[] | undefined;
}
export type OriginProtocolPolicyEnum = "http-only" | "https-only" | (string & {});
export type OriginIpAddressTypeEnum = "ipv4" | "ipv6" | "dualstack" | (string & {});
export interface InputOrigin {
    name?: string | undefined;
    regionName?: RegionName | undefined;
    protocolPolicy?: OriginProtocolPolicyEnum | undefined;
    responseTimeout?: number | undefined;
    ipAddressType?: OriginIpAddressTypeEnum | undefined;
}
export type BehaviorEnum = "dont-cache" | "cache" | (string & {});
export interface CacheBehavior {
    behavior?: BehaviorEnum | undefined;
}
export type ForwardValues = "none" | "allow-list" | "all" | (string & {});
export interface CookieObject {
    option?: ForwardValues | undefined;
    cookiesAllowList?: string[] | undefined;
}
export type HeaderEnum = "Accept" | "Accept-Charset" | "Accept-Datetime" | "Accept-Encoding" | "Accept-Language" | "Authorization" | "CloudFront-Forwarded-Proto" | "CloudFront-Is-Desktop-Viewer" | "CloudFront-Is-Mobile-Viewer" | "CloudFront-Is-SmartTV-Viewer" | "CloudFront-Is-Tablet-Viewer" | "CloudFront-Viewer-Country" | "Host" | "Origin" | "Referer" | (string & {});
export type HeaderForwardList = HeaderEnum[];
export interface HeaderObject {
    option?: ForwardValues | undefined;
    headersAllowList?: HeaderEnum[] | undefined;
}
export interface QueryStringObject {
    option?: boolean | undefined;
    queryStringsAllowList?: string[] | undefined;
}
export interface CacheSettings {
    defaultTTL?: number | undefined;
    minimumTTL?: number | undefined;
    maximumTTL?: number | undefined;
    allowedHTTPMethods?: string | undefined;
    cachedHTTPMethods?: string | undefined;
    forwardedCookies?: CookieObject | undefined;
    forwardedHeaders?: HeaderObject | undefined;
    forwardedQueryStrings?: QueryStringObject | undefined;
}
export interface CacheBehaviorPerPath {
    path?: string | undefined;
    behavior?: BehaviorEnum | undefined;
}
export type CacheBehaviorList = CacheBehaviorPerPath[];
export type IpAddressType = "dualstack" | "ipv4" | "ipv6" | (string & {});
export type ViewerMinimumTlsProtocolVersionEnum = "TLSv1.1_2016" | "TLSv1.2_2018" | "TLSv1.2_2019" | "TLSv1.2_2021" | (string & {});
export interface DistributionCustomErrorResponse {
    errorCode?: number | undefined;
    responseCode?: string | undefined;
    responsePagePath?: string | undefined;
    errorCachingMinTTL?: number | undefined;
}
export type DistributionCustomErrorResponseList = DistributionCustomErrorResponse[];
export type WafPayloadTypeEnum = "JSON" | "FORM_ENCODED" | (string & {});
export type WafStatusCodeList = number[];
export interface WafResponseInspection {
    successCodes?: number[] | undefined;
    failureCodes?: number[] | undefined;
}
export interface WafAtpConfig {
    loginPath?: string | undefined;
    payloadType?: WafPayloadTypeEnum | undefined;
    usernameField?: string | undefined;
    passwordField?: string | undefined;
    responseInspection?: WafResponseInspection | undefined;
}
export interface WafAcfpConfig {
    payloadType?: WafPayloadTypeEnum | undefined;
    creationPath?: string | undefined;
    registrationPagePath?: string | undefined;
    responseInspection?: WafResponseInspection | undefined;
}
export type WafInspectionLevelEnum = "COMMON" | "TARGETED" | (string & {});
export interface WafBotControlConfig {
    inspectionLevel?: WafInspectionLevelEnum | undefined;
}
export interface WafRule {
    name: string;
    atpConfig?: WafAtpConfig | undefined;
    acfpConfig?: WafAcfpConfig | undefined;
    botControlConfig?: WafBotControlConfig | undefined;
}
export type WafRuleList = WafRule[];
export interface CreateDistributionRequest {
    distributionName: string;
    origin: InputOrigin;
    defaultCacheBehavior: CacheBehavior;
    cacheBehaviorSettings?: CacheSettings | undefined;
    cacheBehaviors?: CacheBehaviorPerPath[] | undefined;
    bundleId: string;
    ipAddressType?: IpAddressType | undefined;
    tags?: Tag[] | undefined;
    certificateName?: string | undefined;
    viewerMinimumTlsProtocolVersion?: ViewerMinimumTlsProtocolVersionEnum | undefined;
    enablePrivateOriginAccess?: boolean | undefined;
    defaultRootObject?: string | undefined;
    customErrorResponses?: DistributionCustomErrorResponse[] | undefined;
    enableWaf?: boolean | undefined;
    wafRules?: WafRule[] | undefined;
    subdomainName?: string | undefined;
}
export interface Origin {
    name?: string | undefined;
    resourceType?: ResourceType | undefined;
    regionName?: RegionName | undefined;
    protocolPolicy?: OriginProtocolPolicyEnum | undefined;
    responseTimeout?: number | undefined;
    ipAddressType?: OriginIpAddressTypeEnum | undefined;
    isPrivateOriginAccessEnabled?: boolean | undefined;
}
export interface WafConfig {
    isWafEnabled?: boolean | undefined;
    wafRules?: WafRule[] | undefined;
}
export type LightsailDistributionSubdomainStateEnum = "Creating" | "Attaching" | "Attached" | "Error" | (string & {});
export interface LightsailDistributionSubdomain {
    name: string;
    state: LightsailDistributionSubdomainStateEnum;
    errorCode?: string | undefined;
    errorDetails?: string | undefined;
}
export interface LightsailDistribution {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    alternativeDomainNames?: string[] | undefined;
    status?: string | undefined;
    isEnabled?: boolean | undefined;
    domainName?: string | undefined;
    bundleId?: string | undefined;
    certificateName?: string | undefined;
    origin?: Origin | undefined;
    originPublicDNS?: string | undefined;
    defaultCacheBehavior?: CacheBehavior | undefined;
    cacheBehaviorSettings?: CacheSettings | undefined;
    cacheBehaviors?: CacheBehaviorPerPath[] | undefined;
    ableToUpdateBundle?: boolean | undefined;
    ipAddressType?: IpAddressType | undefined;
    tags?: Tag[] | undefined;
    viewerMinimumTlsProtocolVersion?: string | undefined;
    defaultRootObject?: string | undefined;
    customErrorResponses?: DistributionCustomErrorResponse[] | undefined;
    waf?: WafConfig | undefined;
    subdomain?: LightsailDistributionSubdomain | undefined;
}
export interface CreateDistributionResult {
    distribution?: LightsailDistribution | undefined;
    operation?: Operation | undefined;
}
export interface CreateDomainRequest {
    domainName: string;
    tags?: Tag[] | undefined;
}
export interface CreateDomainResult {
    operation?: Operation | undefined;
}
export type DomainEntryType = string;
export type DomainEntryOptionsKeys = string;
export type DomainEntryOptions = {
    [key: string]: string | undefined;
};
export interface DomainEntry {
    id?: string | undefined;
    name?: string | undefined;
    target?: string | undefined;
    isAlias?: boolean | undefined;
    type?: string | undefined;
    options?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDomainEntryRequest {
    domainName: string;
    domainEntry: DomainEntry;
}
export interface CreateDomainEntryResult {
    operation?: Operation | undefined;
}
export interface CreateGUISessionAccessDetailsRequest {
    resourceName: string;
}
export type Status = "startExpired" | "notStarted" | "started" | "starting" | "stopped" | "stopping" | "settingUpInstance" | "failedInstanceCreation" | "failedStartingGUISession" | "failedStoppingGUISession" | (string & {});
export interface Session {
    name?: string | undefined;
    url?: string | redacted.Redacted<string> | undefined;
    isPrimary?: boolean | undefined;
}
export type Sessions = Session[];
export interface CreateGUISessionAccessDetailsResult {
    resourceName?: string | undefined;
    status?: Status | undefined;
    percentageComplete?: number | undefined;
    failureReason?: string | undefined;
    sessions?: Session[] | undefined;
}
export interface CreateInstancesRequest {
    instanceNames: string[];
    availabilityZone: string;
    customImageName?: string | undefined;
    blueprintId: string;
    bundleId: string;
    userData?: string | undefined;
    keyPairName?: string | undefined;
    tags?: Tag[] | undefined;
    addOns?: AddOnRequest[] | undefined;
    ipAddressType?: IpAddressType | undefined;
}
export interface CreateInstancesResult {
    operations?: Operation[] | undefined;
}
export interface DiskMap {
    originalDiskPath?: string | undefined;
    newDiskName?: string | undefined;
}
export type DiskMapList = DiskMap[];
export type AttachedDiskMap = {
    [key: string]: DiskMap[] | undefined;
};
export interface CreateInstancesFromSnapshotRequest {
    instanceNames: string[];
    attachedDiskMapping?: {
        [key: string]: DiskMap[] | undefined;
    } | undefined;
    availabilityZone: string;
    instanceSnapshotName?: string | undefined;
    bundleId: string;
    userData?: string | undefined;
    keyPairName?: string | undefined;
    tags?: Tag[] | undefined;
    addOns?: AddOnRequest[] | undefined;
    ipAddressType?: IpAddressType | undefined;
    sourceInstanceName?: string | undefined;
    restoreDate?: string | undefined;
    useLatestRestorableAutoSnapshot?: boolean | undefined;
}
export interface CreateInstancesFromSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface CreateInstanceSnapshotRequest {
    instanceSnapshotName: string;
    instanceName: string;
    tags?: Tag[] | undefined;
}
export interface CreateInstanceSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface CreateKeyPairRequest {
    keyPairName: string;
    tags?: Tag[] | undefined;
}
export type Base64 = string;
export interface KeyPair {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    fingerprint?: string | undefined;
}
export type SensitiveBase64 = string | redacted.Redacted<string>;
export interface CreateKeyPairResult {
    keyPair?: KeyPair | undefined;
    publicKeyBase64?: string | undefined;
    privateKeyBase64?: string | redacted.Redacted<string> | undefined;
    operation?: Operation | undefined;
}
export type DomainNameList = string[];
export interface CreateLoadBalancerRequest {
    loadBalancerName: string;
    instancePort: number;
    healthCheckPath?: string | undefined;
    certificateName?: string | undefined;
    certificateDomainName?: string | undefined;
    certificateAlternativeNames?: string[] | undefined;
    tags?: Tag[] | undefined;
    ipAddressType?: IpAddressType | undefined;
    tlsPolicyName?: string | undefined;
}
export interface CreateLoadBalancerResult {
    operations?: Operation[] | undefined;
}
export interface CreateLoadBalancerTlsCertificateRequest {
    loadBalancerName: string;
    certificateName: string;
    certificateDomainName: string;
    certificateAlternativeNames?: string[] | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateLoadBalancerTlsCertificateResult {
    operations?: Operation[] | undefined;
}
export interface CreateRelationalDatabaseRequest {
    relationalDatabaseName: string;
    availabilityZone?: string | undefined;
    relationalDatabaseBlueprintId: string;
    relationalDatabaseBundleId: string;
    masterDatabaseName: string;
    masterUsername: string;
    masterUserPassword?: string | redacted.Redacted<string> | undefined;
    preferredBackupWindow?: string | undefined;
    preferredMaintenanceWindow?: string | undefined;
    publiclyAccessible?: boolean | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateRelationalDatabaseResult {
    operations?: Operation[] | undefined;
}
export interface CreateRelationalDatabaseFromSnapshotRequest {
    relationalDatabaseName: string;
    availabilityZone?: string | undefined;
    publiclyAccessible?: boolean | undefined;
    relationalDatabaseSnapshotName?: string | undefined;
    relationalDatabaseBundleId?: string | undefined;
    sourceRelationalDatabaseName?: string | undefined;
    restoreTime?: Date | undefined;
    useLatestRestorableTime?: boolean | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateRelationalDatabaseFromSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface CreateRelationalDatabaseSnapshotRequest {
    relationalDatabaseName: string;
    relationalDatabaseSnapshotName: string;
    tags?: Tag[] | undefined;
}
export interface CreateRelationalDatabaseSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface CreateSubdomainRequest {
    subdomainName: string;
    tags?: Tag[] | undefined;
}
export type SubdomainState = "CREATING" | "CREATE_FAILED" | "UNATTACHED" | "ATTACHING" | "ATTACHED" | "DETACHING" | "TRANSFERRING" | "IMPLICIT" | (string & {});
export interface SubdomainAttachableResource {
    arn?: string | undefined;
    name?: string | undefined;
    attachedAt?: Date | undefined;
}
export type SubdomainList = Subdomain[];
export interface Subdomain {
    subdomainName?: string | undefined;
    arn?: string | undefined;
    fqdn?: string | undefined;
    depth?: number | undefined;
    state?: SubdomainState | undefined;
    attachedResource?: SubdomainAttachableResource | undefined;
    attachingResource?: SubdomainAttachableResource | undefined;
    location?: ResourceLocation | undefined;
    createdAt?: Date | undefined;
    parentFqdn?: string | undefined;
    children?: Subdomain[] | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateSubdomainResult {
    subdomain?: Subdomain | undefined;
    operation?: Operation | undefined;
}
export interface DeleteAlarmRequest {
    alarmName: string;
}
export interface DeleteAlarmResult {
    operations?: Operation[] | undefined;
}
export type AutoSnapshotDate = string;
export interface DeleteAutoSnapshotRequest {
    resourceName: string;
    date: string;
}
export interface DeleteAutoSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface DeleteBucketRequest {
    bucketName: string;
    forceDelete?: boolean | undefined;
}
export interface DeleteBucketResult {
    operations?: Operation[] | undefined;
}
export interface DeleteBucketAccessKeyRequest {
    bucketName: string;
    accessKeyId: string;
}
export interface DeleteBucketAccessKeyResult {
    operations?: Operation[] | undefined;
}
export interface DeleteCertificateRequest {
    certificateName: string;
}
export interface DeleteCertificateResult {
    operations?: Operation[] | undefined;
}
export interface DeleteContactMethodRequest {
    protocol: ContactProtocol;
}
export interface DeleteContactMethodResult {
    operations?: Operation[] | undefined;
}
export interface DeleteContainerImageRequest {
    serviceName: string;
    image: string;
}
export interface DeleteContainerImageResult {
}
export interface DeleteContainerServiceRequest {
    serviceName: string;
}
export interface DeleteContainerServiceResult {
}
export interface DeleteDiskRequest {
    diskName: string;
    forceDeleteAddOns?: boolean | undefined;
}
export interface DeleteDiskResult {
    operations?: Operation[] | undefined;
}
export interface DeleteDiskSnapshotRequest {
    diskSnapshotName: string;
}
export interface DeleteDiskSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface DeleteDistributionRequest {
    distributionName?: string | undefined;
}
export interface DeleteDistributionResult {
    operation?: Operation | undefined;
}
export interface DeleteDomainRequest {
    domainName: string;
}
export interface DeleteDomainResult {
    operation?: Operation | undefined;
}
export interface DeleteDomainEntryRequest {
    domainName: string;
    domainEntry: DomainEntry;
}
export interface DeleteDomainEntryResult {
    operation?: Operation | undefined;
}
export interface DeleteInstanceRequest {
    instanceName: string;
    forceDeleteAddOns?: boolean | undefined;
}
export interface DeleteInstanceResult {
    operations?: Operation[] | undefined;
}
export interface DeleteInstanceSnapshotRequest {
    instanceSnapshotName: string;
}
export interface DeleteInstanceSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface DeleteKeyPairRequest {
    keyPairName: string;
    expectedFingerprint?: string | undefined;
}
export interface DeleteKeyPairResult {
    operation?: Operation | undefined;
}
export interface DeleteKnownHostKeysRequest {
    instanceName: string;
}
export interface DeleteKnownHostKeysResult {
    operations?: Operation[] | undefined;
}
export interface DeleteLoadBalancerRequest {
    loadBalancerName: string;
}
export interface DeleteLoadBalancerResult {
    operations?: Operation[] | undefined;
}
export interface DeleteLoadBalancerTlsCertificateRequest {
    loadBalancerName: string;
    certificateName: string;
    force?: boolean | undefined;
}
export interface DeleteLoadBalancerTlsCertificateResult {
    operations?: Operation[] | undefined;
}
export interface DeleteRelationalDatabaseRequest {
    relationalDatabaseName: string;
    skipFinalSnapshot?: boolean | undefined;
    finalRelationalDatabaseSnapshotName?: string | undefined;
}
export interface DeleteRelationalDatabaseResult {
    operations?: Operation[] | undefined;
}
export interface DeleteRelationalDatabaseSnapshotRequest {
    relationalDatabaseSnapshotName: string;
}
export interface DeleteRelationalDatabaseSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface DeleteSubdomainRequest {
    subdomainName: string;
}
export interface DeleteSubdomainResult {
    subdomain?: Subdomain | undefined;
    operation?: Operation | undefined;
}
export interface DetachCertificateFromDistributionRequest {
    distributionName: string;
}
export interface DetachCertificateFromDistributionResult {
    operation?: Operation | undefined;
}
export interface DetachDiskRequest {
    diskName: string;
}
export interface DetachDiskResult {
    operations?: Operation[] | undefined;
}
export interface DetachInstancesFromLoadBalancerRequest {
    loadBalancerName: string;
    instanceNames: string[];
}
export interface DetachInstancesFromLoadBalancerResult {
    operations?: Operation[] | undefined;
}
export interface DetachStaticIpRequest {
    staticIpName: string;
}
export interface DetachStaticIpResult {
    operations?: Operation[] | undefined;
}
export interface DisableAddOnRequest {
    addOnType: AddOnType;
    resourceName: string;
}
export interface DisableAddOnResult {
    operations?: Operation[] | undefined;
}
export interface DownloadDefaultKeyPairRequest {
}
export interface DownloadDefaultKeyPairResult {
    publicKeyBase64?: string | undefined;
    privateKeyBase64?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
}
export interface EnableAddOnRequest {
    resourceName: string;
    addOnRequest: AddOnRequest;
}
export interface EnableAddOnResult {
    operations?: Operation[] | undefined;
}
export interface ExportSnapshotRequest {
    sourceSnapshotName: string;
}
export interface ExportSnapshotResult {
    operations?: Operation[] | undefined;
}
export interface GetActiveNamesRequest {
    pageToken?: string | undefined;
}
export interface GetActiveNamesResult {
    activeNames?: string[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetAlarmsRequest {
    alarmName?: string | undefined;
    pageToken?: string | undefined;
    monitoredResourceName?: string | undefined;
}
export type ResourceArn = string;
export interface MonitoredResourceInfo {
    arn?: string | undefined;
    name?: string | undefined;
    resourceType?: ResourceType | undefined;
}
export type ComparisonOperator = "GreaterThanOrEqualToThreshold" | "GreaterThanThreshold" | "LessThanThreshold" | "LessThanOrEqualToThreshold" | (string & {});
export type MetricPeriod = number;
export type TreatMissingData = "breaching" | "notBreaching" | "ignore" | "missing" | (string & {});
export type MetricStatistic = "Minimum" | "Maximum" | "Sum" | "Average" | "SampleCount" | (string & {});
export type MetricName = "CPUUtilization" | "NetworkIn" | "NetworkOut" | "StatusCheckFailed" | "StatusCheckFailed_Instance" | "StatusCheckFailed_System" | "ClientTLSNegotiationErrorCount" | "HealthyHostCount" | "UnhealthyHostCount" | "HTTPCode_LB_4XX_Count" | "HTTPCode_LB_5XX_Count" | "HTTPCode_Instance_2XX_Count" | "HTTPCode_Instance_3XX_Count" | "HTTPCode_Instance_4XX_Count" | "HTTPCode_Instance_5XX_Count" | "InstanceResponseTime" | "RejectedConnectionCount" | "RequestCount" | "DatabaseConnections" | "DiskQueueDepth" | "FreeStorageSpace" | "NetworkReceiveThroughput" | "NetworkTransmitThroughput" | "FreeableMemory" | "SwapUsage" | "BurstCapacityTime" | "BurstCapacityPercentage" | "DiskReadOps" | "DiskWriteOps" | "DiskReadBytes" | "DiskWriteBytes" | "DiskTotalReadTime" | "DiskTotalWriteTime" | "DiskQueueLength" | (string & {});
export type AlarmState = "OK" | "ALARM" | "INSUFFICIENT_DATA" | (string & {});
export type MetricUnit = "Seconds" | "Microseconds" | "Milliseconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Count" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | "None" | (string & {});
export type ContactProtocolsList = ContactProtocol[];
export type NotificationTriggerList = AlarmState[];
export interface Alarm {
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    supportCode?: string | undefined;
    monitoredResourceInfo?: MonitoredResourceInfo | undefined;
    comparisonOperator?: ComparisonOperator | undefined;
    evaluationPeriods?: number | undefined;
    period?: number | undefined;
    threshold?: number | undefined;
    datapointsToAlarm?: number | undefined;
    treatMissingData?: TreatMissingData | undefined;
    statistic?: MetricStatistic | undefined;
    metricName?: MetricName | undefined;
    state?: AlarmState | undefined;
    unit?: MetricUnit | undefined;
    contactProtocols?: ContactProtocol[] | undefined;
    notificationTriggers?: AlarmState[] | undefined;
    notificationEnabled?: boolean | undefined;
    tags?: Tag[] | undefined;
}
export type AlarmsList = Alarm[];
export interface GetAlarmsResult {
    alarms?: Alarm[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetAutoSnapshotsRequest {
    resourceName: string;
}
export type AutoSnapshotStatus = "Success" | "Failed" | "InProgress" | "NotFound" | (string & {});
export interface AttachedDisk {
    path?: string | undefined;
    sizeInGb?: number | undefined;
}
export type AttachedDiskList = AttachedDisk[];
export interface AutoSnapshotDetails {
    date?: string | undefined;
    createdAt?: Date | undefined;
    status?: AutoSnapshotStatus | undefined;
    fromAttachedDisks?: AttachedDisk[] | undefined;
}
export type AutoSnapshotDetailsList = AutoSnapshotDetails[];
export interface GetAutoSnapshotsResult {
    resourceName?: string | undefined;
    resourceType?: ResourceType | undefined;
    autoSnapshots?: AutoSnapshotDetails[] | undefined;
}
export type AppCategory = "LfR" | (string & {});
export interface GetBlueprintsRequest {
    includeInactive?: boolean | undefined;
    pageToken?: string | undefined;
    appCategory?: AppCategory | undefined;
}
export type BlueprintType = "os" | "app" | (string & {});
export type InstancePlatform = "LINUX_UNIX" | "WINDOWS" | (string & {});
export interface Blueprint {
    blueprintId?: string | undefined;
    name?: string | undefined;
    group?: string | undefined;
    type?: BlueprintType | undefined;
    description?: string | undefined;
    isActive?: boolean | undefined;
    minPower?: number | undefined;
    version?: string | undefined;
    versionCode?: string | undefined;
    productUrl?: string | undefined;
    licenseUrl?: string | undefined;
    platform?: InstancePlatform | undefined;
    appCategory?: AppCategory | undefined;
}
export type BlueprintList = Blueprint[];
export interface GetBlueprintsResult {
    blueprints?: Blueprint[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetBucketAccessKeysRequest {
    bucketName: string;
}
export type AccessKeyList = AccessKey[];
export interface GetBucketAccessKeysResult {
    accessKeys?: AccessKey[] | undefined;
}
export interface GetBucketBundlesRequest {
    includeInactive?: boolean | undefined;
}
export interface BucketBundle {
    bundleId?: string | undefined;
    name?: string | undefined;
    price?: number | undefined;
    storagePerMonthInGb?: number | undefined;
    transferPerMonthInGb?: number | undefined;
    isActive?: boolean | undefined;
}
export type BucketBundleList = BucketBundle[];
export interface GetBucketBundlesResult {
    bundles?: BucketBundle[] | undefined;
}
export type BucketMetricName = "BucketSizeBytes" | "NumberOfObjects" | (string & {});
export type MetricStatisticList = MetricStatistic[];
export interface GetBucketMetricDataRequest {
    bucketName: string;
    metricName: BucketMetricName;
    startTime: Date;
    endTime: Date;
    period: number;
    statistics: MetricStatistic[];
    unit: MetricUnit;
}
export interface MetricDatapoint {
    average?: number | undefined;
    maximum?: number | undefined;
    minimum?: number | undefined;
    sampleCount?: number | undefined;
    sum?: number | undefined;
    timestamp?: Date | undefined;
    unit?: MetricUnit | undefined;
}
export type MetricDatapointList = MetricDatapoint[];
export interface GetBucketMetricDataResult {
    metricName?: BucketMetricName | undefined;
    metricData?: MetricDatapoint[] | undefined;
}
export interface GetBucketsRequest {
    bucketName?: string | undefined;
    pageToken?: string | undefined;
    includeConnectedResources?: boolean | undefined;
    includeCors?: boolean | undefined;
}
export type BucketList = Bucket[];
export type AccountLevelBpaSyncStatus = "InSync" | "Failed" | "NeverSynced" | "Defaulted" | (string & {});
export type BPAStatusMessage = "DEFAULTED_FOR_SLR_MISSING" | "SYNC_ON_HOLD" | "DEFAULTED_FOR_SLR_MISSING_ON_HOLD" | "Unknown" | (string & {});
export interface AccountLevelBpaSync {
    status?: AccountLevelBpaSyncStatus | undefined;
    lastSyncedAt?: Date | undefined;
    message?: BPAStatusMessage | undefined;
    bpaImpactsLightsail?: boolean | undefined;
}
export interface GetBucketsResult {
    buckets?: Bucket[] | undefined;
    nextPageToken?: string | undefined;
    accountLevelBpaSync?: AccountLevelBpaSync | undefined;
}
export interface GetBundlesRequest {
    includeInactive?: boolean | undefined;
    pageToken?: string | undefined;
    appCategory?: AppCategory | undefined;
}
export type InstancePlatformList = InstancePlatform[];
export type AppCategoryList = AppCategory[];
export interface Bundle {
    price?: number | undefined;
    cpuCount?: number | undefined;
    diskSizeInGb?: number | undefined;
    bundleId?: string | undefined;
    instanceType?: string | undefined;
    isActive?: boolean | undefined;
    name?: string | undefined;
    power?: number | undefined;
    ramSizeInGb?: number | undefined;
    transferPerMonthInGb?: number | undefined;
    supportedPlatforms?: InstancePlatform[] | undefined;
    supportedAppCategories?: AppCategory[] | undefined;
    publicIpv4AddressCount?: number | undefined;
}
export type BundleList = Bundle[];
export interface GetBundlesResult {
    bundles?: Bundle[] | undefined;
    nextPageToken?: string | undefined;
}
export type CertificateStatusList = CertificateStatus[];
export type IncludeCertificateDetails = boolean;
export interface GetCertificatesRequest {
    certificateStatuses?: CertificateStatus[] | undefined;
    includeCertificateDetails?: boolean | undefined;
    certificateName?: string | undefined;
    pageToken?: string | undefined;
}
export type CertificateSummaryList = CertificateSummary[];
export interface GetCertificatesResult {
    certificates?: CertificateSummary[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetCloudFormationStackRecordsRequest {
    pageToken?: string | undefined;
}
export type RecordState = "Started" | "Succeeded" | "Failed" | (string & {});
export type CloudFormationStackRecordSourceType = "ExportSnapshotRecord" | (string & {});
export interface CloudFormationStackRecordSourceInfo {
    resourceType?: CloudFormationStackRecordSourceType | undefined;
    name?: string | undefined;
    arn?: string | undefined;
}
export type CloudFormationStackRecordSourceInfoList = CloudFormationStackRecordSourceInfo[];
export interface DestinationInfo {
    id?: string | undefined;
    service?: string | undefined;
}
export interface CloudFormationStackRecord {
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    state?: RecordState | undefined;
    sourceInfo?: CloudFormationStackRecordSourceInfo[] | undefined;
    destinationInfo?: DestinationInfo | undefined;
}
export type CloudFormationStackRecordList = CloudFormationStackRecord[];
export interface GetCloudFormationStackRecordsResult {
    cloudFormationStackRecords?: CloudFormationStackRecord[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetContactMethodsRequest {
    protocols?: ContactProtocol[] | undefined;
}
export type ContactMethodStatus = "PendingVerification" | "Valid" | "Invalid" | (string & {});
export interface ContactMethod {
    contactEndpoint?: string | undefined;
    status?: ContactMethodStatus | undefined;
    protocol?: ContactProtocol | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    supportCode?: string | undefined;
    tags?: Tag[] | undefined;
}
export type ContactMethodsList = ContactMethod[];
export interface GetContactMethodsResult {
    contactMethods?: ContactMethod[] | undefined;
}
export interface GetContainerAPIMetadataRequest {
}
export type ContainerServiceMetadataEntry = {
    [key: string]: string | undefined;
};
export type ContainerServiceMetadataEntryList = {
    [key: string]: string | undefined;
}[];
export interface GetContainerAPIMetadataResult {
    metadata?: {
        [key: string]: string | undefined;
    }[] | undefined;
}
export interface GetContainerImagesRequest {
    serviceName: string;
}
export interface ContainerImage {
    image?: string | undefined;
    digest?: string | undefined;
    createdAt?: Date | undefined;
}
export type ContainerImageList = ContainerImage[];
export interface GetContainerImagesResult {
    containerImages?: ContainerImage[] | undefined;
}
export interface GetContainerLogRequest {
    serviceName: string;
    containerName: string;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    filterPattern?: string | undefined;
    pageToken?: string | undefined;
}
export interface ContainerServiceLogEvent {
    createdAt?: Date | undefined;
    message?: string | undefined;
}
export type ContainerServiceLogEventList = ContainerServiceLogEvent[];
export interface GetContainerLogResult {
    logEvents?: ContainerServiceLogEvent[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetContainerServiceDeploymentsRequest {
    serviceName: string;
}
export type ContainerServiceDeploymentList = ContainerServiceDeployment[];
export interface GetContainerServiceDeploymentsResult {
    deployments?: ContainerServiceDeployment[] | undefined;
}
export type ContainerServiceMetricName = "CPUUtilization" | "MemoryUtilization" | (string & {});
export interface GetContainerServiceMetricDataRequest {
    serviceName: string;
    metricName: ContainerServiceMetricName;
    startTime: Date;
    endTime: Date;
    period: number;
    statistics: MetricStatistic[];
}
export interface GetContainerServiceMetricDataResult {
    metricName?: ContainerServiceMetricName | undefined;
    metricData?: MetricDatapoint[] | undefined;
}
export interface GetContainerServicePowersRequest {
}
export interface ContainerServicePower {
    powerId?: string | undefined;
    price?: number | undefined;
    cpuCount?: number | undefined;
    ramSizeInGb?: number | undefined;
    name?: string | undefined;
    isActive?: boolean | undefined;
}
export type ContainerServicePowerList = ContainerServicePower[];
export interface GetContainerServicePowersResult {
    powers?: ContainerServicePower[] | undefined;
}
export interface GetContainerServicesRequest {
    serviceName?: string | undefined;
}
export type ContainerServiceList = ContainerService[];
export interface ContainerServicesListResult {
    containerServices?: ContainerService[] | undefined;
}
export interface GetCostEstimateRequest {
    resourceName: string;
    startTime: Date;
    endTime: Date;
}
export type PricingUnit = "GB" | "Hrs" | "GB-Mo" | "Bundles" | "Queries" | (string & {});
export type Currency = "USD" | (string & {});
export interface TimePeriod {
    start?: Date | undefined;
    end?: Date | undefined;
}
export interface EstimateByTime {
    usageCost?: number | undefined;
    pricingUnit?: PricingUnit | undefined;
    unit?: number | undefined;
    currency?: Currency | undefined;
    timePeriod?: TimePeriod | undefined;
}
export type EstimatesByTime = EstimateByTime[];
export interface CostEstimate {
    usageType?: string | undefined;
    resultsByTime?: EstimateByTime[] | undefined;
}
export type CostEstimates = CostEstimate[];
export interface ResourceBudgetEstimate {
    resourceName?: string | undefined;
    resourceType?: ResourceType | undefined;
    costEstimates?: CostEstimate[] | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type ResourcesBudgetEstimate = ResourceBudgetEstimate[];
export interface GetCostEstimateResult {
    resourcesBudgetEstimate?: ResourceBudgetEstimate[] | undefined;
}
export interface GetDiskRequest {
    diskName: string;
}
export interface AddOn {
    name?: string | undefined;
    status?: string | undefined;
    snapshotTimeOfDay?: string | undefined;
    nextSnapshotTimeOfDay?: string | undefined;
    threshold?: string | undefined;
    duration?: string | undefined;
}
export type AddOnList = AddOn[];
export type DiskState = "pending" | "error" | "available" | "in-use" | "unknown" | (string & {});
export type AutoMountStatus = "Failed" | "Pending" | "Mounted" | "NotMounted" | (string & {});
export interface Disk {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    addOns?: AddOn[] | undefined;
    sizeInGb?: number | undefined;
    isSystemDisk?: boolean | undefined;
    iops?: number | undefined;
    path?: string | undefined;
    state?: DiskState | undefined;
    attachedTo?: string | undefined;
    isAttached?: boolean | undefined;
    attachmentState?: string | undefined;
    gbInUse?: number | undefined;
    autoMountStatus?: AutoMountStatus | undefined;
}
export interface GetDiskResult {
    disk?: Disk | undefined;
}
export interface GetDisksRequest {
    pageToken?: string | undefined;
}
export type DiskList = Disk[];
export interface GetDisksResult {
    disks?: Disk[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetDiskSnapshotRequest {
    diskSnapshotName: string;
}
export type DiskSnapshotState = "pending" | "completed" | "error" | "unknown" | (string & {});
export interface DiskSnapshot {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    sizeInGb?: number | undefined;
    state?: DiskSnapshotState | undefined;
    progress?: string | undefined;
    fromDiskName?: string | undefined;
    fromDiskArn?: string | undefined;
    fromInstanceName?: string | undefined;
    fromInstanceArn?: string | undefined;
    isFromAutoSnapshot?: boolean | undefined;
}
export interface GetDiskSnapshotResult {
    diskSnapshot?: DiskSnapshot | undefined;
}
export interface GetDiskSnapshotsRequest {
    pageToken?: string | undefined;
}
export type DiskSnapshotList = DiskSnapshot[];
export interface GetDiskSnapshotsResult {
    diskSnapshots?: DiskSnapshot[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetDistributionBundlesRequest {
}
export interface DistributionBundle {
    bundleId?: string | undefined;
    name?: string | undefined;
    price?: number | undefined;
    transferPerMonthInGb?: number | undefined;
    isActive?: boolean | undefined;
}
export type DistributionBundleList = DistributionBundle[];
export interface GetDistributionBundlesResult {
    bundles?: DistributionBundle[] | undefined;
}
export interface GetDistributionLatestCacheResetRequest {
    distributionName?: string | undefined;
}
export interface GetDistributionLatestCacheResetResult {
    status?: string | undefined;
    createTime?: Date | undefined;
}
export type DistributionMetricName = "Requests" | "BytesDownloaded" | "BytesUploaded" | "TotalErrorRate" | "Http4xxErrorRate" | "Http5xxErrorRate" | "WafAllowedRequests" | "WafBlockedRequests" | (string & {});
export interface GetDistributionMetricDataRequest {
    distributionName: string;
    metricName: DistributionMetricName;
    startTime: Date;
    endTime: Date;
    period: number;
    unit: MetricUnit;
    statistics: MetricStatistic[];
}
export interface GetDistributionMetricDataResult {
    metricName?: DistributionMetricName | undefined;
    metricData?: MetricDatapoint[] | undefined;
}
export interface GetDistributionsRequest {
    distributionName?: string | undefined;
    pageToken?: string | undefined;
}
export type DistributionList = LightsailDistribution[];
export interface GetDistributionsResult {
    distributions?: LightsailDistribution[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetDomainRequest {
    domainName: string;
}
export type DomainEntryList = DomainEntry[];
export type NameServersUpdateStateCode = "SUCCEEDED" | "PENDING" | "FAILED" | "STARTED" | (string & {});
export interface NameServersUpdateState {
    code?: NameServersUpdateStateCode | undefined;
    message?: string | undefined;
}
export type R53HostedZoneDeletionStateCode = "SUCCEEDED" | "PENDING" | "FAILED" | "STARTED" | (string & {});
export interface R53HostedZoneDeletionState {
    code?: R53HostedZoneDeletionStateCode | undefined;
    message?: string | undefined;
}
export interface RegisteredDomainDelegationInfo {
    nameServersUpdateState?: NameServersUpdateState | undefined;
    r53HostedZoneDeletionState?: R53HostedZoneDeletionState | undefined;
}
export interface Domain {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    domainEntries?: DomainEntry[] | undefined;
    registeredDomainDelegationInfo?: RegisteredDomainDelegationInfo | undefined;
}
export interface GetDomainResult {
    domain?: Domain | undefined;
}
export interface GetDomainsRequest {
    pageToken?: string | undefined;
}
export type DomainList = Domain[];
export interface GetDomainsResult {
    domains?: Domain[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetExportSnapshotRecordsRequest {
    pageToken?: string | undefined;
}
export type ExportSnapshotRecordSourceType = "InstanceSnapshot" | "DiskSnapshot" | (string & {});
export interface DiskInfo {
    name?: string | undefined;
    path?: string | undefined;
    sizeInGb?: number | undefined;
    isSystemDisk?: boolean | undefined;
}
export type DiskInfoList = DiskInfo[];
export interface InstanceSnapshotInfo {
    fromBundleId?: string | undefined;
    fromBlueprintId?: string | undefined;
    fromDiskInfo?: DiskInfo[] | undefined;
}
export interface DiskSnapshotInfo {
    sizeInGb?: number | undefined;
}
export interface ExportSnapshotRecordSourceInfo {
    resourceType?: ExportSnapshotRecordSourceType | undefined;
    createdAt?: Date | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    fromResourceName?: string | undefined;
    fromResourceArn?: string | undefined;
    instanceSnapshotInfo?: InstanceSnapshotInfo | undefined;
    diskSnapshotInfo?: DiskSnapshotInfo | undefined;
}
export interface ExportSnapshotRecord {
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    state?: RecordState | undefined;
    sourceInfo?: ExportSnapshotRecordSourceInfo | undefined;
    destinationInfo?: DestinationInfo | undefined;
}
export type ExportSnapshotRecordList = ExportSnapshotRecord[];
export interface GetExportSnapshotRecordsResult {
    exportSnapshotRecords?: ExportSnapshotRecord[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetInstanceRequest {
    instanceName: string;
    includeHealthStatus?: boolean | undefined;
}
export type IpAddress = string;
export type Ipv6Address = string;
export type Ipv6AddressList = string[];
export interface InstanceHardware {
    cpuCount?: number | undefined;
    disks?: Disk[] | undefined;
    ramSizeInGb?: number | undefined;
}
export interface MonthlyTransfer {
    gbPerMonthAllocated?: number | undefined;
}
export type PortAccessType = "Public" | "Private" | (string & {});
export type AccessDirection = "inbound" | "outbound" | (string & {});
export interface InstancePortInfo {
    fromPort?: number | undefined;
    toPort?: number | undefined;
    protocol?: NetworkProtocol | undefined;
    accessFrom?: string | undefined;
    accessType?: PortAccessType | undefined;
    commonName?: string | undefined;
    accessDirection?: AccessDirection | undefined;
    cidrs?: string[] | undefined;
    ipv6Cidrs?: string[] | undefined;
    cidrListAliases?: string[] | undefined;
}
export type InstancePortInfoList = InstancePortInfo[];
export interface InstanceNetworking {
    monthlyTransfer?: MonthlyTransfer | undefined;
    ports?: InstancePortInfo[] | undefined;
}
export interface InstanceState {
    code?: number | undefined;
    name?: string | undefined;
}
export type InstanceMetadataState = "pending" | "applied" | (string & {});
export type HttpTokens = "optional" | "required" | (string & {});
export type HttpEndpoint = "disabled" | "enabled" | (string & {});
export type HttpProtocolIpv6 = "disabled" | "enabled" | (string & {});
export interface InstanceMetadataOptions {
    state?: InstanceMetadataState | undefined;
    httpTokens?: HttpTokens | undefined;
    httpEndpoint?: HttpEndpoint | undefined;
    httpPutResponseHopLimit?: number | undefined;
    httpProtocolIpv6?: HttpProtocolIpv6 | undefined;
}
export type InstanceHealthStatusValue = "ok" | "impaired" | "initializing" | "insufficient-data" | "not-applicable" | (string & {});
export type InstanceHealthStatusDetailName = "reachability" | (string & {});
export type InstanceHealthStatusDetailValue = "passed" | "failed" | "insufficient-data" | "initializing" | (string & {});
export interface InstanceHealthStatusDetail {
    name?: InstanceHealthStatusDetailName | undefined;
    status?: InstanceHealthStatusDetailValue | undefined;
    impairedSince?: Date | undefined;
}
export type InstanceHealthStatusDetailList = InstanceHealthStatusDetail[];
export interface InstanceHealthStatus {
    status?: InstanceHealthStatusValue | undefined;
    details?: InstanceHealthStatusDetail[] | undefined;
}
export interface Instance {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    blueprintId?: string | undefined;
    blueprintName?: string | undefined;
    bundleId?: string | undefined;
    addOns?: AddOn[] | undefined;
    isStaticIp?: boolean | undefined;
    privateIpAddress?: string | undefined;
    publicIpAddress?: string | undefined;
    ipv6Addresses?: string[] | undefined;
    ipAddressType?: IpAddressType | undefined;
    hardware?: InstanceHardware | undefined;
    networking?: InstanceNetworking | undefined;
    state?: InstanceState | undefined;
    username?: string | undefined;
    sshKeyName?: string | undefined;
    metadataOptions?: InstanceMetadataOptions | undefined;
    instanceStatus?: InstanceHealthStatus | undefined;
    systemStatus?: InstanceHealthStatus | undefined;
}
export interface GetInstanceResult {
    instance?: Instance | undefined;
}
export type InstanceAccessProtocol = "ssh" | "rdp" | (string & {});
export interface GetInstanceAccessDetailsRequest {
    instanceName: string;
    protocol?: InstanceAccessProtocol | undefined;
}
export interface PasswordData {
    ciphertext?: string | redacted.Redacted<string> | undefined;
    keyPairName?: string | undefined;
}
export interface HostKeyAttributes {
    algorithm?: string | undefined;
    publicKey?: string | undefined;
    witnessedAt?: Date | undefined;
    fingerprintSHA1?: string | undefined;
    fingerprintSHA256?: string | undefined;
    notValidBefore?: Date | undefined;
    notValidAfter?: Date | undefined;
}
export type HostKeysList = HostKeyAttributes[];
export interface InstanceAccessDetails {
    certKey?: string | undefined;
    expiresAt?: Date | undefined;
    ipAddress?: string | undefined;
    ipv6Addresses?: string[] | undefined;
    password?: string | redacted.Redacted<string> | undefined;
    passwordData?: PasswordData | undefined;
    privateKey?: string | redacted.Redacted<string> | undefined;
    protocol?: InstanceAccessProtocol | undefined;
    instanceName?: string | undefined;
    username?: string | undefined;
    hostKeys?: HostKeyAttributes[] | undefined;
}
export interface GetInstanceAccessDetailsResult {
    accessDetails?: InstanceAccessDetails | undefined;
}
export type InstanceMetricName = "CPUUtilization" | "NetworkIn" | "NetworkOut" | "StatusCheckFailed" | "StatusCheckFailed_Instance" | "StatusCheckFailed_System" | "BurstCapacityTime" | "BurstCapacityPercentage" | "MetadataNoToken" | "DiskReadOps" | "DiskWriteOps" | "DiskReadBytes" | "DiskWriteBytes" | "DiskTotalReadTime" | "DiskTotalWriteTime" | "DiskQueueLength" | (string & {});
export interface GetInstanceMetricDataRequest {
    instanceName: string;
    metricName: InstanceMetricName;
    period: number;
    startTime: Date;
    endTime: Date;
    unit: MetricUnit;
    statistics: MetricStatistic[];
}
export interface GetInstanceMetricDataResult {
    metricName?: InstanceMetricName | undefined;
    metricData?: MetricDatapoint[] | undefined;
}
export interface GetInstancePortStatesRequest {
    instanceName: string;
}
export type PortState = "open" | "closed" | (string & {});
export interface InstancePortState {
    fromPort?: number | undefined;
    toPort?: number | undefined;
    protocol?: NetworkProtocol | undefined;
    state?: PortState | undefined;
    cidrs?: string[] | undefined;
    ipv6Cidrs?: string[] | undefined;
    cidrListAliases?: string[] | undefined;
}
export type InstancePortStateList = InstancePortState[];
export interface GetInstancePortStatesResult {
    portStates?: InstancePortState[] | undefined;
}
export interface GetInstancesRequest {
    pageToken?: string | undefined;
    includeHealthStatus?: boolean | undefined;
}
export type InstanceList = Instance[];
export interface GetInstancesResult {
    instances?: Instance[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetInstanceSnapshotRequest {
    instanceSnapshotName: string;
}
export type InstanceSnapshotState = "pending" | "error" | "available" | (string & {});
export interface InstanceSnapshot {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    state?: InstanceSnapshotState | undefined;
    progress?: string | undefined;
    fromAttachedDisks?: Disk[] | undefined;
    fromInstanceName?: string | undefined;
    fromInstanceArn?: string | undefined;
    fromBlueprintId?: string | undefined;
    fromBundleId?: string | undefined;
    isFromAutoSnapshot?: boolean | undefined;
    sizeInGb?: number | undefined;
}
export interface GetInstanceSnapshotResult {
    instanceSnapshot?: InstanceSnapshot | undefined;
}
export interface GetInstanceSnapshotsRequest {
    pageToken?: string | undefined;
}
export type InstanceSnapshotList = InstanceSnapshot[];
export interface GetInstanceSnapshotsResult {
    instanceSnapshots?: InstanceSnapshot[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetInstanceStateRequest {
    instanceName: string;
}
export interface GetInstanceStateResult {
    state?: InstanceState | undefined;
}
export interface GetKeyPairRequest {
    keyPairName: string;
}
export interface GetKeyPairResult {
    keyPair?: KeyPair | undefined;
}
export interface GetKeyPairsRequest {
    pageToken?: string | undefined;
    includeDefaultKeyPair?: boolean | undefined;
}
export type KeyPairList = KeyPair[];
export interface GetKeyPairsResult {
    keyPairs?: KeyPair[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetLoadBalancerRequest {
    loadBalancerName: string;
}
export type LoadBalancerState = "active" | "provisioning" | "active_impaired" | "failed" | "unknown" | (string & {});
export type LoadBalancerProtocol = "HTTP_HTTPS" | "HTTP" | (string & {});
export type PortList = number[];
export type InstanceHealthState = "initial" | "healthy" | "unhealthy" | "unused" | "draining" | "unavailable" | (string & {});
export type InstanceHealthReason = "Lb.RegistrationInProgress" | "Lb.InitialHealthChecking" | "Lb.InternalError" | "Instance.ResponseCodeMismatch" | "Instance.Timeout" | "Instance.FailedHealthChecks" | "Instance.NotRegistered" | "Instance.NotInUse" | "Instance.DeregistrationInProgress" | "Instance.InvalidState" | "Instance.IpUnusable" | (string & {});
export interface InstanceHealthSummary {
    instanceName?: string | undefined;
    instanceHealth?: InstanceHealthState | undefined;
    instanceHealthReason?: InstanceHealthReason | undefined;
}
export type InstanceHealthSummaryList = InstanceHealthSummary[];
export interface LoadBalancerTlsCertificateSummary {
    name?: string | undefined;
    isAttached?: boolean | undefined;
}
export type LoadBalancerTlsCertificateSummaryList = LoadBalancerTlsCertificateSummary[];
export type LoadBalancerAttributeName = "HealthCheckPath" | "SessionStickinessEnabled" | "SessionStickiness_LB_CookieDurationSeconds" | "HttpsRedirectionEnabled" | "TlsPolicyName" | (string & {});
export type LoadBalancerConfigurationOptions = {
    [key in LoadBalancerAttributeName]?: string | undefined;
};
export interface LoadBalancer {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    dnsName?: string | undefined;
    state?: LoadBalancerState | undefined;
    protocol?: LoadBalancerProtocol | undefined;
    publicPorts?: number[] | undefined;
    healthCheckPath?: string | undefined;
    instancePort?: number | undefined;
    instanceHealthSummary?: InstanceHealthSummary[] | undefined;
    tlsCertificateSummaries?: LoadBalancerTlsCertificateSummary[] | undefined;
    configurationOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    ipAddressType?: IpAddressType | undefined;
    httpsRedirectionEnabled?: boolean | undefined;
    tlsPolicyName?: string | undefined;
}
export interface GetLoadBalancerResult {
    loadBalancer?: LoadBalancer | undefined;
}
export type LoadBalancerMetricName = "ClientTLSNegotiationErrorCount" | "HealthyHostCount" | "UnhealthyHostCount" | "HTTPCode_LB_4XX_Count" | "HTTPCode_LB_5XX_Count" | "HTTPCode_Instance_2XX_Count" | "HTTPCode_Instance_3XX_Count" | "HTTPCode_Instance_4XX_Count" | "HTTPCode_Instance_5XX_Count" | "InstanceResponseTime" | "RejectedConnectionCount" | "RequestCount" | (string & {});
export interface GetLoadBalancerMetricDataRequest {
    loadBalancerName: string;
    metricName: LoadBalancerMetricName;
    period: number;
    startTime: Date;
    endTime: Date;
    unit: MetricUnit;
    statistics: MetricStatistic[];
}
export interface GetLoadBalancerMetricDataResult {
    metricName?: LoadBalancerMetricName | undefined;
    metricData?: MetricDatapoint[] | undefined;
}
export interface GetLoadBalancersRequest {
    pageToken?: string | undefined;
}
export type LoadBalancerList = LoadBalancer[];
export interface GetLoadBalancersResult {
    loadBalancers?: LoadBalancer[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetLoadBalancerTlsCertificatesRequest {
    loadBalancerName: string;
}
export type LoadBalancerTlsCertificateStatus = "PENDING_VALIDATION" | "ISSUED" | "INACTIVE" | "EXPIRED" | "VALIDATION_TIMED_OUT" | "REVOKED" | "FAILED" | "UNKNOWN" | (string & {});
export type LoadBalancerTlsCertificateDomainStatus = "PENDING_VALIDATION" | "FAILED" | "SUCCESS" | (string & {});
export type LoadBalancerTlsCertificateDnsRecordCreationStateCode = "SUCCEEDED" | "STARTED" | "FAILED" | (string & {});
export interface LoadBalancerTlsCertificateDnsRecordCreationState {
    code?: LoadBalancerTlsCertificateDnsRecordCreationStateCode | undefined;
    message?: string | undefined;
}
export interface LoadBalancerTlsCertificateDomainValidationRecord {
    name?: string | undefined;
    type?: string | undefined;
    value?: string | undefined;
    validationStatus?: LoadBalancerTlsCertificateDomainStatus | undefined;
    domainName?: string | undefined;
    dnsRecordCreationState?: LoadBalancerTlsCertificateDnsRecordCreationState | undefined;
}
export type LoadBalancerTlsCertificateDomainValidationRecordList = LoadBalancerTlsCertificateDomainValidationRecord[];
export type LoadBalancerTlsCertificateFailureReason = "NO_AVAILABLE_CONTACTS" | "ADDITIONAL_VERIFICATION_REQUIRED" | "DOMAIN_NOT_ALLOWED" | "INVALID_PUBLIC_DOMAIN" | "OTHER" | (string & {});
export type LoadBalancerTlsCertificateRenewalStatus = "PENDING_AUTO_RENEWAL" | "PENDING_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export interface LoadBalancerTlsCertificateDomainValidationOption {
    domainName?: string | undefined;
    validationStatus?: LoadBalancerTlsCertificateDomainStatus | undefined;
}
export type LoadBalancerTlsCertificateDomainValidationOptionList = LoadBalancerTlsCertificateDomainValidationOption[];
export interface LoadBalancerTlsCertificateRenewalSummary {
    renewalStatus?: LoadBalancerTlsCertificateRenewalStatus | undefined;
    domainValidationOptions?: LoadBalancerTlsCertificateDomainValidationOption[] | undefined;
}
export type LoadBalancerTlsCertificateRevocationReason = "UNSPECIFIED" | "KEY_COMPROMISE" | "CA_COMPROMISE" | "AFFILIATION_CHANGED" | "SUPERCEDED" | "CESSATION_OF_OPERATION" | "CERTIFICATE_HOLD" | "REMOVE_FROM_CRL" | "PRIVILEGE_WITHDRAWN" | "A_A_COMPROMISE" | (string & {});
export interface LoadBalancerTlsCertificate {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    loadBalancerName?: string | undefined;
    isAttached?: boolean | undefined;
    status?: LoadBalancerTlsCertificateStatus | undefined;
    domainName?: string | undefined;
    domainValidationRecords?: LoadBalancerTlsCertificateDomainValidationRecord[] | undefined;
    failureReason?: LoadBalancerTlsCertificateFailureReason | undefined;
    issuedAt?: Date | undefined;
    issuer?: string | undefined;
    keyAlgorithm?: string | undefined;
    notAfter?: Date | undefined;
    notBefore?: Date | undefined;
    renewalSummary?: LoadBalancerTlsCertificateRenewalSummary | undefined;
    revocationReason?: LoadBalancerTlsCertificateRevocationReason | undefined;
    revokedAt?: Date | undefined;
    serial?: string | undefined;
    signatureAlgorithm?: string | undefined;
    subject?: string | undefined;
    subjectAlternativeNames?: string[] | undefined;
}
export type LoadBalancerTlsCertificateList = LoadBalancerTlsCertificate[];
export interface GetLoadBalancerTlsCertificatesResult {
    tlsCertificates?: LoadBalancerTlsCertificate[] | undefined;
}
export interface GetLoadBalancerTlsPoliciesRequest {
    pageToken?: string | undefined;
}
export interface LoadBalancerTlsPolicy {
    name?: string | undefined;
    isDefault?: boolean | undefined;
    description?: string | undefined;
    protocols?: string[] | undefined;
    ciphers?: string[] | undefined;
}
export type LoadBalancerTlsPolicyList = LoadBalancerTlsPolicy[];
export interface GetLoadBalancerTlsPoliciesResult {
    tlsPolicies?: LoadBalancerTlsPolicy[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetOperationRequest {
    operationId: string;
}
export interface GetOperationResult {
    operation?: Operation | undefined;
}
export interface GetOperationsRequest {
    pageToken?: string | undefined;
}
export interface GetOperationsResult {
    operations?: Operation[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetOperationsForResourceRequest {
    resourceName: string;
    pageToken?: string | undefined;
}
export interface GetOperationsForResourceResult {
    operations?: Operation[] | undefined;
    nextPageCount?: string | undefined;
    nextPageToken?: string | undefined;
}
export interface GetProfileRequest {
}
export type ProfileType = "Lightsailor" | "LightsailPartner" | (string & {});
export type TierName = "Essential" | "Growth" | "Accelerate" | "Premier" | (string & {});
export type PartnerStatus = "Active" | "Suspended" | (string & {});
export interface PartnerInfo {
    enrolledAt: Date;
    tierName?: TierName | undefined;
    status: PartnerStatus;
}
export interface GetProfileResult {
    profileType: ProfileType;
    partner?: PartnerInfo | undefined;
}
export interface GetRegionsRequest {
    includeAvailabilityZones?: boolean | undefined;
    includeRelationalDatabaseAvailabilityZones?: boolean | undefined;
}
export interface AvailabilityZone {
    zoneName?: string | undefined;
    state?: string | undefined;
}
export type AvailabilityZoneList = AvailabilityZone[];
export interface Region {
    continentCode?: string | undefined;
    description?: string | undefined;
    displayName?: string | undefined;
    name?: RegionName | undefined;
    availabilityZones?: AvailabilityZone[] | undefined;
    relationalDatabaseAvailabilityZones?: AvailabilityZone[] | undefined;
}
export type RegionList = Region[];
export interface GetRegionsResult {
    regions?: Region[] | undefined;
}
export interface GetRelationalDatabaseRequest {
    relationalDatabaseName: string;
}
export interface RelationalDatabaseHardware {
    cpuCount?: number | undefined;
    diskSizeInGb?: number | undefined;
    ramSizeInGb?: number | undefined;
}
export interface PendingModifiedRelationalDatabaseValues {
    masterUserPassword?: string | redacted.Redacted<string> | undefined;
    engineVersion?: string | undefined;
    backupRetentionEnabled?: boolean | undefined;
}
export interface RelationalDatabaseEndpoint {
    port?: number | undefined;
    address?: string | undefined;
}
export interface PendingMaintenanceAction {
    action?: string | undefined;
    description?: string | undefined;
    currentApplyDate?: Date | undefined;
}
export type PendingMaintenanceActionList = PendingMaintenanceAction[];
export interface RelationalDatabase {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    relationalDatabaseBlueprintId?: string | undefined;
    relationalDatabaseBundleId?: string | undefined;
    masterDatabaseName?: string | undefined;
    hardware?: RelationalDatabaseHardware | undefined;
    state?: string | undefined;
    secondaryAvailabilityZone?: string | undefined;
    backupRetentionEnabled?: boolean | undefined;
    pendingModifiedValues?: PendingModifiedRelationalDatabaseValues | undefined;
    engine?: string | undefined;
    engineVersion?: string | undefined;
    latestRestorableTime?: Date | undefined;
    masterUsername?: string | undefined;
    parameterApplyStatus?: string | undefined;
    preferredBackupWindow?: string | undefined;
    preferredMaintenanceWindow?: string | undefined;
    publiclyAccessible?: boolean | undefined;
    masterEndpoint?: RelationalDatabaseEndpoint | undefined;
    pendingMaintenanceActions?: PendingMaintenanceAction[] | undefined;
    caCertificateIdentifier?: string | undefined;
}
export interface GetRelationalDatabaseResult {
    relationalDatabase?: RelationalDatabase | undefined;
}
export interface GetRelationalDatabaseBlueprintsRequest {
    pageToken?: string | undefined;
}
export type RelationalDatabaseEngine = "mysql" | (string & {});
export interface RelationalDatabaseBlueprint {
    blueprintId?: string | undefined;
    engine?: RelationalDatabaseEngine | undefined;
    engineVersion?: string | undefined;
    engineDescription?: string | undefined;
    engineVersionDescription?: string | undefined;
    isEngineDefault?: boolean | undefined;
}
export type RelationalDatabaseBlueprintList = RelationalDatabaseBlueprint[];
export interface GetRelationalDatabaseBlueprintsResult {
    blueprints?: RelationalDatabaseBlueprint[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetRelationalDatabaseBundlesRequest {
    pageToken?: string | undefined;
    includeInactive?: boolean | undefined;
}
export interface RelationalDatabaseBundle {
    bundleId?: string | undefined;
    name?: string | undefined;
    price?: number | undefined;
    ramSizeInGb?: number | undefined;
    diskSizeInGb?: number | undefined;
    transferPerMonthInGb?: number | undefined;
    cpuCount?: number | undefined;
    isEncrypted?: boolean | undefined;
    isActive?: boolean | undefined;
}
export type RelationalDatabaseBundleList = RelationalDatabaseBundle[];
export interface GetRelationalDatabaseBundlesResult {
    bundles?: RelationalDatabaseBundle[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetRelationalDatabaseEventsRequest {
    relationalDatabaseName: string;
    durationInMinutes?: number | undefined;
    pageToken?: string | undefined;
}
export interface RelationalDatabaseEvent {
    resource?: string | undefined;
    createdAt?: Date | undefined;
    message?: string | undefined;
    eventCategories?: string[] | undefined;
}
export type RelationalDatabaseEventList = RelationalDatabaseEvent[];
export interface GetRelationalDatabaseEventsResult {
    relationalDatabaseEvents?: RelationalDatabaseEvent[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetRelationalDatabaseLogEventsRequest {
    relationalDatabaseName: string;
    logStreamName: string;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    startFromHead?: boolean | undefined;
    pageToken?: string | undefined;
}
export interface LogEvent {
    createdAt?: Date | undefined;
    message?: string | undefined;
}
export type LogEventList = LogEvent[];
export interface GetRelationalDatabaseLogEventsResult {
    resourceLogEvents?: LogEvent[] | undefined;
    nextBackwardToken?: string | undefined;
    nextForwardToken?: string | undefined;
}
export interface GetRelationalDatabaseLogStreamsRequest {
    relationalDatabaseName: string;
}
export interface GetRelationalDatabaseLogStreamsResult {
    logStreams?: string[] | undefined;
}
export type RelationalDatabasePasswordVersion = "CURRENT" | "PREVIOUS" | "PENDING" | (string & {});
export interface GetRelationalDatabaseMasterUserPasswordRequest {
    relationalDatabaseName: string;
    passwordVersion?: RelationalDatabasePasswordVersion | undefined;
}
export interface GetRelationalDatabaseMasterUserPasswordResult {
    masterUserPassword?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
}
export type RelationalDatabaseMetricName = "CPUUtilization" | "DatabaseConnections" | "DiskQueueDepth" | "FreeStorageSpace" | "NetworkReceiveThroughput" | "NetworkTransmitThroughput" | "FreeableMemory" | "SwapUsage" | (string & {});
export interface GetRelationalDatabaseMetricDataRequest {
    relationalDatabaseName: string;
    metricName: RelationalDatabaseMetricName;
    period: number;
    startTime: Date;
    endTime: Date;
    unit: MetricUnit;
    statistics: MetricStatistic[];
}
export interface GetRelationalDatabaseMetricDataResult {
    metricName?: RelationalDatabaseMetricName | undefined;
    metricData?: MetricDatapoint[] | undefined;
}
export interface GetRelationalDatabaseParametersRequest {
    relationalDatabaseName: string;
    pageToken?: string | undefined;
}
export interface RelationalDatabaseParameter {
    allowedValues?: string | undefined;
    applyMethod?: string | undefined;
    applyType?: string | undefined;
    dataType?: string | undefined;
    description?: string | undefined;
    isModifiable?: boolean | undefined;
    parameterName?: string | undefined;
    parameterValue?: string | undefined;
}
export type RelationalDatabaseParameterList = RelationalDatabaseParameter[];
export interface GetRelationalDatabaseParametersResult {
    parameters?: RelationalDatabaseParameter[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetRelationalDatabasesRequest {
    pageToken?: string | undefined;
}
export type RelationalDatabaseList = RelationalDatabase[];
export interface GetRelationalDatabasesResult {
    relationalDatabases?: RelationalDatabase[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetRelationalDatabaseSnapshotRequest {
    relationalDatabaseSnapshotName: string;
}
export interface RelationalDatabaseSnapshot {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    tags?: Tag[] | undefined;
    engine?: string | undefined;
    engineVersion?: string | undefined;
    sizeInGb?: number | undefined;
    state?: string | undefined;
    fromRelationalDatabaseName?: string | undefined;
    fromRelationalDatabaseArn?: string | undefined;
    fromRelationalDatabaseBundleId?: string | undefined;
    fromRelationalDatabaseBlueprintId?: string | undefined;
}
export interface GetRelationalDatabaseSnapshotResult {
    relationalDatabaseSnapshot?: RelationalDatabaseSnapshot | undefined;
}
export interface GetRelationalDatabaseSnapshotsRequest {
    pageToken?: string | undefined;
}
export type RelationalDatabaseSnapshotList = RelationalDatabaseSnapshot[];
export interface GetRelationalDatabaseSnapshotsResult {
    relationalDatabaseSnapshots?: RelationalDatabaseSnapshot[] | undefined;
    nextPageToken?: string | undefined;
}
export type SetupHistoryPageToken = string;
export interface GetSetupHistoryRequest {
    resourceName: string;
    pageToken?: string | undefined;
}
export type SetupDomainName = string;
export type SetupDomainNameList = string[];
export type CertificateProvider = "LetsEncrypt" | (string & {});
export interface SetupRequest {
    instanceName?: string | undefined;
    domainNames?: string[] | undefined;
    certificateProvider?: CertificateProvider | undefined;
}
export interface SetupHistoryResource {
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
}
export type SetupStatus = "succeeded" | "failed" | "inProgress" | (string & {});
export interface SetupExecutionDetails {
    command?: string | undefined;
    dateTime?: Date | undefined;
    name?: string | undefined;
    status?: SetupStatus | undefined;
    standardError?: string | undefined;
    standardOutput?: string | undefined;
    version?: string | undefined;
}
export type SetupExecutionDetailsList = SetupExecutionDetails[];
export interface SetupHistory {
    operationId?: string | undefined;
    request?: SetupRequest | undefined;
    resource?: SetupHistoryResource | undefined;
    executionDetails?: SetupExecutionDetails[] | undefined;
    status?: SetupStatus | undefined;
}
export type SetupHistoryList = SetupHistory[];
export interface GetSetupHistoryResult {
    setupHistory?: SetupHistory[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetStaticIpRequest {
    staticIpName: string;
}
export interface StaticIp {
    name?: string | undefined;
    arn?: string | undefined;
    supportCode?: string | undefined;
    createdAt?: Date | undefined;
    location?: ResourceLocation | undefined;
    resourceType?: ResourceType | undefined;
    ipAddress?: string | undefined;
    attachedTo?: string | undefined;
    isAttached?: boolean | undefined;
}
export interface GetStaticIpResult {
    staticIp?: StaticIp | undefined;
}
export interface GetStaticIpsRequest {
    pageToken?: string | undefined;
}
export type StaticIpList = StaticIp[];
export interface GetStaticIpsResult {
    staticIps?: StaticIp[] | undefined;
    nextPageToken?: string | undefined;
}
export interface GetSubdomainsRequest {
    subdomainName?: string | undefined;
    pageToken?: string | undefined;
}
export interface GetSubdomainsResult {
    subdomains?: Subdomain[] | undefined;
    nextPageToken?: string | undefined;
}
export interface ImportKeyPairRequest {
    keyPairName: string;
    publicKeyBase64: string;
}
export interface ImportKeyPairResult {
    operation?: Operation | undefined;
}
export interface IsVpcPeeredRequest {
}
export interface IsVpcPeeredResult {
    isPeered?: boolean | undefined;
}
export interface OpenInstancePublicPortsRequest {
    portInfo: PortInfo;
    instanceName: string;
}
export interface OpenInstancePublicPortsResult {
    operation?: Operation | undefined;
}
export interface PeerVpcRequest {
}
export interface PeerVpcResult {
    operation?: Operation | undefined;
}
export interface PutAlarmRequest {
    alarmName: string;
    metricName: MetricName;
    monitoredResourceName: string;
    comparisonOperator: ComparisonOperator;
    threshold: number;
    evaluationPeriods: number;
    datapointsToAlarm?: number | undefined;
    treatMissingData?: TreatMissingData | undefined;
    contactProtocols?: ContactProtocol[] | undefined;
    notificationTriggers?: AlarmState[] | undefined;
    notificationEnabled?: boolean | undefined;
    tags?: Tag[] | undefined;
}
export interface PutAlarmResult {
    operations?: Operation[] | undefined;
}
export type PortInfoList = PortInfo[];
export interface PutInstancePublicPortsRequest {
    portInfos: PortInfo[];
    instanceName: string;
}
export interface PutInstancePublicPortsResult {
    operation?: Operation | undefined;
}
export interface RebootInstanceRequest {
    instanceName: string;
}
export interface RebootInstanceResult {
    operations?: Operation[] | undefined;
}
export interface RebootRelationalDatabaseRequest {
    relationalDatabaseName: string;
}
export interface RebootRelationalDatabaseResult {
    operations?: Operation[] | undefined;
}
export type ContainerLabel = string;
export interface RegisterContainerImageRequest {
    serviceName: string;
    label: string;
    digest: string;
}
export interface RegisterContainerImageResult {
    containerImage?: ContainerImage | undefined;
}
export interface ReleaseStaticIpRequest {
    staticIpName: string;
}
export interface ReleaseStaticIpResult {
    operations?: Operation[] | undefined;
}
export interface ResetDistributionCacheRequest {
    distributionName?: string | undefined;
}
export interface ResetDistributionCacheResult {
    status?: string | undefined;
    createTime?: Date | undefined;
    operation?: Operation | undefined;
}
export type ContactMethodVerificationProtocol = "Email" | (string & {});
export interface SendContactMethodVerificationRequest {
    protocol: ContactMethodVerificationProtocol;
}
export interface SendContactMethodVerificationResult {
    operations?: Operation[] | undefined;
}
export interface SetIpAddressTypeRequest {
    resourceType: ResourceType;
    resourceName: string;
    ipAddressType: IpAddressType;
    acceptBundleUpdate?: boolean | undefined;
}
export interface SetIpAddressTypeResult {
    operations?: Operation[] | undefined;
}
export type ResourceBucketAccess = "allow" | "deny" | (string & {});
export interface SetResourceAccessForBucketRequest {
    resourceName: string;
    bucketName: string;
    access: ResourceBucketAccess;
}
export interface SetResourceAccessForBucketResult {
    operations?: Operation[] | undefined;
}
export type EmailAddress = string | redacted.Redacted<string>;
export interface SetupInstanceHttpsRequest {
    instanceName: string;
    emailAddress: string | redacted.Redacted<string>;
    domainNames: string[];
    certificateProvider: CertificateProvider;
}
export interface SetupInstanceHttpsResult {
    operations?: Operation[] | undefined;
}
export interface StartGUISessionRequest {
    resourceName: string;
}
export interface StartGUISessionResult {
    operations?: Operation[] | undefined;
}
export interface InstanceAttributeUpdates {
    bundleId?: string | undefined;
}
export interface StartInstanceRequest {
    instanceName: string;
    attributeUpdates?: InstanceAttributeUpdates | undefined;
}
export interface StartInstanceResult {
    operations?: Operation[] | undefined;
}
export interface StartRelationalDatabaseRequest {
    relationalDatabaseName: string;
}
export interface StartRelationalDatabaseResult {
    operations?: Operation[] | undefined;
}
export interface StopGUISessionRequest {
    resourceName: string;
}
export interface StopGUISessionResult {
    operations?: Operation[] | undefined;
}
export interface StopInstanceRequest {
    instanceName: string;
    force?: boolean | undefined;
}
export interface StopInstanceResult {
    operations?: Operation[] | undefined;
}
export interface StopRelationalDatabaseRequest {
    relationalDatabaseName: string;
    relationalDatabaseSnapshotName?: string | undefined;
}
export interface StopRelationalDatabaseResult {
    operations?: Operation[] | undefined;
}
export interface TagResourceRequest {
    resourceName: string;
    resourceArn?: string | undefined;
    tags: Tag[];
}
export interface TagResourceResult {
    operations?: Operation[] | undefined;
}
export interface TestAlarmRequest {
    alarmName: string;
    state: AlarmState;
}
export interface TestAlarmResult {
    operations?: Operation[] | undefined;
}
export interface UnpeerVpcRequest {
}
export interface UnpeerVpcResult {
    operation?: Operation | undefined;
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceName: string;
    resourceArn?: string | undefined;
    tagKeys: string[];
}
export interface UntagResourceResult {
    operations?: Operation[] | undefined;
}
export interface UpdateBucketRequest {
    bucketName: string;
    accessRules?: AccessRules | undefined;
    versioning?: string | undefined;
    readonlyAccessAccounts?: string[] | undefined;
    accessLogConfig?: BucketAccessLogConfig | undefined;
    cors?: BucketCorsConfig | undefined;
}
export interface UpdateBucketResult {
    bucket?: Bucket | undefined;
    operations?: Operation[] | undefined;
}
export interface UpdateBucketBundleRequest {
    bucketName: string;
    bundleId: string;
}
export interface UpdateBucketBundleResult {
    operations?: Operation[] | undefined;
}
export interface UpdateContainerServiceRequest {
    serviceName: string;
    power?: ContainerServicePowerName | undefined;
    scale?: number | undefined;
    isDisabled?: boolean | undefined;
    publicDomainNames?: {
        [key: string]: string[] | undefined;
    } | undefined;
    privateRegistryAccess?: PrivateRegistryAccessRequest | undefined;
}
export interface UpdateContainerServiceResult {
    containerService?: ContainerService | undefined;
}
export interface UpdateDistributionRequest {
    distributionName: string;
    origin?: InputOrigin | undefined;
    defaultCacheBehavior?: CacheBehavior | undefined;
    cacheBehaviorSettings?: CacheSettings | undefined;
    cacheBehaviors?: CacheBehaviorPerPath[] | undefined;
    isEnabled?: boolean | undefined;
    viewerMinimumTlsProtocolVersion?: ViewerMinimumTlsProtocolVersionEnum | undefined;
    certificateName?: string | undefined;
    useDefaultCertificate?: boolean | undefined;
    enablePrivateOriginAccess?: boolean | undefined;
    defaultRootObject?: string | undefined;
    customErrorResponses?: DistributionCustomErrorResponse[] | undefined;
    enableWaf?: boolean | undefined;
    wafRules?: WafRule[] | undefined;
}
export interface UpdateDistributionResult {
    operation?: Operation | undefined;
}
export interface UpdateDistributionBundleRequest {
    distributionName?: string | undefined;
    bundleId?: string | undefined;
}
export interface UpdateDistributionBundleResult {
    operation?: Operation | undefined;
}
export interface UpdateDomainEntryRequest {
    domainName: string;
    domainEntry: DomainEntry;
}
export interface UpdateDomainEntryResult {
    operations?: Operation[] | undefined;
}
export interface UpdateInstanceMetadataOptionsRequest {
    instanceName: string;
    httpTokens?: HttpTokens | undefined;
    httpEndpoint?: HttpEndpoint | undefined;
    httpPutResponseHopLimit?: number | undefined;
    httpProtocolIpv6?: HttpProtocolIpv6 | undefined;
}
export interface UpdateInstanceMetadataOptionsResult {
    operation?: Operation | undefined;
}
export interface UpdateLoadBalancerAttributeRequest {
    loadBalancerName: string;
    attributeName: LoadBalancerAttributeName;
    attributeValue: string;
}
export interface UpdateLoadBalancerAttributeResult {
    operations?: Operation[] | undefined;
}
export interface UpdateRelationalDatabaseRequest {
    relationalDatabaseName: string;
    masterUserPassword?: string | redacted.Redacted<string> | undefined;
    rotateMasterUserPassword?: boolean | undefined;
    preferredBackupWindow?: string | undefined;
    preferredMaintenanceWindow?: string | undefined;
    enableBackupRetention?: boolean | undefined;
    disableBackupRetention?: boolean | undefined;
    publiclyAccessible?: boolean | undefined;
    applyImmediately?: boolean | undefined;
    caCertificateIdentifier?: string | undefined;
    relationalDatabaseBlueprintId?: string | undefined;
}
export interface UpdateRelationalDatabaseResult {
    operations?: Operation[] | undefined;
}
export interface UpdateRelationalDatabaseParametersRequest {
    relationalDatabaseName: string;
    parameters: RelationalDatabaseParameter[];
}
export interface UpdateRelationalDatabaseParametersResult {
    operations?: Operation[] | undefined;
}
export type SubdomainAssociationAction = "ASSOCIATE" | "DISASSOCIATE" | "TRANSFER" | (string & {});
export interface UpdateSubdomainAssociationRequest {
    subdomainName: string;
    action: SubdomainAssociationAction;
    targetResourceArn?: string | undefined;
}
export interface UpdateSubdomainAssociationResult {
    subdomain?: Subdomain | undefined;
    operation?: Operation | undefined;
}
export type AllocateStaticIpError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Allocates a static IP address.
 */
export declare const allocateStaticIp: API.OperationMethod<AllocateStaticIpRequest & RegionInput, AllocateStaticIpResult, AllocateStaticIpError, Credentials | HttpClient.HttpClient>;
export type AttachCertificateToDistributionError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Attaches an SSL/TLS certificate to your Amazon Lightsail content delivery network (CDN)
 * distribution.
 *
 * After the certificate is attached, your distribution accepts HTTPS traffic for all of the
 * domains that are associated with the certificate.
 *
 * Use the `CreateCertificate` action to create a certificate that you can attach
 * to your distribution.
 *
 * Only certificates created in the `us-east-1`
 * Amazon Web Services Region can be attached to Lightsail distributions. Lightsail
 * distributions are global resources that can reference an origin in any Amazon Web Services
 * Region, and distribute its content globally. However, all distributions are located in the
 * `us-east-1` Region.
 */
export declare const attachCertificateToDistribution: API.OperationMethod<AttachCertificateToDistributionRequest & RegionInput, AttachCertificateToDistributionResult, AttachCertificateToDistributionError, Credentials | HttpClient.HttpClient>;
export type AttachDiskError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Attaches a block storage disk to a running or stopped Lightsail instance and exposes it
 * to the instance with the specified disk name.
 *
 * The `attach disk` operation supports tag-based access control via resource tags
 * applied to the resource identified by `disk name`. For more information, see the
 * Amazon Lightsail Developer Guide.
 */
export declare const attachDisk: API.OperationMethod<AttachDiskRequest & RegionInput, AttachDiskResult, AttachDiskError, Credentials | HttpClient.HttpClient>;
export type AttachInstancesToLoadBalancerError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Attaches one or more Lightsail instances to a load balancer.
 *
 * After some time, the instances are attached to the load balancer and the health check
 * status is available.
 *
 * The `attach instances to load balancer` operation supports tag-based access
 * control via resource tags applied to the resource identified by load balancer
 * name. For more information, see the Lightsail Developer Guide.
 */
export declare const attachInstancesToLoadBalancer: API.OperationMethod<AttachInstancesToLoadBalancerRequest & RegionInput, AttachInstancesToLoadBalancerResult, AttachInstancesToLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type AttachLoadBalancerTlsCertificateError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Attaches a Transport Layer Security (TLS) certificate to your load balancer. TLS is just
 * an updated, more secure version of Secure Socket Layer (SSL).
 *
 * Once you create and validate your certificate, you can attach it to your load balancer.
 * You can also use this API to rotate the certificates on your account. Use the
 * `AttachLoadBalancerTlsCertificate` action with the non-attached certificate, and
 * it will replace the existing one and become the attached certificate.
 *
 * The `AttachLoadBalancerTlsCertificate` operation supports tag-based access
 * control via resource tags applied to the resource identified by load balancer
 * name. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const attachLoadBalancerTlsCertificate: API.OperationMethod<AttachLoadBalancerTlsCertificateRequest & RegionInput, AttachLoadBalancerTlsCertificateResult, AttachLoadBalancerTlsCertificateError, Credentials | HttpClient.HttpClient>;
export type AttachStaticIpError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Attaches a static IP address to a specific Amazon Lightsail instance.
 */
export declare const attachStaticIp: API.OperationMethod<AttachStaticIpRequest & RegionInput, AttachStaticIpResult, AttachStaticIpError, Credentials | HttpClient.HttpClient>;
export type CheckSubdomainAvailabilityError = AccessDeniedException | InvalidInputException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Checks whether a Lightsail subdomain is available to create. Optionally, reserves the
 * subdomain for your account for 15 minutes.
 *
 * If you don't reserve the subdomain, another account can create it before you do.
 */
export declare const checkSubdomainAvailability: API.OperationMethod<CheckSubdomainAvailabilityRequest & RegionInput, CheckSubdomainAvailabilityResult, CheckSubdomainAvailabilityError, Credentials | HttpClient.HttpClient>;
export type CloseInstancePublicPortsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Closes ports for a specific Amazon Lightsail instance.
 *
 * The `CloseInstancePublicPorts` action supports tag-based access control via
 * resource tags applied to the resource identified by `instanceName`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const closeInstancePublicPorts: API.OperationMethod<CloseInstancePublicPortsRequest & RegionInput, CloseInstancePublicPortsResult, CloseInstancePublicPortsError, Credentials | HttpClient.HttpClient>;
export type CopySnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Copies a manual snapshot of an instance or disk as another manual snapshot, or copies an
 * automatic snapshot of an instance or disk as a manual snapshot. This operation can also be
 * used to copy a manual or automatic snapshot of an instance or a disk from one Amazon Web Services Region to another in Amazon Lightsail.
 *
 * When copying a *manual snapshot*, be sure to define the source
 * region, `source snapshot name`, and `target snapshot name`
 * parameters.
 *
 * When copying an *automatic snapshot*, be sure to define the
 * `source region`, `source resource name`, target snapshot
 * name, and either the `restore date` or the use latest restorable
 * auto snapshot parameters.
 */
export declare const copySnapshot: API.OperationMethod<CopySnapshotRequest & RegionInput, CopySnapshotResult, CopySnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateBucketError = AccessDeniedException | InvalidInputException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates an Amazon Lightsail bucket.
 *
 * A bucket is a cloud storage resource available in the Lightsail object storage service.
 * Use buckets to store objects such as data and its descriptive metadata. For more information
 * about buckets, see Buckets in Amazon Lightsail in the Amazon Lightsail Developer
 * Guide.
 */
export declare const createBucket: API.OperationMethod<CreateBucketRequest & RegionInput, CreateBucketResult, CreateBucketError, Credentials | HttpClient.HttpClient>;
export type CreateBucketAccessKeyError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a new access key for the specified Amazon Lightsail bucket. Access keys consist of
 * an access key ID and corresponding secret access key.
 *
 * Access keys grant full programmatic access to the specified bucket and its objects. You
 * can have a maximum of two access keys per bucket. Use the GetBucketAccessKeys action to get a list of current access keys for a specific bucket. For more
 * information about access keys, see Creating access keys for a bucket in Amazon Lightsail in the
 * *Amazon Lightsail Developer Guide*.
 *
 * The `secretAccessKey` value is returned only in response to the
 * `CreateBucketAccessKey` action. You can get a secret access key only when you
 * first create an access key; you cannot get the secret access key later. If you lose the
 * secret access key, you must create a new access key.
 */
export declare const createBucketAccessKey: API.OperationMethod<CreateBucketAccessKeyRequest & RegionInput, CreateBucketAccessKeyResult, CreateBucketAccessKeyError, Credentials | HttpClient.HttpClient>;
export type CreateCertificateError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates an SSL/TLS certificate for an Amazon Lightsail content delivery network (CDN)
 * distribution and a container service.
 *
 * After the certificate is valid, use the `AttachCertificateToDistribution`
 * action to use the certificate and its domains with your distribution. Or use the
 * `UpdateContainerService` action to use the certificate and its domains with your
 * container service.
 *
 * Only certificates created in the `us-east-1`
 * Amazon Web Services Region can be attached to Lightsail distributions. Lightsail
 * distributions are global resources that can reference an origin in any Amazon Web Services
 * Region, and distribute its content globally. However, all distributions are located in the
 * `us-east-1` Region.
 */
export declare const createCertificate: API.OperationMethod<CreateCertificateRequest & RegionInput, CreateCertificateResult, CreateCertificateError, Credentials | HttpClient.HttpClient>;
export type CreateCloudFormationStackError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates an AWS CloudFormation stack, which creates a new Amazon EC2 instance from an exported
 * Amazon Lightsail snapshot. This operation results in a CloudFormation stack record that can be
 * used to track the AWS CloudFormation stack created. Use the get cloud formation stack
 * records operation to get a list of the CloudFormation stacks created.
 *
 * Wait until after your new Amazon EC2 instance is created before running the create
 * cloud formation stack operation again with the same export snapshot record.
 */
export declare const createCloudFormationStack: API.OperationMethod<CreateCloudFormationStackRequest & RegionInput, CreateCloudFormationStackResult, CreateCloudFormationStackError, Credentials | HttpClient.HttpClient>;
export type CreateContactMethodError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates an email or SMS text message contact method.
 *
 * A contact method is used to send you notifications about your Amazon Lightsail resources.
 * You can add one email address and one mobile phone number contact method in each Amazon Web Services Region. However, SMS text messaging is not supported in some Amazon Web Services
 * Regions, and SMS text messages cannot be sent to some countries/regions. For more information,
 * see Notifications in Amazon Lightsail.
 *
 * The `create contact method` operation supports tag-based access control via request
 * tags. For more information, see the Lightsail Developer Guide.
 */
export declare const createContactMethod: API.OperationMethod<CreateContactMethodRequest & RegionInput, CreateContactMethodResult, CreateContactMethodError, Credentials | HttpClient.HttpClient>;
export type CreateContainerServiceError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates an Amazon Lightsail container service.
 *
 * A Lightsail container service is a compute resource to which you can deploy containers.
 * For more information, see Container services in Amazon Lightsail in the Lightsail Dev
 * Guide.
 */
export declare const createContainerService: API.OperationMethod<CreateContainerServiceRequest & RegionInput, CreateContainerServiceResult, CreateContainerServiceError, Credentials | HttpClient.HttpClient>;
export type CreateContainerServiceDeploymentError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a deployment for your Amazon Lightsail container service.
 *
 * A deployment specifies the containers that will be launched on the container service and
 * their settings, such as the ports to open, the environment variables to apply, and the launch
 * command to run. It also specifies the container that will serve as the public endpoint of the
 * deployment and its settings, such as the HTTP or HTTPS port to use, and the health check
 * configuration.
 *
 * You can deploy containers to your container service using container images from a public
 * registry such as Amazon ECR Public, or from your local machine. For more information, see
 * Creating container images for your Amazon Lightsail container services in the
 * *Amazon Lightsail Developer Guide*.
 */
export declare const createContainerServiceDeployment: API.OperationMethod<CreateContainerServiceDeploymentRequest & RegionInput, CreateContainerServiceDeploymentResult, CreateContainerServiceDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateContainerServiceRegistryLoginError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a temporary set of log in credentials that you can use to log in to the Docker
 * process on your local machine. After you're logged in, you can use the native Docker commands
 * to push your local container images to the container image registry of your Amazon Lightsail
 * account so that you can use them with your Lightsail container service. The log in
 * credentials expire 12 hours after they are created, at which point you will need to create a
 * new set of log in credentials.
 *
 * You can only push container images to the container service registry of your Lightsail
 * account. You cannot pull container images or perform any other container image management
 * actions on the container service registry.
 *
 * After you push your container images to the container image registry of your Lightsail
 * account, use the `RegisterContainerImage` action to register the pushed images to a
 * specific Lightsail container service.
 *
 * This action is not required if you install and use the Lightsail Control
 * (lightsailctl) plugin to push container images to your Lightsail container service. For
 * more information, see Pushing and managing container images on your Amazon Lightsail container services
 * in the *Amazon Lightsail Developer Guide*.
 */
export declare const createContainerServiceRegistryLogin: API.OperationMethod<CreateContainerServiceRegistryLoginRequest & RegionInput, CreateContainerServiceRegistryLoginResult, CreateContainerServiceRegistryLoginError, Credentials | HttpClient.HttpClient>;
export type CreateDiskError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a block storage disk that can be attached to an Amazon Lightsail instance in the
 * same Availability Zone (`us-east-2a`).
 *
 * The `create disk` operation supports tag-based access control via request tags.
 * For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createDisk: API.OperationMethod<CreateDiskRequest & RegionInput, CreateDiskResult, CreateDiskError, Credentials | HttpClient.HttpClient>;
export type CreateDiskFromSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a block storage disk from a manual or automatic snapshot of a disk. The resulting
 * disk can be attached to an Amazon Lightsail instance in the same Availability Zone
 * (`us-east-2a`).
 *
 * The `create disk from snapshot` operation supports tag-based access control via
 * request tags and resource tags applied to the resource identified by disk snapshot
 * name. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createDiskFromSnapshot: API.OperationMethod<CreateDiskFromSnapshotRequest & RegionInput, CreateDiskFromSnapshotResult, CreateDiskFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDiskSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a snapshot of a block storage disk. You can use snapshots for backups, to make
 * copies of disks, and to save data before shutting down a Lightsail instance.
 *
 * You can take a snapshot of an attached disk that is in use; however, snapshots only
 * capture data that has been written to your disk at the time the snapshot command is issued.
 * This may exclude any data that has been cached by any applications or the operating system. If
 * you can pause any file systems on the disk long enough to take a snapshot, your snapshot
 * should be complete. Nevertheless, if you cannot pause all file writes to the disk, you should
 * unmount the disk from within the Lightsail instance, issue the create disk snapshot command,
 * and then remount the disk to ensure a consistent and complete snapshot. You may remount and
 * use your disk while the snapshot status is pending.
 *
 * You can also use this operation to create a snapshot of an instance's system volume. You
 * might want to do this, for example, to recover data from the system volume of a botched
 * instance or to create a backup of the system volume like you would for a block storage disk.
 * To create a snapshot of a system volume, just define the `instance name` parameter
 * when issuing the snapshot command, and a snapshot of the defined instance's system volume will
 * be created. After the snapshot is available, you can create a block storage disk from the
 * snapshot and attach it to a running instance to access the data on the disk.
 *
 * The `create disk snapshot` operation supports tag-based access control via
 * request tags. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createDiskSnapshot: API.OperationMethod<CreateDiskSnapshotRequest & RegionInput, CreateDiskSnapshotResult, CreateDiskSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates an Amazon Lightsail content delivery network (CDN) distribution.
 *
 * A distribution is a globally distributed network of caching servers that improve the
 * performance of your website or web application hosted on a Lightsail instance. For more
 * information, see Content delivery networks in Amazon Lightsail.
 */
export declare const createDistribution: API.OperationMethod<CreateDistributionRequest & RegionInput, CreateDistributionResult, CreateDistributionError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a domain resource for the specified domain (example.com).
 *
 * The `create domain` operation supports tag-based access control via request
 * tags. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest & RegionInput, CreateDomainResult, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateDomainEntryError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates one of the following domain name system (DNS) records in a domain DNS zone:
 * Address (A), canonical name (CNAME), mail exchanger (MX), name server (NS), start of authority
 * (SOA), service locator (SRV), or text (TXT).
 *
 * The `create domain entry` operation supports tag-based access control via
 * resource tags applied to the resource identified by `domain name`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const createDomainEntry: API.OperationMethod<CreateDomainEntryRequest & RegionInput, CreateDomainEntryResult, CreateDomainEntryError, Credentials | HttpClient.HttpClient>;
export type CreateGUISessionAccessDetailsError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates two URLs that are used to access a virtual computer's graphical user interface
 * (GUI) session. The primary URL initiates a web-based Amazon DCV session to the virtual
 * computer's application. The secondary URL initiates a web-based Amazon DCV session to the
 * virtual computer's operating session.
 *
 * Use `StartGUISession` to open the session.
 */
export declare const createGUISessionAccessDetails: API.OperationMethod<CreateGUISessionAccessDetailsRequest & RegionInput, CreateGUISessionAccessDetailsResult, CreateGUISessionAccessDetailsError, Credentials | HttpClient.HttpClient>;
export type CreateInstancesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates one or more Amazon Lightsail instances.
 *
 * The `create instances` operation supports tag-based access control via request
 * tags. For more information, see the Lightsail Developer Guide.
 */
export declare const createInstances: API.OperationMethod<CreateInstancesRequest & RegionInput, CreateInstancesResult, CreateInstancesError, Credentials | HttpClient.HttpClient>;
export type CreateInstancesFromSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates one or more new instances from a manual or automatic snapshot of an
 * instance.
 *
 * The `create instances from snapshot` operation supports tag-based access
 * control via request tags and resource tags applied to the resource identified by
 * `instance snapshot name`. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createInstancesFromSnapshot: API.OperationMethod<CreateInstancesFromSnapshotRequest & RegionInput, CreateInstancesFromSnapshotResult, CreateInstancesFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateInstanceSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a snapshot of a specific virtual private server, or *instance*.
 * You can use a snapshot to create a new instance that is based on that snapshot.
 *
 * The `create instance snapshot` operation supports tag-based access control via
 * request tags. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createInstanceSnapshot: API.OperationMethod<CreateInstanceSnapshotRequest & RegionInput, CreateInstanceSnapshotResult, CreateInstanceSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateKeyPairError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a custom SSH key pair that you can use with an Amazon Lightsail
 * instance.
 *
 * Use the DownloadDefaultKeyPair action to create a Lightsail default key
 * pair in an Amazon Web Services Region where a default key pair does not currently
 * exist.
 *
 * The `create key pair` operation supports tag-based access control via request
 * tags. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createKeyPair: API.OperationMethod<CreateKeyPairRequest & RegionInput, CreateKeyPairResult, CreateKeyPairError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a Lightsail load balancer. To learn more about deciding whether to load balance
 * your application, see Configure your Lightsail instances for load balancing. You can create up to 10
 * load balancers per AWS Region in your account.
 *
 * When you create a load balancer, you can specify a unique name and port settings. To
 * change additional load balancer settings, use the `UpdateLoadBalancerAttribute`
 * operation.
 *
 * The `create load balancer` operation supports tag-based access control via
 * request tags. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createLoadBalancer: API.OperationMethod<CreateLoadBalancerRequest & RegionInput, CreateLoadBalancerResult, CreateLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerTlsCertificateError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates an SSL/TLS certificate for an Amazon Lightsail load balancer.
 *
 * TLS is just an updated, more secure version of Secure Socket Layer (SSL).
 *
 * The `CreateLoadBalancerTlsCertificate` operation supports tag-based access
 * control via resource tags applied to the resource identified by load balancer
 * name. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createLoadBalancerTlsCertificate: API.OperationMethod<CreateLoadBalancerTlsCertificateRequest & RegionInput, CreateLoadBalancerTlsCertificateResult, CreateLoadBalancerTlsCertificateError, Credentials | HttpClient.HttpClient>;
export type CreateRelationalDatabaseError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a new database in Amazon Lightsail.
 *
 * The `create relational database` operation supports tag-based access control
 * via request tags. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createRelationalDatabase: API.OperationMethod<CreateRelationalDatabaseRequest & RegionInput, CreateRelationalDatabaseResult, CreateRelationalDatabaseError, Credentials | HttpClient.HttpClient>;
export type CreateRelationalDatabaseFromSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a new database from an existing database snapshot in Amazon Lightsail.
 *
 * You can create a new database from a snapshot in if something goes wrong with your
 * original database, or to change it to a different plan, such as a high availability or
 * standard plan.
 *
 * The `create relational database from snapshot` operation supports tag-based
 * access control via request tags and resource tags applied to the resource identified by
 * relationalDatabaseSnapshotName. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createRelationalDatabaseFromSnapshot: API.OperationMethod<CreateRelationalDatabaseFromSnapshotRequest & RegionInput, CreateRelationalDatabaseFromSnapshotResult, CreateRelationalDatabaseFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateRelationalDatabaseSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a snapshot of your database in Amazon Lightsail. You can use snapshots for backups,
 * to make copies of a database, and to save data before deleting a database.
 *
 * The `create relational database snapshot` operation supports tag-based access
 * control via request tags. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const createRelationalDatabaseSnapshot: API.OperationMethod<CreateRelationalDatabaseSnapshotRequest & RegionInput, CreateRelationalDatabaseSnapshotResult, CreateRelationalDatabaseSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateSubdomainError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates a Lightsail subdomain, such as `mysite`, with the web address
 * `mysite.amazonlightsail.com`. After the subdomain is created, use the
 * `UpdateSubdomainAssociation` action to associate it with a Lightsail
 * resource.
 *
 * When you create a nested subdomain, such as `blog.mysite`, and you don't
 * already have the top-level subdomain (`mysite`), Lightsail adds the top-level
 * subdomain to your account in the `IMPLICIT` state.
 *
 * You can have up to 30 subdomains in your account. Nested subdomains, subdomains in the
 * `CREATE_FAILED` state, and deleted subdomains that other accounts can't create yet
 * count toward this quota. Subdomains in the `IMPLICIT` state don't count toward this
 * quota.
 */
export declare const createSubdomain: API.OperationMethod<CreateSubdomainRequest & RegionInput, CreateSubdomainResult, CreateSubdomainError, Credentials | HttpClient.HttpClient>;
export type DeleteAlarmError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes an alarm.
 *
 * An alarm is used to monitor a single metric for one of your resources. When a metric
 * condition is met, the alarm can notify you by email, SMS text message, and a banner displayed
 * on the Amazon Lightsail console. For more information, see Alarms
 * in Amazon Lightsail.
 */
export declare const deleteAlarm: API.OperationMethod<DeleteAlarmRequest & RegionInput, DeleteAlarmResult, DeleteAlarmError, Credentials | HttpClient.HttpClient>;
export type DeleteAutoSnapshotError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes an automatic snapshot of an instance or disk. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const deleteAutoSnapshot: API.OperationMethod<DeleteAutoSnapshotRequest & RegionInput, DeleteAutoSnapshotResult, DeleteAutoSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteBucketError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a Amazon Lightsail bucket.
 *
 * When you delete your bucket, the bucket name is released and can be reused for a new
 * bucket in your account or another Amazon Web Services account.
 */
export declare const deleteBucket: API.OperationMethod<DeleteBucketRequest & RegionInput, DeleteBucketResult, DeleteBucketError, Credentials | HttpClient.HttpClient>;
export type DeleteBucketAccessKeyError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes an access key for the specified Amazon Lightsail bucket.
 *
 * We recommend that you delete an access key if the secret access key is compromised.
 *
 * For more information about access keys, see Creating access keys for a bucket in Amazon Lightsail in the
 * *Amazon Lightsail Developer Guide*.
 */
export declare const deleteBucketAccessKey: API.OperationMethod<DeleteBucketAccessKeyRequest & RegionInput, DeleteBucketAccessKeyResult, DeleteBucketAccessKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteCertificateError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes an SSL/TLS certificate for your Amazon Lightsail content delivery network (CDN)
 * distribution.
 *
 * Certificates that are currently attached to a distribution cannot be deleted. Use the
 * `DetachCertificateFromDistribution` action to detach a certificate from a
 * distribution.
 */
export declare const deleteCertificate: API.OperationMethod<DeleteCertificateRequest & RegionInput, DeleteCertificateResult, DeleteCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteContactMethodError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a contact method.
 *
 * A contact method is used to send you notifications about your Amazon Lightsail resources.
 * You can add one email address and one mobile phone number contact method in each Amazon Web Services Region. However, SMS text messaging is not supported in some Amazon Web Services
 * Regions, and SMS text messages cannot be sent to some countries/regions. For more information,
 * see Notifications in Amazon Lightsail.
 */
export declare const deleteContactMethod: API.OperationMethod<DeleteContactMethodRequest & RegionInput, DeleteContactMethodResult, DeleteContactMethodError, Credentials | HttpClient.HttpClient>;
export type DeleteContainerImageError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a container image that is registered to your Amazon Lightsail container
 * service.
 */
export declare const deleteContainerImage: API.OperationMethod<DeleteContainerImageRequest & RegionInput, DeleteContainerImageResult, DeleteContainerImageError, Credentials | HttpClient.HttpClient>;
export type DeleteContainerServiceError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes your Amazon Lightsail container service.
 */
export declare const deleteContainerService: API.OperationMethod<DeleteContainerServiceRequest & RegionInput, DeleteContainerServiceResult, DeleteContainerServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteDiskError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes the specified block storage disk. The disk must be in the `available`
 * state (not attached to a Lightsail instance).
 *
 * The disk may remain in the `deleting` state for several minutes.
 *
 * The `delete disk` operation supports tag-based access control via resource tags
 * applied to the resource identified by `disk name`. For more information, see the
 * Amazon Lightsail Developer Guide.
 */
export declare const deleteDisk: API.OperationMethod<DeleteDiskRequest & RegionInput, DeleteDiskResult, DeleteDiskError, Credentials | HttpClient.HttpClient>;
export type DeleteDiskSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes the specified disk snapshot.
 *
 * When you make periodic snapshots of a disk, the snapshots are incremental, and only the
 * blocks on the device that have changed since your last snapshot are saved in the new snapshot.
 * When you delete a snapshot, only the data not needed for any other snapshot is removed. So
 * regardless of which prior snapshots have been deleted, all active snapshots will have access
 * to all the information needed to restore the disk.
 *
 * The `delete disk snapshot` operation supports tag-based access control via
 * resource tags applied to the resource identified by `disk snapshot name`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const deleteDiskSnapshot: API.OperationMethod<DeleteDiskSnapshotRequest & RegionInput, DeleteDiskSnapshotResult, DeleteDiskSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteDistributionError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes your Amazon Lightsail content delivery network (CDN) distribution.
 */
export declare const deleteDistribution: API.OperationMethod<DeleteDistributionRequest & RegionInput, DeleteDistributionResult, DeleteDistributionError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes the specified domain recordset and all of its domain records.
 *
 * The `delete domain` operation supports tag-based access control via resource
 * tags applied to the resource identified by `domain name`. For more information, see
 * the Amazon Lightsail Developer Guide.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest & RegionInput, DeleteDomainResult, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainEntryError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a specific domain entry.
 *
 * The `delete domain entry` operation supports tag-based access control via
 * resource tags applied to the resource identified by `domain name`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const deleteDomainEntry: API.OperationMethod<DeleteDomainEntryRequest & RegionInput, DeleteDomainEntryResult, DeleteDomainEntryError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes an Amazon Lightsail instance.
 *
 * The `delete instance` operation supports tag-based access control via resource
 * tags applied to the resource identified by `instance name`. For more information,
 * see the Amazon Lightsail Developer Guide.
 */
export declare const deleteInstance: API.OperationMethod<DeleteInstanceRequest & RegionInput, DeleteInstanceResult, DeleteInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a specific snapshot of a virtual private server (or
 * *instance*).
 *
 * The `delete instance snapshot` operation supports tag-based access control via
 * resource tags applied to the resource identified by `instance snapshot name`. For
 * more information, see the Amazon Lightsail Developer Guide.
 */
export declare const deleteInstanceSnapshot: API.OperationMethod<DeleteInstanceSnapshotRequest & RegionInput, DeleteInstanceSnapshotResult, DeleteInstanceSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteKeyPairError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes the specified key pair by removing the public key from Amazon Lightsail.
 *
 * You can delete key pairs that were created using the ImportKeyPair and
 * CreateKeyPair actions, as well as the Lightsail default key pair. A new default
 * key pair will not be created unless you launch an instance without specifying a custom key
 * pair, or you call the DownloadDefaultKeyPair API.
 *
 * The `delete key pair` operation supports tag-based access control via resource
 * tags applied to the resource identified by `key pair name`. For more information,
 * see the Amazon Lightsail Developer Guide.
 */
export declare const deleteKeyPair: API.OperationMethod<DeleteKeyPairRequest & RegionInput, DeleteKeyPairResult, DeleteKeyPairError, Credentials | HttpClient.HttpClient>;
export type DeleteKnownHostKeysError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes the known host key or certificate used by the Amazon Lightsail browser-based SSH or
 * RDP clients to authenticate an instance. This operation enables the Lightsail browser-based
 * SSH or RDP clients to connect to the instance after a host key mismatch.
 *
 * Perform this operation only if you were expecting the host key or certificate mismatch
 * or if you are familiar with the new host key or certificate on the instance. For more
 * information, see Troubleshooting connection issues when using the Amazon Lightsail browser-based SSH or RDP
 * client.
 */
export declare const deleteKnownHostKeys: API.OperationMethod<DeleteKnownHostKeysRequest & RegionInput, DeleteKnownHostKeysResult, DeleteKnownHostKeysError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a Lightsail load balancer and all its associated SSL/TLS certificates. Once the
 * load balancer is deleted, you will need to create a new load balancer, create a new
 * certificate, and verify domain ownership again.
 *
 * The `delete load balancer` operation supports tag-based access control via
 * resource tags applied to the resource identified by `load balancer name`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const deleteLoadBalancer: API.OperationMethod<DeleteLoadBalancerRequest & RegionInput, DeleteLoadBalancerResult, DeleteLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerTlsCertificateError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes an SSL/TLS certificate associated with a Lightsail load balancer.
 *
 * The `DeleteLoadBalancerTlsCertificate` operation supports tag-based access
 * control via resource tags applied to the resource identified by load balancer
 * name. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const deleteLoadBalancerTlsCertificate: API.OperationMethod<DeleteLoadBalancerTlsCertificateRequest & RegionInput, DeleteLoadBalancerTlsCertificateResult, DeleteLoadBalancerTlsCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteRelationalDatabaseError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a database in Amazon Lightsail.
 *
 * The `delete relational database` operation supports tag-based access control
 * via resource tags applied to the resource identified by relationalDatabaseName. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const deleteRelationalDatabase: API.OperationMethod<DeleteRelationalDatabaseRequest & RegionInput, DeleteRelationalDatabaseResult, DeleteRelationalDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteRelationalDatabaseSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a database snapshot in Amazon Lightsail.
 *
 * The `delete relational database snapshot` operation supports tag-based access
 * control via resource tags applied to the resource identified by relationalDatabaseName. For
 * more information, see the Amazon Lightsail Developer Guide.
 */
export declare const deleteRelationalDatabaseSnapshot: API.OperationMethod<DeleteRelationalDatabaseSnapshotRequest & RegionInput, DeleteRelationalDatabaseSnapshotResult, DeleteRelationalDatabaseSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteSubdomainError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a Lightsail subdomain.
 *
 * The subdomain must be in the `UNATTACHED` or `CREATE_FAILED`
 * state. To delete a subdomain that's associated with a resource, first disassociate it by using
 * the `UpdateSubdomainAssociation` action.
 *
 * When you delete a top-level subdomain that has nested subdomains, the nested subdomains
 * continue to work, and the top-level subdomain changes to the `IMPLICIT`
 * state.
 *
 * After you delete a subdomain that was associated with a resource, the subdomain isn't
 * available to other accounts for at least 30 days.
 */
export declare const deleteSubdomain: API.OperationMethod<DeleteSubdomainRequest & RegionInput, DeleteSubdomainResult, DeleteSubdomainError, Credentials | HttpClient.HttpClient>;
export type DetachCertificateFromDistributionError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Detaches an SSL/TLS certificate from your Amazon Lightsail content delivery network (CDN)
 * distribution.
 *
 * After the certificate is detached, your distribution stops accepting traffic for all of
 * the domains that are associated with the certificate.
 */
export declare const detachCertificateFromDistribution: API.OperationMethod<DetachCertificateFromDistributionRequest & RegionInput, DetachCertificateFromDistributionResult, DetachCertificateFromDistributionError, Credentials | HttpClient.HttpClient>;
export type DetachDiskError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Detaches a stopped block storage disk from a Lightsail instance. Make sure to unmount
 * any file systems on the device within your operating system before stopping the instance and
 * detaching the disk.
 *
 * The `detach disk` operation supports tag-based access control via resource tags
 * applied to the resource identified by `disk name`. For more information, see the
 * Amazon Lightsail Developer Guide.
 */
export declare const detachDisk: API.OperationMethod<DetachDiskRequest & RegionInput, DetachDiskResult, DetachDiskError, Credentials | HttpClient.HttpClient>;
export type DetachInstancesFromLoadBalancerError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Detaches the specified instances from a Lightsail load balancer.
 *
 * This operation waits until the instances are no longer needed before they are detached
 * from the load balancer.
 *
 * The `detach instances from load balancer` operation supports tag-based access
 * control via resource tags applied to the resource identified by load balancer
 * name. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const detachInstancesFromLoadBalancer: API.OperationMethod<DetachInstancesFromLoadBalancerRequest & RegionInput, DetachInstancesFromLoadBalancerResult, DetachInstancesFromLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type DetachStaticIpError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Detaches a static IP from the Amazon Lightsail instance to which it is attached.
 */
export declare const detachStaticIp: API.OperationMethod<DetachStaticIpRequest & RegionInput, DetachStaticIpResult, DetachStaticIpError, Credentials | HttpClient.HttpClient>;
export type DisableAddOnError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Disables an add-on for an Amazon Lightsail resource. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const disableAddOn: API.OperationMethod<DisableAddOnRequest & RegionInput, DisableAddOnResult, DisableAddOnError, Credentials | HttpClient.HttpClient>;
export type DownloadDefaultKeyPairError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Downloads the regional Amazon Lightsail default key pair.
 *
 * This action also creates a Lightsail default key pair if a default key pair
 * does not currently exist in the Amazon Web Services Region.
 */
export declare const downloadDefaultKeyPair: API.OperationMethod<DownloadDefaultKeyPairRequest & RegionInput, DownloadDefaultKeyPairResult, DownloadDefaultKeyPairError, Credentials | HttpClient.HttpClient>;
export type EnableAddOnError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Enables or modifies an add-on for an Amazon Lightsail resource. For more information, see
 * the Amazon Lightsail Developer Guide.
 */
export declare const enableAddOn: API.OperationMethod<EnableAddOnRequest & RegionInput, EnableAddOnResult, EnableAddOnError, Credentials | HttpClient.HttpClient>;
export type ExportSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Exports an Amazon Lightsail instance or block storage disk snapshot to Amazon Elastic Compute Cloud (Amazon EC2).
 * This operation results in an export snapshot record that can be used with the create
 * cloud formation stack operation to create new Amazon EC2 instances.
 *
 * Exported instance snapshots appear in Amazon EC2 as Amazon Machine Images (AMIs), and the
 * instance system disk appears as an Amazon Elastic Block Store (Amazon EBS) volume. Exported disk snapshots appear in
 * Amazon EC2 as Amazon EBS volumes. Snapshots are exported to the same Amazon Web Services Region in
 * Amazon EC2 as the source Lightsail snapshot.
 *
 * The `export snapshot` operation supports tag-based access control via resource
 * tags applied to the resource identified by `source snapshot name`. For more
 * information, see the Amazon Lightsail Developer Guide.
 *
 * Use the `get instance snapshots` or `get disk snapshots`
 * operations to get a list of snapshots that you can export to Amazon EC2.
 */
export declare const exportSnapshot: API.OperationMethod<ExportSnapshotRequest & RegionInput, ExportSnapshotResult, ExportSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetActiveNamesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the names of all active (not deleted) resources.
 */
export declare const getActiveNames: API.OperationMethod<GetActiveNamesRequest & RegionInput, GetActiveNamesResult, GetActiveNamesError, Credentials | HttpClient.HttpClient>;
export type GetAlarmsError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about the configured alarms. Specify an alarm name in your request to
 * return information about a specific alarm, or specify a monitored resource name to return
 * information about all alarms for a specific resource.
 *
 * An alarm is used to monitor a single metric for one of your resources. When a metric
 * condition is met, the alarm can notify you by email, SMS text message, and a banner displayed
 * on the Amazon Lightsail console. For more information, see Alarms
 * in Amazon Lightsail.
 */
export declare const getAlarms: API.OperationMethod<GetAlarmsRequest & RegionInput, GetAlarmsResult, GetAlarmsError, Credentials | HttpClient.HttpClient>;
export type GetAutoSnapshotsError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the available automatic snapshots for an instance or disk. For more information,
 * see the Amazon Lightsail Developer Guide.
 */
export declare const getAutoSnapshots: API.OperationMethod<GetAutoSnapshotsRequest & RegionInput, GetAutoSnapshotsResult, GetAutoSnapshotsError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the list of available instance images, or *blueprints*. You can
 * use a blueprint to create a new instance already running a specific operating system, as well
 * as a preinstalled app or development stack. The software each instance is running depends on
 * the blueprint image you choose.
 *
 * Use active blueprints when creating new instances. Inactive blueprints are listed to
 * support customers with existing instances and are not necessarily available to create new
 * instances. Blueprints are marked inactive when they become outdated due to operating system
 * updates or new application releases.
 */
export declare const getBlueprints: API.OperationMethod<GetBlueprintsRequest & RegionInput, GetBlueprintsResult, GetBlueprintsError, Credentials | HttpClient.HttpClient>;
export type GetBucketAccessKeysError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the existing access key IDs for the specified Amazon Lightsail bucket.
 *
 * This action does not return the secret access key value of an access key. You can get a
 * secret access key only when you create it from the response of the CreateBucketAccessKey action. If you lose the secret access key, you must create
 * a new access key.
 */
export declare const getBucketAccessKeys: API.OperationMethod<GetBucketAccessKeysRequest & RegionInput, GetBucketAccessKeysResult, GetBucketAccessKeysError, Credentials | HttpClient.HttpClient>;
export type GetBucketBundlesError = AccessDeniedException | InvalidInputException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the bundles that you can apply to a Amazon Lightsail bucket.
 *
 * The bucket bundle specifies the monthly cost, storage quota, and data transfer quota for a
 * bucket.
 *
 * Use the UpdateBucketBundle action to update the
 * bundle for a bucket.
 */
export declare const getBucketBundles: API.OperationMethod<GetBucketBundlesRequest & RegionInput, GetBucketBundlesResult, GetBucketBundlesError, Credentials | HttpClient.HttpClient>;
export type GetBucketMetricDataError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the data points of a specific metric for an Amazon Lightsail bucket.
 *
 * Metrics report the utilization of a bucket. View and collect metric data regularly to
 * monitor the number of objects stored in a bucket (including object versions) and the storage
 * space used by those objects.
 */
export declare const getBucketMetricData: API.OperationMethod<GetBucketMetricDataRequest & RegionInput, GetBucketMetricDataResult, GetBucketMetricDataError, Credentials | HttpClient.HttpClient>;
export type GetBucketsError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about one or more Amazon Lightsail buckets. The information returned
 * includes the synchronization status of the Amazon Simple Storage Service (Amazon S3)
 * account-level block public access feature for your Lightsail buckets.
 *
 * For more information about buckets, see Buckets in Amazon Lightsail in the Amazon Lightsail Developer
 * Guide.
 */
export declare const getBuckets: API.OperationMethod<GetBucketsRequest & RegionInput, GetBucketsResult, GetBucketsError, Credentials | HttpClient.HttpClient>;
export type GetBundlesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the bundles that you can apply to an Amazon Lightsail instance when you create
 * it.
 *
 * A bundle describes the specifications of an instance, such as the monthly cost, amount of
 * memory, the number of vCPUs, amount of storage space, and monthly network data transfer
 * quota.
 *
 * Bundles are referred to as *instance plans* in the Lightsail
 * console.
 */
export declare const getBundles: API.OperationMethod<GetBundlesRequest & RegionInput, GetBundlesResult, GetBundlesError, Credentials | HttpClient.HttpClient>;
export type GetCertificatesError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about one or more Amazon Lightsail SSL/TLS certificates.
 *
 * To get a summary of a certificate, omit `includeCertificateDetails` from your
 * request. The response will include only the certificate Amazon Resource Name (ARN),
 * certificate name, domain name, and tags.
 */
export declare const getCertificates: API.OperationMethod<GetCertificatesRequest & RegionInput, GetCertificatesResult, GetCertificatesError, Credentials | HttpClient.HttpClient>;
export type GetCloudFormationStackRecordsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the CloudFormation stack record created as a result of the create cloud
 * formation stack operation.
 *
 * An AWS CloudFormation stack is used to create a new Amazon EC2 instance from an exported Lightsail
 * snapshot.
 */
export declare const getCloudFormationStackRecords: API.OperationMethod<GetCloudFormationStackRecordsRequest & RegionInput, GetCloudFormationStackRecordsResult, GetCloudFormationStackRecordsError, Credentials | HttpClient.HttpClient>;
export type GetContactMethodsError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about the configured contact methods. Specify a protocol in your
 * request to return information about a specific contact method.
 *
 * A contact method is used to send you notifications about your Amazon Lightsail resources.
 * You can add one email address and one mobile phone number contact method in each Amazon Web Services Region. However, SMS text messaging is not supported in some Amazon Web Services
 * Regions, and SMS text messages cannot be sent to some countries/regions. For more information,
 * see Notifications in Amazon Lightsail.
 */
export declare const getContactMethods: API.OperationMethod<GetContactMethodsRequest & RegionInput, GetContactMethodsResult, GetContactMethodsError, Credentials | HttpClient.HttpClient>;
export type GetContainerAPIMetadataError = AccessDeniedException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about Amazon Lightsail containers, such as the current version of the
 * Lightsail Control (lightsailctl) plugin.
 */
export declare const getContainerAPIMetadata: API.OperationMethod<GetContainerAPIMetadataRequest & RegionInput, GetContainerAPIMetadataResult, GetContainerAPIMetadataError, Credentials | HttpClient.HttpClient>;
export type GetContainerImagesError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the container images that are registered to your Amazon Lightsail container
 * service.
 *
 * If you created a deployment on your Lightsail container service that uses container
 * images from a public registry like Docker Hub, those images are not returned as part of this
 * action. Those images are not registered to your Lightsail container service.
 */
export declare const getContainerImages: API.OperationMethod<GetContainerImagesRequest & RegionInput, GetContainerImagesResult, GetContainerImagesError, Credentials | HttpClient.HttpClient>;
export type GetContainerLogError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the log events of a container of your Amazon Lightsail container service.
 *
 * If your container service has more than one node (i.e., a scale greater than 1), then the
 * log events that are returned for the specified container are merged from all nodes on your
 * container service.
 *
 * Container logs are retained for a certain amount of time. For more information, see
 * Amazon Lightsail
 * endpoints and quotas in the Amazon Web Services General
 * Reference.
 */
export declare const getContainerLog: API.OperationMethod<GetContainerLogRequest & RegionInput, GetContainerLogResult, GetContainerLogError, Credentials | HttpClient.HttpClient>;
export type GetContainerServiceDeploymentsError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the deployments for your Amazon Lightsail container service
 *
 * A deployment specifies the settings, such as the ports and launch command, of containers
 * that are deployed to your container service.
 *
 * The deployments are ordered by version in ascending order. The newest version is listed at
 * the top of the response.
 *
 * A set number of deployments are kept before the oldest one is replaced with the newest
 * one. For more information, see Amazon Lightsail
 * endpoints and quotas in the Amazon Web Services General
 * Reference.
 */
export declare const getContainerServiceDeployments: API.OperationMethod<GetContainerServiceDeploymentsRequest & RegionInput, GetContainerServiceDeploymentsResult, GetContainerServiceDeploymentsError, Credentials | HttpClient.HttpClient>;
export type GetContainerServiceMetricDataError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the data points of a specific metric of your Amazon Lightsail container
 * service.
 *
 * Metrics report the utilization of your resources. Monitor and collect metric data
 * regularly to maintain the reliability, availability, and performance of your resources.
 */
export declare const getContainerServiceMetricData: API.OperationMethod<GetContainerServiceMetricDataRequest & RegionInput, GetContainerServiceMetricDataResult, GetContainerServiceMetricDataError, Credentials | HttpClient.HttpClient>;
export type GetContainerServicePowersError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the list of powers that can be specified for your Amazon Lightsail container
 * services.
 *
 * The power specifies the amount of memory, the number of vCPUs, and the base price of the
 * container service.
 */
export declare const getContainerServicePowers: API.OperationMethod<GetContainerServicePowersRequest & RegionInput, GetContainerServicePowersResult, GetContainerServicePowersError, Credentials | HttpClient.HttpClient>;
export type GetContainerServicesError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about one or more of your Amazon Lightsail container services.
 */
export declare const getContainerServices: API.OperationMethod<GetContainerServicesRequest & RegionInput, ContainerServicesListResult, GetContainerServicesError, Credentials | HttpClient.HttpClient>;
export type GetCostEstimateError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Retrieves information about the cost estimate for a specified resource. A cost estimate
 * will not generate for a resource that has been deleted.
 */
export declare const getCostEstimate: API.OperationMethod<GetCostEstimateRequest & RegionInput, GetCostEstimateResult, GetCostEstimateError, Credentials | HttpClient.HttpClient>;
export type GetDiskError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific block storage disk.
 */
export declare const getDisk: API.OperationMethod<GetDiskRequest & RegionInput, GetDiskResult, GetDiskError, Credentials | HttpClient.HttpClient>;
export type GetDisksError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all block storage disks in your AWS account and region.
 */
export declare const getDisks: API.OperationMethod<GetDisksRequest & RegionInput, GetDisksResult, GetDisksError, Credentials | HttpClient.HttpClient>;
export type GetDiskSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific block storage disk snapshot.
 */
export declare const getDiskSnapshot: API.OperationMethod<GetDiskSnapshotRequest & RegionInput, GetDiskSnapshotResult, GetDiskSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetDiskSnapshotsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all block storage disk snapshots in your AWS account and
 * region.
 */
export declare const getDiskSnapshots: API.OperationMethod<GetDiskSnapshotsRequest & RegionInput, GetDiskSnapshotsResult, GetDiskSnapshotsError, Credentials | HttpClient.HttpClient>;
export type GetDistributionBundlesError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the bundles that can be applied to your Amazon Lightsail content delivery network
 * (CDN) distributions.
 *
 * A distribution bundle specifies the monthly network transfer quota and monthly cost of
 * your distribution.
 */
export declare const getDistributionBundles: API.OperationMethod<GetDistributionBundlesRequest & RegionInput, GetDistributionBundlesResult, GetDistributionBundlesError, Credentials | HttpClient.HttpClient>;
export type GetDistributionLatestCacheResetError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the timestamp and status of the last cache reset of a specific Amazon Lightsail
 * content delivery network (CDN) distribution.
 */
export declare const getDistributionLatestCacheReset: API.OperationMethod<GetDistributionLatestCacheResetRequest & RegionInput, GetDistributionLatestCacheResetResult, GetDistributionLatestCacheResetError, Credentials | HttpClient.HttpClient>;
export type GetDistributionMetricDataError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the data points of a specific metric for an Amazon Lightsail content delivery
 * network (CDN) distribution.
 *
 * Metrics report the utilization of your resources, and the error counts generated by them.
 * Monitor and collect metric data regularly to maintain the reliability, availability, and
 * performance of your resources.
 */
export declare const getDistributionMetricData: API.OperationMethod<GetDistributionMetricDataRequest & RegionInput, GetDistributionMetricDataResult, GetDistributionMetricDataError, Credentials | HttpClient.HttpClient>;
export type GetDistributionsError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about one or more of your Amazon Lightsail content delivery network
 * (CDN) distributions.
 *
 * The `defaultRootObject` and `customErrorResponses` values are
 * returned only when you specify `distributionName` to retrieve a single
 * distribution. When you call `GetDistributions` without a distribution name to
 * list all distributions, these two fields aren't included in the response.
 */
export declare const getDistributions: API.OperationMethod<GetDistributionsRequest & RegionInput, GetDistributionsResult, GetDistributionsError, Credentials | HttpClient.HttpClient>;
export type GetDomainError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific domain recordset.
 */
export declare const getDomain: API.OperationMethod<GetDomainRequest & RegionInput, GetDomainResult, GetDomainError, Credentials | HttpClient.HttpClient>;
export type GetDomainsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns a list of all domains in the user's account.
 */
export declare const getDomains: API.OperationMethod<GetDomainsRequest & RegionInput, GetDomainsResult, GetDomainsError, Credentials | HttpClient.HttpClient>;
export type GetExportSnapshotRecordsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns all export snapshot records created as a result of the export
 * snapshot operation.
 *
 * An export snapshot record can be used to create a new Amazon EC2 instance and its related
 * resources with the CreateCloudFormationStack
 * action.
 */
export declare const getExportSnapshotRecords: API.OperationMethod<GetExportSnapshotRecordsRequest & RegionInput, GetExportSnapshotRecordsResult, GetExportSnapshotRecordsError, Credentials | HttpClient.HttpClient>;
export type GetInstanceError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific Amazon Lightsail instance, which is a virtual private
 * server.
 */
export declare const getInstance: API.OperationMethod<GetInstanceRequest & RegionInput, GetInstanceResult, GetInstanceError, Credentials | HttpClient.HttpClient>;
export type GetInstanceAccessDetailsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns temporary SSH keys you can use to connect to a specific virtual private server, or
 * *instance*.
 *
 * The `get instance access details` operation supports tag-based access control
 * via resource tags applied to the resource identified by `instance name`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const getInstanceAccessDetails: API.OperationMethod<GetInstanceAccessDetailsRequest & RegionInput, GetInstanceAccessDetailsResult, GetInstanceAccessDetailsError, Credentials | HttpClient.HttpClient>;
export type GetInstanceMetricDataError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the data points for the specified Amazon Lightsail instance metric, given an
 * instance name.
 *
 * Metrics report the utilization of your resources, and the error counts generated by them.
 * Monitor and collect metric data regularly to maintain the reliability, availability, and
 * performance of your resources.
 */
export declare const getInstanceMetricData: API.OperationMethod<GetInstanceMetricDataRequest & RegionInput, GetInstanceMetricDataResult, GetInstanceMetricDataError, Credentials | HttpClient.HttpClient>;
export type GetInstancePortStatesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the firewall port states for a specific Amazon Lightsail instance, the IP addresses
 * allowed to connect to the instance through the ports, and the protocol.
 */
export declare const getInstancePortStates: API.OperationMethod<GetInstancePortStatesRequest & RegionInput, GetInstancePortStatesResult, GetInstancePortStatesError, Credentials | HttpClient.HttpClient>;
export type GetInstancesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all Amazon Lightsail virtual private servers, or
 * *instances*.
 */
export declare const getInstances: API.OperationMethod<GetInstancesRequest & RegionInput, GetInstancesResult, GetInstancesError, Credentials | HttpClient.HttpClient>;
export type GetInstanceSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific instance snapshot.
 */
export declare const getInstanceSnapshot: API.OperationMethod<GetInstanceSnapshotRequest & RegionInput, GetInstanceSnapshotResult, GetInstanceSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetInstanceSnapshotsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns all instance snapshots for the user's account.
 */
export declare const getInstanceSnapshots: API.OperationMethod<GetInstanceSnapshotsRequest & RegionInput, GetInstanceSnapshotsResult, GetInstanceSnapshotsError, Credentials | HttpClient.HttpClient>;
export type GetInstanceStateError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the state of a specific instance. Works on one instance at a time.
 */
export declare const getInstanceState: API.OperationMethod<GetInstanceStateRequest & RegionInput, GetInstanceStateResult, GetInstanceStateError, Credentials | HttpClient.HttpClient>;
export type GetKeyPairError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific key pair.
 */
export declare const getKeyPair: API.OperationMethod<GetKeyPairRequest & RegionInput, GetKeyPairResult, GetKeyPairError, Credentials | HttpClient.HttpClient>;
export type GetKeyPairsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all key pairs in the user's account.
 */
export declare const getKeyPairs: API.OperationMethod<GetKeyPairsRequest & RegionInput, GetKeyPairsResult, GetKeyPairsError, Credentials | HttpClient.HttpClient>;
export type GetLoadBalancerError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about the specified Lightsail load balancer.
 */
export declare const getLoadBalancer: API.OperationMethod<GetLoadBalancerRequest & RegionInput, GetLoadBalancerResult, GetLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type GetLoadBalancerMetricDataError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about health metrics for your Lightsail load balancer.
 *
 * Metrics report the utilization of your resources, and the error counts generated by them.
 * Monitor and collect metric data regularly to maintain the reliability, availability, and
 * performance of your resources.
 */
export declare const getLoadBalancerMetricData: API.OperationMethod<GetLoadBalancerMetricDataRequest & RegionInput, GetLoadBalancerMetricDataResult, GetLoadBalancerMetricDataError, Credentials | HttpClient.HttpClient>;
export type GetLoadBalancersError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all load balancers in an account.
 */
export declare const getLoadBalancers: API.OperationMethod<GetLoadBalancersRequest & RegionInput, GetLoadBalancersResult, GetLoadBalancersError, Credentials | HttpClient.HttpClient>;
export type GetLoadBalancerTlsCertificatesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about the TLS certificates that are associated with the specified
 * Lightsail load balancer.
 *
 * TLS is just an updated, more secure version of Secure Socket Layer (SSL).
 *
 * You can have a maximum of 2 certificates associated with a Lightsail load balancer. One
 * is active and the other is inactive.
 */
export declare const getLoadBalancerTlsCertificates: API.OperationMethod<GetLoadBalancerTlsCertificatesRequest & RegionInput, GetLoadBalancerTlsCertificatesResult, GetLoadBalancerTlsCertificatesError, Credentials | HttpClient.HttpClient>;
export type GetLoadBalancerTlsPoliciesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns a list of TLS security policies that you can apply to Lightsail load
 * balancers.
 *
 * For more information about load balancer TLS security policies, see Configuring TLS security policies on your Amazon Lightsail load
 * balancers in the *Amazon Lightsail Developer Guide*.
 */
export declare const getLoadBalancerTlsPolicies: API.OperationMethod<GetLoadBalancerTlsPoliciesRequest & RegionInput, GetLoadBalancerTlsPoliciesResult, GetLoadBalancerTlsPoliciesError, Credentials | HttpClient.HttpClient>;
export type GetOperationError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific operation. Operations include events such as when you
 * create an instance, allocate a static IP, attach a static IP, and so on.
 */
export declare const getOperation: API.OperationMethod<GetOperationRequest & RegionInput, GetOperationResult, GetOperationError, Credentials | HttpClient.HttpClient>;
export type GetOperationsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all operations.
 *
 * Results are returned from oldest to newest, up to a maximum of 200. Results can be paged
 * by making each subsequent call to `GetOperations` use the maximum (last)
 * `statusChangedAt` value from the previous request.
 */
export declare const getOperations: API.OperationMethod<GetOperationsRequest & RegionInput, GetOperationsResult, GetOperationsError, Credentials | HttpClient.HttpClient>;
export type GetOperationsForResourceError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Gets operations for a specific resource (an instance or a static IP).
 */
export declare const getOperationsForResource: API.OperationMethod<GetOperationsForResourceRequest & RegionInput, GetOperationsForResourceResult, GetOperationsForResourceError, Credentials | HttpClient.HttpClient>;
export type GetProfileError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about the profile of the Amazon Lightsail account that makes the
 * request. The response includes the profile type and, for accounts enrolled in the Lightsail
 * partner program, the partner membership details.
 */
export declare const getProfile: API.OperationMethod<GetProfileRequest & RegionInput, GetProfileResult, GetProfileError, Credentials | HttpClient.HttpClient>;
export type GetRegionsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns a list of all valid regions for Amazon Lightsail. Use the include
 * availability zones parameter to also return the Availability Zones in a
 * region.
 */
export declare const getRegions: API.OperationMethod<GetRegionsRequest & RegionInput, GetRegionsResult, GetRegionsError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific database in Amazon Lightsail.
 */
export declare const getRelationalDatabase: API.OperationMethod<GetRelationalDatabaseRequest & RegionInput, GetRelationalDatabaseResult, GetRelationalDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseBlueprintsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns a list of available database blueprints in Amazon Lightsail. A blueprint describes
 * the major engine version of a database.
 *
 * You can use a blueprint ID to create a new database that runs a specific database
 * engine.
 */
export declare const getRelationalDatabaseBlueprints: API.OperationMethod<GetRelationalDatabaseBlueprintsRequest & RegionInput, GetRelationalDatabaseBlueprintsResult, GetRelationalDatabaseBlueprintsError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseBundlesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the list of bundles that are available in Amazon Lightsail. A bundle describes the
 * performance specifications for a database.
 *
 * You can use a bundle ID to create a new database with explicit performance
 * specifications.
 */
export declare const getRelationalDatabaseBundles: API.OperationMethod<GetRelationalDatabaseBundlesRequest & RegionInput, GetRelationalDatabaseBundlesResult, GetRelationalDatabaseBundlesError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseEventsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns a list of events for a specific database in Amazon Lightsail.
 */
export declare const getRelationalDatabaseEvents: API.OperationMethod<GetRelationalDatabaseEventsRequest & RegionInput, GetRelationalDatabaseEventsResult, GetRelationalDatabaseEventsError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseLogEventsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns a list of log events for a database in Amazon Lightsail.
 */
export declare const getRelationalDatabaseLogEvents: API.OperationMethod<GetRelationalDatabaseLogEventsRequest & RegionInput, GetRelationalDatabaseLogEventsResult, GetRelationalDatabaseLogEventsError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseLogStreamsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns a list of available log streams for a specific database in Amazon Lightsail.
 */
export declare const getRelationalDatabaseLogStreams: API.OperationMethod<GetRelationalDatabaseLogStreamsRequest & RegionInput, GetRelationalDatabaseLogStreamsResult, GetRelationalDatabaseLogStreamsError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseMasterUserPasswordError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the current, previous, or pending versions of the master user password for a
 * Lightsail database.
 *
 * The `GetRelationalDatabaseMasterUserPassword` operation supports tag-based
 * access control via resource tags applied to the resource identified by
 * relationalDatabaseName.
 */
export declare const getRelationalDatabaseMasterUserPassword: API.OperationMethod<GetRelationalDatabaseMasterUserPasswordRequest & RegionInput, GetRelationalDatabaseMasterUserPasswordResult, GetRelationalDatabaseMasterUserPasswordError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseMetricDataError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns the data points of the specified metric for a database in Amazon Lightsail.
 *
 * Metrics report the utilization of your resources, and the error counts generated by them.
 * Monitor and collect metric data regularly to maintain the reliability, availability, and
 * performance of your resources.
 */
export declare const getRelationalDatabaseMetricData: API.OperationMethod<GetRelationalDatabaseMetricDataRequest & RegionInput, GetRelationalDatabaseMetricDataResult, GetRelationalDatabaseMetricDataError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseParametersError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns all of the runtime parameters offered by the underlying database software, or
 * engine, for a specific database in Amazon Lightsail.
 *
 * In addition to the parameter names and values, this operation returns other information
 * about each parameter. This information includes whether changes require a reboot, whether the
 * parameter is modifiable, the allowed values, and the data types.
 */
export declare const getRelationalDatabaseParameters: API.OperationMethod<GetRelationalDatabaseParametersRequest & RegionInput, GetRelationalDatabaseParametersResult, GetRelationalDatabaseParametersError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabasesError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all of your databases in Amazon Lightsail.
 */
export declare const getRelationalDatabases: API.OperationMethod<GetRelationalDatabasesRequest & RegionInput, GetRelationalDatabasesResult, GetRelationalDatabasesError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseSnapshotError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about a specific database snapshot in Amazon Lightsail.
 */
export declare const getRelationalDatabaseSnapshot: API.OperationMethod<GetRelationalDatabaseSnapshotRequest & RegionInput, GetRelationalDatabaseSnapshotResult, GetRelationalDatabaseSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetRelationalDatabaseSnapshotsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all of your database snapshots in Amazon Lightsail.
 */
export declare const getRelationalDatabaseSnapshots: API.OperationMethod<GetRelationalDatabaseSnapshotsRequest & RegionInput, GetRelationalDatabaseSnapshotsResult, GetRelationalDatabaseSnapshotsError, Credentials | HttpClient.HttpClient>;
export type GetSetupHistoryError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns detailed information for five of the most recent `SetupInstanceHttps`
 * requests that were ran on the target instance.
 */
export declare const getSetupHistory: API.OperationMethod<GetSetupHistoryRequest & RegionInput, GetSetupHistoryResult, GetSetupHistoryError, Credentials | HttpClient.HttpClient>;
export type GetStaticIpError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about an Amazon Lightsail static IP.
 */
export declare const getStaticIp: API.OperationMethod<GetStaticIpRequest & RegionInput, GetStaticIpResult, GetStaticIpError, Credentials | HttpClient.HttpClient>;
export type GetStaticIpsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about all static IPs in the user's account.
 */
export declare const getStaticIps: API.OperationMethod<GetStaticIpsRequest & RegionInput, GetStaticIpsResult, GetStaticIpsError, Credentials | HttpClient.HttpClient>;
export type GetSubdomainsError = AccessDeniedException | InvalidInputException | NotFoundException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns information about one or more of your Lightsail subdomains.
 *
 * When you don't specify a subdomain, the response lists your top-level subdomains, and
 * each top-level subdomain includes its nested subdomains.
 *
 * The results are paginated. To get the next page of results, use the `pageToken`
 * parameter.
 */
export declare const getSubdomains: API.OperationMethod<GetSubdomainsRequest & RegionInput, GetSubdomainsResult, GetSubdomainsError, Credentials | HttpClient.HttpClient>;
export type ImportKeyPairError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Imports a public SSH key from a specific key pair.
 */
export declare const importKeyPair: API.OperationMethod<ImportKeyPairRequest & RegionInput, ImportKeyPairResult, ImportKeyPairError, Credentials | HttpClient.HttpClient>;
export type IsVpcPeeredError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Returns a Boolean value indicating whether your Lightsail VPC is peered.
 */
export declare const isVpcPeered: API.OperationMethod<IsVpcPeeredRequest & RegionInput, IsVpcPeeredResult, IsVpcPeeredError, Credentials | HttpClient.HttpClient>;
export type OpenInstancePublicPortsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Opens ports for a specific Amazon Lightsail instance, and specifies the IP addresses
 * allowed to connect to the instance through the ports, and the protocol.
 *
 * The `OpenInstancePublicPorts` action supports tag-based access control via
 * resource tags applied to the resource identified by `instanceName`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const openInstancePublicPorts: API.OperationMethod<OpenInstancePublicPortsRequest & RegionInput, OpenInstancePublicPortsResult, OpenInstancePublicPortsError, Credentials | HttpClient.HttpClient>;
export type PeerVpcError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Peers the Lightsail VPC with the user's default VPC.
 */
export declare const peerVpc: API.OperationMethod<PeerVpcRequest & RegionInput, PeerVpcResult, PeerVpcError, Credentials | HttpClient.HttpClient>;
export type PutAlarmError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates or updates an alarm, and associates it with the specified metric.
 *
 * An alarm is used to monitor a single metric for one of your resources. When a metric
 * condition is met, the alarm can notify you by email, SMS text message, and a banner displayed
 * on the Amazon Lightsail console. For more information, see Alarms
 * in Amazon Lightsail.
 *
 * When this action creates an alarm, the alarm state is immediately set to
 * `INSUFFICIENT_DATA`. The alarm is then evaluated and its state is set
 * appropriately. Any actions associated with the new state are then executed.
 *
 * When you update an existing alarm, its state is left unchanged, but the update completely
 * overwrites the previous configuration of the alarm. The alarm is then evaluated with the
 * updated configuration.
 *
 * The `put alarm` operation supports tag-based access control via request
 * tags. For more information, see the Lightsail Developer Guide.
 */
export declare const putAlarm: API.OperationMethod<PutAlarmRequest & RegionInput, PutAlarmResult, PutAlarmError, Credentials | HttpClient.HttpClient>;
export type PutInstancePublicPortsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Opens ports for a specific Amazon Lightsail instance, and specifies the IP addresses
 * allowed to connect to the instance through the ports, and the protocol. This action also
 * closes all currently open ports that are not included in the request. Include all of the ports
 * and the protocols you want to open in your `PutInstancePublicPorts`request. Or use
 * the `OpenInstancePublicPorts` action to open ports without closing currently open
 * ports.
 *
 * The `PutInstancePublicPorts` action supports tag-based access control via
 * resource tags applied to the resource identified by `instanceName`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const putInstancePublicPorts: API.OperationMethod<PutInstancePublicPortsRequest & RegionInput, PutInstancePublicPortsResult, PutInstancePublicPortsError, Credentials | HttpClient.HttpClient>;
export type RebootInstanceError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Restarts a specific instance.
 *
 * The `reboot instance` operation supports tag-based access control via resource
 * tags applied to the resource identified by `instance name`. For more information,
 * see the Amazon Lightsail Developer Guide.
 */
export declare const rebootInstance: API.OperationMethod<RebootInstanceRequest & RegionInput, RebootInstanceResult, RebootInstanceError, Credentials | HttpClient.HttpClient>;
export type RebootRelationalDatabaseError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Restarts a specific database in Amazon Lightsail.
 *
 * The `reboot relational database` operation supports tag-based access control
 * via resource tags applied to the resource identified by relationalDatabaseName. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const rebootRelationalDatabase: API.OperationMethod<RebootRelationalDatabaseRequest & RegionInput, RebootRelationalDatabaseResult, RebootRelationalDatabaseError, Credentials | HttpClient.HttpClient>;
export type RegisterContainerImageError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Registers a container image to your Amazon Lightsail container service.
 *
 * This action is not required if you install and use the Lightsail Control
 * (lightsailctl) plugin to push container images to your Lightsail container service. For
 * more information, see Pushing and managing container images on your Amazon Lightsail container services
 * in the *Amazon Lightsail Developer Guide*.
 */
export declare const registerContainerImage: API.OperationMethod<RegisterContainerImageRequest & RegionInput, RegisterContainerImageResult, RegisterContainerImageError, Credentials | HttpClient.HttpClient>;
export type ReleaseStaticIpError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes a specific static IP from your account.
 */
export declare const releaseStaticIp: API.OperationMethod<ReleaseStaticIpRequest & RegionInput, ReleaseStaticIpResult, ReleaseStaticIpError, Credentials | HttpClient.HttpClient>;
export type ResetDistributionCacheError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes currently cached content from your Amazon Lightsail content delivery network (CDN)
 * distribution.
 *
 * After resetting the cache, the next time a content request is made, your distribution
 * pulls, serves, and caches it from the origin.
 */
export declare const resetDistributionCache: API.OperationMethod<ResetDistributionCacheRequest & RegionInput, ResetDistributionCacheResult, ResetDistributionCacheError, Credentials | HttpClient.HttpClient>;
export type SendContactMethodVerificationError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Sends a verification request to an email contact method to ensure it's owned by the
 * requester. SMS contact methods don't need to be verified.
 *
 * A contact method is used to send you notifications about your Amazon Lightsail resources.
 * You can add one email address and one mobile phone number contact method in each Amazon Web Services Region. However, SMS text messaging is not supported in some Amazon Web Services
 * Regions, and SMS text messages cannot be sent to some countries/regions. For more information,
 * see Notifications in Amazon Lightsail.
 *
 * A verification request is sent to the contact method when you initially create it. Use
 * this action to send another verification request if a previous verification request was
 * deleted, or has expired.
 *
 * Notifications are not sent to an email contact method until after it is verified, and
 * confirmed as valid.
 */
export declare const sendContactMethodVerification: API.OperationMethod<SendContactMethodVerificationRequest & RegionInput, SendContactMethodVerificationResult, SendContactMethodVerificationError, Credentials | HttpClient.HttpClient>;
export type SetIpAddressTypeError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Sets the IP address type for an Amazon Lightsail resource.
 *
 * Use this action to enable dual-stack for a resource, which enables IPv4 and IPv6 for the
 * specified resource. Alternately, you can use this action to disable dual-stack, and enable
 * IPv4 only.
 */
export declare const setIpAddressType: API.OperationMethod<SetIpAddressTypeRequest & RegionInput, SetIpAddressTypeResult, SetIpAddressTypeError, Credentials | HttpClient.HttpClient>;
export type SetResourceAccessForBucketError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Sets the Amazon Lightsail resources that can access the specified Lightsail
 * bucket.
 *
 * Lightsail buckets currently support setting access for Lightsail instances in the same
 * Amazon Web Services Region.
 */
export declare const setResourceAccessForBucket: API.OperationMethod<SetResourceAccessForBucketRequest & RegionInput, SetResourceAccessForBucketResult, SetResourceAccessForBucketError, Credentials | HttpClient.HttpClient>;
export type SetupInstanceHttpsError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Creates an SSL/TLS certificate that secures traffic for your website. After the
 * certificate is created, it is installed on the specified Lightsail instance.
 *
 * If you provide more than one domain name in the request, at least one name must be less
 * than or equal to 63 characters in length.
 */
export declare const setupInstanceHttps: API.OperationMethod<SetupInstanceHttpsRequest & RegionInput, SetupInstanceHttpsResult, SetupInstanceHttpsError, Credentials | HttpClient.HttpClient>;
export type StartGUISessionError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Initiates a graphical user interface (GUI) session that's used to access a virtual
 * computer's operating system and application. The session will be active for 1 hour. Use this
 * action to resume the session after it expires.
 */
export declare const startGUISession: API.OperationMethod<StartGUISessionRequest & RegionInput, StartGUISessionResult, StartGUISessionError, Credentials | HttpClient.HttpClient>;
export type StartInstanceError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Starts a specific Amazon Lightsail instance from a stopped state. To restart an instance,
 * use the `reboot instance` operation.
 *
 * When you start a stopped instance, Lightsail assigns a new public IP address to the
 * instance. To use the same IP address after stopping and starting an instance, create a
 * static IP address and attach it to the instance. For more information, see the Amazon Lightsail Developer Guide.
 *
 * The `start instance` operation supports tag-based access control via resource
 * tags applied to the resource identified by `instance name`. For more information,
 * see the Amazon Lightsail Developer Guide.
 */
export declare const startInstance: API.OperationMethod<StartInstanceRequest & RegionInput, StartInstanceResult, StartInstanceError, Credentials | HttpClient.HttpClient>;
export type StartRelationalDatabaseError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Starts a specific database from a stopped state in Amazon Lightsail. To restart a database,
 * use the `reboot relational database` operation.
 *
 * The `start relational database` operation supports tag-based access control via
 * resource tags applied to the resource identified by relationalDatabaseName. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const startRelationalDatabase: API.OperationMethod<StartRelationalDatabaseRequest & RegionInput, StartRelationalDatabaseResult, StartRelationalDatabaseError, Credentials | HttpClient.HttpClient>;
export type StopGUISessionError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Terminates a web-based Amazon DCV session that's used to access a virtual computer's
 * operating system or application. The session will close and any unsaved data will be
 * lost.
 */
export declare const stopGUISession: API.OperationMethod<StopGUISessionRequest & RegionInput, StopGUISessionResult, StopGUISessionError, Credentials | HttpClient.HttpClient>;
export type StopInstanceError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Stops a specific Amazon Lightsail instance that is currently running.
 *
 * When you start a stopped instance, Lightsail assigns a new public IP address to the
 * instance. To use the same IP address after stopping and starting an instance, create a
 * static IP address and attach it to the instance. For more information, see the Amazon Lightsail Developer Guide.
 *
 * The `stop instance` operation supports tag-based access control via resource
 * tags applied to the resource identified by `instance name`. For more information,
 * see the Amazon Lightsail Developer Guide.
 */
export declare const stopInstance: API.OperationMethod<StopInstanceRequest & RegionInput, StopInstanceResult, StopInstanceError, Credentials | HttpClient.HttpClient>;
export type StopRelationalDatabaseError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Stops a specific database that is currently running in Amazon Lightsail.
 *
 * If you don't manually start your database instance after it has been stopped for seven
 * consecutive days, Amazon Lightsail automatically starts it for you. This action helps ensure
 * that your database instance doesn't fall behind on any required maintenance updates.
 *
 * The `stop relational database` operation supports tag-based access control via
 * resource tags applied to the resource identified by relationalDatabaseName. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const stopRelationalDatabase: API.OperationMethod<StopRelationalDatabaseRequest & RegionInput, StopRelationalDatabaseResult, StopRelationalDatabaseError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Adds one or more tags to the specified Amazon Lightsail resource. Each resource can have a
 * maximum of 50 tags. Each tag consists of a key and an optional value. Tag keys must be unique
 * per resource. For more information about tags, see the Amazon Lightsail Developer Guide.
 *
 * The `tag resource` operation supports tag-based access control via request tags
 * and resource tags applied to the resource identified by `resource name`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResult, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestAlarmError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Tests an alarm by displaying a banner on the Amazon Lightsail console. If a notification
 * trigger is configured for the specified alarm, the test also sends a notification to the
 * notification protocol (`Email` and/or `SMS`) configured for the
 * alarm.
 *
 * An alarm is used to monitor a single metric for one of your resources. When a metric
 * condition is met, the alarm can notify you by email, SMS text message, and a banner displayed
 * on the Amazon Lightsail console. For more information, see Alarms
 * in Amazon Lightsail.
 */
export declare const testAlarm: API.OperationMethod<TestAlarmRequest & RegionInput, TestAlarmResult, TestAlarmError, Credentials | HttpClient.HttpClient>;
export type UnpeerVpcError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Unpeers the Lightsail VPC from the user's default VPC.
 */
export declare const unpeerVpc: API.OperationMethod<UnpeerVpcRequest & RegionInput, UnpeerVpcResult, UnpeerVpcError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Deletes the specified set of tag keys and their values from the specified Amazon Lightsail
 * resource.
 *
 * The `untag resource` operation supports tag-based access control via request
 * tags and resource tags applied to the resource identified by `resource name`. For
 * more information, see the Amazon Lightsail Developer Guide.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResult, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBucketError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Updates an existing Amazon Lightsail bucket.
 *
 * Use this action to update the configuration of an existing bucket, such as versioning,
 * public accessibility, and the Amazon Web Services accounts that can access the bucket.
 */
export declare const updateBucket: API.OperationMethod<UpdateBucketRequest & RegionInput, UpdateBucketResult, UpdateBucketError, Credentials | HttpClient.HttpClient>;
export type UpdateBucketBundleError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Updates the bundle, or storage plan, of an existing Amazon Lightsail bucket.
 *
 * A bucket bundle specifies the monthly cost, storage space, and data transfer quota for a
 * bucket. You can update a bucket's bundle only one time within a monthly Amazon Web Services
 * billing cycle. To determine if you can update a bucket's bundle, use the GetBuckets action. The
 * `ableToUpdateBundle` parameter in the response will indicate whether you can
 * currently update a bucket's bundle.
 *
 * Update a bucket's bundle if it's consistently going over its storage space or data
 * transfer quota, or if a bucket's usage is consistently in the lower range of its storage space
 * or data transfer quota. Due to the unpredictable usage fluctuations that a bucket might
 * experience, we strongly recommend that you update a bucket's bundle only as a long-term
 * strategy, instead of as a short-term, monthly cost-cutting measure. Choose a bucket bundle
 * that will provide the bucket with ample storage space and data transfer for a long time to
 * come.
 */
export declare const updateBucketBundle: API.OperationMethod<UpdateBucketBundleRequest & RegionInput, UpdateBucketBundleResult, UpdateBucketBundleError, Credentials | HttpClient.HttpClient>;
export type UpdateContainerServiceError = AccessDeniedException | InvalidInputException | NotFoundException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Updates the configuration of your Amazon Lightsail container service, such as its power,
 * scale, and public domain names.
 */
export declare const updateContainerService: API.OperationMethod<UpdateContainerServiceRequest & RegionInput, UpdateContainerServiceResult, UpdateContainerServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Updates an existing Amazon Lightsail content delivery network (CDN) distribution.
 *
 * Use this action to update the configuration of your existing distribution.
 */
export declare const updateDistribution: API.OperationMethod<UpdateDistributionRequest & RegionInput, UpdateDistributionResult, UpdateDistributionError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionBundleError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Updates the bundle of your Amazon Lightsail content delivery network (CDN)
 * distribution.
 *
 * A distribution bundle specifies the monthly network transfer quota and monthly cost of
 * your distribution.
 *
 * Update your distribution's bundle if your distribution is going over its monthly network
 * transfer quota and is incurring an overage fee.
 *
 * You can update your distribution's bundle only one time within your monthly Amazon Web Services billing cycle. To determine if you can update your distribution's bundle, use the
 * `GetDistributions` action. The `ableToUpdateBundle` parameter in the
 * result will indicate whether you can currently update your distribution's bundle.
 */
export declare const updateDistributionBundle: API.OperationMethod<UpdateDistributionBundleRequest & RegionInput, UpdateDistributionBundleResult, UpdateDistributionBundleError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainEntryError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Updates a domain recordset after it is created.
 *
 * The `update domain entry` operation supports tag-based access control via
 * resource tags applied to the resource identified by `domain name`. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const updateDomainEntry: API.OperationMethod<UpdateDomainEntryRequest & RegionInput, UpdateDomainEntryResult, UpdateDomainEntryError, Credentials | HttpClient.HttpClient>;
export type UpdateInstanceMetadataOptionsError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Modifies the Amazon Lightsail instance metadata parameters on a running or stopped
 * instance. When you modify the parameters on a running instance, the `GetInstance`
 * or `GetInstances` API operation initially responds with a state of
 * `pending`. After the parameter modifications are successfully applied, the state
 * changes to `applied` in subsequent `GetInstance` or
 * `GetInstances` API calls. For more information, see Use IMDSv2 with an Amazon Lightsail instance in the *Amazon Lightsail Developer Guide*.
 */
export declare const updateInstanceMetadataOptions: API.OperationMethod<UpdateInstanceMetadataOptionsRequest & RegionInput, UpdateInstanceMetadataOptionsResult, UpdateInstanceMetadataOptionsError, Credentials | HttpClient.HttpClient>;
export type UpdateLoadBalancerAttributeError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Updates the specified attribute for a load balancer. You can only update one attribute at
 * a time.
 *
 * The `update load balancer attribute` operation supports tag-based access
 * control via resource tags applied to the resource identified by load balancer
 * name. For more information, see the Amazon Lightsail Developer Guide.
 */
export declare const updateLoadBalancerAttribute: API.OperationMethod<UpdateLoadBalancerAttributeRequest & RegionInput, UpdateLoadBalancerAttributeResult, UpdateLoadBalancerAttributeError, Credentials | HttpClient.HttpClient>;
export type UpdateRelationalDatabaseError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Allows the update of one or more attributes of a database in Amazon Lightsail.
 *
 * Updates are applied immediately, or in cases where the updates could result in an outage,
 * are applied during the database's predefined maintenance window.
 *
 * The `update relational database` operation supports tag-based access control
 * via resource tags applied to the resource identified by relationalDatabaseName. For more
 * information, see the Amazon Lightsail Developer Guide.
 */
export declare const updateRelationalDatabase: API.OperationMethod<UpdateRelationalDatabaseRequest & RegionInput, UpdateRelationalDatabaseResult, UpdateRelationalDatabaseError, Credentials | HttpClient.HttpClient>;
export type UpdateRelationalDatabaseParametersError = AccessDeniedException | AccountSetupInProgressException | InvalidInputException | NotFoundException | OperationFailureException | RegionSetupInProgressException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Allows the update of one or more parameters of a database in Amazon Lightsail.
 *
 * Parameter updates don't cause outages; therefore, their application is not subject to the
 * preferred maintenance window. However, there are two ways in which parameter updates are
 * applied: `dynamic` or `pending-reboot`. Parameters marked with a
 * `dynamic` apply type are applied immediately. Parameters marked with a
 * `pending-reboot` apply type are applied only after the database is rebooted using
 * the `reboot relational database` operation.
 *
 * The `update relational database parameters` operation supports tag-based access
 * control via resource tags applied to the resource identified by relationalDatabaseName. For
 * more information, see the Amazon Lightsail Developer Guide.
 */
export declare const updateRelationalDatabaseParameters: API.OperationMethod<UpdateRelationalDatabaseParametersRequest & RegionInput, UpdateRelationalDatabaseParametersResult, UpdateRelationalDatabaseParametersError, Credentials | HttpClient.HttpClient>;
export type UpdateSubdomainAssociationError = AccessDeniedException | InvalidInputException | NotFoundException | OperationFailureException | ServiceException | UnauthenticatedException | CommonErrors;
/**
 * Associates a Lightsail subdomain with a resource, disassociates it from a resource, or
 * moves it from one resource to another resource.
 *
 * Currently, you can associate a subdomain only with a Lightsail content delivery network
 * (CDN) distribution. A resource can be associated with only one subdomain at a time.
 *
 * When you associate a subdomain with a distribution, Lightsail attaches the subdomain's
 * certificate to the distribution. You can't associate a subdomain with a distribution that uses
 * a custom domain, which is a distribution that has a Lightsail certificate attached.
 *
 * You can transfer each subdomain to another resource only once in a 24-hour period.
 *
 * The update is asynchronous. The response returns the subdomain in the
 * `ATTACHING`, `DETACHING`, or `TRANSFERRING` state, and an
 * operation. To check when the update is complete, use the `GetSubdomains`
 * action.
 */
export declare const updateSubdomainAssociation: API.OperationMethod<UpdateSubdomainAssociationRequest & RegionInput, UpdateSubdomainAssociationResult, UpdateSubdomainAssociationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lightsail.d.ts.map