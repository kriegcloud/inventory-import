import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConcurrentUpdateException_base: S.TaggedErrorClass<"ConcurrentUpdateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConcurrentUpdateException extends /*@__PURE__*/ ConcurrentUpdateException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ObjectNotFoundException_base: S.TaggedErrorClass<"ObjectNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ObjectNotFoundException extends /*@__PURE__*/ ObjectNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ScalingPlanName = string;
export type XmlString = string;
export type XmlStringMaxLen128 = string;
export type XmlStringMaxLen256 = string;
export type TagValues = string[];
export interface TagFilter {
    Key?: string | undefined;
    Values?: string[] | undefined;
}
export type TagFilters = TagFilter[];
export interface ApplicationSource {
    CloudFormationStackARN?: string | undefined;
    TagFilters?: TagFilter[] | undefined;
}
export type ServiceNamespace = "autoscaling" | "ecs" | "ec2" | "rds" | "dynamodb" | (string & {});
export type ResourceIdMaxLen1600 = string;
export type ScalableDimension = "autoscaling:autoScalingGroup:DesiredCapacity" | "ecs:service:DesiredCount" | "ec2:spot-fleet-request:TargetCapacity" | "rds:cluster:ReadReplicaCount" | "dynamodb:table:ReadCapacityUnits" | "dynamodb:table:WriteCapacityUnits" | "dynamodb:index:ReadCapacityUnits" | "dynamodb:index:WriteCapacityUnits" | (string & {});
export type ResourceCapacity = number;
export type ScalingMetricType = "ASGAverageCPUUtilization" | "ASGAverageNetworkIn" | "ASGAverageNetworkOut" | "DynamoDBReadCapacityUtilization" | "DynamoDBWriteCapacityUtilization" | "ECSServiceAverageCPUUtilization" | "ECSServiceAverageMemoryUtilization" | "ALBRequestCountPerTarget" | "RDSReaderAverageCPUUtilization" | "RDSReaderAverageDatabaseConnections" | "EC2SpotFleetRequestAverageCPUUtilization" | "EC2SpotFleetRequestAverageNetworkIn" | "EC2SpotFleetRequestAverageNetworkOut" | (string & {});
export type ResourceLabel = string;
export interface PredefinedScalingMetricSpecification {
    PredefinedScalingMetricType: ScalingMetricType;
    ResourceLabel?: string | undefined;
}
export type MetricName = string;
export type MetricNamespace = string;
export type MetricDimensionName = string;
export type MetricDimensionValue = string;
export interface MetricDimension {
    Name: string;
    Value: string;
}
export type MetricDimensions = MetricDimension[];
export type MetricStatistic = "Average" | "Minimum" | "Maximum" | "SampleCount" | "Sum" | (string & {});
export type MetricUnit = string;
export interface CustomizedScalingMetricSpecification {
    MetricName: string;
    Namespace: string;
    Dimensions?: MetricDimension[] | undefined;
    Statistic: MetricStatistic;
    Unit?: string | undefined;
}
export type MetricScale = number;
export type DisableScaleIn = boolean;
export type Cooldown = number;
export interface TargetTrackingConfiguration {
    PredefinedScalingMetricSpecification?: PredefinedScalingMetricSpecification | undefined;
    CustomizedScalingMetricSpecification?: CustomizedScalingMetricSpecification | undefined;
    TargetValue: number;
    DisableScaleIn?: boolean | undefined;
    ScaleOutCooldown?: number | undefined;
    ScaleInCooldown?: number | undefined;
    EstimatedInstanceWarmup?: number | undefined;
}
export type TargetTrackingConfigurations = TargetTrackingConfiguration[];
export type LoadMetricType = "ASGTotalCPUUtilization" | "ASGTotalNetworkIn" | "ASGTotalNetworkOut" | "ALBTargetGroupRequestCount" | (string & {});
export interface PredefinedLoadMetricSpecification {
    PredefinedLoadMetricType: LoadMetricType;
    ResourceLabel?: string | undefined;
}
export interface CustomizedLoadMetricSpecification {
    MetricName: string;
    Namespace: string;
    Dimensions?: MetricDimension[] | undefined;
    Statistic: MetricStatistic;
    Unit?: string | undefined;
}
export type ScheduledActionBufferTime = number;
export type PredictiveScalingMaxCapacityBehavior = "SetForecastCapacityToMaxCapacity" | "SetMaxCapacityToForecastCapacity" | "SetMaxCapacityAboveForecastCapacity" | (string & {});
export type PredictiveScalingMode = "ForecastAndScale" | "ForecastOnly" | (string & {});
export type ScalingPolicyUpdateBehavior = "KeepExternalPolicies" | "ReplaceExternalPolicies" | (string & {});
export type DisableDynamicScaling = boolean;
export interface ScalingInstruction {
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    MinCapacity: number;
    MaxCapacity: number;
    TargetTrackingConfigurations: TargetTrackingConfiguration[];
    PredefinedLoadMetricSpecification?: PredefinedLoadMetricSpecification | undefined;
    CustomizedLoadMetricSpecification?: CustomizedLoadMetricSpecification | undefined;
    ScheduledActionBufferTime?: number | undefined;
    PredictiveScalingMaxCapacityBehavior?: PredictiveScalingMaxCapacityBehavior | undefined;
    PredictiveScalingMaxCapacityBuffer?: number | undefined;
    PredictiveScalingMode?: PredictiveScalingMode | undefined;
    ScalingPolicyUpdateBehavior?: ScalingPolicyUpdateBehavior | undefined;
    DisableDynamicScaling?: boolean | undefined;
}
export type ScalingInstructions = ScalingInstruction[];
export interface CreateScalingPlanRequest {
    ScalingPlanName: string;
    ApplicationSource: ApplicationSource;
    ScalingInstructions: ScalingInstruction[];
}
export type ScalingPlanVersion = number;
export interface CreateScalingPlanResponse {
    ScalingPlanVersion: number;
}
export interface DeleteScalingPlanRequest {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
}
export interface DeleteScalingPlanResponse {
}
export type MaxResults = number;
export type NextToken = string;
export interface DescribeScalingPlanResourcesRequest {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PolicyName = string;
export type PolicyType = "TargetTrackingScaling" | (string & {});
export interface ScalingPolicy {
    PolicyName: string;
    PolicyType: PolicyType;
    TargetTrackingConfiguration?: TargetTrackingConfiguration | undefined;
}
export type ScalingPolicies = ScalingPolicy[];
export type ScalingStatusCode = "Inactive" | "PartiallyActive" | "Active" | (string & {});
export interface ScalingPlanResource {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    ScalingPolicies?: ScalingPolicy[] | undefined;
    ScalingStatusCode: ScalingStatusCode;
    ScalingStatusMessage?: string | undefined;
}
export type ScalingPlanResources = ScalingPlanResource[];
export interface DescribeScalingPlanResourcesResponse {
    ScalingPlanResources?: ScalingPlanResource[] | undefined;
    NextToken?: string | undefined;
}
export type ScalingPlanNames = string[];
export type ApplicationSources = ApplicationSource[];
export interface DescribeScalingPlansRequest {
    ScalingPlanNames?: string[] | undefined;
    ScalingPlanVersion?: number | undefined;
    ApplicationSources?: ApplicationSource[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ScalingPlanStatusCode = "Active" | "ActiveWithProblems" | "CreationInProgress" | "CreationFailed" | "DeletionInProgress" | "DeletionFailed" | "UpdateInProgress" | "UpdateFailed" | (string & {});
export interface ScalingPlan {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    ApplicationSource: ApplicationSource;
    ScalingInstructions: ScalingInstruction[];
    StatusCode: ScalingPlanStatusCode;
    StatusMessage?: string | undefined;
    StatusStartTime?: Date | undefined;
    CreationTime?: Date | undefined;
}
export type ScalingPlans = ScalingPlan[];
export interface DescribeScalingPlansResponse {
    ScalingPlans?: ScalingPlan[] | undefined;
    NextToken?: string | undefined;
}
export type ForecastDataType = "CapacityForecast" | "LoadForecast" | "ScheduledActionMinCapacity" | "ScheduledActionMaxCapacity" | (string & {});
export interface GetScalingPlanResourceForecastDataRequest {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    ForecastDataType: ForecastDataType;
    StartTime: Date;
    EndTime: Date;
}
export interface Datapoint {
    Timestamp?: Date | undefined;
    Value?: number | undefined;
}
export type Datapoints = Datapoint[];
export interface GetScalingPlanResourceForecastDataResponse {
    Datapoints: Datapoint[];
}
export interface UpdateScalingPlanRequest {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    ApplicationSource?: ApplicationSource | undefined;
    ScalingInstructions?: ScalingInstruction[] | undefined;
}
export interface UpdateScalingPlanResponse {
}
export type ErrorMessage = string;
export type CreateScalingPlanError = ConcurrentUpdateException | InternalServiceException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a scaling plan.
 */
export declare const createScalingPlan: API.OperationMethod<CreateScalingPlanRequest & RegionInput, CreateScalingPlanResponse, CreateScalingPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteScalingPlanError = ConcurrentUpdateException | InternalServiceException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified scaling plan.
 *
 * Deleting a scaling plan deletes the underlying ScalingInstruction for
 * all of the scalable resources that are covered by the plan.
 *
 * If the plan has launched resources or has scaling activities in progress, you must
 * delete those resources separately.
 */
export declare const deleteScalingPlan: API.OperationMethod<DeleteScalingPlanRequest & RegionInput, DeleteScalingPlanResponse, DeleteScalingPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeScalingPlanResourcesError = ConcurrentUpdateException | InternalServiceException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Describes the scalable resources in the specified scaling plan.
 */
export declare const describeScalingPlanResources: API.OperationMethod<DescribeScalingPlanResourcesRequest & RegionInput, DescribeScalingPlanResourcesResponse, DescribeScalingPlanResourcesError, Credentials | HttpClient.HttpClient>;
export type DescribeScalingPlansError = ConcurrentUpdateException | InternalServiceException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Describes one or more of your scaling plans.
 */
export declare const describeScalingPlans: API.OperationMethod<DescribeScalingPlansRequest & RegionInput, DescribeScalingPlansResponse, DescribeScalingPlansError, Credentials | HttpClient.HttpClient>;
export type GetScalingPlanResourceForecastDataError = InternalServiceException | ValidationException | CommonErrors;
/**
 * Retrieves the forecast data for a scalable resource.
 *
 * Capacity forecasts are represented as predicted values, or data points, that are
 * calculated using historical data points from a specified CloudWatch load metric. Data points are
 * available for up to 56 days.
 */
export declare const getScalingPlanResourceForecastData: API.OperationMethod<GetScalingPlanResourceForecastDataRequest & RegionInput, GetScalingPlanResourceForecastDataResponse, GetScalingPlanResourceForecastDataError, Credentials | HttpClient.HttpClient>;
export type UpdateScalingPlanError = ConcurrentUpdateException | InternalServiceException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the specified scaling plan.
 *
 * You cannot update a scaling plan if it is in the process of being created, updated, or
 * deleted.
 */
export declare const updateScalingPlan: API.OperationMethod<UpdateScalingPlanRequest & RegionInput, UpdateScalingPlanResponse, UpdateScalingPlanError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=auto-scaling-plans.d.ts.map