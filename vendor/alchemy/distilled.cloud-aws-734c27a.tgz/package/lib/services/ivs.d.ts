import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ChannelNotBroadcasting_base: S.TaggedErrorClass<"ChannelNotBroadcasting", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelNotBroadcasting extends /*@__PURE__*/ ChannelNotBroadcasting_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const PendingVerification_base: S.TaggedErrorClass<"PendingVerification", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class PendingVerification extends /*@__PURE__*/ PendingVerification_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailable_base: S.TaggedErrorClass<"ServiceUnavailable", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailable extends /*@__PURE__*/ ServiceUnavailable_base {
}
declare const StreamUnavailable_base: S.TaggedErrorClass<"StreamUnavailable", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class StreamUnavailable extends /*@__PURE__*/ StreamUnavailable_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly accessControlAllowOrigin: any;
    readonly accessControlExposeHeaders: any;
    readonly cacheControl: any;
    readonly contentSecurityPolicy: any;
    readonly strictTransportSecurity: any;
    readonly xContentTypeOptions: any;
    readonly xFrameOptions: any;
    readonly xAmznErrorType: any;
    readonly exceptionMessage: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ChannelArn = string;
export type ChannelArnList = string[];
export interface BatchGetChannelRequest {
    arns: string[];
}
export type ChannelName = string;
export type ChannelLatencyMode = string;
export type ChannelType = "BASIC" | "STANDARD" | "ADVANCED_SD" | "ADVANCED_HD" | (string & {});
export type ChannelRecordingConfigurationArn = string;
export type IngestEndpoint = string;
export type PlaybackURL = string;
export type IsAuthorized = boolean;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type InsecureIngest = boolean;
export type TranscodePreset = "HIGHER_BANDWIDTH_DELIVERY" | "CONSTRAINED_BANDWIDTH_DELIVERY" | (string & {});
export type SrtEndpoint = string;
export type SrtPassphrase = string | redacted.Redacted<string>;
export interface Srt {
    endpoint?: string | undefined;
    passphrase?: string | redacted.Redacted<string> | undefined;
}
export type ChannelPlaybackRestrictionPolicyArn = string;
export type IsMultitrackInputEnabled = boolean;
export type MultitrackPolicy = "ALLOW" | "REQUIRE" | (string & {});
export type MultitrackMaximumResolution = "SD" | "HD" | "FULL_HD" | (string & {});
export interface MultitrackInputConfiguration {
    enabled?: boolean | undefined;
    policy?: MultitrackPolicy | undefined;
    maximumResolution?: MultitrackMaximumResolution | undefined;
}
export type ContainerFormat = string;
export type ChannelAdConfigurationArn = string;
export type ChannelFailoverSlateConfigurationArn = string;
export interface Channel {
    arn?: string | undefined;
    name?: string | undefined;
    latencyMode?: string | undefined;
    type?: ChannelType | undefined;
    recordingConfigurationArn?: string | undefined;
    ingestEndpoint?: string | undefined;
    playbackUrl?: string | undefined;
    authorized?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    insecureIngest?: boolean | undefined;
    preset?: TranscodePreset | undefined;
    srt?: Srt | undefined;
    playbackRestrictionPolicyArn?: string | undefined;
    multitrackInputConfiguration?: MultitrackInputConfiguration | undefined;
    containerFormat?: string | undefined;
    adConfigurationArn?: string | undefined;
    failoverSlateConfigurationArn?: string | undefined;
}
export type Channels = Channel[];
export type ResourceArn = string;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface BatchError {
    arn?: string | undefined;
    code?: string | undefined;
    message?: string | undefined;
}
export type BatchErrors = BatchError[];
export interface BatchGetChannelResponse {
    accessControlAllowOrigin?: string | undefined;
    accessControlExposeHeaders?: string | undefined;
    cacheControl?: string | undefined;
    contentSecurityPolicy?: string | undefined;
    strictTransportSecurity?: string | undefined;
    xContentTypeOptions?: string | undefined;
    xFrameOptions?: string | undefined;
    channels?: Channel[] | undefined;
    errors?: BatchError[] | undefined;
}
export type StreamKeyArn = string;
export type StreamKeyArnList = string[];
export interface BatchGetStreamKeyRequest {
    arns: string[];
}
export type StreamKeyValue = string | redacted.Redacted<string>;
export interface StreamKey {
    arn?: string | undefined;
    value?: string | redacted.Redacted<string> | undefined;
    channelArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StreamKeys = StreamKey[];
export interface BatchGetStreamKeyResponse {
    accessControlAllowOrigin?: string | undefined;
    accessControlExposeHeaders?: string | undefined;
    cacheControl?: string | undefined;
    contentSecurityPolicy?: string | undefined;
    strictTransportSecurity?: string | undefined;
    xContentTypeOptions?: string | undefined;
    xFrameOptions?: string | undefined;
    streamKeys?: StreamKey[] | undefined;
    errors?: BatchError[] | undefined;
}
export type ViewerId = string;
export type ViewerSessionVersion = number;
export interface BatchStartViewerSessionRevocationViewerSession {
    channelArn: string;
    viewerId: string;
    viewerSessionVersionsLessThanOrEqualTo?: number | undefined;
}
export type BatchStartViewerSessionRevocationViewerSessionList = BatchStartViewerSessionRevocationViewerSession[];
export interface BatchStartViewerSessionRevocationRequest {
    viewerSessions: BatchStartViewerSessionRevocationViewerSession[];
}
export interface BatchStartViewerSessionRevocationError_ {
    channelArn: string;
    viewerId: string;
    code?: string | undefined;
    message?: string | undefined;
}
export type BatchStartViewerSessionRevocationErrors = BatchStartViewerSessionRevocationError_[];
export interface BatchStartViewerSessionRevocationResponse {
    accessControlAllowOrigin?: string | undefined;
    accessControlExposeHeaders?: string | undefined;
    cacheControl?: string | undefined;
    contentSecurityPolicy?: string | undefined;
    strictTransportSecurity?: string | undefined;
    xContentTypeOptions?: string | undefined;
    xFrameOptions?: string | undefined;
    errors?: BatchStartViewerSessionRevocationError_[] | undefined;
}
export type AdConfigurationName = string;
export type MediaTailorPlaybackConfigurationArn = string;
export interface MediaTailorPlaybackConfiguration {
    playbackConfigurationArn?: string | undefined;
}
export type MediaTailorPlaybackConfigurationsList = MediaTailorPlaybackConfiguration[];
export type AdDurationSeconds = number;
export interface PostRollConfiguration {
    durationSeconds: number;
    enabled: boolean;
}
export interface CreateAdConfigurationRequest {
    name?: string | undefined;
    mediaTailorPlaybackConfigurations: MediaTailorPlaybackConfiguration[];
    postRollConfiguration?: PostRollConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AdConfigurationArn = string;
export interface AdConfiguration {
    arn: string;
    name?: string | undefined;
    mediaTailorPlaybackConfigurations: MediaTailorPlaybackConfiguration[];
    postRollConfiguration?: PostRollConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateAdConfigurationResponse {
    adConfiguration: AdConfiguration;
}
export interface CreateChannelRequest {
    name?: string | undefined;
    latencyMode?: string | undefined;
    type?: ChannelType | undefined;
    authorized?: boolean | undefined;
    recordingConfigurationArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    insecureIngest?: boolean | undefined;
    preset?: TranscodePreset | undefined;
    playbackRestrictionPolicyArn?: string | undefined;
    multitrackInputConfiguration?: MultitrackInputConfiguration | undefined;
    containerFormat?: string | undefined;
    adConfigurationArn?: string | undefined;
    failoverSlateConfigurationArn?: string | undefined;
}
export interface CreateChannelResponse {
    channel?: Channel | undefined;
    streamKey?: StreamKey | undefined;
}
export type FailoverSlateConfigurationName = string;
export type FailoverSlateActivationThresholdSeconds = number;
export type FailoverSlateMinDisplaySeconds = number;
export type FailoverSlateMaxDisplaySeconds = number;
export interface CreateFailoverSlateConfigurationRequest {
    name?: string | undefined;
    activationThresholdSeconds?: number | undefined;
    minSlateDisplaySeconds?: number | undefined;
    maxSlateDisplaySeconds?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type FailoverSlateConfigurationArn = string;
export type FailoverSlateConfigurationState = string;
export interface FailoverSlateConfiguration {
    arn: string;
    name?: string | undefined;
    activationThresholdSeconds?: number | undefined;
    minSlateDisplaySeconds?: number | undefined;
    maxSlateDisplaySeconds?: number | undefined;
    state: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateFailoverSlateConfigurationResponse {
    failoverSlateConfiguration: FailoverSlateConfiguration;
}
export type PlaybackRestrictionPolicyAllowedCountry = string;
export type PlaybackRestrictionPolicyAllowedCountryList = string[];
export type PlaybackRestrictionPolicyAllowedOrigin = string;
export type PlaybackRestrictionPolicyAllowedOriginList = string[];
export type PlaybackRestrictionPolicyEnableStrictOriginEnforcement = boolean;
export type PlaybackRestrictionPolicyName = string;
export interface CreatePlaybackRestrictionPolicyRequest {
    allowedCountries?: string[] | undefined;
    allowedOrigins?: string[] | undefined;
    enableStrictOriginEnforcement?: boolean | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PlaybackRestrictionPolicyArn = string;
export interface PlaybackRestrictionPolicy {
    arn: string;
    allowedCountries: string[];
    allowedOrigins: string[];
    enableStrictOriginEnforcement?: boolean | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreatePlaybackRestrictionPolicyResponse {
    playbackRestrictionPolicy?: PlaybackRestrictionPolicy | undefined;
}
export type RecordingConfigurationName = string;
export type S3DestinationBucketName = string;
export interface S3DestinationConfiguration {
    bucketName: string;
}
export interface DestinationConfiguration {
    s3?: S3DestinationConfiguration | undefined;
}
export type RecordingMode = string;
export type TargetIntervalSeconds = number;
export type ThumbnailConfigurationResolution = "SD" | "HD" | "FULL_HD" | "LOWEST_RESOLUTION" | (string & {});
export type ThumbnailConfigurationStorage = string;
export type ThumbnailConfigurationStorageList = string[];
export interface ThumbnailConfiguration {
    recordingMode?: string | undefined;
    targetIntervalSeconds?: number | undefined;
    resolution?: ThumbnailConfigurationResolution | undefined;
    storage?: string[] | undefined;
}
export type RecordingReconnectWindowSeconds = number;
export type RenditionConfigurationRenditionSelection = string;
export type RenditionConfigurationRendition = "SD" | "HD" | "FULL_HD" | "LOWEST_RESOLUTION" | (string & {});
export type RenditionConfigurationRenditionList = RenditionConfigurationRendition[];
export interface RenditionConfiguration {
    renditionSelection?: string | undefined;
    renditions?: RenditionConfigurationRendition[] | undefined;
}
export interface CreateRecordingConfigurationRequest {
    name?: string | undefined;
    destinationConfiguration: DestinationConfiguration;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    thumbnailConfiguration?: ThumbnailConfiguration | undefined;
    recordingReconnectWindowSeconds?: number | undefined;
    renditionConfiguration?: RenditionConfiguration | undefined;
}
export type RecordingConfigurationArn = string;
export type RecordingConfigurationState = string;
export interface RecordingConfiguration {
    arn: string;
    name?: string | undefined;
    destinationConfiguration: DestinationConfiguration;
    state: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    thumbnailConfiguration?: ThumbnailConfiguration | undefined;
    recordingReconnectWindowSeconds?: number | undefined;
    renditionConfiguration?: RenditionConfiguration | undefined;
}
export interface CreateRecordingConfigurationResponse {
    recordingConfiguration?: RecordingConfiguration | undefined;
}
export interface CreateStreamKeyRequest {
    channelArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateStreamKeyResponse {
    streamKey?: StreamKey | undefined;
}
export interface DeleteAdConfigurationRequest {
    arn: string;
}
export interface DeleteAdConfigurationResponse {
}
export interface DeleteChannelRequest {
    arn: string;
}
export interface DeleteChannelResponse {
}
export interface DeleteFailoverSlateConfigurationRequest {
    arn: string;
}
export interface DeleteFailoverSlateConfigurationResponse {
}
export type PlaybackKeyPairArn = string;
export interface DeletePlaybackKeyPairRequest {
    arn: string;
}
export interface DeletePlaybackKeyPairResponse {
}
export interface DeletePlaybackRestrictionPolicyRequest {
    arn: string;
}
export interface DeletePlaybackRestrictionPolicyResponse {
}
export interface DeleteRecordingConfigurationRequest {
    arn: string;
}
export interface DeleteRecordingConfigurationResponse {
}
export interface DeleteStreamKeyRequest {
    arn: string;
}
export interface DeleteStreamKeyResponse {
}
export interface GetAdConfigurationRequest {
    arn: string;
}
export interface GetAdConfigurationResponse {
    adConfiguration?: AdConfiguration | undefined;
}
export interface GetChannelRequest {
    arn: string;
}
export interface GetChannelResponse {
    channel?: Channel | undefined;
}
export interface GetFailoverSlateConfigurationRequest {
    arn: string;
}
export interface GetFailoverSlateConfigurationResponse {
    failoverSlateConfiguration: FailoverSlateConfiguration;
}
export interface GetPlaybackKeyPairRequest {
    arn: string;
}
export type PlaybackKeyPairName = string;
export type PlaybackKeyPairFingerprint = string;
export interface PlaybackKeyPair {
    arn?: string | undefined;
    name?: string | undefined;
    fingerprint?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetPlaybackKeyPairResponse {
    keyPair?: PlaybackKeyPair | undefined;
}
export interface GetPlaybackRestrictionPolicyRequest {
    arn: string;
}
export interface GetPlaybackRestrictionPolicyResponse {
    playbackRestrictionPolicy?: PlaybackRestrictionPolicy | undefined;
}
export interface GetRecordingConfigurationRequest {
    arn: string;
}
export interface GetRecordingConfigurationResponse {
    recordingConfiguration?: RecordingConfiguration | undefined;
}
export interface GetStreamRequest {
    channelArn: string;
}
export type StreamId = string;
export type StreamStartTime = Date;
export type StreamState = string;
export type StreamHealth = string;
export type StreamViewerCount = number;
export interface Stream {
    channelArn?: string | undefined;
    streamId?: string | undefined;
    playbackUrl?: string | undefined;
    startTime?: Date | undefined;
    state?: string | undefined;
    health?: string | undefined;
    viewerCount?: number | undefined;
}
export interface GetStreamResponse {
    stream?: Stream | undefined;
}
export interface GetStreamKeyRequest {
    arn: string;
}
export interface GetStreamKeyResponse {
    streamKey?: StreamKey | undefined;
}
export interface GetStreamSessionRequest {
    channelArn: string;
    streamId?: string | undefined;
}
export interface VideoConfiguration {
    avcProfile?: string | undefined;
    avcLevel?: string | undefined;
    codec?: string | undefined;
    encoder?: string | undefined;
    targetBitrate?: number | undefined;
    targetFramerate?: number | undefined;
    videoHeight?: number | undefined;
    videoWidth?: number | undefined;
    level?: string | undefined;
    track?: string | undefined;
    profile?: string | undefined;
}
export interface AudioConfiguration {
    codec?: string | undefined;
    targetBitrate?: number | undefined;
    sampleRate?: number | undefined;
    channels?: number | undefined;
    track?: string | undefined;
}
export interface IngestConfiguration {
    video?: VideoConfiguration | undefined;
    audio?: AudioConfiguration | undefined;
}
export type VideoConfigurationList = VideoConfiguration[];
export type AudioConfigurationList = AudioConfiguration[];
export interface IngestConfigurations {
    videoConfigurations: VideoConfiguration[];
    audioConfigurations: AudioConfiguration[];
}
export interface StreamEvent {
    name?: string | undefined;
    type?: string | undefined;
    eventTime?: Date | undefined;
    code?: string | undefined;
}
export type StreamEvents = StreamEvent[];
export interface StreamSession {
    streamId?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    channel?: Channel | undefined;
    ingestConfiguration?: IngestConfiguration | undefined;
    ingestConfigurations?: IngestConfigurations | undefined;
    recordingConfiguration?: RecordingConfiguration | undefined;
    truncatedEvents?: StreamEvent[] | undefined;
    failoverSlateConfiguration?: FailoverSlateConfiguration | undefined;
}
export interface GetStreamSessionResponse {
    streamSession?: StreamSession | undefined;
}
export type PlaybackPublicKeyMaterial = string;
export interface ImportPlaybackKeyPairRequest {
    publicKeyMaterial: string;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ImportPlaybackKeyPairResponse {
    keyPair?: PlaybackKeyPair | undefined;
}
export type AdBreakId = string;
export interface InsertAdBreakRequest {
    channelArn: string;
    durationSeconds: number;
    adBreakId?: string | undefined;
    targetStartAt?: Date | undefined;
}
export interface InsertAdBreakResponse {
    adBreakId?: string | undefined;
    targetStartAt?: Date | undefined;
}
export type PaginationToken = string;
export type MaxAdConfigurationResults = number;
export interface ListAdConfigurationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AdConfigurationSummary {
    arn: string;
    name?: string | undefined;
    mediaTailorPlaybackConfigurations: MediaTailorPlaybackConfiguration[];
    postRollConfiguration?: PostRollConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AdConfigurationList = AdConfigurationSummary[];
export interface ListAdConfigurationsResponse {
    adConfigurations: AdConfigurationSummary[];
    nextToken?: string | undefined;
}
export type MaxChannelResults = number;
export interface ListChannelsRequest {
    filterByName?: string | undefined;
    filterByRecordingConfigurationArn?: string | undefined;
    filterByPlaybackRestrictionPolicyArn?: string | undefined;
    filterByAdConfigurationArn?: string | undefined;
    filterByFailoverSlateConfigurationArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ChannelSummary {
    arn?: string | undefined;
    name?: string | undefined;
    latencyMode?: string | undefined;
    authorized?: boolean | undefined;
    recordingConfigurationArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    insecureIngest?: boolean | undefined;
    type?: ChannelType | undefined;
    preset?: TranscodePreset | undefined;
    playbackRestrictionPolicyArn?: string | undefined;
    adConfigurationArn?: string | undefined;
    failoverSlateConfigurationArn?: string | undefined;
}
export type ChannelList = ChannelSummary[];
export interface ListChannelsResponse {
    channels: ChannelSummary[];
    nextToken?: string | undefined;
}
export type MaxFailoverSlateConfigurationResults = number;
export interface ListFailoverSlateConfigurationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface FailoverSlateConfigurationSummary {
    arn: string;
    name?: string | undefined;
    activationThresholdSeconds?: number | undefined;
    minSlateDisplaySeconds?: number | undefined;
    maxSlateDisplaySeconds?: number | undefined;
    state: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type FailoverSlateConfigurationList = FailoverSlateConfigurationSummary[];
export interface ListFailoverSlateConfigurationsResponse {
    failoverSlateConfigurations: FailoverSlateConfigurationSummary[];
    nextToken?: string | undefined;
}
export type MaxPlaybackKeyPairResults = number;
export interface ListPlaybackKeyPairsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PlaybackKeyPairSummary {
    arn?: string | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PlaybackKeyPairList = PlaybackKeyPairSummary[];
export interface ListPlaybackKeyPairsResponse {
    keyPairs: PlaybackKeyPairSummary[];
    nextToken?: string | undefined;
}
export type MaxPlaybackRestrictionPolicyResults = number;
export interface ListPlaybackRestrictionPoliciesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PlaybackRestrictionPolicySummary {
    arn: string;
    allowedCountries: string[];
    allowedOrigins: string[];
    enableStrictOriginEnforcement?: boolean | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PlaybackRestrictionPolicyList = PlaybackRestrictionPolicySummary[];
export interface ListPlaybackRestrictionPoliciesResponse {
    playbackRestrictionPolicies: PlaybackRestrictionPolicySummary[];
    nextToken?: string | undefined;
}
export type MaxRecordingConfigurationResults = number;
export interface ListRecordingConfigurationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface RecordingConfigurationSummary {
    arn: string;
    name?: string | undefined;
    destinationConfiguration: DestinationConfiguration;
    state: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RecordingConfigurationList = RecordingConfigurationSummary[];
export interface ListRecordingConfigurationsResponse {
    recordingConfigurations: RecordingConfigurationSummary[];
    nextToken?: string | undefined;
}
export type MaxStreamKeyResults = number;
export interface ListStreamKeysRequest {
    channelArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface StreamKeySummary {
    arn?: string | undefined;
    channelArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StreamKeyList = StreamKeySummary[];
export interface ListStreamKeysResponse {
    streamKeys: StreamKeySummary[];
    nextToken?: string | undefined;
}
export interface StreamFilters {
    health?: string | undefined;
}
export type MaxStreamResults = number;
export interface ListStreamsRequest {
    filterBy?: StreamFilters | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface StreamSummary {
    channelArn?: string | undefined;
    streamId?: string | undefined;
    state?: string | undefined;
    health?: string | undefined;
    viewerCount?: number | undefined;
    startTime?: Date | undefined;
}
export type StreamList = StreamSummary[];
export interface ListStreamsResponse {
    streams: StreamSummary[];
    nextToken?: string | undefined;
}
export interface ListStreamSessionsRequest {
    channelArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface StreamSessionSummary {
    streamId?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    hasErrorEvent?: boolean | undefined;
}
export type StreamSessionList = StreamSessionSummary[];
export interface ListStreamSessionsResponse {
    streamSessions: StreamSessionSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export type StreamMetadata = string | redacted.Redacted<string>;
export interface PutMetadataRequest {
    channelArn: string;
    metadata: string | redacted.Redacted<string>;
}
export interface PutMetadataResponse {
}
export interface StartViewerSessionRevocationRequest {
    channelArn: string;
    viewerId: string;
    viewerSessionVersionsLessThanOrEqualTo?: number | undefined;
}
export interface StartViewerSessionRevocationResponse {
}
export interface StopStreamRequest {
    channelArn: string;
}
export interface StopStreamResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAdConfigurationRequest {
    arn: string;
    name?: string | undefined;
    mediaTailorPlaybackConfigurations?: MediaTailorPlaybackConfiguration[] | undefined;
    postRollConfiguration?: PostRollConfiguration | undefined;
}
export interface UpdateAdConfigurationResponse {
    adConfiguration: AdConfiguration;
}
export interface UpdateChannelRequest {
    arn: string;
    name?: string | undefined;
    latencyMode?: string | undefined;
    type?: ChannelType | undefined;
    authorized?: boolean | undefined;
    recordingConfigurationArn?: string | undefined;
    insecureIngest?: boolean | undefined;
    preset?: TranscodePreset | undefined;
    playbackRestrictionPolicyArn?: string | undefined;
    multitrackInputConfiguration?: MultitrackInputConfiguration | undefined;
    containerFormat?: string | undefined;
    adConfigurationArn?: string | undefined;
    failoverSlateConfigurationArn?: string | undefined;
}
export interface UpdateChannelResponse {
    channel?: Channel | undefined;
}
export interface UpdateFailoverSlateConfigurationRequest {
    arn: string;
    name?: string | undefined;
    activationThresholdSeconds?: number | undefined;
    minSlateDisplaySeconds?: number | undefined;
    maxSlateDisplaySeconds?: number | undefined;
}
export interface UpdateFailoverSlateConfigurationResponse {
    failoverSlateConfiguration: FailoverSlateConfiguration;
}
export interface UpdatePlaybackRestrictionPolicyRequest {
    arn: string;
    allowedCountries?: string[] | undefined;
    allowedOrigins?: string[] | undefined;
    enableStrictOriginEnforcement?: boolean | undefined;
    name?: string | undefined;
}
export interface UpdatePlaybackRestrictionPolicyResponse {
    playbackRestrictionPolicy?: PlaybackRestrictionPolicy | undefined;
}
export type BatchGetChannelError = AccessDeniedException | ServiceUnavailable | ValidationException | CommonErrors;
/**
 * Performs GetChannel on multiple ARNs simultaneously.
 */
export declare const batchGetChannel: API.OperationMethod<BatchGetChannelRequest & RegionInput, BatchGetChannelResponse, BatchGetChannelError, Credentials | HttpClient.HttpClient>;
export type BatchGetStreamKeyError = AccessDeniedException | ServiceUnavailable | ValidationException | CommonErrors;
/**
 * Performs GetStreamKey on multiple ARNs simultaneously.
 */
export declare const batchGetStreamKey: API.OperationMethod<BatchGetStreamKeyRequest & RegionInput, BatchGetStreamKeyResponse, BatchGetStreamKeyError, Credentials | HttpClient.HttpClient>;
export type BatchStartViewerSessionRevocationError = AccessDeniedException | PendingVerification | ThrottlingException | ValidationException | CommonErrors;
/**
 * Performs StartViewerSessionRevocation on multiple channel ARN and viewer ID pairs simultaneously.
 */
export declare const batchStartViewerSessionRevocation: API.OperationMethod<BatchStartViewerSessionRevocationRequest & RegionInput, BatchStartViewerSessionRevocationResponse, BatchStartViewerSessionRevocationError, Credentials | HttpClient.HttpClient>;
export type CreateAdConfigurationError = AccessDeniedException | ConflictException | InternalServerException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new ad configuration to be used for server-side ad insertion.
 */
export declare const createAdConfiguration: API.OperationMethod<CreateAdConfigurationRequest & RegionInput, CreateAdConfigurationResponse, CreateAdConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a new channel and an associated stream key to start streaming.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest & RegionInput, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateFailoverSlateConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new failover slate configuration.
 */
export declare const createFailoverSlateConfiguration: API.OperationMethod<CreateFailoverSlateConfigurationRequest & RegionInput, CreateFailoverSlateConfigurationResponse, CreateFailoverSlateConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreatePlaybackRestrictionPolicyError = AccessDeniedException | PendingVerification | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new playback restriction policy, for constraining playback by countries and/or origins.
 */
export declare const createPlaybackRestrictionPolicy: API.OperationMethod<CreatePlaybackRestrictionPolicyRequest & RegionInput, CreatePlaybackRestrictionPolicyResponse, CreatePlaybackRestrictionPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateRecordingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | PendingVerification | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a new recording configuration, used to enable recording to Amazon S3.
 *
 * **Known issue:** In the us-east-1 region, if you use the Amazon Web Services CLI to create a recording configuration, it returns success even if the S3 bucket is in a different region. In this case, the `state` of the recording configuration is `CREATE_FAILED` (instead of `ACTIVE`). (In other regions, the CLI correctly returns failure if the bucket is in a different region.)
 *
 * **Workaround:** Ensure that your S3 bucket is in the same region as the recording configuration. If you create a recording configuration in a different region as your S3 bucket, delete that recording configuration and create a new one with an S3 bucket from the correct region.
 */
export declare const createRecordingConfiguration: API.OperationMethod<CreateRecordingConfigurationRequest & RegionInput, CreateRecordingConfigurationResponse, CreateRecordingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateStreamKeyError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a stream key, used to initiate a stream, for the specified channel ARN.
 *
 * Note that CreateChannel creates a stream key. If you subsequently use CreateStreamKey on the same channel, it will fail because a stream key already exists and there is a limit of 1 stream key per channel. To reset the stream key on a channel, use DeleteStreamKey and then CreateStreamKey.
 */
export declare const createStreamKey: API.OperationMethod<CreateStreamKeyRequest & RegionInput, CreateStreamKeyResponse, CreateStreamKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteAdConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified ad configuration.
 */
export declare const deleteAdConfiguration: API.OperationMethod<DeleteAdConfigurationRequest & RegionInput, DeleteAdConfigurationResponse, DeleteAdConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified channel and its associated stream keys.
 *
 * If you try to delete a live channel, you will get an error (409 ConflictException). To delete a channel that is live, call StopStream, wait for the Amazon EventBridge "Stream End" event (to verify that the stream's state is no longer Live), then call DeleteChannel. (See Using EventBridge with Amazon IVS.)
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest & RegionInput, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteFailoverSlateConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified failover slate configuration.
 */
export declare const deleteFailoverSlateConfiguration: API.OperationMethod<DeleteFailoverSlateConfigurationRequest & RegionInput, DeleteFailoverSlateConfigurationResponse, DeleteFailoverSlateConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePlaybackKeyPairError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | InternalServerException | CommonErrors;
/**
 * Deletes a specified authorization key pair. This invalidates future viewer tokens generated using the key pair's `privateKey`. For more information, see Setting Up Private Channels in the *Amazon IVS User Guide*.
 */
export declare const deletePlaybackKeyPair: API.OperationMethod<DeletePlaybackKeyPairRequest & RegionInput, DeletePlaybackKeyPairResponse, DeletePlaybackKeyPairError, Credentials | HttpClient.HttpClient>;
export type DeletePlaybackRestrictionPolicyError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified playback restriction policy.
 */
export declare const deletePlaybackRestrictionPolicy: API.OperationMethod<DeletePlaybackRestrictionPolicyRequest & RegionInput, DeletePlaybackRestrictionPolicyResponse, DeletePlaybackRestrictionPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRecordingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the recording configuration for the specified ARN.
 *
 * If you try to delete a recording configuration that is associated with a channel, you will get an error (409 ConflictException). To avoid this, for all channels that reference the recording configuration, first use UpdateChannel to set the `recordingConfigurationArn` field to an empty string, then use DeleteRecordingConfiguration.
 */
export declare const deleteRecordingConfiguration: API.OperationMethod<DeleteRecordingConfigurationRequest & RegionInput, DeleteRecordingConfigurationResponse, DeleteRecordingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteStreamKeyError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the stream key for the specified ARN, so it can no longer be used to stream.
 */
export declare const deleteStreamKey: API.OperationMethod<DeleteStreamKeyRequest & RegionInput, DeleteStreamKeyResponse, DeleteStreamKeyError, Credentials | HttpClient.HttpClient>;
export type GetAdConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the ad configuration represented by the specified ARN.
 */
export declare const getAdConfiguration: API.OperationMethod<GetAdConfigurationRequest & RegionInput, GetAdConfigurationResponse, GetAdConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetChannelError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the channel configuration for the specified channel ARN. See also BatchGetChannel.
 */
export declare const getChannel: API.OperationMethod<GetChannelRequest & RegionInput, GetChannelResponse, GetChannelError, Credentials | HttpClient.HttpClient>;
export type GetFailoverSlateConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets the failover slate configuration for the specified ARN.
 */
export declare const getFailoverSlateConfiguration: API.OperationMethod<GetFailoverSlateConfigurationRequest & RegionInput, GetFailoverSlateConfigurationResponse, GetFailoverSlateConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetPlaybackKeyPairError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets a specified playback authorization key pair and returns the `arn` and `fingerprint`. The `privateKey` held by the caller can be used to generate viewer authorization tokens, to grant viewers access to private channels. For more information, see Setting Up Private Channels in the *Amazon IVS User Guide*.
 */
export declare const getPlaybackKeyPair: API.OperationMethod<GetPlaybackKeyPairRequest & RegionInput, GetPlaybackKeyPairResponse, GetPlaybackKeyPairError, Credentials | HttpClient.HttpClient>;
export type GetPlaybackRestrictionPolicyError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the specified playback restriction policy.
 */
export declare const getPlaybackRestrictionPolicy: API.OperationMethod<GetPlaybackRestrictionPolicyRequest & RegionInput, GetPlaybackRestrictionPolicyResponse, GetPlaybackRestrictionPolicyError, Credentials | HttpClient.HttpClient>;
export type GetRecordingConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the recording configuration for the specified ARN.
 */
export declare const getRecordingConfiguration: API.OperationMethod<GetRecordingConfigurationRequest & RegionInput, GetRecordingConfigurationResponse, GetRecordingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetStreamError = AccessDeniedException | ChannelNotBroadcasting | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets information about the active (live) stream on a specified channel.
 */
export declare const getStream: API.OperationMethod<GetStreamRequest & RegionInput, GetStreamResponse, GetStreamError, Credentials | HttpClient.HttpClient>;
export type GetStreamKeyError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets stream-key information for a specified ARN.
 */
export declare const getStreamKey: API.OperationMethod<GetStreamKeyRequest & RegionInput, GetStreamKeyResponse, GetStreamKeyError, Credentials | HttpClient.HttpClient>;
export type GetStreamSessionError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets metadata on a specified stream.
 */
export declare const getStreamSession: API.OperationMethod<GetStreamSessionRequest & RegionInput, GetStreamSessionResponse, GetStreamSessionError, Credentials | HttpClient.HttpClient>;
export type ImportPlaybackKeyPairError = AccessDeniedException | ConflictException | PendingVerification | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Imports the public portion of a new key pair and returns its `arn` and `fingerprint`. The `privateKey` can then be used to generate viewer authorization tokens, to grant viewers access to private channels. For more information, see Setting Up Private Channels in the *Amazon IVS User Guide*.
 */
export declare const importPlaybackKeyPair: API.OperationMethod<ImportPlaybackKeyPairRequest & RegionInput, ImportPlaybackKeyPairResponse, ImportPlaybackKeyPairError, Credentials | HttpClient.HttpClient>;
export type InsertAdBreakError = AccessDeniedException | ChannelNotBroadcasting | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Inserts an ad marker in the playlist for the specified channel and duration using the ad configuration associated with the channel.
 *
 * **Note:** AWS Elemental MediaTailor (EMT), the service that handles ad requests, provides CloudWatch metrics to help you monitor the success or failure of each InsertAdBreak operation. See Monitoring AWS Elemental MediaTailor with Amazon CloudWatch metrics in the *AWS Elemental MediaTailor User Guide* for details on available metrics.
 */
export declare const insertAdBreak: API.OperationMethod<InsertAdBreakRequest & RegionInput, InsertAdBreakResponse, InsertAdBreakError, Credentials | HttpClient.HttpClient>;
export type ListAdConfigurationsError = AccessDeniedException | InternalServerException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all ad configurations in your account, in the AWS region where the API request is processed.
 */
export declare const listAdConfigurations: API.PaginatedOperationMethod<ListAdConfigurationsRequest & RegionInput, ListAdConfigurationsResponse, ListAdConfigurationsError, Credentials | HttpClient.HttpClient, AdConfigurationSummary>;
export type ListChannelsError = AccessDeniedException | ConflictException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all channels in your account, in the Amazon Web Services region where the API request is processed. This list can be filtered to match a specified name or recording-configuration ARN. Filters are mutually exclusive and cannot be used together. If you try to use both filters, you will get an error (409 ConflictException).
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest & RegionInput, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFailoverSlateConfigurationsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Gets summary information about all failover slate configurations in your account, in the Amazon Web Services region where the API request is processed.
 */
export declare const listFailoverSlateConfigurations: API.PaginatedOperationMethod<ListFailoverSlateConfigurationsRequest & RegionInput, ListFailoverSlateConfigurationsResponse, ListFailoverSlateConfigurationsError, Credentials | HttpClient.HttpClient, FailoverSlateConfigurationSummary>;
export type ListPlaybackKeyPairsError = AccessDeniedException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about playback key pairs. For more information, see Setting Up Private Channels in the *Amazon IVS User Guide*.
 */
export declare const listPlaybackKeyPairs: API.PaginatedOperationMethod<ListPlaybackKeyPairsRequest & RegionInput, ListPlaybackKeyPairsResponse, ListPlaybackKeyPairsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPlaybackRestrictionPoliciesError = AccessDeniedException | ConflictException | PendingVerification | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about playback restriction policies.
 */
export declare const listPlaybackRestrictionPolicies: API.PaginatedOperationMethod<ListPlaybackRestrictionPoliciesRequest & RegionInput, ListPlaybackRestrictionPoliciesResponse, ListPlaybackRestrictionPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRecordingConfigurationsError = AccessDeniedException | InternalServerException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all recording configurations in your account, in the Amazon Web Services region where the API request is processed.
 */
export declare const listRecordingConfigurations: API.PaginatedOperationMethod<ListRecordingConfigurationsRequest & RegionInput, ListRecordingConfigurationsResponse, ListRecordingConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStreamKeysError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about stream keys for the specified channel.
 */
export declare const listStreamKeys: API.PaginatedOperationMethod<ListStreamKeysRequest & RegionInput, ListStreamKeysResponse, ListStreamKeysError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStreamsError = AccessDeniedException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about live streams in your account, in the Amazon Web Services region where the API request is processed.
 */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsRequest & RegionInput, ListStreamsResponse, ListStreamsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStreamSessionsError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets a summary of current and previous streams for a specified channel in your account, in the AWS region where the API request is processed.
 */
export declare const listStreamSessions: API.PaginatedOperationMethod<ListStreamSessionsRequest & RegionInput, ListStreamSessionsResponse, ListStreamSessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets information about Amazon Web Services tags for the specified ARN.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutMetadataError = AccessDeniedException | ChannelNotBroadcasting | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Inserts metadata into the active stream of the specified channel. At most 5 requests per second per channel are allowed, each with a maximum 1 KB payload. (If 5 TPS is not sufficient for your needs, we recommend batching your data into a single PutMetadata call.) At most 155 requests per second per account are allowed. Also see Embedding Metadata within a Video Stream in the *Amazon IVS User Guide*.
 */
export declare const putMetadata: API.OperationMethod<PutMetadataRequest & RegionInput, PutMetadataResponse, PutMetadataError, Credentials | HttpClient.HttpClient>;
export type StartViewerSessionRevocationError = AccessDeniedException | InternalServerException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the process of revoking the viewer session associated with a specified channel ARN and viewer ID. Optionally, you can provide a version to revoke viewer sessions less than and including that version. For instructions on associating a viewer ID with a viewer session, see Setting Up Private Channels.
 */
export declare const startViewerSessionRevocation: API.OperationMethod<StartViewerSessionRevocationRequest & RegionInput, StartViewerSessionRevocationResponse, StartViewerSessionRevocationError, Credentials | HttpClient.HttpClient>;
export type StopStreamError = AccessDeniedException | ChannelNotBroadcasting | ResourceNotFoundException | StreamUnavailable | ValidationException | ThrottlingException | CommonErrors;
/**
 * Disconnects the incoming RTMPS stream for the specified channel. Can be used in conjunction with DeleteStreamKey to prevent further streaming to a channel.
 *
 * Many streaming client-software libraries automatically reconnect a dropped RTMPS session, so to stop the stream permanently, you may want to first revoke the `streamKey` attached to the channel.
 */
export declare const stopStream: API.OperationMethod<StopStreamRequest & RegionInput, StopStreamResponse, StopStreamError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Adds or updates tags for the Amazon Web Services resource with the specified ARN.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Removes tags from the resource with the specified ARN.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAdConfigurationError = AccessDeniedException | ConflictException | InternalServerException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a specified ad configuration.
 */
export declare const updateAdConfiguration: API.OperationMethod<UpdateAdConfigurationRequest & RegionInput, UpdateAdConfigurationResponse, UpdateAdConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a channel's configuration. Live channels cannot be updated. You must stop the ongoing stream, update the channel, and restart the stream for the changes to take effect.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest & RegionInput, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateFailoverSlateConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a specified failover slate configuration.
 */
export declare const updateFailoverSlateConfiguration: API.OperationMethod<UpdateFailoverSlateConfigurationRequest & RegionInput, UpdateFailoverSlateConfigurationResponse, UpdateFailoverSlateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePlaybackRestrictionPolicyError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a specified playback restriction policy.
 */
export declare const updatePlaybackRestrictionPolicy: API.OperationMethod<UpdatePlaybackRestrictionPolicyRequest & RegionInput, UpdatePlaybackRestrictionPolicyResponse, UpdatePlaybackRestrictionPolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ivs.d.ts.map