/**
 * A typed Effect `RpcClient` over a Durable Object namespace whose stubs
 * expose an Effect `fetch` — the client half of `RpcDurableObject`, shared
 * by every engine.
 *
 * @internal
 */
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { RpcClient, RpcSerialization, type Rpc, type RpcGroup } from "effect/rpc";
import type * as RpcClientError from "effect/rpc/RpcClientError";
export declare const bindEffectRpc: <Rpcs extends Rpc.Any>(namespace: {
    readonly getByName: (id: string, options?: any) => {
        readonly fetch: any;
    };
}, group: RpcGroup.RpcGroup<Rpcs>, options?: {
    /**
     * Override the rpc serialization layer. Defaults to NDJSON, which
     * is required when any rpc in the group is a streaming rpc.
     */
    readonly serialization?: Layer.Layer<RpcSerialization.RpcSerialization>;
}) => {
    readonly getByName: (id: string, options?: any) => Effect.Effect<RpcClient.RpcClient<Rpcs, RpcClientError.RpcClientError>, never, Rpc.MiddlewareClient<Rpcs>>;
};
//# sourceMappingURL=EffectRpc.d.ts.map