import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AiGatewaySpendingLimitDeprecated_base: S.TaggedErrorClass<"AiGatewaySpendingLimitDeprecated", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class AiGatewaySpendingLimitDeprecated extends /*@__PURE__*/ AiGatewaySpendingLimitDeprecated_base {
}
declare const DatasetNameAlreadyExists_base: S.TaggedErrorClass<"DatasetNameAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class DatasetNameAlreadyExists extends /*@__PURE__*/ DatasetNameAlreadyExists_base {
}
declare const DatasetNotFound_base: S.TaggedErrorClass<"DatasetNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class DatasetNotFound extends /*@__PURE__*/ DatasetNotFound_base {
}
declare const EvaluationNameAlreadyExists_base: S.TaggedErrorClass<"EvaluationNameAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class EvaluationNameAlreadyExists extends /*@__PURE__*/ EvaluationNameAlreadyExists_base {
}
declare const EvaluationNotFound_base: S.TaggedErrorClass<"EvaluationNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class EvaluationNotFound extends /*@__PURE__*/ EvaluationNotFound_base {
}
declare const GatewayAlreadyExists_base: S.TaggedErrorClass<"GatewayAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class GatewayAlreadyExists extends /*@__PURE__*/ GatewayAlreadyExists_base {
}
declare const GatewayAuthenticationRequired_base: S.TaggedErrorClass<"GatewayAuthenticationRequired", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class GatewayAuthenticationRequired extends /*@__PURE__*/ GatewayAuthenticationRequired_base {
}
declare const GatewayNotFound_base: S.TaggedErrorClass<"GatewayNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class GatewayNotFound extends /*@__PURE__*/ GatewayNotFound_base {
}
declare const NoManualTopup_base: S.TaggedErrorClass<"NoManualTopup", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NoManualTopup extends /*@__PURE__*/ NoManualTopup_base {
}
declare const ProviderConfigAlreadyExists_base: S.TaggedErrorClass<"ProviderConfigAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ProviderConfigAlreadyExists extends /*@__PURE__*/ ProviderConfigAlreadyExists_base {
}
declare const ProviderConfigNotFound_base: S.TaggedErrorClass<"ProviderConfigNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ProviderConfigNotFound extends /*@__PURE__*/ ProviderConfigNotFound_base {
}
declare const ProviderConfigSecretNotFound_base: S.TaggedErrorClass<"ProviderConfigSecretNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ProviderConfigSecretNotFound extends /*@__PURE__*/ ProviderConfigSecretNotFound_base {
}
declare const RouteAlreadyExists_base: S.TaggedErrorClass<"RouteAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class RouteAlreadyExists extends /*@__PURE__*/ RouteAlreadyExists_base {
}
declare const RouteNotFound_base: S.TaggedErrorClass<"RouteNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class RouteNotFound extends /*@__PURE__*/ RouteNotFound_base {
}
export type CreateRequestDlpCase0Action = "BLOCK" | "FLAG";
export type CreateRequestDlpCase0ProfilesList = Array<string>;
export interface CreateRequestDlpCase0 {
    action: CreateRequestDlpCase0Action | (string & {});
    enabled: boolean;
    profiles: CreateRequestDlpCase0ProfilesList;
}
export type CreateRequestDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export type CreateRequestDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export type CreateRequestDlpCase1PoliciesItemCheckList = Array<CreateRequestDlpCase1PoliciesItemCheckItem | (string & {})>;
export type CreateRequestDlpCase1PoliciesItemProfilesList = Array<string>;
export interface CreateRequestDlpCase1PoliciesItem {
    id: string;
    action: CreateRequestDlpCase1PoliciesItemAction | (string & {});
    check: CreateRequestDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: CreateRequestDlpCase1PoliciesItemProfilesList;
}
export type CreateRequestDlpCase1PoliciesList = Array<CreateRequestDlpCase1PoliciesItem>;
export interface CreateRequestDlpCase1 {
    enabled: boolean;
    policies: CreateRequestDlpCase1PoliciesList;
}
export type CreateRequestDlp = CreateRequestDlpCase0 | CreateRequestDlpCase1;
export type CreateRequestGuardrailsPromptP1 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS1 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS10 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS11 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS12 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS13 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS14 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS2 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS3 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS4 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS5 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS6 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS7 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS8 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsPromptS9 = "FLAG" | "BLOCK";
export interface CreateRequestGuardrailsPrompt {
    p1?: CreateRequestGuardrailsPromptP1 | (string & {}) | undefined;
    s1?: CreateRequestGuardrailsPromptS1 | (string & {}) | undefined;
    s10?: CreateRequestGuardrailsPromptS10 | (string & {}) | undefined;
    s11?: CreateRequestGuardrailsPromptS11 | (string & {}) | undefined;
    s12?: CreateRequestGuardrailsPromptS12 | (string & {}) | undefined;
    s13?: CreateRequestGuardrailsPromptS13 | (string & {}) | undefined;
    s14?: CreateRequestGuardrailsPromptS14 | (string & {}) | undefined;
    s2?: CreateRequestGuardrailsPromptS2 | (string & {}) | undefined;
    s3?: CreateRequestGuardrailsPromptS3 | (string & {}) | undefined;
    s4?: CreateRequestGuardrailsPromptS4 | (string & {}) | undefined;
    s5?: CreateRequestGuardrailsPromptS5 | (string & {}) | undefined;
    s6?: CreateRequestGuardrailsPromptS6 | (string & {}) | undefined;
    s7?: CreateRequestGuardrailsPromptS7 | (string & {}) | undefined;
    s8?: CreateRequestGuardrailsPromptS8 | (string & {}) | undefined;
    s9?: CreateRequestGuardrailsPromptS9 | (string & {}) | undefined;
}
export type CreateRequestGuardrailsResponseP1 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS1 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS10 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS11 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS12 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS13 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS14 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS2 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS3 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS4 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS5 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS6 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS7 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS8 = "FLAG" | "BLOCK";
export type CreateRequestGuardrailsResponseS9 = "FLAG" | "BLOCK";
export interface CreateRequestGuardrailsResponse {
    p1?: CreateRequestGuardrailsResponseP1 | (string & {}) | undefined;
    s1?: CreateRequestGuardrailsResponseS1 | (string & {}) | undefined;
    s10?: CreateRequestGuardrailsResponseS10 | (string & {}) | undefined;
    s11?: CreateRequestGuardrailsResponseS11 | (string & {}) | undefined;
    s12?: CreateRequestGuardrailsResponseS12 | (string & {}) | undefined;
    s13?: CreateRequestGuardrailsResponseS13 | (string & {}) | undefined;
    s14?: CreateRequestGuardrailsResponseS14 | (string & {}) | undefined;
    s2?: CreateRequestGuardrailsResponseS2 | (string & {}) | undefined;
    s3?: CreateRequestGuardrailsResponseS3 | (string & {}) | undefined;
    s4?: CreateRequestGuardrailsResponseS4 | (string & {}) | undefined;
    s5?: CreateRequestGuardrailsResponseS5 | (string & {}) | undefined;
    s6?: CreateRequestGuardrailsResponseS6 | (string & {}) | undefined;
    s7?: CreateRequestGuardrailsResponseS7 | (string & {}) | undefined;
    s8?: CreateRequestGuardrailsResponseS8 | (string & {}) | undefined;
    s9?: CreateRequestGuardrailsResponseS9 | (string & {}) | undefined;
}
export interface CreateRequestGuardrails {
    prompt: CreateRequestGuardrailsPrompt;
    response: CreateRequestGuardrailsResponse;
}
export type CreateRequestLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export type CreateRequestOtelItemHeadersMap = {
    [key: string]: string | undefined;
};
export type CreateRequestOtelItemContentType = "json" | "protobuf";
export interface CreateRequestOtelItem {
    headers: CreateRequestOtelItemHeadersMap;
    url: string;
    authorization?: string | undefined;
    contentType?: CreateRequestOtelItemContentType | (string & {}) | undefined;
}
export type CreateRequestOtelList = Array<CreateRequestOtelItem>;
export type CreateRequestRateLimitingTechnique = "fixed" | "sliding";
export type CreateRequestRetryBackoff = "constant" | "linear" | "exponential";
export type CreateRequestSpendLimitsRulesItemLimitType = "cost";
export type CreateRequestSpendLimitsRulesItemMetadataValueModeMode = "partition";
export interface CreateRequestSpendLimitsRulesItemMetadataValueMode {
    mode: CreateRequestSpendLimitsRulesItemMetadataValueModeMode;
}
export type CreateRequestSpendLimitsRulesItemMetadataValueCase1Mode = "filter";
export type CreateRequestSpendLimitsRulesItemMetadataValueCase1ValuesList = Array<string>;
export interface CreateRequestSpendLimitsRulesItemMetadataValueCase1 {
    mode: CreateRequestSpendLimitsRulesItemMetadataValueCase1Mode;
    values: CreateRequestSpendLimitsRulesItemMetadataValueCase1ValuesList;
}
export type CreateRequestSpendLimitsRulesItemMetadataValue = CreateRequestSpendLimitsRulesItemMetadataValueMode | CreateRequestSpendLimitsRulesItemMetadataValueCase1;
export type CreateRequestSpendLimitsRulesItemMetadataMap = {
    [key: string]: CreateRequestSpendLimitsRulesItemMetadataValue | undefined;
};
export type CreateRequestSpendLimitsRulesItemModelMode = "filter";
export type CreateRequestSpendLimitsRulesItemModelValuesList = Array<string>;
export interface CreateRequestSpendLimitsRulesItemModel {
    mode: CreateRequestSpendLimitsRulesItemModelMode | (string & {});
    values: CreateRequestSpendLimitsRulesItemModelValuesList;
}
export type CreateRequestSpendLimitsRulesItemProviderMode = "filter";
export type CreateRequestSpendLimitsRulesItemProviderValuesList = Array<string>;
export interface CreateRequestSpendLimitsRulesItemProvider {
    mode: CreateRequestSpendLimitsRulesItemProviderMode | (string & {});
    values: CreateRequestSpendLimitsRulesItemProviderValuesList;
}
export type CreateRequestSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export interface CreateRequestSpendLimitsRulesItem {
    /** exclusiveMinimum */
    limit: number;
    limitType: CreateRequestSpendLimitsRulesItemLimitType | (string & {});
    /** exclusiveMinimum */
    window: number;
    id?: string | undefined;
    enabled?: boolean | undefined;
    metadata?: CreateRequestSpendLimitsRulesItemMetadataMap | undefined;
    model?: CreateRequestSpendLimitsRulesItemModel | undefined;
    provider?: CreateRequestSpendLimitsRulesItemProvider | undefined;
    technique?: CreateRequestSpendLimitsRulesItemTechnique | (string & {}) | undefined;
}
export type CreateRequestSpendLimitsRulesList = Array<CreateRequestSpendLimitsRulesItem>;
export interface CreateRequestSpendLimits {
    enabled?: boolean | undefined;
    rules?: CreateRequestSpendLimitsRulesList | undefined;
}
export interface CreateRequestStripeUsageEventsItem {
    payload: string;
}
export type CreateRequestStripeUsageEventsList = Array<CreateRequestStripeUsageEventsItem>;
export interface CreateRequestStripe {
    authorization: string;
    usageEvents: CreateRequestStripeUsageEventsList;
}
export type CreateRequestWorkersAiBillingMode = "postpaid" | "unified";
export interface CreateAiGatewayRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number | null;
    collectLogs: boolean;
    rateLimitingInterval: number | null;
    rateLimitingLimit: number | null;
    /** Require authentication for gateway access. New gateways must have authentication enabled. Once enabled, authentication cannot be disabled. */
    authentication?: boolean | undefined;
    /** Requires customer-provided provider credentials and prevents fallback to Unified Billing. */
    byokOnly?: boolean | undefined;
    dlp?: CreateRequestDlp | undefined;
    guardrails?: CreateRequestGuardrails | undefined;
    logClassification?: boolean | undefined;
    logManagement?: number | undefined;
    logManagementStrategy?: CreateRequestLogManagementStrategy | (string & {}) | undefined;
    logpush?: boolean | undefined;
    logpushPublicKey?: string | undefined;
    otel?: CreateRequestOtelList | undefined;
    rateLimitingTechnique?: CreateRequestRateLimitingTechnique | (string & {}) | undefined;
    /** Backoff strategy for retry delays */
    retryBackoff?: CreateRequestRetryBackoff | (string & {}) | undefined;
    /** Delay between retry attempts in milliseconds (0-60000) */
    retryDelay?: number | undefined;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | undefined;
    spendLimits?: CreateRequestSpendLimits | undefined;
    /** Secrets Store used by this gateway. Omit on update to keep the current store. Cannot be cleared while stored keys or secret references depend on it. */
    storeId?: string | undefined;
    stripe?: CreateRequestStripe | undefined;
    /** Controls how Workers AI inference calls routed through this gateway are billed. 'postpaid' bills the account directly through Workers AI; 'unified' deducts credits via AI Gateway using neuron-based pricing and delegates billing to AI Gateway. */
    workersAiBillingMode?: CreateRequestWorkersAiBillingMode | (string & {}) | undefined;
    zdr?: boolean | undefined;
}
export type CreateResponseDlpCase0Action = "BLOCK" | "FLAG";
export type CreateResponseDlpCase0ProfilesList = Array<string>;
export interface CreateResponseDlpCase0 {
    action: CreateResponseDlpCase0Action;
    enabled: boolean;
    profiles: CreateResponseDlpCase0ProfilesList;
}
export type CreateResponseDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export type CreateResponseDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export type CreateResponseDlpCase1PoliciesItemCheckList = Array<CreateResponseDlpCase1PoliciesItemCheckItem>;
export type CreateResponseDlpCase1PoliciesItemProfilesList = Array<string>;
export interface CreateResponseDlpCase1PoliciesItem {
    id: string;
    action: CreateResponseDlpCase1PoliciesItemAction;
    check: CreateResponseDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: CreateResponseDlpCase1PoliciesItemProfilesList;
}
export type CreateResponseDlpCase1PoliciesList = Array<CreateResponseDlpCase1PoliciesItem>;
export interface CreateResponseDlpCase1 {
    enabled: boolean;
    policies: CreateResponseDlpCase1PoliciesList;
}
export type CreateResponseDlp = CreateResponseDlpCase0 | CreateResponseDlpCase1;
export type CreateResponseFedrampLevel = "fedramp-medium" | "fedramp-high";
export type CreateResponseFedrampMode = "prefer" | "require";
export type CreateResponseGuardrailsPromptP1 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS1 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS10 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS11 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS12 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS13 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS14 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS2 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS3 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS4 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS5 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS6 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS7 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS8 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsPromptS9 = "FLAG" | "BLOCK";
export interface CreateResponseGuardrailsPrompt {
    p1?: CreateResponseGuardrailsPromptP1 | null | undefined;
    s1?: CreateResponseGuardrailsPromptS1 | null | undefined;
    s10?: CreateResponseGuardrailsPromptS10 | null | undefined;
    s11?: CreateResponseGuardrailsPromptS11 | null | undefined;
    s12?: CreateResponseGuardrailsPromptS12 | null | undefined;
    s13?: CreateResponseGuardrailsPromptS13 | null | undefined;
    s14?: CreateResponseGuardrailsPromptS14 | null | undefined;
    s2?: CreateResponseGuardrailsPromptS2 | null | undefined;
    s3?: CreateResponseGuardrailsPromptS3 | null | undefined;
    s4?: CreateResponseGuardrailsPromptS4 | null | undefined;
    s5?: CreateResponseGuardrailsPromptS5 | null | undefined;
    s6?: CreateResponseGuardrailsPromptS6 | null | undefined;
    s7?: CreateResponseGuardrailsPromptS7 | null | undefined;
    s8?: CreateResponseGuardrailsPromptS8 | null | undefined;
    s9?: CreateResponseGuardrailsPromptS9 | null | undefined;
}
export type CreateResponseGuardrailsResponseP1 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS1 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS10 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS11 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS12 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS13 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS14 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS2 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS3 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS4 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS5 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS6 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS7 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS8 = "FLAG" | "BLOCK";
export type CreateResponseGuardrailsResponseS9 = "FLAG" | "BLOCK";
export interface CreateResponseGuardrailsResponse {
    p1?: CreateResponseGuardrailsResponseP1 | null | undefined;
    s1?: CreateResponseGuardrailsResponseS1 | null | undefined;
    s10?: CreateResponseGuardrailsResponseS10 | null | undefined;
    s11?: CreateResponseGuardrailsResponseS11 | null | undefined;
    s12?: CreateResponseGuardrailsResponseS12 | null | undefined;
    s13?: CreateResponseGuardrailsResponseS13 | null | undefined;
    s14?: CreateResponseGuardrailsResponseS14 | null | undefined;
    s2?: CreateResponseGuardrailsResponseS2 | null | undefined;
    s3?: CreateResponseGuardrailsResponseS3 | null | undefined;
    s4?: CreateResponseGuardrailsResponseS4 | null | undefined;
    s5?: CreateResponseGuardrailsResponseS5 | null | undefined;
    s6?: CreateResponseGuardrailsResponseS6 | null | undefined;
    s7?: CreateResponseGuardrailsResponseS7 | null | undefined;
    s8?: CreateResponseGuardrailsResponseS8 | null | undefined;
    s9?: CreateResponseGuardrailsResponseS9 | null | undefined;
}
export interface CreateResponseGuardrails {
    prompt: CreateResponseGuardrailsPrompt;
    response: CreateResponseGuardrailsResponse;
}
export type CreateResponseLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export type CreateResponseOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export type CreateResponseOtelItemContentType = "json" | "protobuf";
export interface CreateResponseOtelItem {
    headers: CreateResponseOtelItemHeadersMap;
    url: string;
    authorization?: string | null | undefined;
    contentType?: CreateResponseOtelItemContentType | null | undefined;
}
export type CreateResponseOtelList = Array<CreateResponseOtelItem>;
export type CreateResponseRateLimitingTechnique = "fixed" | "sliding";
export type CreateResponseRetryBackoff = "constant" | "linear" | "exponential";
export type CreateResponseSpendLimitsRulesItemLimitType = "cost";
export type UntypedMetadataMap = {
    [key: string]: unknown | undefined;
};
export type CreateResponseSpendLimitsRulesItemModelMode = "filter";
export type CreateResponseSpendLimitsRulesItemModelValuesList = Array<string>;
export interface CreateResponseSpendLimitsRulesItemModel {
    mode: CreateResponseSpendLimitsRulesItemModelMode;
    values: CreateResponseSpendLimitsRulesItemModelValuesList;
}
export type CreateResponseSpendLimitsRulesItemProviderMode = "filter";
export type CreateResponseSpendLimitsRulesItemProviderValuesList = Array<string>;
export interface CreateResponseSpendLimitsRulesItemProvider {
    mode: CreateResponseSpendLimitsRulesItemProviderMode;
    values: CreateResponseSpendLimitsRulesItemProviderValuesList;
}
export type CreateResponseSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export interface CreateResponseSpendLimitsRulesItem {
    /** exclusiveMinimum */
    limit: number;
    limitType: CreateResponseSpendLimitsRulesItemLimitType;
    /** exclusiveMinimum */
    window: number;
    id?: string | null | undefined;
    enabled?: boolean | null | undefined;
    metadata?: UntypedMetadataMap | null | undefined;
    model?: CreateResponseSpendLimitsRulesItemModel | null | undefined;
    provider?: CreateResponseSpendLimitsRulesItemProvider | null | undefined;
    technique?: CreateResponseSpendLimitsRulesItemTechnique | null | undefined;
}
export type CreateResponseSpendLimitsRulesList = Array<CreateResponseSpendLimitsRulesItem>;
export interface CreateResponseSpendLimits {
    enabled?: boolean | null | undefined;
    rules?: CreateResponseSpendLimitsRulesList | null | undefined;
}
export type CreateResponseStripeUsageEventsItem = CreateRequestStripeUsageEventsItem;
export type CreateResponseStripeUsageEventsList = Array<CreateRequestStripeUsageEventsItem>;
export interface CreateResponseStripe {
    authorization: string;
    usageEvents: CreateResponseStripeUsageEventsList;
}
export type CreateResponseWorkersAiBillingMode = "postpaid" | "unified";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAiGatewayResponse {
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    /** Require authentication for gateway access. New gateways must have authentication enabled. Once enabled, authentication cannot be disabled. */
    authentication?: boolean | null | undefined;
    /** Requires customer-provided provider credentials and prevents fallback to Unified Billing. */
    byokOnly?: boolean | null | undefined;
    dlp?: CreateResponseDlp | null | undefined;
    /** FedRAMP compliance level: fedramp-medium or fedramp-high. */
    fedrampLevel?: CreateResponseFedrampLevel | null | undefined;
    /** FedRAMP enforcement mode. "prefer" prioritizes compliant connectors but allows fallback. "require" strictly filters. */
    fedrampMode?: CreateResponseFedrampMode | null | undefined;
    guardrails?: CreateResponseGuardrails | null | undefined;
    isDefault?: boolean | null | undefined;
    logClassification?: boolean | null | undefined;
    logManagement?: number | null | undefined;
    logManagementStrategy?: CreateResponseLogManagementStrategy | null | undefined;
    logpush?: boolean | null | undefined;
    logpushPublicKey?: string | null | undefined;
    otel?: CreateResponseOtelList | null | undefined;
    rateLimitingTechnique?: CreateResponseRateLimitingTechnique | null | undefined;
    /** Backoff strategy for retry delays */
    retryBackoff?: CreateResponseRetryBackoff | null | undefined;
    /** Delay between retry attempts in milliseconds (0-60000) */
    retryDelay?: number | null | undefined;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null | undefined;
    spendLimits?: CreateResponseSpendLimits | null | undefined;
    /** Secrets Store used by this gateway. Omit on update to keep the current store. Cannot be cleared while stored keys or secret references depend on it. */
    storeId?: string | null | undefined;
    stripe?: CreateResponseStripe | null | undefined;
    /** Controls how Workers AI inference calls routed through this gateway are billed. 'postpaid' bills the account directly through Workers AI; 'unified' deducts credits via AI Gateway using neuron-based pricing and delegates billing to AI Gateway. */
    workersAiBillingMode?: CreateResponseWorkersAiBillingMode | null | undefined;
    zdr?: boolean | null | undefined;
}
export type BillingSpendingLimitCreateRequestDuration = "daily" | "weekly" | "monthly";
export type BillingSpendingLimitCreateRequestStrategy = "fixed" | "sliding";
export interface CreateBillingSpendingLimitRequest {
    accountId: string;
    /** Spending limit amount in cents (min 100). */
    amount: number;
    /** Spending limit duration. */
    duration: BillingSpendingLimitCreateRequestDuration | (string & {});
    /** Spending limit strategy. */
    strategy: BillingSpendingLimitCreateRequestStrategy | (string & {});
}
export type CreateBillingSpendingLimitResponse = unknown;
export interface CreateBillingTopupRequest {
    accountId: string;
    /** Top-up amount in cents (min 1000). */
    amount: number;
    /** Payment method to charge instead of the customer's default payment method. */
    paymentMethodId?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBillingTopupResponse {
    /** Client secret used to complete payment authentication. */
    clientSecret: string;
    /** Whether the user was already onboarded. */
    onboarding: boolean;
    /** Top-up payment identifier. */
    paymentIntentId: string;
    /** Card brand (visa, mastercard, etc.). */
    brand?: string | null | undefined;
    /** Last 4 digits of card. */
    last4?: string | null | undefined;
}
export interface CreateBillingTopupConfigRequest {
    accountId: string;
    /** Auto top-up amount in cents (min 1000). */
    amount: number;
    /** Balance threshold in cents that triggers auto top-up (min 500). */
    threshold: number;
    /** Version of the off-session auto-top-up consent accepted by the user. */
    consentVersion?: string | undefined;
    /** Card to authenticate for future automatic top-ups. */
    paymentMethodId?: string | undefined;
    /** Client-generated UUID that makes payment-method setup safe to retry. */
    setupIdempotencyKey?: string | undefined;
    /** Successfully confirmed payment-method setup identifier. */
    setupIntentId?: string | undefined;
}
export interface BillingTopupConfigCreateResultCase0 {
    amount: number;
    threshold: number;
}
export type BillingTopupConfigCreateResultCase1Status = "configured";
export interface BillingTopupConfigCreateResultCase1 {
    amount: number;
    status: BillingTopupConfigCreateResultCase1Status;
    threshold: number;
}
export type BillingTopupConfigCreateResultCase2Status = "requires_action";
export interface BillingTopupConfigCreateResultCase2 {
    amount: number;
    clientSecret: string;
    setupIntentId: string;
    status: BillingTopupConfigCreateResultCase2Status;
    threshold: number;
}
export type BillingTopupConfigCreateResult = BillingTopupConfigCreateResultCase0 | BillingTopupConfigCreateResultCase1 | BillingTopupConfigCreateResultCase2;
export type CreateBillingTopupConfigResponse = BillingTopupConfigCreateResult;
export interface CreateCustomProviderRequest {
    accountId: string;
    baseUrl: string;
    name: string;
    slug: string;
    beta?: boolean | undefined;
    curlExample?: string | undefined;
    description?: string | undefined;
    enable?: boolean | undefined;
    /** JSON object of extra HTTP headers that AI Gateway sends to the provider. Values can contain credentials. */
    headers?: string | undefined;
    jsExample?: string | undefined;
    link?: string | undefined;
    position?: number | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCustomProviderResponse {
    id: string;
    baseUrl: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    slug: string;
    beta?: boolean | null | undefined;
    curlExample?: string | null | undefined;
    description?: string | null | undefined;
    enable?: boolean | null | undefined;
    /** JSON object of extra HTTP headers that AI Gateway sends to the provider. Values can contain credentials. */
    headers?: string | null | undefined;
    jsExample?: string | null | undefined;
    link?: string | null | undefined;
    logo?: string | null | undefined;
    position?: number | null | undefined;
}
export type DatasetsCreateRequestFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type DatasetsCreateRequestFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type DatasetsCreateRequestFiltersItemValueItem = string | number | boolean;
export type DatasetsCreateRequestFiltersItemValueList = Array<DatasetsCreateRequestFiltersItemValueItem>;
export interface DatasetsCreateRequestFiltersItem {
    key: DatasetsCreateRequestFiltersItemKey | (string & {});
    operator: DatasetsCreateRequestFiltersItemOperator | (string & {});
    value: DatasetsCreateRequestFiltersItemValueList;
}
export type DatasetsCreateRequestFiltersList = Array<DatasetsCreateRequestFiltersItem>;
export interface CreateDatasetRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    enable: boolean;
    filters: DatasetsCreateRequestFiltersList;
    name: string;
}
export type DatasetsCreateResponseFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type DatasetsCreateResponseFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type DatasetsCreateResponseFiltersItemValueItem = string | number | boolean;
export type DatasetsCreateResponseFiltersItemValueList = Array<DatasetsCreateResponseFiltersItemValueItem>;
export interface DatasetsCreateResponseFiltersItem {
    key: DatasetsCreateResponseFiltersItemKey;
    operator: DatasetsCreateResponseFiltersItemOperator;
    value: DatasetsCreateResponseFiltersItemValueList;
}
export type DatasetsCreateResponseFiltersList = Array<DatasetsCreateResponseFiltersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDatasetResponse {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsCreateResponseFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export interface CreateDeploymentDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
    versionId: string;
}
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext {
    elementId: string;
}
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs {
    next: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase0Type = "start";
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase0Type;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs {
    false: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
    true: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
}
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties {
    conditions?: unknown | null | undefined;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase1Type = "conditional";
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase1Type;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateDeploymentResponseElementsItemCase2Type = "percentage";
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase2Type;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs {
    fallback: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
    success: DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateDeploymentResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase3Type = "rate";
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase3Properties;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase3Type;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateDeploymentResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties {
    model: string;
    provider: string;
    retries: number;
    timeout: number;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase4Type = "model";
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase4Type;
}
export type DynamicRoutingCreateDeploymentResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateDeploymentResponseElementsItemCase5Type = "end";
export interface DynamicRoutingCreateDeploymentResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateDeploymentResponseElementsItemCase5Type;
}
export type DynamicRoutingCreateDeploymentResponseElementsItem = DynamicRoutingCreateDeploymentResponseElementsItemCase0 | DynamicRoutingCreateDeploymentResponseElementsItemCase1 | DynamicRoutingCreateDeploymentResponseElementsItemCase2 | DynamicRoutingCreateDeploymentResponseElementsItemCase3 | DynamicRoutingCreateDeploymentResponseElementsItemCase4 | DynamicRoutingCreateDeploymentResponseElementsItemCase5;
export type DynamicRoutingCreateDeploymentResponseElementsList = Array<DynamicRoutingCreateDeploymentResponseElementsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDeploymentDynamicRoutingResponse {
    id: string;
    createdAt: string;
    elements: DynamicRoutingCreateDeploymentResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export type DynamicRoutingCreateRequestElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateRequestElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingCreateRequestElementsItemCase0Type = "start";
export interface DynamicRoutingCreateRequestElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateRequestElementsItemCase0Type;
}
export type DynamicRoutingCreateRequestElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateRequestElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateRequestElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export type DynamicRoutingCreateRequestElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export type DynamicRoutingCreateRequestElementsItemCase1Type = "conditional";
export interface DynamicRoutingCreateRequestElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingCreateRequestElementsItemCase1Type;
}
export type DynamicRoutingCreateRequestElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateRequestElementsItemCase2Type = "percentage";
export interface DynamicRoutingCreateRequestElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateRequestElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateRequestElementsItemCase2Type;
}
export type DynamicRoutingCreateRequestElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateRequestElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateRequestElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingCreateRequestElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingCreateRequestElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateRequestElementsItemCase3PropertiesLimitType | (string & {});
    window: number;
}
export type DynamicRoutingCreateRequestElementsItemCase3Type = "rate";
export interface DynamicRoutingCreateRequestElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateRequestElementsItemCase3Properties;
    type: DynamicRoutingCreateRequestElementsItemCase3Type;
}
export type DynamicRoutingCreateRequestElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateRequestElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateRequestElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingCreateRequestElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingCreateRequestElementsItemCase4Type = "model";
export interface DynamicRoutingCreateRequestElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateRequestElementsItemCase4Type;
}
export type DynamicRoutingCreateRequestElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateRequestElementsItemCase5Type = "end";
export interface DynamicRoutingCreateRequestElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateRequestElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateRequestElementsItemCase5Type;
}
export type DynamicRoutingCreateRequestElementsItem = DynamicRoutingCreateRequestElementsItemCase0 | DynamicRoutingCreateRequestElementsItemCase1 | DynamicRoutingCreateRequestElementsItemCase2 | DynamicRoutingCreateRequestElementsItemCase3 | DynamicRoutingCreateRequestElementsItemCase4 | DynamicRoutingCreateRequestElementsItemCase5;
export type DynamicRoutingCreateRequestElementsList = Array<DynamicRoutingCreateRequestElementsItem>;
export interface CreateDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    elements: DynamicRoutingCreateRequestElementsList;
    name: string;
}
export interface DynamicRoutingCreateResponseDeployment {
    createdAt: string;
    deploymentId: string;
    versionId: string;
}
export type DynamicRoutingCreateResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingCreateResponseElementsItemCase0Type = "start";
export interface DynamicRoutingCreateResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateResponseElementsItemCase0Type;
}
export type DynamicRoutingCreateResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export type DynamicRoutingCreateResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export type DynamicRoutingCreateResponseElementsItemCase1Type = "conditional";
export interface DynamicRoutingCreateResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingCreateResponseElementsItemCase1Type;
}
export type DynamicRoutingCreateResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateResponseElementsItemCase2Type = "percentage";
export interface DynamicRoutingCreateResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateResponseElementsItemCase2Type;
}
export type DynamicRoutingCreateResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingCreateResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingCreateResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export type DynamicRoutingCreateResponseElementsItemCase3Type = "rate";
export interface DynamicRoutingCreateResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateResponseElementsItemCase3Properties;
    type: DynamicRoutingCreateResponseElementsItemCase3Type;
}
export type DynamicRoutingCreateResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingCreateResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingCreateResponseElementsItemCase4Type = "model";
export interface DynamicRoutingCreateResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateResponseElementsItemCase4Type;
}
export type DynamicRoutingCreateResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateResponseElementsItemCase5Type = "end";
export interface DynamicRoutingCreateResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateResponseElementsItemCase5Type;
}
export type DynamicRoutingCreateResponseElementsItem = DynamicRoutingCreateResponseElementsItemCase0 | DynamicRoutingCreateResponseElementsItemCase1 | DynamicRoutingCreateResponseElementsItemCase2 | DynamicRoutingCreateResponseElementsItemCase3 | DynamicRoutingCreateResponseElementsItemCase4 | DynamicRoutingCreateResponseElementsItemCase5;
export type DynamicRoutingCreateResponseElementsList = Array<DynamicRoutingCreateResponseElementsItem>;
export type DynamicRoutingCreateResponseVersionActive = "true" | "false";
export interface DynamicRoutingCreateResponseVersion {
    active: DynamicRoutingCreateResponseVersionActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDynamicRoutingResponse {
    id: string;
    createdAt: string;
    deployment: DynamicRoutingCreateResponseDeployment;
    elements: DynamicRoutingCreateResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    version: DynamicRoutingCreateResponseVersion;
}
export type EvaluationsCreateRequestDatasetIdsList = Array<string>;
export type EvaluationsCreateRequestEvaluationTypeIdsList = Array<string>;
export interface CreateEvaluationRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    datasetIds: EvaluationsCreateRequestDatasetIdsList;
    evaluationTypeIds: EvaluationsCreateRequestEvaluationTypeIdsList;
    name: string;
}
export type EvaluationsCreateResponseDatasetsItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type EvaluationsCreateResponseDatasetsItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type EvaluationsCreateResponseDatasetsItemFiltersItemValueItem = string | number | boolean;
export type EvaluationsCreateResponseDatasetsItemFiltersItemValueList = Array<EvaluationsCreateResponseDatasetsItemFiltersItemValueItem>;
export interface EvaluationsCreateResponseDatasetsItemFiltersItem {
    key: EvaluationsCreateResponseDatasetsItemFiltersItemKey;
    operator: EvaluationsCreateResponseDatasetsItemFiltersItemOperator;
    value: EvaluationsCreateResponseDatasetsItemFiltersItemValueList;
}
export type EvaluationsCreateResponseDatasetsItemFiltersList = Array<EvaluationsCreateResponseDatasetsItemFiltersItem>;
export interface EvaluationsCreateResponseDatasetsItem {
    id: string;
    accountId: string;
    accountTag: string;
    createdAt: string;
    enable: boolean;
    filters: EvaluationsCreateResponseDatasetsItemFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export type EvaluationsCreateResponseDatasetsList = Array<EvaluationsCreateResponseDatasetsItem>;
export interface EvaluationsCreateResponseResultsItem {
    id: string;
    createdAt: string;
    evaluationId: string;
    evaluationTypeId: string;
    modifiedAt: string;
    result: string;
    status: number;
    statusDescription: string;
    totalLogs: number;
}
export type EvaluationsCreateResponseResultsList = Array<EvaluationsCreateResponseResultsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEvaluationResponse {
    id: string;
    createdAt: string;
    datasets: EvaluationsCreateResponseDatasetsList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
    processed: boolean;
    results: EvaluationsCreateResponseResultsList;
    totalLogs: number;
}
export interface CreateProviderConfigRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    alias: string;
    defaultConfig: boolean;
    providerSlug: string;
    rateLimit?: number | undefined;
    rateLimitPeriod?: number | undefined;
    /** Provider API key to store in the Secrets Store configured on the gateway. */
    secret?: string | undefined;
    secretId?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProviderConfigResponse {
    id: string;
    alias: string;
    defaultConfig: boolean;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    providerSlug: string;
    secretId: string;
    secretPreview: string;
    /** UTC date (YYYY-MM-DD) the gateway last selected this key to authenticate a request to the provider, whether or not the request succeeded. Updated at most once a day. Null if the gateway has not used the key since this field was introduced. */
    lastUsedAt?: string | null | undefined;
    rateLimit?: number | null | undefined;
    rateLimitPeriod?: number | null | undefined;
}
export type DynamicRoutingCreateVersionRequestElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionRequestElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingCreateVersionRequestElementsItemCase0Type = "start";
export interface DynamicRoutingCreateVersionRequestElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateVersionRequestElementsItemCase0Type;
}
export type DynamicRoutingCreateVersionRequestElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionRequestElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionRequestElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export interface DynamicRoutingCreateVersionRequestElementsItemCase1Properties {
    conditions?: unknown | undefined;
}
export type DynamicRoutingCreateVersionRequestElementsItemCase1Type = "conditional";
export interface DynamicRoutingCreateVersionRequestElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateVersionRequestElementsItemCase1Properties;
    type: DynamicRoutingCreateVersionRequestElementsItemCase1Type;
}
export type DynamicRoutingCreateVersionRequestElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateVersionRequestElementsItemCase2Type = "percentage";
export interface DynamicRoutingCreateVersionRequestElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateVersionRequestElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateVersionRequestElementsItemCase2Type;
}
export type DynamicRoutingCreateVersionRequestElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionRequestElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionRequestElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingCreateVersionRequestElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingCreateVersionRequestElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateVersionRequestElementsItemCase3PropertiesLimitType | (string & {});
    window: number;
}
export type DynamicRoutingCreateVersionRequestElementsItemCase3Type = "rate";
export interface DynamicRoutingCreateVersionRequestElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateVersionRequestElementsItemCase3Properties;
    type: DynamicRoutingCreateVersionRequestElementsItemCase3Type;
}
export type DynamicRoutingCreateVersionRequestElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionRequestElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionRequestElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingCreateVersionRequestElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingCreateVersionRequestElementsItemCase4Type = "model";
export interface DynamicRoutingCreateVersionRequestElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateVersionRequestElementsItemCase4Type;
}
export type DynamicRoutingCreateVersionRequestElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateVersionRequestElementsItemCase5Type = "end";
export interface DynamicRoutingCreateVersionRequestElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateVersionRequestElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateVersionRequestElementsItemCase5Type;
}
export type DynamicRoutingCreateVersionRequestElementsItem = DynamicRoutingCreateVersionRequestElementsItemCase0 | DynamicRoutingCreateVersionRequestElementsItemCase1 | DynamicRoutingCreateVersionRequestElementsItemCase2 | DynamicRoutingCreateVersionRequestElementsItemCase3 | DynamicRoutingCreateVersionRequestElementsItemCase4 | DynamicRoutingCreateVersionRequestElementsItemCase5;
export type DynamicRoutingCreateVersionRequestElementsList = Array<DynamicRoutingCreateVersionRequestElementsItem>;
export interface CreateVersionDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
    elements: DynamicRoutingCreateVersionRequestElementsList;
}
export type DynamicRoutingCreateVersionResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingCreateVersionResponseElementsItemCase0Type = "start";
export interface DynamicRoutingCreateVersionResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingCreateVersionResponseElementsItemCase0Type;
}
export type DynamicRoutingCreateVersionResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export type DynamicRoutingCreateVersionResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export type DynamicRoutingCreateVersionResponseElementsItemCase1Type = "conditional";
export interface DynamicRoutingCreateVersionResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingCreateVersionResponseElementsItemCase1Type;
}
export type DynamicRoutingCreateVersionResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateVersionResponseElementsItemCase2Type = "percentage";
export interface DynamicRoutingCreateVersionResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingCreateVersionResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingCreateVersionResponseElementsItemCase2Type;
}
export type DynamicRoutingCreateVersionResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingCreateVersionResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingCreateVersionResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingCreateVersionResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export type DynamicRoutingCreateVersionResponseElementsItemCase3Type = "rate";
export interface DynamicRoutingCreateVersionResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateVersionResponseElementsItemCase3Properties;
    type: DynamicRoutingCreateVersionResponseElementsItemCase3Type;
}
export type DynamicRoutingCreateVersionResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingCreateVersionResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingCreateVersionResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingCreateVersionResponseElementsItemCase4Type = "model";
export interface DynamicRoutingCreateVersionResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingCreateVersionResponseElementsItemCase4Type;
}
export type DynamicRoutingCreateVersionResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingCreateVersionResponseElementsItemCase5Type = "end";
export interface DynamicRoutingCreateVersionResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingCreateVersionResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingCreateVersionResponseElementsItemCase5Type;
}
export type DynamicRoutingCreateVersionResponseElementsItem = DynamicRoutingCreateVersionResponseElementsItemCase0 | DynamicRoutingCreateVersionResponseElementsItemCase1 | DynamicRoutingCreateVersionResponseElementsItemCase2 | DynamicRoutingCreateVersionResponseElementsItemCase3 | DynamicRoutingCreateVersionResponseElementsItemCase4 | DynamicRoutingCreateVersionResponseElementsItemCase5;
export type DynamicRoutingCreateVersionResponseElementsList = Array<DynamicRoutingCreateVersionResponseElementsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateVersionDynamicRoutingResponse {
    id: string;
    createdAt: string;
    elements: DynamicRoutingCreateVersionResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    /** Identifier of the newly created version (top-level on the live wire; the docs' nested shape is stale). */
    versionId: string;
}
export interface CreditBalanceBillingRequest {
    accountId: string;
}
export interface BillingCreditBalanceResponsePaymentMethod {
    brand?: string | null | undefined;
    last4?: string | null | undefined;
}
export interface BillingCreditBalanceResponseTopupConfig {
    amount: number;
    threshold: number;
    disabledReason?: string | null | undefined;
    error?: string | null | undefined;
    lastFailedAt?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreditBalanceBillingResponse {
    balance: number;
    hasDefaultPaymentMethod: boolean;
    paymentMethod: BillingCreditBalanceResponsePaymentMethod;
    topupConfig: BillingCreditBalanceResponseTopupConfig;
    firstTopupSuccess?: boolean | null | undefined;
}
export interface DeleteAiGatewayRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
}
export type DeleteResponseDlpCase0Action = "BLOCK" | "FLAG";
export type DeleteResponseDlpCase0ProfilesList = Array<string>;
export interface DeleteResponseDlpCase0 {
    action: DeleteResponseDlpCase0Action;
    enabled: boolean;
    profiles: DeleteResponseDlpCase0ProfilesList;
}
export type DeleteResponseDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export type DeleteResponseDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export type DeleteResponseDlpCase1PoliciesItemCheckList = Array<DeleteResponseDlpCase1PoliciesItemCheckItem>;
export type DeleteResponseDlpCase1PoliciesItemProfilesList = Array<string>;
export interface DeleteResponseDlpCase1PoliciesItem {
    id: string;
    action: DeleteResponseDlpCase1PoliciesItemAction;
    check: DeleteResponseDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: DeleteResponseDlpCase1PoliciesItemProfilesList;
}
export type DeleteResponseDlpCase1PoliciesList = Array<DeleteResponseDlpCase1PoliciesItem>;
export interface DeleteResponseDlpCase1 {
    enabled: boolean;
    policies: DeleteResponseDlpCase1PoliciesList;
}
export type DeleteResponseDlp = DeleteResponseDlpCase0 | DeleteResponseDlpCase1;
export type DeleteResponseFedrampLevel = "fedramp-medium" | "fedramp-high";
export type DeleteResponseFedrampMode = "prefer" | "require";
export type DeleteResponseGuardrailsPromptP1 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS1 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS10 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS11 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS12 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS13 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS14 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS2 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS3 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS4 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS5 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS6 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS7 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS8 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsPromptS9 = "FLAG" | "BLOCK";
export interface DeleteResponseGuardrailsPrompt {
    p1?: DeleteResponseGuardrailsPromptP1 | null | undefined;
    s1?: DeleteResponseGuardrailsPromptS1 | null | undefined;
    s10?: DeleteResponseGuardrailsPromptS10 | null | undefined;
    s11?: DeleteResponseGuardrailsPromptS11 | null | undefined;
    s12?: DeleteResponseGuardrailsPromptS12 | null | undefined;
    s13?: DeleteResponseGuardrailsPromptS13 | null | undefined;
    s14?: DeleteResponseGuardrailsPromptS14 | null | undefined;
    s2?: DeleteResponseGuardrailsPromptS2 | null | undefined;
    s3?: DeleteResponseGuardrailsPromptS3 | null | undefined;
    s4?: DeleteResponseGuardrailsPromptS4 | null | undefined;
    s5?: DeleteResponseGuardrailsPromptS5 | null | undefined;
    s6?: DeleteResponseGuardrailsPromptS6 | null | undefined;
    s7?: DeleteResponseGuardrailsPromptS7 | null | undefined;
    s8?: DeleteResponseGuardrailsPromptS8 | null | undefined;
    s9?: DeleteResponseGuardrailsPromptS9 | null | undefined;
}
export type DeleteResponseGuardrailsResponseP1 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS1 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS10 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS11 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS12 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS13 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS14 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS2 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS3 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS4 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS5 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS6 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS7 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS8 = "FLAG" | "BLOCK";
export type DeleteResponseGuardrailsResponseS9 = "FLAG" | "BLOCK";
export interface DeleteResponseGuardrailsResponse {
    p1?: DeleteResponseGuardrailsResponseP1 | null | undefined;
    s1?: DeleteResponseGuardrailsResponseS1 | null | undefined;
    s10?: DeleteResponseGuardrailsResponseS10 | null | undefined;
    s11?: DeleteResponseGuardrailsResponseS11 | null | undefined;
    s12?: DeleteResponseGuardrailsResponseS12 | null | undefined;
    s13?: DeleteResponseGuardrailsResponseS13 | null | undefined;
    s14?: DeleteResponseGuardrailsResponseS14 | null | undefined;
    s2?: DeleteResponseGuardrailsResponseS2 | null | undefined;
    s3?: DeleteResponseGuardrailsResponseS3 | null | undefined;
    s4?: DeleteResponseGuardrailsResponseS4 | null | undefined;
    s5?: DeleteResponseGuardrailsResponseS5 | null | undefined;
    s6?: DeleteResponseGuardrailsResponseS6 | null | undefined;
    s7?: DeleteResponseGuardrailsResponseS7 | null | undefined;
    s8?: DeleteResponseGuardrailsResponseS8 | null | undefined;
    s9?: DeleteResponseGuardrailsResponseS9 | null | undefined;
}
export interface DeleteResponseGuardrails {
    prompt: DeleteResponseGuardrailsPrompt;
    response: DeleteResponseGuardrailsResponse;
}
export type DeleteResponseLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export type DeleteResponseOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export type DeleteResponseOtelItemContentType = "json" | "protobuf";
export interface DeleteResponseOtelItem {
    headers: DeleteResponseOtelItemHeadersMap;
    url: string;
    authorization?: string | null | undefined;
    contentType?: DeleteResponseOtelItemContentType | null | undefined;
}
export type DeleteResponseOtelList = Array<DeleteResponseOtelItem>;
export type DeleteResponseRateLimitingTechnique = "fixed" | "sliding";
export type DeleteResponseRetryBackoff = "constant" | "linear" | "exponential";
export type DeleteResponseSpendLimitsRulesItemLimitType = "cost";
export type DeleteResponseSpendLimitsRulesItemModelMode = "filter";
export type DeleteResponseSpendLimitsRulesItemModelValuesList = Array<string>;
export interface DeleteResponseSpendLimitsRulesItemModel {
    mode: DeleteResponseSpendLimitsRulesItemModelMode;
    values: DeleteResponseSpendLimitsRulesItemModelValuesList;
}
export type DeleteResponseSpendLimitsRulesItemProviderMode = "filter";
export type DeleteResponseSpendLimitsRulesItemProviderValuesList = Array<string>;
export interface DeleteResponseSpendLimitsRulesItemProvider {
    mode: DeleteResponseSpendLimitsRulesItemProviderMode;
    values: DeleteResponseSpendLimitsRulesItemProviderValuesList;
}
export type DeleteResponseSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export interface DeleteResponseSpendLimitsRulesItem {
    /** exclusiveMinimum */
    limit: number;
    limitType: DeleteResponseSpendLimitsRulesItemLimitType;
    /** exclusiveMinimum */
    window: number;
    id?: string | null | undefined;
    enabled?: boolean | null | undefined;
    metadata?: UntypedMetadataMap | null | undefined;
    model?: DeleteResponseSpendLimitsRulesItemModel | null | undefined;
    provider?: DeleteResponseSpendLimitsRulesItemProvider | null | undefined;
    technique?: DeleteResponseSpendLimitsRulesItemTechnique | null | undefined;
}
export type DeleteResponseSpendLimitsRulesList = Array<DeleteResponseSpendLimitsRulesItem>;
export interface DeleteResponseSpendLimits {
    enabled?: boolean | null | undefined;
    rules?: DeleteResponseSpendLimitsRulesList | null | undefined;
}
export type DeleteResponseStripeUsageEventsItem = CreateRequestStripeUsageEventsItem;
export type DeleteResponseStripeUsageEventsList = Array<CreateRequestStripeUsageEventsItem>;
export interface DeleteResponseStripe {
    authorization: string;
    usageEvents: DeleteResponseStripeUsageEventsList;
}
export type DeleteResponseWorkersAiBillingMode = "postpaid" | "unified";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAiGatewayResponse {
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    /** Require authentication for gateway access. New gateways must have authentication enabled. Once enabled, authentication cannot be disabled. */
    authentication?: boolean | null | undefined;
    /** Requires customer-provided provider credentials and prevents fallback to Unified Billing. */
    byokOnly?: boolean | null | undefined;
    dlp?: DeleteResponseDlp | null | undefined;
    /** FedRAMP compliance level: fedramp-medium or fedramp-high. */
    fedrampLevel?: DeleteResponseFedrampLevel | null | undefined;
    /** FedRAMP enforcement mode. "prefer" prioritizes compliant connectors but allows fallback. "require" strictly filters. */
    fedrampMode?: DeleteResponseFedrampMode | null | undefined;
    guardrails?: DeleteResponseGuardrails | null | undefined;
    isDefault?: boolean | null | undefined;
    logClassification?: boolean | null | undefined;
    logManagement?: number | null | undefined;
    logManagementStrategy?: DeleteResponseLogManagementStrategy | null | undefined;
    logpush?: boolean | null | undefined;
    logpushPublicKey?: string | null | undefined;
    otel?: DeleteResponseOtelList | null | undefined;
    rateLimitingTechnique?: DeleteResponseRateLimitingTechnique | null | undefined;
    /** Backoff strategy for retry delays */
    retryBackoff?: DeleteResponseRetryBackoff | null | undefined;
    /** Delay between retry attempts in milliseconds (0-60000) */
    retryDelay?: number | null | undefined;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null | undefined;
    spendLimits?: DeleteResponseSpendLimits | null | undefined;
    /** Secrets Store used by this gateway. Omit on update to keep the current store. Cannot be cleared while stored keys or secret references depend on it. */
    storeId?: string | null | undefined;
    stripe?: DeleteResponseStripe | null | undefined;
    /** Controls how Workers AI inference calls routed through this gateway are billed. 'postpaid' bills the account directly through Workers AI; 'unified' deducts credits via AI Gateway using neuron-based pricing and delegates billing to AI Gateway. */
    workersAiBillingMode?: DeleteResponseWorkersAiBillingMode | null | undefined;
    zdr?: boolean | null | undefined;
}
export interface DeleteBillingSpendingLimitRequest {
    accountId: string;
}
export type DeleteBillingSpendingLimitResponse = unknown;
export interface DeleteBillingTopupConfigRequest {
    accountId: string;
}
export type DeleteBillingTopupConfigResponse = unknown;
export interface DeleteCustomProviderRequest {
    accountId: string;
    id: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCustomProviderResponse {
    id: string;
    baseUrl: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    slug: string;
    beta?: boolean | null | undefined;
    curlExample?: string | null | undefined;
    description?: string | null | undefined;
    enable?: boolean | null | undefined;
    /** JSON object of extra HTTP headers that AI Gateway sends to the provider. Values can contain credentials. */
    headers?: string | null | undefined;
    jsExample?: string | null | undefined;
    link?: string | null | undefined;
    logo?: string | null | undefined;
    position?: number | null | undefined;
}
export interface DeleteDatasetRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
}
export type DatasetsDeleteResponseFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type DatasetsDeleteResponseFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type DatasetsDeleteResponseFiltersItemValueItem = string | number | boolean;
export type DatasetsDeleteResponseFiltersItemValueList = Array<DatasetsDeleteResponseFiltersItemValueItem>;
export interface DatasetsDeleteResponseFiltersItem {
    key: DatasetsDeleteResponseFiltersItemKey;
    operator: DatasetsDeleteResponseFiltersItemOperator;
    value: DatasetsDeleteResponseFiltersItemValueList;
}
export type DatasetsDeleteResponseFiltersList = Array<DatasetsDeleteResponseFiltersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteDatasetResponse {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsDeleteResponseFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export interface DeleteDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
}
export type DynamicRoutingDeleteResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingDeleteResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingDeleteResponseElementsItemCase0Type = "start";
export interface DynamicRoutingDeleteResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingDeleteResponseElementsItemCase0Type;
}
export type DynamicRoutingDeleteResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingDeleteResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingDeleteResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export type DynamicRoutingDeleteResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export type DynamicRoutingDeleteResponseElementsItemCase1Type = "conditional";
export interface DynamicRoutingDeleteResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingDeleteResponseElementsItemCase1Type;
}
export type DynamicRoutingDeleteResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingDeleteResponseElementsItemCase2Type = "percentage";
export interface DynamicRoutingDeleteResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingDeleteResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingDeleteResponseElementsItemCase2Type;
}
export type DynamicRoutingDeleteResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingDeleteResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingDeleteResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingDeleteResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingDeleteResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingDeleteResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export type DynamicRoutingDeleteResponseElementsItemCase3Type = "rate";
export interface DynamicRoutingDeleteResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingDeleteResponseElementsItemCase3Properties;
    type: DynamicRoutingDeleteResponseElementsItemCase3Type;
}
export type DynamicRoutingDeleteResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingDeleteResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingDeleteResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingDeleteResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingDeleteResponseElementsItemCase4Type = "model";
export interface DynamicRoutingDeleteResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingDeleteResponseElementsItemCase4Type;
}
export type DynamicRoutingDeleteResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingDeleteResponseElementsItemCase5Type = "end";
export interface DynamicRoutingDeleteResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingDeleteResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingDeleteResponseElementsItemCase5Type;
}
export type DynamicRoutingDeleteResponseElementsItem = DynamicRoutingDeleteResponseElementsItemCase0 | DynamicRoutingDeleteResponseElementsItemCase1 | DynamicRoutingDeleteResponseElementsItemCase2 | DynamicRoutingDeleteResponseElementsItemCase3 | DynamicRoutingDeleteResponseElementsItemCase4 | DynamicRoutingDeleteResponseElementsItemCase5;
export type DynamicRoutingDeleteResponseElementsList = Array<DynamicRoutingDeleteResponseElementsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteDynamicRoutingResponse {
    id: string;
    createdAt: string;
    elements: DynamicRoutingDeleteResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export interface DeleteEvaluationRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
}
export type EvaluationsDeleteResponseDatasetsItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type EvaluationsDeleteResponseDatasetsItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type EvaluationsDeleteResponseDatasetsItemFiltersItemValueItem = string | number | boolean;
export type EvaluationsDeleteResponseDatasetsItemFiltersItemValueList = Array<EvaluationsDeleteResponseDatasetsItemFiltersItemValueItem>;
export interface EvaluationsDeleteResponseDatasetsItemFiltersItem {
    key: EvaluationsDeleteResponseDatasetsItemFiltersItemKey;
    operator: EvaluationsDeleteResponseDatasetsItemFiltersItemOperator;
    value: EvaluationsDeleteResponseDatasetsItemFiltersItemValueList;
}
export type EvaluationsDeleteResponseDatasetsItemFiltersList = Array<EvaluationsDeleteResponseDatasetsItemFiltersItem>;
export interface EvaluationsDeleteResponseDatasetsItem {
    id: string;
    accountId: string;
    accountTag: string;
    createdAt: string;
    enable: boolean;
    filters: EvaluationsDeleteResponseDatasetsItemFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export type EvaluationsDeleteResponseDatasetsList = Array<EvaluationsDeleteResponseDatasetsItem>;
export type EvaluationsDeleteResponseResultsItem = EvaluationsCreateResponseResultsItem;
export type EvaluationsDeleteResponseResultsList = Array<EvaluationsCreateResponseResultsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteEvaluationResponse {
    id: string;
    createdAt: string;
    datasets: EvaluationsDeleteResponseDatasetsList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
    processed: boolean;
    results: EvaluationsDeleteResponseResultsList;
    totalLogs: number;
}
export type LogsDeleteRequestFiltersList = Array<string>;
export type LogsDeleteRequestOrderBy = "created_at" | "provider" | "model" | "model_type" | "success" | "cached" | "cost" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type LogsDeleteRequestOrderByDirection = "asc" | "desc";
export interface DeleteLogRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    filters?: LogsDeleteRequestFiltersList | undefined;
    limit?: number | undefined;
    orderBy?: LogsDeleteRequestOrderBy | (string & {}) | undefined;
    orderByDirection?: LogsDeleteRequestOrderByDirection | (string & {}) | undefined;
}
export interface DeleteLogResponse {
}
export interface DeleteProviderConfigRequest {
    /** Identifier. */
    accountId: string;
    gatewayId: string;
    id: string;
}
export type DeleteProviderConfigResponse = unknown;
export interface GetAiGatewayRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
}
export type GetResponseDlpCase0Action = "BLOCK" | "FLAG";
export type GetResponseDlpCase0ProfilesList = Array<string>;
export interface GetResponseDlpCase0 {
    action: GetResponseDlpCase0Action;
    enabled: boolean;
    profiles: GetResponseDlpCase0ProfilesList;
}
export type GetResponseDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export type GetResponseDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export type GetResponseDlpCase1PoliciesItemCheckList = Array<GetResponseDlpCase1PoliciesItemCheckItem>;
export type GetResponseDlpCase1PoliciesItemProfilesList = Array<string>;
export interface GetResponseDlpCase1PoliciesItem {
    id: string;
    action: GetResponseDlpCase1PoliciesItemAction;
    check: GetResponseDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: GetResponseDlpCase1PoliciesItemProfilesList;
}
export type GetResponseDlpCase1PoliciesList = Array<GetResponseDlpCase1PoliciesItem>;
export interface GetResponseDlpCase1 {
    enabled: boolean;
    policies: GetResponseDlpCase1PoliciesList;
}
export type GetResponseDlp = GetResponseDlpCase0 | GetResponseDlpCase1;
export type GetResponseFedrampLevel = "fedramp-medium" | "fedramp-high";
export type GetResponseFedrampMode = "prefer" | "require";
export type GetResponseGuardrailsPromptP1 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS1 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS10 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS11 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS12 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS13 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS14 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS2 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS3 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS4 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS5 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS6 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS7 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS8 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsPromptS9 = "FLAG" | "BLOCK";
export interface GetResponseGuardrailsPrompt {
    p1?: GetResponseGuardrailsPromptP1 | null | undefined;
    s1?: GetResponseGuardrailsPromptS1 | null | undefined;
    s10?: GetResponseGuardrailsPromptS10 | null | undefined;
    s11?: GetResponseGuardrailsPromptS11 | null | undefined;
    s12?: GetResponseGuardrailsPromptS12 | null | undefined;
    s13?: GetResponseGuardrailsPromptS13 | null | undefined;
    s14?: GetResponseGuardrailsPromptS14 | null | undefined;
    s2?: GetResponseGuardrailsPromptS2 | null | undefined;
    s3?: GetResponseGuardrailsPromptS3 | null | undefined;
    s4?: GetResponseGuardrailsPromptS4 | null | undefined;
    s5?: GetResponseGuardrailsPromptS5 | null | undefined;
    s6?: GetResponseGuardrailsPromptS6 | null | undefined;
    s7?: GetResponseGuardrailsPromptS7 | null | undefined;
    s8?: GetResponseGuardrailsPromptS8 | null | undefined;
    s9?: GetResponseGuardrailsPromptS9 | null | undefined;
}
export type GetResponseGuardrailsResponseP1 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS1 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS10 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS11 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS12 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS13 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS14 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS2 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS3 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS4 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS5 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS6 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS7 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS8 = "FLAG" | "BLOCK";
export type GetResponseGuardrailsResponseS9 = "FLAG" | "BLOCK";
export interface GetResponseGuardrailsResponse {
    p1?: GetResponseGuardrailsResponseP1 | null | undefined;
    s1?: GetResponseGuardrailsResponseS1 | null | undefined;
    s10?: GetResponseGuardrailsResponseS10 | null | undefined;
    s11?: GetResponseGuardrailsResponseS11 | null | undefined;
    s12?: GetResponseGuardrailsResponseS12 | null | undefined;
    s13?: GetResponseGuardrailsResponseS13 | null | undefined;
    s14?: GetResponseGuardrailsResponseS14 | null | undefined;
    s2?: GetResponseGuardrailsResponseS2 | null | undefined;
    s3?: GetResponseGuardrailsResponseS3 | null | undefined;
    s4?: GetResponseGuardrailsResponseS4 | null | undefined;
    s5?: GetResponseGuardrailsResponseS5 | null | undefined;
    s6?: GetResponseGuardrailsResponseS6 | null | undefined;
    s7?: GetResponseGuardrailsResponseS7 | null | undefined;
    s8?: GetResponseGuardrailsResponseS8 | null | undefined;
    s9?: GetResponseGuardrailsResponseS9 | null | undefined;
}
export interface GetResponseGuardrails {
    prompt: GetResponseGuardrailsPrompt;
    response: GetResponseGuardrailsResponse;
}
export type GetResponseLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export type GetResponseOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export type GetResponseOtelItemContentType = "json" | "protobuf";
export interface GetResponseOtelItem {
    headers: GetResponseOtelItemHeadersMap;
    url: string;
    authorization?: string | null | undefined;
    contentType?: GetResponseOtelItemContentType | null | undefined;
}
export type GetResponseOtelList = Array<GetResponseOtelItem>;
export type GetResponseRateLimitingTechnique = "fixed" | "sliding";
export type GetResponseRetryBackoff = "constant" | "linear" | "exponential";
export type GetResponseSpendLimitsRulesItemLimitType = "cost";
export type GetResponseSpendLimitsRulesItemModelMode = "filter";
export type GetResponseSpendLimitsRulesItemModelValuesList = Array<string>;
export interface GetResponseSpendLimitsRulesItemModel {
    mode: GetResponseSpendLimitsRulesItemModelMode;
    values: GetResponseSpendLimitsRulesItemModelValuesList;
}
export type GetResponseSpendLimitsRulesItemProviderMode = "filter";
export type GetResponseSpendLimitsRulesItemProviderValuesList = Array<string>;
export interface GetResponseSpendLimitsRulesItemProvider {
    mode: GetResponseSpendLimitsRulesItemProviderMode;
    values: GetResponseSpendLimitsRulesItemProviderValuesList;
}
export type GetResponseSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export interface GetResponseSpendLimitsRulesItem {
    /** exclusiveMinimum */
    limit: number;
    limitType: GetResponseSpendLimitsRulesItemLimitType;
    /** exclusiveMinimum */
    window: number;
    id?: string | null | undefined;
    enabled?: boolean | null | undefined;
    metadata?: UntypedMetadataMap | null | undefined;
    model?: GetResponseSpendLimitsRulesItemModel | null | undefined;
    provider?: GetResponseSpendLimitsRulesItemProvider | null | undefined;
    technique?: GetResponseSpendLimitsRulesItemTechnique | null | undefined;
}
export type GetResponseSpendLimitsRulesList = Array<GetResponseSpendLimitsRulesItem>;
export interface GetResponseSpendLimits {
    enabled?: boolean | null | undefined;
    rules?: GetResponseSpendLimitsRulesList | null | undefined;
}
export type GetResponseStripeUsageEventsItem = CreateRequestStripeUsageEventsItem;
export type GetResponseStripeUsageEventsList = Array<CreateRequestStripeUsageEventsItem>;
export interface GetResponseStripe {
    authorization: string;
    usageEvents: GetResponseStripeUsageEventsList;
}
export type GetResponseWorkersAiBillingMode = "postpaid" | "unified";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAiGatewayResponse {
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    /** Require authentication for gateway access. New gateways must have authentication enabled. Once enabled, authentication cannot be disabled. */
    authentication?: boolean | null | undefined;
    /** Requires customer-provided provider credentials and prevents fallback to Unified Billing. */
    byokOnly?: boolean | null | undefined;
    dlp?: GetResponseDlp | null | undefined;
    /** FedRAMP compliance level: fedramp-medium or fedramp-high. */
    fedrampLevel?: GetResponseFedrampLevel | null | undefined;
    /** FedRAMP enforcement mode. "prefer" prioritizes compliant connectors but allows fallback. "require" strictly filters. */
    fedrampMode?: GetResponseFedrampMode | null | undefined;
    guardrails?: GetResponseGuardrails | null | undefined;
    isDefault?: boolean | null | undefined;
    logClassification?: boolean | null | undefined;
    logManagement?: number | null | undefined;
    logManagementStrategy?: GetResponseLogManagementStrategy | null | undefined;
    logpush?: boolean | null | undefined;
    logpushPublicKey?: string | null | undefined;
    otel?: GetResponseOtelList | null | undefined;
    rateLimitingTechnique?: GetResponseRateLimitingTechnique | null | undefined;
    /** Backoff strategy for retry delays */
    retryBackoff?: GetResponseRetryBackoff | null | undefined;
    /** Delay between retry attempts in milliseconds (0-60000) */
    retryDelay?: number | null | undefined;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null | undefined;
    spendLimits?: GetResponseSpendLimits | null | undefined;
    /** Secrets Store used by this gateway. Omit on update to keep the current store. Cannot be cleared while stored keys or secret references depend on it. */
    storeId?: string | null | undefined;
    stripe?: GetResponseStripe | null | undefined;
    /** Controls how Workers AI inference calls routed through this gateway are billed. 'postpaid' bills the account directly through Workers AI; 'unified' deducts credits via AI Gateway using neuron-based pricing and delegates billing to AI Gateway. */
    workersAiBillingMode?: GetResponseWorkersAiBillingMode | null | undefined;
    zdr?: boolean | null | undefined;
}
export interface GetBillingSpendingLimitRequest {
    accountId: string;
}
export interface BillingSpendingLimitGetResponseConfig {
    amount: number;
    duration: string;
    strategy: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBillingSpendingLimitResponse {
    config: BillingSpendingLimitGetResponseConfig;
    enabled: boolean;
}
export interface GetBillingTopupConfigRequest {
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBillingTopupConfigResponse {
    amount: number;
    threshold: number;
    disabledReason?: string | null | undefined;
    error?: string | null | undefined;
    lastFailedAt?: number | null | undefined;
}
export interface GetCustomProviderRequest {
    accountId: string;
    id: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomProviderResponse {
    id: string;
    baseUrl: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    slug: string;
    beta?: boolean | null | undefined;
    curlExample?: string | null | undefined;
    description?: string | null | undefined;
    enable?: boolean | null | undefined;
    /** JSON object of extra HTTP headers that AI Gateway sends to the provider. Values can contain credentials. */
    headers?: string | null | undefined;
    jsExample?: string | null | undefined;
    link?: string | null | undefined;
    logo?: string | null | undefined;
    position?: number | null | undefined;
}
export interface GetDatasetRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
}
export type DatasetsGetResponseFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type DatasetsGetResponseFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type DatasetsGetResponseFiltersItemValueItem = string | number | boolean;
export type DatasetsGetResponseFiltersItemValueList = Array<DatasetsGetResponseFiltersItemValueItem>;
export interface DatasetsGetResponseFiltersItem {
    key: DatasetsGetResponseFiltersItemKey;
    operator: DatasetsGetResponseFiltersItemOperator;
    value: DatasetsGetResponseFiltersItemValueList;
}
export type DatasetsGetResponseFiltersList = Array<DatasetsGetResponseFiltersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDatasetResponse {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsGetResponseFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export interface GetDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
}
export type DynamicRoutingGetResponseDeployment = DynamicRoutingCreateResponseDeployment;
export type DynamicRoutingGetResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingGetResponseElementsItemCase0Type = "start";
export interface DynamicRoutingGetResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingGetResponseElementsItemCase0Type;
}
export type DynamicRoutingGetResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export type DynamicRoutingGetResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export type DynamicRoutingGetResponseElementsItemCase1Type = "conditional";
export interface DynamicRoutingGetResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingGetResponseElementsItemCase1Type;
}
export type DynamicRoutingGetResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingGetResponseElementsItemCase2Type = "percentage";
export interface DynamicRoutingGetResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingGetResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingGetResponseElementsItemCase2Type;
}
export type DynamicRoutingGetResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingGetResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingGetResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingGetResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export type DynamicRoutingGetResponseElementsItemCase3Type = "rate";
export interface DynamicRoutingGetResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingGetResponseElementsItemCase3Properties;
    type: DynamicRoutingGetResponseElementsItemCase3Type;
}
export type DynamicRoutingGetResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingGetResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingGetResponseElementsItemCase4Type = "model";
export interface DynamicRoutingGetResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingGetResponseElementsItemCase4Type;
}
export type DynamicRoutingGetResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingGetResponseElementsItemCase5Type = "end";
export interface DynamicRoutingGetResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingGetResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingGetResponseElementsItemCase5Type;
}
export type DynamicRoutingGetResponseElementsItem = DynamicRoutingGetResponseElementsItemCase0 | DynamicRoutingGetResponseElementsItemCase1 | DynamicRoutingGetResponseElementsItemCase2 | DynamicRoutingGetResponseElementsItemCase3 | DynamicRoutingGetResponseElementsItemCase4 | DynamicRoutingGetResponseElementsItemCase5;
export type DynamicRoutingGetResponseElementsList = Array<DynamicRoutingGetResponseElementsItem>;
export type DynamicRoutingGetResponseVersionActive = "true" | "false";
export interface DynamicRoutingGetResponseVersion {
    active: DynamicRoutingGetResponseVersionActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDynamicRoutingResponse {
    id: string;
    createdAt: string;
    deployment: DynamicRoutingCreateResponseDeployment;
    elements: DynamicRoutingGetResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    version: DynamicRoutingGetResponseVersion;
}
export interface GetEvaluationRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
}
export type EvaluationsGetResponseDatasetsItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type EvaluationsGetResponseDatasetsItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type EvaluationsGetResponseDatasetsItemFiltersItemValueItem = string | number | boolean;
export type EvaluationsGetResponseDatasetsItemFiltersItemValueList = Array<EvaluationsGetResponseDatasetsItemFiltersItemValueItem>;
export interface EvaluationsGetResponseDatasetsItemFiltersItem {
    key: EvaluationsGetResponseDatasetsItemFiltersItemKey;
    operator: EvaluationsGetResponseDatasetsItemFiltersItemOperator;
    value: EvaluationsGetResponseDatasetsItemFiltersItemValueList;
}
export type EvaluationsGetResponseDatasetsItemFiltersList = Array<EvaluationsGetResponseDatasetsItemFiltersItem>;
export interface EvaluationsGetResponseDatasetsItem {
    id: string;
    accountId: string;
    accountTag: string;
    createdAt: string;
    enable: boolean;
    filters: EvaluationsGetResponseDatasetsItemFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export type EvaluationsGetResponseDatasetsList = Array<EvaluationsGetResponseDatasetsItem>;
export type EvaluationsGetResponseResultsItem = EvaluationsCreateResponseResultsItem;
export type EvaluationsGetResponseResultsList = Array<EvaluationsCreateResponseResultsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEvaluationResponse {
    id: string;
    createdAt: string;
    datasets: EvaluationsGetResponseDatasetsList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
    processed: boolean;
    results: EvaluationsGetResponseResultsList;
    totalLogs: number;
}
export interface GetLogRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLogResponse {
    id: string;
    cached: boolean;
    createdAt: string;
    duration: number;
    model: string;
    path: string;
    provider: string;
    success: boolean;
    tokensIn: number;
    tokensOut: number;
    /** Whether the request and response bodies were eligible to be stored. False when the request sent `cf-aig-collect-log-payload: false`, logging was off, or the gateway does not store bodies for the request. Null for logs written before this field existed. */
    collectLogPayload?: boolean | null | undefined;
    cost?: number | null | undefined;
    customCost?: boolean | null | undefined;
    metadata?: string | null | undefined;
    modelType?: string | null | undefined;
    requestContentType?: string | null | undefined;
    requestHead?: string | null | undefined;
    requestHeadComplete?: boolean | null | undefined;
    requestSize?: number | null | undefined;
    requestType?: string | null | undefined;
    responseContentType?: string | null | undefined;
    responseHead?: string | null | undefined;
    responseHeadComplete?: boolean | null | undefined;
    responseSize?: number | null | undefined;
    statusCode?: number | null | undefined;
    step?: number | null | undefined;
}
export interface GetUrlRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    provider: string;
}
export type GetUrlResponse = string;
export interface GetVersionDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
    versionId: string;
}
export type DynamicRoutingGetVersionResponseActive = "true" | "false";
export type DynamicRoutingGetVersionResponseElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetVersionResponseElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingGetVersionResponseElementsItemCase0Type = "start";
export interface DynamicRoutingGetVersionResponseElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingGetVersionResponseElementsItemCase0Type;
}
export type DynamicRoutingGetVersionResponseElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetVersionResponseElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetVersionResponseElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export type DynamicRoutingGetVersionResponseElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export type DynamicRoutingGetVersionResponseElementsItemCase1Type = "conditional";
export interface DynamicRoutingGetVersionResponseElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingGetVersionResponseElementsItemCase1Type;
}
export type DynamicRoutingGetVersionResponseElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingGetVersionResponseElementsItemCase2Type = "percentage";
export interface DynamicRoutingGetVersionResponseElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingGetVersionResponseElementsItemCase2OutputsMap;
    type: DynamicRoutingGetVersionResponseElementsItemCase2Type;
}
export type DynamicRoutingGetVersionResponseElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetVersionResponseElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetVersionResponseElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingGetVersionResponseElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingGetVersionResponseElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingGetVersionResponseElementsItemCase3PropertiesLimitType;
    window: number;
}
export type DynamicRoutingGetVersionResponseElementsItemCase3Type = "rate";
export interface DynamicRoutingGetVersionResponseElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingGetVersionResponseElementsItemCase3Properties;
    type: DynamicRoutingGetVersionResponseElementsItemCase3Type;
}
export type DynamicRoutingGetVersionResponseElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetVersionResponseElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingGetVersionResponseElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingGetVersionResponseElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingGetVersionResponseElementsItemCase4Type = "model";
export interface DynamicRoutingGetVersionResponseElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingGetVersionResponseElementsItemCase4Type;
}
export type DynamicRoutingGetVersionResponseElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingGetVersionResponseElementsItemCase5Type = "end";
export interface DynamicRoutingGetVersionResponseElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingGetVersionResponseElementsItemCase5OutputsMap;
    type: DynamicRoutingGetVersionResponseElementsItemCase5Type;
}
export type DynamicRoutingGetVersionResponseElementsItem = DynamicRoutingGetVersionResponseElementsItemCase0 | DynamicRoutingGetVersionResponseElementsItemCase1 | DynamicRoutingGetVersionResponseElementsItemCase2 | DynamicRoutingGetVersionResponseElementsItemCase3 | DynamicRoutingGetVersionResponseElementsItemCase4 | DynamicRoutingGetVersionResponseElementsItemCase5;
export type DynamicRoutingGetVersionResponseElementsList = Array<DynamicRoutingGetVersionResponseElementsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVersionDynamicRoutingResponse {
    id: string;
    active: DynamicRoutingGetVersionResponseActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    elements: DynamicRoutingGetVersionResponseElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    versionId: string;
    isValid?: boolean | null | undefined;
}
export type BillingInvoiceHistoryRequestType = "auto" | "all" | "manual";
export interface InvoiceHistoryBillingRequest {
    accountId: string;
    /** Filter invoice type: auto, manual, or all. */
    type?: BillingInvoiceHistoryRequestType | (string & {}) | undefined;
}
export interface BillingInvoiceHistoryResponseInvoicesItem {
    amountDue: number;
    amountPaid: number;
    amountRemaining: number;
    currency: string;
    id?: string | null | undefined;
    attemptCount?: number | null | undefined;
    attempted?: boolean | null | undefined;
    autoAdvance?: boolean | null | undefined;
    created?: number | null | undefined;
    createdBy?: string | null | undefined;
    description?: string | null | undefined;
    invoiceOrigin?: string | null | undefined;
    invoicePdf?: string | null | undefined;
    status?: string | null | undefined;
}
export type BillingInvoiceHistoryResponseInvoicesList = Array<BillingInvoiceHistoryResponseInvoicesItem>;
export interface BillingInvoiceHistoryResponsePagination {
    hasMore: boolean;
    page: number;
    perPage: number;
    totalCount: number;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface InvoiceHistoryBillingResponse {
    invoices: BillingInvoiceHistoryResponseInvoicesList;
    pagination: BillingInvoiceHistoryResponsePagination;
}
export interface InvoicePreviewBillingRequest {
    accountId: string;
}
export interface BillingInvoicePreviewResponseInvoiceLinesItemPeriod {
    end: number;
    start: number;
}
export interface BillingInvoicePreviewResponseInvoiceLinesItemPricing {
    unitAmountDecimal: string;
}
export interface BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsItem {
    amount: number;
    type: string;
    creditBalanceTransaction?: string | null | undefined;
    discount?: string | null | undefined;
}
export type BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsList = Array<BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsItem>;
export interface BillingInvoicePreviewResponseInvoiceLinesItem {
    amount: number;
    currency: string;
    description: string;
    period: BillingInvoicePreviewResponseInvoiceLinesItemPeriod;
    pricing: BillingInvoicePreviewResponseInvoiceLinesItemPricing;
    quantity: number;
    pretaxCreditAmounts?: BillingInvoicePreviewResponseInvoiceLinesItemPretaxCreditAmountsList | null | undefined;
}
export type BillingInvoicePreviewResponseInvoiceLinesList = Array<BillingInvoicePreviewResponseInvoiceLinesItem>;
export type BillingInvoicePreviewResponseStatus = "draft" | "open" | "paid" | "uncollectible" | "void";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface InvoicePreviewBillingResponse {
    id: string;
    amountDue: number;
    amountPaid: number;
    amountRemaining: number;
    currency: string;
    invoiceLines: BillingInvoicePreviewResponseInvoiceLinesList;
    periodEnd: number;
    periodStart: number;
    status: BillingInvoicePreviewResponseStatus;
}
export interface ListAiGatewaysRequest {
    accountId: string;
    page?: number | undefined;
    perPage?: number | undefined;
    /** Search by id */
    search?: string | undefined;
}
export type ListResultItemDlpCase0Action = "BLOCK" | "FLAG";
export type ListResultItemDlpCase0ProfilesList = Array<string>;
export interface ListResultItemDlpCase0 {
    action: ListResultItemDlpCase0Action;
    enabled: boolean;
    profiles: ListResultItemDlpCase0ProfilesList;
}
export type ListResultItemDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export type ListResultItemDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export type ListResultItemDlpCase1PoliciesItemCheckList = Array<ListResultItemDlpCase1PoliciesItemCheckItem>;
export type ListResultItemDlpCase1PoliciesItemProfilesList = Array<string>;
export interface ListResultItemDlpCase1PoliciesItem {
    id: string;
    action: ListResultItemDlpCase1PoliciesItemAction;
    check: ListResultItemDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: ListResultItemDlpCase1PoliciesItemProfilesList;
}
export type ListResultItemDlpCase1PoliciesList = Array<ListResultItemDlpCase1PoliciesItem>;
export interface ListResultItemDlpCase1 {
    enabled: boolean;
    policies: ListResultItemDlpCase1PoliciesList;
}
export type ListResultItemDlp = ListResultItemDlpCase0 | ListResultItemDlpCase1;
export type ListResultItemFedrampLevel = "fedramp-medium" | "fedramp-high";
export type ListResultItemFedrampMode = "prefer" | "require";
export type ListResultItemGuardrailsPromptP1 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS1 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS10 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS11 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS12 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS13 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS14 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS2 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS3 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS4 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS5 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS6 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS7 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS8 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsPromptS9 = "FLAG" | "BLOCK";
export interface ListResultItemGuardrailsPrompt {
    p1?: ListResultItemGuardrailsPromptP1 | null | undefined;
    s1?: ListResultItemGuardrailsPromptS1 | null | undefined;
    s10?: ListResultItemGuardrailsPromptS10 | null | undefined;
    s11?: ListResultItemGuardrailsPromptS11 | null | undefined;
    s12?: ListResultItemGuardrailsPromptS12 | null | undefined;
    s13?: ListResultItemGuardrailsPromptS13 | null | undefined;
    s14?: ListResultItemGuardrailsPromptS14 | null | undefined;
    s2?: ListResultItemGuardrailsPromptS2 | null | undefined;
    s3?: ListResultItemGuardrailsPromptS3 | null | undefined;
    s4?: ListResultItemGuardrailsPromptS4 | null | undefined;
    s5?: ListResultItemGuardrailsPromptS5 | null | undefined;
    s6?: ListResultItemGuardrailsPromptS6 | null | undefined;
    s7?: ListResultItemGuardrailsPromptS7 | null | undefined;
    s8?: ListResultItemGuardrailsPromptS8 | null | undefined;
    s9?: ListResultItemGuardrailsPromptS9 | null | undefined;
}
export type ListResultItemGuardrailsResponseP1 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS1 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS10 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS11 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS12 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS13 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS14 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS2 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS3 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS4 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS5 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS6 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS7 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS8 = "FLAG" | "BLOCK";
export type ListResultItemGuardrailsResponseS9 = "FLAG" | "BLOCK";
export interface ListResultItemGuardrailsResponse {
    p1?: ListResultItemGuardrailsResponseP1 | null | undefined;
    s1?: ListResultItemGuardrailsResponseS1 | null | undefined;
    s10?: ListResultItemGuardrailsResponseS10 | null | undefined;
    s11?: ListResultItemGuardrailsResponseS11 | null | undefined;
    s12?: ListResultItemGuardrailsResponseS12 | null | undefined;
    s13?: ListResultItemGuardrailsResponseS13 | null | undefined;
    s14?: ListResultItemGuardrailsResponseS14 | null | undefined;
    s2?: ListResultItemGuardrailsResponseS2 | null | undefined;
    s3?: ListResultItemGuardrailsResponseS3 | null | undefined;
    s4?: ListResultItemGuardrailsResponseS4 | null | undefined;
    s5?: ListResultItemGuardrailsResponseS5 | null | undefined;
    s6?: ListResultItemGuardrailsResponseS6 | null | undefined;
    s7?: ListResultItemGuardrailsResponseS7 | null | undefined;
    s8?: ListResultItemGuardrailsResponseS8 | null | undefined;
    s9?: ListResultItemGuardrailsResponseS9 | null | undefined;
}
export interface ListResultItemGuardrails {
    prompt: ListResultItemGuardrailsPrompt;
    response: ListResultItemGuardrailsResponse;
}
export type ListResultItemLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export type ListResultItemOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export type ListResultItemOtelItemContentType = "json" | "protobuf";
export interface ListResultItemOtelItem {
    headers: ListResultItemOtelItemHeadersMap;
    url: string;
    authorization?: string | null | undefined;
    contentType?: ListResultItemOtelItemContentType | null | undefined;
}
export type ListResultItemOtelList = Array<ListResultItemOtelItem>;
export type ListResultItemRateLimitingTechnique = "fixed" | "sliding";
export type ListResultItemRetryBackoff = "constant" | "linear" | "exponential";
export type ListResultItemSpendLimitsRulesItemLimitType = "cost";
export type ListResultItemSpendLimitsRulesItemModelMode = "filter";
export type ListResultItemSpendLimitsRulesItemModelValuesList = Array<string>;
export interface ListResultItemSpendLimitsRulesItemModel {
    mode: ListResultItemSpendLimitsRulesItemModelMode;
    values: ListResultItemSpendLimitsRulesItemModelValuesList;
}
export type ListResultItemSpendLimitsRulesItemProviderMode = "filter";
export type ListResultItemSpendLimitsRulesItemProviderValuesList = Array<string>;
export interface ListResultItemSpendLimitsRulesItemProvider {
    mode: ListResultItemSpendLimitsRulesItemProviderMode;
    values: ListResultItemSpendLimitsRulesItemProviderValuesList;
}
export type ListResultItemSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export interface ListResultItemSpendLimitsRulesItem {
    /** exclusiveMinimum */
    limit: number;
    limitType: ListResultItemSpendLimitsRulesItemLimitType;
    /** exclusiveMinimum */
    window: number;
    id?: string | null | undefined;
    enabled?: boolean | null | undefined;
    metadata?: UntypedMetadataMap | null | undefined;
    model?: ListResultItemSpendLimitsRulesItemModel | null | undefined;
    provider?: ListResultItemSpendLimitsRulesItemProvider | null | undefined;
    technique?: ListResultItemSpendLimitsRulesItemTechnique | null | undefined;
}
export type ListResultItemSpendLimitsRulesList = Array<ListResultItemSpendLimitsRulesItem>;
export interface ListResultItemSpendLimits {
    enabled?: boolean | null | undefined;
    rules?: ListResultItemSpendLimitsRulesList | null | undefined;
}
export type ListResultItemStripeUsageEventsItem = CreateRequestStripeUsageEventsItem;
export type ListResultItemStripeUsageEventsList = Array<CreateRequestStripeUsageEventsItem>;
export interface ListResultItemStripe {
    authorization: string;
    usageEvents: ListResultItemStripeUsageEventsList;
}
export type ListResultItemWorkersAiBillingMode = "postpaid" | "unified";
export interface ListResultItem {
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    /** Require authentication for gateway access. New gateways must have authentication enabled. Once enabled, authentication cannot be disabled. */
    authentication?: boolean | null | undefined;
    /** Requires customer-provided provider credentials and prevents fallback to Unified Billing. */
    byokOnly?: boolean | null | undefined;
    dlp?: ListResultItemDlp | null | undefined;
    /** FedRAMP compliance level: fedramp-medium or fedramp-high. */
    fedrampLevel?: ListResultItemFedrampLevel | null | undefined;
    /** FedRAMP enforcement mode. "prefer" prioritizes compliant connectors but allows fallback. "require" strictly filters. */
    fedrampMode?: ListResultItemFedrampMode | null | undefined;
    guardrails?: ListResultItemGuardrails | null | undefined;
    isDefault?: boolean | null | undefined;
    logClassification?: boolean | null | undefined;
    logManagement?: number | null | undefined;
    logManagementStrategy?: ListResultItemLogManagementStrategy | null | undefined;
    logpush?: boolean | null | undefined;
    logpushPublicKey?: string | null | undefined;
    otel?: ListResultItemOtelList | null | undefined;
    rateLimitingTechnique?: ListResultItemRateLimitingTechnique | null | undefined;
    /** Backoff strategy for retry delays */
    retryBackoff?: ListResultItemRetryBackoff | null | undefined;
    /** Delay between retry attempts in milliseconds (0-60000) */
    retryDelay?: number | null | undefined;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null | undefined;
    spendLimits?: ListResultItemSpendLimits | null | undefined;
    /** Secrets Store used by this gateway. Omit on update to keep the current store. Cannot be cleared while stored keys or secret references depend on it. */
    storeId?: string | null | undefined;
    stripe?: ListResultItemStripe | null | undefined;
    /** Controls how Workers AI inference calls routed through this gateway are billed. 'postpaid' bills the account directly through Workers AI; 'unified' deducts credits via AI Gateway using neuron-based pricing and delegates billing to AI Gateway. */
    workersAiBillingMode?: ListResultItemWorkersAiBillingMode | null | undefined;
    zdr?: boolean | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListAiGatewaysResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListCustomProvidersRequest {
    accountId: string;
    beta?: boolean | undefined;
    enable?: boolean | undefined;
    page?: number | undefined;
    perPage?: number | undefined;
    /** Search by id, name, slug */
    search?: string | undefined;
}
export interface CustomProvidersListResultItem {
    id: string;
    baseUrl: string;
    createdAt: string;
    modifiedAt: string;
    name: string;
    slug: string;
    beta?: boolean | null | undefined;
    curlExample?: string | null | undefined;
    description?: string | null | undefined;
    enable?: boolean | null | undefined;
    /** JSON object of extra HTTP headers that AI Gateway sends to the provider. Values can contain credentials. */
    headers?: string | null | undefined;
    jsExample?: string | null | undefined;
    link?: string | null | undefined;
    logo?: string | null | undefined;
    position?: number | null | undefined;
}
export type CustomProvidersListResultList = Array<CustomProvidersListResultItem>;
export interface ListCustomProvidersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CustomProvidersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListDatasetsRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    enable?: boolean | undefined;
    name?: string | undefined;
    page?: number | undefined;
    perPage?: number | undefined;
    /** Search by id, name, filters */
    search?: string | undefined;
}
export type DatasetsListResultItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type DatasetsListResultItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type DatasetsListResultItemFiltersItemValueItem = string | number | boolean;
export type DatasetsListResultItemFiltersItemValueList = Array<DatasetsListResultItemFiltersItemValueItem>;
export interface DatasetsListResultItemFiltersItem {
    key: DatasetsListResultItemFiltersItemKey;
    operator: DatasetsListResultItemFiltersItemOperator;
    value: DatasetsListResultItemFiltersItemValueList;
}
export type DatasetsListResultItemFiltersList = Array<DatasetsListResultItemFiltersItem>;
export interface DatasetsListResultItem {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsListResultItemFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export type DatasetsListResultList = Array<DatasetsListResultItem>;
export interface ListDatasetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatasetsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListDeploymentsDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
}
export type DynamicRoutingListDeploymentsResponseDataDeploymentsItem = DynamicRoutingCreateResponseDeployment;
export type DynamicRoutingListDeploymentsResponseDataDeploymentsList = Array<DynamicRoutingCreateResponseDeployment>;
export interface DynamicRoutingListDeploymentsResponseData {
    deployments: DynamicRoutingListDeploymentsResponseDataDeploymentsList;
    orderBy: string;
    orderByDirection: string;
    page: number;
    perPage: number;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListDeploymentsDynamicRoutingResponse {
    data: DynamicRoutingListDeploymentsResponseData;
}
export interface ListDynamicRoutingsRequest {
    accountId: string;
    gatewayId: string;
    /** Page number */
    page?: number | undefined;
    /** Number of routes per page */
    perPage?: number | undefined;
}
export type DynamicRoutingListResponseDataRoutesItemDeployment = DynamicRoutingCreateResponseDeployment;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase0Type = "start";
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase0Type;
}
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase1Type = "conditional";
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase1Type;
}
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase2Type = "percentage";
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingListResponseDataRoutesItemElementsItemCase2OutputsMap;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase2Type;
}
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingListResponseDataRoutesItemElementsItemCase3PropertiesLimitType;
    window: number;
}
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase3Type = "rate";
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingListResponseDataRoutesItemElementsItemCase3Properties;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase3Type;
}
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase4Type = "model";
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase4Type;
}
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingListResponseDataRoutesItemElementsItemCase5Type = "end";
export interface DynamicRoutingListResponseDataRoutesItemElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingListResponseDataRoutesItemElementsItemCase5OutputsMap;
    type: DynamicRoutingListResponseDataRoutesItemElementsItemCase5Type;
}
export type DynamicRoutingListResponseDataRoutesItemElementsItem = DynamicRoutingListResponseDataRoutesItemElementsItemCase0 | DynamicRoutingListResponseDataRoutesItemElementsItemCase1 | DynamicRoutingListResponseDataRoutesItemElementsItemCase2 | DynamicRoutingListResponseDataRoutesItemElementsItemCase3 | DynamicRoutingListResponseDataRoutesItemElementsItemCase4 | DynamicRoutingListResponseDataRoutesItemElementsItemCase5;
export type DynamicRoutingListResponseDataRoutesItemElementsList = Array<DynamicRoutingListResponseDataRoutesItemElementsItem>;
export type DynamicRoutingListResponseDataRoutesItemVersionActive = "true" | "false";
export interface DynamicRoutingListResponseDataRoutesItemVersion {
    active: DynamicRoutingListResponseDataRoutesItemVersionActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null | undefined;
}
export interface DynamicRoutingListResponseDataRoutesItem {
    id: string;
    accountTag: string;
    createdAt: string;
    deployment: DynamicRoutingCreateResponseDeployment;
    elements: DynamicRoutingListResponseDataRoutesItemElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    version: DynamicRoutingListResponseDataRoutesItemVersion;
}
export type DynamicRoutingListResponseDataRoutesList = Array<DynamicRoutingListResponseDataRoutesItem>;
export interface DynamicRoutingListResponseData {
    orderBy: string;
    orderByDirection: string;
    page: number;
    perPage: number;
    routes: DynamicRoutingListResponseDataRoutesList;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListDynamicRoutingsResponse {
    data: DynamicRoutingListResponseData;
}
export interface ListEvaluationsRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    name?: string | undefined;
    page?: number | undefined;
    perPage?: number | undefined;
    processed?: boolean | undefined;
    /** Search by id, name */
    search?: string | undefined;
}
export type EvaluationsListResultItemDatasetsItemFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type EvaluationsListResultItemDatasetsItemFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type EvaluationsListResultItemDatasetsItemFiltersItemValueItem = string | number | boolean;
export type EvaluationsListResultItemDatasetsItemFiltersItemValueList = Array<EvaluationsListResultItemDatasetsItemFiltersItemValueItem>;
export interface EvaluationsListResultItemDatasetsItemFiltersItem {
    key: EvaluationsListResultItemDatasetsItemFiltersItemKey;
    operator: EvaluationsListResultItemDatasetsItemFiltersItemOperator;
    value: EvaluationsListResultItemDatasetsItemFiltersItemValueList;
}
export type EvaluationsListResultItemDatasetsItemFiltersList = Array<EvaluationsListResultItemDatasetsItemFiltersItem>;
export interface EvaluationsListResultItemDatasetsItem {
    id: string;
    accountId: string;
    accountTag: string;
    createdAt: string;
    enable: boolean;
    filters: EvaluationsListResultItemDatasetsItemFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export type EvaluationsListResultItemDatasetsList = Array<EvaluationsListResultItemDatasetsItem>;
export type EvaluationsListResultItemResultsItem = EvaluationsCreateResponseResultsItem;
export type EvaluationsListResultItemResultsList = Array<EvaluationsCreateResponseResultsItem>;
export interface EvaluationsListResultItem {
    id: string;
    createdAt: string;
    datasets: EvaluationsListResultItemDatasetsList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
    processed: boolean;
    results: EvaluationsListResultItemResultsList;
    totalLogs: number;
}
export type EvaluationsListResultList = Array<EvaluationsListResultItem>;
export interface ListEvaluationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: EvaluationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type EvaluationTypesListRequestOrderByDirection = "asc" | "desc";
export interface ListEvaluationTypesRequest {
    accountId: string;
    orderBy?: string | undefined;
    orderByDirection?: EvaluationTypesListRequestOrderByDirection | (string & {}) | undefined;
    page?: number | undefined;
    perPage?: number | undefined;
}
export interface EvaluationTypesListResultItem {
    id: string;
    createdAt: string;
    description: string;
    enable: boolean;
    mandatory: boolean;
    modifiedAt: string;
    name: string;
    type: string;
}
export type EvaluationTypesListResultList = Array<EvaluationTypesListResultItem>;
export interface ListEvaluationTypesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: EvaluationTypesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type LogsListRequestDirection = "asc" | "desc";
export type LogsListRequestFiltersList = Array<string>;
export type LogsListRequestOrderBy = "created_at" | "provider" | "model" | "model_type" | "success" | "cached";
export type LogsListRequestOrderByDirection = "asc" | "desc";
export interface ListLogsRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    cached?: boolean | undefined;
    direction?: LogsListRequestDirection | (string & {}) | undefined;
    endDate?: string | undefined;
    feedback?: string | undefined;
    filters?: LogsListRequestFiltersList | undefined;
    maxCost?: number | undefined;
    maxDuration?: number | undefined;
    maxTokensIn?: number | undefined;
    maxTokensOut?: number | undefined;
    maxTotalTokens?: number | undefined;
    metaInfo?: boolean | undefined;
    minCost?: number | undefined;
    minDuration?: number | undefined;
    minTokensIn?: number | undefined;
    minTokensOut?: number | undefined;
    minTotalTokens?: number | undefined;
    /** Model filter. */
    model?: string | undefined;
    modelType?: string | undefined;
    orderBy?: LogsListRequestOrderBy | (string & {}) | undefined;
    orderByDirection?: LogsListRequestOrderByDirection | (string & {}) | undefined;
    page?: number | undefined;
    perPage?: number | undefined;
    provider?: string | undefined;
    requestContentType?: string | undefined;
    responseContentType?: string | undefined;
    /** Free-text search over log metadata. */
    search?: string | undefined;
    startDate?: string | undefined;
    success?: boolean | undefined;
}
export interface LogsListResultItem {
    id: string;
    cached: boolean;
    createdAt: string;
    duration: number;
    model: string;
    path: string;
    provider: string;
    success: boolean;
    tokensIn: number;
    tokensOut: number;
    /** Whether the request and response bodies were eligible to be stored. False when the request sent `cf-aig-collect-log-payload: false`, logging was off, or the gateway does not store bodies for the request. Null for logs written before this field existed. */
    collectLogPayload?: boolean | null | undefined;
    cost?: number | null | undefined;
    customCost?: boolean | null | undefined;
    metadata?: string | null | undefined;
    modelType?: string | null | undefined;
    requestContentType?: string | null | undefined;
    requestType?: string | null | undefined;
    responseContentType?: string | null | undefined;
    statusCode?: number | null | undefined;
    step?: number | null | undefined;
}
export type LogsListResultList = Array<LogsListResultItem>;
export interface ListLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListProviderConfigsRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    page?: number | undefined;
    perPage?: number | undefined;
}
export interface ProviderConfigsListResultItem {
    id: string;
    alias: string;
    defaultConfig: boolean;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    providerSlug: string;
    secretId: string;
    secretPreview: string;
    /** UTC date (YYYY-MM-DD) the gateway last selected this key to authenticate a request to the provider, whether or not the request succeeded. Updated at most once a day. Null if the gateway has not used the key since this field was introduced. */
    lastUsedAt?: string | null | undefined;
    rateLimit?: number | null | undefined;
    rateLimitPeriod?: number | null | undefined;
}
export type ProviderConfigsListResultList = Array<ProviderConfigsListResultItem>;
export interface ListProviderConfigsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ProviderConfigsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListVersionsDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
}
export type DynamicRoutingListVersionsResponseDataVersionsItemActive = "true" | "false";
export interface DynamicRoutingListVersionsResponseDataVersionsItem {
    active: DynamicRoutingListVersionsResponseDataVersionsItemActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null | undefined;
}
export type DynamicRoutingListVersionsResponseDataVersionsList = Array<DynamicRoutingListVersionsResponseDataVersionsItem>;
export interface DynamicRoutingListVersionsResponseData {
    orderBy: string;
    orderByDirection: string;
    page: number;
    perPage: number;
    versions: DynamicRoutingListVersionsResponseDataVersionsList;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListVersionsDynamicRoutingResponse {
    data: DynamicRoutingListVersionsResponseData;
}
export interface PatchDynamicRoutingRequest {
    accountId: string;
    gatewayId: string;
    id: string;
    name: string;
}
export type DynamicRoutingUpdateResponseRouteDeployment = DynamicRoutingCreateResponseDeployment;
export type DynamicRoutingUpdateResponseRouteElementsItemCase0OutputsNext = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingUpdateResponseRouteElementsItemCase0Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
export type DynamicRoutingUpdateResponseRouteElementsItemCase0Type = "start";
export interface DynamicRoutingUpdateResponseRouteElementsItemCase0 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase0Outputs;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase0Type;
}
export type DynamicRoutingUpdateResponseRouteElementsItemCase1OutputsFalse = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1OutputsTrue = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
export type DynamicRoutingUpdateResponseRouteElementsItemCase1Type = "conditional";
export interface DynamicRoutingUpdateResponseRouteElementsItemCase1 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase1Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase1Properties;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase1Type;
}
export type DynamicRoutingUpdateResponseRouteElementsItemCase2OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingUpdateResponseRouteElementsItemCase2Type = "percentage";
export interface DynamicRoutingUpdateResponseRouteElementsItemCase2 {
    id: string;
    outputs: DynamicRoutingUpdateResponseRouteElementsItemCase2OutputsMap;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase2Type;
}
export type DynamicRoutingUpdateResponseRouteElementsItemCase3OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingUpdateResponseRouteElementsItemCase3OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingUpdateResponseRouteElementsItemCase3Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingUpdateResponseRouteElementsItemCase3PropertiesLimitType = "count" | "cost";
export interface DynamicRoutingUpdateResponseRouteElementsItemCase3Properties {
    key: string;
    limit: number;
    limitType: DynamicRoutingUpdateResponseRouteElementsItemCase3PropertiesLimitType;
    window: number;
}
export type DynamicRoutingUpdateResponseRouteElementsItemCase3Type = "rate";
export interface DynamicRoutingUpdateResponseRouteElementsItemCase3 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingUpdateResponseRouteElementsItemCase3Properties;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase3Type;
}
export type DynamicRoutingUpdateResponseRouteElementsItemCase4OutputsFallback = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4OutputsSuccess = DynamicRoutingCreateDeploymentResponseElementsItemCase0OutputsNext;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4Outputs = DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4Properties = DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
export type DynamicRoutingUpdateResponseRouteElementsItemCase4Type = "model";
export interface DynamicRoutingUpdateResponseRouteElementsItemCase4 {
    id: string;
    outputs: DynamicRoutingCreateDeploymentResponseElementsItemCase3Outputs;
    properties: DynamicRoutingCreateDeploymentResponseElementsItemCase4Properties;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase4Type;
}
export type DynamicRoutingUpdateResponseRouteElementsItemCase5OutputsMap = {
    [key: string]: unknown | undefined;
};
export type DynamicRoutingUpdateResponseRouteElementsItemCase5Type = "end";
export interface DynamicRoutingUpdateResponseRouteElementsItemCase5 {
    id: string;
    outputs: DynamicRoutingUpdateResponseRouteElementsItemCase5OutputsMap;
    type: DynamicRoutingUpdateResponseRouteElementsItemCase5Type;
}
export type DynamicRoutingUpdateResponseRouteElementsItem = DynamicRoutingUpdateResponseRouteElementsItemCase0 | DynamicRoutingUpdateResponseRouteElementsItemCase1 | DynamicRoutingUpdateResponseRouteElementsItemCase2 | DynamicRoutingUpdateResponseRouteElementsItemCase3 | DynamicRoutingUpdateResponseRouteElementsItemCase4 | DynamicRoutingUpdateResponseRouteElementsItemCase5;
export type DynamicRoutingUpdateResponseRouteElementsList = Array<DynamicRoutingUpdateResponseRouteElementsItem>;
export type DynamicRoutingUpdateResponseRouteVersionActive = "true" | "false";
export interface DynamicRoutingUpdateResponseRouteVersion {
    active: DynamicRoutingUpdateResponseRouteVersionActive;
    createdAt: string;
    data: DynamicRoutingCreateRequestElementsList;
    versionId: string;
    isValid?: boolean | null | undefined;
}
export interface DynamicRoutingUpdateResponseRoute {
    id: string;
    accountTag: string;
    createdAt: string;
    deployment: DynamicRoutingCreateResponseDeployment;
    elements: DynamicRoutingUpdateResponseRouteElementsList;
    gatewayId: string;
    modifiedAt: string;
    name: string;
    version: DynamicRoutingUpdateResponseRouteVersion;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchDynamicRoutingResponse {
    route: DynamicRoutingUpdateResponseRoute;
}
export type LogsEditRequestMetadataValue = string | number | boolean;
export type LogsEditRequestMetadataMap = {
    [key: string]: LogsEditRequestMetadataValue | undefined;
};
export interface PatchLogRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
    feedback?: number | undefined;
    metadata?: LogsEditRequestMetadataMap | undefined;
    score?: number | undefined;
}
export type PatchLogResponse = unknown;
export interface RequestLogRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
}
export interface RequestLogResponse {
}
export interface ResponseLogRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
}
export interface ResponseLogResponse {
}
export interface StatusBillingTopupRequest {
    accountId: string;
    /** Top-up identifier to check status for. */
    paymentIntentId: string;
}
export type BillingTopupStatusResponseStatus = "completed" | "pending";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StatusBillingTopupResponse {
    paymentIntentId: string;
    status: BillingTopupStatusResponseStatus;
}
export type UpdateRequestDlpCase0Action = "BLOCK" | "FLAG";
export type UpdateRequestDlpCase0ProfilesList = Array<string>;
export interface UpdateRequestDlpCase0 {
    action: UpdateRequestDlpCase0Action | (string & {});
    enabled: boolean;
    profiles: UpdateRequestDlpCase0ProfilesList;
}
export type UpdateRequestDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export type UpdateRequestDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export type UpdateRequestDlpCase1PoliciesItemCheckList = Array<UpdateRequestDlpCase1PoliciesItemCheckItem | (string & {})>;
export type UpdateRequestDlpCase1PoliciesItemProfilesList = Array<string>;
export interface UpdateRequestDlpCase1PoliciesItem {
    id: string;
    action: UpdateRequestDlpCase1PoliciesItemAction | (string & {});
    check: UpdateRequestDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: UpdateRequestDlpCase1PoliciesItemProfilesList;
}
export type UpdateRequestDlpCase1PoliciesList = Array<UpdateRequestDlpCase1PoliciesItem>;
export interface UpdateRequestDlpCase1 {
    enabled: boolean;
    policies: UpdateRequestDlpCase1PoliciesList;
}
export type UpdateRequestDlp = UpdateRequestDlpCase0 | UpdateRequestDlpCase1;
export type UpdateRequestGuardrailsPromptP1 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS1 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS10 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS11 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS12 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS13 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS14 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS2 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS3 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS4 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS5 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS6 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS7 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS8 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsPromptS9 = "FLAG" | "BLOCK";
export interface UpdateRequestGuardrailsPrompt {
    p1?: UpdateRequestGuardrailsPromptP1 | (string & {}) | undefined;
    s1?: UpdateRequestGuardrailsPromptS1 | (string & {}) | undefined;
    s10?: UpdateRequestGuardrailsPromptS10 | (string & {}) | undefined;
    s11?: UpdateRequestGuardrailsPromptS11 | (string & {}) | undefined;
    s12?: UpdateRequestGuardrailsPromptS12 | (string & {}) | undefined;
    s13?: UpdateRequestGuardrailsPromptS13 | (string & {}) | undefined;
    s14?: UpdateRequestGuardrailsPromptS14 | (string & {}) | undefined;
    s2?: UpdateRequestGuardrailsPromptS2 | (string & {}) | undefined;
    s3?: UpdateRequestGuardrailsPromptS3 | (string & {}) | undefined;
    s4?: UpdateRequestGuardrailsPromptS4 | (string & {}) | undefined;
    s5?: UpdateRequestGuardrailsPromptS5 | (string & {}) | undefined;
    s6?: UpdateRequestGuardrailsPromptS6 | (string & {}) | undefined;
    s7?: UpdateRequestGuardrailsPromptS7 | (string & {}) | undefined;
    s8?: UpdateRequestGuardrailsPromptS8 | (string & {}) | undefined;
    s9?: UpdateRequestGuardrailsPromptS9 | (string & {}) | undefined;
}
export type UpdateRequestGuardrailsResponseP1 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS1 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS10 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS11 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS12 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS13 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS14 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS2 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS3 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS4 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS5 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS6 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS7 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS8 = "FLAG" | "BLOCK";
export type UpdateRequestGuardrailsResponseS9 = "FLAG" | "BLOCK";
export interface UpdateRequestGuardrailsResponse {
    p1?: UpdateRequestGuardrailsResponseP1 | (string & {}) | undefined;
    s1?: UpdateRequestGuardrailsResponseS1 | (string & {}) | undefined;
    s10?: UpdateRequestGuardrailsResponseS10 | (string & {}) | undefined;
    s11?: UpdateRequestGuardrailsResponseS11 | (string & {}) | undefined;
    s12?: UpdateRequestGuardrailsResponseS12 | (string & {}) | undefined;
    s13?: UpdateRequestGuardrailsResponseS13 | (string & {}) | undefined;
    s14?: UpdateRequestGuardrailsResponseS14 | (string & {}) | undefined;
    s2?: UpdateRequestGuardrailsResponseS2 | (string & {}) | undefined;
    s3?: UpdateRequestGuardrailsResponseS3 | (string & {}) | undefined;
    s4?: UpdateRequestGuardrailsResponseS4 | (string & {}) | undefined;
    s5?: UpdateRequestGuardrailsResponseS5 | (string & {}) | undefined;
    s6?: UpdateRequestGuardrailsResponseS6 | (string & {}) | undefined;
    s7?: UpdateRequestGuardrailsResponseS7 | (string & {}) | undefined;
    s8?: UpdateRequestGuardrailsResponseS8 | (string & {}) | undefined;
    s9?: UpdateRequestGuardrailsResponseS9 | (string & {}) | undefined;
}
export interface UpdateRequestGuardrails {
    prompt: UpdateRequestGuardrailsPrompt;
    response: UpdateRequestGuardrailsResponse;
}
export type UpdateRequestLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export type UpdateRequestOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export type UpdateRequestOtelItemContentType = "json" | "protobuf";
export interface UpdateRequestOtelItem {
    headers: UpdateRequestOtelItemHeadersMap;
    url: string;
    authorization?: string | undefined;
    contentType?: UpdateRequestOtelItemContentType | (string & {}) | undefined;
}
export type UpdateRequestOtelList = Array<UpdateRequestOtelItem>;
export type UpdateRequestRateLimitingTechnique = "fixed" | "sliding";
export type UpdateRequestRetryBackoff = "constant" | "linear" | "exponential";
export type UpdateRequestSpendLimitsRulesItemLimitType = "cost";
export type UpdateRequestSpendLimitsRulesItemModelMode = "filter";
export type UpdateRequestSpendLimitsRulesItemModelValuesList = Array<string>;
export interface UpdateRequestSpendLimitsRulesItemModel {
    mode: UpdateRequestSpendLimitsRulesItemModelMode | (string & {});
    values: UpdateRequestSpendLimitsRulesItemModelValuesList;
}
export type UpdateRequestSpendLimitsRulesItemProviderMode = "filter";
export type UpdateRequestSpendLimitsRulesItemProviderValuesList = Array<string>;
export interface UpdateRequestSpendLimitsRulesItemProvider {
    mode: UpdateRequestSpendLimitsRulesItemProviderMode | (string & {});
    values: UpdateRequestSpendLimitsRulesItemProviderValuesList;
}
export type UpdateRequestSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export interface UpdateRequestSpendLimitsRulesItem {
    /** exclusiveMinimum */
    limit: number;
    limitType: UpdateRequestSpendLimitsRulesItemLimitType | (string & {});
    /** exclusiveMinimum */
    window: number;
    id?: string | undefined;
    enabled?: boolean | undefined;
    metadata?: UntypedMetadataMap | undefined;
    model?: UpdateRequestSpendLimitsRulesItemModel | undefined;
    provider?: UpdateRequestSpendLimitsRulesItemProvider | undefined;
    technique?: UpdateRequestSpendLimitsRulesItemTechnique | (string & {}) | undefined;
}
export type UpdateRequestSpendLimitsRulesList = Array<UpdateRequestSpendLimitsRulesItem>;
export interface UpdateRequestSpendLimits {
    enabled?: boolean | undefined;
    rules?: UpdateRequestSpendLimitsRulesList | undefined;
}
export type UpdateRequestStripeUsageEventsItem = CreateRequestStripeUsageEventsItem;
export type UpdateRequestStripeUsageEventsList = Array<CreateRequestStripeUsageEventsItem>;
export interface UpdateRequestStripe {
    authorization: string;
    usageEvents: UpdateRequestStripeUsageEventsList;
}
export type UpdateRequestWorkersAiBillingMode = "postpaid" | "unified";
export interface UpdateAiGatewayRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number | null;
    collectLogs: boolean;
    rateLimitingInterval: number | null;
    rateLimitingLimit: number | null;
    /** Require authentication for gateway access. New gateways must have authentication enabled. Once enabled, authentication cannot be disabled. */
    authentication?: boolean | undefined;
    /** Requires customer-provided provider credentials and prevents fallback to Unified Billing. */
    byokOnly?: boolean | undefined;
    dlp?: UpdateRequestDlp | undefined;
    guardrails?: UpdateRequestGuardrails | undefined;
    logClassification?: boolean | undefined;
    logManagement?: number | undefined;
    logManagementStrategy?: UpdateRequestLogManagementStrategy | (string & {}) | undefined;
    logpush?: boolean | undefined;
    logpushPublicKey?: string | undefined;
    otel?: UpdateRequestOtelList | undefined;
    rateLimitingTechnique?: UpdateRequestRateLimitingTechnique | (string & {}) | undefined;
    /** Backoff strategy for retry delays */
    retryBackoff?: UpdateRequestRetryBackoff | (string & {}) | undefined;
    /** Delay between retry attempts in milliseconds (0-60000) */
    retryDelay?: number | undefined;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | undefined;
    spendLimits?: UpdateRequestSpendLimits | undefined;
    /** Secrets Store used by this gateway. Omit on update to keep the current store. Cannot be cleared while stored keys or secret references depend on it. */
    storeId?: string | undefined;
    stripe?: UpdateRequestStripe | undefined;
    /** Controls how Workers AI inference calls routed through this gateway are billed. 'postpaid' bills the account directly through Workers AI; 'unified' deducts credits via AI Gateway using neuron-based pricing and delegates billing to AI Gateway. */
    workersAiBillingMode?: UpdateRequestWorkersAiBillingMode | (string & {}) | undefined;
    zdr?: boolean | undefined;
}
export type UpdateResponseDlpCase0Action = "BLOCK" | "FLAG";
export type UpdateResponseDlpCase0ProfilesList = Array<string>;
export interface UpdateResponseDlpCase0 {
    action: UpdateResponseDlpCase0Action;
    enabled: boolean;
    profiles: UpdateResponseDlpCase0ProfilesList;
}
export type UpdateResponseDlpCase1PoliciesItemAction = "FLAG" | "BLOCK";
export type UpdateResponseDlpCase1PoliciesItemCheckItem = "REQUEST" | "RESPONSE";
export type UpdateResponseDlpCase1PoliciesItemCheckList = Array<UpdateResponseDlpCase1PoliciesItemCheckItem>;
export type UpdateResponseDlpCase1PoliciesItemProfilesList = Array<string>;
export interface UpdateResponseDlpCase1PoliciesItem {
    id: string;
    action: UpdateResponseDlpCase1PoliciesItemAction;
    check: UpdateResponseDlpCase1PoliciesItemCheckList;
    enabled: boolean;
    profiles: UpdateResponseDlpCase1PoliciesItemProfilesList;
}
export type UpdateResponseDlpCase1PoliciesList = Array<UpdateResponseDlpCase1PoliciesItem>;
export interface UpdateResponseDlpCase1 {
    enabled: boolean;
    policies: UpdateResponseDlpCase1PoliciesList;
}
export type UpdateResponseDlp = UpdateResponseDlpCase0 | UpdateResponseDlpCase1;
export type UpdateResponseFedrampLevel = "fedramp-medium" | "fedramp-high";
export type UpdateResponseFedrampMode = "prefer" | "require";
export type UpdateResponseGuardrailsPromptP1 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS1 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS10 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS11 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS12 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS13 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS14 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS2 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS3 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS4 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS5 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS6 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS7 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS8 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsPromptS9 = "FLAG" | "BLOCK";
export interface UpdateResponseGuardrailsPrompt {
    p1?: UpdateResponseGuardrailsPromptP1 | null | undefined;
    s1?: UpdateResponseGuardrailsPromptS1 | null | undefined;
    s10?: UpdateResponseGuardrailsPromptS10 | null | undefined;
    s11?: UpdateResponseGuardrailsPromptS11 | null | undefined;
    s12?: UpdateResponseGuardrailsPromptS12 | null | undefined;
    s13?: UpdateResponseGuardrailsPromptS13 | null | undefined;
    s14?: UpdateResponseGuardrailsPromptS14 | null | undefined;
    s2?: UpdateResponseGuardrailsPromptS2 | null | undefined;
    s3?: UpdateResponseGuardrailsPromptS3 | null | undefined;
    s4?: UpdateResponseGuardrailsPromptS4 | null | undefined;
    s5?: UpdateResponseGuardrailsPromptS5 | null | undefined;
    s6?: UpdateResponseGuardrailsPromptS6 | null | undefined;
    s7?: UpdateResponseGuardrailsPromptS7 | null | undefined;
    s8?: UpdateResponseGuardrailsPromptS8 | null | undefined;
    s9?: UpdateResponseGuardrailsPromptS9 | null | undefined;
}
export type UpdateResponseGuardrailsResponseP1 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS1 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS10 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS11 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS12 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS13 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS14 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS2 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS3 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS4 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS5 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS6 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS7 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS8 = "FLAG" | "BLOCK";
export type UpdateResponseGuardrailsResponseS9 = "FLAG" | "BLOCK";
export interface UpdateResponseGuardrailsResponse {
    p1?: UpdateResponseGuardrailsResponseP1 | null | undefined;
    s1?: UpdateResponseGuardrailsResponseS1 | null | undefined;
    s10?: UpdateResponseGuardrailsResponseS10 | null | undefined;
    s11?: UpdateResponseGuardrailsResponseS11 | null | undefined;
    s12?: UpdateResponseGuardrailsResponseS12 | null | undefined;
    s13?: UpdateResponseGuardrailsResponseS13 | null | undefined;
    s14?: UpdateResponseGuardrailsResponseS14 | null | undefined;
    s2?: UpdateResponseGuardrailsResponseS2 | null | undefined;
    s3?: UpdateResponseGuardrailsResponseS3 | null | undefined;
    s4?: UpdateResponseGuardrailsResponseS4 | null | undefined;
    s5?: UpdateResponseGuardrailsResponseS5 | null | undefined;
    s6?: UpdateResponseGuardrailsResponseS6 | null | undefined;
    s7?: UpdateResponseGuardrailsResponseS7 | null | undefined;
    s8?: UpdateResponseGuardrailsResponseS8 | null | undefined;
    s9?: UpdateResponseGuardrailsResponseS9 | null | undefined;
}
export interface UpdateResponseGuardrails {
    prompt: UpdateResponseGuardrailsPrompt;
    response: UpdateResponseGuardrailsResponse;
}
export type UpdateResponseLogManagementStrategy = "STOP_INSERTING" | "DELETE_OLDEST";
export type UpdateResponseOtelItemHeadersMap = {
    [key: string]: unknown | undefined;
};
export type UpdateResponseOtelItemContentType = "json" | "protobuf";
export interface UpdateResponseOtelItem {
    headers: UpdateResponseOtelItemHeadersMap;
    url: string;
    authorization?: string | null | undefined;
    contentType?: UpdateResponseOtelItemContentType | null | undefined;
}
export type UpdateResponseOtelList = Array<UpdateResponseOtelItem>;
export type UpdateResponseRateLimitingTechnique = "fixed" | "sliding";
export type UpdateResponseRetryBackoff = "constant" | "linear" | "exponential";
export type UpdateResponseSpendLimitsRulesItemLimitType = "cost";
export type UpdateResponseSpendLimitsRulesItemModelMode = "filter";
export type UpdateResponseSpendLimitsRulesItemModelValuesList = Array<string>;
export interface UpdateResponseSpendLimitsRulesItemModel {
    mode: UpdateResponseSpendLimitsRulesItemModelMode;
    values: UpdateResponseSpendLimitsRulesItemModelValuesList;
}
export type UpdateResponseSpendLimitsRulesItemProviderMode = "filter";
export type UpdateResponseSpendLimitsRulesItemProviderValuesList = Array<string>;
export interface UpdateResponseSpendLimitsRulesItemProvider {
    mode: UpdateResponseSpendLimitsRulesItemProviderMode;
    values: UpdateResponseSpendLimitsRulesItemProviderValuesList;
}
export type UpdateResponseSpendLimitsRulesItemTechnique = "fixed" | "sliding";
export interface UpdateResponseSpendLimitsRulesItem {
    /** exclusiveMinimum */
    limit: number;
    limitType: UpdateResponseSpendLimitsRulesItemLimitType;
    /** exclusiveMinimum */
    window: number;
    id?: string | null | undefined;
    enabled?: boolean | null | undefined;
    metadata?: UntypedMetadataMap | null | undefined;
    model?: UpdateResponseSpendLimitsRulesItemModel | null | undefined;
    provider?: UpdateResponseSpendLimitsRulesItemProvider | null | undefined;
    technique?: UpdateResponseSpendLimitsRulesItemTechnique | null | undefined;
}
export type UpdateResponseSpendLimitsRulesList = Array<UpdateResponseSpendLimitsRulesItem>;
export interface UpdateResponseSpendLimits {
    enabled?: boolean | null | undefined;
    rules?: UpdateResponseSpendLimitsRulesList | null | undefined;
}
export type UpdateResponseStripeUsageEventsItem = CreateRequestStripeUsageEventsItem;
export type UpdateResponseStripeUsageEventsList = Array<CreateRequestStripeUsageEventsItem>;
export interface UpdateResponseStripe {
    authorization: string;
    usageEvents: UpdateResponseStripeUsageEventsList;
}
export type UpdateResponseWorkersAiBillingMode = "postpaid" | "unified";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAiGatewayResponse {
    /** Unique identifier of the AI Gateway within the account. */
    id: string;
    cacheInvalidateOnUpdate: boolean;
    cacheTtl: number;
    collectLogs: boolean;
    createdAt: string;
    modifiedAt: string;
    rateLimitingInterval: number;
    rateLimitingLimit: number;
    /** Require authentication for gateway access. New gateways must have authentication enabled. Once enabled, authentication cannot be disabled. */
    authentication?: boolean | null | undefined;
    /** Requires customer-provided provider credentials and prevents fallback to Unified Billing. */
    byokOnly?: boolean | null | undefined;
    dlp?: UpdateResponseDlp | null | undefined;
    /** FedRAMP compliance level: fedramp-medium or fedramp-high. */
    fedrampLevel?: UpdateResponseFedrampLevel | null | undefined;
    /** FedRAMP enforcement mode. "prefer" prioritizes compliant connectors but allows fallback. "require" strictly filters. */
    fedrampMode?: UpdateResponseFedrampMode | null | undefined;
    guardrails?: UpdateResponseGuardrails | null | undefined;
    isDefault?: boolean | null | undefined;
    logClassification?: boolean | null | undefined;
    logManagement?: number | null | undefined;
    logManagementStrategy?: UpdateResponseLogManagementStrategy | null | undefined;
    logpush?: boolean | null | undefined;
    logpushPublicKey?: string | null | undefined;
    otel?: UpdateResponseOtelList | null | undefined;
    rateLimitingTechnique?: UpdateResponseRateLimitingTechnique | null | undefined;
    /** Backoff strategy for retry delays */
    retryBackoff?: UpdateResponseRetryBackoff | null | undefined;
    /** Delay between retry attempts in milliseconds (0-60000) */
    retryDelay?: number | null | undefined;
    /** Maximum number of retry attempts for failed requests (1-5) */
    retryMaxAttempts?: number | null | undefined;
    spendLimits?: UpdateResponseSpendLimits | null | undefined;
    /** Secrets Store used by this gateway. Omit on update to keep the current store. Cannot be cleared while stored keys or secret references depend on it. */
    storeId?: string | null | undefined;
    stripe?: UpdateResponseStripe | null | undefined;
    /** Controls how Workers AI inference calls routed through this gateway are billed. 'postpaid' bills the account directly through Workers AI; 'unified' deducts credits via AI Gateway using neuron-based pricing and delegates billing to AI Gateway. */
    workersAiBillingMode?: UpdateResponseWorkersAiBillingMode | null | undefined;
    zdr?: boolean | null | undefined;
}
export type DatasetsUpdateRequestFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type DatasetsUpdateRequestFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type DatasetsUpdateRequestFiltersItemValueItem = string | number | boolean;
export type DatasetsUpdateRequestFiltersItemValueList = Array<DatasetsUpdateRequestFiltersItemValueItem>;
export interface DatasetsUpdateRequestFiltersItem {
    key: DatasetsUpdateRequestFiltersItemKey | (string & {});
    operator: DatasetsUpdateRequestFiltersItemOperator | (string & {});
    value: DatasetsUpdateRequestFiltersItemValueList;
}
export type DatasetsUpdateRequestFiltersList = Array<DatasetsUpdateRequestFiltersItem>;
export interface UpdateDatasetRequest {
    accountId: string;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    id: string;
    enable: boolean;
    filters: DatasetsUpdateRequestFiltersList;
    name: string;
}
export type DatasetsUpdateResponseFiltersItemKey = "created_at" | "request_content_type" | "response_content_type" | "success" | "cached" | "provider" | "model" | "cost" | "tokens" | "tokens_in" | "tokens_out" | "duration" | "feedback";
export type DatasetsUpdateResponseFiltersItemOperator = "eq" | "contains" | "lt" | "gt";
export type DatasetsUpdateResponseFiltersItemValueItem = string | number | boolean;
export type DatasetsUpdateResponseFiltersItemValueList = Array<DatasetsUpdateResponseFiltersItemValueItem>;
export interface DatasetsUpdateResponseFiltersItem {
    key: DatasetsUpdateResponseFiltersItemKey;
    operator: DatasetsUpdateResponseFiltersItemOperator;
    value: DatasetsUpdateResponseFiltersItemValueList;
}
export type DatasetsUpdateResponseFiltersList = Array<DatasetsUpdateResponseFiltersItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateDatasetResponse {
    id: string;
    createdAt: string;
    enable: boolean;
    filters: DatasetsUpdateResponseFiltersList;
    /** Unique identifier of the AI Gateway within the account. */
    gatewayId: string;
    modifiedAt: string;
    name: string;
}
export type BillingUsageHistoryRequestValueGroupingWindow = "day" | "hour";
export interface UsageHistoryBillingRequest {
    accountId: string;
    /** Grouping window for usage data. */
    valueGroupingWindow: BillingUsageHistoryRequestValueGroupingWindow | (string & {});
    /** End time as Unix timestamp in milliseconds. */
    endTime?: number | undefined;
    /** Start time as Unix timestamp in milliseconds. */
    startTime?: number | undefined;
}
export interface BillingUsageHistoryResponseHistoryItem {
    id: string;
    /** AI Gateway usage cost in the window, in US dollars. */
    aggregatedValue: number;
    endTime: number;
    startTime: number;
}
export type BillingUsageHistoryResponseHistoryList = Array<BillingUsageHistoryResponseHistoryItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UsageHistoryBillingResponse {
    history: BillingUsageHistoryResponseHistoryList;
}
export type CreateAiGatewayError = GatewayAlreadyExists | GatewayAuthenticationRequired | CloudflareOpError;
/** Creates an AI Gateway in the account with the specified caching, rate limiting, logging, and authentication settings. The gateway ID appears in request URLs and must be unique within the account. */
export declare const createAiGateway: API.OperationMethod<CreateAiGatewayRequest, CreateAiGatewayResponse, CreateAiGatewayError, CloudflareOpContext>;
export type CreateBillingSpendingLimitError = NoManualTopup | AiGatewaySpendingLimitDeprecated | CloudflareOpError;
/** Deprecated: spending limits can no longer be created, enabled, or modified and this endpoint always responds 403. Use the new AI Gateway spend limits instead: https://developers.cloudflare.com/ai-gateway/features/spend-limits/. Existing limits can be removed via DELETE /spending-limit. */
export declare const createBillingSpendingLimit: API.OperationMethod<CreateBillingSpendingLimitRequest, CreateBillingSpendingLimitResponse, CreateBillingSpendingLimitError, CloudflareOpContext>;
export type CreateBillingTopupError = CloudflareOpError;
/** Create a credit top-up for the given account, charged to the account's default payment method. Requires a dashboard session; API token, OAuth, and service credentials receive 403. */
export declare const createBillingTopup: API.OperationMethod<CreateBillingTopupRequest, CreateBillingTopupResponse, CreateBillingTopupError, CloudflareOpContext>;
export type CreateBillingTopupConfigError = CloudflareOpError;
/** Configure auto top-up with a balance threshold and top-up amount. Requests that add a payment method first return authentication details. The configuration is saved only after the authenticated setup is submitted. Dashboard sessions only: API token, OAuth, and service credentials are rejected with 403. */
export declare const createBillingTopupConfig: API.OperationMethod<CreateBillingTopupConfigRequest, CreateBillingTopupConfigResponse, CreateBillingTopupConfigError, CloudflareOpContext>;
export type CreateCustomProviderError = CloudflareOpError;
/** Creates an account-level custom provider that forwards AI Gateway requests to the HTTPS base URL you supply. Requests reference the provider as `custom-{slug}`, so the slug must be unique within the account. */
export declare const createCustomProvider: API.OperationMethod<CreateCustomProviderRequest, CreateCustomProviderResponse, CreateCustomProviderError, CloudflareOpContext>;
export type CreateDatasetError = GatewayNotFound | DatasetNameAlreadyExists | CloudflareOpError;
/** Creates a dataset that selects gateway logs matching the specified filters for use in evaluations. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, CloudflareOpContext>;
export type CreateDeploymentDynamicRoutingError = RouteNotFound | CloudflareOpError;
/** Deploys the specified version of a dynamic route so that it serves traffic. Deploy an earlier version to roll back. */
export declare const createDeploymentDynamicRouting: API.OperationMethod<CreateDeploymentDynamicRoutingRequest, CreateDeploymentDynamicRoutingResponse, CreateDeploymentDynamicRoutingError, CloudflareOpContext>;
export type CreateDynamicRoutingError = RouteAlreadyExists | GatewayNotFound | CloudflareOpError;
/** Creates a dynamic route on an AI Gateway from the specified routing elements. Clients call the route by using `dynamic/{name}` as the model name. */
export declare const createDynamicRouting: API.OperationMethod<CreateDynamicRoutingRequest, CreateDynamicRoutingResponse, CreateDynamicRoutingError, CloudflareOpContext>;
export type CreateEvaluationError = GatewayNotFound | EvaluationNameAlreadyExists | CloudflareOpError;
/** Creates an evaluation that scores the logs in a dataset with the specified evaluator types. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const createEvaluation: API.OperationMethod<CreateEvaluationRequest, CreateEvaluationResponse, CreateEvaluationError, CloudflareOpContext>;
export type CreateProviderConfigError = ProviderConfigSecretNotFound | ProviderConfigAlreadyExists | GatewayNotFound | CloudflareOpError;
/** Stores an upstream AI provider API key for an AI Gateway in the Secrets Store configured on the gateway, with an optional rate limit. Pass `secret` to store a new key, or omit it to use an existing Secrets Store secret. */
export declare const createProviderConfig: API.OperationMethod<CreateProviderConfigRequest, CreateProviderConfigResponse, CreateProviderConfigError, CloudflareOpContext>;
export type CreateVersionDynamicRoutingError = RouteNotFound | CloudflareOpError;
/** Creates a new version of a dynamic route from the specified routing elements. The version does not serve traffic until you deploy it. */
export declare const createVersionDynamicRouting: API.OperationMethod<CreateVersionDynamicRoutingRequest, CreateVersionDynamicRoutingResponse, CreateVersionDynamicRoutingError, CloudflareOpContext>;
export type CreditBalanceBillingError = CloudflareOpError;
/** Retrieve the current credit balance, payment method info, and top-up configuration. */
export declare const creditBalanceBilling: API.OperationMethod<CreditBalanceBillingRequest, CreditBalanceBillingResponse, CreditBalanceBillingError, CloudflareOpContext>;
export type DeleteAiGatewayError = GatewayNotFound | CloudflareOpError;
/** Permanently deletes an AI Gateway, its configuration, and its stored logs. */
export declare const deleteAiGateway: API.OperationMethod<DeleteAiGatewayRequest, DeleteAiGatewayResponse, DeleteAiGatewayError, CloudflareOpContext>;
export type DeleteBillingSpendingLimitError = CloudflareOpError;
/** Remove the spending limit for the account. */
export declare const deleteBillingSpendingLimit: API.OperationMethod<DeleteBillingSpendingLimitRequest, DeleteBillingSpendingLimitResponse, DeleteBillingSpendingLimitError, CloudflareOpContext>;
export type DeleteBillingTopupConfigError = CloudflareOpError;
/** Remove the auto top-up configuration for the account. Dashboard sessions only: API token, OAuth, and service credentials are rejected with 403. */
export declare const deleteBillingTopupConfig: API.OperationMethod<DeleteBillingTopupConfigRequest, DeleteBillingTopupConfigResponse, DeleteBillingTopupConfigError, CloudflareOpContext>;
export type DeleteCustomProviderError = CloudflareOpError;
/** Deletes a custom provider and every pricing rule that belongs to it. */
export declare const deleteCustomProvider: API.OperationMethod<DeleteCustomProviderRequest, DeleteCustomProviderResponse, DeleteCustomProviderError, CloudflareOpContext>;
export type DeleteDatasetError = DatasetNotFound | CloudflareOpError;
/** Deletes a dataset. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, CloudflareOpContext>;
export type DeleteDynamicRoutingError = RouteNotFound | GatewayNotFound | CloudflareOpError;
/** Deletes a dynamic route from an AI Gateway. */
export declare const deleteDynamicRouting: API.OperationMethod<DeleteDynamicRoutingRequest, DeleteDynamicRoutingResponse, DeleteDynamicRoutingError, CloudflareOpContext>;
export type DeleteEvaluationError = EvaluationNotFound | CloudflareOpError;
/** Deletes an evaluation and its results. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const deleteEvaluation: API.OperationMethod<DeleteEvaluationRequest, DeleteEvaluationResponse, DeleteEvaluationError, CloudflareOpContext>;
export type DeleteLogError = CloudflareOpError;
/** Deletes gateway log entries matching the specified criteria. */
export declare const deleteLog: API.OperationMethod<DeleteLogRequest, DeleteLogResponse, DeleteLogError, CloudflareOpContext>;
export type DeleteProviderConfigError = ProviderConfigNotFound | CloudflareOpError;
export declare const deleteProviderConfig: API.OperationMethod<DeleteProviderConfigRequest, DeleteProviderConfigResponse, DeleteProviderConfigError, CloudflareOpContext>;
export type GetAiGatewayError = GatewayNotFound | CloudflareOpError;
/** Retrieves the configuration of an AI Gateway. */
export declare const getAiGateway: API.OperationMethod<GetAiGatewayRequest, GetAiGatewayResponse, GetAiGatewayError, CloudflareOpContext>;
export type GetBillingSpendingLimitError = CloudflareOpError;
/** Retrieve the current spending limit configuration for the account. */
export declare const getBillingSpendingLimit: API.OperationMethod<GetBillingSpendingLimitRequest, GetBillingSpendingLimitResponse, GetBillingSpendingLimitError, CloudflareOpContext>;
export type GetBillingTopupConfigError = CloudflareOpError;
/** Retrieve the current auto top-up threshold, amount, and any error state. */
export declare const getBillingTopupConfig: API.OperationMethod<GetBillingTopupConfigRequest, GetBillingTopupConfigResponse, GetBillingTopupConfigError, CloudflareOpContext>;
export type GetCustomProviderError = CloudflareOpError;
/** Retrieves a custom provider, including its slug, base URL, and custom headers. */
export declare const getCustomProvider: API.OperationMethod<GetCustomProviderRequest, GetCustomProviderResponse, GetCustomProviderError, CloudflareOpContext>;
export type GetDatasetError = DatasetNotFound | CloudflareOpError;
/** Retrieves a dataset and its log filters. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const getDataset: API.OperationMethod<GetDatasetRequest, GetDatasetResponse, GetDatasetError, CloudflareOpContext>;
export type GetDynamicRoutingError = RouteNotFound | GatewayNotFound | CloudflareOpError;
/** Retrieves a dynamic route with its routing elements, active version, and current deployment. */
export declare const getDynamicRouting: API.OperationMethod<GetDynamicRoutingRequest, GetDynamicRoutingResponse, GetDynamicRoutingError, CloudflareOpContext>;
export type GetEvaluationError = EvaluationNotFound | CloudflareOpError;
/** Retrieves an evaluation and its results. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const getEvaluation: API.OperationMethod<GetEvaluationRequest, GetEvaluationResponse, GetEvaluationError, CloudflareOpContext>;
export type GetLogError = CloudflareOpError;
/** Retrieves detailed information for a specific AI Gateway log entry. */
export declare const getLog: API.OperationMethod<GetLogRequest, GetLogResponse, GetLogError, CloudflareOpContext>;
export type GetUrlError = CloudflareOpError;
/** Retrieves the endpoint URL for an AI Gateway. */
export declare const getUrl: API.OperationMethod<GetUrlRequest, GetUrlResponse, GetUrlError, CloudflareOpContext>;
export type GetVersionDynamicRoutingError = CloudflareOpError;
/** Retrieves a saved version of a dynamic route, including its routing elements. */
export declare const getVersionDynamicRouting: API.OperationMethod<GetVersionDynamicRoutingRequest, GetVersionDynamicRoutingResponse, GetVersionDynamicRoutingError, CloudflareOpContext>;
export type InvoiceHistoryBillingError = CloudflareOpError;
/** Retrieve a list of past invoices with pagination, optionally filtered by type. */
export declare const invoiceHistoryBilling: API.OperationMethod<InvoiceHistoryBillingRequest, InvoiceHistoryBillingResponse, InvoiceHistoryBillingError, CloudflareOpContext>;
export type InvoicePreviewBillingError = CloudflareOpError;
/** Retrieve a preview of the upcoming invoice including line items and tax. */
export declare const invoicePreviewBilling: API.OperationMethod<InvoicePreviewBillingRequest, InvoicePreviewBillingResponse, InvoicePreviewBillingError, CloudflareOpContext>;
export type ListAiGatewaysError = CloudflareOpError;
/** Lists the AI Gateways in the account. Use `search` to filter by gateway ID. */
export declare const listAiGateways: API.PaginatedOperationMethod<ListAiGatewaysRequest, ListAiGatewaysResponse, ListAiGatewaysError, CloudflareOpContext, ListResultItem>;
export type ListCustomProvidersError = CloudflareOpError;
/** Lists the custom providers configured for the account, ordered by position and then name. */
export declare const listCustomProviders: API.PaginatedOperationMethod<ListCustomProvidersRequest, ListCustomProvidersResponse, ListCustomProvidersError, CloudflareOpContext, CustomProvidersListResultItem>;
export type ListDatasetsError = GatewayNotFound | CloudflareOpError;
/** Lists the datasets defined for an AI Gateway. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, CloudflareOpContext, DatasetsListResultItem>;
export type ListDeploymentsDynamicRoutingError = CloudflareOpError;
/** Lists the deployment history of a dynamic route. */
export declare const listDeploymentsDynamicRouting: API.OperationMethod<ListDeploymentsDynamicRoutingRequest, ListDeploymentsDynamicRoutingResponse, ListDeploymentsDynamicRoutingError, CloudflareOpContext>;
export type ListDynamicRoutingsError = GatewayNotFound | CloudflareOpError;
/** Lists the dynamic routes configured on an AI Gateway. */
export declare const listDynamicRoutings: API.OperationMethod<ListDynamicRoutingsRequest, ListDynamicRoutingsResponse, ListDynamicRoutingsError, CloudflareOpContext>;
export type ListEvaluationsError = CloudflareOpError;
/** Lists the evaluations run on an AI Gateway. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const listEvaluations: API.PaginatedOperationMethod<ListEvaluationsRequest, ListEvaluationsResponse, ListEvaluationsError, CloudflareOpContext, EvaluationsListResultItem>;
export type ListEvaluationTypesError = CloudflareOpError;
/** Lists the evaluator types that evaluations can use to score AI Gateway responses. Evaluations are deprecated and unavailable to new accounts. */
export declare const listEvaluationTypes: API.PaginatedOperationMethod<ListEvaluationTypesRequest, ListEvaluationTypesResponse, ListEvaluationTypesError, CloudflareOpContext, EvaluationTypesListResultItem>;
export type ListLogsError = CloudflareOpError;
/** Lists request/response log entries for the AI gateway with filtering and pagination. */
export declare const listLogs: API.PaginatedOperationMethod<ListLogsRequest, ListLogsResponse, ListLogsError, CloudflareOpContext, LogsListResultItem>;
export type ListProviderConfigsError = CloudflareOpError;
/** Lists the provider keys stored for an AI Gateway. Responses show a masked preview of each key, never the key itself. */
export declare const listProviderConfigs: API.PaginatedOperationMethod<ListProviderConfigsRequest, ListProviderConfigsResponse, ListProviderConfigsError, CloudflareOpContext, ProviderConfigsListResultItem>;
export type ListVersionsDynamicRoutingError = CloudflareOpError;
/** Lists the saved versions of a dynamic route. */
export declare const listVersionsDynamicRouting: API.OperationMethod<ListVersionsDynamicRoutingRequest, ListVersionsDynamicRoutingResponse, ListVersionsDynamicRoutingError, CloudflareOpContext>;
export type PatchDynamicRoutingError = RouteNotFound | RouteAlreadyExists | CloudflareOpError;
/** Updates the name of a dynamic route. To change routing behaviour, create and deploy a new version. */
export declare const patchDynamicRouting: API.OperationMethod<PatchDynamicRoutingRequest, PatchDynamicRoutingResponse, PatchDynamicRoutingError, CloudflareOpContext>;
export type PatchLogError = CloudflareOpError;
/** Updates metadata for an AI Gateway log entry. */
export declare const patchLog: API.OperationMethod<PatchLogRequest, PatchLogResponse, PatchLogError, CloudflareOpContext>;
export type RequestLogError = CloudflareOpError;
/** Retrieves the original request payload for an AI Gateway log entry. */
export declare const requestLog: API.OperationMethod<RequestLogRequest, RequestLogResponse, RequestLogError, CloudflareOpContext>;
export type ResponseLogError = CloudflareOpError;
/** Retrieves the response payload for an AI Gateway log entry. */
export declare const responseLog: API.OperationMethod<ResponseLogRequest, ResponseLogResponse, ResponseLogError, CloudflareOpContext>;
export type StatusBillingTopupError = CloudflareOpError;
/** Get the payment processing status of a top-up by its top-up identifier. */
export declare const statusBillingTopup: API.OperationMethod<StatusBillingTopupRequest, StatusBillingTopupResponse, StatusBillingTopupError, CloudflareOpContext>;
export type UpdateAiGatewayError = GatewayNotFound | CloudflareOpError;
/** Updates the configuration of an AI Gateway, such as its caching, rate limiting, logging, and authentication settings. */
export declare const updateAiGateway: API.OperationMethod<UpdateAiGatewayRequest, UpdateAiGatewayResponse, UpdateAiGatewayError, CloudflareOpContext>;
export type UpdateDatasetError = DatasetNotFound | CloudflareOpError;
/** Replaces the name, log filters, and enabled state of a dataset. Evaluations and datasets are deprecated and unavailable to new accounts. */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest, UpdateDatasetResponse, UpdateDatasetError, CloudflareOpContext>;
export type UsageHistoryBillingError = CloudflareOpError;
/** Retrieve AI Gateway usage cost, in US dollars, aggregated by hour or day for the given time range. */
export declare const usageHistoryBilling: API.OperationMethod<UsageHistoryBillingRequest, UsageHistoryBillingResponse, UsageHistoryBillingError, CloudflareOpContext>;
//# sourceMappingURL=ai_gateway.d.ts.map