import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccountSuspendedException_base: S.TaggedErrorClass<"AccountSuspendedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountSuspendedException extends /*@__PURE__*/ AccountSuspendedException_base {
}
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MailFromDomainNotVerifiedException_base: S.TaggedErrorClass<"MailFromDomainNotVerifiedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MailFromDomainNotVerifiedException extends /*@__PURE__*/ MailFromDomainNotVerifiedException_base {
}
declare const MessageRejected_base: S.TaggedErrorClass<"MessageRejected", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MessageRejected extends /*@__PURE__*/ MessageRejected_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const SendingPausedException_base: S.TaggedErrorClass<"SendingPausedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SendingPausedException extends /*@__PURE__*/ SendingPausedException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type Identity = string;
export type EmailAddress = string;
export type CertificateArn = string;
export interface AssociateEmailIdentityCertificateRequest {
    EmailIdentity: string;
    FromAddress?: string | undefined;
    CertificateArn: string;
}
export interface AssociateEmailIdentityCertificateResponse {
}
export type QueryIdentifier = string;
export type MetricNamespace = "VDM" | (string & {});
export type Metric = "SEND" | "COMPLAINT" | "PERMANENT_BOUNCE" | "TRANSIENT_BOUNCE" | "OPEN" | "CLICK" | "DELIVERY" | "DELIVERY_OPEN" | "DELIVERY_CLICK" | "DELIVERY_COMPLAINT" | (string & {});
export type MetricDimensionName = "EMAIL_IDENTITY" | "CONFIGURATION_SET" | "ISP" | "TENANT_NAME" | (string & {});
export type MetricDimensionValue = string;
export type Dimensions = {
    [key in MetricDimensionName]?: string | undefined;
};
export interface BatchGetMetricDataQuery {
    Id: string;
    Namespace: MetricNamespace;
    Metric: Metric;
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
    StartDate: Date;
    EndDate: Date;
}
export type BatchGetMetricDataQueries = BatchGetMetricDataQuery[];
export interface BatchGetMetricDataRequest {
    Queries: BatchGetMetricDataQuery[];
}
export type TimestampList = Date[];
export type Counter = number;
export type MetricValueList = number[];
export interface MetricDataResult {
    Id?: string | undefined;
    Timestamps?: Date[] | undefined;
    Values?: number[] | undefined;
}
export type MetricDataResultList = MetricDataResult[];
export type QueryErrorCode = "INTERNAL_FAILURE" | "ACCESS_DENIED" | (string & {});
export type QueryErrorMessage = string;
export interface MetricDataError {
    Id?: string | undefined;
    Code?: QueryErrorCode | undefined;
    Message?: string | undefined;
}
export type MetricDataErrorList = MetricDataError[];
export interface BatchGetMetricDataResponse {
    Results?: MetricDataResult[] | undefined;
    Errors?: MetricDataError[] | undefined;
}
export type JobId = string;
export interface CancelExportJobRequest {
    JobId: string;
}
export interface CancelExportJobResponse {
}
export type ConfigurationSetName = string;
export type CustomRedirectDomain = string;
export type HttpsPolicy = "REQUIRE" | "REQUIRE_OPEN_ONLY" | "OPTIONAL" | (string & {});
export interface TrackingOptions {
    CustomRedirectDomain: string;
    HttpsPolicy?: HttpsPolicy | undefined;
}
export type TlsPolicy = "REQUIRE" | "OPTIONAL" | (string & {});
export type PoolName = string;
export type MaxDeliverySeconds = number;
export interface DeliveryOptions {
    TlsPolicy?: TlsPolicy | undefined;
    SendingPoolName?: string | undefined;
    MaxDeliverySeconds?: number | undefined;
}
export type Enabled = boolean;
export type LastFreshStart = Date;
export interface ReputationOptions {
    ReputationMetricsEnabled?: boolean | undefined;
    LastFreshStart?: Date | undefined;
}
export interface SendingOptions {
    SendingEnabled?: boolean | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type SuppressionListReason = "BOUNCE" | "COMPLAINT" | (string & {});
export type SuppressionListReasons = SuppressionListReason[];
export type SuppressionListScope = "ACCOUNT" | "TENANT" | (string & {});
export type FeatureStatus = "ENABLED" | "DISABLED" | (string & {});
export type SuppressionConfidenceVerdictThreshold = "MEDIUM" | "HIGH" | "MANAGED" | (string & {});
export interface SuppressionConfidenceThreshold {
    ConfidenceVerdictThreshold: SuppressionConfidenceVerdictThreshold;
}
export interface SuppressionConditionThreshold {
    ConditionThresholdEnabled: FeatureStatus;
    OverallConfidenceThreshold?: SuppressionConfidenceThreshold | undefined;
}
export interface SuppressionValidationOptions {
    ConditionThreshold: SuppressionConditionThreshold;
}
export interface SuppressionOptions {
    SuppressedReasons?: SuppressionListReason[] | undefined;
    SuppressionScope?: SuppressionListScope | undefined;
    ValidationOptions?: SuppressionValidationOptions | undefined;
}
export interface DashboardOptions {
    EngagementMetrics?: FeatureStatus | undefined;
}
export interface GuardianOptions {
    OptimizedSharedDelivery?: FeatureStatus | undefined;
}
export interface VdmOptions {
    DashboardOptions?: DashboardOptions | undefined;
    GuardianOptions?: GuardianOptions | undefined;
}
export type ArchiveArn = string;
export interface ArchivingOptions {
    ArchiveArn?: string | undefined;
}
export interface DefaultSigningScheme {
}
export type SignatureFormat = "DETACHED" | (string & {});
export interface SmimeSigningScheme {
    SignatureFormat?: SignatureFormat | undefined;
}
export type SigningScheme = {
    DefaultScheme: DefaultSigningScheme;
    SmimeScheme?: undefined;
} | {
    DefaultScheme?: undefined;
    SmimeScheme: SmimeSigningScheme;
};
export interface MessageSecurityOptions {
    SigningScheme?: SigningScheme | undefined;
}
export interface CreateConfigurationSetRequest {
    ConfigurationSetName: string;
    TrackingOptions?: TrackingOptions | undefined;
    DeliveryOptions?: DeliveryOptions | undefined;
    ReputationOptions?: ReputationOptions | undefined;
    SendingOptions?: SendingOptions | undefined;
    Tags?: Tag[] | undefined;
    SuppressionOptions?: SuppressionOptions | undefined;
    VdmOptions?: VdmOptions | undefined;
    ArchivingOptions?: ArchivingOptions | undefined;
    MessageSecurityOptions?: MessageSecurityOptions | undefined;
}
export interface CreateConfigurationSetResponse {
}
export type EventDestinationName = string;
export type EventType = "SEND" | "REJECT" | "BOUNCE" | "COMPLAINT" | "DELIVERY" | "OPEN" | "CLICK" | "RENDERING_FAILURE" | "DELIVERY_DELAY" | "SUBSCRIPTION" | (string & {});
export type EventTypes = EventType[];
export type AmazonResourceName = string;
export interface KinesisFirehoseDestination {
    IamRoleArn: string;
    DeliveryStreamArn: string;
}
export type DimensionName = string;
export type DimensionValueSource = "MESSAGE_TAG" | "EMAIL_HEADER" | "LINK_TAG" | (string & {});
export type DefaultDimensionValue = string;
export interface CloudWatchDimensionConfiguration {
    DimensionName: string;
    DimensionValueSource: DimensionValueSource;
    DefaultDimensionValue: string;
}
export type CloudWatchDimensionConfigurations = CloudWatchDimensionConfiguration[];
export interface CloudWatchDestination {
    DimensionConfigurations: CloudWatchDimensionConfiguration[];
}
export interface SnsDestination {
    TopicArn: string;
}
export interface EventBridgeDestination {
    EventBusArn: string;
}
export interface PinpointDestination {
    ApplicationArn?: string | undefined;
}
export interface EventDestinationDefinition {
    Enabled?: boolean | undefined;
    MatchingEventTypes?: EventType[] | undefined;
    KinesisFirehoseDestination?: KinesisFirehoseDestination | undefined;
    CloudWatchDestination?: CloudWatchDestination | undefined;
    SnsDestination?: SnsDestination | undefined;
    EventBridgeDestination?: EventBridgeDestination | undefined;
    PinpointDestination?: PinpointDestination | undefined;
}
export interface CreateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
    EventDestination: EventDestinationDefinition;
}
export interface CreateConfigurationSetEventDestinationResponse {
}
export type ContactListName = string;
export type TopicName = string;
export type SubscriptionStatus = "OPT_IN" | "OPT_OUT" | (string & {});
export interface TopicPreference {
    TopicName: string;
    SubscriptionStatus: SubscriptionStatus;
}
export type TopicPreferenceList = TopicPreference[];
export type UnsubscribeAll = boolean;
export type AttributesData = string;
export interface CreateContactRequest {
    ContactListName: string;
    EmailAddress: string;
    TopicPreferences?: TopicPreference[] | undefined;
    UnsubscribeAll?: boolean | undefined;
    AttributesData?: string | undefined;
}
export interface CreateContactResponse {
}
export type DisplayName = string;
export type Description = string;
export interface Topic {
    TopicName: string;
    DisplayName: string;
    Description?: string | undefined;
    DefaultSubscriptionStatus: SubscriptionStatus;
}
export type Topics = Topic[];
export interface CreateContactListRequest {
    ContactListName: string;
    Topics?: Topic[] | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateContactListResponse {
}
export type EmailTemplateName = string;
export type EmailTemplateSubject = string;
export type TemplateContent = string;
export type SuccessRedirectionURL = string;
export type FailureRedirectionURL = string;
export interface CreateCustomVerificationEmailTemplateRequest {
    TemplateName: string;
    FromEmailAddress: string;
    TemplateSubject: string;
    TemplateContent: string;
    Tags?: Tag[] | undefined;
    SuccessRedirectionURL: string;
    FailureRedirectionURL: string;
}
export interface CreateCustomVerificationEmailTemplateResponse {
}
export type ScalingMode = "STANDARD" | "MANAGED" | (string & {});
export interface CreateDedicatedIpPoolRequest {
    PoolName: string;
    Tags?: Tag[] | undefined;
    ScalingMode?: ScalingMode | undefined;
}
export interface CreateDedicatedIpPoolResponse {
}
export type ReportName = string;
export type MessageData = string;
export type Charset = string;
export interface Content {
    Data: string;
    Charset?: string | undefined;
}
export interface Body {
    Text?: Content | undefined;
    Html?: Content | undefined;
}
export type MessageHeaderName = string;
export type MessageHeaderValue = string;
export interface MessageHeader {
    Name: string;
    Value: string;
}
export type MessageHeaderList = MessageHeader[];
export type RawAttachmentData = Uint8Array;
export type AttachmentContentDisposition = "ATTACHMENT" | "INLINE" | (string & {});
export type AttachmentFileName = string;
export type AttachmentContentDescription = string;
export type AttachmentContentId = string;
export type AttachmentContentTransferEncoding = "BASE64" | "QUOTED_PRINTABLE" | "SEVEN_BIT" | (string & {});
export type AttachmentContentType = string;
export interface Attachment {
    RawContent: Uint8Array;
    ContentDisposition?: AttachmentContentDisposition | undefined;
    FileName: string;
    ContentDescription?: string | undefined;
    ContentId?: string | undefined;
    ContentTransferEncoding?: AttachmentContentTransferEncoding | undefined;
    ContentType?: string | undefined;
}
export type AttachmentList = Attachment[];
export interface Message {
    Subject: Content;
    Body: Body;
    Headers?: MessageHeader[] | undefined;
    Attachments?: Attachment[] | undefined;
}
export type RawMessageData = Uint8Array;
export interface RawMessage {
    Data: Uint8Array;
}
export type EmailTemplateText = string;
export type EmailTemplateHtml = string;
export interface EmailTemplateContent {
    Subject?: string | undefined;
    Text?: string | undefined;
    Html?: string | undefined;
}
export type EmailTemplateData = string;
export interface Template {
    TemplateName?: string | undefined;
    TemplateArn?: string | undefined;
    TemplateContent?: EmailTemplateContent | undefined;
    TemplateData?: string | undefined;
    Headers?: MessageHeader[] | undefined;
    Attachments?: Attachment[] | undefined;
}
export interface EmailContent {
    Simple?: Message | undefined;
    Raw?: RawMessage | undefined;
    Template?: Template | undefined;
}
export interface CreateDeliverabilityTestReportRequest {
    ReportName?: string | undefined;
    FromEmailAddress: string;
    Content: EmailContent;
    Tags?: Tag[] | undefined;
}
export type ReportId = string;
export type DeliverabilityTestStatus = "IN_PROGRESS" | "COMPLETED" | (string & {});
export interface CreateDeliverabilityTestReportResponse {
    ReportId: string;
    DeliverabilityTestStatus: DeliverabilityTestStatus;
}
export type Selector = string;
export type PrivateKey = string | redacted.Redacted<string>;
export type DkimSigningKeyLength = "RSA_1024_BIT" | "RSA_2048_BIT" | (string & {});
export type DkimSigningAttributesOrigin = "AWS_SES" | "EXTERNAL" | "AWS_SES_AF_SOUTH_1" | "AWS_SES_EU_NORTH_1" | "AWS_SES_AP_SOUTH_1" | "AWS_SES_EU_WEST_3" | "AWS_SES_EU_WEST_2" | "AWS_SES_EU_SOUTH_1" | "AWS_SES_EU_WEST_1" | "AWS_SES_AP_NORTHEAST_3" | "AWS_SES_AP_NORTHEAST_2" | "AWS_SES_ME_SOUTH_1" | "AWS_SES_AP_NORTHEAST_1" | "AWS_SES_IL_CENTRAL_1" | "AWS_SES_SA_EAST_1" | "AWS_SES_CA_CENTRAL_1" | "AWS_SES_AP_SOUTHEAST_1" | "AWS_SES_AP_SOUTHEAST_2" | "AWS_SES_AP_SOUTHEAST_3" | "AWS_SES_EU_CENTRAL_1" | "AWS_SES_US_EAST_1" | "AWS_SES_US_EAST_2" | "AWS_SES_US_WEST_1" | "AWS_SES_US_WEST_2" | "AWS_SES_ME_CENTRAL_1" | "AWS_SES_AP_SOUTH_2" | "AWS_SES_EU_CENTRAL_2" | "AWS_SES_AP_SOUTHEAST_5" | "AWS_SES_CA_WEST_1" | "AWS_SES_US_GOV_EAST_1" | "AWS_SES_US_GOV_WEST_1" | (string & {});
export interface DkimSigningAttributes {
    DomainSigningSelector?: string | undefined;
    DomainSigningPrivateKey?: string | redacted.Redacted<string> | undefined;
    NextSigningKeyLength?: DkimSigningKeyLength | undefined;
    DomainSigningAttributesOrigin?: DkimSigningAttributesOrigin | undefined;
}
export interface CreateEmailIdentityRequest {
    EmailIdentity: string;
    Tags?: Tag[] | undefined;
    DkimSigningAttributes?: DkimSigningAttributes | undefined;
    ConfigurationSetName?: string | undefined;
}
export type IdentityType = "EMAIL_ADDRESS" | "DOMAIN" | "MANAGED_DOMAIN" | (string & {});
export type DkimStatus = "PENDING" | "SUCCESS" | "FAILED" | "TEMPORARY_FAILURE" | "NOT_STARTED" | (string & {});
export type DnsToken = string;
export type DnsTokenList = string[];
export type HostedZone = string;
export interface DkimAttributes {
    SigningEnabled?: boolean | undefined;
    Status?: DkimStatus | undefined;
    Tokens?: string[] | undefined;
    SigningHostedZone?: string | undefined;
    SigningAttributesOrigin?: DkimSigningAttributesOrigin | undefined;
    NextSigningKeyLength?: DkimSigningKeyLength | undefined;
    CurrentSigningKeyLength?: DkimSigningKeyLength | undefined;
    LastKeyGenerationTimestamp?: Date | undefined;
}
export interface CreateEmailIdentityResponse {
    IdentityType?: IdentityType | undefined;
    VerifiedForSendingStatus?: boolean | undefined;
    DkimAttributes?: DkimAttributes | undefined;
}
export type PolicyName = string;
export type Policy = string;
export interface CreateEmailIdentityPolicyRequest {
    EmailIdentity: string;
    PolicyName: string;
    Policy: string;
}
export interface CreateEmailIdentityPolicyResponse {
}
export interface CreateEmailTemplateRequest {
    TemplateName: string;
    TemplateContent: EmailTemplateContent;
    Tags?: Tag[] | undefined;
}
export interface CreateEmailTemplateResponse {
}
export type ExportDimensionValue = string[];
export type ExportDimensions = {
    [key in MetricDimensionName]?: string[] | undefined;
};
export type MetricAggregation = "RATE" | "VOLUME" | (string & {});
export interface ExportMetric {
    Name?: Metric | undefined;
    Aggregation?: MetricAggregation | undefined;
}
export type ExportMetrics = ExportMetric[];
export interface MetricsDataSource {
    Dimensions: {
        [key: string]: string[] | undefined;
    };
    Namespace: MetricNamespace;
    Metrics: ExportMetric[];
    StartDate: Date;
    EndDate: Date;
}
export type InsightsEmailAddress = string | redacted.Redacted<string>;
export type EmailAddressFilterList = (string | redacted.Redacted<string>)[];
export type EmailSubject = string | redacted.Redacted<string>;
export type EmailSubjectFilterList = (string | redacted.Redacted<string>)[];
export type Isp = string;
export type IspFilterList = string[];
export type TenantName = string;
export type TenantNameFilterList = string[];
export type DeliveryEventType = "SEND" | "DELIVERY" | "TRANSIENT_BOUNCE" | "PERMANENT_BOUNCE" | "UNDETERMINED_BOUNCE" | "COMPLAINT" | (string & {});
export type LastDeliveryEventList = DeliveryEventType[];
export type EngagementEventType = "OPEN" | "CLICK" | (string & {});
export type LastEngagementEventList = EngagementEventType[];
export interface MessageInsightsFilters {
    FromEmailAddress?: (string | redacted.Redacted<string>)[] | undefined;
    Destination?: (string | redacted.Redacted<string>)[] | undefined;
    Subject?: (string | redacted.Redacted<string>)[] | undefined;
    Isp?: string[] | undefined;
    TenantName?: string[] | undefined;
    LastDeliveryEvent?: DeliveryEventType[] | undefined;
    LastEngagementEvent?: EngagementEventType[] | undefined;
}
export type MessageInsightsExportMaxResults = number;
export interface MessageInsightsDataSource {
    StartDate: Date;
    EndDate: Date;
    Include?: MessageInsightsFilters | undefined;
    Exclude?: MessageInsightsFilters | undefined;
    MaxResults?: number | undefined;
}
export interface ExportDataSource {
    MetricsDataSource?: MetricsDataSource | undefined;
    MessageInsightsDataSource?: MessageInsightsDataSource | undefined;
}
export type DataFormat = "CSV" | "JSON" | (string & {});
export type S3Url = string;
export interface ExportDestination {
    DataFormat: DataFormat;
    S3Url?: string | undefined;
}
export interface CreateExportJobRequest {
    ExportDataSource: ExportDataSource;
    ExportDestination: ExportDestination;
}
export interface CreateExportJobResponse {
    JobId?: string | undefined;
}
export type SuppressionListImportAction = "DELETE" | "PUT" | (string & {});
export interface SuppressionListDestination {
    SuppressionListImportAction: SuppressionListImportAction;
}
export type ContactListImportAction = "DELETE" | "PUT" | (string & {});
export interface ContactListDestination {
    ContactListName: string;
    ContactListImportAction: ContactListImportAction;
}
export interface ImportDestination {
    SuppressionListDestination?: SuppressionListDestination | undefined;
    ContactListDestination?: ContactListDestination | undefined;
}
export interface ImportDataSource {
    S3Url: string;
    DataFormat: DataFormat;
}
export interface CreateImportJobRequest {
    ImportDestination: ImportDestination;
    ImportDataSource: ImportDataSource;
}
export interface CreateImportJobResponse {
    JobId?: string | undefined;
}
export type EndpointName = string;
export type Region = string;
export interface RouteDetails {
    Region: string;
}
export type RoutesDetails = RouteDetails[];
export interface Details {
    RoutesDetails: RouteDetails[];
}
export interface CreateMultiRegionEndpointRequest {
    EndpointName: string;
    Details: Details;
    Tags?: Tag[] | undefined;
}
export type Status = "CREATING" | "READY" | "FAILED" | "DELETING" | (string & {});
export type EndpointId = string;
export interface CreateMultiRegionEndpointResponse {
    Status?: Status | undefined;
    EndpointId?: string | undefined;
}
export interface TenantSuppressionAttributes {
    SuppressedReasons?: SuppressionListReason[] | undefined;
    SuppressionScope?: SuppressionListScope | undefined;
}
export interface CreateTenantRequest {
    TenantName: string;
    Tags?: Tag[] | undefined;
    SuppressionAttributes?: TenantSuppressionAttributes | undefined;
}
export type TenantId = string;
export type SendingStatus = "ENABLED" | "REINSTATED" | "DISABLED" | (string & {});
export interface CreateTenantResponse {
    TenantName?: string | undefined;
    TenantId?: string | undefined;
    TenantArn?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    Tags?: Tag[] | undefined;
    SendingStatus?: SendingStatus | undefined;
    SuppressionAttributes?: TenantSuppressionAttributes | undefined;
}
export interface CreateTenantResourceAssociationRequest {
    TenantName: string;
    ResourceArn: string;
}
export interface CreateTenantResourceAssociationResponse {
}
export interface DeleteConfigurationSetRequest {
    ConfigurationSetName: string;
}
export interface DeleteConfigurationSetResponse {
}
export interface DeleteConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
}
export interface DeleteConfigurationSetEventDestinationResponse {
}
export interface DeleteContactRequest {
    ContactListName: string;
    EmailAddress: string;
}
export interface DeleteContactResponse {
}
export interface DeleteContactListRequest {
    ContactListName: string;
}
export interface DeleteContactListResponse {
}
export interface DeleteCustomVerificationEmailTemplateRequest {
    TemplateName: string;
}
export interface DeleteCustomVerificationEmailTemplateResponse {
}
export interface DeleteDedicatedIpPoolRequest {
    PoolName: string;
}
export interface DeleteDedicatedIpPoolResponse {
}
export interface DeleteEmailIdentityRequest {
    EmailIdentity: string;
}
export interface DeleteEmailIdentityResponse {
}
export interface DeleteEmailIdentityPolicyRequest {
    EmailIdentity: string;
    PolicyName: string;
}
export interface DeleteEmailIdentityPolicyResponse {
}
export interface DeleteEmailTemplateRequest {
    TemplateName: string;
}
export interface DeleteEmailTemplateResponse {
}
export interface DeleteMultiRegionEndpointRequest {
    EndpointName: string;
}
export interface DeleteMultiRegionEndpointResponse {
    Status?: Status | undefined;
}
export interface DeleteSuppressedDestinationRequest {
    EmailAddress: string;
    TenantName?: string | undefined;
}
export interface DeleteSuppressedDestinationResponse {
}
export interface DeleteTenantRequest {
    TenantName: string;
}
export interface DeleteTenantResponse {
}
export interface DeleteTenantResourceAssociationRequest {
    TenantName: string;
    ResourceArn: string;
}
export interface DeleteTenantResourceAssociationResponse {
}
export interface DisassociateEmailIdentityCertificateRequest {
    EmailIdentity: string;
    FromAddress?: string | undefined;
}
export interface DisassociateEmailIdentityCertificateResponse {
}
export interface GetAccountRequest {
}
export type GeneralEnforcementStatus = string;
export type Max24HourSend = number;
export type MaxSendRate = number;
export type SentLast24Hours = number;
export interface SendQuota {
    Max24HourSend?: number | undefined;
    MaxSendRate?: number | undefined;
    SentLast24Hours?: number | undefined;
}
export interface SuppressionValidationAttributes {
    ConditionThreshold: SuppressionConditionThreshold;
}
export interface SuppressionAttributes {
    SuppressedReasons?: SuppressionListReason[] | undefined;
    ValidationAttributes?: SuppressionValidationAttributes | undefined;
}
export type MailType = "MARKETING" | "TRANSACTIONAL" | (string & {});
export type WebsiteURL = string | redacted.Redacted<string>;
export type ContactLanguage = "EN" | "JA" | (string & {});
export type UseCaseDescription = string | redacted.Redacted<string>;
export type AdditionalContactEmailAddress = string | redacted.Redacted<string>;
export type AdditionalContactEmailAddresses = (string | redacted.Redacted<string>)[];
export type ReviewStatus = "PENDING" | "FAILED" | "GRANTED" | "DENIED" | (string & {});
export type CaseId = string;
export interface ReviewDetails {
    Status?: ReviewStatus | undefined;
    CaseId?: string | undefined;
}
export interface AccountDetails {
    MailType?: MailType | undefined;
    WebsiteURL?: string | redacted.Redacted<string> | undefined;
    ContactLanguage?: ContactLanguage | undefined;
    UseCaseDescription?: string | redacted.Redacted<string> | undefined;
    AdditionalContactEmailAddresses?: (string | redacted.Redacted<string>)[] | undefined;
    ReviewDetails?: ReviewDetails | undefined;
}
export interface DashboardAttributes {
    EngagementMetrics?: FeatureStatus | undefined;
}
export interface GuardianAttributes {
    OptimizedSharedDelivery?: FeatureStatus | undefined;
}
export interface VdmAttributes {
    VdmEnabled: FeatureStatus;
    DashboardAttributes?: DashboardAttributes | undefined;
    GuardianAttributes?: GuardianAttributes | undefined;
}
export type PricingPlan = "NONE" | "ESSENTIALS" | "PRO" | "ENTERPRISE" | (string & {});
export interface PricingAttributes {
    CurrentPlan?: PricingPlan | undefined;
    NextPlan?: PricingPlan | undefined;
}
export interface GetAccountResponse {
    DedicatedIpAutoWarmupEnabled?: boolean | undefined;
    EnforcementStatus?: string | undefined;
    ProductionAccessEnabled?: boolean | undefined;
    SendQuota?: SendQuota | undefined;
    SendingEnabled?: boolean | undefined;
    SuppressionAttributes?: SuppressionAttributes | undefined;
    Details?: AccountDetails | undefined;
    VdmAttributes?: VdmAttributes | undefined;
    PricingAttributes?: PricingAttributes | undefined;
}
export type BlacklistItemName = string;
export type BlacklistItemNames = string[];
export interface GetBlacklistReportsRequest {
    BlacklistItemNames: string[];
}
export type RblName = string;
export type BlacklistingDescription = string;
export interface BlacklistEntry {
    RblName?: string | undefined;
    ListingTime?: Date | undefined;
    Description?: string | undefined;
}
export type BlacklistEntries = BlacklistEntry[];
export type BlacklistReport = {
    [key: string]: BlacklistEntry[] | undefined;
};
export interface GetBlacklistReportsResponse {
    BlacklistReport: {
        [key: string]: BlacklistEntry[] | undefined;
    };
}
export interface GetConfigurationSetRequest {
    ConfigurationSetName: string;
}
export interface GetConfigurationSetResponse {
    ConfigurationSetName?: string | undefined;
    TrackingOptions?: TrackingOptions | undefined;
    DeliveryOptions?: DeliveryOptions | undefined;
    ReputationOptions?: ReputationOptions | undefined;
    SendingOptions?: SendingOptions | undefined;
    Tags?: Tag[] | undefined;
    SuppressionOptions?: SuppressionOptions | undefined;
    VdmOptions?: VdmOptions | undefined;
    ArchivingOptions?: ArchivingOptions | undefined;
    MessageSecurityOptions?: MessageSecurityOptions | undefined;
}
export interface GetConfigurationSetEventDestinationsRequest {
    ConfigurationSetName: string;
}
export interface EventDestination {
    Name: string;
    Enabled?: boolean | undefined;
    MatchingEventTypes: EventType[];
    KinesisFirehoseDestination?: KinesisFirehoseDestination | undefined;
    CloudWatchDestination?: CloudWatchDestination | undefined;
    SnsDestination?: SnsDestination | undefined;
    EventBridgeDestination?: EventBridgeDestination | undefined;
    PinpointDestination?: PinpointDestination | undefined;
}
export type EventDestinations = EventDestination[];
export interface GetConfigurationSetEventDestinationsResponse {
    EventDestinations?: EventDestination[] | undefined;
}
export interface GetContactRequest {
    ContactListName: string;
    EmailAddress: string;
}
export interface GetContactResponse {
    ContactListName?: string | undefined;
    EmailAddress?: string | undefined;
    TopicPreferences?: TopicPreference[] | undefined;
    TopicDefaultPreferences?: TopicPreference[] | undefined;
    UnsubscribeAll?: boolean | undefined;
    AttributesData?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
}
export interface GetContactListRequest {
    ContactListName: string;
}
export interface GetContactListResponse {
    ContactListName?: string | undefined;
    Topics?: Topic[] | undefined;
    Description?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetCustomVerificationEmailTemplateRequest {
    TemplateName: string;
}
export interface GetCustomVerificationEmailTemplateResponse {
    TemplateName?: string | undefined;
    FromEmailAddress?: string | undefined;
    TemplateSubject?: string | undefined;
    TemplateContent?: string | undefined;
    Tags?: Tag[] | undefined;
    SuccessRedirectionURL?: string | undefined;
    FailureRedirectionURL?: string | undefined;
}
export type Ip = string;
export interface GetDedicatedIpRequest {
    Ip: string;
}
export type WarmupStatus = "IN_PROGRESS" | "DONE" | "NOT_APPLICABLE" | (string & {});
export type Percentage100Wrapper = number;
export interface DedicatedIp {
    Ip: string;
    WarmupStatus: WarmupStatus;
    WarmupPercentage: number;
    PoolName?: string | undefined;
}
export interface GetDedicatedIpResponse {
    DedicatedIp?: DedicatedIp | undefined;
}
export interface GetDedicatedIpPoolRequest {
    PoolName: string;
}
export interface DedicatedIpPool {
    PoolName: string;
    ScalingMode: ScalingMode;
}
export interface GetDedicatedIpPoolResponse {
    DedicatedIpPool?: DedicatedIpPool | undefined;
}
export type NextToken = string;
export type MaxItems = number;
export interface GetDedicatedIpsRequest {
    PoolName?: string | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type DedicatedIpList = DedicatedIp[];
export interface GetDedicatedIpsResponse {
    DedicatedIps?: DedicatedIp[] | undefined;
    NextToken?: string | undefined;
}
export interface GetDeliverabilityDashboardOptionsRequest {
}
export type DeliverabilityDashboardAccountStatus = "ACTIVE" | "PENDING_EXPIRATION" | "DISABLED" | (string & {});
export type Domain = string;
export type IspName = string;
export type IspNameList = string[];
export interface InboxPlacementTrackingOption {
    Global?: boolean | undefined;
    TrackedIsps?: string[] | undefined;
}
export interface DomainDeliverabilityTrackingOption {
    Domain?: string | undefined;
    SubscriptionStartDate?: Date | undefined;
    InboxPlacementTrackingOption?: InboxPlacementTrackingOption | undefined;
}
export type DomainDeliverabilityTrackingOptions = DomainDeliverabilityTrackingOption[];
export interface GetDeliverabilityDashboardOptionsResponse {
    DashboardEnabled: boolean;
    SubscriptionExpiryDate?: Date | undefined;
    AccountStatus?: DeliverabilityDashboardAccountStatus | undefined;
    ActiveSubscribedDomains?: DomainDeliverabilityTrackingOption[] | undefined;
    PendingExpirationSubscribedDomains?: DomainDeliverabilityTrackingOption[] | undefined;
}
export interface GetDeliverabilityTestReportRequest {
    ReportId: string;
}
export type DeliverabilityTestSubject = string;
export interface DeliverabilityTestReport {
    ReportId?: string | undefined;
    ReportName?: string | undefined;
    Subject?: string | undefined;
    FromEmailAddress?: string | undefined;
    CreateDate?: Date | undefined;
    DeliverabilityTestStatus?: DeliverabilityTestStatus | undefined;
}
export type Percentage = number;
export interface PlacementStatistics {
    InboxPercentage?: number | undefined;
    SpamPercentage?: number | undefined;
    MissingPercentage?: number | undefined;
    SpfPercentage?: number | undefined;
    DkimPercentage?: number | undefined;
}
export interface IspPlacement {
    IspName?: string | undefined;
    PlacementStatistics?: PlacementStatistics | undefined;
}
export type IspPlacements = IspPlacement[];
export type MessageContent = string;
export interface GetDeliverabilityTestReportResponse {
    DeliverabilityTestReport: DeliverabilityTestReport;
    OverallPlacement: PlacementStatistics;
    IspPlacements: IspPlacement[];
    Message?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type CampaignId = string;
export interface GetDomainDeliverabilityCampaignRequest {
    CampaignId: string;
}
export type ImageUrl = string;
export type Subject = string;
export type IpList = string[];
export type Volume = number;
export type Esp = string;
export type Esps = string[];
export interface DomainDeliverabilityCampaign {
    CampaignId?: string | undefined;
    ImageUrl?: string | undefined;
    Subject?: string | undefined;
    FromAddress?: string | undefined;
    SendingIps?: string[] | undefined;
    FirstSeenDateTime?: Date | undefined;
    LastSeenDateTime?: Date | undefined;
    InboxCount?: number | undefined;
    SpamCount?: number | undefined;
    ReadRate?: number | undefined;
    DeleteRate?: number | undefined;
    ReadDeleteRate?: number | undefined;
    ProjectedVolume?: number | undefined;
    Esps?: string[] | undefined;
}
export interface GetDomainDeliverabilityCampaignResponse {
    DomainDeliverabilityCampaign: DomainDeliverabilityCampaign;
}
export interface GetDomainStatisticsReportRequest {
    Domain: string;
    StartDate: Date;
    EndDate: Date;
}
export interface VolumeStatistics {
    InboxRawCount?: number | undefined;
    SpamRawCount?: number | undefined;
    ProjectedInbox?: number | undefined;
    ProjectedSpam?: number | undefined;
}
export interface DomainIspPlacement {
    IspName?: string | undefined;
    InboxRawCount?: number | undefined;
    SpamRawCount?: number | undefined;
    InboxPercentage?: number | undefined;
    SpamPercentage?: number | undefined;
}
export type DomainIspPlacements = DomainIspPlacement[];
export interface OverallVolume {
    VolumeStatistics?: VolumeStatistics | undefined;
    ReadRatePercent?: number | undefined;
    DomainIspPlacements?: DomainIspPlacement[] | undefined;
}
export interface DailyVolume {
    StartDate?: Date | undefined;
    VolumeStatistics?: VolumeStatistics | undefined;
    DomainIspPlacements?: DomainIspPlacement[] | undefined;
}
export type DailyVolumes = DailyVolume[];
export interface GetDomainStatisticsReportResponse {
    OverallVolume: OverallVolume;
    DailyVolumes: DailyVolume[];
}
export interface GetEmailAddressInsightsRequest {
    EmailAddress: string;
}
export type EmailAddressInsightsConfidenceVerdict = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export interface EmailAddressInsightsVerdict {
    ConfidenceVerdict?: EmailAddressInsightsConfidenceVerdict | undefined;
}
export interface EmailAddressInsightsMailboxEvaluations {
    HasValidSyntax?: EmailAddressInsightsVerdict | undefined;
    HasValidDnsRecords?: EmailAddressInsightsVerdict | undefined;
    MailboxExists?: EmailAddressInsightsVerdict | undefined;
    IsRoleAddress?: EmailAddressInsightsVerdict | undefined;
    IsDisposable?: EmailAddressInsightsVerdict | undefined;
    IsRandomInput?: EmailAddressInsightsVerdict | undefined;
}
export interface MailboxValidation {
    IsValid?: EmailAddressInsightsVerdict | undefined;
    Evaluations?: EmailAddressInsightsMailboxEvaluations | undefined;
}
export interface GetEmailAddressInsightsResponse {
    MailboxValidation?: MailboxValidation | undefined;
}
export interface GetEmailIdentityRequest {
    EmailIdentity: string;
}
export type MailFromDomainName = string;
export type MailFromDomainStatus = "PENDING" | "SUCCESS" | "FAILED" | "TEMPORARY_FAILURE" | (string & {});
export type BehaviorOnMxFailure = "USE_DEFAULT_VALUE" | "REJECT_MESSAGE" | (string & {});
export interface MailFromAttributes {
    MailFromDomain?: string | undefined;
    MailFromDomainStatus?: MailFromDomainStatus | undefined;
    BehaviorOnMxFailure?: BehaviorOnMxFailure | undefined;
}
export type PolicyMap = {
    [key: string]: string | undefined;
};
export type VerificationStatus = "PENDING" | "SUCCESS" | "FAILED" | "TEMPORARY_FAILURE" | "NOT_STARTED" | (string & {});
export type VerificationError = "SERVICE_ERROR" | "DNS_SERVER_ERROR" | "HOST_NOT_FOUND" | "TYPE_NOT_FOUND" | "INVALID_VALUE" | "REPLICATION_ACCESS_DENIED" | "REPLICATION_PRIMARY_NOT_FOUND" | "REPLICATION_PRIMARY_BYO_DKIM_NOT_SUPPORTED" | "REPLICATION_REPLICA_AS_PRIMARY_NOT_SUPPORTED" | "REPLICATION_PRIMARY_INVALID_REGION" | (string & {});
export type PrimaryNameServer = string;
export type AdminEmail = string;
export type SerialNumber = number;
export interface SOARecord {
    PrimaryNameServer?: string | undefined;
    AdminEmail?: string | undefined;
    SerialNumber?: number | undefined;
}
export interface VerificationInfo {
    LastCheckedTimestamp?: Date | undefined;
    LastSuccessTimestamp?: Date | undefined;
    ErrorType?: VerificationError | undefined;
    SOARecord?: SOARecord | undefined;
}
export interface GetEmailIdentityResponse {
    IdentityType?: IdentityType | undefined;
    FeedbackForwardingStatus?: boolean | undefined;
    VerifiedForSendingStatus?: boolean | undefined;
    DkimAttributes?: DkimAttributes | undefined;
    MailFromAttributes?: MailFromAttributes | undefined;
    Policies?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
    ConfigurationSetName?: string | undefined;
    VerificationStatus?: VerificationStatus | undefined;
    VerificationInfo?: VerificationInfo | undefined;
}
export interface GetEmailIdentityPoliciesRequest {
    EmailIdentity: string;
}
export interface GetEmailIdentityPoliciesResponse {
    Policies?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetEmailTemplateRequest {
    TemplateName: string;
}
export interface GetEmailTemplateResponse {
    TemplateName: string;
    TemplateContent: EmailTemplateContent;
    Tags?: Tag[] | undefined;
}
export interface GetExportJobRequest {
    JobId: string;
}
export type ExportSourceType = "METRICS_DATA" | "MESSAGE_INSIGHTS" | (string & {});
export type JobStatus = "CREATED" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export type FailedRecordsS3Url = string;
export type ErrorMessage = string;
export interface FailureInfo {
    FailedRecordsS3Url?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type ProcessedRecordsCount = number;
export type ExportedRecordsCount = number;
export interface ExportStatistics {
    ProcessedRecordsCount?: number | undefined;
    ExportedRecordsCount?: number | undefined;
}
export interface GetExportJobResponse {
    JobId?: string | undefined;
    ExportSourceType?: ExportSourceType | undefined;
    JobStatus?: JobStatus | undefined;
    ExportDestination?: ExportDestination | undefined;
    ExportDataSource?: ExportDataSource | undefined;
    CreatedTimestamp?: Date | undefined;
    CompletedTimestamp?: Date | undefined;
    FailureInfo?: FailureInfo | undefined;
    Statistics?: ExportStatistics | undefined;
}
export interface GetImportJobRequest {
    JobId: string;
}
export type FailedRecordsCount = number;
export interface GetImportJobResponse {
    JobId?: string | undefined;
    ImportDestination?: ImportDestination | undefined;
    ImportDataSource?: ImportDataSource | undefined;
    FailureInfo?: FailureInfo | undefined;
    JobStatus?: JobStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    CompletedTimestamp?: Date | undefined;
    ProcessedRecordsCount?: number | undefined;
    FailedRecordsCount?: number | undefined;
}
export type OutboundMessageId = string;
export interface GetMessageInsightsRequest {
    MessageId: string;
}
export type MessageTagName = string;
export type MessageTagValue = string;
export interface MessageTag {
    Name: string;
    Value: string;
}
export type MessageTagList = MessageTag[];
export type BounceType = "UNDETERMINED" | "TRANSIENT" | "PERMANENT" | (string & {});
export type BounceSubType = string;
export type DiagnosticCode = string;
export interface Bounce {
    BounceType?: BounceType | undefined;
    BounceSubType?: string | undefined;
    DiagnosticCode?: string | undefined;
}
export type ComplaintSubType = string;
export type ComplaintFeedbackType = string;
export interface Complaint {
    ComplaintSubType?: string | undefined;
    ComplaintFeedbackType?: string | undefined;
}
export interface EventDetails {
    Bounce?: Bounce | undefined;
    Complaint?: Complaint | undefined;
}
export interface InsightsEvent {
    Timestamp?: Date | undefined;
    Type?: EventType | undefined;
    Details?: EventDetails | undefined;
}
export type InsightsEvents = InsightsEvent[];
export interface EmailInsights {
    Destination?: string | redacted.Redacted<string> | undefined;
    Isp?: string | undefined;
    Events?: InsightsEvent[] | undefined;
}
export type EmailInsightsList = EmailInsights[];
export interface GetMessageInsightsResponse {
    MessageId?: string | undefined;
    FromEmailAddress?: string | redacted.Redacted<string> | undefined;
    Subject?: string | redacted.Redacted<string> | undefined;
    EmailTags?: MessageTag[] | undefined;
    Insights?: EmailInsights[] | undefined;
}
export interface GetMultiRegionEndpointRequest {
    EndpointName: string;
}
export interface Route {
    Region: string;
}
export type Routes = Route[];
export interface GetMultiRegionEndpointResponse {
    EndpointName?: string | undefined;
    EndpointId?: string | undefined;
    Routes?: Route[] | undefined;
    Status?: Status | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
}
export type ReputationEntityReference = string;
export type ReputationEntityType = "RESOURCE" | (string & {});
export interface GetReputationEntityRequest {
    ReputationEntityReference: string;
    ReputationEntityType: ReputationEntityType;
}
export type StatusCause = string;
export interface StatusRecord {
    Status?: SendingStatus | undefined;
    Cause?: string | undefined;
    LastUpdatedTimestamp?: Date | undefined;
}
export type RecommendationImpact = "LOW" | "HIGH" | (string & {});
export interface ReputationEntity {
    ReputationEntityReference?: string | undefined;
    ReputationEntityType?: ReputationEntityType | undefined;
    ReputationManagementPolicy?: string | undefined;
    CustomerManagedStatus?: StatusRecord | undefined;
    AwsSesManagedStatus?: StatusRecord | undefined;
    SendingStatusAggregate?: SendingStatus | undefined;
    ReputationImpact?: RecommendationImpact | undefined;
}
export interface GetReputationEntityResponse {
    ReputationEntity?: ReputationEntity | undefined;
}
export interface GetSuppressedDestinationRequest {
    EmailAddress: string;
    TenantName?: string | undefined;
}
export type FeedbackId = string;
export interface SuppressedDestinationAttributes {
    MessageId?: string | undefined;
    FeedbackId?: string | undefined;
}
export interface SuppressedDestination {
    EmailAddress: string;
    Reason: SuppressionListReason;
    LastUpdateTime: Date;
    Attributes?: SuppressedDestinationAttributes | undefined;
    TenantName?: string | undefined;
}
export interface GetSuppressedDestinationResponse {
    SuppressedDestination: SuppressedDestination;
}
export interface GetTenantRequest {
    TenantName: string;
}
export interface Tenant {
    TenantName?: string | undefined;
    TenantId?: string | undefined;
    TenantArn?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    Tags?: Tag[] | undefined;
    SendingStatus?: SendingStatus | undefined;
    SuppressionAttributes?: TenantSuppressionAttributes | undefined;
}
export interface GetTenantResponse {
    Tenant?: Tenant | undefined;
}
export type ConfigurationSetFilterKey = "CONFIGURATION_SET_NAME_CONTAINS" | (string & {});
export type ConfigurationSetFilterValue = string;
export type ConfigurationSetFilter = {
    [key in ConfigurationSetFilterKey]?: string | undefined;
};
export interface ListConfigurationSetsRequest {
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type ConfigurationSetNameList = string[];
export interface ListConfigurationSetsResponse {
    ConfigurationSets?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListContactListsRequest {
    PageSize?: number | undefined;
    NextToken?: string | undefined;
}
export interface ContactList {
    ContactListName?: string | undefined;
    LastUpdatedTimestamp?: Date | undefined;
}
export type ListOfContactLists = ContactList[];
export interface ListContactListsResponse {
    ContactLists?: ContactList[] | undefined;
    NextToken?: string | undefined;
}
export type UseDefaultIfPreferenceUnavailable = boolean;
export interface TopicFilter {
    TopicName?: string | undefined;
    UseDefaultIfPreferenceUnavailable?: boolean | undefined;
}
export interface ListContactsFilter {
    FilteredStatus?: SubscriptionStatus | undefined;
    TopicFilter?: TopicFilter | undefined;
}
export interface ListContactsRequest {
    ContactListName: string;
    Filter?: ListContactsFilter | undefined;
    PageSize?: number | undefined;
    NextToken?: string | undefined;
}
export interface Contact {
    EmailAddress?: string | undefined;
    TopicPreferences?: TopicPreference[] | undefined;
    TopicDefaultPreferences?: TopicPreference[] | undefined;
    UnsubscribeAll?: boolean | undefined;
    LastUpdatedTimestamp?: Date | undefined;
}
export type ListOfContacts = Contact[];
export interface ListContactsResponse {
    Contacts?: Contact[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCustomVerificationEmailTemplatesRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface CustomVerificationEmailTemplateMetadata {
    TemplateName?: string | undefined;
    FromEmailAddress?: string | undefined;
    TemplateSubject?: string | undefined;
    SuccessRedirectionURL?: string | undefined;
    FailureRedirectionURL?: string | undefined;
}
export type CustomVerificationEmailTemplatesList = CustomVerificationEmailTemplateMetadata[];
export interface ListCustomVerificationEmailTemplatesResponse {
    CustomVerificationEmailTemplates?: CustomVerificationEmailTemplateMetadata[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDedicatedIpPoolsRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type ListOfDedicatedIpPools = string[];
export interface ListDedicatedIpPoolsResponse {
    DedicatedIpPools?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDeliverabilityTestReportsRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type DeliverabilityTestReports = DeliverabilityTestReport[];
export interface ListDeliverabilityTestReportsResponse {
    DeliverabilityTestReports: DeliverabilityTestReport[];
    NextToken?: string | undefined;
}
export interface ListDomainDeliverabilityCampaignsRequest {
    StartDate: Date;
    EndDate: Date;
    SubscribedDomain: string;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type DomainDeliverabilityCampaignList = DomainDeliverabilityCampaign[];
export interface ListDomainDeliverabilityCampaignsResponse {
    DomainDeliverabilityCampaigns: DomainDeliverabilityCampaign[];
    NextToken?: string | undefined;
}
export type IdentityFilterKey = "IDENTITY_NAME_CONTAINS" | "IDENTITY_TYPE" | "VERIFICATION_STATUS" | (string & {});
export type IdentityFilterValue = string;
export type IdentityFilter = {
    [key in IdentityFilterKey]?: string | undefined;
};
export interface ListEmailIdentitiesRequest {
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface IdentityInfo {
    IdentityType?: IdentityType | undefined;
    IdentityName?: string | undefined;
    SendingEnabled?: boolean | undefined;
    VerificationStatus?: VerificationStatus | undefined;
}
export type IdentityInfoList = IdentityInfo[];
export interface ListEmailIdentitiesResponse {
    EmailIdentities?: IdentityInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEmailIdentityCertificatesRequest {
    EmailIdentity: string;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type IdentityCertificateStatus = "PROVISIONING" | "INACTIVE" | "DEPROVISIONING" | "ACTIVE" | "FAILED" | (string & {});
export interface IdentityCertificate {
    FromAddress?: string | undefined;
    Status?: IdentityCertificateStatus | undefined;
    CertificateArn?: string | undefined;
    CertificateExpiryTime?: Date | undefined;
}
export type IdentityCertificateList = IdentityCertificate[];
export interface ListEmailIdentityCertificatesResponse {
    Certificates?: IdentityCertificate[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEmailTemplatesRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface EmailTemplateMetadata {
    TemplateName?: string | undefined;
    CreatedTimestamp?: Date | undefined;
}
export type EmailTemplateMetadataList = EmailTemplateMetadata[];
export interface ListEmailTemplatesResponse {
    TemplatesMetadata?: EmailTemplateMetadata[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExportJobsRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
    ExportSourceType?: ExportSourceType | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface ExportJobSummary {
    JobId?: string | undefined;
    ExportSourceType?: ExportSourceType | undefined;
    JobStatus?: JobStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    CompletedTimestamp?: Date | undefined;
}
export type ExportJobSummaryList = ExportJobSummary[];
export interface ListExportJobsResponse {
    ExportJobs?: ExportJobSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ImportDestinationType = "SUPPRESSION_LIST" | "CONTACT_LIST" | (string & {});
export interface ListImportJobsRequest {
    ImportDestinationType?: ImportDestinationType | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface ImportJobSummary {
    JobId?: string | undefined;
    ImportDestination?: ImportDestination | undefined;
    JobStatus?: JobStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    ProcessedRecordsCount?: number | undefined;
    FailedRecordsCount?: number | undefined;
}
export type ImportJobSummaryList = ImportJobSummary[];
export interface ListImportJobsResponse {
    ImportJobs?: ImportJobSummary[] | undefined;
    NextToken?: string | undefined;
}
export type NextTokenV2 = string;
export type PageSizeV2 = number;
export interface ListMultiRegionEndpointsRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type Regions = string[];
export interface MultiRegionEndpoint {
    EndpointName?: string | undefined;
    Status?: Status | undefined;
    EndpointId?: string | undefined;
    Regions?: string[] | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
}
export type MultiRegionEndpoints = MultiRegionEndpoint[];
export interface ListMultiRegionEndpointsResponse {
    MultiRegionEndpoints?: MultiRegionEndpoint[] | undefined;
    NextToken?: string | undefined;
}
export type ListRecommendationsFilterKey = "TYPE" | "IMPACT" | "STATUS" | "RESOURCE_ARN" | (string & {});
export type ListRecommendationFilterValue = string;
export type ListRecommendationsFilter = {
    [key in ListRecommendationsFilterKey]?: string | undefined;
};
export interface ListRecommendationsRequest {
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type RecommendationType = "DKIM" | "DMARC" | "SPF" | "BIMI" | "COMPLAINT" | "BOUNCE" | "FEEDBACK_3P" | "IP_LISTING" | (string & {});
export type RecommendationDescription = string;
export type RecommendationStatus = "OPEN" | "FIXED" | (string & {});
export interface Recommendation {
    ResourceArn?: string | undefined;
    Type?: RecommendationType | undefined;
    Description?: string | undefined;
    Status?: RecommendationStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    Impact?: RecommendationImpact | undefined;
}
export type RecommendationsList = Recommendation[];
export interface ListRecommendationsResponse {
    Recommendations?: Recommendation[] | undefined;
    NextToken?: string | undefined;
}
export type ReputationEntityFilterKey = "ENTITY_TYPE" | "REPUTATION_IMPACT" | "SENDING_STATUS" | "ENTITY_REFERENCE_PREFIX" | (string & {});
export type ReputationEntityFilterValue = string;
export type ReputationEntityFilter = {
    [key in ReputationEntityFilterKey]?: string | undefined;
};
export interface ListReputationEntitiesRequest {
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type ReputationEntitiesList = ReputationEntity[];
export interface ListReputationEntitiesResponse {
    ReputationEntities?: ReputationEntity[] | undefined;
    NextToken?: string | undefined;
}
export interface ListResourceTenantsRequest {
    ResourceArn: string;
    PageSize?: number | undefined;
    NextToken?: string | undefined;
}
export interface ResourceTenantMetadata {
    TenantName?: string | undefined;
    TenantId?: string | undefined;
    ResourceArn?: string | undefined;
    AssociatedTimestamp?: Date | undefined;
}
export type ResourceTenantMetadataList = ResourceTenantMetadata[];
export interface ListResourceTenantsResponse {
    ResourceTenants?: ResourceTenantMetadata[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSuppressedDestinationsRequest {
    TenantName?: string | undefined;
    Reasons?: SuppressionListReason[] | undefined;
    StartDate?: Date | undefined;
    EndDate?: Date | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface SuppressedDestinationSummary {
    EmailAddress: string;
    Reason: SuppressionListReason;
    LastUpdateTime: Date;
}
export type SuppressedDestinationSummaries = SuppressedDestinationSummary[];
export interface ListSuppressedDestinationsResponse {
    SuppressedDestinationSummaries?: SuppressedDestinationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags: Tag[];
}
export type ListTenantResourcesFilterKey = "RESOURCE_TYPE" | (string & {});
export type ListTenantResourcesFilterValue = string;
export type ListTenantResourcesFilter = {
    [key in ListTenantResourcesFilterKey]?: string | undefined;
};
export interface ListTenantResourcesRequest {
    TenantName: string;
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
    PageSize?: number | undefined;
    NextToken?: string | undefined;
}
export type ResourceType = "EMAIL_IDENTITY" | "CONFIGURATION_SET" | "EMAIL_TEMPLATE" | (string & {});
export interface TenantResource {
    ResourceType?: ResourceType | undefined;
    ResourceArn?: string | undefined;
}
export type TenantResourceList = TenantResource[];
export interface ListTenantResourcesResponse {
    TenantResources?: TenantResource[] | undefined;
    NextToken?: string | undefined;
}
export type ListTenantsFilterKey = "TENANT_NAME_CONTAINS" | "SENDING_STATUS" | (string & {});
export type ListTenantsFilterValue = string;
export type ListTenantsFilter = {
    [key in ListTenantsFilterKey]?: string | undefined;
};
export interface ListTenantsRequest {
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface TenantInfo {
    TenantName?: string | undefined;
    TenantId?: string | undefined;
    TenantArn?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    SendingStatus?: SendingStatus | undefined;
}
export type TenantInfoList = TenantInfo[];
export interface ListTenantsResponse {
    Tenants?: TenantInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface PutAccountDedicatedIpWarmupAttributesRequest {
    AutoWarmupEnabled?: boolean | undefined;
}
export interface PutAccountDedicatedIpWarmupAttributesResponse {
}
export type EnabledWrapper = boolean;
export interface PutAccountDetailsRequest {
    MailType: MailType;
    WebsiteURL: string | redacted.Redacted<string>;
    ContactLanguage?: ContactLanguage | undefined;
    UseCaseDescription?: string | redacted.Redacted<string> | undefined;
    AdditionalContactEmailAddresses?: (string | redacted.Redacted<string>)[] | undefined;
    ProductionAccessEnabled?: boolean | undefined;
}
export interface PutAccountDetailsResponse {
}
export interface PutAccountPricingAttributesRequest {
    Plan: PricingPlan;
}
export interface PutAccountPricingAttributesResponse {
}
export interface PutAccountSendingAttributesRequest {
    SendingEnabled?: boolean | undefined;
}
export interface PutAccountSendingAttributesResponse {
}
export interface PutAccountSuppressionAttributesRequest {
    SuppressedReasons?: SuppressionListReason[] | undefined;
    ValidationAttributes?: SuppressionValidationAttributes | undefined;
}
export interface PutAccountSuppressionAttributesResponse {
}
export interface PutAccountVdmAttributesRequest {
    VdmAttributes: VdmAttributes;
}
export interface PutAccountVdmAttributesResponse {
}
export interface PutConfigurationSetArchivingOptionsRequest {
    ConfigurationSetName: string;
    ArchiveArn?: string | undefined;
}
export interface PutConfigurationSetArchivingOptionsResponse {
}
export type SendingPoolName = string;
export interface PutConfigurationSetDeliveryOptionsRequest {
    ConfigurationSetName: string;
    TlsPolicy?: TlsPolicy | undefined;
    SendingPoolName?: string | undefined;
    MaxDeliverySeconds?: number | undefined;
}
export interface PutConfigurationSetDeliveryOptionsResponse {
}
export interface PutConfigurationSetReputationOptionsRequest {
    ConfigurationSetName: string;
    ReputationMetricsEnabled?: boolean | undefined;
}
export interface PutConfigurationSetReputationOptionsResponse {
}
export interface PutConfigurationSetSendingOptionsRequest {
    ConfigurationSetName: string;
    SendingEnabled?: boolean | undefined;
}
export interface PutConfigurationSetSendingOptionsResponse {
}
export interface PutConfigurationSetSuppressionOptionsRequest {
    ConfigurationSetName: string;
    SuppressionScope?: SuppressionListScope | undefined;
    SuppressedReasons?: SuppressionListReason[] | undefined;
    ValidationOptions?: SuppressionValidationOptions | undefined;
}
export interface PutConfigurationSetSuppressionOptionsResponse {
}
export interface PutConfigurationSetTrackingOptionsRequest {
    ConfigurationSetName: string;
    CustomRedirectDomain?: string | undefined;
    HttpsPolicy?: HttpsPolicy | undefined;
}
export interface PutConfigurationSetTrackingOptionsResponse {
}
export interface PutConfigurationSetVdmOptionsRequest {
    ConfigurationSetName: string;
    VdmOptions?: VdmOptions | undefined;
}
export interface PutConfigurationSetVdmOptionsResponse {
}
export interface PutDedicatedIpInPoolRequest {
    Ip: string;
    DestinationPoolName: string;
}
export interface PutDedicatedIpInPoolResponse {
}
export interface PutDedicatedIpPoolScalingAttributesRequest {
    PoolName: string;
    ScalingMode: ScalingMode;
}
export interface PutDedicatedIpPoolScalingAttributesResponse {
}
export interface PutDedicatedIpWarmupAttributesRequest {
    Ip: string;
    WarmupPercentage: number;
}
export interface PutDedicatedIpWarmupAttributesResponse {
}
export interface PutDeliverabilityDashboardOptionRequest {
    DashboardEnabled: boolean;
    SubscribedDomains?: DomainDeliverabilityTrackingOption[] | undefined;
}
export interface PutDeliverabilityDashboardOptionResponse {
}
export interface PutEmailIdentityConfigurationSetAttributesRequest {
    EmailIdentity: string;
    ConfigurationSetName?: string | undefined;
}
export interface PutEmailIdentityConfigurationSetAttributesResponse {
}
export interface PutEmailIdentityDkimAttributesRequest {
    EmailIdentity: string;
    SigningEnabled?: boolean | undefined;
}
export interface PutEmailIdentityDkimAttributesResponse {
}
export interface PutEmailIdentityDkimSigningAttributesRequest {
    EmailIdentity: string;
    SigningAttributesOrigin: DkimSigningAttributesOrigin;
    SigningAttributes?: DkimSigningAttributes | undefined;
}
export interface PutEmailIdentityDkimSigningAttributesResponse {
    DkimStatus?: DkimStatus | undefined;
    DkimTokens?: string[] | undefined;
    SigningHostedZone?: string | undefined;
}
export interface PutEmailIdentityFeedbackAttributesRequest {
    EmailIdentity: string;
    EmailForwardingEnabled?: boolean | undefined;
}
export interface PutEmailIdentityFeedbackAttributesResponse {
}
export interface PutEmailIdentityMailFromAttributesRequest {
    EmailIdentity: string;
    MailFromDomain?: string | undefined;
    BehaviorOnMxFailure?: BehaviorOnMxFailure | undefined;
}
export interface PutEmailIdentityMailFromAttributesResponse {
}
export interface PutSuppressedDestinationRequest {
    EmailAddress: string;
    Reason: SuppressionListReason;
    TenantName?: string | undefined;
}
export interface PutSuppressedDestinationResponse {
}
export interface PutTenantSuppressionAttributesRequest {
    TenantName: string;
    SuppressedReasons?: SuppressionListReason[] | undefined;
    SuppressionScope?: SuppressionListScope | undefined;
}
export interface PutTenantSuppressionAttributesResponse {
}
export type EmailAddressList = string[];
export interface BulkEmailContent {
    Template?: Template | undefined;
}
export interface Destination {
    ToAddresses?: string[] | undefined;
    CcAddresses?: string[] | undefined;
    BccAddresses?: string[] | undefined;
}
export interface ReplacementTemplate {
    ReplacementTemplateData?: string | undefined;
}
export interface ReplacementEmailContent {
    ReplacementTemplate?: ReplacementTemplate | undefined;
}
export interface BulkEmailEntry {
    Destination: Destination;
    ReplacementTags?: MessageTag[] | undefined;
    ReplacementEmailContent?: ReplacementEmailContent | undefined;
    ReplacementHeaders?: MessageHeader[] | undefined;
}
export type BulkEmailEntryList = BulkEmailEntry[];
export interface TrackingConfigurationOverrides {
    OpenTrackingEnabled?: FeatureStatus | undefined;
    ClickTrackingEnabled?: FeatureStatus | undefined;
}
export interface ConfigurationOverrides {
    Tracking?: TrackingConfigurationOverrides | undefined;
}
export interface SendBulkEmailRequest {
    FromEmailAddress?: string | undefined;
    FromEmailAddressIdentityArn?: string | undefined;
    ReplyToAddresses?: string[] | undefined;
    FeedbackForwardingEmailAddress?: string | undefined;
    FeedbackForwardingEmailAddressIdentityArn?: string | undefined;
    DefaultEmailTags?: MessageTag[] | undefined;
    DefaultContent: BulkEmailContent;
    BulkEmailEntries: BulkEmailEntry[];
    ConfigurationSetName?: string | undefined;
    EndpointId?: string | undefined;
    TenantName?: string | undefined;
    ConfigurationOverrides?: ConfigurationOverrides | undefined;
}
export type BulkEmailStatus = "SUCCESS" | "MESSAGE_REJECTED" | "MAIL_FROM_DOMAIN_NOT_VERIFIED" | "CONFIGURATION_SET_NOT_FOUND" | "TEMPLATE_NOT_FOUND" | "ACCOUNT_SUSPENDED" | "ACCOUNT_THROTTLED" | "ACCOUNT_DAILY_QUOTA_EXCEEDED" | "INVALID_SENDING_POOL_NAME" | "ACCOUNT_SENDING_PAUSED" | "CONFIGURATION_SET_SENDING_PAUSED" | "INVALID_PARAMETER" | "TRANSIENT_FAILURE" | "FAILED" | (string & {});
export interface BulkEmailEntryResult {
    Status?: BulkEmailStatus | undefined;
    Error?: string | undefined;
    MessageId?: string | undefined;
}
export type BulkEmailEntryResultList = BulkEmailEntryResult[];
export interface SendBulkEmailResponse {
    BulkEmailEntryResults: BulkEmailEntryResult[];
}
export interface SendCustomVerificationEmailRequest {
    EmailAddress: string;
    TemplateName: string;
    ConfigurationSetName?: string | undefined;
}
export interface SendCustomVerificationEmailResponse {
    MessageId?: string | undefined;
}
export interface ListManagementOptions {
    ContactListName: string;
    TopicName?: string | undefined;
}
export interface SendEmailRequest {
    FromEmailAddress?: string | undefined;
    FromEmailAddressIdentityArn?: string | undefined;
    Destination?: Destination | undefined;
    ReplyToAddresses?: string[] | undefined;
    FeedbackForwardingEmailAddress?: string | undefined;
    FeedbackForwardingEmailAddressIdentityArn?: string | undefined;
    Content: EmailContent;
    EmailTags?: MessageTag[] | undefined;
    ConfigurationSetName?: string | undefined;
    EndpointId?: string | undefined;
    TenantName?: string | undefined;
    ListManagementOptions?: ListManagementOptions | undefined;
    ConfigurationOverrides?: ConfigurationOverrides | undefined;
}
export interface SendEmailResponse {
    MessageId?: string | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export interface TestRenderEmailTemplateRequest {
    TemplateName: string;
    TemplateData: string;
}
export type RenderedEmailTemplate = string;
export interface TestRenderEmailTemplateResponse {
    RenderedTemplate: string;
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateConfigurationSetRequest {
    ConfigurationSetName: string;
    MessageSecurityOptions?: MessageSecurityOptions | undefined;
}
export interface UpdateConfigurationSetResponse {
}
export interface UpdateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
    EventDestination: EventDestinationDefinition;
}
export interface UpdateConfigurationSetEventDestinationResponse {
}
export interface UpdateContactRequest {
    ContactListName: string;
    EmailAddress: string;
    TopicPreferences?: TopicPreference[] | undefined;
    UnsubscribeAll?: boolean | undefined;
    AttributesData?: string | undefined;
}
export interface UpdateContactResponse {
}
export interface UpdateContactListRequest {
    ContactListName: string;
    Topics?: Topic[] | undefined;
    Description?: string | undefined;
}
export interface UpdateContactListResponse {
}
export interface UpdateCustomVerificationEmailTemplateRequest {
    TemplateName: string;
    FromEmailAddress: string;
    TemplateSubject: string;
    TemplateContent: string;
    SuccessRedirectionURL: string;
    FailureRedirectionURL: string;
}
export interface UpdateCustomVerificationEmailTemplateResponse {
}
export interface UpdateEmailIdentityPolicyRequest {
    EmailIdentity: string;
    PolicyName: string;
    Policy: string;
}
export interface UpdateEmailIdentityPolicyResponse {
}
export interface UpdateEmailTemplateRequest {
    TemplateName: string;
    TemplateContent: EmailTemplateContent;
}
export interface UpdateEmailTemplateResponse {
}
export interface UpdateReputationEntityCustomerManagedStatusRequest {
    ReputationEntityType: ReputationEntityType;
    ReputationEntityReference: string;
    SendingStatus: SendingStatus;
}
export interface UpdateReputationEntityCustomerManagedStatusResponse {
}
export interface UpdateReputationEntityPolicyRequest {
    ReputationEntityType: ReputationEntityType;
    ReputationEntityReference: string;
    ReputationEntityPolicy: string;
}
export interface UpdateReputationEntityPolicyResponse {
}
export type AssociateEmailIdentityCertificateError = AlreadyExistsException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Associates an S/MIME certificate with an email identity. After the certificate is
 * active, Amazon SES API v2 can add an S/MIME signature to messages that you send from the associated
 * address when signing is enabled on the configuration set used to send the message.
 *
 * The certificate is an X.509 certificate that you manage in Certificate Manager
 * (ACM). You identify it by its Amazon Resource Name (ARN).
 *
 * - If the email identity is a domain, you must specify a `FromAddress`
 * that belongs to that domain or one of its subdomains. The certificate applies to
 * messages sent from that address.
 *
 * - If the email identity is an email address, `FromAddress` is
 * optional. If you specify it, it must exactly match the email identity.
 *
 * When the association is created, the certificate begins provisioning and its status is
 * `PROVISIONING`. The status changes to `ACTIVE` when the certificate
 * is ready to use for signing. Each email address can have only one certificate
 * association. If an association already exists for the address, this operation returns an
 * error, unless the existing association is in the `DEPROVISIONING` state.
 */
export declare const associateEmailIdentityCertificate: API.OperationMethod<AssociateEmailIdentityCertificateRequest & RegionInput, AssociateEmailIdentityCertificateResponse, AssociateEmailIdentityCertificateError, Credentials | HttpClient.HttpClient>;
export type BatchGetMetricDataError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves batches of metric data collected based on your sending activity.
 *
 * You can execute this operation no more than 16 times per second,
 * and with at most 160 queries from the batches per second (cumulative).
 */
export declare const batchGetMetricData: API.OperationMethod<BatchGetMetricDataRequest & RegionInput, BatchGetMetricDataResponse, BatchGetMetricDataError, Credentials | HttpClient.HttpClient>;
export type CancelExportJobError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Cancels an export job.
 */
export declare const cancelExportJob: API.OperationMethod<CancelExportJobRequest & RegionInput, CancelExportJobResponse, CancelExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationSetError = AlreadyExistsException | BadRequestException | ConcurrentModificationException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Create a configuration set. *Configuration sets* are groups of
 * rules that you can apply to the emails that you send. You apply a configuration set to
 * an email by specifying the name of the configuration set when you call the Amazon SES API v2. When
 * you apply a configuration set to an email, all of the rules in that configuration set
 * are applied to the email.
 */
export declare const createConfigurationSet: API.OperationMethod<CreateConfigurationSetRequest & RegionInput, CreateConfigurationSetResponse, CreateConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationSetEventDestinationError = AlreadyExistsException | BadRequestException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Create an event destination. *Events* include message sends,
 * deliveries, opens, clicks, bounces, and complaints. Event
 * destinations are places that you can send information about these events
 * to. For example, you can send event data to Amazon EventBridge and associate a rule to send the event
 * to the specified target.
 *
 * A single configuration set can include more than one event destination.
 */
export declare const createConfigurationSetEventDestination: API.OperationMethod<CreateConfigurationSetEventDestinationRequest & RegionInput, CreateConfigurationSetEventDestinationResponse, CreateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateContactError = AlreadyExistsException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a contact, which is an end-user who is receiving the email, and adds them to a
 * contact list.
 */
export declare const createContact: API.OperationMethod<CreateContactRequest & RegionInput, CreateContactResponse, CreateContactError, Credentials | HttpClient.HttpClient>;
export type CreateContactListError = AlreadyExistsException | BadRequestException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates a contact list.
 */
export declare const createContactList: API.OperationMethod<CreateContactListRequest & RegionInput, CreateContactListResponse, CreateContactListError, Credentials | HttpClient.HttpClient>;
export type CreateCustomVerificationEmailTemplateError = AlreadyExistsException | BadRequestException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new custom verification email template.
 *
 * For more information about custom verification email templates, see Using
 * custom verification email templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createCustomVerificationEmailTemplate: API.OperationMethod<CreateCustomVerificationEmailTemplateRequest & RegionInput, CreateCustomVerificationEmailTemplateResponse, CreateCustomVerificationEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateDedicatedIpPoolError = AlreadyExistsException | BadRequestException | ConcurrentModificationException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new pool of dedicated IP addresses. A pool can include one or more dedicated
 * IP addresses that are associated with your Amazon Web Services account. You can associate a pool with
 * a configuration set. When you send an email that uses that configuration set, the
 * message is sent from one of the addresses in the associated pool.
 */
export declare const createDedicatedIpPool: API.OperationMethod<CreateDedicatedIpPoolRequest & RegionInput, CreateDedicatedIpPoolResponse, CreateDedicatedIpPoolError, Credentials | HttpClient.HttpClient>;
export type CreateDeliverabilityTestReportError = AccountSuspendedException | BadRequestException | ConcurrentModificationException | LimitExceededException | MailFromDomainNotVerifiedException | MessageRejected | NotFoundException | SendingPausedException | TooManyRequestsException | CommonErrors;
/**
 * Create a new predictive inbox placement test. Predictive inbox placement tests can help you predict how your messages will be handled
 * by various email providers around the world. When you perform a predictive inbox placement test, you provide a
 * sample message that contains the content that you plan to send to your customers. Amazon SES
 * then sends that message to special email addresses spread across several major email
 * providers. After about 24 hours, the test is complete, and you can use the
 * `GetDeliverabilityTestReport` operation to view the results of the
 * test.
 */
export declare const createDeliverabilityTestReport: API.OperationMethod<CreateDeliverabilityTestReportRequest & RegionInput, CreateDeliverabilityTestReportResponse, CreateDeliverabilityTestReportError, Credentials | HttpClient.HttpClient>;
export type CreateEmailIdentityError = AlreadyExistsException | BadRequestException | ConcurrentModificationException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts the process of verifying an email identity. An *identity* is
 * an email address or domain that you use when you send email. Before you can use an
 * identity to send email, you first have to verify it. By verifying an identity, you
 * demonstrate that you're the owner of the identity, and that you've given Amazon SES API v2
 * permission to send email from the identity.
 *
 * When you verify an email address, Amazon SES sends an email to the address. Your email
 * address is verified as soon as you follow the link in the verification email.
 *
 * When you verify a domain without specifying the `DkimSigningAttributes`
 * object, this operation provides a set of DKIM tokens. You can convert these tokens into
 * CNAME records, which you then add to the DNS configuration for your domain. Your domain
 * is verified when Amazon SES detects these records in the DNS configuration for your domain.
 * This verification method is known as Easy DKIM.
 *
 * Alternatively, you can perform the verification process by providing your own
 * public-private key pair. This verification method is known as Bring Your Own DKIM
 * (BYODKIM). To use BYODKIM, your call to the `CreateEmailIdentity` operation
 * has to include the `DkimSigningAttributes` object. When you specify this
 * object, you provide a selector (a component of the DNS record name that identifies the
 * public key to use for DKIM authentication) and a private key.
 *
 * When you verify a domain, this operation provides a set of DKIM tokens, which you can
 * convert into CNAME tokens. You add these CNAME tokens to the DNS configuration for your
 * domain. Your domain is verified when Amazon SES detects these records in the DNS
 * configuration for your domain. For some DNS providers, it can take 72 hours or more to
 * complete the domain verification process.
 *
 * Additionally, you can associate an existing configuration set with the email identity that you're verifying.
 */
export declare const createEmailIdentity: API.OperationMethod<CreateEmailIdentityRequest & RegionInput, CreateEmailIdentityResponse, CreateEmailIdentityError, Credentials | HttpClient.HttpClient>;
export type CreateEmailIdentityPolicyError = AlreadyExistsException | BadRequestException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates the specified sending authorization policy for the given identity (an email
 * address or a domain).
 *
 * This API is for the identity owner only. If you have not verified the identity,
 * this API will return an error.
 *
 * Sending authorization is a feature that enables an identity owner to authorize other
 * senders to use its identities. For information about using sending authorization, see
 * the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createEmailIdentityPolicy: API.OperationMethod<CreateEmailIdentityPolicyRequest & RegionInput, CreateEmailIdentityPolicyResponse, CreateEmailIdentityPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateEmailTemplateError = AlreadyExistsException | BadRequestException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates an email template. Email templates enable you to send personalized email to
 * one or more destinations in a single API operation. For more information, see the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createEmailTemplate: API.OperationMethod<CreateEmailTemplateRequest & RegionInput, CreateEmailTemplateResponse, CreateEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateExportJobError = BadRequestException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an export job for a data source and destination.
 *
 * Export jobs run asynchronously. This operation returns a `JobId`. Call
 * `GetExportJob` with that ID until `JobStatus` is
 * `COMPLETED`, `FAILED`, or `CANCELLED`. When the
 * status is `COMPLETED`, download the export file from the pre-signed URL in
 * `ExportDestination.S3Url`. When the status is `FAILED`, see
 * `FailureInfo`. To store a copy in your own bucket, upload the downloaded
 * file to your bucket. Do not include `S3Url` in the request.
 *
 * You can execute this operation no more than once per second.
 */
export declare const createExportJob: API.OperationMethod<CreateExportJobRequest & RegionInput, CreateExportJobResponse, CreateExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateImportJobError = BadRequestException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates an import job for a data destination.
 */
export declare const createImportJob: API.OperationMethod<CreateImportJobRequest & RegionInput, CreateImportJobResponse, CreateImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateMultiRegionEndpointError = AlreadyExistsException | BadRequestException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates a multi-region endpoint (global-endpoint).
 *
 * The primary region is going to be the AWS-Region where the operation is executed.
 * The secondary region has to be provided in request's parameters.
 * From the data flow standpoint there is no difference between primary
 * and secondary regions - sending traffic is divided between the two.
 * The primary region is the region where the resource has been created and where it can be managed.
 */
export declare const createMultiRegionEndpoint: API.OperationMethod<CreateMultiRegionEndpointRequest & RegionInput, CreateMultiRegionEndpointResponse, CreateMultiRegionEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateTenantError = AlreadyExistsException | BadRequestException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a tenant.
 *
 * *Tenants* are logical containers that group related SES resources together.
 * Each tenant can have its own set of resources like email identities, configuration sets,
 * and templates, along with reputation metrics and sending status. This helps isolate and manage
 * email sending for different customers or business units within your Amazon SES API v2 account.
 *
 * You can optionally specify `SuppressionAttributes` to configure tenant-level
 * suppression at creation time. When tenant-level suppression is enabled, Amazon SES maintains a
 * separate suppression list for the tenant instead of using the account-level suppression list.
 */
export declare const createTenant: API.OperationMethod<CreateTenantRequest & RegionInput, CreateTenantResponse, CreateTenantError, Credentials | HttpClient.HttpClient>;
export type CreateTenantResourceAssociationError = AlreadyExistsException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Associate a resource with a tenant.
 *
 * *Resources* can be email identities, configuration sets, or email templates.
 * When you associate a resource with a tenant, you can use that resource when sending emails
 * on behalf of that tenant.
 *
 * A single resource can be associated with multiple tenants, allowing for resource sharing
 * across different tenants while maintaining isolation in email sending operations.
 */
export declare const createTenantResourceAssociation: API.OperationMethod<CreateTenantResourceAssociationRequest & RegionInput, CreateTenantResourceAssociationResponse, CreateTenantResourceAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an existing configuration set.
 *
 * *Configuration sets* are groups of rules that you can apply to the
 * emails you send. You apply a configuration set to an email by including a reference to
 * the configuration set in the headers of the email. When you apply a configuration set to
 * an email, all of the rules in that configuration set are applied to the email.
 */
export declare const deleteConfigurationSet: API.OperationMethod<DeleteConfigurationSetRequest & RegionInput, DeleteConfigurationSetResponse, DeleteConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetEventDestinationError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an event destination.
 *
 * *Events* include message sends, deliveries, opens, clicks, bounces,
 * and complaints. *Event destinations* are places that you can send
 * information about these events to. For example, you can send event data to Amazon EventBridge and
 * associate a rule to send the event to the specified target.
 */
export declare const deleteConfigurationSetEventDestination: API.OperationMethod<DeleteConfigurationSetEventDestinationRequest & RegionInput, DeleteConfigurationSetEventDestinationResponse, DeleteConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteContactError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes a contact from a contact list.
 */
export declare const deleteContact: API.OperationMethod<DeleteContactRequest & RegionInput, DeleteContactResponse, DeleteContactError, Credentials | HttpClient.HttpClient>;
export type DeleteContactListError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a contact list and all of the contacts on that list.
 */
export declare const deleteContactList: API.OperationMethod<DeleteContactListRequest & RegionInput, DeleteContactListResponse, DeleteContactListError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomVerificationEmailTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing custom verification email template.
 *
 * For more information about custom verification email templates, see Using
 * custom verification email templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteCustomVerificationEmailTemplate: API.OperationMethod<DeleteCustomVerificationEmailTemplateRequest & RegionInput, DeleteCustomVerificationEmailTemplateResponse, DeleteCustomVerificationEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteDedicatedIpPoolError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a dedicated IP pool.
 */
export declare const deleteDedicatedIpPool: API.OperationMethod<DeleteDedicatedIpPoolRequest & RegionInput, DeleteDedicatedIpPoolResponse, DeleteDedicatedIpPoolError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailIdentityError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an email identity. An identity can be either an email address or a domain
 * name.
 */
export declare const deleteEmailIdentity: API.OperationMethod<DeleteEmailIdentityRequest & RegionInput, DeleteEmailIdentityResponse, DeleteEmailIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailIdentityPolicyError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified sending authorization policy for the given identity (an email
 * address or a domain). This API returns successfully even if a policy with the specified
 * name does not exist.
 *
 * This API is for the identity owner only. If you have not verified the identity,
 * this API will return an error.
 *
 * Sending authorization is a feature that enables an identity owner to authorize other
 * senders to use its identities. For information about using sending authorization, see
 * the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteEmailIdentityPolicy: API.OperationMethod<DeleteEmailIdentityPolicyRequest & RegionInput, DeleteEmailIdentityPolicyResponse, DeleteEmailIdentityPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an email template.
 *
 * You can execute this operation no more than once per second.
 */
export declare const deleteEmailTemplate: API.OperationMethod<DeleteEmailTemplateRequest & RegionInput, DeleteEmailTemplateResponse, DeleteEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteMultiRegionEndpointError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a multi-region endpoint (global-endpoint).
 *
 * Only multi-region endpoints (global-endpoints) whose primary region is the AWS-Region
 * where operation is executed can be deleted.
 */
export declare const deleteMultiRegionEndpoint: API.OperationMethod<DeleteMultiRegionEndpointRequest & RegionInput, DeleteMultiRegionEndpointResponse, DeleteMultiRegionEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteSuppressedDestinationError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes an email address from the suppression list for your account or for a specific
 * tenant. To target a tenant's suppression list, specify the `TenantName`
 * parameter. If you omit `TenantName`, the address is removed from the
 * account-level suppression list.
 */
export declare const deleteSuppressedDestination: API.OperationMethod<DeleteSuppressedDestinationRequest & RegionInput, DeleteSuppressedDestinationResponse, DeleteSuppressedDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteTenantError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an existing tenant.
 *
 * When you delete a tenant, its associations with resources
 * are removed, but the resources themselves are not deleted.
 */
export declare const deleteTenant: API.OperationMethod<DeleteTenantRequest & RegionInput, DeleteTenantResponse, DeleteTenantError, Credentials | HttpClient.HttpClient>;
export type DeleteTenantResourceAssociationError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an association between a tenant and a resource.
 *
 * When you delete a tenant-resource association, the resource itself is not deleted,
 * only its association with the specific tenant is removed. After removal, the resource
 * will no longer be available for use with that tenant's email sending operations.
 */
export declare const deleteTenantResourceAssociation: API.OperationMethod<DeleteTenantResourceAssociationRequest & RegionInput, DeleteTenantResourceAssociationResponse, DeleteTenantResourceAssociationError, Credentials | HttpClient.HttpClient>;
export type DisassociateEmailIdentityCertificateError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the association between an S/MIME certificate and an email identity. After the
 * association is removed, Amazon SES API v2 stops adding an S/MIME signature to messages sent from
 * that address.
 *
 * If the email identity is a domain, specify the `FromAddress` whose
 * certificate association you want to remove.
 *
 * This operation is idempotent. If the specified email identity exists but there's no
 * matching certificate association, the operation succeeds without making any changes.
 * Amazon SES API v2 returns a `NotFoundException` only when the specified email identity
 * doesn't exist.
 */
export declare const disassociateEmailIdentityCertificate: API.OperationMethod<DisassociateEmailIdentityCertificateRequest & RegionInput, DisassociateEmailIdentityCertificateResponse, DisassociateEmailIdentityCertificateError, Credentials | HttpClient.HttpClient>;
export type GetAccountError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Obtain information about the email-sending status and capabilities of your Amazon SES
 * account in the current Amazon Web Services Region.
 */
export declare const getAccount: API.OperationMethod<GetAccountRequest & RegionInput, GetAccountResponse, GetAccountError, Credentials | HttpClient.HttpClient>;
export type GetBlacklistReportsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a list of the blacklists that your dedicated IP addresses appear on.
 */
export declare const getBlacklistReports: API.OperationMethod<GetBlacklistReportsRequest & RegionInput, GetBlacklistReportsResponse, GetBlacklistReportsError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationSetError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get information about an existing configuration set, including the dedicated IP pool
 * that it's associated with, whether or not it's enabled for sending email, and
 * more.
 *
 * *Configuration sets* are groups of rules that you can apply to the
 * emails you send. You apply a configuration set to an email by including a reference to
 * the configuration set in the headers of the email. When you apply a configuration set to
 * an email, all of the rules in that configuration set are applied to the email.
 */
export declare const getConfigurationSet: API.OperationMethod<GetConfigurationSetRequest & RegionInput, GetConfigurationSetResponse, GetConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationSetEventDestinationsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a list of event destinations that are associated with a configuration
 * set.
 *
 * *Events* include message sends, deliveries, opens, clicks, bounces,
 * and complaints. *Event destinations* are places that you can send
 * information about these events to. For example, you can send event data to Amazon EventBridge and
 * associate a rule to send the event to the specified target.
 */
export declare const getConfigurationSetEventDestinations: API.OperationMethod<GetConfigurationSetEventDestinationsRequest & RegionInput, GetConfigurationSetEventDestinationsResponse, GetConfigurationSetEventDestinationsError, Credentials | HttpClient.HttpClient>;
export type GetContactError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns a contact from a contact list.
 */
export declare const getContact: API.OperationMethod<GetContactRequest & RegionInput, GetContactResponse, GetContactError, Credentials | HttpClient.HttpClient>;
export type GetContactListError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns contact list metadata. It does not return any information about the contacts
 * present in the list.
 */
export declare const getContactList: API.OperationMethod<GetContactListRequest & RegionInput, GetContactListResponse, GetContactListError, Credentials | HttpClient.HttpClient>;
export type GetCustomVerificationEmailTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns the custom email verification template for the template name you
 * specify.
 *
 * For more information about custom verification email templates, see Using
 * custom verification email templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getCustomVerificationEmailTemplate: API.OperationMethod<GetCustomVerificationEmailTemplateRequest & RegionInput, GetCustomVerificationEmailTemplateResponse, GetCustomVerificationEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type GetDedicatedIpError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get information about a dedicated IP address, including the name of the dedicated IP
 * pool that it's associated with, as well information about the automatic warm-up process
 * for the address.
 */
export declare const getDedicatedIp: API.OperationMethod<GetDedicatedIpRequest & RegionInput, GetDedicatedIpResponse, GetDedicatedIpError, Credentials | HttpClient.HttpClient>;
export type GetDedicatedIpPoolError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve information about the dedicated pool.
 */
export declare const getDedicatedIpPool: API.OperationMethod<GetDedicatedIpPoolRequest & RegionInput, GetDedicatedIpPoolResponse, GetDedicatedIpPoolError, Credentials | HttpClient.HttpClient>;
export type GetDedicatedIpsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the dedicated IP addresses that are associated with your Amazon Web Services
 * account.
 */
export declare const getDedicatedIps: API.PaginatedOperationMethod<GetDedicatedIpsRequest & RegionInput, GetDedicatedIpsResponse, GetDedicatedIpsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDeliverabilityDashboardOptionsError = BadRequestException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve information about the status of the Deliverability dashboard for your account. When
 * the Deliverability dashboard is enabled, you gain access to reputation, deliverability, and other
 * metrics for the domains that you use to send email. You also gain the ability to perform
 * predictive inbox placement tests.
 *
 * When you use the Deliverability dashboard, you pay a monthly subscription charge, in addition
 * to any other fees that you accrue by using Amazon SES and other Amazon Web Services services. For more
 * information about the features and cost of a Deliverability dashboard subscription, see Amazon SES Pricing.
 */
export declare const getDeliverabilityDashboardOptions: API.OperationMethod<GetDeliverabilityDashboardOptionsRequest & RegionInput, GetDeliverabilityDashboardOptionsResponse, GetDeliverabilityDashboardOptionsError, Credentials | HttpClient.HttpClient>;
export type GetDeliverabilityTestReportError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the results of a predictive inbox placement test.
 */
export declare const getDeliverabilityTestReport: API.OperationMethod<GetDeliverabilityTestReportRequest & RegionInput, GetDeliverabilityTestReportResponse, GetDeliverabilityTestReportError, Credentials | HttpClient.HttpClient>;
export type GetDomainDeliverabilityCampaignError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve all the deliverability data for a specific campaign. This data is available
 * for a campaign only if the campaign sent email by using a domain that the
 * Deliverability dashboard is enabled for.
 */
export declare const getDomainDeliverabilityCampaign: API.OperationMethod<GetDomainDeliverabilityCampaignRequest & RegionInput, GetDomainDeliverabilityCampaignResponse, GetDomainDeliverabilityCampaignError, Credentials | HttpClient.HttpClient>;
export type GetDomainStatisticsReportError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve inbox placement and engagement rates for the domains that you use to send
 * email.
 */
export declare const getDomainStatisticsReport: API.OperationMethod<GetDomainStatisticsReportRequest & RegionInput, GetDomainStatisticsReportResponse, GetDomainStatisticsReportError, Credentials | HttpClient.HttpClient>;
export type GetEmailAddressInsightsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Provides validation insights about a specific email address, including syntax validation, DNS record checks, mailbox existence, and other deliverability factors.
 */
export declare const getEmailAddressInsights: API.OperationMethod<GetEmailAddressInsightsRequest & RegionInput, GetEmailAddressInsightsResponse, GetEmailAddressInsightsError, Credentials | HttpClient.HttpClient>;
export type GetEmailIdentityError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides information about a specific identity, including the identity's verification
 * status, sending authorization policies, its DKIM authentication status, and its custom
 * Mail-From settings.
 */
export declare const getEmailIdentity: API.OperationMethod<GetEmailIdentityRequest & RegionInput, GetEmailIdentityResponse, GetEmailIdentityError, Credentials | HttpClient.HttpClient>;
export type GetEmailIdentityPoliciesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns the requested sending authorization policies for the given identity (an email
 * address or a domain). The policies are returned as a map of policy names to policy
 * contents. You can retrieve a maximum of 20 policies at a time.
 *
 * This API is for the identity owner only. If you have not verified the identity,
 * this API will return an error.
 *
 * Sending authorization is a feature that enables an identity owner to authorize other
 * senders to use its identities. For information about using sending authorization, see
 * the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getEmailIdentityPolicies: API.OperationMethod<GetEmailIdentityPoliciesRequest & RegionInput, GetEmailIdentityPoliciesResponse, GetEmailIdentityPoliciesError, Credentials | HttpClient.HttpClient>;
export type GetEmailTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Displays the template object (which includes the subject line, HTML part and text
 * part) for the template you specify.
 *
 * You can execute this operation no more than 50 times per second.
 */
export declare const getEmailTemplate: API.OperationMethod<GetEmailTemplateRequest & RegionInput, GetEmailTemplateResponse, GetEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type GetExportJobError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides information about an export job.
 *
 * When the job status is `COMPLETED`, the response includes a pre-signed
 * URL in `ExportDestination.S3Url` that you use to download the export
 * file.
 */
export declare const getExportJob: API.OperationMethod<GetExportJobRequest & RegionInput, GetExportJobResponse, GetExportJobError, Credentials | HttpClient.HttpClient>;
export type GetImportJobError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides information about an import job.
 */
export declare const getImportJob: API.OperationMethod<GetImportJobRequest & RegionInput, GetImportJobResponse, GetImportJobError, Credentials | HttpClient.HttpClient>;
export type GetMessageInsightsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides information about a specific message, including the from address, the
 * subject, the recipient address, email tags, as well as events associated with the message.
 *
 * You can execute this operation no more than once per second.
 */
export declare const getMessageInsights: API.OperationMethod<GetMessageInsightsRequest & RegionInput, GetMessageInsightsResponse, GetMessageInsightsError, Credentials | HttpClient.HttpClient>;
export type GetMultiRegionEndpointError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Displays the multi-region endpoint (global-endpoint) configuration.
 *
 * Only multi-region endpoints (global-endpoints) whose primary region is the AWS-Region
 * where operation is executed can be displayed.
 */
export declare const getMultiRegionEndpoint: API.OperationMethod<GetMultiRegionEndpointRequest & RegionInput, GetMultiRegionEndpointResponse, GetMultiRegionEndpointError, Credentials | HttpClient.HttpClient>;
export type GetReputationEntityError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve information about a specific reputation entity, including its reputation
 * management policy, customer-managed status, Amazon Web Services Amazon SES-managed status, and aggregate
 * sending status.
 *
 * *Reputation entities* represent resources in your Amazon SES account that have reputation
 * tracking and management capabilities. The reputation impact reflects the highest
 * impact reputation finding for the entity. Reputation findings can be retrieved
 * using the `ListRecommendations` operation.
 */
export declare const getReputationEntity: API.OperationMethod<GetReputationEntityRequest & RegionInput, GetReputationEntityResponse, GetReputationEntityError, Credentials | HttpClient.HttpClient>;
export type GetSuppressedDestinationError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a specific email address that's on the suppression list
 * for your account or for a specific tenant. To target a tenant's suppression list,
 * specify the `TenantName` parameter. If you omit `TenantName`,
 * the operation targets the account-level suppression list.
 */
export declare const getSuppressedDestination: API.OperationMethod<GetSuppressedDestinationRequest & RegionInput, GetSuppressedDestinationResponse, GetSuppressedDestinationError, Credentials | HttpClient.HttpClient>;
export type GetTenantError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get information about a specific tenant, including the tenant's name, ID, ARN,
 * creation timestamp, tags, sending status, and suppression attributes.
 */
export declare const getTenant: API.OperationMethod<GetTenantRequest & RegionInput, GetTenantResponse, GetTenantError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationSetsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * List all of the configuration sets associated with your account in the current
 * region.
 *
 * *Configuration sets* are groups of rules that you can apply to the
 * emails you send. You apply a configuration set to an email by including a reference to
 * the configuration set in the headers of the email. When you apply a configuration set to
 * an email, all of the rules in that configuration set are applied to the email.
 */
export declare const listConfigurationSets: API.PaginatedOperationMethod<ListConfigurationSetsRequest & RegionInput, ListConfigurationSetsResponse, ListConfigurationSetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListContactListsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the contact lists available.
 *
 * If your output includes a "NextToken" field with a string value, this indicates there may be additional
 * contacts on the filtered list - regardless of the number of contacts returned.
 */
export declare const listContactLists: API.PaginatedOperationMethod<ListContactListsRequest & RegionInput, ListContactListsResponse, ListContactListsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListContactsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the contacts present in a specific contact list.
 */
export declare const listContacts: API.PaginatedOperationMethod<ListContactsRequest & RegionInput, ListContactsResponse, ListContactsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCustomVerificationEmailTemplatesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists the existing custom verification email templates for your account in the current
 * Amazon Web Services Region.
 *
 * For more information about custom verification email templates, see Using
 * custom verification email templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const listCustomVerificationEmailTemplates: API.PaginatedOperationMethod<ListCustomVerificationEmailTemplatesRequest & RegionInput, ListCustomVerificationEmailTemplatesResponse, ListCustomVerificationEmailTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDedicatedIpPoolsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * List all of the dedicated IP pools that exist in your Amazon Web Services account in the current
 * Region.
 */
export declare const listDedicatedIpPools: API.PaginatedOperationMethod<ListDedicatedIpPoolsRequest & RegionInput, ListDedicatedIpPoolsResponse, ListDedicatedIpPoolsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDeliverabilityTestReportsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Show a list of the predictive inbox placement tests that you've performed, regardless of their statuses. For
 * predictive inbox placement tests that are complete, you can use the `GetDeliverabilityTestReport`
 * operation to view the results.
 */
export declare const listDeliverabilityTestReports: API.PaginatedOperationMethod<ListDeliverabilityTestReportsRequest & RegionInput, ListDeliverabilityTestReportsResponse, ListDeliverabilityTestReportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDomainDeliverabilityCampaignsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve deliverability data for all the campaigns that used a specific domain to send
 * email during a specified time range. This data is available for a domain only if you
 * enabled the Deliverability dashboard for the domain.
 */
export declare const listDomainDeliverabilityCampaigns: API.PaginatedOperationMethod<ListDomainDeliverabilityCampaignsRequest & RegionInput, ListDomainDeliverabilityCampaignsResponse, ListDomainDeliverabilityCampaignsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEmailIdentitiesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of all of the email identities that are associated with your Amazon Web Services
 * account. An identity can be either an email address or a domain. This operation returns
 * identities that are verified as well as those that aren't. This operation returns
 * identities that are associated with Amazon SES and Amazon Pinpoint.
 */
export declare const listEmailIdentities: API.PaginatedOperationMethod<ListEmailIdentitiesRequest & RegionInput, ListEmailIdentitiesResponse, ListEmailIdentitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEmailIdentityCertificatesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the S/MIME certificates that are associated with the specified email identity.
 * The results include certificates in all states, such as `PROVISIONING`,
 * `ACTIVE`, `INACTIVE`, `DEPROVISIONING`, and
 * `FAILED`.
 *
 * If a certificate has passed its expiration time, it's returned with a status of
 * `FAILED`.
 *
 * We recommend using pagination to ensure that the operation returns quickly and
 * successfully. When there are more results than fit in a single response, the response
 * includes a `NextToken` value that you use in a subsequent call to retrieve
 * the next set of results.
 */
export declare const listEmailIdentityCertificates: API.PaginatedOperationMethod<ListEmailIdentityCertificatesRequest & RegionInput, ListEmailIdentityCertificatesResponse, ListEmailIdentityCertificatesError, Credentials | HttpClient.HttpClient, IdentityCertificate>;
export type ListEmailTemplatesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists the email templates present in your Amazon SES account in the current Amazon Web Services
 * Region.
 *
 * You can execute this operation no more than once per second.
 */
export declare const listEmailTemplates: API.PaginatedOperationMethod<ListEmailTemplatesRequest & RegionInput, ListEmailTemplatesResponse, ListEmailTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExportJobsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the export jobs.
 */
export declare const listExportJobs: API.PaginatedOperationMethod<ListExportJobsRequest & RegionInput, ListExportJobsResponse, ListExportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListImportJobsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the import jobs.
 */
export declare const listImportJobs: API.PaginatedOperationMethod<ListImportJobsRequest & RegionInput, ListImportJobsResponse, ListImportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMultiRegionEndpointsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * List the multi-region endpoints (global-endpoints).
 *
 * Only multi-region endpoints (global-endpoints) whose primary region is the AWS-Region
 * where operation is executed will be listed.
 */
export declare const listMultiRegionEndpoints: API.PaginatedOperationMethod<ListMultiRegionEndpointsRequest & RegionInput, ListMultiRegionEndpointsResponse, ListMultiRegionEndpointsError, Credentials | HttpClient.HttpClient, MultiRegionEndpoint>;
export type ListRecommendationsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the recommendations present in your Amazon SES account in the current Amazon Web Services Region.
 *
 * You can execute this operation no more than once per second.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest & RegionInput, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListReputationEntitiesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * List reputation entities in your Amazon SES account in the current Amazon Web Services Region.
 * You can filter the results by entity type, reputation impact, sending status,
 * or entity reference prefix.
 *
 * *Reputation entities* represent resources in your account that have reputation
 * tracking and management capabilities. Use this operation to get an overview of
 * all entities and their current reputation status.
 */
export declare const listReputationEntities: API.PaginatedOperationMethod<ListReputationEntitiesRequest & RegionInput, ListReputationEntitiesResponse, ListReputationEntitiesError, Credentials | HttpClient.HttpClient, ReputationEntity>;
export type ListResourceTenantsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List all tenants associated with a specific resource.
 *
 * This operation returns a list of tenants that are associated with the specified
 * resource. This is useful for understanding which tenants are currently using a particular
 * resource such as an email identity, configuration set, or email template.
 */
export declare const listResourceTenants: API.PaginatedOperationMethod<ListResourceTenantsRequest & RegionInput, ListResourceTenantsResponse, ListResourceTenantsError, Credentials | HttpClient.HttpClient, ResourceTenantMetadata>;
export type ListSuppressedDestinationsError = BadRequestException | InvalidNextTokenException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of email addresses that are on the suppression list for your
 * account or for a specific tenant. To target a tenant's suppression list, specify the
 * `TenantName` parameter. If you omit `TenantName`, the operation
 * targets the account-level suppression list.
 */
export declare const listSuppressedDestinations: API.PaginatedOperationMethod<ListSuppressedDestinationsRequest & RegionInput, ListSuppressedDestinationsResponse, ListSuppressedDestinationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a list of the tags (keys and values) that are associated with a specified
 * resource. A *tag* is a label that you optionally define and associate
 * with a resource. Each tag consists of a required *tag key* and an
 * optional associated *tag value*. A tag key is a general label that
 * acts as a category for more specific tag values. A tag value acts as a descriptor within
 * a tag key.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTenantResourcesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List all resources associated with a specific tenant.
 *
 * This operation returns a list of resources (email identities, configuration sets,
 * or email templates) that are associated with the specified tenant. You can optionally
 * filter the results by resource type.
 */
export declare const listTenantResources: API.PaginatedOperationMethod<ListTenantResourcesRequest & RegionInput, ListTenantResourcesResponse, ListTenantResourcesError, Credentials | HttpClient.HttpClient, TenantResource>;
export type ListTenantsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * List all tenants associated with your account in the current Amazon Web Services Region.
 *
 * This operation returns basic information about each tenant,
 * such as tenant name, ID, ARN, and creation timestamp.
 */
export declare const listTenants: API.PaginatedOperationMethod<ListTenantsRequest & RegionInput, ListTenantsResponse, ListTenantsError, Credentials | HttpClient.HttpClient, TenantInfo>;
export type PutAccountDedicatedIpWarmupAttributesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable the automatic warm-up feature for dedicated IP addresses.
 */
export declare const putAccountDedicatedIpWarmupAttributes: API.OperationMethod<PutAccountDedicatedIpWarmupAttributesRequest & RegionInput, PutAccountDedicatedIpWarmupAttributesResponse, PutAccountDedicatedIpWarmupAttributesError, Credentials | HttpClient.HttpClient>;
export type PutAccountDetailsError = BadRequestException | ConflictException | TooManyRequestsException | CommonErrors;
/**
 * Update your Amazon SES account details.
 */
export declare const putAccountDetails: API.OperationMethod<PutAccountDetailsRequest & RegionInput, PutAccountDetailsResponse, PutAccountDetailsError, Credentials | HttpClient.HttpClient>;
export type PutAccountPricingAttributesError = BadRequestException | ConflictException | TooManyRequestsException | CommonErrors;
/**
 * Set the pricing plan for your Amazon SES account.
 */
export declare const putAccountPricingAttributes: API.OperationMethod<PutAccountPricingAttributesRequest & RegionInput, PutAccountPricingAttributesResponse, PutAccountPricingAttributesError, Credentials | HttpClient.HttpClient>;
export type PutAccountSendingAttributesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable the ability of your account to send email.
 */
export declare const putAccountSendingAttributes: API.OperationMethod<PutAccountSendingAttributesRequest & RegionInput, PutAccountSendingAttributesResponse, PutAccountSendingAttributesError, Credentials | HttpClient.HttpClient>;
export type PutAccountSuppressionAttributesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Change the settings for the account-level suppression list.
 */
export declare const putAccountSuppressionAttributes: API.OperationMethod<PutAccountSuppressionAttributesRequest & RegionInput, PutAccountSuppressionAttributesResponse, PutAccountSuppressionAttributesError, Credentials | HttpClient.HttpClient>;
export type PutAccountVdmAttributesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Update your Amazon SES account VDM attributes.
 *
 * You can execute this operation no more than once per second.
 */
export declare const putAccountVdmAttributes: API.OperationMethod<PutAccountVdmAttributesRequest & RegionInput, PutAccountVdmAttributesResponse, PutAccountVdmAttributesError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetArchivingOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Associate the configuration set with a MailManager archive. When you send email using the
 * `SendEmail` or `SendBulkEmail` operations the message as it will be given
 * to the receiving SMTP server will be archived, along with the recipient information.
 */
export declare const putConfigurationSetArchivingOptions: API.OperationMethod<PutConfigurationSetArchivingOptionsRequest & RegionInput, PutConfigurationSetArchivingOptionsResponse, PutConfigurationSetArchivingOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetDeliveryOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Associate a configuration set with a dedicated IP pool. You can use dedicated IP pools
 * to create groups of dedicated IP addresses for sending specific types of email.
 */
export declare const putConfigurationSetDeliveryOptions: API.OperationMethod<PutConfigurationSetDeliveryOptionsRequest & RegionInput, PutConfigurationSetDeliveryOptionsResponse, PutConfigurationSetDeliveryOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetReputationOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable collection of reputation metrics for emails that you send using a
 * particular configuration set in a specific Amazon Web Services Region.
 */
export declare const putConfigurationSetReputationOptions: API.OperationMethod<PutConfigurationSetReputationOptionsRequest & RegionInput, PutConfigurationSetReputationOptionsResponse, PutConfigurationSetReputationOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetSendingOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable email sending for messages that use a particular configuration set
 * in a specific Amazon Web Services Region.
 */
export declare const putConfigurationSetSendingOptions: API.OperationMethod<PutConfigurationSetSendingOptionsRequest & RegionInput, PutConfigurationSetSendingOptionsResponse, PutConfigurationSetSendingOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetSuppressionOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Specify the suppression list preferences for a configuration set. You can
 * also use this operation to specify a `SuppressionScope` to override the
 * suppression scope of the tenant or account for emails sent using this configuration
 * set.
 */
export declare const putConfigurationSetSuppressionOptions: API.OperationMethod<PutConfigurationSetSuppressionOptionsRequest & RegionInput, PutConfigurationSetSuppressionOptionsResponse, PutConfigurationSetSuppressionOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetTrackingOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Specify a custom domain to use for open and click tracking elements in email that you
 * send.
 */
export declare const putConfigurationSetTrackingOptions: API.OperationMethod<PutConfigurationSetTrackingOptionsRequest & RegionInput, PutConfigurationSetTrackingOptionsResponse, PutConfigurationSetTrackingOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetVdmOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Specify VDM preferences for email that you send using the configuration set.
 *
 * You can execute this operation no more than once per second.
 */
export declare const putConfigurationSetVdmOptions: API.OperationMethod<PutConfigurationSetVdmOptionsRequest & RegionInput, PutConfigurationSetVdmOptionsResponse, PutConfigurationSetVdmOptionsError, Credentials | HttpClient.HttpClient>;
export type PutDedicatedIpInPoolError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Move a dedicated IP address to an existing dedicated IP pool.
 *
 * The dedicated IP address that you specify must already exist, and must be
 * associated with your Amazon Web Services account.
 *
 * The dedicated IP pool you specify must already exist. You can create a new pool by
 * using the `CreateDedicatedIpPool` operation.
 */
export declare const putDedicatedIpInPool: API.OperationMethod<PutDedicatedIpInPoolRequest & RegionInput, PutDedicatedIpInPoolResponse, PutDedicatedIpInPoolError, Credentials | HttpClient.HttpClient>;
export type PutDedicatedIpPoolScalingAttributesError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to convert a dedicated IP pool to a different scaling mode.
 *
 * `MANAGED` pools cannot be converted to `STANDARD` scaling mode.
 */
export declare const putDedicatedIpPoolScalingAttributes: API.OperationMethod<PutDedicatedIpPoolScalingAttributesRequest & RegionInput, PutDedicatedIpPoolScalingAttributesResponse, PutDedicatedIpPoolScalingAttributesError, Credentials | HttpClient.HttpClient>;
export type PutDedicatedIpWarmupAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 *
 */
export declare const putDedicatedIpWarmupAttributes: API.OperationMethod<PutDedicatedIpWarmupAttributesRequest & RegionInput, PutDedicatedIpWarmupAttributesResponse, PutDedicatedIpWarmupAttributesError, Credentials | HttpClient.HttpClient>;
export type PutDeliverabilityDashboardOptionError = AlreadyExistsException | BadRequestException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable the Deliverability dashboard. When you enable the Deliverability dashboard, you gain
 * access to reputation, deliverability, and other metrics for the domains that you use to
 * send email. You also gain the ability to perform predictive inbox placement tests.
 *
 * When you use the Deliverability dashboard, you pay a monthly subscription charge, in addition
 * to any other fees that you accrue by using Amazon SES and other Amazon Web Services services. For more
 * information about the features and cost of a Deliverability dashboard subscription, see Amazon SES Pricing.
 */
export declare const putDeliverabilityDashboardOption: API.OperationMethod<PutDeliverabilityDashboardOptionRequest & RegionInput, PutDeliverabilityDashboardOptionResponse, PutDeliverabilityDashboardOptionError, Credentials | HttpClient.HttpClient>;
export type PutEmailIdentityConfigurationSetAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to associate a configuration set with an email identity.
 */
export declare const putEmailIdentityConfigurationSetAttributes: API.OperationMethod<PutEmailIdentityConfigurationSetAttributesRequest & RegionInput, PutEmailIdentityConfigurationSetAttributesResponse, PutEmailIdentityConfigurationSetAttributesError, Credentials | HttpClient.HttpClient>;
export type PutEmailIdentityDkimAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to enable or disable DKIM authentication for an email identity.
 */
export declare const putEmailIdentityDkimAttributes: API.OperationMethod<PutEmailIdentityDkimAttributesRequest & RegionInput, PutEmailIdentityDkimAttributesResponse, PutEmailIdentityDkimAttributesError, Credentials | HttpClient.HttpClient>;
export type PutEmailIdentityDkimSigningAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to configure or change the DKIM authentication settings for an email domain
 * identity. You can use this operation to do any of the following:
 *
 * - Update the signing attributes for an identity that uses Bring Your Own DKIM
 * (BYODKIM).
 *
 * - Update the key length that should be used for Easy DKIM.
 *
 * - Change from using no DKIM authentication to using Easy DKIM.
 *
 * - Change from using no DKIM authentication to using BYODKIM.
 *
 * - Change from using Easy DKIM to using BYODKIM.
 *
 * - Change from using BYODKIM to using Easy DKIM.
 */
export declare const putEmailIdentityDkimSigningAttributes: API.OperationMethod<PutEmailIdentityDkimSigningAttributesRequest & RegionInput, PutEmailIdentityDkimSigningAttributesResponse, PutEmailIdentityDkimSigningAttributesError, Credentials | HttpClient.HttpClient>;
export type PutEmailIdentityFeedbackAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to enable or disable feedback forwarding for an identity. This setting determines
 * what happens when an identity is used to send an email that results in a bounce or
 * complaint event.
 *
 * If the value is `true`, you receive email notifications when bounce or
 * complaint events occur. These notifications are sent to the address that you specified
 * in the `Return-Path` header of the original email.
 *
 * You're required to have a method of tracking bounces and complaints. If you haven't
 * set up another mechanism for receiving bounce or complaint notifications (for example,
 * by setting up an event destination), you receive an email notification when these events
 * occur (even if this setting is disabled).
 */
export declare const putEmailIdentityFeedbackAttributes: API.OperationMethod<PutEmailIdentityFeedbackAttributesRequest & RegionInput, PutEmailIdentityFeedbackAttributesResponse, PutEmailIdentityFeedbackAttributesError, Credentials | HttpClient.HttpClient>;
export type PutEmailIdentityMailFromAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to enable or disable the custom Mail-From domain configuration for an email
 * identity.
 */
export declare const putEmailIdentityMailFromAttributes: API.OperationMethod<PutEmailIdentityMailFromAttributesRequest & RegionInput, PutEmailIdentityMailFromAttributesResponse, PutEmailIdentityMailFromAttributesError, Credentials | HttpClient.HttpClient>;
export type PutSuppressedDestinationError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Adds an email address to the suppression list for your account or for a specific
 * tenant. To target a tenant's suppression list, specify the `TenantName`
 * parameter. If you omit `TenantName`, the address is added to the
 * account-level suppression list.
 */
export declare const putSuppressedDestination: API.OperationMethod<PutSuppressedDestinationRequest & RegionInput, PutSuppressedDestinationResponse, PutSuppressedDestinationError, Credentials | HttpClient.HttpClient>;
export type PutTenantSuppressionAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Configure the suppression list preferences for a tenant. Use this operation to enable
 * or disable tenant-level suppression, or to change the suppressed reasons for a tenant.
 *
 * When you set the suppression scope to `TENANT`, Amazon SES maintains a separate
 * suppression list for the tenant. When you set the scope to `ACCOUNT`, the tenant
 * uses the account-level suppression list.
 */
export declare const putTenantSuppressionAttributes: API.OperationMethod<PutTenantSuppressionAttributesRequest & RegionInput, PutTenantSuppressionAttributesResponse, PutTenantSuppressionAttributesError, Credentials | HttpClient.HttpClient>;
export type SendBulkEmailError = AccountSuspendedException | BadRequestException | LimitExceededException | MailFromDomainNotVerifiedException | MessageRejected | NotFoundException | SendingPausedException | TooManyRequestsException | CommonErrors;
/**
 * Composes an email message to multiple destinations.
 */
export declare const sendBulkEmail: API.OperationMethod<SendBulkEmailRequest & RegionInput, SendBulkEmailResponse, SendBulkEmailError, Credentials | HttpClient.HttpClient>;
export type SendCustomVerificationEmailError = BadRequestException | LimitExceededException | MailFromDomainNotVerifiedException | MessageRejected | NotFoundException | SendingPausedException | TooManyRequestsException | CommonErrors;
/**
 * Adds an email address to the list of identities for your Amazon SES account in the current
 * Amazon Web Services Region and attempts to verify it. As a result of executing this
 * operation, a customized verification email is sent to the specified address.
 *
 * To use this operation, you must first create a custom verification email template. For
 * more information about creating and using custom verification email templates, see
 * Using
 * custom verification email templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const sendCustomVerificationEmail: API.OperationMethod<SendCustomVerificationEmailRequest & RegionInput, SendCustomVerificationEmailResponse, SendCustomVerificationEmailError, Credentials | HttpClient.HttpClient>;
export type SendEmailError = AccountSuspendedException | BadRequestException | LimitExceededException | MailFromDomainNotVerifiedException | MessageRejected | NotFoundException | SendingPausedException | TooManyRequestsException | CommonErrors;
/**
 * Sends an email message. You can use the Amazon SES API v2 to send the following types of
 * messages:
 *
 * - **Simple** - A standard email message. When
 * you create this type of message, you specify the sender, the recipient, and the
 * message body, and Amazon SES assembles the message for you.
 *
 * - **Raw** - A raw, MIME-formatted email
 * message. When you send this type of email, you have to specify all of the
 * message headers, as well as the message body. You can use this message type to
 * send messages that contain attachments. The message that you specify has to be a
 * valid MIME message.
 *
 * - **Templated** - A message that contains
 * personalization tags. When you send this type of email, Amazon SES API v2 automatically
 * replaces the tags with values that you specify.
 */
export declare const sendEmail: API.OperationMethod<SendEmailRequest & RegionInput, SendEmailResponse, SendEmailError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Add one or more tags (keys and values) to a specified resource. A
 * *tag* is a label that you optionally define and associate with a
 * resource. Tags can help you categorize and manage resources in different ways, such as
 * by purpose, owner, environment, or other criteria. A resource can have as many as 50
 * tags.
 *
 * Each tag consists of a required *tag key* and an
 * associated *tag value*, both of which you define. A tag key is a
 * general label that acts as a category for more specific tag values. A tag value acts as
 * a descriptor within a tag key.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestRenderEmailTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a preview of the MIME content of an email when provided with a template and a
 * set of replacement data.
 *
 * You can execute this operation no more than once per second.
 */
export declare const testRenderEmailTemplate: API.OperationMethod<TestRenderEmailTemplateRequest & RegionInput, TestRenderEmailTemplateResponse, TestRenderEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Remove one or more tags (keys and values) from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing configuration set.
 *
 * This operation performs a partial update. Only the attributes that you include in the
 * request are updated; any omitted attribute is left unchanged.
 */
export declare const updateConfigurationSet: API.OperationMethod<UpdateConfigurationSetRequest & RegionInput, UpdateConfigurationSetResponse, UpdateConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetEventDestinationError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Update the configuration of an event destination for a configuration set.
 *
 * *Events* include message sends, deliveries, opens, clicks, bounces,
 * and complaints. *Event destinations* are places that you can send
 * information about these events to. For example, you can send event data to Amazon EventBridge and
 * associate a rule to send the event to the specified target.
 */
export declare const updateConfigurationSetEventDestination: API.OperationMethod<UpdateConfigurationSetEventDestinationRequest & RegionInput, UpdateConfigurationSetEventDestinationResponse, UpdateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateContactError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a contact's preferences for a list.
 *
 * You must specify all existing topic preferences in the
 * `TopicPreferences` object, not just the ones that need updating;
 * otherwise, all your existing preferences will be removed.
 */
export declare const updateContact: API.OperationMethod<UpdateContactRequest & RegionInput, UpdateContactResponse, UpdateContactError, Credentials | HttpClient.HttpClient>;
export type UpdateContactListError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates contact list metadata. This operation does a complete replacement.
 */
export declare const updateContactList: API.OperationMethod<UpdateContactListRequest & RegionInput, UpdateContactListResponse, UpdateContactListError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomVerificationEmailTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing custom verification email template.
 *
 * For more information about custom verification email templates, see Using
 * custom verification email templates in the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateCustomVerificationEmailTemplate: API.OperationMethod<UpdateCustomVerificationEmailTemplateRequest & RegionInput, UpdateCustomVerificationEmailTemplateResponse, UpdateCustomVerificationEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateEmailIdentityPolicyError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified sending authorization policy for the given identity (an email
 * address or a domain). This API returns successfully even if a policy with the specified
 * name does not exist.
 *
 * This API is for the identity owner only. If you have not verified the identity,
 * this API will return an error.
 *
 * Sending authorization is a feature that enables an identity owner to authorize other
 * senders to use its identities. For information about using sending authorization, see
 * the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateEmailIdentityPolicy: API.OperationMethod<UpdateEmailIdentityPolicyRequest & RegionInput, UpdateEmailIdentityPolicyResponse, UpdateEmailIdentityPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateEmailTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an email template. Email templates enable you to send personalized email to
 * one or more destinations in a single API operation. For more information, see the Amazon SES Developer
 * Guide.
 *
 * You can execute this operation no more than once per second.
 */
export declare const updateEmailTemplate: API.OperationMethod<UpdateEmailTemplateRequest & RegionInput, UpdateEmailTemplateResponse, UpdateEmailTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateReputationEntityCustomerManagedStatusError = BadRequestException | ConflictException | TooManyRequestsException | CommonErrors;
/**
 * Update the customer-managed sending status for a reputation entity. This allows
 * you to enable, disable, or reinstate sending for the entity.
 *
 * The customer-managed status works in conjunction with the Amazon Web Services Amazon SES-managed status
 * to determine the overall sending capability. When you update the customer-managed status,
 * the Amazon Web Services Amazon SES-managed status remains unchanged. If Amazon Web Services Amazon SES has disabled the entity,
 * it will not be allowed to send regardless of the customer-managed status setting. When you
 * reinstate an entity through the customer-managed status, it can continue sending only if
 * the Amazon Web Services Amazon SES-managed status also permits sending, even if there are active reputation
 * findings, until the findings are resolved or new violations occur.
 */
export declare const updateReputationEntityCustomerManagedStatus: API.OperationMethod<UpdateReputationEntityCustomerManagedStatusRequest & RegionInput, UpdateReputationEntityCustomerManagedStatusResponse, UpdateReputationEntityCustomerManagedStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateReputationEntityPolicyError = BadRequestException | ConflictException | TooManyRequestsException | CommonErrors;
/**
 * Update the reputation management policy for a reputation entity. The policy
 * determines how the entity responds to reputation findings, such as automatically
 * pausing sending when certain thresholds are exceeded.
 *
 * Reputation management policies are Amazon Web Services Amazon SES-managed (predefined policies).
 * You can select from none, standard, and strict policies.
 */
export declare const updateReputationEntityPolicy: API.OperationMethod<UpdateReputationEntityPolicyRequest & RegionInput, UpdateReputationEntityPolicyResponse, UpdateReputationEntityPolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sesv2.d.ts.map