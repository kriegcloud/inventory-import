import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictingOperationException_base: S.TaggedErrorClass<"ConflictingOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictingOperationException extends /*@__PURE__*/ ConflictingOperationException_base {
}
declare const CustomMetadataLimitExceededException_base: S.TaggedErrorClass<"CustomMetadataLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class CustomMetadataLimitExceededException extends /*@__PURE__*/ CustomMetadataLimitExceededException_base {
}
declare const DeactivatingLastSystemUserException_base: S.TaggedErrorClass<"DeactivatingLastSystemUserException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DeactivatingLastSystemUserException extends /*@__PURE__*/ DeactivatingLastSystemUserException_base {
}
declare const DocumentLockedForCommentsException_base: S.TaggedErrorClass<"DocumentLockedForCommentsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DocumentLockedForCommentsException extends /*@__PURE__*/ DocumentLockedForCommentsException_base {
}
declare const DraftUploadOutOfSyncException_base: S.TaggedErrorClass<"DraftUploadOutOfSyncException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DraftUploadOutOfSyncException extends /*@__PURE__*/ DraftUploadOutOfSyncException_base {
}
declare const EntityAlreadyExistsException_base: S.TaggedErrorClass<"EntityAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EntityAlreadyExistsException extends /*@__PURE__*/ EntityAlreadyExistsException_base {
}
declare const EntityNotExistsException_base: S.TaggedErrorClass<"EntityNotExistsException", {
    readonly message: any;
    readonly EntityIds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EntityNotExistsException extends /*@__PURE__*/ EntityNotExistsException_base {
}
declare const FailedDependencyException_base: S.TaggedErrorClass<"FailedDependencyException", {
    readonly message: any;
}>;
export declare class FailedDependencyException extends /*@__PURE__*/ FailedDependencyException_base {
}
declare const IllegalUserStateException_base: S.TaggedErrorClass<"IllegalUserStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IllegalUserStateException extends /*@__PURE__*/ IllegalUserStateException_base {
}
declare const InvalidArgumentException_base: S.TaggedErrorClass<"InvalidArgumentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgumentException extends /*@__PURE__*/ InvalidArgumentException_base {
}
declare const InvalidCommentOperationException_base: S.TaggedErrorClass<"InvalidCommentOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidCommentOperationException extends /*@__PURE__*/ InvalidCommentOperationException_base {
}
declare const InvalidOperationException_base: S.TaggedErrorClass<"InvalidOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidPasswordException_base: S.TaggedErrorClass<"InvalidPasswordException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InvalidPasswordException extends /*@__PURE__*/ InvalidPasswordException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ProhibitedStateException_base: S.TaggedErrorClass<"ProhibitedStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ProhibitedStateException extends /*@__PURE__*/ ProhibitedStateException_base {
}
declare const RequestedEntityTooLargeException_base: S.TaggedErrorClass<"RequestedEntityTooLargeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestedEntityTooLargeException extends /*@__PURE__*/ RequestedEntityTooLargeException_base {
}
declare const ResourceAlreadyCheckedOutException_base: S.TaggedErrorClass<"ResourceAlreadyCheckedOutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceAlreadyCheckedOutException extends /*@__PURE__*/ ResourceAlreadyCheckedOutException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const StorageLimitExceededException_base: S.TaggedErrorClass<"StorageLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class StorageLimitExceededException extends /*@__PURE__*/ StorageLimitExceededException_base {
}
declare const StorageLimitWillExceedException_base: S.TaggedErrorClass<"StorageLimitWillExceedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageLimitWillExceedException extends /*@__PURE__*/ StorageLimitWillExceedException_base {
}
declare const TooManyLabelsException_base: S.TaggedErrorClass<"TooManyLabelsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyLabelsException extends /*@__PURE__*/ TooManyLabelsException_base {
}
declare const TooManySubscriptionsException_base: S.TaggedErrorClass<"TooManySubscriptionsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManySubscriptionsException extends /*@__PURE__*/ TooManySubscriptionsException_base {
}
declare const UnauthorizedOperationException_base: S.TaggedErrorClass<"UnauthorizedOperationException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedOperationException extends /*@__PURE__*/ UnauthorizedOperationException_base {
}
declare const UnauthorizedResourceAccessException_base: S.TaggedErrorClass<"UnauthorizedResourceAccessException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedResourceAccessException extends /*@__PURE__*/ UnauthorizedResourceAccessException_base {
}
export type AuthenticationHeaderType = string | redacted.Redacted<string>;
export type ResourceIdType = string;
export type DocumentVersionIdType = string;
export interface AbortDocumentVersionUploadRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    VersionId: string;
}
export interface AbortDocumentVersionUploadResponse {
}
export type IdType = string;
export interface ActivateUserRequest {
    UserId: string;
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
}
export type UsernameType = string | redacted.Redacted<string>;
export type EmailAddressType = string | redacted.Redacted<string>;
export type UserAttributeValueType = string | redacted.Redacted<string>;
export type UserStatusType = "ACTIVE" | "INACTIVE" | "PENDING" | (string & {});
export type UserType = "USER" | "ADMIN" | "POWERUSER" | "MINIMALUSER" | "WORKSPACESUSER" | (string & {});
export type TimeZoneIdType = string;
export type LocaleType = "en" | "fr" | "ko" | "de" | "es" | "ja" | "ru" | "zh_CN" | "zh_TW" | "pt_BR" | "default" | (string & {});
export type SizeType = number;
export type PositiveSizeType = number;
export type StorageType = "UNLIMITED" | "QUOTA" | (string & {});
export interface StorageRuleType {
    StorageAllocatedInBytes?: number | undefined;
    StorageType?: StorageType | undefined;
}
export interface UserStorageMetadata {
    StorageUtilizedInBytes?: number | undefined;
    StorageRule?: StorageRuleType | undefined;
}
export interface User {
    Id?: string | undefined;
    Username?: string | redacted.Redacted<string> | undefined;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    GivenName?: string | redacted.Redacted<string> | undefined;
    Surname?: string | redacted.Redacted<string> | undefined;
    OrganizationId?: string | undefined;
    RootFolderId?: string | undefined;
    RecycleBinFolderId?: string | undefined;
    Status?: UserStatusType | undefined;
    Type?: UserType | undefined;
    CreatedTimestamp?: Date | undefined;
    ModifiedTimestamp?: Date | undefined;
    TimeZoneId?: string | undefined;
    Locale?: LocaleType | undefined;
    Storage?: UserStorageMetadata | undefined;
}
export interface ActivateUserResponse {
    User?: User | undefined;
}
export type PrincipalType = "USER" | "GROUP" | "INVITE" | "ANONYMOUS" | "ORGANIZATION" | (string & {});
export type RoleType = "VIEWER" | "CONTRIBUTOR" | "OWNER" | "COOWNER" | (string & {});
export interface SharePrincipal {
    Id: string;
    Type: PrincipalType;
    Role: RoleType;
}
export type SharePrincipalList = SharePrincipal[];
export type MessageType = string | redacted.Redacted<string>;
export interface NotificationOptions {
    SendEmail?: boolean | undefined;
    EmailMessage?: string | redacted.Redacted<string> | undefined;
}
export interface AddResourcePermissionsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    ResourceId: string;
    Principals: SharePrincipal[];
    NotificationOptions?: NotificationOptions | undefined;
}
export type ShareStatusType = "SUCCESS" | "FAILURE" | (string & {});
export interface ShareResult {
    PrincipalId?: string | undefined;
    InviteePrincipalId?: string | undefined;
    Role?: RoleType | undefined;
    Status?: ShareStatusType | undefined;
    ShareId?: string | undefined;
    StatusMessage?: string | redacted.Redacted<string> | undefined;
}
export type ShareResultsList = ShareResult[];
export interface AddResourcePermissionsResponse {
    ShareResults?: ShareResult[] | undefined;
}
export type CommentIdType = string;
export type CommentTextType = string | redacted.Redacted<string>;
export type CommentVisibilityType = "PUBLIC" | "PRIVATE" | (string & {});
export interface CreateCommentRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    VersionId: string;
    ParentId?: string | undefined;
    ThreadId?: string | undefined;
    Text: string | redacted.Redacted<string>;
    Visibility?: CommentVisibilityType | undefined;
    NotifyCollaborators?: boolean | undefined;
}
export type CommentStatusType = "DRAFT" | "PUBLISHED" | "DELETED" | (string & {});
export interface Comment {
    CommentId: string;
    ParentId?: string | undefined;
    ThreadId?: string | undefined;
    Text?: string | redacted.Redacted<string> | undefined;
    Contributor?: User | undefined;
    CreatedTimestamp?: Date | undefined;
    Status?: CommentStatusType | undefined;
    Visibility?: CommentVisibilityType | undefined;
    RecipientId?: string | undefined;
}
export interface CreateCommentResponse {
    Comment?: Comment | undefined;
}
export type CustomMetadataKeyType = string;
export type CustomMetadataValueType = string;
export type CustomMetadataMap = {
    [key: string]: string | undefined;
};
export interface CreateCustomMetadataRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    ResourceId: string;
    VersionId?: string | undefined;
    CustomMetadata: {
        [key: string]: string | undefined;
    };
}
export interface CreateCustomMetadataResponse {
}
export type ResourceNameType = string | redacted.Redacted<string>;
export interface CreateFolderRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    ParentFolderId: string;
}
export type ResourceStateType = "ACTIVE" | "RESTORING" | "RECYCLING" | "RECYCLED" | (string & {});
export type HashType = string;
export type SharedLabel = string;
export type SharedLabels = string[];
export interface FolderMetadata {
    Id?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    CreatorId?: string | undefined;
    ParentFolderId?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    ModifiedTimestamp?: Date | undefined;
    ResourceState?: ResourceStateType | undefined;
    Signature?: string | undefined;
    Labels?: string[] | undefined;
    Size?: number | undefined;
    LatestVersionSize?: number | undefined;
}
export interface CreateFolderResponse {
    Metadata?: FolderMetadata | undefined;
}
export interface CreateLabelsRequest {
    ResourceId: string;
    Labels: string[];
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
}
export interface CreateLabelsResponse {
}
export type SubscriptionEndPointType = string;
export type SubscriptionProtocolType = "HTTPS" | "SQS" | (string & {});
export type SubscriptionType = "ALL" | (string & {});
export interface CreateNotificationSubscriptionRequest {
    OrganizationId: string;
    Endpoint: string;
    Protocol: SubscriptionProtocolType;
    SubscriptionType: SubscriptionType;
}
export interface Subscription {
    SubscriptionId?: string | undefined;
    EndPoint?: string | undefined;
    Protocol?: SubscriptionProtocolType | undefined;
}
export interface CreateNotificationSubscriptionResponse {
    Subscription?: Subscription | undefined;
}
export type PasswordType = string | redacted.Redacted<string>;
export interface CreateUserRequest {
    OrganizationId?: string | undefined;
    Username: string | redacted.Redacted<string>;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    GivenName: string | redacted.Redacted<string>;
    Surname: string | redacted.Redacted<string>;
    Password: string | redacted.Redacted<string>;
    TimeZoneId?: string | undefined;
    StorageRule?: StorageRuleType | undefined;
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
}
export interface CreateUserResponse {
    User?: User | undefined;
}
export interface DeactivateUserRequest {
    UserId: string;
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
}
export interface DeactivateUserResponse {
}
export interface DeleteCommentRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    VersionId: string;
    CommentId: string;
}
export interface DeleteCommentResponse {
}
export type CustomMetadataKeyList = string[];
export interface DeleteCustomMetadataRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    ResourceId: string;
    VersionId?: string | undefined;
    Keys?: string[] | undefined;
    DeleteAll?: boolean | undefined;
}
export interface DeleteCustomMetadataResponse {
}
export interface DeleteDocumentRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
}
export interface DeleteDocumentResponse {
}
export interface DeleteDocumentVersionRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    VersionId: string;
    DeletePriorVersions: boolean;
}
export interface DeleteDocumentVersionResponse {
}
export interface DeleteFolderRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    FolderId: string;
}
export interface DeleteFolderResponse {
}
export interface DeleteFolderContentsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    FolderId: string;
}
export interface DeleteFolderContentsResponse {
}
export interface DeleteLabelsRequest {
    ResourceId: string;
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    Labels?: string[] | undefined;
    DeleteAll?: boolean | undefined;
}
export interface DeleteLabelsResponse {
}
export interface DeleteNotificationSubscriptionRequest {
    SubscriptionId: string;
    OrganizationId: string;
}
export interface DeleteNotificationSubscriptionResponse {
}
export interface DeleteUserRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    UserId: string;
}
export interface DeleteUserResponse {
}
export type ActivityNamesFilterType = string;
export type LimitType = number;
export type SearchMarkerType = string;
export interface DescribeActivitiesRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    OrganizationId?: string | undefined;
    ActivityTypes?: string | undefined;
    ResourceId?: string | undefined;
    UserId?: string | undefined;
    IncludeIndirectActivities?: boolean | undefined;
    Limit?: number | undefined;
    Marker?: string | undefined;
}
export type ActivityType = "DOCUMENT_CHECKED_IN" | "DOCUMENT_CHECKED_OUT" | "DOCUMENT_RENAMED" | "DOCUMENT_VERSION_UPLOADED" | "DOCUMENT_VERSION_DELETED" | "DOCUMENT_VERSION_VIEWED" | "DOCUMENT_VERSION_DOWNLOADED" | "DOCUMENT_RECYCLED" | "DOCUMENT_RESTORED" | "DOCUMENT_REVERTED" | "DOCUMENT_SHARED" | "DOCUMENT_UNSHARED" | "DOCUMENT_SHARE_PERMISSION_CHANGED" | "DOCUMENT_SHAREABLE_LINK_CREATED" | "DOCUMENT_SHAREABLE_LINK_REMOVED" | "DOCUMENT_SHAREABLE_LINK_PERMISSION_CHANGED" | "DOCUMENT_MOVED" | "DOCUMENT_COMMENT_ADDED" | "DOCUMENT_COMMENT_DELETED" | "DOCUMENT_ANNOTATION_ADDED" | "DOCUMENT_ANNOTATION_DELETED" | "FOLDER_CREATED" | "FOLDER_DELETED" | "FOLDER_RENAMED" | "FOLDER_RECYCLED" | "FOLDER_RESTORED" | "FOLDER_SHARED" | "FOLDER_UNSHARED" | "FOLDER_SHARE_PERMISSION_CHANGED" | "FOLDER_SHAREABLE_LINK_CREATED" | "FOLDER_SHAREABLE_LINK_REMOVED" | "FOLDER_SHAREABLE_LINK_PERMISSION_CHANGED" | "FOLDER_MOVED" | (string & {});
export interface UserMetadata {
    Id?: string | undefined;
    Username?: string | redacted.Redacted<string> | undefined;
    GivenName?: string | redacted.Redacted<string> | undefined;
    Surname?: string | redacted.Redacted<string> | undefined;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
}
export type UserMetadataList = UserMetadata[];
export type GroupNameType = string;
export interface GroupMetadata {
    Id?: string | undefined;
    Name?: string | undefined;
}
export type GroupMetadataList = GroupMetadata[];
export interface Participants {
    Users?: UserMetadata[] | undefined;
    Groups?: GroupMetadata[] | undefined;
}
export type ResourceType = "FOLDER" | "DOCUMENT" | (string & {});
export interface ResourceMetadata {
    Type?: ResourceType | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    OriginalName?: string | redacted.Redacted<string> | undefined;
    Id?: string | undefined;
    VersionId?: string | undefined;
    Owner?: UserMetadata | undefined;
    ParentId?: string | undefined;
}
export interface CommentMetadata {
    CommentId?: string | undefined;
    Contributor?: User | undefined;
    CreatedTimestamp?: Date | undefined;
    CommentStatus?: CommentStatusType | undefined;
    RecipientId?: string | undefined;
    ContributorId?: string | undefined;
}
export interface Activity {
    Type?: ActivityType | undefined;
    TimeStamp?: Date | undefined;
    IsIndirectActivity?: boolean | undefined;
    OrganizationId?: string | undefined;
    Initiator?: UserMetadata | undefined;
    Participants?: Participants | undefined;
    ResourceMetadata?: ResourceMetadata | undefined;
    OriginalParent?: ResourceMetadata | undefined;
    CommentMetadata?: CommentMetadata | undefined;
}
export type UserActivities = Activity[];
export interface DescribeActivitiesResponse {
    UserActivities?: Activity[] | undefined;
    Marker?: string | undefined;
}
export type MarkerType = string;
export interface DescribeCommentsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    VersionId: string;
    Limit?: number | undefined;
    Marker?: string | undefined;
}
export type CommentList = Comment[];
export interface DescribeCommentsResponse {
    Comments?: Comment[] | undefined;
    Marker?: string | undefined;
}
export type PageMarkerType = string;
export type FieldNamesType = string;
export interface DescribeDocumentVersionsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    Marker?: string | undefined;
    Limit?: number | undefined;
    Include?: string | undefined;
    Fields?: string | undefined;
}
export type DocumentContentType = string;
export type DocumentStatusType = "INITIALIZED" | "ACTIVE" | (string & {});
export type DocumentThumbnailType = "SMALL" | "SMALL_HQ" | "LARGE" | (string & {});
export type UrlType = string | redacted.Redacted<string>;
export type DocumentThumbnailUrlMap = {
    [key in DocumentThumbnailType]?: string | redacted.Redacted<string> | undefined;
};
export type DocumentSourceType = "ORIGINAL" | "WITH_COMMENTS" | (string & {});
export type DocumentSourceUrlMap = {
    [key in DocumentSourceType]?: string | redacted.Redacted<string> | undefined;
};
export interface DocumentVersionMetadata {
    Id?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    ContentType?: string | undefined;
    Size?: number | undefined;
    Signature?: string | undefined;
    Status?: DocumentStatusType | undefined;
    CreatedTimestamp?: Date | undefined;
    ModifiedTimestamp?: Date | undefined;
    ContentCreatedTimestamp?: Date | undefined;
    ContentModifiedTimestamp?: Date | undefined;
    CreatorId?: string | undefined;
    Thumbnail?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    Source?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export type DocumentVersionMetadataList = DocumentVersionMetadata[];
export interface DescribeDocumentVersionsResponse {
    DocumentVersions?: DocumentVersionMetadata[] | undefined;
    Marker?: string | undefined;
}
export type ResourceSortType = "DATE" | "NAME" | (string & {});
export type OrderType = "ASCENDING" | "DESCENDING" | (string & {});
export type FolderContentType = "ALL" | "DOCUMENT" | "FOLDER" | (string & {});
export interface DescribeFolderContentsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    FolderId: string;
    Sort?: ResourceSortType | undefined;
    Order?: OrderType | undefined;
    Limit?: number | undefined;
    Marker?: string | undefined;
    Type?: FolderContentType | undefined;
    Include?: string | undefined;
}
export type FolderMetadataList = FolderMetadata[];
export interface DocumentMetadata {
    Id?: string | undefined;
    CreatorId?: string | undefined;
    ParentFolderId?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    ModifiedTimestamp?: Date | undefined;
    LatestVersionMetadata?: DocumentVersionMetadata | undefined;
    ResourceState?: ResourceStateType | undefined;
    Labels?: string[] | undefined;
}
export type DocumentMetadataList = DocumentMetadata[];
export interface DescribeFolderContentsResponse {
    Folders?: FolderMetadata[] | undefined;
    Documents?: DocumentMetadata[] | undefined;
    Marker?: string | undefined;
}
export type SearchQueryType = string | redacted.Redacted<string>;
export type PositiveIntegerType = number;
export interface DescribeGroupsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    SearchQuery: string | redacted.Redacted<string>;
    OrganizationId?: string | undefined;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export interface DescribeGroupsResponse {
    Groups?: GroupMetadata[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeNotificationSubscriptionsRequest {
    OrganizationId: string;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export type SubscriptionList = Subscription[];
export interface DescribeNotificationSubscriptionsResponse {
    Subscriptions?: Subscription[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeResourcePermissionsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    ResourceId: string;
    PrincipalId?: string | undefined;
    Limit?: number | undefined;
    Marker?: string | undefined;
}
export type RolePermissionType = "DIRECT" | "INHERITED" | (string & {});
export interface PermissionInfo {
    Role?: RoleType | undefined;
    Type?: RolePermissionType | undefined;
}
export type PermissionInfoList = PermissionInfo[];
export interface Principal {
    Id?: string | undefined;
    Type?: PrincipalType | undefined;
    Roles?: PermissionInfo[] | undefined;
}
export type PrincipalList = Principal[];
export interface DescribeResourcePermissionsResponse {
    Principals?: Principal[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeRootFoldersRequest {
    AuthenticationToken: string | redacted.Redacted<string>;
    Limit?: number | undefined;
    Marker?: string | undefined;
}
export interface DescribeRootFoldersResponse {
    Folders?: FolderMetadata[] | undefined;
    Marker?: string | undefined;
}
export type UserIdsType = string;
export type UserFilterType = "ALL" | "ACTIVE_PENDING" | (string & {});
export type UserSortType = "USER_NAME" | "FULL_NAME" | "STORAGE_LIMIT" | "USER_STATUS" | "STORAGE_USED" | (string & {});
export interface DescribeUsersRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    OrganizationId?: string | undefined;
    UserIds?: string | undefined;
    Query?: string | redacted.Redacted<string> | undefined;
    Include?: UserFilterType | undefined;
    Order?: OrderType | undefined;
    Sort?: UserSortType | undefined;
    Marker?: string | undefined;
    Limit?: number | undefined;
    Fields?: string | undefined;
}
export type OrganizationUserList = User[];
export interface DescribeUsersResponse {
    Users?: User[] | undefined;
    TotalNumberOfUsers?: number | undefined;
    Marker?: string | undefined;
}
export interface GetCurrentUserRequest {
    AuthenticationToken: string | redacted.Redacted<string>;
}
export interface GetCurrentUserResponse {
    User?: User | undefined;
}
export interface GetDocumentRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    IncludeCustomMetadata?: boolean | undefined;
}
export interface GetDocumentResponse {
    Metadata?: DocumentMetadata | undefined;
    CustomMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDocumentPathRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    Limit?: number | undefined;
    Fields?: string | undefined;
    Marker?: string | undefined;
}
export interface ResourcePathComponent {
    Id?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export type ResourcePathComponentList = ResourcePathComponent[];
export interface ResourcePath {
    Components?: ResourcePathComponent[] | undefined;
}
export interface GetDocumentPathResponse {
    Path?: ResourcePath | undefined;
}
export interface GetDocumentVersionRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    VersionId: string;
    Fields?: string | undefined;
    IncludeCustomMetadata?: boolean | undefined;
}
export interface GetDocumentVersionResponse {
    Metadata?: DocumentVersionMetadata | undefined;
    CustomMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetFolderRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    FolderId: string;
    IncludeCustomMetadata?: boolean | undefined;
}
export interface GetFolderResponse {
    Metadata?: FolderMetadata | undefined;
    CustomMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetFolderPathRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    FolderId: string;
    Limit?: number | undefined;
    Fields?: string | undefined;
    Marker?: string | undefined;
}
export interface GetFolderPathResponse {
    Path?: ResourcePath | undefined;
}
export type ResourceCollectionType = "SHARED_WITH_ME" | (string & {});
export interface GetResourcesRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    UserId?: string | undefined;
    CollectionType?: ResourceCollectionType | undefined;
    Limit?: number | undefined;
    Marker?: string | undefined;
}
export interface GetResourcesResponse {
    Folders?: FolderMetadata[] | undefined;
    Documents?: DocumentMetadata[] | undefined;
    Marker?: string | undefined;
}
export interface InitiateDocumentVersionUploadRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    Id?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    ContentCreatedTimestamp?: Date | undefined;
    ContentModifiedTimestamp?: Date | undefined;
    ContentType?: string | undefined;
    DocumentSizeInBytes?: number | undefined;
    ParentFolderId?: string | undefined;
}
export type HeaderNameType = string;
export type HeaderValueType = string;
export type SignedHeaderMap = {
    [key: string]: string | undefined;
};
export interface UploadMetadata {
    UploadUrl?: string | redacted.Redacted<string> | undefined;
    SignedHeaders?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface InitiateDocumentVersionUploadResponse {
    Metadata?: DocumentMetadata | undefined;
    UploadMetadata?: UploadMetadata | undefined;
}
export interface RemoveAllResourcePermissionsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    ResourceId: string;
}
export interface RemoveAllResourcePermissionsResponse {
}
export interface RemoveResourcePermissionRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    ResourceId: string;
    PrincipalId: string;
    PrincipalType?: PrincipalType | undefined;
}
export interface RemoveResourcePermissionResponse {
}
export interface RestoreDocumentVersionsRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
}
export interface RestoreDocumentVersionsResponse {
}
export type SearchQueryScopeType = "NAME" | "CONTENT" | (string & {});
export type SearchQueryScopeTypeList = SearchQueryScopeType[];
export type AdditionalResponseFieldType = "WEBURL" | (string & {});
export type AdditionalResponseFieldsList = AdditionalResponseFieldType[];
export type LanguageCodeType = "AR" | "BG" | "BN" | "DA" | "DE" | "CS" | "EL" | "EN" | "ES" | "FA" | "FI" | "FR" | "HI" | "HU" | "ID" | "IT" | "JA" | "KO" | "LT" | "LV" | "NL" | "NO" | "PT" | "RO" | "RU" | "SV" | "SW" | "TH" | "TR" | "ZH" | "DEFAULT" | (string & {});
export type TextLocaleTypeList = LanguageCodeType[];
export type ContentCategoryType = "IMAGE" | "DOCUMENT" | "PDF" | "SPREADSHEET" | "PRESENTATION" | "AUDIO" | "VIDEO" | "SOURCE_CODE" | "OTHER" | (string & {});
export type SearchContentCategoryTypeList = ContentCategoryType[];
export type SearchResourceType = "FOLDER" | "DOCUMENT" | "COMMENT" | "DOCUMENT_VERSION" | (string & {});
export type SearchResourceTypeList = SearchResourceType[];
export type SearchLabel = string;
export type SearchLabelList = string[];
export type PrincipalRoleType = "VIEWER" | "CONTRIBUTOR" | "OWNER" | "COOWNER" | (string & {});
export type SearchPrincipalRoleList = PrincipalRoleType[];
export interface SearchPrincipalType {
    Id: string;
    Roles?: PrincipalRoleType[] | undefined;
}
export type SearchPrincipalTypeList = SearchPrincipalType[];
export type SearchAncestorId = string;
export type SearchAncestorIdList = string[];
export type SearchCollectionType = "OWNED" | "SHARED_WITH_ME" | (string & {});
export type SearchCollectionTypeList = SearchCollectionType[];
export type LongType = number;
export interface LongRangeType {
    StartValue?: number | undefined;
    EndValue?: number | undefined;
}
export interface DateRangeType {
    StartValue?: Date | undefined;
    EndValue?: Date | undefined;
}
export interface Filters {
    TextLocales?: LanguageCodeType[] | undefined;
    ContentCategories?: ContentCategoryType[] | undefined;
    ResourceTypes?: SearchResourceType[] | undefined;
    Labels?: string[] | undefined;
    Principals?: SearchPrincipalType[] | undefined;
    AncestorIds?: string[] | undefined;
    SearchCollectionTypes?: SearchCollectionType[] | undefined;
    SizeRange?: LongRangeType | undefined;
    CreatedRange?: DateRangeType | undefined;
    ModifiedRange?: DateRangeType | undefined;
}
export type OrderByFieldType = "RELEVANCE" | "NAME" | "SIZE" | "CREATED_TIMESTAMP" | "MODIFIED_TIMESTAMP" | (string & {});
export type SortOrder = "ASC" | "DESC" | (string & {});
export interface SearchSortResult {
    Field?: OrderByFieldType | undefined;
    Order?: SortOrder | undefined;
}
export type SearchResultSortList = SearchSortResult[];
export type SearchResultsLimitType = number;
export type NextMarkerType = string;
export interface SearchResourcesRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    QueryText?: string | redacted.Redacted<string> | undefined;
    QueryScopes?: SearchQueryScopeType[] | undefined;
    OrganizationId?: string | undefined;
    AdditionalResponseFields?: AdditionalResponseFieldType[] | undefined;
    Filters?: Filters | undefined;
    OrderBy?: SearchSortResult[] | undefined;
    Limit?: number | undefined;
    Marker?: string | undefined;
}
export type ResponseItemType = "DOCUMENT" | "FOLDER" | "COMMENT" | "DOCUMENT_VERSION" | (string & {});
export type ResponseItemWebUrl = string | redacted.Redacted<string>;
export interface ResponseItem {
    ResourceType?: ResponseItemType | undefined;
    WebUrl?: string | redacted.Redacted<string> | undefined;
    DocumentMetadata?: DocumentMetadata | undefined;
    FolderMetadata?: FolderMetadata | undefined;
    CommentMetadata?: CommentMetadata | undefined;
    DocumentVersionMetadata?: DocumentVersionMetadata | undefined;
}
export type ResponseItemsList = ResponseItem[];
export interface SearchResourcesResponse {
    Items?: ResponseItem[] | undefined;
    Marker?: string | undefined;
}
export interface UpdateDocumentRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    Name?: string | redacted.Redacted<string> | undefined;
    ParentFolderId?: string | undefined;
    ResourceState?: ResourceStateType | undefined;
}
export interface UpdateDocumentResponse {
}
export type DocumentVersionStatus = "ACTIVE" | (string & {});
export interface UpdateDocumentVersionRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    DocumentId: string;
    VersionId: string;
    VersionStatus?: DocumentVersionStatus | undefined;
}
export interface UpdateDocumentVersionResponse {
}
export interface UpdateFolderRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    FolderId: string;
    Name?: string | redacted.Redacted<string> | undefined;
    ParentFolderId?: string | undefined;
    ResourceState?: ResourceStateType | undefined;
}
export interface UpdateFolderResponse {
}
export type BooleanEnumType = "TRUE" | "FALSE" | (string & {});
export interface UpdateUserRequest {
    AuthenticationToken?: string | redacted.Redacted<string> | undefined;
    UserId: string;
    GivenName?: string | redacted.Redacted<string> | undefined;
    Surname?: string | redacted.Redacted<string> | undefined;
    Type?: UserType | undefined;
    StorageRule?: StorageRuleType | undefined;
    TimeZoneId?: string | undefined;
    Locale?: LocaleType | undefined;
    GrantPoweruserPrivileges?: BooleanEnumType | undefined;
}
export interface UpdateUserResponse {
    User?: User | undefined;
}
export type ErrorMessageType = string;
export type EntityIdList = string[];
export type ExceptionCodeType = string;
export type AbortDocumentVersionUploadError = ConcurrentModificationException | EntityNotExistsException | FailedDependencyException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Aborts the upload of the specified document version that was previously initiated
 * by InitiateDocumentVersionUpload. The client should make this call
 * only when it no longer intends to upload the document version, or fails to do
 * so.
 */
export declare const abortDocumentVersionUpload: API.OperationMethod<AbortDocumentVersionUploadRequest & RegionInput, AbortDocumentVersionUploadResponse, AbortDocumentVersionUploadError, Credentials | HttpClient.HttpClient>;
export type ActivateUserError = EntityNotExistsException | FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Activates the specified user. Only active users can access Amazon
 * WorkDocs.
 */
export declare const activateUser: API.OperationMethod<ActivateUserRequest & RegionInput, ActivateUserResponse, ActivateUserError, Credentials | HttpClient.HttpClient>;
export type AddResourcePermissionsError = FailedDependencyException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Creates a set of permissions for the specified folder or document. The resource
 * permissions are overwritten if the principals already have different
 * permissions.
 */
export declare const addResourcePermissions: API.OperationMethod<AddResourcePermissionsRequest & RegionInput, AddResourcePermissionsResponse, AddResourcePermissionsError, Credentials | HttpClient.HttpClient>;
export type CreateCommentError = DocumentLockedForCommentsException | EntityNotExistsException | FailedDependencyException | InvalidCommentOperationException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Adds a new comment to the specified document version.
 */
export declare const createComment: API.OperationMethod<CreateCommentRequest & RegionInput, CreateCommentResponse, CreateCommentError, Credentials | HttpClient.HttpClient>;
export type CreateCustomMetadataError = CustomMetadataLimitExceededException | EntityNotExistsException | FailedDependencyException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Adds one or more custom properties to the specified resource (a folder, document,
 * or version).
 */
export declare const createCustomMetadata: API.OperationMethod<CreateCustomMetadataRequest & RegionInput, CreateCustomMetadataResponse, CreateCustomMetadataError, Credentials | HttpClient.HttpClient>;
export type CreateFolderError = ConcurrentModificationException | ConflictingOperationException | EntityAlreadyExistsException | EntityNotExistsException | FailedDependencyException | LimitExceededException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Creates a folder with the specified name and parent folder.
 */
export declare const createFolder: API.OperationMethod<CreateFolderRequest & RegionInput, CreateFolderResponse, CreateFolderError, Credentials | HttpClient.HttpClient>;
export type CreateLabelsError = EntityNotExistsException | FailedDependencyException | ServiceUnavailableException | TooManyLabelsException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Adds the specified list of labels to the given resource (a document or
 * folder)
 */
export declare const createLabels: API.OperationMethod<CreateLabelsRequest & RegionInput, CreateLabelsResponse, CreateLabelsError, Credentials | HttpClient.HttpClient>;
export type CreateNotificationSubscriptionError = InvalidArgumentException | ServiceUnavailableException | TooManySubscriptionsException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Configure Amazon WorkDocs to use Amazon SNS notifications. The endpoint receives a
 * confirmation message, and must confirm the subscription.
 *
 * For more information, see Setting up notifications for an IAM user or role in the Amazon WorkDocs Developer
 * Guide.
 */
export declare const createNotificationSubscription: API.OperationMethod<CreateNotificationSubscriptionRequest & RegionInput, CreateNotificationSubscriptionResponse, CreateNotificationSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = EntityAlreadyExistsException | FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Creates a user in a Simple AD or Microsoft AD directory. The status of a newly
 * created user is "ACTIVE". New users can access Amazon WorkDocs.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeactivateUserError = EntityNotExistsException | FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Deactivates the specified user, which revokes the user's access to Amazon
 * WorkDocs.
 */
export declare const deactivateUser: API.OperationMethod<DeactivateUserRequest & RegionInput, DeactivateUserResponse, DeactivateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteCommentError = DocumentLockedForCommentsException | EntityNotExistsException | FailedDependencyException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Deletes the specified comment from the document version.
 */
export declare const deleteComment: API.OperationMethod<DeleteCommentRequest & RegionInput, DeleteCommentResponse, DeleteCommentError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomMetadataError = EntityNotExistsException | FailedDependencyException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Deletes custom metadata from the specified resource.
 */
export declare const deleteCustomMetadata: API.OperationMethod<DeleteCustomMetadataRequest & RegionInput, DeleteCustomMetadataResponse, DeleteCustomMetadataError, Credentials | HttpClient.HttpClient>;
export type DeleteDocumentError = ConcurrentModificationException | ConflictingOperationException | EntityNotExistsException | FailedDependencyException | LimitExceededException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Permanently deletes the specified document and its associated metadata.
 */
export declare const deleteDocument: API.OperationMethod<DeleteDocumentRequest & RegionInput, DeleteDocumentResponse, DeleteDocumentError, Credentials | HttpClient.HttpClient>;
export type DeleteDocumentVersionError = ConcurrentModificationException | ConflictingOperationException | EntityNotExistsException | FailedDependencyException | InvalidOperationException | ProhibitedStateException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Deletes a specific version of a document.
 */
export declare const deleteDocumentVersion: API.OperationMethod<DeleteDocumentVersionRequest & RegionInput, DeleteDocumentVersionResponse, DeleteDocumentVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteFolderError = ConcurrentModificationException | ConflictingOperationException | EntityNotExistsException | FailedDependencyException | LimitExceededException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Permanently deletes the specified folder and its contents.
 */
export declare const deleteFolder: API.OperationMethod<DeleteFolderRequest & RegionInput, DeleteFolderResponse, DeleteFolderError, Credentials | HttpClient.HttpClient>;
export type DeleteFolderContentsError = ConflictingOperationException | EntityNotExistsException | FailedDependencyException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Deletes the contents of the specified folder.
 */
export declare const deleteFolderContents: API.OperationMethod<DeleteFolderContentsRequest & RegionInput, DeleteFolderContentsResponse, DeleteFolderContentsError, Credentials | HttpClient.HttpClient>;
export type DeleteLabelsError = EntityNotExistsException | FailedDependencyException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Deletes the specified list of labels from a resource.
 */
export declare const deleteLabels: API.OperationMethod<DeleteLabelsRequest & RegionInput, DeleteLabelsResponse, DeleteLabelsError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationSubscriptionError = EntityNotExistsException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Deletes the specified subscription from the specified organization.
 */
export declare const deleteNotificationSubscription: API.OperationMethod<DeleteNotificationSubscriptionRequest & RegionInput, DeleteNotificationSubscriptionResponse, DeleteNotificationSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = EntityNotExistsException | FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Deletes the specified user from a Simple AD or Microsoft AD directory.
 *
 * Deleting a user immediately and permanently deletes all content in that user's folder structure. Site retention policies do NOT apply to this type of deletion.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeActivitiesError = FailedDependencyException | InvalidArgumentException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Describes the user activities in a specified time period.
 */
export declare const describeActivities: API.PaginatedOperationMethod<DescribeActivitiesRequest & RegionInput, DescribeActivitiesResponse, DescribeActivitiesError, Credentials | HttpClient.HttpClient, Activity>;
export type DescribeCommentsError = EntityNotExistsException | FailedDependencyException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * List all the comments for the specified document version.
 */
export declare const describeComments: API.PaginatedOperationMethod<DescribeCommentsRequest & RegionInput, DescribeCommentsResponse, DescribeCommentsError, Credentials | HttpClient.HttpClient, Comment>;
export type DescribeDocumentVersionsError = EntityNotExistsException | FailedDependencyException | InvalidArgumentException | InvalidPasswordException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Retrieves the document versions for the specified document.
 *
 * By default, only active versions are returned.
 */
export declare const describeDocumentVersions: API.PaginatedOperationMethod<DescribeDocumentVersionsRequest & RegionInput, DescribeDocumentVersionsResponse, DescribeDocumentVersionsError, Credentials | HttpClient.HttpClient, DocumentVersionMetadata>;
export type DescribeFolderContentsError = EntityNotExistsException | FailedDependencyException | InvalidArgumentException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Describes the contents of the specified folder, including its documents and
 * subfolders.
 *
 * By default, Amazon WorkDocs returns the first 100 active document and folder
 * metadata items. If there are more results, the response includes a marker that you can
 * use to request the next set of results. You can also request initialized
 * documents.
 */
export declare const describeFolderContents: API.PaginatedOperationMethod<DescribeFolderContentsRequest & RegionInput, DescribeFolderContentsResponse, DescribeFolderContentsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeGroupsError = FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Describes the groups specified by the query. Groups are defined by the underlying
 * Active Directory.
 */
export declare const describeGroups: API.PaginatedOperationMethod<DescribeGroupsRequest & RegionInput, DescribeGroupsResponse, DescribeGroupsError, Credentials | HttpClient.HttpClient, GroupMetadata>;
export type DescribeNotificationSubscriptionsError = EntityNotExistsException | ServiceUnavailableException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Lists the specified notification subscriptions.
 */
export declare const describeNotificationSubscriptions: API.PaginatedOperationMethod<DescribeNotificationSubscriptionsRequest & RegionInput, DescribeNotificationSubscriptionsResponse, DescribeNotificationSubscriptionsError, Credentials | HttpClient.HttpClient, Subscription>;
export type DescribeResourcePermissionsError = FailedDependencyException | InvalidArgumentException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Describes the permissions of a specified resource.
 */
export declare const describeResourcePermissions: API.PaginatedOperationMethod<DescribeResourcePermissionsRequest & RegionInput, DescribeResourcePermissionsResponse, DescribeResourcePermissionsError, Credentials | HttpClient.HttpClient, Principal>;
export type DescribeRootFoldersError = FailedDependencyException | InvalidArgumentException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Describes the current user's special folders; the `RootFolder` and the
 * `RecycleBin`. `RootFolder` is the root of user's files and
 * folders and `RecycleBin` is the root of recycled items. This is not a valid
 * action for SigV4 (administrative API) clients.
 *
 * This action requires an authentication token. To get an authentication token,
 * register an application with Amazon WorkDocs. For more information, see Authentication and Access
 * Control for User Applications in the
 * Amazon
 * WorkDocs Developer Guide.
 */
export declare const describeRootFolders: API.PaginatedOperationMethod<DescribeRootFoldersRequest & RegionInput, DescribeRootFoldersResponse, DescribeRootFoldersError, Credentials | HttpClient.HttpClient, FolderMetadata>;
export type DescribeUsersError = EntityNotExistsException | FailedDependencyException | InvalidArgumentException | RequestedEntityTooLargeException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Describes the specified users. You can describe all users or filter the results
 * (for example, by status or organization).
 *
 * By default, Amazon WorkDocs returns the first 24 active or pending users. If there
 * are more results, the response includes a marker that you can use to request the next
 * set of results.
 */
export declare const describeUsers: API.PaginatedOperationMethod<DescribeUsersRequest & RegionInput, DescribeUsersResponse, DescribeUsersError, Credentials | HttpClient.HttpClient, User>;
export type GetCurrentUserError = EntityNotExistsException | FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Retrieves details of the current user for whom the authentication token was
 * generated. This is not a valid action for SigV4 (administrative API) clients.
 *
 * This action requires an authentication token. To get an authentication token,
 * register an application with Amazon WorkDocs. For more information, see Authentication and Access
 * Control for User Applications in the
 * Amazon
 * WorkDocs Developer Guide.
 */
export declare const getCurrentUser: API.OperationMethod<GetCurrentUserRequest & RegionInput, GetCurrentUserResponse, GetCurrentUserError, Credentials | HttpClient.HttpClient>;
export type GetDocumentError = EntityNotExistsException | FailedDependencyException | InvalidArgumentException | InvalidPasswordException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Retrieves details of a document.
 */
export declare const getDocument: API.OperationMethod<GetDocumentRequest & RegionInput, GetDocumentResponse, GetDocumentError, Credentials | HttpClient.HttpClient>;
export type GetDocumentPathError = EntityNotExistsException | FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Retrieves the path information (the hierarchy from the root folder) for the
 * requested document.
 *
 * By default, Amazon WorkDocs returns a maximum of 100 levels upwards from the
 * requested document and only includes the IDs of the parent folders in the path. You can
 * limit the maximum number of levels. You can also request the names of the parent
 * folders.
 */
export declare const getDocumentPath: API.OperationMethod<GetDocumentPathRequest & RegionInput, GetDocumentPathResponse, GetDocumentPathError, Credentials | HttpClient.HttpClient>;
export type GetDocumentVersionError = EntityNotExistsException | FailedDependencyException | InvalidPasswordException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Retrieves version metadata for the specified document.
 */
export declare const getDocumentVersion: API.OperationMethod<GetDocumentVersionRequest & RegionInput, GetDocumentVersionResponse, GetDocumentVersionError, Credentials | HttpClient.HttpClient>;
export type GetFolderError = EntityNotExistsException | FailedDependencyException | InvalidArgumentException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Retrieves the metadata of the specified folder.
 */
export declare const getFolder: API.OperationMethod<GetFolderRequest & RegionInput, GetFolderResponse, GetFolderError, Credentials | HttpClient.HttpClient>;
export type GetFolderPathError = EntityNotExistsException | FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Retrieves the path information (the hierarchy from the root folder) for the
 * specified folder.
 *
 * By default, Amazon WorkDocs returns a maximum of 100 levels upwards from the
 * requested folder and only includes the IDs of the parent folders in the path. You can
 * limit the maximum number of levels. You can also request the parent folder
 * names.
 */
export declare const getFolderPath: API.OperationMethod<GetFolderPathRequest & RegionInput, GetFolderPathResponse, GetFolderPathError, Credentials | HttpClient.HttpClient>;
export type GetResourcesError = FailedDependencyException | InvalidArgumentException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Retrieves a collection of resources, including folders and documents. The only
 * `CollectionType` supported is `SHARED_WITH_ME`.
 */
export declare const getResources: API.OperationMethod<GetResourcesRequest & RegionInput, GetResourcesResponse, GetResourcesError, Credentials | HttpClient.HttpClient>;
export type InitiateDocumentVersionUploadError = DraftUploadOutOfSyncException | EntityAlreadyExistsException | EntityNotExistsException | FailedDependencyException | InvalidArgumentException | InvalidPasswordException | LimitExceededException | ProhibitedStateException | ResourceAlreadyCheckedOutException | ServiceUnavailableException | StorageLimitExceededException | StorageLimitWillExceedException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Creates a new document object and version object.
 *
 * The client specifies the parent folder ID and name of the document to upload. The
 * ID is optionally specified when creating a new version of an existing document. This is
 * the first step to upload a document. Next, upload the document to the URL returned from
 * the call, and then call UpdateDocumentVersion.
 *
 * To cancel the document upload, call AbortDocumentVersionUpload.
 */
export declare const initiateDocumentVersionUpload: API.OperationMethod<InitiateDocumentVersionUploadRequest & RegionInput, InitiateDocumentVersionUploadResponse, InitiateDocumentVersionUploadError, Credentials | HttpClient.HttpClient>;
export type RemoveAllResourcePermissionsError = FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Removes all the permissions from the specified resource.
 */
export declare const removeAllResourcePermissions: API.OperationMethod<RemoveAllResourcePermissionsRequest & RegionInput, RemoveAllResourcePermissionsResponse, RemoveAllResourcePermissionsError, Credentials | HttpClient.HttpClient>;
export type RemoveResourcePermissionError = FailedDependencyException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Removes the permission for the specified principal from the specified
 * resource.
 */
export declare const removeResourcePermission: API.OperationMethod<RemoveResourcePermissionRequest & RegionInput, RemoveResourcePermissionResponse, RemoveResourcePermissionError, Credentials | HttpClient.HttpClient>;
export type RestoreDocumentVersionsError = ConcurrentModificationException | ConflictingOperationException | EntityNotExistsException | FailedDependencyException | InvalidOperationException | ProhibitedStateException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Recovers a deleted version of an Amazon WorkDocs document.
 */
export declare const restoreDocumentVersions: API.OperationMethod<RestoreDocumentVersionsRequest & RegionInput, RestoreDocumentVersionsResponse, RestoreDocumentVersionsError, Credentials | HttpClient.HttpClient>;
export type SearchResourcesError = InvalidArgumentException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Searches metadata and the content of folders, documents, document versions, and comments.
 */
export declare const searchResources: API.PaginatedOperationMethod<SearchResourcesRequest & RegionInput, SearchResourcesResponse, SearchResourcesError, Credentials | HttpClient.HttpClient, ResponseItem>;
export type UpdateDocumentError = ConcurrentModificationException | ConflictingOperationException | EntityAlreadyExistsException | EntityNotExistsException | FailedDependencyException | LimitExceededException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Updates the specified attributes of a document. The user must have access to both
 * the document and its parent folder, if applicable.
 */
export declare const updateDocument: API.OperationMethod<UpdateDocumentRequest & RegionInput, UpdateDocumentResponse, UpdateDocumentError, Credentials | HttpClient.HttpClient>;
export type UpdateDocumentVersionError = ConcurrentModificationException | EntityNotExistsException | FailedDependencyException | InvalidOperationException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Changes the status of the document version to ACTIVE.
 *
 * Amazon WorkDocs also sets its document container to ACTIVE. This is the last step
 * in a document upload, after the client uploads the document to an S3-presigned URL
 * returned by InitiateDocumentVersionUpload.
 */
export declare const updateDocumentVersion: API.OperationMethod<UpdateDocumentVersionRequest & RegionInput, UpdateDocumentVersionResponse, UpdateDocumentVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateFolderError = ConcurrentModificationException | ConflictingOperationException | EntityAlreadyExistsException | EntityNotExistsException | FailedDependencyException | LimitExceededException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Updates the specified attributes of the specified folder. The user must have access
 * to both the folder and its parent folder, if applicable.
 */
export declare const updateFolder: API.OperationMethod<UpdateFolderRequest & RegionInput, UpdateFolderResponse, UpdateFolderError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = DeactivatingLastSystemUserException | EntityNotExistsException | FailedDependencyException | IllegalUserStateException | InvalidArgumentException | ProhibitedStateException | ServiceUnavailableException | UnauthorizedOperationException | UnauthorizedResourceAccessException | CommonErrors;
/**
 * Updates the specified attributes of the specified user, and grants or revokes
 * administrative privileges to the Amazon WorkDocs site.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=workdocs.d.ts.map