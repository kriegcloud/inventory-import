import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export interface EgressAccessLogs {
    LogGroupName?: string | undefined;
}
export interface ConfigureLogsRequest {
    EgressAccessLogs?: EgressAccessLogs | undefined;
    Id: string;
}
export interface Authorization {
    CdnIdentifierSecret?: string | undefined;
    SecretsRoleArn?: string | undefined;
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface ConfigureLogsResponse {
    Arn?: string | undefined;
    Authorization?: (Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    }) | undefined;
    CreatedAt?: string | undefined;
    DomainName?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateAssetRequest {
    Id?: string | undefined;
    PackagingGroupId?: string | undefined;
    ResourceId?: string | undefined;
    SourceArn?: string | undefined;
    SourceRoleArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface EgressEndpoint {
    PackagingConfigurationId?: string | undefined;
    Status?: string | undefined;
    Url?: string | undefined;
}
export type __listOfEgressEndpoint = EgressEndpoint[];
export interface CreateAssetResponse {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    EgressEndpoints?: EgressEndpoint[] | undefined;
    Id?: string | undefined;
    PackagingGroupId?: string | undefined;
    ResourceId?: string | undefined;
    SourceArn?: string | undefined;
    SourceRoleArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PresetSpeke20Audio = "PRESET-AUDIO-1" | "PRESET-AUDIO-2" | "PRESET-AUDIO-3" | "SHARED" | "UNENCRYPTED" | (string & {});
export type PresetSpeke20Video = "PRESET-VIDEO-1" | "PRESET-VIDEO-2" | "PRESET-VIDEO-3" | "PRESET-VIDEO-4" | "PRESET-VIDEO-5" | "PRESET-VIDEO-6" | "PRESET-VIDEO-7" | "PRESET-VIDEO-8" | "SHARED" | "UNENCRYPTED" | (string & {});
export interface EncryptionContractConfiguration {
    PresetSpeke20Audio?: PresetSpeke20Audio | undefined;
    PresetSpeke20Video?: PresetSpeke20Video | undefined;
}
export type __listOf__string = string[];
export interface SpekeKeyProvider {
    EncryptionContractConfiguration?: EncryptionContractConfiguration | undefined;
    RoleArn?: string | undefined;
    SystemIds?: string[] | undefined;
    Url?: string | undefined;
}
export interface CmafEncryption {
    ConstantInitializationVector?: string | undefined;
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export type AdMarkers = "NONE" | "SCTE35_ENHANCED" | "PASSTHROUGH" | (string & {});
export type StreamOrder = "ORIGINAL" | "VIDEO_BITRATE_ASCENDING" | "VIDEO_BITRATE_DESCENDING" | (string & {});
export interface StreamSelection {
    MaxVideoBitsPerSecond?: number | undefined;
    MinVideoBitsPerSecond?: number | undefined;
    StreamOrder?: StreamOrder | undefined;
}
export interface HlsManifest {
    AdMarkers?: AdMarkers | undefined;
    IncludeIframeOnlyStream?: boolean | undefined;
    ManifestName?: string | undefined;
    ProgramDateTimeIntervalSeconds?: number | undefined;
    RepeatExtXKey?: boolean | undefined;
    StreamSelection?: StreamSelection | undefined;
}
export type __listOfHlsManifest = HlsManifest[];
export interface CmafPackage {
    Encryption?: CmafEncryption | undefined;
    HlsManifests?: HlsManifest[] | undefined;
    IncludeEncoderConfigurationInSegments?: boolean | undefined;
    SegmentDurationSeconds?: number | undefined;
}
export type ManifestLayout = "FULL" | "COMPACT" | (string & {});
export type Profile = "NONE" | "HBBTV_1_5" | (string & {});
export type ScteMarkersSource = "SEGMENTS" | "MANIFEST" | (string & {});
export interface DashManifest {
    ManifestLayout?: ManifestLayout | undefined;
    ManifestName?: string | undefined;
    MinBufferTimeSeconds?: number | undefined;
    Profile?: Profile | undefined;
    ScteMarkersSource?: ScteMarkersSource | undefined;
    StreamSelection?: StreamSelection | undefined;
}
export type __listOfDashManifest = DashManifest[];
export interface DashEncryption {
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export type __PeriodTriggersElement = "ADS" | (string & {});
export type __listOf__PeriodTriggersElement = __PeriodTriggersElement[];
export type SegmentTemplateFormat = "NUMBER_WITH_TIMELINE" | "TIME_WITH_TIMELINE" | "NUMBER_WITH_DURATION" | (string & {});
export interface DashPackage {
    DashManifests?: DashManifest[] | undefined;
    Encryption?: DashEncryption | undefined;
    IncludeEncoderConfigurationInSegments?: boolean | undefined;
    IncludeIframeOnlyStream?: boolean | undefined;
    PeriodTriggers?: __PeriodTriggersElement[] | undefined;
    SegmentDurationSeconds?: number | undefined;
    SegmentTemplateFormat?: SegmentTemplateFormat | undefined;
}
export type EncryptionMethod = "AES_128" | "SAMPLE_AES" | (string & {});
export interface HlsEncryption {
    ConstantInitializationVector?: string | undefined;
    EncryptionMethod?: EncryptionMethod | undefined;
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export interface HlsPackage {
    Encryption?: HlsEncryption | undefined;
    HlsManifests?: HlsManifest[] | undefined;
    IncludeDvbSubtitles?: boolean | undefined;
    SegmentDurationSeconds?: number | undefined;
    UseAudioRenditionGroup?: boolean | undefined;
}
export interface MssEncryption {
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export interface MssManifest {
    ManifestName?: string | undefined;
    StreamSelection?: StreamSelection | undefined;
}
export type __listOfMssManifest = MssManifest[];
export interface MssPackage {
    Encryption?: MssEncryption | undefined;
    MssManifests?: MssManifest[] | undefined;
    SegmentDurationSeconds?: number | undefined;
}
export interface CreatePackagingConfigurationRequest {
    CmafPackage?: CmafPackage | undefined;
    DashPackage?: DashPackage | undefined;
    HlsPackage?: HlsPackage | undefined;
    Id?: string | undefined;
    MssPackage?: MssPackage | undefined;
    PackagingGroupId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreatePackagingConfigurationResponse {
    Arn?: string | undefined;
    CmafPackage?: (CmafPackage & {
        HlsManifests: __listOfHlsManifest;
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    CreatedAt?: string | undefined;
    DashPackage?: (DashPackage & {
        DashManifests: __listOfDashManifest;
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    HlsPackage?: (HlsPackage & {
        HlsManifests: __listOfHlsManifest;
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Id?: string | undefined;
    MssPackage?: (MssPackage & {
        MssManifests: __listOfMssManifest;
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    PackagingGroupId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreatePackagingGroupRequest {
    Authorization?: Authorization | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreatePackagingGroupResponse {
    Arn?: string | undefined;
    Authorization?: (Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    }) | undefined;
    CreatedAt?: string | undefined;
    DomainName?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteAssetRequest {
    Id: string;
}
export interface DeleteAssetResponse {
}
export interface DeletePackagingConfigurationRequest {
    Id: string;
}
export interface DeletePackagingConfigurationResponse {
}
export interface DeletePackagingGroupRequest {
    Id: string;
}
export interface DeletePackagingGroupResponse {
}
export interface DescribeAssetRequest {
    Id: string;
}
export interface DescribeAssetResponse {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    EgressEndpoints?: EgressEndpoint[] | undefined;
    Id?: string | undefined;
    PackagingGroupId?: string | undefined;
    ResourceId?: string | undefined;
    SourceArn?: string | undefined;
    SourceRoleArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribePackagingConfigurationRequest {
    Id: string;
}
export interface DescribePackagingConfigurationResponse {
    Arn?: string | undefined;
    CmafPackage?: (CmafPackage & {
        HlsManifests: __listOfHlsManifest;
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    CreatedAt?: string | undefined;
    DashPackage?: (DashPackage & {
        DashManifests: __listOfDashManifest;
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    HlsPackage?: (HlsPackage & {
        HlsManifests: __listOfHlsManifest;
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Id?: string | undefined;
    MssPackage?: (MssPackage & {
        MssManifests: __listOfMssManifest;
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    PackagingGroupId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribePackagingGroupRequest {
    Id: string;
}
export interface DescribePackagingGroupResponse {
    ApproximateAssetCount?: number | undefined;
    Arn?: string | undefined;
    Authorization?: (Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    }) | undefined;
    CreatedAt?: string | undefined;
    DomainName?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MaxResults = number;
export interface ListAssetsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    PackagingGroupId?: string | undefined;
}
export interface AssetShallow {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    Id?: string | undefined;
    PackagingGroupId?: string | undefined;
    ResourceId?: string | undefined;
    SourceArn?: string | undefined;
    SourceRoleArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfAssetShallow = AssetShallow[];
export interface ListAssetsResponse {
    Assets?: AssetShallow[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPackagingConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    PackagingGroupId?: string | undefined;
}
export interface PackagingConfiguration {
    Arn?: string | undefined;
    CmafPackage?: CmafPackage | undefined;
    CreatedAt?: string | undefined;
    DashPackage?: DashPackage | undefined;
    HlsPackage?: HlsPackage | undefined;
    Id?: string | undefined;
    MssPackage?: MssPackage | undefined;
    PackagingGroupId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfPackagingConfiguration = PackagingConfiguration[];
export interface ListPackagingConfigurationsResponse {
    NextToken?: string | undefined;
    PackagingConfigurations?: (PackagingConfiguration & {
        CmafPackage: CmafPackage & {
            HlsManifests: __listOfHlsManifest;
            Encryption: CmafEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        DashPackage: DashPackage & {
            DashManifests: __listOfDashManifest;
            Encryption: DashEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        HlsPackage: HlsPackage & {
            HlsManifests: __listOfHlsManifest;
            Encryption: HlsEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        MssPackage: MssPackage & {
            MssManifests: __listOfMssManifest;
            Encryption: MssEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
    })[] | undefined;
}
export interface ListPackagingGroupsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface PackagingGroup {
    ApproximateAssetCount?: number | undefined;
    Arn?: string | undefined;
    Authorization?: Authorization | undefined;
    CreatedAt?: string | undefined;
    DomainName?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfPackagingGroup = PackagingGroup[];
export interface ListPackagingGroupsResponse {
    NextToken?: string | undefined;
    PackagingGroups?: (PackagingGroup & {
        Authorization: Authorization & {
            CdnIdentifierSecret: string;
            SecretsRoleArn: string;
        };
    })[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdatePackagingGroupRequest {
    Authorization?: Authorization | undefined;
    Id: string;
}
export interface UpdatePackagingGroupResponse {
    ApproximateAssetCount?: number | undefined;
    Arn?: string | undefined;
    Authorization?: (Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    }) | undefined;
    CreatedAt?: string | undefined;
    DomainName?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConfigureLogsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Changes the packaging group's properities to configure log subscription
 */
export declare const configureLogs: API.OperationMethod<ConfigureLogsRequest & RegionInput, ConfigureLogsResponse, ConfigureLogsError, Credentials | HttpClient.HttpClient>;
export type CreateAssetError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new MediaPackage VOD Asset resource.
 */
export declare const createAsset: API.OperationMethod<CreateAssetRequest & RegionInput, CreateAssetResponse, CreateAssetError, Credentials | HttpClient.HttpClient>;
export type CreatePackagingConfigurationError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new MediaPackage VOD PackagingConfiguration resource.
 */
export declare const createPackagingConfiguration: API.OperationMethod<CreatePackagingConfigurationRequest & RegionInput, CreatePackagingConfigurationResponse, CreatePackagingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreatePackagingGroupError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new MediaPackage VOD PackagingGroup resource.
 */
export declare const createPackagingGroup: API.OperationMethod<CreatePackagingGroupRequest & RegionInput, CreatePackagingGroupResponse, CreatePackagingGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes an existing MediaPackage VOD Asset resource.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest & RegionInput, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeletePackagingConfigurationError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes a MediaPackage VOD PackagingConfiguration resource.
 */
export declare const deletePackagingConfiguration: API.OperationMethod<DeletePackagingConfigurationRequest & RegionInput, DeletePackagingConfigurationResponse, DeletePackagingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePackagingGroupError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes a MediaPackage VOD PackagingGroup resource.
 */
export declare const deletePackagingGroup: API.OperationMethod<DeletePackagingGroupRequest & RegionInput, DeletePackagingGroupResponse, DeletePackagingGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a description of a MediaPackage VOD Asset resource.
 */
export declare const describeAsset: API.OperationMethod<DescribeAssetRequest & RegionInput, DescribeAssetResponse, DescribeAssetError, Credentials | HttpClient.HttpClient>;
export type DescribePackagingConfigurationError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a description of a MediaPackage VOD PackagingConfiguration resource.
 */
export declare const describePackagingConfiguration: API.OperationMethod<DescribePackagingConfigurationRequest & RegionInput, DescribePackagingConfigurationResponse, DescribePackagingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribePackagingGroupError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a description of a MediaPackage VOD PackagingGroup resource.
 */
export declare const describePackagingGroup: API.OperationMethod<DescribePackagingGroupRequest & RegionInput, DescribePackagingGroupResponse, DescribePackagingGroupError, Credentials | HttpClient.HttpClient>;
export type ListAssetsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of MediaPackage VOD Asset resources.
 */
export declare const listAssets: API.PaginatedOperationMethod<ListAssetsRequest & RegionInput, ListAssetsResponse, ListAssetsError, Credentials | HttpClient.HttpClient, AssetShallow>;
export type ListPackagingConfigurationsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of MediaPackage VOD PackagingConfiguration resources.
 */
export declare const listPackagingConfigurations: API.PaginatedOperationMethod<ListPackagingConfigurationsRequest & RegionInput, ListPackagingConfigurationsResponse, ListPackagingConfigurationsError, Credentials | HttpClient.HttpClient, PackagingConfiguration>;
export type ListPackagingGroupsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of MediaPackage VOD PackagingGroup resources.
 */
export declare const listPackagingGroups: API.PaginatedOperationMethod<ListPackagingGroupsRequest & RegionInput, ListPackagingGroupsResponse, ListPackagingGroupsError, Credentials | HttpClient.HttpClient, PackagingGroup>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Returns a list of the tags assigned to the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Adds tags to the specified resource. You can specify one or more tags to add.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes tags from the specified resource. You can specify one or more tags to remove.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePackagingGroupError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Updates a specific packaging group. You can't change the id attribute or any other system-generated attributes.
 */
export declare const updatePackagingGroup: API.OperationMethod<UpdatePackagingGroupRequest & RegionInput, UpdatePackagingGroupResponse, UpdatePackagingGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediapackage-vod.d.ts.map