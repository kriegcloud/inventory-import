import type * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
import type { HyperdriveOrigin } from "./bindings/hyperdrive/HyperdriveOrigin.shared.ts";
import type { QueueConsumer } from "./bindings/queue/QueueOptions.shared.ts";
import type { ContainerImage } from "./Docker.ts";
import type { BindingHook } from "./PluginContext.ts";
import { RuntimeError } from "./RuntimeError.shared.ts";
import type * as WorkerdConfig from "./workerd/Config.ts";
import { type OutputSink, WorkerdExit } from "./workerd/Workerd.ts";

/**
 * The lifecycle events of the `workerd` processes serving a worker, as one
 * schema union discriminated by `type` (`domain.subject.verb`), so a host can
 * log or send them as JSON.
 */
export const WorkerdEvent = Schema.Union([
  /**
   * A process is serving the worker. `generation` is 0 for the first start
   * and counts replacements after it. Connections into a previous generation
   * are gone, so a caller that keeps any (such as the Vite module runner
   * sockets) reconnects on a generation above 0.
   */
  Schema.Struct({
    type: Schema.Literal("workerd.process.started"),
    pid: Schema.Number,
    generation: Schema.Number,
  }),
  /** The process exited on its own. */
  Schema.Struct({ type: Schema.Literal("workerd.process.exited"), exit: WorkerdExit }),
  /** A replacement starts after `delayMs`, on the same ports. */
  Schema.Struct({
    type: Schema.Literal("workerd.restart.scheduled"),
    attempt: Schema.Number,
    delayMs: Schema.Number,
  }),
  /**
   * Recovery gave up: `restart-limit` after three restarts within a minute,
   * `restart-failed` when a replacement failed to start.
   */
  Schema.Struct({
    type: Schema.Literal("workerd.recovery.stopped"),
    reason: Schema.Literals(["restart-limit", "restart-failed"]),
    error: Schema.optionalKey(RuntimeError),
  }),
]);
export type WorkerdEvent = typeof WorkerdEvent.Type;

export interface RuntimeWorker<B extends BindingHooks = BindingHooks> {
  readonly name: string;
  readonly proxySharedSecret?: string;
  /**
   * The URL clients reach the Worker at, when a dev server or proxy fronts
   * the runtime. Bindings that hand out URLs to the Worker's own endpoints
   * (Stream preview URLs, Images variant URLs) use it, as Miniflare uses its
   * public URL. Defaults to the runtime's own entry address.
   */
  readonly publicUrl?: string;
  readonly compatibilityDate: string;
  readonly compatibilityFlags: Array<string>;
  readonly bindings: B;
  readonly modules: ReadonlyArray<Module>;
  readonly assets?: Assets;
  readonly hyperdrives?: Record<string, HyperdriveOrigin>;
  readonly durableObjectNamespaces?: ReadonlyArray<DurableObjectNamespace>;
  /**
   * Workflows whose `WorkflowEntrypoint` class is exported by this worker.
   * Each entry hosts a local engine service (`workflows:<name>`) in this
   * process and is published to the dev registry for cross-instance bindings.
   */
  readonly workflows?: ReadonlyArray<Workflow>;
  /**
   * Queues this worker consumes via its `queue()` handler. Each consumed
   * queue gets an in-memory broker hosted in this worker's process; producers
   * (local or in other dev instances) deliver to it.
   */
  readonly queueConsumers?: ReadonlyArray<QueueConsumer>;
  /**
   * Cron expressions (UTC) that trigger this worker's `scheduled()` handler.
   * Each expression gets a Node-side timer that hits the entry socket's
   * `/cdn-cgi/handler/scheduled` route at every match, so crons actually
   * fire during local development. The route is also reachable manually
   * (Miniflare-compatible: `?cron=<expr>&time=<epoch-millis>`).
   */
  readonly crons?: ReadonlyArray<string>;
  /**
   * Names of tail consumer workers (the deployed `tail_consumers` setting).
   * workerd delivers this worker's trace events to each consumer's `tail()`
   * handler. Consumers are resolved through the on-disk dev registry — the
   * same path service bindings to other local workers take — so a consumer
   * may run in a separate `cloudflare-runtime` or `wrangler dev` process and
   * may (re)start at any time. Events produced while a consumer is not
   * running are dropped with a warning, matching dev-registry semantics.
   */
  readonly tails?: ReadonlyArray<string>;
  /**
   * Names of streaming tail consumer workers (the deployed
   * `streaming_tail_consumers` setting). The handler contract differs from
   * plain `tails`: a plain tail consumer exports `tail(items)` and receives an
   * array of completed `TraceItem`s after the producer's invocation has
   * finished, while a streaming tail consumer exports `tailStream(event)`,
   * which is invoked with the invocation's `onset` event as soon as the
   * producer starts executing and returns a handler (a function, or an object
   * keyed by event type) that receives every subsequent event (`spanOpen` /
   * `spanClose`, `log`, `exception`, `diagnosticChannel`, `return`, …)
   * streamed live during execution, ending with the terminal `outcome` event.
   * Consumers are resolved through the on-disk dev registry exactly like
   * `tails` — the registry proxy's `ExternalService` entrypoint forwards the
   * `tailStream()` session to the consumer's process via the workerd debug
   * port — so a consumer may run in a separate process and may (re)start at
   * any time. Sessions started while a consumer is not running are dropped
   * with a warning, matching dev-registry semantics.
   */
  readonly streamingTails?: ReadonlyArray<string>;
  /**
   * Whether the Cache API (`caches.default` / `caches.open()`) stores
   * responses. Defaults to `true`; when `false` every cache operation is a
   * no-op (matching production behaviour on `workers.dev` subdomains).
   */
  readonly cache?: boolean;
  /**
   * Per-worker `request.cf` blob. Merged the way Miniflare does — used
   * verbatim unless the request carries an `MF-CF-Blob` header. Falls back
   * to the runtime-wide `Cf` reference (a static placeholder by default).
   */
  readonly cf?: Record<string, unknown>;
  /**
   * Simulates a request that passed Cloudflare Access: every request's
   * `ctx.access` carries `aud`, and `ctx.access.getIdentity()` resolves
   * `identity`. Mirrors Wrangler's `access.dev` config.
   */
  readonly access?: {
    readonly aud?: string;
    readonly identity?: Record<string, unknown>;
  };
  /**
   * Controls how output from the underlying `workerd` process is surfaced.
   *
   * By default, workerd does not log uncaught exceptions thrown by the
   * worker — they surface as bare `500 Internal Server Error` responses with
   * no output anywhere. Set `verbose: true` to have workerd log them
   * (message + stack) to stderr, and optionally `onOutput` to capture the
   * process output instead of inheriting the parent process's stdio.
   */
  readonly logging?: WorkerdLogging;
  /** Overrides for the `workerd` process that serves this worker. */
  readonly workerd?: WorkerdOptions;
  /**
   * Reports the lifecycle of the `workerd` processes that serve this worker,
   * so an embedding host can track the child PID, save state while workerd
   * is down, or stop when recovery gives up. See {@link WorkerdEvent}.
   *
   * A process that exits on its own (for example when V8 ran out of heap) is
   * replaced on the same ports, so the URL returned by `start` stays valid.
   * Automatic recovery is limited to three restarts within a rolling minute,
   * with backoff between attempts. A failed replacement stops recovery.
   * Closing the runtime's scope kills the process and cancels a pending
   * replacement without reporting an exit.
   *
   * Recovery never waits for the callback. One that throws or returns a
   * rejected promise is logged, and recovery continues.
   */
  readonly onEvent?: (event: WorkerdEvent) => void | PromiseLike<void>;
  /**
   * Runs once, after bindings are prepared and container images are built or
   * pulled, immediately before the first `workerd` process is spawned. A
   * caller replacing a previous instance of this worker uses it to tear that
   * instance down first when the two cannot overlap — e.g. containers, whose
   * deterministic names make a new process adopt ("recover") the previous
   * process's still-running container, which that process's teardown then
   * removes.
   */
  readonly beforeServe?: Effect.Effect<void>;
  /**
   * Also serve the Worker on a Unix socket at this path (macOS and Linux
   * only). The file is removed before each workerd start and when the runtime
   * stops, so the path must belong to this runtime alone.
   */
  readonly entrySocketPath?: string;
  readonly unsafe?: Partial<WorkerdConfig.Worker>;
}

export interface WorkerdLogging {
  /**
   * Pass `--verbose` to workerd. Enables INFO-level logging, which includes
   * uncaught exceptions thrown by the worker (message + stack, written to
   * stderr) — without it, those exceptions surface as bare
   * `500 Internal Server Error` responses with no log output anywhere.
   */
  readonly verbose?: boolean;
  /**
   * Capture the workerd process's stdout/stderr output instead of piping it
   * to the parent process's stdio. Output produced before the process
   * finishes starting is not captured; startup failures surface as typed
   * errors instead.
   */
  readonly onOutput?: OutputSink;
}

export interface WorkerdOptions {
  /**
   * Path to the workerd binary, instead of the one from the `workerd`
   * package and `ALCHEMY_WORKERD_PATH`. Useful where the npm binary can't
   * run, e.g. NixOS.
   */
  readonly path?: string;
  /**
   * Extra V8 flags, e.g. `["--max-old-space-size=4096"]`. Applied after
   * `ALCHEMY_WORKERD_V8_FLAGS`, so they win when both set the same flag.
   */
  readonly v8Flags?: ReadonlyArray<string>;
  /** Extra environment variables for the workerd process. */
  readonly env?: Record<string, string>;
}

export type BindingHooks = ReadonlyArray<BindingHook<any>>;

export type { HyperdriveOrigin } from "./bindings/hyperdrive/HyperdriveOrigin.shared.ts";
export type { QueueConsumer } from "./bindings/queue/QueueOptions.shared.ts";

export type Module =
  | {
      name: string;
      type: "ESModule" | "CommonJsModule" | "Text" | "Json" | "PythonModule";
      content: string;
    }
  | {
      name: string;
      type: "Data" | "Wasm";
      content: Uint8Array;
    };

export interface Assets {
  directory?: string;
  headers?: string;
  redirects?: string;
  htmlHandling?: "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
  notFoundHandling?: "none" | "404-page" | "single-page-application";
  /**
   * URL path prefix the assets are served under (`assets.base_path`), e.g.
   * `/subpath` serves `public/test.txt` at `/subpath/test.txt`. The Asset
   * Worker normalizes relative values and 404s requests outside the prefix.
   */
  basePath?: string;
  runWorkerFirst?: Array<string> | boolean;
  serveDirectly?: boolean;
}

export interface DurableObjectNamespace {
  className: string;
  sql: boolean;
  uniqueKey?: string;
  ephemeralLocal?: true;
  /**
   * Attach a container to every Durable Object in this namespace. workerd
   * starts one per DO instance via the worker's `containerEngine` and exposes
   * it as `ctx.container`.
   */
  container?: ContainerImage | { images: Record<string, ContainerImage> };
}

export interface Workflow {
  /**
   * Logical name of the workflow. Used as the engine identity
   * (`workflows:<workflowName>`) and published to the dev registry.
   */
  workflowName: string;
  /**
   * Class name of the `WorkflowEntrypoint` exported by this worker.
   */
  className: string;
  /**
   * Optional step limit enforced by the local workflow engine.
   */
  stepLimit?: number;
}
