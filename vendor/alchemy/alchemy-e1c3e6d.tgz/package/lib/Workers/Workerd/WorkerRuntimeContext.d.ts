import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type { FunctionContext } from "../../Runtime/Function.ts";
/** Something a hosted class or capture exports onto its Worker's bundle. */
export interface WorkerExportLike {
    readonly kind: string;
}
/** The engine-specific half of a Worker runtime context. */
export interface WorkerRuntimeContextOptions {
    /** The Worker resource type (e.g. `Cloudflare.Worker`). */
    readonly type: string;
    /** Services the host provides its init in every phase. */
    readonly hostServices?: Layer.Layer<any, never, any> | undefined;
    /**
     * The engine's own per-event services (its execution context): the bridge
     * provides them to each event, so a listener never keeps init's copy.
     */
    readonly eventServices?: ReadonlyArray<Context.Key<any, any>> | undefined;
}
export interface WorkerRuntimeContext extends FunctionContext {
    export(name: string, value: any): Effect.Effect<void>;
    shape: () => Record<string, any>;
}
export declare const makeWorkerRuntimeContext: (id: string, options: WorkerRuntimeContextOptions) => WorkerRuntimeContext;
//# sourceMappingURL=WorkerRuntimeContext.d.ts.map