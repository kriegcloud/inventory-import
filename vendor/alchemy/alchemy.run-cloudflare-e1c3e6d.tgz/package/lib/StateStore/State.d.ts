import * as SecretsStore from "@distilled.cloud/cloudflare/secrets-store";
import * as workers from "@distilled.cloud/cloudflare/workers";
import { AuthError } from "alchemy/Auth/AuthProvider";
import { CredentialsStore } from "alchemy/Auth/Credentials";
import * as Interaction from "alchemy/Interaction";
import { State, StateStoreError } from "alchemy/State/State";
import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Access from "../Access.ts";
import * as CloudflareEnvironment from "../CloudflareEnvironment.ts";
import type { WorkerObservability } from "../Workers/Worker.ts";
export type CloudflareStateOptions = {
    /**
     * The Cloudflare account the store lives in. Defaults to the account your
     * Alchemy profile resolves. Pin it when your credentials reach several
     * accounts, so a login against a different one can't read or deploy the
     * store somewhere else.
     */
    readonly accountId?: string;
    /**
     * Serve the store on this hostname in one of the account's zones instead of
     * its workers.dev URL, for networks that can't reach workers.dev. Bootstrap
     * attaches it to the store's Worker as a custom domain.
     */
    readonly domain?: string;
    /**
     * The store's Worker name, for a store other than the account's default
     * `alchemy-state-store`: 1-54 lowercase letters, digits, `-` and `_`,
     * starting with a letter or digit. Its secrets are named after it, e.g.
     * `acme-state` keeps its token in `AlchemyStateStoreToken_acme_state`.
     * @default "alchemy-state-store"
     */
    readonly workerName?: string;
    /**
     * The store Worker's observability settings.
     * @default { enabled: true, logs: { enabled: true, invocationLogs: true } }
     */
    readonly observability?: WorkerObservability;
};
export declare const state: (options?: CloudflareStateOptions) => Layer.Layer<State, never, import("alchemy").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/FileSystem").FileSystem | HttpClient.HttpClient | Interaction.Interaction | import("effect/Path").Path | import("effect/crypto/SecureRandom").SecureRandom>;
export interface BootstrapOptions {
    /** @default "alchemy-state-store" */
    workerName?: string;
    /** The account to deploy into. Defaults to the profile's account. */
    accountId?: string;
    /** A hostname to serve the store on, attached as a custom domain. */
    domain?: string;
    /** The store Worker's observability settings. See {@link CloudflareStateOptions.observability}. */
    observability?: WorkerObservability;
    /** @default false */
    force?: boolean;
    /** @default "default" */
    profile?: string;
}
export declare const bootstrap: (options?: BootstrapOptions) => Effect.Effect<import("alchemy/State/State").StateService, Access.AccessError | AuthError | import("@distilled.cloud/iceberg").BadGateway | import("alchemy/Bundle/Bundle").BundleError | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | Config.ConfigError | import("@distilled.cloud/iceberg").ConfigError | workers.D1DatabaseNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").D1DatabaseNotFound | workers.DispatchNamespaceNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").DispatchNamespaceNotFound | workers.DuplicateMigrationTarget | workers.DurableObjectClassNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").DurableObjectClassNotFound | workers.DurableObjectMustBeSqlite | import("@distilled.cloud/iceberg").Forbidden | workers.Forbidden | import("@distilled.cloud/cloudflare/workers-for-platforms").Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | workers.HostnameAlreadyInUse | import("effect/http/HttpClientError").HttpClientError | workers.HyperdriveConfigNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").HyperdriveConfigNotFound | import("@distilled.cloud/iceberg").InternalServerError | SecretsStore.InvalidAccountId | import("@distilled.cloud/cloudflare/durable-objects").InvalidIdentifier | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | workers.InvalidRoute | workers.InvalidWorkerScript | import("@distilled.cloud/cloudflare/zones").InvalidZoneIdentifier | workers.KVNamespaceNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").KVNamespaceNotFound | workers.MtlsCertificateNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").MtlsCertificateNotFound | SecretsStore.NotFound | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("effect/PlatformError").PlatformError | import("alchemy/Auth/Profile").ProfileError | workers.QueueNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").QueueNotFound | workers.R2BucketNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").R2BucketNotFound | workers.ScriptModuleNotFound | workers.ScriptStartupError | import("@distilled.cloud/core/sdk-error").SdkError | SecretsStore.SecretNameEmpty | SecretsStore.SecretScopeInvalid | workers.SecretsStoreBindingNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").SecretsStoreBindingNotFound | workers.ServiceBindingNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").ServiceBindingNotFound | import("@distilled.cloud/iceberg").ServiceUnavailable | StateStoreError | StateStoreVersionNotReady | SecretsStore.StoreNotFound | workers.SubdomainNotFound | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError | workers.UnknownWorkerEntrypoint | import("@distilled.cloud/cloudflare/workers-for-platforms").UnknownWorkerEntrypoint | workers.VectorizeIndexNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").VectorizeIndexNotFound | workers.WorkerNotFound, Access.Access | CloudflareEnvironment.CloudflareEnvironment | CredentialsStore | import("effect/FileSystem").FileSystem | Interaction.Interaction | import("effect/Path").Path | import("alchemy/Auth/Profile").ProfileStore | import("effect/crypto/SecureRandom").SecureRandom | SecretsStore.CloudflareOpContext>;
export interface TeardownOptions {
    /** @default "alchemy-state-store" */
    workerName?: string;
    /** The account the store lives in. Defaults to the profile's account. */
    accountId?: string;
    /** @default "default" */
    profile?: string;
    /**
     * Delete the account Secrets Store too, but only once the state-store
     * secrets have been removed and no other secrets remain in it. A store that
     * still holds foreign secrets is left in place.
     * @default true
     */
    deleteEmptySecretsStore?: boolean;
}
/**
 * The inverse of {@link bootstrap}: tear down the Cloudflare-deployed state
 * store. Deletes the state-store Worker and the secrets it created in the
 * account Secrets Store (the bearer token + the encryption key), then deletes
 * the Secrets Store itself if it is left empty, and drops the locally cached
 * state-store credentials for the profile.
 *
 * Idempotent — missing resources are treated as already-gone, so it is safe to
 * re-run. Intended for reclaiming a throwaway account after testing; on a
 * shared account it only removes resources alchemy created.
 */
export declare const teardownStateStore: (options?: TeardownOptions) => Effect.Effect<void, import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("@distilled.cloud/iceberg").ConfigError | import("@distilled.cloud/iceberg").Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | workers.InvalidRoute | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("effect/PlatformError").PlatformError | import("alchemy/Auth/Profile").ProfileError | workers.QueueConsumerConflict | import("@distilled.cloud/core/sdk-error").SdkError | workers.ServiceBindingConflict | import("@distilled.cloud/iceberg").ServiceUnavailable | StateStoreError | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, CloudflareEnvironment.CloudflareEnvironment | CredentialsStore | import("effect/FileSystem").FileSystem | Interaction.Interaction | import("effect/Path").Path | import("alchemy/Auth/Profile").ProfileStore | import("effect/crypto/SecureRandom").SecureRandom | SecretsStore.CloudflareOpContext>;
/**
 * Log in to a Cloudflare-deployed HTTP state-store.
 *
 * 1. Find the single account-wide Secrets Store.
 * 2. Upload a short-lived edge-preview worker that binds the
 *    auth-token secret and returns its value.
 * 3. Derive the state-store worker URL: its custom `domain`, or its
 *    workers.dev URL.
 * 4. Persist `{ url, token }` under the `http-state-store`
 *    credentials file.
 *
 * Requirements are covered by the Cloudflare provider stack —
 * `CloudflareEnvironment`, `Credentials`, `HttpClient`, and
 * `FileSystem`.
 */
export declare const loginWithCloudflare: (profileName: string, force: boolean, scriptName?: string | undefined, pinnedAccountId?: string | undefined, domain?: string | undefined) => Effect.Effect<{
    readonly url: string;
    readonly authToken: string;
    readonly accountId?: string | undefined;
}, AuthError | import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | Config.ConfigError | import("@distilled.cloud/iceberg").ConfigError | import("@distilled.cloud/iceberg").Forbidden | workers.Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | SecretsStore.InvalidAccountId | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | workers.InvalidRoute | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/core/sdk-error").SdkError | import("@distilled.cloud/iceberg").ServiceUnavailable | StateStoreError | workers.SubdomainNotFound | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, Access.Access | CloudflareEnvironment.CloudflareEnvironment | CredentialsStore | import("effect/FileSystem").FileSystem | Interaction.Interaction | import("effect/Path").Path | import("effect/crypto/SecureRandom").SecureRandom | SecretsStore.CloudflareOpContext>;
declare const StateStoreVersionNotReady_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "StateStoreVersionNotReady";
} & Readonly<A>;
export declare class StateStoreVersionNotReady extends StateStoreVersionNotReady_base<{
    readonly expected: number;
    readonly observed: number | undefined;
}> {
    get message(): string;
}
/**
 * Edge-preview reads are flaky in ways that clear up on their own:
 * the workers.dev edge can serve a generic Cloudflare 400/502 HTML
 * page while preview routing propagates ("Secret probe returned
 * ..."), the session-create call can hit transient API blips, and the
 * probe fetch can fail at the transport level ("fetch failed").
 * Retry everything except causes that are clearly permanent
 * (bad credentials, invalid routes).
 *
 * @internal exported for unit testing.
 */
export declare const isTransientEdgeSessionError: (error: unknown) => boolean;
export {};
//# sourceMappingURL=State.d.ts.map