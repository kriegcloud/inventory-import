import type * as cf from "@cloudflare/workers-types";
import * as Context from "effect/Context";
import type * as SecureRandom from "effect/crypto/SecureRandom";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Scope from "effect/Scope";
import { CallbackError, type Callback, type CallbackStatus } from "../../Callback.ts";
import { RuntimeContext } from "../../RuntimeContext.ts";
/**
 * @internal Override the redelivery policy, for tests of the scheduler
 * itself. Not part of `Alchemy.makeCallback`.
 */
export interface AlarmRetryPolicy {
    readonly delay?: Duration.Input;
    readonly maxAttempts?: number;
    readonly parkedDelay?: Duration.Input;
}
/** @internal A job's status, with the scheduler's redelivery state. */
export interface AlarmCallbackStatus extends CallbackStatus {
    readonly retryAt: number | undefined;
    readonly attempts: number;
    readonly parked: boolean;
}
/** @internal An alarm callback, with the scheduler's redelivery state. */
export interface AlarmCallback<Payload> extends Callback<Payload> {
    readonly getStatus: (id: string) => Effect.Effect<AlarmCallbackStatus | undefined, CallbackError, RuntimeContext>;
}
/** @internal Register an alarm callback, optionally with its own redelivery policy. */
export type AlarmCallbackFactory = <Payload, E, R>(name: string, handler: (payload: Payload) => Effect.Effect<unknown, E, R>, retry?: AlarmRetryPolicy) => Effect.Effect<AlarmCallback<Payload>, never, Exclude<R, Scope.Scope>>;
/**
 * @internal Run background work handed to `waitUntil` apart from the callback
 * invocation that started it. The invocation ends first, so its schedules
 * would be rejected; here they start a fresh budget, as external schedules
 * do. Only for work whose schedules report their own progress.
 */
export declare const outsideAlarmPass: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, never>>;
/** @internal */
export declare const initializeAlarmCallbacks: (state: cf.DurableObjectState) => () => void;
/**
 * The durable callback factory of one Durable Object instance. `stateTag`
 * is the engine's own Durable Object state service, stripped (with the other
 * per-invocation services) from the registration-time context a handler
 * closes over.
 *
 * @internal
 */
export declare const makeDurableObjectCallbackFactory: (raw: cf.DurableObjectState, stateTag: Context.Key<any, any>, random: SecureRandom.SecureRandom["Service"]) => AlarmCallbackFactory;
/** @internal */
export declare const dispatchAlarmCallbacks: (state: cf.DurableObjectState, hasLegacyHandler: boolean) => Effect.Effect<undefined, unknown, any>;
//# sourceMappingURL=AlarmCallback.d.ts.map