import { Command, Flag } from "effect/cli";
import * as Option from "effect/Option";
import type * as Contributions from "../../Contributions.ts";
/**
 * The flags of every provider's state store, such as `--name` or `--domain`,
 * each optional so a flag not given is `undefined`. Stores that set the same
 * option with the same flag share it. A flag that can't be added is left out
 * with a warning, and `ignored` lists it so the CLI refuses that option for
 * its store. Which ones a backend takes is checked when the store is opened.
 *
 * @internal exported for tests.
 */
export declare const storeOptionFlags: (contributions: ReadonlyArray<Contributions.Contributions>) => {
    flags: Record<string, Flag.Flag<unknown>>;
    ignored: Record<string, string[]>;
};
/**
 * `alchemy state`, sharing a flag with every subcommand for each one the
 * loaded providers' state stores contribute.
 */
export declare const stateCommand: (contributions: ReadonlyArray<Contributions.Contributions>) => Command.Command<"state", {
    readonly storeOptions: {
        readonly [x: string]: unknown;
    };
} | {
    readonly main: string;
    readonly envFile: Option.Option<string>;
    readonly profile: string | undefined;
    readonly backend: string;
    readonly storeOptions: {
        readonly [x: string]: unknown;
    };
}, {
    readonly storeOptions: {
        readonly [x: string]: unknown;
    };
}, Contributions.ContributionFailure, import("effect/Scope").Scope | Contributions.HostServices>;
//# sourceMappingURL=state.d.ts.map