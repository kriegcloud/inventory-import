import * as emailRouting from "@distilled.cloud/cloudflare/email-routing";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
export type AddressProps = {
    /**
     * The email address to register as a verified destination on the
     * account. Cloudflare sends a verification email to this address; the
     * recipient must click the link before the address can receive routed
     * mail or be used as a verified sender.
     *
     * Changing this property triggers a replacement.
     */
    email: string;
};
export type Address = Resource<"Cloudflare.Email.Address", AddressProps, {
    addressId: string;
    email: string;
    accountId: string;
    verified: boolean;
    verifiedAt: string | undefined;
    created: string | undefined;
    modified: string | undefined;
}, never, Providers, AddressLookup>;
/**
 * Props for {@link Address.lookup}: find a destination address this stack
 * doesn't manage, by its email or its id.
 */
export type AddressLookup = {
    /**
     * The registered email address.
     */
    email: string;
} | {
    /**
     * The Cloudflare-assigned ID of the destination address.
     */
    addressId: string;
};
/**
 * A verified destination email address on the account.
 *
 * Destination addresses are account-scoped (not zone-scoped). They are used
 * as forwarding targets in `Rule` actions and can also serve as the
 * `destinationAddress` on a `send_email` Worker binding.
 * ### Registering an Address
 * **Example:** Register a destination address
 * ```typescript
 * const ops = yield* Cloudflare.Email.Address("Ops", {
 *   email: "ops@example.com",
 * });
 * ```
 *
 * Cloudflare sends a verification email when the address is first created.
 * The address must be verified before it can receive routed mail.
 *
 * ### Looking up an existing Address
 * `Address.lookup` reads a destination address Alchemy doesn't manage
 * (registered in the dashboard or by another stack), found by `email` or
 * `addressId`. It is read during plan/deploy and never created or deleted,
 * so no verification email is sent.
 *
 * **Example:** Forward to an address another stack registered
 * ```typescript
 * const ops = Cloudflare.Email.Address.lookup({ email: "ops@example.com" });
 * yield* Cloudflare.Email.Rule("Support", {
 *   zone: "example.com",
 *   matchers: [{ type: "literal", field: "to", value: "support@example.com" }],
 *   actions: [{ type: "forward", value: [ops.email] }],
 * });
 * ```
 *
 * @resource
 * @product Email
 * @category Email
 */
export declare const Address: import("alchemy").ResourceClass<Address>;
export declare const AddressProvider: () => import("effect/Layer").Layer<Provider.Provider<Address>, never, CloudflareEnvironment | emailRouting.CloudflareOpContext>;
//# sourceMappingURL=Address.d.ts.map