import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const IllegalArgumentException_base: S.TaggedErrorClass<"IllegalArgumentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalArgumentException extends /*@__PURE__*/ IllegalArgumentException_base {
}
declare const IllegalStateException_base: S.TaggedErrorClass<"IllegalStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalStateException extends /*@__PURE__*/ IllegalStateException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RetryableConflictException_base: S.TaggedErrorClass<"RetryableConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RetryableConflictException extends /*@__PURE__*/ RetryableConflictException_base {
}
export type PlanArn = string;
export type ExecutionId = string;
export type StepName = string;
export type Approval = "approve" | "decline" | (string & {});
export type ExecutionComment = string;
export interface ApprovePlanExecutionStepRequest {
    planArn: string;
    executionId: string;
    stepName: string;
    approval: Approval;
    comment?: string | undefined;
}
export interface ApprovePlanExecutionStepResponse {
}
export interface CancelPlanExecutionRequest {
    planArn: string;
    executionId: string;
    comment?: string | undefined;
}
export interface CancelPlanExecutionResponse {
}
export type IamRoleArn = string;
export type LambdaArn = string;
export type LambdaPayload = string | redacted.Redacted<string>;
export interface Lambdas {
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    arn?: string | undefined;
    payload?: string | redacted.Redacted<string> | undefined;
}
export type LambdaList = Lambdas[];
export type RegionToRunIn = "activatingRegion" | "deactivatingRegion" | "activeRegion" | "inactiveRegion" | (string & {});
export type LambdaUngracefulBehavior = "skip" | (string & {});
export interface LambdaUngraceful {
    behavior?: LambdaUngracefulBehavior | undefined;
}
export interface CustomActionLambdaConfiguration {
    timeoutMinutes?: number | undefined;
    lambdas: Lambdas[];
    retryIntervalMinutes: number;
    regionToRun: RegionToRunIn;
    ungraceful?: LambdaUngraceful | undefined;
}
export type AsgArn = string;
export interface Asg {
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    arn?: string | undefined;
}
export type AsgList = Asg[];
export interface Ec2Ungraceful {
    minimumSuccessPercentage: number;
}
export type Ec2AsgCapacityMonitoringApproach = "sampledMaxInLast24Hours" | "autoscalingMaxInLast24Hours" | (string & {});
export type WaitELBTargetGroupHealthy = "enabled" | "disabled" | (string & {});
export interface Ec2AsgCapacityIncreaseConfiguration {
    timeoutMinutes?: number | undefined;
    asgs: Asg[];
    ungraceful?: Ec2Ungraceful | undefined;
    targetPercent?: number | undefined;
    capacityMonitoringApproach?: Ec2AsgCapacityMonitoringApproach | undefined;
    waitELBTargetGroupHealthy?: WaitELBTargetGroupHealthy | undefined;
}
export type RoleArn = string;
export interface ExecutionApprovalConfiguration {
    timeoutMinutes?: number | undefined;
    approvalRole: string;
}
export type RoutingControlArn = string;
export type RoutingControlStateChange = "On" | "Off" | (string & {});
export interface ArcRoutingControlState {
    routingControlArn: string;
    state: RoutingControlStateChange;
}
export type ArcRoutingControlStates = ArcRoutingControlState[];
export type RegionAndRoutingControls = {
    [key: string]: ArcRoutingControlState[] | undefined;
};
export interface ArcRoutingControlConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    regionAndRoutingControls: {
        [key: string]: ArcRoutingControlState[] | undefined;
    };
}
export type GlobalAuroraDefaultBehavior = "switchoverOnly" | "failover" | (string & {});
export type GlobalAuroraUngracefulBehavior = "failover" | (string & {});
export interface GlobalAuroraUngraceful {
    ungraceful?: GlobalAuroraUngracefulBehavior | undefined;
}
export type GlobalClusterIdentifier = string;
export type AuroraClusterArn = string;
export type AuroraClusterArns = string[];
export interface GlobalAuroraConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    behavior: GlobalAuroraDefaultBehavior;
    ungraceful?: GlobalAuroraUngraceful | undefined;
    globalClusterIdentifier: string;
    databaseClusterArns: string[];
}
export interface ParallelExecutionBlockConfiguration {
    steps: Step[];
}
export interface RegionSwitchPlanConfiguration {
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    arn: string;
}
export type EcsClusterArn = string;
export type EcsServiceArn = string;
export interface Service {
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    clusterArn?: string | undefined;
    serviceArn?: string | undefined;
}
export type ServiceList = Service[];
export interface EcsUngraceful {
    minimumSuccessPercentage: number;
}
export type EcsCapacityMonitoringApproach = "sampledMaxInLast24Hours" | "containerInsightsMaxInLast24Hours" | (string & {});
export interface EcsCapacityIncreaseConfiguration {
    timeoutMinutes?: number | undefined;
    services: Service[];
    ungraceful?: EcsUngraceful | undefined;
    targetPercent?: number | undefined;
    capacityMonitoringApproach?: EcsCapacityMonitoringApproach | undefined;
    waitELBTargetGroupHealthy?: WaitELBTargetGroupHealthy | undefined;
}
export interface KubernetesResourceType {
    apiVersion: string;
    kind: string;
}
export type Region = string;
export type KubernetesNamespace = string;
export interface KubernetesScalingResource {
    namespace: string;
    name: string;
    hpaName?: string | undefined;
}
export type RegionalScalingResource = {
    [key: string]: KubernetesScalingResource | undefined;
};
export type KubernetesScalingApplication = {
    [key: string]: {
        [key: string]: KubernetesScalingResource | undefined;
    } | undefined;
};
export type KubernetesScalingApps = {
    [key: string]: {
        [key: string]: KubernetesScalingResource | undefined;
    } | undefined;
}[];
export type EksClusterArn = string;
export interface EksCluster {
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    clusterArn: string;
}
export type EksClusters = EksCluster[];
export interface EksResourceScalingUngraceful {
    minimumSuccessPercentage: number;
}
export type EksCapacityMonitoringApproach = "sampledMaxInLast24Hours" | (string & {});
export interface EksResourceScalingConfiguration {
    timeoutMinutes?: number | undefined;
    kubernetesResourceType: KubernetesResourceType;
    scalingResources?: {
        [key: string]: {
            [key: string]: KubernetesScalingResource | undefined;
        } | undefined;
    }[] | undefined;
    eksClusters?: EksCluster[] | undefined;
    ungraceful?: EksResourceScalingUngraceful | undefined;
    targetPercent?: number | undefined;
    capacityMonitoringApproach?: EksCapacityMonitoringApproach | undefined;
}
export type Route53HostedZoneId = string;
export type Route53RecordName = string;
export type Route53ResourceRecordSetIdentifier = string;
export interface Route53ResourceRecordSet {
    recordSetIdentifier?: string | undefined;
    region?: string | undefined;
}
export type Route53ResourceRecordSetList = Route53ResourceRecordSet[];
export interface Route53HealthCheckConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    hostedZoneId: string;
    recordName: string;
    recordSets?: Route53ResourceRecordSet[] | undefined;
}
export type DocumentDbDefaultBehavior = "switchoverOnly" | "failover" | (string & {});
export type DocumentDbUngracefulBehavior = "failover" | (string & {});
export interface DocumentDbUngraceful {
    ungraceful?: DocumentDbUngracefulBehavior | undefined;
}
export type DocumentDbGlobalClusterIdentifier = string;
export type DocumentDbClusterArn = string;
export type DocumentDbClusterArns = string[];
export interface DocumentDbConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    behavior: DocumentDbDefaultBehavior;
    ungraceful?: DocumentDbUngraceful | undefined;
    globalClusterIdentifier: string;
    databaseClusterArns: string[];
}
export type RdsDbInstanceArn = string;
export type RdsDbInstanceArnMap = {
    [key: string]: string | undefined;
};
export interface RdsPromoteReadReplicaConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    dbInstanceArnMap: {
        [key: string]: string | undefined;
    };
}
export interface RdsCreateCrossRegionReplicaConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    dbInstanceArnMap: {
        [key: string]: string | undefined;
    };
}
export type EventSourceMappingAction = "enable" | "disable" | (string & {});
export type EventSourceMappingArn = string;
export interface EventSourceMapping {
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    arn: string;
}
export type RegionEventSourceMappingMap = {
    [key: string]: EventSourceMapping | undefined;
};
export type LambdaEventSourceMappingUngracefulBehavior = "skip" | (string & {});
export interface LambdaEventSourceMappingUngraceful {
    behavior?: LambdaEventSourceMappingUngracefulBehavior | undefined;
}
export interface LambdaEventSourceMappingConfiguration {
    timeoutMinutes?: number | undefined;
    action: EventSourceMappingAction;
    regionEventSourceMappings: {
        [key: string]: EventSourceMapping | undefined;
    };
    ungraceful?: LambdaEventSourceMappingUngraceful | undefined;
}
export type RegionAuroraClusterMap = {
    [key: string]: string | undefined;
};
export interface AuroraServerlessScalingConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    globalClusterIdentifier: string;
    regionDatabaseClusterArns: {
        [key: string]: string | undefined;
    };
    targetPercent?: number | undefined;
}
export type AuroraInstanceArn = string;
export type RegionAuroraInstanceArnMap = {
    [key: string]: string | undefined;
};
export interface AuroraProvisionedScalingConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    globalClusterIdentifier: string;
    regionDatabaseClusterArns: {
        [key: string]: string | undefined;
    };
    instanceArns: {
        [key: string]: string | undefined;
    };
}
export type NeptuneDefaultBehavior = "switchoverOnly" | "failover" | (string & {});
export type NeptuneUngracefulBehavior = "failover" | (string & {});
export interface NeptuneUngraceful {
    ungraceful?: NeptuneUngracefulBehavior | undefined;
}
export type NeptuneGlobalClusterIdentifier = string;
export type NeptuneClusterArn = string;
export type RegionNeptuneClusterArnMap = {
    [key: string]: string | undefined;
};
export interface NeptuneGlobalDatabaseConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    behavior: NeptuneDefaultBehavior;
    ungraceful?: NeptuneUngraceful | undefined;
    globalClusterIdentifier: string;
    regionDatabaseClusterArns: {
        [key: string]: string | undefined;
    };
}
export type RdsUngracefulBehavior = "promoteReadReplica" | (string & {});
export interface RdsUngraceful {
    ungraceful?: RdsUngracefulBehavior | undefined;
}
export interface RdsSwitchoverReadReplicaConfiguration {
    timeoutMinutes?: number | undefined;
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    dbInstanceArnMap: {
        [key: string]: string | undefined;
    };
    ungraceful?: RdsUngraceful | undefined;
}
export type SsmDocumentArn = string;
export type SsmTargetKey = string;
export type SsmTargetValue = string;
export type SsmTargetValueList = string[];
export interface SsmTarget {
    key: string;
    values: string[];
}
export type SsmTargetList = SsmTarget[];
export type SsmParameterKey = string;
export type SsmParameterValue = string;
export type SsmParameterValues = string[];
export type SsmDocumentParameters = {
    [key: string]: string[] | undefined;
};
export type SsmDocumentVersion = string;
export interface SsmDocumentConfig {
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    documentArn: string;
    targets: SsmTarget[];
    parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    documentVersion?: string | undefined;
}
export type RegionSsmDocumentMap = {
    [key: string]: SsmDocumentConfig | undefined;
};
export type SsmSendCommandUngracefulBehavior = "skip" | (string & {});
export interface SsmSendCommandUngraceful {
    behavior?: SsmSendCommandUngracefulBehavior | undefined;
}
export interface SsmSendCommandConfiguration {
    timeoutMinutes?: number | undefined;
    regionDocuments: {
        [key: string]: SsmDocumentConfig | undefined;
    };
    retryIntervalMinutes: number;
    ungraceful?: SsmSendCommandUngraceful | undefined;
}
export type ExecutionBlockConfiguration = {
    customActionLambdaConfig: CustomActionLambdaConfiguration;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig: Ec2AsgCapacityIncreaseConfiguration;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig: ExecutionApprovalConfiguration;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig: ArcRoutingControlConfiguration;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig: GlobalAuroraConfiguration;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig: ParallelExecutionBlockConfiguration;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig: RegionSwitchPlanConfiguration;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig: EcsCapacityIncreaseConfiguration;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig: EksResourceScalingConfiguration;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig: Route53HealthCheckConfiguration;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig: DocumentDbConfiguration;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig: RdsPromoteReadReplicaConfiguration;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig: RdsCreateCrossRegionReplicaConfiguration;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig: LambdaEventSourceMappingConfiguration;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig: AuroraServerlessScalingConfiguration;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig: AuroraProvisionedScalingConfiguration;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig: NeptuneGlobalDatabaseConfiguration;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig: RdsSwitchoverReadReplicaConfiguration;
    ssmSendCommandConfig?: undefined;
} | {
    customActionLambdaConfig?: undefined;
    ec2AsgCapacityIncreaseConfig?: undefined;
    executionApprovalConfig?: undefined;
    arcRoutingControlConfig?: undefined;
    globalAuroraConfig?: undefined;
    parallelConfig?: undefined;
    regionSwitchPlanConfig?: undefined;
    ecsCapacityIncreaseConfig?: undefined;
    eksResourceScalingConfig?: undefined;
    route53HealthCheckConfig?: undefined;
    documentDbConfig?: undefined;
    rdsPromoteReadReplicaConfig?: undefined;
    rdsCreateCrossRegionReadReplicaConfig?: undefined;
    lambdaEventSourceMappingConfig?: undefined;
    auroraServerlessScalingConfig?: undefined;
    auroraProvisionedScalingConfig?: undefined;
    neptuneGlobalDatabaseConfig?: undefined;
    rdsSwitchoverReadReplicaConfig?: undefined;
    ssmSendCommandConfig: SsmSendCommandConfiguration;
};
export type ExecutionBlockType = "CustomActionLambda" | "ManualApproval" | "AuroraGlobalDatabase" | "EC2AutoScaling" | "ARCRoutingControl" | "ARCRegionSwitchPlan" | "Parallel" | "ECSServiceScaling" | "EKSResourceScaling" | "Route53HealthCheck" | "DocumentDb" | "RdsPromoteReadReplica" | "RdsCreateCrossRegionReplica" | "LambdaEventSourceMapping" | "AuroraServerlessScaling" | "AuroraProvisionedScaling" | "NeptuneGlobalDatabase" | "RdsSwitchoverReadReplica" | "SSMSendCommand" | (string & {});
export interface Step {
    name: string;
    description?: string | undefined;
    executionBlockConfiguration: ExecutionBlockConfiguration;
    executionBlockType: ExecutionBlockType;
}
export type Steps = Step[];
export type WorkflowTargetAction = "activate" | "deactivate" | "postRecovery" | (string & {});
export interface Workflow {
    steps?: Step[] | undefined;
    workflowTargetAction: WorkflowTargetAction;
    workflowTargetRegion?: string | undefined;
    workflowDescription?: string | undefined;
}
export type WorkflowList = Workflow[];
export type AlarmType = "applicationHealth" | "trigger" | (string & {});
export interface AssociatedAlarm {
    crossAccountRole?: string | undefined;
    externalId?: string | undefined;
    resourceIdentifier: string;
    alarmType: AlarmType;
}
export type AssociatedAlarmMap = {
    [key: string]: AssociatedAlarm | undefined;
};
export type AlarmCondition = "red" | "green" | (string & {});
export interface TriggerCondition {
    associatedAlarmName: string;
    condition: AlarmCondition;
}
export type TriggerConditionList = TriggerCondition[];
export interface Trigger {
    description?: string | undefined;
    targetRegion: string;
    action: WorkflowTargetAction;
    conditions: TriggerCondition[];
    minDelayMinutesBetweenExecutions: number;
}
export type TriggerList = Trigger[];
export type AccountId = string;
export interface S3ReportOutputConfiguration {
    bucketPath?: string | undefined;
    bucketOwner?: string | undefined;
}
export type ReportOutputConfiguration = {
    s3Configuration: S3ReportOutputConfiguration;
};
export type ReportOutputList = ReportOutputConfiguration[];
export interface ReportConfiguration {
    reportOutput?: ReportOutputConfiguration[] | undefined;
}
export type PlanName = string;
export type RegionList = string[];
export type RecoveryApproach = "activeActive" | "activePassive" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreatePlanRequest {
    description?: string | undefined;
    workflows: Workflow[];
    executionRole: string;
    recoveryTimeObjectiveMinutes?: number | undefined;
    associatedAlarms?: {
        [key: string]: AssociatedAlarm | undefined;
    } | undefined;
    triggers?: Trigger[] | undefined;
    reportConfiguration?: ReportConfiguration | undefined;
    serviceQuotaChecksEnabled?: boolean | undefined;
    name: string;
    regions: string[];
    recoveryApproach: RecoveryApproach;
    primaryRegion?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Plan {
    arn: string;
    description?: string | undefined;
    workflows: Workflow[];
    executionRole: string;
    recoveryTimeObjectiveMinutes?: number | undefined;
    associatedAlarms?: {
        [key: string]: AssociatedAlarm | undefined;
    } | undefined;
    triggers?: Trigger[] | undefined;
    reportConfiguration?: ReportConfiguration | undefined;
    serviceQuotaChecksEnabled?: boolean | undefined;
    name: string;
    regions: string[];
    recoveryApproach: RecoveryApproach;
    primaryRegion?: string | undefined;
    owner: string;
    version?: string | undefined;
    updatedAt?: Date | undefined;
}
export interface CreatePlanResponse {
    plan?: Plan | undefined;
}
export interface DeletePlanRequest {
    arn: string;
}
export interface DeletePlanResponse {
}
export interface GetPlanRequest {
    arn: string;
}
export interface GetPlanResponse {
    plan?: Plan | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface GetPlanEvaluationStatusRequest {
    planArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type EvaluationStatus = "passed" | "actionRequired" | "pendingEvaluation" | "unknown" | (string & {});
export type ExecutionAction = "activate" | "deactivate" | "postRecovery" | (string & {});
export interface MinimalWorkflow {
    action?: ExecutionAction | undefined;
    name?: string | undefined;
}
export type ResourceArn = string;
export type ResourceWarningStatus = "active" | "resolved" | (string & {});
export interface ResourceWarning {
    workflow?: MinimalWorkflow | undefined;
    version: string;
    stepName?: string | undefined;
    resourceArn?: string | undefined;
    warningStatus: ResourceWarningStatus;
    warningUpdatedTime: Date;
    warningMessage: string;
}
export type PlanWarnings = ResourceWarning[];
export interface GetPlanEvaluationStatusResponse {
    planArn: string;
    lastEvaluationTime?: Date | undefined;
    lastEvaluatedVersion?: string | undefined;
    region?: string | undefined;
    evaluationState?: EvaluationStatus | undefined;
    warnings?: ResourceWarning[] | undefined;
    nextToken?: string | undefined;
}
export type GetPlanExecutionStepStatesMaxResults = number;
export interface GetPlanExecutionRequest {
    planArn: string;
    executionId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ExecutionMode = "graceful" | "ungraceful" | (string & {});
export type ExecutionState = "inProgress" | "pausedByFailedStep" | "pausedByOperator" | "completed" | "completedWithExceptions" | "canceled" | "planExecutionTimedOut" | "pendingManualApproval" | "failed" | "pending" | "completedMonitoringApplicationHealth" | (string & {});
export type StepStatus = "notStarted" | "running" | "failed" | "completed" | "canceled" | "skipped" | "pendingApproval" | (string & {});
export interface StepState {
    name?: string | undefined;
    status?: StepStatus | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    stepMode?: ExecutionMode | undefined;
}
export type StepStates = StepState[];
export type Duration = string;
export interface S3ReportOutput {
    s3ObjectKey?: string | undefined;
}
export type FailedReportErrorCode = "insufficientPermissions" | "invalidResource" | "configurationError" | (string & {});
export interface FailedReportOutput {
    errorCode?: FailedReportErrorCode | undefined;
    errorMessage?: string | undefined;
}
export type ReportOutput = {
    s3ReportOutput: S3ReportOutput;
    failedReportOutput?: undefined;
} | {
    s3ReportOutput?: undefined;
    failedReportOutput: FailedReportOutput;
};
export interface GeneratedReport {
    reportGenerationTime?: Date | undefined;
    reportOutput?: ReportOutput | undefined;
}
export type GeneratedReportDetails = GeneratedReport[];
export interface GetPlanExecutionResponse {
    planArn: string;
    executionId: string;
    version?: string | undefined;
    updatedAt?: Date | undefined;
    comment?: string | undefined;
    startTime: Date;
    endTime?: Date | undefined;
    mode: ExecutionMode;
    executionState: ExecutionState;
    executionAction: ExecutionAction;
    executionRegion: string;
    recoveryExecutionId?: string | undefined;
    stepStates?: StepState[] | undefined;
    plan?: Plan | undefined;
    actualRecoveryTime?: string | undefined;
    generatedReportDetails?: GeneratedReport[] | undefined;
    nextToken?: string | undefined;
}
export interface GetPlanInRegionRequest {
    arn: string;
}
export interface GetPlanInRegionResponse {
    plan?: Plan | undefined;
}
export type ListExecutionEventsMaxResults = number;
export interface ListPlanExecutionEventsRequest {
    planArn: string;
    executionId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    name?: string | undefined;
}
export type ExecutionEventType = "unknown" | "executionPending" | "executionStarted" | "executionSucceeded" | "executionFailed" | "executionPausing" | "executionPaused" | "executionCanceling" | "executionCanceled" | "executionPendingApproval" | "executionBehaviorChangedToUngraceful" | "executionBehaviorChangedToGraceful" | "executionPendingChildPlanManualApproval" | "executionSuccessMonitoringApplicationHealth" | "stepStarted" | "stepUpdate" | "stepSucceeded" | "stepFailed" | "stepSkipped" | "stepPausedByError" | "stepPausedByOperator" | "stepCanceled" | "stepPendingApproval" | "stepExecutionBehaviorChangedToUngraceful" | "stepPendingApplicationHealthMonitor" | "planEvaluationWarning" | (string & {});
export type Resources = string[];
export interface ExecutionEvent {
    timestamp?: Date | undefined;
    type?: ExecutionEventType | undefined;
    stepName?: string | undefined;
    executionBlockType?: ExecutionBlockType | undefined;
    resources?: string[] | undefined;
    error?: string | undefined;
    description?: string | undefined;
    eventId: string;
    previousEventId?: string | undefined;
}
export type ExecutionEventList = ExecutionEvent[];
export interface ListPlanExecutionEventsResponse {
    items?: ExecutionEvent[] | undefined;
    nextToken?: string | undefined;
}
export type ListExecutionsMaxResults = number;
export interface ListPlanExecutionsRequest {
    planArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    state?: ExecutionState | undefined;
}
export interface AbbreviatedExecution {
    planArn: string;
    executionId: string;
    version?: string | undefined;
    updatedAt?: Date | undefined;
    comment?: string | undefined;
    startTime: Date;
    endTime?: Date | undefined;
    mode: ExecutionMode;
    executionState: ExecutionState;
    executionAction: ExecutionAction;
    executionRegion: string;
    recoveryExecutionId?: string | undefined;
    actualRecoveryTime?: string | undefined;
}
export type AbbreviatedExecutionsList = AbbreviatedExecution[];
export interface ListPlanExecutionsResponse {
    items?: AbbreviatedExecution[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPlansRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AbbreviatedPlan {
    arn: string;
    owner: string;
    name: string;
    regions: string[];
    recoveryApproach: RecoveryApproach;
    primaryRegion?: string | undefined;
    version?: string | undefined;
    updatedAt?: Date | undefined;
    description?: string | undefined;
    executionRole?: string | undefined;
    activePlanExecution?: string | undefined;
    recoveryTimeObjectiveMinutes?: number | undefined;
}
export type PlanList = AbbreviatedPlan[];
export interface ListPlansResponse {
    plans?: AbbreviatedPlan[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPlansInRegionRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListPlansInRegionResponse {
    plans?: AbbreviatedPlan[] | undefined;
    nextToken?: string | undefined;
}
export interface ListRoute53HealthChecksRequest {
    arn: string;
    hostedZoneId?: string | undefined;
    recordName?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type Route53HealthCheckId = string;
export type Route53HealthCheckStatus = "healthy" | "unhealthy" | "unknown" | (string & {});
export interface Route53HealthCheck {
    hostedZoneId: string;
    recordName: string;
    healthCheckId?: string | undefined;
    status?: Route53HealthCheckStatus | undefined;
    region: string;
}
export type Route53HealthCheckList = Route53HealthCheck[];
export interface ListRoute53HealthChecksResponse {
    healthChecks?: Route53HealthCheck[] | undefined;
    nextToken?: string | undefined;
}
export interface ListRoute53HealthChecksInRegionRequest {
    arn: string;
    hostedZoneId?: string | undefined;
    recordName?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListRoute53HealthChecksInRegionResponse {
    healthChecks?: Route53HealthCheck[] | undefined;
    nextToken?: string | undefined;
}
export type PlanArnList = string[];
export interface ListServiceQuotaWarningsRequest {
    planArns?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ServiceQuotaWarningStatus = "pending" | "denied" | "insufficientPermissions" | "maxRegionSwitchRequestsExceeded" | "maxAccountRequestsExceeded" | (string & {});
export interface ServiceQuotaWarningSummary {
    accountId: string;
    quotaRegion: string;
    serviceCode?: string | undefined;
    quotaCode?: string | undefined;
    quotaName?: string | undefined;
    status: ServiceQuotaWarningStatus;
    planArn: string;
    requestId?: string | undefined;
    caseId?: string | undefined;
    warningMessage?: string | undefined;
    lastCheckedAt?: Date | undefined;
    warningCreatedAt?: Date | undefined;
}
export type ServiceQuotaWarningSummaryList = ServiceQuotaWarningSummary[];
export interface ListServiceQuotaWarningsResponse {
    serviceQuotaWarningSummaries: ServiceQuotaWarningSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    arn: string;
}
export interface ListTagsForResourceResponse {
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RecoveryExecutionId = string;
export interface StartPlanExecutionRequest {
    planArn: string;
    targetRegion: string;
    action: ExecutionAction;
    mode?: ExecutionMode | undefined;
    comment?: string | undefined;
    latestVersion?: string | undefined;
    recoveryExecutionId?: string | undefined;
    clientToken?: string | undefined;
}
export interface StartPlanExecutionResponse {
    executionId?: string | undefined;
    plan?: string | undefined;
    planVersion?: string | undefined;
    activateRegion?: string | undefined;
    deactivateRegion?: string | undefined;
}
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    arn: string;
    resourceTagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdatePlanRequest {
    arn: string;
    description?: string | undefined;
    workflows: Workflow[];
    executionRole: string;
    recoveryTimeObjectiveMinutes?: number | undefined;
    associatedAlarms?: {
        [key: string]: AssociatedAlarm | undefined;
    } | undefined;
    triggers?: Trigger[] | undefined;
    reportConfiguration?: ReportConfiguration | undefined;
    serviceQuotaChecksEnabled?: boolean | undefined;
}
export interface UpdatePlanResponse {
    plan?: Plan | undefined;
}
export type UpdatePlanExecutionAction = "switchToGraceful" | "switchToUngraceful" | "pause" | "resume" | (string & {});
export interface UpdatePlanExecutionRequest {
    planArn: string;
    executionId: string;
    action: UpdatePlanExecutionAction;
    comment?: string | undefined;
}
export interface UpdatePlanExecutionResponse {
}
export type UpdatePlanExecutionStepAction = "switchToUngraceful" | "skip" | (string & {});
export interface UpdatePlanExecutionStepRequest {
    planArn: string;
    executionId: string;
    comment: string;
    stepName: string;
    actionToTake: UpdatePlanExecutionStepAction;
}
export interface UpdatePlanExecutionStepResponse {
}
export type ApprovePlanExecutionStepError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Approves a step in a plan execution that requires manual approval. When you create a plan, you can include approval steps that require manual intervention before the execution can proceed. This operation allows you to provide that approval.
 *
 * You must specify the plan ARN, execution ID, step name, and approval status. You can also provide an optional comment explaining the approval decision.
 */
export declare const approvePlanExecutionStep: API.OperationMethod<ApprovePlanExecutionStepRequest & RegionInput, ApprovePlanExecutionStepResponse, ApprovePlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export type CancelPlanExecutionError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels an in-progress plan execution. This operation stops the execution of the plan and prevents any further steps from being processed.
 *
 * You must specify the plan ARN and execution ID. You can also provide an optional comment explaining why the execution was canceled.
 */
export declare const cancelPlanExecution: API.OperationMethod<CancelPlanExecutionRequest & RegionInput, CancelPlanExecutionResponse, CancelPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type CreatePlanError = CommonErrors;
/**
 * Creates a new Region switch plan. A plan defines the steps required to shift traffic from one Amazon Web Services Region to another.
 *
 * You must specify a name for the plan, the primary Region, and at least one additional Region. You can also provide a description, execution role, recovery time objective, associated alarms, triggers, and workflows that define the steps to execute during a Region switch.
 */
export declare const createPlan: API.OperationMethod<CreatePlanRequest & RegionInput, CreatePlanResponse, CreatePlanError, Credentials | HttpClient.HttpClient>;
export type DeletePlanError = IllegalStateException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Region switch plan. You must specify the ARN of the plan to delete.
 *
 * You cannot delete a plan that has an active execution in progress.
 */
export declare const deletePlan: API.OperationMethod<DeletePlanRequest & RegionInput, DeletePlanResponse, DeletePlanError, Credentials | HttpClient.HttpClient>;
export type GetPlanError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves detailed information about a Region switch plan. You must specify the ARN of the plan.
 */
export declare const getPlan: API.OperationMethod<GetPlanRequest & RegionInput, GetPlanResponse, GetPlanError, Credentials | HttpClient.HttpClient>;
export type GetPlanEvaluationStatusError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the evaluation status of a Region switch plan. The evaluation status provides information about the last time the plan was evaluated and any warnings or issues detected.
 */
export declare const getPlanEvaluationStatus: API.PaginatedOperationMethod<GetPlanEvaluationStatusRequest & RegionInput, GetPlanEvaluationStatusResponse, GetPlanEvaluationStatusError, Credentials | HttpClient.HttpClient, ResourceWarning>;
export type GetPlanExecutionError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves detailed information about a specific plan execution. You must specify the plan ARN and execution ID.
 */
export declare const getPlanExecution: API.PaginatedOperationMethod<GetPlanExecutionRequest & RegionInput, GetPlanExecutionResponse, GetPlanExecutionError, Credentials | HttpClient.HttpClient, StepState>;
export type GetPlanInRegionError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a Region switch plan in a specific Amazon Web Services Region. This operation is useful for getting Region-specific information about a plan.
 */
export declare const getPlanInRegion: API.OperationMethod<GetPlanInRegionRequest & RegionInput, GetPlanInRegionResponse, GetPlanInRegionError, Credentials | HttpClient.HttpClient>;
export type ListPlanExecutionEventsError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the events that occurred during a plan execution. These events provide a detailed timeline of the execution process.
 */
export declare const listPlanExecutionEvents: API.PaginatedOperationMethod<ListPlanExecutionEventsRequest & RegionInput, ListPlanExecutionEventsResponse, ListPlanExecutionEventsError, Credentials | HttpClient.HttpClient, ExecutionEvent>;
export type ListPlanExecutionsError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the executions of a Region switch plan. This operation returns information about both current and historical executions.
 */
export declare const listPlanExecutions: API.PaginatedOperationMethod<ListPlanExecutionsRequest & RegionInput, ListPlanExecutionsResponse, ListPlanExecutionsError, Credentials | HttpClient.HttpClient, AbbreviatedExecution>;
export type ListPlansError = CommonErrors;
/**
 * Lists all Region switch plans in your Amazon Web Services account.
 */
export declare const listPlans: API.PaginatedOperationMethod<ListPlansRequest & RegionInput, ListPlansResponse, ListPlansError, Credentials | HttpClient.HttpClient, AbbreviatedPlan>;
export type ListPlansInRegionError = AccessDeniedException | CommonErrors;
/**
 * Lists all Region switch plans in your Amazon Web Services account that are available in the current Amazon Web Services Region.
 */
export declare const listPlansInRegion: API.PaginatedOperationMethod<ListPlansInRegionRequest & RegionInput, ListPlansInRegionResponse, ListPlansInRegionError, Credentials | HttpClient.HttpClient, AbbreviatedPlan>;
export type ListRoute53HealthChecksError = AccessDeniedException | IllegalArgumentException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * List the Amazon Route 53 health checks.
 */
export declare const listRoute53HealthChecks: API.PaginatedOperationMethod<ListRoute53HealthChecksRequest & RegionInput, ListRoute53HealthChecksResponse, ListRoute53HealthChecksError, Credentials | HttpClient.HttpClient, Route53HealthCheck>;
export type ListRoute53HealthChecksInRegionError = AccessDeniedException | IllegalArgumentException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * List the Amazon Route 53 health checks in a specific Amazon Web Services Region.
 */
export declare const listRoute53HealthChecksInRegion: API.PaginatedOperationMethod<ListRoute53HealthChecksInRegionRequest & RegionInput, ListRoute53HealthChecksInRegionResponse, ListRoute53HealthChecksInRegionError, Credentials | HttpClient.HttpClient, Route53HealthCheck>;
export type ListServiceQuotaWarningsError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Lists the service quota warnings for the plans that you can access. Region switch creates a warning when the applied quota value in one Region of a plan is lower than the value required for the matching resource in another Region or account in the plan.
 *
 * Returns the warnings for the plans that you own and for plans that are shared with your account through Resource Access Manager (RAM). To return warnings for specific plans, provide a list of plan Amazon Resource Names (ARNs). Region switch ignores any plan ARN that you can't access. If you don't provide any plan ARNs, Region switch returns the warnings for all of your accessible plans.
 */
export declare const listServiceQuotaWarnings: API.PaginatedOperationMethod<ListServiceQuotaWarningsRequest & RegionInput, ListServiceQuotaWarningsResponse, ListServiceQuotaWarningsError, Credentials | HttpClient.HttpClient, ServiceQuotaWarningSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags attached to a Region switch resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartPlanExecutionError = AccessDeniedException | ConflictException | IllegalArgumentException | IllegalStateException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the execution of a Region switch plan. You can execute a plan in either `graceful` or `ungraceful` mode.
 *
 * Specifing `ungraceful` mode either changes the behavior of the execution blocks in a workflow or skips specific execution blocks.
 */
export declare const startPlanExecution: API.OperationMethod<StartPlanExecutionRequest & RegionInput, StartPlanExecutionResponse, StartPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Adds or updates tags for a Region switch resource. You can assign metadata to your resources in the form of tags, which are key-value pairs.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from a Region switch resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePlanError = ResourceNotFoundException | RetryableConflictException | CommonErrors;
/**
 * Updates an existing Region switch plan. You can modify the plan's description, workflows, execution role, recovery time objective, associated alarms, and triggers.
 */
export declare const updatePlan: API.OperationMethod<UpdatePlanRequest & RegionInput, UpdatePlanResponse, UpdatePlanError, Credentials | HttpClient.HttpClient>;
export type UpdatePlanExecutionError = AccessDeniedException | IllegalStateException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an in-progress plan execution. This operation allows you to modify certain aspects of the execution, such as adding a comment or changing the action.
 */
export declare const updatePlanExecution: API.OperationMethod<UpdatePlanExecutionRequest & RegionInput, UpdatePlanExecutionResponse, UpdatePlanExecutionError, Credentials | HttpClient.HttpClient>;
export type UpdatePlanExecutionStepError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a specific step in an in-progress plan execution. This operation allows you to modify the step's comment or action.
 */
export declare const updatePlanExecutionStep: API.OperationMethod<UpdatePlanExecutionStepRequest & RegionInput, UpdatePlanExecutionStepResponse, UpdatePlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=arc-region-switch.d.ts.map