import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface DeleteAgentMergeEnrollmentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
}
export interface DeleteAgentMergeEnrollmentResponse {
}
export interface GetAgentMergeEnrollmentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
}
/** An action that Agent Merge is explicitly allowed to perform. */
export type GetAgentMergeEnrollmentResponseAllowedActionsItem = "fix_ci" | "resolve_merge_conflicts";
/** The set of actions which Copilot may perform on the pull request. */
export type GetAgentMergeEnrollmentResponseAllowedActionsList = Array<GetAgentMergeEnrollmentResponseAllowedActionsItem>;
/** The user who most recently enabled Agent Merge for the pull request */
export interface GetAgentMergeEnrollmentResponseUser {
    /** The unique identifier of the user */
    id: number;
}
export interface GetAgentMergeEnrollmentResponse {
    /** The set of actions which Copilot may perform on the pull request. */
    allowed_actions: GetAgentMergeEnrollmentResponseAllowedActionsList;
    /** Timestamp when the pull request was enrolled for Agent Merge. */
    created_at: string;
    /** Timestamp when the Agent Merge enrollment was last updated. */
    updated_at: string;
    /** The user who most recently enabled Agent Merge for the pull request */
    user: GetAgentMergeEnrollmentResponseUser;
}
/** An action that Agent Merge is explicitly allowed to perform. */
export type PutAgentMergeEnrollmentRequestAllowedActionsItem = "fix_ci" | "resolve_merge_conflicts";
/** The set of actions that Copilot may perform on the pull request. */
export type PutAgentMergeEnrollmentRequestAllowedActionsList = Array<PutAgentMergeEnrollmentRequestAllowedActionsItem | (string & {})>;
export interface PutAgentMergeEnrollmentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the pull request. */
    pull_number: number;
    /** The set of actions that Copilot may perform on the pull request. */
    allowed_actions: PutAgentMergeEnrollmentRequestAllowedActionsList;
}
/** An action that Agent Merge is explicitly allowed to perform. */
export type PutAgentMergeEnrollmentResponseAllowedActionsItem = "fix_ci" | "resolve_merge_conflicts";
/** The set of actions which Copilot may perform on the pull request. */
export type PutAgentMergeEnrollmentResponseAllowedActionsList = Array<PutAgentMergeEnrollmentResponseAllowedActionsItem>;
/** The user who most recently enabled Agent Merge for the pull request */
export type PutAgentMergeEnrollmentResponseUser = GetAgentMergeEnrollmentResponseUser;
export interface PutAgentMergeEnrollmentResponse {
    /** The set of actions which Copilot may perform on the pull request. */
    allowed_actions: PutAgentMergeEnrollmentResponseAllowedActionsList;
    /** Timestamp when the pull request was enrolled for Agent Merge. */
    created_at: string;
    /** Timestamp when the Agent Merge enrollment was last updated. */
    updated_at: string;
    /** The user who most recently enabled Agent Merge for the pull request */
    user: GetAgentMergeEnrollmentResponseUser;
}
export type DeleteAgentMergeEnrollmentError = GithubOpError;
/** Disable Agent Merge for a pull request Disables Agent Merge for a pull request. You must have write access to the repository. Disabling does not require enrollment eligibility: your Copilot subscription, coding-agent and Automations policies, the Agent Merge execution flag, pull request state, stack membership, and repository archive state do not prevent cleanup. Authentication, token repository selection, and "Agent tasks" write permission remain required. OAuth app tokens and personal access tokens (classic) need the repo scope for private or internal repositories, or the public_repo scope for public repositories. */
export declare const deleteAgentMergeEnrollment: API.OperationMethod<DeleteAgentMergeEnrollmentRequest, DeleteAgentMergeEnrollmentResponse, DeleteAgentMergeEnrollmentError, GithubOpContext>;
export type GetAgentMergeEnrollmentError = GithubOpError;
/** Get Agent Merge configuration for a pull request Gets the Agent Merge configuration for a pull request. You must have write access to the repository. OAuth app tokens and personal access tokens (classic) need the repo scope for private or internal repositories, or the public_repo scope for public repositories. */
export declare const getAgentMergeEnrollment: API.OperationMethod<GetAgentMergeEnrollmentRequest, GetAgentMergeEnrollmentResponse, GetAgentMergeEnrollmentError, GithubOpContext>;
export type PutAgentMergeEnrollmentError = GithubOpError;
/** Update Agent Merge configuration for a pull request Updates the Agent Merge configuration for a pull request, enabling Agent Merge or changing the allowed actions that Copilot is allowed to take on the pull request. If Agent Merge is currently enabled for the pull request, only the user who most recently enabled it may change its allowed actions. If enrollment eligibility cannot be determined, the operation returns `503`. This endpoint is only available to users with a Copilot subscription, excluding Copilot Free users. You must have write access to the repository, the pull request must not be from a fork or part of a stack, and the repository must have the "Allow automations" setting enabled. OAuth app tokens and personal access tokens (classic) need the repo scope for private or internal repositories, or the public_repo scope for public repositories. */
export declare const putAgentMergeEnrollment: API.OperationMethod<PutAgentMergeEnrollmentRequest, PutAgentMergeEnrollmentResponse, PutAgentMergeEnrollmentError, GithubOpContext>;
//# sourceMappingURL=agent_merge.d.ts.map