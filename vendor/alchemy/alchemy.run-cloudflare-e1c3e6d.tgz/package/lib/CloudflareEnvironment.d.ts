import * as Layer from "effect/Layer";
import { CloudflareEnvironment } from "./CloudflareEnvironmentService.ts";
export { CloudflareEnvironment } from "./CloudflareEnvironmentService.ts";
export declare const fromProfile: () => Layer.Layer<CloudflareEnvironment, never, import("alchemy").AuthProviders | import("alchemy/Auth/Profile").ProfileStore>;
//# sourceMappingURL=CloudflareEnvironment.d.ts.map