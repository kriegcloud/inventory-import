import * as Effect from "effect/Effect";
import type * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type * as Aggregate from "./Aggregate.ts";
import type * as Api from "./Api.ts";
import * as ModelSearch from "./Explore/internal/ModelSearch.ts";
import type { Found } from "./Explore/internal/Search.ts";
import type * as Model from "./Model.ts";
export type { Move, Outcome, Story } from "./Explore/internal/Search.ts";
export type { Asked, Ending, Skipped, Step } from "./Explore/internal/ModelSearch.ts";
export interface Options {
    /** The file the aggregate is declared in: `new URL("../src/Account.ts", import.meta.url)`, or a path. */
    readonly source: URL | string;
    /**
     * The most commands in a sequence.
     * @default 3
     */
    readonly depth?: number;
    /**
     * The most sequences to run before stopping.
     * @default 100000
     */
    readonly budget?: number;
    /** What `check` passes with, though it leaves part of the search undone. */
    readonly allow?: {
        /** Pass when the search stops at its budget before every sequence is run. */
        readonly truncated?: boolean;
    };
}
export interface ModelOptions {
    /** The file the model is declared in: `new URL("../src/Bank.model.ts", import.meta.url)`, or a path. */
    readonly source: URL | string;
    /** The Apis callers reach the model through: their commands are the ones a sequence is made of. */
    readonly apis: ReadonlyArray<Api.Any>;
    /**
     * The most commands callers send in a sequence. What the policies send in
     * reaction does not count.
     * @default 2
     */
    readonly depth?: number;
    /**
     * The most sequences to run before stopping.
     * @default 100000
     */
    readonly budget?: number;
    /**
     * The most instances of one aggregate callers address in a sequence.
     * @default 2
     */
    readonly instances?: number;
    /**
     * The ways delivery goes wrong that every sequence is run with. The kernel
     * delivers an event to a policy at least once and runs the reactions that
     * wait at the same time in no set order, so both are on unless turned off.
     */
    readonly faults?: {
        /**
         * Deliver each event to each policy twice. The commands a policy sends
         * get ids from the event, so an instance that took one does nothing the
         * second time: what changes is what an external system answers.
         * @default true
         */
        readonly redeliver?: boolean;
        /**
         * Run the reactions that wait at the same time in other orders too: after
         * each command, each reaction that shares an aggregate with another is
         * also tried behind the others.
         * @default true
         */
        readonly reorder?: boolean;
        /**
         * Run a saga's step again, as when the saga stops after the step ran and
         * before what it gave was kept. The commands a step sends get ids from
         * the step, so an instance that took one does nothing the second time.
         * @default true
         */
        readonly rerun?: boolean;
    };
    /**
     * Longer sequences to run after every short one: each a walk of commands
     * picked at random, one after another. A rule that takes more commands to
     * break than `depth` is out of reach of the search, and within reach of a
     * walk. The same `seed` picks the same walks.
     * @default none
     */
    readonly walks?: {
        /** How many walks to run. */
        readonly count: number;
        /**
         * The most commands callers send in one.
         * @default 12
         */
        readonly length?: number;
        /** @default 1 */
        readonly seed?: number;
    };
    /** What `check` passes with, though it leaves part of the search undone. */
    readonly allow?: {
        /** Pass when the search stops at its budget before every sequence is run. */
        readonly truncated?: boolean;
        /** The policies and sagas the explorer may leave out, by name. */
        readonly skipped?: ReadonlyArray<string>;
    };
}
declare const ExploreError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ExploreError";
} & Readonly<A>;
/** The explorer could not start: a file did not load, or the solver is missing. */
export declare class ExploreError extends ExploreError_base<{
    readonly message: string;
}> {
}
declare const InvariantBroken_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvariantBroken";
} & Readonly<A>;
/** A sequence of commands breaks an invariant. The message is the report. */
export declare class InvariantBroken extends InvariantBroken_base<{
    readonly message: string;
    readonly report: Report | ModelReport;
}> {
}
declare const Incomplete_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Incomplete";
} & Readonly<A>;
/**
 * No invariant was seen to break, but part of the search was not done, so the
 * search does not say that none does. `reasons` names each part.
 */
export declare class Incomplete extends Incomplete_base<{
    readonly message: string;
    readonly reasons: ReadonlyArray<string>;
    readonly report: Report | ModelReport;
}> {
}
export interface Report extends Found {
    readonly aggregate: string;
    readonly depth: number;
}
export interface ModelReport extends ModelSearch.Found {
    readonly model: string;
    readonly apis: ReadonlyArray<string>;
    readonly depth: number;
}
type Requirements = FileSystem.FileSystem | Path.Path;
/**
 * Run every sequence of up to `depth` commands on a new instance, and say
 * what was reached.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Explore.report(Account, {
 *   source: new URL("../src/Account/Account.aggregate.ts", import.meta.url),
 * });
 * console.log(Explore.render(report));
 * ```
 */
export declare function report(aggregate: Aggregate.Any, options: Options): Effect.Effect<Report, ExploreError, Requirements>;
/**
 * Run every sequence of up to `depth` commands callers can send through the
 * Apis, on a model with nothing in it. After each command the policies react,
 * and the commands they send run before the next one.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Explore.report(Bank, {
 *   source: new URL("../src/Bank.model.ts", import.meta.url),
 *   apis: [CustomerApi, SupportApi],
 * });
 * console.log(Explore.render(report));
 * ```
 */
export declare function report(model: Model.Any, options: ModelOptions): Effect.Effect<ModelReport, ExploreError, Requirements>;
/**
 * Explore an aggregate, and fail with the report when a sequence of commands
 * breaks an invariant.
 *
 * It also fails, with `Incomplete`, when part of the search was not done:
 * code it could not read, a search that stopped at its budget, a command no
 * state accepts, no state reached at all.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("no three commands break an account", () =>
 *   Explore.check(Account, {
 *     source: new URL("../src/Account/Account.aggregate.ts", import.meta.url),
 *   }).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare function check(aggregate: Aggregate.Any, options: Options): Effect.Effect<Report, ExploreError | InvariantBroken | Incomplete, Requirements>;
/**
 * Explore a model, and fail with the report when a sequence of commands
 * breaks an invariant of one of its aggregates or of the model.
 *
 * It also fails, with `Incomplete`, when part of the search was not done:
 * code it could not read, a policy it left out, a search that stopped at its
 * budget, an invariant no sequence reached. `allow` names the parts a pass
 * may leave undone.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("no two commands break the bank", () =>
 *   Explore.check(Bank, {
 *     source: new URL("../src/Bank.model.ts", import.meta.url),
 *     apis: [CustomerApi, SupportApi],
 *   }).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare function check(model: Model.Any, options: ModelOptions): Effect.Effect<ModelReport, ExploreError | InvariantBroken | Incomplete, Requirements>;
/** Each part of a search that was not done, so that a pass would say less than it seems to. */
export declare const undone: (report: Report | ModelReport, allow: NonNullable<ModelOptions["allow"]>) => ReadonlyArray<string>;
/**
 * A story of a model's report as text, one command a line: each command a
 * caller sends or a schedule that comes due, then what the policies and sagas
 * asked and sent because of it.
 */
export declare const describe: (story: ModelSearch.Story, indent?: string) => string;
/**
 * A story of a model's report as the steps of a `Story`, to paste into a
 * test: the sequence the explorer found then runs on the whole model in
 * memory, with its policies, sagas and views, and stays as a regression test.
 *
 * **Example:** The sequence that breaks a rule, as a test
 * ```typescript
 * const report = yield* Explore.report(Bank, { apis: [CustomerApi] });
 * const broken = report.rules.find((rule) => rule.broken)?.broken;
 * if (broken) console.log(Explore.script(broken));
 * ```
 */
export declare const script: (story: ModelSearch.Story) => string;
/** A report as text: the invariants, then every outcome with its shortest story. */
export declare const render: (report: Report | ModelReport) => string;
//# sourceMappingURL=Explore.d.ts.map