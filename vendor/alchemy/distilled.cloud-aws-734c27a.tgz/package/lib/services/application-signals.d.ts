import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly ResourceType: any;
    readonly ResourceId: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type InstrumentationType = "BREAKPOINT" | "PROBE" | (string & {});
export interface BatchDeleteScope {
    Service: string;
    Environment: string;
    InstrumentationType: InstrumentationType;
}
export type BatchDeleteResourceArnList = string[];
export interface BatchDeleteByResourceArns {
    ResourceArns: string[];
    InstrumentationType: InstrumentationType;
}
export type BatchDeleteDeletionTarget = {
    Scope: BatchDeleteScope;
    ResourceArns?: undefined;
} | {
    Scope?: undefined;
    ResourceArns: BatchDeleteByResourceArns;
};
export interface BatchDeleteInstrumentationConfigurationsRequest {
    DeletionTarget: BatchDeleteDeletionTarget;
}
export interface BatchDeleteSuccessfulDeletion {
    ResourceArn?: string | undefined;
    SignalType?: string | undefined;
    LocationHash?: string | undefined;
}
export type BatchDeleteSuccessfulDeletionList = BatchDeleteSuccessfulDeletion[];
export type BatchDeleteErrorCode = "ResourceNotFoundException" | "AccessDeniedException" | "InternalServiceException" | (string & {});
export interface BatchDeleteError {
    ResourceArn: string;
    Code: BatchDeleteErrorCode;
    Message: string;
}
export type BatchDeleteErrorList = BatchDeleteError[];
export interface BatchDeleteInstrumentationConfigurationsResponse {
    DeletedCount: number;
    SuccessfulDeletions: BatchDeleteSuccessfulDeletion[];
    Errors: BatchDeleteError[];
}
export type ServiceLevelObjectiveIds = string[];
export interface BatchGetServiceLevelObjectiveBudgetReportInput {
    Timestamp: Date;
    SloIds: string[];
}
export type ServiceLevelObjectiveArn = string;
export type ServiceLevelObjectiveName = string;
export type EvaluationType = "PeriodBased" | "RequestBased" | (string & {});
export type ServiceLevelObjectiveBudgetStatus = "OK" | "WARNING" | "BREACHED" | "INSUFFICIENT_DATA" | (string & {});
export type Attainment = number;
export type TotalBudgetSeconds = number;
export type BudgetSecondsRemaining = number;
export type TotalBudgetRequests = number;
export type BudgetRequestsRemaining = number;
export type KeyAttributeName = string;
export type KeyAttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export type OperationName = string;
export type ServiceLevelIndicatorMetricType = "LATENCY" | "AVAILABILITY" | (string & {});
export type MetricId = string;
export type Namespace = string;
export type MetricName = string;
export type DimensionName = string;
export type DimensionValue = string;
export interface Dimension {
    Name: string;
    Value: string;
}
export type Dimensions = Dimension[];
export interface Metric {
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
}
export type Period = number;
export type Stat = string;
export type StandardUnit = "Microseconds" | "Milliseconds" | "Seconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Count" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | "None" | (string & {});
export interface MetricStat {
    Metric: Metric;
    Period: number;
    Stat: string;
    Unit?: StandardUnit | undefined;
}
export type MetricExpression = string;
export type MetricLabel = string;
export type ReturnData = boolean;
export type AccountId = string;
export interface MetricDataQuery {
    Id: string;
    MetricStat?: MetricStat | undefined;
    Expression?: string | undefined;
    Label?: string | undefined;
    ReturnData?: boolean | undefined;
    Period?: number | undefined;
    AccountId?: string | undefined;
}
export type MetricDataQueries = MetricDataQuery[];
export interface DependencyConfig {
    DependencyKeyAttributes: {
        [key: string]: string | undefined;
    };
    DependencyOperationName: string;
}
export interface MetricSource {
    MetricSourceKeyAttributes: {
        [key: string]: string | undefined;
    };
    MetricSourceAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SelectionType = "EXPLICIT" | "PREFIX" | "REGEX" | (string & {});
export type SelectionPattern = string;
export interface SelectionConfig {
    Type: SelectionType;
    Pattern?: string | undefined;
}
export type CompositeSliComponent = {
    OperationName: string;
};
export type CompositeSliComponents = CompositeSliComponent[];
export interface CompositeSliConfig {
    SelectionConfig: SelectionConfig;
    Components?: CompositeSliComponent[] | undefined;
}
export interface ServiceLevelIndicatorMetric {
    KeyAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    OperationName?: string | undefined;
    MetricType?: ServiceLevelIndicatorMetricType | undefined;
    MetricDataQueries: MetricDataQuery[];
    DependencyConfig?: DependencyConfig | undefined;
    MetricSource?: MetricSource | undefined;
    CompositeSliConfig?: CompositeSliConfig | undefined;
}
export type ServiceLevelIndicatorMetricThreshold = number;
export type ServiceLevelIndicatorComparisonOperator = "GreaterThanOrEqualTo" | "GreaterThan" | "LessThan" | "LessThanOrEqualTo" | (string & {});
export interface ServiceLevelIndicator {
    SliMetric: ServiceLevelIndicatorMetric;
    MetricThreshold: number;
    ComparisonOperator: ServiceLevelIndicatorComparisonOperator;
}
export type MonitoredRequestCountMetricDataQueries = {
    GoodCountMetric: MetricDataQuery[];
    BadCountMetric?: undefined;
} | {
    GoodCountMetric?: undefined;
    BadCountMetric: MetricDataQuery[];
};
export interface RequestBasedServiceLevelIndicatorMetric {
    KeyAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    OperationName?: string | undefined;
    MetricType?: ServiceLevelIndicatorMetricType | undefined;
    TotalRequestCountMetric: MetricDataQuery[];
    MonitoredRequestCountMetric: MonitoredRequestCountMetricDataQueries;
    DependencyConfig?: DependencyConfig | undefined;
    MetricSource?: MetricSource | undefined;
    CompositeSliConfig?: CompositeSliConfig | undefined;
}
export interface RequestBasedServiceLevelIndicator {
    RequestBasedSliMetric: RequestBasedServiceLevelIndicatorMetric;
    MetricThreshold?: number | undefined;
    ComparisonOperator?: ServiceLevelIndicatorComparisonOperator | undefined;
}
export type DurationUnit = "MINUTE" | "HOUR" | "DAY" | "MONTH" | (string & {});
export type RollingIntervalDuration = number;
export interface RollingInterval {
    DurationUnit: DurationUnit;
    Duration: number;
}
export type CalendarIntervalDuration = number;
export interface CalendarInterval {
    StartTime: Date;
    DurationUnit: DurationUnit;
    Duration: number;
}
export type Interval = {
    RollingInterval: RollingInterval;
    CalendarInterval?: undefined;
} | {
    RollingInterval?: undefined;
    CalendarInterval: CalendarInterval;
};
export type AttainmentGoal = number;
export type WarningThreshold = number;
export interface Goal {
    Interval?: Interval | undefined;
    AttainmentGoal?: number | undefined;
    WarningThreshold?: number | undefined;
}
export interface ServiceLevelObjectiveBudgetReport {
    Arn: string;
    Name: string;
    EvaluationType?: EvaluationType | undefined;
    BudgetStatus: ServiceLevelObjectiveBudgetStatus;
    Attainment?: number | undefined;
    TotalBudgetSeconds?: number | undefined;
    BudgetSecondsRemaining?: number | undefined;
    TotalBudgetRequests?: number | undefined;
    BudgetRequestsRemaining?: number | undefined;
    Sli?: ServiceLevelIndicator | undefined;
    RequestBasedSli?: RequestBasedServiceLevelIndicator | undefined;
    Goal?: Goal | undefined;
}
export type ServiceLevelObjectiveBudgetReports = ServiceLevelObjectiveBudgetReport[];
export type ServiceLevelObjectiveBudgetReportErrorCode = string;
export type ServiceLevelObjectiveBudgetReportErrorMessage = string;
export interface ServiceLevelObjectiveBudgetReportError {
    Name?: string | undefined;
    Arn: string;
    ErrorCode: string;
    ErrorMessage: string;
}
export type ServiceLevelObjectiveBudgetReportErrors = ServiceLevelObjectiveBudgetReportError[];
export interface BatchGetServiceLevelObjectiveBudgetReportOutput {
    Timestamp: Date;
    Reports: ServiceLevelObjectiveBudgetReport[];
    Errors: ServiceLevelObjectiveBudgetReportError[];
}
export type ExclusionDuration = number;
export interface Window {
    DurationUnit: DurationUnit;
    Duration: number;
}
export type Expression = string;
export interface RecurrenceRule {
    Expression?: string | undefined;
}
export type ExclusionReason = string;
export interface ExclusionWindow {
    Window: Window;
    StartTime?: Date | undefined;
    RecurrenceRule?: RecurrenceRule | undefined;
    Reason?: string | undefined;
}
export type ExclusionWindows = ExclusionWindow[];
export interface BatchUpdateExclusionWindowsInput {
    SloIds: string[];
    AddExclusionWindows?: ExclusionWindow[] | undefined;
    RemoveExclusionWindows?: ExclusionWindow[] | undefined;
}
export type ServiceLevelObjectiveId = string;
export type ExclusionWindowErrorCode = string;
export type ExclusionWindowErrorMessage = string;
export interface BatchUpdateExclusionWindowsError_ {
    SloId: string;
    ErrorCode: string;
    ErrorMessage: string;
}
export type BatchUpdateExclusionWindowsErrors = BatchUpdateExclusionWindowsError_[];
export interface BatchUpdateExclusionWindowsOutput {
    SloIds: string[];
    Errors: BatchUpdateExclusionWindowsError_[];
}
export type DynamicInstrumentationSignalType = "SNAPSHOT" | (string & {});
export type ProgrammingLanguage = "Java" | "Python" | "Javascript" | (string & {});
export interface CodeLocation {
    Language: ProgrammingLanguage;
    CodeUnit?: string | undefined;
    ClassName?: string | undefined;
    MethodName?: string | undefined;
    FilePath: string;
    LineNumber?: number | undefined;
}
export type Location = {
    CodeLocation: CodeLocation;
};
export type DynamicInstrumentationAttributeFilterGroup = {
    [key: string]: string | undefined;
};
export type DynamicInstrumentationAttributeFilters = {
    [key: string]: string | undefined;
}[];
export type StringList = string[];
export interface CaptureLimitsConfig {
    MaxHits?: number | undefined;
    MaxStringLength?: number | undefined;
    MaxCollectionWidth?: number | undefined;
    MaxCollectionDepth?: number | undefined;
    MaxStackFrames?: number | undefined;
    MaxStackTraceSize?: number | undefined;
    MaxObjectDepth?: number | undefined;
    MaxFieldsPerObject?: number | undefined;
}
export interface CodeCaptureConfiguration {
    CaptureArguments?: string[] | undefined;
    CaptureReturn?: boolean | undefined;
    CaptureStackTrace?: boolean | undefined;
    CaptureLocals?: string[] | undefined;
    CaptureLimits: CaptureLimitsConfig;
}
export type CaptureConfiguration = {
    CodeCapture: CodeCaptureConfiguration;
};
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateInstrumentationConfigurationRequest {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    Description?: string | undefined;
    ExpiresAt?: Date | undefined;
    AttributeFilters?: {
        [key: string]: string | undefined;
    }[] | undefined;
    CaptureConfiguration: CaptureConfiguration;
    Tags?: Tag[] | undefined;
}
export type InstrumentationConfigurationArn = string;
export interface CreateInstrumentationConfigurationResponse {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    LocationHash: string;
    Description?: string | undefined;
    ExpiresAt?: Date | undefined;
    AttributeFilters?: {
        [key: string]: string | undefined;
    }[] | undefined;
    CaptureConfiguration: CaptureConfiguration;
    CreatedAt: Date;
    ARN: string;
}
export type ServiceLevelObjectiveDescription = string;
export type ServiceLevelIndicatorStatistic = string;
export type SLIPeriodSeconds = number;
export interface ServiceLevelIndicatorMetricConfig {
    KeyAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    OperationName?: string | undefined;
    MetricType?: ServiceLevelIndicatorMetricType | undefined;
    MetricName?: string | undefined;
    Statistic?: string | undefined;
    PeriodSeconds?: number | undefined;
    MetricSource?: MetricSource | undefined;
    MetricDataQueries?: MetricDataQuery[] | undefined;
    DependencyConfig?: DependencyConfig | undefined;
    CompositeSliConfig?: CompositeSliConfig | undefined;
}
export interface ServiceLevelIndicatorConfig {
    SliMetricConfig: ServiceLevelIndicatorMetricConfig;
    MetricThreshold?: number | undefined;
    ComparisonOperator?: ServiceLevelIndicatorComparisonOperator | undefined;
}
export interface RequestBasedServiceLevelIndicatorMetricConfig {
    KeyAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    OperationName?: string | undefined;
    MetricType?: ServiceLevelIndicatorMetricType | undefined;
    TotalRequestCountMetric?: MetricDataQuery[] | undefined;
    MonitoredRequestCountMetric?: MonitoredRequestCountMetricDataQueries | undefined;
    DependencyConfig?: DependencyConfig | undefined;
    MetricSource?: MetricSource | undefined;
    MetricName?: string | undefined;
    CompositeSliConfig?: CompositeSliConfig | undefined;
}
export interface RequestBasedServiceLevelIndicatorConfig {
    RequestBasedSliMetricConfig: RequestBasedServiceLevelIndicatorMetricConfig;
    MetricThreshold?: number | undefined;
    ComparisonOperator?: ServiceLevelIndicatorComparisonOperator | undefined;
}
export type BurnRateLookBackWindowMinutes = number;
export interface BurnRateConfiguration {
    LookBackWindowMinutes: number;
}
export type BurnRateConfigurations = BurnRateConfiguration[];
export interface CreateServiceLevelObjectiveInput {
    Name: string;
    Description?: string | undefined;
    SliConfig?: ServiceLevelIndicatorConfig | undefined;
    RequestBasedSliConfig?: RequestBasedServiceLevelIndicatorConfig | undefined;
    Goal?: Goal | undefined;
    Tags?: Tag[] | undefined;
    BurnRateConfigurations?: BurnRateConfiguration[] | undefined;
    CreateRecommendedSlo?: boolean | undefined;
    AutoInvestigationEnabled?: boolean | undefined;
}
export type MetricSourceType = "ServiceOperation" | "CloudWatchMetric" | "ServiceDependency" | "AppMonitor" | "Canary" | "Service" | (string & {});
export interface ServiceLevelObjective {
    Arn: string;
    Name: string;
    Description?: string | undefined;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    Sli?: ServiceLevelIndicator | undefined;
    RequestBasedSli?: RequestBasedServiceLevelIndicator | undefined;
    EvaluationType?: EvaluationType | undefined;
    Goal: Goal;
    BurnRateConfigurations?: BurnRateConfiguration[] | undefined;
    MetricSourceType?: MetricSourceType | undefined;
    AutoInvestigationEnabled?: boolean | undefined;
}
export interface CreateServiceLevelObjectiveOutput {
    Slo: ServiceLevelObjective;
}
export interface DeleteGroupingConfigurationRequest {
}
export interface DeleteGroupingConfigurationOutput {
}
export type LocationIdentifier = {
    CodeLocation: CodeLocation;
    LocationHash?: undefined;
} | {
    CodeLocation?: undefined;
    LocationHash: string;
};
export interface DeleteInstrumentationConfigurationRequest {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    LocationIdentifier: LocationIdentifier;
}
export type DynamicInstrumentationDeletionStatus = "DELETED" | (string & {});
export interface DeleteInstrumentationConfigurationResponse {
    DeletionStatus: DynamicInstrumentationDeletionStatus;
}
export interface DeleteServiceLevelObjectiveInput {
    Id: string;
}
export interface DeleteServiceLevelObjectiveOutput {
}
export interface GetInstrumentationConfigurationRequest {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    LocationIdentifier: LocationIdentifier;
}
export interface InstrumentationConfiguration {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    LocationHash: string;
    Description?: string | undefined;
    ExpiresAt?: Date | undefined;
    AttributeFilters?: {
        [key: string]: string | undefined;
    }[] | undefined;
    CaptureConfiguration: CaptureConfiguration;
    CreatedAt: Date;
    ARN: string;
}
export interface GetInstrumentationConfigurationResponse {
    Configuration: InstrumentationConfiguration;
}
export type InstrumentationConfigurationStatus = "READY" | "ERROR" | "ACTIVE" | "DISABLED" | (string & {});
export type NextToken = string;
export interface GetInstrumentationConfigurationStatusRequest {
    InstrumentationType: InstrumentationType;
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    LocationIdentifier: LocationIdentifier;
    Status?: InstrumentationConfigurationStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InstrumentationErrorCause = "FILE_NOT_FOUND" | "METHOD_NOT_FOUND" | "LINE_NOT_EXECUTABLE" | "OVERLOADED_METHODS" | "LANGUAGE_MISMATCH" | "RUNTIME_ERROR" | (string & {});
export interface InstrumentationStatusEvent {
    Time: Date;
    ErrorCause?: InstrumentationErrorCause | undefined;
}
export type InstrumentationStatusEventList = InstrumentationStatusEvent[];
export interface GetInstrumentationConfigurationStatusResponse {
    Service: string;
    Environment: string;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    Status: InstrumentationConfigurationStatus;
    Events: InstrumentationStatusEvent[];
    NextToken?: string | undefined;
}
export interface GetServiceInput {
    StartTime: Date;
    EndTime: Date;
    KeyAttributes: {
        [key: string]: string | undefined;
    };
}
export type AttributeMap = {
    [key: string]: string | undefined;
};
export type AttributeMaps = {
    [key: string]: string | undefined;
}[];
export type GroupName = string;
export type GroupValue = string;
export type GroupSource = string;
export type GroupIdentifier = string;
export interface ServiceGroup {
    GroupName: string;
    GroupValue: string;
    GroupSource: string;
    GroupIdentifier: string;
}
export type ServiceGroups = ServiceGroup[];
export type MetricType = string;
export type AwsAccountId = string;
export interface MetricReference {
    Namespace: string;
    MetricType: string;
    Dimensions?: Dimension[] | undefined;
    MetricName: string;
    AccountId?: string | undefined;
}
export type MetricReferences = MetricReference[];
export type LogGroupReferences = {
    [key: string]: string | undefined;
}[];
export interface Service {
    KeyAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    AttributeMaps?: {
        [key: string]: string | undefined;
    }[] | undefined;
    ServiceGroups?: ServiceGroup[] | undefined;
    MetricReferences?: MetricReference[] | undefined;
    LogGroupReferences?: {
        [key: string]: string | undefined;
    }[] | undefined;
}
export interface GetServiceOutput {
    Service: Service;
    StartTime: Date;
    EndTime: Date;
    LogGroupReferences?: {
        [key: string]: string | undefined;
    }[] | undefined;
}
export interface GetServiceLevelObjectiveInput {
    Id: string;
}
export interface GetServiceLevelObjectiveOutput {
    Slo: ServiceLevelObjective;
}
export type Auditors = string[];
export interface ServiceEntity {
    Type?: string | undefined;
    Name?: string | undefined;
    Environment?: string | undefined;
    AwsAccountId?: string | undefined;
}
export interface ServiceLevelObjectiveEntity {
    SloName?: string | undefined;
    SloArn?: string | undefined;
}
export interface ServiceOperationEntity {
    Service?: ServiceEntity | undefined;
    Operation?: string | undefined;
    MetricType?: string | undefined;
}
export interface CanaryEntity {
    CanaryName: string;
}
export type AuditTargetEntity = {
    Service: ServiceEntity;
    Slo?: undefined;
    ServiceOperation?: undefined;
    Canary?: undefined;
} | {
    Service?: undefined;
    Slo: ServiceLevelObjectiveEntity;
    ServiceOperation?: undefined;
    Canary?: undefined;
} | {
    Service?: undefined;
    Slo?: undefined;
    ServiceOperation: ServiceOperationEntity;
    Canary?: undefined;
} | {
    Service?: undefined;
    Slo?: undefined;
    ServiceOperation?: undefined;
    Canary: CanaryEntity;
};
export interface AuditTarget {
    Type: string;
    Data: AuditTargetEntity;
}
export type AuditTargets = AuditTarget[];
export type DetailLevel = "BRIEF" | "DETAILED" | (string & {});
export type ListAuditFindingMaxResults = number;
export interface ListAuditFindingsInput {
    StartTime: Date;
    EndTime: Date;
    Auditors?: string[] | undefined;
    AuditTargets: AuditTarget[];
    DetailLevel?: DetailLevel | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type DataMap = {
    [key: string]: string | undefined;
};
export type Severity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "NONE" | (string & {});
export interface AuditorResult {
    Auditor?: string | undefined;
    Description?: string | undefined;
    Data?: {
        [key: string]: string | undefined;
    } | undefined;
    Severity?: Severity | undefined;
}
export type AuditorResults = AuditorResult[];
export interface MetricGraph {
    MetricDataQueries?: MetricDataQuery[] | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export interface Node {
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    Name: string;
    NodeId: string;
    Operation?: string | undefined;
    Type?: string | undefined;
    Duration?: number | undefined;
    Status?: string | undefined;
}
export type Nodes = Node[];
export type ConnectionType = "INDIRECT" | "DIRECT" | (string & {});
export interface Edge {
    SourceNodeId?: string | undefined;
    DestinationNodeId?: string | undefined;
    Duration?: number | undefined;
    ConnectionType?: ConnectionType | undefined;
}
export type Edges = Edge[];
export interface DependencyGraph {
    Nodes?: Node[] | undefined;
    Edges?: Edge[] | undefined;
}
export interface AuditFinding {
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    AuditorResults?: AuditorResult[] | undefined;
    Operation?: string | undefined;
    MetricGraph?: MetricGraph | undefined;
    DependencyGraph?: DependencyGraph | undefined;
    Type?: string | undefined;
}
export type AuditFindings = AuditFinding[];
export interface ListAuditFindingsOutput {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    AuditFindings: AuditFinding[];
    NextToken?: string | undefined;
}
export type ListEntityEventsMaxResults = number;
export interface ListEntityEventsInput {
    Entity: {
        [key: string]: string | undefined;
    };
    StartTime: Date;
    EndTime: Date;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ChangeEventType = "DEPLOYMENT" | "CONFIGURATION" | (string & {});
export interface ChangeEvent {
    Timestamp: Date;
    AccountId: string;
    Region: string;
    Entity: {
        [key: string]: string | undefined;
    };
    ChangeEventType: ChangeEventType;
    EventId: string;
    UserName?: string | undefined;
    EventName?: string | undefined;
}
export type ChangeEvents = ChangeEvent[];
export interface ListEntityEventsOutput {
    StartTime: Date;
    EndTime: Date;
    ChangeEvents: ChangeEvent[];
    NextToken?: string | undefined;
}
export interface ListGroupingAttributeDefinitionsInput {
    NextToken?: string | undefined;
    AwsAccountId?: string | undefined;
    IncludeLinkedAccounts?: boolean | undefined;
}
export type GroupingString = string;
export type GroupingSourceKeyStringList = string[];
export interface GroupingAttributeDefinition {
    GroupingName: string;
    GroupingSourceKeys?: string[] | undefined;
    DefaultGroupingValue?: string | undefined;
}
export type GroupingAttributeDefinitions = GroupingAttributeDefinition[];
export interface ListGroupingAttributeDefinitionsOutput {
    GroupingAttributeDefinitions: GroupingAttributeDefinition[];
    UpdatedAt?: Date | undefined;
    NextToken?: string | undefined;
}
export interface ListInstrumentationConfigurationsRequest {
    Service: string;
    Environment: string;
    InstrumentationType: InstrumentationType;
    SyncedAt?: Date | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface InstrumentationConfigurationWithoutServiceEnv {
    InstrumentationType: InstrumentationType;
    SignalType: DynamicInstrumentationSignalType;
    Location: Location;
    LocationHash: string;
    Description?: string | undefined;
    ExpiresAt?: Date | undefined;
    AttributeFilters?: {
        [key: string]: string | undefined;
    }[] | undefined;
    CaptureConfiguration: CaptureConfiguration;
    CreatedAt: Date;
    ARN: string;
}
export type InstrumentationConfigurationsWithoutServiceEnv = InstrumentationConfigurationWithoutServiceEnv[];
export interface InstrumentationConfigurationsPage {
    Service: string;
    Environment: string;
    Changed: boolean;
    LatestConfigurations?: InstrumentationConfigurationWithoutServiceEnv[] | undefined;
    SyncedAt: Date;
    SyncInterval: number;
    NextToken?: string | undefined;
}
export type ListServiceDependenciesMaxResults = number;
export interface ListServiceDependenciesInput {
    StartTime: Date;
    EndTime: Date;
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ServiceDependency {
    OperationName: string;
    DependencyKeyAttributes: {
        [key: string]: string | undefined;
    };
    DependencyOperationName: string;
    MetricReferences: MetricReference[];
}
export type ServiceDependencies = ServiceDependency[];
export interface ListServiceDependenciesOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceDependencies: ServiceDependency[];
    NextToken?: string | undefined;
}
export type ListServiceDependentsMaxResults = number;
export interface ListServiceDependentsInput {
    StartTime: Date;
    EndTime: Date;
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ServiceDependent {
    OperationName?: string | undefined;
    DependentKeyAttributes: {
        [key: string]: string | undefined;
    };
    DependentOperationName?: string | undefined;
    MetricReferences: MetricReference[];
}
export type ServiceDependents = ServiceDependent[];
export interface ListServiceDependentsOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceDependents: ServiceDependent[];
    NextToken?: string | undefined;
}
export type ListServiceLevelObjectiveExclusionWindowsMaxResults = number;
export interface ListServiceLevelObjectiveExclusionWindowsInput {
    Id: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListServiceLevelObjectiveExclusionWindowsOutput {
    ExclusionWindows: ExclusionWindow[];
    NextToken?: string | undefined;
}
export type ListServiceLevelObjectivesMaxResults = number;
export type MetricSourceTypes = MetricSourceType[];
export interface ListServiceLevelObjectivesInput {
    KeyAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    OperationName?: string | undefined;
    DependencyConfig?: DependencyConfig | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    MetricSourceTypes?: MetricSourceType[] | undefined;
    IncludeLinkedAccounts?: boolean | undefined;
    SloOwnerAwsAccountId?: string | undefined;
    MetricSource?: MetricSource | undefined;
}
export interface ServiceLevelObjectiveSummary {
    Arn: string;
    Name: string;
    KeyAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    OperationName?: string | undefined;
    DependencyConfig?: DependencyConfig | undefined;
    CreatedTime?: Date | undefined;
    EvaluationType?: EvaluationType | undefined;
    MetricSourceType?: MetricSourceType | undefined;
    MetricSource?: MetricSource | undefined;
    CompositeSliConfig?: CompositeSliConfig | undefined;
}
export type ServiceLevelObjectiveSummaries = ServiceLevelObjectiveSummary[];
export interface ListServiceLevelObjectivesOutput {
    SloSummaries?: ServiceLevelObjectiveSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ListServiceOperationMaxResults = number;
export interface ListServiceOperationsInput {
    StartTime: Date;
    EndTime: Date;
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ServiceOperation {
    Name: string;
    MetricReferences: MetricReference[];
}
export type ServiceOperations = ServiceOperation[];
export interface ListServiceOperationsOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceOperations: ServiceOperation[];
    NextToken?: string | undefined;
}
export type ListServicesMaxResults = number;
export interface ListServicesInput {
    StartTime: Date;
    EndTime: Date;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    IncludeLinkedAccounts?: boolean | undefined;
    AwsAccountId?: string | undefined;
}
export interface ServiceSummary {
    KeyAttributes: {
        [key: string]: string | undefined;
    };
    AttributeMaps?: {
        [key: string]: string | undefined;
    }[] | undefined;
    MetricReferences: MetricReference[];
    ServiceGroups?: ServiceGroup[] | undefined;
}
export type ServiceSummaries = ServiceSummary[];
export interface ListServicesOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceSummaries: ServiceSummary[];
    NextToken?: string | undefined;
}
export type ListServiceStatesMaxResults = number;
export type AttributeFilterName = string;
export type AttributeFilterValue = string;
export type AttributeFilterValues = string[];
export interface AttributeFilter {
    AttributeFilterName: string;
    AttributeFilterValues: string[];
}
export type AttributeFilters = AttributeFilter[];
export interface ListServiceStatesInput {
    StartTime: Date;
    EndTime: Date;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    IncludeLinkedAccounts?: boolean | undefined;
    AwsAccountId?: string | undefined;
    AttributeFilters?: AttributeFilter[] | undefined;
}
export type LatestChangeEvents = ChangeEvent[];
export interface ServiceState {
    AttributeFilters?: AttributeFilter[] | undefined;
    Service: {
        [key: string]: string | undefined;
    };
    LatestChangeEvents: ChangeEvent[];
}
export type ServiceStates = ServiceState[];
export interface ListServiceStatesOutput {
    StartTime: Date;
    EndTime: Date;
    ServiceStates: ServiceState[];
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface PutGroupingConfigurationInput {
    GroupingAttributeDefinitions: GroupingAttributeDefinition[];
}
export interface GroupingConfiguration {
    GroupingAttributeDefinitions: GroupingAttributeDefinition[];
    UpdatedAt: Date;
}
export interface PutGroupingConfigurationOutput {
    GroupingConfiguration: GroupingConfiguration;
}
export interface InstrumentationConfigurationStatusReport {
    InstrumentationType: InstrumentationType;
    SignalType: DynamicInstrumentationSignalType;
    LocationHash: string;
    Status: InstrumentationConfigurationStatus;
    Time: Date;
    ErrorCause?: InstrumentationErrorCause | undefined;
}
export type InstrumentationConfigurationStatusList = InstrumentationConfigurationStatusReport[];
export interface ReportInstrumentationConfigurationStatusRequest {
    Service: string;
    Environment: string;
    Configurations: InstrumentationConfigurationStatusReport[];
}
export type UnprocessedStatusEventFailureReason = "THROTTLED" | "INTERNAL_ERROR" | "VALIDATION_ERROR" | (string & {});
export interface UnprocessedStatusEvent {
    InstrumentationType: InstrumentationType;
    SignalType: DynamicInstrumentationSignalType;
    LocationHash: string;
    Status: InstrumentationConfigurationStatus;
    Time: Date;
    FailedReason: UnprocessedStatusEventFailureReason;
}
export type UnprocessedStatusEventList = UnprocessedStatusEvent[];
export interface ReportInstrumentationConfigurationStatusResponse {
    Service: string;
    Environment: string;
    UnprocessedStatusEvents: UnprocessedStatusEvent[];
}
export interface StartDiscoveryInput {
}
export interface StartDiscoveryOutput {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateServiceLevelObjectiveInput {
    Id: string;
    Description?: string | undefined;
    SliConfig?: ServiceLevelIndicatorConfig | undefined;
    RequestBasedSliConfig?: RequestBasedServiceLevelIndicatorConfig | undefined;
    Goal?: Goal | undefined;
    BurnRateConfigurations?: BurnRateConfiguration[] | undefined;
    AutoInvestigationEnabled?: boolean | undefined;
}
export interface UpdateServiceLevelObjectiveOutput {
    Slo: ServiceLevelObjective;
}
export type ValidationExceptionMessage = string;
export type ResourceType = string;
export type ResourceId = string;
export type FaultDescription = string;
export type ServiceErrorMessage = string;
export type BatchDeleteInstrumentationConfigurationsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes multiple instrumentation configurations in a single request.
 * Supports two mutually exclusive selection methods:
 * - By scope: Delete all configurations matching a Service + Environment + InstrumentationType
 * - By ARN list: Delete specific configurations by providing a list of resource ARNs
 */
export declare const batchDeleteInstrumentationConfigurations: API.OperationMethod<BatchDeleteInstrumentationConfigurationsRequest & RegionInput, BatchDeleteInstrumentationConfigurationsResponse, BatchDeleteInstrumentationConfigurationsError, Credentials | HttpClient.HttpClient>;
export type BatchGetServiceLevelObjectiveBudgetReportError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to retrieve one or more *service level objective (SLO) budget reports*.
 *
 * An *error budget* is the amount of time or requests in an unhealthy state that your service can accumulate during an interval before your overall SLO budget health is breached and the SLO is considered to be unmet. For example, an SLO with a threshold of 99.95% and a monthly interval translates to an error budget of 21.9 minutes of downtime in a 30-day month.
 *
 * Budget reports include a health indicator, the attainment value, and remaining budget.
 *
 * For more information about SLO error budgets, see SLO concepts.
 */
export declare const batchGetServiceLevelObjectiveBudgetReport: API.OperationMethod<BatchGetServiceLevelObjectiveBudgetReportInput & RegionInput, BatchGetServiceLevelObjectiveBudgetReportOutput, BatchGetServiceLevelObjectiveBudgetReportError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateExclusionWindowsError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add or remove time window exclusions for one or more Service Level Objectives (SLOs).
 */
export declare const batchUpdateExclusionWindows: API.OperationMethod<BatchUpdateExclusionWindowsInput & RegionInput, BatchUpdateExclusionWindowsOutput, BatchUpdateExclusionWindowsError, Credentials | HttpClient.HttpClient>;
export type CreateInstrumentationConfigurationError = ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a dynamic instrumentation configuration for a specific code or endpoint location within a service and environment. Configurations are immutable after creation.
 *
 * For `BREAKPOINT` type configurations, they expire after 24 hours unless a shorter expiration is provided. For `PROBE` type configurations, they persist until explicitly deleted; an expiration cannot be set for `PROBE` configurations.
 *
 * If a configuration already exists for the same service, environment, signal type, and location, this operation returns a conflict instead of overwriting it. Use attribute filters and capture settings to control where the instrumentation runs and which data is collected.
 */
export declare const createInstrumentationConfiguration: API.OperationMethod<CreateInstrumentationConfigurationRequest & RegionInput, CreateInstrumentationConfigurationResponse, CreateInstrumentationConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateServiceLevelObjectiveError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a service level objective (SLO), which can help you ensure that your critical business operations are meeting customer expectations. Use SLOs to set and track specific target levels for the reliability and availability of your applications and services. SLOs use service level indicators (SLIs) to calculate whether the application is performing at the level that you want.
 *
 * Create an SLO to set a target for a service or operation's availability or latency. CloudWatch measures this target frequently you can find whether it has been breached.
 *
 * The target performance quality that is defined for an SLO is the *attainment goal*.
 *
 * You can set SLO targets for your applications that are discovered by Application Signals, using critical metrics such as latency and availability. You can also set SLOs against any CloudWatch metric or math expression that produces a time series.
 *
 * You can't create an SLO for a service operation that was discovered by Application Signals until after that operation has reported standard metrics to Application Signals.
 *
 * When you create an SLO, you specify whether it is a *period-based SLO* or a *request-based SLO*. Each type of SLO has a different way of evaluating your application's performance against its attainment goal.
 *
 * - A *period-based SLO* uses defined *periods* of time within a specified total time interval. For each period of time, Application Signals determines whether the application met its goal. The attainment rate is calculated as the `number of good periods/number of total periods`.
 *
 * For example, for a period-based SLO, meeting an attainment goal of 99.9% means that within your interval, your application must meet its performance goal during at least 99.9% of the time periods.
 *
 * - A *request-based SLO* doesn't use pre-defined periods of time. Instead, the SLO measures `number of good requests/number of total requests` during the interval. At any time, you can find the ratio of good requests to total requests for the interval up to the time stamp that you specify, and measure that ratio against the goal set in your SLO.
 *
 * After you have created an SLO, you can retrieve error budget reports for it. An *error budget* is the amount of time or amount of requests that your application can be non-compliant with the SLO's goal, and still have your application meet the goal.
 *
 * - For a period-based SLO, the error budget starts at a number defined by the highest number of periods that can fail to meet the threshold, while still meeting the overall goal. The *remaining error budget* decreases with every failed period that is recorded. The error budget within one interval can never increase.
 *
 * For example, an SLO with a threshold that 99.95% of requests must be completed under 2000ms every month translates to an error budget of 21.9 minutes of downtime per month.
 *
 * - For a request-based SLO, the remaining error budget is dynamic and can increase or decrease, depending on the ratio of good requests to total requests.
 *
 * For more information about SLOs, see Service level objectives (SLOs).
 *
 * When you perform a `CreateServiceLevelObjective` operation, Application Signals creates the *AWSServiceRoleForCloudWatchApplicationSignals* service-linked role, if it doesn't already exist in your account. This service- linked role has the following permissions:
 *
 * - `xray:GetServiceGraph`
 *
 * - `logs:StartQuery`
 *
 * - `logs:GetQueryResults`
 *
 * - `cloudwatch:GetMetricData`
 *
 * - `cloudwatch:ListMetrics`
 *
 * - `tag:GetResources`
 *
 * - `autoscaling:DescribeAutoScalingGroups`
 */
export declare const createServiceLevelObjective: API.OperationMethod<CreateServiceLevelObjectiveInput & RegionInput, CreateServiceLevelObjectiveOutput, CreateServiceLevelObjectiveError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupingConfigurationError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the grouping configuration for this account. This removes all custom grouping attribute definitions that were previously configured.
 */
export declare const deleteGroupingConfiguration: API.OperationMethod<DeleteGroupingConfigurationRequest & RegionInput, DeleteGroupingConfigurationOutput, DeleteGroupingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteInstrumentationConfigurationError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified instrumentation configuration. SDKs remove the instrumentation during their next sync after the configuration is deleted or expires.
 */
export declare const deleteInstrumentationConfiguration: API.OperationMethod<DeleteInstrumentationConfigurationRequest & RegionInput, DeleteInstrumentationConfigurationResponse, DeleteInstrumentationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceLevelObjectiveError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified service level objective.
 */
export declare const deleteServiceLevelObjective: API.OperationMethod<DeleteServiceLevelObjectiveInput & RegionInput, DeleteServiceLevelObjectiveOutput, DeleteServiceLevelObjectiveError, Credentials | HttpClient.HttpClient>;
export type GetInstrumentationConfigurationError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details of a single instrumentation configuration identified by service, environment, signal type, and location. Use this to audit or display configuration details.
 */
export declare const getInstrumentationConfiguration: API.OperationMethod<GetInstrumentationConfigurationRequest & RegionInput, GetInstrumentationConfigurationResponse, GetInstrumentationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetInstrumentationConfigurationStatusError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status history for a single instrumentation configuration during a specified time range. The response lists when the configuration was ACTIVE, READY, ERROR, or DISABLED.
 *
 * If no status or time window is provided, the operation defaults to ACTIVE events from the last hour.
 */
export declare const getInstrumentationConfigurationStatus: API.PaginatedOperationMethod<GetInstrumentationConfigurationStatusRequest & RegionInput, GetInstrumentationConfigurationStatusResponse, GetInstrumentationConfigurationStatusError, Credentials | HttpClient.HttpClient, InstrumentationStatusEvent>;
export type GetServiceError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a service discovered by Application Signals.
 */
export declare const getService: API.OperationMethod<GetServiceInput & RegionInput, GetServiceOutput, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetServiceLevelObjectiveError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about one SLO created in the account.
 */
export declare const getServiceLevelObjective: API.OperationMethod<GetServiceLevelObjectiveInput & RegionInput, GetServiceLevelObjectiveOutput, GetServiceLevelObjectiveError, Credentials | HttpClient.HttpClient>;
export type ListAuditFindingsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of audit findings that provide automated analysis of service behavior and root cause analysis. These findings help identify the most significant observations about your services, including performance issues, anomalies, and potential problems. The findings are generated using heuristic algorithms based on established troubleshooting patterns.
 */
export declare const listAuditFindings: API.OperationMethod<ListAuditFindingsInput & RegionInput, ListAuditFindingsOutput, ListAuditFindingsError, Credentials | HttpClient.HttpClient>;
export type ListEntityEventsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of change events for a specific entity, such as deployments, configuration changes, or other state-changing activities. This operation helps track the history of changes that may have affected service performance.
 */
export declare const listEntityEvents: API.PaginatedOperationMethod<ListEntityEventsInput & RegionInput, ListEntityEventsOutput, ListEntityEventsError, Credentials | HttpClient.HttpClient, ChangeEvent>;
export type ListGroupingAttributeDefinitionsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the current grouping configuration for this account, including all custom grouping attribute definitions that have been configured. These definitions determine how services are logically grouped based on telemetry attributes, Amazon Web Services tags, or predefined mappings.
 */
export declare const listGroupingAttributeDefinitions: API.OperationMethod<ListGroupingAttributeDefinitionsInput & RegionInput, ListGroupingAttributeDefinitionsOutput, ListGroupingAttributeDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListInstrumentationConfigurationsError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns all active instrumentation configurations for a service and environment. SDKs use this operation to sync configurations and apply client-side filters locally.
 *
 * Include the previous `SyncedAt` value to perform incremental syncs. When no changes are detected, the response sets `Changed` to `false` and omits configuration details.
 */
export declare const listInstrumentationConfigurations: API.PaginatedOperationMethod<ListInstrumentationConfigurationsRequest & RegionInput, InstrumentationConfigurationsPage, ListInstrumentationConfigurationsError, Credentials | HttpClient.HttpClient, InstrumentationConfigurationWithoutServiceEnv>;
export type ListServiceDependenciesError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of service dependencies of the service that you specify. A dependency is an infrastructure component that an operation of this service connects with. Dependencies can include Amazon Web Services services, Amazon Web Services resources, and third-party services.
 */
export declare const listServiceDependencies: API.PaginatedOperationMethod<ListServiceDependenciesInput & RegionInput, ListServiceDependenciesOutput, ListServiceDependenciesError, Credentials | HttpClient.HttpClient, ServiceDependency>;
export type ListServiceDependentsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of dependents that invoked the specified service during the provided time range. Dependents include other services, CloudWatch Synthetics canaries, and clients that are instrumented with CloudWatch RUM app monitors.
 */
export declare const listServiceDependents: API.PaginatedOperationMethod<ListServiceDependentsInput & RegionInput, ListServiceDependentsOutput, ListServiceDependentsError, Credentials | HttpClient.HttpClient, ServiceDependent>;
export type ListServiceLevelObjectiveExclusionWindowsError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all exclusion windows configured for a specific SLO.
 */
export declare const listServiceLevelObjectiveExclusionWindows: API.PaginatedOperationMethod<ListServiceLevelObjectiveExclusionWindowsInput & RegionInput, ListServiceLevelObjectiveExclusionWindowsOutput, ListServiceLevelObjectiveExclusionWindowsError, Credentials | HttpClient.HttpClient, ExclusionWindow>;
export type ListServiceLevelObjectivesError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of SLOs created in this account.
 */
export declare const listServiceLevelObjectives: API.PaginatedOperationMethod<ListServiceLevelObjectivesInput & RegionInput, ListServiceLevelObjectivesOutput, ListServiceLevelObjectivesError, Credentials | HttpClient.HttpClient, ServiceLevelObjectiveSummary>;
export type ListServiceOperationsError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the *operations* of this service that have been discovered by Application Signals. Only the operations that were invoked during the specified time range are returned.
 */
export declare const listServiceOperations: API.PaginatedOperationMethod<ListServiceOperationsInput & RegionInput, ListServiceOperationsOutput, ListServiceOperationsError, Credentials | HttpClient.HttpClient, ServiceOperation>;
export type ListServicesError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of services that have been discovered by Application Signals. A service represents a minimum logical and transactional unit that completes a business function. Services are discovered through Application Signals instrumentation.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesInput & RegionInput, ListServicesOutput, ListServicesError, Credentials | HttpClient.HttpClient, ServiceSummary>;
export type ListServiceStatesError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the last deployment and other change states of services. This API provides visibility into recent changes that may have affected service performance, helping with troubleshooting and change correlation.
 */
export declare const listServiceStates: API.PaginatedOperationMethod<ListServiceStatesInput & RegionInput, ListServiceStatesOutput, ListServiceStatesError, Credentials | HttpClient.HttpClient, ServiceState>;
export type ListTagsForResourceError = ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Displays the tags associated with a CloudWatch resource. Tags can be assigned to service level objectives.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutGroupingConfigurationError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates the grouping configuration for this account. This operation allows you to define custom grouping attributes that determine how services are logically grouped based on telemetry attributes, Amazon Web Services tags, or predefined mappings. These grouping attributes can then be used to organize and filter services in the Application Signals console and APIs.
 */
export declare const putGroupingConfiguration: API.OperationMethod<PutGroupingConfigurationInput & RegionInput, PutGroupingConfigurationOutput, PutGroupingConfigurationError, Credentials | HttpClient.HttpClient>;
export type ReportInstrumentationConfigurationStatusError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Reports the status of one or more instrumentation configurations from SDK instances. Use this to record when configurations become ready, hit errors, become active, or are disabled by limits.
 *
 * Report `READY`, `ERROR`, and `DISABLED` when the status changes. Report `ACTIVE` periodically (for example, every minute) while instrumentation is running.
 */
export declare const reportInstrumentationConfigurationStatus: API.OperationMethod<ReportInstrumentationConfigurationStatusRequest & RegionInput, ReportInstrumentationConfigurationStatusResponse, ReportInstrumentationConfigurationStatusError, Credentials | HttpClient.HttpClient>;
export type StartDiscoveryError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables this Amazon Web Services account to be able to use CloudWatch Application Signals by creating the *AWSServiceRoleForCloudWatchApplicationSignals* service-linked role. This service- linked role has the following permissions:
 *
 * - `xray:GetServiceGraph`
 *
 * - `logs:StartQuery`
 *
 * - `logs:GetQueryResults`
 *
 * - `cloudwatch:GetMetricData`
 *
 * - `cloudwatch:ListMetrics`
 *
 * - `tag:GetResources`
 *
 * - `autoscaling:DescribeAutoScalingGroups`
 *
 * A service-linked CloudTrail event channel is created to process CloudTrail events and return change event information. This includes last deployment time, userName, eventName, and other event metadata.
 *
 * After completing this step, you still need to instrument your Java and Python applications to send data to Application Signals. For more information, see Enabling Application Signals.
 */
export declare const startDiscovery: API.OperationMethod<StartDiscoveryInput & RegionInput, StartDiscoveryOutput, StartDiscoveryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified CloudWatch resource, such as a service level objective.
 *
 * Tags can help you organize and categorize your resources. You can also use them to scope user permissions by granting a user permission to access or change only resources with certain tag values.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of characters.
 *
 * You can use the `TagResource` action with an alarm that already has tags. If you specify a new tag key for the alarm, this tag is appended to the list of tags associated with the alarm. If you specify a tag key that is already associated with the alarm, the new tag value that you specify replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a CloudWatch resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceLevelObjectiveError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing service level objective (SLO). If you omit parameters, the previous values of those parameters are retained.
 *
 * You cannot change from a period-based SLO to a request-based SLO, or change from a request-based SLO to a period-based SLO.
 */
export declare const updateServiceLevelObjective: API.OperationMethod<UpdateServiceLevelObjectiveInput & RegionInput, UpdateServiceLevelObjectiveOutput, UpdateServiceLevelObjectiveError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=application-signals.d.ts.map