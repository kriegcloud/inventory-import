import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SecurityTxtInvalid_base: S.TaggedErrorClass<"SecurityTxtInvalid", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SecurityTxtInvalid extends /*@__PURE__*/ SecurityTxtInvalid_base {
}
export interface DeleteSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
}
export interface DeleteSecurityTxtResponse {
}
export interface GetSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResponseAcknowledgmentsList = Array<string>;
export type GetResponseCanonicalList = Array<string>;
export type GetResponseContactList = Array<string>;
export type GetResponseEncryptionList = Array<string>;
export type GetResponseHiringList = Array<string>;
export type GetResponsePolicyList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SecurityTxtFile {
    acknowledgments?: GetResponseAcknowledgmentsList | null | undefined;
    canonical?: GetResponseCanonicalList | null | undefined;
    contact?: GetResponseContactList | null | undefined;
    enabled?: boolean | null | undefined;
    encryption?: GetResponseEncryptionList | null | undefined;
    expires?: string | null | undefined;
    hiring?: GetResponseHiringList | null | undefined;
    policy?: GetResponsePolicyList | null | undefined;
    preferredLanguages?: string | null | undefined;
}
export type GetSecurityTxtResponse = SecurityTxtFile;
export type UpdateRequestAcknowledgmentsList = Array<string>;
export type UpdateRequestCanonicalList = Array<string>;
export type UpdateRequestContactList = Array<string>;
export type UpdateRequestEncryptionList = Array<string>;
export type UpdateRequestHiringList = Array<string>;
export type UpdateRequestPolicyList = Array<string>;
export interface PutSecurityTxtRequest {
    /** Identifier. */
    zoneId: string;
    acknowledgments?: UpdateRequestAcknowledgmentsList | undefined;
    canonical?: UpdateRequestCanonicalList | undefined;
    contact?: UpdateRequestContactList | undefined;
    enabled?: boolean | undefined;
    encryption?: UpdateRequestEncryptionList | undefined;
    expires?: string | undefined;
    hiring?: UpdateRequestHiringList | undefined;
    policy?: UpdateRequestPolicyList | undefined;
    preferredLanguages?: string | undefined;
}
export interface PutSecurityTxtResponse {
}
export type DeleteSecurityTxtError = Forbidden | CloudflareOpError;
/** Removes the security.txt file configuration for a zone. The /.well-known/security.txt endpoint will no longer be served. */
export declare const deleteSecurityTxt: API.OperationMethod<DeleteSecurityTxtRequest, DeleteSecurityTxtResponse, DeleteSecurityTxtError, CloudflareOpContext>;
export type GetSecurityTxtError = Forbidden | CloudflareOpError;
/** Retrieves the current security.txt file configuration for a zone, used for security vulnerability reporting. */
export declare const getSecurityTxt: API.OperationMethod<GetSecurityTxtRequest, GetSecurityTxtResponse, GetSecurityTxtError, CloudflareOpContext>;
export type PutSecurityTxtError = Forbidden | SecurityTxtInvalid | CloudflareOpError;
/** Updates the security.txt file configuration for a zone, which provides security researchers with vulnerability reporting information. */
export declare const putSecurityTxt: API.OperationMethod<PutSecurityTxtRequest, PutSecurityTxtResponse, PutSecurityTxtError, CloudflareOpContext>;
//# sourceMappingURL=security_txt.d.ts.map