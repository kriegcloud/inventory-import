import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface GetGlyphsRequest {
    FontStack: string;
    FontUnicodeRange: string;
}
export interface GetGlyphsResponse {
    Blob?: Uint8Array | undefined;
    ContentType?: string | undefined;
    CacheControl?: string | undefined;
    ETag?: string | undefined;
}
export type MapStyle = "Standard" | "Monochrome" | "Hybrid" | "Satellite" | (string & {});
export type ColorScheme = "Light" | "Dark" | (string & {});
export type Variant = "Default" | (string & {});
export interface GetSpritesRequest {
    FileName: string;
    Style: MapStyle;
    ColorScheme: ColorScheme;
    Variant: Variant;
}
export interface GetSpritesResponse {
    Blob?: Uint8Array | undefined;
    ContentType?: string | undefined;
    CacheControl?: string | undefined;
    ETag?: string | undefined;
}
export type PositionListString = string | redacted.Redacted<string>;
export type PositionString = string | redacted.Redacted<string>;
export type CompactOverlay = string | redacted.Redacted<string>;
export type GeoJsonOverlay = string | redacted.Redacted<string>;
export type SensitiveInteger = number;
export type ApiKey = string | redacted.Redacted<string>;
export type LabelSize = "Small" | "Large" | (string & {});
export type LanguageTag = string;
export type CountryCode = string | redacted.Redacted<string>;
export type MapFeatureMode = "Enabled" | "Disabled" | (string & {});
export type DistanceMeters = number;
export type ScaleBarUnit = "Kilometers" | "KilometersMiles" | "Miles" | "MilesKilometers" | (string & {});
export type StaticMapStyle = "Satellite" | "Standard" | (string & {});
export type SensitiveFloat = number;
export interface GetStaticMapRequest {
    BoundingBox?: string | redacted.Redacted<string> | undefined;
    BoundedPositions?: string | redacted.Redacted<string> | undefined;
    Center?: string | redacted.Redacted<string> | undefined;
    ColorScheme?: ColorScheme | undefined;
    CompactOverlay?: string | redacted.Redacted<string> | undefined;
    CropLabels?: boolean | undefined;
    GeoJsonOverlay?: string | redacted.Redacted<string> | undefined;
    Height: number;
    Key?: string | redacted.Redacted<string> | undefined;
    LabelSize?: LabelSize | undefined;
    Language?: string | undefined;
    Padding?: number | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    PointsOfInterests?: MapFeatureMode | undefined;
    Radius?: number | undefined;
    FileName: string;
    ScaleBarUnit?: ScaleBarUnit | undefined;
    Style?: StaticMapStyle | undefined;
    Width: number;
    Zoom?: number | undefined;
}
export interface GetStaticMapResponse {
    Blob?: Uint8Array | undefined;
    ContentType?: string | undefined;
    CacheControl?: string | undefined;
    ETag?: string | undefined;
    PricingBucket: string;
}
export type Terrain = "Hillshade" | "Terrain3D" | (string & {});
export type ContourDensity = "Low" | "Medium" | "High" | (string & {});
export type Traffic = "All" | "Congestion" | (string & {});
export type TravelMode = "Transit" | "Truck" | (string & {});
export type TravelModeList = TravelMode[];
export type Buildings = "Buildings3D" | (string & {});
export type PoiDensity = "Off" | "VerySparse" | "Sparse" | "Default" | "Dense" | "VeryDense" | (string & {});
export type PoiCategory = "FoodAndDrink" | "Entertainment" | "SightsAndMuseums" | "Transportation" | "Accommodations" | "LeisureAndOutdoor" | "Shopping" | "BusinessAndServices" | "FacilitiesAndBuildings" | (string & {});
export type PoiCategoryList = PoiCategory[];
export interface GetStyleDescriptorRequest {
    Style: MapStyle;
    ColorScheme?: ColorScheme | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    Terrain?: Terrain | undefined;
    ContourDensity?: ContourDensity | undefined;
    Traffic?: Traffic | undefined;
    TravelModes?: TravelMode[] | undefined;
    Buildings?: Buildings | undefined;
    PoiDensity?: PoiDensity | undefined;
    PoiCategories?: PoiCategory[] | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
}
export interface GetStyleDescriptorResponse {
    Blob?: Uint8Array | undefined;
    ContentType?: string | undefined;
    CacheControl?: string | undefined;
    ETag?: string | undefined;
}
export type TileAdditionalFeature = "ContourLines" | "Hillshade" | "Logistics" | "Transit" | (string & {});
export type TileAdditionalFeatureList = TileAdditionalFeature[];
export type Tileset = string;
export type SensitiveString = string | redacted.Redacted<string>;
export interface GetTileRequest {
    AdditionalFeatures?: TileAdditionalFeature[] | undefined;
    Tileset: string;
    Z: string | redacted.Redacted<string>;
    X: string | redacted.Redacted<string>;
    Y: string | redacted.Redacted<string>;
    Key?: string | redacted.Redacted<string> | undefined;
}
export interface GetTileResponse {
    Blob?: Uint8Array | undefined;
    ContentType?: string | undefined;
    CacheControl?: string | undefined;
    ETag?: string | undefined;
    PricingBucket: string;
}
export type ValidationExceptionReason = "UnknownOperation" | "Missing" | "CannotParse" | "FieldValidationFailed" | "Other" | "UnknownField" | (string & {});
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type GetGlyphsError = CommonErrors;
/**
 * `GetGlyphs` returns the map's glyphs.
 *
 * For more information, see Style labels with glyphs in the *Amazon Location Service Developer Guide*.
 */
export declare const getGlyphs: API.OperationMethod<GetGlyphsRequest & RegionInput, GetGlyphsResponse, GetGlyphsError, Credentials | HttpClient.HttpClient>;
export type GetSpritesError = CommonErrors;
/**
 * `GetSprites` returns the map's sprites.
 *
 * For more information, see Style iconography with sprites in the *Amazon Location Service Developer Guide*.
 */
export declare const getSprites: API.OperationMethod<GetSpritesRequest & RegionInput, GetSpritesResponse, GetSpritesError, Credentials | HttpClient.HttpClient>;
export type GetStaticMapError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `GetStaticMap` provides high-quality static map images with customizable options. You can modify the map's appearance and overlay additional information. It's an ideal solution for applications requiring tailored static map snapshots. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see the following topics in the *Amazon Location Service Developer Guide*:
 *
 * - Static maps
 *
 * - Customize static maps
 *
 * - Overlay on the static map
 */
export declare const getStaticMap: API.OperationMethod<GetStaticMapRequest & RegionInput, GetStaticMapResponse, GetStaticMapError, Credentials | HttpClient.HttpClient>;
export type GetStyleDescriptorError = CommonErrors;
/**
 * `GetStyleDescriptor` returns information about the style.
 *
 * For more information, see Style dynamic maps in the *Amazon Location Service Developer Guide*.
 */
export declare const getStyleDescriptor: API.OperationMethod<GetStyleDescriptorRequest & RegionInput, GetStyleDescriptorResponse, GetStyleDescriptorError, Credentials | HttpClient.HttpClient>;
export type GetTileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `GetTile` returns a tile. Map tiles are used by clients to render a map. They're addressed using a grid arrangement with an X coordinate, Y coordinate, and Z (zoom) level.
 *
 * For more information, see Tiles in the *Amazon Location Service Developer Guide*.
 */
export declare const getTile: API.OperationMethod<GetTileRequest & RegionInput, GetTileResponse, GetTileError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=geo-maps.d.ts.map