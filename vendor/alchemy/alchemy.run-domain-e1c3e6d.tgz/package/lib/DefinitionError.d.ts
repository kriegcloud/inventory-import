declare const DuplicateEventTag_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DuplicateEventTag";
} & Readonly<A>;
/** Two different event classes share a tag. */
export declare class DuplicateEventTag extends DuplicateEventTag_base<{
    readonly tag: string;
}> {
    get message(): string;
}
declare const DuplicateName_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DuplicateName";
} & Readonly<A>;
/** Two aggregates, views or streams share a name. */
export declare class DuplicateName extends DuplicateName_base<{
    readonly entity: string;
}> {
    get message(): string;
}
declare const DuplicateDefinition_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DuplicateDefinition";
} & Readonly<A>;
/** The Domain lists the same aggregate, policy, projection or query twice. */
export declare class DuplicateDefinition extends DuplicateDefinition_base<{
    readonly kind: "aggregate" | "policy" | "projection" | "query" | "rewrite" | "compaction";
    readonly entity: string;
}> {
    get message(): string;
}
declare const InvalidInitial_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvalidInitial";
} & Readonly<A>;
/** An `initial` state its state schema cannot encode. */
export declare class InvalidInitial extends InvalidInitial_base<{
    readonly owner: string;
    readonly cause: unknown;
}> {
    get message(): string;
}
declare const MissingInitial_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "MissingInitial";
} & Readonly<A>;
/** A view declares state but no `initial`. */
export declare class MissingInitial extends MissingInitial_base<{
    readonly view: string;
}> {
    get message(): string;
}
declare const UnknownSource_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnknownSource";
} & Readonly<A>;
/** A view, policy or projection consumes something the Domain does not list. */
export declare class UnknownSource extends UnknownSource_base<{
    readonly consumer: string;
    readonly source: string;
}> {
    get message(): string;
}
declare const ConsumesItself_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ConsumesItself";
} & Readonly<A>;
/** A view consumes its own output through other views. */
export declare class ConsumesItself extends ConsumesItself_base<{
    readonly view: string;
}> {
    get message(): string;
}
declare const MissingKeyOf_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "MissingKeyOf";
} & Readonly<A>;
/** A consumer keyed differently from its source names no `keyOf` for an event. */
export declare class MissingKeyOf extends MissingKeyOf_base<{
    readonly consumer: string;
    readonly event: string;
    readonly source: string;
    /** The aggregate the consumer is keyed by, or undefined for a key schema. */
    readonly keyedBy?: string;
}> {
    get message(): string;
}
declare const UnmatchedRoute_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnmatchedRoute";
} & Readonly<A>;
/** A routed handler names a route that `keyOf` does not produce. */
export declare class UnmatchedRoute extends UnmatchedRoute_base<{
    readonly view: string;
    readonly handler: string;
    readonly source: string;
    readonly route: string;
}> {
    get message(): string;
}
declare const NoEmitter_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NoEmitter";
} & Readonly<A>;
/** A consumer subscribes to an event none of its sources emits. */
export declare class NoEmitter extends NoEmitter_base<{
    readonly consumer: string;
    readonly sources: ReadonlyArray<string>;
    readonly event: string;
}> {
    get message(): string;
}
declare const UnknownStream_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnknownStream";
} & Readonly<A>;
/** A projection writes a stream the Domain does not list. */
export declare class UnknownStream extends UnknownStream_base<{
    readonly writer: string;
    readonly stream: string;
}> {
    get message(): string;
}
declare const TwoWriters_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "TwoWriters";
} & Readonly<A>;
/** Two projections write the same stream. */
export declare class TwoWriters extends TwoWriters_base<{
    readonly stream: string;
    readonly first: string;
    readonly second: string;
}> {
    get message(): string;
}
declare const WriterKeyMismatch_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "WriterKeyMismatch";
} & Readonly<A>;
/** A projection writes a stream keyed differently from itself. */
export declare class WriterKeyMismatch extends WriterKeyMismatch_base<{
    readonly writer: string;
    readonly key: string;
    readonly stream: string;
    readonly streamKey: string;
}> {
    get message(): string;
}
declare const NoJsonForm_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NoJsonForm";
} & Readonly<A>;
/** A schema in a state, command, event, reply or rejection has no JSON form. */
export declare class NoJsonForm extends NoJsonForm_base<{
    /** Where the schema is, such as `Order.state.placedAt`. */
    readonly path: string;
}> {
    get message(): string;
}
declare const InitialNotJson_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InitialNotJson";
} & Readonly<A>;
/** An `initial` state that does not come back the same after a trip through JSON. */
export declare class InitialNotJson extends InitialNotJson_base<{
    readonly owner: string;
    /** Why: the JSON error, or the JSON text that comes back different. */
    readonly detail: string;
}> {
    get message(): string;
}
declare const UnhandledCommand_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnhandledCommand";
} & Readonly<A>;
/** An aggregate receives a command it does not list. */
export declare class UnhandledCommand extends UnhandledCommand_base<{
    readonly aggregate: string;
    readonly command: string;
}> {
    get message(): string;
}
declare const UnroutedCommand_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnroutedCommand";
} & Readonly<A>;
/** An Api exposes a command no aggregate in the Domain handles. */
export declare class UnroutedCommand extends UnroutedCommand_base<{
    readonly command: string;
}> {
    get message(): string;
}
declare const ImplementedTwice_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ImplementedTwice";
} & Readonly<A>;
/** Two aggregates or decisions of one model implement the same command. */
export declare class ImplementedTwice extends ImplementedTwice_base<{
    readonly command: string;
    readonly first: string;
    readonly second: string;
}> {
    get message(): string;
}
declare const UnknownRead_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnknownRead";
} & Readonly<A>;
/** A decision reads an aggregate its model does not host. */
export declare class UnknownRead extends UnknownRead_base<{
    readonly decision: string;
    readonly aggregate: string;
}> {
    get message(): string;
}
declare const UnreadRecord_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnreadRecord";
} & Readonly<A>;
/** A decision records an event on an instance it did not read. */
export declare class UnreadRecord extends UnreadRecord_base<{
    readonly decision: string;
    readonly returned: string;
}> {
    get message(): string;
}
declare const DecisionsUnsupported_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DecisionsUnsupported";
} & Readonly<A>;
/** The platform a model is hosted on can't commit decisions. */
export declare class DecisionsUnsupported extends DecisionsUnsupported_base<{
    readonly decisions: ReadonlyArray<string>;
}> {
    get message(): string;
}
declare const UndeclaredDecision_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UndeclaredDecision";
} & Readonly<A>;
/** `decide` returns an event or rejection its command does not declare. */
export declare class UndeclaredDecision extends UndeclaredDecision_base<{
    readonly aggregate: string;
    readonly command: string;
    readonly returned: string;
    readonly list: "events" | "rejects";
}> {
    get message(): string;
}
declare const UndeclaredEvent_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UndeclaredEvent";
} & Readonly<A>;
/** An aggregate commits an event it does not declare. */
export declare class UndeclaredEvent extends UndeclaredEvent_base<{
    readonly aggregate: string;
    readonly event: string;
}> {
    get message(): string;
}
declare const UndeclaredEmit_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UndeclaredEmit";
} & Readonly<A>;
/** A view's `emit` returns an event its `events` do not list. */
export declare class UndeclaredEmit extends UndeclaredEmit_base<{
    readonly view: string;
    readonly event: string;
}> {
    get message(): string;
}
declare const UnknownEvent_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnknownEvent";
} & Readonly<A>;
/** A stored event's tag matches no event in the Domain. */
export declare class UnknownEvent extends UnknownEvent_base<{
    readonly event: string;
}> {
    get message(): string;
}
declare const UnknownRequestContext_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnknownRequestContext";
} & Readonly<A>;
/** A request carries a context service nothing registered. */
export declare class UnknownRequestContext extends UnknownRequestContext_base<{
    readonly key: string;
}> {
    get message(): string;
}
declare const ReservedOperation_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ReservedOperation";
} & Readonly<A>;
/** An external system declares an operation named after a static of its class. */
export declare class ReservedOperation extends ReservedOperation_base<{
    readonly system: string;
    readonly operation: string;
}> {
    get message(): string;
}
declare const ReservedMember_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ReservedMember";
} & Readonly<A>;
/** A model's command, aggregate or view is named after a static of the model's class. */
export declare class ReservedMember extends ReservedMember_base<{
    readonly model: string;
    readonly member: string;
}> {
    get message(): string;
}
declare const MissingWorkflowEngine_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "MissingWorkflowEngine";
} & Readonly<A>;
/** The Domain has sagas, but the platform runs no workflows. */
export declare class MissingWorkflowEngine extends MissingWorkflowEngine_base<{
    readonly sagas: ReadonlyArray<string>;
}> {
    get message(): string;
}
declare const UnvalidatedRead_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnvalidatedRead";
} & Readonly<A>;
/** A view or stream guards its reads, but no Layer provides its `validate`. */
export declare class UnvalidatedRead extends UnvalidatedRead_base<{
    readonly entity: string;
}> {
    get message(): string;
}
declare const ForeignAppend_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ForeignAppend";
} & Readonly<A>;
/** Something other than the stream's writer, handling its input, appends to it. */
export declare class ForeignAppend extends ForeignAppend_base<{
    readonly stream: string;
}> {
    get message(): string;
}
declare const NotInModel_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NotInModel";
} & Readonly<A>;
/** An Api names something its model does not hold. */
export declare class NotInModel extends NotInModel_base<{
    readonly entity: string;
    readonly model: string;
}> {
    get message(): string;
}
declare const ToolNameTooLong_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ToolNameTooLong";
} & Readonly<A>;
/** An Api call makes a tool name longer than model providers accept. */
export declare class ToolNameTooLong extends ToolNameTooLong_base<{
    readonly tool: string;
    readonly max: number;
}> {
    get message(): string;
}
declare const DuplicateTool_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DuplicateTool";
} & Readonly<A>;
/** Two calls of an Api make the same tool name. */
export declare class DuplicateTool extends DuplicateTool_base<{
    readonly api: string;
    readonly tool: string;
}> {
    get message(): string;
}
declare const ReservedFlag_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ReservedFlag";
} & Readonly<A>;
/** A payload field would be a flag the CLI reserves. */
export declare class ReservedFlag extends ReservedFlag_base<{
    readonly call: string;
    readonly field: string;
    readonly flag: string;
}> {
    get message(): string;
}
declare const DuplicateFlag_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DuplicateFlag";
} & Readonly<A>;
/** Two payload fields would be the same CLI flag. */
export declare class DuplicateFlag extends DuplicateFlag_base<{
    readonly call: string;
    readonly field: string;
    readonly flag: string;
    readonly taken: string;
}> {
    get message(): string;
}
declare const DuplicateCommand_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DuplicateCommand";
} & Readonly<A>;
/** Two calls of an Api would be the same CLI command. */
export declare class DuplicateCommand extends DuplicateCommand_base<{
    readonly api: string;
    readonly first: string;
    readonly second: string;
    readonly command: string;
}> {
    get message(): string;
}
declare const MissingGroup_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "MissingGroup";
} & Readonly<A>;
/** An Api's HttpApi group is served from an HttpApi that does not hold it. */
export declare class MissingGroup extends MissingGroup_base<{
    readonly httpApi: string;
    readonly group: string;
}> {
    get message(): string;
}
declare const NewerGeneration_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NewerGeneration";
} & Readonly<A>;
/** A consumer receives a delivery for a newer generation than the code it runs. */
export declare class NewerGeneration extends NewerGeneration_base<{
    readonly consumer: string;
    readonly sent: number;
    readonly runs: number;
}> {
    get message(): string;
}
declare const ModelHostedTwice_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ModelHostedTwice";
} & Readonly<A>;
/** Two different models with the same name are hosted on one platform, so they would share storage. */
export declare class ModelHostedTwice extends ModelHostedTwice_base<{
    readonly model: string;
}> {
    get message(): string;
}
declare const LazyViewNeedsOneSource_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "LazyViewNeedsOneSource";
} & Readonly<A>;
/** A view set to fill lazily isn't keyed by its one source, so a key can't find its own history. */
export declare class LazyViewNeedsOneSource extends LazyViewNeedsOneSource_base<{
    readonly view: string;
}> {
    get message(): string;
}
declare const PagedWithoutSuccess_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "PagedWithoutSuccess";
} & Readonly<A>;
/** A query is `paged` but declares no `success`: a page needs the schema of its entries. */
export declare class PagedWithoutSuccess extends PagedWithoutSuccess_base<{
    readonly query: string;
}> {
    get message(): string;
}
declare const UnknownWait_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnknownWait";
} & Readonly<A>;
/** A query waits for a projection, view or stream the Domain does not list. */
export declare class UnknownWait extends UnknownWait_base<{
    readonly query: string;
    readonly read: string;
}> {
    get message(): string;
}
declare const UnknownAggregate_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnknownAggregate";
} & Readonly<A>;
/** A rewrite or compaction is of an aggregate the Domain does not list. */
export declare class UnknownAggregate extends UnknownAggregate_base<{
    readonly owner: string;
    readonly aggregate: string;
}> {
    get message(): string;
}
declare const UnlistedRewrite_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnlistedRewrite";
} & Readonly<A>;
/** A rewrite or compaction is run that the Domain does not list. */
export declare class UnlistedRewrite extends UnlistedRewrite_base<{
    readonly kind: "rewrite" | "compaction";
    readonly entity: string;
}> {
    get message(): string;
}
declare const InvalidRewrite_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvalidRewrite";
} & Readonly<A>;
/** A rewrite handler returned neither an event nor `null`. */
export declare class InvalidRewrite extends InvalidRewrite_base<{
    readonly rewrite: string;
    readonly event: string;
}> {
    get message(): string;
}
declare const MissingRewriteHandler_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "MissingRewriteHandler";
} & Readonly<A>;
/**
 * A rewrite changes events a projection was given, and the projection's
 * Layer has no `rewrite` handler to say what that means for its store.
 */
export declare class MissingRewriteHandler extends MissingRewriteHandler_base<{
    readonly projection: string;
    readonly rewrite: string;
}> {
    get message(): string;
}
/** Every reason a {@link DefinitionError} has. */
export type Reason = DuplicateEventTag | DuplicateName | DuplicateDefinition | InvalidInitial | MissingInitial | UnknownSource | ConsumesItself | MissingKeyOf | UnmatchedRoute | NoEmitter | UnknownStream | TwoWriters | WriterKeyMismatch | NoJsonForm | InitialNotJson | UnhandledCommand | UnroutedCommand | ImplementedTwice | UnknownRead | UnreadRecord | DecisionsUnsupported | UndeclaredDecision | UndeclaredEvent | UndeclaredEmit | UnknownEvent | UnknownRequestContext | ReservedOperation | ReservedMember | MissingWorkflowEngine | ForeignAppend | NotInModel | ToolNameTooLong | DuplicateTool | ReservedFlag | DuplicateFlag | DuplicateCommand | MissingGroup | NewerGeneration | ModelHostedTwice | LazyViewNeedsOneSource | PagedWithoutSuccess | UnknownWait | UnvalidatedRead | UnknownAggregate | UnlistedRewrite | InvalidRewrite | MissingRewriteHandler;
declare const DefinitionError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DefinitionError";
} & Readonly<A>;
/**
 * A domain definition error, found while the kernel is built or when a
 * handler returns something its declaration does not allow. Its `reason`
 * says which problem it is: match it with `Effect.catchReason`.
 */
export declare class DefinitionError extends DefinitionError_base<{
    readonly reason: Reason;
}> {
    get message(): string;
}
export {};
//# sourceMappingURL=DefinitionError.d.ts.map