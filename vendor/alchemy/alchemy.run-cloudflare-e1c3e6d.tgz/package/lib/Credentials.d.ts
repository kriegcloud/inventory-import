import { Credentials, type ResolvedCredentials } from "@distilled.cloud/cloudflare/Credentials";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
export { Credentials, fromEnv } from "@distilled.cloud/cloudflare/Credentials";
declare module "@distilled.cloud/cloudflare/Credentials" {
    interface Credentials {
        readonly kind: "Credentials";
    }
}
/**
 * Memoize a credentials-resolution effect until shortly before the resolved
 * credentials expire — see {@link CredentialsCache.cacheUntilExpiry} for the
 * caching rules. Non-OAuth credentials (API token / global key) never expire
 * and cache forever.
 */
export declare const cacheUntilExpiry: <E>(resolve: Effect.Effect<ResolvedCredentials, E>) => Effect.Effect<Effect.Effect<ResolvedCredentials, E, never>, never, never>;
/**
 * Build a `Credentials` layer that resolves Cloudflare credentials via the
 * Alchemy AuthProvider using the configured profile (defaults to "default",
 * selected by the current Alchemy profile).
 *
 * `auth.read` refreshes and persists expired OAuth tokens when it is re-run,
 * so expiry-aware caching (instead of caching the first resolution forever)
 * is what keeps long-lived dev sessions authenticated across the ~1h
 * access-token lifetime.
 */
export declare const fromAuthProvider: () => Layer.Layer<Credentials, never, import("alchemy").AuthProviders | import("alchemy/Auth/Profile").ProfileStore>;
//# sourceMappingURL=Credentials.d.ts.map