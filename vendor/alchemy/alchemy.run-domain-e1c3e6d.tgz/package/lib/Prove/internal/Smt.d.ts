import * as Effect from "effect/Effect";
import type * as Scope from "effect/Scope";
/** The sorts the prover gives a TypeScript value. */
export type Sort = "Int" | "Real" | "Bool" | "String";
/** A formula or value in the solver's language (SMT-LIB text) and its sort. */
export interface Term {
    readonly sort: Sort;
    readonly text: string;
}
/** A symbol, quoted so any TypeScript name is one. */
export declare const symbol: (name: string) => string;
export declare const int: (n: number) => Term;
/** A `bigint`, which is a whole number of any size. */
export declare const big: (n: bigint) => Term;
export declare const real: (n: number) => Term;
export declare const string: (value: string) => Term;
export declare const bool: (value: boolean) => Term;
export declare const not: (term: string) => string;
declare const SolverError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "SolverError";
} & Readonly<A>;
/** The solver could not be loaded, or answered with an error. */
export declare class SolverError extends SolverError_base<{
    readonly message: string;
}> {
}
/** A parsed piece of the solver's output. */
export type Sexp = {
    readonly _tag: "Atom";
    readonly text: string;
} | {
    readonly _tag: "Text";
    readonly value: string;
} | {
    readonly _tag: "List";
    readonly items: ReadonlyArray<Sexp>;
};
/** Parse the solver's output: a sequence of S-expressions. */
export declare const parse: (input: string) => ReadonlyArray<Sexp>;
/** The JavaScript value of a value the solver printed, or `undefined` when it is not one. */
export declare const valueOf: (sexp: Sexp) => number | bigint | string | boolean | undefined;
/** One whole number over another: a number the solver found, exactly. */
export interface Fraction {
    readonly numerator: bigint;
    readonly denominator: bigint;
}
/** A number the solver printed, exactly: `undefined` when it is not a number. */
export declare const fractionOf: (sexp: Sexp) => Fraction | undefined;
/**
 * The numbers of a model, exactly. A model gives each as a `number`, which
 * rounds a third; a decimal and a fraction are built from these instead.
 */
export declare const exact: WeakMap<object, ReadonlyMap<string, Fraction>>;
/** One question for the solver: can every assertion hold at once? */
export interface Query {
    readonly declarations: ReadonlyArray<string>;
    readonly assertions: ReadonlyArray<string>;
    /** Terms to read back when the answer is `Sat`. */
    readonly values: ReadonlyArray<string>;
}
export type Answer = {
    readonly _tag: "Unsat";
} | {
    readonly _tag: "Sat";
    readonly values: ReadonlyArray<number | bigint | string | boolean | undefined>;
    /** Each value that is a number, exactly. */
    readonly fractions: ReadonlyArray<Fraction | undefined>;
} | {
    readonly _tag: "Unknown";
    readonly reason: string;
};
export interface Solver {
    readonly check: (query: Query) => Effect.Effect<Answer, SolverError>;
}
/**
 * Z3, compiled to WebAssembly. One instance serves every query, each in a
 * solver of its own; it is torn down with the scope.
 *
 * A query is loaded with `solver_from_string`, which reads the text before it
 * returns. Z3's `eval_smtlib2_string` hands the text to another thread and
 * frees it first, so now and then the solver reads garbage.
 */
export declare const solver: Effect.Effect<Solver, SolverError, Scope.Scope>;
export {};
//# sourceMappingURL=Smt.d.ts.map