import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface AddressValidationRequest {
    /** Address line 1. */
    address?: string | undefined;
    /** Address line 2. */
    address2?: string | undefined;
    /** City. */
    city?: string | undefined;
    /** Country code. */
    country?: string | undefined;
    /** State or province. */
    state?: string | undefined;
    /** Postal or zip code. */
    zipcode?: string | undefined;
}
export interface AddressValidationResponseValidatedAddressesItem {
    /** Validated address line 1. */
    address?: string | null | undefined;
    /** Validated address line 2. */
    address2?: string | null | undefined;
    /** Validated city. */
    city?: string | null | undefined;
    /** Validated country code. */
    country?: string | null | undefined;
    /** Validated state or province. */
    state?: string | null | undefined;
    /** The validation result code. */
    validationCode?: string | null | undefined;
    /** Validated postal or zip code. */
    zipcode?: string | null | undefined;
}
export type AddressValidationResponseValidatedAddressesList = Array<AddressValidationResponseValidatedAddressesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface AddressValidationResponse {
    /** List of validated address suggestions. */
    validatedAddresses?: AddressValidationResponseValidatedAddressesList | null | undefined;
}
export interface CreateProfileRequest {
    /** Identifier */
    accountId: string;
    /** Street address line 1. */
    address?: string | undefined;
    /** Street address line 2 (apt, suite, etc.). */
    address2?: string | undefined;
    /** Primary billing email address. */
    billingEmail?: string | undefined;
    /** Rate plan being purchased right after profile setup. */
    buyingRatePlan?: string | undefined;
    /** Captcha challenge JWT issued during onboarding. */
    captchaChallengeJwt?: string | undefined;
    /** Cloudflare Turnstile response. */
    cfTurnstileResponse?: string | undefined;
    /** City on the billing profile. */
    city?: string | undefined;
    /** Company name on the billing profile. */
    company?: string | undefined;
    /** ISO 3166-1 alpha-2 country code. */
    country?: string | undefined;
    /** First name on the billing profile. */
    firstName?: string | undefined;
    /** hCaptcha response. */
    hCaptchaResponse?: string | undefined;
    /** Last name on the billing profile. */
    lastName?: string | undefined;
    /** Preferred locale for invoice rendering (BCP 47). */
    preferredLocale?: string | undefined;
    /** Secondary billing email address for CC on invoices. */
    secondaryBillingEmail?: string | undefined;
    /** State or region on the billing profile. */
    state?: string | undefined;
    /** Type of tax ID provided. */
    taxIdType?: string | undefined;
    /** Contact phone number. */
    telephone?: string | undefined;
    /** VAT identifier. */
    vat?: string | undefined;
    /** ZIP or postal code. */
    zipcode?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null | undefined;
    accountType?: string | null | undefined;
    address?: string | null | undefined;
    address2?: string | null | undefined;
    balance?: string | null | undefined;
    cardExpiryMonth?: number | null | undefined;
    cardExpiryYear?: number | null | undefined;
    cardNumber?: string | null | undefined;
    city?: string | null | undefined;
    company?: string | null | undefined;
    country?: string | null | undefined;
    createdOn?: string | null | undefined;
    deviceData?: string | null | undefined;
    editedOn?: string | null | undefined;
    enterpriseBillingEmail?: string | null | undefined;
    enterprisePrimaryEmail?: string | null | undefined;
    firstName?: string | null | undefined;
    isPartner?: boolean | null | undefined;
    lastName?: string | null | undefined;
    nextBillDate?: string | null | undefined;
    paymentAddress?: string | null | undefined;
    paymentAddress2?: string | null | undefined;
    paymentCity?: string | null | undefined;
    paymentCountry?: string | null | undefined;
    paymentEmail?: string | null | undefined;
    paymentFirstName?: string | null | undefined;
    paymentGateway?: string | null | undefined;
    paymentLastName?: string | null | undefined;
    paymentNonce?: string | null | undefined;
    paymentState?: string | null | undefined;
    paymentZipcode?: string | null | undefined;
    primaryEmail?: string | null | undefined;
    state?: string | null | undefined;
    taxIdType?: string | null | undefined;
    telephone?: string | null | undefined;
    validationCode?: string | null | undefined;
    vat?: string | null | undefined;
    zipcode?: string | null | undefined;
}
export interface CreateProfilesPaymentMethodRequest {
    /** Identifier */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateProfilesPaymentMethodResponse {
    /** The Stripe client secret for frontend payment method collection. */
    clientSecret?: string | null | undefined;
    /** The type of Stripe intent created. */
    intentType?: string | null | undefined;
}
export type CreateSpendPolicyRequestAction = "notification" | "usage_block";
export type CreateSpendPolicyRequestProductId = "workers" | "durable_objects";
export interface CreateSpendPolicyRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: CreateSpendPolicyRequestAction | (string & {});
    /** Whether the policy is evaluated. */
    enabled: boolean;
    /** Display name of the policy. After surrounding whitespace is trimmed, it must be 1 to 200 bytes long. The value is stored as sent, untrimmed. */
    name: string;
    /** The product the policy applies to: `workers` or `durable_objects`. Each product's balance and policies are separate. Both products support `notification` and `usage_block` policies on create and update. */
    productId: CreateSpendPolicyRequestProductId | (string & {});
    /** The spend threshold for the current billing period, in US cents. Must be greater than zero. */
    thresholdCents: number;
    /** Email address that receives notifications. Required when `action` is `notification`. When set, it must be a bare address (`user@example.com`); display-name forms such as `Name <user@example.com>` are rejected. */
    notificationEmail?: string | undefined;
}
export type CreateSpendPolicyResponseAction = "notification" | "usage_block";
export type CreateSpendPolicyResponseProductId = "workers" | "durable_objects";
export type CreateSpendPolicyResponseCurrentStateEnforcementDeliveryStatus = "pending" | "leased" | "retry" | "succeeded";
export type CreateSpendPolicyResponseCurrentStateEnforcementDesiredState = "active" | "inactive";
export interface CreateSpendPolicyResponseCurrentStateEnforcement {
    appliedGeneration: number;
    deliveryStatus: CreateSpendPolicyResponseCurrentStateEnforcementDeliveryStatus;
    desiredGeneration: number;
    desiredState: CreateSpendPolicyResponseCurrentStateEnforcementDesiredState;
    expiresAt: string;
}
export type CreateSpendPolicyResponseCurrentStateStatus = "disabled" | "no_current_period" | "unavailable" | "below_limit" | "limit_reached";
export interface CreateSpendPolicyResponseCurrentState {
    balanceCents: number;
    billingPeriodEnd: string;
    billingPeriodStart: string;
    /** Durable desired cap and delivery bookkeeping for this policy, or null if no owned effect exists. Separate from threshold evaluation: pending/leased/retry can lag the new billing period. Succeeded with equal generations means delivery completed, not an EWC readback. */
    enforcement: CreateSpendPolicyResponseCurrentStateEnforcement;
    /** Evaluation time; not the timestamp of the latest usage event. */
    evaluatedAt: string;
    /** Threshold evaluation, not proof of an edge cap. No current active period yields no_current_period for enabled policies; failed aggregate reads yield unavailable for enabled policies. Disabled policies report disabled. Neither no_current_period nor unavailable implies a zero balance or below-limit state. Operators may disable current-state reads, in which case current_state is omitted. */
    status: CreateSpendPolicyResponseCurrentStateStatus;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSpendPolicyResponse {
    /** The unique identifier of the spend policy. */
    id: string;
    /** Internal numeric ID of the account that owns the policy. This is not the account tag used in the path. */
    accountId: number;
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: CreateSpendPolicyResponseAction;
    /** Whether the policy is evaluated. */
    enabled: boolean;
    /** Display name of the policy. */
    name: string;
    /** Email address that receives notifications. An empty string when none is set. */
    notificationEmail: string;
    /** The product the policy applies to: `workers` or `durable_objects`. Each product's balance and policies are separate. Both products support `notification` and `usage_block` policies on create and update. */
    productId: CreateSpendPolicyResponseProductId;
    /** The spend threshold for the current billing period, in US cents. */
    thresholdCents: number;
    /** Optimistic-concurrency version. It starts at 1 and goes up by one on every update or delete. This value is also returned in `ETag`. */
    version: number;
    /** Read-only state on list/get responses, evaluated from the latest owning projector snapshot at request time, independently of the API replica. Configuration enabled/version/ETag do not change when a cycle rolls over. Audit history remains unchanged. Missing during a rolling upgrade or on mutation responses; clients must treat missing state as unavailable. Balances are asynchronous estimates, not a synchronous usage read. */
    currentState?: CreateSpendPolicyResponseCurrentState | null | undefined;
}
export interface DeleteProfileRequest {
    /** Identifier */
    accountId: string;
}
export interface DeleteProfileResponse {
}
export interface DeleteSpendPolicyRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** The unique identifier of the spend policy. */
    policyId: string;
    ifMatch: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSpendPolicyResponse {
    /** The unique identifier of the spend policy. */
    id: string;
}
export interface GetBadDebtRequest {
    /** Identifier */
    accountId: string;
}
export interface GetBadDebtResponseInvoicesItem {
    /** Billing history item identifier. */
    id?: string | null | undefined;
    /** The billing item action. */
    action?: string | null | undefined;
    /** The amount associated with this billing item. */
    amount?: number | null | undefined;
    /** The amount remaining to pay. */
    amountToPay?: number | null | undefined;
    /** The currency of the billing item. */
    currency?: string | null | undefined;
    /** The billing item description. */
    description?: string | null | undefined;
    /** The external invoice identifier. */
    externalInvoiceId?: string | null | undefined;
    /** URL to the hosted invoice. */
    hostedInvoiceUrl?: string | null | undefined;
    /** The associated invoice identifier. */
    invoiceId?: string | null | undefined;
    /** When the billing event occurred. */
    occurredAt?: string | null | undefined;
    /** The associated receipt identifier. */
    receiptId?: string | null | undefined;
    /** The source of the billing item. */
    source?: string | null | undefined;
    /** The source invoice identifier. */
    sourceInvoiceId?: string | null | undefined;
    /** The status of the billing item. */
    status?: string | null | undefined;
    /** The billing item type. */
    type?: string | null | undefined;
}
export type GetBadDebtResponseInvoicesList = Array<GetBadDebtResponseInvoicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBadDebtResponse {
    /** Amount already paid towards the debt. */
    alreadyPaid?: number | null | undefined;
    /** The current bad debt status of the account. */
    badDebtStatus?: string | null | undefined;
    /** List of outstanding invoices contributing to bad debt. */
    invoices?: GetBadDebtResponseInvoicesList | null | undefined;
    /** Total outstanding debt amount. */
    totalDebtAmount?: number | null | undefined;
}
export interface GetCreditRequest {
    /** Identifier */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCreditResponse {
    /** The confirmed credit balance in cents. */
    confirmedBalanceCents?: number | null | undefined;
    /** Currency of the credit balance. */
    currency?: string | null | undefined;
    /** Days remaining until the credits expire. */
    daysRemaining?: number | null | undefined;
    /** Whether the account is eligible to receive credits. */
    eligible?: boolean | null | undefined;
    /** Whether a credit record exists for the account. */
    hasRecord?: boolean | null | undefined;
    /** The original credit amount in cents. */
    originalAmountCents?: number | null | undefined;
    /** Percentage of the original credit amount consumed. */
    percentConsumed?: number | null | undefined;
    /** Projected date when the credits will be depleted. */
    projectedDepletionDate?: string | null | undefined;
    /** When the credits become valid. */
    validFrom?: string | null | undefined;
    /** When the credits expire. */
    validTo?: string | null | undefined;
}
export interface GetProfileRequest {
    /** Identifier */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null | undefined;
    accountType?: string | null | undefined;
    address?: string | null | undefined;
    address2?: string | null | undefined;
    balance?: string | null | undefined;
    cardExpiryMonth?: number | null | undefined;
    cardExpiryYear?: number | null | undefined;
    cardNumber?: string | null | undefined;
    city?: string | null | undefined;
    company?: string | null | undefined;
    country?: string | null | undefined;
    createdOn?: string | null | undefined;
    deviceData?: string | null | undefined;
    editedOn?: string | null | undefined;
    enterpriseBillingEmail?: string | null | undefined;
    enterprisePrimaryEmail?: string | null | undefined;
    firstName?: string | null | undefined;
    isPartner?: boolean | null | undefined;
    lastName?: string | null | undefined;
    nextBillDate?: string | null | undefined;
    paymentAddress?: string | null | undefined;
    paymentAddress2?: string | null | undefined;
    paymentCity?: string | null | undefined;
    paymentCountry?: string | null | undefined;
    paymentEmail?: string | null | undefined;
    paymentFirstName?: string | null | undefined;
    paymentGateway?: string | null | undefined;
    paymentLastName?: string | null | undefined;
    paymentNonce?: string | null | undefined;
    paymentState?: string | null | undefined;
    paymentZipcode?: string | null | undefined;
    primaryEmail?: string | null | undefined;
    state?: string | null | undefined;
    taxIdType?: string | null | undefined;
    telephone?: string | null | undefined;
    validationCode?: string | null | undefined;
    vat?: string | null | undefined;
    zipcode?: string | null | undefined;
}
export interface GetRatePlanRequest {
    publicKey: string;
}
export type GetRatePlanResponseComponentsItemMap = {
    [key: string]: unknown | undefined;
};
export type GetRatePlanResponseComponentsList = Array<GetRatePlanResponseComponentsItemMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRatePlanResponse {
    /** The uppercase rate plan public key. */
    id?: string | null | undefined;
    /** Pricing components that make up this rate plan. */
    components?: GetRatePlanResponseComponentsList | null | undefined;
    /** Currency of the rate plan pricing. */
    currency?: string | null | undefined;
    /** Human-readable description of the rate plan. */
    publicName?: string | null | undefined;
}
export interface GetSpendPolicyRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** The unique identifier of the spend policy. */
    policyId: string;
}
export type GetSpendPolicyResponseAction = "notification" | "usage_block";
export type GetSpendPolicyResponseProductId = "workers" | "durable_objects";
export type GetSpendPolicyResponseCurrentStateEnforcementDeliveryStatus = "pending" | "leased" | "retry" | "succeeded";
export type GetSpendPolicyResponseCurrentStateEnforcementDesiredState = "active" | "inactive";
export interface GetSpendPolicyResponseCurrentStateEnforcement {
    appliedGeneration: number;
    deliveryStatus: GetSpendPolicyResponseCurrentStateEnforcementDeliveryStatus;
    desiredGeneration: number;
    desiredState: GetSpendPolicyResponseCurrentStateEnforcementDesiredState;
    expiresAt: string;
}
export type GetSpendPolicyResponseCurrentStateStatus = "disabled" | "no_current_period" | "unavailable" | "below_limit" | "limit_reached";
export interface GetSpendPolicyResponseCurrentState {
    balanceCents: number;
    billingPeriodEnd: string;
    billingPeriodStart: string;
    /** Durable desired cap and delivery bookkeeping for this policy, or null if no owned effect exists. Separate from threshold evaluation: pending/leased/retry can lag the new billing period. Succeeded with equal generations means delivery completed, not an EWC readback. */
    enforcement: GetSpendPolicyResponseCurrentStateEnforcement;
    /** Evaluation time; not the timestamp of the latest usage event. */
    evaluatedAt: string;
    /** Threshold evaluation, not proof of an edge cap. No current active period yields no_current_period for enabled policies; failed aggregate reads yield unavailable for enabled policies. Disabled policies report disabled. Neither no_current_period nor unavailable implies a zero balance or below-limit state. Operators may disable current-state reads, in which case current_state is omitted. */
    status: GetSpendPolicyResponseCurrentStateStatus;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSpendPolicyResponse {
    /** The unique identifier of the spend policy. */
    id: string;
    /** Internal numeric ID of the account that owns the policy. This is not the account tag used in the path. */
    accountId: number;
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: GetSpendPolicyResponseAction;
    /** Whether the policy is evaluated. */
    enabled: boolean;
    /** Display name of the policy. */
    name: string;
    /** Email address that receives notifications. An empty string when none is set. */
    notificationEmail: string;
    /** The product the policy applies to: `workers` or `durable_objects`. Each product's balance and policies are separate. Both products support `notification` and `usage_block` policies on create and update. */
    productId: GetSpendPolicyResponseProductId;
    /** The spend threshold for the current billing period, in US cents. */
    thresholdCents: number;
    /** Optimistic-concurrency version. It starts at 1 and goes up by one on every update or delete. This value is also returned in `ETag`. */
    version: number;
    /** Read-only state on list/get responses, evaluated from the latest owning projector snapshot at request time, independently of the API replica. Configuration enabled/version/ETag do not change when a cycle rolls over. Audit history remains unchanged. Missing during a rolling upgrade or on mutation responses; clients must treat missing state as unavailable. Balances are asynchronous estimates, not a synchronous usage read. */
    currentState?: GetSpendPolicyResponseCurrentState | null | undefined;
}
export interface GetUnpaidInvoiceRequest {
    /** Identifier */
    accountId: string;
}
export type GetUnpaidInvoiceResponseInvoicesItem = GetBadDebtResponseInvoicesItem;
export type GetUnpaidInvoiceResponseInvoicesList = Array<GetBadDebtResponseInvoicesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUnpaidInvoiceResponse {
    /** List of unpaid invoices. */
    invoices?: GetUnpaidInvoiceResponseInvoicesList | null | undefined;
}
export interface GetUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). Required if `to` is set. When omitted along with `to`, defaults to the start of the current month. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    from?: string | undefined;
    /** End date for the usage query (ISO 8601). Required if `from` is set. When omitted along with `from`, defaults to today. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    to?: string | undefined;
}
export type UsageGetResultItemChargeCategory = "Usage";
export type UsageGetResultItemChargeFrequency = "Usage-Based";
export type UsageGetResultItemChargeClass = "Correction";
export type UsageGetResultItemTagsValue = string | boolean;
export type UsageGetResultItemTagsMap = {
    [key: string]: UsageGetResultItemTagsValue | undefined;
};
export interface UsageGetResultItem {
    /** Highest-level classification of a charge based on the nature of how it gets billed. Currently only "Usage" is supported. */
    chargeCategory: UsageGetResultItemChargeCategory;
    /** Self-contained summary of the charge's purpose and price. */
    chargeDescription: string;
    /** Indicates how often a charge occurs. Currently only "Usage-Based" is supported. */
    chargeFrequency: UsageGetResultItemChargeFrequency;
    /** Exclusive end of the time interval during which the usage was consumed. */
    chargePeriodEnd: string;
    /** Inclusive start of the time interval during which the usage was consumed. */
    chargePeriodStart: string;
    /** Unit of measure for the consumed quantity (e.g., "GB", "Requests", "vCPU-Hours"). */
    consumedUnit: string;
    /** Name of the entity providing the underlying infrastructure or platform. */
    hostProviderName: string;
    /** Name of the entity responsible for invoicing for the services consumed. */
    invoiceIssuerName: string;
    /** Name of the entity that made the services available for purchase. */
    serviceProviderName: string;
    /** The unique identifier for the billable metric in the Cloudflare catalog. Cloudflare extension; replaces FOCUS SkuId. */
    xBillableMetricId: string;
    /** A charge serving as the basis for invoicing, inclusive of all reduced rates and discounts while excluding the amortization of upfront charges (one-time or recurring). */
    billedCost?: number | null | undefined;
    /** Public identifier of the Cloudflare account (account tag). Omitted when account is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by account: that usage is returned as its own record with no account. */
    billingAccountId?: string | null | undefined;
    /** Display name of the Cloudflare account. Omitted when account is not part of the requested grouping, and for usage measured at contract level. */
    billingAccountName?: string | null | undefined;
    /** Currency that a charge was billed in (ISO 4217). */
    billingCurrency?: string | null | undefined;
    /** Exclusive end of the billing cycle that contains this usage record. */
    billingPeriodEnd?: string | null | undefined;
    /** Inclusive start of the billing cycle that contains this usage record. */
    billingPeriodStart?: string | null | undefined;
    /** Indicates whether the row represents a correction to one or more charges invoiced in a previous billing period. */
    chargeClass?: UsageGetResultItemChargeClass | null | undefined;
    /** Measured usage amount within the charge period. Reflects raw metered consumption before pricing transformations. */
    consumedQuantity?: number | null | undefined;
    /** Cost calculated by multiplying ContractedUnitPrice and the corresponding PricingQuantity. */
    contractedCost?: number | null | undefined;
    /** The agreed-upon unit price for a single PricingUnit of the associated billable metric, inclusive of negotiated discounts, if present, while excluding any other discounts. */
    contractedUnitPrice?: number | null | undefined;
    /** The amortized cost of the charge after applying all reduced rates, discounts, and the applicable portion of relevant, prepaid purchases (one-time or recurring) that covered the charge. */
    effectiveCost?: number | null | undefined;
    /** Cost calculated by multiplying ListUnitPrice and the corresponding PricingQuantity. */
    listCost?: number | null | undefined;
    /** Suggested provider-published unit price for a single PricingUnit of the associated billable metric, exclusive of any discounts. */
    listUnitPrice?: number | null | undefined;
    /** Volume of a given service used or purchased, based on the PricingUnit. */
    pricingQuantity?: number | null | undefined;
    /** Provider-specified measurement unit for determining unit prices, indicating how the provider rates measured usage after applying pricing rules like block pricing. */
    pricingUnit?: string | null | undefined;
    /** Provider-assigned identifier for an isolated geographic area where a service is provided. */
    regionId?: string | null | undefined;
    /** Name of an isolated geographic area where a service is provided. */
    regionName?: string | null | undefined;
    /** Unique identifier assigned to a grouping of services. For Cloudflare, this is the subscription or contract ID. */
    subAccountId?: string | null | undefined;
    /** Name assigned to a grouping of services. For Cloudflare, this is the subscription or contract display name. */
    subAccountName?: string | null | undefined;
    /** Tag values for the requested `GroupBy` keys. Omitted when `GroupBy` is not provided. Missing keys are omitted, and key-only tags are returned as boolean `true`. All other tag values are strings. */
    tags?: UsageGetResultItemTagsMap | null | undefined;
    /** The display name of the billable metric. Cloudflare extension; replaces FOCUS SkuMeter. */
    xBillableMetricName?: string | null | undefined;
    /** The product category the charge belongs to (e.g., "Developer", "Cloudflare One"). Cloudflare extension; replaces FOCUS ServiceCategory. */
    xProductCategoryName?: string | null | undefined;
    /** The unique identifier for the product family in the Cloudflare catalog. Cloudflare extension; replaces FOCUS ServiceId. */
    xProductFamilyId?: string | null | undefined;
    /** The product family the charge belongs to (e.g., "R2", "Workers"). Cloudflare extension; replaces FOCUS ServiceName. */
    xProductFamilyName?: string | null | undefined;
    /** The identifier for the Cloudflare zone (zone tag). Omitted when zone is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by zone. Cloudflare extension. */
    xZoneId?: string | null | undefined;
    /** The display name of the Cloudflare zone. Omitted when zone is not part of the requested grouping, and for usage measured at contract level. Cloudflare extension. */
    xZoneName?: string | null | undefined;
}
export type UsageGetResultList = Array<UsageGetResultItem>;
export type GetUsageResponse = UsageGetResultList;
export interface ListHistoryRequest {
    /** Identifier */
    accountId: string;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of items per page. */
    perPage?: number | undefined;
    /** Filter billing history by status. */
    status?: string | undefined;
}
export type ListHistoryResultItem = GetBadDebtResponseInvoicesItem;
export type ListHistoryResultList = Array<GetBadDebtResponseInvoicesItem>;
export type ListHistoryResponse = ListHistoryResultList;
export interface ListSpendPoliciesRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
}
export type ListSpendPoliciesResultItemAction = "notification" | "usage_block";
export type ListSpendPoliciesResultItemProductId = "workers" | "durable_objects";
export type ListSpendPoliciesResultItemCurrentStateEnforcementDeliveryStatus = "pending" | "leased" | "retry" | "succeeded";
export type ListSpendPoliciesResultItemCurrentStateEnforcementDesiredState = "active" | "inactive";
export interface ListSpendPoliciesResultItemCurrentStateEnforcement {
    appliedGeneration: number;
    deliveryStatus: ListSpendPoliciesResultItemCurrentStateEnforcementDeliveryStatus;
    desiredGeneration: number;
    desiredState: ListSpendPoliciesResultItemCurrentStateEnforcementDesiredState;
    expiresAt: string;
}
export type ListSpendPoliciesResultItemCurrentStateStatus = "disabled" | "no_current_period" | "unavailable" | "below_limit" | "limit_reached";
export interface ListSpendPoliciesResultItemCurrentState {
    balanceCents: number;
    billingPeriodEnd: string;
    billingPeriodStart: string;
    /** Durable desired cap and delivery bookkeeping for this policy, or null if no owned effect exists. Separate from threshold evaluation: pending/leased/retry can lag the new billing period. Succeeded with equal generations means delivery completed, not an EWC readback. */
    enforcement: ListSpendPoliciesResultItemCurrentStateEnforcement;
    /** Evaluation time; not the timestamp of the latest usage event. */
    evaluatedAt: string;
    /** Threshold evaluation, not proof of an edge cap. No current active period yields no_current_period for enabled policies; failed aggregate reads yield unavailable for enabled policies. Disabled policies report disabled. Neither no_current_period nor unavailable implies a zero balance or below-limit state. Operators may disable current-state reads, in which case current_state is omitted. */
    status: ListSpendPoliciesResultItemCurrentStateStatus;
}
export interface ListSpendPoliciesResultItem {
    /** The unique identifier of the spend policy. */
    id: string;
    /** Internal numeric ID of the account that owns the policy. This is not the account tag used in the path. */
    accountId: number;
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: ListSpendPoliciesResultItemAction;
    /** Whether the policy is evaluated. */
    enabled: boolean;
    /** Display name of the policy. */
    name: string;
    /** Email address that receives notifications. An empty string when none is set. */
    notificationEmail: string;
    /** The product the policy applies to: `workers` or `durable_objects`. Each product's balance and policies are separate. Both products support `notification` and `usage_block` policies on create and update. */
    productId: ListSpendPoliciesResultItemProductId;
    /** The spend threshold for the current billing period, in US cents. */
    thresholdCents: number;
    /** Optimistic-concurrency version. It starts at 1 and goes up by one on every update or delete. This value is also returned in `ETag`. */
    version: number;
    /** Read-only state on list/get responses, evaluated from the latest owning projector snapshot at request time, independently of the API replica. Configuration enabled/version/ETag do not change when a cycle rolls over. Audit history remains unchanged. Missing during a rolling upgrade or on mutation responses; clients must treat missing state as unavailable. Balances are asynchronous estimates, not a synchronous usage read. */
    currentState?: ListSpendPoliciesResultItemCurrentState | null | undefined;
}
export type ListSpendPoliciesResultList = Array<ListSpendPoliciesResultItem>;
export type ListSpendPoliciesResponse = ListSpendPoliciesResultList;
export type ListSpendPoliciesActivityRequestPeriod = "current_billing_cycle" | "all";
export interface ListSpendPoliciesActivityRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Opaque token from the preceding response's result_info.cursor. Pass it unchanged to retrieve older entries. */
    cursor?: string | undefined;
    /** Maximum number of audit entries to return. Defaults to 50. Values above 100 are capped at 100 rather than rejected. */
    limit?: number | undefined;
    /** Select current subscription billing-cycle history or history across all cycles. */
    period?: ListSpendPoliciesActivityRequestPeriod | (string & {}) | undefined;
}
export type ListSpendPoliciesActivityResultItemAction = "created" | "updated" | "enabled" | "disabled" | "deleted";
export type ListSpendPoliciesActivityResultItemDetailsAfterAction = "notification" | "usage_block";
export type ListSpendPoliciesActivityResultItemDetailsAfterProductId = "workers" | "durable_objects";
export type ListSpendPoliciesActivityResultItemDetailsAfterCurrentStateEnforcementDeliveryStatus = "pending" | "leased" | "retry" | "succeeded";
export type ListSpendPoliciesActivityResultItemDetailsAfterCurrentStateEnforcementDesiredState = "active" | "inactive";
export interface ListSpendPoliciesActivityResultItemDetailsAfterCurrentStateEnforcement {
    appliedGeneration: number;
    deliveryStatus: ListSpendPoliciesActivityResultItemDetailsAfterCurrentStateEnforcementDeliveryStatus;
    desiredGeneration: number;
    desiredState: ListSpendPoliciesActivityResultItemDetailsAfterCurrentStateEnforcementDesiredState;
    expiresAt: string;
}
export type ListSpendPoliciesActivityResultItemDetailsAfterCurrentStateStatus = "disabled" | "no_current_period" | "unavailable" | "below_limit" | "limit_reached";
export interface ListSpendPoliciesActivityResultItemDetailsAfterCurrentState {
    balanceCents: number;
    billingPeriodEnd: string;
    billingPeriodStart: string;
    /** Durable desired cap and delivery bookkeeping for this policy, or null if no owned effect exists. Separate from threshold evaluation: pending/leased/retry can lag the new billing period. Succeeded with equal generations means delivery completed, not an EWC readback. */
    enforcement: ListSpendPoliciesActivityResultItemDetailsAfterCurrentStateEnforcement;
    /** Evaluation time; not the timestamp of the latest usage event. */
    evaluatedAt: string;
    /** Threshold evaluation, not proof of an edge cap. No current active period yields no_current_period for enabled policies; failed aggregate reads yield unavailable for enabled policies. Disabled policies report disabled. Neither no_current_period nor unavailable implies a zero balance or below-limit state. Operators may disable current-state reads, in which case current_state is omitted. */
    status: ListSpendPoliciesActivityResultItemDetailsAfterCurrentStateStatus;
}
export interface ListSpendPoliciesActivityResultItemDetailsAfter {
    /** The unique identifier of the spend policy. */
    id: string;
    /** Internal numeric ID of the account that owns the policy. This is not the account tag used in the path. */
    accountId: number;
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: ListSpendPoliciesActivityResultItemDetailsAfterAction;
    /** Whether the policy is evaluated. */
    enabled: boolean;
    /** Display name of the policy. */
    name: string;
    /** Email address that receives notifications. An empty string when none is set. */
    notificationEmail: string;
    /** The product the policy applies to: `workers` or `durable_objects`. Each product's balance and policies are separate. Both products support `notification` and `usage_block` policies on create and update. */
    productId: ListSpendPoliciesActivityResultItemDetailsAfterProductId;
    /** The spend threshold for the current billing period, in US cents. */
    thresholdCents: number;
    /** Optimistic-concurrency version. It starts at 1 and goes up by one on every update or delete. This value is also returned in `ETag`. */
    version: number;
    /** Read-only state on list/get responses, evaluated from the latest owning projector snapshot at request time, independently of the API replica. Configuration enabled/version/ETag do not change when a cycle rolls over. Audit history remains unchanged. Missing during a rolling upgrade or on mutation responses; clients must treat missing state as unavailable. Balances are asynchronous estimates, not a synchronous usage read. */
    currentState?: ListSpendPoliciesActivityResultItemDetailsAfterCurrentState | null | undefined;
}
export type ListSpendPoliciesActivityResultItemDetailsBeforeAction = "notification" | "usage_block";
export type ListSpendPoliciesActivityResultItemDetailsBeforeProductId = "workers" | "durable_objects";
export type ListSpendPoliciesActivityResultItemDetailsBeforeCurrentStateEnforcementDeliveryStatus = "pending" | "leased" | "retry" | "succeeded";
export type ListSpendPoliciesActivityResultItemDetailsBeforeCurrentStateEnforcementDesiredState = "active" | "inactive";
export interface ListSpendPoliciesActivityResultItemDetailsBeforeCurrentStateEnforcement {
    appliedGeneration: number;
    deliveryStatus: ListSpendPoliciesActivityResultItemDetailsBeforeCurrentStateEnforcementDeliveryStatus;
    desiredGeneration: number;
    desiredState: ListSpendPoliciesActivityResultItemDetailsBeforeCurrentStateEnforcementDesiredState;
    expiresAt: string;
}
export type ListSpendPoliciesActivityResultItemDetailsBeforeCurrentStateStatus = "disabled" | "no_current_period" | "unavailable" | "below_limit" | "limit_reached";
export interface ListSpendPoliciesActivityResultItemDetailsBeforeCurrentState {
    balanceCents: number;
    billingPeriodEnd: string;
    billingPeriodStart: string;
    /** Durable desired cap and delivery bookkeeping for this policy, or null if no owned effect exists. Separate from threshold evaluation: pending/leased/retry can lag the new billing period. Succeeded with equal generations means delivery completed, not an EWC readback. */
    enforcement: ListSpendPoliciesActivityResultItemDetailsBeforeCurrentStateEnforcement;
    /** Evaluation time; not the timestamp of the latest usage event. */
    evaluatedAt: string;
    /** Threshold evaluation, not proof of an edge cap. No current active period yields no_current_period for enabled policies; failed aggregate reads yield unavailable for enabled policies. Disabled policies report disabled. Neither no_current_period nor unavailable implies a zero balance or below-limit state. Operators may disable current-state reads, in which case current_state is omitted. */
    status: ListSpendPoliciesActivityResultItemDetailsBeforeCurrentStateStatus;
}
export interface ListSpendPoliciesActivityResultItemDetailsBefore {
    /** The unique identifier of the spend policy. */
    id: string;
    /** Internal numeric ID of the account that owns the policy. This is not the account tag used in the path. */
    accountId: number;
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: ListSpendPoliciesActivityResultItemDetailsBeforeAction;
    /** Whether the policy is evaluated. */
    enabled: boolean;
    /** Display name of the policy. */
    name: string;
    /** Email address that receives notifications. An empty string when none is set. */
    notificationEmail: string;
    /** The product the policy applies to: `workers` or `durable_objects`. Each product's balance and policies are separate. Both products support `notification` and `usage_block` policies on create and update. */
    productId: ListSpendPoliciesActivityResultItemDetailsBeforeProductId;
    /** The spend threshold for the current billing period, in US cents. */
    thresholdCents: number;
    /** Optimistic-concurrency version. It starts at 1 and goes up by one on every update or delete. This value is also returned in `ETag`. */
    version: number;
    /** Read-only state on list/get responses, evaluated from the latest owning projector snapshot at request time, independently of the API replica. Configuration enabled/version/ETag do not change when a cycle rolls over. Audit history remains unchanged. Missing during a rolling upgrade or on mutation responses; clients must treat missing state as unavailable. Balances are asynchronous estimates, not a synchronous usage read. */
    currentState?: ListSpendPoliciesActivityResultItemDetailsBeforeCurrentState | null | undefined;
}
export interface ListSpendPoliciesActivityResultItemDetails {
    /** A spend policy. */
    after?: ListSpendPoliciesActivityResultItemDetailsAfter | null | undefined;
    /** Prior configuration; null on creation or if a previous revision is unavailable. */
    before?: ListSpendPoliciesActivityResultItemDetailsBefore | null | undefined;
}
export interface ListSpendPoliciesActivityResultItem {
    id: string;
    action: ListSpendPoliciesActivityResultItemAction;
    /** Verified actor identifier, unknown when absent, or trusted internal actor. */
    actor: string;
    details: ListSpendPoliciesActivityResultItemDetails;
    occurredAt: string;
    /** The unique identifier of the spend policy. */
    policyId: string;
    policyVersion: number;
    productId: string;
}
export type ListSpendPoliciesActivityResultList = Array<ListSpendPoliciesActivityResultItem>;
export type ListSpendPoliciesActivityResponse = ListSpendPoliciesActivityResultList;
export type ListSpendPoliciesAuditRequestPeriod = "current_billing_cycle" | "all";
export interface ListSpendPoliciesAuditRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** The unique identifier of the spend policy. */
    policyId: string;
    /** Maximum number of audit entries to return. Defaults to 50. Values above 100 are capped at 100 rather than rejected. */
    limit?: number | undefined;
    /** Select current subscription billing-cycle history or history across all cycles. */
    period?: ListSpendPoliciesAuditRequestPeriod | (string & {}) | undefined;
}
export type ListSpendPoliciesAuditResultItemAction = "notification" | "usage_block";
export type ListSpendPoliciesAuditResultItemSource = "kafka" | "policy_revision";
export interface ListSpendPoliciesAuditResultItem {
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: ListSpendPoliciesAuditResultItemAction;
    /** The account's balance for the product at evaluation time, in US cents. */
    balanceCents: number;
    /** Exclusive end of the billing period that was evaluated. */
    billingPeriodEnd: string;
    /** Inclusive start of the billing period that was evaluated. */
    billingPeriodStart: string;
    /** When the entry was recorded. */
    createdAt: string;
    /** The policy `version` that was evaluated. */
    policyVersion: number;
    /** A human-readable explanation of the trigger. */
    reason: string;
    /** What caused the evaluation. `kafka` means a balance update. `policy_revision` means a change to the policy. */
    source: ListSpendPoliciesAuditResultItemSource;
    /** The policy threshold at evaluation time, in US cents. */
    thresholdCents: number;
    /** The trigger recorded at evaluation time. New evaluations record `limit_reached` when the balance reaches or exceeds the configured threshold. Earlier entries retain their recorded trigger. */
    trigger: string;
}
export type ListSpendPoliciesAuditResultList = Array<ListSpendPoliciesAuditResultItem>;
export type ListSpendPoliciesAuditResponse = ListSpendPoliciesAuditResultList;
export interface PaygoUsageRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). The provided time range must include the subscription billing cycle anchor day, otherwise no usage data is returned. Use the info endpoint to retrieve the subscription anchor day. */
    from?: string | undefined;
    /** End date for the usage query (ISO 8601). */
    to?: string | undefined;
}
export type UsagePaygoResultItemChargeCategory = "Usage";
export interface UsagePaygoResultItem {
    /** The amount invoiced for this charge. PayGo is billed directly by Cloudflare, so this equals ContractedCost. */
    billedCost: number;
    /** The identifier of the account the charge is billed to (account tag). */
    billingAccountId: string;
    /** The display name of the billing account. Null when the name could not be resolved. */
    billingAccountName: string;
    /** Specifies the billing currency code (ISO 4217). */
    billingCurrency: string;
    /** Indicates the start of the billing period. There is no `BillingPeriodEnd` counterpart; see the known gaps described on this schema. */
    billingPeriodStart: string;
    /** Describes the nature of the charge. Always "Usage" for this endpoint, which only returns metered usage. */
    chargeCategory: UsagePaygoResultItemChargeCategory;
    /** Indicates whether the row corrects a previously invoiced billing period. Always null for this endpoint, which does not return corrections. */
    chargeClass: string;
    /** A human-readable summary of the charge. */
    chargeDescription: string;
    /** Indicates the end of the charge period. */
    chargePeriodEnd: string;
    /** Indicates the start of the charge period. */
    chargePeriodStart: string;
    /** Specifies the quantity consumed during this charge period. */
    consumedQuantity: number;
    /** A display name for the unit of measurement used for the product (for example, "GB-months", "GB-seconds"). May be empty when the unit is implicit in the service name. */
    consumedUnit: string;
    /** Specifies the cost for this charge period in the billing currency. */
    contractedCost: number;
    /** Specifies the cumulated cost for the billing period in the billing currency. */
    cumulatedContractedCost: number;
    /** Specifies the portion of usage that is actually subject to a unit price. */
    cumulatedPricingQuantity: number;
    /** The amortized cost of the charge. PayGo has no upfront commitments, so this equals ContractedCost. */
    effectiveCost: number;
    /** The provider that hosts the infrastructure or platform the service runs on. */
    hostProviderName: string;
    /** The entity that issues the invoice for this charge. */
    invoiceIssuerName: string;
    /** The cost at published list prices, before any discount. PayGo has no commitment discounts, so this equals ContractedCost. */
    listCost: number;
    /** Specifies the pricing quantity for this charge period. */
    pricingQuantity: number;
    /** The unit that PricingQuantity is expressed in. Unlike ConsumedUnit this is never empty; it falls back to "Count" when the service has no explicit unit. */
    pricingUnit: string;
    /** Identifies the Cloudflare service. */
    serviceName: string;
    /** The provider of the purchased service. */
    serviceProviderName: string;
    /** Identifies the product family for the Cloudflare service. */
    serviceFamilyName?: string | null | undefined;
    /** The identifier for the Cloudflare subscription. */
    subscriptionId?: string | null | undefined;
    /** The identifier for the Cloudflare zone (zone tag). */
    zoneId?: string | null | undefined;
    /** The display name of the Cloudflare zone. */
    zoneName?: string | null | undefined;
}
export type UsagePaygoResultList = Array<UsagePaygoResultItem>;
export type PaygoUsageResponse = UsagePaygoResultList;
export interface ProfilesUpdateBillingEmailRequest {
    /** Identifier */
    accountId: string;
    billingEmail?: string | undefined;
    preferredLocale?: string | undefined;
    secondaryBillingEmail?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ProfilesUpdateBillingEmailResponse {
    /** Billing item identifier tag. */
    id?: string | null | undefined;
    accountType?: string | null | undefined;
    address?: string | null | undefined;
    address2?: string | null | undefined;
    balance?: string | null | undefined;
    cardExpiryMonth?: number | null | undefined;
    cardExpiryYear?: number | null | undefined;
    cardNumber?: string | null | undefined;
    city?: string | null | undefined;
    company?: string | null | undefined;
    country?: string | null | undefined;
    createdOn?: string | null | undefined;
    deviceData?: string | null | undefined;
    editedOn?: string | null | undefined;
    enterpriseBillingEmail?: string | null | undefined;
    enterprisePrimaryEmail?: string | null | undefined;
    firstName?: string | null | undefined;
    isPartner?: boolean | null | undefined;
    lastName?: string | null | undefined;
    nextBillDate?: string | null | undefined;
    paymentAddress?: string | null | undefined;
    paymentAddress2?: string | null | undefined;
    paymentCity?: string | null | undefined;
    paymentCountry?: string | null | undefined;
    paymentEmail?: string | null | undefined;
    paymentFirstName?: string | null | undefined;
    paymentGateway?: string | null | undefined;
    paymentLastName?: string | null | undefined;
    paymentNonce?: string | null | undefined;
    paymentState?: string | null | undefined;
    paymentZipcode?: string | null | undefined;
    primaryEmail?: string | null | undefined;
    state?: string | null | undefined;
    taxIdType?: string | null | undefined;
    telephone?: string | null | undefined;
    validationCode?: string | null | undefined;
    vat?: string | null | undefined;
    zipcode?: string | null | undefined;
}
export interface UpdateProfileRequest {
    /** Identifier */
    accountId: string;
    /** Street address line 1. */
    address?: string | undefined;
    /** Street address line 2 (apt, suite, etc.). */
    address2?: string | undefined;
    /** Primary billing email address. */
    billingEmail?: string | undefined;
    /** Rate plan being purchased right after profile setup. */
    buyingRatePlan?: string | undefined;
    /** Captcha challenge JWT issued during onboarding. */
    captchaChallengeJwt?: string | undefined;
    /** Cloudflare Turnstile response. */
    cfTurnstileResponse?: string | undefined;
    /** City on the billing profile. */
    city?: string | undefined;
    /** Company name on the billing profile. */
    company?: string | undefined;
    /** ISO 3166-1 alpha-2 country code. */
    country?: string | undefined;
    /** First name on the billing profile. */
    firstName?: string | undefined;
    /** hCaptcha response. */
    hCaptchaResponse?: string | undefined;
    /** Last name on the billing profile. */
    lastName?: string | undefined;
    /** Preferred locale for invoice rendering (BCP 47). */
    preferredLocale?: string | undefined;
    /** Secondary billing email address for CC on invoices. */
    secondaryBillingEmail?: string | undefined;
    /** State or region on the billing profile. */
    state?: string | undefined;
    /** Type of tax ID provided. */
    taxIdType?: string | undefined;
    /** Contact phone number. */
    telephone?: string | undefined;
    /** VAT identifier. */
    vat?: string | undefined;
    /** ZIP or postal code. */
    zipcode?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null | undefined;
    accountType?: string | null | undefined;
    address?: string | null | undefined;
    address2?: string | null | undefined;
    balance?: string | null | undefined;
    cardExpiryMonth?: number | null | undefined;
    cardExpiryYear?: number | null | undefined;
    cardNumber?: string | null | undefined;
    city?: string | null | undefined;
    company?: string | null | undefined;
    country?: string | null | undefined;
    createdOn?: string | null | undefined;
    deviceData?: string | null | undefined;
    editedOn?: string | null | undefined;
    enterpriseBillingEmail?: string | null | undefined;
    enterprisePrimaryEmail?: string | null | undefined;
    firstName?: string | null | undefined;
    isPartner?: boolean | null | undefined;
    lastName?: string | null | undefined;
    nextBillDate?: string | null | undefined;
    paymentAddress?: string | null | undefined;
    paymentAddress2?: string | null | undefined;
    paymentCity?: string | null | undefined;
    paymentCountry?: string | null | undefined;
    paymentEmail?: string | null | undefined;
    paymentFirstName?: string | null | undefined;
    paymentGateway?: string | null | undefined;
    paymentLastName?: string | null | undefined;
    paymentNonce?: string | null | undefined;
    paymentState?: string | null | undefined;
    paymentZipcode?: string | null | undefined;
    primaryEmail?: string | null | undefined;
    state?: string | null | undefined;
    taxIdType?: string | null | undefined;
    telephone?: string | null | undefined;
    validationCode?: string | null | undefined;
    vat?: string | null | undefined;
    zipcode?: string | null | undefined;
}
export type UpdateSpendPolicyRequestAction = "notification" | "usage_block";
export type UpdateSpendPolicyRequestProductId = "workers" | "durable_objects";
export interface UpdateSpendPolicyRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** The unique identifier of the spend policy. */
    policyId: string;
    ifMatch: string;
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: UpdateSpendPolicyRequestAction | (string & {});
    /** Whether the policy is evaluated. */
    enabled: boolean;
    /** Display name of the policy. After surrounding whitespace is trimmed, it must be 1 to 200 bytes long. The value is stored as sent, untrimmed. */
    name: string;
    /** The product the policy applies to: `workers` or `durable_objects`. Each product's balance and policies are separate. Both products support `notification` and `usage_block` policies on create and update. */
    productId: UpdateSpendPolicyRequestProductId | (string & {});
    /** The spend threshold for the current billing period, in US cents. Must be greater than zero. */
    thresholdCents: number;
    /** Email address that receives notifications. Required when `action` is `notification`. When set, it must be a bare address (`user@example.com`); display-name forms such as `Name <user@example.com>` are rejected. */
    notificationEmail?: string | undefined;
}
export type UpdateSpendPolicyResponseAction = "notification" | "usage_block";
export type UpdateSpendPolicyResponseProductId = "workers" | "durable_objects";
export type UpdateSpendPolicyResponseCurrentStateEnforcementDeliveryStatus = "pending" | "leased" | "retry" | "succeeded";
export type UpdateSpendPolicyResponseCurrentStateEnforcementDesiredState = "active" | "inactive";
export interface UpdateSpendPolicyResponseCurrentStateEnforcement {
    appliedGeneration: number;
    deliveryStatus: UpdateSpendPolicyResponseCurrentStateEnforcementDeliveryStatus;
    desiredGeneration: number;
    desiredState: UpdateSpendPolicyResponseCurrentStateEnforcementDesiredState;
    expiresAt: string;
}
export type UpdateSpendPolicyResponseCurrentStateStatus = "disabled" | "no_current_period" | "unavailable" | "below_limit" | "limit_reached";
export interface UpdateSpendPolicyResponseCurrentState {
    balanceCents: number;
    billingPeriodEnd: string;
    billingPeriodStart: string;
    /** Durable desired cap and delivery bookkeeping for this policy, or null if no owned effect exists. Separate from threshold evaluation: pending/leased/retry can lag the new billing period. Succeeded with equal generations means delivery completed, not an EWC readback. */
    enforcement: UpdateSpendPolicyResponseCurrentStateEnforcement;
    /** Evaluation time; not the timestamp of the latest usage event. */
    evaluatedAt: string;
    /** Threshold evaluation, not proof of an edge cap. No current active period yields no_current_period for enabled policies; failed aggregate reads yield unavailable for enabled policies. Disabled policies report disabled. Neither no_current_period nor unavailable implies a zero balance or below-limit state. Operators may disable current-state reads, in which case current_state is omitted. */
    status: UpdateSpendPolicyResponseCurrentStateStatus;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSpendPolicyResponse {
    /** The unique identifier of the spend policy. */
    id: string;
    /** Internal numeric ID of the account that owns the policy. This is not the account tag used in the path. */
    accountId: number;
    /** The action taken when the threshold is reached. `notification` sends an email to `notification_email`. `usage_block` blocks further usage of the product until the end of the billing period. Raising the threshold above the current balance, disabling the policy, or deleting it lifts the block early. */
    action: UpdateSpendPolicyResponseAction;
    /** Whether the policy is evaluated. */
    enabled: boolean;
    /** Display name of the policy. */
    name: string;
    /** Email address that receives notifications. An empty string when none is set. */
    notificationEmail: string;
    /** The product the policy applies to: `workers` or `durable_objects`. Each product's balance and policies are separate. Both products support `notification` and `usage_block` policies on create and update. */
    productId: UpdateSpendPolicyResponseProductId;
    /** The spend threshold for the current billing period, in US cents. */
    thresholdCents: number;
    /** Optimistic-concurrency version. It starts at 1 and goes up by one on every update or delete. This value is also returned in `ETag`. */
    version: number;
    /** Read-only state on list/get responses, evaluated from the latest owning projector snapshot at request time, independently of the API replica. Configuration enabled/version/ETag do not change when a cycle rolls over. Audit history remains unchanged. Missing during a rolling upgrade or on mutation responses; clients must treat missing state as unavailable. Balances are asynchronous estimates, not a synchronous usage read. */
    currentState?: UpdateSpendPolicyResponseCurrentState | null | undefined;
}
export interface UsageGetAccountUsageInfoV1Request {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
}
export interface UsageGetAccountUsageInfoV1ResponseSubscriptionsItem {
    /** The identifier for the Cloudflare subscription. */
    id: string;
    /** The subscription billing cycle anchor timestamp. */
    billingCycleAnchorTimestamp: string;
    /** The subscription start timestamp. */
    startTimestamp: string;
    /** The subscription end timestamp. Omitted for active subscriptions; present only when the subscription has been cancelled. */
    endTimestamp?: string | null | undefined;
}
export type UsageGetAccountUsageInfoV1ResponseSubscriptionsList = Array<UsageGetAccountUsageInfoV1ResponseSubscriptionsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UsageGetAccountUsageInfoV1Response {
    /** Indicates whether the account is covered. */
    covered: boolean;
    /** List of subscriptions for the account. */
    subscriptions: UsageGetAccountUsageInfoV1ResponseSubscriptionsList;
}
export interface UsageGetAccountUsageV1Request {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). The provided time range must include the subscription billing cycle anchor day, otherwise no usage data is returned. Use the info endpoint to retrieve the subscription anchor day. */
    from?: string | undefined;
    /** End date for the usage query (ISO 8601). */
    to?: string | undefined;
}
export type UsageGetAccountUsageV1ResultItemChargeCategory = "Usage";
export interface UsageGetAccountUsageV1ResultItem {
    /** The amount invoiced for this charge. PayGo is billed directly by Cloudflare, so this equals ContractedCost. */
    billedCost: number;
    /** The identifier of the account the charge is billed to (account tag). */
    billingAccountId: string;
    /** The display name of the billing account. Null when the name could not be resolved. */
    billingAccountName: string;
    /** Specifies the billing currency code (ISO 4217). */
    billingCurrency: string;
    /** Indicates the start of the billing period. There is no `BillingPeriodEnd` counterpart; see the known gaps described on this schema. */
    billingPeriodStart: string;
    /** Describes the nature of the charge. Always "Usage" for this endpoint, which only returns metered usage. */
    chargeCategory: UsageGetAccountUsageV1ResultItemChargeCategory;
    /** Indicates whether the row corrects a previously invoiced billing period. Always null for this endpoint, which does not return corrections. */
    chargeClass: string;
    /** A human-readable summary of the charge. */
    chargeDescription: string;
    /** Indicates the end of the charge period. */
    chargePeriodEnd: string;
    /** Indicates the start of the charge period. */
    chargePeriodStart: string;
    /** Specifies the quantity consumed during this charge period. */
    consumedQuantity: number;
    /** A display name for the unit of measurement used for the product (for example, "GB-months", "GB-seconds"). May be empty when the unit is implicit in the service name. */
    consumedUnit: string;
    /** Specifies the cost for this charge period in the billing currency. */
    contractedCost: number;
    /** Specifies the cumulated cost for the billing period in the billing currency. */
    cumulatedContractedCost: number;
    /** Specifies the portion of usage that is actually subject to a unit price. */
    cumulatedPricingQuantity: number;
    /** The amortized cost of the charge. PayGo has no upfront commitments, so this equals ContractedCost. */
    effectiveCost: number;
    /** The provider that hosts the infrastructure or platform the service runs on. */
    hostProviderName: string;
    /** The entity that issues the invoice for this charge. */
    invoiceIssuerName: string;
    /** The cost at published list prices, before any discount. PayGo has no commitment discounts, so this equals ContractedCost. */
    listCost: number;
    /** Specifies the pricing quantity for this charge period. */
    pricingQuantity: number;
    /** The unit that PricingQuantity is expressed in. Unlike ConsumedUnit this is never empty; it falls back to "Count" when the service has no explicit unit. */
    pricingUnit: string;
    /** Identifies the Cloudflare service. */
    serviceName: string;
    /** The provider of the purchased service. */
    serviceProviderName: string;
    /** Identifies the product family for the Cloudflare service. */
    serviceFamilyName?: string | null | undefined;
    /** The identifier for the Cloudflare subscription. */
    subscriptionId?: string | null | undefined;
    /** The identifier for the Cloudflare zone (zone tag). */
    zoneId?: string | null | undefined;
    /** The display name of the Cloudflare zone. */
    zoneName?: string | null | undefined;
}
export type UsageGetAccountUsageV1ResultList = Array<UsageGetAccountUsageV1ResultItem>;
export type UsageGetAccountUsageV1Response = UsageGetAccountUsageV1ResultList;
export interface UsageGetAccountUsageV2Request {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
    /** Start date for the usage query (ISO 8601). Required if `to` is set. When omitted along with `to`, defaults to the start of the current month. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    from?: string | undefined;
    /** End date for the usage query (ISO 8601). Required if `from` is set. When omitted along with `from`, defaults to today. Filters by charge period (when consumption happened), not billing period. The maximum date range is 31 days. */
    to?: string | undefined;
}
export type UsageGetAccountUsageV2ResultItemChargeCategory = "Usage";
export type UsageGetAccountUsageV2ResultItemChargeFrequency = "Usage-Based";
export type UsageGetAccountUsageV2ResultItemChargeClass = "Correction";
export type UsageGetAccountUsageV2ResultItemTagsValue = string | boolean;
export type UsageGetAccountUsageV2ResultItemTagsMap = {
    [key: string]: UsageGetAccountUsageV2ResultItemTagsValue | undefined;
};
export interface UsageGetAccountUsageV2ResultItem {
    /** Highest-level classification of a charge based on the nature of how it gets billed. Currently only "Usage" is supported. */
    chargeCategory: UsageGetAccountUsageV2ResultItemChargeCategory;
    /** Self-contained summary of the charge's purpose and price. */
    chargeDescription: string;
    /** Indicates how often a charge occurs. Currently only "Usage-Based" is supported. */
    chargeFrequency: UsageGetAccountUsageV2ResultItemChargeFrequency;
    /** Exclusive end of the time interval during which the usage was consumed. */
    chargePeriodEnd: string;
    /** Inclusive start of the time interval during which the usage was consumed. */
    chargePeriodStart: string;
    /** Unit of measure for the consumed quantity (e.g., "GB", "Requests", "vCPU-Hours"). */
    consumedUnit: string;
    /** Name of the entity providing the underlying infrastructure or platform. */
    hostProviderName: string;
    /** Name of the entity responsible for invoicing for the services consumed. */
    invoiceIssuerName: string;
    /** Name of the entity that made the services available for purchase. */
    serviceProviderName: string;
    /** The unique identifier for the billable metric in the Cloudflare catalog. Cloudflare extension; replaces FOCUS SkuId. */
    xBillableMetricId: string;
    /** A charge serving as the basis for invoicing, inclusive of all reduced rates and discounts while excluding the amortization of upfront charges (one-time or recurring). */
    billedCost?: number | null | undefined;
    /** Public identifier of the Cloudflare account (account tag). Omitted when account is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by account: that usage is returned as its own record with no account. */
    billingAccountId?: string | null | undefined;
    /** Display name of the Cloudflare account. Omitted when account is not part of the requested grouping, and for usage measured at contract level. */
    billingAccountName?: string | null | undefined;
    /** Currency that a charge was billed in (ISO 4217). */
    billingCurrency?: string | null | undefined;
    /** Exclusive end of the billing cycle that contains this usage record. */
    billingPeriodEnd?: string | null | undefined;
    /** Inclusive start of the billing cycle that contains this usage record. */
    billingPeriodStart?: string | null | undefined;
    /** Indicates whether the row represents a correction to one or more charges invoiced in a previous billing period. */
    chargeClass?: UsageGetAccountUsageV2ResultItemChargeClass | null | undefined;
    /** Measured usage amount within the charge period. Reflects raw metered consumption before pricing transformations. */
    consumedQuantity?: number | null | undefined;
    /** Cost calculated by multiplying ContractedUnitPrice and the corresponding PricingQuantity. */
    contractedCost?: number | null | undefined;
    /** The agreed-upon unit price for a single PricingUnit of the associated billable metric, inclusive of negotiated discounts, if present, while excluding any other discounts. */
    contractedUnitPrice?: number | null | undefined;
    /** The amortized cost of the charge after applying all reduced rates, discounts, and the applicable portion of relevant, prepaid purchases (one-time or recurring) that covered the charge. */
    effectiveCost?: number | null | undefined;
    /** Cost calculated by multiplying ListUnitPrice and the corresponding PricingQuantity. */
    listCost?: number | null | undefined;
    /** Suggested provider-published unit price for a single PricingUnit of the associated billable metric, exclusive of any discounts. */
    listUnitPrice?: number | null | undefined;
    /** Volume of a given service used or purchased, based on the PricingUnit. */
    pricingQuantity?: number | null | undefined;
    /** Provider-specified measurement unit for determining unit prices, indicating how the provider rates measured usage after applying pricing rules like block pricing. */
    pricingUnit?: string | null | undefined;
    /** Provider-assigned identifier for an isolated geographic area where a service is provided. */
    regionId?: string | null | undefined;
    /** Name of an isolated geographic area where a service is provided. */
    regionName?: string | null | undefined;
    /** Unique identifier assigned to a grouping of services. For Cloudflare, this is the subscription or contract ID. */
    subAccountId?: string | null | undefined;
    /** Name assigned to a grouping of services. For Cloudflare, this is the subscription or contract display name. */
    subAccountName?: string | null | undefined;
    /** Tag values for the requested `GroupBy` keys. Omitted when `GroupBy` is not provided. Missing keys are omitted, and key-only tags are returned as boolean `true`. All other tag values are strings. */
    tags?: UsageGetAccountUsageV2ResultItemTagsMap | null | undefined;
    /** The display name of the billable metric. Cloudflare extension; replaces FOCUS SkuMeter. */
    xBillableMetricName?: string | null | undefined;
    /** The product category the charge belongs to (e.g., "Developer", "Cloudflare One"). Cloudflare extension; replaces FOCUS ServiceCategory. */
    xProductCategoryName?: string | null | undefined;
    /** The unique identifier for the product family in the Cloudflare catalog. Cloudflare extension; replaces FOCUS ServiceId. */
    xProductFamilyId?: string | null | undefined;
    /** The product family the charge belongs to (e.g., "R2", "Workers"). Cloudflare extension; replaces FOCUS ServiceName. */
    xProductFamilyName?: string | null | undefined;
    /** The identifier for the Cloudflare zone (zone tag). Omitted when zone is not part of the requested grouping, and always omitted for usage measured at contract level, even when grouping by zone. Cloudflare extension. */
    xZoneId?: string | null | undefined;
    /** The display name of the Cloudflare zone. Omitted when zone is not part of the requested grouping, and for usage measured at contract level. Cloudflare extension. */
    xZoneName?: string | null | undefined;
}
export type UsageGetAccountUsageV2ResultList = Array<UsageGetAccountUsageV2ResultItem>;
export type UsageGetAccountUsageV2Response = UsageGetAccountUsageV2ResultList;
export interface UsagePaygoInfoRequest {
    /** Represents a Cloudflare resource identifier tag. */
    accountId: string;
}
export type UsagePaygoInfoResponseSubscriptionsItem = UsageGetAccountUsageInfoV1ResponseSubscriptionsItem;
export type UsagePaygoInfoResponseSubscriptionsList = Array<UsageGetAccountUsageInfoV1ResponseSubscriptionsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UsagePaygoInfoResponse {
    /** Indicates whether the account is covered. */
    covered: boolean;
    /** List of subscriptions for the account. */
    subscriptions: UsagePaygoInfoResponseSubscriptionsList;
}
export type AddressValidationError = CloudflareOpError;
/** Validates a billing address and returns validated address suggestions. Authentication is not enforced to support pre-signup address validation flows, so credentials are accepted but not required. */
export declare const addressValidation: API.OperationMethod<AddressValidationRequest, AddressValidationResponse, AddressValidationError, CloudflareOpContext>;
export type CreateProfileError = CloudflareOpError;
/** Creates a billing profile for an account. */
export declare const createProfile: API.OperationMethod<CreateProfileRequest, CreateProfileResponse, CreateProfileError, CloudflareOpContext>;
export type CreateProfilesPaymentMethodError = CloudflareOpError;
/** Creates a Stripe payment intent for adding or updating a payment method on the account's billing profile. Returns a client secret for frontend payment method collection. */
export declare const createProfilesPaymentMethod: API.OperationMethod<CreateProfilesPaymentMethodRequest, CreateProfilesPaymentMethodResponse, CreateProfilesPaymentMethodError, CloudflareOpContext>;
export type CreateSpendPolicyError = CloudflareOpError;
/** Creates a spend policy. Each account can have only one enabled `usage_block` policy per product. A second one returns `409`. There is no limit on `notification` policies. */
export declare const createSpendPolicy: API.OperationMethod<CreateSpendPolicyRequest, CreateSpendPolicyResponse, CreateSpendPolicyError, CloudflareOpContext>;
export type DeleteProfileError = CloudflareOpError;
/** Deletes the billing profile for an account. */
export declare const deleteProfile: API.OperationMethod<DeleteProfileRequest, DeleteProfileResponse, DeleteProfileError, CloudflareOpContext>;
export type DeleteSpendPolicyError = CloudflareOpError;
/** Soft-deletes the spend policy. The policy is disabled and no longer appears in list, get or audit responses. The `If-Match` header must equal the policy's current `version`. */
export declare const deleteSpendPolicy: API.OperationMethod<DeleteSpendPolicyRequest, DeleteSpendPolicyResponse, DeleteSpendPolicyError, CloudflareOpContext>;
export type GetBadDebtError = CloudflareOpError;
/** Gets bad debt information for an account, including outstanding invoices and total debt amount. */
export declare const getBadDebt: API.OperationMethod<GetBadDebtRequest, GetBadDebtResponse, GetBadDebtError, CloudflareOpContext>;
export type GetCreditError = CloudflareOpError;
/** Gets the credit balance and eligibility for an account. */
export declare const getCredit: API.OperationMethod<GetCreditRequest, GetCreditResponse, GetCreditError, CloudflareOpContext>;
export type GetProfileError = CloudflareOpError;
/** Gets the current billing profile for the account. */
export declare const getProfile: API.OperationMethod<GetProfileRequest, GetProfileResponse, GetProfileError, CloudflareOpContext>;
export type GetRatePlanError = CloudflareOpError;
/** Gets a rate plan's details by its public key (e.g., 'teams_free', 'cf_pro_20_20'). This is a public catalog endpoint, so authentication is not enforced and credentials are accepted but not required. */
export declare const getRatePlan: API.OperationMethod<GetRatePlanRequest, GetRatePlanResponse, GetRatePlanError, CloudflareOpContext>;
export type GetSpendPolicyError = CloudflareOpError;
/** Returns one spend policy. The `ETag` response header holds the current `version`; send it as `If-Match` on a later update or delete. */
export declare const getSpendPolicy: API.OperationMethod<GetSpendPolicyRequest, GetSpendPolicyResponse, GetSpendPolicyError, CloudflareOpContext>;
export type GetUnpaidInvoiceError = CloudflareOpError;
/** Gets unpaid invoice information for an account. */
export declare const getUnpaidInvoice: API.OperationMethod<GetUnpaidInvoiceRequest, GetUnpaidInvoiceResponse, GetUnpaidInvoiceError, CloudflareOpContext>;
export type GetUsageError = CloudflareOpError;
/** Returns cost and usage data for a single Cloudflare account, aligned with the [FinOps FOCUS v1.3](https://focus.finops.org/focus-specification/v1-3/) Cost and Usage dataset specification. Each record represents one billable metric for one account on one day. This includes all metered usage, including usage that falls within free-tier allowances and may result in zero cost. **Note:** This endpoint serves `usage` records only; cost and pricing fields are absent from responses. To retrieve rated costs, use `POST` on the same path with `Metric: cost`. When `from` and `to` are omitted, defaults to the start of the current month through today. The maximum date range is 31 days. */
export declare const getUsage: API.OperationMethod<GetUsageRequest, GetUsageResponse, GetUsageError, CloudflareOpContext>;
export type ListHistoryError = CloudflareOpError;
/** Gets the billing history for an account. */
export declare const listHistory: API.OperationMethod<ListHistoryRequest, ListHistoryResponse, ListHistoryError, CloudflareOpContext>;
export type ListSpendPoliciesError = CloudflareOpError;
/** Returns every spend policy on the account that has not been deleted, including disabled ones. Results are sorted by `name`, then `id`. There is no pagination. */
export declare const listSpendPolicies: API.OperationMethod<ListSpendPoliciesRequest, ListSpendPoliciesResponse, ListSpendPoliciesError, CloudflareOpContext>;
export type ListSpendPoliciesActivityError = CloudflareOpError;
/** Returns configuration history from immutable policy revisions for the account, including deleted policies. Entries contain before/after values and verified actor attribution. Pages use descending revision IDs, not event or commit order; refresh the first page for new entries. This cursor is not an incremental consumer checkpoint. Defaults to `period=current_billing_cycle`: each revision's timestamp must be within its product's current subscription cycle (inclusive start, exclusive end). Each product's cycle is resolved independently from canonical aggregates, including for disabled or deleted policies. Set `period=all` for history across cycles. Filtering happens before pagination. No current cycles returns an empty page; unavailable or disabled cycle resolution returns `503` with code `1013`. Cursors pin resolved cycle bounds across pages and must be used with the same period selection. Cursors obtained before this filter was introduced must be refreshed. */
export declare const listSpendPoliciesActivity: API.OperationMethod<ListSpendPoliciesActivityRequest, ListSpendPoliciesActivityResponse, ListSpendPoliciesActivityError, CloudflareOpContext>;
export type ListSpendPoliciesAuditError = CloudflareOpError;
/** Returns the policy's evaluation history, newest first. At most one threshold-crossing entry (`limit_reached`) is recorded per policy version and billing period, so a policy update can record a new entry without any change in balance. Disabled policies still return their history; deleted policies return `404`. There is no pagination: use `limit` to set how many entries come back. Defaults to `period=current_billing_cycle`, resolved from the product's canonical aggregates, not calendar months. Crossings match their recorded billing-period bounds, even if recorded late. Set `period=all` for history across cycles. Filtering happens before LIMIT. No current cycle returns an empty array; unavailable or disabled cycle resolution returns `503` with code `1013`, never an empty success. */
export declare const listSpendPoliciesAudit: API.OperationMethod<ListSpendPoliciesAuditRequest, ListSpendPoliciesAuditResponse, ListSpendPoliciesAuditError, CloudflareOpContext>;
export type PaygoUsageError = CloudflareOpError;
/** Returns billable usage data for the account. When no query parameters are provided, returns usage for the current billing period. */
export declare const paygoUsage: API.OperationMethod<PaygoUsageRequest, PaygoUsageResponse, PaygoUsageError, CloudflareOpContext>;
export type ProfilesUpdateBillingEmailError = CloudflareOpError;
/** Updates the billing email addresses and preferred locale for an account. */
export declare const profilesUpdateBillingEmail: API.OperationMethod<ProfilesUpdateBillingEmailRequest, ProfilesUpdateBillingEmailResponse, ProfilesUpdateBillingEmailError, CloudflareOpContext>;
export type UpdateProfileError = CloudflareOpError;
/** Updates the billing profile for an account. */
export declare const updateProfile: API.OperationMethod<UpdateProfileRequest, UpdateProfileResponse, UpdateProfileError, CloudflareOpContext>;
export type UpdateSpendPolicyError = CloudflareOpError;
/** Replaces the whole spend policy. Every field is required, as on create; there are no partial updates and `PATCH` is not supported. The `If-Match` header must equal the policy's current `version`. On success, `version` goes up by one and the new value is returned in `ETag`. */
export declare const updateSpendPolicy: API.OperationMethod<UpdateSpendPolicyRequest, UpdateSpendPolicyResponse, UpdateSpendPolicyError, CloudflareOpContext>;
export type UsageGetAccountUsageInfoV1Error = CloudflareOpError;
/** Returns high-level usage information for the account, including coverage, and subscription metadata. */
export declare const usageGetAccountUsageInfoV1: API.OperationMethod<UsageGetAccountUsageInfoV1Request, UsageGetAccountUsageInfoV1Response, UsageGetAccountUsageInfoV1Error, CloudflareOpContext>;
export type UsageGetAccountUsageV1Error = CloudflareOpError;
/** Returns billable usage data for the account. When no query parameters are provided, returns usage for the current billing period. */
export declare const usageGetAccountUsageV1: API.OperationMethod<UsageGetAccountUsageV1Request, UsageGetAccountUsageV1Response, UsageGetAccountUsageV1Error, CloudflareOpContext>;
export type UsageGetAccountUsageV2Error = CloudflareOpError;
/** Returns cost and usage data for a single Cloudflare account, aligned with the [FinOps FOCUS v1.3](https://focus.finops.org/focus-specification/v1-3/) Cost and Usage dataset specification. Each record represents one billable metric for one account on one day. This includes all metered usage, including usage that falls within free-tier allowances and may result in zero cost. **Note:** This endpoint serves `usage` records only; cost and pricing fields are absent from responses. To retrieve rated costs, use `POST` on the same path with `Metric: cost`. When `from` and `to` are omitted, defaults to the start of the current month through today. The maximum date range is 31 days. */
export declare const usageGetAccountUsageV2: API.OperationMethod<UsageGetAccountUsageV2Request, UsageGetAccountUsageV2Response, UsageGetAccountUsageV2Error, CloudflareOpContext>;
export type UsagePaygoInfoError = CloudflareOpError;
/** Returns high-level usage information for the account, including coverage, and subscription metadata. */
export declare const usagePaygoInfo: API.OperationMethod<UsagePaygoInfoRequest, UsagePaygoInfoResponse, UsagePaygoInfoError, CloudflareOpContext>;
//# sourceMappingURL=billing.d.ts.map