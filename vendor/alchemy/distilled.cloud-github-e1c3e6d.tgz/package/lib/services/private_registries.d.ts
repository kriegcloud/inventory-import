import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The registry type. */
export type CreateOrgPrivateRegistryRequestRegistryType = "maven_repository" | "nuget_feed" | "goproxy_server" | "npm_registry" | "rubygems_server" | "cargo_registry" | "composer_repository" | "docker_registry" | "git_source" | "helm_registry" | "hex_organization" | "hex_repository" | "pub_repository" | "python_index" | "terraform_registry";
/** Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry. */
export type CreateOrgPrivateRegistryRequestVisibility = "all" | "private" | "selected";
/** An array of repository IDs that can access the organization private registry. You can only provide a list of repository IDs when `visibility` is set to `selected`. You can manage the list of selected repositories using the [Update a private registry for an organization](https://docs.github.com/rest/private-registries/organization-configurations#update-a-private-registry-for-an-organization) endpoint. This field should be omitted if `visibility` is set to `all` or `private`. */
export type CreateOrgPrivateRegistryRequestSelectedRepositoryIdsList = Array<number>;
/** The authentication type for the private registry. Defaults to `token` if not specified. Use `oidc_azure`, `oidc_aws`, `oidc_jfrog`, `oidc_cloudsmith`, or `oidc_gcp` for OIDC authentication. Use `anonymous` for registries that do not require authentication; `username`, `encrypted_value`, and `key_id` must be omitted. */
export type CreateOrgPrivateRegistryRequestAuthType = "token" | "username_password" | "oidc_azure" | "oidc_aws" | "oidc_jfrog" | "oidc_cloudsmith" | "oidc_gcp" | "anonymous";
export interface CreateOrgPrivateRegistryRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The registry type. */
    registry_type: CreateOrgPrivateRegistryRequestRegistryType | (string & {});
    /** The URL of the private registry. */
    url: string;
    /** The username to use when authenticating with the private registry. This field should be omitted if the private registry does not require a username for authentication. */
    username?: string | null | undefined;
    /** Whether this private registry should replace the base registry (e.g., npmjs.org for npm, rubygems.org for rubygems). When set to `true`, Dependabot will only use this registry and will not fall back to the public registry. When set to `false` (default), Dependabot will use this registry for scoped packages but may fall back to the public registry for other packages. */
    replaces_base?: boolean | undefined;
    /** The value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get private registries public key for an organization](https://docs.github.com/rest/private-registries/organization-configurations#get-private-registries-public-key-for-an-organization) endpoint. Required when `auth_type` is `token` or `username_password`. Should be omitted for OIDC auth types. */
    encrypted_value?: string | undefined;
    /** The ID of the key you used to encrypt the secret. Required when `auth_type` is `token` or `username_password`. Should be omitted for OIDC auth types. */
    key_id?: string | undefined;
    /** Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry. */
    visibility: CreateOrgPrivateRegistryRequestVisibility | (string & {});
    /** An array of repository IDs that can access the organization private registry. You can only provide a list of repository IDs when `visibility` is set to `selected`. You can manage the list of selected repositories using the [Update a private registry for an organization](https://docs.github.com/rest/private-registries/organization-configurations#update-a-private-registry-for-an-organization) endpoint. This field should be omitted if `visibility` is set to `all` or `private`. */
    selected_repository_ids?: CreateOrgPrivateRegistryRequestSelectedRepositoryIdsList | undefined;
    /** The authentication type for the private registry. Defaults to `token` if not specified. Use `oidc_azure`, `oidc_aws`, `oidc_jfrog`, `oidc_cloudsmith`, or `oidc_gcp` for OIDC authentication. Use `anonymous` for registries that do not require authentication; `username`, `encrypted_value`, and `key_id` must be omitted. */
    auth_type?: CreateOrgPrivateRegistryRequestAuthType | (string & {}) | undefined;
    /** The tenant ID of the Azure AD application. Required when `auth_type` is `oidc_azure`. */
    tenant_id?: string | undefined;
    /** The client ID of the Azure AD application. Required when `auth_type` is `oidc_azure`. */
    client_id?: string | undefined;
    /** The AWS region. Required when `auth_type` is `oidc_aws`. */
    aws_region?: string | undefined;
    /** The AWS account ID. Required when `auth_type` is `oidc_aws`. */
    account_id?: string | undefined;
    /** The AWS IAM role name. Required when `auth_type` is `oidc_aws`. */
    role_name?: string | undefined;
    /** The CodeArtifact domain. Required when `auth_type` is `oidc_aws`. */
    domain?: string | undefined;
    /** The CodeArtifact domain owner (AWS account ID). Required when `auth_type` is `oidc_aws`. */
    domain_owner?: string | undefined;
    /** The JFrog OIDC provider name. Required when `auth_type` is `oidc_jfrog`. */
    jfrog_oidc_provider_name?: string | undefined;
    /** The OIDC audience. Optional for `oidc_aws`, `oidc_jfrog`, and `oidc_gcp`, and required for `oidc_cloudsmith` auth types. */
    audience?: string | undefined;
    /** The JFrog identity mapping name. Optional for `oidc_jfrog` auth type. */
    identity_mapping_name?: string | undefined;
    /** The Cloudsmith organization namespace. Required when `auth_type` is `oidc_cloudsmith`. */
    namespace?: string | undefined;
    /** The Cloudsmith service account slug. Required when `auth_type` is `oidc_cloudsmith`. */
    service_slug?: string | undefined;
    /** The Cloudsmith API host. Optional for `oidc_cloudsmith` auth type. If omitted, `api.cloudsmith.io` is used by default. */
    api_host?: string | undefined;
    /** The full resource name of the GCP Workload Identity Provider (e.g. `projects/<NUM>/locations/global/workloadIdentityPools/<POOL>/providers/<PROVIDER>`). Required when `auth_type` is `oidc_gcp`. */
    workload_identity_provider?: string | undefined;
    /** The GCP service account email to impersonate. Optional for `oidc_gcp` auth type. If omitted, the federated token is used directly (direct WIF). */
    service_account?: string | undefined;
}
/** The registry type. */
export type OrgPrivateRegistryConfigurationWithSelectedRepositoriesRegistryType = "maven_repository" | "nuget_feed" | "goproxy_server" | "npm_registry" | "rubygems_server" | "cargo_registry" | "composer_repository" | "docker_registry" | "git_source" | "helm_registry" | "hex_organization" | "hex_repository" | "pub_repository" | "python_index" | "terraform_registry";
/** The authentication type for the private registry. */
export type OrgPrivateRegistryConfigurationWithSelectedRepositoriesAuthType = "token" | "username_password" | "oidc_azure" | "oidc_aws" | "oidc_jfrog" | "oidc_cloudsmith" | "oidc_gcp" | "anonymous";
/** Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry. */
export type OrgPrivateRegistryConfigurationWithSelectedRepositoriesVisibility = "all" | "private" | "selected";
/** An array of repository IDs that can access the organization private registry when `visibility` is set to `selected`. */
export type OrgPrivateRegistryConfigurationWithSelectedRepositoriesSelectedRepositoryIdsList = Array<number>;
/** Private registry configuration for an organization */
export interface OrgPrivateRegistryConfigurationWithSelectedRepositories {
    /** The name of the private registry configuration. */
    name: string;
    /** The registry type. */
    registry_type: OrgPrivateRegistryConfigurationWithSelectedRepositoriesRegistryType;
    /** The authentication type for the private registry. */
    auth_type?: OrgPrivateRegistryConfigurationWithSelectedRepositoriesAuthType | undefined;
    /** The URL of the private registry. */
    url?: string | undefined;
    /** The username to use when authenticating with the private registry. */
    username?: string | undefined;
    /** Whether this private registry replaces the base registry (e.g., npmjs.org for npm, rubygems.org for rubygems). When `true`, Dependabot will only use this registry and will not fall back to the public registry. When `false` (default), Dependabot will use this registry for scoped packages but may fall back to the public registry for other packages. */
    replaces_base?: boolean | undefined;
    /** Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry. */
    visibility: OrgPrivateRegistryConfigurationWithSelectedRepositoriesVisibility;
    /** An array of repository IDs that can access the organization private registry when `visibility` is set to `selected`. */
    selected_repository_ids?: OrgPrivateRegistryConfigurationWithSelectedRepositoriesSelectedRepositoryIdsList | undefined;
    /** The tenant ID of the Azure AD application. */
    tenant_id?: string | undefined;
    /** The client ID of the Azure AD application. */
    client_id?: string | undefined;
    /** The AWS region. */
    aws_region?: string | undefined;
    /** The AWS account ID. */
    account_id?: string | undefined;
    /** The AWS IAM role name. */
    role_name?: string | undefined;
    /** The CodeArtifact domain. */
    domain?: string | undefined;
    /** The CodeArtifact domain owner. */
    domain_owner?: string | undefined;
    /** The JFrog OIDC provider name. */
    jfrog_oidc_provider_name?: string | undefined;
    /** The OIDC audience. */
    audience?: string | undefined;
    /** The JFrog identity mapping name. */
    identity_mapping_name?: string | undefined;
    /** The Cloudsmith organization namespace. */
    namespace?: string | undefined;
    /** The Cloudsmith service account slug. */
    service_slug?: string | undefined;
    /** The Cloudsmith API host. */
    api_host?: string | undefined;
    /** The full resource name of the GCP Workload Identity Provider (e.g. `projects/<NUM>/locations/global/workloadIdentityPools/<POOL>/providers/<PROVIDER>`). */
    workload_identity_provider?: string | undefined;
    /** The GCP service account email to impersonate. If omitted, the federated token is used directly (direct WIF). */
    service_account?: string | undefined;
    created_at: string;
    updated_at: string;
}
export interface DeleteOrgPrivateRegistryRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteOrgPrivateRegistryResponse {
}
export interface GetOrgPrivateRegistryRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
/** The registry type. */
export type OrgPrivateRegistryConfigurationRegistryType = "maven_repository" | "nuget_feed" | "goproxy_server" | "npm_registry" | "rubygems_server" | "cargo_registry" | "composer_repository" | "docker_registry" | "git_source" | "helm_registry" | "hex_organization" | "hex_repository" | "pub_repository" | "python_index" | "terraform_registry";
/** The authentication type for the private registry. */
export type OrgPrivateRegistryConfigurationAuthType = "token" | "username_password" | "oidc_azure" | "oidc_aws" | "oidc_jfrog" | "oidc_cloudsmith" | "oidc_gcp" | "anonymous";
/** Which type of organization repositories have access to the private registry. */
export type OrgPrivateRegistryConfigurationVisibility = "all" | "private" | "selected";
/** Private registry configuration for an organization */
export interface OrgPrivateRegistryConfiguration {
    /** The name of the private registry configuration. */
    name: string;
    /** The registry type. */
    registry_type: OrgPrivateRegistryConfigurationRegistryType;
    /** The authentication type for the private registry. */
    auth_type?: OrgPrivateRegistryConfigurationAuthType | undefined;
    /** The URL of the private registry. */
    url?: string | undefined;
    /** The username to use when authenticating with the private registry. */
    username?: string | null | undefined;
    /** Whether this private registry replaces the base registry (e.g., npmjs.org for npm, rubygems.org for rubygems). When `true`, Dependabot will only use this registry and will not fall back to the public registry. When `false` (default), Dependabot will use this registry for scoped packages but may fall back to the public registry for other packages. */
    replaces_base?: boolean | undefined;
    /** Which type of organization repositories have access to the private registry. */
    visibility: OrgPrivateRegistryConfigurationVisibility;
    /** The tenant ID of the Azure AD application. */
    tenant_id?: string | undefined;
    /** The client ID of the Azure AD application. */
    client_id?: string | undefined;
    /** The AWS region. */
    aws_region?: string | undefined;
    /** The AWS account ID. */
    account_id?: string | undefined;
    /** The AWS IAM role name. */
    role_name?: string | undefined;
    /** The CodeArtifact domain. */
    domain?: string | undefined;
    /** The CodeArtifact domain owner. */
    domain_owner?: string | undefined;
    /** The JFrog OIDC provider name. */
    jfrog_oidc_provider_name?: string | undefined;
    /** The OIDC audience. */
    audience?: string | undefined;
    /** The JFrog identity mapping name. */
    identity_mapping_name?: string | undefined;
    /** The Cloudsmith organization namespace. */
    namespace?: string | undefined;
    /** The Cloudsmith service account slug. */
    service_slug?: string | undefined;
    /** The Cloudsmith API host. */
    api_host?: string | undefined;
    /** The full resource name of the GCP Workload Identity Provider (e.g. `projects/<NUM>/locations/global/workloadIdentityPools/<POOL>/providers/<PROVIDER>`). */
    workload_identity_provider?: string | undefined;
    /** The GCP service account email to impersonate. If omitted, the federated token is used directly (direct WIF). */
    service_account?: string | undefined;
    created_at: string;
    updated_at: string;
}
export interface GetOrgPublicKeyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface GetOrgPublicKeyResponse {
    /** The identifier for the key. */
    key_id: string;
    /** The Base64 encoded public key. */
    key: string;
}
export interface ListOrgPrivateRegistriesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOrgPrivateRegistriesResponseConfigurationsList = Array<OrgPrivateRegistryConfiguration>;
export interface ListOrgPrivateRegistriesResponse {
    total_count: number;
    configurations: ListOrgPrivateRegistriesResponseConfigurationsList;
}
/** The registry type. */
export type UpdateOrgPrivateRegistryRequestRegistryType = "maven_repository" | "nuget_feed" | "goproxy_server" | "npm_registry" | "rubygems_server" | "cargo_registry" | "composer_repository" | "docker_registry" | "git_source" | "helm_registry" | "hex_organization" | "hex_repository" | "pub_repository" | "python_index" | "terraform_registry";
/** Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry. */
export type UpdateOrgPrivateRegistryRequestVisibility = "all" | "private" | "selected";
/** An array of repository IDs that can access the organization private registry. You can only provide a list of repository IDs when `visibility` is set to `selected`. This field should be omitted if `visibility` is set to `all` or `private`. */
export type UpdateOrgPrivateRegistryRequestSelectedRepositoryIdsList = Array<number>;
/** The authentication type for the private registry. This field cannot be changed after creation. If provided, it must match the existing `auth_type` of the configuration. To change the authentication type, delete and recreate the configuration. */
export type UpdateOrgPrivateRegistryRequestAuthType = "token" | "username_password" | "oidc_azure" | "oidc_aws" | "oidc_jfrog" | "oidc_cloudsmith" | "oidc_gcp" | "anonymous";
export interface UpdateOrgPrivateRegistryRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** The registry type. */
    registry_type?: UpdateOrgPrivateRegistryRequestRegistryType | (string & {}) | undefined;
    /** The URL of the private registry. */
    url?: string | undefined;
    /** The username to use when authenticating with the private registry. This field should be omitted if the private registry does not require a username for authentication. */
    username?: string | null | undefined;
    /** Whether this private registry should replace the base registry (e.g., npmjs.org for npm, rubygems.org for rubygems). When set to `true`, Dependabot will only use this registry and will not fall back to the public registry. When set to `false` (default), Dependabot will use this registry for scoped packages but may fall back to the public registry for other packages. */
    replaces_base?: boolean | undefined;
    /** The value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get private registries public key for an organization](https://docs.github.com/rest/private-registries/organization-configurations#get-private-registries-public-key-for-an-organization) endpoint. */
    encrypted_value?: string | undefined;
    /** The ID of the key you used to encrypt the secret. */
    key_id?: string | undefined;
    /** Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry. */
    visibility?: UpdateOrgPrivateRegistryRequestVisibility | (string & {}) | undefined;
    /** An array of repository IDs that can access the organization private registry. You can only provide a list of repository IDs when `visibility` is set to `selected`. This field should be omitted if `visibility` is set to `all` or `private`. */
    selected_repository_ids?: UpdateOrgPrivateRegistryRequestSelectedRepositoryIdsList | undefined;
    /** The authentication type for the private registry. This field cannot be changed after creation. If provided, it must match the existing `auth_type` of the configuration. To change the authentication type, delete and recreate the configuration. */
    auth_type?: UpdateOrgPrivateRegistryRequestAuthType | (string & {}) | undefined;
    /** The tenant ID of the Azure AD application. Required when `auth_type` is `oidc_azure`. */
    tenant_id?: string | undefined;
    /** The client ID of the Azure AD application. Required when `auth_type` is `oidc_azure`. */
    client_id?: string | undefined;
    /** The AWS region. Required when `auth_type` is `oidc_aws`. */
    aws_region?: string | undefined;
    /** The AWS account ID. Required when `auth_type` is `oidc_aws`. */
    account_id?: string | undefined;
    /** The AWS IAM role name. Required when `auth_type` is `oidc_aws`. */
    role_name?: string | undefined;
    /** The CodeArtifact domain. Required when `auth_type` is `oidc_aws`. */
    domain?: string | undefined;
    /** The CodeArtifact domain owner (AWS account ID). Required when `auth_type` is `oidc_aws`. */
    domain_owner?: string | undefined;
    /** The JFrog OIDC provider name. Required when `auth_type` is `oidc_jfrog`. */
    jfrog_oidc_provider_name?: string | undefined;
    /** The OIDC audience. Optional for `oidc_aws`, `oidc_jfrog`, and `oidc_gcp`, and required for `oidc_cloudsmith` auth types. */
    audience?: string | undefined;
    /** The JFrog identity mapping name. Optional for `oidc_jfrog` auth type. */
    identity_mapping_name?: string | undefined;
    /** The Cloudsmith organization namespace. Required when `auth_type` is `oidc_cloudsmith`. */
    namespace?: string | undefined;
    /** The Cloudsmith service account slug. Required when `auth_type` is `oidc_cloudsmith`. */
    service_slug?: string | undefined;
    /** The Cloudsmith API host. Optional for `oidc_cloudsmith` auth type. If omitted, `api.cloudsmith.io` is used by default. */
    api_host?: string | undefined;
    /** The full resource name of the GCP Workload Identity Provider (e.g. `projects/<NUM>/locations/global/workloadIdentityPools/<POOL>/providers/<PROVIDER>`). Required when `auth_type` is `oidc_gcp`. */
    workload_identity_provider?: string | undefined;
    /** The GCP service account email to impersonate. Optional for `oidc_gcp` auth type. If omitted, the federated token is used directly (direct WIF). */
    service_account?: string | undefined;
}
export interface UpdateOrgPrivateRegistryResponse {
}
export type CreateOrgPrivateRegistryError = GithubOpError;
/** Create a private registry for an organization Creates a private registry configuration with an encrypted value for an organization. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." For OIDC-based registries (`oidc_azure`, `oidc_aws`, `oidc_jfrog`, `oidc_cloudsmith`, or `oidc_gcp`), the `encrypted_value` and `key_id` fields should be omitted. For anonymous registries (`anonymous`), the `username`, `encrypted_value`, and `key_id` fields must be omitted. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const createOrgPrivateRegistry: API.OperationMethod<CreateOrgPrivateRegistryRequest, OrgPrivateRegistryConfigurationWithSelectedRepositories, CreateOrgPrivateRegistryError, GithubOpContext>;
export type DeleteOrgPrivateRegistryError = GithubOpError;
/** Delete a private registry for an organization Delete a private registry configuration at the organization-level. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteOrgPrivateRegistry: API.OperationMethod<DeleteOrgPrivateRegistryRequest, DeleteOrgPrivateRegistryResponse, DeleteOrgPrivateRegistryError, GithubOpContext>;
export type GetOrgPrivateRegistryError = GithubOpError;
/** Get a private registry for an organization Get the configuration of a single private registry defined for an organization, omitting its encrypted value. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getOrgPrivateRegistry: API.OperationMethod<GetOrgPrivateRegistryRequest, OrgPrivateRegistryConfiguration, GetOrgPrivateRegistryError, GithubOpContext>;
export type GetOrgPublicKeyError = GithubOpError;
/** Get private registries public key for an organization Gets the org public key, which is needed to encrypt private registry secrets. You need to encrypt a secret before you can create or update secrets. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getOrgPublicKey: API.OperationMethod<GetOrgPublicKeyRequest, GetOrgPublicKeyResponse, GetOrgPublicKeyError, GithubOpContext>;
export type ListOrgPrivateRegistriesError = GithubOpError;
/** List private registries for an organization Lists all private registry configurations available at the organization-level without revealing their encrypted values. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listOrgPrivateRegistries: API.PaginatedOperationMethod<ListOrgPrivateRegistriesRequest, ListOrgPrivateRegistriesResponse, ListOrgPrivateRegistriesError, GithubOpContext, OrgPrivateRegistryConfiguration>;
export type UpdateOrgPrivateRegistryError = GithubOpError;
/** Update a private registry for an organization Updates a private registry configuration with an encrypted value for an organization. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." For OIDC-based registries (`oidc_azure`, `oidc_aws`, `oidc_jfrog`, `oidc_cloudsmith`, or `oidc_gcp`), the `encrypted_value` and `key_id` fields should be omitted. For anonymous registries (`anonymous`), the `username`, `encrypted_value`, and `key_id` fields must be omitted, and `auth_type` cannot be changed to or from `anonymous`. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const updateOrgPrivateRegistry: API.OperationMethod<UpdateOrgPrivateRegistryRequest, UpdateOrgPrivateRegistryResponse, UpdateOrgPrivateRegistryError, GithubOpContext>;
//# sourceMappingURL=private_registries.d.ts.map