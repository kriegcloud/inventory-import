import * as Layer from "effect/Layer";
import { SearchIssues } from "./SearchIssues.ts";
/**
 * Implementation of {@link SearchIssues} with the provider's current credentials.
 * Provide it on an `Action` or another deploy-time Effect.
 *
 * @layer
 * @product Issue
 * @provides GitHub.SearchIssues
 */
export declare const SearchIssuesLocal: Layer.Layer<SearchIssues, import("@distilled.cloud/github").ConfigError | import("@distilled.cloud/github").GithubAppAuthError, import("@distilled.cloud/github").Credentials>;
//# sourceMappingURL=SearchIssuesLocal.d.ts.map