import * as Effect from "effect/Effect";
import * as Aggregate from "./Aggregate.ts";
import type { Plan } from "./Backfill.ts";
import * as Decision from "./Decision.ts";
import { DefinitionError } from "./DefinitionError.ts";
import type { Accepted, AggregateKit, DecisionKit, DecisionReceiptJson, Delivery, EnvelopeJson, Json, PolicyKit, ReceiptJson, Root, StreamEntry, ViewEntry, ViewKit } from "./Platform.ts";
import type * as Policy from "./Policy.ts";
import type * as Projection from "./Projection.ts";
import type * as Query from "./Query.ts";
import type * as DomainStream from "./Stream.ts";
import * as Telemetry from "./Telemetry.ts";
import type * as View from "./View.ts";
/**
 * The entities of a Domain.
 */
export interface Definitions {
    readonly aggregates: ReadonlyArray<Aggregate.Any>;
    /** The decisions that implement commands across several aggregates. */
    readonly decisions?: ReadonlyArray<Decision.Any>;
    readonly views: ReadonlyArray<View.Any>;
    readonly policies: ReadonlyArray<Policy.Any>;
    readonly projections: ReadonlyArray<Projection.Any>;
    readonly streams: ReadonlyArray<DomainStream.Any>;
    readonly queries?: ReadonlyArray<Query.Any>;
}
/**
 * What a projection input carries for `Stream.append`, out of sight of the
 * handler's types: who is writing, where in its input log, and the source
 * event being handled. Appends count up per input, so a re-run of the same
 * input makes exactly the same writes.
 *
 * @internal
 */
export declare const InputMeta: unique symbol;
/** @internal */
export interface InputMetaValue {
    readonly projection: string;
    readonly key: string;
    /** The projection's generation: its input log starts over at each one. */
    readonly generation: number;
    readonly position: number;
    readonly source: string;
    readonly sourceSeq: number;
    /** The aggregate event the input derives from, through any views. */
    readonly root: Root;
    readonly at: number;
    readonly commandId: string;
    /** Appends made for this input so far in this run. */
    appends: number;
}
export { DefinitionError };
/** @internal */
export declare const encodeEnvelope: (envelope: Aggregate.Envelope, trace?: Telemetry.TraceJson) => EnvelopeJson;
/** @internal */
export declare const decodeEnvelope: (json: EnvelopeJson) => Aggregate.Envelope;
/** The aggregate event a delivery derives from: its own, unless a view passed it on. @internal */
export declare const rootOf: (delivery: Delivery) => Root;
/**
 * The pure semantics shared by every platform: decide, evolve, reply,
 * routing and view application, plus every codec.
 */
export interface Kernel {
    readonly aggregateKit: (aggregate: Aggregate.Any, deliver: (d: Delivery) => Effect.Effect<void>) => Omit<AggregateKit, "push">;
    readonly decisionKit: (decision: Decision.Any) => DecisionKit;
    readonly viewKit: (view: View.Any, deliver: (d: Delivery) => Effect.Effect<void>) => Omit<ViewKit, "push">;
    readonly policyKit: (policy: Policy.Any, handler: Policy.Handler<unknown>) => PolicyKit;
    /** Decode a run of a projection key's input log into handler inputs. */
    readonly projectionInputs: (projection: Projection.Any, key: string, batch: ReadonlyArray<Accepted>) => Effect.Effect<ReadonlyArray<unknown>>;
    /**
     * The keys of a projection an event of a source (an aggregate instance, or
     * a view key with its encoded `state` after the event) is routed to: empty
     * if the projection does not consume it.
     */
    readonly projectionKeys: (projection: Projection.Any, source: string, id: string, event: {
        readonly _tag: string;
    }, seq: number, state?: Json) => ReadonlyArray<string>;
    /** The keys of a view an event of a source (as for `projectionKeys`) reaches. */
    readonly viewKeys: (view: View.Any, source: string, id: string, event: {
        readonly _tag: string;
    }, seq: number, state?: Json) => ReadonlyArray<string>;
    /** Every view and projection in the model, by `CatchUp.targetId`: what catches up. */
    readonly targets: ReadonlyArray<string>;
    /**
     * Whether every key of a consumer (by `CatchUp.targetId`) hears from exactly one
     * source instance, the one with its own id: it needs no merge and no barrier.
     */
    readonly singleSource: (target: string) => boolean;
    /**
     * The sources (aggregates and views, by name) a consumer reads, by
     * `CatchUp.targetId`; `undefined` for one this model doesn't have.
     */
    readonly sourcesOf: (target: string) => ReadonlyArray<string> | undefined;
    /** What a backfill needs to know of a consumer; `undefined` for one this model doesn't have. */
    readonly planOf: (target: string) => Plan | undefined;
    /**
     * Route a source instance's stored rows (as its `log` returns them) to one
     * consumer only, as history: each row's seq and its deliveries.
     */
    readonly history: (target: string, source: string, id: string, rows: ReadonlyArray<unknown>) => Effect.Effect<ReadonlyArray<{
        readonly seq: number;
        readonly deliveries: ReadonlyArray<Delivery>;
    }>>;
    /**
     * Set a view's or projection's version (`view:Name` or `projection:Name`).
     * Bumping it rebuilds the consumer, and every view or projection that reads
     * it, from the history. Set every version before the platform starts.
     */
    readonly setVersion: (consumer: string, version: number) => void;
    /** A consumer's generation: its version plus those of the views it reads. */
    readonly generationOf: (kind: "view" | "projection", name: string) => number;
    /** The generation of a consumer's storage: a view rebuilt in place keeps it. */
    readonly classGenerationOf: (kind: "view" | "projection", name: string) => number;
    /** A consumer's id, by `CatchUp.targetId`. */
    readonly targetIdOf: (kind: "view" | "projection", name: string) => string;
    /** Whether a view is rebuilt in place: keyed by the one aggregate it reads. */
    readonly inPlace: (kind: "view" | "projection", name: string) => boolean;
    /** The projection that writes a stream, if any. */
    readonly writerOf: (stream: DomainStream.Any) => Projection.Any | undefined;
    readonly decodeStreamEntry: (entry: StreamEntry) => Effect.Effect<DomainStream.Entry<unknown, string>>;
    readonly encodeCommand: (aggregate: Aggregate.Any, command: {
        readonly _tag: string;
    }) => Effect.Effect<Json>;
    readonly decodeRejection: (aggregate: Aggregate.Any, json: Json) => unknown;
    readonly decodeReceipt: (aggregate: Aggregate.Any, commandTag: string, json: ReceiptJson) => Effect.Effect<Aggregate.Receipt>;
    readonly decodeState: (aggregate: Aggregate.Any, json: Json) => unknown;
    readonly encodeDecisionCommand: (decision: Decision.Any, command: {
        readonly _tag: string;
    }) => Effect.Effect<Json>;
    readonly decodeDecisionRejection: (decision: Decision.Any, json: Json) => unknown;
    readonly decodeDecisionReceipt: (decision: Decision.Any, json: DecisionReceiptJson) => Effect.Effect<Decision.Receipt>;
    readonly decodeViewState: (view: View.Any, json: Json) => unknown;
    readonly decodeViewEntry: (view: View.Any, entry: ViewEntry) => Effect.Effect<View.Entry<unknown, unknown>>;
    readonly decodeEvent: (json: Json) => Effect.Effect<unknown>;
    readonly encodeEvent: (event: {
        readonly _tag: string;
    }) => Effect.Effect<Json>;
}
/**
 * Build the kernel for a set of definitions. Validates tags and routing, and
 * dies with a {@link DefinitionError} for every problem, in definition order:
 * each one is a defect of the Cause.
 */
export declare const make: (definitions: Definitions, telemetry?: Telemetry.Resolved) => Effect.Effect<Kernel>;
//# sourceMappingURL=Kernel.d.ts.map