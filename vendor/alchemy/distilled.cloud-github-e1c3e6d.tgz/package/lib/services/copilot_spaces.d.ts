import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The type of actor (user or team). */
export type AddCollaboratorForOrgRequestActorType = "User" | "Team";
/** The role to grant to the collaborator. */
export type AddCollaboratorForOrgRequestRole = "reader" | "writer" | "admin";
export interface AddCollaboratorForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The type of actor (user or team). */
    actor_type: AddCollaboratorForOrgRequestActorType | (string & {});
    /** The username (for users) or team slug (for teams). The numeric ID of a user or team is also accepted. */
    actor_identifier: string;
    /** The role to grant to the collaborator. */
    role: AddCollaboratorForOrgRequestRole | (string & {});
}
/** The collaborator actor type. */
export type CopilotSpaceCollaboratorCase0ActorType = "User";
/** The role granted to the collaborator */
export type CopilotSpaceCollaboratorCase0Role = "reader" | "writer" | "admin";
export interface CopilotSpaceCollaboratorCase0 {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
    /** The collaborator actor type. */
    actor_type: CopilotSpaceCollaboratorCase0ActorType;
    /** The role granted to the collaborator */
    role: CopilotSpaceCollaboratorCase0Role;
}
/** The collaborator actor type. */
export type CopilotSpaceCollaboratorCase1ActorType = "Team";
/** The role granted to the collaborator */
export type CopilotSpaceCollaboratorCase1Role = "reader" | "writer" | "admin";
export type CopilotSpaceCollaboratorCase1Type = "Team";
export interface CopilotSpaceCollaboratorCase1 {
    /** The collaborator actor type. */
    actor_type: CopilotSpaceCollaboratorCase1ActorType;
    /** The role granted to the collaborator */
    role: CopilotSpaceCollaboratorCase1Role;
    id: number;
    node_id: string;
    name: string;
    slug: string;
    type: CopilotSpaceCollaboratorCase1Type;
    description?: string | null | undefined;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    members_url?: string | undefined;
    repositories_url?: string | undefined;
    organization_id?: number | undefined;
    parent?: unknown | null | undefined;
}
/** A collaborator (user or team) of a Copilot Space */
export type CopilotSpaceCollaborator = CopilotSpaceCollaboratorCase0 | CopilotSpaceCollaboratorCase1;
export type AddCollaboratorForOrgResponse = CopilotSpaceCollaborator;
/** The type of actor (must be `User` for user-owned spaces; `Team` will be rejected). */
export type AddCollaboratorForUserRequestActorType = "User" | "Team";
/** The role to grant to the collaborator. */
export type AddCollaboratorForUserRequestRole = "reader" | "writer" | "admin";
export interface AddCollaboratorForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The type of actor (must be `User` for user-owned spaces; `Team` will be rejected). */
    actor_type: AddCollaboratorForUserRequestActorType | (string & {});
    /** The username of the collaborator. The numeric user ID is also accepted. */
    actor_identifier: string;
    /** The role to grant to the collaborator. */
    role: AddCollaboratorForUserRequestRole | (string & {});
}
export type AddCollaboratorForUserResponse = CopilotSpaceCollaborator;
/** The base role that determines default permissions for organization members. - `no_access`: No default access (default) - `reader`: Organization members can read the space - `writer`: Organization members can read and edit the space - `admin`: Organization members have full admin access to the space */
export type CreateForOrgRequestBaseRole = "reader" | "writer" | "admin" | "no_access";
/** The type of resource. */
export type CreateForOrgRequestResourcesAttributesItemResourceType = "repository" | "github_file" | "free_text" | "github_issue" | "github_pull_request" | "media_content" | "uploaded_text_file";
/** Metadata specific to the resource type. */
export interface CreateForOrgRequestResourcesAttributesItemMetadata {
    /** Repository ID for repository or file resources. */
    repository_id?: number | undefined;
    /** File path for file resources. */
    file_path?: string | undefined;
    /** Text content for free text resources. */
    text?: string | undefined;
    /** Name for the resource. */
    name?: string | undefined;
    /** Issue or PR number. */
    number?: number | undefined;
}
export interface CreateForOrgRequestResourcesAttributesItem {
    /** The type of resource. */
    resource_type?: CreateForOrgRequestResourcesAttributesItemResourceType | (string & {}) | undefined;
    /** Metadata specific to the resource type. */
    metadata?: CreateForOrgRequestResourcesAttributesItemMetadata | undefined;
}
/** Resources to attach to the space. */
export type CreateForOrgRequestResourcesAttributesList = Array<CreateForOrgRequestResourcesAttributesItem>;
export interface CreateForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the Copilot Space. */
    name: string;
    /** A description of the Copilot Space. */
    description?: string | undefined;
    /** General instructions for the Copilot Space. */
    general_instructions?: string | undefined;
    /** The base role that determines default permissions for organization members. - `no_access`: No default access (default) - `reader`: Organization members can read the space - `writer`: Organization members can read and edit the space - `admin`: Organization members have full admin access to the space */
    base_role?: CreateForOrgRequestBaseRole | (string & {}) | undefined;
    /** Resources to attach to the space. */
    resources_attributes?: CreateForOrgRequestResourcesAttributesList | undefined;
}
/** The base role that determines default permissions. - `no_access`: No default access - `reader`: Default read permissions - `writer`: Default write permissions (organization spaces only) - `admin`: Default admin permissions (organization spaces only) */
export type CopilotSpaceBaseRole = "reader" | "writer" | "admin" | "no_access";
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** A GitHub organization. */
export interface OrganizationSimple {
    login: string;
    id: number;
    node_id: string;
    url: string;
    repos_url: string;
    events_url: string;
    hooks_url: string;
    issues_url: string;
    members_url: string;
    public_members_url: string;
    avatar_url: string;
    description: string | null;
}
/** The user or organization that owns this space. */
export type CopilotSpaceOwner = SimpleUser | OrganizationSimple;
/** The type of resource. */
export type CopilotSpaceResourcesAttributesItemResourceType = "repository" | "github_file" | "free_text" | "github_issue" | "github_pull_request" | "media_content" | "uploaded_text_file";
/** Metadata specific to the resource type. */
export interface CopilotSpaceResourcesAttributesItemMetadata {
    /** Repository ID for repository or file resources. */
    repository_id?: number | undefined;
    /** File path for file resources. */
    file_path?: string | undefined;
    /** Text content for free text resources. */
    text?: string | undefined;
    /** Name for the resource. */
    name?: string | undefined;
    /** Issue or PR number. */
    number?: number | undefined;
    /** Chat attachment ID for uploaded files or media. */
    copilot_chat_attachment_id?: number | undefined;
    /** Media type for media content resources. */
    media_type?: string | undefined;
    /** URL for media content resources. */
    url?: string | undefined;
    /** Height for media content resources. */
    height?: number | undefined;
    /** Width for media content resources. */
    width?: number | undefined;
}
export interface CopilotSpaceResourcesAttributesItem {
    /** The unique identifier of the resource. */
    id?: number | undefined;
    /** The type of resource. */
    resource_type?: CopilotSpaceResourcesAttributesItemResourceType | undefined;
    /** The unique identifier of the chat attachment for uploaded files or media content. */
    copilot_chat_attachment_id?: number | null | undefined;
    /** The date and time the resource was created. */
    created_at?: string | undefined;
    /** The date and time the resource was last updated. */
    updated_at?: string | undefined;
    /** Metadata specific to the resource type. */
    metadata?: CopilotSpaceResourcesAttributesItemMetadata | undefined;
}
/** Resources attached to the space. */
export type CopilotSpaceResourcesAttributesList = Array<CopilotSpaceResourcesAttributesItem>;
/** A GitHub Copilot Space represents an interactive AI workspace where users can ask questions and get assistance. */
export interface CopilotSpace {
    /** The unique identifier of the space. */
    id: number;
    /** The number that identifies the space within its owner. */
    number: number;
    /** The display name of the space. */
    name: string;
    /** A description of the space. */
    description?: string | null | undefined;
    /** General instructions for the Copilot Space. */
    general_instructions?: string | null | undefined;
    /** The base role that determines default permissions. - `no_access`: No default access - `reader`: Default read permissions - `writer`: Default write permissions (organization spaces only) - `admin`: Default admin permissions (organization spaces only) */
    base_role: CopilotSpaceBaseRole;
    /** The user or organization that owns this space. */
    owner: CopilotSpaceOwner;
    creator: SimpleUser;
    /** The date and time the space was created. */
    created_at: string;
    /** The date and time the space was last updated. */
    updated_at: string;
    /** The HTML URL of the space. */
    html_url: string;
    /** The API URL of the space. */
    api_url: string;
    /** Resources attached to the space. */
    resources_attributes?: CopilotSpaceResourcesAttributesList | undefined;
}
/** The base role that determines default permissions for the space. - `no_access`: No default access (default) - `reader`: Makes the space publicly readable Note: User spaces do not support writer or admin base roles. */
export type CreateForUserRequestBaseRole = "reader" | "no_access";
/** The type of resource. */
export type CreateForUserRequestResourcesAttributesItemResourceType = "repository" | "github_file" | "free_text" | "github_issue" | "github_pull_request" | "media_content" | "uploaded_text_file";
/** Metadata specific to the resource type. */
export type CreateForUserRequestResourcesAttributesItemMetadata = CreateForOrgRequestResourcesAttributesItemMetadata;
export interface CreateForUserRequestResourcesAttributesItem {
    /** The type of resource. */
    resource_type?: CreateForUserRequestResourcesAttributesItemResourceType | (string & {}) | undefined;
    /** Metadata specific to the resource type. */
    metadata?: CreateForOrgRequestResourcesAttributesItemMetadata | undefined;
}
/** Resources to attach to the space. */
export type CreateForUserRequestResourcesAttributesList = Array<CreateForUserRequestResourcesAttributesItem>;
export interface CreateForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The name of the Copilot Space. */
    name: string;
    /** A description of the Copilot Space. */
    description?: string | undefined;
    /** General instructions for the Copilot Space. */
    general_instructions?: string | undefined;
    /** The base role that determines default permissions for the space. - `no_access`: No default access (default) - `reader`: Makes the space publicly readable Note: User spaces do not support writer or admin base roles. */
    base_role?: CreateForUserRequestBaseRole | (string & {}) | undefined;
    /** Resources to attach to the space. */
    resources_attributes?: CreateForUserRequestResourcesAttributesList | undefined;
}
/** The type of resource to create. */
export type CreateResourceForOrgRequestResourceType = "repository" | "github_file" | "free_text" | "github_issue" | "github_pull_request";
/** Resource-specific metadata. */
export type CreateResourceForOrgRequestMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface CreateResourceForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The type of resource to create. */
    resource_type: CreateResourceForOrgRequestResourceType | (string & {});
    /** Resource-specific metadata. */
    metadata: CreateResourceForOrgRequestMetadataMap;
}
/** The type of the resource. */
export type CopilotSpaceResourceResourceType = "repository" | "github_file" | "free_text" | "github_issue" | "github_pull_request" | "media_content" | "uploaded_text_file";
/** Resource-specific metadata. The keys and values depend on the resource type. */
export type CopilotSpaceResourceMetadataMap = {
    [key: string]: unknown | undefined;
};
/** A resource attached to a Copilot Space. */
export interface CopilotSpaceResource {
    /** The unique identifier of the resource. */
    id: number;
    /** The type of the resource. */
    resource_type: CopilotSpaceResourceResourceType;
    /** The ID of the associated chat attachment, if any. */
    copilot_chat_attachment_id?: number | null | undefined;
    /** Resource-specific metadata. The keys and values depend on the resource type. */
    metadata: CopilotSpaceResourceMetadataMap;
    /** The date and time the resource was created. */
    created_at: string;
    /** The date and time the resource was last updated. */
    updated_at: string;
}
/** The type of resource to create. */
export type CreateResourceForUserRequestResourceType = "repository" | "github_file" | "free_text" | "github_issue" | "github_pull_request";
/** Resource-specific metadata. */
export type CreateResourceForUserRequestMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface CreateResourceForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The type of resource to create. */
    resource_type: CreateResourceForUserRequestResourceType | (string & {});
    /** Resource-specific metadata. */
    metadata: CreateResourceForUserRequestMetadataMap;
}
export interface DeleteForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
}
export interface DeleteForOrgResponse {
}
export interface DeleteForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
}
export interface DeleteForUserResponse {
}
export interface DeleteResourceForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The unique identifier of the resource. */
    space_resource_id: number;
}
export interface DeleteResourceForOrgResponse {
}
export interface DeleteResourceForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The unique identifier of the resource. */
    space_resource_id: number;
}
export interface DeleteResourceForUserResponse {
}
export interface GetForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
}
export interface GetForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
}
export interface GetResourceForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The unique identifier of the resource. */
    space_resource_id: number;
}
export interface GetResourceForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The unique identifier of the resource. */
    space_resource_id: number;
}
export interface ListCollaboratorsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
}
/** The list of collaborators for this Copilot Space. */
export type ListCollaboratorsForOrgResponseCollaboratorsList = Array<CopilotSpaceCollaborator>;
export interface ListCollaboratorsForOrgResponse {
    /** The list of collaborators for this Copilot Space. */
    collaborators: ListCollaboratorsForOrgResponseCollaboratorsList;
}
export interface ListCollaboratorsForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
}
/** The list of collaborators for this Copilot Space. */
export type ListCollaboratorsForUserResponseCollaboratorsList = Array<CopilotSpaceCollaborator>;
export interface ListCollaboratorsForUserResponse {
    /** The list of collaborators for this Copilot Space. */
    collaborators: ListCollaboratorsForUserResponseCollaboratorsList;
}
export interface ListForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. */
    after?: string | undefined;
}
/** The list of Copilot Spaces on this page of results. */
export type ListForOrgResponseSpacesList = Array<CopilotSpace>;
export interface ListForOrgResponse {
    /** The list of Copilot Spaces on this page of results. */
    spaces: ListForOrgResponseSpacesList;
}
export interface ListForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. */
    after?: string | undefined;
}
/** The list of Copilot Spaces on this page of results. */
export type ListForUserResponseSpacesList = Array<CopilotSpace>;
export interface ListForUserResponse {
    /** The list of Copilot Spaces on this page of results. */
    spaces: ListForUserResponseSpacesList;
}
export interface ListResourcesForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
}
/** The list of resources attached to this Copilot Space. */
export type ListResourcesForOrgResponseResourcesList = Array<CopilotSpaceResource>;
export interface ListResourcesForOrgResponse {
    /** The list of resources attached to this Copilot Space. */
    resources: ListResourcesForOrgResponseResourcesList;
}
export interface ListResourcesForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
}
/** The list of resources attached to this Copilot Space. */
export type ListResourcesForUserResponseResourcesList = Array<CopilotSpaceResource>;
export interface ListResourcesForUserResponse {
    /** The list of resources attached to this Copilot Space. */
    resources: ListResourcesForUserResponseResourcesList;
}
export type RemoveCollaboratorForOrgRequestActorType = "User" | "Team";
export interface RemoveCollaboratorForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The type of actor (user or team). */
    actor_type: RemoveCollaboratorForOrgRequestActorType | (string & {});
    /** The username (for users) or team slug (for teams). The numeric ID of a user or team is also accepted. */
    actor_identifier: string;
}
export interface RemoveCollaboratorForOrgResponse {
}
export type RemoveCollaboratorForUserRequestActorType = "User" | "Team";
export interface RemoveCollaboratorForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The type of actor (must be `User` for user-owned spaces; `Team` will be rejected). */
    actor_type: RemoveCollaboratorForUserRequestActorType | (string & {});
    /** The username of the collaborator. The numeric user ID is also accepted. */
    actor_identifier: string;
}
export interface RemoveCollaboratorForUserResponse {
}
export type UpdateCollaboratorForOrgRequestActorType = "User" | "Team";
/** The new role to grant to the collaborator. Use `no_access` to remove the collaborator. */
export type UpdateCollaboratorForOrgRequestRole = "reader" | "writer" | "admin" | "no_access";
export interface UpdateCollaboratorForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The type of actor (user or team). */
    actor_type: UpdateCollaboratorForOrgRequestActorType | (string & {});
    /** The username (for users) or team slug (for teams). The numeric ID of a user or team is also accepted. */
    actor_identifier: string;
    /** The new role to grant to the collaborator. Use `no_access` to remove the collaborator. */
    role: UpdateCollaboratorForOrgRequestRole | (string & {});
}
export type UpdateCollaboratorForOrgResponse = CopilotSpaceCollaborator;
export type UpdateCollaboratorForUserRequestActorType = "User" | "Team";
/** The new role to grant to the collaborator. Use `no_access` to remove the collaborator. */
export type UpdateCollaboratorForUserRequestRole = "reader" | "writer" | "admin" | "no_access";
export interface UpdateCollaboratorForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The type of actor (must be `User` for user-owned spaces; `Team` will be rejected). */
    actor_type: UpdateCollaboratorForUserRequestActorType | (string & {});
    /** The username of the collaborator. The numeric user ID is also accepted. */
    actor_identifier: string;
    /** The new role to grant to the collaborator. Use `no_access` to remove the collaborator. */
    role: UpdateCollaboratorForUserRequestRole | (string & {});
}
export type UpdateCollaboratorForUserResponse = CopilotSpaceCollaborator;
/** The base role that determines default permissions for organization members. Changing this field requires admin permissions. - `no_access`: No default access (default) - `reader`: Organization members can read the space - `writer`: Organization members can read and edit the space - `admin`: Organization members have full admin access to the space */
export type UpdateForOrgRequestBaseRole = "reader" | "writer" | "admin" | "no_access";
/** The type of resource. */
export type UpdateForOrgRequestResourcesAttributesItemResourceType = "repository" | "github_file" | "free_text" | "github_issue" | "github_pull_request" | "media_content" | "uploaded_text_file";
/** Metadata specific to the resource type. */
export type UpdateForOrgRequestResourcesAttributesItemMetadata = CreateForOrgRequestResourcesAttributesItemMetadata;
export interface UpdateForOrgRequestResourcesAttributesItem {
    /** The type of resource. */
    resource_type?: UpdateForOrgRequestResourcesAttributesItemResourceType | (string & {}) | undefined;
    /** Metadata specific to the resource type. */
    metadata?: CreateForOrgRequestResourcesAttributesItemMetadata | undefined;
}
/** Resources to attach to the space. */
export type UpdateForOrgRequestResourcesAttributesList = Array<UpdateForOrgRequestResourcesAttributesItem>;
export interface UpdateForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The name of the Copilot Space. */
    name?: string | undefined;
    /** A description of the Copilot Space. */
    description?: string | undefined;
    /** General instructions for the Copilot Space. */
    general_instructions?: string | undefined;
    /** The base role that determines default permissions for organization members. Changing this field requires admin permissions. - `no_access`: No default access (default) - `reader`: Organization members can read the space - `writer`: Organization members can read and edit the space - `admin`: Organization members have full admin access to the space */
    base_role?: UpdateForOrgRequestBaseRole | (string & {}) | undefined;
    /** Resources to attach to the space. */
    resources_attributes?: UpdateForOrgRequestResourcesAttributesList | undefined;
}
/** The base role that determines default permissions for the space. Changing this field requires admin permissions. - `no_access`: No default access (default) - `reader`: Makes the space publicly readable Note: User spaces do not support writer or admin base roles. */
export type UpdateForUserRequestBaseRole = "reader" | "no_access";
/** The type of resource. */
export type UpdateForUserRequestResourcesAttributesItemResourceType = "repository" | "github_file" | "free_text" | "github_issue" | "github_pull_request" | "media_content" | "uploaded_text_file";
/** Metadata specific to the resource type. */
export type UpdateForUserRequestResourcesAttributesItemMetadata = CreateForOrgRequestResourcesAttributesItemMetadata;
export interface UpdateForUserRequestResourcesAttributesItem {
    /** The type of resource. */
    resource_type?: UpdateForUserRequestResourcesAttributesItemResourceType | (string & {}) | undefined;
    /** Metadata specific to the resource type. */
    metadata?: CreateForOrgRequestResourcesAttributesItemMetadata | undefined;
}
/** Resources to attach to the space. */
export type UpdateForUserRequestResourcesAttributesList = Array<UpdateForUserRequestResourcesAttributesItem>;
export interface UpdateForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The name of the Copilot Space. */
    name?: string | undefined;
    /** A description of the Copilot Space. */
    description?: string | undefined;
    /** General instructions for the Copilot Space. */
    general_instructions?: string | undefined;
    /** The base role that determines default permissions for the space. Changing this field requires admin permissions. - `no_access`: No default access (default) - `reader`: Makes the space publicly readable Note: User spaces do not support writer or admin base roles. */
    base_role?: UpdateForUserRequestBaseRole | (string & {}) | undefined;
    /** Resources to attach to the space. */
    resources_attributes?: UpdateForUserRequestResourcesAttributesList | undefined;
}
/** Updated resource-specific metadata. */
export type UpdateResourceForOrgRequestMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface UpdateResourceForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The unique identifier of the resource. */
    space_resource_id: number;
    /** Updated resource-specific metadata. */
    metadata?: UpdateResourceForOrgRequestMetadataMap | undefined;
}
/** Updated resource-specific metadata. */
export type UpdateResourceForUserRequestMetadataMap = {
    [key: string]: unknown | undefined;
};
export interface UpdateResourceForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the Copilot Space. */
    space_number: number;
    /** The unique identifier of the resource. */
    space_resource_id: number;
    /** Updated resource-specific metadata. */
    metadata?: UpdateResourceForUserRequestMetadataMap | undefined;
}
export type AddCollaboratorForOrgError = GithubOpError;
/** Add a collaborator to an organization Copilot Space Adds a collaborator (user or team) to a specific Copilot Space owned by an organization. The authenticated user must have appropriate permissions to manage collaborators. **Note:** When adding users as collaborators, they must already be members of the organization. When adding teams as collaborators, they must be defined in the organization. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const addCollaboratorForOrg: API.OperationMethod<AddCollaboratorForOrgRequest, AddCollaboratorForOrgResponse, AddCollaboratorForOrgError, GithubOpContext>;
export type AddCollaboratorForUserError = GithubOpError;
/** Add a collaborator to a Copilot Space for a user Adds a collaborator to a specific Copilot Space owned by a user. The authenticated user must be the owner of the space or have admin access to the space. Team collaborators are not supported for user-owned Copilot Spaces. OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const addCollaboratorForUser: API.OperationMethod<AddCollaboratorForUserRequest, AddCollaboratorForUserResponse, AddCollaboratorForUserError, GithubOpContext>;
export type CreateForOrgError = GithubOpError;
/** Create an organization Copilot Space Creates a new Copilot Space owned by an organization. The authenticated user must have permissions to create spaces in the organization. Organization members with appropriate permissions can create Copilot Spaces to be shared within their organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by the submitted resources. */
export declare const createForOrg: API.OperationMethod<CreateForOrgRequest, CopilotSpace, CreateForOrgError, GithubOpContext>;
export type CreateForUserError = GithubOpError;
/** Create a Copilot Space for a user Creates a new Copilot Space owned by a user. Only the authenticated user can create spaces for their own account. Users can create personal Copilot Spaces for their individual use. OAuth app tokens and personal access tokens (classic) need the `read:user` scope to use this endpoint. */
export declare const createForUser: API.OperationMethod<CreateForUserRequest, CopilotSpace, CreateForUserError, GithubOpContext>;
export type CreateResourceForOrgError = GithubOpError;
/** Create a resource for an organization Copilot Space Creates a new resource in a specific Copilot Space owned by an organization. The authenticated user must have write permissions on the space. The following resource types are supported: `repository`, `github_file`, `free_text`, `github_issue`, `github_pull_request`. The `uploaded_text_file` and `media_content` types are not supported via this endpoint. For `github_file` resources, if a resource with the same repository, file path, and SHA already exists, the existing resource is returned with a `200` status. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space, including the resource being created. */
export declare const createResourceForOrg: API.OperationMethod<CreateResourceForOrgRequest, CopilotSpaceResource, CreateResourceForOrgError, GithubOpContext>;
export type CreateResourceForUserError = GithubOpError;
/** Create a resource for a Copilot Space for a user Creates a new resource in a specific Copilot Space owned by a user. The authenticated user must have write permissions on the space. The following resource types are supported: `repository`, `github_file`, `free_text`, `github_issue`, `github_pull_request`. The `uploaded_text_file` and `media_content` types are not supported via this endpoint. For `github_file` resources, if a resource with the same repository, file path, and SHA already exists, the existing resource is returned with a `200` status. OAuth app tokens and personal access tokens (classic) need the `write:user` scope to use this endpoint. */
export declare const createResourceForUser: API.OperationMethod<CreateResourceForUserRequest, CopilotSpaceResource, CreateResourceForUserError, GithubOpContext>;
export type DeleteForOrgError = GithubOpError;
/** Delete an organization Copilot Space Deletes a Copilot Space owned by an organization. The authenticated user must have permissions to delete spaces in the organization. **Warning:** This action is permanent and cannot be undone. Deleting a Copilot Space will remove all associated resources and configurations. Organization members with appropriate permissions can delete Copilot Spaces owned by their organization. OAuth app tokens and personal access tokens (classic) need both the `read:org` and `repo` scopes to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const deleteForOrg: API.OperationMethod<DeleteForOrgRequest, DeleteForOrgResponse, DeleteForOrgError, GithubOpContext>;
export type DeleteForUserError = GithubOpError;
/** Delete a Copilot Space for a user Deletes a Copilot Space owned by a user. The authenticated user must be the owner of the space. **Warning:** This action is permanent and cannot be undone. Deleting a space will remove all associated resources and configurations. OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const deleteForUser: API.OperationMethod<DeleteForUserRequest, DeleteForUserResponse, DeleteForUserError, GithubOpContext>;
export type DeleteResourceForOrgError = GithubOpError;
/** Delete a resource from an organization Copilot Space Deletes a resource from a specific Copilot Space owned by an organization. The authenticated user must have write permissions on the space. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const deleteResourceForOrg: API.OperationMethod<DeleteResourceForOrgRequest, DeleteResourceForOrgResponse, DeleteResourceForOrgError, GithubOpContext>;
export type DeleteResourceForUserError = GithubOpError;
/** Delete a resource from a Copilot Space for a user Deletes a resource from a specific Copilot Space owned by a user. The authenticated user must have write permissions on the space. OAuth app tokens and personal access tokens (classic) need the `write:user` scope to use this endpoint. */
export declare const deleteResourceForUser: API.OperationMethod<DeleteResourceForUserRequest, DeleteResourceForUserResponse, DeleteResourceForUserError, GithubOpContext>;
export type GetForOrgError = GithubOpError;
/** Get an organization Copilot Space Gets details about a specific Copilot Space owned by an organization. The authenticated user must have read access to the Space. Internal Spaces require the authenticated user to be a member of the organization or have been granted read permissions. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const getForOrg: API.OperationMethod<GetForOrgRequest, CopilotSpace, GetForOrgError, GithubOpContext>;
export type GetForUserError = GithubOpError;
/** Get a Copilot Space for a user Gets details about a specific Copilot Space owned by a user. The authenticated user must have read access to the Space. Private user spaces require the authenticated user to be the owner of the space. Public user spaces are accessible to any authenticated user. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getForUser: API.OperationMethod<GetForUserRequest, CopilotSpace, GetForUserError, GithubOpContext>;
export type GetResourceForOrgError = GithubOpError;
/** Get a resource for an organization Copilot Space Gets a specific resource attached to a Copilot Space owned by an organization. The authenticated user must have appropriate permissions to view the space. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const getResourceForOrg: API.OperationMethod<GetResourceForOrgRequest, CopilotSpaceResource, GetResourceForOrgError, GithubOpContext>;
export type GetResourceForUserError = GithubOpError;
/** Get a resource for a Copilot Space for a user Gets a specific resource attached to a Copilot Space owned by a user. The authenticated user must have appropriate permissions to view the space. OAuth app tokens and personal access tokens (classic) need the `read:user` scope to use this endpoint. */
export declare const getResourceForUser: API.OperationMethod<GetResourceForUserRequest, CopilotSpaceResource, GetResourceForUserError, GithubOpContext>;
export type ListCollaboratorsForOrgError = GithubOpError;
/** List collaborators for an organization Copilot Space Lists all collaborators for a specific Copilot Space owned by an organization. The authenticated user must have appropriate permissions to view collaborators. Each collaborator entry specifies which user or team has access to the space and at what level (reader, writer, or admin). The space owner (organization) is excluded from this list. **Note:** Team collaborators listed here are teams that are defined in the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const listCollaboratorsForOrg: API.OperationMethod<ListCollaboratorsForOrgRequest, ListCollaboratorsForOrgResponse, ListCollaboratorsForOrgError, GithubOpContext>;
export type ListCollaboratorsForUserError = GithubOpError;
/** List collaborators for a Copilot Space for a user Lists all collaborators for a specific Copilot Space owned by a user. The authenticated user must be the owner of the space or have admin access to the space. Each collaborator entry specifies which user has access to the space and at what level (reader, writer, or admin). The space owner is excluded from this list. Team collaborators are not supported for user-owned Copilot Spaces. OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const listCollaboratorsForUser: API.OperationMethod<ListCollaboratorsForUserRequest, ListCollaboratorsForUserResponse, ListCollaboratorsForUserError, GithubOpContext>;
export type ListForOrgError = GithubOpError;
/** List organization Copilot Spaces Lists Copilot Spaces owned by an organization. The authenticated user must have read access to the organization's Copilot Spaces. Only Spaces that are readable by the authenticated user are returned. This includes public Spaces and internal Spaces if the user is a member of the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in a space; spaces with inaccessible resources are omitted from the response. */
export declare const listForOrg: API.OperationMethod<ListForOrgRequest, ListForOrgResponse, ListForOrgError, GithubOpContext>;
export type ListForUserError = GithubOpError;
/** List Copilot Spaces for a user Lists Copilot Spaces owned by a user. The authenticated user must have read access to the user's Copilot Spaces. Only Spaces that are readable by the authenticated user are returned. This includes the user's own spaces, and public user spaces when accessing another user's spaces. OAuth app tokens and personal access tokens (classic) need the `read:user` scope to use this endpoint. */
export declare const listForUser: API.OperationMethod<ListForUserRequest, ListForUserResponse, ListForUserError, GithubOpContext>;
export type ListResourcesForOrgError = GithubOpError;
/** List resources for an organization Copilot Space Lists all resources attached to a specific Copilot Space owned by an organization. The authenticated user must have appropriate permissions to view the space. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const listResourcesForOrg: API.OperationMethod<ListResourcesForOrgRequest, ListResourcesForOrgResponse, ListResourcesForOrgError, GithubOpContext>;
export type ListResourcesForUserError = GithubOpError;
/** List resources for a Copilot Space for a user Lists all resources attached to a specific Copilot Space owned by a user. The authenticated user must have appropriate permissions to view the space. OAuth app tokens and personal access tokens (classic) need the `read:user` scope to use this endpoint. */
export declare const listResourcesForUser: API.OperationMethod<ListResourcesForUserRequest, ListResourcesForUserResponse, ListResourcesForUserError, GithubOpContext>;
export type RemoveCollaboratorForOrgError = GithubOpError;
/** Remove a collaborator from an organization Copilot Space Removes a collaborator from a specific Copilot Space owned by an organization. The authenticated user must have appropriate permissions to manage collaborators. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const removeCollaboratorForOrg: API.OperationMethod<RemoveCollaboratorForOrgRequest, RemoveCollaboratorForOrgResponse, RemoveCollaboratorForOrgError, GithubOpContext>;
export type RemoveCollaboratorForUserError = GithubOpError;
/** Remove a collaborator from a Copilot Space for a user Removes a collaborator from a specific Copilot Space owned by a user. The authenticated user must be the owner of the space or have admin access to the space. OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const removeCollaboratorForUser: API.OperationMethod<RemoveCollaboratorForUserRequest, RemoveCollaboratorForUserResponse, RemoveCollaboratorForUserError, GithubOpContext>;
export type UpdateCollaboratorForOrgError = GithubOpError;
/** Set a collaborator role for an organization Copilot Space Updates the role of a collaborator for a specific Copilot Space owned by an organization. The authenticated user must have appropriate permissions to manage collaborators. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space. */
export declare const updateCollaboratorForOrg: API.OperationMethod<UpdateCollaboratorForOrgRequest, UpdateCollaboratorForOrgResponse, UpdateCollaboratorForOrgError, GithubOpContext>;
export type UpdateCollaboratorForUserError = GithubOpError;
/** Set a collaborator role for a Copilot Space for a user Updates the role of a collaborator for a specific Copilot Space owned by a user. The authenticated user must be the owner of the space or have admin access to the space. OAuth app tokens and personal access tokens (classic) need the `user` scope to use this endpoint. */
export declare const updateCollaboratorForUser: API.OperationMethod<UpdateCollaboratorForUserRequest, UpdateCollaboratorForUserResponse, UpdateCollaboratorForUserError, GithubOpContext>;
export type UpdateForOrgError = GithubOpError;
/** Set an organization Copilot Space Updates a Copilot Space owned by an organization. The authenticated user must have permissions to update spaces in the organization. Organization members with appropriate permissions can update Copilot Spaces owned by their organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space, including any being added or updated. */
export declare const updateForOrg: API.OperationMethod<UpdateForOrgRequest, CopilotSpace, UpdateForOrgError, GithubOpContext>;
export type UpdateForUserError = GithubOpError;
/** Set a Copilot Space for a user Updates a Copilot Space owned by a user. Only the authenticated user can update spaces for their own account. Users can update their personal Copilot Spaces. OAuth app tokens and personal access tokens (classic) need the `read:user` scope to use this endpoint. */
export declare const updateForUser: API.OperationMethod<UpdateForUserRequest, CopilotSpace, UpdateForUserError, GithubOpContext>;
export type UpdateResourceForOrgError = GithubOpError;
/** Set a resource for an organization Copilot Space Updates the metadata of a resource in a specific Copilot Space owned by an organization. The authenticated user must have write permissions on the space. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. Fine-grained tokens and GitHub App user access tokens must have been granted access to the organization that owns the space. They must also have been granted access to every repository referenced by resources in the space, including the resource being updated. */
export declare const updateResourceForOrg: API.OperationMethod<UpdateResourceForOrgRequest, CopilotSpaceResource, UpdateResourceForOrgError, GithubOpContext>;
export type UpdateResourceForUserError = GithubOpError;
/** Set a resource for a Copilot Space for a user Updates the metadata of a resource in a specific Copilot Space owned by a user. The authenticated user must have write permissions on the space. OAuth app tokens and personal access tokens (classic) need the `write:user` scope to use this endpoint. */
export declare const updateResourceForUser: API.OperationMethod<UpdateResourceForUserRequest, CopilotSpaceResource, UpdateResourceForUserError, GithubOpContext>;
//# sourceMappingURL=copilot_spaces.d.ts.map