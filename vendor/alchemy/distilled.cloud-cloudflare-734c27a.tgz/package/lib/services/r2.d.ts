import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import * as T from "../traits.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const BucketAlreadyExists_base: S.TaggedErrorClass<"BucketAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class BucketAlreadyExists extends /*@__PURE__*/ BucketAlreadyExists_base {
}
declare const BucketNotEmpty_base: S.TaggedErrorClass<"BucketNotEmpty", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class BucketNotEmpty extends /*@__PURE__*/ BucketNotEmpty_base {
}
declare const BucketNotFound_base: S.TaggedErrorClass<"BucketNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class BucketNotFound extends /*@__PURE__*/ BucketNotFound_base {
}
declare const CustomDomainInUse_base: S.TaggedErrorClass<"CustomDomainInUse", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CustomDomainInUse extends /*@__PURE__*/ CustomDomainInUse_base {
}
declare const DomainNotFound_base: S.TaggedErrorClass<"DomainNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class DomainNotFound extends /*@__PURE__*/ DomainNotFound_base {
}
declare const EventNotificationConfigNotFound_base: S.TaggedErrorClass<"EventNotificationConfigNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class EventNotificationConfigNotFound extends /*@__PURE__*/ EventNotificationConfigNotFound_base {
}
declare const EventNotificationRuleConflict_base: S.TaggedErrorClass<"EventNotificationRuleConflict", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class EventNotificationRuleConflict extends /*@__PURE__*/ EventNotificationRuleConflict_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidBucketName_base: S.TaggedErrorClass<"InvalidBucketName", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidBucketName extends /*@__PURE__*/ InvalidBucketName_base {
}
declare const InvalidEventNotificationConfig_base: S.TaggedErrorClass<"InvalidEventNotificationConfig", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidEventNotificationConfig extends /*@__PURE__*/ InvalidEventNotificationConfig_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidUpstreamCredentials_base: S.TaggedErrorClass<"InvalidUpstreamCredentials", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidUpstreamCredentials extends /*@__PURE__*/ InvalidUpstreamCredentials_base {
}
declare const NoCorsConfiguration_base: S.TaggedErrorClass<"NoCorsConfiguration", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NoCorsConfiguration extends /*@__PURE__*/ NoCorsConfiguration_base {
}
declare const NoEventNotificationConfig_base: S.TaggedErrorClass<"NoEventNotificationConfig", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NoEventNotificationConfig extends /*@__PURE__*/ NoEventNotificationConfig_base {
}
declare const NoRoute_base: S.TaggedErrorClass<"NoRoute", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NoRoute extends /*@__PURE__*/ NoRoute_base {
}
declare const NoSuchBucket_base: S.TaggedErrorClass<"NoSuchBucket", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NoSuchBucket extends /*@__PURE__*/ NoSuchBucket_base {
}
declare const NoSuchKey_base: S.TaggedErrorClass<"NoSuchKey", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class NoSuchKey extends /*@__PURE__*/ NoSuchKey_base {
}
declare const QueueNotFound_base: S.TaggedErrorClass<"QueueNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class QueueNotFound extends /*@__PURE__*/ QueueNotFound_base {
}
declare const SuperSlurperJobOperationFailed_base: S.TaggedErrorClass<"SuperSlurperJobOperationFailed", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SuperSlurperJobOperationFailed extends /*@__PURE__*/ SuperSlurperJobOperationFailed_base {
}
declare const SuperSlurperPreconnectivityFailed_base: S.TaggedErrorClass<"SuperSlurperPreconnectivityFailed", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class SuperSlurperPreconnectivityFailed extends /*@__PURE__*/ SuperSlurperPreconnectivityFailed_base {
}
export interface AbortAllSuperSlurperJobRequest {
    accountId: string;
}
export type AbortAllSuperSlurperJobResponse = string;
export interface AbortSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export type AbortSuperSlurperJobResponse = string;
export type BucketsCreateRequestLocationHint = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export type BucketsCreateRequestStorageClass = "Standard" | "InfrequentAccess";
export type BucketsCreateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface CreateBucketRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    name: string;
    /** Location of the bucket. */
    locationHint?: BucketsCreateRequestLocationHint | (string & {}) | undefined;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsCreateRequestStorageClass | (string & {}) | undefined;
    jurisdiction?: BucketsCreateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsCreateResponseJurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export type BucketsCreateResponseLocation = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export type BucketsCreateResponseStorageClass = "Standard" | "InfrequentAccess";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBucketResponse {
    /** Creation timestamp. */
    creationDate?: string | null | undefined;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsCreateResponseJurisdiction | null | undefined;
    /** Location of the bucket. */
    location?: BucketsCreateResponseLocation | null | undefined;
    /** Name of the bucket. */
    name?: string | null | undefined;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsCreateResponseStorageClass | null | undefined;
}
export type BucketsDomainsCustomCreateRequestCiphersList = Array<string>;
export type BucketsDomainsCustomCreateRequestMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export type BucketsDomainsCustomCreateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface CreateBucketDomainCustomRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Name of the custom domain to be added. */
    domain: string;
    /** Whether to enable public bucket access at the custom domain. If undefined, the domain will be enabled. */
    enabled: boolean;
    /** Zone ID of the custom domain. */
    zoneId: string;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomCreateRequestCiphersList | undefined;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomCreateRequestMinTLS | (string & {}) | undefined;
    jurisdiction?: BucketsDomainsCustomCreateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsDomainsCustomCreateResponseCiphersList = Array<string>;
export type BucketsDomainsCustomCreateResponseMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBucketDomainCustomResponse {
    /** Domain name of the affected custom domain. */
    domain: string;
    /** Whether this bucket is publicly accessible at the specified custom domain. */
    enabled: boolean;
    /** Zone ID of the custom domain. */
    zoneId: string;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomCreateResponseCiphersList | null | undefined;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomCreateResponseMinTLS | null | undefined;
}
export type CreateBucketsJobRequestJobType = "prefixDelete" | "storageClassMigration";
export type CreateBucketsJobRequestDestinationStorageClass = "Standard" | "InfrequentAccess";
export type CreateBucketsJobRequestSourceStorageClass = "Standard" | "InfrequentAccess";
export type CreateBucketsJobRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface CreateBucketsJobRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    cfR2DataCatalogCheck?: string | undefined;
    jobType: CreateBucketsJobRequestJobType | (string & {});
    /** Prefix matched against object keys. A non-empty value must end in `/`. An empty string empties the entire bucket. */
    prefix?: string | undefined;
    destinationStorageClass?: CreateBucketsJobRequestDestinationStorageClass | (string & {}) | undefined;
    sourceStorageClass?: CreateBucketsJobRequestSourceStorageClass | (string & {}) | undefined;
    jurisdiction?: CreateBucketsJobRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type CreateBucketsJobResultPrefixDeleteJobType = "prefixDelete";
export interface CreateBucketsJobResultPrefixDeletePrefixDelete {
    /** Number of objects deleted by the job so far. */
    deletedObjects: number;
    /** The prefix matched against object keys. An empty string means the entire bucket. */
    prefix: string;
    /** True when the job was created to clear the entire bucket. This field can be absent on jobs created before Empty Bucket job tracking was introduced. */
    isBucketClear?: boolean | null | undefined;
}
export type CreateBucketsJobResultPrefixDeleteStatus = "ENQUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
export interface CreateBucketsJobResultPrefixDelete {
    /** Unique identifier used to poll the job. */
    id: string;
    /** The job kind. */
    jobType: CreateBucketsJobResultPrefixDeleteJobType;
    /** Details specific to the prefix-delete job. */
    prefixDelete: CreateBucketsJobResultPrefixDeletePrefixDelete;
    /** When the job was created. */
    startTime: string;
    /** Lifecycle status of a bucket background job. */
    status: CreateBucketsJobResultPrefixDeleteStatus;
    /** When the job finished. Absent while the job is still `ENQUEUED` or `RUNNING`. */
    endTime?: string | null | undefined;
}
export type CreateBucketsJobResultStorageClassMigrationJobType = "storageClassMigration";
export type CreateBucketsJobResultStorageClassMigrationStatus = "ENQUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
export type CreateBucketsJobResultStorageClassMigrationStorageClassMigrationDestinationStorageClass = "Standard" | "InfrequentAccess";
export type CreateBucketsJobResultStorageClassMigrationStorageClassMigrationSourceStorageClass = "Standard" | "InfrequentAccess";
export interface CreateBucketsJobResultStorageClassMigrationStorageClassMigration {
    /** The storage class objects are migrated to. The source and destination storage classes always differ. */
    destinationStorageClass: CreateBucketsJobResultStorageClassMigrationStorageClassMigrationDestinationStorageClass;
    /** Number of object versions migrated successfully. */
    migratedObjects: number;
    /** The storage class objects are migrated from. */
    sourceStorageClass: CreateBucketsJobResultStorageClassMigrationStorageClassMigrationSourceStorageClass;
    /** Payload bytes belonging to failed object versions. */
    failedBytes?: number | null | undefined;
    /** Number of object versions that failed migration. */
    failedObjects?: number | null | undefined;
    /** Object payload bytes migrated successfully. Present for Metadata Worker jobs. */
    migratedBytes?: number | null | undefined;
    /** Object metadata bytes migrated successfully. Present for Metadata Worker jobs. */
    migratedMetadataBytes?: number | null | undefined;
    /** Payload bytes belonging to skipped object versions. */
    skippedBytes?: number | null | undefined;
    /** Number of object versions skipped. */
    skippedObjects?: number | null | undefined;
}
export interface CreateBucketsJobResultStorageClassMigration {
    /** Unique identifier used to poll the job. */
    id: string;
    /** The job kind. */
    jobType: CreateBucketsJobResultStorageClassMigrationJobType;
    /** When the job was created. */
    startTime: string;
    /** Lifecycle status of a bucket background job. */
    status: CreateBucketsJobResultStorageClassMigrationStatus;
    storageClassMigration: CreateBucketsJobResultStorageClassMigrationStorageClassMigration;
    /** When the job finished. Absent while the job is still `ENQUEUED` or `RUNNING`. */
    endTime?: string | null | undefined;
}
export type CreateBucketsJobResult = CreateBucketsJobResultPrefixDelete | CreateBucketsJobResultStorageClassMigration;
export type CreateBucketsJobResponse = CreateBucketsJobResult;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret {
    accessKeyId: string;
    secretAccessKey: string;
}
export type SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaVendor = "s3";
export type SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaKeysList = Array<string>;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchema {
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
    vendor: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaVendor;
    /** Custom S3-compatible endpoint that must use https://. */
    endpoint?: string | undefined;
    keys?: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaKeysList | undefined;
    pathPrefix?: string | undefined;
    region?: string | undefined;
}
export interface SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret {
    clientEmail: string;
    privateKey: string;
}
export type SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaVendor = "gcs";
export type SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaKeysList = Array<string>;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchema {
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret;
    vendor: SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaVendor;
    keys?: SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaKeysList | undefined;
    pathPrefix?: string | undefined;
}
export type SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaSecret = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
export type SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaVendor = "r2";
export type SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaJurisdiction = "default" | "eu" | "us" | "fedramp";
export type SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaKeysList = Array<string>;
export interface SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchema {
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
    vendor: SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaVendor;
    jurisdiction?: SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaJurisdiction | (string & {}) | undefined;
    keys?: SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchemaKeysList | undefined;
    pathPrefix?: string | undefined;
}
export type SuperSlurperJobsCreateRequestSource = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchema | SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchema | SuperSlurperJobsCreateRequestSourceR2SlurperR2SourceSchema;
export type SuperSlurperJobsCreateRequestTargetSecret = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
export type SuperSlurperJobsCreateRequestTargetVendor = "r2";
export type SuperSlurperJobsCreateRequestTargetJurisdiction = "default" | "eu" | "us" | "fedramp";
export interface SuperSlurperJobsCreateRequestTarget {
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
    vendor: SuperSlurperJobsCreateRequestTargetVendor | (string & {});
    jurisdiction?: SuperSlurperJobsCreateRequestTargetJurisdiction | (string & {}) | undefined;
}
export interface CreateSuperSlurperJobRequest {
    accountId: string;
    overwrite?: boolean | undefined;
    source?: SuperSlurperJobsCreateRequestSource | undefined;
    target?: SuperSlurperJobsCreateRequestTarget | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSuperSlurperJobResponse {
    id?: string | null | undefined;
}
export type TemporaryCredentialsCreateRequestPermission = "admin-read-write" | "admin-read-only" | "object-read-write" | "object-read-only";
export type TemporaryCredentialsCreateRequestObjectsList = Array<string>;
export type TemporaryCredentialsCreateRequestPrefixesList = Array<string>;
export interface CreateTemporaryCredentialRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the R2 bucket. */
    bucket: string;
    /** Access key ID of the parent R2 API token. The temporary credentials cannot exceed this token's permissions. */
    parentAccessKeyId: string;
    /** Permissions allowed on the credentials. */
    permission: TemporaryCredentialsCreateRequestPermission | (string & {});
    /** Lifetime of the temporary credentials in seconds, up to 604800 seconds (7 days). */
    ttlSeconds: number;
    /** Optional object paths to scope the credentials to. */
    objects?: TemporaryCredentialsCreateRequestObjectsList | undefined;
    /** Optional prefix paths to scope the credentials to. */
    prefixes?: TemporaryCredentialsCreateRequestPrefixesList | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTemporaryCredentialResponse {
    /** ID for new access key. */
    accessKeyId?: string | null | undefined;
    /** Secret access key. */
    secretAccessKey?: string | null | undefined;
    /** Security token. */
    sessionToken?: string | null | undefined;
}
export type BucketsDeleteRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface DeleteBucketRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsDeleteRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type DeleteBucketResponse = unknown;
export type BucketsCorsDeleteRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface DeleteBucketCorsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsCorsDeleteRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type DeleteBucketCorsResponse = unknown;
export type BucketsDomainsCustomDeleteRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface DeleteBucketDomainCustomRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Name of the custom domain. */
    domain: string;
    jurisdiction?: BucketsDomainsCustomDeleteRequestCfR2Jurisdiction | (string & {}) | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteBucketDomainCustomResponse {
    /** Name of the removed custom domain. */
    domain: string;
}
export type BucketsEventNotificationsDeleteRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface DeleteBucketEventNotificationRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** ID of the Cloudflare Queue that receives notifications for matching R2 object events. */
    queueId: string;
    jurisdiction?: BucketsEventNotificationsDeleteRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type DeleteBucketEventNotificationResponse = unknown;
export type BucketsObjectsDeleteRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface DeleteBucketObjectRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** The key (name) of the object to delete. May contain slashes for path-like keys. Slashes (`/`) within the key MUST be sent literally and MUST NOT be percent-encoded (i.e. `%2F`); other reserved characters should be percent-encoded as usual. */
    objectName: string;
    jurisdiction?: BucketsObjectsDeleteRequestCfR2Jurisdiction | (string & {}) | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteBucketObjectResponse {
    /** The key (name) of the deleted object. */
    key?: string | null | undefined;
}
export type BucketsSippyDeleteRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface DeleteBucketSippyRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsSippyDeleteRequestCfR2Jurisdiction | (string & {}) | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteBucketSippyResponse {
    enabled?: boolean | null | undefined;
}
export type DeleteObjectsKeyList = Array<string>;
export interface DeleteObjectsRequest {
    /** Account ID. */
    accountId: string;
    /** Name of the R2 bucket. */
    bucketName: string;
    prefix?: string | undefined;
    body?: DeleteObjectsKeyList | undefined;
    jurisdiction?: string | undefined;
}
export type DeleteObjectsResponse = unknown;
export type BucketsGetRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsGetRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsGetResponseJurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export type BucketsGetResponseLocation = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export type BucketsGetResponseStorageClass = "Standard" | "InfrequentAccess";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketResponse {
    /** Creation timestamp. */
    creationDate?: string | null | undefined;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsGetResponseJurisdiction | null | undefined;
    /** Location of the bucket. */
    location?: BucketsGetResponseLocation | null | undefined;
    /** Name of the bucket. */
    name?: string | null | undefined;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsGetResponseStorageClass | null | undefined;
}
export type BucketsCorsGetRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketCorsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsCorsGetRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsCorsGetResponseRulesItemAllowedMethodsItem = "GET" | "PUT" | "POST" | "DELETE" | "HEAD";
export type BucketsCorsGetResponseRulesItemAllowedMethodsList = Array<BucketsCorsGetResponseRulesItemAllowedMethodsItem>;
export type BucketsCorsGetResponseRulesItemAllowedOriginsList = Array<string>;
export type BucketsCorsGetResponseRulesItemAllowedHeadersList = Array<string>;
export interface BucketsCorsGetResponseRulesItemAllowed {
    /** Specifies the value for the Access-Control-Allow-Methods header R2 sets when requesting objects in a bucket from a browser. */
    methods: BucketsCorsGetResponseRulesItemAllowedMethodsList;
    /** Specifies the value for the Access-Control-Allow-Origin header R2 sets when requesting objects in a bucket from a browser. */
    origins: BucketsCorsGetResponseRulesItemAllowedOriginsList;
    /** Specifies the value for the Access-Control-Allow-Headers header R2 sets when requesting objects in this bucket from a browser. Cross-origin requests that include custom headers (e.g. x-user-id) should specify these headers as AllowedHeaders. */
    headers?: BucketsCorsGetResponseRulesItemAllowedHeadersList | null | undefined;
}
export type BucketsCorsGetResponseRulesItemExposeHeadersList = Array<string>;
export interface BucketsCorsGetResponseRulesItem {
    /** Object specifying allowed origins, methods and headers for this CORS rule. */
    allowed: BucketsCorsGetResponseRulesItemAllowed;
    /** Identifier for this rule. */
    id?: string | null | undefined;
    /** Specifies the headers that can be exposed back, and accessed by, the JavaScript making the cross-origin request. If you need to access headers beyond the safelisted response headers, such as Content-Encoding or cf-cache-status, you must specify it here. */
    exposeHeaders?: BucketsCorsGetResponseRulesItemExposeHeadersList | null | undefined;
    /** Specifies the amount of time (in seconds) browsers are allowed to cache CORS preflight responses. Browsers may limit this to 2 hours or less, even if the maximum value (86400) is specified. */
    maxAgeSeconds?: number | null | undefined;
}
export type BucketsCorsGetResponseRulesList = Array<BucketsCorsGetResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketCorsResponse {
    rules?: BucketsCorsGetResponseRulesList | null | undefined;
}
export type BucketsDomainsCustomGetRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketDomainCustomRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Name of the custom domain. */
    domain: string;
    jurisdiction?: BucketsDomainsCustomGetRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsDomainsCustomGetResponseStatusOwnership = "pending" | "active" | "deactivated" | "blocked" | "error" | "unknown";
export type BucketsDomainsCustomGetResponseStatusSsl = "initializing" | "pending" | "active" | "deactivated" | "error" | "unknown";
export interface BucketsDomainsCustomGetResponseStatus {
    /** Ownership status of the domain. */
    ownership: BucketsDomainsCustomGetResponseStatusOwnership;
    /** SSL certificate status. */
    ssl: BucketsDomainsCustomGetResponseStatusSsl;
}
export type BucketsDomainsCustomGetResponseCiphersList = Array<string>;
export type BucketsDomainsCustomGetResponseMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketDomainCustomResponse {
    /** Domain name of the custom domain to be added. */
    domain: string;
    /** Whether this bucket is publicly accessible at the specified custom domain. */
    enabled: boolean;
    status: BucketsDomainsCustomGetResponseStatus;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomGetResponseCiphersList | null | undefined;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomGetResponseMinTLS | null | undefined;
    /** Zone ID of the custom domain resides in. */
    zoneId?: string | null | undefined;
    /** Zone that the custom domain resides in. */
    zoneName?: string | null | undefined;
}
export type BucketsEventNotificationsGetRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketEventNotificationRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** ID of the Cloudflare Queue that receives notifications for matching R2 object events. */
    queueId: string;
    jurisdiction?: BucketsEventNotificationsGetRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsEventNotificationsGetResponseRulesItemActionsItem = "PutObject" | "CopyObject" | "DeleteObject" | "CompleteMultipartUpload" | "LifecycleDeletion";
export type BucketsEventNotificationsGetResponseRulesItemActionsList = Array<BucketsEventNotificationsGetResponseRulesItemActionsItem>;
export interface BucketsEventNotificationsGetResponseRulesItem {
    /** Array of R2 object actions that will trigger notifications. */
    actions: BucketsEventNotificationsGetResponseRulesItemActionsList;
    /** Timestamp when the rule was created. */
    createdAt?: string | null | undefined;
    /** A description that can be used to identify the event notification rule after creation. */
    description?: string | null | undefined;
    /** Notifications will be sent only for objects with this prefix. */
    prefix?: string | null | undefined;
    /** Rule ID. */
    ruleId?: string | null | undefined;
    /** Notifications will be sent only for objects with this suffix. */
    suffix?: string | null | undefined;
}
export type BucketsEventNotificationsGetResponseRulesList = Array<BucketsEventNotificationsGetResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketEventNotificationResponse {
    /** Queue ID. */
    queueId?: string | null | undefined;
    /** Name of the queue. */
    queueName?: string | null | undefined;
    rules?: BucketsEventNotificationsGetResponseRulesList | null | undefined;
}
export type BucketsLifecycleGetRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketLifecycleRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsLifecycleGetRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export interface BucketsLifecycleGetResponseRulesItemConditions {
    /** Transitions will only apply to objects/uploads in the bucket that start with the given prefix, an empty prefix can be provided to scope rule to all objects/uploads. */
    prefix: string;
}
export type BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionConditionType = "Age";
export interface BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionCondition {
    maxAge: number;
    type: BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionConditionType;
}
export interface BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransition {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition?: BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransitionCondition | null | undefined;
}
export type BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType = "Age";
export interface BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition {
    maxAge: number;
    type: BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType;
}
export type BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType = "Date";
export interface BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition {
    date: string;
    type: BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType;
}
export type BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionCondition = BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition | BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition;
export interface BucketsLifecycleGetResponseRulesItemDeleteObjectsTransition {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition?: BucketsLifecycleGetResponseRulesItemDeleteObjectsTransitionCondition | null | undefined;
}
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType = "Age";
export interface BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition {
    maxAge: number;
    type: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType;
}
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType = "Date";
export interface BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition {
    date: string;
    type: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType;
}
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemCondition = BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition | BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition;
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemStorageClass = "InfrequentAccess";
export interface BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItem {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemCondition;
    storageClass: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItemStorageClass;
}
export type BucketsLifecycleGetResponseRulesItemStorageClassTransitionsList = Array<BucketsLifecycleGetResponseRulesItemStorageClassTransitionsItem>;
export interface BucketsLifecycleGetResponseRulesItem {
    /** Unique identifier for this rule. */
    id: string;
    /** Conditions that apply to all transitions of this rule. */
    conditions: BucketsLifecycleGetResponseRulesItemConditions;
    /** Whether or not this rule is in effect. */
    enabled: boolean;
    /** Transition to abort ongoing multipart uploads. */
    abortMultipartUploadsTransition?: BucketsLifecycleGetResponseRulesItemAbortMultipartUploadsTransition | null | undefined;
    /** Transition to delete objects. */
    deleteObjectsTransition?: BucketsLifecycleGetResponseRulesItemDeleteObjectsTransition | null | undefined;
    /** Transitions to change the storage class of objects. */
    storageClassTransitions?: BucketsLifecycleGetResponseRulesItemStorageClassTransitionsList | null | undefined;
}
export type BucketsLifecycleGetResponseRulesList = Array<BucketsLifecycleGetResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketLifecycleResponse {
    rules?: BucketsLifecycleGetResponseRulesList | null | undefined;
}
export interface GetBucketLocalUploadsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketLocalUploadsResponse {
    /** Whether Local Uploads is enabled for the bucket. */
    enabled: boolean;
}
export type BucketsLocksGetRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketLockRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsLocksGetRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeConditionType = "Age";
export interface BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeCondition {
    maxAgeSeconds: number;
    type: BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeConditionType;
}
export type BucketsLocksGetResponseRulesItemConditionR2LockRuleDateConditionType = "Date";
export interface BucketsLocksGetResponseRulesItemConditionR2LockRuleDateCondition {
    date: string;
    type: BucketsLocksGetResponseRulesItemConditionR2LockRuleDateConditionType;
}
export type BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteConditionType = "Indefinite";
export interface BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteCondition {
    type: BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteConditionType;
}
export type BucketsLocksGetResponseRulesItemCondition = BucketsLocksGetResponseRulesItemConditionR2LockRuleAgeCondition | BucketsLocksGetResponseRulesItemConditionR2LockRuleDateCondition | BucketsLocksGetResponseRulesItemConditionR2LockRuleIndefiniteCondition;
export interface BucketsLocksGetResponseRulesItem {
    /** Unique identifier for this rule. */
    id: string;
    /** Condition to apply a lock rule to an object for how long in seconds. */
    condition: BucketsLocksGetResponseRulesItemCondition;
    /** Whether or not this rule is in effect. */
    enabled: boolean;
    /** Rule will only apply to objects/uploads in the bucket that start with the given prefix, an empty prefix can be provided to scope rule to all objects/uploads. */
    prefix?: string | null | undefined;
}
export type BucketsLocksGetResponseRulesList = Array<BucketsLocksGetResponseRulesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketLockResponse {
    rules?: BucketsLocksGetResponseRulesList | null | undefined;
}
export type BucketsObjectsGetRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketObjectRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** The key (name) of the object to retrieve. May contain slashes for path-like keys. Slashes (`/`) within the key MUST be sent literally and MUST NOT be percent-encoded (i.e. `%2F`); other reserved characters should be percent-encoded as usual. */
    objectName: string;
    jurisdiction?: BucketsObjectsGetRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type GetBucketObjectResponseCfR2StorageClass = "Standard" | "InfrequentAccess";
export interface GetBucketObjectResponse {
    /** Raw object body as an Effect Stream. */
    body: T.BinaryResponseBody;
    /** Entity tag of the object (raw hex digest). */
    etag?: string | undefined;
    /** MIME type of the object. */
    contentType?: string | undefined;
    /** Object size in bytes. */
    contentLength?: number | undefined;
    /** Content encoding of the object (e.g. `gzip`). */
    contentEncoding?: string | undefined;
    /** Content disposition header for the object. */
    contentDisposition?: string | undefined;
    /** Content language of the object. */
    contentLanguage?: string | undefined;
    /** Byte range returned (set when the request used `Range`). */
    contentRange?: string | undefined;
    /** Cache-Control directives associated with the object. */
    cacheControl?: string | undefined;
    /** Expiration date of the object. */
    expires?: string | undefined;
    /** When the object was last modified (RFC 7231 date). */
    lastModified?: string | undefined;
    /** Storage class of the object (`Standard` or `InfrequentAccess`). */
    cfR2StorageClass?: GetBucketObjectResponseCfR2StorageClass | undefined;
}
export type BucketsSippyGetRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketSippyRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsSippyGetRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsSippyGetResponseDestinationProvider = "r2";
export interface BucketsSippyGetResponseDestination {
    /** ID of the Cloudflare API token used when writing objects to this bucket. */
    accessKeyId?: string | null | undefined;
    account?: string | null | undefined;
    /** Name of the bucket on the provider. */
    bucket?: string | null | undefined;
    provider?: BucketsSippyGetResponseDestinationProvider | null | undefined;
}
export type BucketsSippyGetResponseSourceProvider = "aws" | "gcs" | "s3" | "azure";
export interface BucketsSippyGetResponseSource {
    /** Name of the bucket on the provider (AWS, GCS only). */
    bucket?: string | null | undefined;
    /** S3-compatible URL (Generic S3-compatible providers only). */
    bucketUrl?: string | null | undefined;
    /** Name of the Azure Blob Storage container (Azure only). */
    container?: string | null | undefined;
    provider?: BucketsSippyGetResponseSourceProvider | null | undefined;
    /** Region where the bucket resides (AWS only). */
    region?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBucketSippyResponse {
    /** Details about the configured destination bucket. */
    destination?: BucketsSippyGetResponseDestination | null | undefined;
    /** State of Sippy for this bucket. */
    enabled?: boolean | null | undefined;
    /** Details about the configured source bucket. */
    source?: BucketsSippyGetResponseSource | null | undefined;
}
export type GetBucketsJobRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface GetBucketsJobRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jobId: string;
    jurisdiction?: GetBucketsJobRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type GetBucketsJobResultPrefixDeleteJobType = "prefixDelete";
export type GetBucketsJobResultPrefixDeletePrefixDelete = CreateBucketsJobResultPrefixDeletePrefixDelete;
export type GetBucketsJobResultPrefixDeleteStatus = "ENQUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
export interface GetBucketsJobResultPrefixDelete {
    /** Unique identifier used to poll the job. */
    id: string;
    /** The job kind. */
    jobType: GetBucketsJobResultPrefixDeleteJobType;
    /** Details specific to the prefix-delete job. */
    prefixDelete: CreateBucketsJobResultPrefixDeletePrefixDelete;
    /** When the job was created. */
    startTime: string;
    /** Lifecycle status of a bucket background job. */
    status: GetBucketsJobResultPrefixDeleteStatus;
    /** When the job finished. Absent while the job is still `ENQUEUED` or `RUNNING`. */
    endTime?: string | null | undefined;
}
export type GetBucketsJobResultStorageClassMigrationJobType = "storageClassMigration";
export type GetBucketsJobResultStorageClassMigrationStatus = "ENQUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
export type GetBucketsJobResultStorageClassMigrationStorageClassMigrationDestinationStorageClass = "Standard" | "InfrequentAccess";
export type GetBucketsJobResultStorageClassMigrationStorageClassMigrationSourceStorageClass = "Standard" | "InfrequentAccess";
export interface GetBucketsJobResultStorageClassMigrationStorageClassMigration {
    /** The storage class objects are migrated to. The source and destination storage classes always differ. */
    destinationStorageClass: GetBucketsJobResultStorageClassMigrationStorageClassMigrationDestinationStorageClass;
    /** Number of object versions migrated successfully. */
    migratedObjects: number;
    /** The storage class objects are migrated from. */
    sourceStorageClass: GetBucketsJobResultStorageClassMigrationStorageClassMigrationSourceStorageClass;
    /** Payload bytes belonging to failed object versions. */
    failedBytes?: number | null | undefined;
    /** Number of object versions that failed migration. */
    failedObjects?: number | null | undefined;
    /** Object payload bytes migrated successfully. Present for Metadata Worker jobs. */
    migratedBytes?: number | null | undefined;
    /** Object metadata bytes migrated successfully. Present for Metadata Worker jobs. */
    migratedMetadataBytes?: number | null | undefined;
    /** Payload bytes belonging to skipped object versions. */
    skippedBytes?: number | null | undefined;
    /** Number of object versions skipped. */
    skippedObjects?: number | null | undefined;
}
export interface GetBucketsJobResultStorageClassMigration {
    /** Unique identifier used to poll the job. */
    id: string;
    /** The job kind. */
    jobType: GetBucketsJobResultStorageClassMigrationJobType;
    /** When the job was created. */
    startTime: string;
    /** Lifecycle status of a bucket background job. */
    status: GetBucketsJobResultStorageClassMigrationStatus;
    storageClassMigration: GetBucketsJobResultStorageClassMigrationStorageClassMigration;
    /** When the job finished. Absent while the job is still `ENQUEUED` or `RUNNING`. */
    endTime?: string | null | undefined;
}
export type GetBucketsJobResult = GetBucketsJobResultPrefixDelete | GetBucketsJobResultStorageClassMigration;
export type GetBucketsJobResponse = GetBucketsJobResult;
export interface GetSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export type SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaKeysList = Array<string>;
export type SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaVendor = "s3";
export interface SuperSlurperJobsGetResponseSourceS3SourceResponseSchema {
    bucket?: string | null | undefined;
    endpoint?: string | null | undefined;
    keys?: SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaKeysList | null | undefined;
    pathPrefix?: string | null | undefined;
    vendor?: SuperSlurperJobsGetResponseSourceS3SourceResponseSchemaVendor | null | undefined;
}
export type SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaKeysList = Array<string>;
export type SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaVendor = "gcs";
export interface SuperSlurperJobsGetResponseSourceGcsSourceResponseSchema {
    bucket?: string | null | undefined;
    keys?: SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaKeysList | null | undefined;
    pathPrefix?: string | null | undefined;
    vendor?: SuperSlurperJobsGetResponseSourceGcsSourceResponseSchemaVendor | null | undefined;
}
export type SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaJurisdiction = "default" | "eu" | "us" | "fedramp";
export type SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaKeysList = Array<string>;
export type SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaVendor = "r2";
export interface SuperSlurperJobsGetResponseSourceR2SourceResponseSchema {
    bucket?: string | null | undefined;
    jurisdiction?: SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaJurisdiction | null | undefined;
    keys?: SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaKeysList | null | undefined;
    pathPrefix?: string | null | undefined;
    vendor?: SuperSlurperJobsGetResponseSourceR2SourceResponseSchemaVendor | null | undefined;
}
export type SuperSlurperJobsGetResponseSource = SuperSlurperJobsGetResponseSourceS3SourceResponseSchema | SuperSlurperJobsGetResponseSourceGcsSourceResponseSchema | SuperSlurperJobsGetResponseSourceR2SourceResponseSchema;
export type SuperSlurperJobsGetResponseStatus = "running" | "paused" | "aborted" | "completed";
export type SuperSlurperJobsGetResponseTargetJurisdiction = "default" | "eu" | "us" | "fedramp";
export type SuperSlurperJobsGetResponseTargetVendor = "r2";
export interface SuperSlurperJobsGetResponseTarget {
    bucket?: string | null | undefined;
    jurisdiction?: SuperSlurperJobsGetResponseTargetJurisdiction | null | undefined;
    vendor?: SuperSlurperJobsGetResponseTargetVendor | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSuperSlurperJobResponse {
    id?: string | null | undefined;
    createdAt?: string | null | undefined;
    finishedAt?: string | null | undefined;
    overwrite?: boolean | null | undefined;
    source?: SuperSlurperJobsGetResponseSource | null | undefined;
    status?: SuperSlurperJobsGetResponseStatus | null | undefined;
    target?: SuperSlurperJobsGetResponseTarget | null | undefined;
}
export type BucketsDomainsCustomListRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface ListBucketDomainCustomsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsDomainsCustomListRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsDomainsCustomListResponseDomainsItemStatusOwnership = "pending" | "active" | "deactivated" | "blocked" | "error" | "unknown";
export type BucketsDomainsCustomListResponseDomainsItemStatusSsl = "initializing" | "pending" | "active" | "deactivated" | "error" | "unknown";
export interface BucketsDomainsCustomListResponseDomainsItemStatus {
    /** Ownership status of the domain. */
    ownership: BucketsDomainsCustomListResponseDomainsItemStatusOwnership;
    /** SSL certificate status. */
    ssl: BucketsDomainsCustomListResponseDomainsItemStatusSsl;
}
export type BucketsDomainsCustomListResponseDomainsItemCiphersList = Array<string>;
export type BucketsDomainsCustomListResponseDomainsItemMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export interface BucketsDomainsCustomListResponseDomainsItem {
    /** Domain name of the custom domain to be added. */
    domain: string;
    /** Whether this bucket is publicly accessible at the specified custom domain. */
    enabled: boolean;
    status: BucketsDomainsCustomListResponseDomainsItemStatus;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomListResponseDomainsItemCiphersList | null | undefined;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomListResponseDomainsItemMinTLS | null | undefined;
    /** Zone ID of the custom domain resides in. */
    zoneId?: string | null | undefined;
    /** Zone that the custom domain resides in. */
    zoneName?: string | null | undefined;
}
export type BucketsDomainsCustomListResponseDomainsList = Array<BucketsDomainsCustomListResponseDomainsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketDomainCustomsResponse {
    domains: BucketsDomainsCustomListResponseDomainsList;
}
export type BucketsDomainsManagedListRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface ListBucketDomainManagedsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsDomainsManagedListRequestCfR2Jurisdiction | (string & {}) | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketDomainManagedsResponse {
    /** Bucket ID. */
    bucketId: string;
    /** Domain name of the bucket's r2.dev domain. */
    domain: string;
    /** Whether this bucket is publicly accessible at the r2.dev domain. */
    enabled: boolean;
}
export type BucketsEventNotificationsListRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface ListBucketEventNotificationsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    jurisdiction?: BucketsEventNotificationsListRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsEventNotificationsListResponseQueuesItemRulesItemActionsItem = "PutObject" | "CopyObject" | "DeleteObject" | "CompleteMultipartUpload" | "LifecycleDeletion";
export type BucketsEventNotificationsListResponseQueuesItemRulesItemActionsList = Array<BucketsEventNotificationsListResponseQueuesItemRulesItemActionsItem>;
export interface BucketsEventNotificationsListResponseQueuesItemRulesItem {
    /** Array of R2 object actions that will trigger notifications. */
    actions: BucketsEventNotificationsListResponseQueuesItemRulesItemActionsList;
    /** Timestamp when the rule was created. */
    createdAt?: string | null | undefined;
    /** A description that can be used to identify the event notification rule after creation. */
    description?: string | null | undefined;
    /** Notifications will be sent only for objects with this prefix. */
    prefix?: string | null | undefined;
    /** Rule ID. */
    ruleId?: string | null | undefined;
    /** Notifications will be sent only for objects with this suffix. */
    suffix?: string | null | undefined;
}
export type BucketsEventNotificationsListResponseQueuesItemRulesList = Array<BucketsEventNotificationsListResponseQueuesItemRulesItem>;
export interface BucketsEventNotificationsListResponseQueuesItem {
    /** Queue ID. */
    queueId?: string | null | undefined;
    /** Name of the queue. */
    queueName?: string | null | undefined;
    rules?: BucketsEventNotificationsListResponseQueuesItemRulesList | null | undefined;
}
export type BucketsEventNotificationsListResponseQueuesList = Array<BucketsEventNotificationsListResponseQueuesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketEventNotificationsResponse {
    /** Name of the bucket. */
    bucketName?: string | null | undefined;
    /** List of queues associated with the bucket. */
    queues?: BucketsEventNotificationsListResponseQueuesList | null | undefined;
}
export interface ListBucketMetricsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
}
export interface BucketsMetricsListResponseInfrequentAccessPublished {
    /** Amount of. */
    metadataSize?: number | null | undefined;
    /** Number of objects stored. */
    objects?: number | null | undefined;
    /** Amount of storage used by object data. */
    payloadSize?: number | null | undefined;
}
export type BucketsMetricsListResponseInfrequentAccessUploaded = BucketsMetricsListResponseInfrequentAccessPublished;
export interface BucketsMetricsListResponseInfrequentAccess {
    /** Metrics on number of objects/amount of storage used. */
    published?: BucketsMetricsListResponseInfrequentAccessPublished | null | undefined;
    /** Metrics on number of objects/amount of storage used. */
    uploaded?: BucketsMetricsListResponseInfrequentAccessPublished | null | undefined;
}
export type BucketsMetricsListResponseStandardPublished = BucketsMetricsListResponseInfrequentAccessPublished;
export type BucketsMetricsListResponseStandardUploaded = BucketsMetricsListResponseInfrequentAccessPublished;
export type BucketsMetricsListResponseStandard = BucketsMetricsListResponseInfrequentAccess;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketMetricsResponse {
    /** Metrics based on what state they are in(uploaded or published). */
    infrequentAccess?: BucketsMetricsListResponseInfrequentAccess | null | undefined;
    /** Metrics based on what state they are in(uploaded or published). */
    standard?: BucketsMetricsListResponseInfrequentAccess | null | undefined;
}
export type BucketsObjectsListRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface ListBucketObjectsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Pagination cursor received from a previous List Objects call. Used to retrieve the next page of results. */
    cursor?: string | undefined;
    /** A single character used to group keys. All keys that contain the delimiter between the prefix and the first occurrence of the delimiter after the prefix are grouped under a single result element. */
    delimiter?: string | undefined;
    /** Maximum number of objects to return per page. */
    perPage?: number | undefined;
    /** Restricts results to only those objects whose keys begin with the specified prefix. */
    prefix?: string | undefined;
    /** Returns objects with keys that come after the specified key in lexicographic order. */
    startAfter?: string | undefined;
    jurisdiction?: BucketsObjectsListRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsObjectsListResultItemCustomMetadataMap = {
    [key: string]: string | undefined;
};
export interface BucketsObjectsListResultItemHttpMetadata {
    /** Specifies caching behavior for the object. */
    cacheControl?: string | null | undefined;
    /** The date and time at which the object's cache entry expires. */
    cacheExpiry?: string | null | undefined;
    /** Specifies presentational information for the object. */
    contentDisposition?: string | null | undefined;
    /** Specifies the content encoding applied to the object. */
    contentEncoding?: string | null | undefined;
    /** The language of the object content. */
    contentLanguage?: string | null | undefined;
    /** The MIME type of the object. */
    contentType?: string | null | undefined;
}
export type BucketsObjectsListResultItemStorageClass = "Standard" | "InfrequentAccess";
export interface BucketsObjectsListResultItem {
    /** Custom metadata key-value pairs associated with the object. */
    customMetadata?: BucketsObjectsListResultItemCustomMetadataMap | null | undefined;
    /** The entity tag for the object. In JSON list/get responses this is the raw hex digest (without surrounding quotes). The HTTP `ETag` response header on Get Object follows RFC 7232 and IS wrapped in surrounding double-quotes. */
    etag?: string | null | undefined;
    /** HTTP metadata associated with an R2 object. */
    httpMetadata?: BucketsObjectsListResultItemHttpMetadata | null | undefined;
    /** The object key (name). */
    key?: string | null | undefined;
    /** The date and time the object was last modified. */
    lastModified?: string | null | undefined;
    /** The size of the object in bytes. */
    size?: number | null | undefined;
    /** Whether the object is encrypted with a customer-supplied encryption key. */
    ssec?: boolean | null | undefined;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsObjectsListResultItemStorageClass | null | undefined;
}
export type BucketsObjectsListResultList = Array<BucketsObjectsListResultItem>;
export interface ListBucketObjectsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BucketsObjectsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type BucketsListRequestDirection = "asc" | "desc";
export type BucketsListRequestOrder = "name";
export type BucketsListRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface ListBucketsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Pagination cursor received during the last List Buckets call. R2 buckets are paginated using cursors instead of page numbers. */
    cursor?: string | undefined;
    /** Direction to order buckets. */
    direction?: BucketsListRequestDirection | (string & {}) | undefined;
    /** Bucket names to filter by. Only buckets with this phrase in their name will be returned. */
    nameContains?: string | undefined;
    /** Field to order buckets by. */
    order?: BucketsListRequestOrder | (string & {}) | undefined;
    /** Maximum number of buckets to return in a single call. */
    perPage?: number | undefined;
    /** Bucket name to start searching after. Buckets are ordered lexicographically. */
    startAfter?: string | undefined;
    jurisdiction?: BucketsListRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsListResponseBucketsItemJurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export type BucketsListResponseBucketsItemLocation = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export type BucketsListResponseBucketsItemStorageClass = "Standard" | "InfrequentAccess";
export interface BucketsListResponseBucketsItem {
    /** Creation timestamp. */
    creationDate?: string | null | undefined;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsListResponseBucketsItemJurisdiction | null | undefined;
    /** Location of the bucket. */
    location?: BucketsListResponseBucketsItemLocation | null | undefined;
    /** Name of the bucket. */
    name?: string | null | undefined;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsListResponseBucketsItemStorageClass | null | undefined;
}
export type BucketsListResponseBucketsList = Array<BucketsListResponseBucketsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketsResponse {
    buckets: BucketsListResponseBucketsList;
}
export type ListBucketsJobsRequestJobType = "prefixDelete" | "storageClassMigration";
export type ListBucketsJobsRequestStatus = "ENQUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
export type ListBucketsJobsRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface ListBucketsJobsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Pagination token received as `nextContinuationToken` in the previous response. */
    continuationToken?: string | undefined;
    /** Restricts results to jobs of the specified type. */
    jobType?: ListBucketsJobsRequestJobType | (string & {}) | undefined;
    /** Maximum number of jobs to return. */
    maxKeys?: number | undefined;
    /** Restricts results to jobs with the specified status. `jobType` is required when this parameter is provided. */
    status?: ListBucketsJobsRequestStatus | (string & {}) | undefined;
    jurisdiction?: ListBucketsJobsRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type ListBucketsJobsResponseJobsItemPrefixDeleteJobType = "prefixDelete";
export type ListBucketsJobsResponseJobsItemPrefixDeletePrefixDelete = CreateBucketsJobResultPrefixDeletePrefixDelete;
export type ListBucketsJobsResponseJobsItemPrefixDeleteStatus = "ENQUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
export interface ListBucketsJobsResponseJobsItemPrefixDelete {
    /** Unique identifier used to poll the job. */
    id: string;
    /** The job kind. */
    jobType: ListBucketsJobsResponseJobsItemPrefixDeleteJobType;
    /** Details specific to the prefix-delete job. */
    prefixDelete: CreateBucketsJobResultPrefixDeletePrefixDelete;
    /** When the job was created. */
    startTime: string;
    /** Lifecycle status of a bucket background job. */
    status: ListBucketsJobsResponseJobsItemPrefixDeleteStatus;
    /** When the job finished. Absent while the job is still `ENQUEUED` or `RUNNING`. */
    endTime?: string | null | undefined;
}
export type ListBucketsJobsResponseJobsItemStorageClassMigrationJobType = "storageClassMigration";
export type ListBucketsJobsResponseJobsItemStorageClassMigrationStatus = "ENQUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED";
export type ListBucketsJobsResponseJobsItemStorageClassMigrationStorageClassMigrationDestinationStorageClass = "Standard" | "InfrequentAccess";
export type ListBucketsJobsResponseJobsItemStorageClassMigrationStorageClassMigrationSourceStorageClass = "Standard" | "InfrequentAccess";
export interface ListBucketsJobsResponseJobsItemStorageClassMigrationStorageClassMigration {
    /** The storage class objects are migrated to. The source and destination storage classes always differ. */
    destinationStorageClass: ListBucketsJobsResponseJobsItemStorageClassMigrationStorageClassMigrationDestinationStorageClass;
    /** Number of object versions migrated successfully. */
    migratedObjects: number;
    /** The storage class objects are migrated from. */
    sourceStorageClass: ListBucketsJobsResponseJobsItemStorageClassMigrationStorageClassMigrationSourceStorageClass;
    /** Payload bytes belonging to failed object versions. */
    failedBytes?: number | null | undefined;
    /** Number of object versions that failed migration. */
    failedObjects?: number | null | undefined;
    /** Object payload bytes migrated successfully. Present for Metadata Worker jobs. */
    migratedBytes?: number | null | undefined;
    /** Object metadata bytes migrated successfully. Present for Metadata Worker jobs. */
    migratedMetadataBytes?: number | null | undefined;
    /** Payload bytes belonging to skipped object versions. */
    skippedBytes?: number | null | undefined;
    /** Number of object versions skipped. */
    skippedObjects?: number | null | undefined;
}
export interface ListBucketsJobsResponseJobsItemStorageClassMigration {
    /** Unique identifier used to poll the job. */
    id: string;
    /** The job kind. */
    jobType: ListBucketsJobsResponseJobsItemStorageClassMigrationJobType;
    /** When the job was created. */
    startTime: string;
    /** Lifecycle status of a bucket background job. */
    status: ListBucketsJobsResponseJobsItemStorageClassMigrationStatus;
    storageClassMigration: ListBucketsJobsResponseJobsItemStorageClassMigrationStorageClassMigration;
    /** When the job finished. Absent while the job is still `ENQUEUED` or `RUNNING`. */
    endTime?: string | null | undefined;
}
export type ListBucketsJobsResponseJobsItem = ListBucketsJobsResponseJobsItemPrefixDelete | ListBucketsJobsResponseJobsItemStorageClassMigration;
export type ListBucketsJobsResponseJobsList = Array<ListBucketsJobsResponseJobsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListBucketsJobsResponse {
    /** Bucket jobs in the current page. */
    jobs: ListBucketsJobsResponseJobsList;
    /** Token to pass as `continuationToken` to retrieve the next page. */
    nextContinuationToken?: string | null | undefined;
}
export interface ListSuperSlurperJobLogsRequest {
    accountId: string;
    jobId: string;
    limit?: number | undefined;
    offset?: number | undefined;
}
export type SuperSlurperJobsLogsListResultItemLogType = "migrationStart" | "migrationComplete" | "migrationAbort" | "migrationError" | "migrationPause" | "migrationResume" | "migrationErrorFailedContinuation" | "importErrorRetryExhaustion" | "importSkippedStorageClass" | "importSkippedOversized" | "importSkippedEmptyObject" | "importSkippedUnsupportedContentType" | "importSkippedExcludedContentType" | "importSkippedInvalidMedia" | "importSkippedRequiresRetrieval";
export interface SuperSlurperJobsLogsListResultItem {
    createdAt?: string | null | undefined;
    job?: string | null | undefined;
    logType?: SuperSlurperJobsLogsListResultItemLogType | null | undefined;
    message?: string | null | undefined;
    objectKey?: string | null | undefined;
}
export type SuperSlurperJobsLogsListResultList = Array<SuperSlurperJobsLogsListResultItem>;
export interface ListSuperSlurperJobLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SuperSlurperJobsLogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListSuperSlurperJobsRequest {
    accountId: string;
    limit?: number | undefined;
    offset?: number | undefined;
}
export type SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaKeysList = Array<string>;
export type SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaVendor = "s3";
export interface SuperSlurperJobsListResultItemSourceS3SourceResponseSchema {
    bucket?: string | null | undefined;
    endpoint?: string | null | undefined;
    keys?: SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaKeysList | null | undefined;
    pathPrefix?: string | null | undefined;
    vendor?: SuperSlurperJobsListResultItemSourceS3SourceResponseSchemaVendor | null | undefined;
}
export type SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaKeysList = Array<string>;
export type SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaVendor = "gcs";
export interface SuperSlurperJobsListResultItemSourceGcsSourceResponseSchema {
    bucket?: string | null | undefined;
    keys?: SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaKeysList | null | undefined;
    pathPrefix?: string | null | undefined;
    vendor?: SuperSlurperJobsListResultItemSourceGcsSourceResponseSchemaVendor | null | undefined;
}
export type SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaJurisdiction = "default" | "eu" | "us" | "fedramp";
export type SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaKeysList = Array<string>;
export type SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaVendor = "r2";
export interface SuperSlurperJobsListResultItemSourceR2SourceResponseSchema {
    bucket?: string | null | undefined;
    jurisdiction?: SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaJurisdiction | null | undefined;
    keys?: SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaKeysList | null | undefined;
    pathPrefix?: string | null | undefined;
    vendor?: SuperSlurperJobsListResultItemSourceR2SourceResponseSchemaVendor | null | undefined;
}
export type SuperSlurperJobsListResultItemSource = SuperSlurperJobsListResultItemSourceS3SourceResponseSchema | SuperSlurperJobsListResultItemSourceGcsSourceResponseSchema | SuperSlurperJobsListResultItemSourceR2SourceResponseSchema;
export type SuperSlurperJobsListResultItemStatus = "running" | "paused" | "aborted" | "completed";
export type SuperSlurperJobsListResultItemTargetJurisdiction = "default" | "eu" | "us" | "fedramp";
export type SuperSlurperJobsListResultItemTargetVendor = "r2";
export interface SuperSlurperJobsListResultItemTarget {
    bucket?: string | null | undefined;
    jurisdiction?: SuperSlurperJobsListResultItemTargetJurisdiction | null | undefined;
    vendor?: SuperSlurperJobsListResultItemTargetVendor | null | undefined;
}
export interface SuperSlurperJobsListResultItem {
    id?: string | null | undefined;
    createdAt?: string | null | undefined;
    finishedAt?: string | null | undefined;
    overwrite?: boolean | null | undefined;
    source?: SuperSlurperJobsListResultItemSource | null | undefined;
    status?: SuperSlurperJobsListResultItemStatus | null | undefined;
    target?: SuperSlurperJobsListResultItemTarget | null | undefined;
}
export type SuperSlurperJobsListResultList = Array<SuperSlurperJobsListResultItem>;
export interface ListSuperSlurperJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SuperSlurperJobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type BucketsEditRequestCfR2StorageClass = "Standard" | "InfrequentAccess";
export type BucketsEditRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface PatchBucketRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass: BucketsEditRequestCfR2StorageClass | (string & {});
    jurisdiction?: BucketsEditRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsEditResponseJurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export type BucketsEditResponseLocation = "apac" | "eeur" | "enam" | "weur" | "wnam" | "oc";
export type BucketsEditResponseStorageClass = "Standard" | "InfrequentAccess";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchBucketResponse {
    /** Creation timestamp. */
    creationDate?: string | null | undefined;
    /** Jurisdiction where objects in this bucket are guaranteed to be stored. */
    jurisdiction?: BucketsEditResponseJurisdiction | null | undefined;
    /** Location of the bucket. */
    location?: BucketsEditResponseLocation | null | undefined;
    /** Name of the bucket. */
    name?: string | null | undefined;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsEditResponseStorageClass | null | undefined;
}
export interface PauseSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export type PauseSuperSlurperJobResponse = string;
export interface ProgressSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export type SuperSlurperJobsProgressResponseStatus = "running" | "paused" | "aborted" | "completed";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ProgressSuperSlurperJobResponse {
    id?: string | null | undefined;
    createdAt?: string | null | undefined;
    failedObjects?: number | null | undefined;
    objects?: number | null | undefined;
    skippedObjects?: number | null | undefined;
    status?: SuperSlurperJobsProgressResponseStatus | null | undefined;
    transferredObjects?: number | null | undefined;
}
export type BucketsCorsUpdateRequestRulesItemAllowedMethodsItem = "GET" | "PUT" | "POST" | "DELETE" | "HEAD";
export type BucketsCorsUpdateRequestRulesItemAllowedMethodsList = Array<BucketsCorsUpdateRequestRulesItemAllowedMethodsItem | (string & {})>;
export type BucketsCorsUpdateRequestRulesItemAllowedOriginsList = Array<string>;
export type BucketsCorsUpdateRequestRulesItemAllowedHeadersList = Array<string>;
export interface BucketsCorsUpdateRequestRulesItemAllowed {
    /** Specifies the value for the Access-Control-Allow-Methods header R2 sets when requesting objects in a bucket from a browser. */
    methods: BucketsCorsUpdateRequestRulesItemAllowedMethodsList;
    /** Specifies the value for the Access-Control-Allow-Origin header R2 sets when requesting objects in a bucket from a browser. */
    origins: BucketsCorsUpdateRequestRulesItemAllowedOriginsList;
    /** Specifies the value for the Access-Control-Allow-Headers header R2 sets when requesting objects in this bucket from a browser. Cross-origin requests that include custom headers (e.g. x-user-id) should specify these headers as AllowedHeaders. */
    headers?: BucketsCorsUpdateRequestRulesItemAllowedHeadersList | undefined;
}
export type BucketsCorsUpdateRequestRulesItemExposeHeadersList = Array<string>;
export interface BucketsCorsUpdateRequestRulesItem {
    /** Object specifying allowed origins, methods and headers for this CORS rule. */
    allowed: BucketsCorsUpdateRequestRulesItemAllowed;
    /** Identifier for this rule. */
    id?: string | undefined;
    /** Specifies the headers that can be exposed back, and accessed by, the JavaScript making the cross-origin request. If you need to access headers beyond the safelisted response headers, such as Content-Encoding or cf-cache-status, you must specify it here. */
    exposeHeaders?: BucketsCorsUpdateRequestRulesItemExposeHeadersList | undefined;
    /** Specifies the amount of time (in seconds) browsers are allowed to cache CORS preflight responses. Browsers may limit this to 2 hours or less, even if the maximum value (86400) is specified. */
    maxAgeSeconds?: number | undefined;
}
export type BucketsCorsUpdateRequestRulesList = Array<BucketsCorsUpdateRequestRulesItem>;
export type BucketsCorsUpdateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface PutBucketCorsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    rules?: BucketsCorsUpdateRequestRulesList | undefined;
    jurisdiction?: BucketsCorsUpdateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type PutBucketCorsResponse = unknown;
export type BucketsDomainsManagedUpdateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface PutBucketDomainManagedRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Whether to enable public bucket access at the r2.dev domain. */
    enabled: boolean;
    jurisdiction?: BucketsDomainsManagedUpdateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutBucketDomainManagedResponse {
    /** Bucket ID. */
    bucketId: string;
    /** Domain name of the bucket's r2.dev domain. */
    domain: string;
    /** Whether this bucket is publicly accessible at the r2.dev domain. */
    enabled: boolean;
}
export type BucketsEventNotificationsUpdateRequestRulesItemActionsItem = "PutObject" | "CopyObject" | "DeleteObject" | "CompleteMultipartUpload" | "LifecycleDeletion";
export type BucketsEventNotificationsUpdateRequestRulesItemActionsList = Array<BucketsEventNotificationsUpdateRequestRulesItemActionsItem | (string & {})>;
export interface BucketsEventNotificationsUpdateRequestRulesItem {
    /** Array of R2 object actions that will trigger notifications. */
    actions: BucketsEventNotificationsUpdateRequestRulesItemActionsList;
    /** A description that can be used to identify the event notification rule after creation. */
    description?: string | undefined;
    /** Notifications will be sent only for objects with this prefix. */
    prefix?: string | undefined;
    /** Notifications will be sent only for objects with this suffix. */
    suffix?: string | undefined;
}
export type BucketsEventNotificationsUpdateRequestRulesList = Array<BucketsEventNotificationsUpdateRequestRulesItem>;
export type BucketsEventNotificationsUpdateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface PutBucketEventNotificationRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** ID of the Cloudflare Queue that receives notifications for matching R2 object events. */
    queueId: string;
    /** Array of rules to drive notifications. */
    rules: BucketsEventNotificationsUpdateRequestRulesList;
    jurisdiction?: BucketsEventNotificationsUpdateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type PutBucketEventNotificationResponse = unknown;
export type BucketsLifecycleUpdateRequestRulesItemConditions = BucketsLifecycleGetResponseRulesItemConditions;
export type BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionConditionType = "Age";
export interface BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionCondition {
    maxAge: number;
    type: BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionConditionType | (string & {});
}
export interface BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransition {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition?: BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransitionCondition | undefined;
}
export type BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType = "Age";
export interface BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition {
    maxAge: number;
    type: BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeConditionType;
}
export type BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType = "Date";
export interface BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition {
    date: string;
    type: BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateConditionType;
}
export type BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionCondition = BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleAgeCondition | BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionConditionR2LifecycleDateCondition;
export interface BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransition {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition?: BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransitionCondition | undefined;
}
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType = "Age";
export interface BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition {
    maxAge: number;
    type: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeConditionType;
}
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType = "Date";
export interface BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition {
    date: string;
    type: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateConditionType;
}
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemCondition = BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleAgeCondition | BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemConditionR2LifecycleDateCondition;
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemStorageClass = "InfrequentAccess";
export interface BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItem {
    /** Condition for lifecycle transitions to apply after an object reaches an age in seconds. */
    condition: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemCondition;
    storageClass: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItemStorageClass | (string & {});
}
export type BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsList = Array<BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsItem>;
export interface BucketsLifecycleUpdateRequestRulesItem {
    /** Unique identifier for this rule. */
    id: string;
    /** Conditions that apply to all transitions of this rule. */
    conditions: BucketsLifecycleGetResponseRulesItemConditions;
    /** Whether or not this rule is in effect. */
    enabled: boolean;
    /** Transition to abort ongoing multipart uploads. */
    abortMultipartUploadsTransition?: BucketsLifecycleUpdateRequestRulesItemAbortMultipartUploadsTransition | undefined;
    /** Transition to delete objects. */
    deleteObjectsTransition?: BucketsLifecycleUpdateRequestRulesItemDeleteObjectsTransition | undefined;
    /** Transitions to change the storage class of objects. */
    storageClassTransitions?: BucketsLifecycleUpdateRequestRulesItemStorageClassTransitionsList | undefined;
}
export type BucketsLifecycleUpdateRequestRulesList = Array<BucketsLifecycleUpdateRequestRulesItem>;
export type BucketsLifecycleUpdateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface PutBucketLifecycleRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    rules?: BucketsLifecycleUpdateRequestRulesList | undefined;
    jurisdiction?: BucketsLifecycleUpdateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type PutBucketLifecycleResponse = unknown;
export interface PutBucketLocalUploadsRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Enable (`true`) or disable (`false`) Local Uploads for the bucket. */
    enabled: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutBucketLocalUploadsResponse {
    /** Whether Local Uploads is enabled for the bucket. The live API omits it from the PUT response (observed 2026-10-22); read it back with getBucketLocalUploads. */
    enabled?: boolean | null | undefined;
}
export type BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeConditionType = "Age";
export interface BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeCondition {
    maxAgeSeconds: number;
    type: BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeConditionType;
}
export type BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateConditionType = "Date";
export interface BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateCondition {
    date: string;
    type: BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateConditionType;
}
export type BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteConditionType = "Indefinite";
export interface BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteCondition {
    type: BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteConditionType;
}
export type BucketsLocksUpdateRequestRulesItemCondition = BucketsLocksUpdateRequestRulesItemConditionR2LockRuleAgeCondition | BucketsLocksUpdateRequestRulesItemConditionR2LockRuleDateCondition | BucketsLocksUpdateRequestRulesItemConditionR2LockRuleIndefiniteCondition;
export interface BucketsLocksUpdateRequestRulesItem {
    /** Unique identifier for this rule. */
    id: string;
    /** Condition to apply a lock rule to an object for how long in seconds. */
    condition: BucketsLocksUpdateRequestRulesItemCondition;
    /** Whether or not this rule is in effect. */
    enabled: boolean;
    /** Rule will only apply to objects/uploads in the bucket that start with the given prefix, an empty prefix can be provided to scope rule to all objects/uploads. */
    prefix?: string | undefined;
}
export type BucketsLocksUpdateRequestRulesList = Array<BucketsLocksUpdateRequestRulesItem>;
export type BucketsLocksUpdateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface PutBucketLockRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    rules?: BucketsLocksUpdateRequestRulesList | undefined;
    jurisdiction?: BucketsLocksUpdateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type PutBucketLockResponse = unknown;
export type BucketsSippyUpdateRequestDestinationProvider = "r2";
export interface BucketsSippyUpdateRequestDestination {
    /** ID of a Cloudflare API token. This is the value labelled "Access Key ID" when creating an API. token from the [R2 dashboard](https://dash.cloudflare.com/?to=/:account/r2/api-tokens). */
    accessKeyId?: string | undefined;
    provider?: BucketsSippyUpdateRequestDestinationProvider | (string & {}) | undefined;
    /** Value of a Cloudflare API token. This is the value labelled "Secret Access Key" when creating an API. token from the [R2 dashboard](https://dash.cloudflare.com/?to=/:account/r2/api-tokens). */
    secretAccessKey?: string | undefined;
}
export type BucketsSippyUpdateRequestSourceR2EnableSippyAwsProvider = "aws";
export interface BucketsSippyUpdateRequestSourceR2EnableSippyAws {
    /** Access Key ID of an IAM credential (ideally scoped to a single S3 bucket). */
    accessKeyId?: string | undefined;
    /** Name of the AWS S3 bucket. */
    bucket?: string | undefined;
    provider?: BucketsSippyUpdateRequestSourceR2EnableSippyAwsProvider | (string & {}) | undefined;
    /** AWS region containing the source S3 bucket. */
    region?: string | undefined;
    /** Secret Access Key of an IAM credential (ideally scoped to a single S3 bucket). */
    secretAccessKey?: string | undefined;
}
export type BucketsSippyUpdateRequestSourceR2EnableSippyGcsProvider = "gcs";
export interface BucketsSippyUpdateRequestSourceR2EnableSippyGcs {
    /** Name of the GCS bucket. */
    bucket?: string | undefined;
    /** Client email of an IAM credential (ideally scoped to a single GCS bucket). */
    clientEmail?: string | undefined;
    /** Private Key of an IAM credential (ideally scoped to a single GCS bucket). */
    privateKey?: string | undefined;
    provider?: BucketsSippyUpdateRequestSourceR2EnableSippyGcsProvider | (string & {}) | undefined;
}
export type BucketsSippyUpdateRequestSourceR2EnableSippyS3Provider = "s3";
export interface BucketsSippyUpdateRequestSourceR2EnableSippyS3 {
    /** Access Key ID of an IAM credential (ideally scoped to a single S3 bucket). */
    accessKeyId?: string | undefined;
    /** URL to the S3-compatible API of the bucket. */
    bucketUrl?: string | undefined;
    provider?: BucketsSippyUpdateRequestSourceR2EnableSippyS3Provider | (string & {}) | undefined;
    /** Secret Access Key of an IAM credential (ideally scoped to a single S3 bucket). */
    secretAccessKey?: string | undefined;
}
export type BucketsSippyUpdateRequestSourceR2EnableSippyAzureProvider = "azure";
export interface BucketsSippyUpdateRequestSourceR2EnableSippyAzure {
    /** Access key for the Azure Storage account. Mutually exclusive with sasToken. */
    accountKey?: string | undefined;
    /** Name of the Azure Storage account. */
    accountName?: string | undefined;
    /** Name of the Azure Blob Storage container. */
    container?: string | undefined;
    provider?: BucketsSippyUpdateRequestSourceR2EnableSippyAzureProvider | (string & {}) | undefined;
    /** Shared Access Signature token for the Azure Storage account. Mutually exclusive with accountKey. */
    sasToken?: string | undefined;
}
export type BucketsSippyUpdateRequestSource = BucketsSippyUpdateRequestSourceR2EnableSippyAws | BucketsSippyUpdateRequestSourceR2EnableSippyGcs | BucketsSippyUpdateRequestSourceR2EnableSippyS3 | BucketsSippyUpdateRequestSourceR2EnableSippyAzure;
export type BucketsSippyUpdateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface PutBucketSippyRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** R2 bucket to copy objects to. */
    destination?: BucketsSippyUpdateRequestDestination | undefined;
    /** AWS S3 bucket to copy objects from. */
    source?: BucketsSippyUpdateRequestSource | undefined;
    jurisdiction?: BucketsSippyUpdateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsSippyUpdateResponseDestinationProvider = "r2";
export interface BucketsSippyUpdateResponseDestination {
    /** ID of the Cloudflare API token used when writing objects to this bucket. */
    accessKeyId?: string | null | undefined;
    account?: string | null | undefined;
    /** Name of the bucket on the provider. */
    bucket?: string | null | undefined;
    provider?: BucketsSippyUpdateResponseDestinationProvider | null | undefined;
}
export type BucketsSippyUpdateResponseSourceProvider = "aws" | "gcs" | "s3" | "azure";
export interface BucketsSippyUpdateResponseSource {
    /** Name of the bucket on the provider (AWS, GCS only). */
    bucket?: string | null | undefined;
    /** S3-compatible URL (Generic S3-compatible providers only). */
    bucketUrl?: string | null | undefined;
    /** Name of the Azure Blob Storage container (Azure only). */
    container?: string | null | undefined;
    provider?: BucketsSippyUpdateResponseSourceProvider | null | undefined;
    /** Region where the bucket resides (AWS only). */
    region?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutBucketSippyResponse {
    /** Details about the configured destination bucket. */
    destination?: BucketsSippyUpdateResponseDestination | null | undefined;
    /** State of Sippy for this bucket. */
    enabled?: boolean | null | undefined;
    /** Details about the configured source bucket. */
    source?: BucketsSippyUpdateResponseSource | null | undefined;
}
export interface ResumeSuperSlurperJobRequest {
    accountId: string;
    jobId: string;
}
export type ResumeSuperSlurperJobResponse = string;
export type SuperSlurperConnectivityPrecheckSourceRequestSecretR2SlurperS3SourceSchema = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
export type SuperSlurperConnectivityPrecheckSourceRequestSecretR2SlurperGcsSourceSchema = SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret;
export type SuperSlurperConnectivityPrecheckSourceRequestSecret = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret | SuperSlurperJobsCreateRequestSourceR2SlurperGcsSourceSchemaSecret;
export type SuperSlurperConnectivityPrecheckSourceRequestVendor = "s3" | "gcs" | "r2";
export type SuperSlurperConnectivityPrecheckSourceRequestKeysList = Array<string>;
export type SuperSlurperConnectivityPrecheckSourceRequestJurisdiction = "default" | "eu" | "us" | "fedramp";
export interface SourceSuperSlurperConnectivityPrecheckRequest {
    accountId: string;
    bucket: string;
    secret: SuperSlurperConnectivityPrecheckSourceRequestSecret;
    vendor: SuperSlurperConnectivityPrecheckSourceRequestVendor | (string & {});
    /** Custom S3-compatible endpoint that must use https://. */
    endpoint?: string | undefined;
    keys?: SuperSlurperConnectivityPrecheckSourceRequestKeysList | undefined;
    pathPrefix?: string | undefined;
    region?: string | undefined;
    jurisdiction?: SuperSlurperConnectivityPrecheckSourceRequestJurisdiction | (string & {}) | undefined;
}
export type SuperSlurperConnectivityPrecheckSourceResponseConnectivityStatus = "success" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SourceSuperSlurperConnectivityPrecheckResponse {
    connectivityStatus?: SuperSlurperConnectivityPrecheckSourceResponseConnectivityStatus | null | undefined;
}
export type SuperSlurperConnectivityPrecheckTargetRequestSecret = SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
export type SuperSlurperConnectivityPrecheckTargetRequestVendor = "r2";
export type SuperSlurperConnectivityPrecheckTargetRequestJurisdiction = "default" | "eu" | "us" | "fedramp";
export interface TargetSuperSlurperConnectivityPrecheckRequest {
    accountId: string;
    bucket: string;
    secret: SuperSlurperJobsCreateRequestSourceR2SlurperS3SourceSchemaSecret;
    vendor: SuperSlurperConnectivityPrecheckTargetRequestVendor | (string & {});
    jurisdiction?: SuperSlurperConnectivityPrecheckTargetRequestJurisdiction | (string & {}) | undefined;
}
export type SuperSlurperConnectivityPrecheckTargetResponseConnectivityStatus = "success" | "error";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TargetSuperSlurperConnectivityPrecheckResponse {
    connectivityStatus?: SuperSlurperConnectivityPrecheckTargetResponseConnectivityStatus | null | undefined;
}
export type BucketsDomainsCustomUpdateRequestCiphersList = Array<string>;
export type BucketsDomainsCustomUpdateRequestMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
export type BucketsDomainsCustomUpdateRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface UpdateBucketDomainCustomRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Name of the custom domain. */
    domain: string;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomUpdateRequestCiphersList | undefined;
    /** Whether to enable public bucket access at the specified custom domain. */
    enabled?: boolean | undefined;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to previous value. */
    minTLS?: BucketsDomainsCustomUpdateRequestMinTLS | (string & {}) | undefined;
    jurisdiction?: BucketsDomainsCustomUpdateRequestCfR2Jurisdiction | (string & {}) | undefined;
}
export type BucketsDomainsCustomUpdateResponseCiphersList = Array<string>;
export type BucketsDomainsCustomUpdateResponseMinTLS = "1.0" | "1.1" | "1.2" | "1.3";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateBucketDomainCustomResponse {
    /** Domain name of the affected custom domain. */
    domain: string;
    /** An allowlist of ciphers for TLS termination. These ciphers must be in the BoringSSL format. */
    ciphers?: BucketsDomainsCustomUpdateResponseCiphersList | null | undefined;
    /** Whether this bucket is publicly accessible at the specified custom domain. */
    enabled?: boolean | null | undefined;
    /** Minimum TLS Version the custom domain will accept for incoming connections. If not set, defaults to 1.0. */
    minTLS?: BucketsDomainsCustomUpdateResponseMinTLS | null | undefined;
}
export type BucketsObjectsUploadRequestCfR2StorageClass = "Standard" | "InfrequentAccess";
export type BucketsObjectsUploadRequestCfR2Jurisdiction = "default" | "eu" | "us" | "fedramp" | "fedramp-high";
export interface UploadBucketObjectRequest {
    /** Cloudflare account ID that owns the R2 resource. */
    accountId: string;
    /** Name of the bucket. */
    bucketName: string;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    cfR2StorageClass?: BucketsObjectsUploadRequestCfR2StorageClass | (string & {}) | undefined;
    /** The key (name) to assign to the object. May contain slashes for path-like keys. Slashes (`/`) within the key MUST be sent literally and MUST NOT be percent-encoded (i.e. `%2F`); other reserved characters should be percent-encoded as usual. */
    objectName: string;
    jurisdiction?: BucketsObjectsUploadRequestCfR2Jurisdiction | (string & {}) | undefined;
    /** The object content -- sent verbatim as the request body. */
    body?: Blob | Uint8Array | ArrayBuffer | string | undefined;
    /** MIME type stored with the object. */
    contentType?: string | undefined;
    /** Content disposition of the object. */
    contentDisposition?: string | undefined;
    /** Content encoding of the object. */
    contentEncoding?: string | undefined;
    /** Content language of the object. */
    contentLanguage?: string | undefined;
    /** Content length of the object in bytes. */
    contentLength?: string | undefined;
    /** Cache control directives for the object. */
    cacheControl?: string | undefined;
    /** Expiration date of the object. */
    expires?: string | undefined;
}
export type BucketsObjectsUploadResponseStorageClass = "Standard" | "InfrequentAccess";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UploadBucketObjectResponse {
    /** The entity tag for the uploaded object. */
    etag?: string | null | undefined;
    /** The key (name) of the uploaded object. */
    key?: string | null | undefined;
    /** The size of the uploaded object in bytes (as a string). */
    size?: string | null | undefined;
    /** Storage class for newly uploaded objects, unless specified otherwise. */
    storageClass?: BucketsObjectsUploadResponseStorageClass | null | undefined;
    /** The date and time the object was uploaded. */
    uploaded?: string | null | undefined;
    /** The version UUID of the uploaded object. */
    version?: string | null | undefined;
}
export type AbortAllSuperSlurperJobError = CloudflareOpError;
/** Cancels all running R2 Super Slurper migration jobs for the account. Any objects in the middle of a transfer will finish, but no new objects will start transferring. */
export declare const abortAllSuperSlurperJob: API.OperationMethod<AbortAllSuperSlurperJobRequest, AbortAllSuperSlurperJobResponse, AbortAllSuperSlurperJobError, CloudflareOpContext>;
export type AbortSuperSlurperJobError = SuperSlurperJobOperationFailed | CloudflareOpError;
/** Cancels a specific R2 Super Slurper migration job. Any objects in the middle of a transfer will finish, but no new objects will start transferring. */
export declare const abortSuperSlurperJob: API.OperationMethod<AbortSuperSlurperJobRequest, AbortSuperSlurperJobResponse, AbortSuperSlurperJobError, CloudflareOpContext>;
export type CreateBucketError = InvalidBucketName | BucketAlreadyExists | InvalidRoute | CloudflareOpError;
/** Creates an R2 bucket in the account and selected jurisdiction, with an optional location hint and default storage class. */
export declare const createBucket: API.OperationMethod<CreateBucketRequest, CreateBucketResponse, CreateBucketError, CloudflareOpContext>;
export type CreateBucketDomainCustomError = NoSuchBucket | InvalidBucketName | CustomDomainInUse | CloudflareOpError;
/** Register a new custom domain for an existing R2 bucket. */
export declare const createBucketDomainCustom: API.OperationMethod<CreateBucketDomainCustomRequest, CreateBucketDomainCustomResponse, CreateBucketDomainCustomError, CloudflareOpContext>;
export type CreateBucketsJobError = CloudflareOpError;
/** Creates a background job for an R2 bucket. The `jobType` field selects the job: - **`prefixDelete`**: deletes every object whose key begins with `prefix`. A non-empty prefix must end in `/`. An empty prefix ( `""`) empties the entire bucket. - **`storageClassMigration`**: migrates every object in the bucket between storage classes. `sourceStorageClass` and `destinationStorageClass` must be provided together and must differ; omitting both migrates from `InfrequentAccess` to `Standard`. Poll the returned `id` with the Get Bucket Job endpoint. Small prefix-delete jobs can finish synchronously and return `COMPLETED`. Objects uploaded after a background job starts are not affected by that job. For prefix-delete jobs: abort active multipart uploads before submitting the request, since a synchronously completed job does not abort them, and avoid writing objects or starting multipart uploads while a bucket-emptying job is in progress. Each request creates a distinct job, and the number of active prefix-delete jobs is limited per bucket; wait for an existing job to finish before retrying a request rejected with HTTP 429. A bucket cannot be emptied while event notifications are configured (HTTP 409 / error code 10083). To protect a bucket with R2 Data Catalog enabled, send the `cf-r2-data-catalog-check` header; a conflict is returned with HTTP 409 / error code 10081. Prefix-delete jobs require permission to delete objects; storage-class migration jobs require permission to write to the bucket. */
export declare const createBucketsJob: API.OperationMethod<CreateBucketsJobRequest, CreateBucketsJobResponse, CreateBucketsJobError, CloudflareOpContext>;
export type CreateSuperSlurperJobError = SuperSlurperPreconnectivityFailed | CloudflareOpError;
/** Creates a new R2 Super Slurper migration job to transfer objects from a source bucket (e.g. S3, GCS, R2) to R2. */
export declare const createSuperSlurperJob: API.OperationMethod<CreateSuperSlurperJobRequest, CreateSuperSlurperJobResponse, CreateSuperSlurperJobError, CloudflareOpContext>;
export type CreateTemporaryCredentialError = CloudflareOpError;
/** Creates temporary access credentials on a bucket that can be optionally scoped to prefixes or objects. */
export declare const createTemporaryCredential: API.OperationMethod<CreateTemporaryCredentialRequest, CreateTemporaryCredentialResponse, CreateTemporaryCredentialError, CloudflareOpContext>;
export type DeleteBucketError = NoSuchBucket | BucketNotEmpty | InvalidRoute | NoRoute | CloudflareOpError;
/** Deletes an empty R2 bucket and its configuration. The bucket must have no objects, no in-progress multipart uploads, and no event notification rules; otherwise the request fails. */
export declare const deleteBucket: API.OperationMethod<DeleteBucketRequest, DeleteBucketResponse, DeleteBucketError, CloudflareOpContext>;
export type DeleteBucketCorsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Delete the CORS policy for a bucket. */
export declare const deleteBucketCors: API.OperationMethod<DeleteBucketCorsRequest, DeleteBucketCorsResponse, DeleteBucketCorsError, CloudflareOpContext>;
export type DeleteBucketDomainCustomError = DomainNotFound | NoSuchBucket | CloudflareOpError;
/** Disconnects a custom domain from an R2 bucket and removes its configuration. Access through other enabled custom domains or the bucket's r2.dev domain is unaffected. */
export declare const deleteBucketDomainCustom: API.OperationMethod<DeleteBucketDomainCustomRequest, DeleteBucketDomainCustomResponse, DeleteBucketDomainCustomError, CloudflareOpContext>;
export type DeleteBucketEventNotificationError = BucketNotFound | EventNotificationConfigNotFound | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Deletes the specified event notification rules for an R2 bucket and Cloudflare Queue. Provide ruleIds in the request body to select rules. If no body is provided, all rules for that bucket and queue are deleted. */
export declare const deleteBucketEventNotification: API.OperationMethod<DeleteBucketEventNotificationRequest, DeleteBucketEventNotificationResponse, DeleteBucketEventNotificationError, CloudflareOpContext>;
export type DeleteBucketObjectError = NoSuchBucket | NoSuchKey | CloudflareOpError;
/** Deletes an object from an R2 bucket. For most workloads, we recommend using R2's [S3-compatible API](https://developers.cloudflare.com/r2/api/s3/api/) or a [Worker with an R2 binding](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/) instead. */
export declare const deleteBucketObject: API.OperationMethod<DeleteBucketObjectRequest, DeleteBucketObjectResponse, DeleteBucketObjectError, CloudflareOpContext>;
export type DeleteBucketSippyError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Disables Sippy on-demand migration for an R2 bucket. Requests no longer fetch missing objects from the source storage provider. Objects already copied to R2 remain in the bucket. */
export declare const deleteBucketSippy: API.OperationMethod<DeleteBucketSippyRequest, DeleteBucketSippyResponse, DeleteBucketSippyError, CloudflareOpContext>;
export type DeleteObjectsError = NoSuchBucket | InvalidRoute | NoRoute | CloudflareOpError;
export declare const deleteObjects: API.OperationMethod<DeleteObjectsRequest, DeleteObjectsResponse, DeleteObjectsError, CloudflareOpContext>;
export type GetBucketError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Gets properties of an existing R2 bucket. */
export declare const getBucket: API.OperationMethod<GetBucketRequest, GetBucketResponse, GetBucketError, CloudflareOpContext>;
export type GetBucketCorsError = NoSuchBucket | InvalidRoute | NoCorsConfiguration | CloudflareOpError;
/** Get the CORS policy for a bucket. */
export declare const getBucketCors: API.OperationMethod<GetBucketCorsRequest, GetBucketCorsResponse, GetBucketCorsError, CloudflareOpContext>;
export type GetBucketDomainCustomError = DomainNotFound | NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Get the configuration for a custom domain on an existing R2 bucket. */
export declare const getBucketDomainCustom: API.OperationMethod<GetBucketDomainCustomRequest, GetBucketDomainCustomResponse, GetBucketDomainCustomError, CloudflareOpContext>;
export type GetBucketEventNotificationError = BucketNotFound | NoEventNotificationConfig | EventNotificationConfigNotFound | QueueNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Gets the event notification rules for the specified R2 bucket and Cloudflare Queue. The response includes the queue's configuration and its array of rules. */
export declare const getBucketEventNotification: API.OperationMethod<GetBucketEventNotificationRequest, GetBucketEventNotificationResponse, GetBucketEventNotificationError, CloudflareOpContext>;
export type GetBucketLifecycleError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Get object lifecycle rules for a bucket. */
export declare const getBucketLifecycle: API.OperationMethod<GetBucketLifecycleRequest, GetBucketLifecycleResponse, GetBucketLifecycleError, CloudflareOpContext>;
export type GetBucketLocalUploadsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Get the Local Uploads configuration for a bucket. */
export declare const getBucketLocalUploads: API.OperationMethod<GetBucketLocalUploadsRequest, GetBucketLocalUploadsResponse, GetBucketLocalUploadsError, CloudflareOpContext>;
export type GetBucketLockError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Get lock rules for a bucket. */
export declare const getBucketLock: API.OperationMethod<GetBucketLockRequest, GetBucketLockResponse, GetBucketLockError, CloudflareOpContext>;
export type GetBucketObjectError = NoSuchBucket | InvalidRoute | NoSuchKey | CloudflareOpError;
/** Retrieves an object from an R2 bucket. Returns the object body along with metadata headers. For most workloads, we recommend using R2's [S3-compatible API](https://developers.cloudflare.com/r2/api/s3/api/) or a [Worker with an R2 binding](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/) instead. */
export declare const getBucketObject: API.OperationMethod<GetBucketObjectRequest, GetBucketObjectResponse, GetBucketObjectError, CloudflareOpContext>;
export type GetBucketSippyError = NoSuchBucket | InvalidRoute | Forbidden | CloudflareOpError;
/** Gets configuration for Sippy for an existing R2 bucket. */
export declare const getBucketSippy: API.OperationMethod<GetBucketSippyRequest, GetBucketSippyResponse, GetBucketSippyError, CloudflareOpContext>;
export type GetBucketsJobError = CloudflareOpError;
/** Gets the current status of a background job of any type for an R2 bucket. Poll this endpoint with the job identifier returned by Create Bucket Job until the status is `COMPLETED`, `FAILED`, or `CANCELLED`. */
export declare const getBucketsJob: API.OperationMethod<GetBucketsJobRequest, GetBucketsJobResponse, GetBucketsJobError, CloudflareOpContext>;
export type GetSuperSlurperJobError = SuperSlurperJobOperationFailed | CloudflareOpError;
/** Retrieves detailed status and configuration for a specific R2 Super Slurper migration job. */
export declare const getSuperSlurperJob: API.OperationMethod<GetSuperSlurperJobRequest, GetSuperSlurperJobResponse, GetSuperSlurperJobError, CloudflareOpContext>;
export type ListBucketDomainCustomsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Gets a list of all custom domains registered with an existing R2 bucket. */
export declare const listBucketDomainCustoms: API.OperationMethod<ListBucketDomainCustomsRequest, ListBucketDomainCustomsResponse, ListBucketDomainCustomsError, CloudflareOpContext>;
export type ListBucketDomainManagedsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Gets the R2 bucket's managed r2.dev domain and whether public access is enabled. The r2.dev domain is rate-limited and intended for development use. */
export declare const listBucketDomainManageds: API.OperationMethod<ListBucketDomainManagedsRequest, ListBucketDomainManagedsResponse, ListBucketDomainManagedsError, CloudflareOpContext>;
export type ListBucketEventNotificationsError = NoSuchBucket | InvalidRoute | NoEventNotificationConfig | BucketNotFound | CloudflareOpError;
/** Lists event notification rules for an R2 bucket, grouped by the Cloudflare Queue that receives matching object events. */
export declare const listBucketEventNotifications: API.OperationMethod<ListBucketEventNotificationsRequest, ListBucketEventNotificationsResponse, ListBucketEventNotificationsError, CloudflareOpContext>;
export type ListBucketMetricsError = InvalidRoute | CloudflareOpError;
/** Get Storage/Object Count Metrics across all buckets in your account. Note that Account-Level Metrics may not immediately reflect the latest data. */
export declare const listBucketMetrics: API.OperationMethod<ListBucketMetricsRequest, ListBucketMetricsResponse, ListBucketMetricsError, CloudflareOpContext>;
export type ListBucketObjectsError = NoSuchBucket | CloudflareOpError;
/** Lists objects in an R2 bucket. Returns object metadata including key, size, etag, last modified date, HTTP metadata, and custom metadata. For most workloads, we recommend using R2's [S3-compatible API](https://developers.cloudflare.com/r2/api/s3/api/) or a [Worker with an R2 binding](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/) instead. */
export declare const listBucketObjects: API.PaginatedOperationMethod<ListBucketObjectsRequest, ListBucketObjectsResponse, ListBucketObjectsError, CloudflareOpContext, BucketsObjectsListResultItem>;
export type ListBucketsError = InvalidRoute | CloudflareOpError;
/** Lists a page of R2 buckets in the account and selected jurisdiction. Use the returned cursor to retrieve the next page. */
export declare const listBuckets: API.OperationMethod<ListBucketsRequest, ListBucketsResponse, ListBucketsError, CloudflareOpContext>;
export type ListBucketsJobsError = CloudflareOpError;
/** Lists background jobs for an R2 bucket, including prefix-delete (and bucket-emptying) jobs and storage-class migration jobs. Jobs of every type are returned unless `jobType` is provided. */
export declare const listBucketsJobs: API.OperationMethod<ListBucketsJobsRequest, ListBucketsJobsResponse, ListBucketsJobsError, CloudflareOpContext>;
export type ListSuperSlurperJobLogsError = CloudflareOpError;
/** Gets log entries for an R2 Super Slurper migration job, showing migration status changes, errors, etc. */
export declare const listSuperSlurperJobLogs: API.PaginatedOperationMethod<ListSuperSlurperJobLogsRequest, ListSuperSlurperJobLogsResponse, ListSuperSlurperJobLogsError, CloudflareOpContext, SuperSlurperJobsLogsListResultItem>;
export type ListSuperSlurperJobsError = CloudflareOpError;
/** Lists all R2 Super Slurper migration jobs for the account with their status. */
export declare const listSuperSlurperJobs: API.PaginatedOperationMethod<ListSuperSlurperJobsRequest, ListSuperSlurperJobsResponse, ListSuperSlurperJobsError, CloudflareOpContext, SuperSlurperJobsListResultItem>;
export type PatchBucketError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Changes the default storage class for newly uploaded objects in an existing R2 bucket. Existing objects retain their storage class, and individual uploads can override the bucket default. */
export declare const patchBucket: API.OperationMethod<PatchBucketRequest, PatchBucketResponse, PatchBucketError, CloudflareOpContext>;
export type PauseSuperSlurperJobError = SuperSlurperJobOperationFailed | CloudflareOpError;
/** Pauses a running R2 Super Slurper migration job. The job can be resumed later to continue transferring. */
export declare const pauseSuperSlurperJob: API.OperationMethod<PauseSuperSlurperJobRequest, PauseSuperSlurperJobResponse, PauseSuperSlurperJobError, CloudflareOpContext>;
export type ProgressSuperSlurperJobError = CloudflareOpError;
/** Retrieves current progress metrics for an R2 Super Slurper migration job */
export declare const progressSuperSlurperJob: API.OperationMethod<ProgressSuperSlurperJobRequest, ProgressSuperSlurperJobResponse, ProgressSuperSlurperJobError, CloudflareOpContext>;
export type PutBucketCorsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Replaces the Cross-Origin Resource Sharing (CORS) rules for an R2 bucket. Rules specify which origins, methods, and headers are allowed for browser requests to objects in the bucket. */
export declare const putBucketCors: API.OperationMethod<PutBucketCorsRequest, PutBucketCorsResponse, PutBucketCorsError, CloudflareOpContext>;
export type PutBucketDomainManagedError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Enables or disables public access to the R2 bucket through its managed r2.dev domain. Custom domain access is unaffected. The r2.dev domain is rate-limited and intended for development use. */
export declare const putBucketDomainManaged: API.OperationMethod<PutBucketDomainManagedRequest, PutBucketDomainManagedResponse, PutBucketDomainManagedError, CloudflareOpContext>;
export type PutBucketEventNotificationError = BucketNotFound | InvalidEventNotificationConfig | EventNotificationRuleConflict | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Creates rules that send notifications for matching R2 object events to the specified Cloudflare Queue. Rules can filter objects by key prefix and suffix. New rules are added to any existing rules for the queue; a rule that overlaps an existing rule is rejected. */
export declare const putBucketEventNotification: API.OperationMethod<PutBucketEventNotificationRequest, PutBucketEventNotificationResponse, PutBucketEventNotificationError, CloudflareOpContext>;
export type PutBucketLifecycleError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Replaces the object lifecycle rules for an R2 bucket. Rules match object-key prefixes and can expire objects, abort incomplete multipart uploads, or transition objects to Infrequent Access storage. */
export declare const putBucketLifecycle: API.OperationMethod<PutBucketLifecycleRequest, PutBucketLifecycleResponse, PutBucketLifecycleError, CloudflareOpContext>;
export type PutBucketLocalUploadsError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Enable or disable Local Uploads for a bucket. Upload data from clients outside the bucket's region is written near the client first, then replicated to the bucket. */
export declare const putBucketLocalUploads: API.OperationMethod<PutBucketLocalUploadsRequest, PutBucketLocalUploadsResponse, PutBucketLocalUploadsError, CloudflareOpContext>;
export type PutBucketLockError = NoSuchBucket | InvalidRoute | CloudflareOpError;
/** Replaces the lock rules for an R2 bucket. Enabled rules prevent matching objects from being overwritten or deleted for a duration, until a date, or indefinitely. Rules apply to existing and newly uploaded objects. */
export declare const putBucketLock: API.OperationMethod<PutBucketLockRequest, PutBucketLockResponse, PutBucketLockError, CloudflareOpContext>;
export type PutBucketSippyError = InvalidUpstreamCredentials | InvalidRoute | CloudflareOpError;
/** Configures and enables Sippy on-demand migration for an R2 bucket. When a requested object is missing from R2, Sippy serves it from the configured source storage provider and copies it to R2. */
export declare const putBucketSippy: API.OperationMethod<PutBucketSippyRequest, PutBucketSippyResponse, PutBucketSippyError, CloudflareOpContext>;
export type ResumeSuperSlurperJobError = SuperSlurperJobOperationFailed | CloudflareOpError;
/** Resumes a paused R2 Super Slurper migration job, continuing the transfer from where it stopped. */
export declare const resumeSuperSlurperJob: API.OperationMethod<ResumeSuperSlurperJobRequest, ResumeSuperSlurperJobResponse, ResumeSuperSlurperJobError, CloudflareOpContext>;
export type SourceSuperSlurperConnectivityPrecheckError = CloudflareOpError;
/** Check whether tokens are valid against the source bucket */
export declare const sourceSuperSlurperConnectivityPrecheck: API.OperationMethod<SourceSuperSlurperConnectivityPrecheckRequest, SourceSuperSlurperConnectivityPrecheckResponse, SourceSuperSlurperConnectivityPrecheckError, CloudflareOpContext>;
export type TargetSuperSlurperConnectivityPrecheckError = CloudflareOpError;
/** Check whether tokens are valid against the target bucket */
export declare const targetSuperSlurperConnectivityPrecheck: API.OperationMethod<TargetSuperSlurperConnectivityPrecheckRequest, TargetSuperSlurperConnectivityPrecheckResponse, TargetSuperSlurperConnectivityPrecheckError, CloudflareOpContext>;
export type UpdateBucketDomainCustomError = NoSuchBucket | CloudflareOpError;
/** Edit the configuration for a custom domain on an existing R2 bucket. */
export declare const updateBucketDomainCustom: API.OperationMethod<UpdateBucketDomainCustomRequest, UpdateBucketDomainCustomResponse, UpdateBucketDomainCustomError, CloudflareOpContext>;
export type UploadBucketObjectError = NoSuchBucket | CloudflareOpError;
/** Uploads an object to an R2 bucket. The object body is provided as the request body. Returns metadata about the uploaded object. The maximum upload size for this endpoint is 300 MB. For most workloads, we recommend using R2's [S3-compatible API](https://developers.cloudflare.com/r2/api/s3/api/) or a [Worker with an R2 binding](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/) instead. */
export declare const uploadBucketObject: API.OperationMethod<UploadBucketObjectRequest, UploadBucketObjectResponse, UploadBucketObjectError, CloudflareOpContext>;
export declare const deleteObject: API.OperationMethod<DeleteBucketObjectRequest, DeleteBucketObjectResponse, DeleteBucketObjectError, CloudflareOpContext>;
export type DeleteObjectRequest = DeleteBucketObjectRequest;
export type DeleteObjectResponse = DeleteBucketObjectResponse;
export type DeleteObjectError = DeleteBucketObjectError;
export declare const getObject: API.OperationMethod<GetBucketObjectRequest, GetBucketObjectResponse, GetBucketObjectError, CloudflareOpContext>;
export type GetObjectRequest = GetBucketObjectRequest;
export type GetObjectResponse = GetBucketObjectResponse;
export type GetObjectError = GetBucketObjectError;
export declare const listObjects: API.PaginatedOperationMethod<ListBucketObjectsRequest, ListBucketObjectsResponse, ListBucketObjectsError, CloudflareOpContext, BucketsObjectsListResultItem>;
export type ListObjectsRequest = ListBucketObjectsRequest;
export type ListObjectsResponse = ListBucketObjectsResponse;
export type ListObjectsError = ListBucketObjectsError;
export declare const putObject: API.OperationMethod<UploadBucketObjectRequest, UploadBucketObjectResponse, UploadBucketObjectError, CloudflareOpContext>;
export type PutObjectRequest = UploadBucketObjectRequest;
export type PutObjectResponse = UploadBucketObjectResponse;
export type PutObjectError = UploadBucketObjectError;
export { layerS3, S3CredentialsError } from "../layer-s3.ts";
//# sourceMappingURL=r2.d.ts.map