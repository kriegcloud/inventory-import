/**
 * Reading schema annotations through the wrappers a generated schema has:
 * Suspend, encodings, and `S.optional` / nullable unions. Shared by the
 * protocols (via `./protocol-http.ts`) and by `./telemetry.ts`, which
 * derives span facts from the same annotations.
 */
import type * as AST from "effect/SchemaAST";
/**
 * Marks a response schema whose entire value is the response body (see
 * `RawResponseRoot` in `./protocol-rest.ts`).
 */
export declare const rawResponseRootSymbol: unique symbol;
export declare const getProps: (ast: AST.AST) => readonly AST.PropertySignature[];
export declare const getAnn: (ast: AST.AST, symbol: symbol) => unknown;
/** Resolve wrappers to the real node: Suspend, encoding, optional/null unions. */
export declare const resolveNode: (ast: AST.AST) => AST.AST;
//# sourceMappingURL=annotations.d.ts.map