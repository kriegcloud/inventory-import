import { ConfigError } from "@distilled.cloud/core/errors";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import type { GithubAppAuthError } from "./errors.ts";
/** github.com's REST API root. */
export declare const DEFAULT_API_BASE_URL = "https://api.github.com";
/**
 * GitHub requires every request to carry a User-Agent and rejects those
 * that don't (403). Callers on GitHub Enterprise Server point
 * `apiBaseUrl` at `https://HOSTNAME/api/v3`.
 */
export declare const DEFAULT_USER_AGENT = "distilled.cloud-github";
export interface Config {
    readonly token: Redacted.Redacted<string>;
    readonly apiBaseUrl: string;
    readonly userAgent: string;
    /**
     * When `token` was minted, in epoch milliseconds. GitHub can refuse a
     * token it minted a moment ago while the token replicates, so the
     * protocol sends a request that fails with 401 again for up to five
     * seconds after this time. Leave it out for long-lived tokens.
     */
    readonly issuedAt?: number;
}
declare const Credentials_base: Context.ServiceClass<Credentials, "GithubCredentials", Effect.Effect<Config, ConfigError | GithubAppAuthError, never>>;
export declare class Credentials extends /*@__PURE__*/ Credentials_base {
}
export declare const CredentialsFromEnv: Layer.Layer<Credentials, never, never>;
/** Convenience layer from a redacted token + optional base URL / User-Agent. */
export declare const credentials: (config: {
    readonly token: Redacted.Redacted<string>;
    readonly apiBaseUrl?: string;
    readonly userAgent?: string;
}) => Layer.Layer<Credentials>;
export {};
//# sourceMappingURL=credentials.d.ts.map