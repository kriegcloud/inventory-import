import * as Issues from "@distilled.cloud/github/issues";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as GitHub from "./Providers.ts";
export interface MilestoneProps {
    /**
     * Repository owner (user or organization).
     */
    owner: string;
    /**
     * Repository name.
     */
    repository: string;
    /**
     * Milestone title. The title is the milestone's identity — changing it
     * replaces the milestone.
     */
    title: string;
    /**
     * Milestone state.
     * @default "open"
     */
    state?: "open" | "closed";
    /**
     * Description of the milestone.
     */
    description?: string;
    /**
     * Due date for the milestone (ISO-8601 format: `YYYY-MM-DD` or full
     * `YYYY-MM-DDTHH:MM:SSZ`).
     */
    dueOn?: string;
    /**
     * Override the GitHub host or API base URL for this resource only (e.g.
     * `github.example.com` for GitHub Enterprise). Falls back to
     * `GitHub.providers({ baseUrl })`, then to the host resolved by the auth
     * provider. Changing it replaces the resource — the same name on a
     * different GitHub instance is a different physical resource.
     */
    baseUrl?: string;
}
export interface Milestone extends Resource<"GitHub.Milestone", MilestoneProps, {
    /**
     * The numeric milestone number.
     */
    milestoneNumber: number;
    /**
     * GraphQL node ID of the milestone.
     */
    nodeId: string;
    /**
     * The milestone title.
     */
    title: string;
    /**
     * Current state of the milestone.
     */
    state: "open" | "closed";
    /**
     * Milestone description.
     */
    description: string | null;
    /**
     * Due date for the milestone (ISO-8601 format).
     */
    dueOn: string | null;
    /**
     * URL to view the milestone in a browser.
     */
    htmlUrl: string;
    /**
     * ISO-8601 timestamp of when the milestone was created.
     */
    createdAt: string;
    /**
     * ISO-8601 timestamp of the last update.
     */
    updatedAt: string;
    /**
     * ISO-8601 timestamp when the milestone was closed.
     */
    closedAt: string | null;
    /**
     * Number of open issues in this milestone.
     */
    openIssues: number;
    /**
     * Number of closed issues in this milestone.
     */
    closedIssues: number;
}, never, GitHub.Providers, MilestoneLookup> {
}
/**
 * Props for {@link Milestone.lookup}: find a milestone this stack
 * doesn't manage by its repository and number.
 */
export interface MilestoneLookup {
    /** Repository owner (user or organization). */
    owner: string;
    /** Repository name. */
    repository: string;
    /** Milestone number. */
    number: number;
    /**
     * GitHub Enterprise Server URL.
     * @default `https://github.com`
     */
    baseUrl?: string;
}
/**
 * A GitHub milestone.
 *
 * `Milestone` manages repository milestones for tracking issues and pull
 * requests. Milestones are created on first deploy and updated in place on
 * subsequent deploys when properties change.
 *
 * Authentication is resolved via the GitHub `Credentials` service supplied by
 * `GitHub.providers()` (env, stored PAT, `gh` CLI, or OAuth). The token needs
 * `repo` scope for private repositories or `public_repo` for public ones.
 * ### Creating Milestones
 * **Example:** Basic Milestone
 * ```typescript
 * const v1 = yield* GitHub.Milestone("v1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "v1.0.0",
 *   description: "First stable release",
 * });
 * ```
 *
 * **Example:** Milestone with Due Date
 * ```typescript
 * yield* GitHub.Milestone("sprint-1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Sprint 1",
 *   description: "Complete user authentication",
 *   dueOn: "2026-12-31",
 * });
 * ```
 *
 * ### Updating Milestones
 * Deploy with the same logical ID and different properties to update the
 * existing milestone in place.
 *
 * **Example:** Update Description and Due Date
 * ```typescript
 * yield* GitHub.Milestone("v2", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "v2.0.0",
 *   description: "Updated: API redesign and performance improvements",
 *   dueOn: "2027-06-30",
 * });
 * ```
 *
 * ### Closing and Reopening
 * **Example:** Close a Milestone
 * ```typescript
 * yield* GitHub.Milestone("v1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "v1.0.0",
 *   state: "closed",
 * });
 * ```
 *
 * **Example:** Reopen a Milestone
 * ```typescript
 * yield* GitHub.Milestone("v1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "v1.0.0",
 *   state: "open",
 * });
 * ```
 *
 * ### Replacing on Title Change
 * Changing the title creates a new milestone and deletes the old one.
 *
 * **Example:** Replace by Changing Title
 * ```typescript
 * // First deploy creates "Q1 2026"
 * const milestone = yield* GitHub.Milestone("q1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Q1 2026",
 * });
 *
 * // Later deploy with same logical ID but different title replaces it
 * const milestone = yield* GitHub.Milestone("q1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Q1 2027",
 * });
 * ```
 *
 * ### Wiring with Other Resources
 * **Example:** Create Repository with Milestone
 * ```typescript
 * import * as Output from "alchemy/Output";
 *
 * const repo = yield* GitHub.Repository("api", {
 *   owner: "my-org",
 *   name: "api",
 *   autoInit: true,
 * });
 *
 * yield* GitHub.Milestone("launch", {
 *   owner: repo.owner!,
 *   repository: Output.map(repo.fullName, (fullName) => fullName.split("/")[1]!),
 *   title: "Initial Launch",
 *   dueOn: "2026-12-31",
 * });
 * ```
 *
 * ### Looking up an existing milestone
 * `Milestone.lookup` references a milestone Alchemy doesn't manage (created on
 * GitHub or by another stack). It is read during plan/deploy, never created,
 * updated or deleted.
 *
 * **Example:** Reference an existing milestone
 * ```typescript
 * const v2 = GitHub.Milestone.lookup({ owner: "alchemy-run", repository: "alchemy", number: 3 });
 * ```
 *
 * @resource
 * @product Issue
 */
export declare const Milestone: import("alchemy/Resource").ResourceClass<Milestone>;
export declare const MilestoneProvider: () => import("effect/Layer").Layer<Provider.Provider<Milestone>, never, Issues.GithubOpContext>;
//# sourceMappingURL=Milestone.d.ts.map