import { RuntimeContext } from "alchemy/RuntimeContext";
import * as Effect from "effect/Effect";
import * as HttpServerRequest from "effect/http/HttpServerRequest";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
export declare const STATE_STORE_SCRIPT_NAME: "alchemy-state-store";
/**
 * Version of the deployed Cloudflare State Store worker contract.
 *
 * Bump this whenever the wire format or runtime behaviour of the
 * worker changes in a way that an older deployed copy can no longer
 * satisfy. Clients query `/version` on the deployed worker and
 * compare against this constant; a mismatch (or 404) triggers a
 * forced redeploy via the bootstrap flow.
 */
export declare const STATE_STORE_VERSION: 9;
/**
 * Hard-coded OTLP/HTTP endpoints. Point at the public ingest relay
 * defined in `stacks/src/otel.ts` (bound to `otel.alchemy.run`), which
 * forwards to Axiom with the bearer token attached server-side. Hard-
 * coded on purpose: the worker has no env-var plumbing and the relay
 * is account-level infra that lives outside any single deploy.
 */
/**
 * OTLP traces + metrics + logs Layer for the state-store worker.
 * Mirrors the CLI's `TelemetryLive` so every signal the worker emits
 * (`Effect.withSpan`, runtime metrics, `Effect.log*`) ships to the
 * same Axiom datasets as deploy-time CLI signals. Resource attributes
 * brand each signal with the worker's service name + contract version
 * so they're easy to slice in Axiom.
 */
/** This module, the state-store Worker's bundling entry (see `Deploy.ts`). */
export declare const API_MAIN: string;
declare const _default: Effect.Effect<import("effect/Pipeable").Pipeable & import("alchemy").ResourceLike<"Cloudflare.Worker", import("../index.ts").WorkerProps<any, import("../index.ts").WorkerAssetsConfig | undefined>, {
    workerId: string;
    workerName: string;
    namespace: string | undefined;
    logpush: boolean | undefined;
    url: string | undefined;
    urls: string[];
    domain: {
        name: string;
        aliases: string[];
        redirects: string[];
        zone?: import("../Zone/lookup.ts").Reference;
        previews?: boolean;
    } | undefined;
    tags: string[] | undefined;
    durableObjectNamespaces: Record<string, string>;
    accountId: string;
    routes: {
        id: string;
        pattern: string;
        zoneId: string;
        url?: string;
    }[];
    crons: string[];
    tailConsumers?: {
        service: string;
    }[] | undefined;
    streamingTailConsumers?: {
        service: string;
    }[] | undefined;
    versionOf?: string | undefined;
    previewOf?: string | undefined;
    previewId?: string | undefined;
    previewName?: string | undefined;
    previewSlug?: string | undefined;
    previewDoClasses?: string[] | undefined;
    versionId?: string | undefined;
    versionAlias?: string | undefined;
    deploymentId?: string | undefined;
    affinityZoneIds?: string[] | undefined;
    secretNames?: string[] | undefined;
    hash?: {
        assets: string | undefined;
        bundle: string | undefined;
        input: string | undefined;
        additionalWorkspaces: string[] | undefined;
        metadata?: string | undefined;
    };
}, {
    bindings?: import("../index.ts").WorkerBinding[];
    env?: Record<string, any>;
    cache?: import("../index.ts").WorkerCache;
    observability?: {
        traces?: Partial<NonNullable<import("../index.ts").WorkerObservability["traces"]>>;
        logs?: Partial<NonNullable<import("../index.ts").WorkerObservability["logs"]>>;
    };
    containers?: {
        className: string;
        attachedBy?: "binding";
        name?: string;
        images?: Record<string, string>;
        devImages?: Record<string, import("../index.ts").DevContainerImage>;
        dev: import("../index.ts").DevContainerImage | undefined;
        hash: string | undefined;
    }[];
    crons?: string[];
    hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
    devRemote?: Record<string, boolean>;
}, import("../Providers.ts").Providers, import("../index.ts").WorkerLookup> & {
    bind(sid: import("alchemy").Input<string>, binding: import("alchemy").Input<{
        bindings?: import("../index.ts").WorkerBinding[];
        env?: Record<string, any>;
        cache?: import("../index.ts").WorkerCache;
        observability?: {
            traces?: Partial<NonNullable<import("../index.ts").WorkerObservability["traces"]>>;
            logs?: Partial<NonNullable<import("../index.ts").WorkerObservability["logs"]>>;
        };
        containers?: {
            className: string;
            attachedBy?: "binding";
            name?: string;
            images?: Record<string, string>;
            devImages?: Record<string, import("../index.ts").DevContainerImage>;
            dev: import("../index.ts").DevContainerImage | undefined;
            hash: string | undefined;
        }[];
        crons?: string[];
        hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
        devRemote?: Record<string, boolean>;
    }>): Effect.Effect<void>;
    bind(template: TemplateStringsArray, ...args: any[]): (binding: import("alchemy").Input<{
        bindings?: import("../index.ts").WorkerBinding[];
        env?: Record<string, any>;
        cache?: import("../index.ts").WorkerCache;
        observability?: {
            traces?: Partial<NonNullable<import("../index.ts").WorkerObservability["traces"]>>;
            logs?: Partial<NonNullable<import("../index.ts").WorkerObservability["logs"]>>;
        };
        containers?: {
            className: string;
            attachedBy?: "binding";
            name?: string;
            images?: Record<string, string>;
            devImages?: Record<string, import("../index.ts").DevContainerImage>;
            dev: import("../index.ts").DevContainerImage | undefined;
            hash: string | undefined;
        }[];
        crons?: string[];
        hyperdrives?: Record<string, Required<import("../Hyperdrive/Connection.ts").DevOrigin>>;
        devRemote?: Record<string, boolean>;
    }>) => Effect.Effect<void>;
} & {
    workerId: import("alchemy").Output<string, never>;
    workerName: import("alchemy").Output<string, never>;
    namespace: import("alchemy").Output<string | undefined, never>;
    logpush: import("alchemy").Output<boolean | undefined, never>;
    url: import("alchemy").Output<string | undefined, never>;
    urls: import("alchemy").Output<string[], never>;
    domain: import("alchemy").Output<{
        name: string;
        aliases: string[];
        redirects: string[];
        zone?: import("../Zone/lookup.ts").Reference;
        previews?: boolean;
    } | undefined, never>;
    tags: import("alchemy").Output<string[] | undefined, never>;
    durableObjectNamespaces: import("alchemy/Output").ObjectExpr<Record<string, string>, never>;
    accountId: import("alchemy").Output<string, never>;
    routes: import("alchemy").Output<{
        id: string;
        pattern: string;
        zoneId: string;
        url?: string;
    }[], never>;
    crons: import("alchemy").Output<string[], never>;
    tailConsumers: import("alchemy").Output<{
        service: string;
    }[] | undefined, never>;
    streamingTailConsumers: import("alchemy").Output<{
        service: string;
    }[] | undefined, never>;
    versionOf: import("alchemy").Output<string | undefined, never>;
    previewOf: import("alchemy").Output<string | undefined, never>;
    previewId: import("alchemy").Output<string | undefined, never>;
    previewName: import("alchemy").Output<string | undefined, never>;
    previewSlug: import("alchemy").Output<string | undefined, never>;
    previewDoClasses: import("alchemy").Output<string[] | undefined, never>;
    versionId: import("alchemy").Output<string | undefined, never>;
    versionAlias: import("alchemy").Output<string | undefined, never>;
    deploymentId: import("alchemy").Output<string | undefined, never>;
    affinityZoneIds: import("alchemy").Output<string[] | undefined, never>;
    secretNames: import("alchemy").Output<string[] | undefined, never>;
    hash: import("alchemy").Output<{
        assets: string | undefined;
        bundle: string | undefined;
        input: string | undefined;
        additionalWorkspaces: string[] | undefined;
        metadata?: string | undefined;
    } | undefined, never>;
} & import("alchemy").Rpc<{
    fetch: Effect.Effect<Effect.Effect<HttpServerResponse.HttpServerResponse, import("effect/http/HttpServerError").HttpServerError, HttpServerRequest.HttpServerRequest | RuntimeContext | import("effect/Scope").Scope>, never, import("effect/FileSystem").FileSystem | import("effect/Scope").Scope>;
}>, never, import("../Providers.ts").Providers> & import("alchemy").Named<"Api"> & import("alchemy").PlatformIdentity<"Api">;
export default _default;
//# sourceMappingURL=Api.d.ts.map