import type { RenderOptions, TerminalCapabilities, View } from "../types.ts";
export declare const normalizeView: (view: View) => View;
/** Render a layout to a string without a live renderer (help, plain output, snapshots). */
export declare const formatView: (view: View, capabilities: TerminalCapabilities, options?: RenderOptions) => string;
//# sourceMappingURL=Format.d.ts.map