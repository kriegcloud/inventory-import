/**
 * Query Parameter Utilities
 *
 * Handles extraction and parsing of query parameters from URI paths.
 */
import type { Request } from "../client/request.ts";
/**
 * Extract static query params from the URI path (e.g., "/{Bucket}?tagging").
 * Modifies request.path to remove the query part and adds params to request.query.
 */
export declare function extractStaticQueryParams(request: Request): void;
//# sourceMappingURL=query-params.d.ts.map