import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as Scope from "effect/Scope";
/**
 * The shape of the {@link Telemetry} reference: a Layer of telemetry
 * exporters (tracer, loggers, metrics) built once per event into the
 * event's request scope. Requirements are satisfied from the runtime's
 * isolate context (`HttpClient`, `ConfigProvider`, …).
 */
export type TelemetryLayer = Layer.Layer<never, any, any>;
/**
 * One export target for one signal, as stored in the bound destination
 * list: a concrete OTLP/HTTP URL and the headers to send with it.
 */
export interface ResolvedSignal {
    url: string;
    headers?: Record<string, string> | undefined;
}
/**
 * One export destination in the bound list — the resolved form of one
 * {@link layerOtlp} layer.
 */
export interface ResolvedDestination {
    traces?: ResolvedSignal | undefined;
    logs?: ResolvedSignal | undefined;
    metrics?: ResolvedSignal | undefined;
}
/**
 * The single env binding carrying every configured destination as a JSON
 * array of {@link ResolvedDestination}. One key (instead of per-signal
 * keys) is what lets multiple `layerOtlp` layers compose — each layer
 * build appends its destination and rebinds the full list.
 */
export declare const EXPORTERS_KEY = "ALCHEMY_OTEL_EXPORTERS";
/**
 * The `service.name` `layerOtlp({ serviceName })` binds. It has its own
 * Alchemy-owned key, not `OTEL_SERVICE_NAME`, so a value Alchemy packs never
 * shares a key with a value a user set verbatim. It wins over
 * `OTEL_SERVICE_NAME`.
 */
export declare const SERVICE_NAME_KEY = "ALCHEMY_OTEL_SERVICE_NAME";
/**
 * Every destination this runtime exports to: the bound `layerOtlp` list,
 * plus the standard `OTEL_EXPORTER_OTLP_*` variables as an implicit extra
 * destination. Resolved per call, since providers can change between events.
 *
 * @internal
 */
export declare const configuredDestinations: Effect.Effect<ResolvedDestination[]>;
/**
 * The runtime half of the {@link layerOtlp} binding, and the default
 * per-event Layer: reads the bound `OTEL_EXPORTER_OTLP_*` values back and
 * constructs the OTLP exporters (JSON for traces and logs, protobuf for
 * metrics). Each signal resolves independently;
 * only configured signals export; resolves to `Layer.empty` when nothing is
 * bound, so no exporters are built until a destination is configured.
 *
 * The periodic export intervals are effectively disabled: the exporter is
 * built per event and the request-scope flush delivers everything. An
 * interval export firing mid-event would race the scope close — the close
 * interrupts the exporter's in-flight batch (already spliced out of the
 * buffer), silently dropping it. Lambda invocations regularly outlive the
 * 1-second logger interval, which is exactly how this was discovered.
 * Final exports get the OTLP ten-second batch budget rather than the
 * exporter's three-second shutdown default, which can cancel slow delivery.
 *
 * A malformed configuration degrades to `Layer.empty` with a warning
 * instead of failing the event.
 */
export declare const fromBoundConfig: TelemetryLayer;
/**
 * The per-event telemetry exporters, as a `Context.Reference` holding the
 * Layer the runtime bridges build into every event's request scope.
 * Provide it via {@link layerOtlp} / {@link layer} rather than directly —
 * see the module documentation.
 */
export declare const Telemetry: Context.Reference<TelemetryLayer>;
/**
 * Build the configured {@link Telemetry} Layer into an event's request
 * scope, returning the Context of telemetry services to provide to the
 * event's handler effect.
 *
 * Called by the runtime bridges (Worker, Durable Object, Workflow, Lambda)
 * once per event. Building into the *request* scope — not the
 * never-finalized isolate scope — is what makes export work on workerd:
 * the batching fiber lives inside the event's I/O context and the final
 * flush runs from the scope's finalizer, which the bridges register with
 * `ctx.waitUntil`.
 *
 * A failed build (bad user Layer, config error) degrades to an empty
 * Context with a warning instead of failing the event.
 *
 * `override` is the (possibly merged) custom Layer registered on the
 * runtime context by {@link layer} during init. It composes with
 * — rather than replaces — the bound OTLP destinations: loggers and metric
 * exporters merge, and a custom `Tracer` (a single Effect service) wins
 * over the built-in one.
 *
 * Declared `R = never`: the Layer's actual requirements (`HttpClient`,
 * `ConfigProvider`, …) are satisfied at runtime by the bridge's surrounding
 * `Effect.provide` of the built runtime context.
 */
export declare const buildEventTelemetry: (context: Context.Context<never>, scope: Scope.Scope, override?: TelemetryLayer, base?: TelemetryLayer) => Effect.Effect<Context.Context<never>>;
/**
 * Provide telemetry to a long-running server process (Cloudflare Container,
 * ECS Task, EC2 host, Lambda microVM).
 *
 * Unlike the per-event runtime bridges, server processes have no I/O-context
 * pinning and a real shutdown: the configured {@link Telemetry} Layer is
 * built ONCE into the ambient root scope, exporters batch on their intervals
 * for the life of the process, and the final flush runs when the root scope
 * closes on graceful exit.
 *
 * `runtimeContext` is the entrypoint's runtime context; its `telemetry`
 * field carries the custom Layer(s) registered by {@link layer}
 * during init, composed with the bound OTLP destinations (read with the
 * standard periodic export intervals).
 *
 * Not for Durable Objects: the periodic exporters keep a timer pending, and
 * workerd won't hibernate an object while one is. The Durable Object bridge
 * gives each instance interval-free exporters of its own, flushed per event
 * (see {@link buildInstanceTelemetry}).
 */
export declare const provideProcessTelemetry: (runtimeContext?: {
    telemetry?: TelemetryLayer | undefined;
}) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R | Scope.Scope>;
/**
 * Telemetry built once for a Durable Object instance: the services to
 * provide to its initializer, and the flush the bridge runs at the end of
 * every event.
 *
 * @internal
 */
export interface InstanceTelemetry {
    readonly context: Context.Context<never>;
    readonly flush: Effect.Effect<void>;
}
/**
 * Build the bound trace and log exporters into a Durable Object instance's
 * scope, which never closes (workerd gives an instance no shutdown hook).
 * Fibers the initializer forks (a tick loop, a subscription) record into
 * them. The exporters have no export interval, so nothing keeps the object
 * awake while it is idle; `flush` delivers what they hold, and the bridge
 * runs it at the end of every event, inside that event's I/O context.
 *
 * Custom {@link layer} exporters stay per event: their intervals aren't
 * ours to turn off.
 *
 * @internal
 */
export declare const buildInstanceTelemetry: (context: Context.Context<never>, scope: Scope.Scope) => Effect.Effect<InstanceTelemetry>;
/**
 * An event's telemetry, handing off to the instance's once the event has
 * ended. A fiber the event forked and left running (`Effect.forkDetach`)
 * keeps the event's Tracer and loggers, whose exporters flushed and stopped
 * when the event's scope closed. Spans it starts and logs it writes after
 * that go to the instance's exporters instead, which the next event
 * flushes. Only services both contexts carry are switched.
 *
 * @internal
 */
export declare const handOffAfterEvent: (event: Context.Context<never>, instance: Context.Context<never>, ended: () => boolean) => Context.Context<never>;
//# sourceMappingURL=TelemetryRuntime.d.ts.map