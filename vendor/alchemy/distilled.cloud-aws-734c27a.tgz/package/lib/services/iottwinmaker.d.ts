import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConnectorFailureException_base: S.TaggedErrorClass<"ConnectorFailureException", {
    readonly message: any;
}>;
export declare class ConnectorFailureException extends /*@__PURE__*/ ConnectorFailureException_base {
}
declare const ConnectorTimeoutException_base: S.TaggedErrorClass<"ConnectorTimeoutException", {
    readonly message: any;
}>;
export declare class ConnectorTimeoutException extends /*@__PURE__*/ ConnectorTimeoutException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const QueryTimeoutException_base: S.TaggedErrorClass<"QueryTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class QueryTimeoutException extends /*@__PURE__*/ QueryTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Id = string;
export type Name = string;
export type ComponentPath = string;
export type ExternalIdProperty = {
    [key: string]: string | undefined;
};
export type EntityId = string;
export interface EntityPropertyReference {
    componentName?: string | undefined;
    componentPath?: string | undefined;
    externalIdProperty?: {
        [key: string]: string | undefined;
    } | undefined;
    entityId?: string | undefined;
    propertyName: string;
}
export type DataValueList = DataValue[];
export type DataValueMap = {
    [key: string]: DataValue | undefined;
};
export interface RelationshipValue {
    targetEntityId?: string | undefined;
    targetComponentName?: string | undefined;
}
export type Expression = string;
export interface DataValue {
    booleanValue?: boolean | undefined;
    doubleValue?: number | undefined;
    integerValue?: number | undefined;
    longValue?: number | undefined;
    stringValue?: string | undefined;
    listValue?: DataValue[] | undefined;
    mapValue?: {
        [key: string]: DataValue | undefined;
    } | undefined;
    relationshipValue?: RelationshipValue | undefined;
    expression?: string | undefined;
}
export interface PropertyValue {
    timestamp?: Date | undefined;
    value: DataValue;
    time?: string | undefined;
}
export type PropertyValues = PropertyValue[];
export interface PropertyValueEntry {
    entityPropertyReference: EntityPropertyReference;
    propertyValues?: PropertyValue[] | undefined;
}
export type Entries = PropertyValueEntry[];
export interface BatchPutPropertyValuesRequest {
    workspaceId: string;
    entries: PropertyValueEntry[];
}
export interface BatchPutPropertyError {
    errorCode: string;
    errorMessage: string;
    entry: PropertyValueEntry;
}
export type Errors = BatchPutPropertyError[];
export interface BatchPutPropertyErrorEntry {
    errors: BatchPutPropertyError[];
}
export type ErrorEntries = BatchPutPropertyErrorEntry[];
export interface BatchPutPropertyValuesResponse {
    errorEntries: BatchPutPropertyErrorEntry[];
}
export interface CancelMetadataTransferJobRequest {
    metadataTransferJobId: string;
}
export type TwinMakerArn = string;
export type MetadataTransferJobState = string;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface ErrorDetails {
    code?: string | undefined;
    message?: string | undefined;
}
export interface MetadataTransferJobStatus {
    state?: string | undefined;
    error?: ErrorDetails | undefined;
    queuedPosition?: number | undefined;
}
export interface MetadataTransferJobProgress {
    totalCount?: number | undefined;
    succeededCount?: number | undefined;
    skippedCount?: number | undefined;
    failedCount?: number | undefined;
}
export interface CancelMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress | undefined;
}
export type ComponentTypeId = string;
export type Description = string;
export type Type = string;
export interface Relationship {
    targetComponentTypeId?: string | undefined;
    relationshipType?: string | undefined;
}
export interface DataType {
    type: string;
    nestedType?: DataType | undefined;
    allowedValues?: DataValue[] | undefined;
    unitOfMeasure?: string | undefined;
    relationship?: Relationship | undefined;
}
export type Value = string;
export type Configuration = {
    [key: string]: string | undefined;
};
export type PropertyDisplayName = string;
export interface PropertyDefinitionRequest {
    dataType?: DataType | undefined;
    isRequiredInEntity?: boolean | undefined;
    isExternalId?: boolean | undefined;
    isStoredExternally?: boolean | undefined;
    isTimeSeries?: boolean | undefined;
    defaultValue?: DataValue | undefined;
    configuration?: {
        [key: string]: string | undefined;
    } | undefined;
    displayName?: string | undefined;
}
export type PropertyDefinitionsRequest = {
    [key: string]: PropertyDefinitionRequest | undefined;
};
export type ExtendsFrom = string[];
export type RequiredProperties = string[];
export type Scope = string;
export type LambdaArn = string;
export interface LambdaFunction {
    arn: string;
}
export interface DataConnector {
    lambda?: LambdaFunction | undefined;
    isNative?: boolean | undefined;
}
export interface FunctionRequest {
    requiredProperties?: string[] | undefined;
    scope?: string | undefined;
    implementedBy?: DataConnector | undefined;
}
export type FunctionsRequest = {
    [key: string]: FunctionRequest | undefined;
};
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type GroupType = string;
export type PropertyNames = string[];
export interface PropertyGroupRequest {
    groupType?: string | undefined;
    propertyNames?: string[] | undefined;
}
export type PropertyGroupsRequest = {
    [key: string]: PropertyGroupRequest | undefined;
};
export type ComponentTypeName = string;
export interface CompositeComponentTypeRequest {
    componentTypeId?: string | undefined;
}
export type CompositeComponentTypesRequest = {
    [key: string]: CompositeComponentTypeRequest | undefined;
};
export interface CreateComponentTypeRequest {
    workspaceId: string;
    isSingleton?: boolean | undefined;
    componentTypeId: string;
    description?: string | undefined;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionRequest | undefined;
    } | undefined;
    extendsFrom?: string[] | undefined;
    functions?: {
        [key: string]: FunctionRequest | undefined;
    } | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    propertyGroups?: {
        [key: string]: PropertyGroupRequest | undefined;
    } | undefined;
    componentTypeName?: string | undefined;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeRequest | undefined;
    } | undefined;
}
export type State = string;
export interface CreateComponentTypeResponse {
    arn: string;
    creationDateTime: Date;
    state: string;
}
export type EntityName = string;
export type PropertyUpdateType = string;
export interface PropertyRequest {
    definition?: PropertyDefinitionRequest | undefined;
    value?: DataValue | undefined;
    updateType?: string | undefined;
}
export type PropertyRequests = {
    [key: string]: PropertyRequest | undefined;
};
export type PropertyGroupUpdateType = string;
export interface ComponentPropertyGroupRequest {
    groupType?: string | undefined;
    propertyNames?: string[] | undefined;
    updateType?: string | undefined;
}
export type ComponentPropertyGroupRequests = {
    [key: string]: ComponentPropertyGroupRequest | undefined;
};
export interface ComponentRequest {
    description?: string | undefined;
    componentTypeId?: string | undefined;
    properties?: {
        [key: string]: PropertyRequest | undefined;
    } | undefined;
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    } | undefined;
}
export type ComponentsMapRequest = {
    [key: string]: ComponentRequest | undefined;
};
export interface CompositeComponentRequest {
    description?: string | undefined;
    properties?: {
        [key: string]: PropertyRequest | undefined;
    } | undefined;
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    } | undefined;
}
export type CompositeComponentsMapRequest = {
    [key: string]: CompositeComponentRequest | undefined;
};
export type ParentEntityId = string;
export interface CreateEntityRequest {
    workspaceId: string;
    entityId?: string | undefined;
    entityName: string;
    description?: string | undefined;
    components?: {
        [key: string]: ComponentRequest | undefined;
    } | undefined;
    compositeComponents?: {
        [key: string]: CompositeComponentRequest | undefined;
    } | undefined;
    parentEntityId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateEntityResponse {
    entityId: string;
    arn: string;
    creationDateTime: Date;
    state: string;
}
export type SourceType = string;
export type S3SourceLocation = string;
export interface S3SourceConfiguration {
    location: string;
}
export type Uuid = string;
export type SiteWiseExternalId = string;
export interface FilterByAssetModel {
    assetModelId?: string | undefined;
    assetModelExternalId?: string | undefined;
    includeOffspring?: boolean | undefined;
    includeAssets?: boolean | undefined;
}
export interface FilterByAsset {
    assetId?: string | undefined;
    assetExternalId?: string | undefined;
    includeOffspring?: boolean | undefined;
    includeAssetModel?: boolean | undefined;
}
export type IotSiteWiseSourceConfigurationFilter = {
    filterByAssetModel: FilterByAssetModel;
    filterByAsset?: undefined;
} | {
    filterByAssetModel?: undefined;
    filterByAsset: FilterByAsset;
};
export type IotSiteWiseSourceConfigurationFilters = IotSiteWiseSourceConfigurationFilter[];
export interface IotSiteWiseSourceConfiguration {
    filters?: IotSiteWiseSourceConfigurationFilter[] | undefined;
}
export interface FilterByComponentType {
    componentTypeId: string;
}
export interface FilterByEntity {
    entityId: string;
}
export type IotTwinMakerSourceConfigurationFilter = {
    filterByComponentType: FilterByComponentType;
    filterByEntity?: undefined;
} | {
    filterByComponentType?: undefined;
    filterByEntity: FilterByEntity;
};
export type IotTwinMakerSourceConfigurationFilters = IotTwinMakerSourceConfigurationFilter[];
export interface IotTwinMakerSourceConfiguration {
    workspace: string;
    filters?: IotTwinMakerSourceConfigurationFilter[] | undefined;
}
export interface SourceConfiguration {
    type: string;
    s3Configuration?: S3SourceConfiguration | undefined;
    iotSiteWiseConfiguration?: IotSiteWiseSourceConfiguration | undefined;
    iotTwinMakerConfiguration?: IotTwinMakerSourceConfiguration | undefined;
}
export type SourceConfigurations = SourceConfiguration[];
export type DestinationType = string;
export type S3DestinationLocation = string;
export interface S3DestinationConfiguration {
    location: string;
}
export interface IotTwinMakerDestinationConfiguration {
    workspace: string;
}
export interface DestinationConfiguration {
    type: string;
    s3Configuration?: S3DestinationConfiguration | undefined;
    iotTwinMakerConfiguration?: IotTwinMakerDestinationConfiguration | undefined;
}
export interface CreateMetadataTransferJobRequest {
    metadataTransferJobId?: string | undefined;
    description?: string | undefined;
    sources: SourceConfiguration[];
    destination: DestinationConfiguration;
}
export interface CreateMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    creationDateTime: Date;
    status: MetadataTransferJobStatus;
}
export type S3Url = string;
export type SceneCapability = string;
export type SceneCapabilities = string[];
export type SceneMetadataValue = string;
export type SceneMetadataMap = {
    [key: string]: string | undefined;
};
export interface CreateSceneRequest {
    workspaceId: string;
    sceneId: string;
    contentLocation: string;
    description?: string | undefined;
    capabilities?: string[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    sceneMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateSceneResponse {
    arn: string;
    creationDateTime: Date;
}
export type SyncSource = string;
export type RoleArn = string;
export interface CreateSyncJobRequest {
    workspaceId: string;
    syncSource: string;
    syncRole: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SyncJobState = string;
export interface CreateSyncJobResponse {
    arn: string;
    creationDateTime: Date;
    state: string;
}
export type S3Location = string;
export interface CreateWorkspaceRequest {
    workspaceId: string;
    description?: string | undefined;
    s3Location?: string | undefined;
    role?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateWorkspaceResponse {
    arn: string;
    creationDateTime: Date;
}
export interface DeleteComponentTypeRequest {
    workspaceId: string;
    componentTypeId: string;
}
export interface DeleteComponentTypeResponse {
    state: string;
}
export interface DeleteEntityRequest {
    workspaceId: string;
    entityId: string;
    isRecursive?: boolean | undefined;
}
export interface DeleteEntityResponse {
    state: string;
}
export interface DeleteSceneRequest {
    workspaceId: string;
    sceneId: string;
}
export interface DeleteSceneResponse {
}
export interface DeleteSyncJobRequest {
    workspaceId: string;
    syncSource: string;
}
export interface DeleteSyncJobResponse {
    state: string;
}
export interface DeleteWorkspaceRequest {
    workspaceId: string;
}
export type WorkspaceDeleteMessage = string;
export interface DeleteWorkspaceResponse {
    message?: string | undefined;
}
export type QueryStatement = string;
export type QueryServiceMaxResults = number;
export type NextToken = string;
export interface ExecuteQueryRequest {
    workspaceId: string;
    queryStatement: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ColumnName = string;
export type ColumnType = string;
export interface ColumnDescription {
    name?: string | undefined;
    type?: string | undefined;
}
export type ColumnDescriptions = ColumnDescription[];
export type QueryResultValue = unknown;
export type RowData = any[];
export interface Row {
    rowData?: any[] | undefined;
}
export type Rows = Row[];
export interface ExecuteQueryResponse {
    columnDescriptions?: ColumnDescription[] | undefined;
    rows?: Row[] | undefined;
    nextToken?: string | undefined;
}
export interface GetComponentTypeRequest {
    workspaceId: string;
    componentTypeId: string;
}
export interface PropertyDefinitionResponse {
    dataType: DataType;
    isTimeSeries: boolean;
    isRequiredInEntity: boolean;
    isExternalId: boolean;
    isStoredExternally: boolean;
    isImported: boolean;
    isFinal: boolean;
    isInherited: boolean;
    defaultValue?: DataValue | undefined;
    configuration?: {
        [key: string]: string | undefined;
    } | undefined;
    displayName?: string | undefined;
}
export type PropertyDefinitionsResponse = {
    [key: string]: PropertyDefinitionResponse | undefined;
};
export interface FunctionResponse {
    requiredProperties?: string[] | undefined;
    scope?: string | undefined;
    implementedBy?: DataConnector | undefined;
    isInherited?: boolean | undefined;
}
export type FunctionsResponse = {
    [key: string]: FunctionResponse | undefined;
};
export interface Status {
    state?: string | undefined;
    error?: ErrorDetails | undefined;
}
export interface PropertyGroupResponse {
    groupType: string;
    propertyNames: string[];
    isInherited: boolean;
}
export type PropertyGroupsResponse = {
    [key: string]: PropertyGroupResponse | undefined;
};
export interface CompositeComponentTypeResponse {
    componentTypeId?: string | undefined;
    isInherited?: boolean | undefined;
}
export type CompositeComponentTypesResponse = {
    [key: string]: CompositeComponentTypeResponse | undefined;
};
export interface GetComponentTypeResponse {
    workspaceId: string;
    isSingleton?: boolean | undefined;
    componentTypeId: string;
    description?: string | undefined;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionResponse | undefined;
    } | undefined;
    extendsFrom?: string[] | undefined;
    functions?: {
        [key: string]: FunctionResponse | undefined;
    } | undefined;
    creationDateTime: Date;
    updateDateTime: Date;
    arn: string;
    isAbstract?: boolean | undefined;
    isSchemaInitialized?: boolean | undefined;
    status?: Status | undefined;
    propertyGroups?: {
        [key: string]: PropertyGroupResponse | undefined;
    } | undefined;
    syncSource?: string | undefined;
    componentTypeName?: string | undefined;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeResponse | undefined;
    } | undefined;
}
export interface GetEntityRequest {
    workspaceId: string;
    entityId: string;
}
export interface PropertyResponse {
    definition?: PropertyDefinitionResponse | undefined;
    value?: DataValue | undefined;
    areAllPropertyValuesReturned?: boolean | undefined;
}
export type PropertyResponses = {
    [key: string]: PropertyResponse | undefined;
};
export interface ComponentPropertyGroupResponse {
    groupType: string;
    propertyNames: string[];
    isInherited: boolean;
}
export type ComponentPropertyGroupResponses = {
    [key: string]: ComponentPropertyGroupResponse | undefined;
};
export interface ComponentSummary {
    componentName: string;
    componentTypeId: string;
    definedIn?: string | undefined;
    description?: string | undefined;
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupResponse | undefined;
    } | undefined;
    status: Status;
    syncSource?: string | undefined;
    componentPath?: string | undefined;
}
export type CompositeComponentResponse = {
    [key: string]: ComponentSummary | undefined;
};
export interface ComponentResponse {
    componentName?: string | undefined;
    description?: string | undefined;
    componentTypeId?: string | undefined;
    status?: Status | undefined;
    definedIn?: string | undefined;
    properties?: {
        [key: string]: PropertyResponse | undefined;
    } | undefined;
    propertyGroups?: {
        [key: string]: ComponentPropertyGroupResponse | undefined;
    } | undefined;
    syncSource?: string | undefined;
    areAllPropertiesReturned?: boolean | undefined;
    compositeComponents?: {
        [key: string]: ComponentSummary | undefined;
    } | undefined;
    areAllCompositeComponentsReturned?: boolean | undefined;
}
export type ComponentsMap = {
    [key: string]: ComponentResponse | undefined;
};
export interface GetEntityResponse {
    entityId: string;
    entityName: string;
    arn: string;
    status: Status;
    workspaceId: string;
    description?: string | undefined;
    components?: {
        [key: string]: ComponentResponse | undefined;
    } | undefined;
    parentEntityId: string;
    hasChildEntities: boolean;
    creationDateTime: Date;
    updateDateTime: Date;
    syncSource?: string | undefined;
    areAllComponentsReturned?: boolean | undefined;
}
export interface GetMetadataTransferJobRequest {
    metadataTransferJobId: string;
}
export interface GetMetadataTransferJobResponse {
    metadataTransferJobId: string;
    arn: string;
    description?: string | undefined;
    sources: SourceConfiguration[];
    destination: DestinationConfiguration;
    metadataTransferJobRole: string;
    reportUrl?: string | undefined;
    creationDateTime: Date;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress | undefined;
}
export interface GetPricingPlanRequest {
}
export type BundleName = string;
export type PricingBundles = string[];
export type PricingTier = string;
export interface BundleInformation {
    bundleNames: string[];
    pricingTier?: string | undefined;
}
export type PricingMode = string;
export type UpdateReason = string;
export interface PricingPlan {
    billableEntityCount?: number | undefined;
    bundleInformation?: BundleInformation | undefined;
    effectiveDateTime: Date;
    pricingMode: string;
    updateDateTime: Date;
    updateReason: string;
}
export interface GetPricingPlanResponse {
    currentPricingPlan: PricingPlan;
    pendingPricingPlan?: PricingPlan | undefined;
}
export type SelectedPropertyList = string[];
export type MaxResults = number;
export type Order = string;
export interface OrderBy {
    order?: string | undefined;
    propertyName: string;
}
export type OrderByList = OrderBy[];
export interface PropertyFilter {
    propertyName?: string | undefined;
    operator?: string | undefined;
    value?: DataValue | undefined;
}
export type PropertyFilters = PropertyFilter[];
export interface TabularConditions {
    orderBy?: OrderBy[] | undefined;
    propertyFilters?: PropertyFilter[] | undefined;
}
export interface GetPropertyValueRequest {
    componentName?: string | undefined;
    componentPath?: string | undefined;
    componentTypeId?: string | undefined;
    entityId?: string | undefined;
    selectedProperties: string[];
    workspaceId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    propertyGroupName?: string | undefined;
    tabularConditions?: TabularConditions | undefined;
}
export interface PropertyLatestValue {
    propertyReference: EntityPropertyReference;
    propertyValue?: DataValue | undefined;
}
export type PropertyLatestValueMap = {
    [key: string]: PropertyLatestValue | undefined;
};
export type PropertyTableValue = {
    [key: string]: DataValue | undefined;
};
export type TabularPropertyValue = {
    [key: string]: DataValue | undefined;
}[];
export type TabularPropertyValues = {
    [key: string]: DataValue | undefined;
}[][];
export interface GetPropertyValueResponse {
    propertyValues?: {
        [key: string]: PropertyLatestValue | undefined;
    } | undefined;
    nextToken?: string | undefined;
    tabularPropertyValues?: {
        [key: string]: DataValue | undefined;
    }[][] | undefined;
}
export type InterpolationType = string;
export type IntervalInSeconds = number;
export interface InterpolationParameters {
    interpolationType?: string | undefined;
    intervalInSeconds?: number | undefined;
}
export type OrderByTime = string;
export interface GetPropertyValueHistoryRequest {
    workspaceId: string;
    entityId?: string | undefined;
    componentName?: string | undefined;
    componentPath?: string | undefined;
    componentTypeId?: string | undefined;
    selectedProperties: string[];
    propertyFilters?: PropertyFilter[] | undefined;
    startDateTime?: Date | undefined;
    endDateTime?: Date | undefined;
    interpolation?: InterpolationParameters | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    orderByTime?: string | undefined;
    startTime?: string | undefined;
    endTime?: string | undefined;
}
export type Values = PropertyValue[];
export interface PropertyValueHistory {
    entityPropertyReference: EntityPropertyReference;
    values?: PropertyValue[] | undefined;
}
export type PropertyValueList = PropertyValueHistory[];
export interface GetPropertyValueHistoryResponse {
    propertyValues: PropertyValueHistory[];
    nextToken?: string | undefined;
}
export interface GetSceneRequest {
    workspaceId: string;
    sceneId: string;
}
export type GeneratedSceneMetadataMap = {
    [key: string]: string | undefined;
};
export type SceneErrorCode = string;
export interface SceneError {
    code?: string | undefined;
    message?: string | undefined;
}
export interface GetSceneResponse {
    workspaceId: string;
    sceneId: string;
    contentLocation: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string | undefined;
    capabilities?: string[] | undefined;
    sceneMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    generatedSceneMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    error?: SceneError | undefined;
}
export interface GetSyncJobRequest {
    syncSource: string;
    workspaceId?: string | undefined;
}
export interface SyncJobStatus {
    state?: string | undefined;
    error?: ErrorDetails | undefined;
}
export interface GetSyncJobResponse {
    arn: string;
    workspaceId: string;
    syncSource: string;
    syncRole: string;
    status: SyncJobStatus;
    creationDateTime: Date;
    updateDateTime: Date;
}
export type IdOrArn = string;
export interface GetWorkspaceRequest {
    workspaceId: string;
}
export type LinkedService = string;
export type LinkedServices = string[];
export interface GetWorkspaceResponse {
    workspaceId: string;
    arn: string;
    description?: string | undefined;
    linkedServices?: string[] | undefined;
    s3Location?: string | undefined;
    role?: string | undefined;
    creationDateTime: Date;
    updateDateTime: Date;
}
export interface ListComponentsRequest {
    workspaceId: string;
    entityId: string;
    componentPath?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ComponentSummaries = ComponentSummary[];
export interface ListComponentsResponse {
    componentSummaries: ComponentSummary[];
    nextToken?: string | undefined;
}
export type ListComponentTypesFilter = {
    extendsFrom: string;
    namespace?: undefined;
    isAbstract?: undefined;
} | {
    extendsFrom?: undefined;
    namespace: string;
    isAbstract?: undefined;
} | {
    extendsFrom?: undefined;
    namespace?: undefined;
    isAbstract: boolean;
};
export type ListComponentTypesFilters = ListComponentTypesFilter[];
export interface ListComponentTypesRequest {
    workspaceId: string;
    filters?: ListComponentTypesFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ComponentTypeSummary {
    arn: string;
    componentTypeId: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string | undefined;
    status?: Status | undefined;
    componentTypeName?: string | undefined;
}
export type ComponentTypeSummaries = ComponentTypeSummary[];
export interface ListComponentTypesResponse {
    workspaceId: string;
    componentTypeSummaries: ComponentTypeSummary[];
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ListEntitiesFilter = {
    parentEntityId: string;
    componentTypeId?: undefined;
    externalId?: undefined;
} | {
    parentEntityId?: undefined;
    componentTypeId: string;
    externalId?: undefined;
} | {
    parentEntityId?: undefined;
    componentTypeId?: undefined;
    externalId: string;
};
export type ListEntitiesFilters = ListEntitiesFilter[];
export interface ListEntitiesRequest {
    workspaceId: string;
    filters?: ListEntitiesFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface EntitySummary {
    entityId: string;
    entityName: string;
    arn: string;
    parentEntityId?: string | undefined;
    status: Status;
    description?: string | undefined;
    hasChildEntities?: boolean | undefined;
    creationDateTime: Date;
    updateDateTime: Date;
}
export type EntitySummaries = EntitySummary[];
export interface ListEntitiesResponse {
    entitySummaries?: EntitySummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListMetadataTransferJobsFilter = {
    workspaceId: string;
    state?: undefined;
} | {
    workspaceId?: undefined;
    state: string;
};
export type ListMetadataTransferJobsFilters = ListMetadataTransferJobsFilter[];
export interface ListMetadataTransferJobsRequest {
    sourceType: string;
    destinationType: string;
    filters?: ListMetadataTransferJobsFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface MetadataTransferJobSummary {
    metadataTransferJobId: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    status: MetadataTransferJobStatus;
    progress?: MetadataTransferJobProgress | undefined;
}
export type MetadataTransferJobSummaries = MetadataTransferJobSummary[];
export interface ListMetadataTransferJobsResponse {
    metadataTransferJobSummaries: MetadataTransferJobSummary[];
    nextToken?: string | undefined;
}
export interface ListPropertiesRequest {
    workspaceId: string;
    componentName?: string | undefined;
    componentPath?: string | undefined;
    entityId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface PropertySummary {
    definition?: PropertyDefinitionResponse | undefined;
    propertyName: string;
    value?: DataValue | undefined;
    areAllPropertyValuesReturned?: boolean | undefined;
}
export type PropertySummaries = PropertySummary[];
export interface ListPropertiesResponse {
    propertySummaries: PropertySummary[];
    nextToken?: string | undefined;
}
export interface ListScenesRequest {
    workspaceId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SceneSummary {
    sceneId: string;
    contentLocation: string;
    arn: string;
    creationDateTime: Date;
    updateDateTime: Date;
    description?: string | undefined;
}
export type SceneSummaries = SceneSummary[];
export interface ListScenesResponse {
    sceneSummaries?: SceneSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSyncJobsRequest {
    workspaceId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SyncJobSummary {
    arn?: string | undefined;
    workspaceId?: string | undefined;
    syncSource?: string | undefined;
    status?: SyncJobStatus | undefined;
    creationDateTime?: Date | undefined;
    updateDateTime?: Date | undefined;
}
export type SyncJobSummaries = SyncJobSummary[];
export interface ListSyncJobsResponse {
    syncJobSummaries?: SyncJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SyncResourceState = string;
export type SyncResourceType = string;
export type SyncResourceFilter = {
    state: string;
    resourceType?: undefined;
    resourceId?: undefined;
    externalId?: undefined;
} | {
    state?: undefined;
    resourceType: string;
    resourceId?: undefined;
    externalId?: undefined;
} | {
    state?: undefined;
    resourceType?: undefined;
    resourceId: string;
    externalId?: undefined;
} | {
    state?: undefined;
    resourceType?: undefined;
    resourceId?: undefined;
    externalId: string;
};
export type SyncResourceFilters = SyncResourceFilter[];
export interface ListSyncResourcesRequest {
    workspaceId: string;
    syncSource: string;
    filters?: SyncResourceFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SyncResourceStatus {
    state?: string | undefined;
    error?: ErrorDetails | undefined;
}
export interface SyncResourceSummary {
    resourceType?: string | undefined;
    externalId?: string | undefined;
    resourceId?: string | undefined;
    status?: SyncResourceStatus | undefined;
    updateDateTime?: Date | undefined;
}
export type SyncResourceSummaries = SyncResourceSummary[];
export interface ListSyncResourcesResponse {
    syncResources?: SyncResourceSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceARN: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    nextToken?: string | undefined;
}
export interface ListWorkspacesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface WorkspaceSummary {
    workspaceId: string;
    arn: string;
    description?: string | undefined;
    linkedServices?: string[] | undefined;
    creationDateTime: Date;
    updateDateTime: Date;
}
export type WorkspaceSummaries = WorkspaceSummary[];
export interface ListWorkspacesResponse {
    workspaceSummaries?: WorkspaceSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateComponentTypeRequest {
    workspaceId: string;
    isSingleton?: boolean | undefined;
    componentTypeId: string;
    description?: string | undefined;
    propertyDefinitions?: {
        [key: string]: PropertyDefinitionRequest | undefined;
    } | undefined;
    extendsFrom?: string[] | undefined;
    functions?: {
        [key: string]: FunctionRequest | undefined;
    } | undefined;
    propertyGroups?: {
        [key: string]: PropertyGroupRequest | undefined;
    } | undefined;
    componentTypeName?: string | undefined;
    compositeComponentTypes?: {
        [key: string]: CompositeComponentTypeRequest | undefined;
    } | undefined;
}
export interface UpdateComponentTypeResponse {
    workspaceId: string;
    arn: string;
    componentTypeId: string;
    state: string;
}
export type ComponentUpdateType = string;
export interface ComponentUpdateRequest {
    updateType?: string | undefined;
    description?: string | undefined;
    componentTypeId?: string | undefined;
    propertyUpdates?: {
        [key: string]: PropertyRequest | undefined;
    } | undefined;
    propertyGroupUpdates?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    } | undefined;
}
export type ComponentUpdatesMapRequest = {
    [key: string]: ComponentUpdateRequest | undefined;
};
export interface CompositeComponentUpdateRequest {
    updateType?: string | undefined;
    description?: string | undefined;
    propertyUpdates?: {
        [key: string]: PropertyRequest | undefined;
    } | undefined;
    propertyGroupUpdates?: {
        [key: string]: ComponentPropertyGroupRequest | undefined;
    } | undefined;
}
export type CompositeComponentUpdatesMapRequest = {
    [key: string]: CompositeComponentUpdateRequest | undefined;
};
export type ParentEntityUpdateType = string;
export interface ParentEntityUpdateRequest {
    updateType: string;
    parentEntityId?: string | undefined;
}
export interface UpdateEntityRequest {
    workspaceId: string;
    entityId: string;
    entityName?: string | undefined;
    description?: string | undefined;
    componentUpdates?: {
        [key: string]: ComponentUpdateRequest | undefined;
    } | undefined;
    compositeComponentUpdates?: {
        [key: string]: CompositeComponentUpdateRequest | undefined;
    } | undefined;
    parentEntityUpdate?: ParentEntityUpdateRequest | undefined;
}
export interface UpdateEntityResponse {
    updateDateTime: Date;
    state: string;
}
export interface UpdatePricingPlanRequest {
    pricingMode: string;
    bundleNames?: string[] | undefined;
}
export interface UpdatePricingPlanResponse {
    currentPricingPlan: PricingPlan;
    pendingPricingPlan?: PricingPlan | undefined;
}
export interface UpdateSceneRequest {
    workspaceId: string;
    sceneId: string;
    contentLocation?: string | undefined;
    description?: string | undefined;
    capabilities?: string[] | undefined;
    sceneMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateSceneResponse {
    updateDateTime: Date;
}
export interface UpdateWorkspaceRequest {
    workspaceId: string;
    description?: string | undefined;
    role?: string | undefined;
    s3Location?: string | undefined;
}
export interface UpdateWorkspaceResponse {
    updateDateTime: Date;
}
export type ExceptionMessage = string;
export type BatchPutPropertyValuesError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets values for multiple time series properties.
 */
export declare const batchPutPropertyValues: API.OperationMethod<BatchPutPropertyValuesRequest & RegionInput, BatchPutPropertyValuesResponse, BatchPutPropertyValuesError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataTransferJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the metadata transfer job.
 */
export declare const cancelMetadataTransferJob: API.OperationMethod<CancelMetadataTransferJobRequest & RegionInput, CancelMetadataTransferJobResponse, CancelMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type CreateComponentTypeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a component type.
 */
export declare const createComponentType: API.OperationMethod<CreateComponentTypeRequest & RegionInput, CreateComponentTypeResponse, CreateComponentTypeError, Credentials | HttpClient.HttpClient>;
export type CreateEntityError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an entity.
 */
export declare const createEntity: API.OperationMethod<CreateEntityRequest & RegionInput, CreateEntityResponse, CreateEntityError, Credentials | HttpClient.HttpClient>;
export type CreateMetadataTransferJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new metadata transfer job.
 */
export declare const createMetadataTransferJob: API.OperationMethod<CreateMetadataTransferJobRequest & RegionInput, CreateMetadataTransferJobResponse, CreateMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type CreateSceneError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a scene.
 */
export declare const createScene: API.OperationMethod<CreateSceneRequest & RegionInput, CreateSceneResponse, CreateSceneError, Credentials | HttpClient.HttpClient>;
export type CreateSyncJobError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action creates a SyncJob.
 */
export declare const createSyncJob: API.OperationMethod<CreateSyncJobRequest & RegionInput, CreateSyncJobResponse, CreateSyncJobError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a workplace.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest & RegionInput, CreateWorkspaceResponse, CreateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a component type.
 */
export declare const deleteComponentType: API.OperationMethod<DeleteComponentTypeRequest & RegionInput, DeleteComponentTypeResponse, DeleteComponentTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteEntityError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an entity.
 */
export declare const deleteEntity: API.OperationMethod<DeleteEntityRequest & RegionInput, DeleteEntityResponse, DeleteEntityError, Credentials | HttpClient.HttpClient>;
export type DeleteSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a scene.
 */
export declare const deleteScene: API.OperationMethod<DeleteSceneRequest & RegionInput, DeleteSceneResponse, DeleteSceneError, Credentials | HttpClient.HttpClient>;
export type DeleteSyncJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the SyncJob.
 */
export declare const deleteSyncJob: API.OperationMethod<DeleteSyncJobRequest & RegionInput, DeleteSyncJobResponse, DeleteSyncJobError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a workspace.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest & RegionInput, DeleteWorkspaceResponse, DeleteWorkspaceError, Credentials | HttpClient.HttpClient>;
export type ExecuteQueryError = AccessDeniedException | InternalServerException | QueryTimeoutException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Run queries to access information from your knowledge graph of entities within
 * individual workspaces.
 *
 * The ExecuteQuery action only works with Amazon Web Services Java SDK2.
 * ExecuteQuery will not work with any Amazon Web Services Java SDK version < 2.x.
 */
export declare const executeQuery: API.PaginatedOperationMethod<ExecuteQueryRequest & RegionInput, ExecuteQueryResponse, ExecuteQueryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a component type.
 */
export declare const getComponentType: API.OperationMethod<GetComponentTypeRequest & RegionInput, GetComponentTypeResponse, GetComponentTypeError, Credentials | HttpClient.HttpClient>;
export type GetEntityError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an entity.
 */
export declare const getEntity: API.OperationMethod<GetEntityRequest & RegionInput, GetEntityResponse, GetEntityError, Credentials | HttpClient.HttpClient>;
export type GetMetadataTransferJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a nmetadata transfer job.
 */
export declare const getMetadataTransferJob: API.OperationMethod<GetMetadataTransferJobRequest & RegionInput, GetMetadataTransferJobResponse, GetMetadataTransferJobError, Credentials | HttpClient.HttpClient>;
export type GetPricingPlanError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the pricing plan.
 */
export declare const getPricingPlan: API.OperationMethod<GetPricingPlanRequest & RegionInput, GetPricingPlanResponse, GetPricingPlanError, Credentials | HttpClient.HttpClient>;
export type GetPropertyValueError = AccessDeniedException | ConnectorFailureException | ConnectorTimeoutException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the property values for a component, component type, entity, or workspace.
 *
 * You must specify a value for either `componentName`,
 * `componentTypeId`, `entityId`, or `workspaceId`.
 */
export declare const getPropertyValue: API.PaginatedOperationMethod<GetPropertyValueRequest & RegionInput, GetPropertyValueResponse, GetPropertyValueError, Credentials | HttpClient.HttpClient, unknown>;
export type GetPropertyValueHistoryError = AccessDeniedException | ConnectorFailureException | ConnectorTimeoutException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the history of a time series property value for a component,
 * component type, entity, or workspace.
 *
 * You must specify a value for `workspaceId`. For entity-specific queries,
 * specify values for `componentName` and `entityId`. For cross-entity
 * quries, specify a value for `componentTypeId`.
 */
export declare const getPropertyValueHistory: API.PaginatedOperationMethod<GetPropertyValueHistoryRequest & RegionInput, GetPropertyValueHistoryResponse, GetPropertyValueHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a scene.
 */
export declare const getScene: API.OperationMethod<GetSceneRequest & RegionInput, GetSceneResponse, GetSceneError, Credentials | HttpClient.HttpClient>;
export type GetSyncJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the SyncJob.
 */
export declare const getSyncJob: API.OperationMethod<GetSyncJobRequest & RegionInput, GetSyncJobResponse, GetSyncJobError, Credentials | HttpClient.HttpClient>;
export type GetWorkspaceError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a workspace.
 */
export declare const getWorkspace: API.OperationMethod<GetWorkspaceRequest & RegionInput, GetWorkspaceResponse, GetWorkspaceError, Credentials | HttpClient.HttpClient>;
export type ListComponentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API lists the components of an entity.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest & RegionInput, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListComponentTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all component types in a workspace.
 */
export declare const listComponentTypes: API.PaginatedOperationMethod<ListComponentTypesRequest & RegionInput, ListComponentTypesResponse, ListComponentTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntitiesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all entities in a workspace.
 */
export declare const listEntities: API.PaginatedOperationMethod<ListEntitiesRequest & RegionInput, ListEntitiesResponse, ListEntitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMetadataTransferJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the metadata transfer jobs.
 */
export declare const listMetadataTransferJobs: API.PaginatedOperationMethod<ListMetadataTransferJobsRequest & RegionInput, ListMetadataTransferJobsResponse, ListMetadataTransferJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPropertiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API lists the properties of a component.
 */
export declare const listProperties: API.PaginatedOperationMethod<ListPropertiesRequest & RegionInput, ListPropertiesResponse, ListPropertiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListScenesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all scenes in a workspace.
 */
export declare const listScenes: API.PaginatedOperationMethod<ListScenesRequest & RegionInput, ListScenesResponse, ListScenesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSyncJobsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all SyncJobs.
 */
export declare const listSyncJobs: API.PaginatedOperationMethod<ListSyncJobsRequest & RegionInput, ListSyncJobsResponse, ListSyncJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSyncResourcesError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the sync resources.
 */
export declare const listSyncResources: API.PaginatedOperationMethod<ListSyncResourcesRequest & RegionInput, ListSyncResourcesResponse, ListSyncResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all tags associated with a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkspacesError = InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about workspaces in the current account.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest & RegionInput, ListWorkspacesResponse, ListWorkspacesError, Credentials | HttpClient.HttpClient, unknown>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentTypeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information in a component type.
 */
export declare const updateComponentType: API.OperationMethod<UpdateComponentTypeRequest & RegionInput, UpdateComponentTypeResponse, UpdateComponentTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateEntityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an entity.
 */
export declare const updateEntity: API.OperationMethod<UpdateEntityRequest & RegionInput, UpdateEntityResponse, UpdateEntityError, Credentials | HttpClient.HttpClient>;
export type UpdatePricingPlanError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the pricing plan.
 */
export declare const updatePricingPlan: API.OperationMethod<UpdatePricingPlanRequest & RegionInput, UpdatePricingPlanResponse, UpdatePricingPlanError, Credentials | HttpClient.HttpClient>;
export type UpdateSceneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a scene.
 */
export declare const updateScene: API.OperationMethod<UpdateSceneRequest & RegionInput, UpdateSceneResponse, UpdateSceneError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a workspace.
 */
export declare const updateWorkspace: API.OperationMethod<UpdateWorkspaceRequest & RegionInput, UpdateWorkspaceResponse, UpdateWorkspaceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iottwinmaker.d.ts.map