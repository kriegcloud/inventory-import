import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
    readonly error: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InvalidGatewayRequestException_base: S.TaggedErrorClass<"InvalidGatewayRequestException", {
    readonly message: any;
    readonly error: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGatewayRequestException extends /*@__PURE__*/ InvalidGatewayRequestException_base {
}
declare const ServiceUnavailableError_base: S.TaggedErrorClass<"ServiceUnavailableError", {
    readonly message: any;
    readonly error: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableError extends /*@__PURE__*/ ServiceUnavailableError_base {
}
export type ActivationKey = string;
export type GatewayName = string;
export type GatewayTimezone = string;
export type RegionId = string;
export type GatewayType = string;
export type TapeDriveType = string;
export type MediumChangerType = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type Tags = Tag[];
export interface ActivateGatewayInput {
    ActivationKey: string;
    GatewayName: string;
    GatewayTimezone: string;
    GatewayRegion: string;
    GatewayType?: string | undefined;
    TapeDriveType?: string | undefined;
    MediumChangerType?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type GatewayARN = string;
export interface ActivateGatewayOutput {
    GatewayARN?: string | undefined;
}
export type DiskId = string;
export type DiskIds = string[];
export interface AddCacheInput {
    GatewayARN: string;
    DiskIds: string[];
}
export interface AddCacheOutput {
    GatewayARN?: string | undefined;
}
export type ResourceARN = string;
export interface AddTagsToResourceInput {
    ResourceARN: string;
    Tags: Tag[];
}
export interface AddTagsToResourceOutput {
    ResourceARN?: string | undefined;
}
export interface AddUploadBufferInput {
    GatewayARN: string;
    DiskIds: string[];
}
export interface AddUploadBufferOutput {
    GatewayARN?: string | undefined;
}
export interface AddWorkingStorageInput {
    GatewayARN: string;
    DiskIds: string[];
}
export interface AddWorkingStorageOutput {
    GatewayARN?: string | undefined;
}
export type TapeARN = string;
export type PoolId = string;
export interface AssignTapePoolInput {
    TapeARN: string;
    PoolId: string;
    BypassGovernanceRetention?: boolean | undefined;
}
export interface AssignTapePoolOutput {
    TapeARN?: string | undefined;
}
export type DomainUserName = string;
export type DomainUserPassword = string | redacted.Redacted<string>;
export type ClientToken = string;
export type FileSystemLocationARN = string;
export type AuditDestinationARN = string;
export type CacheStaleTimeoutInSeconds = number;
export interface CacheAttributes {
    CacheStaleTimeoutInSeconds?: number | undefined;
}
export type IPV4Address = string;
export type IpAddressList = string[];
export interface EndpointNetworkConfiguration {
    IpAddresses?: string[] | undefined;
}
export interface AssociateFileSystemInput {
    UserName: string;
    Password: string | redacted.Redacted<string>;
    ClientToken: string;
    GatewayARN: string;
    LocationARN: string;
    Tags?: Tag[] | undefined;
    AuditDestinationARN?: string | undefined;
    CacheAttributes?: CacheAttributes | undefined;
    EndpointNetworkConfiguration?: EndpointNetworkConfiguration | undefined;
}
export type FileSystemAssociationARN = string;
export interface AssociateFileSystemOutput {
    FileSystemAssociationARN?: string | undefined;
}
export type TargetName = string;
export type VolumeARN = string;
export type NetworkInterfaceId = string;
export interface AttachVolumeInput {
    GatewayARN: string;
    TargetName?: string | undefined;
    VolumeARN: string;
    NetworkInterfaceId: string;
    DiskId?: string | undefined;
}
export type TargetARN = string;
export interface AttachVolumeOutput {
    VolumeARN?: string | undefined;
    TargetARN?: string | undefined;
}
export interface CancelArchivalInput {
    GatewayARN: string;
    TapeARN: string;
}
export interface CancelArchivalOutput {
    TapeARN?: string | undefined;
}
export type CacheReportARN = string;
export interface CancelCacheReportInput {
    CacheReportARN: string;
}
export interface CancelCacheReportOutput {
    CacheReportARN?: string | undefined;
}
export interface CancelRetrievalInput {
    GatewayARN: string;
    TapeARN: string;
}
export interface CancelRetrievalOutput {
    TapeARN?: string | undefined;
}
export type SnapshotId = string;
export type KMSKey = string;
export interface CreateCachediSCSIVolumeInput {
    GatewayARN: string;
    VolumeSizeInBytes: number;
    SnapshotId?: string | undefined;
    TargetName: string;
    SourceVolumeARN?: string | undefined;
    NetworkInterfaceId: string;
    ClientToken: string;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateCachediSCSIVolumeOutput {
    VolumeARN?: string | undefined;
    TargetARN?: string | undefined;
}
export type PermissionMode = string;
export type PermissionId = number;
export interface NFSFileShareDefaults {
    FileMode?: string | undefined;
    DirectoryMode?: string | undefined;
    GroupId?: number | undefined;
    OwnerId?: number | undefined;
}
export type EncryptionType = "SseS3" | "SseKms" | "DsseKms" | (string & {});
export type Role = string;
export type LocationARN = string;
export type StorageClass = string;
export type ObjectACL = "private" | "public-read" | "public-read-write" | "authenticated-read" | "bucket-owner-read" | "bucket-owner-full-control" | "aws-exec-read" | (string & {});
export type Ipv4OrIpv6AddressCIDR = string;
export type FileShareClientList = string[];
export type Squash = string;
export type FileShareName = string;
export type NotificationPolicy = string;
export type DNSHostName = string;
export interface CreateNFSFileShareInput {
    ClientToken: string;
    NFSFileShareDefaults?: NFSFileShareDefaults | undefined;
    GatewayARN: string;
    EncryptionType?: EncryptionType | undefined;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    Role: string;
    LocationARN: string;
    DefaultStorageClass?: string | undefined;
    ObjectACL?: ObjectACL | undefined;
    ClientList?: string[] | undefined;
    Squash?: string | undefined;
    ReadOnly?: boolean | undefined;
    GuessMIMETypeEnabled?: boolean | undefined;
    RequesterPays?: boolean | undefined;
    Tags?: Tag[] | undefined;
    FileShareName?: string | undefined;
    CacheAttributes?: CacheAttributes | undefined;
    NotificationPolicy?: string | undefined;
    VPCEndpointDNSName?: string | undefined;
    BucketRegion?: string | undefined;
    AuditDestinationARN?: string | undefined;
}
export type FileShareARN = string;
export interface CreateNFSFileShareOutput {
    FileShareARN?: string | undefined;
}
export type UserListUser = string;
export type UserList = string[];
export type Authentication = string;
export type CaseSensitivity = "ClientSpecified" | "CaseSensitive" | (string & {});
export interface CreateSMBFileShareInput {
    ClientToken: string;
    GatewayARN: string;
    EncryptionType?: EncryptionType | undefined;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    Role: string;
    LocationARN: string;
    DefaultStorageClass?: string | undefined;
    ObjectACL?: ObjectACL | undefined;
    ReadOnly?: boolean | undefined;
    GuessMIMETypeEnabled?: boolean | undefined;
    RequesterPays?: boolean | undefined;
    SMBACLEnabled?: boolean | undefined;
    AccessBasedEnumeration?: boolean | undefined;
    AdminUserList?: string[] | undefined;
    ValidUserList?: string[] | undefined;
    InvalidUserList?: string[] | undefined;
    AuditDestinationARN?: string | undefined;
    Authentication?: string | undefined;
    CaseSensitivity?: CaseSensitivity | undefined;
    Tags?: Tag[] | undefined;
    FileShareName?: string | undefined;
    CacheAttributes?: CacheAttributes | undefined;
    NotificationPolicy?: string | undefined;
    VPCEndpointDNSName?: string | undefined;
    BucketRegion?: string | undefined;
    OplocksEnabled?: boolean | undefined;
}
export interface CreateSMBFileShareOutput {
    FileShareARN?: string | undefined;
}
export type SnapshotDescription = string;
export interface CreateSnapshotInput {
    VolumeARN: string;
    SnapshotDescription: string;
    Tags?: Tag[] | undefined;
}
export interface CreateSnapshotOutput {
    VolumeARN?: string | undefined;
    SnapshotId?: string | undefined;
}
export interface CreateSnapshotFromVolumeRecoveryPointInput {
    VolumeARN: string;
    SnapshotDescription: string;
    Tags?: Tag[] | undefined;
}
export interface CreateSnapshotFromVolumeRecoveryPointOutput {
    SnapshotId?: string | undefined;
    VolumeARN?: string | undefined;
    VolumeRecoveryPointTime?: string | undefined;
}
export interface CreateStorediSCSIVolumeInput {
    GatewayARN: string;
    DiskId: string;
    SnapshotId?: string | undefined;
    PreserveExistingData: boolean;
    TargetName: string;
    NetworkInterfaceId: string;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateStorediSCSIVolumeOutput {
    VolumeARN?: string | undefined;
    VolumeSizeInBytes?: number | undefined;
    TargetARN?: string | undefined;
}
export type PoolName = string;
export type TapeStorageClass = "DEEP_ARCHIVE" | "GLACIER" | (string & {});
export type RetentionLockType = "COMPLIANCE" | "GOVERNANCE" | "NONE" | (string & {});
export type RetentionLockTimeInDays = number;
export interface CreateTapePoolInput {
    PoolName: string;
    StorageClass: TapeStorageClass;
    RetentionLockType?: RetentionLockType | undefined;
    RetentionLockTimeInDays?: number | undefined;
    Tags?: Tag[] | undefined;
}
export type PoolARN = string;
export interface CreateTapePoolOutput {
    PoolARN?: string | undefined;
}
export type TapeSize = number;
export type NumTapesToCreate = number;
export type TapeBarcodePrefix = string;
export interface CreateTapesInput {
    GatewayARN: string;
    TapeSizeInBytes: number;
    ClientToken: string;
    NumTapesToCreate: number;
    TapeBarcodePrefix: string;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    PoolId?: string | undefined;
    Worm?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export type TapeARNs = string[];
export interface CreateTapesOutput {
    TapeARNs?: string[] | undefined;
}
export type TapeBarcode = string;
export interface CreateTapeWithBarcodeInput {
    GatewayARN: string;
    TapeSizeInBytes: number;
    TapeBarcode: string;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    PoolId?: string | undefined;
    Worm?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateTapeWithBarcodeOutput {
    TapeARN?: string | undefined;
}
export interface DeleteAutomaticTapeCreationPolicyInput {
    GatewayARN: string;
}
export interface DeleteAutomaticTapeCreationPolicyOutput {
    GatewayARN?: string | undefined;
}
export type BandwidthType = string;
export interface DeleteBandwidthRateLimitInput {
    GatewayARN: string;
    BandwidthType: string;
}
export interface DeleteBandwidthRateLimitOutput {
    GatewayARN?: string | undefined;
}
export interface DeleteCacheReportInput {
    CacheReportARN: string;
}
export interface DeleteCacheReportOutput {
    CacheReportARN?: string | undefined;
}
export type IqnName = string;
export interface DeleteChapCredentialsInput {
    TargetARN: string;
    InitiatorName: string;
}
export interface DeleteChapCredentialsOutput {
    TargetARN?: string | undefined;
    InitiatorName?: string | undefined;
}
export interface DeleteFileShareInput {
    FileShareARN: string;
    ForceDelete?: boolean | undefined;
}
export interface DeleteFileShareOutput {
    FileShareARN?: string | undefined;
}
export interface DeleteGatewayInput {
    GatewayARN: string;
}
export interface DeleteGatewayOutput {
    GatewayARN?: string | undefined;
}
export interface DeleteSnapshotScheduleInput {
    VolumeARN: string;
}
export interface DeleteSnapshotScheduleOutput {
    VolumeARN?: string | undefined;
}
export interface DeleteTapeInput {
    GatewayARN: string;
    TapeARN: string;
    BypassGovernanceRetention?: boolean | undefined;
}
export interface DeleteTapeOutput {
    TapeARN?: string | undefined;
}
export interface DeleteTapeArchiveInput {
    TapeARN: string;
    BypassGovernanceRetention?: boolean | undefined;
}
export interface DeleteTapeArchiveOutput {
    TapeARN?: string | undefined;
}
export interface DeleteTapePoolInput {
    PoolARN: string;
}
export interface DeleteTapePoolOutput {
    PoolARN?: string | undefined;
}
export interface DeleteVolumeInput {
    VolumeARN: string;
}
export interface DeleteVolumeOutput {
    VolumeARN?: string | undefined;
}
export interface DescribeAvailabilityMonitorTestInput {
    GatewayARN: string;
}
export type AvailabilityMonitorTestStatus = "COMPLETE" | "FAILED" | "PENDING" | (string & {});
export interface DescribeAvailabilityMonitorTestOutput {
    GatewayARN?: string | undefined;
    Status?: AvailabilityMonitorTestStatus | undefined;
    StartTime?: Date | undefined;
}
export interface DescribeBandwidthRateLimitInput {
    GatewayARN: string;
}
export type BandwidthUploadRateLimit = number;
export type BandwidthDownloadRateLimit = number;
export interface DescribeBandwidthRateLimitOutput {
    GatewayARN?: string | undefined;
    AverageUploadRateLimitInBitsPerSec?: number | undefined;
    AverageDownloadRateLimitInBitsPerSec?: number | undefined;
}
export interface DescribeBandwidthRateLimitScheduleInput {
    GatewayARN: string;
}
export type HourOfDay = number;
export type MinuteOfHour = number;
export type DayOfWeek = number;
export type DaysOfWeek = number[];
export interface BandwidthRateLimitInterval {
    StartHourOfDay: number;
    StartMinuteOfHour: number;
    EndHourOfDay: number;
    EndMinuteOfHour: number;
    DaysOfWeek: number[];
    AverageUploadRateLimitInBitsPerSec?: number | undefined;
    AverageDownloadRateLimitInBitsPerSec?: number | undefined;
}
export type BandwidthRateLimitIntervals = BandwidthRateLimitInterval[];
export interface DescribeBandwidthRateLimitScheduleOutput {
    GatewayARN?: string | undefined;
    BandwidthRateLimitIntervals?: BandwidthRateLimitInterval[] | undefined;
}
export interface DescribeCacheInput {
    GatewayARN: string;
}
export interface DescribeCacheOutput {
    GatewayARN?: string | undefined;
    DiskIds?: string[] | undefined;
    CacheAllocatedInBytes?: number | undefined;
    CacheUsedPercentage?: number | undefined;
    CacheDirtyPercentage?: number | undefined;
    CacheHitPercentage?: number | undefined;
    CacheMissPercentage?: number | undefined;
}
export type VolumeARNs = string[];
export interface DescribeCachediSCSIVolumesInput {
    VolumeARNs: string[];
}
export type VolumeId = string;
export type VolumeType = string;
export type VolumeStatus = string;
export type VolumeAttachmentStatus = string;
export type DoubleObject = number;
export type PositiveIntObject = number;
export interface VolumeiSCSIAttributes {
    TargetARN?: string | undefined;
    NetworkInterfaceId?: string | undefined;
    NetworkInterfacePort?: number | undefined;
    LunNumber?: number | undefined;
    ChapEnabled?: boolean | undefined;
}
export type CreatedDate = Date;
export type VolumeUsedInBytes = number;
export interface CachediSCSIVolume {
    VolumeARN?: string | undefined;
    VolumeId?: string | undefined;
    VolumeType?: string | undefined;
    VolumeStatus?: string | undefined;
    VolumeAttachmentStatus?: string | undefined;
    VolumeSizeInBytes?: number | undefined;
    VolumeProgress?: number | undefined;
    SourceSnapshotId?: string | undefined;
    VolumeiSCSIAttributes?: VolumeiSCSIAttributes | undefined;
    CreatedDate?: Date | undefined;
    VolumeUsedInBytes?: number | undefined;
    KMSKey?: string | undefined;
    TargetName?: string | undefined;
}
export type CachediSCSIVolumes = CachediSCSIVolume[];
export interface DescribeCachediSCSIVolumesOutput {
    CachediSCSIVolumes?: CachediSCSIVolume[] | undefined;
}
export interface DescribeCacheReportInput {
    CacheReportARN: string;
}
export type CacheReportStatus = "IN_PROGRESS" | "COMPLETED" | "CANCELED" | "FAILED" | "ERROR" | (string & {});
export type ReportCompletionPercent = number;
export type CacheReportFilterName = "UploadState" | "UploadFailureReason" | (string & {});
export type CacheReportFilterValue = string;
export type CacheReportFilterValues = string[];
export interface CacheReportFilter {
    Name: CacheReportFilterName;
    Values: string[];
}
export type CacheReportFilterList = CacheReportFilter[];
export type CacheReportName = string;
export interface CacheReportInfo {
    CacheReportARN?: string | undefined;
    CacheReportStatus?: CacheReportStatus | undefined;
    ReportCompletionPercent?: number | undefined;
    EndTime?: Date | undefined;
    Role?: string | undefined;
    FileShareARN?: string | undefined;
    LocationARN?: string | undefined;
    StartTime?: Date | undefined;
    InclusionFilters?: CacheReportFilter[] | undefined;
    ExclusionFilters?: CacheReportFilter[] | undefined;
    ReportName?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface DescribeCacheReportOutput {
    CacheReportInfo?: CacheReportInfo | undefined;
}
export interface DescribeChapCredentialsInput {
    TargetARN: string;
}
export type ChapSecret = string | redacted.Redacted<string>;
export interface ChapInfo {
    TargetARN?: string | undefined;
    SecretToAuthenticateInitiator?: string | redacted.Redacted<string> | undefined;
    InitiatorName?: string | undefined;
    SecretToAuthenticateTarget?: string | redacted.Redacted<string> | undefined;
}
export type ChapCredentials = ChapInfo[];
export interface DescribeChapCredentialsOutput {
    ChapCredentials?: ChapInfo[] | undefined;
}
export type FileSystemAssociationARNList = string[];
export interface DescribeFileSystemAssociationsInput {
    FileSystemAssociationARNList: string[];
}
export type FileSystemAssociationStatus = string;
export type FileSystemAssociationSyncErrorCode = string;
export interface FileSystemAssociationStatusDetail {
    ErrorCode?: string | undefined;
}
export type FileSystemAssociationStatusDetails = FileSystemAssociationStatusDetail[];
export interface FileSystemAssociationInfo {
    FileSystemAssociationARN?: string | undefined;
    LocationARN?: string | undefined;
    FileSystemAssociationStatus?: string | undefined;
    AuditDestinationARN?: string | undefined;
    GatewayARN?: string | undefined;
    Tags?: Tag[] | undefined;
    CacheAttributes?: CacheAttributes | undefined;
    EndpointNetworkConfiguration?: EndpointNetworkConfiguration | undefined;
    FileSystemAssociationStatusDetails?: FileSystemAssociationStatusDetail[] | undefined;
}
export type FileSystemAssociationInfoList = FileSystemAssociationInfo[];
export interface DescribeFileSystemAssociationsOutput {
    FileSystemAssociationInfoList?: FileSystemAssociationInfo[] | undefined;
}
export interface DescribeGatewayInformationInput {
    GatewayARN: string;
}
export type GatewayId = string;
export type GatewayState = string;
export interface NetworkInterface {
    Ipv4Address?: string | undefined;
    MacAddress?: string | undefined;
    Ipv6Address?: string | undefined;
}
export type GatewayNetworkInterfaces = NetworkInterface[];
export type NextUpdateAvailabilityDate = string;
export type LastSoftwareUpdate = string;
export type Ec2InstanceId = string;
export type Ec2InstanceRegion = string;
export type CloudWatchLogGroupARN = string;
export type HostEnvironment = "VMWARE" | "HYPER-V" | "EC2" | "KVM" | "OTHER" | "SNOWBALL" | (string & {});
export type EndpointType = string;
export type SoftwareUpdatesEndDate = string;
export type DeprecationDate = string;
export type GatewayCapacity = "Small" | "Medium" | "Large" | (string & {});
export type SupportedGatewayCapacities = GatewayCapacity[];
export type HostEnvironmentId = string;
export type SoftwareVersion = string;
export interface DescribeGatewayInformationOutput {
    GatewayARN?: string | undefined;
    GatewayId?: string | undefined;
    GatewayName?: string | undefined;
    GatewayTimezone?: string | undefined;
    GatewayState?: string | undefined;
    GatewayNetworkInterfaces?: NetworkInterface[] | undefined;
    GatewayType?: string | undefined;
    NextUpdateAvailabilityDate?: string | undefined;
    LastSoftwareUpdate?: string | undefined;
    Ec2InstanceId?: string | undefined;
    Ec2InstanceRegion?: string | undefined;
    Tags?: Tag[] | undefined;
    VPCEndpoint?: string | undefined;
    CloudWatchLogGroupARN?: string | undefined;
    HostEnvironment?: HostEnvironment | undefined;
    EndpointType?: string | undefined;
    SoftwareUpdatesEndDate?: string | undefined;
    DeprecationDate?: string | undefined;
    GatewayCapacity?: GatewayCapacity | undefined;
    SupportedGatewayCapacities?: GatewayCapacity[] | undefined;
    HostEnvironmentId?: string | undefined;
    SoftwareVersion?: string | undefined;
}
export interface DescribeMaintenanceStartTimeInput {
    GatewayARN: string;
}
export type DayOfMonth = number;
export type AutomaticUpdatePolicy = "ALL_VERSIONS" | "EMERGENCY_VERSIONS_ONLY" | (string & {});
export interface SoftwareUpdatePreferences {
    AutomaticUpdatePolicy?: AutomaticUpdatePolicy | undefined;
}
export interface DescribeMaintenanceStartTimeOutput {
    GatewayARN?: string | undefined;
    HourOfDay?: number | undefined;
    MinuteOfHour?: number | undefined;
    DayOfWeek?: number | undefined;
    DayOfMonth?: number | undefined;
    Timezone?: string | undefined;
    SoftwareUpdatePreferences?: SoftwareUpdatePreferences | undefined;
}
export type FileShareARNList = string[];
export interface DescribeNFSFileSharesInput {
    FileShareARNList: string[];
}
export type FileShareId = string;
export type FileShareStatus = string;
export type Path = string;
export interface NFSFileShareInfo {
    NFSFileShareDefaults?: NFSFileShareDefaults | undefined;
    FileShareARN?: string | undefined;
    FileShareId?: string | undefined;
    FileShareStatus?: string | undefined;
    GatewayARN?: string | undefined;
    EncryptionType?: EncryptionType | undefined;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    Path?: string | undefined;
    Role?: string | undefined;
    LocationARN?: string | undefined;
    DefaultStorageClass?: string | undefined;
    ObjectACL?: ObjectACL | undefined;
    ClientList?: string[] | undefined;
    Squash?: string | undefined;
    ReadOnly?: boolean | undefined;
    GuessMIMETypeEnabled?: boolean | undefined;
    RequesterPays?: boolean | undefined;
    Tags?: Tag[] | undefined;
    FileShareName?: string | undefined;
    CacheAttributes?: CacheAttributes | undefined;
    NotificationPolicy?: string | undefined;
    VPCEndpointDNSName?: string | undefined;
    BucketRegion?: string | undefined;
    AuditDestinationARN?: string | undefined;
}
export type NFSFileShareInfoList = NFSFileShareInfo[];
export interface DescribeNFSFileSharesOutput {
    NFSFileShareInfoList?: NFSFileShareInfo[] | undefined;
}
export interface DescribeSMBFileSharesInput {
    FileShareARNList: string[];
}
export interface SMBFileShareInfo {
    FileShareARN?: string | undefined;
    FileShareId?: string | undefined;
    FileShareStatus?: string | undefined;
    GatewayARN?: string | undefined;
    EncryptionType?: EncryptionType | undefined;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    Path?: string | undefined;
    Role?: string | undefined;
    LocationARN?: string | undefined;
    DefaultStorageClass?: string | undefined;
    ObjectACL?: ObjectACL | undefined;
    ReadOnly?: boolean | undefined;
    GuessMIMETypeEnabled?: boolean | undefined;
    RequesterPays?: boolean | undefined;
    SMBACLEnabled?: boolean | undefined;
    AccessBasedEnumeration?: boolean | undefined;
    AdminUserList?: string[] | undefined;
    ValidUserList?: string[] | undefined;
    InvalidUserList?: string[] | undefined;
    AuditDestinationARN?: string | undefined;
    Authentication?: string | undefined;
    CaseSensitivity?: CaseSensitivity | undefined;
    Tags?: Tag[] | undefined;
    FileShareName?: string | undefined;
    CacheAttributes?: CacheAttributes | undefined;
    NotificationPolicy?: string | undefined;
    VPCEndpointDNSName?: string | undefined;
    BucketRegion?: string | undefined;
    OplocksEnabled?: boolean | undefined;
}
export type SMBFileShareInfoList = SMBFileShareInfo[];
export interface DescribeSMBFileSharesOutput {
    SMBFileShareInfoList?: SMBFileShareInfo[] | undefined;
}
export interface DescribeSMBSettingsInput {
    GatewayARN: string;
}
export type DomainName = string;
export type ActiveDirectoryStatus = "ACCESS_DENIED" | "DETACHED" | "JOINED" | "JOINING" | "NETWORK_ERROR" | "TIMEOUT" | "UNKNOWN_ERROR" | "INSUFFICIENT_PERMISSIONS" | (string & {});
export type SMBSecurityStrategy = "ClientSpecified" | "MandatorySigning" | "MandatoryEncryption" | "MandatoryEncryptionNoAes128" | (string & {});
export interface SMBLocalGroups {
    GatewayAdmins?: string[] | undefined;
}
export interface DescribeSMBSettingsOutput {
    GatewayARN?: string | undefined;
    DomainName?: string | undefined;
    ActiveDirectoryStatus?: ActiveDirectoryStatus | undefined;
    SMBGuestPasswordSet?: boolean | undefined;
    SMBSecurityStrategy?: SMBSecurityStrategy | undefined;
    FileSharesVisible?: boolean | undefined;
    SMBLocalGroups?: SMBLocalGroups | undefined;
}
export interface DescribeSnapshotScheduleInput {
    VolumeARN: string;
}
export type RecurrenceInHours = number;
export type Description = string;
export interface DescribeSnapshotScheduleOutput {
    VolumeARN?: string | undefined;
    StartAt?: number | undefined;
    RecurrenceInHours?: number | undefined;
    Description?: string | undefined;
    Timezone?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface DescribeStorediSCSIVolumesInput {
    VolumeARNs: string[];
}
export interface StorediSCSIVolume {
    VolumeARN?: string | undefined;
    VolumeId?: string | undefined;
    VolumeType?: string | undefined;
    VolumeStatus?: string | undefined;
    VolumeAttachmentStatus?: string | undefined;
    VolumeSizeInBytes?: number | undefined;
    VolumeProgress?: number | undefined;
    VolumeDiskId?: string | undefined;
    SourceSnapshotId?: string | undefined;
    PreservedExistingData?: boolean | undefined;
    VolumeiSCSIAttributes?: VolumeiSCSIAttributes | undefined;
    CreatedDate?: Date | undefined;
    VolumeUsedInBytes?: number | undefined;
    KMSKey?: string | undefined;
    TargetName?: string | undefined;
}
export type StorediSCSIVolumes = StorediSCSIVolume[];
export interface DescribeStorediSCSIVolumesOutput {
    StorediSCSIVolumes?: StorediSCSIVolume[] | undefined;
}
export type Marker = string;
export interface DescribeTapeArchivesInput {
    TapeARNs?: string[] | undefined;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export type TapeArchiveStatus = string;
export type TapeUsage = number;
export interface TapeArchive {
    TapeARN?: string | undefined;
    TapeBarcode?: string | undefined;
    TapeCreatedDate?: Date | undefined;
    TapeSizeInBytes?: number | undefined;
    CompletionTime?: Date | undefined;
    RetrievedTo?: string | undefined;
    TapeStatus?: string | undefined;
    TapeUsedInBytes?: number | undefined;
    KMSKey?: string | undefined;
    PoolId?: string | undefined;
    Worm?: boolean | undefined;
    RetentionStartDate?: Date | undefined;
    PoolEntryDate?: Date | undefined;
}
export type TapeArchives = TapeArchive[];
export interface DescribeTapeArchivesOutput {
    TapeArchives?: TapeArchive[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeTapeRecoveryPointsInput {
    GatewayARN: string;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export type TapeRecoveryPointStatus = string;
export interface TapeRecoveryPointInfo {
    TapeARN?: string | undefined;
    TapeRecoveryPointTime?: Date | undefined;
    TapeSizeInBytes?: number | undefined;
    TapeStatus?: string | undefined;
}
export type TapeRecoveryPointInfos = TapeRecoveryPointInfo[];
export interface DescribeTapeRecoveryPointsOutput {
    GatewayARN?: string | undefined;
    TapeRecoveryPointInfos?: TapeRecoveryPointInfo[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeTapesInput {
    GatewayARN: string;
    TapeARNs?: string[] | undefined;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export type TapeStatus = string;
export type VTLDeviceARN = string;
export interface Tape {
    TapeARN?: string | undefined;
    TapeBarcode?: string | undefined;
    TapeCreatedDate?: Date | undefined;
    TapeSizeInBytes?: number | undefined;
    TapeStatus?: string | undefined;
    VTLDevice?: string | undefined;
    Progress?: number | undefined;
    TapeUsedInBytes?: number | undefined;
    KMSKey?: string | undefined;
    PoolId?: string | undefined;
    Worm?: boolean | undefined;
    RetentionStartDate?: Date | undefined;
    PoolEntryDate?: Date | undefined;
}
export type Tapes = Tape[];
export interface DescribeTapesOutput {
    Tapes?: Tape[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeUploadBufferInput {
    GatewayARN: string;
}
export interface DescribeUploadBufferOutput {
    GatewayARN?: string | undefined;
    DiskIds?: string[] | undefined;
    UploadBufferUsedInBytes?: number | undefined;
    UploadBufferAllocatedInBytes?: number | undefined;
}
export type VTLDeviceARNs = string[];
export interface DescribeVTLDevicesInput {
    GatewayARN: string;
    VTLDeviceARNs?: string[] | undefined;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export type VTLDeviceType = string;
export type VTLDeviceVendor = string;
export type VTLDeviceProductIdentifier = string;
export interface DeviceiSCSIAttributes {
    TargetARN?: string | undefined;
    NetworkInterfaceId?: string | undefined;
    NetworkInterfacePort?: number | undefined;
    ChapEnabled?: boolean | undefined;
}
export interface VTLDevice {
    VTLDeviceARN?: string | undefined;
    VTLDeviceType?: string | undefined;
    VTLDeviceVendor?: string | undefined;
    VTLDeviceProductIdentifier?: string | undefined;
    DeviceiSCSIAttributes?: DeviceiSCSIAttributes | undefined;
}
export type VTLDevices = VTLDevice[];
export interface DescribeVTLDevicesOutput {
    GatewayARN?: string | undefined;
    VTLDevices?: VTLDevice[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeWorkingStorageInput {
    GatewayARN: string;
}
export interface DescribeWorkingStorageOutput {
    GatewayARN?: string | undefined;
    DiskIds?: string[] | undefined;
    WorkingStorageUsedInBytes?: number | undefined;
    WorkingStorageAllocatedInBytes?: number | undefined;
}
export interface DetachVolumeInput {
    VolumeARN: string;
    ForceDetach?: boolean | undefined;
}
export interface DetachVolumeOutput {
    VolumeARN?: string | undefined;
}
export interface DisableGatewayInput {
    GatewayARN: string;
}
export interface DisableGatewayOutput {
    GatewayARN?: string | undefined;
}
export interface DisassociateFileSystemInput {
    FileSystemAssociationARN: string;
    ForceDelete?: boolean | undefined;
}
export interface DisassociateFileSystemOutput {
    FileSystemAssociationARN?: string | undefined;
}
export interface EvictFilesFailingUploadInput {
    FileShareARN: string;
    ForceRemove?: boolean | undefined;
}
export interface EvictFilesFailingUploadOutput {
    NotificationId?: string | undefined;
}
export type OrganizationalUnit = string;
export type Host = string;
export type Hosts = string[];
export type TimeoutInSeconds = number;
export interface JoinDomainInput {
    GatewayARN: string;
    DomainName: string;
    OrganizationalUnit?: string | undefined;
    DomainControllers?: string[] | undefined;
    TimeoutInSeconds?: number | undefined;
    UserName: string;
    Password: string | redacted.Redacted<string>;
}
export interface JoinDomainOutput {
    GatewayARN?: string | undefined;
    ActiveDirectoryStatus?: ActiveDirectoryStatus | undefined;
}
export interface ListAutomaticTapeCreationPoliciesInput {
    GatewayARN?: string | undefined;
}
export type MinimumNumTapes = number;
export interface AutomaticTapeCreationRule {
    TapeBarcodePrefix: string;
    PoolId: string;
    TapeSizeInBytes: number;
    MinimumNumTapes: number;
    Worm?: boolean | undefined;
}
export type AutomaticTapeCreationRules = AutomaticTapeCreationRule[];
export interface AutomaticTapeCreationPolicyInfo {
    AutomaticTapeCreationRules?: AutomaticTapeCreationRule[] | undefined;
    GatewayARN?: string | undefined;
}
export type AutomaticTapeCreationPolicyInfos = AutomaticTapeCreationPolicyInfo[];
export interface ListAutomaticTapeCreationPoliciesOutput {
    AutomaticTapeCreationPolicyInfos?: AutomaticTapeCreationPolicyInfo[] | undefined;
}
export interface ListCacheReportsInput {
    Marker?: string | undefined;
}
export type CacheReportList = CacheReportInfo[];
export interface ListCacheReportsOutput {
    CacheReportList?: CacheReportInfo[] | undefined;
    Marker?: string | undefined;
}
export interface ListFileSharesInput {
    GatewayARN?: string | undefined;
    Limit?: number | undefined;
    Marker?: string | undefined;
}
export type FileShareType = "NFS" | "SMB" | (string & {});
export interface FileShareInfo {
    FileShareType?: FileShareType | undefined;
    FileShareARN?: string | undefined;
    FileShareId?: string | undefined;
    FileShareStatus?: string | undefined;
    GatewayARN?: string | undefined;
}
export type FileShareInfoList = FileShareInfo[];
export interface ListFileSharesOutput {
    Marker?: string | undefined;
    NextMarker?: string | undefined;
    FileShareInfoList?: FileShareInfo[] | undefined;
}
export interface ListFileSystemAssociationsInput {
    GatewayARN?: string | undefined;
    Limit?: number | undefined;
    Marker?: string | undefined;
}
export type FileSystemAssociationId = string;
export interface FileSystemAssociationSummary {
    FileSystemAssociationId?: string | undefined;
    FileSystemAssociationARN?: string | undefined;
    FileSystemAssociationStatus?: string | undefined;
    GatewayARN?: string | undefined;
}
export type FileSystemAssociationSummaryList = FileSystemAssociationSummary[];
export interface ListFileSystemAssociationsOutput {
    Marker?: string | undefined;
    NextMarker?: string | undefined;
    FileSystemAssociationSummaryList?: FileSystemAssociationSummary[] | undefined;
}
export interface ListGatewaysInput {
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export type GatewayOperationalState = string;
export interface GatewayInfo {
    GatewayId?: string | undefined;
    GatewayARN?: string | undefined;
    GatewayType?: string | undefined;
    GatewayOperationalState?: string | undefined;
    GatewayName?: string | undefined;
    Ec2InstanceId?: string | undefined;
    Ec2InstanceRegion?: string | undefined;
    HostEnvironment?: HostEnvironment | undefined;
    HostEnvironmentId?: string | undefined;
    DeprecationDate?: string | undefined;
    SoftwareVersion?: string | undefined;
}
export type Gateways = GatewayInfo[];
export interface ListGatewaysOutput {
    Gateways?: GatewayInfo[] | undefined;
    Marker?: string | undefined;
}
export interface ListLocalDisksInput {
    GatewayARN: string;
}
export type DiskAllocationType = string;
export type DiskAttribute = string;
export type DiskAttributeList = string[];
export interface Disk {
    DiskId?: string | undefined;
    DiskPath?: string | undefined;
    DiskNode?: string | undefined;
    DiskStatus?: string | undefined;
    DiskSizeInBytes?: number | undefined;
    DiskAllocationType?: string | undefined;
    DiskAllocationResource?: string | undefined;
    DiskAttributeList?: string[] | undefined;
}
export type Disks = Disk[];
export interface ListLocalDisksOutput {
    GatewayARN?: string | undefined;
    Disks?: Disk[] | undefined;
}
export interface ListTagsForResourceInput {
    ResourceARN: string;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export interface ListTagsForResourceOutput {
    ResourceARN?: string | undefined;
    Marker?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type PoolARNs = string[];
export interface ListTapePoolsInput {
    PoolARNs?: string[] | undefined;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export type PoolStatus = "ACTIVE" | "DELETED" | (string & {});
export interface PoolInfo {
    PoolARN?: string | undefined;
    PoolName?: string | undefined;
    StorageClass?: TapeStorageClass | undefined;
    RetentionLockType?: RetentionLockType | undefined;
    RetentionLockTimeInDays?: number | undefined;
    PoolStatus?: PoolStatus | undefined;
}
export type PoolInfos = PoolInfo[];
export interface ListTapePoolsOutput {
    PoolInfos?: PoolInfo[] | undefined;
    Marker?: string | undefined;
}
export interface ListTapesInput {
    TapeARNs?: string[] | undefined;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export interface TapeInfo {
    TapeARN?: string | undefined;
    TapeBarcode?: string | undefined;
    TapeSizeInBytes?: number | undefined;
    TapeStatus?: string | undefined;
    GatewayARN?: string | undefined;
    PoolId?: string | undefined;
    RetentionStartDate?: Date | undefined;
    PoolEntryDate?: Date | undefined;
}
export type TapeInfos = TapeInfo[];
export interface ListTapesOutput {
    TapeInfos?: TapeInfo[] | undefined;
    Marker?: string | undefined;
}
export interface ListVolumeInitiatorsInput {
    VolumeARN: string;
}
export type Initiator = string;
export type Initiators = string[];
export interface ListVolumeInitiatorsOutput {
    Initiators?: string[] | undefined;
}
export interface ListVolumeRecoveryPointsInput {
    GatewayARN: string;
}
export interface VolumeRecoveryPointInfo {
    VolumeARN?: string | undefined;
    VolumeSizeInBytes?: number | undefined;
    VolumeUsageInBytes?: number | undefined;
    VolumeRecoveryPointTime?: string | undefined;
}
export type VolumeRecoveryPointInfos = VolumeRecoveryPointInfo[];
export interface ListVolumeRecoveryPointsOutput {
    GatewayARN?: string | undefined;
    VolumeRecoveryPointInfos?: VolumeRecoveryPointInfo[] | undefined;
}
export interface ListVolumesInput {
    GatewayARN?: string | undefined;
    Marker?: string | undefined;
    Limit?: number | undefined;
}
export interface VolumeInfo {
    VolumeARN?: string | undefined;
    VolumeId?: string | undefined;
    GatewayARN?: string | undefined;
    GatewayId?: string | undefined;
    VolumeType?: string | undefined;
    VolumeSizeInBytes?: number | undefined;
    VolumeAttachmentStatus?: string | undefined;
}
export type VolumeInfos = VolumeInfo[];
export interface ListVolumesOutput {
    GatewayARN?: string | undefined;
    Marker?: string | undefined;
    VolumeInfos?: VolumeInfo[] | undefined;
}
export interface NotifyWhenUploadedInput {
    FileShareARN: string;
}
export type NotificationId = string;
export interface NotifyWhenUploadedOutput {
    FileShareARN?: string | undefined;
    NotificationId?: string | undefined;
}
export type Folder = string;
export type FolderList = string[];
export interface RefreshCacheInput {
    FileShareARN: string;
    FolderList?: string[] | undefined;
    Recursive?: boolean | undefined;
}
export interface RefreshCacheOutput {
    FileShareARN?: string | undefined;
    NotificationId?: string | undefined;
}
export type TagKeys = string[];
export interface RemoveTagsFromResourceInput {
    ResourceARN: string;
    TagKeys: string[];
}
export interface RemoveTagsFromResourceOutput {
    ResourceARN?: string | undefined;
}
export interface ResetCacheInput {
    GatewayARN: string;
}
export interface ResetCacheOutput {
    GatewayARN?: string | undefined;
}
export interface RetrieveTapeArchiveInput {
    TapeARN: string;
    GatewayARN: string;
}
export interface RetrieveTapeArchiveOutput {
    TapeARN?: string | undefined;
}
export interface RetrieveTapeRecoveryPointInput {
    TapeARN: string;
    GatewayARN: string;
}
export interface RetrieveTapeRecoveryPointOutput {
    TapeARN?: string | undefined;
}
export type LocalConsolePassword = string | redacted.Redacted<string>;
export interface SetLocalConsolePasswordInput {
    GatewayARN: string;
    LocalConsolePassword: string | redacted.Redacted<string>;
}
export interface SetLocalConsolePasswordOutput {
    GatewayARN?: string | undefined;
}
export type SMBGuestPassword = string | redacted.Redacted<string>;
export interface SetSMBGuestPasswordInput {
    GatewayARN: string;
    Password: string | redacted.Redacted<string>;
}
export interface SetSMBGuestPasswordOutput {
    GatewayARN?: string | undefined;
}
export interface ShutdownGatewayInput {
    GatewayARN: string;
}
export interface ShutdownGatewayOutput {
    GatewayARN?: string | undefined;
}
export interface StartAvailabilityMonitorTestInput {
    GatewayARN: string;
}
export interface StartAvailabilityMonitorTestOutput {
    GatewayARN?: string | undefined;
}
export interface StartCacheReportInput {
    FileShareARN: string;
    Role: string;
    LocationARN: string;
    BucketRegion: string;
    VPCEndpointDNSName?: string | undefined;
    InclusionFilters?: CacheReportFilter[] | undefined;
    ExclusionFilters?: CacheReportFilter[] | undefined;
    ClientToken: string;
    Tags?: Tag[] | undefined;
}
export interface StartCacheReportOutput {
    CacheReportARN?: string | undefined;
}
export interface StartGatewayInput {
    GatewayARN: string;
}
export interface StartGatewayOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateAutomaticTapeCreationPolicyInput {
    AutomaticTapeCreationRules: AutomaticTapeCreationRule[];
    GatewayARN: string;
}
export interface UpdateAutomaticTapeCreationPolicyOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateBandwidthRateLimitInput {
    GatewayARN: string;
    AverageUploadRateLimitInBitsPerSec?: number | undefined;
    AverageDownloadRateLimitInBitsPerSec?: number | undefined;
}
export interface UpdateBandwidthRateLimitOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateBandwidthRateLimitScheduleInput {
    GatewayARN: string;
    BandwidthRateLimitIntervals: BandwidthRateLimitInterval[];
}
export interface UpdateBandwidthRateLimitScheduleOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateChapCredentialsInput {
    TargetARN: string;
    SecretToAuthenticateInitiator: string | redacted.Redacted<string>;
    InitiatorName: string;
    SecretToAuthenticateTarget?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateChapCredentialsOutput {
    TargetARN?: string | undefined;
    InitiatorName?: string | undefined;
}
export interface UpdateFileSystemAssociationInput {
    FileSystemAssociationARN: string;
    UserName?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    AuditDestinationARN?: string | undefined;
    CacheAttributes?: CacheAttributes | undefined;
}
export interface UpdateFileSystemAssociationOutput {
    FileSystemAssociationARN?: string | undefined;
}
export interface UpdateGatewayInformationInput {
    GatewayARN: string;
    GatewayName?: string | undefined;
    GatewayTimezone?: string | undefined;
    CloudWatchLogGroupARN?: string | undefined;
    GatewayCapacity?: GatewayCapacity | undefined;
}
export interface UpdateGatewayInformationOutput {
    GatewayARN?: string | undefined;
    GatewayName?: string | undefined;
}
export interface UpdateGatewaySoftwareNowInput {
    GatewayARN: string;
}
export interface UpdateGatewaySoftwareNowOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateMaintenanceStartTimeInput {
    GatewayARN: string;
    HourOfDay?: number | undefined;
    MinuteOfHour?: number | undefined;
    DayOfWeek?: number | undefined;
    DayOfMonth?: number | undefined;
    SoftwareUpdatePreferences?: SoftwareUpdatePreferences | undefined;
}
export interface UpdateMaintenanceStartTimeOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateNFSFileShareInput {
    FileShareARN: string;
    EncryptionType?: EncryptionType | undefined;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    NFSFileShareDefaults?: NFSFileShareDefaults | undefined;
    DefaultStorageClass?: string | undefined;
    ObjectACL?: ObjectACL | undefined;
    ClientList?: string[] | undefined;
    Squash?: string | undefined;
    ReadOnly?: boolean | undefined;
    GuessMIMETypeEnabled?: boolean | undefined;
    RequesterPays?: boolean | undefined;
    FileShareName?: string | undefined;
    CacheAttributes?: CacheAttributes | undefined;
    NotificationPolicy?: string | undefined;
    AuditDestinationARN?: string | undefined;
}
export interface UpdateNFSFileShareOutput {
    FileShareARN?: string | undefined;
}
export interface UpdateSMBFileShareInput {
    FileShareARN: string;
    EncryptionType?: EncryptionType | undefined;
    KMSEncrypted?: boolean | undefined;
    KMSKey?: string | undefined;
    DefaultStorageClass?: string | undefined;
    ObjectACL?: ObjectACL | undefined;
    ReadOnly?: boolean | undefined;
    GuessMIMETypeEnabled?: boolean | undefined;
    RequesterPays?: boolean | undefined;
    SMBACLEnabled?: boolean | undefined;
    AccessBasedEnumeration?: boolean | undefined;
    AdminUserList?: string[] | undefined;
    ValidUserList?: string[] | undefined;
    InvalidUserList?: string[] | undefined;
    AuditDestinationARN?: string | undefined;
    CaseSensitivity?: CaseSensitivity | undefined;
    FileShareName?: string | undefined;
    CacheAttributes?: CacheAttributes | undefined;
    NotificationPolicy?: string | undefined;
    OplocksEnabled?: boolean | undefined;
}
export interface UpdateSMBFileShareOutput {
    FileShareARN?: string | undefined;
}
export interface UpdateSMBFileShareVisibilityInput {
    GatewayARN: string;
    FileSharesVisible: boolean;
}
export interface UpdateSMBFileShareVisibilityOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateSMBLocalGroupsInput {
    GatewayARN: string;
    SMBLocalGroups: SMBLocalGroups;
}
export interface UpdateSMBLocalGroupsOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateSMBSecurityStrategyInput {
    GatewayARN: string;
    SMBSecurityStrategy: SMBSecurityStrategy;
}
export interface UpdateSMBSecurityStrategyOutput {
    GatewayARN?: string | undefined;
}
export interface UpdateSnapshotScheduleInput {
    VolumeARN: string;
    StartAt: number;
    RecurrenceInHours: number;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface UpdateSnapshotScheduleOutput {
    VolumeARN?: string | undefined;
}
export type DeviceType = string;
export interface UpdateVTLDeviceTypeInput {
    VTLDeviceARN: string;
    DeviceType: string;
}
export interface UpdateVTLDeviceTypeOutput {
    VTLDeviceARN?: string | undefined;
}
export type ErrorCode = "ActivationKeyExpired" | "ActivationKeyInvalid" | "ActivationKeyNotFound" | "GatewayInternalError" | "GatewayNotConnected" | "GatewayNotFound" | "GatewayProxyNetworkConnectionBusy" | "AuthenticationFailure" | "BandwidthThrottleScheduleNotFound" | "Blocked" | "CannotExportSnapshot" | "ChapCredentialNotFound" | "DiskAlreadyAllocated" | "DiskDoesNotExist" | "DiskSizeGreaterThanVolumeMaxSize" | "DiskSizeLessThanVolumeSize" | "DiskSizeNotGigAligned" | "DuplicateCertificateInfo" | "DuplicateSchedule" | "EndpointNotFound" | "IAMNotSupported" | "InitiatorInvalid" | "InitiatorNotFound" | "InternalError" | "InvalidGateway" | "InvalidEndpoint" | "InvalidParameters" | "InvalidSchedule" | "LocalStorageLimitExceeded" | "LunAlreadyAllocated " | "LunInvalid" | "JoinDomainInProgress" | "MaximumContentLengthExceeded" | "MaximumTapeCartridgeCountExceeded" | "MaximumVolumeCountExceeded" | "NetworkConfigurationChanged" | "NoDisksAvailable" | "NotImplemented" | "NotSupported" | "OperationAborted" | "OutdatedGateway" | "ParametersNotImplemented" | "RegionInvalid" | "RequestTimeout" | "ServiceUnavailable" | "SnapshotDeleted" | "SnapshotIdInvalid" | "SnapshotInProgress" | "SnapshotNotFound" | "SnapshotScheduleNotFound" | "StagingAreaFull" | "StorageFailure" | "TapeCartridgeNotFound" | "TargetAlreadyExists" | "TargetInvalid" | "TargetNotFound" | "UnauthorizedOperation" | "VolumeAlreadyExists" | "VolumeIdInvalid" | "VolumeInUse" | "VolumeNotFound" | "VolumeNotReady" | (string & {});
export type ErrorDetails = {
    [key: string]: string | undefined;
};
export interface StorageGatewayError {
    errorCode?: ErrorCode | undefined;
    errorDetails?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ActivateGatewayError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Activates the gateway you previously deployed on your host. In the activation process,
 * you specify information such as the Amazon Web Services Region that you want to use for
 * storing snapshots or tapes, the time zone for scheduled snapshots the gateway snapshot
 * schedule window, an activation key, and a name for your gateway. The activation process
 * also associates your gateway with your account. For more information, see UpdateGatewayInformation.
 *
 * You must turn on the gateway VM before you can activate your gateway.
 */
export declare const activateGateway: API.OperationMethod<ActivateGatewayInput & RegionInput, ActivateGatewayOutput, ActivateGatewayError, Credentials | HttpClient.HttpClient>;
export type AddCacheError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Configures one or more gateway local disks as cache for a gateway. This operation is
 * only supported in the cached volume, tape, and file gateway type (see How Storage Gateway works (architecture).
 *
 * In the request, you specify the gateway Amazon Resource Name (ARN) to which you want to
 * add cache, and one or more disk IDs that you want to configure as cache.
 */
export declare const addCache: API.OperationMethod<AddCacheInput & RegionInput, AddCacheOutput, AddCacheError, Credentials | HttpClient.HttpClient>;
export type AddTagsToResourceError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Adds one or more tags to the specified resource. You use tags to add metadata to
 * resources, which you can use to categorize these resources. For example, you can categorize
 * resources by purpose, owner, environment, or team. Each tag consists of a key and a value,
 * which you define. You can add tags to the following Storage Gateway resources:
 *
 * - Storage gateways of all types
 *
 * - Storage volumes
 *
 * - Virtual tapes
 *
 * - NFS and SMB file shares
 *
 * - File System associations
 *
 * You can create a maximum of 50 tags for each resource. Virtual tapes and storage volumes
 * that are recovered to a new gateway maintain their tags.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceInput & RegionInput, AddTagsToResourceOutput, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type AddUploadBufferError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Configures one or more gateway local disks as upload buffer for a specified gateway.
 * This operation is supported for the stored volume, cached volume, and tape gateway
 * types.
 *
 * In the request, you specify the gateway Amazon Resource Name (ARN) to which you want to
 * add upload buffer, and one or more disk IDs that you want to configure as upload
 * buffer.
 */
export declare const addUploadBuffer: API.OperationMethod<AddUploadBufferInput & RegionInput, AddUploadBufferOutput, AddUploadBufferError, Credentials | HttpClient.HttpClient>;
export type AddWorkingStorageError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Configures one or more gateway local disks as working storage for a gateway. This
 * operation is only supported in the stored volume gateway type. This operation is deprecated
 * in cached volume API version 20120630. Use AddUploadBuffer
 * instead.
 *
 * Working storage is also referred to as upload buffer. You can also use the AddUploadBuffer operation to add upload buffer to a stored volume
 * gateway.
 *
 * In the request, you specify the gateway Amazon Resource Name (ARN) to which you want to
 * add working storage, and one or more disk IDs that you want to configure as working
 * storage.
 */
export declare const addWorkingStorage: API.OperationMethod<AddWorkingStorageInput & RegionInput, AddWorkingStorageOutput, AddWorkingStorageError, Credentials | HttpClient.HttpClient>;
export type AssignTapePoolError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Assigns a tape to a tape pool for archiving. The tape assigned to a pool is archived in
 * the S3 storage class that is associated with the pool. When you use your backup application
 * to eject the tape, the tape is archived directly into the S3 storage class (S3 Glacier or
 * S3 Glacier Deep Archive) that corresponds to the pool.
 */
export declare const assignTapePool: API.OperationMethod<AssignTapePoolInput & RegionInput, AssignTapePoolOutput, AssignTapePoolError, Credentials | HttpClient.HttpClient>;
export type AssociateFileSystemError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Associate an Amazon FSx file system with the FSx File Gateway. After the
 * association process is complete, the file shares on the Amazon FSx file system are
 * available for access through the gateway. This operation only supports the FSx File Gateway
 * type.
 */
export declare const associateFileSystem: API.OperationMethod<AssociateFileSystemInput & RegionInput, AssociateFileSystemOutput, AssociateFileSystemError, Credentials | HttpClient.HttpClient>;
export type AttachVolumeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Connects a volume to an iSCSI connection and then attaches the volume to the specified
 * gateway. Detaching and attaching a volume enables you to recover your data from one gateway
 * to a different gateway without creating a snapshot. It also makes it easier to move your
 * volumes from an on-premises gateway to a gateway hosted on an Amazon EC2 instance.
 */
export declare const attachVolume: API.OperationMethod<AttachVolumeInput & RegionInput, AttachVolumeOutput, AttachVolumeError, Credentials | HttpClient.HttpClient>;
export type CancelArchivalError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Cancels archiving of a virtual tape to the virtual tape shelf (VTS) after the archiving
 * process is initiated. This operation is only supported in the tape gateway type.
 */
export declare const cancelArchival: API.OperationMethod<CancelArchivalInput & RegionInput, CancelArchivalOutput, CancelArchivalError, Credentials | HttpClient.HttpClient>;
export type CancelCacheReportError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Cancels generation of a specified cache report. You can use this operation to manually
 * cancel an IN-PROGRESS report for any reason. This action changes the report status from
 * IN-PROGRESS to CANCELLED. You can only cancel in-progress reports. If the the report you
 * attempt to cancel is in FAILED, ERROR, or COMPLETED state, the cancel operation returns an
 * error.
 */
export declare const cancelCacheReport: API.OperationMethod<CancelCacheReportInput & RegionInput, CancelCacheReportOutput, CancelCacheReportError, Credentials | HttpClient.HttpClient>;
export type CancelRetrievalError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Cancels retrieval of a virtual tape from the virtual tape shelf (VTS) to a gateway after
 * the retrieval process is initiated. The virtual tape is returned to the VTS. This operation
 * is only supported in the tape gateway type.
 */
export declare const cancelRetrieval: API.OperationMethod<CancelRetrievalInput & RegionInput, CancelRetrievalOutput, CancelRetrievalError, Credentials | HttpClient.HttpClient>;
export type CreateCachediSCSIVolumeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Creates a cached volume on a specified cached volume gateway. This operation is only
 * supported in the cached volume gateway type.
 *
 * Cache storage must be allocated to the gateway before you can create a cached volume.
 * Use the AddCache operation to add cache storage to a gateway.
 *
 * In the request, you must specify the gateway, size of the volume in bytes, the iSCSI
 * target name, an IP address on which to expose the target, and a unique client token. In
 * response, the gateway creates the volume and returns information about it. This information
 * includes the volume Amazon Resource Name (ARN), its size, and the iSCSI target ARN that
 * initiators can use to connect to the volume target.
 *
 * Optionally, you can provide the ARN for an existing volume as the
 * `SourceVolumeARN` for this cached volume, which creates an exact copy of the
 * existing volume's latest recovery point. The `VolumeSizeInBytes` value must be
 * equal to or larger than the size of the copied volume, in bytes.
 */
export declare const createCachediSCSIVolume: API.OperationMethod<CreateCachediSCSIVolumeInput & RegionInput, CreateCachediSCSIVolumeOutput, CreateCachediSCSIVolumeError, Credentials | HttpClient.HttpClient>;
export type CreateNFSFileShareError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Creates a Network File System (NFS) file share on an existing S3 File Gateway. In
 * Storage Gateway, a file share is a file system mount point backed by Amazon S3
 * cloud storage. Storage Gateway exposes file shares using an NFS interface. This operation
 * is only supported for S3 File Gateways.
 *
 * S3 File gateway requires Security Token Service (Amazon Web Services STS) to be
 * activated to enable you to create a file share. Make sure Amazon Web Services STS is
 * activated in the Amazon Web Services Region you are creating your S3 File Gateway in. If
 * Amazon Web Services STS is not activated in the Amazon Web Services Region, activate
 * it. For information about how to activate Amazon Web Services STS, see Activating and
 * deactivating Amazon Web Services STS in an Amazon Web Services Region in the
 * *Identity and Access Management User Guide*.
 *
 * S3 File Gateways do not support creating hard or symbolic links on a file
 * share.
 */
export declare const createNFSFileShare: API.OperationMethod<CreateNFSFileShareInput & RegionInput, CreateNFSFileShareOutput, CreateNFSFileShareError, Credentials | HttpClient.HttpClient>;
export type CreateSMBFileShareError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Creates a Server Message Block (SMB) file share on an existing S3 File Gateway. In
 * Storage Gateway, a file share is a file system mount point backed by Amazon S3
 * cloud storage. Storage Gateway exposes file shares using an SMB interface. This operation
 * is only supported for S3 File Gateways.
 *
 * S3 File Gateways require Security Token Service (Amazon Web Services STS) to be
 * activated to enable you to create a file share. Make sure that Amazon Web Services STS
 * is activated in the Amazon Web Services Region you are creating your S3 File Gateway in.
 * If Amazon Web Services STS is not activated in this Amazon Web Services Region, activate
 * it. For information about how to activate Amazon Web Services STS, see Activating and
 * deactivating Amazon Web Services STS in an Amazon Web Services Region in the
 * *Identity and Access Management User Guide*.
 *
 * File gateways don't support creating hard or symbolic links on a file
 * share.
 */
export declare const createSMBFileShare: API.OperationMethod<CreateSMBFileShareInput & RegionInput, CreateSMBFileShareOutput, CreateSMBFileShareError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = InternalServerError | InvalidGatewayRequestException | ServiceUnavailableError | CommonErrors;
/**
 * Initiates a snapshot of a volume.
 *
 * Storage Gateway provides the ability to back up point-in-time snapshots of your
 * data to Amazon Simple Storage (Amazon S3) for durable off-site recovery, and also
 * import the data to an Amazon Elastic Block Store (EBS) volume in Amazon Elastic Compute
 * Cloud (EC2). You can take snapshots of your gateway volume on a scheduled or ad hoc basis.
 * This API enables you to take an ad hoc snapshot. For more information, see Editing a
 * snapshot schedule.
 *
 * In the `CreateSnapshot` request, you identify the volume by providing its
 * Amazon Resource Name (ARN). You must also provide description for the snapshot. When
 * Storage Gateway takes the snapshot of specified volume, the snapshot and
 * description appears in the Storage Gateway console. In response, Storage Gateway
 * returns you a snapshot ID. You can use this snapshot ID to check the snapshot progress or
 * later use it when you want to create a volume from a snapshot. This operation is only
 * supported in stored and cached volume gateway type.
 *
 * To list or delete a snapshot, you must use the Amazon EC2 API. For more information,
 * see DescribeSnapshots
 * or DeleteSnapshot in the Amazon Elastic Compute Cloud API
 * Reference.
 *
 * Volume and snapshot IDs are changing to a longer length ID format. For more
 * information, see the important note on the Welcome page.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotInput & RegionInput, CreateSnapshotOutput, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotFromVolumeRecoveryPointError = InternalServerError | InvalidGatewayRequestException | ServiceUnavailableError | CommonErrors;
/**
 * Initiates a snapshot of a gateway from a volume recovery point. This operation is only
 * supported in the cached volume gateway type.
 *
 * A volume recovery point is a point in time at which all data of the volume is consistent
 * and from which you can create a snapshot. To get a list of volume recovery point for cached
 * volume gateway, use ListVolumeRecoveryPoints.
 *
 * In the `CreateSnapshotFromVolumeRecoveryPoint` request, you identify the
 * volume by providing its Amazon Resource Name (ARN). You must also provide a description for
 * the snapshot. When the gateway takes a snapshot of the specified volume, the snapshot and
 * its description appear in the Storage Gateway console.
 * In response, the gateway returns
 * you a snapshot ID. You can use this snapshot ID to check the snapshot progress or later use
 * it when you want to create a volume from a snapshot.
 *
 * To list or delete a snapshot, you must use the Amazon EC2 API. For more information,
 * see DescribeSnapshots
 * or DeleteSnapshot in the Amazon Elastic Compute Cloud API
 * Reference.
 */
export declare const createSnapshotFromVolumeRecoveryPoint: API.OperationMethod<CreateSnapshotFromVolumeRecoveryPointInput & RegionInput, CreateSnapshotFromVolumeRecoveryPointOutput, CreateSnapshotFromVolumeRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type CreateStorediSCSIVolumeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Creates a volume on a specified gateway. This operation is only supported in the stored
 * volume gateway type.
 *
 * The size of the volume to create is inferred from the disk size. You can choose to
 * preserve existing data on the disk, create volume from an existing snapshot, or create an
 * empty volume. If you choose to create an empty gateway volume, then any existing data on
 * the disk is erased.
 *
 * In the request, you must specify the gateway and the disk information on which you are
 * creating the volume. In response, the gateway creates the volume and returns volume
 * information such as the volume Amazon Resource Name (ARN), its size, and the iSCSI target
 * ARN that initiators can use to connect to the volume target.
 */
export declare const createStorediSCSIVolume: API.OperationMethod<CreateStorediSCSIVolumeInput & RegionInput, CreateStorediSCSIVolumeOutput, CreateStorediSCSIVolumeError, Credentials | HttpClient.HttpClient>;
export type CreateTapePoolError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Creates a new custom tape pool. You can use custom tape pool to enable tape retention
 * lock on tapes that are archived in the custom pool.
 */
export declare const createTapePool: API.OperationMethod<CreateTapePoolInput & RegionInput, CreateTapePoolOutput, CreateTapePoolError, Credentials | HttpClient.HttpClient>;
export type CreateTapesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Creates one or more virtual tapes. You write data to the virtual tapes and then archive
 * the tapes. This operation is only supported in the tape gateway type.
 *
 * Cache storage must be allocated to the gateway before you can create virtual tapes.
 * Use the AddCache operation to add cache storage to a gateway.
 */
export declare const createTapes: API.OperationMethod<CreateTapesInput & RegionInput, CreateTapesOutput, CreateTapesError, Credentials | HttpClient.HttpClient>;
export type CreateTapeWithBarcodeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Creates a virtual tape by using your own barcode. You write data to the virtual tape and
 * then archive the tape. A barcode is unique and cannot be reused if it has already been used
 * on a tape. This applies to barcodes used on deleted tapes. This operation is only supported
 * in the tape gateway type.
 *
 * Cache storage must be allocated to the gateway before you can create a virtual tape.
 * Use the AddCache operation to add cache storage to a gateway.
 */
export declare const createTapeWithBarcode: API.OperationMethod<CreateTapeWithBarcodeInput & RegionInput, CreateTapeWithBarcodeOutput, CreateTapeWithBarcodeError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomaticTapeCreationPolicyError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes the automatic tape creation policy of a gateway. If you delete this policy, new
 * virtual tapes must be created manually. Use the Amazon Resource Name (ARN) of the gateway
 * in your request to remove the policy.
 */
export declare const deleteAutomaticTapeCreationPolicy: API.OperationMethod<DeleteAutomaticTapeCreationPolicyInput & RegionInput, DeleteAutomaticTapeCreationPolicyOutput, DeleteAutomaticTapeCreationPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteBandwidthRateLimitError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes the bandwidth rate limits of a gateway. You can delete either the upload and
 * download bandwidth rate limit, or you can delete both. If you delete only one of the
 * limits, the other limit remains unchanged. To specify which gateway to work with, use the
 * Amazon Resource Name (ARN) of the gateway in your request. This operation is supported only
 * for the stored volume, cached volume, and tape gateway types.
 */
export declare const deleteBandwidthRateLimit: API.OperationMethod<DeleteBandwidthRateLimitInput & RegionInput, DeleteBandwidthRateLimitOutput, DeleteBandwidthRateLimitError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheReportError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes the specified cache report and any associated tags from the Storage Gateway database. You can only delete completed reports. If the status of the
 * report you attempt to delete still IN-PROGRESS, the delete operation returns an error. You
 * can use `CancelCacheReport` to cancel an IN-PROGRESS report.
 *
 * `DeleteCacheReport` does not delete the report object from your Amazon S3 bucket.
 */
export declare const deleteCacheReport: API.OperationMethod<DeleteCacheReportInput & RegionInput, DeleteCacheReportOutput, DeleteCacheReportError, Credentials | HttpClient.HttpClient>;
export type DeleteChapCredentialsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes Challenge-Handshake Authentication Protocol (CHAP) credentials for a specified
 * iSCSI target and initiator pair. This operation is supported in volume and tape gateway
 * types.
 */
export declare const deleteChapCredentials: API.OperationMethod<DeleteChapCredentialsInput & RegionInput, DeleteChapCredentialsOutput, DeleteChapCredentialsError, Credentials | HttpClient.HttpClient>;
export type DeleteFileShareError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes a file share from an S3 File Gateway. This operation is only supported for S3
 * File Gateways.
 */
export declare const deleteFileShare: API.OperationMethod<DeleteFileShareInput & RegionInput, DeleteFileShareOutput, DeleteFileShareError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes a gateway. To specify which gateway to delete, use the Amazon Resource Name
 * (ARN) of the gateway in your request. The operation deletes the gateway; however, it does
 * not delete the gateway virtual machine (VM) from your host computer.
 *
 * After you delete a gateway, you cannot reactivate it. Completed snapshots of the gateway
 * volumes are not deleted upon deleting the gateway, however, pending snapshots will not
 * complete. After you delete a gateway, your next step is to remove it from your
 * environment.
 *
 * You no longer pay software charges after the gateway is deleted; however, your
 * existing Amazon EBS snapshots persist and you will continue to be billed for these
 * snapshots. You can choose to remove all remaining Amazon EBS snapshots by canceling your
 * Amazon EC2 subscription.  If you prefer not to cancel your Amazon EC2 subscription, you
 * can delete your snapshots using the Amazon EC2 console. For more information, see the
 * Storage Gateway detail
 * page.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayInput & RegionInput, DeleteGatewayOutput, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotScheduleError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes a snapshot of a volume.
 *
 * You can take snapshots of your gateway volumes on a scheduled or ad hoc basis. This API
 * action enables you to delete a snapshot schedule for a volume. For more information, see
 * Backing up your
 * volumes. In the `DeleteSnapshotSchedule` request, you identify the
 * volume by providing its Amazon Resource Name (ARN). This operation is only supported for
 * cached volume gateway types.
 *
 * To list or delete a snapshot, you must use the Amazon EC2 API. For more information,
 * go to DescribeSnapshots
 * in the *Amazon Elastic Compute Cloud API Reference*.
 */
export declare const deleteSnapshotSchedule: API.OperationMethod<DeleteSnapshotScheduleInput & RegionInput, DeleteSnapshotScheduleOutput, DeleteSnapshotScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteTapeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes the specified virtual tape. This operation is only supported in the tape gateway
 * type.
 */
export declare const deleteTape: API.OperationMethod<DeleteTapeInput & RegionInput, DeleteTapeOutput, DeleteTapeError, Credentials | HttpClient.HttpClient>;
export type DeleteTapeArchiveError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes the specified virtual tape from the virtual tape shelf (VTS). This operation is
 * only supported in the tape gateway type.
 */
export declare const deleteTapeArchive: API.OperationMethod<DeleteTapeArchiveInput & RegionInput, DeleteTapeArchiveOutput, DeleteTapeArchiveError, Credentials | HttpClient.HttpClient>;
export type DeleteTapePoolError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Delete a custom tape pool. A custom tape pool can only be deleted if there are no tapes
 * in the pool and if there are no automatic tape creation policies that reference the custom
 * tape pool.
 */
export declare const deleteTapePool: API.OperationMethod<DeleteTapePoolInput & RegionInput, DeleteTapePoolOutput, DeleteTapePoolError, Credentials | HttpClient.HttpClient>;
export type DeleteVolumeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Deletes the specified storage volume that you previously created using the CreateCachediSCSIVolume or CreateStorediSCSIVolume API.
 * This operation is only supported in the cached volume and stored volume types. For stored
 * volume gateways, the local disk that was configured as the storage volume is not deleted.
 * You can reuse the local disk to create another storage volume.
 *
 * Before you delete a volume, make sure there are no iSCSI connections to the volume you
 * are deleting. You should also make sure there is no snapshot in progress. You can use the
 * Amazon Elastic Compute Cloud (Amazon EC2) API to query snapshots on the volume you are
 * deleting and check the snapshot status. For more information, go to DescribeSnapshots in the Amazon Elastic Compute Cloud API
 * Reference.
 *
 * In the request, you must provide the Amazon Resource Name (ARN) of the storage volume
 * you want to delete.
 */
export declare const deleteVolume: API.OperationMethod<DeleteVolumeInput & RegionInput, DeleteVolumeOutput, DeleteVolumeError, Credentials | HttpClient.HttpClient>;
export type DescribeAvailabilityMonitorTestError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns information about the most recent high availability monitoring test that was
 * performed on the host in a cluster. If a test isn't performed, the status and start
 * time in the response would be null.
 */
export declare const describeAvailabilityMonitorTest: API.OperationMethod<DescribeAvailabilityMonitorTestInput & RegionInput, DescribeAvailabilityMonitorTestOutput, DescribeAvailabilityMonitorTestError, Credentials | HttpClient.HttpClient>;
export type DescribeBandwidthRateLimitError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns the bandwidth rate limits of a gateway. By default, these limits are not set,
 * which means no bandwidth rate limiting is in effect. This operation is supported only for
 * the stored volume, cached volume, and tape gateway types. To describe bandwidth rate limits
 * for S3 file gateways, use DescribeBandwidthRateLimitSchedule.
 *
 * This operation returns a value for a bandwidth rate limit only if the limit is set. If
 * no limits are set for the gateway, then this operation returns only the gateway ARN in the
 * response body. To specify which gateway to describe, use the Amazon Resource Name (ARN) of
 * the gateway in your request.
 */
export declare const describeBandwidthRateLimit: API.OperationMethod<DescribeBandwidthRateLimitInput & RegionInput, DescribeBandwidthRateLimitOutput, DescribeBandwidthRateLimitError, Credentials | HttpClient.HttpClient>;
export type DescribeBandwidthRateLimitScheduleError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns information about the bandwidth rate limit schedule of a gateway. By default,
 * gateways do not have bandwidth rate limit schedules, which means no bandwidth rate limiting
 * is in effect. This operation is supported only for volume, tape and S3 file gateways. FSx
 * file gateways do not support bandwidth rate limits.
 *
 * This operation returns information about a gateway's bandwidth rate limit schedule. A
 * bandwidth rate limit schedule consists of one or more bandwidth rate limit intervals. A
 * bandwidth rate limit interval defines a period of time on one or more days of the week,
 * during which bandwidth rate limits are specified for uploading, downloading, or both.
 *
 * A bandwidth rate limit interval consists of one or more days of the week, a start hour
 * and minute, an ending hour and minute, and bandwidth rate limits for uploading and
 * downloading
 *
 * If no bandwidth rate limit schedule intervals are set for the gateway, this operation
 * returns an empty response. To specify which gateway to describe, use the Amazon Resource
 * Name (ARN) of the gateway in your request.
 */
export declare const describeBandwidthRateLimitSchedule: API.OperationMethod<DescribeBandwidthRateLimitScheduleInput & RegionInput, DescribeBandwidthRateLimitScheduleOutput, DescribeBandwidthRateLimitScheduleError, Credentials | HttpClient.HttpClient>;
export type DescribeCacheError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns information about the cache of a gateway. This operation is only supported in
 * the cached volume, tape, and file gateway types.
 *
 * The response includes disk IDs that are configured as cache, and it includes the amount
 * of cache allocated and used.
 */
export declare const describeCache: API.OperationMethod<DescribeCacheInput & RegionInput, DescribeCacheOutput, DescribeCacheError, Credentials | HttpClient.HttpClient>;
export type DescribeCachediSCSIVolumesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns a description of the gateway volumes specified in the request. This operation is
 * only supported in the cached volume gateway types.
 *
 * The list of gateway volumes in the request must be from one gateway. In the response,
 * Storage Gateway returns volume information sorted by volume Amazon Resource Name
 * (ARN).
 */
export declare const describeCachediSCSIVolumes: API.OperationMethod<DescribeCachediSCSIVolumesInput & RegionInput, DescribeCachediSCSIVolumesOutput, DescribeCachediSCSIVolumesError, Credentials | HttpClient.HttpClient>;
export type DescribeCacheReportError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns information about the specified cache report, including completion status and
 * generation progress.
 */
export declare const describeCacheReport: API.OperationMethod<DescribeCacheReportInput & RegionInput, DescribeCacheReportOutput, DescribeCacheReportError, Credentials | HttpClient.HttpClient>;
export type DescribeChapCredentialsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns an array of Challenge-Handshake Authentication Protocol (CHAP) credentials
 * information for a specified iSCSI target, one for each target-initiator pair. This
 * operation is supported in the volume and tape gateway types.
 */
export declare const describeChapCredentials: API.OperationMethod<DescribeChapCredentialsInput & RegionInput, DescribeChapCredentialsOutput, DescribeChapCredentialsError, Credentials | HttpClient.HttpClient>;
export type DescribeFileSystemAssociationsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Gets the file system association information. This operation is only supported for FSx
 * File Gateways.
 */
export declare const describeFileSystemAssociations: API.OperationMethod<DescribeFileSystemAssociationsInput & RegionInput, DescribeFileSystemAssociationsOutput, DescribeFileSystemAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayInformationError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns metadata about a gateway such as its name, network interfaces, time zone,
 * status, and software version. To specify which gateway to describe, use the Amazon Resource
 * Name (ARN) of the gateway in your request.
 */
export declare const describeGatewayInformation: API.OperationMethod<DescribeGatewayInformationInput & RegionInput, DescribeGatewayInformationOutput, DescribeGatewayInformationError, Credentials | HttpClient.HttpClient>;
export type DescribeMaintenanceStartTimeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns your gateway's maintenance window schedule information, with values for
 * monthly or weekly cadence, specific day and time to begin maintenance, and which types of
 * updates to apply. Time values returned are for the gateway's time zone.
 */
export declare const describeMaintenanceStartTime: API.OperationMethod<DescribeMaintenanceStartTimeInput & RegionInput, DescribeMaintenanceStartTimeOutput, DescribeMaintenanceStartTimeError, Credentials | HttpClient.HttpClient>;
export type DescribeNFSFileSharesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Gets a description for one or more Network File System (NFS) file shares from an S3 File
 * Gateway. This operation is only supported for S3 File Gateways.
 */
export declare const describeNFSFileShares: API.OperationMethod<DescribeNFSFileSharesInput & RegionInput, DescribeNFSFileSharesOutput, DescribeNFSFileSharesError, Credentials | HttpClient.HttpClient>;
export type DescribeSMBFileSharesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Gets a description for one or more Server Message Block (SMB) file shares from a S3 File
 * Gateway. This operation is only supported for S3 File Gateways.
 */
export declare const describeSMBFileShares: API.OperationMethod<DescribeSMBFileSharesInput & RegionInput, DescribeSMBFileSharesOutput, DescribeSMBFileSharesError, Credentials | HttpClient.HttpClient>;
export type DescribeSMBSettingsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Gets a description of a Server Message Block (SMB) file share settings from a file
 * gateway. This operation is only supported for file gateways.
 */
export declare const describeSMBSettings: API.OperationMethod<DescribeSMBSettingsInput & RegionInput, DescribeSMBSettingsOutput, DescribeSMBSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeSnapshotScheduleError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Describes the snapshot schedule for the specified gateway volume. The snapshot schedule
 * information includes intervals at which snapshots are automatically initiated on the
 * volume. This operation is only supported in the cached volume and stored volume
 * types.
 */
export declare const describeSnapshotSchedule: API.OperationMethod<DescribeSnapshotScheduleInput & RegionInput, DescribeSnapshotScheduleOutput, DescribeSnapshotScheduleError, Credentials | HttpClient.HttpClient>;
export type DescribeStorediSCSIVolumesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns the description of the gateway volumes specified in the request. The list of
 * gateway volumes in the request must be from one gateway. In the response, Storage Gateway returns volume information sorted by volume ARNs. This operation is only
 * supported in stored volume gateway type.
 */
export declare const describeStorediSCSIVolumes: API.OperationMethod<DescribeStorediSCSIVolumesInput & RegionInput, DescribeStorediSCSIVolumesOutput, DescribeStorediSCSIVolumesError, Credentials | HttpClient.HttpClient>;
export type DescribeTapeArchivesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns a description of specified virtual tapes in the virtual tape shelf (VTS). This
 * operation is only supported in the tape gateway type.
 *
 * If a specific `TapeARN` is not specified, Storage Gateway returns a
 * description of all virtual tapes found in the VTS associated with your account.
 */
export declare const describeTapeArchives: API.PaginatedOperationMethod<DescribeTapeArchivesInput & RegionInput, DescribeTapeArchivesOutput, DescribeTapeArchivesError, Credentials | HttpClient.HttpClient, TapeArchive>;
export type DescribeTapeRecoveryPointsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns a list of virtual tape recovery points that are available for the specified tape
 * gateway.
 *
 * A recovery point is a point-in-time view of a virtual tape at which all the data on the
 * virtual tape is consistent. If your gateway crashes, virtual tapes that have recovery
 * points can be recovered to a new gateway. This operation is only supported in the tape
 * gateway type.
 */
export declare const describeTapeRecoveryPoints: API.PaginatedOperationMethod<DescribeTapeRecoveryPointsInput & RegionInput, DescribeTapeRecoveryPointsOutput, DescribeTapeRecoveryPointsError, Credentials | HttpClient.HttpClient, TapeRecoveryPointInfo>;
export type DescribeTapesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns a description of virtual tapes that correspond to the specified Amazon Resource
 * Names (ARNs). If `TapeARN` is not specified, returns a description of the
 * virtual tapes associated with the specified gateway. This operation is only supported for
 * the tape gateway type.
 *
 * The operation supports pagination. By default, the operation returns a maximum of up to
 * 100 tapes. You can optionally specify the `Limit` field in the body to limit the
 * number of tapes in the response. If the number of tapes returned in the response is
 * truncated, the response includes a `Marker` field. You can use this
 * `Marker` value in your subsequent request to retrieve the next set of
 * tapes.
 */
export declare const describeTapes: API.PaginatedOperationMethod<DescribeTapesInput & RegionInput, DescribeTapesOutput, DescribeTapesError, Credentials | HttpClient.HttpClient, Tape>;
export type DescribeUploadBufferError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns information about the upload buffer of a gateway. This operation is supported
 * for the stored volume, cached volume, and tape gateway types.
 *
 * The response includes disk IDs that are configured as upload buffer space, and it
 * includes the amount of upload buffer space allocated and used.
 */
export declare const describeUploadBuffer: API.OperationMethod<DescribeUploadBufferInput & RegionInput, DescribeUploadBufferOutput, DescribeUploadBufferError, Credentials | HttpClient.HttpClient>;
export type DescribeVTLDevicesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns a description of virtual tape library (VTL) devices for the specified tape
 * gateway. In the response, Storage Gateway returns VTL device information.
 *
 * This operation is only supported in the tape gateway type.
 */
export declare const describeVTLDevices: API.PaginatedOperationMethod<DescribeVTLDevicesInput & RegionInput, DescribeVTLDevicesOutput, DescribeVTLDevicesError, Credentials | HttpClient.HttpClient, VTLDevice>;
export type DescribeWorkingStorageError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns information about the working storage of a gateway. This operation is only
 * supported in the stored volumes gateway type. This operation is deprecated in cached
 * volumes API version (20120630). Use DescribeUploadBuffer instead.
 *
 * Working storage is also referred to as upload buffer. You can also use the
 * DescribeUploadBuffer operation to add upload buffer to a stored volume gateway.
 *
 * The response includes disk IDs that are configured as working storage, and it includes
 * the amount of working storage allocated and used.
 */
export declare const describeWorkingStorage: API.OperationMethod<DescribeWorkingStorageInput & RegionInput, DescribeWorkingStorageOutput, DescribeWorkingStorageError, Credentials | HttpClient.HttpClient>;
export type DetachVolumeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Disconnects a volume from an iSCSI connection and then detaches the volume from the
 * specified gateway. Detaching and attaching a volume enables you to recover your data from
 * one gateway to a different gateway without creating a snapshot. It also makes it easier to
 * move your volumes from an on-premises gateway to a gateway hosted on an Amazon EC2
 * instance. This operation is only supported in the volume gateway type.
 */
export declare const detachVolume: API.OperationMethod<DetachVolumeInput & RegionInput, DetachVolumeOutput, DetachVolumeError, Credentials | HttpClient.HttpClient>;
export type DisableGatewayError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Disables a tape gateway when the gateway is no longer functioning. For example, if your
 * gateway VM is damaged, you can disable the gateway so you can recover virtual tapes.
 *
 * Use this operation for a tape gateway that is not reachable or not functioning. This
 * operation is only supported in the tape gateway type.
 *
 * After a gateway is disabled, it cannot be enabled.
 */
export declare const disableGateway: API.OperationMethod<DisableGatewayInput & RegionInput, DisableGatewayOutput, DisableGatewayError, Credentials | HttpClient.HttpClient>;
export type DisassociateFileSystemError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Disassociates an Amazon FSx file system from the specified gateway. After the
 * disassociation process finishes, the gateway can no longer access the Amazon FSx
 * file system. This operation is only supported in the FSx File Gateway type.
 */
export declare const disassociateFileSystem: API.OperationMethod<DisassociateFileSystemInput & RegionInput, DisassociateFileSystemOutput, DisassociateFileSystemError, Credentials | HttpClient.HttpClient>;
export type EvictFilesFailingUploadError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Starts a process that cleans the specified file share's cache of file entries that are
 * failing upload to Amazon S3. This API operation reports success if the request is
 * received with valid arguments, and there are no other cache clean operations currently
 * in-progress for the specified file share. After a successful request, the cache clean
 * operation occurs asynchronously and reports progress using CloudWatch logs and
 * notifications.
 *
 * If `ForceRemove` is set to `True`, the cache clean operation
 * will delete file data from the gateway which might otherwise be recoverable. We
 * recommend using this operation only after all other methods to clear files failing
 * upload have been exhausted, and if your business need outweighs the potential data
 * loss.
 */
export declare const evictFilesFailingUpload: API.OperationMethod<EvictFilesFailingUploadInput & RegionInput, EvictFilesFailingUploadOutput, EvictFilesFailingUploadError, Credentials | HttpClient.HttpClient>;
export type JoinDomainError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Adds a file gateway to an Active Directory domain. This operation is only supported for
 * file gateways that support the SMB file protocol.
 *
 * Joining a domain creates an Active Directory computer account in the default
 * organizational unit, using the gateway's **Gateway ID** as
 * the account name (for example, SGW-1234ADE). If your Active Directory environment
 * requires that you pre-stage accounts to facilitate the join domain process, you will
 * need to create this account ahead of time.
 *
 * To create the gateway's computer account in an organizational unit other than the
 * default, you must specify the organizational unit when joining the domain.
 */
export declare const joinDomain: API.OperationMethod<JoinDomainInput & RegionInput, JoinDomainOutput, JoinDomainError, Credentials | HttpClient.HttpClient>;
export type ListAutomaticTapeCreationPoliciesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Lists the automatic tape creation policies for a gateway. If there are no automatic tape
 * creation policies for the gateway, it returns an empty list.
 *
 * This operation is only supported for tape gateways.
 */
export declare const listAutomaticTapeCreationPolicies: API.OperationMethod<ListAutomaticTapeCreationPoliciesInput & RegionInput, ListAutomaticTapeCreationPoliciesOutput, ListAutomaticTapeCreationPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListCacheReportsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns a list of existing cache reports for all file shares associated with your
 * Amazon Web Services account. This list includes all information provided by the
 * `DescribeCacheReport` action, such as report name, status, completion
 * progress, start time, end time, filters, and tags.
 */
export declare const listCacheReports: API.PaginatedOperationMethod<ListCacheReportsInput & RegionInput, ListCacheReportsOutput, ListCacheReportsError, Credentials | HttpClient.HttpClient, CacheReportInfo>;
export type ListFileSharesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Gets a list of the file shares for a specific S3 File Gateway, or the list of file
 * shares that belong to the calling Amazon Web Services account. This operation is only
 * supported for S3 File Gateways.
 */
export declare const listFileShares: API.PaginatedOperationMethod<ListFileSharesInput & RegionInput, ListFileSharesOutput, ListFileSharesError, Credentials | HttpClient.HttpClient, FileShareInfo>;
export type ListFileSystemAssociationsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Gets a list of `FileSystemAssociationSummary` objects. Each object contains a
 * summary of a file system association. This operation is only supported for FSx File
 * Gateways.
 */
export declare const listFileSystemAssociations: API.PaginatedOperationMethod<ListFileSystemAssociationsInput & RegionInput, ListFileSystemAssociationsOutput, ListFileSystemAssociationsError, Credentials | HttpClient.HttpClient, FileSystemAssociationSummary>;
export type ListGatewaysError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Lists gateways owned by an Amazon Web Services account in an Amazon Web Services Region
 * specified in the request. The returned list is ordered by gateway Amazon Resource Name
 * (ARN).
 *
 * By default, the operation returns a maximum of 100 gateways. This operation supports
 * pagination that allows you to optionally reduce the number of gateways returned in a
 * response.
 *
 * If you have more gateways than are returned in a response (that is, the response returns
 * only a truncated list of your gateways), the response contains a marker that you can
 * specify in your next request to fetch the next page of gateways.
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysInput & RegionInput, ListGatewaysOutput, ListGatewaysError, Credentials | HttpClient.HttpClient, GatewayInfo>;
export type ListLocalDisksError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Returns a list of the gateway's local disks. To specify which gateway to describe,
 * you use the Amazon Resource Name (ARN) of the gateway in the body of the request.
 *
 * The request returns a list of all disks, specifying which are configured as working
 * storage, cache storage, or stored volume or not configured at all. The response includes a
 * `DiskStatus` field. This field can have a value of present (the disk is
 * available to use), missing (the disk is no longer connected to the gateway), or mismatch
 * (the disk node is occupied by a disk that has incorrect metadata or the disk content is
 * corrupted).
 */
export declare const listLocalDisks: API.OperationMethod<ListLocalDisksInput & RegionInput, ListLocalDisksOutput, ListLocalDisksError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Lists the tags that have been added to the specified resource. This operation is
 * supported in storage gateways of all types.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListTapePoolsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Lists custom tape pools. You specify custom tape pools to list by specifying one or more
 * custom tape pool Amazon Resource Names (ARNs). If you don't specify a custom tape pool ARN,
 * the operation lists all custom tape pools.
 *
 * This operation supports pagination. You can optionally specify the `Limit`
 * parameter in the body to limit the number of tape pools in the response. If the number of
 * tape pools returned in the response is truncated, the response includes a
 * `Marker` element that you can use in your subsequent request to retrieve the
 * next set of tape pools.
 */
export declare const listTapePools: API.PaginatedOperationMethod<ListTapePoolsInput & RegionInput, ListTapePoolsOutput, ListTapePoolsError, Credentials | HttpClient.HttpClient, PoolInfo>;
export type ListTapesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Lists virtual tapes in your virtual tape library (VTL) and your virtual tape shelf
 * (VTS). You specify the tapes to list by specifying one or more tape Amazon Resource Names
 * (ARNs). If you don't specify a tape ARN, the operation lists all virtual tapes in both
 * your VTL and VTS.
 *
 * This operation supports pagination. By default, the operation returns a maximum of up to
 * 100 tapes. You can optionally specify the `Limit` parameter in the body to limit
 * the number of tapes in the response. If the number of tapes returned in the response is
 * truncated, the response includes a `Marker` element that you can use in your
 * subsequent request to retrieve the next set of tapes. This operation is only supported in
 * the tape gateway type.
 */
export declare const listTapes: API.PaginatedOperationMethod<ListTapesInput & RegionInput, ListTapesOutput, ListTapesError, Credentials | HttpClient.HttpClient, TapeInfo>;
export type ListVolumeInitiatorsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Lists iSCSI initiators that are connected to a volume. You can use this operation to
 * determine whether a volume is being used or not. This operation is only supported in the
 * cached volume and stored volume gateway types.
 */
export declare const listVolumeInitiators: API.OperationMethod<ListVolumeInitiatorsInput & RegionInput, ListVolumeInitiatorsOutput, ListVolumeInitiatorsError, Credentials | HttpClient.HttpClient>;
export type ListVolumeRecoveryPointsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Lists the recovery points for a specified gateway. This operation is only supported in
 * the cached volume gateway type.
 *
 * Each cache volume has one recovery point. A volume recovery point is a point in time at
 * which all data of the volume is consistent and from which you can create a snapshot or
 * clone a new cached volume from a source volume. To create a snapshot from a volume recovery
 * point use the CreateSnapshotFromVolumeRecoveryPoint operation.
 */
export declare const listVolumeRecoveryPoints: API.OperationMethod<ListVolumeRecoveryPointsInput & RegionInput, ListVolumeRecoveryPointsOutput, ListVolumeRecoveryPointsError, Credentials | HttpClient.HttpClient>;
export type ListVolumesError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Lists the iSCSI stored volumes of a gateway. Results are sorted by volume ARN. The
 * response includes only the volume ARNs. If you want additional volume information, use the
 * DescribeStorediSCSIVolumes or the DescribeCachediSCSIVolumes API.
 *
 * The operation supports pagination. By default, the operation returns a maximum of up to
 * 100 volumes. You can optionally specify the `Limit` field in the body to limit
 * the number of volumes in the response. If the number of volumes returned in the response is
 * truncated, the response includes a Marker field. You can use this Marker value in your
 * subsequent request to retrieve the next set of volumes. This operation is only supported in
 * the cached volume and stored volume gateway types.
 */
export declare const listVolumes: API.PaginatedOperationMethod<ListVolumesInput & RegionInput, ListVolumesOutput, ListVolumesError, Credentials | HttpClient.HttpClient, VolumeInfo>;
export type NotifyWhenUploadedError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Sends you notification through Amazon EventBridge when all files written to your file
 * share have been uploaded to Amazon S3.
 *
 * Storage Gateway can send a notification through Amazon EventBridge when all
 * files written to your file share up to that point in time have been uploaded to Amazon S3. These files include files written to the file share up to the time that you
 * make a request for notification. When the upload is done, Storage Gateway sends you
 * notification through EventBridge. You can configure EventBridge to send the
 * notification through event targets such as Amazon SNS or Lambda
 * function. This operation is only supported for S3 File Gateways.
 *
 * For more information, see Getting
 * file upload notification in the Amazon S3 File Gateway User
 * Guide.
 */
export declare const notifyWhenUploaded: API.OperationMethod<NotifyWhenUploadedInput & RegionInput, NotifyWhenUploadedOutput, NotifyWhenUploadedError, Credentials | HttpClient.HttpClient>;
export type RefreshCacheError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Refreshes the cached inventory of objects for the specified file share. This operation
 * finds objects in the Amazon S3 bucket that were added, removed, or replaced since
 * the gateway last listed the bucket's contents and cached the results. This operation
 * does not import files into the S3 File Gateway cache storage. It only updates the cached
 * inventory to reflect changes in the inventory of the objects in the S3 bucket. This
 * operation is only supported in the S3 File Gateway types.
 *
 * You can subscribe to be notified through an Amazon CloudWatch event when your
 * `RefreshCache` operation completes. For more information, see Getting
 * notified about file operations in the Amazon S3 File Gateway User
 * Guide. This operation is Only supported for S3 File Gateways.
 *
 * When this API is called, it only initiates the refresh operation. When the API call
 * completes and returns a success code, it doesn't necessarily mean that the file
 * refresh has completed. You should use the refresh-complete notification to determine that
 * the operation has completed before you check for new files on the gateway file share. You
 * can subscribe to be notified through a CloudWatch event when your `RefreshCache`
 * operation completes.
 *
 * Throttle limit: This API is asynchronous, so the gateway will accept no more than two
 * refreshes at any time. We recommend using the refresh-complete CloudWatch event
 * notification before issuing additional requests. For more information, see Getting
 * notified about file operations in the Amazon S3 File Gateway User
 * Guide.
 *
 * - Wait at least 60 seconds between consecutive RefreshCache API requests.
 *
 * - If you invoke the RefreshCache API when two requests are already being
 * processed, any new request will cause an
 * `InvalidGatewayRequestException` error because too many requests
 * were sent to the server.
 *
 * The S3 bucket name does not need to be included when entering the list of folders in
 * the FolderList parameter.
 *
 * For more information, see Getting
 * notified about file operations in the Amazon S3 File Gateway User
 * Guide.
 */
export declare const refreshCache: API.OperationMethod<RefreshCacheInput & RegionInput, RefreshCacheOutput, RefreshCacheError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Removes one or more tags from the specified resource. This operation is supported in
 * storage gateways of all types.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceInput & RegionInput, RemoveTagsFromResourceOutput, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetCacheError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Resets all cache disks that have encountered an error and makes the disks available for
 * reconfiguration as cache storage. If your cache disk encounters an error, the gateway
 * prevents read and write operations on virtual tapes in the gateway. For example, an error
 * can occur when a disk is corrupted or removed from the gateway. When a cache is reset, the
 * gateway loses its cache storage. At this point, you can reconfigure the disks as cache
 * disks. This operation is only supported in the cached volume and tape types.
 *
 * If the cache disk you are resetting contains data that has not been uploaded to
 * Amazon S3 yet, that data can be lost. After you reset cache disks, there will
 * be no configured cache disks left in the gateway, so you must configure at least one new
 * cache disk for your gateway to function properly.
 */
export declare const resetCache: API.OperationMethod<ResetCacheInput & RegionInput, ResetCacheOutput, ResetCacheError, Credentials | HttpClient.HttpClient>;
export type RetrieveTapeArchiveError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Retrieves an archived virtual tape from the virtual tape shelf (VTS) to a tape gateway.
 * Virtual tapes archived in the VTS are not associated with any gateway. However after a tape
 * is retrieved, it is associated with a gateway, even though it is also listed in the VTS,
 * that is, archive. This operation is only supported in the tape gateway type.
 *
 * Once a tape is successfully retrieved to a gateway, it cannot be retrieved again to
 * another gateway. You must archive the tape again before you can retrieve it to another
 * gateway. This operation is only supported in the tape gateway type.
 */
export declare const retrieveTapeArchive: API.OperationMethod<RetrieveTapeArchiveInput & RegionInput, RetrieveTapeArchiveOutput, RetrieveTapeArchiveError, Credentials | HttpClient.HttpClient>;
export type RetrieveTapeRecoveryPointError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Retrieves the recovery point for the specified virtual tape. This operation is only
 * supported in the tape gateway type.
 *
 * A recovery point is a point in time view of a virtual tape at which all the data on the
 * tape is consistent. If your gateway crashes, virtual tapes that have recovery points can be
 * recovered to a new gateway.
 *
 * The virtual tape can be retrieved to only one gateway. The retrieved tape is
 * read-only. The virtual tape can be retrieved to only a tape gateway. There is no charge
 * for retrieving recovery points.
 */
export declare const retrieveTapeRecoveryPoint: API.OperationMethod<RetrieveTapeRecoveryPointInput & RegionInput, RetrieveTapeRecoveryPointOutput, RetrieveTapeRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type SetLocalConsolePasswordError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Sets the password for your VM local console. When you log in to the local console for
 * the first time, you log in to the VM with the default credentials. We recommend that you
 * set a new password. You don't need to know the default password to set a new
 * password.
 */
export declare const setLocalConsolePassword: API.OperationMethod<SetLocalConsolePasswordInput & RegionInput, SetLocalConsolePasswordOutput, SetLocalConsolePasswordError, Credentials | HttpClient.HttpClient>;
export type SetSMBGuestPasswordError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Sets the password for the guest user `smbguest`. The `smbguest`
 * user is the user when the authentication method for the file share is set to
 * `GuestAccess`. This operation only supported for S3 File Gateways
 */
export declare const setSMBGuestPassword: API.OperationMethod<SetSMBGuestPasswordInput & RegionInput, SetSMBGuestPasswordOutput, SetSMBGuestPasswordError, Credentials | HttpClient.HttpClient>;
export type ShutdownGatewayError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Shuts down a Tape Gateway or Volume Gateway. To specify which gateway to shut down, use
 * the Amazon Resource Name (ARN) of the gateway in the body of your request.
 *
 * This API action cannot be used to shut down S3 File Gateway or FSx File
 * Gateway.
 *
 * The operation shuts down the gateway service component running in the gateway's
 * virtual machine (VM) and not the host VM.
 *
 * If you want to shut down the VM, it is recommended that you first shut down the
 * gateway component in the VM to avoid unpredictable conditions.
 *
 * After the gateway is shutdown, you cannot call any other API except StartGateway, DescribeGatewayInformation, and ListGateways. For more information, see ActivateGateway.
 * Your applications cannot read from or write to the gateway's storage volumes, and
 * there are no snapshots taken.
 *
 * When you make a shutdown request, you will get a `200 OK` success response
 * immediately. However, it might take some time for the gateway to shut down. You can call
 * the DescribeGatewayInformation API to check the status. For more
 * information, see ActivateGateway.
 *
 * If do not intend to use the gateway again, you must delete the gateway (using DeleteGateway) to no longer pay software charges associated with the
 * gateway.
 */
export declare const shutdownGateway: API.OperationMethod<ShutdownGatewayInput & RegionInput, ShutdownGatewayOutput, ShutdownGatewayError, Credentials | HttpClient.HttpClient>;
export type StartAvailabilityMonitorTestError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Start a test that verifies that the specified gateway is configured for High
 * Availability monitoring in your host environment. This request only initiates the test and
 * that a successful response only indicates that the test was started. It doesn't
 * indicate that the test passed. For the status of the test, invoke the
 * `DescribeAvailabilityMonitorTest` API.
 *
 * Starting this test will cause your gateway to go offline for a brief period.
 */
export declare const startAvailabilityMonitorTest: API.OperationMethod<StartAvailabilityMonitorTestInput & RegionInput, StartAvailabilityMonitorTestOutput, StartAvailabilityMonitorTestError, Credentials | HttpClient.HttpClient>;
export type StartCacheReportError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Starts generating a report of the file metadata currently cached by an S3 File Gateway for a specific file share. You can use this report to identify and resolve
 * issues if you have files failing upload from your gateway to Amazon S3. The report
 * is a CSV file containing a list of files which match the set of filter parameters you
 * specify in the request.
 *
 * The **Files Failing Upload** flag is reset every 24
 * hours and during gateway reboot. If this report captures the files after the reset, but
 * before they become flagged again, they will not be reported as **Files Failing Upload**.
 *
 * The following requirements must be met to successfully generate a cache report:
 *
 * - You must have `s3:PutObject` and `s3:AbortMultipartUpload`
 * permissions for the Amazon S3 bucket where you want to store the cache
 * report.
 *
 * - No other cache reports can currently be in-progress for the specified file
 * share.
 *
 * - There must be fewer than 10 existing cache reports for the specified file
 * share.
 *
 * - The gateway must be online and connected to Amazon Web Services.
 *
 * - The root disk must have at least 20GB of free space when report generation
 * starts.
 *
 * - You must specify at least one value for `InclusionFilters` or
 * `ExclusionFilters` in the request.
 */
export declare const startCacheReport: API.OperationMethod<StartCacheReportInput & RegionInput, StartCacheReportOutput, StartCacheReportError, Credentials | HttpClient.HttpClient>;
export type StartGatewayError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Starts a gateway that you previously shut down (see ShutdownGateway).
 * After the gateway starts, you can then make other API calls, your applications can read
 * from or write to the gateway's storage volumes and you will be able to take snapshot
 * backups.
 *
 * When you make a request, you will get a 200 OK success response immediately. However,
 * it might take some time for the gateway to be ready. You should call DescribeGatewayInformation and check the status before making any
 * additional API calls. For more information, see ActivateGateway.
 *
 * To specify which gateway to start, use the Amazon Resource Name (ARN) of the gateway in
 * your request.
 */
export declare const startGateway: API.OperationMethod<StartGatewayInput & RegionInput, StartGatewayOutput, StartGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomaticTapeCreationPolicyError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates the automatic tape creation policy of a gateway. Use this to update the policy
 * with a new set of automatic tape creation rules. This is only supported for tape
 * gateways.
 *
 * By default, there is no automatic tape creation policy.
 *
 * A gateway can have only one automatic tape creation policy.
 */
export declare const updateAutomaticTapeCreationPolicy: API.OperationMethod<UpdateAutomaticTapeCreationPolicyInput & RegionInput, UpdateAutomaticTapeCreationPolicyOutput, UpdateAutomaticTapeCreationPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateBandwidthRateLimitError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates the bandwidth rate limits of a gateway. You can update both the upload and
 * download bandwidth rate limit or specify only one of the two. If you don't set a
 * bandwidth rate limit, the existing rate limit remains. This operation is supported only for
 * the stored volume, cached volume, and tape gateway types. To update bandwidth rate limits
 * for S3 file gateways, use UpdateBandwidthRateLimitSchedule.
 *
 * By default, a gateway's bandwidth rate limits are not set. If you don't set
 * any limit, the gateway does not have any limitations on its bandwidth usage and could
 * potentially use the maximum available bandwidth.
 *
 * To specify which gateway to update, use the Amazon Resource Name (ARN) of the gateway in
 * your request.
 */
export declare const updateBandwidthRateLimit: API.OperationMethod<UpdateBandwidthRateLimitInput & RegionInput, UpdateBandwidthRateLimitOutput, UpdateBandwidthRateLimitError, Credentials | HttpClient.HttpClient>;
export type UpdateBandwidthRateLimitScheduleError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates the bandwidth rate limit schedule for a specified gateway. By default, gateways
 * do not have bandwidth rate limit schedules, which means no bandwidth rate limiting is in
 * effect. Use this to initiate or update a gateway's bandwidth rate limit schedule. This
 * operation is supported for volume, tape, and S3 file gateways. S3 file gateways support
 * bandwidth rate limits for upload only. FSx file gateways do not support bandwidth rate
 * limits.
 */
export declare const updateBandwidthRateLimitSchedule: API.OperationMethod<UpdateBandwidthRateLimitScheduleInput & RegionInput, UpdateBandwidthRateLimitScheduleOutput, UpdateBandwidthRateLimitScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateChapCredentialsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates the Challenge-Handshake Authentication Protocol (CHAP) credentials for a
 * specified iSCSI target. By default, a gateway does not have CHAP enabled; however, for
 * added security, you might use it. This operation is supported in the volume and tape
 * gateway types.
 *
 * When you update CHAP credentials, all existing connections on the target are closed
 * and initiators must reconnect with the new credentials.
 */
export declare const updateChapCredentials: API.OperationMethod<UpdateChapCredentialsInput & RegionInput, UpdateChapCredentialsOutput, UpdateChapCredentialsError, Credentials | HttpClient.HttpClient>;
export type UpdateFileSystemAssociationError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates a file system association. This operation is only supported in the FSx File
 * Gateways.
 */
export declare const updateFileSystemAssociation: API.OperationMethod<UpdateFileSystemAssociationInput & RegionInput, UpdateFileSystemAssociationOutput, UpdateFileSystemAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayInformationError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates a gateway's metadata, which includes the gateway's name, time zone,
 * and metadata cache size. To specify which gateway to update, use the Amazon Resource Name
 * (ARN) of the gateway in your request.
 *
 * For gateways activated after September 2, 2015, the gateway's ARN contains the
 * gateway ID rather than the gateway name. However, changing the name of the gateway has
 * no effect on the gateway's ARN.
 */
export declare const updateGatewayInformation: API.OperationMethod<UpdateGatewayInformationInput & RegionInput, UpdateGatewayInformationOutput, UpdateGatewayInformationError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewaySoftwareNowError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates the gateway virtual machine (VM) software. The request immediately triggers the
 * software update.
 *
 * When you make this request, you get a `200 OK` success response
 * immediately. However, it might take some time for the update to complete. You can call
 * DescribeGatewayInformation to verify the gateway is in the
 * `STATE_RUNNING` state.
 *
 * A software update forces a system restart of your gateway. You can minimize the
 * chance of any disruption to your applications by increasing your iSCSI Initiators'
 * timeouts. For more information about increasing iSCSI Initiator timeouts for Windows and
 * Linux, see Customizing your Windows iSCSI settings and Customizing your Linux iSCSI settings, respectively.
 */
export declare const updateGatewaySoftwareNow: API.OperationMethod<UpdateGatewaySoftwareNowInput & RegionInput, UpdateGatewaySoftwareNowOutput, UpdateGatewaySoftwareNowError, Credentials | HttpClient.HttpClient>;
export type UpdateMaintenanceStartTimeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates a gateway's maintenance window schedule, with settings for monthly or
 * weekly cadence, specific day and time to begin maintenance, and which types of updates to
 * apply. Time configuration uses the gateway's time zone. You can pass values for a complete
 * maintenance schedule, or update policy, or both. Previous values will persist for whichever
 * setting you choose not to modify. If an incomplete or invalid maintenance schedule is
 * passed, the entire request will be rejected with an error and no changes will occur.
 *
 * A complete maintenance schedule must include values for *both*
 * `MinuteOfHour` and `HourOfDay`, and *either*
 * `DayOfMonth`
 * *or*
 * `DayOfWeek`.
 *
 * We recommend keeping maintenance updates turned on, except in specific use cases
 * where the brief disruptions caused by updating the gateway could critically impact your
 * deployment.
 */
export declare const updateMaintenanceStartTime: API.OperationMethod<UpdateMaintenanceStartTimeInput & RegionInput, UpdateMaintenanceStartTimeOutput, UpdateMaintenanceStartTimeError, Credentials | HttpClient.HttpClient>;
export type UpdateNFSFileShareError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates a Network File System (NFS) file share. This operation is only supported in S3
 * File Gateways.
 *
 * To leave a file share field unchanged, set the corresponding input field to
 * null.
 *
 * Updates the following file share settings:
 *
 * - Default storage class for your S3 bucket
 *
 * - Metadata defaults for your S3 bucket
 *
 * - Allowed NFS clients for your file share
 *
 * - Squash settings
 *
 * - Write status of your file share
 */
export declare const updateNFSFileShare: API.OperationMethod<UpdateNFSFileShareInput & RegionInput, UpdateNFSFileShareOutput, UpdateNFSFileShareError, Credentials | HttpClient.HttpClient>;
export type UpdateSMBFileShareError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates a Server Message Block (SMB) file share. This operation is only supported for S3
 * File Gateways.
 *
 * To leave a file share field unchanged, set the corresponding input field to
 * null.
 *
 * File gateways require Security Token Service (Amazon Web Services STS) to be
 * activated to enable you to create a file share. Make sure that Amazon Web Services STS
 * is activated in the Amazon Web Services Region you are creating your file gateway in. If
 * Amazon Web Services STS is not activated in this Amazon Web Services Region, activate
 * it. For information about how to activate Amazon Web Services STS, see Activating and
 * deactivating Amazon Web Services STS in an Amazon Web Services Region in the
 * *Identity and Access Management User Guide*.
 *
 * File gateways don't support creating hard or symbolic links on a file
 * share.
 */
export declare const updateSMBFileShare: API.OperationMethod<UpdateSMBFileShareInput & RegionInput, UpdateSMBFileShareOutput, UpdateSMBFileShareError, Credentials | HttpClient.HttpClient>;
export type UpdateSMBFileShareVisibilityError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Controls whether the shares on an S3 File Gateway are visible in a net view or browse
 * list. The operation is only supported for S3 File Gateways.
 */
export declare const updateSMBFileShareVisibility: API.OperationMethod<UpdateSMBFileShareVisibilityInput & RegionInput, UpdateSMBFileShareVisibilityOutput, UpdateSMBFileShareVisibilityError, Credentials | HttpClient.HttpClient>;
export type UpdateSMBLocalGroupsError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates the list of Active Directory users and groups that have special permissions for
 * SMB file shares on the gateway.
 */
export declare const updateSMBLocalGroups: API.OperationMethod<UpdateSMBLocalGroupsInput & RegionInput, UpdateSMBLocalGroupsOutput, UpdateSMBLocalGroupsError, Credentials | HttpClient.HttpClient>;
export type UpdateSMBSecurityStrategyError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates the SMB security strategy level for an Amazon S3 file gateway. This
 * action is only supported for Amazon S3 file gateways.
 *
 * For information about configuring this setting using the Amazon Web Services console,
 * see Setting a security level for your gateway in the Amazon S3
 * File Gateway User Guide.
 *
 * A higher security strategy level can affect performance of the gateway.
 */
export declare const updateSMBSecurityStrategy: API.OperationMethod<UpdateSMBSecurityStrategyInput & RegionInput, UpdateSMBSecurityStrategyOutput, UpdateSMBSecurityStrategyError, Credentials | HttpClient.HttpClient>;
export type UpdateSnapshotScheduleError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates a snapshot schedule configured for a gateway volume. This operation is only
 * supported in the cached volume and stored volume gateway types.
 *
 * The default snapshot schedule for volume is once every 24 hours, starting at the
 * creation time of the volume. You can use this API to change the snapshot schedule
 * configured for the volume.
 *
 * In the request you must identify the gateway volume whose snapshot schedule you want to
 * update, and the schedule information, including when you want the snapshot to begin on a
 * day and the frequency (in hours) of snapshots.
 */
export declare const updateSnapshotSchedule: API.OperationMethod<UpdateSnapshotScheduleInput & RegionInput, UpdateSnapshotScheduleOutput, UpdateSnapshotScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateVTLDeviceTypeError = InternalServerError | InvalidGatewayRequestException | CommonErrors;
/**
 * Updates the type of medium changer in a tape gateway. When you activate a tape gateway,
 * you select a medium changer type for the tape gateway. This operation enables you to select
 * a different type of medium changer after a tape gateway is activated. This operation is
 * only supported in the tape gateway type.
 */
export declare const updateVTLDeviceType: API.OperationMethod<UpdateVTLDeviceTypeInput & RegionInput, UpdateVTLDeviceTypeOutput, UpdateVTLDeviceTypeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=storage-gateway.d.ts.map