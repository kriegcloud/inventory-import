import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface AddFieldForOrgRequestBodyCase0 {
    /** The ID of the IssueField to create the field for. */
    issue_field_id: number;
}
/** The field's data type. */
export type AddFieldForOrgRequestBodyCase1DataType = "text" | "number" | "date";
export interface AddFieldForOrgRequestBodyCase1 {
    /** The name of the field. */
    name: string;
    /** The field's data type. */
    data_type: AddFieldForOrgRequestBodyCase1DataType | (string & {});
}
/** The field's data type. */
export type AddFieldForOrgRequestBodyCase2DataType = "single_select";
/** The color associated with the option. */
export type ProjectsV2FieldSingleSelectOptionColor = "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
export interface ProjectsV2FieldSingleSelectOption {
    /** The display name of the option. */
    name?: string | undefined;
    /** The color associated with the option. */
    color?: ProjectsV2FieldSingleSelectOptionColor | (string & {}) | undefined;
    /** The description of the option. */
    description?: string | undefined;
}
/** The options available for single select fields. At least one option must be provided when creating a single select field. */
export type AddFieldForOrgRequestBodyCase2SingleSelectOptionsList = Array<ProjectsV2FieldSingleSelectOption>;
export interface AddFieldForOrgRequestBodyCase2 {
    /** The name of the field. */
    name: string;
    /** The field's data type. */
    data_type: AddFieldForOrgRequestBodyCase2DataType;
    /** The options available for single select fields. At least one option must be provided when creating a single select field. */
    single_select_options: AddFieldForOrgRequestBodyCase2SingleSelectOptionsList;
}
/** The field's data type. */
export type AddFieldForOrgRequestBodyCase3DataType = "iteration";
export interface ProjectsV2FieldIterationConfigurationIterationsItem {
    /** The title of the iteration. */
    title: string;
    /** The start date of the iteration. */
    start_date: string;
    /** The duration of the iteration in days. */
    duration: number;
}
/** Zero or more iterations for the field. */
export type ProjectsV2FieldIterationConfigurationIterationsList = Array<ProjectsV2FieldIterationConfigurationIterationsItem>;
/** The configuration for iteration fields. */
export interface ProjectsV2FieldIterationConfiguration {
    /** The start date of the first iteration. */
    start_date: string;
    /** The default duration for iterations in days. Individual iterations can override this value. */
    duration: number;
    /** Zero or more iterations for the field. */
    iterations?: ProjectsV2FieldIterationConfigurationIterationsList | undefined;
}
export interface AddFieldForOrgRequestBodyCase3 {
    /** The name of the field. */
    name: string;
    /** The field's data type. */
    data_type: AddFieldForOrgRequestBodyCase3DataType;
    iteration_configuration: ProjectsV2FieldIterationConfiguration;
}
export type AddFieldForOrgRequestBody = AddFieldForOrgRequestBodyCase0 | AddFieldForOrgRequestBodyCase1 | AddFieldForOrgRequestBodyCase2 | AddFieldForOrgRequestBodyCase3;
export interface AddFieldForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    body: AddFieldForOrgRequestBody;
}
/** The field's data type. */
export type ProjectsV2FieldDataType = "assignees" | "linked_pull_requests" | "reviewers" | "labels" | "milestone" | "repository" | "title" | "text" | "single_select" | "number" | "date" | "iteration" | "issue_type" | "parent_issue" | "sub_issues_progress";
/** The display name of the option, in raw text and HTML formats. */
export interface ProjectsV2SingleSelectOptionsName {
    raw: string;
    html: string;
}
/** The description of the option, in raw text and HTML formats. */
export type ProjectsV2SingleSelectOptionsDescription = ProjectsV2SingleSelectOptionsName;
/** An option for a single select field */
export interface ProjectsV2SingleSelectOptions {
    /** The unique identifier of the option. */
    id: string;
    /** The display name of the option, in raw text and HTML formats. */
    name: ProjectsV2SingleSelectOptionsName;
    /** The description of the option, in raw text and HTML formats. */
    description: ProjectsV2SingleSelectOptionsName;
    /** The color associated with the option. */
    color: string;
}
/** The options available for single select fields. */
export type ProjectsV2FieldOptionsList = Array<ProjectsV2SingleSelectOptions>;
/** The iteration title, in raw text and HTML formats. */
export type ProjectsV2IterationSettingsTitle = ProjectsV2SingleSelectOptionsName;
/** An iteration setting for an iteration field */
export interface ProjectsV2IterationSettings {
    /** The unique identifier of the iteration setting. */
    id: string;
    /** The start date of the iteration. */
    start_date: string;
    /** The duration of the iteration in days. */
    duration: number;
    /** The iteration title, in raw text and HTML formats. */
    title: ProjectsV2SingleSelectOptionsName;
    /** Whether the iteration has been completed. */
    completed: boolean;
}
export type ProjectsV2FieldConfigurationIterationsList = Array<ProjectsV2IterationSettings>;
/** Configuration for iteration fields. */
export interface ProjectsV2FieldConfiguration {
    /** The day of the week when the iteration starts. */
    start_day?: number | undefined;
    /** The duration of the iteration in days. */
    duration?: number | undefined;
    iterations?: ProjectsV2FieldConfigurationIterationsList | undefined;
}
/** A field inside a projects v2 project */
export interface ProjectsV2Field {
    /** The unique identifier of the field. */
    id: number;
    /** The ID of the issue field. */
    issue_field_id?: number | undefined;
    /** The node ID of the field. */
    node_id?: string | undefined;
    /** The API URL of the project that contains the field. */
    project_url: string;
    /** The name of the field. */
    name: string;
    /** The field's data type. */
    data_type: ProjectsV2FieldDataType;
    /** The options available for single select fields. */
    options?: ProjectsV2FieldOptionsList | undefined;
    /** Configuration for iteration fields. */
    configuration?: ProjectsV2FieldConfiguration | undefined;
    /** The time when the field was created. */
    created_at: string;
    /** The time when the field was last updated. */
    updated_at: string;
}
/** The field's data type. */
export type AddFieldForUserRequestBodyCase0DataType = "text" | "number" | "date";
export interface AddFieldForUserRequestBodyCase0 {
    /** The name of the field. */
    name: string;
    /** The field's data type. */
    data_type: AddFieldForUserRequestBodyCase0DataType | (string & {});
}
/** The field's data type. */
export type AddFieldForUserRequestBodyCase1DataType = "single_select";
/** The options available for single select fields. At least one option must be provided when creating a single select field. */
export type AddFieldForUserRequestBodyCase1SingleSelectOptionsList = Array<ProjectsV2FieldSingleSelectOption>;
export interface AddFieldForUserRequestBodyCase1 {
    /** The name of the field. */
    name: string;
    /** The field's data type. */
    data_type: AddFieldForUserRequestBodyCase1DataType;
    /** The options available for single select fields. At least one option must be provided when creating a single select field. */
    single_select_options: AddFieldForUserRequestBodyCase1SingleSelectOptionsList;
}
/** The field's data type. */
export type AddFieldForUserRequestBodyCase2DataType = "iteration";
export interface AddFieldForUserRequestBodyCase2 {
    /** The name of the field. */
    name: string;
    /** The field's data type. */
    data_type: AddFieldForUserRequestBodyCase2DataType;
    iteration_configuration: ProjectsV2FieldIterationConfiguration;
}
export type AddFieldForUserRequestBody = AddFieldForUserRequestBodyCase0 | AddFieldForUserRequestBodyCase1 | AddFieldForUserRequestBodyCase2;
export interface AddFieldForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    body: AddFieldForUserRequestBody;
}
/** The type of item to add to the project. Must be either Issue or PullRequest. */
export type AddItemForOrgRequestType = "Issue" | "PullRequest";
export interface AddItemForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The type of item to add to the project. Must be either Issue or PullRequest. */
    type: AddItemForOrgRequestType | (string & {});
    /** The unique identifier of the issue or pull request to add to the project. */
    id?: number | undefined;
    /** The repository owner login. */
    owner?: string | undefined;
    /** The repository name. */
    repo?: string | undefined;
    /** The issue or pull request number. */
    number?: number | undefined;
}
/** The reason for the current state */
export type IssueStateReason = "completed" | "reopened" | "not_planned" | "duplicate";
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
export interface IssueLabelsItemCase1 {
    id?: number | undefined;
    node_id?: string | undefined;
    url?: string | undefined;
    name?: string | undefined;
    description?: string | null | undefined;
    color?: string | null | undefined;
    default?: boolean | undefined;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by?: NullableSimpleUser | null | undefined;
}
export type IssueLabelsItem = string | IssueLabelsItemCase1;
/** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
export type IssueLabelsList = Array<IssueLabelsItem>;
export type IssueAssigneesList = Array<NullableSimpleUser>;
/** The state of the milestone. */
export type NullableMilestoneState = "open" | "closed";
/** A collection of related issues and pull requests. */
export interface NullableMilestone {
    url: string;
    html_url: string;
    labels_url: string;
    id: number;
    node_id: string;
    /** The number of the milestone. */
    number: number;
    /** The state of the milestone. */
    state: NullableMilestoneState;
    /** The title of the milestone. */
    title: string;
    description: string | null;
    creator: NullableSimpleUser | null;
    open_issues: number;
    closed_issues: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    due_on: string | null;
}
export interface IssuePullRequest {
    merged_at?: string | null | undefined;
    diff_url: string | null;
    html_url: string | null;
    patch_url: string | null;
    url: string | null;
}
/** The color of the issue type. */
export type IssueTypeColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
/** The type assigned to the issue. This is only present for issues in repositories where issue types are supported. */
export interface IssueType {
    /** The unique identifier of the issue type. */
    id: number;
    /** The node identifier of the issue type. */
    node_id: string;
    /** The name of the issue type. */
    name: string;
    /** The description of the issue type. */
    description: string | null;
    /** The color of the issue type. */
    color?: IssueTypeColor | null | undefined;
    /** The time the issue type created. */
    created_at?: string | undefined;
    /** The time the issue type last updated. */
    updated_at?: string | undefined;
    /** The enabled state of the issue type. */
    is_enabled?: boolean | undefined;
}
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: NullableSimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type NullableIntegrationOwner = NullableSimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export interface NullableIntegrationPermissions {
    issues?: string | undefined;
    checks?: string | undefined;
    metadata?: string | undefined;
    contents?: string | undefined;
    deployments?: string | undefined;
    [key: string]: unknown;
}
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type NullableIntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface NullableIntegration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: NullableIntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: NullableIntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: NullableIntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
export interface ReactionRollup {
    url: string;
    total_count: number;
    _1: number;
    _1_2: number;
    laugh: number;
    confused: number;
    heart: number;
    hooray: number;
    eyes: number;
    rocket: number;
}
export interface SubIssuesSummary {
    total: number;
    completed: number;
    percent_completed: number;
}
/** Context around who pinned an issue comment and when it was pinned. */
export interface NullablePinnedIssueComment {
    pinned_at: string;
    pinned_by: NullableSimpleUser | null;
}
/** Details about why an issue comment was minimized. */
export interface NullableIssueCommentMinimized {
    /** The reason the comment was minimized. */
    reason: string | null;
}
/** Comments provide a way for people to collaborate on an issue. */
export interface NullableIssueComment {
    /** Unique identifier of the issue comment */
    id: number;
    node_id: string;
    /** URL for the issue comment */
    url: string;
    /** Contents of the issue comment */
    body?: string | undefined;
    body_text?: string | undefined;
    body_html?: string | undefined;
    html_url: string;
    user: NullableSimpleUser | null;
    created_at: string;
    updated_at: string;
    issue_url: string;
    author_association?: AuthorAssociation | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    reactions?: ReactionRollup | undefined;
    pin?: NullablePinnedIssueComment | null | undefined;
    minimized?: NullableIssueCommentMinimized | null | undefined;
}
export interface IssueDependenciesSummary {
    blocked_by: number;
    blocking: number;
    total_blocked_by: number;
    total_blocking: number;
}
/** The data type of the issue field */
export type IssueFieldValueDataType = "text" | "single_select" | "multi_select" | "number" | "date";
/** The value of the issue field */
export type IssueFieldValueValue = string | number | number;
/** Details about the selected option (only present for single_select fields) */
export interface IssueFieldValueSingleSelectOption {
    /** Unique identifier for the option. */
    id: number;
    /** The name of the option */
    name: string;
    /** The color of the option */
    color: string;
}
export type IssueFieldValueMultiSelectOptionsItem = IssueFieldValueSingleSelectOption;
/** Details about the selected options */
export type IssueFieldValueMultiSelectOptionsList = Array<IssueFieldValueSingleSelectOption>;
/** A value assigned to an issue field */
export interface IssueFieldValue {
    /** Unique identifier for the issue field. */
    issue_field_id: number;
    /** The human-readable name of the issue field. */
    issue_field_name?: string | undefined;
    node_id: string;
    /** The data type of the issue field */
    data_type: IssueFieldValueDataType;
    /** The value of the issue field */
    value: IssueFieldValueValue | null;
    /** Details about the selected option (only present for single_select fields) */
    single_select_option?: IssueFieldValueSingleSelectOption | null | undefined;
    /** Details about the selected options */
    multi_select_options?: IssueFieldValueMultiSelectOptionsList | null | undefined;
}
export type IssueIssueFieldValuesList = Array<IssueFieldValue>;
/** Issues are a great way to keep track of tasks, enhancements, and bugs for your projects. */
export interface Issue {
    id: number;
    node_id: string;
    /** URL for the issue */
    url: string;
    repository_url: string;
    labels_url: string;
    comments_url: string;
    events_url: string;
    html_url: string;
    /** Number uniquely identifying the issue within its repository */
    number: number;
    /** State of the issue; either 'open' or 'closed' */
    state: string;
    /** The reason for the current state */
    state_reason?: IssueStateReason | null | undefined;
    /** Title of the issue */
    title: string;
    /** Contents of the issue */
    body?: string | null | undefined;
    user: NullableSimpleUser | null;
    /** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
    labels: IssueLabelsList;
    assignee: NullableSimpleUser | null;
    assignees?: IssueAssigneesList | undefined;
    milestone: NullableMilestone | null;
    locked: boolean;
    active_lock_reason?: string | null | undefined;
    comments: number;
    pull_request?: IssuePullRequest | undefined;
    closed_at: string | null;
    created_at: string;
    updated_at: string;
    draft?: boolean | undefined;
    closed_by?: NullableSimpleUser | null | undefined;
    body_html?: string | undefined;
    body_text?: string | undefined;
    timeline_url?: string | undefined;
    type?: IssueType | null | undefined;
    repository?: Repository | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    author_association?: AuthorAssociation | undefined;
    reactions?: ReactionRollup | undefined;
    sub_issues_summary?: SubIssuesSummary | undefined;
    /** URL to get the parent issue of this issue, if it is a sub-issue */
    parent_issue_url?: string | null | undefined;
    pinned_comment?: NullableIssueComment | null | undefined;
    issue_dependencies_summary?: IssueDependenciesSummary | undefined;
    issue_field_values?: IssueIssueFieldValuesList | undefined;
}
export interface PullRequestSimpleLabelsItem {
    id: number;
    node_id: string;
    url: string;
    name: string;
    description: string;
    color: string;
    default: boolean;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by: NullableSimpleUser | null;
}
export type PullRequestSimpleLabelsList = Array<PullRequestSimpleLabelsItem>;
export type PullRequestSimpleAssigneesList = Array<NullableSimpleUser>;
export type PullRequestSimpleRequestedReviewersList = Array<NullableSimpleUser>;
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
export type PullRequestSimpleRequestedTeamsList = Array<Team>;
export interface PullRequestSimpleHead {
    label: string;
    ref: string;
    repo: Repository;
    sha: string;
    user: NullableSimpleUser | null;
}
export type PullRequestSimpleBase = PullRequestSimpleHead;
/** Hypermedia Link */
export interface Link {
    href: string;
}
export interface PullRequestSimpleLinks {
    comments: Link;
    commits: Link;
    statuses: Link;
    html: Link;
    issue: Link;
    review_comments: Link;
    review_comment: Link;
    self: Link;
}
/** The merge method to use. */
export type AutoMergeMergeMethod = "merge" | "squash" | "rebase";
/** The status of auto merging a pull request. */
export interface AutoMerge {
    enabled_by: NullableSimpleUser;
    /** The merge method to use. */
    merge_method: AutoMergeMergeMethod;
    /** Title for the merge commit message. */
    commit_title: string;
    /** Commit message for the merge commit. */
    commit_message: string;
}
export interface PullRequestStackBase {
    /** The base ref of the stack this pull request belongs to. */
    ref: string;
    /** The base SHA of the stack this pull request belongs to. */
    sha: string;
}
/** The stack information associated with a pull request. */
export interface PullRequestStack {
    base: PullRequestStackBase;
    /** The total number of pull requests in the stack. */
    size?: number | undefined;
    /** The one-based position of this pull request within the stack, where 1 is the bottom of the stack. */
    position?: number | undefined;
    /** The ID of the stack that this pull request belongs to. */
    id?: number | undefined;
    /** The number of the stack that this pull request belongs to. */
    number?: number | undefined;
}
/** Pull Request Simple */
export interface PullRequestSimple {
    url: string;
    id: number;
    node_id: string;
    html_url: string;
    diff_url: string;
    patch_url: string;
    issue_url: string;
    commits_url: string;
    review_comments_url: string;
    review_comment_url: string;
    comments_url: string;
    statuses_url: string;
    number: number;
    state: string;
    locked: boolean;
    title: string;
    user: NullableSimpleUser | null;
    body: string | null;
    labels: PullRequestSimpleLabelsList;
    milestone: NullableMilestone | null;
    active_lock_reason?: string | null | undefined;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    merged_at: string | null;
    merge_commit_sha: string | null;
    assignee: NullableSimpleUser | null;
    assignees?: PullRequestSimpleAssigneesList | undefined;
    requested_reviewers?: PullRequestSimpleRequestedReviewersList | undefined;
    requested_teams?: PullRequestSimpleRequestedTeamsList | undefined;
    head: PullRequestSimpleHead;
    base: PullRequestSimpleHead;
    _links: PullRequestSimpleLinks;
    author_association: AuthorAssociation;
    auto_merge: AutoMerge | null;
    stack?: PullRequestStack | null | undefined;
    /** Indicates whether or not the pull request is a draft. */
    draft?: boolean | undefined;
}
/** A draft issue in a project */
export interface ProjectsV2DraftIssue {
    /** The ID of the draft issue */
    id: number;
    /** The node ID of the draft issue */
    node_id: string;
    /** The title of the draft issue */
    title: string;
    /** The body content of the draft issue */
    body?: string | null | undefined;
    user: NullableSimpleUser | null;
    /** The time the draft issue was created */
    created_at: string;
    /** The time the draft issue was last updated */
    updated_at: string;
}
/** The content represented by the item. */
export type ProjectsV2ItemSimpleContent = Issue | PullRequestSimple | ProjectsV2DraftIssue;
/** The type of content tracked in a project item */
export type ProjectsV2ItemContentType = "Issue" | "PullRequest" | "DraftIssue";
/** An item belonging to a project */
export interface ProjectsV2ItemSimple {
    /** The unique identifier of the project item. */
    id: number;
    /** The node ID of the project item. */
    node_id?: string | undefined;
    /** The content represented by the item. */
    content?: ProjectsV2ItemSimpleContent | undefined;
    content_type: ProjectsV2ItemContentType;
    creator?: NullableSimpleUser | undefined;
    /** The time when the item was created. */
    created_at: string;
    /** The time when the item was last updated. */
    updated_at: string;
    /** The time when the item was archived. */
    archived_at: string | null;
    /** The URL of the project this item belongs to. */
    project_url?: string | undefined;
    /** The URL of the item in the project. */
    item_url?: string | undefined;
}
/** The type of item to add to the project. Must be either Issue or PullRequest. */
export type AddItemForUserRequestType = "Issue" | "PullRequest";
export interface AddItemForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    /** The type of item to add to the project. Must be either Issue or PullRequest. */
    type: AddItemForUserRequestType | (string & {});
    /** The unique identifier of the issue or pull request to add to the project. */
    id?: number | undefined;
    /** The repository owner login. */
    owner?: string | undefined;
    /** The repository name. */
    repo?: string | undefined;
    /** The issue or pull request number. */
    number?: number | undefined;
}
export interface CreateDraftItemForAuthenticatedUserRequest {
    /** The unique identifier of the user. */
    user_id: string;
    /** The project's number. */
    project_number: number;
    /** The title of the draft issue item to create in the project. */
    title: string;
    /** The body content of the draft issue item to create in the project. */
    body?: string | undefined;
}
export interface CreateDraftItemForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The title of the draft issue item to create in the project. */
    title: string;
    /** The body content of the draft issue item to create in the project. */
    body?: string | undefined;
}
/** The layout of the view. */
export type CreateViewForOrgRequestLayout = "table" | "board" | "roadmap";
/** `visible_fields` is not applicable to `roadmap` layout views. For `table` and `board` layouts, this represents the field IDs that should be visible in the view. If not provided, the default visible fields will be used. */
export type CreateViewForOrgRequestVisibleFieldsList = Array<number>;
export type CreateViewForOrgRequestSortByItemItem = number | string;
export type CreateViewForOrgRequestSortByItemList = Array<CreateViewForOrgRequestSortByItemItem>;
/** Sorting configuration for the view. Each element is a two-element array of `[field_id, direction]` where `direction` is `"asc"` or `"desc"`. Supports multiple sort criteria applied in order. */
export type CreateViewForOrgRequestSortByList = Array<CreateViewForOrgRequestSortByItemList>;
/** The field IDs to group items by (horizontal grouping). Supports a single field. The field must support grouping; fields such as `Title`, `Reviewers`, `Linked pull requests`, `Sub-issues progress`, `Tracked by`, and `Tracks` cannot be grouped on. */
export type CreateViewForOrgRequestGroupByList = Array<number>;
/** The field IDs to use as columns in `board` layout (vertical grouping). Supports a single field. The field must support grouping; fields such as `Title`, `Reviewers`, `Linked pull requests`, `Sub-issues progress`, `Tracked by`, and `Tracks` cannot be grouped on. */
export type CreateViewForOrgRequestVerticalGroupByList = Array<number>;
export interface CreateViewForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The name of the view. */
    name: string;
    /** The layout of the view. */
    layout: CreateViewForOrgRequestLayout | (string & {});
    /** The filter query for the view. See [Filtering projects](https://docs.github.com/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/filtering-projects) for more information. */
    filter?: string | undefined;
    /** `visible_fields` is not applicable to `roadmap` layout views. For `table` and `board` layouts, this represents the field IDs that should be visible in the view. If not provided, the default visible fields will be used. */
    visible_fields?: CreateViewForOrgRequestVisibleFieldsList | undefined;
    /** Sorting configuration for the view. Each element is a two-element array of `[field_id, direction]` where `direction` is `"asc"` or `"desc"`. Supports multiple sort criteria applied in order. */
    sort_by?: CreateViewForOrgRequestSortByList | undefined;
    /** The field IDs to group items by (horizontal grouping). Supports a single field. The field must support grouping; fields such as `Title`, `Reviewers`, `Linked pull requests`, `Sub-issues progress`, `Tracked by`, and `Tracks` cannot be grouped on. */
    group_by?: CreateViewForOrgRequestGroupByList | undefined;
    /** The field IDs to use as columns in `board` layout (vertical grouping). Supports a single field. The field must support grouping; fields such as `Title`, `Reviewers`, `Linked pull requests`, `Sub-issues progress`, `Tracked by`, and `Tracks` cannot be grouped on. */
    vertical_group_by?: CreateViewForOrgRequestVerticalGroupByList | undefined;
}
/** The layout of the view. */
export type ProjectsV2ViewLayout = "table" | "board" | "roadmap";
/** The list of field IDs that are visible in the view. */
export type ProjectsV2ViewVisibleFieldsList = Array<number>;
export type ProjectsV2ViewSortByItemItem = number | string;
export type ProjectsV2ViewSortByItemList = Array<ProjectsV2ViewSortByItemItem>;
/** The sorting configuration for the view. Each element is a tuple of [field_id, direction] where direction is "asc" or "desc". */
export type ProjectsV2ViewSortByList = Array<ProjectsV2ViewSortByItemList>;
/** The list of field IDs used for horizontal grouping. */
export type ProjectsV2ViewGroupByList = Array<number>;
/** The list of field IDs used for vertical grouping (board layout). */
export type ProjectsV2ViewVerticalGroupByList = Array<number>;
/** A view inside a projects v2 project */
export interface ProjectsV2View {
    /** The unique identifier of the view. */
    id: number;
    /** The number of the view within the project. */
    number: number;
    /** The name of the view. */
    name: string;
    /** The layout of the view. */
    layout: ProjectsV2ViewLayout;
    /** The node ID of the view. */
    node_id: string;
    /** The API URL of the project that contains the view. */
    project_url: string;
    /** The web URL of the view. */
    html_url: string;
    creator: NullableSimpleUser;
    /** The time when the view was created. */
    created_at: string;
    /** The time when the view was last updated. */
    updated_at: string;
    /** The filter query for the view. */
    filter?: string | null | undefined;
    /** The list of field IDs that are visible in the view. */
    visible_fields: ProjectsV2ViewVisibleFieldsList;
    /** The sorting configuration for the view. Each element is a tuple of [field_id, direction] where direction is "asc" or "desc". */
    sort_by: ProjectsV2ViewSortByList;
    /** The list of field IDs used for horizontal grouping. */
    group_by: ProjectsV2ViewGroupByList;
    /** The list of field IDs used for vertical grouping (board layout). */
    vertical_group_by: ProjectsV2ViewVerticalGroupByList;
}
/** The layout of the view. */
export type CreateViewForUserRequestLayout = "table" | "board" | "roadmap";
/** `visible_fields` is not applicable to `roadmap` layout views. For `table` and `board` layouts, this represents the field IDs that should be visible in the view. If not provided, the default visible fields will be used. */
export type CreateViewForUserRequestVisibleFieldsList = Array<number>;
export type CreateViewForUserRequestSortByItemItem = number | string;
export type CreateViewForUserRequestSortByItemList = Array<CreateViewForUserRequestSortByItemItem>;
/** Sorting configuration for the view. Each element is a two-element array of `[field_id, direction]` where `direction` is `"asc"` or `"desc"`. Supports multiple sort criteria applied in order. */
export type CreateViewForUserRequestSortByList = Array<CreateViewForUserRequestSortByItemList>;
/** The field IDs to group items by (horizontal grouping). Supports a single field. The field must support grouping; fields such as `Title`, `Reviewers`, `Linked pull requests`, `Sub-issues progress`, `Tracked by`, and `Tracks` cannot be grouped on. */
export type CreateViewForUserRequestGroupByList = Array<number>;
/** The field IDs to use as columns in `board` layout (vertical grouping). Supports a single field. The field must support grouping; fields such as `Title`, `Reviewers`, `Linked pull requests`, `Sub-issues progress`, `Tracked by`, and `Tracks` cannot be grouped on. */
export type CreateViewForUserRequestVerticalGroupByList = Array<number>;
export interface CreateViewForUserRequest {
    /** The unique identifier of the user. */
    user_id: string;
    /** The project's number. */
    project_number: number;
    /** The name of the view. */
    name: string;
    /** The layout of the view. */
    layout: CreateViewForUserRequestLayout | (string & {});
    /** The filter query for the view. See [Filtering projects](https://docs.github.com/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/filtering-projects) for more information. */
    filter?: string | undefined;
    /** `visible_fields` is not applicable to `roadmap` layout views. For `table` and `board` layouts, this represents the field IDs that should be visible in the view. If not provided, the default visible fields will be used. */
    visible_fields?: CreateViewForUserRequestVisibleFieldsList | undefined;
    /** Sorting configuration for the view. Each element is a two-element array of `[field_id, direction]` where `direction` is `"asc"` or `"desc"`. Supports multiple sort criteria applied in order. */
    sort_by?: CreateViewForUserRequestSortByList | undefined;
    /** The field IDs to group items by (horizontal grouping). Supports a single field. The field must support grouping; fields such as `Title`, `Reviewers`, `Linked pull requests`, `Sub-issues progress`, `Tracked by`, and `Tracks` cannot be grouped on. */
    group_by?: CreateViewForUserRequestGroupByList | undefined;
    /** The field IDs to use as columns in `board` layout (vertical grouping). Supports a single field. The field must support grouping; fields such as `Title`, `Reviewers`, `Linked pull requests`, `Sub-issues progress`, `Tracked by`, and `Tracks` cannot be grouped on. */
    vertical_group_by?: CreateViewForUserRequestVerticalGroupByList | undefined;
}
export interface DeleteItemForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The unique identifier of the project item. */
    item_id: number;
}
export interface DeleteItemForOrgResponse {
}
export interface DeleteItemForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    /** The unique identifier of the project item. */
    item_id: number;
}
export interface DeleteItemForUserResponse {
}
export interface GetFieldForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The unique identifier of the field. */
    field_id: number;
}
export interface GetFieldForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    /** The unique identifier of the field. */
    field_id: number;
}
export interface GetForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
}
/** The current state of the project. */
export type ProjectsV2State = "open" | "closed";
/** The current status. */
export type NullableProjectsV2StatusUpdateStatus = "INACTIVE" | "ON_TRACK" | "AT_RISK" | "OFF_TRACK" | "COMPLETE";
/** An status update belonging to a project */
export interface NullableProjectsV2StatusUpdate {
    /** The unique identifier of the status update. */
    id: number;
    /** The node ID of the status update. */
    node_id: string;
    /** The node ID of the project that this status update belongs to. */
    project_node_id?: string | undefined;
    creator?: NullableSimpleUser | undefined;
    /** The time when the status update was created. */
    created_at: string;
    /** The time when the status update was last updated. */
    updated_at: string;
    /** The current status. */
    status?: NullableProjectsV2StatusUpdateStatus | null | undefined;
    /** The start date of the period covered by the update. */
    start_date?: string | undefined;
    /** The target date associated with the update. */
    target_date?: string | undefined;
    /** Body of the status update */
    body?: string | null | undefined;
}
/** A projects v2 project */
export interface ProjectsV2 {
    /** The unique identifier of the project. */
    id: number;
    /** The node ID of the project. */
    node_id: string;
    owner: NullableSimpleUser;
    creator: NullableSimpleUser;
    /** The project title. */
    title: string;
    /** A short description of the project. */
    description: string | null;
    /** Whether the project is visible to anyone with access to the owner. */
    public: boolean;
    /** The time when the project was closed. */
    closed_at: string | null;
    /** The time when the project was created. */
    created_at: string;
    /** The time when the project was last updated. */
    updated_at: string;
    /** The project number. */
    number: number;
    /** A concise summary of the project. */
    short_description: string | null;
    /** The time when the project was deleted. */
    deleted_at: string | null;
    deleted_by: NullableSimpleUser | null;
    /** The current state of the project. */
    state?: ProjectsV2State | undefined;
    latest_status_update?: NullableProjectsV2StatusUpdate | null | undefined;
    /** Whether this project is a template */
    is_template?: boolean | undefined;
}
export interface GetForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
}
export type GetOrgItemRequestFieldsCase1List = Array<string>;
export type GetOrgItemRequestFields = string | GetOrgItemRequestFieldsCase1List;
export interface GetOrgItemRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The unique identifier of the project item. */
    item_id: number;
    /** Limit results to specific fields, by their IDs. If not specified, the title field will be returned. Example: fields[]=123&fields[]=456&fields[]=789 or fields=123,456,789 */
    fields?: GetOrgItemRequestFields | undefined;
}
/** The content of the item, which varies by content type. */
export type ProjectsV2ItemWithContentContentMap = {
    [key: string]: unknown | undefined;
};
export type ProjectsV2ItemWithContentFieldsItemMap = {
    [key: string]: unknown | undefined;
};
/** The fields and values associated with this item. */
export type ProjectsV2ItemWithContentFieldsList = Array<ProjectsV2ItemWithContentFieldsItemMap>;
/** An item belonging to a project */
export interface ProjectsV2ItemWithContent {
    /** The unique identifier of the project item. */
    id: number;
    /** The node ID of the project item. */
    node_id?: string | undefined;
    /** The API URL of the project that contains this item. */
    project_url?: string | undefined;
    content_type: ProjectsV2ItemContentType;
    /** The content of the item, which varies by content type. */
    content?: ProjectsV2ItemWithContentContentMap | null | undefined;
    creator?: NullableSimpleUser | undefined;
    /** The time when the item was created. */
    created_at: string;
    /** The time when the item was last updated. */
    updated_at: string;
    /** The time when the item was archived. */
    archived_at: string | null;
    /** The API URL of this item. */
    item_url?: string | null | undefined;
    /** The fields and values associated with this item. */
    fields?: ProjectsV2ItemWithContentFieldsList | undefined;
}
export type GetUserItemRequestFieldsCase1List = Array<string>;
export type GetUserItemRequestFields = string | GetUserItemRequestFieldsCase1List;
export interface GetUserItemRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    /** The unique identifier of the project item. */
    item_id: number;
    /** Limit results to specific fields, by their IDs. If not specified, the title field will be returned. Example: fields[]=123&fields[]=456&fields[]=789 or fields=123,456,789 */
    fields?: GetUserItemRequestFields | undefined;
}
export interface ListFieldsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
}
export type ListFieldsForOrgResponseBodyList = Array<ProjectsV2Field>;
export type ListFieldsForOrgResponse = ListFieldsForOrgResponseBodyList;
export interface ListFieldsForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
}
export type ListFieldsForUserResponseBodyList = Array<ProjectsV2Field>;
export type ListFieldsForUserResponse = ListFieldsForUserResponseBodyList;
export interface ListForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Limit results to projects of the specified type. */
    q?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListForOrgResponseBodyList = Array<ProjectsV2>;
export type ListForOrgResponse = ListForOrgResponseBodyList;
export interface ListForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** Limit results to projects of the specified type. */
    q?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListForUserResponseBodyList = Array<ProjectsV2>;
export type ListForUserResponse = ListForUserResponseBodyList;
export type ListItemsForOrgRequestFieldsCase1List = Array<string>;
export type ListItemsForOrgRequestFields = string | ListItemsForOrgRequestFieldsCase1List;
export interface ListItemsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** Search query to filter items, see [Filtering projects](https://docs.github.com/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/filtering-projects) for more information. */
    q?: string | undefined;
    /** Limit results to specific fields, by their IDs. If not specified, the title field will be returned. Example: `fields[]=123&fields[]=456&fields[]=789` or `fields=123,456,789` */
    fields?: ListItemsForOrgRequestFields | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListItemsForOrgResponseBodyList = Array<ProjectsV2ItemWithContent>;
export type ListItemsForOrgResponse = ListItemsForOrgResponseBodyList;
export type ListItemsForUserRequestFieldsCase1List = Array<string>;
export type ListItemsForUserRequestFields = string | ListItemsForUserRequestFieldsCase1List;
export interface ListItemsForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** Search query to filter items, see [Filtering projects](https://docs.github.com/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/filtering-projects) for more information. */
    q?: string | undefined;
    /** Limit results to specific fields, by their IDs. If not specified, the title field will be returned. Example: `fields[]=123&fields[]=456&fields[]=789` or `fields=123,456,789` */
    fields?: ListItemsForUserRequestFields | undefined;
}
export type ListItemsForUserResponseBodyList = Array<ProjectsV2ItemWithContent>;
export type ListItemsForUserResponse = ListItemsForUserResponseBodyList;
export type ListViewItemsForOrgRequestFieldsCase1List = Array<string>;
export type ListViewItemsForOrgRequestFields = string | ListViewItemsForOrgRequestFieldsCase1List;
export interface ListViewItemsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The number that identifies the project view. */
    view_number: number;
    /** Limit results to specific fields, by their IDs. If not specified, the title field will be returned. Example: `fields[]=123&fields[]=456&fields[]=789` or `fields=123,456,789` */
    fields?: ListViewItemsForOrgRequestFields | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListViewItemsForOrgResponseBodyList = Array<ProjectsV2ItemWithContent>;
export type ListViewItemsForOrgResponse = ListViewItemsForOrgResponseBodyList;
export type ListViewItemsForUserRequestFieldsCase1List = Array<string>;
export type ListViewItemsForUserRequestFields = string | ListViewItemsForUserRequestFieldsCase1List;
export interface ListViewItemsForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    /** The number that identifies the project view. */
    view_number: number;
    /** Limit results to specific fields, by their IDs. If not specified, the title field will be returned. Example: `fields[]=123&fields[]=456&fields[]=789` or `fields=123,456,789` */
    fields?: ListViewItemsForUserRequestFields | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListViewItemsForUserResponseBodyList = Array<ProjectsV2ItemWithContent>;
export type ListViewItemsForUserResponse = ListViewItemsForUserResponseBodyList;
/** The new value for the field: - For text, number, and date fields, provide the new value directly. - For single select and iteration fields, provide the ID of the option or iteration. - To clear the field, set this to null. */
export type UpdateItemForOrgRequestFieldsItemValue = string | number;
export interface UpdateItemForOrgRequestFieldsItem {
    /** The ID of the project field to update. */
    id: number;
    /** The new value for the field: - For text, number, and date fields, provide the new value directly. - For single select and iteration fields, provide the ID of the option or iteration. - To clear the field, set this to null. */
    value: UpdateItemForOrgRequestFieldsItemValue | null;
}
/** A list of field updates to apply. */
export type UpdateItemForOrgRequestFieldsList = Array<UpdateItemForOrgRequestFieldsItem>;
export interface UpdateItemForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The project's number. */
    project_number: number;
    /** The unique identifier of the project item. */
    item_id: number;
    /** A list of field updates to apply. */
    fields: UpdateItemForOrgRequestFieldsList;
}
/** The new value for the field: - For text, number, and date fields, provide the new value directly. - For single select and iteration fields, provide the ID of the option or iteration. - To clear the field, set this to null. */
export type UpdateItemForUserRequestFieldsItemValue = string | number;
export interface UpdateItemForUserRequestFieldsItem {
    /** The ID of the project field to update. */
    id: number;
    /** The new value for the field: - For text, number, and date fields, provide the new value directly. - For single select and iteration fields, provide the ID of the option or iteration. - To clear the field, set this to null. */
    value: UpdateItemForUserRequestFieldsItemValue | null;
}
/** A list of field updates to apply. */
export type UpdateItemForUserRequestFieldsList = Array<UpdateItemForUserRequestFieldsItem>;
export interface UpdateItemForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The project's number. */
    project_number: number;
    /** The unique identifier of the project item. */
    item_id: number;
    /** A list of field updates to apply. */
    fields: UpdateItemForUserRequestFieldsList;
}
export type AddFieldForOrgError = GithubOpError;
/** Add a field to an organization-owned project. Add a field to an organization-owned project. */
export declare const addFieldForOrg: API.OperationMethod<AddFieldForOrgRequest, ProjectsV2Field, AddFieldForOrgError, GithubOpContext>;
export type AddFieldForUserError = GithubOpError;
/** Add field to user owned project Add a field to a specified user owned project. */
export declare const addFieldForUser: API.OperationMethod<AddFieldForUserRequest, ProjectsV2Field, AddFieldForUserError, GithubOpContext>;
export type AddItemForOrgError = GithubOpError;
/** Add item to organization owned project Add an issue or pull request item to the specified organization owned project. */
export declare const addItemForOrg: API.OperationMethod<AddItemForOrgRequest, ProjectsV2ItemSimple, AddItemForOrgError, GithubOpContext>;
export type AddItemForUserError = GithubOpError;
/** Add item to user owned project Add an issue or pull request item to the specified user owned project. */
export declare const addItemForUser: API.OperationMethod<AddItemForUserRequest, ProjectsV2ItemSimple, AddItemForUserError, GithubOpContext>;
export type CreateDraftItemForAuthenticatedUserError = GithubOpError;
/** Create draft item for user owned project Create draft issue item for the specified user owned project. */
export declare const createDraftItemForAuthenticatedUser: API.OperationMethod<CreateDraftItemForAuthenticatedUserRequest, ProjectsV2ItemSimple, CreateDraftItemForAuthenticatedUserError, GithubOpContext>;
export type CreateDraftItemForOrgError = GithubOpError;
/** Create draft item for organization owned project Create draft issue item for the specified organization owned project. */
export declare const createDraftItemForOrg: API.OperationMethod<CreateDraftItemForOrgRequest, ProjectsV2ItemSimple, CreateDraftItemForOrgError, GithubOpContext>;
export type CreateViewForOrgError = GithubOpError;
/** Create a view for an organization-owned project Create a new view in an organization-owned project. Views allow you to customize how items in a project are displayed and filtered. */
export declare const createViewForOrg: API.OperationMethod<CreateViewForOrgRequest, ProjectsV2View, CreateViewForOrgError, GithubOpContext>;
export type CreateViewForUserError = GithubOpError;
/** Create a view for a user-owned project Create a new view in a user-owned project. Views allow you to customize how items in a project are displayed and filtered. */
export declare const createViewForUser: API.OperationMethod<CreateViewForUserRequest, ProjectsV2View, CreateViewForUserError, GithubOpContext>;
export type DeleteItemForOrgError = GithubOpError;
/** Delete project item for organization Delete a specific item from an organization-owned project. */
export declare const deleteItemForOrg: API.OperationMethod<DeleteItemForOrgRequest, DeleteItemForOrgResponse, DeleteItemForOrgError, GithubOpContext>;
export type DeleteItemForUserError = GithubOpError;
/** Delete project item for user Delete a specific item from a user-owned project. */
export declare const deleteItemForUser: API.OperationMethod<DeleteItemForUserRequest, DeleteItemForUserResponse, DeleteItemForUserError, GithubOpContext>;
export type GetFieldForOrgError = GithubOpError;
/** Get project field for organization Get a specific field for an organization-owned project. */
export declare const getFieldForOrg: API.OperationMethod<GetFieldForOrgRequest, ProjectsV2Field, GetFieldForOrgError, GithubOpContext>;
export type GetFieldForUserError = GithubOpError;
/** Get project field for user Get a specific field for a user-owned project. */
export declare const getFieldForUser: API.OperationMethod<GetFieldForUserRequest, ProjectsV2Field, GetFieldForUserError, GithubOpContext>;
export type GetForOrgError = GithubOpError;
/** Get project for organization Get a specific organization-owned project. */
export declare const getForOrg: API.OperationMethod<GetForOrgRequest, ProjectsV2, GetForOrgError, GithubOpContext>;
export type GetForUserError = GithubOpError;
/** Get project for user Get a specific user-owned project. */
export declare const getForUser: API.OperationMethod<GetForUserRequest, ProjectsV2, GetForUserError, GithubOpContext>;
export type GetOrgItemError = GithubOpError;
/** Get an item for an organization owned project Get a specific item from an organization-owned project. */
export declare const getOrgItem: API.OperationMethod<GetOrgItemRequest, ProjectsV2ItemWithContent, GetOrgItemError, GithubOpContext>;
export type GetUserItemError = GithubOpError;
/** Get an item for a user owned project Get a specific item from a user-owned project. */
export declare const getUserItem: API.OperationMethod<GetUserItemRequest, ProjectsV2ItemWithContent, GetUserItemError, GithubOpContext>;
export type ListFieldsForOrgError = GithubOpError;
/** List project fields for organization List all fields for a specific organization-owned project. */
export declare const listFieldsForOrg: API.OperationMethod<ListFieldsForOrgRequest, ListFieldsForOrgResponse, ListFieldsForOrgError, GithubOpContext>;
export type ListFieldsForUserError = GithubOpError;
/** List project fields for user List all fields for a specific user-owned project. */
export declare const listFieldsForUser: API.OperationMethod<ListFieldsForUserRequest, ListFieldsForUserResponse, ListFieldsForUserError, GithubOpContext>;
export type ListForOrgError = GithubOpError;
/** List projects for organization List all projects owned by a specific organization accessible by the authenticated user. */
export declare const listForOrg: API.OperationMethod<ListForOrgRequest, ListForOrgResponse, ListForOrgError, GithubOpContext>;
export type ListForUserError = GithubOpError;
/** List projects for user List all projects owned by a specific user accessible by the authenticated user. */
export declare const listForUser: API.OperationMethod<ListForUserRequest, ListForUserResponse, ListForUserError, GithubOpContext>;
export type ListItemsForOrgError = GithubOpError;
/** List items for an organization owned project List all items for a specific organization-owned project accessible by the authenticated user. */
export declare const listItemsForOrg: API.OperationMethod<ListItemsForOrgRequest, ListItemsForOrgResponse, ListItemsForOrgError, GithubOpContext>;
export type ListItemsForUserError = GithubOpError;
/** List items for a user owned project List all items for a specific user-owned project accessible by the authenticated user. */
export declare const listItemsForUser: API.OperationMethod<ListItemsForUserRequest, ListItemsForUserResponse, ListItemsForUserError, GithubOpContext>;
export type ListViewItemsForOrgError = GithubOpError;
/** List items for an organization project view List items in an organization project with the saved view's filter applied. */
export declare const listViewItemsForOrg: API.OperationMethod<ListViewItemsForOrgRequest, ListViewItemsForOrgResponse, ListViewItemsForOrgError, GithubOpContext>;
export type ListViewItemsForUserError = GithubOpError;
/** List items for a user project view List items in a user project with the saved view's filter applied. */
export declare const listViewItemsForUser: API.OperationMethod<ListViewItemsForUserRequest, ListViewItemsForUserResponse, ListViewItemsForUserError, GithubOpContext>;
export type UpdateItemForOrgError = GithubOpError;
/** Update project item for organization Update a specific item in an organization-owned project. */
export declare const updateItemForOrg: API.OperationMethod<UpdateItemForOrgRequest, ProjectsV2ItemWithContent, UpdateItemForOrgError, GithubOpContext>;
export type UpdateItemForUserError = GithubOpError;
/** Update project item for user Update a specific item in a user-owned project. */
export declare const updateItemForUser: API.OperationMethod<UpdateItemForUserRequest, ProjectsV2ItemWithContent, UpdateItemForUserError, GithubOpContext>;
//# sourceMappingURL=projects.d.ts.map