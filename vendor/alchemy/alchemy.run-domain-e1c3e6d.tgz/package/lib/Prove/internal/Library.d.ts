import type { Host } from "./Kit.ts";
import type { Eval, Site, V } from "./Value.ts";
export type { Host, Model } from "./Kit.ts";
/**
 * The library functions the prover knows, each written once as what it does
 * to a symbolic value. A call to any other library function is not
 * translated, and the report names the call.
 */
export declare const make: (host: Host) => {
    /**
     * Every library function and value the prover has a model for, as
     * `module:path`, and every method of a string it reads.
     */
    surface: {
        library: string[];
        strings: string[];
    };
    opticMember: (optic: V & {
        readonly _tag: "Optic";
    }, key: string) => V | undefined;
    /** A member of a latch or a semaphore: `latch.open`, `semaphore.withPermits`. */
    waitMember: (value: V, key: string) => V | undefined;
    /** A helper of a tagged union of `effect/Schema`, as a value the code calls. */
    unionMember: (schema: unknown, key: string, name: string) => V | undefined;
    /** A method of a string, as a value the code calls. */
    stringMember: (self: V, key: string) => V | undefined;
    /** What `yield*` gives inside `Option.gen` and `Result.gen`. */
    yielded: (value: V) => Eval<V> | undefined;
    /** What a loop or a spread goes over. */
    iterate: (v: V, site: Site) => Eval<ReadonlyArray<V> | undefined>;
    /** Whether a value is a class of `effect/Data`, which `new` makes an instance of. */
    isClass: (value: V) => boolean;
    /** A class a file declares by extending one of `effect/Data`'s: its own class, with the same fields. */
    subclass: (base: V, name: string) => V | undefined;
    valueOf: (lib: V & {
        readonly _tag: "Lib";
    }, site: Site) => V | undefined;
    /**
     * Whether a package is one the prover knows by its models, and never
     * reads the code of: Effect, and Alchemy's own.
     */
    known: (specifier: string) => boolean;
    /** Whether the prover has a model for a library function. */
    models: (lib: V & {
        readonly _tag: "Lib";
    }) => boolean;
    call: (lib: V & {
        readonly _tag: "Lib";
    }, args: ReadonlyArray<V>, site: Site) => Eval<V>;
};
//# sourceMappingURL=Library.d.ts.map