import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ClientCertificateAlreadyRevoked_base: S.TaggedErrorClass<"ClientCertificateAlreadyRevoked", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ClientCertificateAlreadyRevoked extends /*@__PURE__*/ ClientCertificateAlreadyRevoked_base {
}
declare const ClientCertificateNotFound_base: S.TaggedErrorClass<"ClientCertificateNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ClientCertificateNotFound extends /*@__PURE__*/ ClientCertificateNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CreateClientCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr: string;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays: number;
}
export interface CreateResponseCertificateAuthority {
    id?: string | null | undefined;
    name?: string | null | undefined;
}
export type CreateResponseStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateClientCertificateResponse {
    /** Client Certificate Tag */
    id?: string | null | undefined;
    /** The Client Certificate PEM. */
    certificate?: string | null | undefined;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null | undefined;
    /** Common Name of the Client Certificate. */
    commonName?: string | null | undefined;
    /** Country, provided by the CSR. */
    country?: string | null | undefined;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null | undefined;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null | undefined;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null | undefined;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null | undefined;
    /** Location, provided by the CSR. */
    location?: string | null | undefined;
    /** Organization, provided by the CSR. */
    organization?: string | null | undefined;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null | undefined;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null | undefined;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null | undefined;
    /** Subject Key Identifier. */
    ski?: string | null | undefined;
    /** State, provided by the CSR. */
    state?: string | null | undefined;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: CreateResponseStatus | null | undefined;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null | undefined;
}
export interface DeleteClientCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Client Certificate Tag */
    clientCertificateId: string;
}
export type DeleteResponseCertificateAuthority = CreateResponseCertificateAuthority;
export type DeleteResponseStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteClientCertificateResponse {
    /** Client Certificate Tag */
    id?: string | null | undefined;
    /** The Client Certificate PEM. */
    certificate?: string | null | undefined;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null | undefined;
    /** Common Name of the Client Certificate. */
    commonName?: string | null | undefined;
    /** Country, provided by the CSR. */
    country?: string | null | undefined;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null | undefined;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null | undefined;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null | undefined;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null | undefined;
    /** Location, provided by the CSR. */
    location?: string | null | undefined;
    /** Organization, provided by the CSR. */
    organization?: string | null | undefined;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null | undefined;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null | undefined;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null | undefined;
    /** Subject Key Identifier. */
    ski?: string | null | undefined;
    /** State, provided by the CSR. */
    state?: string | null | undefined;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: DeleteResponseStatus | null | undefined;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null | undefined;
}
export interface GetClientCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Client Certificate Tag */
    clientCertificateId: string;
}
export type GetResponseCertificateAuthority = CreateResponseCertificateAuthority;
export type GetResponseStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetClientCertificateResponse {
    /** Client Certificate Tag */
    id?: string | null | undefined;
    /** The Client Certificate PEM. */
    certificate?: string | null | undefined;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null | undefined;
    /** Common Name of the Client Certificate. */
    commonName?: string | null | undefined;
    /** Country, provided by the CSR. */
    country?: string | null | undefined;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null | undefined;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null | undefined;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null | undefined;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null | undefined;
    /** Location, provided by the CSR. */
    location?: string | null | undefined;
    /** Organization, provided by the CSR. */
    organization?: string | null | undefined;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null | undefined;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null | undefined;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null | undefined;
    /** Subject Key Identifier. */
    ski?: string | null | undefined;
    /** State, provided by the CSR. */
    state?: string | null | undefined;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: GetResponseStatus | null | undefined;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null | undefined;
}
export type ListRequestStatus = "all" | "active" | "pending_reactivation" | "pending_revocation" | "revoked";
export interface ListClientCertificatesRequest {
    /** Identifier. */
    zoneId: string;
    /** Limit to the number of records returned. */
    limit?: number | undefined;
    /** Offset the results. */
    offset?: number | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of records per page. */
    perPage?: number | undefined;
    /** Client Certitifcate Status to filter results by. */
    status?: ListRequestStatus | (string & {}) | undefined;
}
export type ListResultItemCertificateAuthority = CreateResponseCertificateAuthority;
export type ListResultItemStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
export interface ListResultItem {
    /** Client Certificate Tag */
    id?: string | null | undefined;
    /** The Client Certificate PEM. */
    certificate?: string | null | undefined;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null | undefined;
    /** Common Name of the Client Certificate. */
    commonName?: string | null | undefined;
    /** Country, provided by the CSR. */
    country?: string | null | undefined;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null | undefined;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null | undefined;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null | undefined;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null | undefined;
    /** Location, provided by the CSR. */
    location?: string | null | undefined;
    /** Organization, provided by the CSR. */
    organization?: string | null | undefined;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null | undefined;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null | undefined;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null | undefined;
    /** Subject Key Identifier. */
    ski?: string | null | undefined;
    /** State, provided by the CSR. */
    state?: string | null | undefined;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: ListResultItemStatus | null | undefined;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListClientCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface PatchClientCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Client Certificate Tag */
    clientCertificateId: string;
    reactivate?: boolean | undefined;
}
export type EditResponseCertificateAuthority = CreateResponseCertificateAuthority;
export type EditResponseStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchClientCertificateResponse {
    /** Client Certificate Tag */
    id?: string | null | undefined;
    /** The Client Certificate PEM. */
    certificate?: string | null | undefined;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null | undefined;
    /** Common Name of the Client Certificate. */
    commonName?: string | null | undefined;
    /** Country, provided by the CSR. */
    country?: string | null | undefined;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null | undefined;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null | undefined;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null | undefined;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null | undefined;
    /** Location, provided by the CSR. */
    location?: string | null | undefined;
    /** Organization, provided by the CSR. */
    organization?: string | null | undefined;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null | undefined;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null | undefined;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null | undefined;
    /** Subject Key Identifier. */
    ski?: string | null | undefined;
    /** State, provided by the CSR. */
    state?: string | null | undefined;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: EditResponseStatus | null | undefined;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null | undefined;
}
export type CreateClientCertificateError = Forbidden | CloudflareOpError;
/** Create a new API Shield mTLS Client Certificate. */
export declare const createClientCertificate: API.OperationMethod<CreateClientCertificateRequest, CreateClientCertificateResponse, CreateClientCertificateError, CloudflareOpContext>;
export type DeleteClientCertificateError = ClientCertificateNotFound | ClientCertificateAlreadyRevoked | Forbidden | CloudflareOpError;
/** Set a API Shield mTLS Client Certificate to pending_revocation status for processing to revoked status. */
export declare const deleteClientCertificate: API.OperationMethod<DeleteClientCertificateRequest, DeleteClientCertificateResponse, DeleteClientCertificateError, CloudflareOpContext>;
export type GetClientCertificateError = ClientCertificateNotFound | Forbidden | CloudflareOpError;
/** Get Details for a single mTLS API Shield Client Certificate. */
export declare const getClientCertificate: API.OperationMethod<GetClientCertificateRequest, GetClientCertificateResponse, GetClientCertificateError, CloudflareOpContext>;
export type ListClientCertificatesError = Forbidden | CloudflareOpError;
/** List all of your Zone's API Shield mTLS Client Certificates by Status and/or using Pagination. */
export declare const listClientCertificates: API.PaginatedOperationMethod<ListClientCertificatesRequest, ListClientCertificatesResponse, ListClientCertificatesError, CloudflareOpContext, ListResultItem>;
export type PatchClientCertificateError = ClientCertificateNotFound | Forbidden | CloudflareOpError;
/** If a API Shield mTLS Client Certificate is in a pending_revocation state, you may reactivate it with this endpoint. */
export declare const patchClientCertificate: API.OperationMethod<PatchClientCertificateRequest, PatchClientCertificateResponse, PatchClientCertificateError, CloudflareOpContext>;
//# sourceMappingURL=client_certificates.d.ts.map