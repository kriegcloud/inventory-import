import * as Effect from "effect/Effect";
import { SharedConfigError } from "../credentials-service.ts";
import { type ParsedIniData, type SharedConfigFiles } from "./parse-ini.ts";
/** The home directory: the environment first, then the OS. */
export declare const getHomeDir: () => string;
export declare const getConfigFilepath: () => string;
export declare const getCredentialsFilepath: () => string;
/** Both files, read on every run so an edited file is picked up. */
export declare const loadSharedConfigFiles: Effect.Effect<SharedConfigFiles, SharedConfigError>;
/** Both files as one profile map, with the credentials file winning. */
export declare const mergeKnownFiles: ({ configFile, credentialsFile, }: SharedConfigFiles) => ParsedIniData;
export declare const parseKnownFiles: Effect.Effect<ParsedIniData, SharedConfigError>;
//# sourceMappingURL=shared-config.d.ts.map