import * as Provider from "../Provider.ts";
import { Resource } from "../Resource.ts";
import { CommandExecutor, type CommandProps } from "./Command.ts";
export interface DevProps extends CommandProps {
    /**
     * Make the URL required: the resource is ready only once the command
     * prints a URL, however long that takes, and fails if the command exits
     * first. Without it, the resource waits 5 seconds and settles with
     * `url: undefined` when no URL appears.
     *
     * A localhost/IP URL is still preferred: when the first URL printed is
     * another one, the resource waits up to 5 seconds more for a local one
     * before settling with it.
     *
     * @default false
     */
    waitForUrl?: boolean;
    /**
     * The port the command listens on. Alchemy sets `PORT` to it, over any
     * `env.PORT`, and the resource is ready once the port accepts a
     * connection, however long that takes. Output isn't scanned for a URL,
     * so `waitForUrl` has no effect: `url` is `http://localhost:<port>`.
     *
     * The resource fails if the command exits before the port opens, or if
     * another process already listens on the port when the command starts.
     */
    port?: number;
}
export interface Dev extends Resource<"Command.Dev", DevProps, {
    /**
     * URL extracted from stdout/stderr. A `localhost`/IP URL (the dev
     * server's own address) is preferred over any other URL the command
     * prints; a non-local URL is only used as a fallback if no local one
     * appears. Best-effort: `undefined` if no URL appears within 5 seconds,
     * unless `waitForUrl` is set, which waits until one does. With `port`,
     * it is `http://localhost:<port>`.
     */
    url: string | undefined;
}> {
}
/**
 * A long-lived shell process scoped to a stack instance, started during
 * `alchemy dev` and restarted when its inputs change. During `alchemy deploy`
 * this is a no-op — `Dev` resources only run in dev mode.
 *
 * The child process runs inside the dev sidecar (see `Command/Local.ts`) so it
 * survives user-code HMR — Alchemy's user process can restart without killing
 * your `npm run dev` server. Its stdout/stderr are mirrored to the terminal
 * (preserving colored output) and scanned for an `http(s)://…` URL, favoring
 * a `localhost`/IP URL (the dev server's own address) over any unrelated URL
 * the command prints first. The result is exposed as the `url` output
 * attribute — useful for surfacing a dev server's local URL back out to
 * whatever resource declared this `Dev`.
 *
 *
 * ### Basic Usage
 * Pass a shell command that starts a long-lived dev server. Alchemy
 * runs it in the background and extracts the first URL it prints.
 *
 * **Example:** Start a Vite dev server
 * ```typescript
 * const dev = yield* Dev("Frontend", {
 *   command: "npm run dev",
 * });
 * yield* Console.log(dev.url); // e.g. "http://localhost:5173"
 * ```
 *
 * ### Requiring a URL
 * By default the resource waits 5 seconds for a URL and settles with
 * `url: undefined` if none appears. Set `waitForUrl` when downstream
 * resources depend on the URL: the resource is ready only once the
 * command prints one, however long the server takes to start, and fails
 * if the command exits first.
 *
 * **Example:** Wait for a slow server's URL
 * ```typescript
 * const engine = yield* Dev("Engine", {
 *   command: "rivet-engine start",
 *   waitForUrl: true,
 * });
 * ```
 *
 * ### Known Port
 * When you choose the port, pass it as `port`: Alchemy sets `PORT` to it
 * and the resource is ready once the port accepts a connection, with no
 * output scanning. This suits servers that print no URL, and wrappers
 * that route the port elsewhere.
 *
 * **Example:** Serve on port 4000
 * ```typescript
 * const api = yield* Dev("Api", {
 *   command: "node server.ts",
 *   port: 4000,
 * });
 * yield* Console.log(api.url); // "http://localhost:4000"
 * ```
 *
 * ### Working Directory
 * Use `cwd` to run the command in a subdirectory — useful in
 * monorepos where each package has its own dev server.
 *
 * **Example:** Monorepo package
 * ```typescript
 * const dev = yield* Dev("Web", {
 *   command: "npm run dev",
 *   cwd: "apps/web",
 * });
 * ```
 *
 * ### Environment Variables
 * Extra environment variables are merged on top of `process.env`.
 * Sensitive values can be wrapped in `Redacted` to keep them out
 * of logs and state files.
 *
 * **Example:** Custom port and env
 * ```typescript
 * const dev = yield* Dev("Api", {
 *   command: "npm run dev",
 *   env: {
 *     PORT: "4000",
 *     DATABASE_URL: Redacted.make("postgres://..."),
 *   },
 * });
 * ```
 *
 * @resource
 */
export declare const Dev: import("../Resource.ts").ResourceClass<Dev>;
export declare const DevProvider: () => import("effect/Layer").Layer<Provider.Provider<Dev>, never, import("../AlchemyContext.ts").AlchemyContext | import("../Artifacts.ts").ArtifactStore | CommandExecutor | import("../Stack.ts").Stack>;
export declare const DevProviderLive: () => import("effect/Layer").Layer<Provider.Provider<Dev>, never, never>;
export declare const DevProviderLocal: () => import("effect/Layer").Layer<Provider.Provider<Dev>, never, import("../AlchemyContext.ts").AlchemyContext | import("../Artifacts.ts").ArtifactStore | CommandExecutor | import("../Stack.ts").Stack>;
/**
 * Extract a URL from `text`, favoring a localhost/IP URL (the dev server's
 * own address) over any other URL. Returns the first localhost/IP URL if one
 * is present, otherwise the first plain http(s) URL, otherwise `undefined`.
 * `Vite`, `Next`, etc. surround the URL with ANSI color codes that would
 * otherwise be eaten by the URL regex, so strip them first.
 * @internal
 */
export declare const extractUrl: (text: string) => string | undefined;
//# sourceMappingURL=Dev.d.ts.map