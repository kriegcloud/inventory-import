import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface GetRequest {
}
export interface RateLimit2 {
    limit: number;
    remaining: number;
    reset: number;
    used: number;
}
export interface RateLimitOverviewResources {
    core: RateLimit2;
    graphql?: RateLimit2 | undefined;
    search: RateLimit2;
    code_search?: RateLimit2 | undefined;
    source_import?: RateLimit2 | undefined;
    integration_manifest?: RateLimit2 | undefined;
    actions_runner_registration?: RateLimit2 | undefined;
    scim?: RateLimit2 | undefined;
    dependency_snapshots?: RateLimit2 | undefined;
    dependency_sbom?: RateLimit2 | undefined;
    code_scanning_autofix?: RateLimit2 | undefined;
    copilot_usage_records?: RateLimit2 | undefined;
}
/** Rate limit status for the applicable requester and resource category. Requests authenticated as a user share the user's rate limit across credentials. Requests without authentication use the requesting IP address. API requests routed through either an API hostname or a web hostname can count against the same applicable limit. */
export interface RateLimitOverview {
    resources: RateLimitOverviewResources;
    rate: RateLimit2;
}
export type GetError = GithubOpError;
/** Get rate limit status for the authenticated user > [!NOTE] > Accessing this endpoint does not count against your REST API rate limit. Rate limit status reflects the applicable limits for the requester and resource category, not the hostname used for the request. Requests authenticated as a user share the user's rate limit across credentials. Requests without authentication use the requesting IP address. API requests routed through either an API hostname or a web hostname can count against the same applicable limit. Some categories of endpoints have custom rate limits that are separate from the rate limit governing the other REST API endpoints. For this reason, the API response categorizes your rate limit. Under `resources`, you'll see objects relating to different categories: * The `core` object provides your rate limit status for all non-search-related resources in the REST API. * The `search` object provides your rate limit status for the REST API for searching (excluding code searches). For more information, see "[Search](https://docs.github.com/rest/search/search)." * The `code_search` object provides your rate limit status for the REST API for searching code. For more information, see "[Search code](https://docs.github.com/rest/search/search#search-code)." * The `graphql` object provides your rate limit status for the GraphQL API. For more information, see "[Resource limitations](https://docs.github.com/graphql/overview/resource-limitations#rate-limit)." * The `integration_manifest` object provides your rate limit status for the `POST /app-manifests/{code}/conversions` operation. For more information, see "[Creating a GitHub App from a manifest](https://docs.github.com/apps/creating-github-apps/setting-up-a-github-app/creating-a-github-app-from-a-manifest#3-you-exchange-the-temporary-code-to-retrieve-the-app-configuration)." * The `dependency_snapshots` object provides your rate limit status for submitting snapshots to the dependency graph. For more information, see "[Dependency graph](https://docs.github.com/rest/dependency-graph)." * The `dependency_sbom` object provides your rate limit status for requesting SBOMs from the dependency graph. For more information, see "[Dependency graph](https://docs.github.com/rest/dependency-graph)." * The `actions_runner_registration` object provides your rate limit status for registering self-hosted runners in GitHub Actions. For more information, see "[Self-hosted runners](https://docs.github.com/rest/actions/self-hosted-runners)." * The `source_import` object is no longer in use for any API endpoints, and it will be removed in the next API version. For more information about API versions, see "[API Versions](https://docs.github.com/rest/about-the-rest-api/api-versions)." > [!NOTE] > The `rate` object is closing down. If you're writing new API client code or updating existing code, you should use the `core` object instead of the `rate` object. The `core` object contains the same information that is present in the `rate` object. */
export declare const get: API.OperationMethod<GetRequest, RateLimitOverview, GetError, GithubOpContext>;
//# sourceMappingURL=rate_limit.d.ts.map