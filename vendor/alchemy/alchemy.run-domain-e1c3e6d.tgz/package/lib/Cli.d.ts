import * as CliError from "effect/cli/CliError";
import * as Command from "effect/cli/Command";
import * as Effect from "effect/Effect";
import type * as Headers from "effect/http/Headers";
import type * as Rpc from "effect/rpc/Rpc";
import type * as RpcGroup from "effect/rpc/RpcGroup";
import * as Runtime from "effect/Runtime";
import type * as Scope from "effect/Scope";
import type { Annotations } from "./Annotations.ts";
import type { Servable } from "./Api.ts";
import { type OnceCallName } from "./ReadRpcs.ts";
/**
 * A command line for an Api: one subcommand per thing it serves, run as a client of the
 * deployed Api over its HTTP protocol. Not part of the Domain core: import it
 * from `@alchemy.run/domain/Cli`, so an app that builds no CLI never loads
 * `effect/cli`.
 */
/** What {@link toCli} reads from an Api class. */
export interface Cliable {
    readonly apiName: string;
    readonly annotations: Annotations;
    readonly serves: ReadonlyArray<Servable>;
    readonly group: RpcGroup.RpcGroup<Rpc.Any>;
    readonly client: Effect.Effect<unknown, never, any>;
}
/** The services an Api's client needs, less the scope each run opens itself. */
export type ClientServices<A extends Cliable> = A["client"] extends Effect.Effect<any, any, infer R> ? Exclude<R, Scope.Scope> : never;
declare const CallRejected_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CallRejected";
} & Readonly<A>;
/**
 * The Api answered with a typed failure: a declared rejection, or the error
 * of the middleware that guards the call. The CLI has already written
 * `error` (its wire JSON) to stderr, so `runMain` exits with code 1 and
 * prints nothing more.
 */
export declare class CallRejected extends CallRejected_base<{
    /** The RPC that rejected the call (`Deposit`, `Balance.get`). */
    readonly rpc: string;
    /** The failure as wire JSON, as the Api's RPC server encodes it. */
    readonly error: unknown;
}> {
    readonly [Runtime.errorReported] = false;
}
/**
 * A call {@link toCli} can run: a command's tag (`DepositMoney`), or a read
 * that returns once as `<Name>.<operation>` (`AccountSummary.get`).
 */
export type Exposable<A extends Cliable> = OnceCallName<A["client"] extends Effect.Effect<infer Client, any, any> ? Client : never>;
/** How {@link toCli} builds the command line. */
export interface Options<A extends Cliable, E = never, R = never> {
    /**
     * The calls to give subcommands, by name. No subcommand is built unless
     * its call is listed: list each call on purpose.
     * @default []
     */
    readonly expose?: ReadonlyArray<Exposable<A>>;
    /** The root command: the name a person types. Default: the Api's name in kebab-case. */
    readonly name?: string;
    /** The root command's help text. The Api's `description` annotation by default. */
    readonly description?: string;
    /**
     * Headers sent with every call, such as a bearer token for the session
     * middleware that runs on the server. An Effect runs once per call, so it
     * can read the token from the environment (`Config.Redacted("TOKEN")`).
     */
    readonly headers?: Headers.Input | Effect.Effect<Headers.Input, E, R>;
}
/** The errors a command of the CLI fails with. */
export type Failure<E = never> = CallRejected | CliError.UserError | E;
/**
 * The command-line name of a command, view, stream, operation or field: kebab-case
 * (`AccountSummary` → `account-summary`, `commandId` → `command-id`).
 */
export declare const kebab: (name: string) => string;
/**
 * An Effect CLI command for an Api: a client that calls the deployed Api over
 * its HTTP protocol, so a person or an agent in a terminal can run the
 * request/response calls `options.expose` lists. Nothing is exposed by
 * default. The tree is read from those calls:
 *
 * - each command, query, view and stream is a subcommand named in kebab-case (`AccountSummary` →
 *   `account-summary`). A command or a query runs as that subcommand; a view
 *   or a stream has one subcommand per call (`get`, `list`,
 *   `snapshot`, `peek`). Live reads (`watch`, `events`) are left out.
 * - each payload field is a flag in kebab-case (`--command-id`, `--key`),
 *   and a command's or a query's input fields are flags of their own
 *   (`--account-id`, `--amount`). A string, a number, a boolean or a set of string literals
 *   takes a typed flag; any other field takes its JSON (`--at-least
 *   '{"stream":"Account/a-1","version":3}'`). `--json` takes the flags as
 *   one object (`{"accountId":"a-1","amount":1000}`), and flags override it.
 * - two of them with one command name, or a field whose flag another field
 *   or the CLI takes, fail every run with a `DefinitionError`.
 * - the input is decoded against the call's schema before anything is sent;
 *   an invalid input fails as a `CliError.UserError`.
 * - the result is printed to stdout as JSON (its wire form). A typed
 *   failure (a rejection, or the error of the middleware that guards the
 *   call) is printed to stderr as JSON and fails the run with
 *   {@link CallRejected}, so the process exits with code 1.
 *
 * Provide the protocol to the command (`Domain.protocolHttp(url)` and an
 * `HttpClient`), and the platform's CLI services to run it.
 *
 * **Example:** A CLI for an Api
 * ```typescript
 * import { toCli } from "@alchemy.run/domain/Cli";
 * import * as Domain from "@alchemy.run/domain";
 * import { BunRuntime, BunServices } from "@effect/platform-bun";
 * import * as Command from "effect/cli/Command";
 * import * as Config from "effect/Config";
 * import * as Effect from "effect/Effect";
 * import * as FetchHttpClient from "effect/http/FetchHttpClient";
 * import * as Redacted from "effect/Redacted";
 * import { CustomerApi } from "./CustomerApi.ts";
 *
 * const bank = toCli(CustomerApi, {
 *   name: "bank",
 *   expose: ["DepositMoney", "AccountLedger", "AccountSummary.get"],
 *   headers: Config.Redacted("BANK_TOKEN").pipe(
 *     Effect.map((token) => ({ authorization: `Bearer ${Redacted.value(token)}` })),
 *   ),
 * });
 *
 * Command.run(bank, { version: "1.0.0" }).pipe(
 *   Effect.provide(Domain.protocolHttp("https://bank.example.com/api")),
 *   Effect.provide(FetchHttpClient.layer),
 *   Effect.provide(BunServices.layer),
 *   BunRuntime.runMain,
 * );
 * // $ bank deposit-money --account-id a-1 --amount 1000
 * // $ bank account-ledger --account a-1 --take 20
 * // $ bank account-summary get --key a-1
 * ```
 */
export declare const toCli: <A extends Cliable, E = never, R = never>(api: A, options?: Options<A, E, R>) => Command.Command<string, unknown, {}, Failure<E>, ClientServices<A> | R>;
export {};
//# sourceMappingURL=Cli.d.ts.map