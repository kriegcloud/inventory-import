import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type TenantId = string;
export type AccessType = "PROGRAMMATIC_ACCESS" | (string & {});
export type SessionName = string;
export interface GetRoleCredentialsRequest {
    tenantId: string;
    roleArn: string;
    accessType: AccessType;
    sessionName?: string | undefined;
    sessionDuration?: number | undefined;
}
export interface ProgrammaticAccessDetails {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken: string;
    expiresAt?: Date | undefined;
}
export type CredentialsDetails = {
    programmaticAccess: ProgrammaticAccessDetails;
};
export interface GetRoleCredentialsResponse {
    credentialsDetails?: CredentialsDetails | undefined;
}
export type Token = string;
export interface ListRolesRequest {
    tenantId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type Account = string;
export interface AccessDetails {
    accountId: string;
    accountName?: string | undefined;
    roleArn: string;
}
export type AccessDetailsList = AccessDetails[];
export interface ListRolesResponse {
    roles: AccessDetails[];
    nextToken?: string | undefined;
}
export type GetRoleCredentialsError = AccessDeniedException | InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns temporary Amazon Web Services credentials for a role that you are entitled to assume within a tenant. You can use these credentials for programmatic access with the CLI or an Amazon Web Services SDK. If you aren't entitled to the role, the request fails with an `AccessDeniedException` error.
 */
export declare const getRoleCredentials: API.OperationMethod<GetRoleCredentialsRequest & RegionInput, GetRoleCredentialsResponse, GetRoleCredentialsError, Credentials | HttpClient.HttpClient>;
export type ListRolesError = InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the roles that you are entitled to access within a tenant. The results are paginated. Use a returned role with `GetRoleCredentials` to obtain temporary credentials.
 */
export declare const listRoles: API.PaginatedOperationMethod<ListRolesRequest & RegionInput, ListRolesResponse, ListRolesError, Credentials | HttpClient.HttpClient, AccessDetails>;
export {};
//# sourceMappingURL=account-access-runtime.d.ts.map