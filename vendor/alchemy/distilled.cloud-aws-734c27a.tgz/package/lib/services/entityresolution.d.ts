import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ExceedsLimitException_base: S.TaggedErrorClass<"ExceedsLimitException", {
    readonly message: any;
    readonly quotaName: any;
    readonly quotaValue: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ExceedsLimitException extends /*@__PURE__*/ ExceedsLimitException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type VeniceGlobalArn = string;
export type StatementId = string;
export type StatementEffect = "Allow" | "Deny" | (string & {});
export type StatementAction = string;
export type StatementActionList = string[];
export type StatementPrincipal = string;
export type StatementPrincipalList = string[];
export type StatementCondition = string;
export interface AddPolicyStatementInput {
    arn: string;
    statementId: string;
    effect: StatementEffect;
    action: string[];
    principal: string[];
    condition?: string | undefined;
}
export type PolicyToken = string;
export type PolicyDocument = string;
export interface AddPolicyStatementOutput {
    arn: string;
    token: string;
    policy?: string | undefined;
}
export type EntityName = string;
export type HeaderSafeUniqueId = string;
export type UniqueIdList = string[];
export interface BatchDeleteUniqueIdInput {
    workflowName: string;
    inputSource?: string | undefined;
    uniqueIds: string[];
}
export type DeleteUniqueIdStatus = "COMPLETED" | "ACCEPTED" | (string & {});
export type DeleteUniqueIdErrorType = "SERVICE_ERROR" | "VALIDATION_ERROR" | (string & {});
export interface DeleteUniqueIdError {
    uniqueId: string;
    errorType: DeleteUniqueIdErrorType;
}
export type DeleteUniqueIdErrorsList = DeleteUniqueIdError[];
export interface DeletedUniqueId {
    uniqueId: string;
}
export type DeletedUniqueIdList = DeletedUniqueId[];
export type DisconnectedUniqueIdsList = string[];
export interface BatchDeleteUniqueIdOutput {
    status: DeleteUniqueIdStatus;
    errors?: DeleteUniqueIdError[] | undefined;
    deleted?: DeletedUniqueId[] | undefined;
    disconnectedUniqueIds?: string[] | undefined;
}
export type Description = string;
export type InputSourceARN = string;
export type IdNamespaceType = "SOURCE" | "TARGET" | (string & {});
export interface IdMappingWorkflowInputSource {
    inputSourceARN: string;
    schemaName?: string | undefined;
    type?: IdNamespaceType | undefined;
}
export type IdMappingWorkflowInputSourceConfig = IdMappingWorkflowInputSource[];
export type KMSArn = string;
export type S3Path = string;
export interface IdMappingWorkflowOutputSource {
    KMSArn?: string | undefined;
    outputS3Path: string;
}
export type IdMappingWorkflowOutputSourceConfig = IdMappingWorkflowOutputSource[];
export type IdMappingType = "PROVIDER" | "RULE_BASED" | (string & {});
export type AttributeName = string;
export type MatchingKeys = string[];
export interface Rule {
    ruleName: string;
    matchingKeys: string[];
}
export type RuleList = Rule[];
export type IdMappingWorkflowRuleDefinitionType = "SOURCE" | "TARGET" | (string & {});
export type AttributeMatchingModel = "ONE_TO_ONE" | "MANY_TO_MANY" | (string & {});
export type RecordMatchingModel = "ONE_SOURCE_TO_ONE_TARGET" | "MANY_SOURCE_TO_ONE_TARGET" | (string & {});
export interface IdMappingRuleBasedProperties {
    rules?: Rule[] | undefined;
    ruleDefinitionType: IdMappingWorkflowRuleDefinitionType;
    attributeMatchingModel: AttributeMatchingModel;
    recordMatchingModel: RecordMatchingModel;
}
export type ProviderServiceArn = string;
export interface IntermediateSourceConfiguration {
    intermediateS3Path: string;
}
export interface ProviderProperties {
    providerServiceArn: string;
    providerConfiguration?: any | undefined;
    intermediateSourceConfiguration?: IntermediateSourceConfiguration | undefined;
}
export interface IdMappingTechniques {
    idMappingType: IdMappingType;
    ruleBasedProperties?: IdMappingRuleBasedProperties | undefined;
    providerProperties?: ProviderProperties | undefined;
}
export type IdMappingIncrementalRunType = "ON_DEMAND" | (string & {});
export interface IdMappingIncrementalRunConfig {
    incrementalRunType?: IdMappingIncrementalRunType | undefined;
}
export type IdMappingRoleArn = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateIdMappingWorkflowInput {
    workflowName: string;
    description?: string | undefined;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[] | undefined;
    idMappingTechniques: IdMappingTechniques;
    incrementalRunConfig?: IdMappingIncrementalRunConfig | undefined;
    roleArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type IdMappingWorkflowArn = string;
export interface CreateIdMappingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string | undefined;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[] | undefined;
    idMappingTechniques: IdMappingTechniques;
    incrementalRunConfig?: IdMappingIncrementalRunConfig | undefined;
    roleArn?: string | undefined;
}
export interface IdNamespaceInputSource {
    inputSourceARN: string;
    schemaName?: string | undefined;
}
export type IdNamespaceInputSourceConfig = IdNamespaceInputSource[];
export type IdMappingWorkflowRuleDefinitionTypeList = IdMappingWorkflowRuleDefinitionType[];
export type RecordMatchingModelList = RecordMatchingModel[];
export interface NamespaceRuleBasedProperties {
    rules?: Rule[] | undefined;
    ruleDefinitionTypes?: IdMappingWorkflowRuleDefinitionType[] | undefined;
    attributeMatchingModel?: AttributeMatchingModel | undefined;
    recordMatchingModels?: RecordMatchingModel[] | undefined;
}
export interface NamespaceProviderProperties {
    providerServiceArn: string;
    providerConfiguration?: any | undefined;
}
export interface IdNamespaceIdMappingWorkflowProperties {
    idMappingType: IdMappingType;
    ruleBasedProperties?: NamespaceRuleBasedProperties | undefined;
    providerProperties?: NamespaceProviderProperties | undefined;
}
export type IdNamespaceIdMappingWorkflowPropertiesList = IdNamespaceIdMappingWorkflowProperties[];
export type RoleArn = string;
export interface CreateIdNamespaceInput {
    idNamespaceName: string;
    description?: string | undefined;
    inputSourceConfig?: IdNamespaceInputSource[] | undefined;
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[] | undefined;
    type: IdNamespaceType;
    roleArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type IdNamespaceArn = string;
export interface CreateIdNamespaceOutput {
    idNamespaceName: string;
    idNamespaceArn: string;
    description?: string | undefined;
    inputSourceConfig?: IdNamespaceInputSource[] | undefined;
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[] | undefined;
    type: IdNamespaceType;
    roleArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface InputSource {
    inputSourceARN: string;
    schemaName: string;
    applyNormalization?: boolean | undefined;
}
export type InputSourceConfig = InputSource[];
export type OptionalS3Path = string;
export interface OutputAttribute {
    name: string;
    hashed?: boolean | undefined;
}
export type OutputAttributes = OutputAttribute[];
export type CustomerProfilesDomainArn = string;
export type CustomerProfilesObjectTypeArn = string;
export interface CustomerProfilesIntegrationConfig {
    domainArn: string;
    objectTypeArn: string;
}
export interface OutputSource {
    KMSArn?: string | undefined;
    outputS3Path?: string | undefined;
    output: OutputAttribute[];
    applyNormalization?: boolean | undefined;
    customerProfilesIntegrationConfig?: CustomerProfilesIntegrationConfig | undefined;
}
export type OutputSourceConfig = OutputSource[];
export type ResolutionType = "RULE_MATCHING" | "ML_MATCHING" | "PROVIDER" | (string & {});
export type MatchPurpose = "IDENTIFIER_GENERATION" | "INDEXING" | (string & {});
export interface RuleBasedProperties {
    rules: Rule[];
    attributeMatchingModel: AttributeMatchingModel;
    matchPurpose?: MatchPurpose | undefined;
}
export interface RuleCondition {
    ruleName: string;
    condition: string;
}
export type RuleConditionList = RuleCondition[];
export interface MatchingConfig {
    enableTransitiveMatching?: boolean | undefined;
}
export interface RuleConditionProperties {
    rules: RuleCondition[];
    matchingConfig?: MatchingConfig | undefined;
}
export interface ResolutionTechniques {
    resolutionType: ResolutionType;
    ruleBasedProperties?: RuleBasedProperties | undefined;
    ruleConditionProperties?: RuleConditionProperties | undefined;
    enableRealTimeMatching?: boolean | undefined;
    providerProperties?: ProviderProperties | undefined;
}
export type IncrementalRunType = "IMMEDIATE" | (string & {});
export interface IncrementalRunConfig {
    incrementalRunType?: IncrementalRunType | undefined;
}
export interface CreateMatchingWorkflowInput {
    workflowName: string;
    description?: string | undefined;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    incrementalRunConfig?: IncrementalRunConfig | undefined;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MatchingWorkflowArn = string;
export interface CreateMatchingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string | undefined;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    incrementalRunConfig?: IncrementalRunConfig | undefined;
    roleArn: string;
}
export type SchemaAttributeType = "NAME" | "NAME_FIRST" | "NAME_MIDDLE" | "NAME_LAST" | "ADDRESS" | "ADDRESS_STREET1" | "ADDRESS_STREET2" | "ADDRESS_STREET3" | "ADDRESS_CITY" | "ADDRESS_STATE" | "ADDRESS_COUNTRY" | "ADDRESS_POSTALCODE" | "PHONE" | "PHONE_NUMBER" | "PHONE_COUNTRYCODE" | "EMAIL_ADDRESS" | "UNIQUE_ID" | "DATE" | "STRING" | "PROVIDER_ID" | "IPV4" | "IPV6" | "MAID" | (string & {});
export interface SchemaInputAttribute {
    fieldName: string;
    type: SchemaAttributeType;
    groupName?: string | undefined;
    matchKey?: string | undefined;
    subType?: string | undefined;
    hashed?: boolean | undefined;
}
export type SchemaInputAttributes = SchemaInputAttribute[];
export interface CreateSchemaMappingInput {
    schemaName: string;
    description?: string | undefined;
    mappedInputFields: SchemaInputAttribute[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SchemaMappingArn = string;
export interface CreateSchemaMappingOutput {
    schemaName: string;
    schemaArn: string;
    description?: string | undefined;
    mappedInputFields: SchemaInputAttribute[];
}
export interface DeleteIdMappingWorkflowInput {
    workflowName: string;
}
export interface DeleteIdMappingWorkflowOutput {
    message: string;
}
export interface DeleteIdNamespaceInput {
    idNamespaceName: string;
}
export interface DeleteIdNamespaceOutput {
    message: string;
}
export interface DeleteMatchingWorkflowInput {
    workflowName: string;
}
export interface DeleteMatchingWorkflowOutput {
    message: string;
}
export interface DeletePolicyStatementInput {
    arn: string;
    statementId: string;
}
export interface DeletePolicyStatementOutput {
    arn: string;
    token: string;
    policy?: string | undefined;
}
export interface DeleteSchemaMappingInput {
    schemaName: string;
}
export interface DeleteSchemaMappingOutput {
    message: string;
}
export type UniqueId = string;
export type RecordAttributeMapString255 = {
    [key: string]: string | undefined;
};
export interface Record {
    inputSourceARN: string;
    uniqueId: string;
    recordAttributeMap: {
        [key: string]: string | undefined;
    };
}
export type RecordList = Record[];
export type ProcessingType = "CONSISTENT" | "EVENTUAL" | "EVENTUAL_NO_LOOKUP" | (string & {});
export interface GenerateMatchIdInput {
    workflowName: string;
    records: Record[];
    processingType?: ProcessingType | undefined;
}
export interface MatchedRecord {
    inputSourceARN: string;
    recordId: string;
}
export type MatchedRecordsList = MatchedRecord[];
export interface MatchGroup {
    records: MatchedRecord[];
    matchId: string;
    matchRule: string;
}
export type MatchGroupsList = MatchGroup[];
export type ErrorMessage = string;
export interface FailedRecord {
    inputSourceARN: string;
    uniqueId: string;
    errorMessage: string;
}
export type FailedRecordsList = FailedRecord[];
export interface GenerateMatchIdOutput {
    matchGroups: MatchGroup[];
    failedRecords: FailedRecord[];
}
export type EntityNameOrIdMappingWorkflowArn = string;
export type JobId = string;
export interface GetIdMappingJobInput {
    workflowName: string;
    jobId: string;
}
export type JobStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "QUEUED" | (string & {});
export interface IdMappingJobMetrics {
    inputRecords?: number | undefined;
    totalRecordsProcessed?: number | undefined;
    recordsNotProcessed?: number | undefined;
    deleteRecordsProcessed?: number | undefined;
    totalMappedRecords?: number | undefined;
    totalMappedSourceRecords?: number | undefined;
    totalMappedTargetRecords?: number | undefined;
    uniqueRecordsLoaded?: number | undefined;
    newMappedRecords?: number | undefined;
    newMappedSourceRecords?: number | undefined;
    newMappedTargetRecords?: number | undefined;
    newUniqueRecordsLoaded?: number | undefined;
    mappedRecordsRemoved?: number | undefined;
    mappedSourceRecordsRemoved?: number | undefined;
    mappedTargetRecordsRemoved?: number | undefined;
}
export interface ErrorDetails {
    errorMessage?: string | undefined;
}
export interface IdMappingJobOutputSource {
    roleArn: string;
    outputS3Path: string;
    KMSArn?: string | undefined;
}
export type IdMappingJobOutputSourceConfig = IdMappingJobOutputSource[];
export type JobType = "BATCH" | "INCREMENTAL" | "DELETE_ONLY" | (string & {});
export interface GetIdMappingJobOutput {
    jobId: string;
    status: JobStatus;
    startTime: Date;
    endTime?: Date | undefined;
    metrics?: IdMappingJobMetrics | undefined;
    errorDetails?: ErrorDetails | undefined;
    outputSourceConfig?: IdMappingJobOutputSource[] | undefined;
    jobType?: JobType | undefined;
}
export interface GetIdMappingWorkflowInput {
    workflowName: string;
}
export interface GetIdMappingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string | undefined;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[] | undefined;
    idMappingTechniques: IdMappingTechniques;
    createdAt: Date;
    updatedAt: Date;
    incrementalRunConfig?: IdMappingIncrementalRunConfig | undefined;
    roleArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EntityNameOrIdNamespaceArn = string;
export interface GetIdNamespaceInput {
    idNamespaceName: string;
}
export interface GetIdNamespaceOutput {
    idNamespaceName: string;
    idNamespaceArn: string;
    description?: string | undefined;
    inputSourceConfig?: IdNamespaceInputSource[] | undefined;
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[] | undefined;
    type: IdNamespaceType;
    roleArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RecordAttributeMap = {
    [key: string]: string | undefined;
};
export interface GetMatchIdInput {
    workflowName: string;
    record: {
        [key: string]: string | undefined;
    };
    applyNormalization?: boolean | undefined;
}
export interface GetMatchIdOutput {
    matchId?: string | undefined;
    matchRule?: string | undefined;
}
export interface GetMatchingJobInput {
    workflowName: string;
    jobId: string;
}
export interface JobMetrics {
    inputRecords?: number | undefined;
    totalRecordsProcessed?: number | undefined;
    recordsNotProcessed?: number | undefined;
    deleteRecordsProcessed?: number | undefined;
    matchIDs?: number | undefined;
}
export interface JobOutputSource {
    roleArn: string;
    outputS3Path: string;
    KMSArn?: string | undefined;
}
export type JobOutputSourceConfig = JobOutputSource[];
export interface GetMatchingJobOutput {
    jobId: string;
    status: JobStatus;
    startTime: Date;
    endTime?: Date | undefined;
    metrics?: JobMetrics | undefined;
    errorDetails?: ErrorDetails | undefined;
    outputSourceConfig?: JobOutputSource[] | undefined;
}
export interface GetMatchingWorkflowInput {
    workflowName: string;
}
export interface GetMatchingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string | undefined;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    createdAt: Date;
    updatedAt: Date;
    incrementalRunConfig?: IncrementalRunConfig | undefined;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetPolicyInput {
    arn: string;
}
export interface GetPolicyOutput {
    arn: string;
    token: string;
    policy?: string | undefined;
}
export interface GetProviderServiceInput {
    providerName: string;
    providerServiceName: string;
}
export type ProviderServiceDisplayName = string;
export type ServiceType = "ASSIGNMENT" | "ID_MAPPING" | (string & {});
export interface ProviderIdNameSpaceConfiguration {
    description?: string | undefined;
    providerTargetConfigurationDefinition?: any | undefined;
    providerSourceConfigurationDefinition?: any | undefined;
}
export interface ProviderMarketplaceConfiguration {
    dataSetId: string;
    revisionId: string;
    assetId: string;
    listingId: string;
}
export type ProviderEndpointConfiguration = {
    marketplaceConfiguration: ProviderMarketplaceConfiguration;
};
export type AwsAccountId = string;
export type AwsAccountIdList = string[];
export type RequiredBucketActionsList = string[];
export interface ProviderIntermediateDataAccessConfiguration {
    awsAccountIds?: string[] | undefined;
    requiredBucketActions?: string[] | undefined;
}
export type SchemaList = string[];
export type Schemas = string[][];
export interface ProviderSchemaAttribute {
    fieldName: string;
    type: SchemaAttributeType;
    subType?: string | undefined;
    hashing?: boolean | undefined;
}
export type ProviderSchemaAttributes = ProviderSchemaAttribute[];
export interface ProviderComponentSchema {
    schemas?: string[][] | undefined;
    providerSchemaAttributes?: ProviderSchemaAttribute[] | undefined;
}
export interface GetProviderServiceOutput {
    providerName: string;
    providerServiceName: string;
    providerServiceDisplayName: string;
    providerServiceType: ServiceType;
    providerServiceArn: string;
    providerConfigurationDefinition?: any | undefined;
    providerIdNameSpaceConfiguration?: ProviderIdNameSpaceConfiguration | undefined;
    providerJobConfiguration?: any | undefined;
    providerEndpointConfiguration: ProviderEndpointConfiguration;
    anonymizedOutput: boolean;
    providerEntityOutputDefinition: any;
    providerIntermediateDataAccessConfiguration?: ProviderIntermediateDataAccessConfiguration | undefined;
    providerComponentSchema?: ProviderComponentSchema | undefined;
}
export interface GetSchemaMappingInput {
    schemaName: string;
}
export interface GetSchemaMappingOutput {
    schemaName: string;
    schemaArn: string;
    description?: string | undefined;
    mappedInputFields: SchemaInputAttribute[];
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    hasWorkflows: boolean;
}
export type NextToken = string;
export interface ListIdMappingJobsInput {
    workflowName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface JobSummary {
    jobId: string;
    status: JobStatus;
    startTime: Date;
    endTime?: Date | undefined;
}
export type JobList = JobSummary[];
export interface ListIdMappingJobsOutput {
    jobs?: JobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListIdMappingWorkflowsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IdMappingWorkflowSummary {
    workflowName: string;
    workflowArn: string;
    createdAt: Date;
    updatedAt: Date;
}
export type IdMappingWorkflowList = IdMappingWorkflowSummary[];
export interface ListIdMappingWorkflowsOutput {
    workflowSummaries?: IdMappingWorkflowSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListIdNamespacesInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IdNamespaceIdMappingWorkflowMetadata {
    idMappingType: IdMappingType;
}
export type IdNamespaceIdMappingWorkflowMetadataList = IdNamespaceIdMappingWorkflowMetadata[];
export interface IdNamespaceSummary {
    idNamespaceName: string;
    idNamespaceArn: string;
    description?: string | undefined;
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowMetadata[] | undefined;
    type: IdNamespaceType;
    createdAt: Date;
    updatedAt: Date;
}
export type IdNamespaceList = IdNamespaceSummary[];
export interface ListIdNamespacesOutput {
    idNamespaceSummaries?: IdNamespaceSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListMatchingJobsInput {
    workflowName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListMatchingJobsOutput {
    jobs?: JobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListMatchingWorkflowsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface MatchingWorkflowSummary {
    workflowName: string;
    workflowArn: string;
    createdAt: Date;
    updatedAt: Date;
    resolutionType: ResolutionType;
}
export type MatchingWorkflowList = MatchingWorkflowSummary[];
export interface ListMatchingWorkflowsOutput {
    workflowSummaries?: MatchingWorkflowSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListProviderServicesInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    providerName?: string | undefined;
}
export interface ProviderServiceSummary {
    providerServiceArn: string;
    providerName: string;
    providerServiceDisplayName: string;
    providerServiceName: string;
    providerServiceType: ServiceType;
}
export type ProviderServiceList = ProviderServiceSummary[];
export interface ListProviderServicesOutput {
    providerServiceSummaries?: ProviderServiceSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSchemaMappingsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SchemaMappingSummary {
    schemaName: string;
    schemaArn: string;
    createdAt: Date;
    updatedAt: Date;
    hasWorkflows: boolean;
}
export type SchemaMappingList = SchemaMappingSummary[];
export interface ListSchemaMappingsOutput {
    schemaList?: SchemaMappingSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface PutPolicyInput {
    arn: string;
    token?: string | undefined;
    policy: string;
}
export interface PutPolicyOutput {
    arn: string;
    token: string;
    policy?: string | undefined;
}
export interface StartIdMappingJobInput {
    workflowName: string;
    outputSourceConfig?: IdMappingJobOutputSource[] | undefined;
    jobType?: JobType | undefined;
}
export interface StartIdMappingJobOutput {
    jobId: string;
    outputSourceConfig?: IdMappingJobOutputSource[] | undefined;
    jobType?: JobType | undefined;
}
export interface StartMatchingJobInput {
    workflowName: string;
}
export interface StartMatchingJobOutput {
    jobId: string;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateIdMappingWorkflowInput {
    workflowName: string;
    description?: string | undefined;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[] | undefined;
    idMappingTechniques: IdMappingTechniques;
    incrementalRunConfig?: IdMappingIncrementalRunConfig | undefined;
    roleArn?: string | undefined;
}
export interface UpdateIdMappingWorkflowOutput {
    workflowName: string;
    workflowArn: string;
    description?: string | undefined;
    inputSourceConfig: IdMappingWorkflowInputSource[];
    outputSourceConfig?: IdMappingWorkflowOutputSource[] | undefined;
    idMappingTechniques: IdMappingTechniques;
    incrementalRunConfig?: IdMappingIncrementalRunConfig | undefined;
    roleArn?: string | undefined;
}
export interface UpdateIdNamespaceInput {
    idNamespaceName: string;
    description?: string | undefined;
    inputSourceConfig?: IdNamespaceInputSource[] | undefined;
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[] | undefined;
    roleArn?: string | undefined;
}
export interface UpdateIdNamespaceOutput {
    idNamespaceName: string;
    idNamespaceArn: string;
    description?: string | undefined;
    inputSourceConfig?: IdNamespaceInputSource[] | undefined;
    idMappingWorkflowProperties?: IdNamespaceIdMappingWorkflowProperties[] | undefined;
    type: IdNamespaceType;
    roleArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export interface UpdateMatchingWorkflowInput {
    workflowName: string;
    description?: string | undefined;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    incrementalRunConfig?: IncrementalRunConfig | undefined;
    roleArn: string;
}
export interface UpdateMatchingWorkflowOutput {
    workflowName: string;
    description?: string | undefined;
    inputSourceConfig: InputSource[];
    outputSourceConfig: OutputSource[];
    resolutionTechniques: ResolutionTechniques;
    incrementalRunConfig?: IncrementalRunConfig | undefined;
    roleArn: string;
}
export interface UpdateSchemaMappingInput {
    schemaName: string;
    description?: string | undefined;
    mappedInputFields: SchemaInputAttribute[];
}
export interface UpdateSchemaMappingOutput {
    schemaName: string;
    schemaArn: string;
    description?: string | undefined;
    mappedInputFields: SchemaInputAttribute[];
}
export type AddPolicyStatementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a policy statement object. To retrieve a list of existing policy statements, use the `GetPolicy` API.
 */
export declare const addPolicyStatement: API.OperationMethod<AddPolicyStatementInput & RegionInput, AddPolicyStatementOutput, AddPolicyStatementError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteUniqueIdError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes multiple unique IDs in a matching workflow.
 */
export declare const batchDeleteUniqueId: API.OperationMethod<BatchDeleteUniqueIdInput & RegionInput, BatchDeleteUniqueIdOutput, BatchDeleteUniqueIdError, Credentials | HttpClient.HttpClient>;
export type CreateIdMappingWorkflowError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an `IdMappingWorkflow` object which stores the configuration of the data processing job to be run. Each `IdMappingWorkflow` must have a unique workflow name. To modify an existing workflow, use the UpdateIdMappingWorkflow API.
 *
 * Incremental processing is not supported for ID mapping workflows.
 */
export declare const createIdMappingWorkflow: API.OperationMethod<CreateIdMappingWorkflowInput & RegionInput, CreateIdMappingWorkflowOutput, CreateIdMappingWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateIdNamespaceError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ID namespace object which will help customers provide metadata explaining their dataset and how to use it. Each ID namespace must have a unique name. To modify an existing ID namespace, use the UpdateIdNamespace API.
 */
export declare const createIdNamespace: API.OperationMethod<CreateIdNamespaceInput & RegionInput, CreateIdNamespaceOutput, CreateIdNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateMatchingWorkflowError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a matching workflow that defines the configuration for a data processing job. The workflow name must be unique. To modify an existing workflow, use `UpdateMatchingWorkflow`.
 *
 * For workflows where `resolutionType` is `PROVIDER`, incremental processing is not supported.
 */
export declare const createMatchingWorkflow: API.OperationMethod<CreateMatchingWorkflowInput & RegionInput, CreateMatchingWorkflowOutput, CreateMatchingWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaMappingError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a schema mapping, which defines the schema of the input customer records table. The `SchemaMapping` also provides Entity Resolution with some metadata about the table, such as the attribute types of the columns and which columns to match on.
 */
export declare const createSchemaMapping: API.OperationMethod<CreateSchemaMappingInput & RegionInput, CreateSchemaMappingOutput, CreateSchemaMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteIdMappingWorkflowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the `IdMappingWorkflow` with a given name. This operation returns a `ResourceNotFoundException` if a workflow with the given name does not exist.
 */
export declare const deleteIdMappingWorkflow: API.OperationMethod<DeleteIdMappingWorkflowInput & RegionInput, DeleteIdMappingWorkflowOutput, DeleteIdMappingWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteIdNamespaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | ConflictException | CommonErrors;
/**
 * Deletes the `IdNamespace` with a given name. This operation returns a `ResourceNotFoundException` if an ID namespace with the given name does not exist.
 */
export declare const deleteIdNamespace: API.OperationMethod<DeleteIdNamespaceInput & RegionInput, DeleteIdNamespaceOutput, DeleteIdNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteMatchingWorkflowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the `MatchingWorkflow` with a given name. This operation returns a `ResourceNotFoundException` if a workflow with the given name does not exist.
 */
export declare const deleteMatchingWorkflow: API.OperationMethod<DeleteMatchingWorkflowInput & RegionInput, DeleteMatchingWorkflowOutput, DeleteMatchingWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyStatementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the policy statement.
 */
export declare const deletePolicyStatement: API.OperationMethod<DeletePolicyStatementInput & RegionInput, DeletePolicyStatementOutput, DeletePolicyStatementError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaMappingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the `SchemaMapping` with a given name. This operation returns a `ResourceNotFoundException` if a schema with the given name does not exist. This operation will fail if there is a `MatchingWorkflow` object that references the `SchemaMapping` in the workflow's `InputSourceConfig`.
 */
export declare const deleteSchemaMapping: API.OperationMethod<DeleteSchemaMappingInput & RegionInput, DeleteSchemaMappingOutput, DeleteSchemaMappingError, Credentials | HttpClient.HttpClient>;
export type GenerateMatchIdError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates or retrieves Match IDs for records using a rule-based matching workflow. When you call this operation, it processes your records against the workflow's matching rules to identify potential matches. For existing records, it retrieves their Match IDs and associated rules. For records without matches, it generates new Match IDs. The operation saves results to Amazon S3.
 *
 * The processing type (`processingType`) you choose affects both the accuracy and response time of the operation. Additional charges apply for each API call, whether made through the Entity Resolution console or directly via the API. The rule-based matching workflow must exist and be active before calling this operation.
 */
export declare const generateMatchId: API.OperationMethod<GenerateMatchIdInput & RegionInput, GenerateMatchIdOutput, GenerateMatchIdError, Credentials | HttpClient.HttpClient>;
export type GetIdMappingJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the status, metrics, and errors (if there are any) that are associated with a job.
 */
export declare const getIdMappingJob: API.OperationMethod<GetIdMappingJobInput & RegionInput, GetIdMappingJobOutput, GetIdMappingJobError, Credentials | HttpClient.HttpClient>;
export type GetIdMappingWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the `IdMappingWorkflow` with a given name, if it exists.
 */
export declare const getIdMappingWorkflow: API.OperationMethod<GetIdMappingWorkflowInput & RegionInput, GetIdMappingWorkflowOutput, GetIdMappingWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetIdNamespaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the `IdNamespace` with a given name, if it exists.
 */
export declare const getIdNamespace: API.OperationMethod<GetIdNamespaceInput & RegionInput, GetIdNamespaceOutput, GetIdNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetMatchIdError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the corresponding Match ID of a customer record if the record has been processed in a rule-based matching workflow.
 *
 * You can call this API as a dry run of an incremental load on the rule-based matching workflow.
 */
export declare const getMatchId: API.OperationMethod<GetMatchIdInput & RegionInput, GetMatchIdOutput, GetMatchIdError, Credentials | HttpClient.HttpClient>;
export type GetMatchingJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the status, metrics, and errors (if there are any) that are associated with a job.
 */
export declare const getMatchingJob: API.OperationMethod<GetMatchingJobInput & RegionInput, GetMatchingJobOutput, GetMatchingJobError, Credentials | HttpClient.HttpClient>;
export type GetMatchingWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the `MatchingWorkflow` with a given name, if it exists.
 */
export declare const getMatchingWorkflow: API.OperationMethod<GetMatchingWorkflowInput & RegionInput, GetMatchingWorkflowOutput, GetMatchingWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource-based policy.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyInput & RegionInput, GetPolicyOutput, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProviderServiceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the `ProviderService` of a given name.
 */
export declare const getProviderService: API.OperationMethod<GetProviderServiceInput & RegionInput, GetProviderServiceOutput, GetProviderServiceError, Credentials | HttpClient.HttpClient>;
export type GetSchemaMappingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the SchemaMapping of a given name.
 */
export declare const getSchemaMapping: API.OperationMethod<GetSchemaMappingInput & RegionInput, GetSchemaMappingOutput, GetSchemaMappingError, Credentials | HttpClient.HttpClient>;
export type ListIdMappingJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all ID mapping jobs for a given workflow.
 */
export declare const listIdMappingJobs: API.PaginatedOperationMethod<ListIdMappingJobsInput & RegionInput, ListIdMappingJobsOutput, ListIdMappingJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListIdMappingWorkflowsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the `IdMappingWorkflows` that have been created for an Amazon Web Services account.
 */
export declare const listIdMappingWorkflows: API.PaginatedOperationMethod<ListIdMappingWorkflowsInput & RegionInput, ListIdMappingWorkflowsOutput, ListIdMappingWorkflowsError, Credentials | HttpClient.HttpClient, IdMappingWorkflowSummary>;
export type ListIdNamespacesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all ID namespaces.
 */
export declare const listIdNamespaces: API.PaginatedOperationMethod<ListIdNamespacesInput & RegionInput, ListIdNamespacesOutput, ListIdNamespacesError, Credentials | HttpClient.HttpClient, IdNamespaceSummary>;
export type ListMatchingJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all jobs for a given workflow.
 */
export declare const listMatchingJobs: API.PaginatedOperationMethod<ListMatchingJobsInput & RegionInput, ListMatchingJobsOutput, ListMatchingJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListMatchingWorkflowsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the `MatchingWorkflows` that have been created for an Amazon Web Services account.
 */
export declare const listMatchingWorkflows: API.PaginatedOperationMethod<ListMatchingWorkflowsInput & RegionInput, ListMatchingWorkflowsOutput, ListMatchingWorkflowsError, Credentials | HttpClient.HttpClient, MatchingWorkflowSummary>;
export type ListProviderServicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the `ProviderServices` that are available in this Amazon Web Services Region.
 */
export declare const listProviderServices: API.PaginatedOperationMethod<ListProviderServicesInput & RegionInput, ListProviderServicesOutput, ListProviderServicesError, Credentials | HttpClient.HttpClient, ProviderServiceSummary>;
export type ListSchemaMappingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the `SchemaMappings` that have been created for an Amazon Web Services account.
 */
export declare const listSchemaMappings: API.PaginatedOperationMethod<ListSchemaMappingsInput & RegionInput, ListSchemaMappingsOutput, ListSchemaMappingsError, Credentials | HttpClient.HttpClient, SchemaMappingSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Displays the tags associated with an Entity Resolution resource. In Entity Resolution, `SchemaMapping`, and `MatchingWorkflow` can be tagged.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the resource-based policy.
 */
export declare const putPolicy: API.OperationMethod<PutPolicyInput & RegionInput, PutPolicyOutput, PutPolicyError, Credentials | HttpClient.HttpClient>;
export type StartIdMappingJobError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the `IdMappingJob` of a workflow. The workflow must have previously been created using the `CreateIdMappingWorkflow` endpoint.
 */
export declare const startIdMappingJob: API.OperationMethod<StartIdMappingJobInput & RegionInput, StartIdMappingJobOutput, StartIdMappingJobError, Credentials | HttpClient.HttpClient>;
export type StartMatchingJobError = AccessDeniedException | ConflictException | ExceedsLimitException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the `MatchingJob` of a workflow. The workflow must have previously been created using the `CreateMatchingWorkflow` endpoint.
 */
export declare const startMatchingJob: API.OperationMethod<StartMatchingJobInput & RegionInput, StartMatchingJobOutput, StartMatchingJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified Entity Resolution resource. Tags can help you organize and categorize your resources. You can also use them to scope user permissions by granting a user permission to access or change only resources with certain tag values. In Entity Resolution, `SchemaMapping` and `MatchingWorkflow` can be tagged. Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of characters. You can use the `TagResource` action with a resource that already has tags. If you specify a new tag key, this tag is appended to the list of tags associated with the resource. If you specify a tag key that is already associated with the resource, the new tag value that you specify replaces the previous value for that tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from the specified Entity Resolution resource. In Entity Resolution, `SchemaMapping`, and `MatchingWorkflow` can be tagged.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateIdMappingWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing `IdMappingWorkflow`. This method is identical to CreateIdMappingWorkflow, except it uses an HTTP `PUT` request instead of a `POST` request, and the `IdMappingWorkflow` must already exist for the method to succeed.
 *
 * Incremental processing is not supported for ID mapping workflows.
 */
export declare const updateIdMappingWorkflow: API.OperationMethod<UpdateIdMappingWorkflowInput & RegionInput, UpdateIdMappingWorkflowOutput, UpdateIdMappingWorkflowError, Credentials | HttpClient.HttpClient>;
export type UpdateIdNamespaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing ID namespace.
 */
export declare const updateIdNamespace: API.OperationMethod<UpdateIdNamespaceInput & RegionInput, UpdateIdNamespaceOutput, UpdateIdNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdateMatchingWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing matching workflow. The workflow must already exist for this operation to succeed.
 *
 * For workflows where `resolutionType` is `PROVIDER`, incremental processing is not supported.
 */
export declare const updateMatchingWorkflow: API.OperationMethod<UpdateMatchingWorkflowInput & RegionInput, UpdateMatchingWorkflowOutput, UpdateMatchingWorkflowError, Credentials | HttpClient.HttpClient>;
export type UpdateSchemaMappingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a schema mapping.
 *
 * A schema is immutable if it is being used by a workflow. Therefore, you can't update a schema mapping if it's associated with a workflow.
 */
export declare const updateSchemaMapping: API.OperationMethod<UpdateSchemaMappingInput & RegionInput, UpdateSchemaMappingOutput, UpdateSchemaMappingError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=entityresolution.d.ts.map