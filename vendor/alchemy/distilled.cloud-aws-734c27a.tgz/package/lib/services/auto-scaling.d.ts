import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ActiveInstanceRefreshNotFoundFault_base: S.TaggedErrorClass<"ActiveInstanceRefreshNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ActiveInstanceRefreshNotFoundFault extends /*@__PURE__*/ ActiveInstanceRefreshNotFoundFault_base {
}
declare const AlreadyExistsFault_base: S.TaggedErrorClass<"AlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsFault extends /*@__PURE__*/ AlreadyExistsFault_base {
}
declare const AutoScalingGroupNotFound_base: S.TaggedErrorClass<"AutoScalingGroupNotFound", {
    readonly message: any;
}>;
export declare class AutoScalingGroupNotFound extends /*@__PURE__*/ AutoScalingGroupNotFound_base {
}
declare const IdempotentCallInProgressFault_base: S.TaggedErrorClass<"IdempotentCallInProgressFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class IdempotentCallInProgressFault extends /*@__PURE__*/ IdempotentCallInProgressFault_base {
}
declare const IdempotentParameterMismatchError_base: S.TaggedErrorClass<"IdempotentParameterMismatchError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchError extends /*@__PURE__*/ IdempotentParameterMismatchError_base {
}
declare const InstanceRefreshInProgressFault_base: S.TaggedErrorClass<"InstanceRefreshInProgressFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InstanceRefreshInProgressFault extends /*@__PURE__*/ InstanceRefreshInProgressFault_base {
}
declare const InvalidIamInstanceProfile_base: S.TaggedErrorClass<"InvalidIamInstanceProfile", {
    readonly message: any;
}>;
export declare class InvalidIamInstanceProfile extends /*@__PURE__*/ InvalidIamInstanceProfile_base {
}
declare const InvalidNextToken_base: S.TaggedErrorClass<"InvalidNextToken", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextToken extends /*@__PURE__*/ InvalidNextToken_base {
}
declare const IrreversibleInstanceRefreshFault_base: S.TaggedErrorClass<"IrreversibleInstanceRefreshFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IrreversibleInstanceRefreshFault extends /*@__PURE__*/ IrreversibleInstanceRefreshFault_base {
}
declare const LimitExceededFault_base: S.TaggedErrorClass<"LimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededFault extends /*@__PURE__*/ LimitExceededFault_base {
}
declare const ResourceContentionFault_base: S.TaggedErrorClass<"ResourceContentionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ResourceContentionFault extends /*@__PURE__*/ ResourceContentionFault_base {
}
declare const ResourceInUseFault_base: S.TaggedErrorClass<"ResourceInUseFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseFault extends /*@__PURE__*/ ResourceInUseFault_base {
}
declare const ScalingActivityInProgressFault_base: S.TaggedErrorClass<"ScalingActivityInProgressFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ScalingActivityInProgressFault extends /*@__PURE__*/ ScalingActivityInProgressFault_base {
}
declare const ServiceLinkedRoleFailure_base: S.TaggedErrorClass<"ServiceLinkedRoleFailure", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceLinkedRoleFailure extends /*@__PURE__*/ ServiceLinkedRoleFailure_base {
}
export type XmlStringMaxLen19 = string;
export type InstanceIds = string[];
export type XmlStringMaxLen255 = string;
export interface AttachInstancesQuery {
    InstanceIds?: string[] | undefined;
    AutoScalingGroupName?: string | undefined;
}
export interface AttachInstancesResponse {
}
export type LoadBalancerNames = string[];
export interface AttachLoadBalancersType {
    AutoScalingGroupName?: string | undefined;
    LoadBalancerNames?: string[] | undefined;
}
export interface AttachLoadBalancersResultType {
}
export type XmlStringMaxLen511 = string;
export type TargetGroupARNs = string[];
export interface AttachLoadBalancerTargetGroupsType {
    AutoScalingGroupName?: string | undefined;
    TargetGroupARNs?: string[] | undefined;
}
export interface AttachLoadBalancerTargetGroupsResultType {
}
export interface TrafficSourceIdentifier {
    Identifier?: string | undefined;
    Type?: string | undefined;
}
export type TrafficSources = TrafficSourceIdentifier[];
export type SkipZonalShiftValidation = boolean;
export interface AttachTrafficSourcesType {
    AutoScalingGroupName?: string | undefined;
    TrafficSources?: TrafficSourceIdentifier[] | undefined;
    SkipZonalShiftValidation?: boolean | undefined;
}
export interface AttachTrafficSourcesResultType {
}
export type ScheduledActionNames = string[];
export interface BatchDeleteScheduledActionType {
    AutoScalingGroupName?: string | undefined;
    ScheduledActionNames?: string[] | undefined;
}
export type XmlStringMaxLen64 = string;
export type XmlString = string;
export interface FailedScheduledUpdateGroupActionRequest {
    ScheduledActionName?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type FailedScheduledUpdateGroupActionRequests = FailedScheduledUpdateGroupActionRequest[];
export interface BatchDeleteScheduledActionAnswer {
    FailedScheduledActions?: (FailedScheduledUpdateGroupActionRequest & {
        ScheduledActionName: XmlStringMaxLen255;
    })[] | undefined;
}
export type AutoScalingGroupMinSize = number;
export type AutoScalingGroupMaxSize = number;
export type AutoScalingGroupDesiredCapacity = number;
export interface ScheduledUpdateGroupActionRequest {
    ScheduledActionName?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Recurrence?: string | undefined;
    MinSize?: number | undefined;
    MaxSize?: number | undefined;
    DesiredCapacity?: number | undefined;
    TimeZone?: string | undefined;
}
export type ScheduledUpdateGroupActionRequests = ScheduledUpdateGroupActionRequest[];
export interface BatchPutScheduledUpdateGroupActionType {
    AutoScalingGroupName?: string | undefined;
    ScheduledUpdateGroupActions?: ScheduledUpdateGroupActionRequest[] | undefined;
}
export interface BatchPutScheduledUpdateGroupActionAnswer {
    FailedScheduledUpdateGroupActions?: (FailedScheduledUpdateGroupActionRequest & {
        ScheduledActionName: XmlStringMaxLen255;
    })[] | undefined;
}
export interface CancelInstanceRefreshType {
    AutoScalingGroupName?: string | undefined;
    WaitForTransitioningInstances?: boolean | undefined;
}
export interface CancelInstanceRefreshAnswer {
    InstanceRefreshId?: string | undefined;
}
export type AsciiStringMaxLen255 = string;
export type ResourceName = string;
export type LifecycleActionToken = string;
export type LifecycleActionResult = string;
export interface CompleteLifecycleActionType {
    LifecycleHookName?: string | undefined;
    AutoScalingGroupName?: string | undefined;
    LifecycleActionToken?: string | undefined;
    LifecycleActionResult?: string | undefined;
    InstanceId?: string | undefined;
}
export interface CompleteLifecycleActionAnswer {
}
export type LaunchTemplateName = string;
export interface LaunchTemplateSpecification {
    LaunchTemplateId?: string | undefined;
    LaunchTemplateName?: string | undefined;
    Version?: string | undefined;
}
export type XmlStringMaxLen32 = string;
export type NullablePositiveInteger = number;
export interface VCpuCountRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export interface MemoryMiBRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export type CpuManufacturer = "intel" | "amd" | "amazon-web-services" | "apple" | (string & {});
export type CpuManufacturers = CpuManufacturer[];
export type NullablePositiveDouble = number;
export interface MemoryGiBPerVCpuRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export type ExcludedInstance = string;
export type ExcludedInstanceTypes = string[];
export type InstanceGeneration = "current" | "previous" | (string & {});
export type InstanceGenerations = InstanceGeneration[];
export type BareMetal = "included" | "excluded" | "required" | (string & {});
export type BurstablePerformance = "included" | "excluded" | "required" | (string & {});
export interface NetworkInterfaceCountRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export type LocalStorage = "included" | "excluded" | "required" | (string & {});
export type LocalStorageType = "hdd" | "ssd" | (string & {});
export type LocalStorageTypes = LocalStorageType[];
export interface TotalLocalStorageGBRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export interface BaselineEbsBandwidthMbpsRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export type AcceleratorType = "gpu" | "fpga" | "inference" | (string & {});
export type AcceleratorTypes = AcceleratorType[];
export interface AcceleratorCountRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export type AcceleratorManufacturer = "nvidia" | "amd" | "amazon-web-services" | "xilinx" | (string & {});
export type AcceleratorManufacturers = AcceleratorManufacturer[];
export type AcceleratorName = "a100" | "v100" | "k80" | "t4" | "m60" | "radeon-pro-v520" | "vu9p" | (string & {});
export type AcceleratorNames = AcceleratorName[];
export interface AcceleratorTotalMemoryMiBRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export interface NetworkBandwidthGbpsRequest {
    Min?: number | undefined;
    Max?: number | undefined;
}
export type AllowedInstanceType = string;
export type AllowedInstanceTypes = string[];
export interface PerformanceFactorReferenceRequest {
    InstanceFamily?: string | undefined;
}
export type PerformanceFactorReferenceSetRequest = PerformanceFactorReferenceRequest[];
export interface CpuPerformanceFactorRequest {
    References?: PerformanceFactorReferenceRequest[] | undefined;
}
export interface BaselinePerformanceFactorsRequest {
    Cpu?: CpuPerformanceFactorRequest | undefined;
}
export interface InstanceRequirements {
    VCpuCount?: VCpuCountRequest | undefined;
    MemoryMiB?: MemoryMiBRequest | undefined;
    CpuManufacturers?: CpuManufacturer[] | undefined;
    MemoryGiBPerVCpu?: MemoryGiBPerVCpuRequest | undefined;
    ExcludedInstanceTypes?: string[] | undefined;
    InstanceGenerations?: InstanceGeneration[] | undefined;
    SpotMaxPricePercentageOverLowestPrice?: number | undefined;
    MaxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number | undefined;
    OnDemandMaxPricePercentageOverLowestPrice?: number | undefined;
    BareMetal?: BareMetal | undefined;
    BurstablePerformance?: BurstablePerformance | undefined;
    RequireHibernateSupport?: boolean | undefined;
    NetworkInterfaceCount?: NetworkInterfaceCountRequest | undefined;
    LocalStorage?: LocalStorage | undefined;
    LocalStorageTypes?: LocalStorageType[] | undefined;
    TotalLocalStorageGB?: TotalLocalStorageGBRequest | undefined;
    BaselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsRequest | undefined;
    AcceleratorTypes?: AcceleratorType[] | undefined;
    AcceleratorCount?: AcceleratorCountRequest | undefined;
    AcceleratorManufacturers?: AcceleratorManufacturer[] | undefined;
    AcceleratorNames?: AcceleratorName[] | undefined;
    AcceleratorTotalMemoryMiB?: AcceleratorTotalMemoryMiBRequest | undefined;
    NetworkBandwidthGbps?: NetworkBandwidthGbpsRequest | undefined;
    AllowedInstanceTypes?: string[] | undefined;
    BaselinePerformanceFactors?: BaselinePerformanceFactorsRequest | undefined;
}
export type ImageId = string;
export interface LaunchTemplateOverrides {
    InstanceType?: string | undefined;
    WeightedCapacity?: string | undefined;
    LaunchTemplateSpecification?: LaunchTemplateSpecification | undefined;
    InstanceRequirements?: InstanceRequirements | undefined;
    ImageId?: string | undefined;
}
export type Overrides = LaunchTemplateOverrides[];
export interface LaunchTemplate {
    LaunchTemplateSpecification?: LaunchTemplateSpecification | undefined;
    Overrides?: LaunchTemplateOverrides[] | undefined;
}
export type OnDemandBaseCapacity = number;
export type OnDemandPercentageAboveBaseCapacity = number;
export type SpotInstancePools = number;
export type MixedInstanceSpotPrice = string;
export type TargetCapacityType = "on-demand-capacity-reservation" | "capacity-block" | "interruptible-capacity-reservation" | "on-demand" | (string & {});
export type TargetCapacityTypes = TargetCapacityType[];
export interface DistributionSegment {
    TargetCapacityTypes?: TargetCapacityType[] | undefined;
}
export type DistributionSegments = DistributionSegment[];
export interface InstancesDistribution {
    OnDemandAllocationStrategy?: string | undefined;
    OnDemandBaseCapacity?: number | undefined;
    OnDemandPercentageAboveBaseCapacity?: number | undefined;
    SpotAllocationStrategy?: string | undefined;
    SpotInstancePools?: number | undefined;
    SpotMaxPrice?: string | undefined;
    DistributionSegments?: DistributionSegment[] | undefined;
}
export interface MixedInstancesPolicy {
    LaunchTemplate?: LaunchTemplate | undefined;
    InstancesDistribution?: InstancesDistribution | undefined;
}
export type Cooldown = number;
export type AvailabilityZones = string[];
export type AvailabilityZoneIds = string[];
export type HealthCheckGracePeriod = number;
export type XmlStringMaxLen5000 = string;
export type XmlStringMaxLen1600 = string;
export type TerminationPolicies = string[];
export type InstanceProtected = boolean;
export type CapacityRebalanceEnabled = boolean;
export type LifecycleTransition = string;
export type AnyPrintableAsciiStringMaxLen4000 = string;
export type HeartbeatTimeout = number;
export type NotificationTargetResourceName = string;
export interface LifecycleHookSpecification {
    LifecycleHookName?: string | undefined;
    LifecycleTransition?: string | undefined;
    NotificationMetadata?: string | undefined;
    HeartbeatTimeout?: number | undefined;
    DefaultResult?: string | undefined;
    NotificationTargetARN?: string | undefined;
    RoleARN?: string | undefined;
}
export type LifecycleHookSpecifications = LifecycleHookSpecification[];
export type DeletionProtection = "none" | "prevent-force-deletion" | "prevent-all-deletion" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type PropagateAtLaunch = boolean;
export interface Tag {
    ResourceId?: string | undefined;
    ResourceType?: string | undefined;
    Key?: string | undefined;
    Value?: string | undefined;
    PropagateAtLaunch?: boolean | undefined;
}
export type Tags = Tag[];
export type MaxInstanceLifetime = number;
export type Context = string;
export type DefaultInstanceWarmup = number;
export type IntPercentResettable = number;
export type IntPercent100To200Resettable = number;
export interface InstanceMaintenancePolicy {
    MinHealthyPercentage?: number | undefined;
    MaxHealthyPercentage?: number | undefined;
}
export type CapacityDistributionStrategy = "balanced-only" | "balanced-best-effort" | "reservations-then-balanced" | (string & {});
export interface AvailabilityZoneDistribution {
    CapacityDistributionStrategy?: CapacityDistributionStrategy | undefined;
}
export type ZonalShiftEnabled = boolean;
export type ImpairedZoneHealthCheckBehavior = "ReplaceUnhealthy" | "IgnoreUnhealthy" | (string & {});
export interface AvailabilityZoneImpairmentPolicy {
    ZonalShiftEnabled?: boolean | undefined;
    ImpairedZoneHealthCheckBehavior?: ImpairedZoneHealthCheckBehavior | undefined;
}
export type CapacityReservationPreference = "capacity-reservations-only" | "capacity-reservations-first" | "none" | "default" | (string & {});
export type CapacityReservationIds = string[];
export type CapacityReservationResourceGroupArns = string[];
export interface CapacityReservationTarget {
    CapacityReservationIds?: string[] | undefined;
    CapacityReservationResourceGroupArns?: string[] | undefined;
}
export interface CapacityReservationSpecification {
    CapacityReservationPreference?: CapacityReservationPreference | undefined;
    CapacityReservationTarget?: CapacityReservationTarget | undefined;
}
export type RetentionAction = "retain" | "terminate" | (string & {});
export interface RetentionTriggers {
    TerminateHookAbandon?: RetentionAction | undefined;
}
export interface InstanceLifecyclePolicy {
    RetentionTriggers?: RetentionTriggers | undefined;
}
export type ManagerIdentifier = string;
export interface Operator {
    Principal?: string | undefined;
}
export interface CreateAutoScalingGroupType {
    AutoScalingGroupName?: string | undefined;
    LaunchConfigurationName?: string | undefined;
    LaunchTemplate?: LaunchTemplateSpecification | undefined;
    MixedInstancesPolicy?: MixedInstancesPolicy | undefined;
    InstanceId?: string | undefined;
    MinSize?: number | undefined;
    MaxSize?: number | undefined;
    DesiredCapacity?: number | undefined;
    DefaultCooldown?: number | undefined;
    AvailabilityZones?: string[] | undefined;
    AvailabilityZoneIds?: string[] | undefined;
    LoadBalancerNames?: string[] | undefined;
    TargetGroupARNs?: string[] | undefined;
    HealthCheckType?: string | undefined;
    HealthCheckGracePeriod?: number | undefined;
    PlacementGroup?: string | undefined;
    VPCZoneIdentifier?: string | undefined;
    TerminationPolicies?: string[] | undefined;
    NewInstancesProtectedFromScaleIn?: boolean | undefined;
    CapacityRebalance?: boolean | undefined;
    LifecycleHookSpecificationList?: LifecycleHookSpecification[] | undefined;
    DeletionProtection?: DeletionProtection | undefined;
    Tags?: Tag[] | undefined;
    ServiceLinkedRoleARN?: string | undefined;
    MaxInstanceLifetime?: number | undefined;
    Context?: string | undefined;
    DesiredCapacityType?: string | undefined;
    DefaultInstanceWarmup?: number | undefined;
    TrafficSources?: TrafficSourceIdentifier[] | undefined;
    InstanceMaintenancePolicy?: InstanceMaintenancePolicy | undefined;
    AvailabilityZoneDistribution?: AvailabilityZoneDistribution | undefined;
    AvailabilityZoneImpairmentPolicy?: AvailabilityZoneImpairmentPolicy | undefined;
    SkipZonalShiftValidation?: boolean | undefined;
    CapacityReservationSpecification?: CapacityReservationSpecification | undefined;
    InstanceLifecyclePolicy?: InstanceLifecyclePolicy | undefined;
    Operator?: Operator | undefined;
}
export interface CreateAutoScalingGroupResponse {
}
export type SecurityGroups = string[];
export type ClassicLinkVPCSecurityGroups = string[];
export type XmlStringUserData = string;
export type BlockDeviceEbsVolumeSize = number;
export type BlockDeviceEbsVolumeType = string;
export type BlockDeviceEbsDeleteOnTermination = boolean;
export type BlockDeviceEbsIops = number;
export type BlockDeviceEbsEncrypted = boolean;
export type BlockDeviceEbsThroughput = number;
export interface Ebs {
    SnapshotId?: string | undefined;
    VolumeSize?: number | undefined;
    VolumeType?: string | undefined;
    DeleteOnTermination?: boolean | undefined;
    Iops?: number | undefined;
    Encrypted?: boolean | undefined;
    Throughput?: number | undefined;
}
export type NoDevice = boolean;
export interface BlockDeviceMapping {
    VirtualName?: string | undefined;
    DeviceName?: string | undefined;
    Ebs?: Ebs | undefined;
    NoDevice?: boolean | undefined;
}
export type BlockDeviceMappings = BlockDeviceMapping[];
export type MonitoringEnabled = boolean;
export interface InstanceMonitoring {
    Enabled?: boolean | undefined;
}
export type SpotPrice = string;
export type EbsOptimized = boolean;
export type AssociatePublicIpAddress = boolean;
export type InstanceMetadataHttpTokensState = "optional" | "required" | (string & {});
export type InstanceMetadataHttpPutResponseHopLimit = number;
export type InstanceMetadataEndpointState = "disabled" | "enabled" | (string & {});
export interface InstanceMetadataOptions {
    HttpTokens?: InstanceMetadataHttpTokensState | undefined;
    HttpPutResponseHopLimit?: number | undefined;
    HttpEndpoint?: InstanceMetadataEndpointState | undefined;
}
export interface CreateLaunchConfigurationType {
    LaunchConfigurationName?: string | undefined;
    ImageId?: string | undefined;
    KeyName?: string | undefined;
    SecurityGroups?: string[] | undefined;
    ClassicLinkVPCId?: string | undefined;
    ClassicLinkVPCSecurityGroups?: string[] | undefined;
    UserData?: string | undefined;
    InstanceId?: string | undefined;
    InstanceType?: string | undefined;
    KernelId?: string | undefined;
    RamdiskId?: string | undefined;
    BlockDeviceMappings?: BlockDeviceMapping[] | undefined;
    InstanceMonitoring?: InstanceMonitoring | undefined;
    SpotPrice?: string | undefined;
    IamInstanceProfile?: string | undefined;
    EbsOptimized?: boolean | undefined;
    AssociatePublicIpAddress?: boolean | undefined;
    PlacementTenancy?: string | undefined;
    MetadataOptions?: InstanceMetadataOptions | undefined;
}
export interface CreateLaunchConfigurationResponse {
}
export interface CreateOrUpdateTagsType {
    Tags?: Tag[] | undefined;
}
export interface CreateOrUpdateTagsResponse {
}
export type ForceDelete = boolean;
export interface DeleteAutoScalingGroupType {
    AutoScalingGroupName?: string | undefined;
    ForceDelete?: boolean | undefined;
}
export interface DeleteAutoScalingGroupResponse {
}
export interface LaunchConfigurationNameType {
    LaunchConfigurationName?: string | undefined;
}
export interface DeleteLaunchConfigurationResponse {
}
export interface DeleteLifecycleHookType {
    LifecycleHookName?: string | undefined;
    AutoScalingGroupName?: string | undefined;
}
export interface DeleteLifecycleHookAnswer {
}
export interface DeleteNotificationConfigurationType {
    AutoScalingGroupName?: string | undefined;
    TopicARN?: string | undefined;
}
export interface DeleteNotificationConfigurationResponse {
}
export interface DeletePolicyType {
    AutoScalingGroupName?: string | undefined;
    PolicyName?: string | undefined;
}
export interface DeletePolicyResponse {
}
export interface DeleteScheduledActionType {
    AutoScalingGroupName?: string | undefined;
    ScheduledActionName?: string | undefined;
}
export interface DeleteScheduledActionResponse {
}
export interface DeleteTagsType {
    Tags?: Tag[] | undefined;
}
export interface DeleteTagsResponse {
}
export interface DeleteWarmPoolType {
    AutoScalingGroupName?: string | undefined;
    ForceDelete?: boolean | undefined;
}
export interface DeleteWarmPoolAnswer {
}
export interface DescribeAccountLimitsRequest {
}
export type MaxNumberOfAutoScalingGroups = number;
export type MaxNumberOfLaunchConfigurations = number;
export type NumberOfAutoScalingGroups = number;
export type NumberOfLaunchConfigurations = number;
export interface DescribeAccountLimitsAnswer {
    MaxNumberOfAutoScalingGroups?: number | undefined;
    MaxNumberOfLaunchConfigurations?: number | undefined;
    NumberOfAutoScalingGroups?: number | undefined;
    NumberOfLaunchConfigurations?: number | undefined;
}
export type MaxRecords = number;
export interface DescribeAccountSettingsType {
    Name?: string | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface AccountSetting {
    Name?: string | undefined;
    Value?: string | undefined;
    EnforcementType?: string | undefined;
    EnforcementDate?: Date | undefined;
    DefaultValue?: string | undefined;
    EnforcedValue?: string | undefined;
}
export type AccountSettings = AccountSetting[];
export interface DescribeAccountSettingsAnswer {
    Settings?: AccountSetting[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeAdjustmentTypesRequest {
}
export interface AdjustmentType {
    AdjustmentType?: string | undefined;
}
export type AdjustmentTypes = AdjustmentType[];
export interface DescribeAdjustmentTypesAnswer {
    AdjustmentTypes?: AdjustmentType[] | undefined;
}
export type AutoScalingGroupNames = string[];
export type IncludeInstances = boolean;
export type IncludeManagedResources = boolean;
export type Values = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type Filters = Filter[];
export interface AutoScalingGroupNamesType {
    AutoScalingGroupNames?: string[] | undefined;
    IncludeInstances?: boolean | undefined;
    IncludeManagedResources?: boolean | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
    Filters?: Filter[] | undefined;
}
export type AutoScalingGroupPredictedCapacity = number;
export type LifecycleState = "Pending" | "Pending:Wait" | "Pending:Proceed" | "Quarantined" | "InService" | "Terminating" | "Terminating:Wait" | "Terminating:Proceed" | "Terminating:Retained" | "Terminated" | "Detaching" | "Detached" | "EnteringStandby" | "Standby" | "ReplacingRootVolume" | "ReplacingRootVolume:Wait" | "ReplacingRootVolume:Proceed" | "RootVolumeReplaced" | "Warmed:Pending" | "Warmed:Pending:Wait" | "Warmed:Pending:Proceed" | "Warmed:Pending:Retained" | "Warmed:Terminating" | "Warmed:Terminating:Wait" | "Warmed:Terminating:Proceed" | "Warmed:Terminating:Retained" | "Warmed:Terminated" | "Warmed:Stopped" | "Warmed:Running" | "Warmed:Hibernated" | (string & {});
export interface Instance {
    InstanceId?: string | undefined;
    InstanceType?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    LifecycleState?: LifecycleState | undefined;
    HealthStatus?: string | undefined;
    LaunchConfigurationName?: string | undefined;
    LaunchTemplate?: LaunchTemplateSpecification | undefined;
    ImageId?: string | undefined;
    ProtectedFromScaleIn?: boolean | undefined;
    WeightedCapacity?: string | undefined;
}
export type Instances = Instance[];
export interface SuspendedProcess {
    ProcessName?: string | undefined;
    SuspensionReason?: string | undefined;
}
export type SuspendedProcesses = SuspendedProcess[];
export interface EnabledMetric {
    Metric?: string | undefined;
    Granularity?: string | undefined;
}
export type EnabledMetrics = EnabledMetric[];
export interface TagDescription {
    ResourceId?: string | undefined;
    ResourceType?: string | undefined;
    Key?: string | undefined;
    Value?: string | undefined;
    PropagateAtLaunch?: boolean | undefined;
}
export type TagDescriptionList = TagDescription[];
export type MaxGroupPreparedCapacity = number;
export type WarmPoolMinSize = number;
export type WarmPoolState = "Stopped" | "Running" | "Hibernated" | (string & {});
export type WarmPoolStatus = "PendingDelete" | (string & {});
export type ReuseOnScaleIn = boolean;
export interface InstanceReusePolicy {
    ReuseOnScaleIn?: boolean | undefined;
}
export interface WarmPoolConfiguration {
    MaxGroupPreparedCapacity?: number | undefined;
    MinSize?: number | undefined;
    PoolState?: WarmPoolState | undefined;
    Status?: WarmPoolStatus | undefined;
    InstanceReusePolicy?: InstanceReusePolicy | undefined;
}
export type WarmPoolSize = number;
export interface AutoScalingGroup {
    AutoScalingGroupName?: string | undefined;
    AutoScalingGroupARN?: string | undefined;
    LaunchConfigurationName?: string | undefined;
    LaunchTemplate?: LaunchTemplateSpecification | undefined;
    MixedInstancesPolicy?: MixedInstancesPolicy | undefined;
    MinSize?: number | undefined;
    MaxSize?: number | undefined;
    DesiredCapacity?: number | undefined;
    PredictedCapacity?: number | undefined;
    DefaultCooldown?: number | undefined;
    AvailabilityZones?: string[] | undefined;
    AvailabilityZoneIds?: string[] | undefined;
    LoadBalancerNames?: string[] | undefined;
    TargetGroupARNs?: string[] | undefined;
    HealthCheckType?: string | undefined;
    HealthCheckGracePeriod?: number | undefined;
    Instances?: Instance[] | undefined;
    CreatedTime?: Date | undefined;
    SuspendedProcesses?: SuspendedProcess[] | undefined;
    PlacementGroup?: string | undefined;
    VPCZoneIdentifier?: string | undefined;
    EnabledMetrics?: EnabledMetric[] | undefined;
    Status?: string | undefined;
    Tags?: TagDescription[] | undefined;
    TerminationPolicies?: string[] | undefined;
    NewInstancesProtectedFromScaleIn?: boolean | undefined;
    ServiceLinkedRoleARN?: string | undefined;
    MaxInstanceLifetime?: number | undefined;
    CapacityRebalance?: boolean | undefined;
    WarmPoolConfiguration?: WarmPoolConfiguration | undefined;
    WarmPoolSize?: number | undefined;
    Context?: string | undefined;
    DesiredCapacityType?: string | undefined;
    DefaultInstanceWarmup?: number | undefined;
    TrafficSources?: TrafficSourceIdentifier[] | undefined;
    InstanceMaintenancePolicy?: InstanceMaintenancePolicy | undefined;
    DeletionProtection?: DeletionProtection | undefined;
    AvailabilityZoneDistribution?: AvailabilityZoneDistribution | undefined;
    AvailabilityZoneImpairmentPolicy?: AvailabilityZoneImpairmentPolicy | undefined;
    CapacityReservationSpecification?: CapacityReservationSpecification | undefined;
    InstanceLifecyclePolicy?: InstanceLifecyclePolicy | undefined;
    Operator?: Operator | undefined;
}
export type AutoScalingGroups = AutoScalingGroup[];
export interface AutoScalingGroupsType {
    AutoScalingGroups: (AutoScalingGroup & {
        AutoScalingGroupName: XmlStringMaxLen255;
        MinSize: AutoScalingGroupMinSize;
        MaxSize: AutoScalingGroupMaxSize;
        DesiredCapacity: AutoScalingGroupDesiredCapacity;
        DefaultCooldown: Cooldown;
        AvailabilityZones: AvailabilityZones;
        HealthCheckType: XmlStringMaxLen32;
        CreatedTime: Date;
        MixedInstancesPolicy: MixedInstancesPolicy & {
            LaunchTemplate: LaunchTemplate & {
                Overrides: (LaunchTemplateOverrides & {
                    InstanceRequirements: InstanceRequirements & {
                        VCpuCount: VCpuCountRequest & {
                            Min: NullablePositiveInteger;
                        };
                        MemoryMiB: MemoryMiBRequest & {
                            Min: NullablePositiveInteger;
                        };
                    };
                })[];
            };
        };
        Instances: (Instance & {
            InstanceId: XmlStringMaxLen19;
            AvailabilityZone: XmlStringMaxLen255;
            LifecycleState: LifecycleState;
            HealthStatus: XmlStringMaxLen32;
            ProtectedFromScaleIn: InstanceProtected;
        })[];
        TrafficSources: (TrafficSourceIdentifier & {
            Identifier: XmlStringMaxLen511;
        })[];
        Operator: Operator & {
            Principal: ManagerIdentifier;
        };
    })[];
    NextToken?: string | undefined;
}
export interface DescribeAutoScalingInstancesType {
    InstanceIds?: string[] | undefined;
    IncludeManagedResources?: boolean | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface AutoScalingInstanceDetails {
    InstanceId?: string | undefined;
    InstanceType?: string | undefined;
    AutoScalingGroupName?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    LifecycleState?: string | undefined;
    HealthStatus?: string | undefined;
    LaunchConfigurationName?: string | undefined;
    LaunchTemplate?: LaunchTemplateSpecification | undefined;
    ImageId?: string | undefined;
    ProtectedFromScaleIn?: boolean | undefined;
    WeightedCapacity?: string | undefined;
}
export type AutoScalingInstances = AutoScalingInstanceDetails[];
export interface AutoScalingInstancesType {
    AutoScalingInstances?: (AutoScalingInstanceDetails & {
        InstanceId: XmlStringMaxLen19;
        AutoScalingGroupName: XmlStringMaxLen255;
        AvailabilityZone: XmlStringMaxLen255;
        LifecycleState: XmlStringMaxLen32;
        HealthStatus: XmlStringMaxLen32;
        ProtectedFromScaleIn: InstanceProtected;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeAutoScalingNotificationTypesRequest {
}
export type AutoScalingNotificationTypes = string[];
export interface DescribeAutoScalingNotificationTypesAnswer {
    AutoScalingNotificationTypes?: string[] | undefined;
}
export type InstanceRefreshIds = string[];
export interface DescribeInstanceRefreshesType {
    AutoScalingGroupName?: string | undefined;
    InstanceRefreshIds?: string[] | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export type InstanceRefreshStatus = "Pending" | "InProgress" | "Successful" | "Failed" | "Cancelling" | "Cancelled" | "RollbackInProgress" | "RollbackFailed" | "RollbackSuccessful" | "Baking" | (string & {});
export type XmlStringMaxLen1023 = string;
export type IntPercent = number;
export type InstancesToUpdate = number;
export interface InstanceRefreshLivePoolProgress {
    PercentageComplete?: number | undefined;
    InstancesToUpdate?: number | undefined;
}
export interface InstanceRefreshWarmPoolProgress {
    PercentageComplete?: number | undefined;
    InstancesToUpdate?: number | undefined;
}
export interface InstanceRefreshProgressDetails {
    LivePoolProgress?: InstanceRefreshLivePoolProgress | undefined;
    WarmPoolProgress?: InstanceRefreshWarmPoolProgress | undefined;
}
export type RefreshInstanceWarmup = number;
export type NonZeroIntPercent = number;
export type CheckpointPercentages = number[];
export type CheckpointDelay = number;
export type SkipMatching = boolean;
export type AutoRollback = boolean;
export type ScaleInProtectedInstances = "Refresh" | "Ignore" | "Wait" | (string & {});
export type StandbyInstances = "Terminate" | "Ignore" | "Wait" | (string & {});
export type AlarmList = string[];
export interface AlarmSpecification {
    Alarms?: string[] | undefined;
}
export type IntPercent100To200 = number;
export type BakeTime = number;
export interface RefreshPreferences {
    MinHealthyPercentage?: number | undefined;
    InstanceWarmup?: number | undefined;
    CheckpointPercentages?: number[] | undefined;
    CheckpointDelay?: number | undefined;
    SkipMatching?: boolean | undefined;
    AutoRollback?: boolean | undefined;
    ScaleInProtectedInstances?: ScaleInProtectedInstances | undefined;
    StandbyInstances?: StandbyInstances | undefined;
    AlarmSpecification?: AlarmSpecification | undefined;
    MaxHealthyPercentage?: number | undefined;
    BakeTime?: number | undefined;
}
export interface DesiredConfiguration {
    LaunchTemplate?: LaunchTemplateSpecification | undefined;
    MixedInstancesPolicy?: MixedInstancesPolicy | undefined;
}
export interface RollbackDetails {
    RollbackReason?: string | undefined;
    RollbackStartTime?: Date | undefined;
    PercentageCompleteOnRollback?: number | undefined;
    InstancesToUpdateOnRollback?: number | undefined;
    ProgressDetailsOnRollback?: InstanceRefreshProgressDetails | undefined;
}
export type RefreshStrategy = "Rolling" | "ReplaceRootVolume" | (string & {});
export interface InstanceRefresh {
    InstanceRefreshId?: string | undefined;
    AutoScalingGroupName?: string | undefined;
    Status?: InstanceRefreshStatus | undefined;
    StatusReason?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    PercentageComplete?: number | undefined;
    InstancesToUpdate?: number | undefined;
    ProgressDetails?: InstanceRefreshProgressDetails | undefined;
    Preferences?: RefreshPreferences | undefined;
    DesiredConfiguration?: DesiredConfiguration | undefined;
    RollbackDetails?: RollbackDetails | undefined;
    Strategy?: RefreshStrategy | undefined;
}
export type InstanceRefreshes = InstanceRefresh[];
export interface DescribeInstanceRefreshesAnswer {
    InstanceRefreshes?: (InstanceRefresh & {
        DesiredConfiguration: DesiredConfiguration & {
            MixedInstancesPolicy: MixedInstancesPolicy & {
                LaunchTemplate: LaunchTemplate & {
                    Overrides: (LaunchTemplateOverrides & {
                        InstanceRequirements: InstanceRequirements & {
                            VCpuCount: VCpuCountRequest & {
                                Min: NullablePositiveInteger;
                            };
                            MemoryMiB: MemoryMiBRequest & {
                                Min: NullablePositiveInteger;
                            };
                        };
                    })[];
                };
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type LaunchConfigurationNames = string[];
export interface LaunchConfigurationNamesType {
    LaunchConfigurationNames?: string[] | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface LaunchConfiguration {
    LaunchConfigurationName?: string | undefined;
    LaunchConfigurationARN?: string | undefined;
    ImageId?: string | undefined;
    KeyName?: string | undefined;
    SecurityGroups?: string[] | undefined;
    ClassicLinkVPCId?: string | undefined;
    ClassicLinkVPCSecurityGroups?: string[] | undefined;
    UserData?: string | undefined;
    InstanceType?: string | undefined;
    KernelId?: string | undefined;
    RamdiskId?: string | undefined;
    BlockDeviceMappings?: BlockDeviceMapping[] | undefined;
    InstanceMonitoring?: InstanceMonitoring | undefined;
    SpotPrice?: string | undefined;
    IamInstanceProfile?: string | undefined;
    CreatedTime?: Date | undefined;
    EbsOptimized?: boolean | undefined;
    AssociatePublicIpAddress?: boolean | undefined;
    PlacementTenancy?: string | undefined;
    MetadataOptions?: InstanceMetadataOptions | undefined;
}
export type LaunchConfigurations = LaunchConfiguration[];
export interface LaunchConfigurationsType {
    LaunchConfigurations: (LaunchConfiguration & {
        LaunchConfigurationName: XmlStringMaxLen255;
        ImageId: XmlStringMaxLen255;
        InstanceType: XmlStringMaxLen255;
        CreatedTime: Date;
        BlockDeviceMappings: (BlockDeviceMapping & {
            DeviceName: XmlStringMaxLen255;
        })[];
    })[];
    NextToken?: string | undefined;
}
export type LifecycleHookNames = string[];
export interface DescribeLifecycleHooksType {
    AutoScalingGroupName?: string | undefined;
    LifecycleHookNames?: string[] | undefined;
}
export type GlobalTimeout = number;
export interface LifecycleHook {
    LifecycleHookName?: string | undefined;
    AutoScalingGroupName?: string | undefined;
    LifecycleTransition?: string | undefined;
    NotificationTargetARN?: string | undefined;
    RoleARN?: string | undefined;
    NotificationMetadata?: string | undefined;
    HeartbeatTimeout?: number | undefined;
    GlobalTimeout?: number | undefined;
    DefaultResult?: string | undefined;
}
export type LifecycleHooks = LifecycleHook[];
export interface DescribeLifecycleHooksAnswer {
    LifecycleHooks?: LifecycleHook[] | undefined;
}
export interface DescribeLifecycleHookTypesRequest {
}
export interface DescribeLifecycleHookTypesAnswer {
    LifecycleHookTypes?: string[] | undefined;
}
export interface DescribeLoadBalancersRequest {
    AutoScalingGroupName?: string | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface LoadBalancerState {
    LoadBalancerName?: string | undefined;
    State?: string | undefined;
}
export type LoadBalancerStates = LoadBalancerState[];
export interface DescribeLoadBalancersResponse {
    LoadBalancers?: LoadBalancerState[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeLoadBalancerTargetGroupsRequest {
    AutoScalingGroupName?: string | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface LoadBalancerTargetGroupState {
    LoadBalancerTargetGroupARN?: string | undefined;
    State?: string | undefined;
}
export type LoadBalancerTargetGroupStates = LoadBalancerTargetGroupState[];
export interface DescribeLoadBalancerTargetGroupsResponse {
    LoadBalancerTargetGroups?: LoadBalancerTargetGroupState[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeMetricCollectionTypesRequest {
}
export interface MetricCollectionType {
    Metric?: string | undefined;
}
export type MetricCollectionTypes = MetricCollectionType[];
export interface MetricGranularityType {
    Granularity?: string | undefined;
}
export type MetricGranularityTypes = MetricGranularityType[];
export interface DescribeMetricCollectionTypesAnswer {
    Metrics?: MetricCollectionType[] | undefined;
    Granularities?: MetricGranularityType[] | undefined;
}
export interface DescribeNotificationConfigurationsType {
    AutoScalingGroupNames?: string[] | undefined;
    IncludeManagedResources?: boolean | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface NotificationConfiguration {
    AutoScalingGroupName?: string | undefined;
    TopicARN?: string | undefined;
    NotificationType?: string | undefined;
}
export type NotificationConfigurations = NotificationConfiguration[];
export interface DescribeNotificationConfigurationsAnswer {
    NotificationConfigurations: NotificationConfiguration[];
    NextToken?: string | undefined;
}
export type PolicyNames = string[];
export type PolicyTypes = string[];
export interface DescribePoliciesType {
    AutoScalingGroupName?: string | undefined;
    PolicyNames?: string[] | undefined;
    PolicyTypes?: string[] | undefined;
    IncludeManagedResources?: boolean | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export type MinAdjustmentStep = number;
export type MinAdjustmentMagnitude = number;
export type PolicyIncrement = number;
export type MetricScale = number;
export interface StepAdjustment {
    MetricIntervalLowerBound?: number | undefined;
    MetricIntervalUpperBound?: number | undefined;
    ScalingAdjustment?: number | undefined;
}
export type StepAdjustments = StepAdjustment[];
export type EstimatedInstanceWarmup = number;
export interface Alarm {
    AlarmName?: string | undefined;
    AlarmARN?: string | undefined;
}
export type Alarms = Alarm[];
export type MetricType = "ASGAverageCPUUtilization" | "ASGAverageCPUUtilizationHighResolution" | "ASGAverageNetworkIn" | "ASGAverageNetworkOut" | "ALBRequestCountPerTarget" | (string & {});
export interface PredefinedMetricSpecification {
    PredefinedMetricType?: MetricType | undefined;
    ResourceLabel?: string | undefined;
}
export type MetricName = string;
export type MetricNamespace = string;
export type MetricDimensionName = string;
export type MetricDimensionValue = string;
export interface MetricDimension {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type MetricDimensions = MetricDimension[];
export type MetricStatistic = "Average" | "Minimum" | "Maximum" | "SampleCount" | "Sum" | (string & {});
export type MetricUnit = string;
export type MetricGranularityInSeconds = number;
export type XmlStringMaxLen2047 = string;
export interface Metric {
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: MetricDimension[] | undefined;
}
export type XmlStringMetricStat = string;
export interface TargetTrackingMetricStat {
    Metric?: Metric | undefined;
    Stat?: string | undefined;
    Unit?: string | undefined;
    Period?: number | undefined;
}
export type XmlStringMetricLabel = string;
export type ReturnData = boolean;
export interface TargetTrackingMetricDataQuery {
    Id?: string | undefined;
    Expression?: string | undefined;
    MetricStat?: TargetTrackingMetricStat | undefined;
    Label?: string | undefined;
    Period?: number | undefined;
    ReturnData?: boolean | undefined;
}
export type TargetTrackingMetricDataQueries = TargetTrackingMetricDataQuery[];
export interface CustomizedMetricSpecification {
    MetricName?: string | undefined;
    Namespace?: string | undefined;
    Dimensions?: MetricDimension[] | undefined;
    Statistic?: MetricStatistic | undefined;
    Unit?: string | undefined;
    Period?: number | undefined;
    Metrics?: TargetTrackingMetricDataQuery[] | undefined;
}
export type DisableScaleIn = boolean;
export interface TargetTrackingConfiguration {
    PredefinedMetricSpecification?: PredefinedMetricSpecification | undefined;
    CustomizedMetricSpecification?: CustomizedMetricSpecification | undefined;
    TargetValue?: number | undefined;
    DisableScaleIn?: boolean | undefined;
}
export type ScalingPolicyEnabled = boolean;
export type PredefinedMetricPairType = "ASGCPUUtilization" | "ASGNetworkIn" | "ASGNetworkOut" | "ALBRequestCount" | (string & {});
export interface PredictiveScalingPredefinedMetricPair {
    PredefinedMetricType?: PredefinedMetricPairType | undefined;
    ResourceLabel?: string | undefined;
}
export type PredefinedScalingMetricType = "ASGAverageCPUUtilization" | "ASGAverageNetworkIn" | "ASGAverageNetworkOut" | "ALBRequestCountPerTarget" | (string & {});
export interface PredictiveScalingPredefinedScalingMetric {
    PredefinedMetricType?: PredefinedScalingMetricType | undefined;
    ResourceLabel?: string | undefined;
}
export type PredefinedLoadMetricType = "ASGTotalCPUUtilization" | "ASGTotalNetworkIn" | "ASGTotalNetworkOut" | "ALBTargetGroupRequestCount" | (string & {});
export interface PredictiveScalingPredefinedLoadMetric {
    PredefinedMetricType?: PredefinedLoadMetricType | undefined;
    ResourceLabel?: string | undefined;
}
export interface MetricStat {
    Metric?: Metric | undefined;
    Stat?: string | undefined;
    Unit?: string | undefined;
}
export interface MetricDataQuery {
    Id?: string | undefined;
    Expression?: string | undefined;
    MetricStat?: MetricStat | undefined;
    Label?: string | undefined;
    ReturnData?: boolean | undefined;
}
export type MetricDataQueries = MetricDataQuery[];
export interface PredictiveScalingCustomizedScalingMetric {
    MetricDataQueries?: MetricDataQuery[] | undefined;
}
export interface PredictiveScalingCustomizedLoadMetric {
    MetricDataQueries?: MetricDataQuery[] | undefined;
}
export interface PredictiveScalingCustomizedCapacityMetric {
    MetricDataQueries?: MetricDataQuery[] | undefined;
}
export interface PredictiveScalingMetricSpecification {
    TargetValue?: number | undefined;
    PredefinedMetricPairSpecification?: PredictiveScalingPredefinedMetricPair | undefined;
    PredefinedScalingMetricSpecification?: PredictiveScalingPredefinedScalingMetric | undefined;
    PredefinedLoadMetricSpecification?: PredictiveScalingPredefinedLoadMetric | undefined;
    CustomizedScalingMetricSpecification?: PredictiveScalingCustomizedScalingMetric | undefined;
    CustomizedLoadMetricSpecification?: PredictiveScalingCustomizedLoadMetric | undefined;
    CustomizedCapacityMetricSpecification?: PredictiveScalingCustomizedCapacityMetric | undefined;
}
export type PredictiveScalingMetricSpecifications = PredictiveScalingMetricSpecification[];
export type PredictiveScalingMode = "ForecastAndScale" | "ForecastOnly" | (string & {});
export type PredictiveScalingSchedulingBufferTime = number;
export type PredictiveScalingMaxCapacityBreachBehavior = "HonorMaxCapacity" | "IncreaseMaxCapacity" | (string & {});
export type PredictiveScalingMaxCapacityBuffer = number;
export interface PredictiveScalingConfiguration {
    MetricSpecifications?: PredictiveScalingMetricSpecification[] | undefined;
    Mode?: PredictiveScalingMode | undefined;
    SchedulingBufferTime?: number | undefined;
    MaxCapacityBreachBehavior?: PredictiveScalingMaxCapacityBreachBehavior | undefined;
    MaxCapacityBuffer?: number | undefined;
}
export interface ScalingPolicy {
    AutoScalingGroupName?: string | undefined;
    PolicyName?: string | undefined;
    PolicyARN?: string | undefined;
    PolicyType?: string | undefined;
    AdjustmentType?: string | undefined;
    MinAdjustmentStep?: number | undefined;
    MinAdjustmentMagnitude?: number | undefined;
    ScalingAdjustment?: number | undefined;
    Cooldown?: number | undefined;
    StepAdjustments?: StepAdjustment[] | undefined;
    MetricAggregationType?: string | undefined;
    EstimatedInstanceWarmup?: number | undefined;
    Alarms?: Alarm[] | undefined;
    TargetTrackingConfiguration?: TargetTrackingConfiguration | undefined;
    Enabled?: boolean | undefined;
    PredictiveScalingConfiguration?: PredictiveScalingConfiguration | undefined;
}
export type ScalingPolicies = ScalingPolicy[];
export interface PoliciesType {
    ScalingPolicies?: (ScalingPolicy & {
        StepAdjustments: (StepAdjustment & {
            ScalingAdjustment: PolicyIncrement;
        })[];
        TargetTrackingConfiguration: TargetTrackingConfiguration & {
            TargetValue: MetricScale;
            PredefinedMetricSpecification: PredefinedMetricSpecification & {
                PredefinedMetricType: MetricType;
            };
            CustomizedMetricSpecification: CustomizedMetricSpecification & {
                Dimensions: (MetricDimension & {
                    Name: MetricDimensionName;
                    Value: MetricDimensionValue;
                })[];
                Metrics: (TargetTrackingMetricDataQuery & {
                    Id: XmlStringMaxLen64;
                    MetricStat: TargetTrackingMetricStat & {
                        Metric: Metric & {
                            Namespace: MetricNamespace;
                            MetricName: MetricName;
                            Dimensions: (MetricDimension & {
                                Name: MetricDimensionName;
                                Value: MetricDimensionValue;
                            })[];
                        };
                        Stat: XmlStringMetricStat;
                    };
                })[];
            };
        };
        PredictiveScalingConfiguration: PredictiveScalingConfiguration & {
            MetricSpecifications: (PredictiveScalingMetricSpecification & {
                TargetValue: MetricScale;
                PredefinedMetricPairSpecification: PredictiveScalingPredefinedMetricPair & {
                    PredefinedMetricType: PredefinedMetricPairType;
                };
                PredefinedScalingMetricSpecification: PredictiveScalingPredefinedScalingMetric & {
                    PredefinedMetricType: PredefinedScalingMetricType;
                };
                PredefinedLoadMetricSpecification: PredictiveScalingPredefinedLoadMetric & {
                    PredefinedMetricType: PredefinedLoadMetricType;
                };
                CustomizedScalingMetricSpecification: PredictiveScalingCustomizedScalingMetric & {
                    MetricDataQueries: (MetricDataQuery & {
                        Id: XmlStringMaxLen255;
                        MetricStat: MetricStat & {
                            Metric: Metric & {
                                Namespace: MetricNamespace;
                                MetricName: MetricName;
                                Dimensions: (MetricDimension & {
                                    Name: MetricDimensionName;
                                    Value: MetricDimensionValue;
                                })[];
                            };
                            Stat: XmlStringMetricStat;
                        };
                    })[];
                };
                CustomizedLoadMetricSpecification: PredictiveScalingCustomizedLoadMetric & {
                    MetricDataQueries: (MetricDataQuery & {
                        Id: XmlStringMaxLen255;
                        MetricStat: MetricStat & {
                            Metric: Metric & {
                                Namespace: MetricNamespace;
                                MetricName: MetricName;
                                Dimensions: (MetricDimension & {
                                    Name: MetricDimensionName;
                                    Value: MetricDimensionValue;
                                })[];
                            };
                            Stat: XmlStringMetricStat;
                        };
                    })[];
                };
                CustomizedCapacityMetricSpecification: PredictiveScalingCustomizedCapacityMetric & {
                    MetricDataQueries: (MetricDataQuery & {
                        Id: XmlStringMaxLen255;
                        MetricStat: MetricStat & {
                            Metric: Metric & {
                                Namespace: MetricNamespace;
                                MetricName: MetricName;
                                Dimensions: (MetricDimension & {
                                    Name: MetricDimensionName;
                                    Value: MetricDimensionValue;
                                })[];
                            };
                            Stat: XmlStringMetricStat;
                        };
                    })[];
                };
            })[];
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type ActivityIds = string[];
export type IncludeDeletedGroups = boolean;
export interface DescribeScalingActivitiesType {
    ActivityIds?: string[] | undefined;
    AutoScalingGroupName?: string | undefined;
    IncludeDeletedGroups?: boolean | undefined;
    IncludeManagedResources?: boolean | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type ScalingActivityStatusCode = "PendingSpotBidPlacement" | "WaitingForSpotInstanceRequestId" | "WaitingForSpotInstanceId" | "WaitingForInstanceId" | "PreInService" | "InProgress" | "WaitingForELBConnectionDraining" | "MidLifecycleAction" | "WaitingForInstanceWarmup" | "Successful" | "Failed" | "Cancelled" | "WaitingForConnectionDraining" | "WaitingForInPlaceUpdateToStart" | "WaitingForInPlaceUpdateToFinalize" | "InPlaceUpdateInProgress" | (string & {});
export type Progress = number;
export type AutoScalingGroupState = string;
export interface Activity {
    ActivityId?: string | undefined;
    AutoScalingGroupName?: string | undefined;
    Description?: string | undefined;
    Cause?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    StatusCode?: ScalingActivityStatusCode | undefined;
    StatusMessage?: string | undefined;
    Progress?: number | undefined;
    Details?: string | undefined;
    AutoScalingGroupState?: string | undefined;
    AutoScalingGroupARN?: string | undefined;
}
export type Activities = Activity[];
export interface ActivitiesType {
    Activities: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[];
    NextToken?: string | undefined;
}
export interface DescribeScalingProcessTypesRequest {
}
export interface ProcessType {
    ProcessName?: string | undefined;
}
export type Processes = ProcessType[];
export interface ProcessesType {
    Processes?: (ProcessType & {
        ProcessName: XmlStringMaxLen255;
    })[] | undefined;
}
export interface DescribeScheduledActionsType {
    AutoScalingGroupName?: string | undefined;
    ScheduledActionNames?: string[] | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    IncludeManagedResources?: boolean | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface ScheduledUpdateGroupAction {
    AutoScalingGroupName?: string | undefined;
    ScheduledActionName?: string | undefined;
    ScheduledActionARN?: string | undefined;
    Time?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Recurrence?: string | undefined;
    MinSize?: number | undefined;
    MaxSize?: number | undefined;
    DesiredCapacity?: number | undefined;
    TimeZone?: string | undefined;
}
export type ScheduledUpdateGroupActions = ScheduledUpdateGroupAction[];
export interface ScheduledActionsType {
    ScheduledUpdateGroupActions?: ScheduledUpdateGroupAction[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeTagsType {
    Filters?: Filter[] | undefined;
    IncludeManagedResources?: boolean | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface TagsType {
    Tags?: TagDescription[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeTerminationPolicyTypesRequest {
}
export interface DescribeTerminationPolicyTypesAnswer {
    TerminationPolicyTypes?: string[] | undefined;
}
export interface DescribeTrafficSourcesRequest {
    AutoScalingGroupName?: string | undefined;
    TrafficSourceType?: string | undefined;
    NextToken?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface TrafficSourceState {
    TrafficSource?: string | undefined;
    State?: string | undefined;
    Identifier?: string | undefined;
    Type?: string | undefined;
}
export type TrafficSourceStates = TrafficSourceState[];
export interface DescribeTrafficSourcesResponse {
    TrafficSources?: TrafficSourceState[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeWarmPoolType {
    AutoScalingGroupName?: string | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeWarmPoolAnswer {
    WarmPoolConfiguration?: WarmPoolConfiguration | undefined;
    Instances?: (Instance & {
        InstanceId: XmlStringMaxLen19;
        AvailabilityZone: XmlStringMaxLen255;
        LifecycleState: LifecycleState;
        HealthStatus: XmlStringMaxLen32;
        ProtectedFromScaleIn: InstanceProtected;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type ShouldDecrementDesiredCapacity = boolean;
export interface DetachInstancesQuery {
    InstanceIds?: string[] | undefined;
    AutoScalingGroupName?: string | undefined;
    ShouldDecrementDesiredCapacity?: boolean | undefined;
}
export interface DetachInstancesAnswer {
    Activities?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[] | undefined;
}
export interface DetachLoadBalancersType {
    AutoScalingGroupName?: string | undefined;
    LoadBalancerNames?: string[] | undefined;
}
export interface DetachLoadBalancersResultType {
}
export interface DetachLoadBalancerTargetGroupsType {
    AutoScalingGroupName?: string | undefined;
    TargetGroupARNs?: string[] | undefined;
}
export interface DetachLoadBalancerTargetGroupsResultType {
}
export interface DetachTrafficSourcesType {
    AutoScalingGroupName?: string | undefined;
    TrafficSources?: TrafficSourceIdentifier[] | undefined;
}
export interface DetachTrafficSourcesResultType {
}
export type Metrics = string[];
export interface DisableMetricsCollectionQuery {
    AutoScalingGroupName?: string | undefined;
    Metrics?: string[] | undefined;
}
export interface DisableMetricsCollectionResponse {
}
export interface EnableMetricsCollectionQuery {
    AutoScalingGroupName?: string | undefined;
    Metrics?: string[] | undefined;
    Granularity?: string | undefined;
}
export interface EnableMetricsCollectionResponse {
}
export interface EnterStandbyQuery {
    InstanceIds?: string[] | undefined;
    AutoScalingGroupName?: string | undefined;
    ShouldDecrementDesiredCapacity?: boolean | undefined;
}
export interface EnterStandbyAnswer {
    Activities?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[] | undefined;
}
export type HonorCooldown = boolean;
export interface ExecutePolicyType {
    AutoScalingGroupName?: string | undefined;
    PolicyName?: string | undefined;
    HonorCooldown?: boolean | undefined;
    MetricValue?: number | undefined;
    BreachThreshold?: number | undefined;
}
export interface ExecutePolicyResponse {
}
export interface ExitStandbyQuery {
    InstanceIds?: string[] | undefined;
    AutoScalingGroupName?: string | undefined;
}
export interface ExitStandbyAnswer {
    Activities?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[] | undefined;
}
export interface GetPredictiveScalingForecastType {
    AutoScalingGroupName?: string | undefined;
    PolicyName?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type PredictiveScalingForecastTimestamps = Date[];
export type PredictiveScalingForecastValues = number[];
export interface LoadForecast {
    Timestamps?: Date[] | undefined;
    Values?: number[] | undefined;
    MetricSpecification?: PredictiveScalingMetricSpecification | undefined;
}
export type LoadForecasts = LoadForecast[];
export interface CapacityForecast {
    Timestamps?: Date[] | undefined;
    Values?: number[] | undefined;
}
export interface GetPredictiveScalingForecastAnswer {
    LoadForecast: (LoadForecast & {
        Timestamps: PredictiveScalingForecastTimestamps;
        Values: PredictiveScalingForecastValues;
        MetricSpecification: PredictiveScalingMetricSpecification & {
            TargetValue: MetricScale;
            PredefinedMetricPairSpecification: PredictiveScalingPredefinedMetricPair & {
                PredefinedMetricType: PredefinedMetricPairType;
            };
            PredefinedScalingMetricSpecification: PredictiveScalingPredefinedScalingMetric & {
                PredefinedMetricType: PredefinedScalingMetricType;
            };
            PredefinedLoadMetricSpecification: PredictiveScalingPredefinedLoadMetric & {
                PredefinedMetricType: PredefinedLoadMetricType;
            };
            CustomizedScalingMetricSpecification: PredictiveScalingCustomizedScalingMetric & {
                MetricDataQueries: (MetricDataQuery & {
                    Id: XmlStringMaxLen255;
                    MetricStat: MetricStat & {
                        Metric: Metric & {
                            Namespace: MetricNamespace;
                            MetricName: MetricName;
                            Dimensions: (MetricDimension & {
                                Name: MetricDimensionName;
                                Value: MetricDimensionValue;
                            })[];
                        };
                        Stat: XmlStringMetricStat;
                    };
                })[];
            };
            CustomizedLoadMetricSpecification: PredictiveScalingCustomizedLoadMetric & {
                MetricDataQueries: (MetricDataQuery & {
                    Id: XmlStringMaxLen255;
                    MetricStat: MetricStat & {
                        Metric: Metric & {
                            Namespace: MetricNamespace;
                            MetricName: MetricName;
                            Dimensions: (MetricDimension & {
                                Name: MetricDimensionName;
                                Value: MetricDimensionValue;
                            })[];
                        };
                        Stat: XmlStringMetricStat;
                    };
                })[];
            };
            CustomizedCapacityMetricSpecification: PredictiveScalingCustomizedCapacityMetric & {
                MetricDataQueries: (MetricDataQuery & {
                    Id: XmlStringMaxLen255;
                    MetricStat: MetricStat & {
                        Metric: Metric & {
                            Namespace: MetricNamespace;
                            MetricName: MetricName;
                            Dimensions: (MetricDimension & {
                                Name: MetricDimensionName;
                                Value: MetricDimensionValue;
                            })[];
                        };
                        Stat: XmlStringMetricStat;
                    };
                })[];
            };
        };
    })[];
    CapacityForecast: CapacityForecast & {
        Timestamps: PredictiveScalingForecastTimestamps;
        Values: PredictiveScalingForecastValues;
    };
    UpdateTime: Date;
}
export type RequestedCapacity = number;
export type ClientToken = string;
export type AvailabilityZonesLimit1 = string[];
export type AvailabilityZoneIdsLimit1 = string[];
export type SubnetIdsLimit1 = string[];
export type RetryStrategy = "retry-with-group-configuration" | "none" | (string & {});
export interface LaunchInstancesRequest {
    AutoScalingGroupName?: string | undefined;
    RequestedCapacity?: number | undefined;
    ClientToken?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    AvailabilityZoneIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    RetryStrategy?: RetryStrategy | undefined;
}
export interface InstanceCollection {
    InstanceType?: string | undefined;
    MarketType?: string | undefined;
    SubnetId?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    InstanceIds?: string[] | undefined;
}
export type InstanceCollections = InstanceCollection[];
export interface LaunchInstancesError_ {
    InstanceType?: string | undefined;
    MarketType?: string | undefined;
    SubnetId?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type LaunchInstancesErrors = LaunchInstancesError_[];
export interface LaunchInstancesResult {
    AutoScalingGroupName?: string | undefined;
    ClientToken?: string | undefined;
    Instances?: InstanceCollection[] | undefined;
    Errors?: LaunchInstancesError_[] | undefined;
}
export interface PutAccountSettingType {
    Name?: string | undefined;
    Value?: string | undefined;
}
export interface PutAccountSettingAnswer {
}
export interface PutLifecycleHookType {
    LifecycleHookName?: string | undefined;
    AutoScalingGroupName?: string | undefined;
    LifecycleTransition?: string | undefined;
    RoleARN?: string | undefined;
    NotificationTargetARN?: string | undefined;
    NotificationMetadata?: string | undefined;
    HeartbeatTimeout?: number | undefined;
    DefaultResult?: string | undefined;
}
export interface PutLifecycleHookAnswer {
}
export interface PutNotificationConfigurationType {
    AutoScalingGroupName?: string | undefined;
    TopicARN?: string | undefined;
    NotificationTypes?: string[] | undefined;
}
export interface PutNotificationConfigurationResponse {
}
export interface PutScalingPolicyType {
    AutoScalingGroupName?: string | undefined;
    PolicyName?: string | undefined;
    PolicyType?: string | undefined;
    AdjustmentType?: string | undefined;
    MinAdjustmentStep?: number | undefined;
    MinAdjustmentMagnitude?: number | undefined;
    ScalingAdjustment?: number | undefined;
    Cooldown?: number | undefined;
    MetricAggregationType?: string | undefined;
    StepAdjustments?: StepAdjustment[] | undefined;
    EstimatedInstanceWarmup?: number | undefined;
    TargetTrackingConfiguration?: TargetTrackingConfiguration | undefined;
    Enabled?: boolean | undefined;
    PredictiveScalingConfiguration?: PredictiveScalingConfiguration | undefined;
}
export interface PolicyARNType {
    PolicyARN?: string | undefined;
    Alarms?: Alarm[] | undefined;
}
export interface PutScheduledUpdateGroupActionType {
    AutoScalingGroupName?: string | undefined;
    ScheduledActionName?: string | undefined;
    Time?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Recurrence?: string | undefined;
    MinSize?: number | undefined;
    MaxSize?: number | undefined;
    DesiredCapacity?: number | undefined;
    TimeZone?: string | undefined;
}
export interface PutScheduledUpdateGroupActionResponse {
}
export interface PutWarmPoolType {
    AutoScalingGroupName?: string | undefined;
    MaxGroupPreparedCapacity?: number | undefined;
    MinSize?: number | undefined;
    PoolState?: WarmPoolState | undefined;
    InstanceReusePolicy?: InstanceReusePolicy | undefined;
}
export interface PutWarmPoolAnswer {
}
export interface RecordLifecycleActionHeartbeatType {
    LifecycleHookName?: string | undefined;
    AutoScalingGroupName?: string | undefined;
    LifecycleActionToken?: string | undefined;
    InstanceId?: string | undefined;
}
export interface RecordLifecycleActionHeartbeatAnswer {
}
export type ProcessNames = string[];
export interface ScalingProcessQuery {
    AutoScalingGroupName?: string | undefined;
    ScalingProcesses?: string[] | undefined;
}
export interface ResumeProcessesResponse {
}
export interface RollbackInstanceRefreshType {
    AutoScalingGroupName?: string | undefined;
}
export interface RollbackInstanceRefreshAnswer {
    InstanceRefreshId?: string | undefined;
}
export interface SetDesiredCapacityType {
    AutoScalingGroupName?: string | undefined;
    DesiredCapacity?: number | undefined;
    HonorCooldown?: boolean | undefined;
}
export interface SetDesiredCapacityResponse {
}
export type ShouldRespectGracePeriod = boolean;
export interface SetInstanceHealthQuery {
    InstanceId?: string | undefined;
    HealthStatus?: string | undefined;
    ShouldRespectGracePeriod?: boolean | undefined;
}
export interface SetInstanceHealthResponse {
}
export type ProtectedFromScaleIn = boolean;
export interface SetInstanceProtectionQuery {
    InstanceIds?: string[] | undefined;
    AutoScalingGroupName?: string | undefined;
    ProtectedFromScaleIn?: boolean | undefined;
}
export interface SetInstanceProtectionAnswer {
}
export interface StartInstanceRefreshType {
    AutoScalingGroupName?: string | undefined;
    Strategy?: RefreshStrategy | undefined;
    DesiredConfiguration?: DesiredConfiguration | undefined;
    Preferences?: RefreshPreferences | undefined;
}
export interface StartInstanceRefreshAnswer {
    InstanceRefreshId?: string | undefined;
}
export interface SuspendProcessesResponse {
}
export type TerminationInstanceIds = string[];
export interface TerminateInstanceInAutoScalingGroupType {
    InstanceId?: string | undefined;
    InstanceIds?: string[] | undefined;
    AutoScalingGroupName?: string | undefined;
    ShouldDecrementDesiredCapacity?: boolean | undefined;
}
export interface ActivityType {
    Activity?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    }) | undefined;
    Activities?: (Activity & {
        ActivityId: XmlString;
        AutoScalingGroupName: XmlStringMaxLen255;
        Cause: XmlStringMaxLen1023;
        StartTime: Date;
        StatusCode: ScalingActivityStatusCode;
    })[] | undefined;
}
export type UpdatePlacementGroupParam = string;
export interface UpdateAutoScalingGroupType {
    AutoScalingGroupName?: string | undefined;
    LaunchConfigurationName?: string | undefined;
    LaunchTemplate?: LaunchTemplateSpecification | undefined;
    MixedInstancesPolicy?: MixedInstancesPolicy | undefined;
    MinSize?: number | undefined;
    MaxSize?: number | undefined;
    DesiredCapacity?: number | undefined;
    DefaultCooldown?: number | undefined;
    AvailabilityZones?: string[] | undefined;
    AvailabilityZoneIds?: string[] | undefined;
    HealthCheckType?: string | undefined;
    HealthCheckGracePeriod?: number | undefined;
    PlacementGroup?: string | undefined;
    VPCZoneIdentifier?: string | undefined;
    TerminationPolicies?: string[] | undefined;
    NewInstancesProtectedFromScaleIn?: boolean | undefined;
    ServiceLinkedRoleARN?: string | undefined;
    MaxInstanceLifetime?: number | undefined;
    CapacityRebalance?: boolean | undefined;
    Context?: string | undefined;
    DesiredCapacityType?: string | undefined;
    DefaultInstanceWarmup?: number | undefined;
    InstanceMaintenancePolicy?: InstanceMaintenancePolicy | undefined;
    AvailabilityZoneDistribution?: AvailabilityZoneDistribution | undefined;
    AvailabilityZoneImpairmentPolicy?: AvailabilityZoneImpairmentPolicy | undefined;
    SkipZonalShiftValidation?: boolean | undefined;
    CapacityReservationSpecification?: CapacityReservationSpecification | undefined;
    InstanceLifecyclePolicy?: InstanceLifecyclePolicy | undefined;
    DeletionProtection?: DeletionProtection | undefined;
}
export interface UpdateAutoScalingGroupResponse {
}
export type AttachInstancesError = ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Attaches one or more EC2 instances to the specified Auto Scaling group.
 *
 * When you attach instances, Amazon EC2 Auto Scaling increases the desired capacity of the group by the
 * number of instances being attached. If the number of instances being attached plus the
 * desired capacity of the group exceeds the maximum size of the group, the operation
 * fails.
 *
 * If there is a Classic Load Balancer attached to your Auto Scaling group, the instances are
 * also registered with the load balancer. If there are target groups attached to your Auto Scaling
 * group, the instances are also registered with the target groups.
 *
 * For more information, see Detach
 * or attach instances in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const attachInstances: API.OperationMethod<AttachInstancesQuery & RegionInput, AttachInstancesResponse, AttachInstancesError, Credentials | HttpClient.HttpClient>;
export type AttachLoadBalancersError = InstanceRefreshInProgressFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * This API operation is superseded by AttachTrafficSources, which
 * can attach multiple traffic sources types. We recommend using
 * `AttachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `AttachLoadBalancers`. You can use both
 * the original `AttachLoadBalancers` API operation and
 * `AttachTrafficSources` on the same Auto Scaling group.
 *
 * Attaches one or more Classic Load Balancers to the specified Auto Scaling group. Amazon EC2 Auto Scaling registers the
 * running instances with these Classic Load Balancers.
 *
 * To describe the load balancers for an Auto Scaling group, call the DescribeLoadBalancers API.
 * To detach a load balancer from the Auto Scaling group, call the DetachLoadBalancers
 * API.
 *
 * This operation is additive and does not detach existing Classic Load Balancers or
 * target groups from the Auto Scaling group.
 *
 * For more information, see Use Elastic Load Balancing to
 * distribute traffic across the instances in your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const attachLoadBalancers: API.OperationMethod<AttachLoadBalancersType & RegionInput, AttachLoadBalancersResultType, AttachLoadBalancersError, Credentials | HttpClient.HttpClient>;
export type AttachLoadBalancerTargetGroupsError = InstanceRefreshInProgressFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * This API operation is superseded by AttachTrafficSources, which
 * can attach multiple traffic sources types. We recommend using
 * `AttachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `AttachLoadBalancerTargetGroups`. You can
 * use both the original `AttachLoadBalancerTargetGroups` API operation and
 * `AttachTrafficSources` on the same Auto Scaling group.
 *
 * Attaches one or more target groups to the specified Auto Scaling group.
 *
 * This operation is used with the following load balancer types:
 *
 * - Application Load Balancer - Operates at the application layer (layer 7) and supports HTTP and
 * HTTPS.
 *
 * - Network Load Balancer - Operates at the transport layer (layer 4) and supports TCP, TLS, and
 * UDP.
 *
 * - Gateway Load Balancer - Operates at the network layer (layer 3).
 *
 * To describe the target groups for an Auto Scaling group, call the DescribeLoadBalancerTargetGroups
 * API. To detach the target group from
 * the Auto Scaling group, call the DetachLoadBalancerTargetGroups API.
 *
 * This operation is additive and does not detach existing target groups or Classic Load
 * Balancers from the Auto Scaling group.
 *
 * For more information, see Use Elastic Load Balancing to
 * distribute traffic across the instances in your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const attachLoadBalancerTargetGroups: API.OperationMethod<AttachLoadBalancerTargetGroupsType & RegionInput, AttachLoadBalancerTargetGroupsResultType, AttachLoadBalancerTargetGroupsError, Credentials | HttpClient.HttpClient>;
export type AttachTrafficSourcesError = InstanceRefreshInProgressFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Attaches one or more traffic sources to the specified Auto Scaling group.
 *
 * You can use any of the following as traffic sources for an Auto Scaling group:
 *
 * - Application Load Balancer
 *
 * - Classic Load Balancer
 *
 * - Gateway Load Balancer
 *
 * - Network Load Balancer
 *
 * - VPC Lattice
 *
 * This operation is additive and does not detach existing traffic sources from the Auto Scaling
 * group.
 *
 * After the operation completes, use the DescribeTrafficSources API to
 * return details about the state of the attachments between traffic sources and your Auto Scaling
 * group. To detach a traffic source from the Auto Scaling group, call the
 * DetachTrafficSources API.
 */
export declare const attachTrafficSources: API.OperationMethod<AttachTrafficSourcesType & RegionInput, AttachTrafficSourcesResultType, AttachTrafficSourcesError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteScheduledActionError = ResourceContentionFault | CommonErrors;
/**
 * Deletes one or more scheduled actions for the specified Auto Scaling group.
 */
export declare const batchDeleteScheduledAction: API.OperationMethod<BatchDeleteScheduledActionType & RegionInput, BatchDeleteScheduledActionAnswer, BatchDeleteScheduledActionError, Credentials | HttpClient.HttpClient>;
export type BatchPutScheduledUpdateGroupActionError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Creates or updates one or more scheduled scaling actions for an Auto Scaling group.
 */
export declare const batchPutScheduledUpdateGroupAction: API.OperationMethod<BatchPutScheduledUpdateGroupActionType & RegionInput, BatchPutScheduledUpdateGroupActionAnswer, BatchPutScheduledUpdateGroupActionError, Credentials | HttpClient.HttpClient>;
export type CancelInstanceRefreshError = ActiveInstanceRefreshNotFoundFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Cancels an instance refresh or rollback that is in progress. If an instance refresh or
 * rollback is not in progress, an `ActiveInstanceRefreshNotFound` error
 * occurs.
 *
 * This operation is part of the instance refresh
 * feature in Amazon EC2 Auto Scaling, which helps you update instances in your Auto Scaling group
 * after you make configuration changes.
 *
 * When you cancel an instance refresh, this does not roll back any changes that it made.
 * Use the RollbackInstanceRefresh API to roll back instead.
 */
export declare const cancelInstanceRefresh: API.OperationMethod<CancelInstanceRefreshType & RegionInput, CancelInstanceRefreshAnswer, CancelInstanceRefreshError, Credentials | HttpClient.HttpClient>;
export type CompleteLifecycleActionError = ResourceContentionFault | CommonErrors;
/**
 * Completes the lifecycle action for the specified token or instance with the specified
 * result.
 *
 * This step is a part of the procedure for adding a lifecycle hook to an Auto Scaling
 * group:
 *
 * - (Optional) Create a launch template or launch configuration with a user data
 * script that runs while an instance is in a wait state due to a lifecycle
 * hook.
 *
 * - (Optional) Create a Lambda function and a rule that allows Amazon EventBridge to invoke
 * your Lambda function when an instance is put into a wait state due to a
 * lifecycle hook.
 *
 * - (Optional) Create a notification target and an IAM role. The target can be
 * either an Amazon SQS queue or an Amazon SNS topic. The role allows Amazon EC2 Auto Scaling to publish
 * lifecycle notifications to the target.
 *
 * - Create the lifecycle hook. Specify whether the hook is used when the instances
 * launch or terminate.
 *
 * - If you need more time, record the lifecycle action heartbeat to keep the
 * instance in a wait state.
 *
 * - If you finish before the timeout period ends, send a
 * callback by using the CompleteLifecycleAction API
 * call.
 *
 * For more information, see Complete a lifecycle
 * action in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const completeLifecycleAction: API.OperationMethod<CompleteLifecycleActionType & RegionInput, CompleteLifecycleActionAnswer, CompleteLifecycleActionError, Credentials | HttpClient.HttpClient>;
export type CreateAutoScalingGroupError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | ServiceLinkedRoleFailure | InvalidIamInstanceProfile | CommonErrors;
/**
 * **We strongly recommend using a launch template when calling this operation to ensure full functionality for Amazon EC2 Auto Scaling and Amazon EC2.**
 *
 * Creates an Auto Scaling group with the specified name and attributes.
 *
 * If you exceed your maximum limit of Auto Scaling groups, the call fails. To query this limit,
 * call the DescribeAccountLimits API. For information about updating
 * this limit, see Quotas for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * If you're new to Amazon EC2 Auto Scaling, see the introductory tutorials in Get started
 * with Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * Every Auto Scaling group has three size properties (`DesiredCapacity`,
 * `MaxSize`, and `MinSize`). Usually, you set these sizes based
 * on a specific number of instances. However, if you configure a mixed instances policy
 * that defines weights for the instance types, you must specify these sizes with the same
 * units that you use for weighting instances.
 */
export declare const createAutoScalingGroup: API.OperationMethod<CreateAutoScalingGroupType & RegionInput, CreateAutoScalingGroupResponse, CreateAutoScalingGroupError, Credentials | HttpClient.HttpClient>;
export type CreateLaunchConfigurationError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Creates a launch configuration.
 *
 * If you exceed your maximum limit of launch configurations, the call fails. To query
 * this limit, call the DescribeAccountLimits API.
 * For information about updating this limit, see Quotas for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * For more information, see Launch
 * configurations in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * Amazon EC2 Auto Scaling configures instances launched as part of an Auto Scaling group using either a
 * launch template or a launch configuration. We strongly recommend that you do not use
 * launch configurations. They do not provide full functionality for Amazon EC2 Auto Scaling or Amazon EC2.
 * For information about using launch templates, see Launch templates in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const createLaunchConfiguration: API.OperationMethod<CreateLaunchConfigurationType & RegionInput, CreateLaunchConfigurationResponse, CreateLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateOrUpdateTagsError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Creates or updates tags for the specified Auto Scaling group.
 *
 * When you specify a tag with a key that already exists, the operation overwrites the
 * previous tag definition, and you do not get an error message.
 *
 * For more information, see Tag Auto Scaling groups and
 * instances in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const createOrUpdateTags: API.OperationMethod<CreateOrUpdateTagsType & RegionInput, CreateOrUpdateTagsResponse, CreateOrUpdateTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteAutoScalingGroupError = ResourceContentionFault | ResourceInUseFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Deletes the specified Auto Scaling group.
 *
 * If the group has instances or scaling activities in progress, you must specify the
 * option to force the deletion in order for it to succeed. The force delete operation will
 * also terminate the EC2 instances. If the group has a warm pool, the force delete option
 * also deletes the warm pool.
 *
 * To remove instances from the Auto Scaling group before deleting it, call the
 * DetachInstances API with the list of instances and the option to
 * decrement the desired capacity. This ensures that Amazon EC2 Auto Scaling does not launch replacement
 * instances.
 *
 * To terminate all instances before deleting the Auto Scaling group, call the
 * UpdateAutoScalingGroup API and set the minimum size and desired capacity
 * of the Auto Scaling group to
 * zero.
 *
 * If the group has scaling policies, deleting the group deletes the policies, the
 * underlying alarm actions, and any alarm that no longer has an associated action.
 *
 * For more information, see Delete your Auto Scaling
 * infrastructure in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const deleteAutoScalingGroup: API.OperationMethod<DeleteAutoScalingGroupType & RegionInput, DeleteAutoScalingGroupResponse, DeleteAutoScalingGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteLaunchConfigurationError = ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Deletes the specified launch configuration.
 *
 * The launch configuration must not be attached to an Auto Scaling group. When this call
 * completes, the launch configuration is no longer available for use.
 */
export declare const deleteLaunchConfiguration: API.OperationMethod<LaunchConfigurationNameType & RegionInput, DeleteLaunchConfigurationResponse, DeleteLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecycleHookError = ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Deletes the specified lifecycle hook.
 *
 * If there are any outstanding lifecycle actions, they are completed first
 * (`ABANDON` for launching instances, `CONTINUE` for terminating
 * instances).
 */
export declare const deleteLifecycleHook: API.OperationMethod<DeleteLifecycleHookType & RegionInput, DeleteLifecycleHookAnswer, DeleteLifecycleHookError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationConfigurationError = ResourceContentionFault | CommonErrors;
/**
 * Deletes the specified notification.
 */
export declare const deleteNotificationConfiguration: API.OperationMethod<DeleteNotificationConfigurationType & RegionInput, DeleteNotificationConfigurationResponse, DeleteNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Deletes the specified scaling policy.
 *
 * Deleting either a step scaling policy or a simple scaling policy deletes the
 * underlying alarm action, but does not delete the alarm, even if it no longer has an
 * associated action.
 *
 * For more information, see Delete a scaling
 * policy in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyType & RegionInput, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledActionError = ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Deletes the specified scheduled action.
 */
export declare const deleteScheduledAction: API.OperationMethod<DeleteScheduledActionType & RegionInput, DeleteScheduledActionResponse, DeleteScheduledActionError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Deletes the specified tags.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsType & RegionInput, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteWarmPoolError = LimitExceededFault | ResourceContentionFault | ResourceInUseFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Deletes the warm pool for the specified Auto Scaling group.
 *
 * For more information, see Warm pools for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const deleteWarmPool: API.OperationMethod<DeleteWarmPoolType & RegionInput, DeleteWarmPoolAnswer, DeleteWarmPoolError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountLimitsError = ResourceContentionFault | CommonErrors;
/**
 * Describes the current Amazon EC2 Auto Scaling resource quotas for your account.
 *
 * When you establish an Amazon Web Services account, the account has initial quotas on the maximum
 * number of Auto Scaling groups and launch configurations that you can create in a given Region.
 * For more information, see Quotas for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeAccountLimits: API.OperationMethod<DescribeAccountLimitsRequest & RegionInput, DescribeAccountLimitsAnswer, DescribeAccountLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountSettingsError = InvalidNextToken | CommonErrors;
/**
 * Describes the current Amazon EC2 Auto Scaling account settings for your account. Account settings are a framework that allows you to enable or disable features for your account. The framework also gives you visibility into features that will be enforced by a given date, providing a time window to prepare for backwards-incompatible changes.
 */
export declare const describeAccountSettings: API.OperationMethod<DescribeAccountSettingsType & RegionInput, DescribeAccountSettingsAnswer, DescribeAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeAdjustmentTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the available adjustment types for step scaling and simple scaling
 * policies.
 *
 * The following adjustment types are supported:
 *
 * - `ChangeInCapacity`
 *
 * - `ExactCapacity`
 *
 * - `PercentChangeInCapacity`
 */
export declare const describeAdjustmentTypes: API.OperationMethod<DescribeAdjustmentTypesRequest & RegionInput, DescribeAdjustmentTypesAnswer, DescribeAdjustmentTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeAutoScalingGroupsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the Auto Scaling groups in the account and Region.
 *
 * If you specify Auto Scaling group names, the output includes information for only the
 * specified Auto Scaling groups. If you specify filters, the output includes information for only
 * those Auto Scaling groups that meet the filter criteria. If you do not specify group names or
 * filters, the output includes information for all Auto Scaling groups.
 *
 * This operation also returns information about instances in Auto Scaling groups. To retrieve
 * information about the instances in a warm pool, you must call the
 * DescribeWarmPool API.
 */
export declare const describeAutoScalingGroups: API.PaginatedOperationMethod<AutoScalingGroupNamesType & RegionInput, AutoScalingGroupsType, DescribeAutoScalingGroupsError, Credentials | HttpClient.HttpClient, AutoScalingGroup>;
export type DescribeAutoScalingInstancesError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the Auto Scaling instances in the account and Region.
 */
export declare const describeAutoScalingInstances: API.PaginatedOperationMethod<DescribeAutoScalingInstancesType & RegionInput, AutoScalingInstancesType, DescribeAutoScalingInstancesError, Credentials | HttpClient.HttpClient, AutoScalingInstanceDetails>;
export type DescribeAutoScalingNotificationTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the notification types that are supported by Amazon EC2 Auto Scaling.
 */
export declare const describeAutoScalingNotificationTypes: API.OperationMethod<DescribeAutoScalingNotificationTypesRequest & RegionInput, DescribeAutoScalingNotificationTypesAnswer, DescribeAutoScalingNotificationTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeInstanceRefreshesError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the instance refreshes for the specified Auto Scaling group from the
 * previous six weeks.
 *
 * This operation is part of the instance refresh
 * feature in Amazon EC2 Auto Scaling, which helps you update instances in your Auto Scaling group
 * after you make configuration changes.
 *
 * To help you determine the status of an instance refresh, Amazon EC2 Auto Scaling returns information
 * about the instance refreshes you previously initiated, including their status, start
 * time, end time, the percentage of the instance refresh that is complete, and the number
 * of instances remaining to update before the instance refresh is complete. If a rollback
 * is initiated while an instance refresh is in progress, Amazon EC2 Auto Scaling also returns information
 * about the rollback of the instance refresh.
 */
export declare const describeInstanceRefreshes: API.PaginatedOperationMethod<DescribeInstanceRefreshesType & RegionInput, DescribeInstanceRefreshesAnswer, DescribeInstanceRefreshesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeLaunchConfigurationsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the launch configurations in the account and Region.
 */
export declare const describeLaunchConfigurations: API.PaginatedOperationMethod<LaunchConfigurationNamesType & RegionInput, LaunchConfigurationsType, DescribeLaunchConfigurationsError, Credentials | HttpClient.HttpClient, LaunchConfiguration>;
export type DescribeLifecycleHooksError = ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Gets information about the lifecycle hooks for the specified Auto Scaling group.
 */
export declare const describeLifecycleHooks: API.OperationMethod<DescribeLifecycleHooksType & RegionInput, DescribeLifecycleHooksAnswer, DescribeLifecycleHooksError, Credentials | HttpClient.HttpClient>;
export type DescribeLifecycleHookTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the available types of lifecycle hooks.
 *
 * The following hook types are supported:
 *
 * - `autoscaling:EC2_INSTANCE_LAUNCHING`
 *
 * - `autoscaling:EC2_INSTANCE_TERMINATING`
 */
export declare const describeLifecycleHookTypes: API.OperationMethod<DescribeLifecycleHookTypesRequest & RegionInput, DescribeLifecycleHookTypesAnswer, DescribeLifecycleHookTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancersError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * This API operation is superseded by DescribeTrafficSources,
 * which can describe multiple traffic sources types. We recommend using
 * `DescribeTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `DescribeLoadBalancers`. You can use both
 * the original `DescribeLoadBalancers` API operation and
 * `DescribeTrafficSources` on the same Auto Scaling group.
 *
 * Gets information about the load balancers for the specified Auto Scaling group.
 *
 * This operation describes only Classic Load Balancers. If you have Application Load Balancers, Network Load Balancers, or Gateway Load Balancers, use the
 * DescribeLoadBalancerTargetGroups API instead.
 *
 * To determine the attachment status of the load balancer, use the `State`
 * element in the response. When you attach a load balancer to an Auto Scaling group, the initial
 * `State` value is `Adding`. The state transitions to
 * `Added` after all Auto Scaling instances are registered with the load balancer.
 * If Elastic Load Balancing health checks are enabled for the Auto Scaling group, the state transitions to
 * `InService` after at least one Auto Scaling instance passes the health check.
 * When the load balancer is in the `InService` state, Amazon EC2 Auto Scaling can terminate
 * and replace any instances that are reported as unhealthy. If no registered instances
 * pass the health checks, the load balancer doesn't enter the `InService`
 * state.
 *
 * Load balancers also have an `InService` state if you attach them in the
 * CreateAutoScalingGroup API call. If your load balancer state is
 * `InService`, but it is not working properly, check the scaling activities
 * by calling DescribeScalingActivities and take any corrective actions
 * necessary.
 *
 * For help with failed health checks, see Troubleshooting Amazon EC2 Auto Scaling:
 * Health checks in the *Amazon EC2 Auto Scaling User Guide*. For more
 * information, see Use Elastic Load Balancing to
 * distribute traffic across the instances in your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeLoadBalancers: API.PaginatedOperationMethod<DescribeLoadBalancersRequest & RegionInput, DescribeLoadBalancersResponse, DescribeLoadBalancersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeLoadBalancerTargetGroupsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * This API operation is superseded by DescribeTrafficSources,
 * which can describe multiple traffic sources types. We recommend using
 * `DetachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `DescribeLoadBalancerTargetGroups`. You
 * can use both the original `DescribeLoadBalancerTargetGroups` API
 * operation and `DescribeTrafficSources` on the same Auto Scaling group.
 *
 * Gets information about the Elastic Load Balancing target groups for the specified Auto Scaling group.
 *
 * To determine the attachment status of the target group, use the `State`
 * element in the response. When you attach a target group to an Auto Scaling group, the initial
 * `State` value is `Adding`. The state transitions to
 * `Added` after all Auto Scaling instances are registered with the target group. If
 * Elastic Load Balancing health checks are enabled for the Auto Scaling group, the state transitions to
 * `InService` after at least one Auto Scaling instance passes the health check.
 * When the target group is in the `InService` state, Amazon EC2 Auto Scaling can terminate and
 * replace any instances that are reported as unhealthy. If no registered instances pass
 * the health checks, the target group doesn't enter the `InService` state.
 *
 * Target groups also have an `InService` state if you attach them in the
 * CreateAutoScalingGroup API call. If your target group state is
 * `InService`, but it is not working properly, check the scaling activities
 * by calling DescribeScalingActivities and take any corrective actions
 * necessary.
 *
 * For help with failed health checks, see Troubleshooting Amazon EC2 Auto Scaling:
 * Health checks in the *Amazon EC2 Auto Scaling User Guide*. For more
 * information, see Use Elastic Load Balancing to
 * distribute traffic across the instances in your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 *
 * You can use this operation to describe target groups that were attached by using
 * AttachLoadBalancerTargetGroups, but not for target groups that
 * were attached by using AttachTrafficSources.
 */
export declare const describeLoadBalancerTargetGroups: API.PaginatedOperationMethod<DescribeLoadBalancerTargetGroupsRequest & RegionInput, DescribeLoadBalancerTargetGroupsResponse, DescribeLoadBalancerTargetGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetricCollectionTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the available CloudWatch metrics for Amazon EC2 Auto Scaling.
 */
export declare const describeMetricCollectionTypes: API.OperationMethod<DescribeMetricCollectionTypesRequest & RegionInput, DescribeMetricCollectionTypesAnswer, DescribeMetricCollectionTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeNotificationConfigurationsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the Amazon SNS notifications that are configured for one or more
 * Auto Scaling groups.
 */
export declare const describeNotificationConfigurations: API.PaginatedOperationMethod<DescribeNotificationConfigurationsType & RegionInput, DescribeNotificationConfigurationsAnswer, DescribeNotificationConfigurationsError, Credentials | HttpClient.HttpClient, NotificationConfiguration>;
export type DescribePoliciesError = InvalidNextToken | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Gets information about the scaling policies in the account and Region.
 */
export declare const describePolicies: API.PaginatedOperationMethod<DescribePoliciesType & RegionInput, PoliciesType, DescribePoliciesError, Credentials | HttpClient.HttpClient, ScalingPolicy>;
export type DescribeScalingActivitiesError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the scaling activities in the account and Region.
 *
 * When scaling events occur, you see a record of the scaling activity in the scaling
 * activities. For more information, see Verify a scaling
 * activity for an Auto Scaling group in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * If the scaling event succeeds, the value of the `StatusCode` element in the
 * response is `Successful`. If an attempt to launch instances failed, the
 * `StatusCode` value is `Failed` or `Cancelled` and
 * the `StatusMessage` element in the response indicates the cause of the
 * failure. For help interpreting the `StatusMessage`, see Troubleshooting Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeScalingActivities: API.PaginatedOperationMethod<DescribeScalingActivitiesType & RegionInput, ActivitiesType, DescribeScalingActivitiesError, Credentials | HttpClient.HttpClient, Activity>;
export type DescribeScalingProcessTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the scaling process types for use with the ResumeProcesses
 * and SuspendProcesses APIs.
 */
export declare const describeScalingProcessTypes: API.OperationMethod<DescribeScalingProcessTypesRequest & RegionInput, ProcessesType, DescribeScalingProcessTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeScheduledActionsError = InvalidNextToken | ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Gets information about the scheduled actions that haven't run or that have not reached
 * their end time.
 *
 * To describe the scaling activities for scheduled actions that have already run, call
 * the DescribeScalingActivities API.
 */
export declare const describeScheduledActions: API.PaginatedOperationMethod<DescribeScheduledActionsType & RegionInput, ScheduledActionsType, DescribeScheduledActionsError, Credentials | HttpClient.HttpClient, ScheduledUpdateGroupAction>;
export type DescribeTagsError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Describes the specified tags.
 *
 * You can use filters to limit the results. For example, you can query for the tags for
 * a specific Auto Scaling group. You can specify multiple values for a filter. A tag must match at
 * least one of the specified values for it to be included in the results.
 *
 * You can also specify multiple filters. The result includes information for a
 * particular tag only if it matches all the filters. If there's no match, no special
 * message is returned.
 *
 * For more information, see Tag Auto Scaling groups and
 * instances in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeTags: API.PaginatedOperationMethod<DescribeTagsType & RegionInput, TagsType, DescribeTagsError, Credentials | HttpClient.HttpClient, TagDescription>;
export type DescribeTerminationPolicyTypesError = ResourceContentionFault | CommonErrors;
/**
 * Describes the termination policies supported by Amazon EC2 Auto Scaling.
 *
 * For more information, see Configure
 * termination policies for Amazon EC2 Auto Scaling in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeTerminationPolicyTypes: API.OperationMethod<DescribeTerminationPolicyTypesRequest & RegionInput, DescribeTerminationPolicyTypesAnswer, DescribeTerminationPolicyTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeTrafficSourcesError = InvalidNextToken | ResourceContentionFault | CommonErrors;
/**
 * Gets information about the traffic sources for the specified Auto Scaling group.
 *
 * You can optionally provide a traffic source type. If you provide a traffic source
 * type, then the results only include that traffic source type.
 *
 * If you do not provide a traffic source type, then the results include all the traffic
 * sources for the specified Auto Scaling group.
 */
export declare const describeTrafficSources: API.PaginatedOperationMethod<DescribeTrafficSourcesRequest & RegionInput, DescribeTrafficSourcesResponse, DescribeTrafficSourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeWarmPoolError = InvalidNextToken | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Gets information about a warm pool and its instances.
 *
 * For more information, see Warm pools for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const describeWarmPool: API.PaginatedOperationMethod<DescribeWarmPoolType & RegionInput, DescribeWarmPoolAnswer, DescribeWarmPoolError, Credentials | HttpClient.HttpClient, Instance>;
export type DetachInstancesError = ResourceContentionFault | CommonErrors;
/**
 * Removes one or more instances from the specified Auto Scaling group.
 *
 * After the instances are detached, you can manage them independent of the Auto Scaling
 * group.
 *
 * If you do not specify the option to decrement the desired capacity, Amazon EC2 Auto Scaling launches
 * instances to replace the ones that are detached.
 *
 * If there is a Classic Load Balancer attached to the Auto Scaling group, the instances are
 * deregistered from the load balancer. If there are target groups attached to the Auto Scaling
 * group, the instances are deregistered from the target groups.
 *
 * For more information, see Detach
 * or attach instances in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const detachInstances: API.OperationMethod<DetachInstancesQuery & RegionInput, DetachInstancesAnswer, DetachInstancesError, Credentials | HttpClient.HttpClient>;
export type DetachLoadBalancersError = ResourceContentionFault | CommonErrors;
/**
 * This API operation is superseded by DetachTrafficSources, which
 * can detach multiple traffic sources types. We recommend using
 * `DetachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `DetachLoadBalancers`. You can use both
 * the original `DetachLoadBalancers` API operation and
 * `DetachTrafficSources` on the same Auto Scaling group.
 *
 * Detaches one or more Classic Load Balancers from the specified Auto Scaling group.
 *
 * This operation detaches only Classic Load Balancers. If you have Application Load Balancers, Network Load Balancers, or
 * Gateway Load Balancers, use the DetachLoadBalancerTargetGroups API instead.
 *
 * When you detach a load balancer, it enters the `Removing` state while
 * deregistering the instances in the group. When all instances are deregistered, then you
 * can no longer describe the load balancer using the DescribeLoadBalancers
 * API call. The instances remain running.
 */
export declare const detachLoadBalancers: API.OperationMethod<DetachLoadBalancersType & RegionInput, DetachLoadBalancersResultType, DetachLoadBalancersError, Credentials | HttpClient.HttpClient>;
export type DetachLoadBalancerTargetGroupsError = ResourceContentionFault | CommonErrors;
/**
 * This API operation is superseded by DetachTrafficSources, which
 * can detach multiple traffic sources types. We recommend using
 * `DetachTrafficSources` to simplify how you manage traffic sources.
 * However, we continue to support `DetachLoadBalancerTargetGroups`. You can
 * use both the original `DetachLoadBalancerTargetGroups` API operation and
 * `DetachTrafficSources` on the same Auto Scaling group.
 *
 * Detaches one or more target groups from the specified Auto Scaling group.
 *
 * When you detach a target group, it enters the `Removing` state while
 * deregistering the instances in the group. When all instances are deregistered, then you
 * can no longer describe the target group using the
 * DescribeLoadBalancerTargetGroups
 * API call. The instances remain running.
 *
 * You can use this operation to detach target groups that were attached by using
 * AttachLoadBalancerTargetGroups, but not for target groups that
 * were attached by using AttachTrafficSources.
 */
export declare const detachLoadBalancerTargetGroups: API.OperationMethod<DetachLoadBalancerTargetGroupsType & RegionInput, DetachLoadBalancerTargetGroupsResultType, DetachLoadBalancerTargetGroupsError, Credentials | HttpClient.HttpClient>;
export type DetachTrafficSourcesError = ResourceContentionFault | CommonErrors;
/**
 * Detaches one or more traffic sources from the specified Auto Scaling group.
 *
 * When you detach a traffic source, it enters the `Removing` state while
 * deregistering the instances in the group. When all instances are deregistered, then you
 * can no longer describe the traffic source using the
 * DescribeTrafficSources
 * API call. The instances continue to run.
 */
export declare const detachTrafficSources: API.OperationMethod<DetachTrafficSourcesType & RegionInput, DetachTrafficSourcesResultType, DetachTrafficSourcesError, Credentials | HttpClient.HttpClient>;
export type DisableMetricsCollectionError = ResourceContentionFault | CommonErrors;
/**
 * Disables group metrics collection for the specified Auto Scaling group.
 */
export declare const disableMetricsCollection: API.OperationMethod<DisableMetricsCollectionQuery & RegionInput, DisableMetricsCollectionResponse, DisableMetricsCollectionError, Credentials | HttpClient.HttpClient>;
export type EnableMetricsCollectionError = ResourceContentionFault | CommonErrors;
/**
 * Enables group metrics collection for the specified Auto Scaling group.
 *
 * You can use these metrics to track changes in an Auto Scaling group and to set alarms on
 * threshold values. You can view group metrics using the Amazon EC2 Auto Scaling console or the CloudWatch
 * console. For more information, see Monitor
 * CloudWatch metrics for your Auto Scaling groups and instances in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const enableMetricsCollection: API.OperationMethod<EnableMetricsCollectionQuery & RegionInput, EnableMetricsCollectionResponse, EnableMetricsCollectionError, Credentials | HttpClient.HttpClient>;
export type EnterStandbyError = ResourceContentionFault | CommonErrors;
/**
 * Moves the specified instances into the standby state.
 *
 * If you choose to decrement the desired capacity of the Auto Scaling group, the instances can
 * enter standby as long as the desired capacity of the Auto Scaling group after the instances are
 * placed into standby is equal to or greater than the minimum capacity of the
 * group.
 *
 * If you choose not to decrement the desired capacity of the Auto Scaling group, the Auto Scaling group
 * launches new instances to replace the instances on standby.
 *
 * For more information, see Temporarily removing
 * instances from your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const enterStandby: API.OperationMethod<EnterStandbyQuery & RegionInput, EnterStandbyAnswer, EnterStandbyError, Credentials | HttpClient.HttpClient>;
export type ExecutePolicyError = ResourceContentionFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Executes the specified policy. This can be useful for testing the design of your
 * scaling policy.
 */
export declare const executePolicy: API.OperationMethod<ExecutePolicyType & RegionInput, ExecutePolicyResponse, ExecutePolicyError, Credentials | HttpClient.HttpClient>;
export type ExitStandbyError = ResourceContentionFault | CommonErrors;
/**
 * Moves the specified instances out of the standby state.
 *
 * After you put the instances back in service, the desired capacity is
 * incremented.
 *
 * For more information, see Temporarily removing
 * instances from your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const exitStandby: API.OperationMethod<ExitStandbyQuery & RegionInput, ExitStandbyAnswer, ExitStandbyError, Credentials | HttpClient.HttpClient>;
export type GetPredictiveScalingForecastError = ResourceContentionFault | CommonErrors;
/**
 * Retrieves the forecast data for a predictive scaling policy.
 *
 * Load forecasts are predictions of the hourly load values using historical load data
 * from CloudWatch and an analysis of historical trends. Capacity forecasts are represented as
 * predicted values for the minimum capacity that is needed on an hourly basis, based on
 * the hourly load forecast.
 *
 * A minimum of 24 hours of data is required to create the initial forecasts. However,
 * having a full 14 days of historical data results in more accurate forecasts.
 *
 * For more information, see Predictive
 * scaling for Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const getPredictiveScalingForecast: API.OperationMethod<GetPredictiveScalingForecastType & RegionInput, GetPredictiveScalingForecastAnswer, GetPredictiveScalingForecastError, Credentials | HttpClient.HttpClient>;
export type LaunchInstancesError = IdempotentCallInProgressFault | IdempotentParameterMismatchError | ResourceContentionFault | CommonErrors;
/**
 * Launches a specified number of instances in an Auto Scaling group. Returns instance IDs and
 * other details if launch is successful or error details if launch is unsuccessful.
 */
export declare const launchInstances: API.OperationMethod<LaunchInstancesRequest & RegionInput, LaunchInstancesResult, LaunchInstancesError, Credentials | HttpClient.HttpClient>;
export type PutAccountSettingError = CommonErrors;
/**
 * Modifies an account setting for your account. You can use this operation to opt in or opt out of features provided through account settings when permitted. Account settings give you control over features that might have backwards-incompatible changes. When Amazon EC2 Auto Scaling introduces such changes, account settings allow you to test and adopt new features. Some account settings are enforced after a specified date. This means that after the enforcement date, you can no longer modify the setting.
 */
export declare const putAccountSetting: API.OperationMethod<PutAccountSettingType & RegionInput, PutAccountSettingAnswer, PutAccountSettingError, Credentials | HttpClient.HttpClient>;
export type PutLifecycleHookError = LimitExceededFault | ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Creates or updates a lifecycle hook for the specified Auto Scaling group.
 *
 * Lifecycle hooks let you create solutions that are aware of events in the Auto Scaling instance
 * lifecycle, and then perform a custom action on instances when the corresponding
 * lifecycle event occurs.
 *
 * This step is a part of the procedure for adding a lifecycle hook to an Auto Scaling
 * group:
 *
 * - (Optional) Create a launch template or launch configuration with a user data
 * script that runs while an instance is in a wait state due to a lifecycle
 * hook.
 *
 * - (Optional) Create a Lambda function and a rule that allows Amazon EventBridge to invoke
 * your Lambda function when an instance is put into a wait state due to a
 * lifecycle hook.
 *
 * - (Optional) Create a notification target and an IAM role. The target can be
 * either an Amazon SQS queue or an Amazon SNS topic. The role allows Amazon EC2 Auto Scaling to publish
 * lifecycle notifications to the target.
 *
 * - Create the lifecycle hook. Specify whether the hook is
 * used when the instances launch or terminate.
 *
 * - If you need more time, record the lifecycle action heartbeat to keep the
 * instance in a wait state using the RecordLifecycleActionHeartbeat API call.
 *
 * - If you finish before the timeout period ends, send a callback by using the
 * CompleteLifecycleAction API call.
 *
 * For more information, see Amazon EC2 Auto Scaling lifecycle
 * hooks in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * If you exceed your maximum limit of lifecycle hooks, which by default is 50 per Auto Scaling
 * group, the call fails.
 *
 * You can view the lifecycle hooks for an Auto Scaling group using the
 * DescribeLifecycleHooks API call. If you are no longer using a lifecycle
 * hook, you can delete it by calling the DeleteLifecycleHook API.
 */
export declare const putLifecycleHook: API.OperationMethod<PutLifecycleHookType & RegionInput, PutLifecycleHookAnswer, PutLifecycleHookError, Credentials | HttpClient.HttpClient>;
export type PutNotificationConfigurationError = LimitExceededFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Configures an Auto Scaling group to send notifications when specified events take place.
 * Subscribers to the specified topic can have messages delivered to an endpoint such as a
 * web server or an email address.
 *
 * This configuration overwrites any existing configuration.
 *
 * For more information, see Amazon SNS
 * notification options for Amazon EC2 Auto Scaling in the
 * *Amazon EC2 Auto Scaling User Guide*.
 *
 * If you exceed your maximum limit of SNS topics, which is 10 per Auto Scaling group, the call
 * fails.
 */
export declare const putNotificationConfiguration: API.OperationMethod<PutNotificationConfigurationType & RegionInput, PutNotificationConfigurationResponse, PutNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutScalingPolicyError = LimitExceededFault | ResourceContentionFault | ServiceLinkedRoleFailure | CommonErrors;
/**
 * Creates or updates a scaling policy for an Auto Scaling group. Scaling policies are used to
 * scale an Auto Scaling group based on configurable metrics. If no policies are defined, the
 * dynamic scaling and predictive scaling features are not used.
 *
 * For more information about using dynamic scaling, see Target tracking
 * scaling policies and Step and simple scaling
 * policies in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * For more information about using predictive scaling, see Predictive
 * scaling for Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * You can view the scaling policies for an Auto Scaling group using the
 * DescribePolicies API call. If you are no longer using a scaling policy,
 * you can delete it by calling the DeletePolicy API.
 */
export declare const putScalingPolicy: API.OperationMethod<PutScalingPolicyType & RegionInput, PolicyARNType, PutScalingPolicyError, Credentials | HttpClient.HttpClient>;
export type PutScheduledUpdateGroupActionError = AlreadyExistsFault | LimitExceededFault | ResourceContentionFault | AutoScalingGroupNotFound | CommonErrors;
/**
 * Creates or updates a scheduled scaling action for an Auto Scaling group.
 *
 * For more information, see Scheduled scaling in the
 * *Amazon EC2 Auto Scaling User Guide*.
 *
 * You can view the scheduled actions for an Auto Scaling group using the
 * DescribeScheduledActions
 * API call. If you are no longer using a scheduled action, you can delete it by calling the
 * DeleteScheduledAction API.
 *
 * If you try to schedule your action in the past, Amazon EC2 Auto Scaling returns an error
 * message.
 */
export declare const putScheduledUpdateGroupAction: API.OperationMethod<PutScheduledUpdateGroupActionType & RegionInput, PutScheduledUpdateGroupActionResponse, PutScheduledUpdateGroupActionError, Credentials | HttpClient.HttpClient>;
export type PutWarmPoolError = InstanceRefreshInProgressFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Creates or updates a warm pool for the specified Auto Scaling group. A warm pool is a pool of
 * pre-initialized EC2 instances that sits alongside the Auto Scaling group. Whenever your
 * application needs to scale out, the Auto Scaling group can draw on the warm pool to meet its new
 * desired capacity.
 *
 * This operation must be called from the Region in which the Auto Scaling group was
 * created.
 *
 * You can view the instances in the warm pool using the DescribeWarmPool API call.
 * If you are no longer using a warm pool, you can delete it by calling the DeleteWarmPool API.
 *
 * For more information, see Warm pools for
 * Amazon EC2 Auto Scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const putWarmPool: API.OperationMethod<PutWarmPoolType & RegionInput, PutWarmPoolAnswer, PutWarmPoolError, Credentials | HttpClient.HttpClient>;
export type RecordLifecycleActionHeartbeatError = ResourceContentionFault | CommonErrors;
/**
 * Records a heartbeat for the lifecycle action associated with the specified token or
 * instance. This extends the timeout by the length of time defined using the
 * PutLifecycleHook API call.
 *
 * This step is a part of the procedure for adding a lifecycle hook to an Auto Scaling
 * group:
 *
 * - (Optional) Create a launch template or launch configuration with a user data
 * script that runs while an instance is in a wait state due to a lifecycle
 * hook.
 *
 * - (Optional) Create a Lambda function and a rule that allows Amazon EventBridge to invoke
 * your Lambda function when an instance is put into a wait state due to a
 * lifecycle hook.
 *
 * - (Optional) Create a notification target and an IAM role. The target can be
 * either an Amazon SQS queue or an Amazon SNS topic. The role allows Amazon EC2 Auto Scaling to publish
 * lifecycle notifications to the target.
 *
 * - Create the lifecycle hook. Specify whether the hook is used when the instances
 * launch or terminate.
 *
 * - If you need more time, record the lifecycle action
 * heartbeat to keep the instance in a wait state.
 *
 * - If you finish before the timeout period ends, send a callback by using the
 * CompleteLifecycleAction API call.
 *
 * For more information, see Amazon EC2 Auto Scaling lifecycle
 * hooks in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const recordLifecycleActionHeartbeat: API.OperationMethod<RecordLifecycleActionHeartbeatType & RegionInput, RecordLifecycleActionHeartbeatAnswer, RecordLifecycleActionHeartbeatError, Credentials | HttpClient.HttpClient>;
export type ResumeProcessesError = ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Resumes the specified suspended auto scaling processes, or all suspended process, for
 * the specified Auto Scaling group.
 *
 * For more information, see Suspend and resume
 * Amazon EC2 Auto Scaling processes in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const resumeProcesses: API.OperationMethod<ScalingProcessQuery & RegionInput, ResumeProcessesResponse, ResumeProcessesError, Credentials | HttpClient.HttpClient>;
export type RollbackInstanceRefreshError = ActiveInstanceRefreshNotFoundFault | IrreversibleInstanceRefreshFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Cancels an instance refresh that is in progress and rolls back any changes that it
 * made. Amazon EC2 Auto Scaling replaces any instances that were replaced during the instance refresh.
 * This restores your Auto Scaling group to the configuration that it was using before the start of
 * the instance refresh.
 *
 * This operation is part of the instance refresh
 * feature in Amazon EC2 Auto Scaling, which helps you update instances in your Auto Scaling group
 * after you make configuration changes.
 *
 * A rollback is not supported in the following situations:
 *
 * - There is no desired configuration specified for the instance refresh.
 *
 * - The Auto Scaling group has a launch template that uses an Amazon Web Services Systems Manager parameter instead
 * of an AMI ID for the `ImageId` property.
 *
 * - The Auto Scaling group uses the launch template's `$Latest` or
 * `$Default` version.
 *
 * When you receive a successful response from this operation, Amazon EC2 Auto Scaling immediately
 * begins replacing instances. You can check the status of this operation through the
 * DescribeInstanceRefreshes API operation.
 */
export declare const rollbackInstanceRefresh: API.OperationMethod<RollbackInstanceRefreshType & RegionInput, RollbackInstanceRefreshAnswer, RollbackInstanceRefreshError, Credentials | HttpClient.HttpClient>;
export type SetDesiredCapacityError = ResourceContentionFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Sets the size of the specified Auto Scaling group.
 *
 * If a scale-in activity occurs as a result of a new `DesiredCapacity` value
 * that is lower than the current size of the group, the Auto Scaling group uses its termination
 * policy to determine which instances to terminate.
 *
 * For more information, see Manual
 * scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const setDesiredCapacity: API.OperationMethod<SetDesiredCapacityType & RegionInput, SetDesiredCapacityResponse, SetDesiredCapacityError, Credentials | HttpClient.HttpClient>;
export type SetInstanceHealthError = ResourceContentionFault | CommonErrors;
/**
 * Sets the health status of the specified instance.
 *
 * For more information, see Set up a custom
 * health check for your Auto Scaling group in the
 * *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const setInstanceHealth: API.OperationMethod<SetInstanceHealthQuery & RegionInput, SetInstanceHealthResponse, SetInstanceHealthError, Credentials | HttpClient.HttpClient>;
export type SetInstanceProtectionError = LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Updates the instance protection settings of the specified instances. This operation
 * cannot be called on instances in a warm pool.
 *
 * For more information, see Use
 * instance scale-in protection in the
 * *Amazon EC2 Auto Scaling User Guide*.
 *
 * If you exceed your maximum limit of instance IDs, which is 50 per Auto Scaling group, the call
 * fails.
 */
export declare const setInstanceProtection: API.OperationMethod<SetInstanceProtectionQuery & RegionInput, SetInstanceProtectionAnswer, SetInstanceProtectionError, Credentials | HttpClient.HttpClient>;
export type StartInstanceRefreshError = InstanceRefreshInProgressFault | LimitExceededFault | ResourceContentionFault | CommonErrors;
/**
 * Starts an instance refresh.
 *
 * This operation is part of the instance refresh
 * feature in Amazon EC2 Auto Scaling, which helps you update instances in your Auto Scaling group.
 * This feature is helpful, for example, when you have a new AMI or a new user data script.
 * You just need to create a new launch template that specifies the new AMI or user data
 * script. Then start an instance refresh to immediately begin the process of updating
 * instances in the group.
 *
 * If successful, the request's response contains a unique ID that you can use to track
 * the progress of the instance refresh. To query its status, call the DescribeInstanceRefreshes API.
 * To describe the instance refreshes that
 * have already run, call the DescribeInstanceRefreshes API. To cancel an
 * instance refresh that is in progress, use the CancelInstanceRefresh
 * API.
 *
 * An instance refresh might fail for several reasons, such as EC2 launch failures,
 * misconfigured health checks, or not ignoring or allowing the termination of instances
 * that are in `Standby` state or protected from scale in. You can monitor for
 * failed EC2 launches using the scaling activities. To find the scaling activities, call
 * the DescribeScalingActivities API.
 *
 * If you enable auto rollback, your Auto Scaling group will be rolled back automatically when
 * the instance refresh fails. You can enable this feature before starting an instance
 * refresh by specifying the `AutoRollback` property in the instance refresh
 * preferences. Otherwise, to roll back an instance refresh before it finishes, use the
 * RollbackInstanceRefresh API.
 */
export declare const startInstanceRefresh: API.OperationMethod<StartInstanceRefreshType & RegionInput, StartInstanceRefreshAnswer, StartInstanceRefreshError, Credentials | HttpClient.HttpClient>;
export type SuspendProcessesError = ResourceContentionFault | ResourceInUseFault | CommonErrors;
/**
 * Suspends the specified auto scaling processes, or all processes, for the specified
 * Auto Scaling group.
 *
 * If you suspend either the `Launch` or `Terminate` process types,
 * it can prevent other process types from functioning properly. For more information, see
 * Suspend and resume
 * Amazon EC2 Auto Scaling processes in the *Amazon EC2 Auto Scaling User Guide*.
 *
 * To resume processes that have been suspended, call the ResumeProcesses API.
 */
export declare const suspendProcesses: API.OperationMethod<ScalingProcessQuery & RegionInput, SuspendProcessesResponse, SuspendProcessesError, Credentials | HttpClient.HttpClient>;
export type TerminateInstanceInAutoScalingGroupError = ResourceContentionFault | ScalingActivityInProgressFault | CommonErrors;
/**
 * Terminates the specified instance and optionally adjusts the desired group size. This
 * operation cannot be called on instances in a warm pool.
 *
 * This call simply makes a termination request. The instances are not terminated
 * immediately. When an instance is terminated, the instance status changes to
 * `terminated`. You can't connect to or start an instance after you've
 * terminated it.
 *
 * If you do not specify the option to decrement the desired capacity, Amazon EC2 Auto Scaling launches
 * instances to replace the ones that are terminated.
 *
 * To terminate multiple instances in a single call, use the `InstanceIds`
 * and `AutoScalingGroupName` parameters instead of `InstanceId`.
 * When terminating multiple instances, the response populates
 * `Activities` instead of `Activity`.
 *
 * By default, Amazon EC2 Auto Scaling balances instances across all Availability Zones. If you
 * decrement the desired capacity, your Auto Scaling group can become unbalanced between
 * Availability Zones. Amazon EC2 Auto Scaling tries to rebalance the group, and rebalancing might
 * terminate instances in other zones. For more information, see Manual
 * scaling in the *Amazon EC2 Auto Scaling User Guide*.
 */
export declare const terminateInstanceInAutoScalingGroup: API.OperationMethod<TerminateInstanceInAutoScalingGroupType & RegionInput, ActivityType, TerminateInstanceInAutoScalingGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateAutoScalingGroupError = ResourceContentionFault | ScalingActivityInProgressFault | ServiceLinkedRoleFailure | InvalidIamInstanceProfile | CommonErrors;
/**
 * **We strongly recommend that all Auto Scaling groups use launch templates to ensure full functionality for Amazon EC2 Auto Scaling and Amazon EC2.**
 *
 * Updates the configuration for the specified Auto Scaling group.
 *
 * To update an Auto Scaling group, specify the name of the group and the property that you want
 * to change. Any properties that you don't specify are not changed by this update request.
 * The new settings take effect on any scaling activities after this call returns.
 *
 * If you associate a new launch configuration or template with an Auto Scaling group, all new
 * instances will get the updated configuration. Existing instances continue to run with
 * the configuration that they were originally launched with. When you update a group to
 * specify a mixed instances policy instead of a launch configuration or template, existing
 * instances may be replaced to match the new purchasing options that you specified in the
 * policy. For example, if the group currently has 100% On-Demand capacity and the policy
 * specifies 50% Spot capacity, this means that half of your instances will be gradually
 * terminated and relaunched as Spot Instances. When replacing instances, Amazon EC2 Auto Scaling launches
 * new instances before terminating the old ones, so that updating your group does not
 * compromise the performance or availability of your application.
 *
 * Note the following about changing `DesiredCapacity`, `MaxSize`,
 * or `MinSize`:
 *
 * - If a scale-in activity occurs as a result of a new
 * `DesiredCapacity` value that is lower than the current size of
 * the group, the Auto Scaling group uses its termination policy to determine which
 * instances to terminate.
 *
 * - If you specify a new value for `MinSize` without specifying a value
 * for `DesiredCapacity`, and the new `MinSize` is larger
 * than the current size of the group, this sets the group's
 * `DesiredCapacity` to the new `MinSize` value.
 *
 * - If you specify a new value for `MaxSize` without specifying a value
 * for `DesiredCapacity`, and the new `MaxSize` is smaller
 * than the current size of the group, this sets the group's
 * `DesiredCapacity` to the new `MaxSize` value.
 *
 * To see which properties have been set, call the DescribeAutoScalingGroups API.
 * To view the scaling policies for an Auto Scaling
 * group, call the DescribePolicies API. If the group has scaling
 * policies, you can update them by calling the PutScalingPolicy API.
 */
export declare const updateAutoScalingGroup: API.OperationMethod<UpdateAutoScalingGroupType & RegionInput, UpdateAutoScalingGroupResponse, UpdateAutoScalingGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=auto-scaling.d.ts.map