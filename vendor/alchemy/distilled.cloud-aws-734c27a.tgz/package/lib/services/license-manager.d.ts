import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AuthorizationException_base: S.TaggedErrorClass<"AuthorizationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AuthorizationException extends /*@__PURE__*/ AuthorizationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const EntitlementNotAllowedException_base: S.TaggedErrorClass<"EntitlementNotAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EntitlementNotAllowedException extends /*@__PURE__*/ EntitlementNotAllowedException_base {
}
declare const FailedDependencyException_base: S.TaggedErrorClass<"FailedDependencyException", {
    readonly message: any;
    readonly ErrorCode: any;
}>;
export declare class FailedDependencyException extends /*@__PURE__*/ FailedDependencyException_base {
}
declare const FilterLimitExceededException_base: S.TaggedErrorClass<"FilterLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FilterLimitExceededException extends /*@__PURE__*/ FilterLimitExceededException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidResourceStateException_base: S.TaggedErrorClass<"InvalidResourceStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourceStateException extends /*@__PURE__*/ InvalidResourceStateException_base {
}
declare const LicenseConfigurationNotFound_base: S.TaggedErrorClass<"LicenseConfigurationNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class LicenseConfigurationNotFound extends /*@__PURE__*/ LicenseConfigurationNotFound_base {
}
declare const LicenseUsageException_base: S.TaggedErrorClass<"LicenseUsageException", {
    readonly message: any;
}>;
export declare class LicenseUsageException extends /*@__PURE__*/ LicenseUsageException_base {
}
declare const NoEntitlementsAllowedException_base: S.TaggedErrorClass<"NoEntitlementsAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoEntitlementsAllowedException extends /*@__PURE__*/ NoEntitlementsAllowedException_base {
}
declare const RateLimitExceededException_base: S.TaggedErrorClass<"RateLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class RateLimitExceededException extends /*@__PURE__*/ RateLimitExceededException_base {
}
declare const RedirectException_base: S.TaggedErrorClass<"RedirectException", {
    readonly Location: any;
    readonly message: any;
}>;
export declare class RedirectException extends /*@__PURE__*/ RedirectException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServerInternalException_base: S.TaggedErrorClass<"ServerInternalException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServerInternalException extends /*@__PURE__*/ ServerInternalException_base {
}
declare const UnsupportedDigitalSignatureMethodException_base: S.TaggedErrorClass<"UnsupportedDigitalSignatureMethodException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedDigitalSignatureMethodException extends /*@__PURE__*/ UnsupportedDigitalSignatureMethodException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export interface AcceptGrantRequest {
    GrantArn: string;
}
export type GrantStatus = "PENDING_WORKFLOW" | "PENDING_ACCEPT" | "REJECTED" | "ACTIVE" | "FAILED_WORKFLOW" | "DELETED" | "PENDING_DELETE" | "DISABLED" | "WORKFLOW_COMPLETED" | (string & {});
export interface AcceptGrantResponse {
    GrantArn?: string | undefined;
    Status?: GrantStatus | undefined;
    Version?: string | undefined;
}
export interface CheckInLicenseRequest {
    LicenseConsumptionToken: string;
    Beneficiary?: string | undefined;
}
export interface CheckInLicenseResponse {
}
export type EntitlementDataUnit = "Count" | "None" | "Seconds" | "Microseconds" | "Milliseconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | (string & {});
export interface EntitlementData {
    Name: string;
    Value?: string | undefined;
    Unit: EntitlementDataUnit;
}
export type EntitlementDataList = EntitlementData[];
export type DigitalSignatureMethod = "JWT_PS384" | (string & {});
export interface Metadata {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type MetadataList = Metadata[];
export type ClientToken = string;
export interface CheckoutBorrowLicenseRequest {
    LicenseArn: string;
    Entitlements: EntitlementData[];
    DigitalSignatureMethod: DigitalSignatureMethod;
    NodeId?: string | undefined;
    CheckoutMetadata?: Metadata[] | undefined;
    ClientToken: string;
}
export type SignedToken = string;
export type ISO8601DateTime = string;
export interface CheckoutBorrowLicenseResponse {
    LicenseArn?: string | undefined;
    LicenseConsumptionToken?: string | undefined;
    EntitlementsAllowed?: EntitlementData[] | undefined;
    NodeId?: string | undefined;
    SignedToken?: string | undefined;
    IssuedAt?: string | undefined;
    Expiration?: string | undefined;
    CheckoutMetadata?: Metadata[] | undefined;
}
export type CheckoutType = "PROVISIONAL" | "PERPETUAL" | (string & {});
export interface CheckoutLicenseRequest {
    ProductSKU: string;
    CheckoutType: CheckoutType;
    KeyFingerprint: string;
    Entitlements: EntitlementData[];
    ClientToken: string;
    Beneficiary?: string | undefined;
    NodeId?: string | undefined;
}
export interface CheckoutLicenseResponse {
    CheckoutType?: CheckoutType | undefined;
    LicenseConsumptionToken?: string | undefined;
    EntitlementsAllowed?: EntitlementData[] | undefined;
    SignedToken?: string | undefined;
    NodeId?: string | undefined;
    IssuedAt?: string | undefined;
    Expiration?: string | undefined;
    LicenseArn?: string | undefined;
}
export type PrincipalArnList = string[];
export type AllowedOperation = "CreateGrant" | "CheckoutLicense" | "CheckoutBorrowLicense" | "CheckInLicense" | "ExtendConsumptionLicense" | "ListPurchasedLicenses" | "CreateToken" | "ListReceivedLicenses" | (string & {});
export type AllowedOperationList = AllowedOperation[];
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export type GrantType = "BuyerGrant" | "DelegateGrant" | (string & {});
export type ActivationOverrideBehavior = "DISTRIBUTED_GRANTS_ONLY" | "ALL_GRANTS_PERMITTED_BY_ISSUER" | (string & {});
export interface Options {
    ActivationOverrideBehavior?: ActivationOverrideBehavior | undefined;
    DesiredStatus?: GrantStatus | undefined;
}
export interface CreateGrantRequest {
    ClientToken: string;
    GrantName: string;
    LicenseArn: string;
    Principals: string[];
    HomeRegion: string;
    AllowedOperations: AllowedOperation[];
    Tags?: Tag[] | undefined;
    GrantType?: GrantType | undefined;
    Options?: Options | undefined;
}
export interface CreateGrantResponse {
    GrantArn?: string | undefined;
    Status?: GrantStatus | undefined;
    Version?: string | undefined;
}
export type StatusReasonMessage = string;
export interface CreateGrantVersionRequest {
    ClientToken: string;
    GrantArn: string;
    GrantName?: string | undefined;
    AllowedOperations?: AllowedOperation[] | undefined;
    Status?: GrantStatus | undefined;
    StatusReason?: string | undefined;
    SourceVersion?: string | undefined;
    Options?: Options | undefined;
}
export interface CreateGrantVersionResponse {
    GrantArn?: string | undefined;
    Status?: GrantStatus | undefined;
    Version?: string | undefined;
}
export interface Issuer {
    Name: string;
    SignKey?: string | undefined;
}
export interface DatetimeRange {
    Begin: string;
    End?: string | undefined;
}
export type BoxBoolean = boolean;
export type EntitlementUnit = "Count" | "None" | "Seconds" | "Microseconds" | "Milliseconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | (string & {});
export interface Entitlement {
    Name: string;
    Value?: string | undefined;
    MaxCount?: number | undefined;
    Overage?: boolean | undefined;
    Unit: EntitlementUnit;
    AllowCheckIn?: boolean | undefined;
}
export type EntitlementList = Entitlement[];
export type RenewType = "None" | "Weekly" | "Monthly" | (string & {});
export type BoxInteger = number;
export interface ProvisionalConfiguration {
    MaxTimeToLiveInMinutes: number;
}
export interface BorrowConfiguration {
    AllowEarlyCheckIn: boolean;
    MaxTimeToLiveInMinutes: number;
}
export interface ConsumptionConfiguration {
    RenewType?: RenewType | undefined;
    ProvisionalConfiguration?: ProvisionalConfiguration | undefined;
    BorrowConfiguration?: BorrowConfiguration | undefined;
}
export interface CreateLicenseRequest {
    LicenseName: string;
    ProductName: string;
    ProductSKU: string;
    Issuer: Issuer;
    HomeRegion: string;
    Validity: DatetimeRange;
    Entitlements: Entitlement[];
    Beneficiary: string;
    ConsumptionConfiguration: ConsumptionConfiguration;
    LicenseMetadata?: Metadata[] | undefined;
    ClientToken: string;
    Tags?: Tag[] | undefined;
}
export type LicenseStatus = "AVAILABLE" | "PENDING_AVAILABLE" | "DEACTIVATED" | "SUSPENDED" | "EXPIRED" | "PENDING_DELETE" | "DELETED" | (string & {});
export interface CreateLicenseResponse {
    LicenseArn?: string | undefined;
    Status?: LicenseStatus | undefined;
    Version?: string | undefined;
}
export type LicenseAssetResourceName = string;
export type LicenseAssetResourceDescription = string;
export interface LicenseAssetGroupConfiguration {
    UsageDimension?: string | undefined;
}
export type LicenseAssetGroupConfigurationList = LicenseAssetGroupConfiguration[];
export type LicenseAssetRulesetArnList = string[];
export interface LicenseAssetGroupProperty {
    Key: string;
    Value: string;
}
export type LicenseAssetGroupPropertyList = LicenseAssetGroupProperty[];
export interface CreateLicenseAssetGroupRequest {
    Name: string;
    Description?: string | undefined;
    LicenseAssetGroupConfigurations: LicenseAssetGroupConfiguration[];
    AssociatedLicenseAssetRulesetARNs: string[];
    Properties?: LicenseAssetGroupProperty[] | undefined;
    Tags?: Tag[] | undefined;
    ClientToken: string;
}
export interface CreateLicenseAssetGroupResponse {
    LicenseAssetGroupArn: string;
    Status: string;
}
export type StringList = string[];
export interface MatchingRuleStatement {
    KeyToMatch: string;
    Constraint: string;
    ValueToMatch: string[];
}
export type MatchingRuleStatementList = MatchingRuleStatement[];
export interface ScriptRuleStatement {
    KeyToMatch: string;
    Script: string;
}
export type ScriptRuleStatementList = ScriptRuleStatement[];
export interface AndRuleStatement {
    MatchingRuleStatements?: MatchingRuleStatement[] | undefined;
    ScriptRuleStatements?: ScriptRuleStatement[] | undefined;
}
export interface OrRuleStatement {
    MatchingRuleStatements?: MatchingRuleStatement[] | undefined;
    ScriptRuleStatements?: ScriptRuleStatement[] | undefined;
}
export interface LicenseConfigurationRuleStatement {
    AndRuleStatement?: AndRuleStatement | undefined;
    OrRuleStatement?: OrRuleStatement | undefined;
    MatchingRuleStatement?: MatchingRuleStatement | undefined;
}
export interface LicenseRuleStatement {
    AndRuleStatement?: AndRuleStatement | undefined;
    OrRuleStatement?: OrRuleStatement | undefined;
    MatchingRuleStatement?: MatchingRuleStatement | undefined;
}
export interface InstanceRuleStatement {
    AndRuleStatement?: AndRuleStatement | undefined;
    OrRuleStatement?: OrRuleStatement | undefined;
    MatchingRuleStatement?: MatchingRuleStatement | undefined;
    ScriptRuleStatement?: ScriptRuleStatement | undefined;
}
export interface RuleStatement {
    LicenseConfigurationRuleStatement?: LicenseConfigurationRuleStatement | undefined;
    LicenseRuleStatement?: LicenseRuleStatement | undefined;
    InstanceRuleStatement?: InstanceRuleStatement | undefined;
}
export interface LicenseAssetRule {
    RuleStatement: RuleStatement;
}
export type LicenseAssetRuleList = LicenseAssetRule[];
export interface CreateLicenseAssetRulesetRequest {
    Name: string;
    Description?: string | undefined;
    Rules: LicenseAssetRule[];
    Tags?: Tag[] | undefined;
    ClientToken: string;
}
export interface CreateLicenseAssetRulesetResponse {
    LicenseAssetRulesetArn: string;
}
export type LicenseCountingType = "vCPU" | "Instance" | "Core" | "Socket" | (string & {});
export type BoxLong = number;
export interface ProductInformationFilter {
    ProductInformationFilterName: string;
    ProductInformationFilterValue?: string[] | undefined;
    ProductInformationFilterComparator: string;
}
export type ProductInformationFilterList = ProductInformationFilter[];
export interface ProductInformation {
    ResourceType: string;
    ProductInformationFilterList: ProductInformationFilter[];
}
export type ProductInformationList = ProductInformation[];
export interface CreateLicenseConfigurationRequest {
    Name: string;
    Description?: string | undefined;
    LicenseCountingType: LicenseCountingType;
    LicenseCount?: number | undefined;
    LicenseCountHardLimit?: boolean | undefined;
    LicenseRules?: string[] | undefined;
    Tags?: Tag[] | undefined;
    DisassociateWhenNotFound?: boolean | undefined;
    ProductInformationList?: ProductInformation[] | undefined;
    LicenseExpiry?: number | undefined;
}
export interface CreateLicenseConfigurationResponse {
    LicenseConfigurationArn?: string | undefined;
}
export type UsageOperation = string;
export type ProductCodeId = string;
export type ProductCodeType = "marketplace" | (string & {});
export interface ProductCodeListItem {
    ProductCodeId: string;
    ProductCodeType: ProductCodeType;
}
export type ProductCodeList = ProductCodeListItem[];
export interface LicenseConversionContext {
    UsageOperation?: string | undefined;
    ProductCodes?: ProductCodeListItem[] | undefined;
}
export interface CreateLicenseConversionTaskForResourceRequest {
    ResourceArn: string;
    SourceLicenseContext: LicenseConversionContext;
    DestinationLicenseContext: LicenseConversionContext;
}
export type LicenseConversionTaskId = string;
export interface CreateLicenseConversionTaskForResourceResponse {
    LicenseConversionTaskId?: string | undefined;
}
export type ReportGeneratorName = string;
export type ReportType = "LicenseConfigurationSummaryReport" | "LicenseConfigurationUsageReport" | "LicenseAssetGroupUsageReport" | (string & {});
export type ReportTypeList = ReportType[];
export type ArnList = string[];
export interface ReportContext {
    licenseConfigurationArns?: string[] | undefined;
    licenseAssetGroupArns?: string[] | undefined;
    reportStartDate?: Date | undefined;
    reportEndDate?: Date | undefined;
}
export type ReportFrequencyType = "DAY" | "WEEK" | "MONTH" | "ONE_TIME" | (string & {});
export interface ReportFrequency {
    value?: number | undefined;
    period?: ReportFrequencyType | undefined;
}
export type ClientRequestToken = string;
export interface CreateLicenseManagerReportGeneratorRequest {
    ReportGeneratorName: string;
    Type: ReportType[];
    ReportContext: ReportContext;
    ReportFrequency: ReportFrequency;
    ClientToken: string;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateLicenseManagerReportGeneratorResponse {
    LicenseManagerReportGeneratorArn?: string | undefined;
}
export interface CreateLicenseVersionRequest {
    LicenseArn: string;
    LicenseName: string;
    ProductName: string;
    Issuer: Issuer;
    HomeRegion: string;
    Validity: DatetimeRange;
    LicenseMetadata?: Metadata[] | undefined;
    Entitlements: Entitlement[];
    ConsumptionConfiguration: ConsumptionConfiguration;
    Status: LicenseStatus;
    ClientToken: string;
    SourceVersion?: string | undefined;
    ResetUsage?: boolean | undefined;
}
export interface CreateLicenseVersionResponse {
    LicenseArn?: string | undefined;
    Version?: string | undefined;
    Status?: LicenseStatus | undefined;
}
export type MaxSize3StringList = string[];
export interface CreateTokenRequest {
    LicenseArn: string;
    RoleArns?: string[] | undefined;
    ExpirationInDays?: number | undefined;
    TokenProperties?: string[] | undefined;
    ClientToken: string;
}
export type TokenType = "REFRESH_TOKEN" | (string & {});
export type TokenString = string;
export interface CreateTokenResponse {
    TokenId?: string | undefined;
    TokenType?: TokenType | undefined;
    Token?: string | redacted.Redacted<string> | undefined;
}
export interface DeleteGrantRequest {
    GrantArn: string;
    StatusReason?: string | undefined;
    Version: string;
}
export interface DeleteGrantResponse {
    GrantArn?: string | undefined;
    Status?: GrantStatus | undefined;
    Version?: string | undefined;
}
export interface DeleteLicenseRequest {
    LicenseArn: string;
    SourceVersion: string;
}
export type LicenseDeletionStatus = "PENDING_DELETE" | "DELETED" | (string & {});
export interface DeleteLicenseResponse {
    Status?: LicenseDeletionStatus | undefined;
    DeletionDate?: string | undefined;
}
export interface DeleteLicenseAssetGroupRequest {
    LicenseAssetGroupArn: string;
}
export type LicenseAssetGroupStatus = "ACTIVE" | "DISABLED" | "DELETED" | (string & {});
export interface DeleteLicenseAssetGroupResponse {
    Status: LicenseAssetGroupStatus;
}
export interface DeleteLicenseAssetRulesetRequest {
    LicenseAssetRulesetArn: string;
}
export interface DeleteLicenseAssetRulesetResponse {
}
export interface DeleteLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
}
export interface DeleteLicenseConfigurationResponse {
}
export interface DeleteLicenseManagerReportGeneratorRequest {
    LicenseManagerReportGeneratorArn: string;
}
export interface DeleteLicenseManagerReportGeneratorResponse {
}
export interface DeleteTokenRequest {
    TokenId: string;
}
export interface DeleteTokenResponse {
}
export interface ExtendLicenseConsumptionRequest {
    LicenseConsumptionToken: string;
    DryRun?: boolean | undefined;
}
export interface ExtendLicenseConsumptionResponse {
    LicenseConsumptionToken?: string | undefined;
    Expiration?: string | undefined;
}
export interface GetAccessTokenRequest {
    Token: string | redacted.Redacted<string>;
    TokenProperties?: string[] | undefined;
}
export interface GetAccessTokenResponse {
    AccessToken?: string | redacted.Redacted<string> | undefined;
}
export interface GetGrantRequest {
    GrantArn: string;
    Version?: string | undefined;
}
export interface Grant {
    GrantArn: string;
    GrantName: string;
    ParentArn: string;
    LicenseArn: string;
    GranteePrincipalArn: string;
    HomeRegion: string;
    GrantStatus: GrantStatus;
    StatusReason?: string | undefined;
    Version: string;
    GrantedOperations: AllowedOperation[];
    Options?: Options | undefined;
    GrantType?: GrantType | undefined;
}
export interface GetGrantResponse {
    Grant?: Grant | undefined;
}
export interface GetLicenseRequest {
    LicenseArn: string;
    Version?: string | undefined;
}
export interface IssuerDetails {
    Name?: string | undefined;
    SignKey?: string | undefined;
    KeyFingerprint?: string | undefined;
}
export interface License {
    LicenseArn?: string | undefined;
    LicenseName?: string | undefined;
    ProductName?: string | undefined;
    ProductSKU?: string | undefined;
    Issuer?: IssuerDetails | undefined;
    HomeRegion?: string | undefined;
    Status?: LicenseStatus | undefined;
    Validity?: DatetimeRange | undefined;
    Beneficiary?: string | undefined;
    Entitlements?: Entitlement[] | undefined;
    ConsumptionConfiguration?: ConsumptionConfiguration | undefined;
    LicenseMetadata?: Metadata[] | undefined;
    CreateTime?: string | undefined;
    Version?: string | undefined;
}
export interface GetLicenseResponse {
    License?: License | undefined;
}
export interface GetLicenseAssetGroupRequest {
    LicenseAssetGroupArn: string;
}
export interface LicenseAssetGroup {
    Name: string;
    Description?: string | undefined;
    LicenseAssetGroupConfigurations?: LicenseAssetGroupConfiguration[] | undefined;
    AssociatedLicenseAssetRulesetARNs: string[];
    Properties?: LicenseAssetGroupProperty[] | undefined;
    LicenseAssetGroupArn: string;
    Status: LicenseAssetGroupStatus;
    StatusMessage?: string | undefined;
    LatestUsageAnalysisTime?: Date | undefined;
    LatestResourceDiscoveryTime?: Date | undefined;
}
export interface GetLicenseAssetGroupResponse {
    LicenseAssetGroup: LicenseAssetGroup;
}
export interface GetLicenseAssetRulesetRequest {
    LicenseAssetRulesetArn: string;
}
export interface LicenseAssetRuleset {
    Name: string;
    Description?: string | undefined;
    Rules: LicenseAssetRule[];
    LicenseAssetRulesetArn: string;
}
export interface GetLicenseAssetRulesetResponse {
    LicenseAssetRuleset: LicenseAssetRuleset;
}
export interface GetLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
}
export type ResourceType = "EC2_INSTANCE" | "EC2_HOST" | "EC2_AMI" | "RDS" | "SYSTEMS_MANAGER_MANAGED_INSTANCE" | (string & {});
export interface ConsumedLicenseSummary {
    ResourceType?: ResourceType | undefined;
    ConsumedLicenses?: number | undefined;
}
export type ConsumedLicenseSummaryList = ConsumedLicenseSummary[];
export interface ManagedResourceSummary {
    ResourceType?: ResourceType | undefined;
    AssociationCount?: number | undefined;
}
export type ManagedResourceSummaryList = ManagedResourceSummary[];
export interface AutomatedDiscoveryInformation {
    LastRunTime?: Date | undefined;
}
export interface GetLicenseConfigurationResponse {
    LicenseConfigurationId?: string | undefined;
    LicenseConfigurationArn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    LicenseCountingType?: LicenseCountingType | undefined;
    LicenseRules?: string[] | undefined;
    LicenseCount?: number | undefined;
    LicenseCountHardLimit?: boolean | undefined;
    ConsumedLicenses?: number | undefined;
    Status?: string | undefined;
    OwnerAccountId?: string | undefined;
    ConsumedLicenseSummaryList?: ConsumedLicenseSummary[] | undefined;
    ManagedResourceSummaryList?: ManagedResourceSummary[] | undefined;
    Tags?: Tag[] | undefined;
    ProductInformationList?: ProductInformation[] | undefined;
    AutomatedDiscoveryInformation?: AutomatedDiscoveryInformation | undefined;
    DisassociateWhenNotFound?: boolean | undefined;
    LicenseExpiry?: number | undefined;
}
export interface GetLicenseConversionTaskRequest {
    LicenseConversionTaskId: string;
}
export type LicenseConversionTaskStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export interface GetLicenseConversionTaskResponse {
    LicenseConversionTaskId?: string | undefined;
    ResourceArn?: string | undefined;
    SourceLicenseContext?: LicenseConversionContext | undefined;
    DestinationLicenseContext?: LicenseConversionContext | undefined;
    StatusMessage?: string | undefined;
    Status?: LicenseConversionTaskStatus | undefined;
    StartTime?: Date | undefined;
    LicenseConversionTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export interface GetLicenseManagerReportGeneratorRequest {
    LicenseManagerReportGeneratorArn: string;
}
export interface S3Location {
    bucket?: string | undefined;
    keyPrefix?: string | undefined;
}
export interface ReportGenerator {
    ReportGeneratorName?: string | undefined;
    ReportType?: ReportType[] | undefined;
    ReportContext?: ReportContext | undefined;
    ReportFrequency?: ReportFrequency | undefined;
    LicenseManagerReportGeneratorArn?: string | undefined;
    LastRunStatus?: string | undefined;
    LastRunFailureReason?: string | undefined;
    LastReportGenerationTime?: string | undefined;
    ReportCreatorAccount?: string | undefined;
    Description?: string | undefined;
    S3Location?: S3Location | undefined;
    CreateTime?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetLicenseManagerReportGeneratorResponse {
    ReportGenerator?: ReportGenerator | undefined;
}
export interface GetLicenseUsageRequest {
    LicenseArn: string;
}
export interface EntitlementUsage {
    Name: string;
    ConsumedValue: string;
    MaxCount?: string | undefined;
    Unit: EntitlementDataUnit;
}
export type EntitlementUsageList = EntitlementUsage[];
export interface LicenseUsage {
    EntitlementUsages?: EntitlementUsage[] | undefined;
}
export interface GetLicenseUsageResponse {
    LicenseUsage?: LicenseUsage | undefined;
}
export interface GetServiceSettingsRequest {
}
export interface OrganizationConfiguration {
    EnableIntegration: boolean;
}
export interface CrossAccountDiscoveryServiceStatus {
    Message?: string | undefined;
}
export interface RegionStatus {
    Status?: string | undefined;
}
export type RegionStatusMap = {
    [key: string]: RegionStatus | undefined;
};
export interface CrossRegionDiscoveryStatus {
    Message?: {
        [key: string]: RegionStatus | undefined;
    } | undefined;
}
export interface ServiceStatus {
    CrossAccountDiscovery?: CrossAccountDiscoveryServiceStatus | undefined;
    CrossRegionDiscovery?: CrossRegionDiscoveryStatus | undefined;
}
export interface GetServiceSettingsResponse {
    S3BucketArn?: string | undefined;
    SnsTopicArn?: string | undefined;
    OrganizationConfiguration?: OrganizationConfiguration | undefined;
    EnableCrossAccountsDiscovery?: boolean | undefined;
    LicenseManagerResourceShareArn?: string | undefined;
    CrossRegionDiscoveryHomeRegion?: string | undefined;
    CrossRegionDiscoverySourceRegions?: string[] | undefined;
    ServiceStatus?: ServiceStatus | undefined;
}
export interface ListAssetsForLicenseAssetGroupRequest {
    LicenseAssetGroupArn: string;
    AssetType: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Asset {
    AssetArn?: string | undefined;
    LatestAssetDiscoveryTime?: Date | undefined;
}
export type AssetList = Asset[];
export interface ListAssetsForLicenseAssetGroupResponse {
    Assets?: Asset[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAssociationsForLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface LicenseConfigurationAssociation {
    ResourceArn?: string | undefined;
    ResourceType?: ResourceType | undefined;
    ResourceOwnerId?: string | undefined;
    AssociationTime?: Date | undefined;
    AmiAssociationScope?: string | undefined;
}
export type LicenseConfigurationAssociations = LicenseConfigurationAssociation[];
export interface ListAssociationsForLicenseConfigurationResponse {
    LicenseConfigurationAssociations?: LicenseConfigurationAssociation[] | undefined;
    NextToken?: string | undefined;
}
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type FilterList = Filter[];
export type MaxSize100 = number;
export interface ListDistributedGrantsRequest {
    GrantArns?: string[] | undefined;
    Filters?: Filter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type GrantList = Grant[];
export interface ListDistributedGrantsResponse {
    Grants?: Grant[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFailuresForLicenseConfigurationOperationsRequest {
    LicenseConfigurationArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface LicenseOperationFailure {
    ResourceArn?: string | undefined;
    ResourceType?: ResourceType | undefined;
    ErrorMessage?: string | undefined;
    FailureTime?: Date | undefined;
    OperationName?: string | undefined;
    ResourceOwnerId?: string | undefined;
    OperationRequestedBy?: string | undefined;
    MetadataList?: Metadata[] | undefined;
}
export type LicenseOperationFailureList = LicenseOperationFailure[];
export interface ListFailuresForLicenseConfigurationOperationsResponse {
    LicenseOperationFailureList?: LicenseOperationFailure[] | undefined;
    NextToken?: string | undefined;
}
export type Filters = Filter[];
export interface ListLicenseAssetGroupsRequest {
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type LicenseAssetGroupList = LicenseAssetGroup[];
export interface ListLicenseAssetGroupsResponse {
    LicenseAssetGroups?: LicenseAssetGroup[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLicenseAssetRulesetsRequest {
    Filters?: Filter[] | undefined;
    ShowAWSManagedLicenseAssetRulesets?: boolean | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type LicenseAssetRulesetList = LicenseAssetRuleset[];
export interface ListLicenseAssetRulesetsResponse {
    LicenseAssetRulesets?: LicenseAssetRuleset[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLicenseConfigurationsRequest {
    LicenseConfigurationArns?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface LicenseConfiguration {
    LicenseConfigurationId?: string | undefined;
    LicenseConfigurationArn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    LicenseCountingType?: LicenseCountingType | undefined;
    LicenseRules?: string[] | undefined;
    LicenseCount?: number | undefined;
    LicenseCountHardLimit?: boolean | undefined;
    DisassociateWhenNotFound?: boolean | undefined;
    ConsumedLicenses?: number | undefined;
    Status?: string | undefined;
    OwnerAccountId?: string | undefined;
    ConsumedLicenseSummaryList?: ConsumedLicenseSummary[] | undefined;
    ManagedResourceSummaryList?: ManagedResourceSummary[] | undefined;
    ProductInformationList?: ProductInformation[] | undefined;
    AutomatedDiscoveryInformation?: AutomatedDiscoveryInformation | undefined;
    LicenseExpiry?: number | undefined;
}
export type LicenseConfigurations = LicenseConfiguration[];
export interface ListLicenseConfigurationsResponse {
    LicenseConfigurations?: LicenseConfiguration[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLicenseConfigurationsForOrganizationRequest {
    LicenseConfigurationArns?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface ListLicenseConfigurationsForOrganizationResponse {
    LicenseConfigurations?: LicenseConfiguration[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLicenseConversionTasksRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface LicenseConversionTask {
    LicenseConversionTaskId?: string | undefined;
    ResourceArn?: string | undefined;
    SourceLicenseContext?: LicenseConversionContext | undefined;
    DestinationLicenseContext?: LicenseConversionContext | undefined;
    Status?: LicenseConversionTaskStatus | undefined;
    StatusMessage?: string | undefined;
    StartTime?: Date | undefined;
    LicenseConversionTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type LicenseConversionTasks = LicenseConversionTask[];
export interface ListLicenseConversionTasksResponse {
    LicenseConversionTasks?: LicenseConversionTask[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLicenseManagerReportGeneratorsRequest {
    Filters?: Filter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ReportGeneratorList = ReportGenerator[];
export interface ListLicenseManagerReportGeneratorsResponse {
    ReportGenerators?: ReportGenerator[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLicensesRequest {
    LicenseArns?: string[] | undefined;
    Filters?: Filter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type LicenseList = License[];
export interface ListLicensesResponse {
    Licenses?: License[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLicenseSpecificationsForResourceRequest {
    ResourceArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface LicenseSpecification {
    LicenseConfigurationArn: string;
    AmiAssociationScope?: string | undefined;
}
export type LicenseSpecifications = LicenseSpecification[];
export interface ListLicenseSpecificationsForResourceResponse {
    LicenseSpecifications?: LicenseSpecification[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLicenseVersionsRequest {
    LicenseArn: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListLicenseVersionsResponse {
    Licenses?: License[] | undefined;
    NextToken?: string | undefined;
}
export interface ListReceivedGrantsRequest {
    GrantArns?: string[] | undefined;
    Filters?: Filter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListReceivedGrantsResponse {
    Grants?: Grant[] | undefined;
    NextToken?: string | undefined;
}
export interface ListReceivedGrantsForOrganizationRequest {
    LicenseArn: string;
    Filters?: Filter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListReceivedGrantsForOrganizationResponse {
    Grants?: Grant[] | undefined;
    NextToken?: string | undefined;
}
export interface ListReceivedLicensesRequest {
    LicenseArns?: string[] | undefined;
    Filters?: Filter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ReceivedStatus = "PENDING_WORKFLOW" | "PENDING_ACCEPT" | "REJECTED" | "ACTIVE" | "FAILED_WORKFLOW" | "DELETED" | "DISABLED" | "WORKFLOW_COMPLETED" | (string & {});
export interface ReceivedMetadata {
    ReceivedStatus?: ReceivedStatus | undefined;
    ReceivedStatusReason?: string | undefined;
    AllowedOperations?: AllowedOperation[] | undefined;
    GrantType?: GrantType | undefined;
}
export interface GrantedLicense {
    LicenseArn?: string | undefined;
    LicenseName?: string | undefined;
    ProductName?: string | undefined;
    ProductSKU?: string | undefined;
    Issuer?: IssuerDetails | undefined;
    HomeRegion?: string | undefined;
    Status?: LicenseStatus | undefined;
    Validity?: DatetimeRange | undefined;
    Beneficiary?: string | undefined;
    Entitlements?: Entitlement[] | undefined;
    ConsumptionConfiguration?: ConsumptionConfiguration | undefined;
    LicenseMetadata?: Metadata[] | undefined;
    CreateTime?: string | undefined;
    Version?: string | undefined;
    ReceivedMetadata?: ReceivedMetadata | undefined;
}
export type GrantedLicenseList = GrantedLicense[];
export interface ListReceivedLicensesResponse {
    Licenses?: GrantedLicense[] | undefined;
    NextToken?: string | undefined;
}
export interface ListReceivedLicensesForOrganizationRequest {
    Filters?: Filter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListReceivedLicensesForOrganizationResponse {
    Licenses?: GrantedLicense[] | undefined;
    NextToken?: string | undefined;
}
export type InventoryFilterCondition = "EQUALS" | "NOT_EQUALS" | "BEGINS_WITH" | "CONTAINS" | (string & {});
export interface InventoryFilter {
    Name: string;
    Condition: InventoryFilterCondition;
    Value?: string | undefined;
}
export type InventoryFilterList = InventoryFilter[];
export interface ListResourceInventoryRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: InventoryFilter[] | undefined;
}
export interface ResourceInventory {
    ResourceId?: string | undefined;
    ResourceType?: ResourceType | undefined;
    ResourceArn?: string | undefined;
    Platform?: string | undefined;
    PlatformVersion?: string | undefined;
    ResourceOwningAccountId?: string | undefined;
    MarketplaceProductCodes?: string[] | undefined;
    UsageOperation?: string | undefined;
    AmiId?: string | undefined;
    HostId?: string | undefined;
    Region?: string | undefined;
    InstanceType?: string | undefined;
}
export type ResourceInventoryList = ResourceInventory[];
export interface ListResourceInventoryResponse {
    ResourceInventoryList?: ResourceInventory[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface ListTokensRequest {
    TokenIds?: string[] | undefined;
    Filters?: Filter[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TokenData {
    TokenId?: string | undefined;
    TokenType?: string | undefined;
    LicenseArn?: string | undefined;
    ExpirationTime?: string | undefined;
    TokenProperties?: string[] | undefined;
    RoleArns?: string[] | undefined;
    Status?: string | undefined;
}
export type TokenList = TokenData[];
export interface ListTokensResponse {
    Tokens?: TokenData[] | undefined;
    NextToken?: string | undefined;
}
export interface ListUsageForLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface LicenseConfigurationUsage {
    ResourceArn?: string | undefined;
    ResourceType?: ResourceType | undefined;
    ResourceStatus?: string | undefined;
    ResourceOwnerId?: string | undefined;
    AssociationTime?: Date | undefined;
    ConsumedLicenses?: number | undefined;
}
export type LicenseConfigurationUsageList = LicenseConfigurationUsage[];
export interface ListUsageForLicenseConfigurationResponse {
    LicenseConfigurationUsageList?: LicenseConfigurationUsage[] | undefined;
    NextToken?: string | undefined;
}
export interface RejectGrantRequest {
    GrantArn: string;
}
export interface RejectGrantResponse {
    GrantArn?: string | undefined;
    Status?: GrantStatus | undefined;
    Version?: string | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateLicenseAssetGroupRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    LicenseAssetGroupConfigurations?: LicenseAssetGroupConfiguration[] | undefined;
    AssociatedLicenseAssetRulesetARNs: string[];
    Properties?: LicenseAssetGroupProperty[] | undefined;
    LicenseAssetGroupArn: string;
    Status?: LicenseAssetGroupStatus | undefined;
    ClientToken: string;
}
export interface UpdateLicenseAssetGroupResponse {
    LicenseAssetGroupArn: string;
    Status: string;
}
export interface UpdateLicenseAssetRulesetRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    Rules: LicenseAssetRule[];
    LicenseAssetRulesetArn: string;
    ClientToken: string;
}
export interface UpdateLicenseAssetRulesetResponse {
    LicenseAssetRulesetArn: string;
}
export type LicenseConfigurationStatus = "AVAILABLE" | "DISABLED" | (string & {});
export interface UpdateLicenseConfigurationRequest {
    LicenseConfigurationArn: string;
    LicenseConfigurationStatus?: LicenseConfigurationStatus | undefined;
    LicenseRules?: string[] | undefined;
    LicenseCount?: number | undefined;
    LicenseCountHardLimit?: boolean | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    ProductInformationList?: ProductInformation[] | undefined;
    DisassociateWhenNotFound?: boolean | undefined;
    LicenseExpiry?: number | undefined;
}
export interface UpdateLicenseConfigurationResponse {
}
export interface UpdateLicenseManagerReportGeneratorRequest {
    LicenseManagerReportGeneratorArn: string;
    ReportGeneratorName: string;
    Type: ReportType[];
    ReportContext: ReportContext;
    ReportFrequency: ReportFrequency;
    ClientToken: string;
    Description?: string | undefined;
}
export interface UpdateLicenseManagerReportGeneratorResponse {
}
export interface UpdateLicenseSpecificationsForResourceRequest {
    ResourceArn: string;
    AddLicenseSpecifications?: LicenseSpecification[] | undefined;
    RemoveLicenseSpecifications?: LicenseSpecification[] | undefined;
}
export interface UpdateLicenseSpecificationsForResourceResponse {
}
export interface UpdateServiceSettingsRequest {
    S3BucketArn?: string | undefined;
    SnsTopicArn?: string | undefined;
    OrganizationConfiguration?: OrganizationConfiguration | undefined;
    EnableCrossAccountsDiscovery?: boolean | undefined;
    EnabledDiscoverySourceRegions?: string[] | undefined;
}
export interface UpdateServiceSettingsResponse {
}
export type Message = string;
export type Location = string;
export type AcceptGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Accepts the specified grant.
 */
export declare const acceptGrant: API.OperationMethod<AcceptGrantRequest & RegionInput, AcceptGrantResponse, AcceptGrantError, Credentials | HttpClient.HttpClient>;
export type CheckInLicenseError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | RateLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Checks in the specified license. Check in a license when it is no longer in use.
 */
export declare const checkInLicense: API.OperationMethod<CheckInLicenseRequest & RegionInput, CheckInLicenseResponse, CheckInLicenseError, Credentials | HttpClient.HttpClient>;
export type CheckoutBorrowLicenseError = AccessDeniedException | AuthorizationException | EntitlementNotAllowedException | InvalidParameterValueException | NoEntitlementsAllowedException | RateLimitExceededException | RedirectException | ResourceNotFoundException | ServerInternalException | UnsupportedDigitalSignatureMethodException | ValidationException | CommonErrors;
/**
 * Checks out the specified license for offline use.
 */
export declare const checkoutBorrowLicense: API.OperationMethod<CheckoutBorrowLicenseRequest & RegionInput, CheckoutBorrowLicenseResponse, CheckoutBorrowLicenseError, Credentials | HttpClient.HttpClient>;
export type CheckoutLicenseError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | NoEntitlementsAllowedException | RateLimitExceededException | RedirectException | ResourceNotFoundException | ServerInternalException | UnsupportedDigitalSignatureMethodException | ValidationException | CommonErrors;
/**
 * Checks out the specified license.
 *
 * If the account that created the license is the same that is performing the check out, you must
 * specify the account as the beneficiary.
 */
export declare const checkoutLicense: API.OperationMethod<CheckoutLicenseRequest & RegionInput, CheckoutLicenseResponse, CheckoutLicenseError, Credentials | HttpClient.HttpClient>;
export type CreateGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a grant for the specified license. A grant shares the use of license
 * entitlements with a specific Amazon Web Services account, an organization, or an
 * organizational unit (OU). For more information, see Granted licenses in License Manager in the *License Manager User Guide*.
 *
 * Set the type of grant with the `GrantType` field:
 *
 * - `BuyerGrant` - The default grant type, created by the seller when a
 * customer subscribes to a product. The seller creates a license for the subscription
 * and a buyer grant for the customer. With a buyer grant, the customer can use,
 * consume, and distribute the license, according to the permissions the seller sets in
 * the product contract.
 *
 * - `DelegateGrant` - A delegate grant gives the grantee read-only
 * visibility into the licenses and grants that you have distributed to buyers for a
 * product. The grantee can monitor that activity on your behalf, and can also listen
 * for the related Amazon EventBridge events. A delegate grant conveys no entitlement to
 * use the licenses, and its only allowed operation is `ListReceivedLicenses`.
 * You must create the delegate grant, and its license, from the same
 * Amazon Web Services account that you used to create those buyer licenses and grants.
 */
export declare const createGrant: API.OperationMethod<CreateGrantRequest & RegionInput, CreateGrantResponse, CreateGrantError, Credentials | HttpClient.HttpClient>;
export type CreateGrantVersionError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a new version of the specified grant. For more information, see
 * Granted licenses in License Manager in the *License Manager User Guide*.
 */
export declare const createGrantVersion: API.OperationMethod<CreateGrantVersionRequest & RegionInput, CreateGrantVersionResponse, CreateGrantVersionError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | RedirectException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a license.
 */
export declare const createLicense: API.OperationMethod<CreateLicenseRequest & RegionInput, CreateLicenseResponse, CreateLicenseError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a license asset group.
 */
export declare const createLicenseAssetGroup: API.OperationMethod<CreateLicenseAssetGroupRequest & RegionInput, CreateLicenseAssetGroupResponse, CreateLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseAssetRulesetError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a license asset ruleset.
 */
export declare const createLicenseAssetRuleset: API.OperationMethod<CreateLicenseAssetRulesetRequest & RegionInput, CreateLicenseAssetRulesetResponse, CreateLicenseAssetRulesetError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseConfigurationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Creates a license configuration.
 *
 * A license configuration is an abstraction of a customer license agreement that can be
 * consumed and enforced by License Manager. Components include specifications for the license
 * type (licensing by instance, socket, CPU, or vCPU), allowed tenancy (shared tenancy,
 * Dedicated Instance, Dedicated Host, or all of these), license affinity to host (how long a
 * license must be associated with a host), and the number of licenses purchased and used.
 */
export declare const createLicenseConfiguration: API.OperationMethod<CreateLicenseConfigurationRequest & RegionInput, CreateLicenseConfigurationResponse, CreateLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseConversionTaskForResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a new license conversion task.
 */
export declare const createLicenseConversionTaskForResource: API.OperationMethod<CreateLicenseConversionTaskForResourceRequest & RegionInput, CreateLicenseConversionTaskForResourceResponse, CreateLicenseConversionTaskForResourceError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseManagerReportGeneratorError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a report generator.
 */
export declare const createLicenseManagerReportGenerator: API.OperationMethod<CreateLicenseManagerReportGeneratorRequest & RegionInput, CreateLicenseManagerReportGeneratorResponse, CreateLicenseManagerReportGeneratorError, Credentials | HttpClient.HttpClient>;
export type CreateLicenseVersionError = AccessDeniedException | AuthorizationException | ConflictException | RateLimitExceededException | RedirectException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a new version of the specified license.
 */
export declare const createLicenseVersion: API.OperationMethod<CreateLicenseVersionRequest & RegionInput, CreateLicenseVersionResponse, CreateLicenseVersionError, Credentials | HttpClient.HttpClient>;
export type CreateTokenError = AccessDeniedException | AuthorizationException | RateLimitExceededException | RedirectException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Creates a long-lived token.
 *
 * A refresh token is a JWT token used to get an access token. With an access token,
 * you can call AssumeRoleWithWebIdentity to get role credentials that you can use to
 * call License Manager to manage the specified license.
 */
export declare const createToken: API.OperationMethod<CreateTokenRequest & RegionInput, CreateTokenResponse, CreateTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes the specified grant.
 */
export declare const deleteGrant: API.OperationMethod<DeleteGrantRequest & RegionInput, DeleteGrantResponse, DeleteGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | RateLimitExceededException | RedirectException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes the specified license.
 */
export declare const deleteLicense: API.OperationMethod<DeleteLicenseRequest & RegionInput, DeleteLicenseResponse, DeleteLicenseError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes a license asset group.
 */
export declare const deleteLicenseAssetGroup: API.OperationMethod<DeleteLicenseAssetGroupRequest & RegionInput, DeleteLicenseAssetGroupResponse, DeleteLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseAssetRulesetError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes a license asset ruleset.
 */
export declare const deleteLicenseAssetRuleset: API.OperationMethod<DeleteLicenseAssetRulesetRequest & RegionInput, DeleteLicenseAssetRulesetResponse, DeleteLicenseAssetRulesetError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseConfigurationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | LicenseConfigurationNotFound | CommonErrors;
/**
 * Deletes the specified license configuration.
 *
 * You cannot delete a license configuration that is in use.
 */
export declare const deleteLicenseConfiguration: API.OperationMethod<DeleteLicenseConfigurationRequest & RegionInput, DeleteLicenseConfigurationResponse, DeleteLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteLicenseManagerReportGeneratorError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes the specified report generator.
 *
 * This action deletes the report generator, which stops it from generating future reports.
 * The action cannot be reversed. It has no effect on the previous reports from this generator.
 */
export declare const deleteLicenseManagerReportGenerator: API.OperationMethod<DeleteLicenseManagerReportGeneratorRequest & RegionInput, DeleteLicenseManagerReportGeneratorResponse, DeleteLicenseManagerReportGeneratorError, Credentials | HttpClient.HttpClient>;
export type DeleteTokenError = AccessDeniedException | AuthorizationException | RateLimitExceededException | RedirectException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Deletes the specified token. Must be called in the license home Region.
 */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest & RegionInput, DeleteTokenResponse, DeleteTokenError, Credentials | HttpClient.HttpClient>;
export type ExtendLicenseConsumptionError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Extends the expiration date for license consumption.
 */
export declare const extendLicenseConsumption: API.OperationMethod<ExtendLicenseConsumptionRequest & RegionInput, ExtendLicenseConsumptionResponse, ExtendLicenseConsumptionError, Credentials | HttpClient.HttpClient>;
export type GetAccessTokenError = AccessDeniedException | AuthorizationException | RateLimitExceededException | ServerInternalException | ValidationException | InvalidParameterValueException | CommonErrors;
/**
 * Gets a temporary access token to use with AssumeRoleWithWebIdentity. Access tokens
 * are valid for one hour.
 */
export declare const getAccessToken: API.OperationMethod<GetAccessTokenRequest & RegionInput, GetAccessTokenResponse, GetAccessTokenError, Credentials | HttpClient.HttpClient>;
export type GetGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets detailed information about the specified grant.
 */
export declare const getGrant: API.OperationMethod<GetGrantRequest & RegionInput, GetGrantResponse, GetGrantError, Credentials | HttpClient.HttpClient>;
export type GetLicenseError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets detailed information about the specified license.
 */
export declare const getLicense: API.OperationMethod<GetLicenseRequest & RegionInput, GetLicenseResponse, GetLicenseError, Credentials | HttpClient.HttpClient>;
export type GetLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Gets a license asset group.
 */
export declare const getLicenseAssetGroup: API.OperationMethod<GetLicenseAssetGroupRequest & RegionInput, GetLicenseAssetGroupResponse, GetLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type GetLicenseAssetRulesetError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Gets a license asset ruleset.
 */
export declare const getLicenseAssetRuleset: API.OperationMethod<GetLicenseAssetRulesetRequest & RegionInput, GetLicenseAssetRulesetResponse, GetLicenseAssetRulesetError, Credentials | HttpClient.HttpClient>;
export type GetLicenseConfigurationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | LicenseConfigurationNotFound | CommonErrors;
/**
 * Gets detailed information about the specified license configuration.
 */
export declare const getLicenseConfiguration: API.OperationMethod<GetLicenseConfigurationRequest & RegionInput, GetLicenseConfigurationResponse, GetLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetLicenseConversionTaskError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Gets information about the specified license type conversion task.
 */
export declare const getLicenseConversionTask: API.OperationMethod<GetLicenseConversionTaskRequest & RegionInput, GetLicenseConversionTaskResponse, GetLicenseConversionTaskError, Credentials | HttpClient.HttpClient>;
export type GetLicenseManagerReportGeneratorError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Gets information about the specified report generator.
 */
export declare const getLicenseManagerReportGenerator: API.OperationMethod<GetLicenseManagerReportGeneratorRequest & RegionInput, GetLicenseManagerReportGeneratorResponse, GetLicenseManagerReportGeneratorError, Credentials | HttpClient.HttpClient>;
export type GetLicenseUsageError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Gets detailed information about the usage of the specified license.
 */
export declare const getLicenseUsage: API.OperationMethod<GetLicenseUsageRequest & RegionInput, GetLicenseUsageResponse, GetLicenseUsageError, Credentials | HttpClient.HttpClient>;
export type GetServiceSettingsError = AccessDeniedException | AuthorizationException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Gets the License Manager settings for the current Region.
 */
export declare const getServiceSettings: API.OperationMethod<GetServiceSettingsRequest & RegionInput, GetServiceSettingsResponse, GetServiceSettingsError, Credentials | HttpClient.HttpClient>;
export type ListAssetsForLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists assets for a license asset group.
 */
export declare const listAssetsForLicenseAssetGroup: API.OperationMethod<ListAssetsForLicenseAssetGroupRequest & RegionInput, ListAssetsForLicenseAssetGroupResponse, ListAssetsForLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type ListAssociationsForLicenseConfigurationError = AccessDeniedException | AuthorizationException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists the resource associations for the specified license configuration.
 *
 * Resource associations need not consume licenses from a license configuration.
 * For example, an AMI or a stopped instance might not consume a license (depending on
 * the license rules).
 */
export declare const listAssociationsForLicenseConfiguration: API.OperationMethod<ListAssociationsForLicenseConfigurationRequest & RegionInput, ListAssociationsForLicenseConfigurationResponse, ListAssociationsForLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListDistributedGrantsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the grants distributed for the specified license.
 */
export declare const listDistributedGrants: API.OperationMethod<ListDistributedGrantsRequest & RegionInput, ListDistributedGrantsResponse, ListDistributedGrantsError, Credentials | HttpClient.HttpClient>;
export type ListFailuresForLicenseConfigurationOperationsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists the license configuration operations that failed.
 */
export declare const listFailuresForLicenseConfigurationOperations: API.OperationMethod<ListFailuresForLicenseConfigurationOperationsRequest & RegionInput, ListFailuresForLicenseConfigurationOperationsResponse, ListFailuresForLicenseConfigurationOperationsError, Credentials | HttpClient.HttpClient>;
export type ListLicenseAssetGroupsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists license asset groups.
 */
export declare const listLicenseAssetGroups: API.OperationMethod<ListLicenseAssetGroupsRequest & RegionInput, ListLicenseAssetGroupsResponse, ListLicenseAssetGroupsError, Credentials | HttpClient.HttpClient>;
export type ListLicenseAssetRulesetsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists license asset rulesets.
 */
export declare const listLicenseAssetRulesets: API.OperationMethod<ListLicenseAssetRulesetsRequest & RegionInput, ListLicenseAssetRulesetsResponse, ListLicenseAssetRulesetsError, Credentials | HttpClient.HttpClient>;
export type ListLicenseConfigurationsError = AccessDeniedException | AuthorizationException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists the license configurations for your account.
 */
export declare const listLicenseConfigurations: API.OperationMethod<ListLicenseConfigurationsRequest & RegionInput, ListLicenseConfigurationsResponse, ListLicenseConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListLicenseConfigurationsForOrganizationError = AccessDeniedException | AuthorizationException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists license configurations for an organization.
 */
export declare const listLicenseConfigurationsForOrganization: API.OperationMethod<ListLicenseConfigurationsForOrganizationRequest & RegionInput, ListLicenseConfigurationsForOrganizationResponse, ListLicenseConfigurationsForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListLicenseConversionTasksError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists the license type conversion tasks for your account.
 */
export declare const listLicenseConversionTasks: API.OperationMethod<ListLicenseConversionTasksRequest & RegionInput, ListLicenseConversionTasksResponse, ListLicenseConversionTasksError, Credentials | HttpClient.HttpClient>;
export type ListLicenseManagerReportGeneratorsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the report generators for your account.
 */
export declare const listLicenseManagerReportGenerators: API.OperationMethod<ListLicenseManagerReportGeneratorsRequest & RegionInput, ListLicenseManagerReportGeneratorsResponse, ListLicenseManagerReportGeneratorsError, Credentials | HttpClient.HttpClient>;
export type ListLicensesError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the licenses for your account.
 */
export declare const listLicenses: API.OperationMethod<ListLicensesRequest & RegionInput, ListLicensesResponse, ListLicensesError, Credentials | HttpClient.HttpClient>;
export type ListLicenseSpecificationsForResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Describes the license configurations for the specified resource.
 */
export declare const listLicenseSpecificationsForResource: API.OperationMethod<ListLicenseSpecificationsForResourceRequest & RegionInput, ListLicenseSpecificationsForResourceResponse, ListLicenseSpecificationsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListLicenseVersionsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists all versions of the specified license.
 */
export declare const listLicenseVersions: API.OperationMethod<ListLicenseVersionsRequest & RegionInput, ListLicenseVersionsResponse, ListLicenseVersionsError, Credentials | HttpClient.HttpClient>;
export type ListReceivedGrantsError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists grants that are received. Received grants are grants created while specifying the
 * recipient as this Amazon Web Services account, your organization, or an organizational unit
 * (OU) to which this member account belongs.
 */
export declare const listReceivedGrants: API.OperationMethod<ListReceivedGrantsRequest & RegionInput, ListReceivedGrantsResponse, ListReceivedGrantsError, Credentials | HttpClient.HttpClient>;
export type ListReceivedGrantsForOrganizationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the grants received for all accounts in the organization.
 */
export declare const listReceivedGrantsForOrganization: API.OperationMethod<ListReceivedGrantsForOrganizationRequest & RegionInput, ListReceivedGrantsForOrganizationResponse, ListReceivedGrantsForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListReceivedLicensesError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists received licenses.
 */
export declare const listReceivedLicenses: API.OperationMethod<ListReceivedLicensesRequest & RegionInput, ListReceivedLicensesResponse, ListReceivedLicensesError, Credentials | HttpClient.HttpClient>;
export type ListReceivedLicensesForOrganizationError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the licenses received for all accounts in the organization.
 */
export declare const listReceivedLicensesForOrganization: API.OperationMethod<ListReceivedLicensesForOrganizationRequest & RegionInput, ListReceivedLicensesForOrganizationResponse, ListReceivedLicensesForOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListResourceInventoryError = AccessDeniedException | AuthorizationException | FailedDependencyException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists resources managed using Systems Manager inventory.
 */
export declare const listResourceInventory: API.OperationMethod<ListResourceInventoryRequest & RegionInput, ListResourceInventoryResponse, ListResourceInventoryError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists the tags for the specified resource. For more information about tagging support in
 * License Manager, see the TagResource operation.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTokensError = AccessDeniedException | AuthorizationException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Lists your tokens.
 */
export declare const listTokens: API.OperationMethod<ListTokensRequest & RegionInput, ListTokensResponse, ListTokensError, Credentials | HttpClient.HttpClient>;
export type ListUsageForLicenseConfigurationError = AccessDeniedException | AuthorizationException | FilterLimitExceededException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Lists all license usage records for a license configuration, displaying license
 * consumption details by resource at a selected point in time. Use this action to audit the
 * current license consumption for any license inventory and configuration.
 */
export declare const listUsageForLicenseConfiguration: API.OperationMethod<ListUsageForLicenseConfigurationRequest & RegionInput, ListUsageForLicenseConfigurationResponse, ListUsageForLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type RejectGrantError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Rejects the specified grant.
 */
export declare const rejectGrant: API.OperationMethod<RejectGrantRequest & RegionInput, RejectGrantResponse, RejectGrantError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Adds the specified tags to the specified resource. The following resources support
 * tagging in License Manager:
 *
 * - Licenses
 *
 * - Grants
 *
 * - License configurations
 *
 * - Report generators
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseAssetGroupError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Updates a license asset group.
 */
export declare const updateLicenseAssetGroup: API.OperationMethod<UpdateLicenseAssetGroupRequest & RegionInput, UpdateLicenseAssetGroupResponse, UpdateLicenseAssetGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseAssetRulesetError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Updates a license asset ruleset.
 */
export declare const updateLicenseAssetRuleset: API.OperationMethod<UpdateLicenseAssetRulesetRequest & RegionInput, UpdateLicenseAssetRulesetResponse, UpdateLicenseAssetRulesetError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseConfigurationError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ServerInternalException | LicenseConfigurationNotFound | CommonErrors;
/**
 * Modifies the attributes of an existing license configuration.
 */
export declare const updateLicenseConfiguration: API.OperationMethod<UpdateLicenseConfigurationRequest & RegionInput, UpdateLicenseConfigurationResponse, UpdateLicenseConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseManagerReportGeneratorError = AccessDeniedException | AuthorizationException | InvalidParameterValueException | RateLimitExceededException | ResourceLimitExceededException | ResourceNotFoundException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Updates a report generator.
 *
 * After you make changes to a report generator, it starts generating new reports within 60 minutes of being updated.
 */
export declare const updateLicenseManagerReportGenerator: API.OperationMethod<UpdateLicenseManagerReportGeneratorRequest & RegionInput, UpdateLicenseManagerReportGeneratorResponse, UpdateLicenseManagerReportGeneratorError, Credentials | HttpClient.HttpClient>;
export type UpdateLicenseSpecificationsForResourceError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | InvalidResourceStateException | LicenseUsageException | RateLimitExceededException | ServerInternalException | CommonErrors;
/**
 * Adds or removes the specified license configurations for the specified Amazon Web Services resource.
 *
 * You can update the license specifications of AMIs, instances, and hosts.
 * You cannot update the license specifications for launch templates and CloudFormation templates,
 * as they send license configurations to the operation that creates the resource.
 */
export declare const updateLicenseSpecificationsForResource: API.OperationMethod<UpdateLicenseSpecificationsForResourceRequest & RegionInput, UpdateLicenseSpecificationsForResourceResponse, UpdateLicenseSpecificationsForResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceSettingsError = AccessDeniedException | AuthorizationException | ConflictException | InvalidParameterValueException | RateLimitExceededException | ServerInternalException | ValidationException | CommonErrors;
/**
 * Updates License Manager settings for the current Region.
 */
export declare const updateServiceSettings: API.OperationMethod<UpdateServiceSettingsRequest & RegionInput, UpdateServiceSettingsResponse, UpdateServiceSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=license-manager.d.ts.map