import type { APIError } from "better-auth";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
/**
 * Structural `APIError` detection. Deliberately not `instanceof` — the
 * error may originate from a different module instance (bundled better-auth
 * vs peer) or realm.
 */
export declare const isAPIErrorLike: (error: unknown) => error is APIError;
/**
 * Merge an `APIError`'s visible `headers` with the hidden response headers
 * better-call carries on {@link kAPIErrorHeaders}. `set-cookie` values are
 * appended (never collapsed) so session cookies written before the failure
 * survive.
 */
export declare const mergeAPIErrorHeaders: (error: APIError) => Headers;
declare const BetterAuthApiError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "BetterAuthApiError";
} & Readonly<A>;
/**
 * Typed failure of an effectified `auth.api.*` call.
 *
 * Better Auth throws `APIError` from `better-call`; this error carries the
 * same information as first-class fields:
 *
 * - `status` — the better-call status KEY, e.g. `"UNAUTHORIZED"` (a string)
 * - `statusCode` — the numeric HTTP status, e.g. `401`
 * - `body` — the JSON error body (`message`, `code`, ...)
 * - `headers` — merged response headers, INCLUDING the `set-cookie`
 *   headers better-call hides on a symbol property of the thrown error
 *
 * Match on `statusCode` (or `body.code`) — `status` is a string key, not a
 * number.
 */
export declare class BetterAuthApiError extends BetterAuthApiError_base<{
    readonly status: string;
    readonly statusCode: number;
    readonly body: ({
        message?: string;
        code?: string;
    } & Record<string, unknown>) | undefined;
    readonly headers: Headers;
    readonly cause: APIError;
}> {
    static fromAPIError(error: APIError): BetterAuthApiError;
    get message(): string;
    /**
     * Render the error as an HTTP response (status + JSON body + merged
     * headers) — for handlers that want to pass the failure through to the
     * client exactly as Better Auth would have.
     */
    toResponse(): HttpServerResponse.HttpServerResponse;
}
declare const BetterAuthMigrationError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "BetterAuthMigrationError";
} & Readonly<A>;
/** Failure of the deploy-time schema migration. */
export declare class BetterAuthMigrationError extends BetterAuthMigrationError_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
declare const BetterAuthStorageError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "BetterAuthStorageError";
} & Readonly<A>;
/** Failure of a `secondaryStorage` operation. */
export declare class BetterAuthStorageError extends BetterAuthStorageError_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
export {};
//# sourceMappingURL=Errors.d.ts.map