import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface CreateOidcCustomPropertyInclusionForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The name of the custom property to include in the OIDC token */
    custom_property_name: string;
}
/** Whether the inclusion was defined at the organization or enterprise level */
export type OidcCustomPropertyInclusionInclusionSource = "organization" | "enterprise";
/** An OIDC custom property inclusion for repository properties */
export interface OidcCustomPropertyInclusion {
    /** The name of the custom property that is included in the OIDC token */
    custom_property_name: string;
    /** Whether the inclusion was defined at the organization or enterprise level */
    inclusion_source: OidcCustomPropertyInclusionInclusionSource;
}
export interface CreateOidcCustomPropertyInclusionForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the custom property to include in the OIDC token */
    custom_property_name: string;
}
export interface DeleteOidcCustomPropertyInclusionForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The name of the custom property to remove from OIDC token inclusion */
    custom_property_name: string;
}
export interface DeleteOidcCustomPropertyInclusionForEnterpriseResponse {
}
export interface DeleteOidcCustomPropertyInclusionForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the custom property to remove from OIDC token inclusion */
    custom_property_name: string;
}
export interface DeleteOidcCustomPropertyInclusionForOrgResponse {
}
export interface GetOidcCustomSubTemplateForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** Array of unique strings. Each claim key can only contain alphanumeric characters and underscores. */
export type OidcCustomSubIncludeClaimKeysList = Array<string>;
/** Actions OIDC Subject customization */
export interface OidcCustomSub {
    /** Array of unique strings. Each claim key can only contain alphanumeric characters and underscores. */
    include_claim_keys: OidcCustomSubIncludeClaimKeysList;
    /** Whether to opt in to the immutable OIDC subject claim format for the organization. When `true`, new OIDC tokens will use a stable, repository-ID-based `sub` claim instead of the name-based format. */
    use_immutable_subject?: boolean | undefined;
}
export interface ListOidcCustomPropertyInclusionsForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
}
export type ListOidcCustomPropertyInclusionsForEnterpriseResponseBodyList = Array<OidcCustomPropertyInclusion>;
export type ListOidcCustomPropertyInclusionsForEnterpriseResponse = ListOidcCustomPropertyInclusionsForEnterpriseResponseBodyList;
export interface ListOidcCustomPropertyInclusionsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type ListOidcCustomPropertyInclusionsForOrgResponseBodyList = Array<OidcCustomPropertyInclusion>;
export type ListOidcCustomPropertyInclusionsForOrgResponse = ListOidcCustomPropertyInclusionsForOrgResponseBodyList;
/** Array of unique strings. Each claim key can only contain alphanumeric characters and underscores. */
export type UpdateOidcCustomSubTemplateForOrgRequestIncludeClaimKeysList = Array<string>;
export interface UpdateOidcCustomSubTemplateForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Array of unique strings. Each claim key can only contain alphanumeric characters and underscores. */
    include_claim_keys?: UpdateOidcCustomSubTemplateForOrgRequestIncludeClaimKeysList | undefined;
    /** Whether to opt in to the immutable OIDC subject claim format for the organization. When `true`, new OIDC tokens will use a stable, repository-ID-based `sub` claim instead of the name-based format. */
    use_immutable_subject?: boolean | undefined;
}
export type UpdateOidcCustomSubTemplateForOrgResponse = unknown;
export type CreateOidcCustomPropertyInclusionForEnterpriseError = GithubOpError;
/** Create an OIDC custom property inclusion for an enterprise Adds a repository custom property to be included in the OIDC token for repository actions in an enterprise. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const createOidcCustomPropertyInclusionForEnterprise: API.OperationMethod<CreateOidcCustomPropertyInclusionForEnterpriseRequest, OidcCustomPropertyInclusion, CreateOidcCustomPropertyInclusionForEnterpriseError, GithubOpContext>;
export type CreateOidcCustomPropertyInclusionForOrgError = GithubOpError;
/** Create an OIDC custom property inclusion for an organization Adds a repository custom property to be included in the OIDC token for repository actions in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const createOidcCustomPropertyInclusionForOrg: API.OperationMethod<CreateOidcCustomPropertyInclusionForOrgRequest, OidcCustomPropertyInclusion, CreateOidcCustomPropertyInclusionForOrgError, GithubOpContext>;
export type DeleteOidcCustomPropertyInclusionForEnterpriseError = GithubOpError;
/** Delete an OIDC custom property inclusion for an enterprise Removes a repository custom property from being included in the OIDC token for repository actions in an enterprise. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const deleteOidcCustomPropertyInclusionForEnterprise: API.OperationMethod<DeleteOidcCustomPropertyInclusionForEnterpriseRequest, DeleteOidcCustomPropertyInclusionForEnterpriseResponse, DeleteOidcCustomPropertyInclusionForEnterpriseError, GithubOpContext>;
export type DeleteOidcCustomPropertyInclusionForOrgError = GithubOpError;
/** Delete an OIDC custom property inclusion for an organization Removes a repository custom property from being included in the OIDC token for repository actions in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteOidcCustomPropertyInclusionForOrg: API.OperationMethod<DeleteOidcCustomPropertyInclusionForOrgRequest, DeleteOidcCustomPropertyInclusionForOrgResponse, DeleteOidcCustomPropertyInclusionForOrgError, GithubOpContext>;
export type GetOidcCustomSubTemplateForOrgError = GithubOpError;
/** Get the customization template for an OIDC subject claim for an organization Gets the customization template for an OpenID Connect (OIDC) subject claim. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const getOidcCustomSubTemplateForOrg: API.OperationMethod<GetOidcCustomSubTemplateForOrgRequest, OidcCustomSub, GetOidcCustomSubTemplateForOrgError, GithubOpContext>;
export type ListOidcCustomPropertyInclusionsForEnterpriseError = GithubOpError;
/** List OIDC custom property inclusions for an enterprise Lists the repository custom properties that are included in the OIDC token for repository actions in an enterprise. OAuth app tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const listOidcCustomPropertyInclusionsForEnterprise: API.OperationMethod<ListOidcCustomPropertyInclusionsForEnterpriseRequest, ListOidcCustomPropertyInclusionsForEnterpriseResponse, ListOidcCustomPropertyInclusionsForEnterpriseError, GithubOpContext>;
export type ListOidcCustomPropertyInclusionsForOrgError = GithubOpError;
/** List OIDC custom property inclusions for an organization Lists the repository custom properties that are included in the OIDC token for repository actions in an organization. OAuth app tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const listOidcCustomPropertyInclusionsForOrg: API.OperationMethod<ListOidcCustomPropertyInclusionsForOrgRequest, ListOidcCustomPropertyInclusionsForOrgResponse, ListOidcCustomPropertyInclusionsForOrgError, GithubOpContext>;
export type UpdateOidcCustomSubTemplateForOrgError = GithubOpError;
/** Set the customization template for an OIDC subject claim for an organization Creates or updates the customization template for an OpenID Connect (OIDC) subject claim. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const updateOidcCustomSubTemplateForOrg: API.OperationMethod<UpdateOidcCustomSubTemplateForOrgRequest, UpdateOidcCustomSubTemplateForOrgResponse, UpdateOidcCustomSubTemplateForOrgError, GithubOpContext>;
//# sourceMappingURL=oidc.d.ts.map