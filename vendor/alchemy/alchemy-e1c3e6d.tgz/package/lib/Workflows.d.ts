import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Layer from "effect/Layer";
import type * as Schema from "effect/Schema";
import { type DurableDeferred, type Workflow, WorkflowEngine } from "effect/workflow";
import type { RuntimeContext } from "./RuntimeContext.ts";
declare const ImplementedTypeId: unique symbol;
declare const StorageName_base: Context.ServiceClass<StorageName, "alchemy/Workflows/StorageName", string>;
/**
 * Annotates a workflow with the name an engine stores its runs under, when
 * that differs from the workflow's own name. An engine that names storage
 * after the workflow, like Cloudflare's Durable Object engine with one class
 * per workflow, uses it as given.
 */
export declare class StorageName extends StorageName_base {
}
/**
 * Marks a workflow as runnable here: something in the context implements it.
 * `Workflows.layer` provides it for the workflow it implements, and a remote
 * engine, like `AWS.Lambda.DurableFunctionEngine`, for the workflows its
 * hosts run. `Workflows.RunWorkflow` requires it, so running a workflow
 * nothing implements is a type error.
 */
export interface Implemented<Name extends string> {
    readonly [ImplementedTypeId]: Name;
}
/** @internal */
export declare const Implemented: <Name extends string>(name: Name) => Context.Service<Implemented<Name>, true>;
/** @internal */
export declare const implemented: <Name extends string>(names: ReadonlyArray<Name>) => Layer.Layer<Implemented<Name>>;
type Requirements<L> = L extends Layer.Layer<any, any, infer R> ? R : never;
/** A workflow's handler: runs it for a payload, inside a run. */
export type Execute<Payload extends Workflow.AnyStructSchema, Success extends Schema.Top, Error extends Schema.Top, R> = (payload: Payload["Type"], executionId: string) => Effect.Effect<Success["Type"], Error["Type"], R>;
/**
 * Implement a workflow. Like `workflow.toLayer(execute)`, it registers the
 * handler with the engine, and it marks the workflow as implemented, so
 * `RunWorkflow` can run it.
 *
 * Pass the handler, or an Effect that builds it. The Effect runs once, when
 * the Layer is built, so resolve bindings and services there and use them in
 * the handler it returns.
 *
 * Handlers can call runtime-only APIs, like a bucket's `put` or another
 * Durable Object's methods. A runtime-only API requires `RuntimeContext`,
 * which a Worker's or Lambda function's init doesn't have. A handler only
 * runs inside a run, and every run has one, so this Layer doesn't ask for it.
 *
 * ### Implementing a workflow
 * **Example:** A handler
 * ```typescript
 * import * as Workflows from "alchemy/Workflows";
 * import * as Effect from "effect/Effect";
 * import { Activity } from "effect/workflow";
 *
 * export const GreetLive = Workflows.layer(
 *   Greet,
 *   Effect.fn(function* ({ name }) {
 *     return yield* Activity.make({
 *       name: "greet",
 *       success: Schema.String,
 *       execute: Effect.succeed(`hello ${name}`),
 *     });
 *   }),
 * );
 * ```
 *
 * **Example:** A handler that uses a binding
 * ```typescript
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 * import * as Workflows from "alchemy/Workflows";
 * import * as Effect from "effect/Effect";
 * import { Activity } from "effect/workflow";
 * import { Receipts } from "./Receipts.ts";
 *
 * export const CheckoutLive = Workflows.layer(
 *   Checkout,
 *   Effect.gen(function* () {
 *     const receipts = yield* Cloudflare.R2.WriteBucket(Receipts);
 *     return Effect.fn(function* ({ orderId }) {
 *       yield* Activity.make({
 *         name: "receipt",
 *         execute: receipts.put(`${orderId}.json`, JSON.stringify({ orderId })).pipe(Effect.orDie),
 *       });
 *     });
 *   }),
 * );
 * ```
 *
 * @primitive
 */
export declare function layer<Name extends string, Payload extends Workflow.AnyStructSchema, Success extends Schema.Top, Error extends Schema.Top, R>(workflow: Workflow.Workflow<Name, Payload, Success, Error>, execute: Execute<Payload, Success, Error, R>): Layer.Layer<Implemented<Name>, never, Exclude<Requirements<ReturnType<typeof workflow.toLayer<R>>>, RuntimeContext>>;
export declare function layer<Name extends string, Payload extends Workflow.AnyStructSchema, Success extends Schema.Top, Error extends Schema.Top, R, InitE, InitR>(workflow: Workflow.Workflow<Name, Payload, Success, Error>, make: Effect.Effect<Execute<Payload, Success, Error, R>, InitE, InitR>): Layer.Layer<Implemented<Name>, InitE, InitR | Exclude<Requirements<ReturnType<typeof workflow.toLayer<R>>>, RuntimeContext>>;
type NameOf<W> = W extends Workflow.Workflow<infer Name, any, any, any> ? Name : never;
type SuccessOf<W> = W extends Workflow.Workflow<any, any, infer S, any> ? S["Type"] : never;
type ErrorOf<W> = W extends Workflow.Workflow<any, any, any, infer E> ? E["Type"] : never;
type PayloadOf<W> = W extends Workflow.Workflow<any, infer P, any, any> ? P["~type.make.in"] : never;
/** Where a run is. */
export type Status<A, E> = {
    readonly _tag: "NotStarted";
} | {
    readonly _tag: "Running";
} | {
    readonly _tag: "Completed";
    readonly result: A;
} | {
    readonly _tag: "Failed";
    readonly error: E;
} | {
    readonly _tag: "Interrupted";
} | {
    readonly _tag: "Died";
    readonly defect: unknown;
};
/**
 * How a finished run ended, from its stored exit.
 *
 * @internal
 */
export declare const statusOf: <A, E>(exit: Exit.Exit<A, E>) => Ended<A, E>;
/** Where a finished run ended. */
export type Ended<A, E> = Exclude<Status<A, E>, {
    readonly _tag: "NotStarted" | "Running";
}>;
/** A run whose result the engine stored, as {@link OnResult} receives it. */
export interface StoredResult {
    /** The workflow's name. */
    readonly workflow: string;
    /** The run's id. */
    readonly executionId: string;
    /** How the run ended. */
    readonly status: Ended<unknown, unknown>;
}
declare const OnResult_base: Context.ServiceClass<OnResult, "alchemy/Workflows/OnResult", (stored: StoredResult) => Effect.Effect<void, never, RuntimeContext>>;
/**
 * Called each time the workflow engine stores a run's result: when the run
 * completes, fails, is interrupted, or dies. A run that suspends or is retried
 * stores nothing and calls nothing.
 *
 * It is delivered at least once and only after the result is stored. The
 * engine schedules the call in the same write as the result and retries it
 * until it succeeds, so a hook that dies runs again and must be idempotent.
 * Key what it writes by the workflow and execution id.
 *
 * Provide it where the engine Layer is built. The Durable Object engines
 * call it: `Cloudflare.Workflows.layerDurableObjectEngine`, Rivet's engine,
 * and `@alchemy.run/domain` sagas on Cloudflare and Rivet. It runs inside the
 * execution's Durable Object, so resolve bindings while the Layer builds.
 *
 * ### Reacting to stored results
 * **Example:** Report every run that died
 * ```typescript
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 * import * as Workflows from "alchemy/Workflows";
 * import * as Effect from "effect/Effect";
 * import * as Layer from "effect/Layer";
 * import { Incidents } from "./Incidents.ts";
 * import { SendWelcomeLive } from "./SendWelcome.ts";
 *
 * const ReportDeaths = Layer.effect(
 *   Workflows.OnResult,
 *   Effect.gen(function* () {
 *     const incidents = yield* Cloudflare.Queues.WriteQueue(Incidents);
 *     return Effect.fn(function* ({ workflow, executionId, status }) {
 *       if (status._tag !== "Died") return;
 *       yield* incidents
 *         .send({ id: `${workflow}/${executionId}`, defect: String(status.defect) })
 *         .pipe(Effect.orDie);
 *     });
 *   }),
 * ).pipe(Layer.provide(Cloudflare.Queues.WriteQueueBinding));
 *
 * const WorkflowsLive = SendWelcomeLive.pipe(
 *   Layer.provideMerge(Cloudflare.Workflows.layerDurableObjectEngine()),
 *   Layer.provide(ReportDeaths),
 * );
 * ```
 *
 * @primitive
 */
export declare class OnResult extends OnResult_base {
}
/** One run of a workflow. */
export interface Run<A, E> {
    /** The run's id. Store it to read the run again later, with `get`. */
    readonly executionId: string;
    /** Where the run is now. */
    readonly status: Effect.Effect<Status<A, E>>;
    /**
     * Wait for the run to finish: its result, or its failure. A run can take
     * days, so wait in tests and scripts, not in a request.
     */
    readonly result: Effect.Effect<A, E>;
    /** Complete a `DurableDeferred` the run waits on. */
    readonly signal: <Success extends Schema.Constraint>(deferred: DurableDeferred.DurableDeferred<Success, any>, value: Success["Type"]) => Effect.Effect<void>;
    /** Stop the run: it fails where it waits, and its compensations run. */
    readonly interrupt: Effect.Effect<void>;
}
/** Starts and reads runs of one workflow. */
export interface WorkflowClient<W> {
    /** Start a run, or return the run already started with the same key. Returns at once. */
    readonly start: (payload: PayloadOf<W>) => Effect.Effect<Run<SuccessOf<W>, ErrorOf<W>>>;
    /** A run started earlier, by its id. */
    readonly get: (executionId: string) => Run<SuccessOf<W>, ErrorOf<W>>;
}
/**
 * Start and read runs of a workflow, on whichever engine the runtime
 * provides. Resolve it once, during init; its methods need nothing else.
 *
 * It needs the workflow implemented: by `Workflows.layer` in the same
 * runtime, or by a host a remote engine routes to. Running a workflow nothing
 * implements is a type error.
 *
 * ### Running a workflow
 * **Example:** Start a run from a request
 * ```typescript
 * import * as Workflows from "alchemy/Workflows";
 * import * as Effect from "effect/Effect";
 * import * as HttpServerResponse from "effect/http/HttpServerResponse";
 *
 * const app = Effect.gen(function* () {
 *   const greet = yield* Workflows.RunWorkflow(Greet);
 *   return {
 *     fetch: Effect.gen(function* () {
 *       const run = yield* greet.start({ name: "sam" });
 *       return HttpServerResponse.text(run.executionId);
 *     }),
 *   };
 * });
 * ```
 *
 * **Example:** Read a run later
 * ```typescript
 * const run = greet.get(executionId);
 * const status = yield* run.status;
 * yield* run.signal(Approval, "agent-7");
 * ```
 *
 * @primitive
 */
export declare const RunWorkflow: <W extends Workflow.Any>(workflow: W) => Effect.Effect<WorkflowClient<W>, never, WorkflowEngine.WorkflowEngine | Implemented<NameOf<W>>>;
/**
 * A handle to one run of a workflow on an engine.
 *
 * @internal
 */
export declare const makeRun: <A = unknown, E = unknown>(engine: WorkflowEngine.WorkflowEngine["Service"], workflow: Workflow.Workflow<string, any, any, any>, executionId: string) => Run<A, E>;
export {};
//# sourceMappingURL=Workflows.d.ts.map