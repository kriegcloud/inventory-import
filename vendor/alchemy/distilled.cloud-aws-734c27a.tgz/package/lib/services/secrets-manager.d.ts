import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const DecryptionFailure_base: S.TaggedErrorClass<"DecryptionFailure", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DecryptionFailure extends /*@__PURE__*/ DecryptionFailure_base {
}
declare const EncryptionFailure_base: S.TaggedErrorClass<"EncryptionFailure", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class EncryptionFailure extends /*@__PURE__*/ EncryptionFailure_base {
}
declare const InternalServiceError_base: S.TaggedErrorClass<"InternalServiceError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceError extends /*@__PURE__*/ InternalServiceError_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MalformedPolicyDocumentException_base: S.TaggedErrorClass<"MalformedPolicyDocumentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedPolicyDocumentException extends /*@__PURE__*/ MalformedPolicyDocumentException_base {
}
declare const PreconditionNotMetException_base: S.TaggedErrorClass<"PreconditionNotMetException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class PreconditionNotMetException extends /*@__PURE__*/ PreconditionNotMetException_base {
}
declare const PublicPolicyException_base: S.TaggedErrorClass<"PublicPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PublicPolicyException extends /*@__PURE__*/ PublicPolicyException_base {
}
declare const ResourceExistsException_base: S.TaggedErrorClass<"ResourceExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceExistsException extends /*@__PURE__*/ ResourceExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type SecretIdType = string;
export type SecretARNType = string;
export type ReplicaRestrictionType = "SameOrg" | "NoRestriction" | (string & {});
export type RoleARNType = string;
export interface AssociateCrossAccountReplicaRequest {
    SecretId: string;
    CrossAccountReplicaARN: string;
    ReplicaRestriction?: ReplicaRestrictionType | undefined;
    ReplicationRoleARN?: string | undefined;
}
export type StatusType = "InSync" | "Failed" | "InProgress" | "Pending" | "Detached" | (string & {});
export interface AssociateCrossAccountReplicaResponse {
    ARN?: string | undefined;
    CrossAccountReplicaARN?: string | undefined;
    ReplicationStatus?: StatusType | undefined;
}
export type SecretIdListType = string[];
export type FilterNameStringType = "description" | "name" | "tag-key" | "tag-value" | "primary-region" | "owning-service" | "all" | (string & {});
export type FilterValueStringType = string;
export type FilterValuesStringList = string[];
export interface Filter {
    Key?: FilterNameStringType | undefined;
    Values?: string[] | undefined;
}
export type FiltersListType = Filter[];
export type MaxResultsBatchType = number;
export type NextTokenType = string;
export interface BatchGetSecretValueRequest {
    SecretIdList?: string[] | undefined;
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SecretNameType = string;
export type SecretVersionIdType = string;
export type SecretBinaryType = Uint8Array | redacted.Redacted<Uint8Array>;
export type SecretStringType = string | redacted.Redacted<string>;
export type SecretVersionStageType = string;
export type SecretVersionStagesType = string[];
export type CreatedDateType = Date;
export interface SecretValueEntry {
    ARN?: string | undefined;
    Name?: string | undefined;
    VersionId?: string | undefined;
    SecretBinary?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    SecretString?: string | redacted.Redacted<string> | undefined;
    VersionStages?: string[] | undefined;
    CreatedDate?: Date | undefined;
}
export type SecretValuesType = SecretValueEntry[];
export type ErrorCode = string;
export type ErrorMessage = string;
export interface APIErrorType {
    SecretId?: string | undefined;
    ErrorCode?: string | undefined;
    Message?: string | undefined;
}
export type APIErrorListType = APIErrorType[];
export interface BatchGetSecretValueResponse {
    SecretValues?: SecretValueEntry[] | undefined;
    NextToken?: string | undefined;
    Errors?: APIErrorType[] | undefined;
}
export interface CancelRotateSecretRequest {
    SecretId: string;
}
export interface CancelRotateSecretResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    VersionId?: string | undefined;
}
export type NameType = string;
export type ClientRequestTokenType = string;
export type DescriptionType = string;
export type KmsKeyIdType = string;
export type TagKeyType = string;
export type TagValueType = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagListType = Tag[];
export type RegionType = string;
export interface ReplicaRegionType {
    Region?: string | undefined;
    KmsKeyId?: string | undefined;
}
export type AddReplicaRegionListType = ReplicaRegionType[];
export type MedeaTypeType = string;
export interface CreateSecretRequest {
    Name: string;
    ClientRequestToken?: string | undefined;
    Description?: string | undefined;
    KmsKeyId?: string | undefined;
    SecretBinary?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    SecretString?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
    AddReplicaRegions?: ReplicaRegionType[] | undefined;
    ForceOverwriteReplicaSecret?: boolean | undefined;
    Type?: string | undefined;
    CrossAccountPrimaryARN?: string | undefined;
}
export type StatusMessageType = string;
export type LastAccessedDateType = Date;
export interface ReplicationStatusType {
    Region?: string | undefined;
    KmsKeyId?: string | undefined;
    Status?: StatusType | undefined;
    StatusMessage?: string | undefined;
    LastAccessedDate?: Date | undefined;
}
export type ReplicationStatusListType = ReplicationStatusType[];
export interface CreateSecretResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    VersionId?: string | undefined;
    ReplicationStatus?: ReplicationStatusType[] | undefined;
}
export type ResourcePolicyNameType = string;
export interface DeleteResourcePolicyRequest {
    SecretId: string;
    PolicyName?: string | undefined;
}
export interface DeleteResourcePolicyResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    PolicyName?: string | undefined;
}
export type RecoveryWindowInDaysType = number;
export interface DeleteSecretRequest {
    SecretId: string;
    RecoveryWindowInDays?: number | undefined;
    ForceDeleteWithoutRecovery?: boolean | undefined;
}
export type DeletionDateType = Date;
export interface DeleteSecretResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    DeletionDate?: Date | undefined;
}
export interface DescribeSecretRequest {
    SecretId: string;
}
export type RotationEnabledType = boolean;
export type RotationLambdaARNType = string;
export type AutomaticallyRotateAfterDaysType = number;
export type DurationType = string;
export type ScheduleExpressionType = string;
export interface RotationRulesType {
    AutomaticallyAfterDays?: number | undefined;
    Duration?: string | undefined;
    ScheduleExpression?: string | undefined;
}
export type ExternalSecretRotationMetadataItemKeyType = string;
export type ExternalSecretRotationMetadataItemValueType = string;
export interface ExternalSecretRotationMetadataItem {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type ExternalSecretRotationMetadataType = ExternalSecretRotationMetadataItem[];
export type LastRotatedDateType = Date;
export type LastChangedDateType = Date;
export type DeletedDateType = Date;
export type NextRotationDateType = Date;
export type SecretVersionsToStagesMapType = {
    [key: string]: string[] | undefined;
};
export type OwningServiceType = string;
export interface CrossAccountPrimaryType {
    PrimarySecretARN?: string | undefined;
    ReplicationStatus?: StatusType | undefined;
    StatusMessage?: string | undefined;
}
export interface CrossAccountReplicaEntry {
    ReplicaSecretARN?: string | undefined;
    ReplicationRoleARN?: string | undefined;
    ReplicationStatus?: StatusType | undefined;
    StatusMessage?: string | undefined;
}
export type CrossAccountReplicaListType = CrossAccountReplicaEntry[];
export interface DescribeSecretResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    Type?: string | undefined;
    Description?: string | undefined;
    KmsKeyId?: string | undefined;
    RotationEnabled?: boolean | undefined;
    RotationLambdaARN?: string | undefined;
    RotationRules?: RotationRulesType | undefined;
    ExternalSecretRotationMetadata?: ExternalSecretRotationMetadataItem[] | undefined;
    ExternalSecretRotationRoleArn?: string | undefined;
    LastRotatedDate?: Date | undefined;
    LastChangedDate?: Date | undefined;
    LastAccessedDate?: Date | undefined;
    DeletedDate?: Date | undefined;
    NextRotationDate?: Date | undefined;
    Tags?: Tag[] | undefined;
    VersionIdsToStages?: {
        [key: string]: string[] | undefined;
    } | undefined;
    OwningService?: string | undefined;
    CreatedDate?: Date | undefined;
    PrimaryRegion?: string | undefined;
    ReplicationStatus?: ReplicationStatusType[] | undefined;
    CrossAccountPrimary?: CrossAccountPrimaryType | undefined;
    CrossAccountReplicas?: CrossAccountReplicaEntry[] | undefined;
}
export interface DisassociateCrossAccountReplicaRequest {
    SecretId: string;
    CrossAccountReplicaARN: string;
}
export interface DisassociateCrossAccountReplicaResponse {
    ARN?: string | undefined;
    CrossAccountReplicaARN?: string | undefined;
}
export type PasswordLengthType = number;
export type ExcludeCharactersType = string;
export type ExcludeNumbersType = boolean;
export type ExcludePunctuationType = boolean;
export type ExcludeUppercaseType = boolean;
export type ExcludeLowercaseType = boolean;
export type IncludeSpaceType = boolean;
export type RequireEachIncludedTypeType = boolean;
export interface GetRandomPasswordRequest {
    PasswordLength?: number | undefined;
    ExcludeCharacters?: string | undefined;
    ExcludeNumbers?: boolean | undefined;
    ExcludePunctuation?: boolean | undefined;
    ExcludeUppercase?: boolean | undefined;
    ExcludeLowercase?: boolean | undefined;
    IncludeSpace?: boolean | undefined;
    RequireEachIncludedType?: boolean | undefined;
}
export type RandomPasswordType = string | redacted.Redacted<string>;
export interface GetRandomPasswordResponse {
    RandomPassword?: string | redacted.Redacted<string> | undefined;
}
export interface GetResourcePolicyRequest {
    SecretId: string;
    PolicyName?: string | undefined;
}
export type NonEmptyResourcePolicyType = string;
export interface GetResourcePolicyResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    ResourcePolicy?: string | undefined;
    PolicyName?: string | undefined;
}
export interface GetSecretValueRequest {
    SecretId: string;
    VersionId?: string | undefined;
    VersionStage?: string | undefined;
}
export interface GetSecretValueResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    VersionId?: string | undefined;
    SecretBinary?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    SecretString?: string | redacted.Redacted<string> | undefined;
    VersionStages?: string[] | undefined;
    CreatedDate?: Date | undefined;
}
export type MaxResultsType = number;
export interface ListResourcePoliciesRequest {
    SecretId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ResourcePolicySummary {
    PolicyName?: string | undefined;
}
export type ResourcePolicySummaryListType = ResourcePolicySummary[];
export interface ListResourcePoliciesResponse {
    ResourcePolicies: ResourcePolicySummary[];
    NextToken?: string | undefined;
}
export type SortOrderType = "asc" | "desc" | (string & {});
export type SortByType = "created-date" | "last-accessed-date" | "last-changed-date" | "name" | (string & {});
export interface ListSecretsRequest {
    IncludePlannedDeletion?: boolean | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
    SortOrder?: SortOrderType | undefined;
    SortBy?: SortByType | undefined;
}
export interface SecretListEntry {
    ARN?: string | undefined;
    Name?: string | undefined;
    Type?: string | undefined;
    Description?: string | undefined;
    KmsKeyId?: string | undefined;
    RotationEnabled?: boolean | undefined;
    RotationLambdaARN?: string | undefined;
    RotationRules?: RotationRulesType | undefined;
    ExternalSecretRotationMetadata?: ExternalSecretRotationMetadataItem[] | undefined;
    ExternalSecretRotationRoleArn?: string | undefined;
    LastRotatedDate?: Date | undefined;
    LastChangedDate?: Date | undefined;
    LastAccessedDate?: Date | undefined;
    DeletedDate?: Date | undefined;
    NextRotationDate?: Date | undefined;
    Tags?: Tag[] | undefined;
    SecretVersionsToStages?: {
        [key: string]: string[] | undefined;
    } | undefined;
    OwningService?: string | undefined;
    CreatedDate?: Date | undefined;
    PrimaryRegion?: string | undefined;
}
export type SecretListType = SecretListEntry[];
export interface ListSecretsResponse {
    SecretList?: SecretListEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSecretVersionIdsRequest {
    SecretId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    IncludeDeprecated?: boolean | undefined;
}
export type KmsKeyIdListType = string[];
export interface SecretVersionsListEntry {
    VersionId?: string | undefined;
    VersionStages?: string[] | undefined;
    LastAccessedDate?: Date | undefined;
    CreatedDate?: Date | undefined;
    KmsKeyIds?: string[] | undefined;
}
export type SecretVersionsListType = SecretVersionsListEntry[];
export interface ListSecretVersionIdsResponse {
    Versions?: SecretVersionsListEntry[] | undefined;
    NextToken?: string | undefined;
    ARN?: string | undefined;
    Name?: string | undefined;
}
export interface PutResourcePolicyRequest {
    SecretId: string;
    ResourcePolicy: string;
    PolicyName?: string | undefined;
    BlockPublicPolicy?: boolean | undefined;
}
export interface PutResourcePolicyResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    PolicyName?: string | undefined;
}
export type RotationTokenType = string | redacted.Redacted<string>;
export interface PutSecretValueRequest {
    SecretId: string;
    ClientRequestToken?: string | undefined;
    SecretBinary?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    SecretString?: string | redacted.Redacted<string> | undefined;
    VersionStages?: string[] | undefined;
    RotationToken?: string | redacted.Redacted<string> | undefined;
}
export interface PutSecretValueResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    VersionId?: string | undefined;
    VersionStages?: string[] | undefined;
}
export type RemoveReplicaRegionListType = string[];
export interface RemoveRegionsFromReplicationRequest {
    SecretId: string;
    RemoveReplicaRegions: string[];
}
export interface RemoveRegionsFromReplicationResponse {
    ARN?: string | undefined;
    ReplicationStatus?: ReplicationStatusType[] | undefined;
}
export interface ReplicateSecretToRegionsRequest {
    SecretId: string;
    AddReplicaRegions: ReplicaRegionType[];
    ForceOverwriteReplicaSecret?: boolean | undefined;
}
export interface ReplicateSecretToRegionsResponse {
    ARN?: string | undefined;
    ReplicationStatus?: ReplicationStatusType[] | undefined;
}
export interface RestoreSecretRequest {
    SecretId: string;
}
export interface RestoreSecretResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
}
export interface RotateSecretRequest {
    SecretId: string;
    ClientRequestToken?: string | undefined;
    RotationLambdaARN?: string | undefined;
    RotationRules?: RotationRulesType | undefined;
    ExternalSecretRotationMetadata?: ExternalSecretRotationMetadataItem[] | undefined;
    ExternalSecretRotationRoleArn?: string | undefined;
    RotateImmediately?: boolean | undefined;
}
export interface RotateSecretResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    VersionId?: string | undefined;
}
export interface StopReplicationToReplicaRequest {
    SecretId: string;
}
export interface StopReplicationToReplicaResponse {
    ARN?: string | undefined;
}
export interface TagResourceRequest {
    SecretId: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyListType = string[];
export interface UntagResourceRequest {
    SecretId: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateSecretRequest {
    SecretId: string;
    ClientRequestToken?: string | undefined;
    Description?: string | undefined;
    KmsKeyId?: string | undefined;
    SecretBinary?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    SecretString?: string | redacted.Redacted<string> | undefined;
    Type?: string | undefined;
}
export interface UpdateSecretResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
    VersionId?: string | undefined;
}
export interface UpdateSecretVersionStageRequest {
    SecretId: string;
    VersionStage: string;
    RemoveFromVersionId?: string | undefined;
    MoveToVersionId?: string | undefined;
}
export interface UpdateSecretVersionStageResponse {
    ARN?: string | undefined;
    Name?: string | undefined;
}
export interface ValidateResourcePolicyRequest {
    SecretId?: string | undefined;
    ResourcePolicy: string;
}
export interface ValidationErrorsEntry {
    CheckName?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type ValidationErrorsType = ValidationErrorsEntry[];
export interface ValidateResourcePolicyResponse {
    PolicyValidationPassed?: boolean | undefined;
    ValidationErrors?: ValidationErrorsEntry[] | undefined;
}
export type AssociateCrossAccountReplicaError = InternalServiceError | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Links a primary secret in your account to a replica secret in a different Amazon Web Services
 * account and starts replication to this replica. The replica secret must already exist in the
 * other Amazon Web Services account. Create the replica with CreateSecret and set its
 * `CrossAccountPrimaryARN` field set to this primary secret's ARN.
 * When you call AssociateCrossAccountReplica, Secrets Manager calls
 * AcceptCrossAccountReplication on the replica secret on your behalf.
 *
 * The primary and replica secrets must be in the same Amazon Web Services Region and partition, and
 * you must call this operation from the account that owns the primary secret. A primary
 * secret can have at most one cross-account replica. This operation is idempotent, so
 * you can call it again for the same replica to repair replication. If the association fails,
 * Secrets Manager does not modify either the primary or replica secret.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:AssociateCrossAccountReplica`,
 * `secretsmanager:GetSecretValue` on the primary secret, and
 * `secretsmanager:AcceptCrossAccountReplication` on the replica secret. You
 * must also have `kms:Decrypt` permission for the Key Management Service
 * (KMS) key that encrypts the primary secret, and
 * `kms:Encrypt` permission for the Amazon Web Services KMS key that encrypts the replica
 * secret. If you supply `ReplicationRoleARN`, you also need
 * `iam:PassRole` for that role. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const associateCrossAccountReplica: API.OperationMethod<AssociateCrossAccountReplicaRequest & RegionInput, AssociateCrossAccountReplicaResponse, AssociateCrossAccountReplicaError, Credentials | HttpClient.HttpClient>;
export type BatchGetSecretValueError = DecryptionFailure | InternalServiceError | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the contents of the encrypted fields `SecretString` or
 * `SecretBinary` for up to 20 secrets. To retrieve a single secret, call
 * GetSecretValue.
 *
 * To choose which secrets to retrieve, you can specify a list of secrets by name or ARN,
 * or you can use filters. If Secrets Manager encounters errors such as
 * `AccessDeniedException` while attempting to retrieve any of the secrets,
 * you can see the errors in `Errors` in the response.
 *
 * Secrets Manager generates CloudTrail
 * `GetSecretValue` log entries for each secret you request when you call this
 * action. Do not include sensitive information in request parameters because it might be
 * logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * **Required permissions: **
 * `secretsmanager:BatchGetSecretValue`, and you must have
 * `secretsmanager:GetSecretValue` for each secret. If you use filters, you
 * must also have `secretsmanager:ListSecrets`. If the secrets are encrypted
 * using customer-managed keys instead of the Amazon Web Services managed key
 * `aws/secretsmanager`, then you also need `kms:Decrypt`
 * permissions for the keys. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const batchGetSecretValue: API.PaginatedOperationMethod<BatchGetSecretValueRequest & RegionInput, BatchGetSecretValueResponse, BatchGetSecretValueError, Credentials | HttpClient.HttpClient, unknown>;
export type CancelRotateSecretError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Turns off automatic rotation, and if a rotation is currently in progress, cancels the
 * rotation.
 *
 * If you cancel a rotation in progress, it can leave the `VersionStage`
 * labels in an unexpected state. You might need to remove the staging label
 * `AWSPENDING` from the partially created version. You also need to
 * determine whether to roll back to the previous version of the secret by moving the
 * staging label `AWSCURRENT` to the version that has `AWSPENDING`.
 * To determine which version has a specific staging label, call DescribeSecret. Then use UpdateSecretVersionStage to change staging labels. For more information, see How rotation
 * works.
 *
 * To turn on automatic rotation again, call RotateSecret.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:CancelRotateSecret`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const cancelRotateSecret: API.OperationMethod<CancelRotateSecretRequest & RegionInput, CancelRotateSecretResponse, CancelRotateSecretError, Credentials | HttpClient.HttpClient>;
export type CreateSecretError = DecryptionFailure | EncryptionFailure | InternalServiceError | InvalidParameterException | InvalidRequestException | LimitExceededException | MalformedPolicyDocumentException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new secret. A *secret* can be a password, a set of
 * credentials such as a user name and password, an OAuth token, or other secret
 * information that you store in an encrypted form in Secrets Manager. The secret also includes the
 * connection information to access a database or other service. Secrets Manager does not encrypt
 * this connection information. A secret in Secrets Manager consists of both the encrypted secret
 * versions and the metadata that Secrets Manager uses to manage the secret.
 *
 * For secrets that use *managed rotation*, you need to create the
 * secret through the managing service. For more information, see Secrets Manager secrets
 * managed by other Amazon Web Services services.
 *
 * For information about creating a secret in the console, see Create a
 * secret.
 *
 * To create a secret, you can provide the secret value to be encrypted in either the
 * `SecretString` parameter or the `SecretBinary` parameter, but
 * not both. If you include `SecretString` or `SecretBinary`, then
 * Secrets Manager creates an initial secret version and automatically attaches the staging label
 * `AWSCURRENT` to it.
 *
 * For database credentials you want to rotate, for Secrets Manager to be able to rotate the
 * secret, you must make sure the JSON you store in the `SecretString` matches
 * the JSON
 * structure of a database secret.
 *
 * If you don't specify an KMS encryption key, Secrets Manager uses the Amazon Web Services managed key
 * `aws/secretsmanager`. If this key doesn't already exist in your account,
 * then Secrets Manager creates it for you automatically. All users and roles in the Amazon Web Services account
 * automatically have access to use `aws/secretsmanager`. Creating
 * `aws/secretsmanager` can result in a one-time delay to complete the
 * secret creation.
 *
 * If the secret is in a different Amazon Web Services account from the credentials calling the API,
 * then you can't use `aws/secretsmanager` to encrypt the secret, and you must
 * create and use a customer managed KMS key.
 *
 * To create a cross-account replica secret, include `CrossAccountPrimaryARN`.
 * The replica must use a customer managed KMS key, and can't include
 * `AddReplicaRegions`, `Description`, `SecretBinary`,
 * `SecretString`, or `Type`.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action.
 * Do not include sensitive information in request parameters except
 * `SecretBinary` or `SecretString` because it might be logged.
 * For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:CreateSecret`. If you include tags in the
 * secret, you also need `secretsmanager:TagResource`. To add replica Regions,
 * you must also have `secretsmanager:ReplicateSecretToRegions`. To create a
 * cross-account replica secret, you must also have
 * `secretsmanager:PutResourcePolicy` permissions. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 *
 * To encrypt the secret with a KMS key other than `aws/secretsmanager`, you
 * need `kms:GenerateDataKey` and `kms:Decrypt` permission to the
 * key.
 *
 * When you enter commands in a command shell, there is a risk of the command history being accessed or utilities having access to your command parameters. This is a concern if the command includes the value of a secret. Learn how to Mitigate the risks of using command-line tools to store Secrets Manager secrets.
 */
export declare const createSecret: API.OperationMethod<CreateSecretRequest & RegionInput, CreateSecretResponse, CreateSecretError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the resource-based permission policy attached to the secret. To attach a
 * policy to a secret, use PutResourcePolicy.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:DeleteResourcePolicy`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSecretError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a secret and all of its versions. You can specify a recovery window during
 * which you can restore the secret. The minimum recovery window is 7 days. The default
 * recovery window is 30 days. Secrets Manager attaches a `DeletionDate` stamp to the
 * secret that specifies the end of the recovery window. At the end of the recovery window,
 * Secrets Manager deletes the secret permanently.
 *
 * You can't delete a primary secret that is replicated to other Regions. You must first
 * delete the replicas using RemoveRegionsFromReplication, and then
 * delete the primary secret. When you delete a replica, it is deleted immediately.
 *
 * You can't delete a cross-account primary secret that is associated with a
 * cross-account replica secret. You must first disassociate each of the replicas using
 * DisassociateCrossAccountReplica, before deleting the primary secret.
 * Similarly, you can't delete a cross-account replica secret without first stopping
 * replication. Call StopReplicationToReplica to stop replication, and
 * then you can delete the secret.
 *
 * You can't directly delete a version of a secret. Instead, you remove all staging
 * labels from the version using UpdateSecretVersionStage. This marks the
 * version as deprecated, and then Secrets Manager can automatically delete the version in the
 * background.
 *
 * To determine whether an application still uses a secret, you can create an Amazon CloudWatch alarm
 * to alert you to any attempts to access a secret during the recovery window. For more
 * information, see
 * Monitor secrets scheduled for deletion.
 *
 * Secrets Manager performs the permanent secret deletion at the end of the waiting period as a
 * background task with low priority. There is no guarantee of a specific time after the
 * recovery window for the permanent delete to occur.
 *
 * At any time before recovery window ends, you can use RestoreSecret
 * to remove the `DeletionDate` and cancel the deletion of the secret.
 *
 * When a secret is scheduled for deletion, you cannot retrieve the secret value. You
 * must first cancel the deletion with RestoreSecret and then you can
 * retrieve the secret.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:DeleteSecret`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const deleteSecret: API.OperationMethod<DeleteSecretRequest & RegionInput, DeleteSecretResponse, DeleteSecretError, Credentials | HttpClient.HttpClient>;
export type DescribeSecretError = InternalServiceError | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the details of a secret. It does not include the encrypted secret value.
 * Secrets Manager only returns fields that have a value in the response.
 *
 * The `VersionIdsToStages` field in the response includes every version ID
 * that has a staging label attached, even if that version doesn't contain a secret
 * value. In contrast, `ListSecretVersionIds` only returns versions that
 * contain a secret value. To check whether a secret version contains a value, call
 * GetSecretValue.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:DescribeSecret`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const describeSecret: API.OperationMethod<DescribeSecretRequest & RegionInput, DescribeSecretResponse, DescribeSecretError, Credentials | HttpClient.HttpClient>;
export type DisassociateCrossAccountReplicaError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the link between a primary secret in your account and a cross-account replica
 * secret, and stops replication to the replica secret. Call this operation on the primary secret.
 * This action removes the replica association created by AssociateCrossAccountReplica.
 *
 * Disassociating the replica from the primary does not delete the replica secret or
 * convert the replica secret to a standalone secret. The replica secret remains in the other
 * account and its replication status changes to `Detached`. Secrets Manager no longer sends updates
 * from the primary secret to the replica secret after disassociation. To convert a detached
 * replica into a standalone secret, call
 * StopReplicationToReplica on the replica secret.
 *
 * You must disassociate a cross-account replica before you call DeleteSecret for the primary secret. The DeleteSecret
 * call fails if any replicas are still associated with the primary secret.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:DisassociateCrossAccountReplica`.
 * For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const disassociateCrossAccountReplica: API.OperationMethod<DisassociateCrossAccountReplicaRequest & RegionInput, DisassociateCrossAccountReplicaResponse, DisassociateCrossAccountReplicaError, Credentials | HttpClient.HttpClient>;
export type GetRandomPasswordError = InternalServiceError | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * Generates a random password. We recommend that you specify the maximum length and
 * include every character type that the system you are generating a password for can
 * support. By default, Secrets Manager uses uppercase and lowercase letters, numbers, and the
 * following characters in passwords:
 * `!\"#$%&'()*+,-./:;?@[\\]^_`{|}~`
 *
 * Secrets Manager generates a CloudTrail log entry when you call this
 * action.
 *
 * Required permissions:
 *
 * `secretsmanager:GetRandomPassword`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const getRandomPassword: API.OperationMethod<GetRandomPasswordRequest & RegionInput, GetRandomPasswordResponse, GetRandomPasswordError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the JSON text of the resource-based policy document attached to the secret.
 * For more information about permissions policies attached to a secret, see Permissions policies attached to a secret.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:GetResourcePolicy`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetSecretValueError = DecryptionFailure | InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the contents of the encrypted fields `SecretString` or
 * `SecretBinary` from the specified version of a secret, whichever contains
 * content.
 *
 * To retrieve the values for a group of secrets, call BatchGetSecretValue.
 *
 * We recommend that you cache your secret values by using client-side caching. Caching
 * secrets improves speed and reduces your costs. For more information, see Cache secrets for your applications.
 *
 * To retrieve the previous version of a secret, use `VersionStage` and
 * specify AWSPREVIOUS. To revert to the previous version of a secret, call UpdateSecretVersionStage.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:GetSecretValue`. If the secret is encrypted
 * using a customer-managed key instead of the Amazon Web Services managed key
 * `aws/secretsmanager`, then you also need `kms:Decrypt`
 * permissions for that key. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const getSecretValue: API.OperationMethod<GetSecretValueRequest & RegionInput, GetSecretValueResponse, GetSecretValueError, Credentials | HttpClient.HttpClient>;
export type ListResourcePoliciesError = InternalServiceError | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the resource-based policies attached to a secret. The response contains only the
 * names of the policies, not their contents. Secrets Manager lists `default` first,
 * followed by any other policies in alphabetical order. To get the contents of a policy,
 * use GetResourcePolicy. You can modify only the `default`
 * policy.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:ListResourcePolicies`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const listResourcePolicies: API.PaginatedOperationMethod<ListResourcePoliciesRequest & RegionInput, ListResourcePoliciesResponse, ListResourcePoliciesError, Credentials | HttpClient.HttpClient, ResourcePolicySummary>;
export type ListSecretsError = InternalServiceError | InvalidNextTokenException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * Lists the secrets that are stored by Secrets Manager in the Amazon Web Services account, not including secrets
 * that are marked for deletion. To see secrets marked for deletion, use the Secrets Manager
 * console.
 *
 * All Secrets Manager operations are eventually consistent. ListSecrets might not
 * reflect changes from the last five minutes. You can get more recent information for a
 * specific secret by calling DescribeSecret.
 *
 * To list the versions of a secret, use ListSecretVersionIds.
 *
 * To retrieve the values for the secrets, call BatchGetSecretValue or
 * GetSecretValue.
 *
 * For information about finding secrets in the console, see Find secrets in
 * Secrets Manager.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:ListSecrets`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const listSecrets: API.PaginatedOperationMethod<ListSecretsRequest & RegionInput, ListSecretsResponse, ListSecretsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSecretVersionIdsError = InternalServiceError | InvalidNextTokenException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the versions of a secret. Secrets Manager uses staging labels to indicate the different
 * versions of a secret. For more information, see Secrets Manager
 * concepts: Versions.
 *
 * To list the secrets in the account, use ListSecrets.
 *
 * `ListSecretVersionIds` only returns versions that contain a secret
 * value. To see all version IDs that have staging labels attached, including ones
 * without a secret value, call `DescribeSecret` and check
 * `VersionIdsToStages`.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:ListSecretVersionIds`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const listSecretVersionIds: API.PaginatedOperationMethod<ListSecretVersionIdsRequest & RegionInput, ListSecretVersionIdsResponse, ListSecretVersionIdsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutResourcePolicyError = InternalServiceError | InvalidParameterException | InvalidRequestException | MalformedPolicyDocumentException | PublicPolicyException | ResourceNotFoundException | CommonErrors;
/**
 * Attaches a resource-based permission policy to a secret. A resource-based policy is
 * optional. For more information, see Authentication and access control for Secrets Manager
 *
 * For information about attaching a policy in the console, see Attach a permissions policy to a secret.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:PutResourcePolicy`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutSecretValueError = DecryptionFailure | EncryptionFailure | InternalServiceError | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new version of your secret by creating a new encrypted value and attaching
 * it to the secret. version can contain a new `SecretString` value or a new
 * `SecretBinary` value.
 *
 * Do not call `PutSecretValue` at a sustained rate of more than once every 10
 * minutes. When you update the secret value, Secrets Manager creates a new version of the secret.
 * Secrets Manager keeps 100 of the most recent versions, but it keeps *all*
 * secret versions created in the last 24 hours. If you call `PutSecretValue`
 * more than once every 10 minutes, you will create more versions than Secrets Manager removes, and
 * you will reach the quota for secret versions.
 *
 * You can specify the staging labels to attach to the new version in
 * `VersionStages`. If you don't include `VersionStages`, then
 * Secrets Manager automatically moves the staging label `AWSCURRENT` to this version. If
 * this operation creates the first version for the secret, then Secrets Manager automatically
 * attaches the staging label `AWSCURRENT` to it. If this operation moves the
 * staging label `AWSCURRENT` from another version to this version, then Secrets Manager
 * also automatically moves the staging label `AWSPREVIOUS` to the version that
 * `AWSCURRENT` was removed from.
 *
 * This operation is idempotent. If you call this operation with a
 * `ClientRequestToken` that matches an existing version's VersionId, and
 * you specify the same secret data, the operation succeeds but does nothing. However, if
 * the secret data is different, then the operation fails because you can't modify an
 * existing version; you can only create new ones.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action.
 * Do not include sensitive information in request parameters except
 * `SecretBinary`, `SecretString`, or `RotationToken`
 * because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:PutSecretValue`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 *
 * When you enter commands in a command shell, there is a risk of the command history being accessed or utilities having access to your command parameters. This is a concern if the command includes the value of a secret. Learn how to Mitigate the risks of using command-line tools to store Secrets Manager secrets.
 */
export declare const putSecretValue: API.OperationMethod<PutSecretValueRequest & RegionInput, PutSecretValueResponse, PutSecretValueError, Credentials | HttpClient.HttpClient>;
export type RemoveRegionsFromReplicationError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * For a secret that is replicated to other Regions, deletes the secret replicas from the
 * Regions you specify.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:RemoveRegionsFromReplication`.
 * For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const removeRegionsFromReplication: API.OperationMethod<RemoveRegionsFromReplicationRequest & RegionInput, RemoveRegionsFromReplicationResponse, RemoveRegionsFromReplicationError, Credentials | HttpClient.HttpClient>;
export type ReplicateSecretToRegionsError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Replicates the secret to a new Regions. See Multi-Region secrets.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:ReplicateSecretToRegions`. If the primary
 * secret is encrypted with a KMS key other than `aws/secretsmanager`, you also
 * need `kms:Decrypt` permission to the key. To encrypt the replicated secret
 * with a KMS key other than `aws/secretsmanager`, you need
 * `kms:GenerateDataKey` and `kms:Encrypt` to the key.
 * For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const replicateSecretToRegions: API.OperationMethod<ReplicateSecretToRegionsRequest & RegionInput, ReplicateSecretToRegionsResponse, ReplicateSecretToRegionsError, Credentials | HttpClient.HttpClient>;
export type RestoreSecretError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels the scheduled deletion of a secret by removing the `DeletedDate`
 * time stamp. You can access a secret again after it has been restored.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:RestoreSecret`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const restoreSecret: API.OperationMethod<RestoreSecretRequest & RegionInput, RestoreSecretResponse, RestoreSecretError, Credentials | HttpClient.HttpClient>;
export type RotateSecretError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Configures and starts the asynchronous process of rotating the secret. For information
 * about rotation, see Rotate secrets
 * in the *Secrets Manager User Guide*. If you include the configuration
 * parameters, the operation sets the values for the secret and then immediately starts a
 * rotation. If you don't include the configuration parameters, the operation starts a
 * rotation with the values already stored in the secret.
 *
 * When rotation is successful, the `AWSPENDING` staging label might be
 * attached to the same version as the `AWSCURRENT` version, or it might not be
 * attached to any version. If the `AWSPENDING` staging label is present but not
 * attached to the same version as `AWSCURRENT`, then any later invocation of
 * `RotateSecret` assumes that a previous rotation request is still in
 * progress and returns an error. When rotation is unsuccessful, the
 * `AWSPENDING` staging label might be attached to an empty secret version.
 * For more information, see Troubleshoot
 * rotation in the *Secrets Manager User Guide*.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:RotateSecret`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager. You also
 * need `lambda:InvokeFunction` permissions on the rotation function. For more
 * information, see Permissions for rotation.
 */
export declare const rotateSecret: API.OperationMethod<RotateSecretRequest & RegionInput, RotateSecretResponse, RotateSecretError, Credentials | HttpClient.HttpClient>;
export type StopReplicationToReplicaError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the link between a replica secret and its primary secret, and stops
 * replication to the replica. You call this operation from the replica account or Region.
 * Depending on the type of replica, the behavior is:
 *
 * - **Cross-Region replica**: promotes the replica to
 * a standalone primary secret in the replica Region.
 *
 * - **Cross-account replica**: promotes the replica
 * in your account to a standalone secret and stops replication from its primary
 * secret in the other account. Secrets Manager updates the primary secret's replication status
 * to `Detached` for this replica.
 *
 * To stop cross-account replication from the primary account instead, use DisassociateCrossAccountReplica.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:StopReplicationToReplica`. For cross-account
 * replica secrets, you must also have `secretsmanager:DeleteResourcePolicy`
 * permissions. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const stopReplicationToReplica: API.OperationMethod<StopReplicationToReplicaRequest & RegionInput, StopReplicationToReplicaResponse, StopReplicationToReplicaError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Attaches tags to a secret. Tags consist of a key name and a value. Tags are part of
 * the secret's metadata. They are not associated with specific versions of the secret.
 * This operation appends tags to the existing list of tags.
 *
 * For tag quotas and naming restrictions, see Service quotas for
 * Tagging in the *Amazon Web Services General Reference guide*.
 *
 * If you use tags as part of your security strategy, then adding or removing a tag
 * can change permissions. If successfully completing this operation would result in
 * you losing your permissions for this secret, then the operation is blocked and
 * returns an Access Denied error.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:TagResource`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceError | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes specific tags from a secret.
 *
 * This operation is idempotent. If a requested tag is not attached to the secret, no
 * error is returned and the secret metadata is unchanged.
 *
 * If you use tags as part of your security strategy, then removing a tag can change
 * permissions. If successfully completing this operation would result in you losing
 * your permissions for this secret, then the operation is blocked and returns an
 * Access Denied error.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:UntagResource`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateSecretError = DecryptionFailure | EncryptionFailure | InternalServiceError | InvalidParameterException | InvalidRequestException | LimitExceededException | MalformedPolicyDocumentException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the details of a secret, including metadata and the secret value. To change
 * the secret value, you can also use PutSecretValue.
 *
 * To change the rotation configuration of a secret, use RotateSecret
 * instead.
 *
 * To change a secret so that it is managed by another service, you need to recreate the
 * secret in that service. See Secrets Manager secrets
 * managed by other Amazon Web Services services.
 *
 * We recommend you avoid calling `UpdateSecret` at a sustained rate of more
 * than once every 10 minutes. When you call `UpdateSecret` to update the secret
 * value, Secrets Manager creates a new version of the secret. Secrets Manager removes outdated versions when
 * there are more than 100, but it does not remove versions created less than 24 hours ago.
 * If you update the secret value more than once every 10 minutes, you create more versions
 * than Secrets Manager removes, and you will reach the quota for secret versions.
 *
 * If you include `SecretString` or `SecretBinary` to create a new
 * secret version, Secrets Manager automatically moves the staging label `AWSCURRENT` to
 * the new version. Then it attaches the label `AWSPREVIOUS` to the version that
 * `AWSCURRENT` was removed from.
 *
 * If you call this operation with a `ClientRequestToken` that matches an
 * existing version's `VersionId`, the operation results in an error. You can't
 * modify an existing version, you can only create a new version. To remove a version,
 * remove all staging labels from it. See UpdateSecretVersionStage.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action.
 * Do not include sensitive information in request parameters except
 * `SecretBinary` or `SecretString` because it might be logged.
 * For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:UpdateSecret`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager. If you use a
 * customer managed key, you must also have `kms:GenerateDataKey`,
 * `kms:Encrypt`, and `kms:Decrypt` permissions on the key. If
 * you change the KMS key and you don't have `kms:Encrypt` permission to the new
 * key, Secrets Manager does not re-encrypt existing secret versions with the new key. For more
 * information, see Secret encryption
 * and decryption.
 *
 * When you enter commands in a command shell, there is a risk of the command history being accessed or utilities having access to your command parameters. This is a concern if the command includes the value of a secret. Learn how to Mitigate the risks of using command-line tools to store Secrets Manager secrets.
 */
export declare const updateSecret: API.OperationMethod<UpdateSecretRequest & RegionInput, UpdateSecretResponse, UpdateSecretError, Credentials | HttpClient.HttpClient>;
export type UpdateSecretVersionStageError = InternalServiceError | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the staging labels attached to a version of a secret. Secrets Manager uses staging
 * labels to track a version as it progresses through the secret rotation process. Each
 * staging label can be attached to only one version at a time. To add a staging label to a
 * version when it is already attached to another version, Secrets Manager first removes it from the
 * other version first and then attaches it to this one. For more information about
 * versions and staging labels, see Concepts:
 * Version.
 *
 * The staging labels that you specify in the `VersionStage` parameter are
 * added to the existing list of staging labels for the version.
 *
 * You can move the `AWSCURRENT` staging label to this version by including it
 * in this call.
 *
 * Whenever you move `AWSCURRENT`, Secrets Manager automatically moves the label
 * `AWSPREVIOUS` to the version that `AWSCURRENT` was removed
 * from.
 *
 * If this action results in the last label being removed from a version, then the
 * version is considered to be 'deprecated' and can be deleted by Secrets Manager.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:UpdateSecretVersionStage`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const updateSecretVersionStage: API.OperationMethod<UpdateSecretVersionStageRequest & RegionInput, UpdateSecretVersionStageResponse, UpdateSecretVersionStageError, Credentials | HttpClient.HttpClient>;
export type ValidateResourcePolicyError = InternalServiceError | InvalidParameterException | InvalidRequestException | MalformedPolicyDocumentException | ResourceNotFoundException | CommonErrors;
/**
 * Validates that a resource policy does not grant a wide range of principals access to
 * your secret. A resource-based policy is optional for secrets.
 *
 * The API performs three checks when validating the policy:
 *
 * - Sends a call to Zelkova, an automated reasoning engine, to ensure your resource
 * policy does not allow broad access to your secret, for example policies that use
 * a wildcard for the principal.
 *
 * - Checks for correct syntax in a policy.
 *
 * - Verifies the policy does not lock out a caller.
 *
 * Secrets Manager generates a CloudTrail log entry when you call this action. Do not include sensitive information in request parameters because it might be logged. For more information, see Logging Secrets Manager events with CloudTrail.
 *
 * Required permissions:
 *
 * `secretsmanager:ValidateResourcePolicy` and
 * `secretsmanager:PutResourcePolicy`. For more information, see
 * IAM policy actions for Secrets Manager and Authentication
 * and access control in Secrets Manager.
 */
export declare const validateResourcePolicy: API.OperationMethod<ValidateResourcePolicyRequest & RegionInput, ValidateResourcePolicyResponse, ValidateResourcePolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=secrets-manager.d.ts.map