/**
 * Base64 for byte arrays, on the native `toBase64`/`fromBase64` when the
 * runtime has them and `btoa`/`atob` otherwise.
 */
export declare const bytesToBase64: (bytes: Uint8Array) => string;
export declare const base64ToBytes: (b64: string) => Uint8Array;
//# sourceMappingURL=base64.d.ts.map