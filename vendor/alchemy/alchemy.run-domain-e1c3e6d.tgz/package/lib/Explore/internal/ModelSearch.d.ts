import * as Effect from "effect/Effect";
import * as Aggregate from "../../Aggregate.ts";
import type * as Decision from "../../Decision.ts";
import * as Check from "../../Prove/internal/Check.ts";
import * as Induction from "../../Prove/internal/Induction.ts";
import type { Interpreter } from "../../Prove/internal/Interpreter.ts";
import * as Paths from "../../Prove/internal/Paths.ts";
import * as Relations from "../../Prove/internal/Relations.ts";
import * as Smt from "../../Prove/internal/Smt.ts";
import type * as Source from "../../Prove/internal/Source.ts";
import * as Suggest from "../../Prove/internal/Suggest.ts";
import type { Module, Node, V } from "../../Prove/internal/Value.ts";
import * as Value from "../../Prove/internal/Value.ts";
import type { Move } from "./Search.ts";
/** One command of a story: who it went to, and who sent it. */
export interface Step extends Move {
    /** The aggregate the command went to: for a decision, the first it read. */
    readonly aggregate: string;
    readonly id: string;
    /**
     * For a command a decision implements: what it recorded, instance by
     * instance. `undefined` for a command one aggregate handles.
     */
    readonly recorded: ReadonlyArray<{
        readonly aggregate: string;
        readonly id: string;
        readonly events: ReadonlyArray<unknown>;
    }> | undefined;
    /** The policy or saga that sent the command; `undefined` when a caller did, or a schedule. */
    readonly by: string | undefined;
    /** The delay of the schedule that sent the command, as the code wrote it. */
    readonly after: string | undefined;
    /** What the external systems answered after the command, before the next one ran. */
    readonly asked: ReadonlyArray<Asked>;
    /**
     * Whether it was sent a second time round: by a policy handling an event it
     * had handled before, or by a saga running a step it had run before.
     */
    readonly again: boolean;
    /** The saga step that sent it, by name. */
    readonly step: string | undefined;
    /**
     * Whether a scheduled command was due by then and had not run. A platform
     * runs each instance's schedule on its own, so one can run late.
     */
    readonly late: boolean;
}
/** One call to an external system, and the answer the solver picked for it. */
export interface Asked {
    /** The policy or saga that called. */
    readonly by: string | undefined;
    /** The system and its operation: `FraudCheck.score`. */
    readonly call: string;
    /** The operation itself, as the system's class holds it. */
    readonly op: unknown;
    readonly answer: unknown;
    /** Whether the answer is one of the operation's declared errors. */
    readonly failed: boolean;
    /** Whether the call was made a second time round, as a command is. */
    readonly again: boolean;
    /** The saga step that called, by name. */
    readonly step: string | undefined;
}
/** Commands callers send one after another, each followed by what the policies do about it. */
export type Story = ReadonlyArray<Step>;
export interface Outcome {
    /** The aggregate that handles the command: `undefined` for a command a decision implements. */
    readonly aggregate: string | undefined;
    readonly command: string;
    readonly kind: "records" | "rejects";
    readonly tag: string;
    /** The shortest story found that ends in it. */
    readonly story: Story | undefined;
}
/** One way a saga's run can stop. */
export interface Ending {
    readonly saga: string;
    /** `completes`, `fails with <rejection>`, or `waits for <signal>`. */
    readonly ending: string;
    /** The shortest story found that gets a run there. */
    readonly story: Story | undefined;
}
/** A policy or saga the explorer left out, and the code it could not read. */
export interface Skipped {
    readonly policy: string;
    readonly reason: string;
    readonly file: string | undefined;
    readonly line: number | undefined;
}
/** A part of the model the sequences were run without, which no rule depends on. */
export interface Aside {
    readonly kind: "view" | "projection" | "stream" | "query";
    readonly name: string;
    readonly reason: string;
}
export interface Found {
    /** The command sequences run, one per path through the code. */
    readonly sequences: number;
    /** The states whose invariants were checked. */
    readonly states: number;
    readonly truncated: boolean;
    /** The most commands in a sequence for which every sequence was run. */
    readonly complete: number;
    readonly invariants: ReadonlyArray<{
        readonly aggregate: string;
        readonly name: string;
        /** An invariant is about a state, a transition about one step. */
        readonly kind: "invariant" | "transition";
        readonly broken: Story | undefined;
        readonly proved: boolean;
        /** The states reached in which it was looked at. */
        readonly states: number;
        /** For a rule that is not proved: the command the proof fails on, and why. */
        readonly unproved: {
            readonly by: string;
            readonly verdict: Check.Verdict;
        } | undefined;
        /**
         * Where the proof fails from a state the rules allow: an invariant every
         * command keeps, that makes this one proved once it is written down.
         */
        readonly suggested: Suggest.Suggestion | undefined;
    }>;
    /**
     * The model's own invariants, looked at whenever a sequence has nothing left
     * to react: `broken` is the shortest sequence found that breaks one, and
     * `states` is how many times one was looked at.
     */
    readonly rules: ReadonlyArray<{
        readonly name: string;
        /** An invariant is given every instance; a relation is about a few, so it can be proved. */
        readonly kind: "invariant" | "relation";
        readonly broken: Story | undefined;
        /** A relation every command and every decision keeps, from any states the rules allow. */
        readonly proved: boolean;
        /** For a relation that is not proved: what the proof fails on. */
        readonly unproved: {
            readonly by: string;
            readonly verdict: Check.Verdict;
        } | undefined;
        readonly states: number;
    }>;
    /**
     * What the model says holds once everything has run its course, looked at
     * whenever a sequence has nothing left to react and no command scheduled:
     * `broken` is the shortest sequence found that ends without it, and
     * `states` is how many sequences were run to their end.
     */
    readonly eventually: ReadonlyArray<{
        readonly name: string;
        readonly broken: Story | undefined;
        readonly states: number;
    }>;
    /**
     * What the model says can happen, looked at whenever a sequence has nothing
     * left to react: `reached` is the shortest sequence found that gets there,
     * run on the real code, and `states` is how many times one was looked at.
     */
    readonly sometimes: ReadonlyArray<{
        readonly name: string;
        readonly reached: Story | undefined;
        readonly states: number;
    }>;
    /**
     * The commands no state the invariants allow accepts: they never record an
     * event, so nothing said here is about them.
     */
    readonly dead: ReadonlyArray<string>;
    /** The decisions run in the sequences, each by the command it implements. */
    readonly decisions: ReadonlyArray<string>;
    readonly outcomes: ReadonlyArray<Outcome>;
    readonly reached: ReadonlyArray<{
        readonly aggregate: string;
        readonly tag: string;
        readonly story: Story | undefined;
    }>;
    /** The policies whose reactions were run. */
    readonly followed: ReadonlyArray<string>;
    /** The policies no sequence recorded an event for. */
    readonly idle: ReadonlyArray<string>;
    /** The views folded along every sequence: a policy reacts to one, or an invariant reads one. */
    readonly views: ReadonlyArray<string>;
    /** The projections an invariant reads: what each is given is followed along every sequence. */
    readonly projections: ReadonlyArray<string>;
    /** The external systems called, each answered with every answer its schema allows. */
    readonly systems: ReadonlyArray<string>;
    /** The ways delivery went wrong that the sequences were run with. */
    readonly faults: {
        readonly redeliver: boolean;
        readonly reorder: boolean;
        readonly rerun: boolean;
    };
    /**
     * The longer sequences run past the ones every sequence was run to: each a
     * walk of commands picked at random, from a seed that picks the same again.
     */
    readonly walks: {
        readonly seed: number;
        /** The walks run. */
        readonly count: number;
        /** The commands callers sent in them, all together. */
        readonly commands: number;
        /** The most commands callers sent in one. */
        readonly longest: number;
        /** Each walk as it ended, with the values the solver picked: a story to run on the real model. */
        readonly stories: ReadonlyArray<Story>;
    };
    /**
     * The external calls a policy makes again when an event is delivered to it
     * again: each has to be safe to repeat, which the explorer cannot tell.
     */
    readonly repeated: ReadonlyArray<string>;
    /** The sagas that ran. */
    readonly sagas: ReadonlyArray<string>;
    /** The sagas no sequence started. */
    readonly unstarted: ReadonlyArray<string>;
    readonly endings: ReadonlyArray<Ending>;
    /** The policies and sagas left out: the sequences were run as if they did nothing. */
    readonly skipped: ReadonlyArray<Skipped>;
    /**
     * Every other part of the model the sequences were run without, by name: a
     * view or projection no rule reads and no policy reacts to, and each stream
     * and query. No rule depends on one, so leaving it out changes no result.
     */
    readonly aside: ReadonlyArray<Aside>;
    /**
     * What a command writes to a part of a state whose schema has a check the
     * prover does not read: the new value is not proved to pass it.
     */
    readonly unkept: ReadonlyArray<string>;
    /** A rejection a policy does not handle: its handler fails with it. */
    readonly failures: ReadonlyArray<{
        readonly policy: string;
        readonly tag: string;
        readonly story: Story;
    }>;
    /** Sequences whose reactions were still going after the most the explorer follows. */
    readonly unsettled: number;
    readonly unread: ReadonlyArray<Value.NotTranslated>;
    readonly disagreements: ReadonlyArray<string>;
    /**
     * How far the proofs' reading of each command was held against the real
     * code: the paths inputs were picked and run for, and the ones that could not be run.
     * A path where the real code did something else is in `disagreements`.
     */
    readonly agreement: {
        readonly compared: number;
        readonly uncompared: number;
    };
    readonly undecided: ReadonlyArray<{
        readonly reason: string;
        readonly times: number;
    }>;
}
export interface Options {
    /** The most commands callers send in a sequence. */
    readonly depth: number;
    readonly budget: number;
    /** The most instances of one aggregate in a sequence. */
    readonly instances: number;
    readonly faults: {
        /** Deliver each event to each policy twice: the kernel delivers at least once. */
        readonly redeliver: boolean;
        /** Run the reactions waiting at the same time in other orders too. */
        readonly reorder: boolean;
        /** Run a saga's step again, as when it stopped before its result was kept. */
        readonly rerun: boolean;
    };
    /** Longer sequences to run after every short one: how many, of how many commands, from which seed. */
    readonly walks: {
        readonly count: number;
        readonly length: number;
        readonly seed: number;
    };
}
/** A model, as far as the explorer reads it. */
export interface ModelLike {
    readonly modelName: string;
    readonly definitions: {
        readonly aggregates: ReadonlyArray<Aggregate.Any>;
        readonly decisions?: ReadonlyArray<Decision.Any>;
        readonly views?: ReadonlyArray<unknown>;
        readonly policies: ReadonlyArray<unknown>;
        readonly projections?: ReadonlyArray<unknown>;
        readonly streams?: ReadonlyArray<unknown>;
    };
    readonly sagas?: ReadonlyArray<unknown>;
    readonly queries?: ReadonlyArray<unknown>;
    readonly invariants?: {
        readonly [name: string]: (model: never) => boolean;
    };
    readonly eventually?: {
        readonly [name: string]: (model: never) => boolean;
    };
    readonly sometimes?: {
        readonly [name: string]: (model: never) => boolean;
    };
    readonly relations?: {
        readonly [name: string]: {
            readonly over: Readonly<Record<string, Aggregate.Any>>;
            readonly holds: (on: never) => boolean;
        };
    };
}
interface CommandClass extends Paths.CommandClass {
    readonly events: ReadonlyArray<{
        readonly tag: string;
    }>;
    readonly rejects: ReadonlyArray<{
        readonly tag: string;
    }>;
}
interface ViewClass {
    readonly viewName: string;
    readonly definition: {
        readonly from: ReadonlyArray<unknown>;
        readonly key: unknown;
        readonly state?: unknown;
        readonly initial?: unknown;
        readonly keyOf?: unknown;
        readonly evolve?: Readonly<Record<string, unknown>>;
        readonly events?: ReadonlyArray<{
            readonly tag: string;
        }>;
        readonly emit?: Readonly<Record<string, unknown>>;
        /** A projection's events. */
        readonly on?: ReadonlyArray<unknown>;
    };
}
/** A view or a projection the explorer follows: what reads the model's events, key by key. */
interface ViewImpl {
    readonly name: string;
    /** A projection keeps no state the model declares: what it is given is what is known of it. */
    readonly kind: "view" | "projection";
    readonly cls: ViewClass;
    readonly definition: Paths.Definition;
    /** The aggregates and views it reads, by class, with the name its handlers know each by. */
    readonly sources: ReadonlyMap<unknown, string>;
    /** The name of the aggregate that keys it: `undefined` when a value does. */
    readonly keyedBy: string | undefined;
    readonly stateful: boolean;
    readonly initial: V;
    /** The events it says it emits: without them it passes on each event it folds. */
    readonly declared: ReadonlySet<string> | undefined;
    /** For a projection: the events it handles. */
    readonly on: ReadonlyArray<unknown>;
}
interface Agg {
    readonly cls: Aggregate.Any;
    readonly name: string;
    readonly definition: Paths.Definition;
    readonly commands: ReadonlyArray<CommandClass>;
    readonly initial: V;
    /** The names of its invariants, then of its transitions. */
    readonly invariants: ReadonlyArray<string>;
    readonly transitions: ReadonlySet<string>;
    /** The real invariants, on a state. */
    readonly real: Readonly<Record<string, (state: unknown) => boolean>>;
    /** The real invariants and transitions, on a step. */
    readonly rules: Readonly<Record<string, Check.Kept["holds"]>>;
}
/** A decision the explorer follows: one command, decided across the instances it names. */
interface Decided extends Induction.DecisionImpl {
    /** The tag of the command it implements. */
    readonly name: string;
    readonly command: CommandClass;
    /** The aggregate behind each name in `reads`. */
    readonly aggs: Readonly<Record<string, Agg>>;
    /** The names of its own transitions. */
    readonly own: ReadonlyArray<string>;
}
interface PolicyImpl {
    readonly name: string;
    readonly from: unknown;
    readonly on: ReadonlyArray<unknown>;
    readonly module: Module;
    /** The handler's construction: the argument of `toLayer`. */
    readonly node: Node;
    /**
     * The aggregates its handler names, so may send to: `undefined` when it
     * names a saga, whose steps may send to any.
     */
    readonly writes: ReadonlySet<unknown> | undefined;
}
interface SagaClass {
    readonly sagaName: string;
    readonly definition: {
        readonly rejects?: ReadonlyArray<{
            readonly tag: string;
        }>;
    };
    readonly withCompensation: unknown;
}
interface SagaImpl {
    readonly name: string;
    readonly cls: SagaClass;
    /** The rejections a run may end in. */
    readonly rejects: ReadonlyArray<string>;
    readonly module: Module;
    /** The handler's construction: the argument of `toLayer`. */
    readonly node: Node;
}
/**
 * The sequence a story is the start of, with everything the model did after
 * the story's last command: a story is cut where what it shows happened.
 */
export declare const whole: (story: Story) => Story;
/**
 * Read the files a model's file imports, and find in them each aggregate's
 * definition and each policy's handler.
 */
export declare const locate: (loader: Source.Loader, interpreter: Interpreter, model: ModelLike, file: string) => Effect.Effect<{
    aggregates: Agg[];
    decisions: Decided[];
    missing: string[];
    unread: string[];
    policies: PolicyImpl[];
    sagas: SagaImpl[];
    skipped: Skipped[];
    aside: Aside[];
    rules: {
        definition: Paths.Definition | undefined;
        names: string[];
        relations: (Relations.Relation & {
            readonly aggs: ReadonlyArray<Agg>;
        })[];
        real: {
            [x: string]: ((world: unknown) => boolean) | ((model: unknown) => boolean);
        };
        later: readonly string[];
        realLater: Record<string, (model: unknown) => boolean>;
        possible: readonly string[];
        realPossible: Record<string, (model: unknown) => boolean>;
    };
    views: ViewImpl[];
}, Source.LoadError, never>;
export type Located = Effect.Success<ReturnType<typeof locate>>;
/**
 * Run every sequence of commands callers can send, up to `depth` of them, on
 * a model with nothing in it. After each command the policies react, and their
 * commands run before the next one a caller sends.
 */
export declare const search: (solver: Smt.Solver, interpreter: Interpreter, located: {
    aggregates: Agg[];
    decisions: Decided[];
    missing: string[];
    unread: string[];
    policies: PolicyImpl[];
    sagas: SagaImpl[];
    skipped: Skipped[];
    aside: Aside[];
    rules: {
        definition: Paths.Definition | undefined;
        names: string[];
        relations: (Relations.Relation & {
            readonly aggs: ReadonlyArray<Agg>;
        })[];
        real: {
            [x: string]: ((world: unknown) => boolean) | ((model: unknown) => boolean);
        };
        later: readonly string[];
        realLater: Record<string, (model: unknown) => boolean>;
        possible: readonly string[];
        realPossible: Record<string, (model: unknown) => boolean>;
    };
    views: ViewImpl[];
}, external: readonly unknown[], options: Options) => Effect.Effect<Found, Smt.SolverError, never>;
export {};
//# sourceMappingURL=ModelSearch.d.ts.map