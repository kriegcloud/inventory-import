import * as Layer from "effect/Layer";
export declare const TelemetryMetrics: {
    /** Records `rpc.client.call.duration` for every distilled call it is provided to. */
    readonly layer: Layer.Layer<never>;
};
//# sourceMappingURL=telemetry-metrics.d.ts.map