import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DuplicateResourceException_base: S.TaggedErrorClass<"DuplicateResourceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateResourceException extends /*@__PURE__*/ DuplicateResourceException_base {
}
declare const InternalServiceError_base: S.TaggedErrorClass<"InternalServiceError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceError extends /*@__PURE__*/ InternalServiceError_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceQuotaExceededException_base: S.TaggedErrorClass<"ResourceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ResourceQuotaExceededException extends /*@__PURE__*/ ResourceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type ApplicationName = string;
export type ApplicationNamespace = string;
export type Description = string;
export type URL = string;
export type ApplicationTrustedSource = string;
export type ApplicationApprovedOrigins = string[];
export interface ExternalUrlConfig {
    AccessUrl: string;
    ApprovedOrigins?: string[] | undefined;
}
export interface ApplicationSourceConfig {
    ExternalUrlConfig?: ExternalUrlConfig | undefined;
}
export type EventName = string;
export interface Subscription {
    Event: string;
    Description?: string | undefined;
}
export type SubscriptionList = Subscription[];
export type EventDefinitionSchema = string;
export interface Publication {
    Event: string;
    Schema: string;
    Description?: string | undefined;
}
export type PublicationList = Publication[];
export type IdempotencyToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type Permission = string;
export type PermissionList = string[];
export type InitializationTimeout = number;
export type ContactHandlingScope = "CROSS_CONTACTS" | "PER_CONTACT" | (string & {});
export interface ContactHandling {
    Scope?: ContactHandlingScope | undefined;
}
export interface ApplicationConfig {
    ContactHandling?: ContactHandling | undefined;
}
export type IframePermission = string;
export type IframePermissionList = string[];
export interface IframeConfig {
    Allow?: string[] | undefined;
    Sandbox?: string[] | undefined;
}
export type ApplicationType = "STANDARD" | "SERVICE" | "MCP_SERVER" | "A2A_SERVER" | (string & {});
export type AuthType = "API_KEY" | "CONNECT_JWT" | (string & {});
export type Arn = string;
export type Identifier = string;
export interface AuthConfig {
    AuthType?: AuthType | undefined;
    CredentialProviderIdentifier?: string | undefined;
    AudienceOverride?: string | undefined;
}
export interface CreateApplicationRequest {
    Name: string;
    Namespace: string;
    Description?: string | undefined;
    ApplicationSourceConfig: ApplicationSourceConfig;
    Subscriptions?: Subscription[] | undefined;
    Publications?: Publication[] | undefined;
    ClientToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Permissions?: string[] | undefined;
    IsService?: boolean | undefined;
    InitializationTimeout?: number | undefined;
    ApplicationConfig?: ApplicationConfig | undefined;
    IframeConfig?: IframeConfig | undefined;
    ApplicationType?: ApplicationType | undefined;
    AuthConfig?: AuthConfig | undefined;
}
export type UUID = string;
export interface CreateApplicationResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
}
export type Name = string;
export type NonBlankString = string;
export type SourceURI = string;
export interface ScheduleConfiguration {
    FirstExecutionFrom?: string | undefined;
    Object?: string | undefined;
    ScheduleExpression: string;
}
export type NonBlankLongString = string;
export type FolderList = string[];
export type Fields = string;
export type FieldsList = string[];
export type FieldsMap = {
    [key: string]: string[] | undefined;
};
export interface FileConfiguration {
    Folders: string[];
    Filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type ObjectConfiguration = {
    [key: string]: {
        [key: string]: string[] | undefined;
    } | undefined;
};
export interface CreateDataIntegrationRequest {
    Name: string;
    Description?: string | undefined;
    KmsKey: string;
    SourceURI?: string | undefined;
    ScheduleConfig?: ScheduleConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
    FileConfiguration?: FileConfiguration | undefined;
    ObjectConfiguration?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    } | undefined;
}
export interface CreateDataIntegrationResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    KmsKey?: string | undefined;
    SourceURI?: string | undefined;
    ScheduleConfiguration?: ScheduleConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
    FileConfiguration?: FileConfiguration | undefined;
    ObjectConfiguration?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    } | undefined;
}
export type ClientId = string;
export type DestinationURI = string;
export type ClientAssociationMetadata = {
    [key: string]: string | undefined;
};
export type ExecutionMode = "ON_DEMAND" | "SCHEDULED" | (string & {});
export interface OnDemandConfiguration {
    StartTime: string;
    EndTime?: string | undefined;
}
export interface ExecutionConfiguration {
    ExecutionMode: ExecutionMode;
    OnDemandConfiguration?: OnDemandConfiguration | undefined;
    ScheduleConfiguration?: ScheduleConfiguration | undefined;
}
export interface CreateDataIntegrationAssociationRequest {
    DataIntegrationIdentifier: string;
    ClientId?: string | undefined;
    ObjectConfiguration?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    } | undefined;
    DestinationURI?: string | undefined;
    ClientAssociationMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
    ExecutionConfiguration?: ExecutionConfiguration | undefined;
}
export interface CreateDataIntegrationAssociationResponse {
    DataIntegrationAssociationId?: string | undefined;
    DataIntegrationArn?: string | undefined;
}
export type Source = string;
export interface EventFilter {
    Source: string;
}
export type EventBridgeBus = string;
export interface CreateEventIntegrationRequest {
    Name: string;
    Description?: string | undefined;
    EventFilter: EventFilter;
    EventBridgeBus: string;
    ClientToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateEventIntegrationResponse {
    EventIntegrationArn?: string | undefined;
}
export type ArnOrUUID = string;
export interface DeleteApplicationRequest {
    Arn: string;
    Force?: boolean | undefined;
}
export interface DeleteApplicationResponse {
}
export interface DeleteDataIntegrationRequest {
    DataIntegrationIdentifier: string;
}
export interface DeleteDataIntegrationResponse {
}
export interface DeleteEventIntegrationRequest {
    Name: string;
}
export interface DeleteEventIntegrationResponse {
}
export interface GetApplicationRequest {
    Arn: string;
}
export type RegionName = string;
export interface GetApplicationResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Namespace?: string | undefined;
    Description?: string | undefined;
    ApplicationSourceConfig?: ApplicationSourceConfig | undefined;
    Subscriptions?: Subscription[] | undefined;
    Publications?: Publication[] | undefined;
    CreatedTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedRegion?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Permissions?: string[] | undefined;
    IsService?: boolean | undefined;
    InitializationTimeout?: number | undefined;
    ApplicationConfig?: ApplicationConfig | undefined;
    IframeConfig?: IframeConfig | undefined;
    ApplicationType?: ApplicationType | undefined;
    AuthConfig?: AuthConfig | undefined;
}
export interface GetDataIntegrationRequest {
    Identifier: string;
}
export interface GetDataIntegrationResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    KmsKey?: string | undefined;
    SourceURI?: string | undefined;
    ScheduleConfiguration?: ScheduleConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    FileConfiguration?: FileConfiguration | undefined;
    ObjectConfiguration?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    } | undefined;
}
export interface GetEventIntegrationRequest {
    Name: string;
}
export interface GetEventIntegrationResponse {
    Name?: string | undefined;
    Description?: string | undefined;
    EventIntegrationArn?: string | undefined;
    EventBridgeBus?: string | undefined;
    EventFilter?: EventFilter | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListApplicationAssociationsRequest {
    ApplicationId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ApplicationAssociationSummary {
    ApplicationAssociationArn?: string | undefined;
    ApplicationArn?: string | undefined;
    ClientId?: string | undefined;
}
export type ApplicationAssociationsList = ApplicationAssociationSummary[];
export interface ListApplicationAssociationsResponse {
    ApplicationAssociations?: ApplicationAssociationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListApplicationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ApplicationType?: ApplicationType | undefined;
}
export interface ApplicationSummary {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Namespace?: string | undefined;
    CreatedTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastModifiedRegion?: string | undefined;
    IsService?: boolean | undefined;
    ApplicationType?: ApplicationType | undefined;
}
export type ApplicationsList = ApplicationSummary[];
export interface ListApplicationsResponse {
    Applications?: ApplicationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDataIntegrationAssociationsRequest {
    DataIntegrationIdentifier: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ExecutionStatus = "COMPLETED" | "IN_PROGRESS" | "FAILED" | (string & {});
export interface LastExecutionStatus {
    ExecutionStatus?: ExecutionStatus | undefined;
    StatusMessage?: string | undefined;
}
export interface DataIntegrationAssociationSummary {
    DataIntegrationAssociationArn?: string | undefined;
    DataIntegrationArn?: string | undefined;
    ClientId?: string | undefined;
    DestinationURI?: string | undefined;
    LastExecutionStatus?: LastExecutionStatus | undefined;
    ExecutionConfiguration?: ExecutionConfiguration | undefined;
}
export type DataIntegrationAssociationsList = DataIntegrationAssociationSummary[];
export interface ListDataIntegrationAssociationsResponse {
    DataIntegrationAssociations?: DataIntegrationAssociationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDataIntegrationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DataIntegrationSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
    SourceURI?: string | undefined;
}
export type DataIntegrationsList = DataIntegrationSummary[];
export interface ListDataIntegrationsResponse {
    DataIntegrations?: DataIntegrationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventIntegrationAssociationsRequest {
    EventIntegrationName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type EventBridgeRuleName = string;
export interface EventIntegrationAssociation {
    EventIntegrationAssociationArn?: string | undefined;
    EventIntegrationAssociationId?: string | undefined;
    EventIntegrationName?: string | undefined;
    ClientId?: string | undefined;
    EventBridgeRuleName?: string | undefined;
    ClientAssociationMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EventIntegrationAssociationsList = EventIntegrationAssociation[];
export interface ListEventIntegrationAssociationsResponse {
    EventIntegrationAssociations?: EventIntegrationAssociation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventIntegrationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface EventIntegration {
    EventIntegrationArn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    EventFilter?: EventFilter | undefined;
    EventBridgeBus?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EventIntegrationsList = EventIntegration[];
export interface ListEventIntegrationsResponse {
    EventIntegrations?: EventIntegration[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApplicationRequest {
    Arn: string;
    Name?: string | undefined;
    Description?: string | undefined;
    ApplicationSourceConfig?: ApplicationSourceConfig | undefined;
    Subscriptions?: Subscription[] | undefined;
    Publications?: Publication[] | undefined;
    Permissions?: string[] | undefined;
    IsService?: boolean | undefined;
    InitializationTimeout?: number | undefined;
    ApplicationConfig?: ApplicationConfig | undefined;
    IframeConfig?: IframeConfig | undefined;
    ApplicationType?: ApplicationType | undefined;
    AuthConfig?: AuthConfig | undefined;
}
export interface UpdateApplicationResponse {
}
export interface UpdateDataIntegrationRequest {
    Identifier: string;
    Name?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateDataIntegrationResponse {
}
export interface UpdateDataIntegrationAssociationRequest {
    DataIntegrationIdentifier: string;
    DataIntegrationAssociationIdentifier: string;
    ExecutionConfiguration: ExecutionConfiguration;
}
export interface UpdateDataIntegrationAssociationResponse {
}
export interface UpdateEventIntegrationRequest {
    Name: string;
    Description?: string | undefined;
}
export interface UpdateEventIntegrationResponse {
}
export type Message = string;
export type CreateApplicationError = AccessDeniedException | DuplicateResourceException | InternalServiceError | InvalidRequestException | ResourceQuotaExceededException | ThrottlingException | UnsupportedOperationException | TooManyRequestsException | CommonErrors;
/**
 * Creates and persists an Application resource.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDataIntegrationError = AccessDeniedException | DuplicateResourceException | InternalServiceError | InvalidRequestException | ResourceQuotaExceededException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Creates and persists a DataIntegration resource.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been
 * previously associated. Use a different DataIntegration, or recreate the DataIntegration
 * using the `CreateDataIntegration` API.
 */
export declare const createDataIntegration: API.OperationMethod<CreateDataIntegrationRequest & RegionInput, CreateDataIntegrationResponse, CreateDataIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateDataIntegrationAssociationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ResourceQuotaExceededException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Creates and persists a DataIntegrationAssociation resource.
 */
export declare const createDataIntegrationAssociation: API.OperationMethod<CreateDataIntegrationAssociationRequest & RegionInput, CreateDataIntegrationAssociationResponse, CreateDataIntegrationAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateEventIntegrationError = AccessDeniedException | DuplicateResourceException | InternalServiceError | InvalidRequestException | ResourceQuotaExceededException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Creates an EventIntegration, given a specified name, description, and a reference to an
 * Amazon EventBridge bus in your account and a partner event source that pushes events to
 * that bus. No objects are created in the your account, only metadata that is persisted on the
 * EventIntegration control plane.
 */
export declare const createEventIntegration: API.OperationMethod<CreateEventIntegrationRequest & RegionInput, CreateEventIntegrationResponse, CreateEventIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an application. If the application has associations, you must delete them first.
 * Alternatively, use the `force` option to delete the application and remove its
 * associations.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the DataIntegration. Only DataIntegrations that don't have any
 * DataIntegrationAssociations can be deleted. Deleting a DataIntegration also deletes the
 * underlying Amazon AppFlow flow and service linked role.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const deleteDataIntegration: API.OperationMethod<DeleteDataIntegrationRequest & RegionInput, DeleteDataIntegrationResponse, DeleteDataIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteEventIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified existing event integration. If the event integration is associated
 * with clients, the request is rejected.
 */
export declare const deleteEventIntegration: API.OperationMethod<DeleteEventIntegrationRequest & RegionInput, DeleteEventIntegrationResponse, DeleteEventIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Get an Application resource.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest & RegionInput, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetDataIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about the DataIntegration.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const getDataIntegration: API.OperationMethod<GetDataIntegrationRequest & RegionInput, GetDataIntegrationResponse, GetDataIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetEventIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about the event integration.
 */
export declare const getEventIntegration: API.OperationMethod<GetEventIntegrationRequest & RegionInput, GetEventIntegrationResponse, GetEventIntegrationError, Credentials | HttpClient.HttpClient>;
export type ListApplicationAssociationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of application associations for an application.
 */
export declare const listApplicationAssociations: API.PaginatedOperationMethod<ListApplicationAssociationsRequest & RegionInput, ListApplicationAssociationsResponse, ListApplicationAssociationsError, Credentials | HttpClient.HttpClient, ApplicationAssociationSummary>;
export type ListApplicationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Lists applications in the account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListDataIntegrationAssociationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of DataIntegration associations in the account.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const listDataIntegrationAssociations: API.PaginatedOperationMethod<ListDataIntegrationAssociationsRequest & RegionInput, ListDataIntegrationAssociationsResponse, ListDataIntegrationAssociationsError, Credentials | HttpClient.HttpClient, DataIntegrationAssociationSummary>;
export type ListDataIntegrationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of DataIntegrations in the account.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const listDataIntegrations: API.PaginatedOperationMethod<ListDataIntegrationsRequest & RegionInput, ListDataIntegrationsResponse, ListDataIntegrationsError, Credentials | HttpClient.HttpClient, DataIntegrationSummary>;
export type ListEventIntegrationAssociationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of event integration associations in the account.
 */
export declare const listEventIntegrationAssociations: API.PaginatedOperationMethod<ListEventIntegrationAssociationsRequest & RegionInput, ListEventIntegrationAssociationsResponse, ListEventIntegrationAssociationsError, Credentials | HttpClient.HttpClient, EventIntegrationAssociation>;
export type ListEventIntegrationsError = AccessDeniedException | InternalServiceError | InvalidRequestException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of event integrations in the account.
 */
export declare const listEventIntegrations: API.PaginatedOperationMethod<ListEventIntegrationsRequest & RegionInput, ListEventIntegrationsResponse, ListEventIntegrationsError, Credentials | HttpClient.HttpClient, EventIntegration>;
export type ListTagsForResourceError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AccessDeniedException | ConflictException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnsupportedOperationException | TooManyRequestsException | CommonErrors;
/**
 * Updates and persists an Application resource.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Updates the description of a DataIntegration.
 *
 * You cannot create a DataIntegration association for a DataIntegration that has been previously associated.
 * Use a different DataIntegration, or recreate the DataIntegration using the
 * CreateDataIntegration API.
 */
export declare const updateDataIntegration: API.OperationMethod<UpdateDataIntegrationRequest & RegionInput, UpdateDataIntegrationResponse, UpdateDataIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataIntegrationAssociationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Updates and persists a DataIntegrationAssociation resource.
 *
 * Updating a DataIntegrationAssociation with ExecutionConfiguration will rerun the on-demand job.
 */
export declare const updateDataIntegrationAssociation: API.OperationMethod<UpdateDataIntegrationAssociationRequest & RegionInput, UpdateDataIntegrationAssociationResponse, UpdateDataIntegrationAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateEventIntegrationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | TooManyRequestsException | CommonErrors;
/**
 * Updates the description of an event integration.
 */
export declare const updateEventIntegration: API.OperationMethod<UpdateEventIntegrationRequest & RegionInput, UpdateEventIntegrationResponse, UpdateEventIntegrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appintegrations.d.ts.map