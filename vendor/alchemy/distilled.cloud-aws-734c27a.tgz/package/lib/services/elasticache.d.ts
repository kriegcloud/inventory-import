import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const APICallRateForCustomerExceededFault_base: S.TaggedErrorClass<"APICallRateForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class APICallRateForCustomerExceededFault extends /*@__PURE__*/ APICallRateForCustomerExceededFault_base {
}
declare const AuthorizationAlreadyExistsFault_base: S.TaggedErrorClass<"AuthorizationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AuthorizationAlreadyExistsFault extends /*@__PURE__*/ AuthorizationAlreadyExistsFault_base {
}
declare const AuthorizationNotFoundFault_base: S.TaggedErrorClass<"AuthorizationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationNotFoundFault extends /*@__PURE__*/ AuthorizationNotFoundFault_base {
}
declare const CacheClusterAlreadyExistsFault_base: S.TaggedErrorClass<"CacheClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheClusterAlreadyExistsFault extends /*@__PURE__*/ CacheClusterAlreadyExistsFault_base {
}
declare const CacheClusterNotFoundFault_base: S.TaggedErrorClass<"CacheClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheClusterNotFoundFault extends /*@__PURE__*/ CacheClusterNotFoundFault_base {
}
declare const CacheParameterGroupAlreadyExistsFault_base: S.TaggedErrorClass<"CacheParameterGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheParameterGroupAlreadyExistsFault extends /*@__PURE__*/ CacheParameterGroupAlreadyExistsFault_base {
}
declare const CacheParameterGroupNotFoundFault_base: S.TaggedErrorClass<"CacheParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheParameterGroupNotFoundFault extends /*@__PURE__*/ CacheParameterGroupNotFoundFault_base {
}
declare const CacheParameterGroupQuotaExceededFault_base: S.TaggedErrorClass<"CacheParameterGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheParameterGroupQuotaExceededFault extends /*@__PURE__*/ CacheParameterGroupQuotaExceededFault_base {
}
declare const CacheSecurityGroupAlreadyExistsFault_base: S.TaggedErrorClass<"CacheSecurityGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheSecurityGroupAlreadyExistsFault extends /*@__PURE__*/ CacheSecurityGroupAlreadyExistsFault_base {
}
declare const CacheSecurityGroupNotFoundFault_base: S.TaggedErrorClass<"CacheSecurityGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSecurityGroupNotFoundFault extends /*@__PURE__*/ CacheSecurityGroupNotFoundFault_base {
}
declare const CacheSecurityGroupQuotaExceededFault_base: S.TaggedErrorClass<"CacheSecurityGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSecurityGroupQuotaExceededFault extends /*@__PURE__*/ CacheSecurityGroupQuotaExceededFault_base {
}
declare const CacheSubnetGroupAlreadyExistsFault_base: S.TaggedErrorClass<"CacheSubnetGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheSubnetGroupAlreadyExistsFault extends /*@__PURE__*/ CacheSubnetGroupAlreadyExistsFault_base {
}
declare const CacheSubnetGroupInUse_base: S.TaggedErrorClass<"CacheSubnetGroupInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CacheSubnetGroupInUse extends /*@__PURE__*/ CacheSubnetGroupInUse_base {
}
declare const CacheSubnetGroupNotFoundFault_base: S.TaggedErrorClass<"CacheSubnetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetGroupNotFoundFault extends /*@__PURE__*/ CacheSubnetGroupNotFoundFault_base {
}
declare const CacheSubnetGroupQuotaExceededFault_base: S.TaggedErrorClass<"CacheSubnetGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetGroupQuotaExceededFault extends /*@__PURE__*/ CacheSubnetGroupQuotaExceededFault_base {
}
declare const CacheSubnetQuotaExceededFault_base: S.TaggedErrorClass<"CacheSubnetQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetQuotaExceededFault extends /*@__PURE__*/ CacheSubnetQuotaExceededFault_base {
}
declare const ClusterQuotaForCustomerExceededFault_base: S.TaggedErrorClass<"ClusterQuotaForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterQuotaForCustomerExceededFault extends /*@__PURE__*/ ClusterQuotaForCustomerExceededFault_base {
}
declare const DefaultUserAssociatedToUserGroupFault_base: S.TaggedErrorClass<"DefaultUserAssociatedToUserGroupFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DefaultUserAssociatedToUserGroupFault extends /*@__PURE__*/ DefaultUserAssociatedToUserGroupFault_base {
}
declare const DefaultUserRequired_base: S.TaggedErrorClass<"DefaultUserRequired", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DefaultUserRequired extends /*@__PURE__*/ DefaultUserRequired_base {
}
declare const DuplicateUserNameFault_base: S.TaggedErrorClass<"DuplicateUserNameFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateUserNameFault extends /*@__PURE__*/ DuplicateUserNameFault_base {
}
declare const GlobalReplicationGroupAlreadyExistsFault_base: S.TaggedErrorClass<"GlobalReplicationGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalReplicationGroupAlreadyExistsFault extends /*@__PURE__*/ GlobalReplicationGroupAlreadyExistsFault_base {
}
declare const GlobalReplicationGroupNotFoundFault_base: S.TaggedErrorClass<"GlobalReplicationGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalReplicationGroupNotFoundFault extends /*@__PURE__*/ GlobalReplicationGroupNotFoundFault_base {
}
declare const InsufficientCacheClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientCacheClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientCacheClusterCapacityFault extends /*@__PURE__*/ InsufficientCacheClusterCapacityFault_base {
}
declare const InvalidARNFault_base: S.TaggedErrorClass<"InvalidARNFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidARNFault extends /*@__PURE__*/ InvalidARNFault_base {
}
declare const InvalidCacheClusterStateFault_base: S.TaggedErrorClass<"InvalidCacheClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheClusterStateFault extends /*@__PURE__*/ InvalidCacheClusterStateFault_base {
}
declare const InvalidCacheParameterGroupStateFault_base: S.TaggedErrorClass<"InvalidCacheParameterGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheParameterGroupStateFault extends /*@__PURE__*/ InvalidCacheParameterGroupStateFault_base {
}
declare const InvalidCacheSecurityGroupStateFault_base: S.TaggedErrorClass<"InvalidCacheSecurityGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheSecurityGroupStateFault extends /*@__PURE__*/ InvalidCacheSecurityGroupStateFault_base {
}
declare const InvalidCredentialsException_base: S.TaggedErrorClass<"InvalidCredentialsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class InvalidCredentialsException extends /*@__PURE__*/ InvalidCredentialsException_base {
}
declare const InvalidGlobalReplicationGroupStateFault_base: S.TaggedErrorClass<"InvalidGlobalReplicationGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGlobalReplicationGroupStateFault extends /*@__PURE__*/ InvalidGlobalReplicationGroupStateFault_base {
}
declare const InvalidKMSKeyFault_base: S.TaggedErrorClass<"InvalidKMSKeyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidKMSKeyFault extends /*@__PURE__*/ InvalidKMSKeyFault_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidReplicationGroupStateFault_base: S.TaggedErrorClass<"InvalidReplicationGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidReplicationGroupStateFault extends /*@__PURE__*/ InvalidReplicationGroupStateFault_base {
}
declare const InvalidServerlessCacheSnapshotStateFault_base: S.TaggedErrorClass<"InvalidServerlessCacheSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidServerlessCacheSnapshotStateFault extends /*@__PURE__*/ InvalidServerlessCacheSnapshotStateFault_base {
}
declare const InvalidServerlessCacheStateFault_base: S.TaggedErrorClass<"InvalidServerlessCacheStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidServerlessCacheStateFault extends /*@__PURE__*/ InvalidServerlessCacheStateFault_base {
}
declare const InvalidSnapshotStateFault_base: S.TaggedErrorClass<"InvalidSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnapshotStateFault extends /*@__PURE__*/ InvalidSnapshotStateFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidUserGroupStateFault_base: S.TaggedErrorClass<"InvalidUserGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserGroupStateFault extends /*@__PURE__*/ InvalidUserGroupStateFault_base {
}
declare const InvalidUserStateFault_base: S.TaggedErrorClass<"InvalidUserStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserStateFault extends /*@__PURE__*/ InvalidUserStateFault_base {
}
declare const InvalidVPCNetworkStateFault_base: S.TaggedErrorClass<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const MigrationHealthFault_base: S.TaggedErrorClass<"MigrationHealthFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MigrationHealthFault extends /*@__PURE__*/ MigrationHealthFault_base {
}
declare const NodeGroupNotFoundFault_base: S.TaggedErrorClass<"NodeGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeGroupNotFoundFault extends /*@__PURE__*/ NodeGroupNotFoundFault_base {
}
declare const NodeGroupsPerReplicationGroupQuotaExceededFault_base: S.TaggedErrorClass<"NodeGroupsPerReplicationGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeGroupsPerReplicationGroupQuotaExceededFault extends /*@__PURE__*/ NodeGroupsPerReplicationGroupQuotaExceededFault_base {
}
declare const NodeQuotaForClusterExceededFault_base: S.TaggedErrorClass<"NodeQuotaForClusterExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForClusterExceededFault extends /*@__PURE__*/ NodeQuotaForClusterExceededFault_base {
}
declare const NodeQuotaForCustomerExceededFault_base: S.TaggedErrorClass<"NodeQuotaForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForCustomerExceededFault extends /*@__PURE__*/ NodeQuotaForCustomerExceededFault_base {
}
declare const NoOperationFault_base: S.TaggedErrorClass<"NoOperationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoOperationFault extends /*@__PURE__*/ NoOperationFault_base {
}
declare const ReplicationGroupAlreadyExistsFault_base: S.TaggedErrorClass<"ReplicationGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReplicationGroupAlreadyExistsFault extends /*@__PURE__*/ ReplicationGroupAlreadyExistsFault_base {
}
declare const ReplicationGroupAlreadyUnderMigrationFault_base: S.TaggedErrorClass<"ReplicationGroupAlreadyUnderMigrationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupAlreadyUnderMigrationFault extends /*@__PURE__*/ ReplicationGroupAlreadyUnderMigrationFault_base {
}
declare const ReplicationGroupNotFoundFault_base: S.TaggedErrorClass<"ReplicationGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupNotFoundFault extends /*@__PURE__*/ ReplicationGroupNotFoundFault_base {
}
declare const ReplicationGroupNotUnderMigrationFault_base: S.TaggedErrorClass<"ReplicationGroupNotUnderMigrationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupNotUnderMigrationFault extends /*@__PURE__*/ ReplicationGroupNotUnderMigrationFault_base {
}
declare const ReservedCacheNodeAlreadyExistsFault_base: S.TaggedErrorClass<"ReservedCacheNodeAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReservedCacheNodeAlreadyExistsFault extends /*@__PURE__*/ ReservedCacheNodeAlreadyExistsFault_base {
}
declare const ReservedCacheNodeNotFoundFault_base: S.TaggedErrorClass<"ReservedCacheNodeNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodeNotFoundFault extends /*@__PURE__*/ ReservedCacheNodeNotFoundFault_base {
}
declare const ReservedCacheNodeQuotaExceededFault_base: S.TaggedErrorClass<"ReservedCacheNodeQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodeQuotaExceededFault extends /*@__PURE__*/ ReservedCacheNodeQuotaExceededFault_base {
}
declare const ReservedCacheNodesOfferingNotFoundFault_base: S.TaggedErrorClass<"ReservedCacheNodesOfferingNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodesOfferingNotFoundFault extends /*@__PURE__*/ ReservedCacheNodesOfferingNotFoundFault_base {
}
declare const ServerlessCacheAlreadyExistsFault_base: S.TaggedErrorClass<"ServerlessCacheAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ServerlessCacheAlreadyExistsFault extends /*@__PURE__*/ ServerlessCacheAlreadyExistsFault_base {
}
declare const ServerlessCacheAlreadyUnderMigrationFault_base: S.TaggedErrorClass<"ServerlessCacheAlreadyUnderMigrationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheAlreadyUnderMigrationFault extends /*@__PURE__*/ ServerlessCacheAlreadyUnderMigrationFault_base {
}
declare const ServerlessCacheNotFoundFault_base: S.TaggedErrorClass<"ServerlessCacheNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheNotFoundFault extends /*@__PURE__*/ ServerlessCacheNotFoundFault_base {
}
declare const ServerlessCacheNotUnderMigrationFault_base: S.TaggedErrorClass<"ServerlessCacheNotUnderMigrationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheNotUnderMigrationFault extends /*@__PURE__*/ ServerlessCacheNotUnderMigrationFault_base {
}
declare const ServerlessCacheQuotaForCustomerExceededFault_base: S.TaggedErrorClass<"ServerlessCacheQuotaForCustomerExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheQuotaForCustomerExceededFault extends /*@__PURE__*/ ServerlessCacheQuotaForCustomerExceededFault_base {
}
declare const ServerlessCacheSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"ServerlessCacheSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ServerlessCacheSnapshotAlreadyExistsFault extends /*@__PURE__*/ ServerlessCacheSnapshotAlreadyExistsFault_base {
}
declare const ServerlessCacheSnapshotNotFoundFault_base: S.TaggedErrorClass<"ServerlessCacheSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheSnapshotNotFoundFault extends /*@__PURE__*/ ServerlessCacheSnapshotNotFoundFault_base {
}
declare const ServerlessCacheSnapshotQuotaExceededFault_base: S.TaggedErrorClass<"ServerlessCacheSnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheSnapshotQuotaExceededFault extends /*@__PURE__*/ ServerlessCacheSnapshotQuotaExceededFault_base {
}
declare const ServiceLinkedRoleNotFoundFault_base: S.TaggedErrorClass<"ServiceLinkedRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceLinkedRoleNotFoundFault extends /*@__PURE__*/ ServiceLinkedRoleNotFoundFault_base {
}
declare const ServiceUpdateNotFoundFault_base: S.TaggedErrorClass<"ServiceUpdateNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceUpdateNotFoundFault extends /*@__PURE__*/ ServiceUpdateNotFoundFault_base {
}
declare const SnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"SnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SnapshotAlreadyExistsFault extends /*@__PURE__*/ SnapshotAlreadyExistsFault_base {
}
declare const SnapshotFeatureNotSupportedFault_base: S.TaggedErrorClass<"SnapshotFeatureNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotFeatureNotSupportedFault extends /*@__PURE__*/ SnapshotFeatureNotSupportedFault_base {
}
declare const SnapshotNotFoundFault_base: S.TaggedErrorClass<"SnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotNotFoundFault extends /*@__PURE__*/ SnapshotNotFoundFault_base {
}
declare const SnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotQuotaExceededFault extends /*@__PURE__*/ SnapshotQuotaExceededFault_base {
}
declare const SubnetInUse_base: S.TaggedErrorClass<"SubnetInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetInUse extends /*@__PURE__*/ SubnetInUse_base {
}
declare const SubnetNotAllowedFault_base: S.TaggedErrorClass<"SubnetNotAllowedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetNotAllowedFault extends /*@__PURE__*/ SubnetNotAllowedFault_base {
}
declare const TagNotFoundFault_base: S.TaggedErrorClass<"TagNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagNotFoundFault extends /*@__PURE__*/ TagNotFoundFault_base {
}
declare const TagQuotaPerResourceExceeded_base: S.TaggedErrorClass<"TagQuotaPerResourceExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagQuotaPerResourceExceeded extends /*@__PURE__*/ TagQuotaPerResourceExceeded_base {
}
declare const TestFailoverNotAvailableFault_base: S.TaggedErrorClass<"TestFailoverNotAvailableFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TestFailoverNotAvailableFault extends /*@__PURE__*/ TestFailoverNotAvailableFault_base {
}
declare const UserAlreadyExistsFault_base: S.TaggedErrorClass<"UserAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class UserAlreadyExistsFault extends /*@__PURE__*/ UserAlreadyExistsFault_base {
}
declare const UserGroupAlreadyExistsFault_base: S.TaggedErrorClass<"UserGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class UserGroupAlreadyExistsFault extends /*@__PURE__*/ UserGroupAlreadyExistsFault_base {
}
declare const UserGroupNotFoundFault_base: S.TaggedErrorClass<"UserGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserGroupNotFoundFault extends /*@__PURE__*/ UserGroupNotFoundFault_base {
}
declare const UserGroupQuotaExceededFault_base: S.TaggedErrorClass<"UserGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserGroupQuotaExceededFault extends /*@__PURE__*/ UserGroupQuotaExceededFault_base {
}
declare const UserNotFoundFault_base: S.TaggedErrorClass<"UserNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotFoundFault extends /*@__PURE__*/ UserNotFoundFault_base {
}
declare const UserQuotaExceededFault_base: S.TaggedErrorClass<"UserQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserQuotaExceededFault extends /*@__PURE__*/ UserQuotaExceededFault_base {
}
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface AddTagsToResourceMessage {
    ResourceName?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface TagListMessage {
    TagList?: Tag[] | undefined;
}
export interface AuthorizeCacheSecurityGroupIngressMessage {
    CacheSecurityGroupName?: string | undefined;
    EC2SecurityGroupName?: string | undefined;
    EC2SecurityGroupOwnerId?: string | undefined;
}
export interface EC2SecurityGroup {
    Status?: string | undefined;
    EC2SecurityGroupName?: string | undefined;
    EC2SecurityGroupOwnerId?: string | undefined;
}
export type EC2SecurityGroupList = EC2SecurityGroup[];
export interface CacheSecurityGroup {
    OwnerId?: string | undefined;
    CacheSecurityGroupName?: string | undefined;
    Description?: string | undefined;
    EC2SecurityGroups?: EC2SecurityGroup[] | undefined;
    ARN?: string | undefined;
}
export interface AuthorizeCacheSecurityGroupIngressResult {
    CacheSecurityGroup?: CacheSecurityGroup | undefined;
}
export type ReplicationGroupIdList = string[];
export type CacheClusterIdList = string[];
export interface BatchApplyUpdateActionMessage {
    ReplicationGroupIds?: string[] | undefined;
    CacheClusterIds?: string[] | undefined;
    ServiceUpdateName?: string | undefined;
}
export type UpdateActionStatus = "not-applied" | "waiting-to-start" | "in-progress" | "stopping" | "stopped" | "complete" | "scheduling" | "scheduled" | "not-applicable" | (string & {});
export interface ProcessedUpdateAction {
    ReplicationGroupId?: string | undefined;
    CacheClusterId?: string | undefined;
    ServiceUpdateName?: string | undefined;
    UpdateActionStatus?: UpdateActionStatus | undefined;
}
export type ProcessedUpdateActionList = ProcessedUpdateAction[];
export interface UnprocessedUpdateAction {
    ReplicationGroupId?: string | undefined;
    CacheClusterId?: string | undefined;
    ServiceUpdateName?: string | undefined;
    ErrorType?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type UnprocessedUpdateActionList = UnprocessedUpdateAction[];
export interface UpdateActionResultsMessage {
    ProcessedUpdateActions?: ProcessedUpdateAction[] | undefined;
    UnprocessedUpdateActions?: UnprocessedUpdateAction[] | undefined;
}
export interface BatchStopUpdateActionMessage {
    ReplicationGroupIds?: string[] | undefined;
    CacheClusterIds?: string[] | undefined;
    ServiceUpdateName?: string | undefined;
}
export interface CompleteMigrationMessage {
    ReplicationGroupId?: string | undefined;
    ServerlessCacheName?: string | undefined;
    Force?: boolean | undefined;
}
export interface GlobalReplicationGroupInfo {
    GlobalReplicationGroupId?: string | undefined;
    GlobalReplicationGroupMemberRole?: string | undefined;
}
export type PendingAutomaticFailoverStatus = "enabled" | "disabled" | (string & {});
export interface SlotMigration {
    ProgressPercentage?: number | undefined;
}
export interface ReshardingStatus {
    SlotMigration?: SlotMigration | undefined;
}
export type AuthTokenUpdateStatus = "SETTING" | "ROTATING" | (string & {});
export type UserGroupId = string;
export type UserGroupIdList = string[];
export interface UserGroupsUpdateStatus {
    UserGroupIdsToAdd?: string[] | undefined;
    UserGroupIdsToRemove?: string[] | undefined;
}
export type LogType = "slow-log" | "engine-log" | (string & {});
export type DestinationType = "cloudwatch-logs" | "kinesis-firehose" | (string & {});
export interface CloudWatchLogsDestinationDetails {
    LogGroup?: string | undefined;
}
export interface KinesisFirehoseDestinationDetails {
    DeliveryStream?: string | undefined;
}
export interface DestinationDetails {
    CloudWatchLogsDetails?: CloudWatchLogsDestinationDetails | undefined;
    KinesisFirehoseDetails?: KinesisFirehoseDestinationDetails | undefined;
}
export type LogFormat = "text" | "json" | (string & {});
export interface PendingLogDeliveryConfiguration {
    LogType?: LogType | undefined;
    DestinationType?: DestinationType | undefined;
    DestinationDetails?: DestinationDetails | undefined;
    LogFormat?: LogFormat | undefined;
}
export type PendingLogDeliveryConfigurationList = PendingLogDeliveryConfiguration[];
export type TransitEncryptionMode = "preferred" | "required" | (string & {});
export type ClusterMode = "enabled" | "disabled" | "compatible" | (string & {});
export interface ReplicationGroupPendingModifiedValues {
    PrimaryClusterId?: string | undefined;
    AutomaticFailoverStatus?: PendingAutomaticFailoverStatus | undefined;
    Resharding?: ReshardingStatus | undefined;
    AuthTokenStatus?: AuthTokenUpdateStatus | undefined;
    UserGroups?: UserGroupsUpdateStatus | undefined;
    LogDeliveryConfigurations?: PendingLogDeliveryConfiguration[] | undefined;
    TransitEncryptionEnabled?: boolean | undefined;
    TransitEncryptionMode?: TransitEncryptionMode | undefined;
    ClusterMode?: ClusterMode | undefined;
}
export type ClusterIdList = string[];
export interface Endpoint {
    Address?: string | undefined;
    Port?: number | undefined;
}
export interface NodeGroupMember {
    CacheClusterId?: string | undefined;
    CacheNodeId?: string | undefined;
    ReadEndpoint?: Endpoint | undefined;
    PreferredAvailabilityZone?: string | undefined;
    PreferredOutpostArn?: string | undefined;
    CurrentRole?: string | undefined;
}
export type NodeGroupMemberList = NodeGroupMember[];
export interface NodeGroup {
    NodeGroupId?: string | undefined;
    Status?: string | undefined;
    PrimaryEndpoint?: Endpoint | undefined;
    ReaderEndpoint?: Endpoint | undefined;
    Slots?: string | undefined;
    NodeGroupMembers?: NodeGroupMember[] | undefined;
}
export type NodeGroupList = NodeGroup[];
export type AutomaticFailoverStatus = "enabled" | "disabled" | "enabling" | "disabling" | (string & {});
export type MultiAZStatus = "enabled" | "disabled" | (string & {});
export type ReplicationGroupOutpostArnList = string[];
export type StorageEncryptionType = "none" | "sse-elasticache" | "sse-kms" | (string & {});
export type LogDeliveryConfigurationStatus = "active" | "enabling" | "modifying" | "disabling" | "error" | (string & {});
export interface LogDeliveryConfiguration {
    LogType?: LogType | undefined;
    DestinationType?: DestinationType | undefined;
    DestinationDetails?: DestinationDetails | undefined;
    LogFormat?: LogFormat | undefined;
    Status?: LogDeliveryConfigurationStatus | undefined;
    Message?: string | undefined;
}
export type LogDeliveryConfigurationList = LogDeliveryConfiguration[];
export type DataTieringStatus = "enabled" | "disabled" | (string & {});
export type NetworkType = "ipv4" | "ipv6" | "dual_stack" | (string & {});
export type IpDiscovery = "ipv4" | "ipv6" | (string & {});
export type Durability = "default" | "async" | "sync" | "disabled" | (string & {});
export type EffectiveDurability = "async" | "sync" | "disabled" | (string & {});
export interface ReplicationGroup {
    ReplicationGroupId?: string | undefined;
    Description?: string | undefined;
    GlobalReplicationGroupInfo?: GlobalReplicationGroupInfo | undefined;
    Status?: string | undefined;
    PendingModifiedValues?: ReplicationGroupPendingModifiedValues | undefined;
    MemberClusters?: string[] | undefined;
    NodeGroups?: NodeGroup[] | undefined;
    SnapshottingClusterId?: string | undefined;
    AutomaticFailover?: AutomaticFailoverStatus | undefined;
    MultiAZ?: MultiAZStatus | undefined;
    ConfigurationEndpoint?: Endpoint | undefined;
    SnapshotRetentionLimit?: number | undefined;
    SnapshotWindow?: string | undefined;
    ClusterEnabled?: boolean | undefined;
    CacheNodeType?: string | undefined;
    AuthTokenEnabled?: boolean | undefined;
    AuthTokenLastModifiedDate?: Date | undefined;
    TransitEncryptionEnabled?: boolean | undefined;
    AtRestEncryptionEnabled?: boolean | undefined;
    MemberClustersOutpostArns?: string[] | undefined;
    KmsKeyId?: string | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    ARN?: string | undefined;
    UserGroupIds?: string[] | undefined;
    LogDeliveryConfigurations?: LogDeliveryConfiguration[] | undefined;
    ReplicationGroupCreateTime?: Date | undefined;
    DataTiering?: DataTieringStatus | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    NetworkType?: NetworkType | undefined;
    IpDiscovery?: IpDiscovery | undefined;
    TransitEncryptionMode?: TransitEncryptionMode | undefined;
    ClusterMode?: ClusterMode | undefined;
    Engine?: string | undefined;
    Durability?: Durability | undefined;
    EffectiveDurability?: EffectiveDurability | undefined;
}
export type DataStorageUnit = "GB" | (string & {});
export interface DataStorage {
    Maximum?: number | undefined;
    Minimum?: number | undefined;
    Unit?: DataStorageUnit | undefined;
}
export interface ECPUPerSecond {
    Maximum?: number | undefined;
    Minimum?: number | undefined;
}
export interface CacheUsageLimits {
    DataStorage?: DataStorage | undefined;
    ECPUPerSecond?: ECPUPerSecond | undefined;
}
export type SecurityGroupIdsList = string[];
export type SubnetIdsList = string[];
export type ConnectionType = "vpc" | "public" | (string & {});
export interface MigrationSummary {
    Status?: string | undefined;
    MigrationEndpoint?: Endpoint | undefined;
    CutoverMode?: string | undefined;
}
export interface ServerlessCache {
    ServerlessCacheName?: string | undefined;
    Description?: string | undefined;
    CreateTime?: Date | undefined;
    Status?: string | undefined;
    Engine?: string | undefined;
    MajorEngineVersion?: string | undefined;
    FullEngineVersion?: string | undefined;
    CacheUsageLimits?: CacheUsageLimits | undefined;
    KmsKeyId?: string | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    SecurityGroupIds?: string[] | undefined;
    Endpoint?: Endpoint | undefined;
    ReaderEndpoint?: Endpoint | undefined;
    ARN?: string | undefined;
    UserGroupId?: string | undefined;
    SubnetIds?: string[] | undefined;
    SnapshotRetentionLimit?: number | undefined;
    DailySnapshotTime?: string | undefined;
    NetworkType?: NetworkType | undefined;
    ConnectionType?: ConnectionType | undefined;
    Migration?: MigrationSummary | undefined;
}
export interface CompleteMigrationResponse {
    ReplicationGroup?: ReplicationGroup | undefined;
    ServerlessCache?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    }) | undefined;
}
export interface CopyServerlessCacheSnapshotRequest {
    SourceServerlessCacheSnapshotName?: string | undefined;
    TargetServerlessCacheSnapshotName?: string | undefined;
    KmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ServerlessCacheConfiguration {
    ServerlessCacheName?: string | undefined;
    Engine?: string | undefined;
    MajorEngineVersion?: string | undefined;
}
export interface ServerlessCacheSnapshot {
    ServerlessCacheSnapshotName?: string | undefined;
    ARN?: string | undefined;
    KmsKeyId?: string | undefined;
    SnapshotType?: string | undefined;
    Status?: string | undefined;
    CreateTime?: Date | undefined;
    ExpiryTime?: Date | undefined;
    BytesUsedForCache?: string | undefined;
    ServerlessCacheConfiguration?: ServerlessCacheConfiguration | undefined;
}
export interface CopyServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot | undefined;
}
export interface CopySnapshotMessage {
    SourceSnapshotName?: string | undefined;
    TargetSnapshotName?: string | undefined;
    TargetBucket?: string | undefined;
    KmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type AllowedNodeGroupId = string;
export type AvailabilityZonesList = string[];
export type OutpostArnsList = string[];
export interface NodeGroupConfiguration {
    NodeGroupId?: string | undefined;
    Slots?: string | undefined;
    ReplicaCount?: number | undefined;
    PrimaryAvailabilityZone?: string | undefined;
    ReplicaAvailabilityZones?: string[] | undefined;
    PrimaryOutpostArn?: string | undefined;
    ReplicaOutpostArns?: string[] | undefined;
}
export interface NodeSnapshot {
    CacheClusterId?: string | undefined;
    NodeGroupId?: string | undefined;
    CacheNodeId?: string | undefined;
    NodeGroupConfiguration?: NodeGroupConfiguration | undefined;
    CacheSize?: string | undefined;
    CacheNodeCreateTime?: Date | undefined;
    SnapshotCreateTime?: Date | undefined;
}
export type NodeSnapshotList = NodeSnapshot[];
export interface Snapshot {
    SnapshotName?: string | undefined;
    ReplicationGroupId?: string | undefined;
    ReplicationGroupDescription?: string | undefined;
    CacheClusterId?: string | undefined;
    SnapshotStatus?: string | undefined;
    SnapshotSource?: string | undefined;
    CacheNodeType?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    NumCacheNodes?: number | undefined;
    PreferredAvailabilityZone?: string | undefined;
    PreferredOutpostArn?: string | undefined;
    CacheClusterCreateTime?: Date | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    TopicArn?: string | undefined;
    Port?: number | undefined;
    CacheParameterGroupName?: string | undefined;
    CacheSubnetGroupName?: string | undefined;
    VpcId?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    SnapshotRetentionLimit?: number | undefined;
    SnapshotWindow?: string | undefined;
    NumNodeGroups?: number | undefined;
    AutomaticFailover?: AutomaticFailoverStatus | undefined;
    NodeSnapshots?: NodeSnapshot[] | undefined;
    KmsKeyId?: string | undefined;
    ARN?: string | undefined;
    DataTiering?: DataTieringStatus | undefined;
    Durability?: Durability | undefined;
}
export interface CopySnapshotResult {
    Snapshot?: Snapshot | undefined;
}
export type AZMode = "single-az" | "cross-az" | (string & {});
export type PreferredAvailabilityZoneList = string[];
export type CacheSecurityGroupNameList = string[];
export type SnapshotArnsList = string[];
export type OutpostMode = "single-outpost" | "cross-outpost" | (string & {});
export type PreferredOutpostArnList = string[];
export interface LogDeliveryConfigurationRequest {
    LogType?: LogType | undefined;
    DestinationType?: DestinationType | undefined;
    DestinationDetails?: DestinationDetails | undefined;
    LogFormat?: LogFormat | undefined;
    Enabled?: boolean | undefined;
}
export type LogDeliveryConfigurationRequestList = LogDeliveryConfigurationRequest[];
export interface CreateCacheClusterMessage {
    CacheClusterId?: string | undefined;
    ReplicationGroupId?: string | undefined;
    AZMode?: AZMode | undefined;
    PreferredAvailabilityZone?: string | undefined;
    PreferredAvailabilityZones?: string[] | undefined;
    NumCacheNodes?: number | undefined;
    CacheNodeType?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    CacheParameterGroupName?: string | undefined;
    CacheSubnetGroupName?: string | undefined;
    CacheSecurityGroupNames?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    SnapshotArns?: string[] | undefined;
    SnapshotName?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    Port?: number | undefined;
    NotificationTopicArn?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    SnapshotRetentionLimit?: number | undefined;
    SnapshotWindow?: string | undefined;
    AuthToken?: string | redacted.Redacted<string> | undefined;
    OutpostMode?: OutpostMode | undefined;
    PreferredOutpostArn?: string | undefined;
    PreferredOutpostArns?: string[] | undefined;
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[] | undefined;
    TransitEncryptionEnabled?: boolean | undefined;
    NetworkType?: NetworkType | undefined;
    IpDiscovery?: IpDiscovery | undefined;
}
export type CacheNodeIdsList = string[];
export interface ScaleConfig {
    ScalePercentage?: number | undefined;
    ScaleIntervalMinutes?: number | undefined;
}
export interface PendingModifiedValues {
    NumCacheNodes?: number | undefined;
    CacheNodeIdsToRemove?: string[] | undefined;
    EngineVersion?: string | undefined;
    CacheNodeType?: string | undefined;
    AuthTokenStatus?: AuthTokenUpdateStatus | undefined;
    LogDeliveryConfigurations?: PendingLogDeliveryConfiguration[] | undefined;
    TransitEncryptionEnabled?: boolean | undefined;
    TransitEncryptionMode?: TransitEncryptionMode | undefined;
    ScaleConfig?: ScaleConfig | undefined;
}
export interface NotificationConfiguration {
    TopicArn?: string | undefined;
    TopicStatus?: string | undefined;
}
export interface CacheSecurityGroupMembership {
    CacheSecurityGroupName?: string | undefined;
    Status?: string | undefined;
}
export type CacheSecurityGroupMembershipList = CacheSecurityGroupMembership[];
export interface CacheParameterGroupStatus {
    CacheParameterGroupName?: string | undefined;
    ParameterApplyStatus?: string | undefined;
    CacheNodeIdsToReboot?: string[] | undefined;
}
export interface CacheNode {
    CacheNodeId?: string | undefined;
    CacheNodeStatus?: string | undefined;
    CacheNodeCreateTime?: Date | undefined;
    Endpoint?: Endpoint | undefined;
    ParameterGroupStatus?: string | undefined;
    SourceCacheNodeId?: string | undefined;
    CustomerAvailabilityZone?: string | undefined;
    CustomerOutpostArn?: string | undefined;
}
export type CacheNodeList = CacheNode[];
export interface SecurityGroupMembership {
    SecurityGroupId?: string | undefined;
    Status?: string | undefined;
}
export type SecurityGroupMembershipList = SecurityGroupMembership[];
export interface CacheCluster {
    CacheClusterId?: string | undefined;
    ConfigurationEndpoint?: Endpoint | undefined;
    ClientDownloadLandingPage?: string | undefined;
    CacheNodeType?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    CacheClusterStatus?: string | undefined;
    NumCacheNodes?: number | undefined;
    PreferredAvailabilityZone?: string | undefined;
    PreferredOutpostArn?: string | undefined;
    CacheClusterCreateTime?: Date | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    PendingModifiedValues?: PendingModifiedValues | undefined;
    NotificationConfiguration?: NotificationConfiguration | undefined;
    CacheSecurityGroups?: CacheSecurityGroupMembership[] | undefined;
    CacheParameterGroup?: CacheParameterGroupStatus | undefined;
    CacheSubnetGroupName?: string | undefined;
    CacheNodes?: CacheNode[] | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    SecurityGroups?: SecurityGroupMembership[] | undefined;
    ReplicationGroupId?: string | undefined;
    SnapshotRetentionLimit?: number | undefined;
    SnapshotWindow?: string | undefined;
    AuthTokenEnabled?: boolean | undefined;
    AuthTokenLastModifiedDate?: Date | undefined;
    TransitEncryptionEnabled?: boolean | undefined;
    AtRestEncryptionEnabled?: boolean | undefined;
    ARN?: string | undefined;
    ReplicationGroupLogDeliveryEnabled?: boolean | undefined;
    LogDeliveryConfigurations?: LogDeliveryConfiguration[] | undefined;
    NetworkType?: NetworkType | undefined;
    IpDiscovery?: IpDiscovery | undefined;
    TransitEncryptionMode?: TransitEncryptionMode | undefined;
}
export interface CreateCacheClusterResult {
    CacheCluster?: CacheCluster | undefined;
}
export interface CreateCacheParameterGroupMessage {
    CacheParameterGroupName?: string | undefined;
    CacheParameterGroupFamily?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CacheParameterGroup {
    CacheParameterGroupName?: string | undefined;
    CacheParameterGroupFamily?: string | undefined;
    Description?: string | undefined;
    IsGlobal?: boolean | undefined;
    ARN?: string | undefined;
}
export interface CreateCacheParameterGroupResult {
    CacheParameterGroup?: CacheParameterGroup | undefined;
}
export interface CreateCacheSecurityGroupMessage {
    CacheSecurityGroupName?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateCacheSecurityGroupResult {
    CacheSecurityGroup?: CacheSecurityGroup | undefined;
}
export type SubnetIdentifierList = string[];
export interface CreateCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string | undefined;
    CacheSubnetGroupDescription?: string | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface AvailabilityZone {
    Name?: string | undefined;
}
export interface SubnetOutpost {
    SubnetOutpostArn?: string | undefined;
}
export type NetworkTypeList = NetworkType[];
export interface Subnet {
    SubnetIdentifier?: string | undefined;
    SubnetAvailabilityZone?: AvailabilityZone | undefined;
    SubnetOutpost?: SubnetOutpost | undefined;
    SupportedNetworkTypes?: NetworkType[] | undefined;
}
export type SubnetList = Subnet[];
export interface CacheSubnetGroup {
    CacheSubnetGroupName?: string | undefined;
    CacheSubnetGroupDescription?: string | undefined;
    VpcId?: string | undefined;
    Subnets?: Subnet[] | undefined;
    ARN?: string | undefined;
    SupportedNetworkTypes?: NetworkType[] | undefined;
}
export interface CreateCacheSubnetGroupResult {
    CacheSubnetGroup?: CacheSubnetGroup | undefined;
}
export interface CreateGlobalReplicationGroupMessage {
    GlobalReplicationGroupIdSuffix?: string | undefined;
    GlobalReplicationGroupDescription?: string | undefined;
    PrimaryReplicationGroupId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface GlobalReplicationGroupMember {
    ReplicationGroupId?: string | undefined;
    ReplicationGroupRegion?: string | undefined;
    Role?: string | undefined;
    AutomaticFailover?: AutomaticFailoverStatus | undefined;
    Status?: string | undefined;
}
export type GlobalReplicationGroupMemberList = GlobalReplicationGroupMember[];
export interface GlobalNodeGroup {
    GlobalNodeGroupId?: string | undefined;
    Slots?: string | undefined;
}
export type GlobalNodeGroupList = GlobalNodeGroup[];
export interface GlobalReplicationGroup {
    GlobalReplicationGroupId?: string | undefined;
    GlobalReplicationGroupDescription?: string | undefined;
    Status?: string | undefined;
    CacheNodeType?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Members?: GlobalReplicationGroupMember[] | undefined;
    ClusterEnabled?: boolean | undefined;
    GlobalNodeGroups?: GlobalNodeGroup[] | undefined;
    AuthTokenEnabled?: boolean | undefined;
    TransitEncryptionEnabled?: boolean | undefined;
    AtRestEncryptionEnabled?: boolean | undefined;
    ARN?: string | undefined;
}
export interface CreateGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup | undefined;
}
export type NodeGroupConfigurationList = NodeGroupConfiguration[];
export type UserGroupIdListInput = string[];
export interface CreateReplicationGroupMessage {
    ReplicationGroupId?: string | undefined;
    ReplicationGroupDescription?: string | undefined;
    GlobalReplicationGroupId?: string | undefined;
    PrimaryClusterId?: string | undefined;
    AutomaticFailoverEnabled?: boolean | undefined;
    MultiAZEnabled?: boolean | undefined;
    NumCacheClusters?: number | undefined;
    PreferredCacheClusterAZs?: string[] | undefined;
    NumNodeGroups?: number | undefined;
    ReplicasPerNodeGroup?: number | undefined;
    NodeGroupConfiguration?: NodeGroupConfiguration[] | undefined;
    CacheNodeType?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    CacheParameterGroupName?: string | undefined;
    CacheSubnetGroupName?: string | undefined;
    CacheSecurityGroupNames?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    SnapshotArns?: string[] | undefined;
    SnapshotName?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    Port?: number | undefined;
    NotificationTopicArn?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    SnapshotRetentionLimit?: number | undefined;
    SnapshotWindow?: string | undefined;
    AuthToken?: string | redacted.Redacted<string> | undefined;
    TransitEncryptionEnabled?: boolean | undefined;
    AtRestEncryptionEnabled?: boolean | undefined;
    KmsKeyId?: string | undefined;
    UserGroupIds?: string[] | undefined;
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[] | undefined;
    DataTieringEnabled?: boolean | undefined;
    NetworkType?: NetworkType | undefined;
    IpDiscovery?: IpDiscovery | undefined;
    TransitEncryptionMode?: TransitEncryptionMode | undefined;
    ClusterMode?: ClusterMode | undefined;
    ServerlessCacheSnapshotName?: string | undefined;
    Durability?: Durability | undefined;
}
export interface CreateReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup | undefined;
}
export interface CreateServerlessCacheRequest {
    ServerlessCacheName?: string | undefined;
    Description?: string | undefined;
    Engine?: string | undefined;
    MajorEngineVersion?: string | undefined;
    CacheUsageLimits?: CacheUsageLimits | undefined;
    KmsKeyId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SnapshotArnsToRestore?: string[] | undefined;
    Tags?: Tag[] | undefined;
    UserGroupId?: string | undefined;
    SubnetIds?: string[] | undefined;
    SnapshotRetentionLimit?: number | undefined;
    DailySnapshotTime?: string | undefined;
    NetworkType?: NetworkType | undefined;
    ConnectionType?: ConnectionType | undefined;
}
export interface CreateServerlessCacheResponse {
    ServerlessCache?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    }) | undefined;
}
export interface CreateServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string | undefined;
    ServerlessCacheName?: string | undefined;
    KmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot | undefined;
}
export interface CreateSnapshotMessage {
    ReplicationGroupId?: string | undefined;
    CacheClusterId?: string | undefined;
    SnapshotName?: string | undefined;
    KmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateSnapshotResult {
    Snapshot?: Snapshot | undefined;
}
export type UserId = string;
export type UserName = string;
export type EngineType = string;
export type PasswordListInput = string[];
export type AccessString = string;
export type InputAuthenticationType = "password" | "no-password-required" | "iam" | (string & {});
export interface AuthenticationMode {
    Type?: InputAuthenticationType | undefined;
    Passwords?: Array<string | redacted.Redacted<string>> | undefined;
}
export interface CreateUserMessage {
    UserId?: string | undefined;
    UserName?: string | undefined;
    Engine?: string | undefined;
    Passwords?: Array<string | redacted.Redacted<string>> | undefined;
    AccessString?: string | undefined;
    NoPasswordRequired?: boolean | undefined;
    Tags?: Tag[] | undefined;
    AuthenticationMode?: AuthenticationMode | undefined;
}
export type AuthenticationType = "password" | "no-password" | "iam" | (string & {});
export interface Authentication {
    Type?: AuthenticationType | undefined;
    PasswordCount?: number | undefined;
}
export interface User {
    UserId?: string | undefined;
    UserName?: string | undefined;
    Status?: string | undefined;
    Engine?: string | undefined;
    MinimumEngineVersion?: string | undefined;
    AccessString?: string | undefined;
    UserGroupIds?: string[] | undefined;
    Authentication?: Authentication | undefined;
    ARN?: string | undefined;
}
export type UserIdListInput = string[];
export interface CreateUserGroupMessage {
    UserGroupId?: string | undefined;
    Engine?: string | undefined;
    UserIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export type UserIdList = string[];
export interface UserGroupPendingChanges {
    UserIdsToRemove?: string[] | undefined;
    UserIdsToAdd?: string[] | undefined;
}
export type UGReplicationGroupIdList = string[];
export type UGServerlessCacheIdList = string[];
export interface UserGroup {
    UserGroupId?: string | undefined;
    Status?: string | undefined;
    Engine?: string | undefined;
    UserIds?: string[] | undefined;
    MinimumEngineVersion?: string | undefined;
    PendingChanges?: UserGroupPendingChanges | undefined;
    ReplicationGroups?: string[] | undefined;
    ServerlessCaches?: string[] | undefined;
    ARN?: string | undefined;
}
export type GlobalNodeGroupIdList = string[];
export interface DecreaseNodeGroupsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string | undefined;
    NodeGroupCount?: number | undefined;
    GlobalNodeGroupsToRemove?: string[] | undefined;
    GlobalNodeGroupsToRetain?: string[] | undefined;
    ApplyImmediately?: boolean | undefined;
}
export interface DecreaseNodeGroupsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup | undefined;
}
export interface ConfigureShard {
    NodeGroupId?: string | undefined;
    NewReplicaCount?: number | undefined;
    PreferredAvailabilityZones?: string[] | undefined;
    PreferredOutpostArns?: string[] | undefined;
}
export type ReplicaConfigurationList = ConfigureShard[];
export type RemoveReplicasList = string[];
export interface DecreaseReplicaCountMessage {
    ReplicationGroupId?: string | undefined;
    NewReplicaCount?: number | undefined;
    ReplicaConfiguration?: ConfigureShard[] | undefined;
    ReplicasToRemove?: string[] | undefined;
    ApplyImmediately?: boolean | undefined;
}
export interface DecreaseReplicaCountResult {
    ReplicationGroup?: ReplicationGroup | undefined;
}
export interface DeleteCacheClusterMessage {
    CacheClusterId?: string | undefined;
    FinalSnapshotIdentifier?: string | undefined;
}
export interface DeleteCacheClusterResult {
    CacheCluster?: CacheCluster | undefined;
}
export interface DeleteCacheParameterGroupMessage {
    CacheParameterGroupName?: string | undefined;
}
export interface DeleteCacheParameterGroupResponse {
}
export interface DeleteCacheSecurityGroupMessage {
    CacheSecurityGroupName?: string | undefined;
}
export interface DeleteCacheSecurityGroupResponse {
}
export interface DeleteCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string | undefined;
}
export interface DeleteCacheSubnetGroupResponse {
}
export interface DeleteGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string | undefined;
    RetainPrimaryReplicationGroup?: boolean | undefined;
}
export interface DeleteGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup | undefined;
}
export interface DeleteReplicationGroupMessage {
    ReplicationGroupId?: string | undefined;
    RetainPrimaryCluster?: boolean | undefined;
    FinalSnapshotIdentifier?: string | undefined;
}
export interface DeleteReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup | undefined;
}
export interface DeleteServerlessCacheRequest {
    ServerlessCacheName?: string | undefined;
    FinalSnapshotName?: string | undefined;
}
export interface DeleteServerlessCacheResponse {
    ServerlessCache?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    }) | undefined;
}
export interface DeleteServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string | undefined;
}
export interface DeleteServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot | undefined;
}
export interface DeleteSnapshotMessage {
    SnapshotName?: string | undefined;
}
export interface DeleteSnapshotResult {
    Snapshot?: Snapshot | undefined;
}
export interface DeleteUserMessage {
    UserId?: string | undefined;
}
export interface DeleteUserGroupMessage {
    UserGroupId?: string | undefined;
}
export interface DescribeCacheClustersMessage {
    CacheClusterId?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    ShowCacheNodeInfo?: boolean | undefined;
    ShowCacheClustersNotInReplicationGroups?: boolean | undefined;
}
export type CacheClusterList = CacheCluster[];
export interface CacheClusterMessage {
    Marker?: string | undefined;
    CacheClusters?: CacheCluster[] | undefined;
}
export interface DescribeCacheEngineVersionsMessage {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    CacheParameterGroupFamily?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    DefaultOnly?: boolean | undefined;
}
export interface CacheEngineVersion {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    CacheParameterGroupFamily?: string | undefined;
    CacheEngineDescription?: string | undefined;
    CacheEngineVersionDescription?: string | undefined;
}
export type CacheEngineVersionList = CacheEngineVersion[];
export interface CacheEngineVersionMessage {
    Marker?: string | undefined;
    CacheEngineVersions?: CacheEngineVersion[] | undefined;
}
export interface DescribeCacheParameterGroupsMessage {
    CacheParameterGroupName?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type CacheParameterGroupList = CacheParameterGroup[];
export interface CacheParameterGroupsMessage {
    Marker?: string | undefined;
    CacheParameterGroups?: CacheParameterGroup[] | undefined;
}
export interface DescribeCacheParametersMessage {
    CacheParameterGroupName?: string | undefined;
    Source?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ChangeType = "immediate" | "requires-reboot" | (string & {});
export interface Parameter {
    ParameterName?: string | undefined;
    ParameterValue?: string | undefined;
    Description?: string | undefined;
    Source?: string | undefined;
    DataType?: string | undefined;
    AllowedValues?: string | undefined;
    IsModifiable?: boolean | undefined;
    MinimumEngineVersion?: string | undefined;
    ChangeType?: ChangeType | undefined;
}
export type ParametersList = Parameter[];
export interface CacheNodeTypeSpecificValue {
    CacheNodeType?: string | undefined;
    Value?: string | undefined;
}
export type CacheNodeTypeSpecificValueList = CacheNodeTypeSpecificValue[];
export interface CacheNodeTypeSpecificParameter {
    ParameterName?: string | undefined;
    Description?: string | undefined;
    Source?: string | undefined;
    DataType?: string | undefined;
    AllowedValues?: string | undefined;
    IsModifiable?: boolean | undefined;
    MinimumEngineVersion?: string | undefined;
    CacheNodeTypeSpecificValues?: CacheNodeTypeSpecificValue[] | undefined;
    ChangeType?: ChangeType | undefined;
}
export type CacheNodeTypeSpecificParametersList = CacheNodeTypeSpecificParameter[];
export interface CacheParameterGroupDetails {
    Marker?: string | undefined;
    Parameters?: Parameter[] | undefined;
    CacheNodeTypeSpecificParameters?: CacheNodeTypeSpecificParameter[] | undefined;
}
export interface DescribeCacheSecurityGroupsMessage {
    CacheSecurityGroupName?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type CacheSecurityGroups = CacheSecurityGroup[];
export interface CacheSecurityGroupMessage {
    Marker?: string | undefined;
    CacheSecurityGroups?: CacheSecurityGroup[] | undefined;
}
export interface DescribeCacheSubnetGroupsMessage {
    CacheSubnetGroupName?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type CacheSubnetGroups = CacheSubnetGroup[];
export interface CacheSubnetGroupMessage {
    Marker?: string | undefined;
    CacheSubnetGroups?: CacheSubnetGroup[] | undefined;
}
export interface DescribeEngineDefaultParametersMessage {
    CacheParameterGroupFamily?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface EngineDefaults {
    CacheParameterGroupFamily?: string | undefined;
    Marker?: string | undefined;
    Parameters?: Parameter[] | undefined;
    CacheNodeTypeSpecificParameters?: CacheNodeTypeSpecificParameter[] | undefined;
}
export interface DescribeEngineDefaultParametersResult {
    EngineDefaults?: EngineDefaults | undefined;
}
export type SourceType = "cache-cluster" | "cache-parameter-group" | "cache-security-group" | "cache-subnet-group" | "replication-group" | "serverless-cache" | "serverless-cache-snapshot" | "user" | "user-group" | (string & {});
export interface DescribeEventsMessage {
    SourceIdentifier?: string | undefined;
    SourceType?: SourceType | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Duration?: number | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface Event {
    SourceIdentifier?: string | undefined;
    SourceType?: SourceType | undefined;
    Message?: string | undefined;
    Date?: Date | undefined;
}
export type EventList = Event[];
export interface EventsMessage {
    Marker?: string | undefined;
    Events?: Event[] | undefined;
}
export interface DescribeGlobalReplicationGroupsMessage {
    GlobalReplicationGroupId?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    ShowMemberInfo?: boolean | undefined;
}
export type GlobalReplicationGroupList = GlobalReplicationGroup[];
export interface DescribeGlobalReplicationGroupsResult {
    Marker?: string | undefined;
    GlobalReplicationGroups?: GlobalReplicationGroup[] | undefined;
}
export interface DescribeReplicationGroupsMessage {
    ReplicationGroupId?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ReplicationGroupList = ReplicationGroup[];
export interface ReplicationGroupMessage {
    Marker?: string | undefined;
    ReplicationGroups?: ReplicationGroup[] | undefined;
}
export interface DescribeReservedCacheNodesMessage {
    ReservedCacheNodeId?: string | undefined;
    ReservedCacheNodesOfferingId?: string | undefined;
    CacheNodeType?: string | undefined;
    Duration?: string | undefined;
    ProductDescription?: string | undefined;
    OfferingType?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface RecurringCharge {
    RecurringChargeAmount?: number | undefined;
    RecurringChargeFrequency?: string | undefined;
}
export type RecurringChargeList = RecurringCharge[];
export interface ReservedCacheNode {
    ReservedCacheNodeId?: string | undefined;
    ReservedCacheNodesOfferingId?: string | undefined;
    CacheNodeType?: string | undefined;
    StartTime?: Date | undefined;
    Duration?: number | undefined;
    FixedPrice?: number | undefined;
    UsagePrice?: number | undefined;
    CacheNodeCount?: number | undefined;
    ProductDescription?: string | undefined;
    OfferingType?: string | undefined;
    State?: string | undefined;
    RecurringCharges?: RecurringCharge[] | undefined;
    ReservationARN?: string | undefined;
}
export type ReservedCacheNodeList = ReservedCacheNode[];
export interface ReservedCacheNodeMessage {
    Marker?: string | undefined;
    ReservedCacheNodes?: ReservedCacheNode[] | undefined;
}
export interface DescribeReservedCacheNodesOfferingsMessage {
    ReservedCacheNodesOfferingId?: string | undefined;
    CacheNodeType?: string | undefined;
    Duration?: string | undefined;
    ProductDescription?: string | undefined;
    OfferingType?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface ReservedCacheNodesOffering {
    ReservedCacheNodesOfferingId?: string | undefined;
    CacheNodeType?: string | undefined;
    Duration?: number | undefined;
    FixedPrice?: number | undefined;
    UsagePrice?: number | undefined;
    ProductDescription?: string | undefined;
    OfferingType?: string | undefined;
    RecurringCharges?: RecurringCharge[] | undefined;
}
export type ReservedCacheNodesOfferingList = ReservedCacheNodesOffering[];
export interface ReservedCacheNodesOfferingMessage {
    Marker?: string | undefined;
    ReservedCacheNodesOfferings?: ReservedCacheNodesOffering[] | undefined;
}
export interface DescribeServerlessCachesRequest {
    ServerlessCacheName?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ServerlessCacheList = ServerlessCache[];
export interface DescribeServerlessCachesResponse {
    NextToken?: string | undefined;
    ServerlessCaches?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    })[] | undefined;
}
export interface DescribeServerlessCacheSnapshotsRequest {
    ServerlessCacheName?: string | undefined;
    ServerlessCacheSnapshotName?: string | undefined;
    SnapshotType?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ServerlessCacheSnapshotList = ServerlessCacheSnapshot[];
export interface DescribeServerlessCacheSnapshotsResponse {
    NextToken?: string | undefined;
    ServerlessCacheSnapshots?: ServerlessCacheSnapshot[] | undefined;
}
export type ServiceUpdateStatus = "available" | "cancelled" | "expired" | (string & {});
export type ServiceUpdateStatusList = ServiceUpdateStatus[];
export interface DescribeServiceUpdatesMessage {
    ServiceUpdateName?: string | undefined;
    ServiceUpdateStatus?: ServiceUpdateStatus[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ServiceUpdateSeverity = "critical" | "important" | "medium" | "low" | (string & {});
export type ServiceUpdateType = "security-update" | (string & {});
export interface ServiceUpdate {
    ServiceUpdateName?: string | undefined;
    ServiceUpdateReleaseDate?: Date | undefined;
    ServiceUpdateEndDate?: Date | undefined;
    ServiceUpdateSeverity?: ServiceUpdateSeverity | undefined;
    ServiceUpdateRecommendedApplyByDate?: Date | undefined;
    ServiceUpdateStatus?: ServiceUpdateStatus | undefined;
    ServiceUpdateDescription?: string | undefined;
    ServiceUpdateType?: ServiceUpdateType | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    AutoUpdateAfterRecommendedApplyByDate?: boolean | undefined;
    EstimatedUpdateTime?: string | undefined;
}
export type ServiceUpdateList = ServiceUpdate[];
export interface ServiceUpdatesMessage {
    Marker?: string | undefined;
    ServiceUpdates?: ServiceUpdate[] | undefined;
}
export interface DescribeSnapshotsMessage {
    ReplicationGroupId?: string | undefined;
    CacheClusterId?: string | undefined;
    SnapshotName?: string | undefined;
    SnapshotSource?: string | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
    ShowNodeGroupConfig?: boolean | undefined;
}
export type SnapshotList = Snapshot[];
export interface DescribeSnapshotsListMessage {
    Marker?: string | undefined;
    Snapshots?: Snapshot[] | undefined;
}
export interface TimeRangeFilter {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type UpdateActionStatusList = UpdateActionStatus[];
export interface DescribeUpdateActionsMessage {
    ServiceUpdateName?: string | undefined;
    ReplicationGroupIds?: string[] | undefined;
    CacheClusterIds?: string[] | undefined;
    Engine?: string | undefined;
    ServiceUpdateStatus?: ServiceUpdateStatus[] | undefined;
    ServiceUpdateTimeRange?: TimeRangeFilter | undefined;
    UpdateActionStatus?: UpdateActionStatus[] | undefined;
    ShowNodeLevelUpdateStatus?: boolean | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type SlaMet = "yes" | "no" | "n/a" | (string & {});
export type NodeUpdateStatus = "not-applied" | "waiting-to-start" | "in-progress" | "stopping" | "stopped" | "complete" | (string & {});
export type NodeUpdateInitiatedBy = "system" | "customer" | (string & {});
export interface NodeGroupMemberUpdateStatus {
    CacheClusterId?: string | undefined;
    CacheNodeId?: string | undefined;
    NodeUpdateStatus?: NodeUpdateStatus | undefined;
    NodeDeletionDate?: Date | undefined;
    NodeUpdateStartDate?: Date | undefined;
    NodeUpdateEndDate?: Date | undefined;
    NodeUpdateInitiatedBy?: NodeUpdateInitiatedBy | undefined;
    NodeUpdateInitiatedDate?: Date | undefined;
    NodeUpdateStatusModifiedDate?: Date | undefined;
}
export type NodeGroupMemberUpdateStatusList = NodeGroupMemberUpdateStatus[];
export interface NodeGroupUpdateStatus {
    NodeGroupId?: string | undefined;
    NodeGroupMemberUpdateStatus?: NodeGroupMemberUpdateStatus[] | undefined;
}
export type NodeGroupUpdateStatusList = NodeGroupUpdateStatus[];
export interface CacheNodeUpdateStatus {
    CacheNodeId?: string | undefined;
    NodeUpdateStatus?: NodeUpdateStatus | undefined;
    NodeDeletionDate?: Date | undefined;
    NodeUpdateStartDate?: Date | undefined;
    NodeUpdateEndDate?: Date | undefined;
    NodeUpdateInitiatedBy?: NodeUpdateInitiatedBy | undefined;
    NodeUpdateInitiatedDate?: Date | undefined;
    NodeUpdateStatusModifiedDate?: Date | undefined;
}
export type CacheNodeUpdateStatusList = CacheNodeUpdateStatus[];
export interface UpdateAction {
    ReplicationGroupId?: string | undefined;
    CacheClusterId?: string | undefined;
    ServiceUpdateName?: string | undefined;
    ServiceUpdateReleaseDate?: Date | undefined;
    ServiceUpdateSeverity?: ServiceUpdateSeverity | undefined;
    ServiceUpdateStatus?: ServiceUpdateStatus | undefined;
    ServiceUpdateRecommendedApplyByDate?: Date | undefined;
    ServiceUpdateType?: ServiceUpdateType | undefined;
    UpdateActionAvailableDate?: Date | undefined;
    UpdateActionStatus?: UpdateActionStatus | undefined;
    NodesUpdated?: string | undefined;
    UpdateActionStatusModifiedDate?: Date | undefined;
    SlaMet?: SlaMet | undefined;
    NodeGroupUpdateStatus?: NodeGroupUpdateStatus[] | undefined;
    CacheNodeUpdateStatus?: CacheNodeUpdateStatus[] | undefined;
    EstimatedUpdateTime?: string | undefined;
    Engine?: string | undefined;
}
export type UpdateActionList = UpdateAction[];
export interface UpdateActionsMessage {
    Marker?: string | undefined;
    UpdateActions?: UpdateAction[] | undefined;
}
export interface DescribeUserGroupsMessage {
    UserGroupId?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type UserGroupList = UserGroup[];
export interface DescribeUserGroupsResult {
    UserGroups?: UserGroup[] | undefined;
    Marker?: string | undefined;
}
export type FilterName = string;
export type FilterValue = string;
export type FilterValueList = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type FilterList = Filter[];
export interface DescribeUsersMessage {
    Engine?: string | undefined;
    UserId?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type UserList = User[];
export interface DescribeUsersResult {
    Users?: User[] | undefined;
    Marker?: string | undefined;
}
export interface DisassociateGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string | undefined;
    ReplicationGroupId?: string | undefined;
    ReplicationGroupRegion?: string | undefined;
}
export interface DisassociateGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup | undefined;
}
export interface ExportServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string | undefined;
    S3BucketName?: string | undefined;
}
export interface ExportServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot | undefined;
}
export interface FailoverGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string | undefined;
    PrimaryRegion?: string | undefined;
    PrimaryReplicationGroupId?: string | undefined;
}
export interface FailoverGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup | undefined;
}
export interface ReshardingConfiguration {
    NodeGroupId?: string | undefined;
    PreferredAvailabilityZones?: string[] | undefined;
}
export type ReshardingConfigurationList = ReshardingConfiguration[];
export interface RegionalConfiguration {
    ReplicationGroupId?: string | undefined;
    ReplicationGroupRegion?: string | undefined;
    ReshardingConfiguration?: ReshardingConfiguration[] | undefined;
}
export type RegionalConfigurationList = RegionalConfiguration[];
export interface IncreaseNodeGroupsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string | undefined;
    NodeGroupCount?: number | undefined;
    RegionalConfigurations?: RegionalConfiguration[] | undefined;
    ApplyImmediately?: boolean | undefined;
}
export interface IncreaseNodeGroupsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup | undefined;
}
export interface IncreaseReplicaCountMessage {
    ReplicationGroupId?: string | undefined;
    NewReplicaCount?: number | undefined;
    ReplicaConfiguration?: ConfigureShard[] | undefined;
    ApplyImmediately?: boolean | undefined;
}
export interface IncreaseReplicaCountResult {
    ReplicationGroup?: ReplicationGroup | undefined;
}
export interface ListAllowedNodeTypeModificationsMessage {
    CacheClusterId?: string | undefined;
    ReplicationGroupId?: string | undefined;
}
export type NodeTypeList = string[];
export interface AllowedNodeTypeModificationsMessage {
    ScaleUpModifications?: string[] | undefined;
    ScaleDownModifications?: string[] | undefined;
}
export interface ListTagsForResourceMessage {
    ResourceName?: string | undefined;
}
export type AuthTokenUpdateStrategyType = "SET" | "ROTATE" | "DELETE" | (string & {});
export interface ModifyCacheClusterMessage {
    CacheClusterId?: string | undefined;
    NumCacheNodes?: number | undefined;
    CacheNodeIdsToRemove?: string[] | undefined;
    AZMode?: AZMode | undefined;
    NewAvailabilityZones?: string[] | undefined;
    CacheSecurityGroupNames?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    NotificationTopicArn?: string | undefined;
    CacheParameterGroupName?: string | undefined;
    NotificationTopicStatus?: string | undefined;
    ApplyImmediately?: boolean | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    SnapshotRetentionLimit?: number | undefined;
    SnapshotWindow?: string | undefined;
    CacheNodeType?: string | undefined;
    AuthToken?: string | redacted.Redacted<string> | undefined;
    AuthTokenUpdateStrategy?: AuthTokenUpdateStrategyType | undefined;
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[] | undefined;
    IpDiscovery?: IpDiscovery | undefined;
    ScaleConfig?: ScaleConfig | undefined;
}
export interface ModifyCacheClusterResult {
    CacheCluster?: CacheCluster | undefined;
}
export interface ParameterNameValue {
    ParameterName?: string | undefined;
    ParameterValue?: string | undefined;
}
export type ParameterNameValueList = ParameterNameValue[];
export interface ModifyCacheParameterGroupMessage {
    CacheParameterGroupName?: string | undefined;
    ParameterNameValues?: ParameterNameValue[] | undefined;
}
export interface CacheParameterGroupNameMessage {
    CacheParameterGroupName?: string | undefined;
}
export interface ModifyCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string | undefined;
    CacheSubnetGroupDescription?: string | undefined;
    SubnetIds?: string[] | undefined;
}
export interface ModifyCacheSubnetGroupResult {
    CacheSubnetGroup?: CacheSubnetGroup | undefined;
}
export interface ModifyGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string | undefined;
    ApplyImmediately?: boolean | undefined;
    CacheNodeType?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    CacheParameterGroupName?: string | undefined;
    GlobalReplicationGroupDescription?: string | undefined;
    AutomaticFailoverEnabled?: boolean | undefined;
}
export interface ModifyGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup | undefined;
}
export interface ModifyReplicationGroupMessage {
    ReplicationGroupId?: string | undefined;
    ReplicationGroupDescription?: string | undefined;
    PrimaryClusterId?: string | undefined;
    SnapshottingClusterId?: string | undefined;
    AutomaticFailoverEnabled?: boolean | undefined;
    MultiAZEnabled?: boolean | undefined;
    NodeGroupId?: string | undefined;
    CacheSecurityGroupNames?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    NotificationTopicArn?: string | undefined;
    CacheParameterGroupName?: string | undefined;
    NotificationTopicStatus?: string | undefined;
    ApplyImmediately?: boolean | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    SnapshotRetentionLimit?: number | undefined;
    SnapshotWindow?: string | undefined;
    CacheNodeType?: string | undefined;
    AuthToken?: string | redacted.Redacted<string> | undefined;
    AuthTokenUpdateStrategy?: AuthTokenUpdateStrategyType | undefined;
    UserGroupIdsToAdd?: string[] | undefined;
    UserGroupIdsToRemove?: string[] | undefined;
    RemoveUserGroups?: boolean | undefined;
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[] | undefined;
    IpDiscovery?: IpDiscovery | undefined;
    TransitEncryptionEnabled?: boolean | undefined;
    TransitEncryptionMode?: TransitEncryptionMode | undefined;
    ClusterMode?: ClusterMode | undefined;
    Durability?: Durability | undefined;
}
export interface ModifyReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup | undefined;
}
export type NodeGroupsToRemoveList = string[];
export type NodeGroupsToRetainList = string[];
export interface ModifyReplicationGroupShardConfigurationMessage {
    ReplicationGroupId?: string | undefined;
    NodeGroupCount?: number | undefined;
    ApplyImmediately?: boolean | undefined;
    ReshardingConfiguration?: ReshardingConfiguration[] | undefined;
    NodeGroupsToRemove?: string[] | undefined;
    NodeGroupsToRetain?: string[] | undefined;
}
export interface ModifyReplicationGroupShardConfigurationResult {
    ReplicationGroup?: ReplicationGroup | undefined;
}
export interface ModifyServerlessCacheRequest {
    ServerlessCacheName?: string | undefined;
    Description?: string | undefined;
    CacheUsageLimits?: CacheUsageLimits | undefined;
    RemoveUserGroup?: boolean | undefined;
    UserGroupId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SnapshotRetentionLimit?: number | undefined;
    DailySnapshotTime?: string | undefined;
    Engine?: string | undefined;
    MajorEngineVersion?: string | undefined;
}
export interface ModifyServerlessCacheResponse {
    ServerlessCache?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    }) | undefined;
}
export interface ModifyUserMessage {
    UserId?: string | undefined;
    AccessString?: string | undefined;
    AppendAccessString?: string | undefined;
    Passwords?: Array<string | redacted.Redacted<string>> | undefined;
    NoPasswordRequired?: boolean | undefined;
    AuthenticationMode?: AuthenticationMode | undefined;
    Engine?: string | undefined;
}
export interface ModifyUserGroupMessage {
    UserGroupId?: string | undefined;
    UserIdsToAdd?: string[] | undefined;
    UserIdsToRemove?: string[] | undefined;
    Engine?: string | undefined;
}
export interface CustomerNodeEndpoint {
    Address?: string | undefined;
    Port?: number | undefined;
}
export type CustomerNodeEndpointList = CustomerNodeEndpoint[];
export interface SecretManagerAuthConfig {
    SecretArn?: string | undefined;
}
export interface SourceAuthenticationConfiguration {
    SecretManagerConfig?: SecretManagerAuthConfig | undefined;
}
export type TlsMode = "none" | "verify-ca" | (string & {});
export interface SourceTlsConfiguration {
    SourceTlsMode?: TlsMode | undefined;
    SourceTlsCertificate?: string | undefined;
}
export interface PrepareMigrationRequest {
    ServerlessCacheName?: string | undefined;
    CustomerNodeEndpointList?: CustomerNodeEndpoint[] | undefined;
    SourceAuthenticationConfiguration?: SourceAuthenticationConfiguration | undefined;
    SourceTlsConfiguration?: SourceTlsConfiguration | undefined;
}
export interface PrepareMigrationResponse {
    ServerlessCache?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    }) | undefined;
}
export interface PurchaseReservedCacheNodesOfferingMessage {
    ReservedCacheNodesOfferingId?: string | undefined;
    ReservedCacheNodeId?: string | undefined;
    CacheNodeCount?: number | undefined;
    Tags?: Tag[] | undefined;
}
export interface PurchaseReservedCacheNodesOfferingResult {
    ReservedCacheNode?: ReservedCacheNode | undefined;
}
export interface RebalanceSlotsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string | undefined;
    ApplyImmediately?: boolean | undefined;
}
export interface RebalanceSlotsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup | undefined;
}
export interface RebootCacheClusterMessage {
    CacheClusterId?: string | undefined;
    CacheNodeIdsToReboot?: string[] | undefined;
}
export interface RebootCacheClusterResult {
    CacheCluster?: CacheCluster | undefined;
}
export type KeyList = string[];
export interface RemoveTagsFromResourceMessage {
    ResourceName?: string | undefined;
    TagKeys?: string[] | undefined;
}
export interface ResetCacheParameterGroupMessage {
    CacheParameterGroupName?: string | undefined;
    ResetAllParameters?: boolean | undefined;
    ParameterNameValues?: ParameterNameValue[] | undefined;
}
export interface RevokeCacheSecurityGroupIngressMessage {
    CacheSecurityGroupName?: string | undefined;
    EC2SecurityGroupName?: string | undefined;
    EC2SecurityGroupOwnerId?: string | undefined;
}
export interface RevokeCacheSecurityGroupIngressResult {
    CacheSecurityGroup?: CacheSecurityGroup | undefined;
}
export interface StartMigrationMessage {
    ServerlessCacheName?: string | undefined;
    ReplicationGroupId?: string | undefined;
    CustomerNodeEndpointList?: CustomerNodeEndpoint[] | undefined;
    AutoCutover?: boolean | undefined;
    ClearTargetCacheData?: boolean | undefined;
}
export interface StartMigrationResponse {
    ReplicationGroup?: ReplicationGroup | undefined;
    ServerlessCache?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    }) | undefined;
}
export interface StopMigrationRequest {
    ServerlessCacheName?: string | undefined;
}
export interface StopMigrationResponse {
    ServerlessCache?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    }) | undefined;
}
export interface TestFailoverMessage {
    ReplicationGroupId?: string | undefined;
    NodeGroupId?: string | undefined;
}
export interface TestFailoverResult {
    ReplicationGroup?: ReplicationGroup | undefined;
}
export interface TestMigrationMessage {
    ReplicationGroupId?: string | undefined;
    CustomerNodeEndpointList?: CustomerNodeEndpoint[] | undefined;
}
export interface TestMigrationResponse {
    ReplicationGroup?: ReplicationGroup | undefined;
}
export type ExceptionMessage = string;
export type AwsQueryErrorMessage = string;
export type AddTagsToResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | GlobalReplicationGroupNotFoundFault | InvalidARNFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * A tag is a key-value pair where the key and value are case-sensitive. You can use tags
 * to categorize and track all your ElastiCache resources.
 * When you add or remove tags on replication groups, those actions will
 * be replicated to all nodes in the replication group. For more information, see Resource-level permissions.
 *
 * For example, you can use cost-allocation tags to your ElastiCache resources, Amazon
 * generates a cost allocation report as a comma-separated value (CSV) file with your usage
 * and costs aggregated by your tags. You can apply tags that represent business categories
 * (such as cost centers, application names, or owners) to organize your costs across
 * multiple services.
 *
 * For more information, see Using Cost Allocation Tags in
 * Amazon ElastiCache in the ElastiCache User
 * Guide.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage & RegionInput, TagListMessage, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type AuthorizeCacheSecurityGroupIngressError = AuthorizationAlreadyExistsFault | CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Allows network ingress to a cache security group. Applications using ElastiCache must
 * be running on Amazon EC2, and Amazon EC2 security groups are used as the authorization
 * mechanism.
 *
 * You cannot authorize ingress from an Amazon EC2 security group in one region to an
 * ElastiCache cluster in another region.
 */
export declare const authorizeCacheSecurityGroupIngress: API.OperationMethod<AuthorizeCacheSecurityGroupIngressMessage & RegionInput, AuthorizeCacheSecurityGroupIngressResult, AuthorizeCacheSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type BatchApplyUpdateActionError = InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Apply the service update. For more information on service updates and applying them,
 * see Applying Service
 * Updates.
 */
export declare const batchApplyUpdateAction: API.OperationMethod<BatchApplyUpdateActionMessage & RegionInput, UpdateActionResultsMessage, BatchApplyUpdateActionError, Credentials | HttpClient.HttpClient>;
export type BatchStopUpdateActionError = InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Stop the service update. For more information on service updates and stopping them,
 * see Stopping
 * Service Updates.
 */
export declare const batchStopUpdateAction: API.OperationMethod<BatchStopUpdateActionMessage & RegionInput, UpdateActionResultsMessage, BatchStopUpdateActionError, Credentials | HttpClient.HttpClient>;
export type CompleteMigrationError = InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidServerlessCacheStateFault | MigrationHealthFault | ReplicationGroupNotFoundFault | ReplicationGroupNotUnderMigrationFault | ServerlessCacheNotFoundFault | ServerlessCacheNotUnderMigrationFault | CommonErrors;
/**
 * Completes the migration of data.
 */
export declare const completeMigration: API.OperationMethod<CompleteMigrationMessage & RegionInput, CompleteMigrationResponse, CompleteMigrationError, Credentials | HttpClient.HttpClient>;
export type CopyServerlessCacheSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotAlreadyExistsFault | ServerlessCacheSnapshotNotFoundFault | ServerlessCacheSnapshotQuotaExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a copy of an existing serverless cache's snapshot. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const copyServerlessCacheSnapshot: API.OperationMethod<CopyServerlessCacheSnapshotRequest & RegionInput, CopyServerlessCacheSnapshotResponse, CopyServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type CopySnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidSnapshotStateFault | SnapshotAlreadyExistsFault | SnapshotNotFoundFault | SnapshotQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Makes a copy of an existing snapshot.
 *
 * This operation is valid for Valkey or Redis OSS only.
 *
 * Users or groups that have permissions to use the `CopySnapshot`
 * operation can create their own Amazon S3 buckets and copy snapshots to it. To
 * control access to your snapshots, use an IAM policy to control who has the ability
 * to use the `CopySnapshot` operation. For more information about using IAM
 * to control the use of ElastiCache operations, see Exporting
 * Snapshots and Authentication & Access
 * Control.
 *
 * You could receive the following error messages.
 *
 * **Error Messages**
 *
 * - **Error Message:** The S3 bucket %s is outside of
 * the region.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The S3 bucket %s does not
 * exist.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The S3 bucket %s is not owned
 * by the authenticated user.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The authenticated user does
 * not have sufficient permissions to perform the desired activity.
 *
 * **Solution:** Contact your system administrator
 * to get the needed permissions.
 *
 * - **Error Message:** The S3 bucket %s already
 * contains an object with key %s.
 *
 * **Solution:** Give the
 * `TargetSnapshotName` a new and unique value. If exporting a
 * snapshot, you could alternatively create a new Amazon S3 bucket and use this
 * same value for `TargetSnapshotName`.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted READ permissions %s on the S3 Bucket.
 *
 * **Solution:** Add List and Read permissions on
 * the bucket. For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted WRITE permissions %s on the S3 Bucket.
 *
 * **Solution:** Add Upload/Delete permissions on
 * the bucket. For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted READ_ACP permissions %s on the S3 Bucket.
 *
 * **Solution:** Add View Permissions on the bucket.
 * For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 */
export declare const copySnapshot: API.OperationMethod<CopySnapshotMessage & RegionInput, CopySnapshotResult, CopySnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateCacheClusterError = CacheClusterAlreadyExistsFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a cluster. All nodes in the cluster run the same protocol-compliant cache
 * engine software, either Memcached, Valkey or Redis OSS.
 *
 * This operation is not supported for Valkey or Redis OSS (cluster mode enabled) clusters.
 */
export declare const createCacheCluster: API.OperationMethod<CreateCacheClusterMessage & RegionInput, CreateCacheClusterResult, CreateCacheClusterError, Credentials | HttpClient.HttpClient>;
export type CreateCacheParameterGroupError = CacheParameterGroupAlreadyExistsFault | CacheParameterGroupQuotaExceededFault | InvalidCacheParameterGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new Amazon ElastiCache cache parameter group. An ElastiCache cache parameter
 * group is a collection of parameters and their values that are applied to all of the
 * nodes in any cluster or replication group using the CacheParameterGroup.
 *
 * A newly created CacheParameterGroup is an exact duplicate of the default parameter
 * group for the CacheParameterGroupFamily. To customize the newly created
 * CacheParameterGroup you can change the values of specific parameters. For more
 * information, see:
 *
 * - ModifyCacheParameterGroup in the ElastiCache API Reference.
 *
 * - Parameters and
 * Parameter Groups in the ElastiCache User Guide.
 */
export declare const createCacheParameterGroup: API.OperationMethod<CreateCacheParameterGroupMessage & RegionInput, CreateCacheParameterGroupResult, CreateCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCacheSecurityGroupError = CacheSecurityGroupAlreadyExistsFault | CacheSecurityGroupQuotaExceededFault | InvalidParameterCombinationException | InvalidParameterValueException | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new cache security group. Use a cache security group to control access to
 * one or more clusters.
 *
 * Cache security groups are only used when you are creating a cluster outside of an
 * Amazon Virtual Private Cloud (Amazon VPC). If you are creating a cluster inside of a
 * VPC, use a cache subnet group instead. For more information, see CreateCacheSubnetGroup.
 */
export declare const createCacheSecurityGroup: API.OperationMethod<CreateCacheSecurityGroupMessage & RegionInput, CreateCacheSecurityGroupResult, CreateCacheSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCacheSubnetGroupError = CacheSubnetGroupAlreadyExistsFault | CacheSubnetGroupQuotaExceededFault | CacheSubnetQuotaExceededFault | InvalidSubnet | SubnetNotAllowedFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new cache subnet group.
 *
 * Use this parameter only when you are creating a cluster in an Amazon Virtual Private
 * Cloud (Amazon VPC).
 */
export declare const createCacheSubnetGroup: API.OperationMethod<CreateCacheSubnetGroupMessage & RegionInput, CreateCacheSubnetGroupResult, CreateCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalReplicationGroupError = GlobalReplicationGroupAlreadyExistsFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Global Datastore offers fully managed, fast, reliable and secure
 * cross-region replication. Using Global Datastore with Valkey or Redis OSS, you can create cross-region
 * read replica clusters for ElastiCache to enable low-latency reads and disaster
 * recovery across regions. For more information, see Replication
 * Across Regions Using Global Datastore.
 *
 * - The **GlobalReplicationGroupIdSuffix** is the
 * name of the Global datastore.
 *
 * - The **PrimaryReplicationGroupId** represents the
 * name of the primary cluster that accepts writes and will replicate updates to
 * the secondary cluster.
 */
export declare const createGlobalReplicationGroup: API.OperationMethod<CreateGlobalReplicationGroupMessage & RegionInput, CreateGlobalReplicationGroupResult, CreateGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationGroupError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | ClusterQuotaForCustomerExceededFault | GlobalReplicationGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupAlreadyExistsFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | CommonErrors;
/**
 * Creates a Valkey or Redis OSS (cluster mode disabled) or a Valkey or Redis OSS (cluster mode enabled) replication
 * group.
 *
 * This API can be used to create a standalone regional replication group or a secondary
 * replication group associated with a Global datastore.
 *
 * A Valkey or Redis OSS (cluster mode disabled) replication group is a collection of nodes, where
 * one of the nodes is a read/write primary and the others are read-only replicas.
 * Writes to the primary are asynchronously propagated to the replicas.
 *
 * A Valkey or Redis OSS cluster-mode enabled cluster is comprised of from 1 to 90 shards (API/CLI:
 * node groups). Each shard has a primary node and up to 5 read-only replica nodes. The
 * configuration can range from 90 shards and 0 replicas to 15 shards and 5 replicas, which
 * is the maximum number or replicas allowed.
 *
 * The node or shard limit can be increased to a maximum of 500 per cluster if the Valkey or Redis OSS
 * engine version is 5.0.6 or higher. For example, you can choose to configure a 500 node
 * cluster that ranges between 83 shards (one primary and 5 replicas per shard) and 500
 * shards (single primary and no replicas). Make sure there are enough available IP
 * addresses to accommodate the increase. Common pitfalls include the subnets in the subnet
 * group have too small a CIDR range or the subnets are shared and heavily used by other
 * clusters. For more information, see Creating a Subnet
 * Group. For versions below 5.0.6, the limit is 250 per cluster.
 *
 * To request a limit increase, see Amazon Service Limits and
 * choose the limit type Nodes per cluster per instance
 * type.
 *
 * When a Valkey or Redis OSS (cluster mode disabled) replication group has been successfully created,
 * you can add one or more read replicas to it, up to a total of 5 read replicas. If you
 * need to increase or decrease the number of node groups (console: shards), you can use scaling.
 * For more information, see Scaling self-designed clusters in the ElastiCache User
 * Guide.
 *
 * This operation is valid for Valkey and Redis OSS only.
 */
export declare const createReplicationGroup: API.OperationMethod<CreateReplicationGroupMessage & RegionInput, CreateReplicationGroupResult, CreateReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type CreateServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | InvalidUserGroupStateFault | ServerlessCacheAlreadyExistsFault | ServerlessCacheNotFoundFault | ServerlessCacheQuotaForCustomerExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | CommonErrors;
/**
 * Creates a serverless cache.
 */
export declare const createServerlessCache: API.OperationMethod<CreateServerlessCacheRequest & RegionInput, CreateServerlessCacheResponse, CreateServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type CreateServerlessCacheSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotAlreadyExistsFault | ServerlessCacheSnapshotQuotaExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * This API creates a copy of an entire ServerlessCache at a specific moment in time. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const createServerlessCacheSnapshot: API.OperationMethod<CreateServerlessCacheSnapshotRequest & RegionInput, CreateServerlessCacheSnapshotResponse, CreateServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a copy of an entire cluster or replication group at a specific moment in
 * time.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotMessage & RegionInput, CreateSnapshotResult, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = DuplicateUserNameFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserAlreadyExistsFault | UserQuotaExceededFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 to 7.1: Creates a user. For more information, see
 * Using Role Based Access Control (RBAC).
 */
export declare const createUser: API.OperationMethod<CreateUserMessage & RegionInput, User, CreateUserError, Credentials | HttpClient.HttpClient>;
export type CreateUserGroupError = DefaultUserRequired | DuplicateUserNameFault | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserGroupAlreadyExistsFault | UserGroupQuotaExceededFault | UserNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 to 7.1: Creates a user group. For more
 * information, see Using Role Based Access Control (RBAC)
 */
export declare const createUserGroup: API.OperationMethod<CreateUserGroupMessage & RegionInput, UserGroup, CreateUserGroupError, Credentials | HttpClient.HttpClient>;
export type DecreaseNodeGroupsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Decreases the number of node groups in a Global datastore
 */
export declare const decreaseNodeGroupsInGlobalReplicationGroup: API.OperationMethod<DecreaseNodeGroupsInGlobalReplicationGroupMessage & RegionInput, DecreaseNodeGroupsInGlobalReplicationGroupResult, DecreaseNodeGroupsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DecreaseReplicaCountError = ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | NoOperationFault | ReplicationGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Dynamically decreases the number of replicas in a Valkey or Redis OSS (cluster mode disabled)
 * replication group or the number of replica nodes in one or more node groups (shards) of
 * a Valkey or Redis OSS (cluster mode enabled) replication group. This operation is performed with no
 * cluster down time.
 */
export declare const decreaseReplicaCount: API.OperationMethod<DecreaseReplicaCountMessage & RegionInput, DecreaseReplicaCountResult, DecreaseReplicaCountError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheClusterError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes a previously provisioned cluster. `DeleteCacheCluster` deletes all
 * associated cache nodes, node endpoints and the cluster itself. When you receive a
 * successful response from this operation, Amazon ElastiCache immediately begins deleting
 * the cluster; you cannot cancel or revert this operation.
 *
 * This operation is not valid for:
 *
 * - Valkey or Redis OSS (cluster mode enabled) clusters
 *
 * - Valkey or Redis OSS (cluster mode disabled) clusters
 *
 * - A cluster that is the last read replica of a replication group
 *
 * - A cluster that is the primary node of a replication group
 *
 * - A node group (shard) that has Multi-AZ mode enabled
 *
 * - A cluster from a Valkey or Redis OSS (cluster mode enabled) replication group
 *
 * - A cluster that is not in the `available` state
 */
export declare const deleteCacheCluster: API.OperationMethod<DeleteCacheClusterMessage & RegionInput, DeleteCacheClusterResult, DeleteCacheClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Deletes the specified cache parameter group. You cannot delete a cache parameter group
 * if it is associated with any cache clusters. You cannot delete the default cache
 * parameter groups in your account.
 */
export declare const deleteCacheParameterGroup: API.OperationMethod<DeleteCacheParameterGroupMessage & RegionInput, DeleteCacheParameterGroupResponse, DeleteCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheSecurityGroupError = CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Deletes a cache security group.
 *
 * You cannot delete a cache security group if it is associated with any
 * clusters.
 */
export declare const deleteCacheSecurityGroup: API.OperationMethod<DeleteCacheSecurityGroupMessage & RegionInput, DeleteCacheSecurityGroupResponse, DeleteCacheSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheSubnetGroupError = CacheSubnetGroupInUse | CacheSubnetGroupNotFoundFault | CommonErrors;
/**
 * Deletes a cache subnet group.
 *
 * You cannot delete a default cache subnet group or one that is associated with any
 * clusters.
 */
export declare const deleteCacheSubnetGroup: API.OperationMethod<DeleteCacheSubnetGroupMessage & RegionInput, DeleteCacheSubnetGroupResponse, DeleteCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Deleting a Global datastore is a two-step process:
 *
 * - First, you must DisassociateGlobalReplicationGroup to remove
 * the secondary clusters in the Global datastore.
 *
 * - Once the Global datastore contains only the primary cluster, you can use the
 * `DeleteGlobalReplicationGroup` API to delete the Global datastore
 * while retainining the primary cluster using
 * `RetainPrimaryReplicationGroup=true`.
 *
 * Since the Global Datastore has only a primary cluster, you can delete the Global
 * Datastore while retaining the primary by setting
 * `RetainPrimaryReplicationGroup=true`. The primary cluster is never
 * deleted when deleting a Global Datastore. It can only be deleted when it no longer is
 * associated with any Global Datastore.
 *
 * When you receive a successful response from this operation, Amazon ElastiCache
 * immediately begins deleting the selected resources; you cannot cancel or revert this
 * operation.
 */
export declare const deleteGlobalReplicationGroup: API.OperationMethod<DeleteGlobalReplicationGroupMessage & RegionInput, DeleteGlobalReplicationGroupResult, DeleteGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationGroupError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes an existing replication group. By default, this operation deletes the entire
 * replication group, including the primary/primaries and all of the read replicas. If the
 * replication group has only one primary, you can optionally delete only the read
 * replicas, while retaining the primary by setting
 * `RetainPrimaryCluster=true`.
 *
 * When you receive a successful response from this operation, Amazon ElastiCache
 * immediately begins deleting the selected resources; you cannot cancel or revert this
 * operation.
 *
 * - `CreateSnapshot` permission is required to create a final snapshot.
 * Without this permission, the API call will fail with an `Access Denied` exception.
 *
 * - This operation is valid for Redis OSS only.
 */
export declare const deleteReplicationGroup: API.OperationMethod<DeleteReplicationGroupMessage & RegionInput, DeleteReplicationGroupResult, DeleteReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotAlreadyExistsFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes a specified existing serverless cache.
 *
 * `CreateServerlessCacheSnapshot` permission is required to create a final snapshot.
 * Without this permission, the API call will fail with an `Access Denied` exception.
 */
export declare const deleteServerlessCache: API.OperationMethod<DeleteServerlessCacheRequest & RegionInput, DeleteServerlessCacheResponse, DeleteServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type DeleteServerlessCacheSnapshotError = InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes an existing serverless cache snapshot. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const deleteServerlessCacheSnapshot: API.OperationMethod<DeleteServerlessCacheSnapshotRequest & RegionInput, DeleteServerlessCacheSnapshotResponse, DeleteServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidSnapshotStateFault | SnapshotNotFoundFault | CommonErrors;
/**
 * Deletes an existing snapshot. When you receive a successful response from this
 * operation, ElastiCache immediately begins deleting the snapshot; you cannot cancel or
 * revert this operation.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotMessage & RegionInput, DeleteSnapshotResult, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = DefaultUserAssociatedToUserGroupFault | InvalidParameterValueException | InvalidUserStateFault | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 onwards: Deletes a user. The user will be removed from
 * all user groups and in turn removed from all replication groups. For more information,
 * see Using Role Based Access Control (RBAC).
 */
export declare const deleteUser: API.OperationMethod<DeleteUserMessage & RegionInput, User, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteUserGroupError = InvalidParameterValueException | InvalidUserGroupStateFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 onwards: Deletes a user group. The user group must first
 * be disassociated from the replication group before it can be deleted. For more
 * information, see Using Role Based Access Control (RBAC).
 */
export declare const deleteUserGroup: API.OperationMethod<DeleteUserGroupMessage & RegionInput, UserGroup, DeleteUserGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeCacheClustersError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns information about all provisioned clusters if no cluster identifier is
 * specified, or about a specific cache cluster if a cluster identifier is supplied.
 *
 * By default, abbreviated information about the clusters is returned. You can use the
 * optional *ShowCacheNodeInfo* flag to retrieve detailed information
 * about the cache nodes associated with the clusters. These details include the DNS
 * address and port for the cache node endpoint.
 *
 * If the cluster is in the *creating* state, only cluster-level
 * information is displayed until all of the nodes are successfully provisioned.
 *
 * If the cluster is in the *deleting* state, only cluster-level
 * information is displayed.
 *
 * If cache nodes are currently being added to the cluster, node endpoint information and
 * creation time for the additional nodes are not displayed until they are completely
 * provisioned. When the cluster state is *available*, the cluster is
 * ready for use.
 *
 * If cache nodes are currently being removed from the cluster, no endpoint information
 * for the removed nodes is displayed.
 */
export declare const describeCacheClusters: API.PaginatedOperationMethod<DescribeCacheClustersMessage & RegionInput, CacheClusterMessage, DescribeCacheClustersError, Credentials | HttpClient.HttpClient, CacheCluster>;
export type DescribeCacheEngineVersionsError = CommonErrors;
/**
 * Returns a list of the available cache engines and their versions.
 */
export declare const describeCacheEngineVersions: API.PaginatedOperationMethod<DescribeCacheEngineVersionsMessage & RegionInput, CacheEngineVersionMessage, DescribeCacheEngineVersionsError, Credentials | HttpClient.HttpClient, CacheEngineVersion>;
export type DescribeCacheParameterGroupsError = CacheParameterGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of cache parameter group descriptions. If a cache parameter group name
 * is specified, the list contains only the descriptions for that group.
 */
export declare const describeCacheParameterGroups: API.PaginatedOperationMethod<DescribeCacheParameterGroupsMessage & RegionInput, CacheParameterGroupsMessage, DescribeCacheParameterGroupsError, Credentials | HttpClient.HttpClient, CacheParameterGroup>;
export type DescribeCacheParametersError = CacheParameterGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns the detailed parameter list for a particular cache parameter group.
 */
export declare const describeCacheParameters: API.PaginatedOperationMethod<DescribeCacheParametersMessage & RegionInput, CacheParameterGroupDetails, DescribeCacheParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeCacheSecurityGroupsError = CacheSecurityGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of cache security group descriptions. If a cache security group name is
 * specified, the list contains only the description of that group. This applicable only
 * when you have ElastiCache in Classic setup
 */
export declare const describeCacheSecurityGroups: API.PaginatedOperationMethod<DescribeCacheSecurityGroupsMessage & RegionInput, CacheSecurityGroupMessage, DescribeCacheSecurityGroupsError, Credentials | HttpClient.HttpClient, CacheSecurityGroup>;
export type DescribeCacheSubnetGroupsError = CacheSubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of cache subnet group descriptions. If a subnet group name is
 * specified, the list contains only the description of that group. This is applicable only
 * when you have ElastiCache in VPC setup. All ElastiCache clusters now launch in VPC by
 * default.
 */
export declare const describeCacheSubnetGroups: API.PaginatedOperationMethod<DescribeCacheSubnetGroupsMessage & RegionInput, CacheSubnetGroupMessage, DescribeCacheSubnetGroupsError, Credentials | HttpClient.HttpClient, CacheSubnetGroup>;
export type DescribeEngineDefaultParametersError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns the default engine and system parameter information for the specified cache
 * engine.
 */
export declare const describeEngineDefaultParameters: API.PaginatedOperationMethod<DescribeEngineDefaultParametersMessage & RegionInput, DescribeEngineDefaultParametersResult, DescribeEngineDefaultParametersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventsError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns events related to clusters, cache security groups, and cache parameter groups.
 * You can obtain events specific to a particular cluster, cache security group, or cache
 * parameter group by providing the name as a parameter.
 *
 * By default, only the events occurring within the last hour are returned; however, you
 * can retrieve up to 14 days' worth of events if necessary.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage & RegionInput, EventsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeGlobalReplicationGroupsError = GlobalReplicationGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns information about a particular global replication group. If no identifier is
 * specified, returns information about all Global datastores.
 */
export declare const describeGlobalReplicationGroups: API.PaginatedOperationMethod<DescribeGlobalReplicationGroupsMessage & RegionInput, DescribeGlobalReplicationGroupsResult, DescribeGlobalReplicationGroupsError, Credentials | HttpClient.HttpClient, GlobalReplicationGroup>;
export type DescribeReplicationGroupsError = InvalidParameterCombinationException | InvalidParameterValueException | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Returns information about a particular replication group. If no identifier is
 * specified, `DescribeReplicationGroups` returns information about all
 * replication groups.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const describeReplicationGroups: API.PaginatedOperationMethod<DescribeReplicationGroupsMessage & RegionInput, ReplicationGroupMessage, DescribeReplicationGroupsError, Credentials | HttpClient.HttpClient, ReplicationGroup>;
export type DescribeReservedCacheNodesError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodeNotFoundFault | CommonErrors;
/**
 * Returns information about reserved cache nodes for this account, or about a specified
 * reserved cache node.
 */
export declare const describeReservedCacheNodes: API.PaginatedOperationMethod<DescribeReservedCacheNodesMessage & RegionInput, ReservedCacheNodeMessage, DescribeReservedCacheNodesError, Credentials | HttpClient.HttpClient, ReservedCacheNode>;
export type DescribeReservedCacheNodesOfferingsError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodesOfferingNotFoundFault | CommonErrors;
/**
 * Lists available reserved cache node offerings.
 */
export declare const describeReservedCacheNodesOfferings: API.PaginatedOperationMethod<DescribeReservedCacheNodesOfferingsMessage & RegionInput, ReservedCacheNodesOfferingMessage, DescribeReservedCacheNodesOfferingsError, Credentials | HttpClient.HttpClient, ReservedCacheNodesOffering>;
export type DescribeServerlessCachesError = InvalidParameterCombinationException | InvalidParameterValueException | ServerlessCacheNotFoundFault | CommonErrors;
/**
 * Returns information about a specific serverless cache.
 * If no identifier is specified, then the API returns information on all the serverless caches belonging to
 * this Amazon Web Services account.
 */
export declare const describeServerlessCaches: API.PaginatedOperationMethod<DescribeServerlessCachesRequest & RegionInput, DescribeServerlessCachesResponse, DescribeServerlessCachesError, Credentials | HttpClient.HttpClient, ServerlessCache>;
export type DescribeServerlessCacheSnapshotsError = InvalidParameterCombinationException | InvalidParameterValueException | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about serverless cache snapshots.
 * By default, this API lists all of the customer's serverless cache snapshots.
 * It can also describe a single serverless cache snapshot, or the snapshots associated with
 * a particular serverless cache. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const describeServerlessCacheSnapshots: API.PaginatedOperationMethod<DescribeServerlessCacheSnapshotsRequest & RegionInput, DescribeServerlessCacheSnapshotsResponse, DescribeServerlessCacheSnapshotsError, Credentials | HttpClient.HttpClient, ServerlessCacheSnapshot>;
export type DescribeServiceUpdatesError = InvalidParameterCombinationException | InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Returns details of the service updates
 */
export declare const describeServiceUpdates: API.PaginatedOperationMethod<DescribeServiceUpdatesMessage & RegionInput, ServiceUpdatesMessage, DescribeServiceUpdatesError, Credentials | HttpClient.HttpClient, ServiceUpdate>;
export type DescribeSnapshotsError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | SnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about cluster or replication group snapshots. By default,
 * `DescribeSnapshots` lists all of your snapshots; it can optionally
 * describe a single snapshot, or just the snapshots associated with a particular cache
 * cluster.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const describeSnapshots: API.PaginatedOperationMethod<DescribeSnapshotsMessage & RegionInput, DescribeSnapshotsListMessage, DescribeSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type DescribeUpdateActionsError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns details of the update actions
 */
export declare const describeUpdateActions: API.PaginatedOperationMethod<DescribeUpdateActionsMessage & RegionInput, UpdateActionsMessage, DescribeUpdateActionsError, Credentials | HttpClient.HttpClient, UpdateAction>;
export type DescribeUserGroupsError = InvalidParameterCombinationException | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of user groups.
 */
export declare const describeUserGroups: API.PaginatedOperationMethod<DescribeUserGroupsMessage & RegionInput, DescribeUserGroupsResult, DescribeUserGroupsError, Credentials | HttpClient.HttpClient, UserGroup>;
export type DescribeUsersError = InvalidParameterCombinationException | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Returns a list of users.
 */
export declare const describeUsers: API.PaginatedOperationMethod<DescribeUsersMessage & RegionInput, DescribeUsersResult, DescribeUsersError, Credentials | HttpClient.HttpClient, User>;
export type DisassociateGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Remove a secondary cluster from the Global datastore using the Global datastore name.
 * The secondary cluster will no longer receive updates from the primary cluster, but will
 * remain as a standalone cluster in that Amazon region.
 */
export declare const disassociateGlobalReplicationGroup: API.OperationMethod<DisassociateGlobalReplicationGroupMessage & RegionInput, DisassociateGlobalReplicationGroupResult, DisassociateGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ExportServerlessCacheSnapshotError = InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Provides the functionality to export the serverless cache snapshot data to Amazon S3. Available for Valkey and Redis OSS only.
 */
export declare const exportServerlessCacheSnapshot: API.OperationMethod<ExportServerlessCacheSnapshotRequest & RegionInput, ExportServerlessCacheSnapshotResponse, ExportServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type FailoverGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Used to failover the primary region to a secondary region. The secondary region will
 * become primary, and all other clusters will become secondary.
 */
export declare const failoverGlobalReplicationGroup: API.OperationMethod<FailoverGlobalReplicationGroupMessage & RegionInput, FailoverGlobalReplicationGroupResult, FailoverGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type IncreaseNodeGroupsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Increase the number of node groups in the Global datastore
 */
export declare const increaseNodeGroupsInGlobalReplicationGroup: API.OperationMethod<IncreaseNodeGroupsInGlobalReplicationGroupMessage & RegionInput, IncreaseNodeGroupsInGlobalReplicationGroupResult, IncreaseNodeGroupsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type IncreaseReplicaCountError = ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | NoOperationFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Dynamically increases the number of replicas in a Valkey or Redis OSS (cluster mode disabled)
 * replication group or the number of replica nodes in one or more node groups (shards) of
 * a Valkey or Redis OSS (cluster mode enabled) replication group. This operation is performed with no
 * cluster down time.
 */
export declare const increaseReplicaCount: API.OperationMethod<IncreaseReplicaCountMessage & RegionInput, IncreaseReplicaCountResult, IncreaseReplicaCountError, Credentials | HttpClient.HttpClient>;
export type ListAllowedNodeTypeModificationsError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Lists all available node types that you can scale with your cluster's replication
 * group's current node type.
 *
 * When you use the `ModifyCacheCluster` or
 * `ModifyReplicationGroup` operations to scale your cluster or replication
 * group, the value of the `CacheNodeType` parameter must be one of the node
 * types returned by this operation.
 */
export declare const listAllowedNodeTypeModifications: API.OperationMethod<ListAllowedNodeTypeModificationsMessage & RegionInput, AllowedNodeTypeModificationsMessage, ListAllowedNodeTypeModificationsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | GlobalReplicationGroupNotFoundFault | InvalidARNFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Lists all tags currently on a named resource.
 *
 * A tag is a key-value pair where the key and value are case-sensitive. You can use
 * tags to categorize and track all your ElastiCache resources.
 * When you add or remove tags on replication groups, those
 * actions will be replicated to all nodes in the replication group. For more information,
 * see Resource-level permissions.
 *
 * If the cluster is not in the *available* state,
 * `ListTagsForResource` returns an error.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage & RegionInput, TagListMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheClusterError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | CommonErrors;
/**
 * Modifies the settings for a cluster. You can use this operation to change one or more
 * cluster configuration parameters by specifying the parameters and the new values.
 */
export declare const modifyCacheCluster: API.OperationMethod<ModifyCacheClusterMessage & RegionInput, ModifyCacheClusterResult, ModifyCacheClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the parameters of a cache parameter group. You can modify up to 20 parameters
 * in a single request by submitting a list parameter name and value pairs.
 */
export declare const modifyCacheParameterGroup: API.OperationMethod<ModifyCacheParameterGroupMessage & RegionInput, CacheParameterGroupNameMessage, ModifyCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheSubnetGroupError = CacheSubnetGroupNotFoundFault | CacheSubnetQuotaExceededFault | InvalidSubnet | SubnetInUse | SubnetNotAllowedFault | CommonErrors;
/**
 * Modifies an existing cache subnet group.
 */
export declare const modifyCacheSubnetGroup: API.OperationMethod<ModifyCacheSubnetGroupMessage & RegionInput, ModifyCacheSubnetGroupResult, ModifyCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the settings for a Global datastore.
 */
export declare const modifyGlobalReplicationGroup: API.OperationMethod<ModifyGlobalReplicationGroupMessage & RegionInput, ModifyGlobalReplicationGroupResult, ModifyGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationGroupError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidCacheSecurityGroupStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidUserGroupStateFault | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * Modifies the settings for a replication group. This is limited to Valkey and Redis OSS 7 and above.
 *
 * - Scaling for Valkey or Redis OSS (cluster mode enabled) in
 * the ElastiCache User Guide
 *
 * - ModifyReplicationGroupShardConfiguration in the ElastiCache API
 * Reference
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const modifyReplicationGroup: API.OperationMethod<ModifyReplicationGroupMessage & RegionInput, ModifyReplicationGroupResult, ModifyReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationGroupShardConfigurationError = InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Modifies a replication group's shards (node groups) by allowing you to add shards,
 * remove shards, or rebalance the keyspaces among existing shards.
 */
export declare const modifyReplicationGroupShardConfiguration: API.OperationMethod<ModifyReplicationGroupShardConfigurationMessage & RegionInput, ModifyReplicationGroupShardConfigurationResult, ModifyReplicationGroupShardConfigurationError, Credentials | HttpClient.HttpClient>;
export type ModifyServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | InvalidUserGroupStateFault | ServerlessCacheNotFoundFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * This API modifies the attributes of a serverless cache.
 */
export declare const modifyServerlessCache: API.OperationMethod<ModifyServerlessCacheRequest & RegionInput, ModifyServerlessCacheResponse, ModifyServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type ModifyUserError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserStateFault | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Changes user password(s) and/or access string.
 */
export declare const modifyUser: API.OperationMethod<ModifyUserMessage & RegionInput, User, ModifyUserError, Credentials | HttpClient.HttpClient>;
export type ModifyUserGroupError = DefaultUserRequired | DuplicateUserNameFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserGroupStateFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Changes the list of users that belong to the user group.
 */
export declare const modifyUserGroup: API.OperationMethod<ModifyUserGroupMessage & RegionInput, UserGroup, ModifyUserGroupError, Credentials | HttpClient.HttpClient>;
export type PrepareMigrationError = InvalidParameterValueException | InvalidServerlessCacheStateFault | ServerlessCacheAlreadyUnderMigrationFault | ServerlessCacheNotFoundFault | CommonErrors;
/**
 * Prepares the serverless cache for data migration by validating the configuration and setting up the migration resources.
 */
export declare const prepareMigration: API.OperationMethod<PrepareMigrationRequest & RegionInput, PrepareMigrationResponse, PrepareMigrationError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedCacheNodesOfferingError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodeAlreadyExistsFault | ReservedCacheNodeQuotaExceededFault | ReservedCacheNodesOfferingNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Allows you to purchase a reserved cache node offering. Reserved nodes are not eligible
 * for cancellation and are non-refundable. For more information, see Managing Costs with Reserved Nodes.
 */
export declare const purchaseReservedCacheNodesOffering: API.OperationMethod<PurchaseReservedCacheNodesOfferingMessage & RegionInput, PurchaseReservedCacheNodesOfferingResult, PurchaseReservedCacheNodesOfferingError, Credentials | HttpClient.HttpClient>;
export type RebalanceSlotsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Redistribute slots to ensure uniform distribution across existing shards in the
 * cluster.
 */
export declare const rebalanceSlotsInGlobalReplicationGroup: API.OperationMethod<RebalanceSlotsInGlobalReplicationGroupMessage & RegionInput, RebalanceSlotsInGlobalReplicationGroupResult, RebalanceSlotsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type RebootCacheClusterError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | CommonErrors;
/**
 * Reboots some, or all, of the cache nodes within a provisioned cluster. This operation
 * applies any modified cache parameter groups to the cluster. The reboot operation takes
 * place as soon as possible, and results in a momentary outage to the cluster. During the
 * reboot, the cluster status is set to REBOOTING.
 *
 * The reboot causes the contents of the cache (for each cache node being rebooted) to be
 * lost.
 *
 * When the reboot is complete, a cluster event is created.
 *
 * Rebooting a cluster is currently supported on Memcached, Valkey and Redis OSS (cluster mode
 * disabled) clusters. Rebooting is not supported on Valkey or Redis OSS (cluster mode enabled)
 * clusters.
 *
 * If you make changes to parameters that require a Valkey or Redis OSS (cluster mode enabled) cluster
 * reboot for the changes to be applied, see Rebooting a Cluster for an alternate process.
 */
export declare const rebootCacheCluster: API.OperationMethod<RebootCacheClusterMessage & RegionInput, RebootCacheClusterResult, RebootCacheClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | GlobalReplicationGroupNotFoundFault | InvalidARNFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | TagNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Removes the tags identified by the `TagKeys` list from the named resource.
 * A tag is a key-value pair where the key and value are case-sensitive. You can use tags
 * to categorize and track all your ElastiCache resources.
 * When you add or remove tags on replication groups, those actions will
 * be replicated to all nodes in the replication group. For more information, see Resource-level permissions.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage & RegionInput, TagListMessage, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the parameters of a cache parameter group to the engine or system default
 * value. You can reset specific parameters by submitting a list of parameter names. To
 * reset the entire cache parameter group, specify the `ResetAllParameters` and
 * `CacheParameterGroupName` parameters.
 */
export declare const resetCacheParameterGroup: API.OperationMethod<ResetCacheParameterGroupMessage & RegionInput, CacheParameterGroupNameMessage, ResetCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type RevokeCacheSecurityGroupIngressError = AuthorizationNotFoundFault | CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Revokes ingress from a cache security group. Use this operation to disallow access
 * from an Amazon EC2 security group that had been previously authorized.
 */
export declare const revokeCacheSecurityGroupIngress: API.OperationMethod<RevokeCacheSecurityGroupIngressMessage & RegionInput, RevokeCacheSecurityGroupIngressResult, RevokeCacheSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type StartMigrationError = InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidServerlessCacheStateFault | MigrationHealthFault | ReplicationGroupAlreadyUnderMigrationFault | ReplicationGroupNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheNotUnderMigrationFault | CommonErrors;
/**
 * Starts the migration of data.
 */
export declare const startMigration: API.OperationMethod<StartMigrationMessage & RegionInput, StartMigrationResponse, StartMigrationError, Credentials | HttpClient.HttpClient>;
export type StopMigrationError = InvalidParameterValueException | InvalidServerlessCacheStateFault | ServerlessCacheNotFoundFault | ServerlessCacheNotUnderMigrationFault | CommonErrors;
/**
 * Stops an ongoing data sync between the source and the serverless cache. The migration remains
 * open and the data sync can be restarted. This operation is valid only while the migration is
 * syncing; during cutover it returns
 * `InvalidServerlessCacheStateFault`.
 */
export declare const stopMigration: API.OperationMethod<StopMigrationRequest & RegionInput, StopMigrationResponse, StopMigrationError, Credentials | HttpClient.HttpClient>;
export type TestFailoverError = APICallRateForCustomerExceededFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | NodeGroupNotFoundFault | ReplicationGroupNotFoundFault | TestFailoverNotAvailableFault | CommonErrors;
/**
 * Represents the input of a `TestFailover` operation which tests automatic
 * failover on a specified node group (called shard in the console) in a replication group
 * (called cluster in the console).
 *
 * This API is designed for testing the behavior of your application in case of
 * ElastiCache failover. It is not designed to be an operational tool for initiating a
 * failover to overcome a problem you may have with the cluster. Moreover, in certain
 * conditions such as large-scale operational events, Amazon may block this API.
 *
 * **Note the following**
 *
 * - A customer can use this operation to test automatic failover on up to 15 shards
 * (called node groups in the ElastiCache API and Amazon CLI) in any rolling
 * 24-hour period.
 *
 * - If calling this operation on shards in different clusters (called replication
 * groups in the API and CLI), the calls can be made concurrently.
 *
 * - If calling this operation multiple times on different shards in the same Valkey or Redis OSS (cluster mode enabled) replication group, the first node replacement must
 * complete before a subsequent call can be made.
 *
 * - To determine whether the node replacement is complete you can check Events
 * using the Amazon ElastiCache console, the Amazon CLI, or the ElastiCache API.
 * Look for the following automatic failover related events, listed here in order
 * of occurrance:
 *
 * - Replication group message: Test Failover API called for node
 * group
 *
 * - Cache cluster message: Failover from primary node
 * to replica node
 * completed
 *
 * - Replication group message: Failover from primary node
 * to replica node
 * completed
 *
 * - Cache cluster message: Recovering cache nodes
 *
 * - Cache cluster message: Finished recovery for cache nodes
 *
 * For more information see:
 *
 * - Viewing
 * ElastiCache Events in the ElastiCache User
 * Guide
 *
 * - DescribeEvents in the ElastiCache API Reference
 *
 * Also see, Testing
 * Multi-AZ in the *ElastiCache User Guide*.
 */
export declare const testFailover: API.OperationMethod<TestFailoverMessage & RegionInput, TestFailoverResult, TestFailoverError, Credentials | HttpClient.HttpClient>;
export type TestMigrationError = InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupAlreadyUnderMigrationFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Async API to test connection between source and target replication group.
 */
export declare const testMigration: API.OperationMethod<TestMigrationMessage & RegionInput, TestMigrationResponse, TestMigrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elasticache.d.ts.map