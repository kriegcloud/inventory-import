import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const WAFAssociatedItemException_base: S.TaggedErrorClass<"WAFAssociatedItemException", {
    readonly message: any;
}>;
export declare class WAFAssociatedItemException extends /*@__PURE__*/ WAFAssociatedItemException_base {
}
declare const WAFConfigurationWarningException_base: S.TaggedErrorClass<"WAFConfigurationWarningException", {
    readonly message: any;
}>;
export declare class WAFConfigurationWarningException extends /*@__PURE__*/ WAFConfigurationWarningException_base {
}
declare const WAFDuplicateItemException_base: S.TaggedErrorClass<"WAFDuplicateItemException", {
    readonly message: any;
}>;
export declare class WAFDuplicateItemException extends /*@__PURE__*/ WAFDuplicateItemException_base {
}
declare const WAFExpiredManagedRuleGroupVersionException_base: S.TaggedErrorClass<"WAFExpiredManagedRuleGroupVersionException", {
    readonly message: any;
}>;
export declare class WAFExpiredManagedRuleGroupVersionException extends /*@__PURE__*/ WAFExpiredManagedRuleGroupVersionException_base {
}
declare const WAFFeatureNotIncludedInPricingPlanException_base: S.TaggedErrorClass<"WAFFeatureNotIncludedInPricingPlanException", {
    readonly message: any;
    readonly DisallowedFeatures: any;
}>;
export declare class WAFFeatureNotIncludedInPricingPlanException extends /*@__PURE__*/ WAFFeatureNotIncludedInPricingPlanException_base {
}
declare const WAFInternalErrorException_base: S.TaggedErrorClass<"WAFInternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class WAFInternalErrorException extends /*@__PURE__*/ WAFInternalErrorException_base {
}
declare const WAFInvalidOperationException_base: S.TaggedErrorClass<"WAFInvalidOperationException", {
    readonly message: any;
}>;
export declare class WAFInvalidOperationException extends /*@__PURE__*/ WAFInvalidOperationException_base {
}
declare const WAFInvalidParameterException_base: S.TaggedErrorClass<"WAFInvalidParameterException", {
    readonly message: any;
    readonly Field: any;
    readonly Parameter: any;
    readonly Reason: any;
}>;
export declare class WAFInvalidParameterException extends /*@__PURE__*/ WAFInvalidParameterException_base {
}
declare const WAFInvalidPermissionPolicyException_base: S.TaggedErrorClass<"WAFInvalidPermissionPolicyException", {
    readonly message: any;
}>;
export declare class WAFInvalidPermissionPolicyException extends /*@__PURE__*/ WAFInvalidPermissionPolicyException_base {
}
declare const WAFInvalidResourceException_base: S.TaggedErrorClass<"WAFInvalidResourceException", {
    readonly message: any;
}>;
export declare class WAFInvalidResourceException extends /*@__PURE__*/ WAFInvalidResourceException_base {
}
declare const WAFLimitsExceededException_base: S.TaggedErrorClass<"WAFLimitsExceededException", {
    readonly message: any;
    readonly SourceType: any;
}>;
export declare class WAFLimitsExceededException extends /*@__PURE__*/ WAFLimitsExceededException_base {
}
declare const WAFLogDestinationPermissionIssueException_base: S.TaggedErrorClass<"WAFLogDestinationPermissionIssueException", {
    readonly message: any;
}>;
export declare class WAFLogDestinationPermissionIssueException extends /*@__PURE__*/ WAFLogDestinationPermissionIssueException_base {
}
declare const WAFNonexistentItemException_base: S.TaggedErrorClass<"WAFNonexistentItemException", {
    readonly message: any;
}>;
export declare class WAFNonexistentItemException extends /*@__PURE__*/ WAFNonexistentItemException_base {
}
declare const WAFOptimisticLockException_base: S.TaggedErrorClass<"WAFOptimisticLockException", {
    readonly message: any;
}>;
export declare class WAFOptimisticLockException extends /*@__PURE__*/ WAFOptimisticLockException_base {
}
declare const WAFServiceLinkedRoleErrorException_base: S.TaggedErrorClass<"WAFServiceLinkedRoleErrorException", {
    readonly message: any;
}>;
export declare class WAFServiceLinkedRoleErrorException extends /*@__PURE__*/ WAFServiceLinkedRoleErrorException_base {
}
declare const WAFSubscriptionNotFoundException_base: S.TaggedErrorClass<"WAFSubscriptionNotFoundException", {
    readonly message: any;
}>;
export declare class WAFSubscriptionNotFoundException extends /*@__PURE__*/ WAFSubscriptionNotFoundException_base {
}
declare const WAFTagOperationException_base: S.TaggedErrorClass<"WAFTagOperationException", {
    readonly message: any;
}>;
export declare class WAFTagOperationException extends /*@__PURE__*/ WAFTagOperationException_base {
}
declare const WAFTagOperationInternalErrorException_base: S.TaggedErrorClass<"WAFTagOperationInternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class WAFTagOperationInternalErrorException extends /*@__PURE__*/ WAFTagOperationInternalErrorException_base {
}
declare const WAFUnavailableEntityException_base: S.TaggedErrorClass<"WAFUnavailableEntityException", {
    readonly message: any;
}>;
export declare class WAFUnavailableEntityException extends /*@__PURE__*/ WAFUnavailableEntityException_base {
}
declare const WAFUnsupportedAggregateKeyTypeException_base: S.TaggedErrorClass<"WAFUnsupportedAggregateKeyTypeException", {
    readonly message: any;
}>;
export declare class WAFUnsupportedAggregateKeyTypeException extends /*@__PURE__*/ WAFUnsupportedAggregateKeyTypeException_base {
}
export type ResourceArn = string;
export interface AssociateWebACLRequest {
    WebACLArn: string;
    ResourceArn: string;
}
export interface AssociateWebACLResponse {
}
export type Scope = "CLOUDFRONT" | "REGIONAL" | (string & {});
export type EntityName = string;
export type RulePriority = number;
export type SearchString = Uint8Array;
export type FieldToMatchData = string;
export interface SingleHeader {
    Name: string;
}
export interface SingleQueryArgument {
    Name: string;
}
export interface AllQueryArguments {
}
export interface UriPath {
}
export interface QueryString {
}
export type OversizeHandling = "CONTINUE" | "MATCH" | "NO_MATCH" | (string & {});
export interface Body {
    OversizeHandling?: OversizeHandling | undefined;
}
export interface Method {
}
export interface All {
}
export type JsonPointerPath = string;
export type JsonPointerPaths = string[];
export interface JsonMatchPattern {
    All?: All | undefined;
    IncludedPaths?: string[] | undefined;
}
export type JsonMatchScope = "ALL" | "KEY" | "VALUE" | (string & {});
export type BodyParsingFallbackBehavior = "MATCH" | "NO_MATCH" | "EVALUATE_AS_STRING" | (string & {});
export interface JsonBody {
    MatchPattern: JsonMatchPattern;
    MatchScope: JsonMatchScope;
    InvalidFallbackBehavior?: BodyParsingFallbackBehavior | undefined;
    OversizeHandling?: OversizeHandling | undefined;
}
export type HeaderNames = string[];
export interface HeaderMatchPattern {
    All?: All | undefined;
    IncludedHeaders?: string[] | undefined;
    ExcludedHeaders?: string[] | undefined;
}
export type MapMatchScope = "ALL" | "KEY" | "VALUE" | (string & {});
export interface Headers {
    MatchPattern: HeaderMatchPattern;
    MatchScope: MapMatchScope;
    OversizeHandling: OversizeHandling;
}
export type SingleCookieName = string;
export type CookieNames = string[];
export interface CookieMatchPattern {
    All?: All | undefined;
    IncludedCookies?: string[] | undefined;
    ExcludedCookies?: string[] | undefined;
}
export interface Cookies {
    MatchPattern: CookieMatchPattern;
    MatchScope: MapMatchScope;
    OversizeHandling: OversizeHandling;
}
export interface HeaderOrder {
    OversizeHandling: OversizeHandling;
}
export type FallbackBehavior = "MATCH" | "NO_MATCH" | (string & {});
export interface JA3Fingerprint {
    FallbackBehavior: FallbackBehavior;
}
export interface JA4Fingerprint {
    FallbackBehavior: FallbackBehavior;
}
export interface UriFragment {
    FallbackBehavior?: FallbackBehavior | undefined;
}
export interface FieldToMatch {
    SingleHeader?: SingleHeader | undefined;
    SingleQueryArgument?: SingleQueryArgument | undefined;
    AllQueryArguments?: AllQueryArguments | undefined;
    UriPath?: UriPath | undefined;
    QueryString?: QueryString | undefined;
    Body?: Body | undefined;
    Method?: Method | undefined;
    JsonBody?: JsonBody | undefined;
    Headers?: Headers | undefined;
    Cookies?: Cookies | undefined;
    HeaderOrder?: HeaderOrder | undefined;
    JA3Fingerprint?: JA3Fingerprint | undefined;
    JA4Fingerprint?: JA4Fingerprint | undefined;
    UriFragment?: UriFragment | undefined;
}
export type TextTransformationPriority = number;
export type TextTransformationType = "NONE" | "COMPRESS_WHITE_SPACE" | "HTML_ENTITY_DECODE" | "LOWERCASE" | "CMD_LINE" | "URL_DECODE" | "BASE64_DECODE" | "HEX_DECODE" | "MD5" | "REPLACE_COMMENTS" | "ESCAPE_SEQ_DECODE" | "SQL_HEX_DECODE" | "CSS_DECODE" | "JS_DECODE" | "NORMALIZE_PATH" | "NORMALIZE_PATH_WIN" | "REMOVE_NULLS" | "REPLACE_NULLS" | "BASE64_DECODE_EXT" | "URL_DECODE_UNI" | "UTF8_TO_UNICODE" | "REMOVE_WHITESPACE" | "TRIM" | "TRIM_LEFT" | "TRIM_RIGHT" | "REMOVE_COMMENTS_CHAR" | "UPPERCASE" | "CMD_LINE_WIN" | "CMD_LINE_UNIX" | "JS_DECODE_EXT" | "SHA256" | (string & {});
export interface TextTransformation {
    Priority: number;
    Type: TextTransformationType;
}
export type TextTransformations = TextTransformation[];
export type PreParseTextTransformationPriority = number;
export type PreParseTextTransformationType = "NONE" | "URL_DECODE" | "URL_DECODE_UNI" | "COMBINE_DUPLICATE_QUERY_ARGS_BY_COMMA" | "REPLACE_SEMICOLONS_WITH_AMPERSANDS" | (string & {});
export interface PreParseTextTransformation {
    Priority: number;
    Type: PreParseTextTransformationType;
}
export type PreParseTextTransformations = PreParseTextTransformation[];
export type PositionalConstraint = "EXACTLY" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "CONTAINS_WORD" | (string & {});
export interface ByteMatchStatement {
    SearchString: Uint8Array;
    FieldToMatch: FieldToMatch;
    TextTransformations: TextTransformation[];
    PreParseTextTransformations?: PreParseTextTransformation[] | undefined;
    PositionalConstraint: PositionalConstraint;
}
export type SensitivityLevel = "LOW" | "HIGH" | (string & {});
export interface SqliMatchStatement {
    FieldToMatch: FieldToMatch;
    TextTransformations: TextTransformation[];
    PreParseTextTransformations?: PreParseTextTransformation[] | undefined;
    SensitivityLevel?: SensitivityLevel | undefined;
}
export interface XssMatchStatement {
    FieldToMatch: FieldToMatch;
    TextTransformations: TextTransformation[];
    PreParseTextTransformations?: PreParseTextTransformation[] | undefined;
}
export type ComparisonOperator = "EQ" | "NE" | "LE" | "LT" | "GE" | "GT" | (string & {});
export type Size = number;
export interface SizeConstraintStatement {
    FieldToMatch: FieldToMatch;
    ComparisonOperator: ComparisonOperator;
    Size: number;
    TextTransformations: TextTransformation[];
    PreParseTextTransformations?: PreParseTextTransformation[] | undefined;
}
export type CountryCode = "AF" | "AX" | "AL" | "DZ" | "AS" | "AD" | "AO" | "AI" | "AQ" | "AG" | "AR" | "AM" | "AW" | "AU" | "AT" | "AZ" | "BS" | "BH" | "BD" | "BB" | "BY" | "BE" | "BZ" | "BJ" | "BM" | "BT" | "BO" | "BQ" | "BA" | "BW" | "BV" | "BR" | "IO" | "BN" | "BG" | "BF" | "BI" | "KH" | "CM" | "CA" | "CV" | "KY" | "CF" | "TD" | "CL" | "CN" | "CX" | "CC" | "CO" | "KM" | "CG" | "CD" | "CK" | "CR" | "CI" | "HR" | "CU" | "CW" | "CY" | "CZ" | "DK" | "DJ" | "DM" | "DO" | "EC" | "EG" | "SV" | "GQ" | "ER" | "EE" | "ET" | "FK" | "FO" | "FJ" | "FI" | "FR" | "GF" | "PF" | "TF" | "GA" | "GM" | "GE" | "DE" | "GH" | "GI" | "GR" | "GL" | "GD" | "GP" | "GU" | "GT" | "GG" | "GN" | "GW" | "GY" | "HT" | "HM" | "VA" | "HN" | "HK" | "HU" | "IS" | "IN" | "ID" | "IR" | "IQ" | "IE" | "IM" | "IL" | "IT" | "JM" | "JP" | "JE" | "JO" | "KZ" | "KE" | "KI" | "KP" | "KR" | "KW" | "KG" | "LA" | "LV" | "LB" | "LS" | "LR" | "LY" | "LI" | "LT" | "LU" | "MO" | "MK" | "MG" | "MW" | "MY" | "MV" | "ML" | "MT" | "MH" | "MQ" | "MR" | "MU" | "YT" | "MX" | "FM" | "MD" | "MC" | "MN" | "ME" | "MS" | "MA" | "MZ" | "MM" | "NA" | "NR" | "NP" | "NL" | "NC" | "NZ" | "NI" | "NE" | "NG" | "NU" | "NF" | "MP" | "NO" | "OM" | "PK" | "PW" | "PS" | "PA" | "PG" | "PY" | "PE" | "PH" | "PN" | "PL" | "PT" | "PR" | "QA" | "RE" | "RO" | "RU" | "RW" | "BL" | "SH" | "KN" | "LC" | "MF" | "PM" | "VC" | "WS" | "SM" | "ST" | "SA" | "SN" | "RS" | "SC" | "SL" | "SG" | "SX" | "SK" | "SI" | "SB" | "SO" | "ZA" | "GS" | "SS" | "ES" | "LK" | "SD" | "SR" | "SJ" | "SZ" | "SE" | "CH" | "SY" | "TW" | "TJ" | "TZ" | "TH" | "TL" | "TG" | "TK" | "TO" | "TT" | "TN" | "TR" | "TM" | "TC" | "TV" | "UG" | "UA" | "AE" | "GB" | "US" | "UM" | "UY" | "UZ" | "VU" | "VE" | "VN" | "VG" | "VI" | "WF" | "EH" | "YE" | "ZM" | "ZW" | "XK" | (string & {});
export type CountryCodes = CountryCode[];
export type ForwardedIPHeaderName = string;
export interface ForwardedIPConfig {
    HeaderName: string;
    FallbackBehavior: FallbackBehavior;
}
export interface GeoMatchStatement {
    CountryCodes?: CountryCode[] | undefined;
    ForwardedIPConfig?: ForwardedIPConfig | undefined;
}
export interface ExcludedRule {
    Name: string;
}
export type ExcludedRules = ExcludedRule[];
export type ResponseStatusCode = number;
export type CustomHTTPHeaderName = string;
export type CustomHTTPHeaderValue = string;
export interface CustomHTTPHeader {
    Name: string;
    Value: string;
}
export type CustomHTTPHeaders = CustomHTTPHeader[];
export interface CustomResponse {
    ResponseCode: number;
    CustomResponseBodyKey?: string | undefined;
    ResponseHeaders?: CustomHTTPHeader[] | undefined;
}
export interface BlockAction {
    CustomResponse?: CustomResponse | undefined;
}
export interface CustomRequestHandling {
    InsertHeaders: CustomHTTPHeader[];
}
export interface AllowAction {
    CustomRequestHandling?: CustomRequestHandling | undefined;
}
export interface CountAction {
    CustomRequestHandling?: CustomRequestHandling | undefined;
}
export interface CaptchaAction {
    CustomRequestHandling?: CustomRequestHandling | undefined;
}
export interface ChallengeAction {
    CustomRequestHandling?: CustomRequestHandling | undefined;
}
export type PriceMultiplier = string;
export interface MonetizeAction {
    PriceMultiplier?: string | undefined;
}
export interface RuleAction {
    Block?: BlockAction | undefined;
    Allow?: AllowAction | undefined;
    Count?: CountAction | undefined;
    Captcha?: CaptchaAction | undefined;
    Challenge?: ChallengeAction | undefined;
    Monetize?: MonetizeAction | undefined;
}
export interface RuleActionOverride {
    Name: string;
    ActionToUse: RuleAction;
}
export type RuleActionOverrides = RuleActionOverride[];
export interface RuleGroupReferenceStatement {
    ARN: string;
    ExcludedRules?: ExcludedRule[] | undefined;
    RuleActionOverrides?: RuleActionOverride[] | undefined;
}
export type ForwardedIPPosition = "FIRST" | "LAST" | "ANY" | (string & {});
export interface IPSetForwardedIPConfig {
    HeaderName: string;
    FallbackBehavior: FallbackBehavior;
    Position: ForwardedIPPosition;
}
export interface IPSetReferenceStatement {
    ARN: string;
    IPSetForwardedIPConfig?: IPSetForwardedIPConfig | undefined;
}
export interface RegexPatternSetReferenceStatement {
    ARN: string;
    FieldToMatch: FieldToMatch;
    TextTransformations: TextTransformation[];
    PreParseTextTransformations?: PreParseTextTransformation[] | undefined;
}
export type RateLimit = number;
export type EvaluationWindowSec = number;
export type RateBasedStatementAggregateKeyType = "IP" | "FORWARDED_IP" | "CUSTOM_KEYS" | "CONSTANT" | (string & {});
export interface RateLimitHeader {
    Name: string;
    TextTransformations: TextTransformation[];
}
export interface RateLimitCookie {
    Name: string;
    TextTransformations: TextTransformation[];
}
export interface RateLimitQueryArgument {
    Name: string;
    TextTransformations: TextTransformation[];
}
export interface RateLimitQueryString {
    TextTransformations: TextTransformation[];
}
export interface RateLimitHTTPMethod {
}
export interface RateLimitForwardedIP {
}
export interface RateLimitIP {
}
export type LabelNamespace = string;
export interface RateLimitLabelNamespace {
    Namespace: string;
}
export interface RateLimitUriPath {
    TextTransformations: TextTransformation[];
}
export interface RateLimitJA3Fingerprint {
    FallbackBehavior: FallbackBehavior;
}
export interface RateLimitJA4Fingerprint {
    FallbackBehavior: FallbackBehavior;
}
export interface RateLimitAsn {
}
export interface RateBasedStatementCustomKey {
    Header?: RateLimitHeader | undefined;
    Cookie?: RateLimitCookie | undefined;
    QueryArgument?: RateLimitQueryArgument | undefined;
    QueryString?: RateLimitQueryString | undefined;
    HTTPMethod?: RateLimitHTTPMethod | undefined;
    ForwardedIP?: RateLimitForwardedIP | undefined;
    IP?: RateLimitIP | undefined;
    LabelNamespace?: RateLimitLabelNamespace | undefined;
    UriPath?: RateLimitUriPath | undefined;
    JA3Fingerprint?: RateLimitJA3Fingerprint | undefined;
    JA4Fingerprint?: RateLimitJA4Fingerprint | undefined;
    ASN?: RateLimitAsn | undefined;
}
export type RateBasedStatementCustomKeys = RateBasedStatementCustomKey[];
export interface RateBasedStatement {
    Limit: number;
    EvaluationWindowSec?: number | undefined;
    AggregateKeyType: RateBasedStatementAggregateKeyType;
    ScopeDownStatement?: Statement | undefined;
    ForwardedIPConfig?: ForwardedIPConfig | undefined;
    CustomKeys?: RateBasedStatementCustomKey[] | undefined;
}
export type Statements = Statement[];
export interface AndStatement {
    Statements: Statement[];
}
export interface OrStatement {
    Statements: Statement[];
}
export interface NotStatement {
    Statement: Statement;
}
export type VendorName = string;
export type VersionKeyString = string;
export type LoginPathString = string;
export type PayloadType = "JSON" | "FORM_ENCODED" | (string & {});
export type FieldIdentifier = string;
export interface UsernameField {
    Identifier: string;
}
export interface PasswordField {
    Identifier: string;
}
export type InspectionLevel = "COMMON" | "TARGETED" | (string & {});
export type EnableMachineLearning = boolean;
export interface AWSManagedRulesBotControlRuleSet {
    InspectionLevel: InspectionLevel;
    EnableMachineLearning?: boolean | undefined;
}
export interface RequestInspection {
    PayloadType: PayloadType;
    UsernameField: UsernameField;
    PasswordField: PasswordField;
}
export type SuccessCode = number;
export type ResponseInspectionStatusCodeSuccessCodes = number[];
export type FailureCode = number;
export type ResponseInspectionStatusCodeFailureCodes = number[];
export interface ResponseInspectionStatusCode {
    SuccessCodes: number[];
    FailureCodes: number[];
}
export type ResponseInspectionHeaderName = string;
export type SuccessValue = string;
export type ResponseInspectionHeaderSuccessValues = string[];
export type FailureValue = string;
export type ResponseInspectionHeaderFailureValues = string[];
export interface ResponseInspectionHeader {
    Name: string;
    SuccessValues: string[];
    FailureValues: string[];
}
export type ResponseInspectionBodyContainsSuccessStrings = string[];
export type ResponseInspectionBodyContainsFailureStrings = string[];
export interface ResponseInspectionBodyContains {
    SuccessStrings: string[];
    FailureStrings: string[];
}
export type ResponseInspectionJsonSuccessValues = string[];
export type ResponseInspectionJsonFailureValues = string[];
export interface ResponseInspectionJson {
    Identifier: string;
    SuccessValues: string[];
    FailureValues: string[];
}
export interface ResponseInspection {
    StatusCode?: ResponseInspectionStatusCode | undefined;
    Header?: ResponseInspectionHeader | undefined;
    BodyContains?: ResponseInspectionBodyContains | undefined;
    Json?: ResponseInspectionJson | undefined;
}
export interface AWSManagedRulesATPRuleSet {
    LoginPath: string;
    RequestInspection?: RequestInspection | undefined;
    ResponseInspection?: ResponseInspection | undefined;
    EnableRegexInPath?: boolean | undefined;
}
export type CreationPathString = string;
export type RegistrationPagePathString = string;
export interface EmailField {
    Identifier: string;
}
export interface PhoneNumberField {
    Identifier: string;
}
export type PhoneNumberFields = PhoneNumberField[];
export interface AddressField {
    Identifier: string;
}
export type AddressFields = AddressField[];
export interface RequestInspectionACFP {
    PayloadType: PayloadType;
    UsernameField?: UsernameField | undefined;
    PasswordField?: PasswordField | undefined;
    EmailField?: EmailField | undefined;
    PhoneNumberFields?: PhoneNumberField[] | undefined;
    AddressFields?: AddressField[] | undefined;
}
export interface AWSManagedRulesACFPRuleSet {
    CreationPath: string;
    RegistrationPagePath: string;
    RequestInspection: RequestInspectionACFP;
    ResponseInspection?: ResponseInspection | undefined;
    EnableRegexInPath?: boolean | undefined;
}
export type UsageOfAction = "ENABLED" | "DISABLED" | (string & {});
export type SensitivityToAct = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type RegexPatternString = string;
export interface Regex {
    RegexString?: string | undefined;
}
export type RegularExpressionList = Regex[];
export interface ClientSideAction {
    UsageOfAction: UsageOfAction;
    Sensitivity?: SensitivityToAct | undefined;
    ExemptUriRegularExpressions?: Regex[] | undefined;
}
export interface ClientSideActionConfig {
    Challenge: ClientSideAction;
}
export interface AWSManagedRulesAntiDDoSRuleSet {
    ClientSideActionConfig: ClientSideActionConfig;
    SensitivityToBlock?: SensitivityToAct | undefined;
}
export interface ManagedRuleGroupConfig {
    LoginPath?: string | undefined;
    PayloadType?: PayloadType | undefined;
    UsernameField?: UsernameField | undefined;
    PasswordField?: PasswordField | undefined;
    AWSManagedRulesBotControlRuleSet?: AWSManagedRulesBotControlRuleSet | undefined;
    AWSManagedRulesATPRuleSet?: AWSManagedRulesATPRuleSet | undefined;
    AWSManagedRulesACFPRuleSet?: AWSManagedRulesACFPRuleSet | undefined;
    AWSManagedRulesAntiDDoSRuleSet?: AWSManagedRulesAntiDDoSRuleSet | undefined;
}
export type ManagedRuleGroupConfigs = ManagedRuleGroupConfig[];
export interface ManagedRuleGroupStatement {
    VendorName: string;
    Name: string;
    Version?: string | undefined;
    ExcludedRules?: ExcludedRule[] | undefined;
    ScopeDownStatement?: Statement | undefined;
    ManagedRuleGroupConfigs?: ManagedRuleGroupConfig[] | undefined;
    RuleActionOverrides?: RuleActionOverride[] | undefined;
}
export type LabelMatchScope = "LABEL" | "NAMESPACE" | (string & {});
export type LabelMatchKey = string;
export interface LabelMatchStatement {
    Scope: LabelMatchScope;
    Key: string;
}
export interface RegexMatchStatement {
    RegexString: string;
    FieldToMatch: FieldToMatch;
    TextTransformations: TextTransformation[];
    PreParseTextTransformations?: PreParseTextTransformation[] | undefined;
}
export type ASN = number;
export type AsnList = number[];
export interface AsnMatchStatement {
    AsnList: number[];
    ForwardedIPConfig?: ForwardedIPConfig | undefined;
}
export interface Statement {
    ByteMatchStatement?: ByteMatchStatement | undefined;
    SqliMatchStatement?: SqliMatchStatement | undefined;
    XssMatchStatement?: XssMatchStatement | undefined;
    SizeConstraintStatement?: SizeConstraintStatement | undefined;
    GeoMatchStatement?: GeoMatchStatement | undefined;
    RuleGroupReferenceStatement?: RuleGroupReferenceStatement | undefined;
    IPSetReferenceStatement?: IPSetReferenceStatement | undefined;
    RegexPatternSetReferenceStatement?: RegexPatternSetReferenceStatement | undefined;
    RateBasedStatement?: RateBasedStatement | undefined;
    AndStatement?: AndStatement | undefined;
    OrStatement?: OrStatement | undefined;
    NotStatement?: NotStatement | undefined;
    ManagedRuleGroupStatement?: ManagedRuleGroupStatement | undefined;
    LabelMatchStatement?: LabelMatchStatement | undefined;
    RegexMatchStatement?: RegexMatchStatement | undefined;
    AsnMatchStatement?: AsnMatchStatement | undefined;
}
export interface NoneAction {
}
export interface OverrideAction {
    Count?: CountAction | undefined;
    None?: NoneAction | undefined;
}
export type LabelName = string;
export interface Label {
    Name: string;
}
export type Labels = Label[];
export type MetricName = string;
export interface VisibilityConfig {
    SampledRequestsEnabled: boolean;
    CloudWatchMetricsEnabled: boolean;
    MetricName: string;
}
export type TimeWindowSecond = number;
export interface ImmunityTimeProperty {
    ImmunityTime: number;
}
export interface CaptchaConfig {
    ImmunityTimeProperty?: ImmunityTimeProperty | undefined;
}
export interface ChallengeConfig {
    ImmunityTimeProperty?: ImmunityTimeProperty | undefined;
}
export interface Rule {
    Name: string;
    Priority: number;
    Statement: Statement;
    Action?: RuleAction | undefined;
    OverrideAction?: OverrideAction | undefined;
    RuleLabels?: Label[] | undefined;
    VisibilityConfig: VisibilityConfig;
    CaptchaConfig?: CaptchaConfig | undefined;
    ChallengeConfig?: ChallengeConfig | undefined;
}
export type Rules = Rule[];
export interface CheckCapacityRequest {
    Scope: Scope;
    Rules: Rule[];
}
export type ConsumedCapacity = number;
export interface CheckCapacityResponse {
    Capacity?: number | undefined;
}
export type TokenDomain = string;
export type APIKeyTokenDomains = string[];
export interface CreateAPIKeyRequest {
    Scope: Scope;
    TokenDomains: string[];
}
export type APIKey = string;
export interface CreateAPIKeyResponse {
    APIKey?: string | undefined;
}
export type EntityDescription = string;
export type IPAddressVersion = "IPV4" | "IPV6" | (string & {});
export type IPAddress = string;
export type IPAddresses = string[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateIPSetRequest {
    Name: string;
    Scope: Scope;
    Description?: string | undefined;
    IPAddressVersion: IPAddressVersion;
    Addresses: string[];
    Tags?: Tag[] | undefined;
}
export type EntityId = string;
export type LockToken = string;
export interface IPSetSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    Description?: string | undefined;
    LockToken?: string | undefined;
    ARN?: string | undefined;
}
export interface CreateIPSetResponse {
    Summary?: IPSetSummary | undefined;
}
export interface CreateRegexPatternSetRequest {
    Name: string;
    Scope: Scope;
    Description?: string | undefined;
    RegularExpressionList: Regex[];
    Tags?: Tag[] | undefined;
}
export interface RegexPatternSetSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    Description?: string | undefined;
    LockToken?: string | undefined;
    ARN?: string | undefined;
}
export interface CreateRegexPatternSetResponse {
    Summary?: RegexPatternSetSummary | undefined;
}
export type CapacityUnit = number;
export type ResponseContentType = "TEXT_PLAIN" | "TEXT_HTML" | "APPLICATION_JSON" | (string & {});
export type ResponseContent = string;
export interface CustomResponseBody {
    ContentType: ResponseContentType;
    Content: string;
}
export type CustomResponseBodies = {
    [key: string]: CustomResponseBody | undefined;
};
export type BlockchainChain = "BASE" | "SOLANA" | "BASE_SEPOLIA" | "SOLANA_DEVNET" | (string & {});
export type WalletAddress = string;
export type PriceAmount = string;
export type CryptoCurrency = "USDC" | (string & {});
export interface Price {
    Amount: string;
    Currency: CryptoCurrency;
}
export type Prices = Price[];
export interface PaymentNetwork {
    Chain: BlockchainChain;
    WalletAddress: string;
    Prices: Price[];
}
export type PaymentNetworks = PaymentNetwork[];
export interface CryptoConfig {
    PaymentNetworks: PaymentNetwork[];
}
export type ConnectedAccountArn = string;
export type ConnectedAccountChain = "BASE" | "SOLANA" | (string & {});
export type ConnectedAccountPriceAmount = string;
export interface ConnectedAccountPrice {
    Amount: string;
    Currency: CryptoCurrency;
}
export type ConnectedAccountPrices = ConnectedAccountPrice[];
export interface ConnectedAccountChainConfig {
    Chain: ConnectedAccountChain;
    Prices: ConnectedAccountPrice[];
}
export type ConnectedAccountPaymentNetworks = ConnectedAccountChainConfig[];
export interface ConnectedAccountConfig {
    ConnectedAccountArn: string;
    PaymentNetworks: ConnectedAccountChainConfig[];
}
export type ConnectedAccountConfigs = ConnectedAccountConfig[];
export type CurrencyMode = "REAL" | "TEST" | (string & {});
export interface MonetizationConfig {
    CryptoConfig?: CryptoConfig | undefined;
    ConnectedAccountConfigs?: ConnectedAccountConfig[] | undefined;
    CurrencyMode?: CurrencyMode | undefined;
}
export interface CreateRuleGroupRequest {
    Name: string;
    Scope: Scope;
    Capacity: number;
    Description?: string | undefined;
    Rules?: Rule[] | undefined;
    VisibilityConfig: VisibilityConfig;
    Tags?: Tag[] | undefined;
    CustomResponseBodies?: {
        [key: string]: CustomResponseBody | undefined;
    } | undefined;
    MonetizationConfig?: MonetizationConfig | undefined;
}
export interface RuleGroupSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    Description?: string | undefined;
    LockToken?: string | undefined;
    ARN?: string | undefined;
}
export interface CreateRuleGroupResponse {
    Summary?: RuleGroupSummary | undefined;
}
export interface DefaultAction {
    Block?: BlockAction | undefined;
    Allow?: AllowAction | undefined;
}
export type FieldToProtectType = "SINGLE_HEADER" | "SINGLE_COOKIE" | "SINGLE_QUERY_ARGUMENT" | "QUERY_STRING" | "BODY" | (string & {});
export type FieldToProtectKeyName = string;
export type FieldToProtectKeys = string[];
export interface FieldToProtect {
    FieldType: FieldToProtectType;
    FieldKeys?: string[] | undefined;
}
export type DataProtectionAction = "SUBSTITUTION" | "HASH" | (string & {});
export interface DataProtection {
    Field: FieldToProtect;
    Action: DataProtectionAction;
    ExcludeRuleMatchDetails?: boolean | undefined;
    ExcludeRateBasedDetails?: boolean | undefined;
}
export type DataProtections = DataProtection[];
export interface DataProtectionConfig {
    DataProtections: DataProtection[];
}
export type TokenDomains = string[];
export type AssociatedResourceType = "CLOUDFRONT" | "API_GATEWAY" | "COGNITO_USER_POOL" | "APP_RUNNER_SERVICE" | "VERIFIED_ACCESS_INSTANCE" | "AGENTCORE_GATEWAY" | (string & {});
export type SizeInspectionLimit = "KB_16" | "KB_32" | "KB_48" | "KB_64" | (string & {});
export interface RequestBodyAssociatedResourceTypeConfig {
    DefaultSizeInspectionLimit: SizeInspectionLimit;
}
export type RequestBody = {
    [key in AssociatedResourceType]?: RequestBodyAssociatedResourceTypeConfig | undefined;
};
export interface ChallengeJavascriptSdkInjectionConfig {
}
export type ChallengeJavascriptSdkInjection = {
    [key in AssociatedResourceType]?: ChallengeJavascriptSdkInjectionConfig | undefined;
};
export interface AssociationConfig {
    RequestBody?: {
        [key: string]: RequestBodyAssociatedResourceTypeConfig | undefined;
    } | undefined;
    ChallengeJavascriptSdkInjection?: {
        [key: string]: ChallengeJavascriptSdkInjectionConfig | undefined;
    } | undefined;
}
export type LowReputationMode = "ACTIVE_UNDER_DDOS" | "ALWAYS_ON" | (string & {});
export interface OnSourceDDoSProtectionConfig {
    ALBLowReputationMode: LowReputationMode;
}
export type AttributeName = string;
export type AttributeValue = string;
export type AttributeValues = string[];
export interface ApplicationAttribute {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type ApplicationAttributes = ApplicationAttribute[];
export interface ApplicationConfig {
    Attributes?: ApplicationAttribute[] | undefined;
}
export interface CreateWebACLRequest {
    Name: string;
    Scope: Scope;
    DefaultAction: DefaultAction;
    Description?: string | undefined;
    Rules?: Rule[] | undefined;
    VisibilityConfig: VisibilityConfig;
    DataProtectionConfig?: DataProtectionConfig | undefined;
    Tags?: Tag[] | undefined;
    CustomResponseBodies?: {
        [key: string]: CustomResponseBody | undefined;
    } | undefined;
    CaptchaConfig?: CaptchaConfig | undefined;
    ChallengeConfig?: ChallengeConfig | undefined;
    TokenDomains?: string[] | undefined;
    AssociationConfig?: AssociationConfig | undefined;
    OnSourceDDoSProtectionConfig?: OnSourceDDoSProtectionConfig | undefined;
    ApplicationConfig?: ApplicationConfig | undefined;
    MonetizationConfig?: MonetizationConfig | undefined;
}
export interface WebACLSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    Description?: string | undefined;
    LockToken?: string | undefined;
    ARN?: string | undefined;
}
export interface CreateWebACLResponse {
    Summary?: WebACLSummary | undefined;
}
export interface DeleteAPIKeyRequest {
    Scope: Scope;
    APIKey: string;
}
export interface DeleteAPIKeyResponse {
}
export interface DeleteFirewallManagerRuleGroupsRequest {
    WebACLArn: string;
    WebACLLockToken: string;
}
export interface DeleteFirewallManagerRuleGroupsResponse {
    NextWebACLLockToken?: string | undefined;
}
export interface DeleteIPSetRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    LockToken: string;
}
export interface DeleteIPSetResponse {
}
export type LogType = "WAF_LOGS" | (string & {});
export type LogScope = "CUSTOMER" | "SECURITY_LAKE" | "CLOUDWATCH_TELEMETRY_RULE_MANAGED" | (string & {});
export interface DeleteLoggingConfigurationRequest {
    ResourceArn: string;
    LogType?: LogType | undefined;
    LogScope?: LogScope | undefined;
}
export interface DeleteLoggingConfigurationResponse {
}
export interface DeletePermissionPolicyRequest {
    ResourceArn: string;
}
export interface DeletePermissionPolicyResponse {
}
export interface DeleteRegexPatternSetRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    LockToken: string;
}
export interface DeleteRegexPatternSetResponse {
}
export interface DeleteRuleGroupRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    LockToken: string;
}
export interface DeleteRuleGroupResponse {
}
export interface DeleteWebACLRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    LockToken: string;
}
export interface DeleteWebACLResponse {
}
export interface DescribeAllManagedProductsRequest {
    Scope: Scope;
}
export type ProductId = string;
export type ProductLink = string;
export type ProductTitle = string;
export type ProductDescription = string;
export interface ManagedProductDescriptor {
    VendorName?: string | undefined;
    ManagedRuleSetName?: string | undefined;
    ProductId?: string | undefined;
    ProductLink?: string | undefined;
    ProductTitle?: string | undefined;
    ProductDescription?: string | undefined;
    SnsTopicArn?: string | undefined;
    IsVersioningSupported?: boolean | undefined;
    IsAdvancedManagedRuleSet?: boolean | undefined;
}
export type ManagedProductDescriptors = ManagedProductDescriptor[];
export interface DescribeAllManagedProductsResponse {
    ManagedProducts?: ManagedProductDescriptor[] | undefined;
}
export interface DescribeManagedProductsByVendorRequest {
    VendorName: string;
    Scope: Scope;
}
export interface DescribeManagedProductsByVendorResponse {
    ManagedProducts?: ManagedProductDescriptor[] | undefined;
}
export interface DescribeManagedRuleGroupRequest {
    VendorName: string;
    Name: string;
    Scope: Scope;
    VersionName?: string | undefined;
}
export interface RuleSummary {
    Name?: string | undefined;
    Action?: RuleAction | undefined;
}
export type RuleSummaries = RuleSummary[];
export interface LabelSummary {
    Name?: string | undefined;
}
export type LabelSummaries = LabelSummary[];
export interface DescribeManagedRuleGroupResponse {
    VersionName?: string | undefined;
    SnsTopicArn?: string | undefined;
    Capacity?: number | undefined;
    Rules?: RuleSummary[] | undefined;
    LabelNamespace?: string | undefined;
    AvailableLabels?: LabelSummary[] | undefined;
    ConsumedLabels?: LabelSummary[] | undefined;
}
export interface DisassociateWebACLRequest {
    ResourceArn: string;
}
export interface DisassociateWebACLResponse {
}
export type Platform = "IOS" | "ANDROID" | (string & {});
export interface GenerateMobileSdkReleaseUrlRequest {
    Platform: Platform;
    ReleaseVersion: string;
}
export type DownloadUrl = string;
export interface GenerateMobileSdkReleaseUrlResponse {
    Url?: string | undefined;
}
export interface GetDecryptedAPIKeyRequest {
    Scope: Scope;
    APIKey: string;
}
export interface GetDecryptedAPIKeyResponse {
    TokenDomains?: string[] | undefined;
    CreationTimestamp?: Date | undefined;
}
export interface GetIPSetRequest {
    Name: string;
    Scope: Scope;
    Id: string;
}
export interface IPSet {
    Name: string;
    Id: string;
    ARN: string;
    Description?: string | undefined;
    IPAddressVersion: IPAddressVersion;
    Addresses: string[];
}
export interface GetIPSetResponse {
    IPSet?: IPSet | undefined;
    LockToken?: string | undefined;
}
export interface GetLoggingConfigurationRequest {
    ResourceArn: string;
    LogType?: LogType | undefined;
    LogScope?: LogScope | undefined;
}
export type LogDestinationConfigs = string[];
export type RedactedFields = FieldToMatch[];
export type FilterBehavior = "KEEP" | "DROP" | (string & {});
export type FilterRequirement = "MEETS_ALL" | "MEETS_ANY" | (string & {});
export type ActionValue = "ALLOW" | "BLOCK" | "COUNT" | "CAPTCHA" | "CHALLENGE" | "MONETIZE" | "EXCLUDED_AS_COUNT" | (string & {});
export interface ActionCondition {
    Action: ActionValue;
}
export interface LabelNameCondition {
    LabelName: string;
}
export interface Condition {
    ActionCondition?: ActionCondition | undefined;
    LabelNameCondition?: LabelNameCondition | undefined;
}
export type Conditions = Condition[];
export interface Filter {
    Behavior: FilterBehavior;
    Requirement: FilterRequirement;
    Conditions: Condition[];
}
export type Filters = Filter[];
export interface LoggingFilter {
    Filters: Filter[];
    DefaultBehavior: FilterBehavior;
}
export interface LoggingConfiguration {
    ResourceArn: string;
    LogDestinationConfigs: string[];
    RedactedFields?: FieldToMatch[] | undefined;
    ManagedByFirewallManager?: boolean | undefined;
    LoggingFilter?: LoggingFilter | undefined;
    LogType?: LogType | undefined;
    LogScope?: LogScope | undefined;
}
export interface GetLoggingConfigurationResponse {
    LoggingConfiguration?: LoggingConfiguration | undefined;
}
export interface GetManagedRuleSetRequest {
    Name: string;
    Scope: Scope;
    Id: string;
}
export type TimeWindowDay = number;
export interface ManagedRuleSetVersion {
    AssociatedRuleGroupArn?: string | undefined;
    Capacity?: number | undefined;
    ForecastedLifetime?: number | undefined;
    PublishTimestamp?: Date | undefined;
    LastUpdateTimestamp?: Date | undefined;
    ExpiryTimestamp?: Date | undefined;
}
export type PublishedVersions = {
    [key: string]: ManagedRuleSetVersion | undefined;
};
export interface ManagedRuleSet {
    Name: string;
    Id: string;
    ARN: string;
    Description?: string | undefined;
    PublishedVersions?: {
        [key: string]: ManagedRuleSetVersion | undefined;
    } | undefined;
    RecommendedVersion?: string | undefined;
    LabelNamespace?: string | undefined;
}
export interface GetManagedRuleSetResponse {
    ManagedRuleSet?: ManagedRuleSet | undefined;
    LockToken?: string | undefined;
}
export interface GetMobileSdkReleaseRequest {
    Platform: Platform;
    ReleaseVersion: string;
}
export type ReleaseNotes = string;
export interface MobileSdkRelease {
    ReleaseVersion?: string | undefined;
    Timestamp?: Date | undefined;
    ReleaseNotes?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetMobileSdkReleaseResponse {
    MobileSdkRelease?: MobileSdkRelease | undefined;
}
export interface GetPermissionPolicyRequest {
    ResourceArn: string;
}
export type PolicyString = string;
export interface GetPermissionPolicyResponse {
    Policy?: string | undefined;
}
export interface GetRateBasedStatementManagedKeysRequest {
    Scope: Scope;
    WebACLName: string;
    WebACLId: string;
    RuleGroupRuleName?: string | undefined;
    RuleName: string;
}
export interface RateBasedStatementManagedKeysIPSet {
    IPAddressVersion?: IPAddressVersion | undefined;
    Addresses?: string[] | undefined;
}
export interface GetRateBasedStatementManagedKeysResponse {
    ManagedKeysIPV4?: RateBasedStatementManagedKeysIPSet | undefined;
    ManagedKeysIPV6?: RateBasedStatementManagedKeysIPSet | undefined;
}
export interface GetRegexPatternSetRequest {
    Name: string;
    Scope: Scope;
    Id: string;
}
export interface RegexPatternSet {
    Name?: string | undefined;
    Id?: string | undefined;
    ARN?: string | undefined;
    Description?: string | undefined;
    RegularExpressionList?: Regex[] | undefined;
}
export interface GetRegexPatternSetResponse {
    RegexPatternSet?: RegexPatternSet | undefined;
    LockToken?: string | undefined;
}
export type RankingStatisticType = "TOP_SOURCES_BY_REVENUE" | "TOP_PATHS_BY_REVENUE" | (string & {});
export interface TimeWindow {
    StartTime: Date;
    EndTime: Date;
}
export type Currency = "USDC" | (string & {});
export type GroupByType = "NAME" | "CATEGORY" | "INTENT" | "ORGANIZATION" | "WEBACL" | (string & {});
export type MonetizationFilterName = string;
export type MonetizationFilterValue = string;
export type MonetizationFilterValueList = string[];
export interface MonetizationFilter {
    Name: string;
    Values: string[];
}
export type MonetizationFilterList = MonetizationFilter[];
export type NextMarker = string;
export type PathStatisticsLimit = number;
export type RankingSortBy = "REVENUE" | "PERCENTAGE" | "NAME" | (string & {});
export type SortOrder = "ASC" | "DESC" | (string & {});
export interface GetRevenueStatisticsRequest {
    StatisticType: RankingStatisticType;
    TimeWindow: TimeWindow;
    Scope: Scope;
    Currency: Currency;
    GroupBy?: GroupByType | undefined;
    Filters?: MonetizationFilter[] | undefined;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
    SortBy?: RankingSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type FilterString = string;
export type PercentageValue = number;
export type MonetizationAmountValue = string;
export type RequestCount = number;
export type VerifiedStatus = boolean;
export interface SourceStatistics {
    SourceName: string;
    Percentage: number;
    Amount: string;
    RequestCount: number;
    SourceCategory?: string | undefined;
    Intent?: string | undefined;
    Organization?: string | undefined;
    Verified?: boolean | undefined;
    GroupByValue?: string | undefined;
}
export type SourceStatisticsList = SourceStatistics[];
export type PathString = string;
export interface RevenuePathStatistics {
    Path: string;
    Percentage: number;
    Amount: string;
    RequestCount: number;
}
export type RevenuePathStatisticsList = RevenuePathStatistics[];
export interface GetRevenueStatisticsResponse {
    SourceStatistics?: SourceStatistics[] | undefined;
    RevenuePathStatistics?: RevenuePathStatistics[] | undefined;
    NextMarker?: string | undefined;
}
export interface GetRevenueStatisticsSummaryRequest {
    TimeWindow: TimeWindow;
    Scope: Scope;
    Currency: Currency;
    Filters?: MonetizationFilter[] | undefined;
}
export interface RevenueBreakdown {
    TotalAmount?: string | undefined;
    VerifiedAmount?: string | undefined;
    UnverifiedAmount?: string | undefined;
    Currency?: Currency | undefined;
    TotalSettled?: number | undefined;
    TotalMonetizeServed?: number | undefined;
}
export interface GetRevenueStatisticsSummaryResponse {
    RevenueBreakdown?: RevenueBreakdown | undefined;
}
export type TimeSeriesStatisticType = "DATE_HISTOGRAM" | "PAYMENT_TRAFFIC" | (string & {});
export type IntervalType = "MINUTELY" | "FIVE_MINUTELY" | "HOURLY" | "DAILY" | (string & {});
export type MaxDataPoints = number;
export interface GetRevenueStatisticsTimeSeriesRequest {
    StatisticType: TimeSeriesStatisticType;
    TimeWindow: TimeWindow;
    Scope: Scope;
    Interval: IntervalType;
    Currency: Currency;
    GroupBy?: GroupByType | undefined;
    Filters?: MonetizationFilter[] | undefined;
    Limit?: number | undefined;
    NextMarker?: string | undefined;
}
export interface DataPointEntry {
    Date?: Date | undefined;
    MonetizeServedCount?: number | undefined;
    SettledCount?: number | undefined;
    TotalAmount?: string | undefined;
    Category?: string | undefined;
    Intent?: string | undefined;
    GroupByValue?: string | undefined;
}
export type DataPointsList = DataPointEntry[];
export interface GetRevenueStatisticsTimeSeriesResponse {
    DataPoints?: DataPointEntry[] | undefined;
    NextMarker?: string | undefined;
}
export interface GetRuleGroupRequest {
    Name?: string | undefined;
    Scope?: Scope | undefined;
    Id?: string | undefined;
    ARN?: string | undefined;
}
export interface RuleGroup {
    Name: string;
    Id: string;
    Capacity: number;
    ARN: string;
    Description?: string | undefined;
    Rules?: Rule[] | undefined;
    VisibilityConfig: VisibilityConfig;
    LabelNamespace?: string | undefined;
    CustomResponseBodies?: {
        [key: string]: CustomResponseBody | undefined;
    } | undefined;
    AvailableLabels?: LabelSummary[] | undefined;
    ConsumedLabels?: LabelSummary[] | undefined;
    MonetizationConfig?: MonetizationConfig | undefined;
}
export interface GetRuleGroupResponse {
    RuleGroup?: RuleGroup | undefined;
    LockToken?: string | undefined;
}
export type ListMaxItems = number;
export interface GetSampledRequestsRequest {
    WebAclArn: string;
    RuleMetricName: string;
    Scope: Scope;
    TimeWindow: TimeWindow;
    MaxItems: number;
}
export type IPString = string;
export type Country = string;
export type URIString = string;
export type HTTPMethod = string;
export type HTTPVersion = string;
export type HeaderName = string;
export type HeaderValue = string;
export interface HTTPHeader {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type HTTPHeaders = HTTPHeader[];
export interface HTTPRequest {
    ClientIP?: string | undefined;
    Country?: string | undefined;
    URI?: string | undefined;
    Method?: string | undefined;
    HTTPVersion?: string | undefined;
    Headers?: HTTPHeader[] | undefined;
}
export type SampleWeight = number;
export type Action = string;
export type ResponseCode = number;
export type SolveTimestamp = number;
export type FailureReason = "TOKEN_MISSING" | "TOKEN_EXPIRED" | "TOKEN_INVALID" | "TOKEN_DOMAIN_MISMATCH" | (string & {});
export interface CaptchaResponse {
    ResponseCode?: number | undefined;
    SolveTimestamp?: number | undefined;
    FailureReason?: FailureReason | undefined;
}
export interface ChallengeResponse {
    ResponseCode?: number | undefined;
    SolveTimestamp?: number | undefined;
    FailureReason?: FailureReason | undefined;
}
export interface SampledHTTPRequest {
    Request: HTTPRequest;
    Weight: number;
    Timestamp?: Date | undefined;
    Action?: string | undefined;
    RuleNameWithinRuleGroup?: string | undefined;
    RequestHeadersInserted?: HTTPHeader[] | undefined;
    ResponseCodeSent?: number | undefined;
    Labels?: Label[] | undefined;
    CaptchaResponse?: CaptchaResponse | undefined;
    ChallengeResponse?: ChallengeResponse | undefined;
    OverriddenAction?: string | undefined;
}
export type SampledHTTPRequests = SampledHTTPRequest[];
export type PopulationSize = number;
export interface GetSampledRequestsResponse {
    SampledRequests?: SampledHTTPRequest[] | undefined;
    PopulationSize?: number | undefined;
    TimeWindow?: TimeWindow | undefined;
}
export type UriPathPrefixString = string;
export type NumberOfTopTrafficBotsPerPath = number;
export interface GetTopPathStatisticsByTrafficRequest {
    WebAclArn: string;
    Scope: Scope;
    UriPathPrefix?: string | undefined;
    TimeWindow: TimeWindow;
    BotCategory?: string | undefined;
    BotOrganization?: string | undefined;
    BotName?: string | undefined;
    Limit: number;
    NumberOfTopTrafficBotsPerPath: number;
    NextMarker?: string | undefined;
}
export interface FilterSource {
    BotCategory?: string | undefined;
    BotOrganization?: string | undefined;
    BotName?: string | undefined;
}
export interface BotStatistics {
    BotName: string;
    RequestCount: number;
    Percentage: number;
}
export type BotStatisticsList = BotStatistics[];
export interface PathStatistics {
    Source?: FilterSource | undefined;
    Path: string;
    RequestCount: number;
    Percentage: number;
    TopBots?: BotStatistics[] | undefined;
}
export type PathStatisticsList = PathStatistics[];
export interface GetTopPathStatisticsByTrafficResponse {
    PathStatistics: PathStatistics[];
    TotalRequestCount: number;
    NextMarker?: string | undefined;
    TopCategories?: PathStatistics[] | undefined;
}
export interface GetWebACLRequest {
    Name?: string | undefined;
    Scope?: Scope | undefined;
    Id?: string | undefined;
    ARN?: string | undefined;
}
export interface FirewallManagerStatement {
    ManagedRuleGroupStatement?: ManagedRuleGroupStatement | undefined;
    RuleGroupReferenceStatement?: RuleGroupReferenceStatement | undefined;
}
export interface FirewallManagerRuleGroup {
    Name: string;
    Priority: number;
    FirewallManagerStatement: FirewallManagerStatement;
    OverrideAction: OverrideAction;
    VisibilityConfig: VisibilityConfig;
}
export type FirewallManagerRuleGroups = FirewallManagerRuleGroup[];
export interface WebACL {
    Name: string;
    Id: string;
    ARN: string;
    DefaultAction: DefaultAction;
    Description?: string | undefined;
    Rules?: Rule[] | undefined;
    VisibilityConfig: VisibilityConfig;
    DataProtectionConfig?: DataProtectionConfig | undefined;
    Capacity?: number | undefined;
    PreProcessFirewallManagerRuleGroups?: FirewallManagerRuleGroup[] | undefined;
    PostProcessFirewallManagerRuleGroups?: FirewallManagerRuleGroup[] | undefined;
    ManagedByFirewallManager?: boolean | undefined;
    LabelNamespace?: string | undefined;
    CustomResponseBodies?: {
        [key: string]: CustomResponseBody | undefined;
    } | undefined;
    CaptchaConfig?: CaptchaConfig | undefined;
    ChallengeConfig?: ChallengeConfig | undefined;
    TokenDomains?: string[] | undefined;
    AssociationConfig?: AssociationConfig | undefined;
    RetrofittedByFirewallManager?: boolean | undefined;
    OnSourceDDoSProtectionConfig?: OnSourceDDoSProtectionConfig | undefined;
    ApplicationConfig?: ApplicationConfig | undefined;
    MonetizationConfig?: MonetizationConfig | undefined;
}
export type OutputUrl = string;
export interface GetWebACLResponse {
    WebACL?: WebACL | undefined;
    LockToken?: string | undefined;
    ApplicationIntegrationURL?: string | undefined;
}
export interface GetWebACLForResourceRequest {
    ResourceArn: string;
}
export interface GetWebACLForResourceResponse {
    WebACL?: WebACL | undefined;
}
export type PaginationLimit = number;
export interface ListAPIKeysRequest {
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export type APIKeyVersion = number;
export interface APIKeySummary {
    TokenDomains?: string[] | undefined;
    APIKey?: string | undefined;
    CreationTimestamp?: Date | undefined;
    Version?: number | undefined;
}
export type APIKeySummaries = APIKeySummary[];
export interface ListAPIKeysResponse {
    NextMarker?: string | undefined;
    APIKeySummaries?: APIKeySummary[] | undefined;
    ApplicationIntegrationURL?: string | undefined;
}
export interface ListAvailableManagedRuleGroupsRequest {
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export interface ManagedRuleGroupSummary {
    VendorName?: string | undefined;
    Name?: string | undefined;
    VersioningSupported?: boolean | undefined;
    Description?: string | undefined;
}
export type ManagedRuleGroupSummaries = ManagedRuleGroupSummary[];
export interface ListAvailableManagedRuleGroupsResponse {
    NextMarker?: string | undefined;
    ManagedRuleGroups?: ManagedRuleGroupSummary[] | undefined;
}
export interface ListAvailableManagedRuleGroupVersionsRequest {
    VendorName: string;
    Name: string;
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export interface ManagedRuleGroupVersion {
    Name?: string | undefined;
    LastUpdateTimestamp?: Date | undefined;
}
export type ManagedRuleGroupVersions = ManagedRuleGroupVersion[];
export interface ListAvailableManagedRuleGroupVersionsResponse {
    NextMarker?: string | undefined;
    Versions?: ManagedRuleGroupVersion[] | undefined;
    CurrentDefaultVersion?: string | undefined;
}
export interface ListIPSetsRequest {
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export type IPSetSummaries = IPSetSummary[];
export interface ListIPSetsResponse {
    NextMarker?: string | undefined;
    IPSets?: IPSetSummary[] | undefined;
}
export interface ListLoggingConfigurationsRequest {
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
    LogScope?: LogScope | undefined;
}
export type LoggingConfigurations = LoggingConfiguration[];
export interface ListLoggingConfigurationsResponse {
    LoggingConfigurations?: LoggingConfiguration[] | undefined;
    NextMarker?: string | undefined;
}
export interface ListManagedRuleSetsRequest {
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export interface ManagedRuleSetSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    Description?: string | undefined;
    LockToken?: string | undefined;
    ARN?: string | undefined;
    LabelNamespace?: string | undefined;
}
export type ManagedRuleSetSummaries = ManagedRuleSetSummary[];
export interface ListManagedRuleSetsResponse {
    NextMarker?: string | undefined;
    ManagedRuleSets?: ManagedRuleSetSummary[] | undefined;
}
export interface ListMobileSdkReleasesRequest {
    Platform: Platform;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export interface ReleaseSummary {
    ReleaseVersion?: string | undefined;
    Timestamp?: Date | undefined;
}
export type ReleaseSummaries = ReleaseSummary[];
export interface ListMobileSdkReleasesResponse {
    ReleaseSummaries?: ReleaseSummary[] | undefined;
    NextMarker?: string | undefined;
}
export interface ListRegexPatternSetsRequest {
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export type RegexPatternSetSummaries = RegexPatternSetSummary[];
export interface ListRegexPatternSetsResponse {
    NextMarker?: string | undefined;
    RegexPatternSets?: RegexPatternSetSummary[] | undefined;
}
export type ResourceType = "APPLICATION_LOAD_BALANCER" | "API_GATEWAY" | "APPSYNC" | "COGNITO_USER_POOL" | "APP_RUNNER_SERVICE" | "VERIFIED_ACCESS_INSTANCE" | "AMPLIFY" | "AGENTCORE_GATEWAY" | (string & {});
export interface ListResourcesForWebACLRequest {
    WebACLArn: string;
    ResourceType?: ResourceType | undefined;
}
export type ResourceArns = string[];
export interface ListResourcesForWebACLResponse {
    ResourceArns?: string[] | undefined;
}
export interface ListRuleGroupsRequest {
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export type RuleGroupSummaries = RuleGroupSummary[];
export interface ListRuleGroupsResponse {
    NextMarker?: string | undefined;
    RuleGroups?: RuleGroupSummary[] | undefined;
}
export type SettlementSortBy = "TIMESTAMP" | "AMOUNT" | "NAME" | "STATUS" | (string & {});
export type SettlementRecordLimit = number;
export interface ListSettlementRecordsRequest {
    TimeWindow: TimeWindow;
    Scope: Scope;
    Currency: Currency;
    Filters?: MonetizationFilter[] | undefined;
    SortBy?: SettlementSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    Limit?: number | undefined;
    NextMarker?: string | undefined;
}
export type SettlementFilterString = string;
export type SettlementStatus = "SETTLED" | "PENDING" | "FAILED" | "SERVICE_ERROR" | "SKIPPED_ORIGIN_ERROR" | "DUPLICATE" | (string & {});
export type SettlementIdString = string;
export interface SettlementRecord {
    Timestamp: Date;
    PayerAddress?: string | undefined;
    WalletAddress?: string | undefined;
    Status: SettlementStatus;
    Amount: string;
    Currency?: Currency | undefined;
    Network?: string | undefined;
    TransactionId?: string | undefined;
    RequestId?: string | undefined;
    SourceName?: string | undefined;
    Organization?: string | undefined;
    SourceCategory?: string | undefined;
    Intent?: string | undefined;
    Verified?: boolean | undefined;
    ContentPath?: string | undefined;
    WebAclArn?: string | undefined;
    RequestTimestamp?: Date | undefined;
}
export type SettlementRecordList = SettlementRecord[];
export interface ListSettlementRecordsResponse {
    Settlements?: SettlementRecord[] | undefined;
    NextMarker?: string | undefined;
}
export interface ListTagsForResourceRequest {
    NextMarker?: string | undefined;
    Limit?: number | undefined;
    ResourceARN: string;
}
export interface TagInfoForResource {
    ResourceARN?: string | undefined;
    TagList?: Tag[] | undefined;
}
export interface ListTagsForResourceResponse {
    NextMarker?: string | undefined;
    TagInfoForResource?: TagInfoForResource | undefined;
}
export interface ListWebACLsRequest {
    Scope: Scope;
    NextMarker?: string | undefined;
    Limit?: number | undefined;
}
export type WebACLSummaries = WebACLSummary[];
export interface ListWebACLsResponse {
    NextMarker?: string | undefined;
    WebACLs?: WebACLSummary[] | undefined;
}
export interface PutLoggingConfigurationRequest {
    LoggingConfiguration: LoggingConfiguration;
}
export interface PutLoggingConfigurationResponse {
    LoggingConfiguration?: LoggingConfiguration | undefined;
}
export interface VersionToPublish {
    AssociatedRuleGroupArn?: string | undefined;
    ForecastedLifetime?: number | undefined;
}
export type VersionsToPublish = {
    [key: string]: VersionToPublish | undefined;
};
export interface PutManagedRuleSetVersionsRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    LockToken: string;
    RecommendedVersion?: string | undefined;
    VersionsToPublish?: {
        [key: string]: VersionToPublish | undefined;
    } | undefined;
}
export interface PutManagedRuleSetVersionsResponse {
    NextLockToken?: string | undefined;
}
export interface PutPermissionPolicyRequest {
    ResourceArn: string;
    Policy: string;
}
export interface PutPermissionPolicyResponse {
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateIPSetRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    Description?: string | undefined;
    Addresses: string[];
    LockToken: string;
}
export interface UpdateIPSetResponse {
    NextLockToken?: string | undefined;
}
export interface UpdateManagedRuleSetVersionExpiryDateRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    LockToken: string;
    VersionToExpire: string;
    ExpiryTimestamp: Date;
}
export interface UpdateManagedRuleSetVersionExpiryDateResponse {
    ExpiringVersion?: string | undefined;
    ExpiryTimestamp?: Date | undefined;
    NextLockToken?: string | undefined;
}
export interface UpdateRegexPatternSetRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    Description?: string | undefined;
    RegularExpressionList: Regex[];
    LockToken: string;
}
export interface UpdateRegexPatternSetResponse {
    NextLockToken?: string | undefined;
}
export interface UpdateRuleGroupRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    Description?: string | undefined;
    Rules?: Rule[] | undefined;
    VisibilityConfig: VisibilityConfig;
    LockToken: string;
    CustomResponseBodies?: {
        [key: string]: CustomResponseBody | undefined;
    } | undefined;
    MonetizationConfig?: MonetizationConfig | undefined;
}
export interface UpdateRuleGroupResponse {
    NextLockToken?: string | undefined;
}
export interface UpdateWebACLRequest {
    Name: string;
    Scope: Scope;
    Id: string;
    DefaultAction: DefaultAction;
    Description?: string | undefined;
    Rules?: Rule[] | undefined;
    VisibilityConfig: VisibilityConfig;
    DataProtectionConfig?: DataProtectionConfig | undefined;
    LockToken: string;
    CustomResponseBodies?: {
        [key: string]: CustomResponseBody | undefined;
    } | undefined;
    CaptchaConfig?: CaptchaConfig | undefined;
    ChallengeConfig?: ChallengeConfig | undefined;
    TokenDomains?: string[] | undefined;
    AssociationConfig?: AssociationConfig | undefined;
    OnSourceDDoSProtectionConfig?: OnSourceDDoSProtectionConfig | undefined;
    ApplicationConfig?: ApplicationConfig | undefined;
    MonetizationConfig?: MonetizationConfig | undefined;
}
export interface UpdateWebACLResponse {
    NextLockToken?: string | undefined;
}
export type ErrorMessage = string;
export type PricingPlanFeatureName = string;
export type RequiredPricingPlanName = string;
export interface DisallowedFeature {
    Feature?: string | undefined;
    RequiredPricingPlan?: string | undefined;
}
export type DisallowedFeatures = DisallowedFeature[];
export type ParameterExceptionField = "WEB_ACL" | "RULE_GROUP" | "REGEX_PATTERN_SET" | "IP_SET" | "MANAGED_RULE_SET" | "RULE" | "EXCLUDED_RULE" | "STATEMENT" | "BYTE_MATCH_STATEMENT" | "SQLI_MATCH_STATEMENT" | "XSS_MATCH_STATEMENT" | "SIZE_CONSTRAINT_STATEMENT" | "GEO_MATCH_STATEMENT" | "RATE_BASED_STATEMENT" | "RULE_GROUP_REFERENCE_STATEMENT" | "REGEX_PATTERN_REFERENCE_STATEMENT" | "IP_SET_REFERENCE_STATEMENT" | "MANAGED_RULE_SET_STATEMENT" | "LABEL_MATCH_STATEMENT" | "AND_STATEMENT" | "OR_STATEMENT" | "NOT_STATEMENT" | "IP_ADDRESS" | "IP_ADDRESS_VERSION" | "FIELD_TO_MATCH" | "TEXT_TRANSFORMATION" | "SINGLE_QUERY_ARGUMENT" | "SINGLE_HEADER" | "DEFAULT_ACTION" | "RULE_ACTION" | "ENTITY_LIMIT" | "OVERRIDE_ACTION" | "SCOPE_VALUE" | "RESOURCE_ARN" | "RESOURCE_TYPE" | "TAGS" | "TAG_KEYS" | "METRIC_NAME" | "FIREWALL_MANAGER_STATEMENT" | "FALLBACK_BEHAVIOR" | "POSITION" | "FORWARDED_IP_CONFIG" | "IP_SET_FORWARDED_IP_CONFIG" | "HEADER_NAME" | "CUSTOM_REQUEST_HANDLING" | "RESPONSE_CONTENT_TYPE" | "CUSTOM_RESPONSE" | "CUSTOM_RESPONSE_BODY" | "JSON_MATCH_PATTERN" | "JSON_MATCH_SCOPE" | "BODY_PARSING_FALLBACK_BEHAVIOR" | "LOGGING_FILTER" | "FILTER_CONDITION" | "EXPIRE_TIMESTAMP" | "CHANGE_PROPAGATION_STATUS" | "ASSOCIABLE_RESOURCE" | "LOG_DESTINATION" | "MANAGED_RULE_GROUP_CONFIG" | "PAYLOAD_TYPE" | "HEADER_MATCH_PATTERN" | "COOKIE_MATCH_PATTERN" | "MAP_MATCH_SCOPE" | "OVERSIZE_HANDLING" | "CHALLENGE_CONFIG" | "TOKEN_DOMAIN" | "ATP_RULE_SET_RESPONSE_INSPECTION" | "ASSOCIATED_RESOURCE_TYPE" | "SCOPE_DOWN" | "CUSTOM_KEYS" | "ACP_RULE_SET_RESPONSE_INSPECTION" | "DATA_PROTECTION_CONFIG" | "LOW_REPUTATION_MODE" | "MONETIZATION_CONFIG" | "WALLET_ADDRESS" | "PRICE_AMOUNT" | "PAYMENT_NETWORK" | "PRE_PARSE_TEXT_TRANSFORMATION" | "CHALLENGE_JAVASCRIPT_SDK_INJECTION_CONFIG" | (string & {});
export type ParameterExceptionParameter = string;
export type ErrorReason = string;
export type SourceType = string;
export type AssociateWebACLError = WAFFeatureNotIncludedInPricingPlanException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFNonexistentItemException | WAFUnavailableEntityException | CommonErrors;
/**
 * Associates a web ACL with a resource, to protect the resource.
 *
 * Use this for all resource types except for Amazon CloudFront distributions. For Amazon CloudFront, call `UpdateDistribution` for the distribution and provide the Amazon Resource Name (ARN) of the web ACL in the web ACL ID. For information, see UpdateDistribution in the *Amazon CloudFront Developer Guide*.
 *
 * **Required permissions for customer-managed IAM policies**
 *
 * This call requires permissions that are specific to the protected resource type.
 * For details, see Permissions for AssociateWebACL in the *WAF Developer Guide*.
 *
 * **Temporary inconsistencies during updates**
 *
 * When you create or change a web ACL or other WAF resources, the changes take a small amount of time to propagate to all areas where the resources are stored. The propagation time can be from a few seconds to a number of minutes.
 *
 * The following are examples of the temporary inconsistencies that you might notice during change propagation:
 *
 * - After you create a web ACL, if you try to associate it with a resource, you might get an exception indicating that the web ACL is unavailable.
 *
 * - After you add a rule group to a web ACL, the new rule group rules might be in effect in one area where the web ACL is used and not in another.
 *
 * - After you change a rule action setting, you might see the old action in some places and the new action in others.
 *
 * - After you add an IP address to an IP set that is in use in a blocking rule, the new address might be blocked in one area while still allowed in another.
 */
export declare const associateWebACL: API.OperationMethod<AssociateWebACLRequest & RegionInput, AssociateWebACLResponse, AssociateWebACLError, Credentials | HttpClient.HttpClient>;
export type CheckCapacityError = WAFExpiredManagedRuleGroupVersionException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFInvalidResourceException | WAFLimitsExceededException | WAFNonexistentItemException | WAFSubscriptionNotFoundException | WAFUnavailableEntityException | CommonErrors;
/**
 * Returns the web ACL capacity unit (WCU) requirements for a specified scope and set of rules.
 * You can use this to check the capacity requirements for the rules you want to use in a
 * RuleGroup or WebACL.
 *
 * WAF uses WCUs to calculate and control the operating
 * resources that are used to run your rules, rule groups, and web ACLs. WAF
 * calculates capacity differently for each rule type, to reflect the relative cost of each rule.
 * Simple rules that cost little to run use fewer WCUs than more complex rules
 * that use more processing power.
 * Rule group capacity is fixed at creation, which helps users plan their
 * web ACL WCU usage when they use a rule group. For more information, see WAF web ACL capacity units (WCU)
 * in the *WAF Developer Guide*.
 */
export declare const checkCapacity: API.OperationMethod<CheckCapacityRequest & RegionInput, CheckCapacityResponse, CheckCapacityError, Credentials | HttpClient.HttpClient>;
export type CreateAPIKeyError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | CommonErrors;
/**
 * Creates an API key that contains a set of token domains.
 *
 * API keys are required for the integration of the CAPTCHA API in your JavaScript client applications.
 * The API lets you customize the placement and characteristics of the CAPTCHA puzzle for your end users.
 * For more information about the CAPTCHA JavaScript integration, see WAF client application integration in the *WAF Developer Guide*.
 *
 * You can use a single key for up to 5 domains. After you generate a key, you can copy it for use in your JavaScript
 * integration.
 */
export declare const createAPIKey: API.OperationMethod<CreateAPIKeyRequest & RegionInput, CreateAPIKeyResponse, CreateAPIKeyError, Credentials | HttpClient.HttpClient>;
export type CreateIPSetError = WAFDuplicateItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFOptimisticLockException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Creates an IPSet, which you use to identify web requests that
 * originate from specific IP addresses or ranges of IP addresses. For example, if you're
 * receiving a lot of requests from a ranges of IP addresses, you can configure WAF to
 * block them using an IPSet that lists those IP addresses.
 */
export declare const createIPSet: API.OperationMethod<CreateIPSetRequest & RegionInput, CreateIPSetResponse, CreateIPSetError, Credentials | HttpClient.HttpClient>;
export type CreateRegexPatternSetError = WAFDuplicateItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFOptimisticLockException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Creates a RegexPatternSet, which you reference in a RegexPatternSetReferenceStatement, to have WAF inspect a web request
 * component for the specified patterns.
 */
export declare const createRegexPatternSet: API.OperationMethod<CreateRegexPatternSetRequest & RegionInput, CreateRegexPatternSetResponse, CreateRegexPatternSetError, Credentials | HttpClient.HttpClient>;
export type CreateRuleGroupError = WAFDuplicateItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFNonexistentItemException | WAFOptimisticLockException | WAFSubscriptionNotFoundException | WAFTagOperationException | WAFTagOperationInternalErrorException | WAFUnavailableEntityException | CommonErrors;
/**
 * Creates a RuleGroup per the specifications provided.
 *
 * A rule group defines a collection of rules to inspect and control web requests that you can use in a WebACL. When you create a rule group, you define an immutable capacity limit. If you update a rule group, you must stay within the capacity. This allows others to reuse the rule group with confidence in its capacity requirements.
 */
export declare const createRuleGroup: API.OperationMethod<CreateRuleGroupRequest & RegionInput, CreateRuleGroupResponse, CreateRuleGroupError, Credentials | HttpClient.HttpClient>;
export type CreateWebACLError = WAFConfigurationWarningException | WAFDuplicateItemException | WAFExpiredManagedRuleGroupVersionException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFInvalidResourceException | WAFLimitsExceededException | WAFNonexistentItemException | WAFOptimisticLockException | WAFSubscriptionNotFoundException | WAFTagOperationException | WAFTagOperationInternalErrorException | WAFUnavailableEntityException | CommonErrors;
/**
 * Creates a WebACL per the specifications provided.
 *
 * A web ACL defines a collection of rules to use to inspect and control web requests. Each rule has a statement that defines what to look for in web requests and an action that WAF applies to requests that match the statement. In the web ACL, you assign a default action to take (allow, block) for any request that does not match any of the rules. The rules in a web ACL can be a combination of the types Rule, RuleGroup, and managed rule group. You can associate a web ACL with one or more Amazon Web Services resources to protect. The resource types include Amazon CloudFront distribution, Amazon API Gateway REST API, Application Load Balancer, AppSync GraphQL API, Amazon Cognito user pool, App Runner service, Amplify application, Amazon Web Services Verified Access instance, and Amazon Bedrock AgentCore Gateway.
 */
export declare const createWebACL: API.OperationMethod<CreateWebACLRequest & RegionInput, CreateWebACLResponse, CreateWebACLError, Credentials | HttpClient.HttpClient>;
export type DeleteAPIKeyError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | CommonErrors;
/**
 * Deletes the specified API key.
 *
 * After you delete a key, it can take up to 24 hours for WAF to disallow use of the key in all regions.
 */
export declare const deleteAPIKey: API.OperationMethod<DeleteAPIKeyRequest & RegionInput, DeleteAPIKeyResponse, DeleteAPIKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallManagerRuleGroupsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | CommonErrors;
/**
 * Deletes all rule groups that are managed by Firewall Manager from the specified WebACL.
 *
 * You can only use this if `ManagedByFirewallManager` and `RetrofittedByFirewallManager` are both false in the web ACL.
 */
export declare const deleteFirewallManagerRuleGroups: API.OperationMethod<DeleteFirewallManagerRuleGroupsRequest & RegionInput, DeleteFirewallManagerRuleGroupsResponse, DeleteFirewallManagerRuleGroupsError, Credentials | HttpClient.HttpClient>;
export type DeleteIPSetError = WAFAssociatedItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Deletes the specified IPSet.
 */
export declare const deleteIPSet: API.OperationMethod<DeleteIPSetRequest & RegionInput, DeleteIPSetResponse, DeleteIPSetError, Credentials | HttpClient.HttpClient>;
export type DeleteLoggingConfigurationError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | CommonErrors;
/**
 * Deletes the LoggingConfiguration from the specified web ACL.
 */
export declare const deleteLoggingConfiguration: API.OperationMethod<DeleteLoggingConfigurationRequest & RegionInput, DeleteLoggingConfigurationResponse, DeleteLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePermissionPolicyError = WAFInternalErrorException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Permanently deletes an IAM policy from the specified rule group.
 *
 * You must be the owner of the rule group to perform this operation.
 */
export declare const deletePermissionPolicy: API.OperationMethod<DeletePermissionPolicyRequest & RegionInput, DeletePermissionPolicyResponse, DeletePermissionPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRegexPatternSetError = WAFAssociatedItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Deletes the specified RegexPatternSet.
 */
export declare const deleteRegexPatternSet: API.OperationMethod<DeleteRegexPatternSetRequest & RegionInput, DeleteRegexPatternSetResponse, DeleteRegexPatternSetError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleGroupError = WAFAssociatedItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Deletes the specified RuleGroup.
 */
export declare const deleteRuleGroup: API.OperationMethod<DeleteRuleGroupRequest & RegionInput, DeleteRuleGroupResponse, DeleteRuleGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteWebACLError = WAFAssociatedItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Deletes the specified WebACL.
 *
 * You can only use this if `ManagedByFirewallManager` is false in the web ACL.
 *
 * Before deleting any web ACL, first disassociate it from all resources.
 *
 * - To retrieve a list of the resources that are associated with a web ACL, use the
 * following calls:
 *
 * - For Amazon CloudFront distributions, use the CloudFront call
 * `ListDistributionsByWebACLId`. For information, see ListDistributionsByWebACLId
 * in the *Amazon CloudFront API Reference*.
 *
 * - For all other resources, call ListResourcesForWebACL.
 *
 * - To disassociate a resource from a web ACL, use the following calls:
 *
 * - For Amazon CloudFront distributions, provide an empty web ACL ID in the CloudFront call
 * `UpdateDistribution`. For information, see UpdateDistribution
 * in the *Amazon CloudFront API Reference*.
 *
 * - For all other resources, call DisassociateWebACL.
 */
export declare const deleteWebACL: API.OperationMethod<DeleteWebACLRequest & RegionInput, DeleteWebACLResponse, DeleteWebACLError, Credentials | HttpClient.HttpClient>;
export type DescribeAllManagedProductsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Provides high-level information for the Amazon Web Services Managed Rules rule groups and Amazon Web Services Marketplace managed rule groups.
 */
export declare const describeAllManagedProducts: API.OperationMethod<DescribeAllManagedProductsRequest & RegionInput, DescribeAllManagedProductsResponse, DescribeAllManagedProductsError, Credentials | HttpClient.HttpClient>;
export type DescribeManagedProductsByVendorError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Provides high-level information for the managed rule groups owned by a specific vendor.
 */
export declare const describeManagedProductsByVendor: API.OperationMethod<DescribeManagedProductsByVendorRequest & RegionInput, DescribeManagedProductsByVendorResponse, DescribeManagedProductsByVendorError, Credentials | HttpClient.HttpClient>;
export type DescribeManagedRuleGroupError = WAFExpiredManagedRuleGroupVersionException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFInvalidResourceException | WAFNonexistentItemException | CommonErrors;
/**
 * Provides high-level information for a managed rule group, including descriptions of the rules.
 */
export declare const describeManagedRuleGroup: API.OperationMethod<DescribeManagedRuleGroupRequest & RegionInput, DescribeManagedRuleGroupResponse, DescribeManagedRuleGroupError, Credentials | HttpClient.HttpClient>;
export type DisassociateWebACLError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFUnavailableEntityException | CommonErrors;
/**
 * Disassociates the specified resource from its web ACL
 * association, if it has one.
 *
 * Use this for all resource types except for Amazon CloudFront distributions. For Amazon CloudFront, call `UpdateDistribution` for the distribution and provide an empty web ACL ID. For information, see UpdateDistribution in the *Amazon CloudFront API Reference*.
 *
 * **Required permissions for customer-managed IAM policies**
 *
 * This call requires permissions that are specific to the protected resource type.
 * For details, see Permissions for DisassociateWebACL in the *WAF Developer Guide*.
 */
export declare const disassociateWebACL: API.OperationMethod<DisassociateWebACLRequest & RegionInput, DisassociateWebACLResponse, DisassociateWebACLError, Credentials | HttpClient.HttpClient>;
export type GenerateMobileSdkReleaseUrlError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Generates a presigned download URL for the specified release of the mobile SDK.
 *
 * The mobile SDK is not generally available. Customers who have access to the mobile SDK can use it to establish and manage WAF tokens for use in HTTP(S) requests from a mobile device to WAF. For more information, see
 * WAF client application integration in the *WAF Developer Guide*.
 */
export declare const generateMobileSdkReleaseUrl: API.OperationMethod<GenerateMobileSdkReleaseUrlRequest & RegionInput, GenerateMobileSdkReleaseUrlResponse, GenerateMobileSdkReleaseUrlError, Credentials | HttpClient.HttpClient>;
export type GetDecryptedAPIKeyError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFInvalidResourceException | WAFNonexistentItemException | CommonErrors;
/**
 * Returns your API key in decrypted form. Use this to check the token domains that you have defined for the key.
 *
 * API keys are required for the integration of the CAPTCHA API in your JavaScript client applications.
 * The API lets you customize the placement and characteristics of the CAPTCHA puzzle for your end users.
 * For more information about the CAPTCHA JavaScript integration, see WAF client application integration in the *WAF Developer Guide*.
 */
export declare const getDecryptedAPIKey: API.OperationMethod<GetDecryptedAPIKeyRequest & RegionInput, GetDecryptedAPIKeyResponse, GetDecryptedAPIKeyError, Credentials | HttpClient.HttpClient>;
export type GetIPSetError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves the specified IPSet.
 */
export declare const getIPSet: API.OperationMethod<GetIPSetRequest & RegionInput, GetIPSetResponse, GetIPSetError, Credentials | HttpClient.HttpClient>;
export type GetLoggingConfigurationError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Returns the LoggingConfiguration for the specified web ACL.
 */
export declare const getLoggingConfiguration: API.OperationMethod<GetLoggingConfigurationRequest & RegionInput, GetLoggingConfigurationResponse, GetLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetManagedRuleSetError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves the specified managed rule set.
 *
 * This is intended for use only by vendors of managed rule sets. Vendors are Amazon Web Services and Amazon Web Services Marketplace sellers.
 *
 * Vendors, you can use the managed rule set APIs to provide controlled rollout of your versioned managed rule group offerings for your customers. The APIs are `ListManagedRuleSets`, `GetManagedRuleSet`, `PutManagedRuleSetVersions`, and `UpdateManagedRuleSetVersionExpiryDate`.
 */
export declare const getManagedRuleSet: API.OperationMethod<GetManagedRuleSetRequest & RegionInput, GetManagedRuleSetResponse, GetManagedRuleSetError, Credentials | HttpClient.HttpClient>;
export type GetMobileSdkReleaseError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves information for the specified mobile SDK release, including release notes and
 * tags.
 *
 * The mobile SDK is not generally available. Customers who have access to the mobile SDK can use it to establish and manage WAF tokens for use in HTTP(S) requests from a mobile device to WAF. For more information, see
 * WAF client application integration in the *WAF Developer Guide*.
 */
export declare const getMobileSdkRelease: API.OperationMethod<GetMobileSdkReleaseRequest & RegionInput, GetMobileSdkReleaseResponse, GetMobileSdkReleaseError, Credentials | HttpClient.HttpClient>;
export type GetPermissionPolicyError = WAFInternalErrorException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Returns the IAM policy that is attached to the specified rule group.
 *
 * You must be the owner of the rule group to perform this operation.
 */
export declare const getPermissionPolicy: API.OperationMethod<GetPermissionPolicyRequest & RegionInput, GetPermissionPolicyResponse, GetPermissionPolicyError, Credentials | HttpClient.HttpClient>;
export type GetRateBasedStatementManagedKeysError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFUnsupportedAggregateKeyTypeException | CommonErrors;
/**
 * Retrieves the IP addresses that are currently blocked by a rate-based rule instance. This
 * is only available for rate-based rules that aggregate solely on the IP address or on the forwarded IP
 * address.
 *
 * The maximum
 * number of addresses that can be blocked for a single rate-based rule instance is 10,000.
 * If more than 10,000 addresses exceed the rate limit, those with the highest rates are
 * blocked.
 *
 * For a rate-based rule that you've defined inside a rule group, provide the name of the
 * rule group reference statement in your request, in addition to the rate-based rule name and
 * the web ACL name.
 *
 * WAF monitors web requests and manages keys independently for each unique combination
 * of web ACL, optional rule group, and rate-based rule. For example, if you define a
 * rate-based rule inside a rule group, and then use the rule group in a web ACL, WAF
 * monitors web requests and manages keys for that web ACL, rule group reference statement,
 * and rate-based rule instance. If you use the same rule group in a second web ACL, WAF
 * monitors web requests and manages keys for this second usage completely independent of your
 * first.
 */
export declare const getRateBasedStatementManagedKeys: API.OperationMethod<GetRateBasedStatementManagedKeysRequest & RegionInput, GetRateBasedStatementManagedKeysResponse, GetRateBasedStatementManagedKeysError, Credentials | HttpClient.HttpClient>;
export type GetRegexPatternSetError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves the specified RegexPatternSet.
 */
export declare const getRegexPatternSet: API.OperationMethod<GetRegexPatternSetRequest & RegionInput, GetRegexPatternSetResponse, GetRegexPatternSetError, Credentials | HttpClient.HttpClient>;
export type GetRevenueStatisticsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves ranked monetization statistics. Use the `StatisticType` parameter to specify the ranking: `TOP_SOURCES_BY_REVENUE` for top sources by revenue, or `TOP_PATHS_BY_REVENUE` for top content paths by revenue. This operation is only available for `CLOUDFRONT` scope. The maximum supported time window is 90 days. When no `CurrencyMode` filter is provided, results default to `REAL`. To retrieve test data, include a `CurrencyMode` filter with the value `TEST`.
 */
export declare const getRevenueStatistics: API.OperationMethod<GetRevenueStatisticsRequest & RegionInput, GetRevenueStatisticsResponse, GetRevenueStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetRevenueStatisticsSummaryError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves a summary of monetization revenue for the specified time window. Returns total revenue, revenue by verification tier, total settlements, and total HTTP 402 responses served. This operation is only available for `CLOUDFRONT` scope. The maximum supported time window is 90 days. When no `CurrencyMode` filter is provided, results default to `REAL`. To retrieve test data, include a `CurrencyMode` filter with the value `TEST`.
 */
export declare const getRevenueStatisticsSummary: API.OperationMethod<GetRevenueStatisticsSummaryRequest & RegionInput, GetRevenueStatisticsSummaryResponse, GetRevenueStatisticsSummaryError, Credentials | HttpClient.HttpClient>;
export type GetRevenueStatisticsTimeSeriesError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves time series data for monetization revenue. Returns data points aggregated at the specified interval for the given time window. This operation is only available for `CLOUDFRONT` scope. The maximum supported time window is 90 days. When no `CurrencyMode` filter is provided, results default to `REAL`. To retrieve test data, include a `CurrencyMode` filter with the value `TEST`.
 */
export declare const getRevenueStatisticsTimeSeries: API.OperationMethod<GetRevenueStatisticsTimeSeriesRequest & RegionInput, GetRevenueStatisticsTimeSeriesResponse, GetRevenueStatisticsTimeSeriesError, Credentials | HttpClient.HttpClient>;
export type GetRuleGroupError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves the specified RuleGroup.
 */
export declare const getRuleGroup: API.OperationMethod<GetRuleGroupRequest & RegionInput, GetRuleGroupResponse, GetRuleGroupError, Credentials | HttpClient.HttpClient>;
export type GetSampledRequestsError = WAFInternalErrorException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Gets detailed information about a specified number of requests--a sample--that WAF
 * randomly selects from among the first 5,000 requests that your Amazon Web Services resource received
 * during a time range that you choose. You can specify a sample size of up to 500 requests,
 * and you can specify any time range in the previous three hours.
 *
 * `GetSampledRequests` returns a time range, which is usually the time range that
 * you specified. However, if your resource (such as a CloudFront distribution) received 5,000
 * requests before the specified time range elapsed, `GetSampledRequests` returns
 * an updated time range. This new time range indicates the actual period during which WAF
 * selected the requests in the sample.
 */
export declare const getSampledRequests: API.OperationMethod<GetSampledRequestsRequest & RegionInput, GetSampledRequestsResponse, GetSampledRequestsError, Credentials | HttpClient.HttpClient>;
export type GetTopPathStatisticsByTrafficError = WAFFeatureNotIncludedInPricingPlanException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves aggregated statistics about the top URI paths accessed by bot traffic for a specified web ACL and time window.
 * You can use this operation to analyze which paths on your web application receive the most bot traffic and identify the specific bots accessing those paths.
 * The operation supports filtering by bot category, organization, or name, and allows you to drill down into specific path prefixes to view detailed URI-level statistics.
 */
export declare const getTopPathStatisticsByTraffic: API.OperationMethod<GetTopPathStatisticsByTrafficRequest & RegionInput, GetTopPathStatisticsByTrafficResponse, GetTopPathStatisticsByTrafficError, Credentials | HttpClient.HttpClient>;
export type GetWebACLError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves the specified WebACL.
 */
export declare const getWebACL: API.OperationMethod<GetWebACLRequest & RegionInput, GetWebACLResponse, GetWebACLError, Credentials | HttpClient.HttpClient>;
export type GetWebACLForResourceError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFUnavailableEntityException | CommonErrors;
/**
 * Retrieves the WebACL for the specified resource.
 *
 * This call uses `GetWebACL`, to verify that your account has permission to access the retrieved web ACL.
 * If you get an error that indicates that your account isn't authorized to perform `wafv2:GetWebACL` on the resource,
 * that error won't be included in your CloudTrail event history.
 *
 * For Amazon CloudFront, don't use this call. Instead, call the CloudFront action
 * `GetDistributionConfig`. For information, see GetDistributionConfig in the *Amazon CloudFront API Reference*.
 *
 * **Required permissions for customer-managed IAM policies**
 *
 * This call requires permissions that are specific to the protected resource type.
 * For details, see Permissions for GetWebACLForResource in the *WAF Developer Guide*.
 */
export declare const getWebACLForResource: API.OperationMethod<GetWebACLForResourceRequest & RegionInput, GetWebACLForResourceResponse, GetWebACLForResourceError, Credentials | HttpClient.HttpClient>;
export type ListAPIKeysError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFInvalidResourceException | CommonErrors;
/**
 * Retrieves a list of the API keys that you've defined for the specified scope.
 *
 * API keys are required for the integration of the CAPTCHA API in your JavaScript client applications.
 * The API lets you customize the placement and characteristics of the CAPTCHA puzzle for your end users.
 * For more information about the CAPTCHA JavaScript integration, see WAF client application integration in the *WAF Developer Guide*.
 */
export declare const listAPIKeys: API.OperationMethod<ListAPIKeysRequest & RegionInput, ListAPIKeysResponse, ListAPIKeysError, Credentials | HttpClient.HttpClient>;
export type ListAvailableManagedRuleGroupsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Retrieves an array of managed rule groups that are available for you to use. This list
 * includes all Amazon Web Services Managed Rules rule groups and all of the Amazon Web Services Marketplace managed rule groups that you're
 * subscribed to.
 */
export declare const listAvailableManagedRuleGroups: API.OperationMethod<ListAvailableManagedRuleGroupsRequest & RegionInput, ListAvailableManagedRuleGroupsResponse, ListAvailableManagedRuleGroupsError, Credentials | HttpClient.HttpClient>;
export type ListAvailableManagedRuleGroupVersionsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Returns a list of the available versions for the specified managed rule group.
 */
export declare const listAvailableManagedRuleGroupVersions: API.OperationMethod<ListAvailableManagedRuleGroupVersionsRequest & RegionInput, ListAvailableManagedRuleGroupVersionsResponse, ListAvailableManagedRuleGroupVersionsError, Credentials | HttpClient.HttpClient>;
export type ListIPSetsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Retrieves an array of IPSetSummary objects for the IP sets that you
 * manage.
 */
export declare const listIPSets: API.OperationMethod<ListIPSetsRequest & RegionInput, ListIPSetsResponse, ListIPSetsError, Credentials | HttpClient.HttpClient>;
export type ListLoggingConfigurationsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Retrieves an array of your LoggingConfiguration objects.
 */
export declare const listLoggingConfigurations: API.OperationMethod<ListLoggingConfigurationsRequest & RegionInput, ListLoggingConfigurationsResponse, ListLoggingConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListManagedRuleSetsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Retrieves the managed rule sets that you own.
 *
 * This is intended for use only by vendors of managed rule sets. Vendors are Amazon Web Services and Amazon Web Services Marketplace sellers.
 *
 * Vendors, you can use the managed rule set APIs to provide controlled rollout of your versioned managed rule group offerings for your customers. The APIs are `ListManagedRuleSets`, `GetManagedRuleSet`, `PutManagedRuleSetVersions`, and `UpdateManagedRuleSetVersionExpiryDate`.
 */
export declare const listManagedRuleSets: API.OperationMethod<ListManagedRuleSetsRequest & RegionInput, ListManagedRuleSetsResponse, ListManagedRuleSetsError, Credentials | HttpClient.HttpClient>;
export type ListMobileSdkReleasesError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Retrieves a list of the available releases for the mobile SDK and the specified device
 * platform.
 *
 * The mobile SDK is not generally available. Customers who have access to the mobile SDK can use it to establish and manage WAF tokens for use in HTTP(S) requests from a mobile device to WAF. For more information, see
 * WAF client application integration in the *WAF Developer Guide*.
 */
export declare const listMobileSdkReleases: API.OperationMethod<ListMobileSdkReleasesRequest & RegionInput, ListMobileSdkReleasesResponse, ListMobileSdkReleasesError, Credentials | HttpClient.HttpClient>;
export type ListRegexPatternSetsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Retrieves an array of RegexPatternSetSummary objects for the regex
 * pattern sets that you manage.
 */
export declare const listRegexPatternSets: API.OperationMethod<ListRegexPatternSetsRequest & RegionInput, ListRegexPatternSetsResponse, ListRegexPatternSetsError, Credentials | HttpClient.HttpClient>;
export type ListResourcesForWebACLError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves an array of the Amazon Resource Names (ARNs) for the resources that
 * are associated with the specified web ACL.
 *
 * For Amazon CloudFront, don't use this call. Instead, use the CloudFront call
 * `ListDistributionsByWebACLId`. For information, see ListDistributionsByWebACLId
 * in the *Amazon CloudFront API Reference*.
 *
 * **Required permissions for customer-managed IAM policies**
 *
 * This call requires permissions that are specific to the protected resource type.
 * For details, see Permissions for ListResourcesForWebACL in the *WAF Developer Guide*.
 */
export declare const listResourcesForWebACL: API.OperationMethod<ListResourcesForWebACLRequest & RegionInput, ListResourcesForWebACLResponse, ListResourcesForWebACLError, Credentials | HttpClient.HttpClient>;
export type ListRuleGroupsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Retrieves an array of RuleGroupSummary objects for the rule groups
 * that you manage.
 */
export declare const listRuleGroups: API.OperationMethod<ListRuleGroupsRequest & RegionInput, ListRuleGroupsResponse, ListRuleGroupsError, Credentials | HttpClient.HttpClient>;
export type ListSettlementRecordsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | CommonErrors;
/**
 * Retrieves individual settlement transaction records for monetization. Each record represents a single payment transaction between a client and your protected resource. This operation is only available for `CLOUDFRONT` scope. The maximum supported time window is 90 days. When no `CurrencyMode` filter is provided, results default to `REAL`. To retrieve test data, include a `CurrencyMode` filter with the value `TEST`.
 */
export declare const listSettlementRecords: API.OperationMethod<ListSettlementRecordsRequest & RegionInput, ListSettlementRecordsResponse, ListSettlementRecordsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Retrieves the TagInfoForResource for the specified resource. Tags are
 * key:value pairs that you can use to categorize and manage your resources, for purposes like
 * billing. For example, you might set the tag key to "customer" and the value to the customer
 * name or ID. You can specify one or more tags to add to each Amazon Web Services resource, up to 50 tags
 * for a resource.
 *
 * You can tag the Amazon Web Services resources that you manage through WAF: web ACLs, rule
 * groups, IP sets, and regex pattern sets. You can't manage or view tags through the WAF
 * console.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWebACLsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | CommonErrors;
/**
 * Retrieves an array of WebACLSummary objects for the web ACLs that you
 * manage.
 */
export declare const listWebACLs: API.OperationMethod<ListWebACLsRequest & RegionInput, ListWebACLsResponse, ListWebACLsError, Credentials | HttpClient.HttpClient>;
export type PutLoggingConfigurationError = WAFFeatureNotIncludedInPricingPlanException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFLogDestinationPermissionIssueException | WAFNonexistentItemException | WAFOptimisticLockException | WAFServiceLinkedRoleErrorException | CommonErrors;
/**
 * Enables the specified LoggingConfiguration, to start logging from a
 * web ACL, according to the configuration provided.
 *
 * If you configure data protection for the web ACL, the protection applies to the data that WAF sends to the logs.
 *
 * This operation completely replaces any mutable specifications that you already have for a logging configuration with the ones that you provide to this call.
 *
 * To modify an existing logging configuration, do the following:
 *
 * - Retrieve it by calling GetLoggingConfiguration
 *
 * - Update its settings as needed
 *
 * - Provide the complete logging configuration specification to this call
 *
 * You can define one logging destination per web ACL.
 *
 * You can access information about the traffic that WAF inspects using the following
 * steps:
 *
 * - Create your logging destination. You can use an Amazon CloudWatch Logs log group, an Amazon Simple Storage Service (Amazon S3) bucket, or an Amazon Kinesis Data Firehose.
 *
 * The name that you give the destination must start with `aws-waf-logs-`. Depending on the type of destination, you might need to configure additional settings or permissions.
 *
 * For configuration requirements and pricing information for each destination type, see
 * Logging web ACL traffic
 * in the *WAF Developer Guide*.
 *
 * - Associate your logging destination to your web ACL using a
 * `PutLoggingConfiguration` request.
 *
 * When you successfully enable logging using a `PutLoggingConfiguration`
 * request, WAF creates an additional role or policy that is required to write
 * logs to the logging destination. For an Amazon CloudWatch Logs log group, WAF creates a resource policy on the log group.
 * For an Amazon S3 bucket, WAF creates a bucket policy. For an Amazon Kinesis Data Firehose, WAF creates a service-linked role.
 *
 * For additional information about web ACL logging, see
 * Logging web ACL traffic information
 * in the *WAF Developer Guide*.
 */
export declare const putLoggingConfiguration: API.OperationMethod<PutLoggingConfigurationRequest & RegionInput, PutLoggingConfigurationResponse, PutLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutManagedRuleSetVersionsError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | CommonErrors;
/**
 * Defines the versions of your managed rule set that you are offering to the customers.
 * Customers see your offerings as managed rule groups with versioning.
 *
 * This is intended for use only by vendors of managed rule sets. Vendors are Amazon Web Services and Amazon Web Services Marketplace sellers.
 *
 * Vendors, you can use the managed rule set APIs to provide controlled rollout of your versioned managed rule group offerings for your customers. The APIs are `ListManagedRuleSets`, `GetManagedRuleSet`, `PutManagedRuleSetVersions`, and `UpdateManagedRuleSetVersionExpiryDate`.
 *
 * Customers retrieve their managed rule group list by calling ListAvailableManagedRuleGroups. The name that you provide here for your
 * managed rule set is the name the customer sees for the corresponding managed rule group.
 * Customers can retrieve the available versions for a managed rule group by calling ListAvailableManagedRuleGroupVersions. You provide a rule group
 * specification for each version. For each managed rule set, you must specify a version that
 * you recommend using.
 *
 * To initiate the expiration of a managed rule group version, use UpdateManagedRuleSetVersionExpiryDate.
 */
export declare const putManagedRuleSetVersions: API.OperationMethod<PutManagedRuleSetVersionsRequest & RegionInput, PutManagedRuleSetVersionsResponse, PutManagedRuleSetVersionsError, Credentials | HttpClient.HttpClient>;
export type PutPermissionPolicyError = WAFInternalErrorException | WAFInvalidParameterException | WAFInvalidPermissionPolicyException | WAFNonexistentItemException | CommonErrors;
/**
 * Use this to share a rule group with other accounts.
 *
 * This action attaches an IAM policy to the specified resource. You must be the owner of the rule group to perform this operation.
 *
 * This action is subject to the following restrictions:
 *
 * - You can attach only one policy with each `PutPermissionPolicy`
 * request.
 *
 * - The ARN in the request must be a valid WAF RuleGroup ARN and the
 * rule group must exist in the same Region.
 *
 * - The user making the request must be the owner of the rule group.
 *
 * If a rule group has been shared with your account, you can access it through the call `GetRuleGroup`,
 * and you can reference it in `CreateWebACL` and `UpdateWebACL`.
 * Rule groups that are shared with you don't appear in your WAF console rule groups listing.
 */
export declare const putPermissionPolicy: API.OperationMethod<PutPermissionPolicyRequest & RegionInput, PutPermissionPolicyResponse, PutPermissionPolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFNonexistentItemException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Associates tags with the specified Amazon Web Services resource. Tags are key:value pairs that you can
 * use to categorize and manage your resources, for purposes like billing. For example, you
 * might set the tag key to "customer" and the value to the customer name or ID. You can
 * specify one or more tags to add to each Amazon Web Services resource, up to 50 tags for a
 * resource.
 *
 * You can tag the Amazon Web Services resources that you manage through WAF: web ACLs, rule
 * groups, IP sets, and regex pattern sets. You can't manage or view tags through the WAF
 * console.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFTagOperationException | WAFTagOperationInternalErrorException | CommonErrors;
/**
 * Disassociates tags from an Amazon Web Services resource. Tags are key:value pairs that you can
 * associate with Amazon Web Services resources. For example, the tag key might be "customer" and the tag
 * value might be "companyA." You can specify one or more tags to add to each container. You
 * can add up to 50 tags to each Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateIPSetError = WAFDuplicateItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFNonexistentItemException | WAFOptimisticLockException | CommonErrors;
/**
 * Updates the specified IPSet.
 *
 * This operation completely replaces the mutable specifications that you already have for the IP set with the ones that you provide to this call.
 *
 * To modify an IP set, do the following:
 *
 * - Retrieve it by calling GetIPSet
 *
 * - Update its settings as needed
 *
 * - Provide the complete IP set specification to this call
 *
 * **Temporary inconsistencies during updates**
 *
 * When you create or change a web ACL or other WAF resources, the changes take a small amount of time to propagate to all areas where the resources are stored. The propagation time can be from a few seconds to a number of minutes.
 *
 * The following are examples of the temporary inconsistencies that you might notice during change propagation:
 *
 * - After you create a web ACL, if you try to associate it with a resource, you might get an exception indicating that the web ACL is unavailable.
 *
 * - After you add a rule group to a web ACL, the new rule group rules might be in effect in one area where the web ACL is used and not in another.
 *
 * - After you change a rule action setting, you might see the old action in some places and the new action in others.
 *
 * - After you add an IP address to an IP set that is in use in a blocking rule, the new address might be blocked in one area while still allowed in another.
 */
export declare const updateIPSet: API.OperationMethod<UpdateIPSetRequest & RegionInput, UpdateIPSetResponse, UpdateIPSetError, Credentials | HttpClient.HttpClient>;
export type UpdateManagedRuleSetVersionExpiryDateError = WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFNonexistentItemException | WAFOptimisticLockException | CommonErrors;
/**
 * Updates the expiration information for your managed rule set. Use this to initiate the
 * expiration of a managed rule group version. After you initiate expiration for a version,
 * WAF excludes it from the response to ListAvailableManagedRuleGroupVersions for the managed rule group.
 *
 * This is intended for use only by vendors of managed rule sets. Vendors are Amazon Web Services and Amazon Web Services Marketplace sellers.
 *
 * Vendors, you can use the managed rule set APIs to provide controlled rollout of your versioned managed rule group offerings for your customers. The APIs are `ListManagedRuleSets`, `GetManagedRuleSet`, `PutManagedRuleSetVersions`, and `UpdateManagedRuleSetVersionExpiryDate`.
 */
export declare const updateManagedRuleSetVersionExpiryDate: API.OperationMethod<UpdateManagedRuleSetVersionExpiryDateRequest & RegionInput, UpdateManagedRuleSetVersionExpiryDateResponse, UpdateManagedRuleSetVersionExpiryDateError, Credentials | HttpClient.HttpClient>;
export type UpdateRegexPatternSetError = WAFDuplicateItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFNonexistentItemException | WAFOptimisticLockException | CommonErrors;
/**
 * Updates the specified RegexPatternSet.
 *
 * This operation completely replaces the mutable specifications that you already have for the regex pattern set with the ones that you provide to this call.
 *
 * To modify a regex pattern set, do the following:
 *
 * - Retrieve it by calling GetRegexPatternSet
 *
 * - Update its settings as needed
 *
 * - Provide the complete regex pattern set specification to this call
 *
 * **Temporary inconsistencies during updates**
 *
 * When you create or change a web ACL or other WAF resources, the changes take a small amount of time to propagate to all areas where the resources are stored. The propagation time can be from a few seconds to a number of minutes.
 *
 * The following are examples of the temporary inconsistencies that you might notice during change propagation:
 *
 * - After you create a web ACL, if you try to associate it with a resource, you might get an exception indicating that the web ACL is unavailable.
 *
 * - After you add a rule group to a web ACL, the new rule group rules might be in effect in one area where the web ACL is used and not in another.
 *
 * - After you change a rule action setting, you might see the old action in some places and the new action in others.
 *
 * - After you add an IP address to an IP set that is in use in a blocking rule, the new address might be blocked in one area while still allowed in another.
 */
export declare const updateRegexPatternSet: API.OperationMethod<UpdateRegexPatternSetRequest & RegionInput, UpdateRegexPatternSetResponse, UpdateRegexPatternSetError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleGroupError = WAFConfigurationWarningException | WAFDuplicateItemException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFLimitsExceededException | WAFNonexistentItemException | WAFOptimisticLockException | WAFSubscriptionNotFoundException | WAFUnavailableEntityException | CommonErrors;
/**
 * Updates the specified RuleGroup.
 *
 * This operation completely replaces the mutable specifications that you already have for the rule group with the ones that you provide to this call.
 *
 * To modify a rule group, do the following:
 *
 * - Retrieve it by calling GetRuleGroup
 *
 * - Update its settings as needed
 *
 * - Provide the complete rule group specification to this call
 *
 * A rule group defines a collection of rules to inspect and control web requests that you can use in a WebACL. When you create a rule group, you define an immutable capacity limit. If you update a rule group, you must stay within the capacity. This allows others to reuse the rule group with confidence in its capacity requirements.
 *
 * **Temporary inconsistencies during updates**
 *
 * When you create or change a web ACL or other WAF resources, the changes take a small amount of time to propagate to all areas where the resources are stored. The propagation time can be from a few seconds to a number of minutes.
 *
 * The following are examples of the temporary inconsistencies that you might notice during change propagation:
 *
 * - After you create a web ACL, if you try to associate it with a resource, you might get an exception indicating that the web ACL is unavailable.
 *
 * - After you add a rule group to a web ACL, the new rule group rules might be in effect in one area where the web ACL is used and not in another.
 *
 * - After you change a rule action setting, you might see the old action in some places and the new action in others.
 *
 * - After you add an IP address to an IP set that is in use in a blocking rule, the new address might be blocked in one area while still allowed in another.
 */
export declare const updateRuleGroup: API.OperationMethod<UpdateRuleGroupRequest & RegionInput, UpdateRuleGroupResponse, UpdateRuleGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateWebACLError = WAFConfigurationWarningException | WAFDuplicateItemException | WAFExpiredManagedRuleGroupVersionException | WAFFeatureNotIncludedInPricingPlanException | WAFInternalErrorException | WAFInvalidOperationException | WAFInvalidParameterException | WAFInvalidResourceException | WAFLimitsExceededException | WAFNonexistentItemException | WAFOptimisticLockException | WAFSubscriptionNotFoundException | WAFUnavailableEntityException | CommonErrors;
/**
 * Updates the specified WebACL. While updating a web ACL, WAF provides
 * continuous coverage to the resources that you have associated with the web ACL.
 *
 * This operation completely replaces the mutable specifications that you already have for the web ACL with the ones that you provide to this call.
 *
 * To modify a web ACL, do the following:
 *
 * - Retrieve it by calling GetWebACL
 *
 * - Update its settings as needed
 *
 * - Provide the complete web ACL specification to this call
 *
 * A web ACL defines a collection of rules to use to inspect and control web requests. Each rule has a statement that defines what to look for in web requests and an action that WAF applies to requests that match the statement. In the web ACL, you assign a default action to take (allow, block) for any request that does not match any of the rules. The rules in a web ACL can be a combination of the types Rule, RuleGroup, and managed rule group. You can associate a web ACL with one or more Amazon Web Services resources to protect. The resource types include Amazon CloudFront distribution, Amazon API Gateway REST API, Application Load Balancer, AppSync GraphQL API, Amazon Cognito user pool, App Runner service, Amplify application, Amazon Web Services Verified Access instance, and Amazon Bedrock AgentCore Gateway.
 *
 * **Temporary inconsistencies during updates**
 *
 * When you create or change a web ACL or other WAF resources, the changes take a small amount of time to propagate to all areas where the resources are stored. The propagation time can be from a few seconds to a number of minutes.
 *
 * The following are examples of the temporary inconsistencies that you might notice during change propagation:
 *
 * - After you create a web ACL, if you try to associate it with a resource, you might get an exception indicating that the web ACL is unavailable.
 *
 * - After you add a rule group to a web ACL, the new rule group rules might be in effect in one area where the web ACL is used and not in another.
 *
 * - After you change a rule action setting, you might see the old action in some places and the new action in others.
 *
 * - After you add an IP address to an IP set that is in use in a blocking rule, the new address might be blocked in one area while still allowed in another.
 */
export declare const updateWebACL: API.OperationMethod<UpdateWebACLRequest & RegionInput, UpdateWebACLResponse, UpdateWebACLError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=wafv2.d.ts.map