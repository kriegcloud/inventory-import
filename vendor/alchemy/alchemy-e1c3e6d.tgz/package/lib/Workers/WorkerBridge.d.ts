/**
 * The engine-invariant event-dispatch core shared by every
 * engine's bridge: run one event's handler against a shared build under a
 * fresh per-event `Scope`, and normalize an RPC dispatcher's return value
 * into the effect the bridge runs.
 *
 * The engine's entrypoint class (workerd's `WorkerEntrypoint`, a runner's
 * server loop) owns the event API; it hands this core the per-event
 * services and its `waitUntil` hook.
 *
 * @internal
 */
import type * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Layer from "effect/Layer";
import { EventLifetime } from "./EventLifetime.ts";
import type { Pin, WorkerBuild } from "./Worker.ts";
export interface ProcessEventOptions<T, Build extends WorkerBuild<any, any>> {
    /**
     * Select the handler effect for this event from the build, together with
     * the services captured when the export was assembled.
     */
    readonly makeEffect: (built: Build) => readonly [Effect.Effect<any, any, any>, Context.Context<never>];
    /**
     * Per-event services that shadow the captured services and the built
     * instance context — e.g. the real per-event execution context, which
     * must win over the *deferred* one the instance context carries.
     */
    readonly services?: ((built: Build) => Layer.Layer<never>) | undefined;
    /**
     * Keep the event alive until `promise` settles (`ctx.waitUntil`). Used
     * to pin the in-flight build and to close the request scope after the
     * response has been returned.
     */
    readonly waitUntil: Pin;
    /** Turn the handler's exit into the value returned to the engine. */
    readonly onExit: (exit: Exit.Exit<any, any>, lifetime: EventLifetime["Service"]) => T | Promise<T>;
}
/**
 * Run one event: resolve the shared build (pinned to this event), run the
 * selected handler with a fresh request `Scope` provided as `Scope.Scope`
 * (so `Effect.addFinalizer` in a handler attaches to the request scope) and
 * the event's telemetry exporters, then close the scope into `waitUntil`
 * after the response. Closing waits for the work the event was told about
 * through its {@link EventLifetime}: `waitUntil` work, and a streamed body
 * or RPC stream.
 */
export declare const processEvent: <T, Build extends WorkerBuild<any, any>>(build: (pin: Pin) => Promise<Build>, { makeEffect, services, waitUntil, onExit }: ProcessEventOptions<T, Build>) => Promise<T>;
/**
 * Normalize an RPC dispatcher's return value into the effect the bridge
 * runs. Effects (including nested-RPC values built by `asEffectOrStream`,
 * which are Effects *branded* as Streams) run as effects — their resolved
 * value may itself be a `Stream`, which `handleRpcExit` then encodes. A
 * *genuine* `Stream` (not an Effect) or a plain value is lifted into the
 * success channel so `handleRpcExit` encodes it directly.
 */
export declare const toRpcEffect: (result: unknown) => Effect.Effect<unknown, unknown, any>;
/**
 * Dispatch an RPC method call against a shape: a missing method is a
 * defect (the caller named something the worker never exported).
 */
export declare const dispatchRpcMethod: (shape: Record<string, unknown> | undefined, method: string, args: readonly unknown[]) => Effect.Effect<unknown, unknown, any>;
/**
 * The RPC transport reads a Stream result after the call has returned, outside
 * the event's fiber. Run it with the call's context, so its spans reach the
 * event's exporters and the `waitUntil` work it hands off joins the event.
 */
export declare const withEventContext: <E, R>(effect: Effect.Effect<unknown, E, R>) => Effect.Effect<unknown, E, R>;
//# sourceMappingURL=WorkerBridge.d.ts.map