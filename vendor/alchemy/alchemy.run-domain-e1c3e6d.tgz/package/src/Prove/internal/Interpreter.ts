import * as Data from "effect/Data";
import * as Effect from "effect/Effect";
import * as Option from "effect/Option";
import * as Brands from "./Brands.ts";
import * as Compare from "./Compare.ts";
import { fromTruth, isQuotient, same, textual, truth } from "./Compare.ts";
import * as Library from "./Library.ts";
import * as Smt from "./Smt.ts";
import type { Loader, OpaqueFunction } from "./Source.ts";
import * as Symbolic from "./Symbolic.ts";
import type { Brand, Env, Eval, Module, Node, Run, Scope, Site, V } from "./Value.ts";
import * as Value from "./Value.ts";

const KINDS = ["Event", "Rejection", "Command"] as const;

/** A domain class: an event, a rejection or a command. */
interface DomainClass {
  readonly kind: (typeof KINDS)[number];
  readonly tag: string;
  readonly fields: Readonly<Record<string, unknown>>;
}

const isDomainClass = (u: unknown): u is DomainClass =>
  typeof u === "function" &&
  (KINDS as ReadonlyArray<unknown>).includes((u as { kind?: unknown }).kind) &&
  typeof (u as { tag?: unknown }).tag === "string";

/** A request context: a tag with the schema of what it provides. */
interface ContextTag {
  readonly key: string;
  readonly schema: unknown;
}

const isContextTag = (u: unknown): u is ContextTag =>
  typeof u === "function" &&
  typeof (u as { key?: unknown }).key === "string" &&
  Symbolic.typeOf((u as { schema?: unknown }).schema) !== undefined;

/** Whether a class is one of `effect/Data`'s or `effect/Schema`'s: its instances are their fields. */
const extendsOneOf = (cls: unknown, bases: ReadonlyArray<unknown>): boolean => {
  if (typeof cls !== "function") return false;
  for (
    let parent: unknown = Object.getPrototypeOf(cls);
    typeof parent === "function";
    parent = Object.getPrototypeOf(parent)
  )
    if (bases.includes(parent)) return true;
  return false;
};

const isDataClass = (cls: unknown): boolean => extendsOneOf(cls, [Data.Class, Data.Error]);

/** Whether a class is an error: `yield*` on an instance fails with it. */
const isError = (cls: unknown): boolean =>
  typeof cls === "function"
    ? extendsOneOf(cls, [Data.Error])
    : (cls as { readonly error?: unknown } | null)?.error === true;

const tags = new WeakMap<object, string | undefined>();

/** The `_tag` a class of `Data.TaggedError` or `Data.TaggedClass` gives its instances. */
const tagOfClass = (cls: unknown): string | undefined => {
  if (typeof cls !== "function") return undefined;
  if (tags.has(cls)) return tags.get(cls);
  let tag: string | undefined;
  try {
    const made: unknown = Reflect.construct(cls, [{}]);
    const found = (made as { readonly _tag?: unknown } | null)?._tag;
    tag = typeof found === "string" ? found : undefined;
  } catch {
    tag = undefined;
  }
  tags.set(cls, tag);
  return tag;
};

const brands = new WeakMap<object, Brand>();

/** The brand of a data class's instances: one for each class, so two of them compare as one class. */
const dataBrand = (cls: unknown): Brand => {
  const known = brands.get(cls as object);
  if (known) return known;
  const made: Brand = { kind: "Data", cls };
  brands.set(cls as object, made);
  return made;
};

const fromHost = (value: unknown, name: string): V =>
  typeof value === "number"
    ? Value.num(value)
    : typeof value === "string"
      ? Value.str(value)
      : typeof value === "boolean"
        ? Value.bool(value)
        : typeof value === "bigint"
          ? { _tag: "Big", value }
          : value === null
            ? Value.nil
            : value === undefined
              ? Value.undef
              : { _tag: "Host", value, name };

const child = (parent: Scope | undefined): Scope => ({ variables: new Map(), parent });

export interface Interpreter {
  /** The run the interpreter records choices and assumptions in. */
  readonly current: {
    run: Run;
    /**
     * Whether some inputs take the run's path and make a condition true.
     * Without it, both sides of every test are taken.
     */
    feasible?: (run: Run, condition: string) => Effect.Effect<boolean>;
  };
  /**
   * Take one side of a condition of the inputs. A side no inputs reach on
   * this path is not taken, and makes no path.
   */
  readonly branch: (condition: string) => Eval<boolean>;
  readonly evaluate: (node: Node, env: Env) => Eval<V>;
  readonly call: (fn: V, args: ReadonlyArray<V>, site: Site) => Eval<V>;
  /** The result of `yield*` on a value: an effect's result, or a request context's value. */
  readonly settle: (value: V, site: Site) => Eval<V>;
  readonly member: (value: V, key: string, site: Site) => Eval<V>;
  /** Whether a value is truthy on this path. A symbolic value splits the path. */
  readonly decide: (value: V, site: Site) => Eval<boolean>;
  /** The formula for "this value is truthy", without splitting the path. */
  readonly truth: (value: V, site: Site) => Eval<boolean | string>;
  readonly moduleEnv: (module: Module) => Env;
  /** A value used as an id: what an opaque function returned is the text it gives. */
  readonly id: (value: V) => V;
  /** What the interpreter reads, by name: the tests hold a case for each. */
  readonly surface: {
    readonly library: ReadonlyArray<string>;
    readonly strings: ReadonlyArray<string>;
    readonly arrays: ReadonlyArray<string>;
  };
  /** What a model explorer plugs in. */
  readonly hooks: Hooks;
}

export interface Hooks {
  /**
   * What `yield*` on a class gives, for the classes the caller knows: an
   * aggregate's client, a saga's, an external system's.
   */
  service: ((host: unknown, site: Site) => V | undefined) | undefined;
  /** What calling a function the prover does not read gives, for the functions the caller knows. */
  host: ((value: unknown, args: ReadonlyArray<V>, site: Site) => Eval<V> | undefined) | undefined;
  /** The request contexts provided around the code being run, by tag. */
  readonly provided: Map<unknown, V>;
  /**
   * The time the command being decided is handled at. It is what the clock
   * reads inside `decide`, and there is none anywhere else.
   */
  now: V | undefined;
  /** Models of library functions the caller adds, by `module:path`. */
  readonly models: Map<string, Library.Model>;
}

/** A value the prover knows, as the text JavaScript makes of it in a string. */
const shown = (v: V): string =>
  v._tag === "Null"
    ? "null"
    : v._tag === "Undef"
      ? "undefined"
      : String((v as { readonly value?: unknown }).value);

/** The syntax that only says what type an expression has. */
const WRAPPERS = new Set([
  "ParenthesizedExpression",
  "TSAsExpression",
  "TSSatisfiesExpression",
  "TSNonNullExpression",
  "TSTypeAssertion",
]);

/** `pipe`, as a function: what it is given first is what the steps work on. */
const PIPES = new Set(["effect/pipe:", "effect/Function:pipe"]);

/** The operators that only compute: none tests its operand, and none can fail. */
const COMPUTES = new Set(["+", "-", "*", "===", "!==", "<", "<=", ">", ">="]);

/**
 * Whether an expression only computes a value: a literal, a name, a property
 * of one, and sums, products and comparisons of those. Evaluating it tests
 * nothing, calls nothing and writes nothing, so it may be evaluated on a path
 * the code would not evaluate it on.
 */
const isPlain = (node: Node): boolean =>
  node.type === "Literal" ||
  node.type === "Identifier" ||
  (node.type === "TemplateLiteral" && (node.expressions as ReadonlyArray<Node>).every(isPlain)) ||
  (node.type === "UnaryExpression" &&
    ["-", "+", "!"].includes(node.operator) &&
    isPlain(node.argument)) ||
  (node.type === "BinaryExpression" &&
    COMPUTES.has(node.operator) &&
    isPlain(node.left) &&
    isPlain(node.right)) ||
  (node.type === "MemberExpression" && !node.computed && !node.optional && isPlain(node.object)) ||
  (WRAPPERS.has(node.type) && isPlain(node.expression));

/** What a chain of `?.` gives once a link of it is `null` or `undefined`: the rest of it is not run. */
const SHORT: V = { _tag: "Undef" };

/** What the code did with a value, where the value is what an opaque function returned. */
const inside = (what: string, ...values: ReadonlyArray<V | undefined>): string | undefined => {
  const applied = values.find((value) => value?._tag === "Applied");
  return applied?._tag === "Applied"
    ? `${what} what ${applied.name} returned, which the prover does not look inside: ${applied.name} ${applied.why}`
    : undefined;
};

/** The library functions that keep a value without looking at it: what they are given stays as it is. */
const PASSES: ReadonlySet<string> = new Set([
  "effect/Effect:succeed",
  "effect/Option:some",
  "effect/Result:succeed",
  "effect/Result:fail",
  "effect/Array:of",
  "effect/Array:make",
]);

/**
 * The functions of Node's the prover takes to give the same result for the
 * same arguments. It reads none of them, and a hash is not something a rule
 * should depend on the inside of.
 */
const PURE: ReadonlySet<string> = new Set([
  "node:crypto:createHash",
  "node:crypto:createHmac",
  "node:crypto:hash",
]);

/** Leaves the `switch` or the loop it is in. */
const BREAK: V = { _tag: "Opaque", what: "break" };
/** Goes on to the next turn of the loop it is in. */
const CONTINUE: V = { _tag: "Opaque", what: "continue" };

/** The most turns a loop takes before the prover stops reading it. */
const MAX_TURNS = 10_000;

/** What `typeof` gives, for the values it is known of. */
const kindOf = (v: V): string | undefined => {
  switch (v._tag) {
    case "Num":
      return "number";
    case "Big":
      return "bigint";
    case "Str":
      return "string";
    case "Bool":
      return "boolean";
    case "Undef":
      return "undefined";
    case "Null":
    case "Obj":
    case "Arr":
    case "List":
    case "Time":
    case "Stream":
      return "object";
    case "Fn":
    case "Native":
      return "function";
    case "Term":
      return v.big
        ? "bigint"
        : v.term.sort === "String"
          ? "string"
          : v.term.sort === "Bool"
            ? "boolean"
            : "number";
    default:
      return undefined;
  }
};

/**
 * Runs the TypeScript of `decide`, `evolve` and the invariants on symbolic
 * values. It follows calls into the code the model is written in, uses a
 * model for each library function it knows, and stops with `NotTranslated`
 * at anything else.
 */
export const make = (loader: Loader, run: Run): Interpreter => {
  const current: Interpreter["current"] = { run };

  const branch: Interpreter["branch"] = (condition) =>
    Effect.suspend(() => {
      const run = current.run;
      const known = run.sideOf(condition);
      if (known !== undefined) return Effect.succeed(known);
      const feasible = current.feasible;
      if (!feasible) return Effect.succeed(run.branch(condition));
      return feasible(run, condition).pipe(
        Effect.flatMap((holds) =>
          holds ? feasible(run, Smt.not(condition)) : Effect.succeed(undefined),
        ),
        // It can hold and it can fail: two paths. Otherwise the one side that can occur.
        Effect.map((fails) =>
          run.branch(condition, fails === undefined ? false : fails ? undefined : true),
        ),
      );
    });
  const hooks: Hooks = {
    service: undefined,
    host: undefined,
    provided: new Map(),
    now: undefined,
    models: new Map(),
  };
  const tops = new Map<string, V>();
  const roots = new Map<Module, Env>();
  /**
   * The calls being run, innermost last. `0` stands for a file's own
   * constants, which belong to no call.
   */
  const frames: Array<number> = [];
  let calls = 0;
  /** The call that made each array and object the code wrote. */
  const makers = new WeakMap<object, number>();

  /** An array or object the code wrote, remembered as the running call's. */
  const made = <A extends V>(value: A): A => {
    const frame = frames[frames.length - 1];
    if (frame !== undefined && frame !== 0) makers.set(value, frame);
    return value;
  };

  /**
   * Whether the code may change a value in place: it wrote the value itself,
   * in a call that has not returned. Anything else was given to it, and code
   * that changes what it is given is not a function of its inputs.
   */
  const mine = (value: V): boolean => {
    const frame = makers.get(value);
    return frame !== undefined && frames.includes(frame);
  };

  /** What an opaque function returned, as the text it is: an input the real function decides. */
  const textOf = (applied: V & { readonly _tag: "Applied" }): V => ({
    _tag: "Term",
    term: current.run.observe(applied, "as text", "String", (value) =>
      typeof value === "string" ? value : undefined,
    ),
  });

  /**
   * What an opaque function returned, next to a value the solver has: the
   * result is taken to be of the same kind, text next to text and a number
   * next to a number. A result of another kind is equal to nothing, which is
   * one of the values the input can take.
   */
  const alike = (value: V, other: V): V => {
    if (value._tag !== "Applied") return value;
    if (textual(other)) return textOf(value);
    if (other._tag === "Bool" || (other._tag === "Term" && other.term.sort === "Bool"))
      return {
        _tag: "Term",
        term: current.run.observe(value, "as a boolean", "Bool", (real) =>
          typeof real === "boolean" ? real : undefined,
        ),
      };
    // A number, which may be any: nothing says the function gives a whole one.
    return Value.isBig(other) || !Compare.numeric(other)
      ? value
      : {
          _tag: "Term",
          term: current.run.observe(value, "as a number", "Real", (real) =>
            typeof real === "number" && Number.isFinite(real) ? real : undefined,
          ),
        };
  };

  /** `a === b`, where either may be what an opaque function returned. */
  const sameAs = (a: V, b: V): Compare.Known => same(alike(a, b), alike(b, a));

  /** What an opaque function returned, as the `Option` it is: a `Some` of what it holds, or nothing. */
  const optionOf = (applied: V & { readonly _tag: "Applied" }): Eval<V> => {
    const some = current.run.observe(applied, "is a Some", "Bool", (value) =>
      Option.isOption(value) ? Option.isSome(value) : undefined,
    );
    return branch(some.text).pipe(
      Effect.map((is) =>
        is
          ? Value.some(
              Value.derived(applied, "the value of", (value) =>
                Option.isOption(value) && Option.isSome(value) ? value.value : undefined,
              ),
            )
          : Value.none,
      ),
    );
  };

  /**
   * What an opaque function returned, as the list it is: a number of items
   * the run chooses, each a value the prover does not look inside. A list
   * longer than `MAX_ITEMS` is not tried, and the run says so.
   */
  const listOf = (applied: V & { readonly _tag: "Applied" }): V => {
    const run = current.run;
    const key = `list ${applied.key}`;
    const known = run.lists.get(key);
    if (known) return known;
    const length = run.observe(applied, "has a number of items", "Int", (value) =>
      Array.isArray(value) ? value.length : undefined,
    );
    run.bounds.set(`what ${applied.name} returned`, Symbolic.MAX_ITEMS);
    const count = run.choose(Symbolic.MAX_ITEMS + 1);
    run.assume(`(= ${length.text} ${count})`);
    const list: V = {
      _tag: "Arr",
      items: Array.from({ length: count }, (_, index) =>
        Value.derived(applied, `item ${index} of`, (value) =>
          Array.isArray(value) ? (value as ReadonlyArray<unknown>)[index] : undefined,
        ),
      ),
    };
    run.lists.set(key, list);
    return list;
  };

  /**
   * What a library function is given, where it was given what an opaque
   * function returned and has no reading of that: the result as what the
   * function works on, an `Option` for `effect/Option` and a list for
   * `effect/Array`. `undefined` when there is nothing to take another way.
   */
  const reshaped = (fn: V, args: ReadonlyArray<V>): Eval<ReadonlyArray<V>> | undefined => {
    const [self, ...rest] = args;
    if (self?._tag !== "Applied") return undefined;
    const family =
      fn._tag === "Lib"
        ? fn.module.replace(/^effect\//, "")
        : fn._tag === "Native"
          ? fn.name.slice(0, Math.max(0, fn.name.indexOf(".")))
          : "";
    return family === "Option"
      ? optionOf(self).pipe(Effect.map((option) => [option, ...rest]))
      : family === "Array"
        ? Effect.succeed([listOf(self), ...rest])
        : undefined;
  };

  /** A list with its items, and an object with every field chosen, on this path. */
  const forced = (value: V): V =>
    value._tag === "List"
      ? Symbolic.force(value, current.run)
      : Symbolic.settle(value, current.run);

  const moduleEnv = (module: Module): Env => {
    const known = roots.get(module);
    if (known) return known;
    const env: Env = { scope: child(undefined), module };
    roots.set(module, env);
    return env;
  };

  const fail = (site: Site, reason: string) => Effect.fail(Value.notTranslated(site, reason));

  /**
   * Stop at code that reaches outside what the prover reads. A function that
   * does is not taken to be pure, so it never stands as an opaque one.
   */
  const reaches = (site: Site, reason: string) =>
    Effect.fail(Value.notTranslated(site, reason, true));

  const loadAt = (file: string, site: Site): Eval<Module> =>
    loader
      .load(file)
      .pipe(Effect.mapError((error) => Value.notTranslated(site, error.message, true)));

  /** A function a file exports, with the real one: what a call gives where the body is not read. */
  const exported = (value: V, module: Module, name: string): V => {
    const real = module.exports[name];
    return value._tag === "Fn" && typeof real === "function"
      ? {
          ...value,
          real: { name, call: real as (...args: ReadonlyArray<unknown>) => unknown },
        }
      : value;
  };

  /** A top-level name of a module: a declaration, an import, or a runtime export. */
  const top: (module: Module, name: string, site: Site) => Eval<V | undefined> = Effect.fnUntraced(
    function* (module: Module, name: string, site: Site) {
      const key = `${module.path}#${name}`;
      const known = tops.get(key);
      if (known) return known;
      const resolved = yield* resolveTop(module, name, site);
      if (resolved) tops.set(key, resolved);
      return resolved;
    },
  );

  const resolveTop: (module: Module, name: string, site: Site) => Eval<V | undefined> =
    Effect.fnUntraced(function* (module: Module, name: string, site: Site) {
      const declaration = module.declarations.get(name);
      // A function the caller named as opaque is not read, wherever it is written.
      const given =
        declaration && name in module.exports
          ? loader.opaque(module.exports[name], name)
          : undefined;
      if (given) return named(given);
      if (declaration?._tag === "Const") {
        if (!declaration.init) return Value.undef;
        // A constant the prover cannot build from its source, such as a schema, is the value Node loaded.
        frames.push(0);
        return yield* evaluate(declaration.init, moduleEnv(module)).pipe(
          Effect.ensuring(Effect.sync(() => void frames.pop())),
          Effect.map((made) =>
            made._tag === "Opaque" && name in module.exports
              ? fromHost(module.exports[name], name)
              : exported(made, module, name),
          ),
          Effect.catchTag("NotTranslated", (error) =>
            name in module.exports
              ? Effect.succeed(fromHost(module.exports[name], name))
              : Effect.fail(error),
          ),
        );
      }
      if (declaration?._tag === "Pattern") {
        // `const { a } = made`: what the pattern gives the name, of what the file made.
        frames.push(0);
        const env = moduleEnv(module);
        const bound = child(env.scope);
        return yield* evaluate(declaration.init, env).pipe(
          Effect.flatMap((made) =>
            bind(declaration.pattern, made, bound, { ...env, scope: bound }),
          ),
          Effect.ensuring(Effect.sync(() => void frames.pop())),
          Effect.map(() => bound.variables.get(name) ?? Value.undef),
          Effect.catchTag("NotTranslated", (error) =>
            name in module.exports
              ? Effect.succeed(fromHost(module.exports[name], name))
              : Effect.fail(error),
          ),
        );
      }
      if (declaration?._tag === "Function") {
        return exported(
          { _tag: "Fn", node: declaration.node, env: moduleEnv(module), effectful: false },
          module,
          name,
        );
      }
      if (declaration?._tag === "Class") {
        if (name in module.exports) return fromHost(module.exports[name], name);
        // A class a file keeps to itself is read where it only extends one of `effect/Data`'s.
        const node = declaration.node;
        const body: ReadonlyArray<Node> = node.body?.body ?? [];
        if (node.superClass && body.length === 0) {
          const base = yield* evaluate(node.superClass, moduleEnv(module));
          const made = library.subclass(base, name);
          if (made) return made;
        }
        return yield* reaches(site, `${name} is a class that its file does not export`);
      }
      const imported = module.imports.get(name);
      if (imported) {
        // A package the prover has no models for is read like the model's own files.
        const read =
          module.resolved.has(imported.specifier) || library.known(imported.specifier)
            ? undefined
            : yield* loader.resolve(module, imported.specifier).pipe(
                Effect.flatMap((file) =>
                  file === undefined ? Effect.succeed(undefined) : loader.load(file),
                ),
                Effect.catchTag("LoadError", () => Effect.succeed(undefined)),
              );
        const file = module.resolved.get(imported.specifier) ?? read?.path;
        if (file === undefined) {
          const namespace = yield* loader.runtime(module, imported.specifier);
          const host = imported.imported === "*" ? namespace : namespace?.[imported.imported];
          const given = loader.opaque(host, imported.imported);
          if (given) return named(given);
          const at = host === undefined ? {} : { host };
          // A package: `import { Effect } from "effect"` is the module `effect/Effect`.
          return imported.imported === "*"
            ? ({ _tag: "Lib", module: imported.specifier, path: [], ...at } as V)
            : imported.specifier === "effect"
              ? ({ _tag: "Lib", module: `effect/${imported.imported}`, path: [], ...at } as V)
              : ({
                  _tag: "Lib",
                  module: imported.specifier,
                  path: [imported.imported],
                  ...at,
                } as V);
        }
        const other = yield* loadAt(file, site);
        if (imported.imported === "*") return { _tag: "Namespace", module: other } as V;
        const found = yield* top(other, imported.imported, site);
        if (found) return found;
        return imported.imported in other.exports
          ? fromHost(other.exports[imported.imported], imported.imported)
          : yield* reaches(site, `${name} is not exported by ${file}`);
      }
      for (const specifier of module.stars) {
        const file = module.resolved.get(specifier);
        if (file === undefined) continue;
        const found = yield* top(yield* loadAt(file, site), name, site);
        if (found) return found;
      }
      return undefined;
    });

  /** A call of a function the prover does not read: a value it does not look inside. */
  const applied = (fn: OpaqueFunction, args: ReadonlyArray<V>, why: string): V => {
    loader.assume(fn.name);
    return Value.applied(fn.name, fn.call, args, why);
  };

  /** A function the caller named as opaque. */
  const named = (fn: OpaqueFunction): V => ({
    _tag: "Native",
    name: fn.name,
    call: (args) => Effect.succeed(applied(fn, args, "is opaque")),
  });

  const lookup: (name: string, env: Env, site: Site) => Eval<V> = Effect.fnUntraced(function* (
    name: string,
    env: Env,
    site: Site,
  ) {
    for (let scope: Scope | undefined = env.scope; scope; scope = scope.parent) {
      const local = scope.variables.get(name);
      if (local) return local;
    }
    const found = yield* top(env.module, name, site);
    if (found) return found;
    if (name === "undefined") return Value.undef;
    if (name === "Math" || name === "Object") return { _tag: "Lib", module: name, path: [] } as V;
    if (name === "BigInt")
      return {
        _tag: "Native",
        name,
        call: ([value], at) =>
          value?._tag === "Big" || (value?._tag === "Term" && value.big)
            ? Effect.succeed(value)
            : value?._tag === "Num" && Number.isInteger(value.value)
              ? Effect.succeed<V>({ _tag: "Big", value: BigInt(value.value) })
              : value?._tag === "Term" && value.term.sort === "Int"
                ? Effect.succeed<V>({ _tag: "Term", term: value.term, big: true })
                : fail(at, "calls BigInt on a value the prover cannot see as a whole number"),
      } as V;
    return yield* reaches(site, `refers to ${name}, which the prover cannot find`);
  });

  const library = Library.make({
    current,
    branch: (condition) => branch(condition),
    provided: hooks.provided,
    now: () => hooks.now,
    extra: hooks.models,
    call: (fn, args, site) => call(fn, args, site),
    settle: (value, site) => settle(value, site),
    decide: (value, site) => decide(value, site),
    truth: (value, site) => truthOf(value, site),
    arithmetic: (operator, a, b, site) => arithmetic(operator, a, b, site),
    member: (value, key, site) => member(value, key, site),
    kind: (value) => kindOf(value),
    equal: (a, b, site) => {
      const equal = sameAs(a, b);
      return equal === undefined
        ? fail(site, inside("compares", a, b) ?? "compares values the prover does not model")
        : Effect.succeed(fromTruth(equal));
    },
    force: (value) => forced(value),
    array: (name, items, fn, initial, site) => arrayMethods[name]!(items, fn, initial, site),
  });

  /** The array methods that take a function. The items are known; what the function gives may not be. */
  const arrayMethods: Record<
    string,
    (items: ReadonlyArray<V>, fn: V, initial: V | undefined, at: Site) => Eval<V>
  > = {
    find: Effect.fnUntraced(function* (items, fn, _initial, at) {
      for (const item of items) if (yield* decide(yield* call(fn, [item], at), at)) return item;
      return Value.undef;
    }),
    filter: Effect.fnUntraced(function* (items, fn, _initial, at) {
      const kept: Array<V> = [];
      for (const [index, item] of items.entries())
        if (yield* decide(yield* call(fn, [item, Value.num(index)], at), at)) kept.push(item);
      return { _tag: "Arr", items: kept } as V;
    }),
    map: Effect.fnUntraced(function* (items, fn, _initial, at) {
      const made: Array<V> = [];
      for (const [index, item] of items.entries())
        made.push(yield* call(fn, [item, Value.num(index)], at));
      return { _tag: "Arr", items: made } as V;
    }),
    flatMap: Effect.fnUntraced(function* (items, fn, _initial, at) {
      const made: Array<V> = [];
      for (const [index, item] of items.entries()) {
        const given = yield* call(fn, [item, Value.num(index)], at);
        if (given._tag === "Arr") made.push(...given.items);
        else made.push(given);
      }
      return { _tag: "Arr", items: made } as V;
    }),
    // `every` and `some` give one formula over all the items, so a rule over a list does not split the path.
    every: Effect.fnUntraced(function* (items, fn, _initial, at) {
      const parts: Array<string> = [];
      for (const [index, item] of items.entries()) {
        const t = yield* truthOf(yield* call(fn, [item, Value.num(index)], at), at);
        if (t === false || t === "false") return Value.bool(false);
        if (t !== true && t !== "true") parts.push(t);
      }
      return fromTruth(
        parts.length === 0 ? true : parts.length === 1 ? parts[0]! : `(and ${parts.join(" ")})`,
      );
    }),
    some: Effect.fnUntraced(function* (items, fn, _initial, at) {
      const parts: Array<string> = [];
      for (const [index, item] of items.entries()) {
        const t = yield* truthOf(yield* call(fn, [item, Value.num(index)], at), at);
        if (t === true || t === "true") return Value.bool(true);
        if (t !== false && t !== "false") parts.push(t);
      }
      return fromTruth(
        parts.length === 0 ? false : parts.length === 1 ? parts[0]! : `(or ${parts.join(" ")})`,
      );
    }),
    findIndex: Effect.fnUntraced(function* (items, fn, _initial, at) {
      for (const [index, item] of items.entries())
        if (yield* decide(yield* call(fn, [item, Value.num(index)], at), at))
          return Value.num(index);
      return Value.num(-1);
    }),
    findLast: Effect.fnUntraced(function* (items, fn, _initial, at) {
      for (let index = items.length - 1; index >= 0; index--)
        if (yield* decide(yield* call(fn, [items[index]!, Value.num(index)], at), at))
          return items[index]!;
      return Value.undef;
    }),
    findLastIndex: Effect.fnUntraced(function* (items, fn, _initial, at) {
      for (let index = items.length - 1; index >= 0; index--)
        if (yield* decide(yield* call(fn, [items[index]!, Value.num(index)], at), at))
          return Value.num(index);
      return Value.num(-1);
    }),
    forEach: Effect.fnUntraced(function* (items, fn, _initial, at) {
      for (const [index, item] of [...items].entries())
        yield* call(fn, [item, Value.num(index)], at);
      return Value.undef;
    }),
    reduce: Effect.fnUntraced(function* (items, fn, initial, at) {
      if (initial === undefined && items.length === 0)
        return yield* fail(at, "reduces an empty array with no first value");
      let total = initial ?? items[0]!;
      for (const [index, item] of items.entries()) {
        if (initial === undefined && index === 0) continue;
        total = yield* call(fn, [total, item, Value.num(index)], at);
      }
      return total;
    }),
  };

  /** The array methods that take values. */
  const arrayOwn: Record<
    string,
    (self: V & { readonly _tag: "Arr" }, args: ReadonlyArray<V>, at: Site) => Eval<V>
  > = {
    includes: (self, [wanted], at) => {
      const parts: Array<string> = [];
      for (const item of self.items) {
        const equal = sameAs(item, wanted ?? Value.undef);
        if (equal === undefined)
          return fail(
            at,
            inside("looks for", item, wanted) ?? "looks for a value the prover does not model",
          );
        if (equal === true) return Effect.succeed(Value.bool(true));
        if (equal !== false) parts.push(equal);
      }
      return Effect.succeed(
        fromTruth(
          parts.length === 0 ? false : parts.length === 1 ? parts[0]! : `(or ${parts.join(" ")})`,
        ),
      );
    },
    concat: (self, args, at) => {
      const items = [...self.items];
      for (const argument of args.map(forced)) {
        if (argument._tag === "Arr") items.push(...argument.items);
        else if (argument._tag === "Opaque") return fail(at, `joins ${argument.what} to an array`);
        else items.push(argument);
      }
      return Effect.succeed(made<V>({ _tag: "Arr", items }));
    },
    slice: (self, [from, to], at) =>
      (from === undefined || from._tag === "Num" || from._tag === "Undef") &&
      (to === undefined || to._tag === "Num" || to._tag === "Undef")
        ? Effect.succeed(
            made<V>({
              _tag: "Arr",
              items: self.items.slice(
                from?._tag === "Num" ? from.value : undefined,
                to?._tag === "Num" ? to.value : undefined,
              ),
            }),
          )
        : fail(at, "slices an array at a place the prover cannot see"),
    at: (self, [index], at) =>
      index?._tag === "Num"
        ? Effect.succeed(self.items.at(index.value) ?? Value.undef)
        : fail(at, "reads an array at a place the prover cannot see"),
    entries: (self) =>
      Effect.succeed<V>({
        _tag: "Arr",
        items: self.items.map((item, index): V => ({
          _tag: "Arr",
          items: [Value.num(index), item],
        })),
      }),
    keys: (self) =>
      Effect.succeed<V>({ _tag: "Arr", items: self.items.map((_, index) => Value.num(index)) }),
    values: (self) => Effect.succeed<V>({ _tag: "Arr", items: [...self.items] }),
    join: Effect.fnUntraced(function* (self, [separator], at) {
      let out: V = Value.str("");
      for (const [index, item] of self.items.entries()) {
        if (index > 0)
          out = yield* arithmetic(
            "+",
            out,
            separator && separator._tag !== "Undef" ? separator : Value.str(","),
            at,
          );
        // An item that is nothing is written as nothing.
        if (item._tag !== "Null" && item._tag !== "Undef")
          out = yield* arithmetic("+", out, item, at);
      }
      return out;
    }),
    indexOf: Effect.fnUntraced(function* (self, [wanted], at) {
      for (const [index, item] of self.items.entries()) {
        const equal = sameAs(item, wanted ?? Value.undef);
        if (equal === undefined)
          return yield* fail(
            at,
            inside("looks for", item, wanted) ?? "looks for a value the prover does not model",
          );
        if (typeof equal === "boolean" ? equal : yield* branch(equal)) return Value.num(index);
      }
      return Value.num(-1);
    }),
    flat: (self, [depth], at) =>
      depth === undefined || depth._tag === "Undef" || (depth._tag === "Num" && depth.value === 1)
        ? Effect.succeed(
            made<V>({
              _tag: "Arr",
              items: self.items.flatMap((item) => {
                const inner = forced(item);
                return inner._tag === "Arr" ? inner.items : [item];
              }),
            }),
          )
        : fail(at, "flattens an array to a depth the prover does not read"),
    toReversed: (self) =>
      Effect.succeed(made<V>({ _tag: "Arr", items: [...self.items].reverse() })),
    push: (self, args, at) => {
      if (!mine(self)) return reaches(at, "pushes onto an array it was given, which changes it");
      (self.items as Array<V>).push(...args);
      return Effect.succeed(Value.num(self.items.length));
    },
  };

  /** `value.pipe(f, g)`: each function applied to what the one before gave. */
  const piping = (value: V): V => ({
    _tag: "Native",
    name: "pipe",
    call: Effect.fnUntraced(function* (steps: ReadonlyArray<V>, at: Site) {
      let piped: V = value;
      for (const step of steps) piped = yield* call(step, [piped], at);
      return piped;
    }),
  });

  const member: Interpreter["member"] = Effect.fnUntraced(function* (
    value: V,
    key: string,
    site: Site,
  ) {
    switch (value._tag) {
      case "Obj": {
        const waiting = library.waitMember(value, key);
        if (waiting) return waiting;
        // A duration, a decimal, a hash set and a hash map are read through their modules, never by what they are made of.
        if (value.brand && Brands.SEALED.has(value.brand.kind) && key !== "pipe")
          return yield* fail(site, `reads .${key} of a ${value.brand.kind}`);
        // An error's message and stack are the runtime's, not fields the code gave it.
        if (
          value.brand?.kind === "Data" &&
          !Object.hasOwn(value.fields, key) &&
          ["message", "stack", "name", "cause"].includes(key)
        )
          return yield* fail(site, `reads .${key} of an error, which the prover does not model`);
        // `option.pipe(Option.map(f))`: each function applied to what the one before gave.
        if (
          key === "pipe" &&
          value.brand &&
          Brands.PIPED.has(value.brand.kind) &&
          !value.fields.pipe
        )
          return piping(value);
        const held = value.fields[key];
        // A field the run has yet to choose is chosen now: this one, and no other.
        return (
          (held?._tag === "Pending" ? Symbolic.resolve(held, current.run) : held) ?? Value.undef
        );
      }
      case "List":
        // The first and the last part of a split string are known, however many parts there are.
        if (value.split && key === "0") return value.split.first;
        if (value.split && key === "at") {
          const { first, last } = value.split;
          return {
            _tag: "Native",
            name: "at",
            call: Effect.fnUntraced(function* (args: ReadonlyArray<V>, at: Site) {
              const index = args[0];
              if (index === undefined || (index._tag === "Num" && index.value === 0)) return first;
              if (index._tag === "Num" && index.value === -1 && last) return last;
              return yield* call(yield* member(forced(value), "at", at), args, at);
            }),
          };
        }
        return yield* member(forced(value), key, site);
      case "Arr":
        if (key === "length") return Value.num(value.items.length);
        if (Object.hasOwn(arrayOwn, key)) {
          const method = arrayOwn[key]!;
          return {
            _tag: "Native",
            name: key,
            call: (args: ReadonlyArray<V>, at: Site) => method(value, args, at),
          };
        }
        if (Object.hasOwn(arrayMethods, key)) {
          const method = arrayMethods[key]!;
          return {
            _tag: "Native",
            name: key,
            call: Effect.fnUntraced(function* (args: ReadonlyArray<V>, at: Site) {
              const fn = args[0];
              if (!fn) return yield* fail(at, `calls ${key} without a function`);
              return yield* method(value.items, fn, args[1], at);
            }),
          };
        }
        return /^\d+$/.test(key)
          ? (value.items[Number(key)] ?? Value.undef)
          : yield* fail(site, `reads .${key} of an array`);
      case "Str":
        return key === "length"
          ? Value.num(value.value.length)
          : (library.stringMember(value, key) ?? (yield* fail(site, `reads .${key} of a string`)));
      case "Term":
        return value.term.sort === "String" && key === "length"
          ? Value.term("Int", `(str.len ${value.term.text})`)
          : ((value.term.sort === "String" ? library.stringMember(value, key) : undefined) ??
              (yield* fail(site, `reads .${key} of a ${value.term.sort.toLowerCase()}`)));
      case "Optic":
        return (
          library.opticMember(value, key) ??
          (yield* fail(site, `uses an optic's .${key}, which the prover has no model for`))
        );
      case "Lib": {
        const { host, ...lib } = value;
        const held =
          (typeof host === "object" || typeof host === "function") && host !== null
            ? (host as Readonly<Record<string, unknown>>)[key]
            : undefined;
        const next: V & { readonly _tag: "Lib" } = {
          ...lib,
          path: [...value.path, key],
          ...(held === undefined ? {} : { host: held }),
        };
        return library.valueOf(next, site) ?? next;
      }
      case "Namespace": {
        // A namespace has what its file exports, and nothing else the file declares.
        if (!(key in value.module.exports)) return Value.undef;
        const found = yield* top(value.module, key, site);
        return found ?? fromHost(value.module.exports[key], key);
      }
      case "Host":
        // `Started.make(fields)`: the event, as `new Started(fields)` builds it.
        if (key === "make" && isDomainClass(value.value))
          return {
            _tag: "Native",
            name: `${value.name}.make`,
            call: (args: ReadonlyArray<V>, at: Site) => construct(value, args, at),
          };
        // `Receipt.make(fields)`, for a class of `effect/Schema`: the instance `new` makes.
        if (key === "make" && isDataClass(value.value))
          return {
            _tag: "Native",
            name: `${value.name}.make`,
            call: (args: ReadonlyArray<V>, at: Site) => constructData(value, args, at),
          };
        // `AccountId.make(text)`: the text, when the schema allows it.
        if (key === "make" && Symbolic.typeOf(value.value) !== undefined) {
          const ast = Symbolic.typeOf(value.value)!;
          return {
            _tag: "Native",
            name: `${value.name}.make`,
            call: ([made]) =>
              made && Symbolic.assumeFits(made, ast, current.run)
                ? Effect.succeed(made)
                : Effect.fail(new Value.Infeasible()),
          };
        }
        return (
          library.unionMember(value.value, key, value.name) ??
          fromHost((value.value as Record<string, unknown>)[key], `${value.name}.${key}`)
        );
      case "Time":
      case "Effect":
      case "Stream":
        // `effect.pipe(f, g)`: each function applied to what the one before gave.
        if (key === "pipe") return piping(value);
        return yield* fail(
          site,
          `reads .${key} of ${value._tag === "Time" ? "a time" : value._tag === "Effect" ? "an effect" : "a stream"}`,
        );
      case "Opaque":
        return yield* fail(site, `reads .${key} of ${value.what}, which the prover does not model`);
      case "Applied":
        // `result.pipe(Option.map(f))`: each function applied to what the one before gave.
        if (key === "pipe") return piping(value);
        // Read as only an array is read: the result is a list of what the function gives.
        // Its length, and what a string has too, do not say which it is.
        return (Object.hasOwn(arrayOwn, key) || Object.hasOwn(arrayMethods, key)) &&
          !["includes", "indexOf", "slice", "concat", "at"].includes(key)
          ? yield* member(listOf(value), key, site)
          : yield* fail(site, inside(`reads .${key} of`, value)!);
      default:
        return yield* fail(
          site,
          `reads .${key} of ${value._tag === "Null" ? "null" : value._tag === "Undef" ? "undefined" : `a ${value._tag}`}`,
        );
    }
  });

  /** A field of an input, read as the code reads it: the run chooses what it holds. */
  const chosen = (value: V): V =>
    value._tag === "Pending" ? (Symbolic.resolve(value, current.run) ?? Value.undef) : value;

  /**
   * What an expression gives, with a field of an input left as it is: the
   * code that asked says whether it has to be looked at.
   */
  const unread: (node: Node, env: Env) => Eval<V> = Effect.fnUntraced(function* (
    node: Node,
    env: Env,
  ) {
    if (WRAPPERS.has(node.type)) return yield* unread(node.expression, env);
    // A name the field was given: `const note = command.note`.
    if (node.type === "Identifier")
      return yield* lookup(node.name, env, { module: env.module, node });
    if (node.type !== "MemberExpression" || node.computed || node.optional)
      return yield* evaluate(node, env);
    const object = yield* evaluate(node.object, env);
    if (object === SHORT) return SHORT;
    return yield* unreadMember(object, node.property.name, { module: env.module, node });
  });

  /** A property of a value, with a field of an input left as it is. */
  const unreadMember = (object: V, key: string, site: Site): Eval<V> => {
    const held = object._tag === "Obj" ? object.fields[key] : undefined;
    return held?._tag === "Pending" &&
      object._tag === "Obj" &&
      !(object.brand && Brands.SEALED.has(object.brand.kind)) &&
      !library.waitMember(object, key)
      ? Effect.succeed(held)
      : member(object, key, site);
  };

  /** A value as the solver holds one: a string, a number or a boolean. */
  const scalar = (value: V): Smt.Term | undefined =>
    value._tag === "Term"
      ? value.big || value.quotient
        ? undefined
        : value.term
      : value._tag === "Bool"
        ? Smt.bool(value.value)
        : value._tag === "Num"
          ? Compare.numeric(value)
          : Compare.textual(value);

  /** `value` where `present` holds and `other` where it does not, as one value. */
  const oneOf = (present: Smt.Term, value: V, other: V): V | undefined => {
    const a = scalar(value);
    const b = scalar(other);
    if (!a || !b) return undefined;
    const numbers =
      a.sort !== "Bool" && a.sort !== "String" && b.sort !== "Bool" && b.sort !== "String";
    if (!numbers && a.sort !== b.sort) return undefined;
    const [l, r] = numbers ? Compare.promote(a, b) : [a, b];
    return l.text === r.text
      ? value
      : { _tag: "Term", term: { sort: l.sort, text: `(ite ${present.text} ${l.text} ${r.text})` } };
  };

  /** Whether calling a function only gives a value: no test, no call, nothing written. */
  const givesValue = (fn: V | undefined): fn is V & { readonly _tag: "Fn" } =>
    fn?._tag === "Fn" &&
    !fn.effectful &&
    fn.node.type === "ArrowFunctionExpression" &&
    (fn.node.params as ReadonlyArray<Node>).every((param) => param.type === "Identifier") &&
    fn.node.body.type !== "BlockStatement" &&
    isPlain(fn.node.body);

  /** The function of `effect/Option` a value is, where it is one that only takes a value or a default. */
  const optionReader = (fn: V | undefined): "getOrElse" | "match" | undefined => {
    const name =
      fn?._tag === "Lib" && fn.module === "effect/Option"
        ? fn.path.join(".")
        : fn?._tag === "Native" && fn.given && fn.name.startsWith("Option.")
          ? fn.name.slice("Option.".length)
          : undefined;
    return name === "getOrElse" || name === "match" ? name : undefined;
  };

  const isPipe = (fn: V): boolean =>
    fn._tag === "Lib" && PIPES.has(`${fn.module}:${fn.path.join(".")}`);

  /** What a function gives, or `undefined` where the prover cannot read it. */
  const tried = (run: Eval<V>): Eval<V | undefined> =>
    run.pipe(Effect.catchTag("NotTranslated", () => Effect.succeed(undefined)));

  /**
   * `Option.getOrElse(field, () => other)` and `Option.match(field, cases)`,
   * where the field is an `Option` an input holds that no code looked at, and
   * each case only gives a value: one value, and no path for each case.
   * `step` is the function, and `extra` what it is given after the field.
   * `undefined` for any other call, and the field is then read as it was.
   */
  const defaulted: (
    self: V | undefined,
    step: V | undefined,
    extra: ReadonlyArray<V>,
    site: Site,
  ) => Eval<V | undefined> = Effect.fnUntraced(function* (
    self: V | undefined,
    step: V | undefined,
    extra: ReadonlyArray<V>,
    site: Site,
  ) {
    const reader = optionReader(step);
    if (self?._tag !== "Pending" || !step || !reader) return undefined;
    // `f(field, x)`, or `f(x)` given the field later: what it was given first is kept.
    const given = step._tag === "Native" ? (extra.length === 0 ? step.given : undefined) : extra;
    const [first] = given ?? [];
    const cases =
      reader === "getOrElse"
        ? { onSome: undefined, onNone: first }
        : first?._tag === "Obj"
          ? { onSome: first.fields.onSome, onNone: first.fields.onNone }
          : undefined;
    if (
      given?.length !== 1 ||
      !cases ||
      !givesValue(cases.onNone) ||
      !(cases.onSome === undefined || givesValue(cases.onSome))
    )
      return undefined;
    const held = Symbolic.keep(self, current.run);
    if (!held?.option) return undefined;
    const none = yield* tried(call(cases.onNone, [], site));
    const some = cases.onSome ? yield* tried(call(cases.onSome, [held.value], site)) : held.value;
    return none && some ? oneOf(held.present, some, none) : undefined;
  });

  const truthOf: Interpreter["truth"] = (value, site) => {
    // Whether an opaque function's result is truthy is an input: both ways are tried.
    if (value._tag === "Applied") return Effect.succeed(current.run.truthy(value).text);
    const t = truth(value);
    return t === undefined
      ? fail(site, "tests a value the prover does not model")
      : Effect.succeed(t);
  };

  const decide: Interpreter["decide"] = (value, site) =>
    truthOf(value, site).pipe(
      Effect.flatMap((t) => (typeof t === "boolean" ? Effect.succeed(t) : branch(t))),
    );

  const bind: (pattern: Node, value: V, scope: Scope, env: Env) => Eval<void> = Effect.fnUntraced(
    function* (pattern: Node, value: V, scope: Scope, env: Env) {
      const site: Site = { module: env.module, node: pattern };
      switch (pattern.type) {
        case "Identifier":
          scope.variables.set(pattern.name, value);
          return;
        case "AssignmentPattern":
          if (value._tag === "Applied") return yield* fail(site, inside("defaults", value)!);
          return yield* bind(
            pattern.left,
            chosen(value)._tag === "Undef"
              ? yield* evaluate(pattern.right, { ...env, scope })
              : chosen(value),
            scope,
            env,
          );
        case "ObjectPattern": {
          const taken: Array<string> = [];
          for (const property of pattern.properties as ReadonlyArray<Node>) {
            if (property.type === "RestElement") {
              // `{ a, ...rest }`: what is left of an object whose keys the prover sees.
              if (value._tag !== "Obj")
                return yield* fail(site, "takes the rest of a value the prover cannot see into");
              yield* bind(
                property.argument,
                made(
                  Value.obj(
                    Object.fromEntries(
                      Object.entries(value.fields).filter(([key]) => !taken.includes(key)),
                    ),
                  ),
                ),
                scope,
                env,
              );
              continue;
            }
            if (property.type !== "Property")
              return yield* fail(site, "destructures in a way the prover does not read");
            const named = property.computed
              ? yield* evaluate(property.key, { ...env, scope })
              : Value.str(
                  property.key.type === "Identifier"
                    ? property.key.name
                    : String(property.key.value),
                );
            if (named._tag !== "Str" && named._tag !== "Num")
              return yield* fail(site, "destructures by a key the prover cannot see");
            const key = String(named.value);
            taken.push(key);
            // `const { note } = command`: the name is given the field, and its first use looks at it.
            yield* bind(
              property.value,
              property.value.type === "Identifier" || property.value.type === "AssignmentPattern"
                ? yield* unreadMember(value, key, site)
                : yield* member(value, key, site),
              scope,
              env,
            );
          }
          return;
        }
        case "ArrayPattern": {
          // `const [name] = ref.split("@")`: the first part, however many there are.
          const list =
            value._tag === "List" && value.split && pattern.elements.length === 1
              ? value
              : forced(value);
          for (const [index, element] of (
            pattern.elements as ReadonlyArray<Node | null>
          ).entries()) {
            if (!element) continue;
            if (element.type === "RestElement") {
              if (list._tag !== "Arr")
                return yield* fail(site, "takes the rest of a value that is not a known array");
              yield* bind(
                element.argument,
                made<V>({ _tag: "Arr", items: list.items.slice(index) }),
                scope,
                env,
              );
              continue;
            }
            yield* bind(element, yield* member(list, String(index), site), scope, env);
          }
          return;
        }
        default:
          return yield* fail(site, `binds a ${pattern.type}, which the prover does not read`);
      }
    },
  );

  /** Run a function's body with its parameters bound. */
  const invoke: (fn: V & { readonly _tag: "Fn" }, args: ReadonlyArray<V>) => Eval<V> =
    Effect.fnUntraced(function* (fn: V & { readonly _tag: "Fn" }, args: ReadonlyArray<V>) {
      const scope = child(fn.env.scope);
      const env: Env = { module: fn.env.module, scope };
      for (const [index, parameter] of (fn.node.params as ReadonlyArray<Node>).entries()) {
        if (parameter.type === "RestElement")
          yield* bind(parameter.argument, { _tag: "Arr", items: args.slice(index) }, scope, env);
        else yield* bind(parameter, args[index] ?? Value.undef, scope, env);
      }
      const body: Node = fn.node.body;
      // What the call writes, it may change until it returns.
      const frame = ++calls;
      frames.push(frame);
      const leave = Effect.sync(() => void frames.splice(frames.lastIndexOf(frame), 1));
      if (body.type !== "BlockStatement")
        return yield* evaluate(body, env).pipe(Effect.ensuring(leave));
      const returned = yield* execute(body.body, env).pipe(Effect.ensuring(leave));
      return returned === undefined || returned === BREAK || returned === CONTINUE
        ? Value.undef
        : returned;
    });

  /** Write a property of a value the code made itself. */
  const write = (object: V, key: V, value: V, site: Site): Eval<void> => {
    if (key._tag !== "Str" && key._tag !== "Num")
      return fail(site, "writes a property by a key the prover cannot see");
    if ((object._tag !== "Obj" && object._tag !== "Arr") || !mine(object))
      return reaches(
        site,
        "changes a value it was given: the prover reads code that changes only what it wrote itself",
      );
    if (object._tag === "Obj") (object.fields as Record<string, V>)[String(key.value)] = value;
    else if (typeof key.value === "number" && Number.isInteger(key.value) && key.value >= 0)
      (object.items as Array<V>)[key.value] = value;
    else return fail(site, "writes an array at a place that is not an index");
    return Effect.void;
  };

  /** Give a variable or a property a new value. */
  const assign: (target: Node, value: V, env: Env, site: Site) => Eval<void> = Effect.fnUntraced(
    function* (target: Node, value: V, env: Env, site: Site) {
      if (target.type === "Identifier") {
        for (let scope: Scope | undefined = env.scope; scope; scope = scope.parent) {
          if (scope.variables.has(target.name)) {
            scope.variables.set(target.name, value);
            return;
          }
        }
        return yield* reaches(site, `assigns to ${target.name}, which is not a local variable`);
      }
      if (target.type === "ArrayPattern" || target.type === "ObjectPattern") {
        // `[x, y] = pair`: each name is bound as a declaration binds it, then given to the variable it names.
        const bound = child(env.scope);
        yield* bind(target, value, bound, { ...env, scope: bound });
        for (const [name, part] of bound.variables)
          yield* assign(
            { type: "Identifier", name, start: target.start, end: target.end },
            part,
            env,
            site,
          );
        return;
      }
      if (target.type !== "MemberExpression")
        return yield* reaches(site, "assigns in a way the prover does not read");
      const object = yield* evaluate(target.object, env);
      const key = target.computed
        ? yield* evaluate(target.property, env)
        : Value.str(target.property.name);
      return yield* write(object, key, value, site);
    },
  );

  /** One turn of a loop: `BREAK` to leave it, a value to return, or nothing to go on. */
  const turn = (body: Node, env: Env): Eval<V | undefined> =>
    execute([body], env).pipe(
      Effect.map((returned) => (returned === CONTINUE ? undefined : returned)),
    );

  /** Whether a loop goes on. What an input decides, the prover cannot count the turns of. */
  const goesOn: (test: Node | null, env: Env, site: Site) => Eval<boolean> = Effect.fnUntraced(
    function* (test: Node | null, env: Env, site: Site) {
      if (!test) return true;
      const t = yield* truthOf(yield* evaluate(test, env), site);
      if (t === true || t === "true") return true;
      if (t === false || t === "false") return false;
      return yield* fail(site, "loops a number of times that depends on an input");
    },
  );

  /** What a loop or a spread goes over: what an opaque function returned is a list of what it gives. */
  const iterate = (value: V, site: Site) =>
    library.iterate(value._tag === "Applied" ? listOf(value) : value, site);

  /** A call that has no reading of an opaque function's result is tried again with the result as what it works on. */
  const retaken =
    (fn: V, args: ReadonlyArray<V>, site: Site) =>
    (made: Eval<V>): Eval<V> =>
      args[0]?._tag === "Applied"
        ? made.pipe(
            Effect.catchTag("NotTranslated", (stop) => {
              const again = stop.reaches ? undefined : reshaped(fn, args);
              return again
                ? again.pipe(Effect.flatMap((taken) => call(fn, taken, site)))
                : Effect.fail(stop);
            }),
          )
        : made;

  /**
   * What a function the prover does not read the code of is given: an object
   * the code wrote, or an input holds, with every field chosen. An event or a
   * command is read by its fields, one at a time, and stays as it is.
   */
  const whole = (value: V): V =>
    value._tag === "Obj" && (value.brand === undefined || value.brand.kind === "Data")
      ? Symbolic.settle(value, current.run)
      : value;

  /** Whether a library function only keeps what it is given, and looks at none of it. */
  const passes = (fn: V & { readonly _tag: "Lib" }): boolean =>
    PASSES.has(`${fn.module}:${fn.path.join(".")}`);

  const call: Interpreter["call"] = (fn, args, site) => {
    switch (fn._tag) {
      case "Fn":
        if (fn.node.async) return reaches(site, "calls an async function");
        // A generator's body runs when it is yielded, as an effect does.
        if (fn.node.generator || fn.effectful)
          return Effect.succeed<V>({ _tag: "Effect", run: Effect.suspend(() => invoke(fn, args)) });
        const real = fn.real;
        if (real === undefined) return invoke(fn, args);
        // An exported function whose body the prover cannot read is a value it does not look inside.
        // What the body chose and assumed before it stopped stays: the call is not read on
        // the inputs of this path, and is read on the others.
        return invoke(fn, args).pipe(
          Effect.catchTag("NotTranslated", (stop) =>
            stop.reaches ? Effect.fail(stop) : Effect.succeed(applied(real, args, stop.reason)),
          ),
        );
      case "Native":
        return fn.call(args.map(whole), site).pipe(retaken(fn, args, site));
      case "Lib": {
        // A library function goes over what it is given: every field of it is chosen first.
        if (library.models(fn))
          return library
            .call(fn, passes(fn) ? args : args.map(whole), site)
            .pipe(retaken(fn, args, site));
        const given = loader.opaque(fn.host, fn.path.at(-1));
        if (given) return Effect.succeed(applied(given, args, "is opaque"));
        // A function of Node's that gives the same result for the same arguments.
        return typeof fn.host === "function" && PURE.has(`${fn.module}:${fn.path.join(".")}`)
          ? Effect.succeed(
              applied(
                {
                  name: fn.path.at(-1)!,
                  call: fn.host as (...args: ReadonlyArray<unknown>) => unknown,
                },
                args,
                `is a function of ${fn.module}, which is not code the prover reads`,
              ),
            )
          : library.call(fn, args, site);
      }
      case "Host": {
        const given = loader.opaque(fn.value, fn.name.slice(fn.name.lastIndexOf(".") + 1));
        return given
          ? Effect.succeed(applied(given, args, "is opaque"))
          : (hooks.host?.(fn.value, args, site) ??
              reaches(site, `calls ${fn.name}, which is outside the code the prover reads`));
      }
      case "Opaque":
        return reaches(site, `calls ${fn.what}, which the prover does not model`);
      default:
        return reaches(site, "calls something that is not a function");
    }
  };

  const settle: Interpreter["settle"] = (value, site) => {
    // Inside `Option.gen` and `Result.gen`, an `Option` and a `Result` give what they hold.
    const generated = library.yielded(value);
    if (generated) return generated;
    if (value._tag === "Effect") return value.run;
    if (value._tag === "Obj" && value.brand?.kind === "Rejection")
      return Effect.fail(new Value.Rejected({ rejection: value }));
    // An error of `Data.TaggedError` or `Schema.TaggedError` fails with itself.
    if (value._tag === "Obj" && value.brand?.kind === "Data" && isError(value.brand.cls))
      return Effect.fail(new Value.Rejected({ rejection: value }));
    if (value._tag === "Host") {
      const service = hooks.service?.(value.value, site);
      if (service) return Effect.succeed(service);
    }
    if (value._tag === "Host" && isContextTag(value.value)) {
      const tag = value.value;
      const key = `${current.run.label}${tag.key}`;
      // What the code provides around an effect is what the effect reads, whatever was read outside it.
      const given = hooks.provided.get(tag);
      if (given) {
        if (!current.run.contexts.has(key)) current.run.contexts.set(key, { tag, value: given });
        return Effect.succeed(given);
      }
      const known = current.run.contexts.get(key);
      if (known) return Effect.succeed(known.value);
      const made = Symbolic.symbolic(
        Symbolic.typeOf(tag.schema)!,
        `${current.run.label}${tag.key.slice(tag.key.lastIndexOf("/") + 1)}`,
        current.run,
      );
      current.run.contexts.set(key, { tag, value: made });
      return Effect.succeed(made);
    }
    return reaches(site, "yields a value the prover has no model for");
  };

  /** An instance of a class of `effect/Data` or `effect/Schema`: its fields, and its tag. */
  const constructData = (
    cls: V & { readonly _tag: "Host" },
    args: ReadonlyArray<V>,
    site: Site,
  ): Eval<V> => {
    const [input] = args;
    if (input !== undefined && input._tag !== "Obj" && input._tag !== "Undef")
      return fail(site, `constructs ${cls.name} from a value the prover cannot see into`);
    const fields: Record<string, V> = { ...(input?._tag === "Obj" ? input.fields : {}) };
    const declared = (cls.value as { readonly fields?: unknown }).fields;
    if (Symbolic.typeOf(cls.value) !== undefined && typeof declared === "object" && declared) {
      // A schema's class refuses fields its schema does not allow, and knows its own tag.
      for (const [key, schema] of Object.entries(declared)) {
        const ast = Symbolic.typeOf(schema);
        if (!ast) continue;
        if (key === "_tag" && ast._tag === "Literal" && typeof ast.literal === "string")
          fields._tag = Value.str(ast.literal);
        const field = fields[key];
        if (field && !Symbolic.assumeFits(field, ast, current.run))
          return Effect.fail(new Value.Infeasible());
      }
    } else {
      const tag = tagOfClass(cls.value);
      if (tag !== undefined) fields._tag = Value.str(tag);
    }
    return Effect.succeed(Value.obj(fields, dataBrand(cls.value)));
  };

  const construct: (cls: V, args: ReadonlyArray<V>, site: Site) => Eval<V> = Effect.fnUntraced(
    function* (cls: V, args: ReadonlyArray<V>, site: Site) {
      if (cls._tag === "Host" && !isDomainClass(cls.value) && isDataClass(cls.value))
        return yield* constructData(cls, args, site);
      if (cls._tag === "Native" && library.isClass(cls)) return yield* cls.call(args, site);
      if (cls._tag !== "Host" || !isDomainClass(cls.value))
        return yield* reaches(
          site,
          `constructs ${cls._tag === "Host" ? cls.name : "a class"}, which is not an event, a rejection or a command`,
        );
      const domain = cls.value;
      const [input] = args;
      if (input !== undefined && input._tag !== "Obj" && input._tag !== "Undef")
        return yield* fail(
          site,
          `constructs ${domain.tag} from a value the prover cannot see into`,
        );
      const fields: Record<string, V> = {
        ...(input?._tag === "Obj" ? input.fields : {}),
        _tag: Value.str(domain.tag),
      };
      for (const [key, schema] of Object.entries(domain.fields)) {
        const ast = Symbolic.typeOf(schema);
        const field = fields[key];
        if (ast && field && !Symbolic.assumeFits(field, ast, current.run))
          return yield* new Value.Infeasible();
      }
      const brand: Brand = { kind: domain.kind, cls: domain };
      return Value.obj(fields, brand);
    },
  );

  const arithmetic: (operator: string, a: V, b: V, site: Site) => Eval<V> = (
    operator,
    a,
    b,
    site,
  ) => {
    if (a._tag === "Applied" || b._tag === "Applied") {
      // What an opaque function returned, next to a number or text, is one too.
      const [l, r] = [alike(a, b), alike(b, a)];
      if (l !== a || r !== b) return arithmetic(operator, l, r, site);
    }
    const x = Compare.numeric(a);
    const y = Compare.numeric(b);
    if (x && y) {
      const big = Value.isBig(a);
      if (big !== Value.isBig(b)) return fail(site, `applies ${operator} to a bigint and a number`);
      if (a._tag === "Big" && b._tag === "Big") {
        const l = a.value;
        const r = b.value;
        if ((operator === "/" || operator === "%") && r === 0n)
          return fail(site, "divides a bigint by zero");
        const folded =
          operator === "+"
            ? l + r
            : operator === "-"
              ? l - r
              : operator === "*"
                ? l * r
                : operator === "/"
                  ? l / r
                  : operator === "%"
                    ? l % r
                    : operator === "<"
                      ? l < r
                      : operator === "<="
                        ? l <= r
                        : operator === ">"
                          ? l > r
                          : l >= r;
        return Effect.succeed<V>(
          typeof folded === "bigint" ? { _tag: "Big", value: folded } : Value.bool(folded),
        );
      }
      if (a._tag === "Num" && b._tag === "Num") {
        const l = a.value;
        const r = b.value;
        const folded =
          operator === "+"
            ? l + r
            : operator === "-"
              ? l - r
              : operator === "*"
                ? l * r
                : operator === "/"
                  ? l / r
                  : operator === "%"
                    ? l % r
                    : operator === "<"
                      ? l < r
                      : operator === "<="
                        ? l <= r
                        : operator === ">"
                          ? l > r
                          : l >= r;
        return Effect.succeed(typeof folded === "number" ? Value.num(folded) : Value.bool(folded));
      }
      if (operator === "/" || operator === "%") {
        // A whole number over a whole number the code writes: the solver divides those exactly.
        const divisor = b._tag === "Num" ? b.value : b._tag === "Big" ? Number(b.value) : undefined;
        if (
          divisor === undefined ||
          divisor === 0 ||
          !Number.isSafeInteger(divisor) ||
          x.sort !== "Int"
        )
          return fail(
            site,
            `divides with ${operator} in a way the prover does not translate: it reads a whole number divided by a whole number the code writes`,
          );
        const size = Math.abs(divisor);
        // JavaScript's remainder takes the sign of what is divided; the solver's is never negative.
        if (operator === "%")
          return Effect.succeed<V>({
            _tag: "Term",
            term: {
              sort: "Int",
              text: `(ite (>= ${x.text} 0) (mod ${x.text} ${size}) (- (mod (- ${x.text}) ${size})))`,
            },
            ...(big ? { big: true as const } : {}),
          });
        if (big) {
          // A bigint divides towards zero.
          const towards = `(ite (>= ${x.text} 0) (div ${x.text} ${size}) (- (div (- ${x.text}) ${size})))`;
          return Effect.succeed<V>({
            _tag: "Term",
            term: { sort: "Int", text: divisor > 0 ? towards : `(- ${towards})` },
            big: true,
          });
        }
        return Effect.succeed<V>({
          _tag: "Term",
          term: { sort: "Real", text: `(/ (to_real ${x.text}) ${Smt.real(divisor).text})` },
          quotient: { dividend: x.text, divisor },
        });
      }
      const [l, r] = Compare.promote(x, y);
      // A solver counts exactly, and JavaScript rounds: a tenth and two tenths are not
      // three tenths there. Whole numbers agree, and so does comparing any two numbers.
      if (l.sort === "Real" && (operator === "+" || operator === "-" || operator === "*"))
        return fail(
          site,
          `applies ${operator} to numbers that may not be whole, which JavaScript rounds and the prover does not`,
        );
      // A division is rounded too. It still compares with a whole number as the exact one does.
      if ((isQuotient(a) && y.sort !== "Int") || (isQuotient(b) && x.sort !== "Int"))
        return fail(
          site,
          `compares a division with a number that may not be whole, which JavaScript rounds and the prover does not`,
        );
      const text = `(${operator} ${l.text} ${r.text})`;
      return Effect.succeed<V>(
        operator === "+" || operator === "-" || operator === "*"
          ? { _tag: "Term", term: { sort: l.sort, text }, ...(big ? { big: true as const } : {}) }
          : Value.term("Bool", text),
      );
    }
    if (operator === "+") {
      // A number in a string is its text. The solver knows the text of a
      // number only as the real `String` gives it, one number at a time.
      const written = (v: V) =>
        textual(v) ??
        (v._tag === "Num" || v._tag === "Big" || v._tag === "Bool"
          ? Smt.string(String(v.value))
          : v._tag === "Null" || v._tag === "Undef"
            ? Smt.string(v._tag === "Null" ? "null" : "undefined")
            : v._tag === "Term" && v.term.sort === "Bool"
              ? ({ sort: "String", text: `(ite ${v.term.text} "true" "false")` } as const)
              : v._tag === "Term" && (v.term.sort === "Int" || v.term.sort === "Real")
                ? current.run.apply(
                    `String of ${v.term.sort}`,
                    v.term,
                    "String",
                    String,
                    undefined,
                    true,
                  )
                : undefined);
      const s = written(a);
      const t = written(b);
      if (s && t)
        return Effect.succeed(
          a._tag !== "Term" && b._tag !== "Term"
            ? Value.str(shown(a) + shown(b))
            : Value.term("String", `(str.++ ${s.text} ${t.text})`),
        );
    }
    return fail(
      site,
      inside(`applies ${operator} to`, a, b) ??
        `applies ${operator} to values the prover cannot do arithmetic on`,
    );
  };

  const evaluate: Interpreter["evaluate"] = Effect.fnUntraced(function* (node: Node, env: Env) {
    const site: Site = { module: env.module, node };
    switch (node.type) {
      case "Literal": {
        const value: unknown = node.value;
        if (typeof value === "number") return Value.num(value);
        if (typeof value === "string") return Value.str(value);
        if (typeof value === "boolean") return Value.bool(value);
        if (typeof node.bigint === "string") return { _tag: "Big", value: BigInt(node.bigint) };
        return value === null && node.raw === "null"
          ? Value.nil
          : yield* fail(site, "uses a literal the prover does not read");
      }
      case "TemplateLiteral": {
        let out: V = Value.str("");
        for (const [index, quasi] of (node.quasis as ReadonlyArray<Node>).entries()) {
          out = yield* arithmetic("+", out, Value.str(quasi.value.cooked ?? ""), site);
          const expression = node.expressions[index] as Node | undefined;
          if (expression) out = yield* arithmetic("+", out, yield* evaluate(expression, env), site);
        }
        return out;
      }
      case "Identifier":
        // A name given a field of an input no code looked at: this use looks at it.
        return chosen(yield* lookup(node.name, env, site));
      case "ParenthesizedExpression":
      case "TSAsExpression":
      case "TSSatisfiesExpression":
      case "TSNonNullExpression":
      case "TSTypeAssertion":
      case "TSInstantiationExpression":
        return yield* evaluate(node.expression, env);
      case "ChainExpression": {
        const made = yield* evaluate(node.expression, env);
        return made === SHORT ? Value.undef : made;
      }
      case "ArrowFunctionExpression":
      case "FunctionExpression":
        return { _tag: "Fn", node, env, effectful: false };
      case "MemberExpression": {
        const object = yield* evaluate(node.object, env);
        if (object === SHORT) return SHORT;
        if (node.optional && (object._tag === "Null" || object._tag === "Undef")) return SHORT;
        const key = node.computed
          ? yield* evaluate(node.property, env)
          : Value.str(node.property.name);
        return key._tag === "Str" || key._tag === "Num"
          ? yield* member(object, String(key.value), site)
          : yield* fail(site, "reads a property by a key the prover cannot see");
      }
      case "CallExpression": {
        // `field.pipe(f)`: the field is not looked at before `f` is known.
        const receiver =
          node.callee.type === "MemberExpression" &&
          !node.callee.computed &&
          !node.callee.optional &&
          node.callee.property.name === "pipe"
            ? yield* unread(node.callee.object, env)
            : undefined;
        if (receiver === SHORT) return SHORT;
        const callee =
          receiver === undefined
            ? yield* evaluate(node.callee, env)
            : receiver._tag === "Pending"
              ? receiver
              : yield* member(receiver, "pipe", { module: env.module, node: node.callee });
        if (callee === SHORT) return SHORT;
        if (node.optional && (callee._tag === "Null" || callee._tag === "Undef")) return SHORT;
        // An `Option` an input holds is not looked at before the function it is given to is known.
        const lazily = optionReader(callee) !== undefined || isPipe(callee);
        const args: Array<V> = [];
        for (const [index, argument] of (node.arguments as ReadonlyArray<Node>).entries()) {
          if (argument.type === "SpreadElement") {
            const spread = yield* iterate(yield* evaluate(argument.argument, env), site);
            if (!spread) return yield* fail(site, "spreads arguments that are not a known array");
            args.push(...spread);
          } else
            args.push(
              index === 0 && lazily ? yield* unread(argument, env) : yield* evaluate(argument, env),
            );
        }
        // `field.pipe(f, g)` and `pipe(field, f, g)`: `f` reads the field, and `g` what `f` gave.
        const [self, ...steps] = callee._tag === "Pending" ? [callee, ...args] : args;
        const piped = callee._tag === "Pending" || isPipe(callee);
        const either = piped
          ? yield* defaulted(self, steps[0], [], site)
          : yield* defaulted(self, callee, steps, site);
        if (either && piped) {
          let value = either;
          for (const step of steps.slice(1)) value = yield* call(step, [value], site);
          return value;
        }
        if (either) return either;
        const given = self?._tag === "Pending" ? [chosen(self), ...steps] : args;
        return callee._tag === "Pending"
          ? yield* call(
              yield* member(given[0]!, "pipe", { module: env.module, node: node.callee }),
              steps,
              site,
            )
          : yield* call(callee, given, site);
      }
      case "NewExpression": {
        const cls = yield* evaluate(node.callee, env);
        const args: Array<V> = [];
        for (const argument of node.arguments as ReadonlyArray<Node>)
          args.push(yield* evaluate(argument, env));
        return yield* construct(cls, args, site);
      }
      case "YieldExpression":
        return node.delegate && node.argument
          ? yield* settle(yield* evaluate(node.argument, env), site)
          : yield* fail(site, "yields without a star");
      case "ConditionalExpression":
        return (yield* decide(yield* evaluate(node.test, env), site))
          ? yield* evaluate(node.consequent, env)
          : yield* evaluate(node.alternate, env);
      case "LogicalExpression": {
        const read =
          node.operator === "??" && isPlain(node.right)
            ? yield* unread(node.left, env)
            : yield* evaluate(node.left, env);
        // `field ?? other`, where both are values the solver holds: one value, and no path each way.
        const held = read._tag === "Pending" ? Symbolic.keep(read, current.run) : undefined;
        const other = held && !held.option ? yield* tried(evaluate(node.right, env)) : undefined;
        const either = held && other ? oneOf(held.present, held.value, other) : undefined;
        if (either) return either;
        const left = chosen(read);
        if (node.operator === "??" && left._tag === "Applied")
          return yield* fail(site, inside("uses ?? on", left)!);
        if (node.operator === "??")
          return left._tag === "Null" || left._tag === "Undef"
            ? yield* evaluate(node.right, env)
            : left;
        const truthy = yield* decide(left, site);
        // On the side that keeps the left operand, it is known true (or false) here.
        const kept = left._tag === "Term" && left.term.sort === "Bool" ? Value.bool(truthy) : left;
        return (node.operator === "&&") === truthy ? yield* evaluate(node.right, env) : kept;
      }
      case "UnaryExpression": {
        const argument = yield* evaluate(node.argument, env);
        if (node.operator === "!") {
          const t = yield* truthOf(argument, site);
          return fromTruth(typeof t === "boolean" ? !t : Smt.not(t));
        }
        if (node.operator === "-")
          return yield* arithmetic(
            "-",
            Value.isBig(argument) ? { _tag: "Big", value: 0n } : Value.num(0),
            argument,
            site,
          );
        if (node.operator === "+" && Compare.numeric(argument) && !Value.isBig(argument))
          return argument;
        // `void x`: `x` is run, and nothing is given.
        if (node.operator === "void") return Value.undef;
        if (node.operator === "typeof") {
          const kind = kindOf(argument);
          if (kind !== undefined) return Value.str(kind);
        }
        return yield* fail(site, `uses ${node.operator}, which the prover does not translate`);
      }
      case "BinaryExpression": {
        const left = yield* evaluate(node.left, env);
        const right = yield* evaluate(node.right, env);
        if (node.operator === "===" || node.operator === "!==") {
          const equal = sameAs(left, right);
          if (equal === undefined)
            return yield* fail(
              site,
              inside("compares", left, right) ?? "compares values the prover does not model",
            );
          return fromTruth(
            node.operator === "===" ? equal : typeof equal === "boolean" ? !equal : Smt.not(equal),
          );
        }
        if (["+", "-", "*", "/", "%", "<", "<=", ">", ">="].includes(node.operator))
          return yield* arithmetic(node.operator, left, right, site);
        if (node.operator === "==" || node.operator === "!=") {
          // `x == null`: nothing, of either kind.
          const nothing = (v: V) => v._tag === "Null" || v._tag === "Undef";
          if (!nothing(left) && !nothing(right))
            return yield* fail(site, `uses ${node.operator}, where the prover reads ===`);
          const other = nothing(left) ? right : left;
          if (other._tag === "Opaque" || other._tag === "Applied")
            return yield* fail(
              site,
              inside("compares", other) ?? "compares values the prover does not model",
            );
          return Value.bool(nothing(other) === (node.operator === "=="));
        }
        if (node.operator === "in") {
          if ((left._tag !== "Str" && left._tag !== "Num") || right._tag !== "Obj")
            return yield* fail(site, "uses in on values the prover cannot see into");
          return Value.bool(
            Object.hasOwn((forced(right) as typeof right).fields, String(left.value)),
          );
        }
        return yield* fail(site, `uses ${node.operator}, which the prover does not translate`);
      }
      case "ObjectExpression": {
        const fields: Record<string, V> = {};
        for (const property of node.properties as ReadonlyArray<Node>) {
          if (property.type === "SpreadElement") {
            const spread = yield* evaluate(property.argument, env);
            if (spread._tag === "Obj" && spread.brand?.kind !== "Option")
              Object.assign(fields, spread.fields);
            else if (spread._tag !== "Null" && spread._tag !== "Undef")
              return yield* fail(site, "spreads a value the prover cannot see into");
            continue;
          }
          // A getter runs when the property is read: the prover reads a property as the value it holds.
          if (property.kind === "get" || property.kind === "set")
            return yield* fail(
              site,
              `declares a ${property.kind}ter in an object, which the prover does not read`,
            );
          const key = property.computed
            ? yield* evaluate(property.key, env)
            : Value.str(
                property.key.type === "Identifier" ? property.key.name : String(property.key.value),
              );
          if (key._tag !== "Str" && key._tag !== "Num")
            return yield* fail(
              site,
              "writes a property by a key the prover cannot see: it reads an object whose keys the code writes",
            );
          fields[String(key.value)] = yield* evaluate(property.value, env);
        }
        return made(Value.obj(fields));
      }
      case "ArrayExpression": {
        const items: Array<V> = [];
        for (const element of node.elements as ReadonlyArray<Node | null>) {
          if (!element) items.push(Value.undef);
          else if (element.type === "SpreadElement") {
            const spread = yield* iterate(yield* evaluate(element.argument, env), site);
            if (!spread) return yield* fail(site, "spreads a value that is not a known array");
            items.push(...spread);
          } else items.push(yield* evaluate(element, env));
        }
        return made<V>({ _tag: "Arr", items });
      }
      case "AssignmentExpression": {
        if (node.operator === "=") {
          const value = yield* evaluate(node.right, env);
          yield* assign(node.left, value, env, site);
          return value;
        }
        const operator: string = node.operator.slice(0, -1);
        // `note ??= other`, as `note ?? other` is read: one value, and no path each way.
        const waiting =
          operator === "??" && node.left.type === "Identifier" && isPlain(node.right)
            ? yield* unread(node.left, env)
            : undefined;
        const kept = waiting?._tag === "Pending" ? Symbolic.keep(waiting, current.run) : undefined;
        const fallback = kept && !kept.option ? yield* tried(evaluate(node.right, env)) : undefined;
        const merged = kept && fallback ? oneOf(kept.present, kept.value, fallback) : undefined;
        if (merged) {
          yield* assign(node.left, merged, env, site);
          return merged;
        }
        const before = yield* evaluate(node.left, env);
        let value: V;
        if (operator === "??" && before._tag === "Applied")
          return yield* fail(site, inside("uses ??= on", before)!);
        if (operator === "??")
          value =
            before._tag === "Null" || before._tag === "Undef"
              ? yield* evaluate(node.right, env)
              : before;
        else if (operator === "||" || operator === "&&")
          value =
            (yield* decide(before, site)) === (operator === "&&")
              ? yield* evaluate(node.right, env)
              : before;
        else if (["+", "-", "*", "/", "%"].includes(operator))
          value = yield* arithmetic(operator, before, yield* evaluate(node.right, env), site);
        else return yield* fail(site, `uses ${node.operator}, which the prover does not translate`);
        yield* assign(node.left, value, env, site);
        return value;
      }
      case "UpdateExpression": {
        const before = yield* evaluate(node.argument, env);
        const after = yield* arithmetic(
          node.operator === "++" ? "+" : "-",
          before,
          Value.isBig(before) ? { _tag: "Big", value: 1n } : Value.num(1),
          site,
        );
        yield* assign(node.argument, after, env, site);
        return node.prefix ? after : before;
      }
      default:
        // `this`, `await`, `import()` and `import.meta` are not a function of the arguments.
        return yield* Value.notTranslated(
          site,
          `uses a ${node.type}, which the prover does not read`,
          ["ThisExpression", "AwaitExpression", "ImportExpression", "MetaProperty"].includes(
            node.type,
          ),
        );
    }
  });

  /** Run statements in order. The result is what they returned, or `undefined` when they did not. */
  const execute: (statements: ReadonlyArray<Node>, env: Env) => Eval<V | undefined> =
    Effect.fnUntraced(function* (statements: ReadonlyArray<Node>, env: Env) {
      // A function a block declares is there from the block's first line.
      for (const statement of statements)
        if (statement.type === "FunctionDeclaration" && !env.scope.variables.has(statement.id.name))
          env.scope.variables.set(statement.id.name, {
            _tag: "Fn",
            node: statement,
            env,
            effectful: false,
          });
      for (const statement of statements) {
        const site: Site = { module: env.module, node: statement };
        switch (statement.type) {
          case "VariableDeclaration":
            for (const declarator of statement.declarations as ReadonlyArray<Node>) {
              yield* bind(
                declarator.id,
                // `const note = command.note`: the name is given the field, and its first use looks at it.
                !declarator.init
                  ? Value.undef
                  : declarator.id.type === "Identifier"
                    ? yield* unread(declarator.init, env)
                    : yield* evaluate(declarator.init, env),
                env.scope,
                env,
              );
            }
            break;
          case "ExpressionStatement":
            yield* evaluate(statement.expression, env);
            break;
          case "ReturnStatement":
            return statement.argument ? yield* evaluate(statement.argument, env) : Value.undef;
          case "BlockStatement": {
            const returned = yield* execute(statement.body, { ...env, scope: child(env.scope) });
            if (returned) return returned;
            break;
          }
          case "IfStatement": {
            const branch: Node | null = (yield* decide(yield* evaluate(statement.test, env), site))
              ? statement.consequent
              : statement.alternate;
            if (branch) {
              const returned = yield* execute([branch], { ...env, scope: child(env.scope) });
              if (returned) return returned;
            }
            break;
          }
          case "SwitchStatement": {
            const subject = yield* evaluate(statement.discriminant, env);
            const cases = statement.cases as ReadonlyArray<Node>;
            let at = -1;
            for (const [index, entry] of cases.entries()) {
              if (!entry.test) continue;
              const equal = sameAs(subject, yield* evaluate(entry.test, env));
              if (equal === undefined)
                return yield* fail(
                  site,
                  inside("switches on", subject) ?? "switches on a value the prover does not model",
                );
              if (typeof equal === "boolean" ? equal : yield* branch(equal)) {
                at = index;
                break;
              }
            }
            if (at < 0) at = cases.findIndex((entry) => !entry.test);
            if (at < 0) break;
            // A case without a `break` runs on into the next.
            const body = cases
              .slice(at)
              .flatMap((entry) => entry.consequent as ReadonlyArray<Node>);
            const returned = yield* execute(body, { ...env, scope: child(env.scope) });
            if (returned && returned !== BREAK) return returned;
            break;
          }
          case "BreakStatement":
            return statement.label ? yield* fail(site, "breaks to a label") : BREAK;
          case "ContinueStatement":
            return statement.label ? yield* fail(site, "continues to a label") : CONTINUE;
          case "ForOfStatement":
          case "ForInStatement": {
            if (statement.await) return yield* reaches(site, "loops with for await");
            const subject = forced(yield* evaluate(statement.right, env));
            const over =
              statement.type === "ForOfStatement"
                ? yield* iterate(subject, site)
                : subject._tag === "Obj" && !subject.brand
                  ? Object.keys(subject.fields).map(Value.str)
                  : subject._tag === "Arr"
                    ? subject.items.map((_, index) => Value.str(String(index)))
                    : undefined;
            const items = over ? [...over] : undefined;
            if (!items)
              return yield* fail(
                site,
                subject._tag === "Opaque"
                  ? `loops over ${subject.what}, whose items the prover does not know`
                  : "loops over a value whose items the prover does not know",
              );
            const left: Node = statement.left;
            for (const item of items) {
              const scope = child(env.scope);
              const inner = { ...env, scope };
              if (left.type === "VariableDeclaration")
                yield* bind(left.declarations[0].id, item, scope, inner);
              else yield* assign(left, item, env, site);
              const returned = yield* turn(statement.body, inner);
              if (returned === BREAK) break;
              if (returned) return returned;
            }
            break;
          }
          case "ForStatement":
          case "WhileStatement":
          case "DoWhileStatement": {
            const inner = { ...env, scope: child(env.scope) };
            const init: Node | null = statement.init ?? null;
            if (init?.type === "VariableDeclaration") {
              const returned = yield* execute([init], inner);
              if (returned) return returned;
            } else if (init) yield* evaluate(init, inner);
            let turns = 0;
            let first = statement.type === "DoWhileStatement";
            while (first || (yield* goesOn(statement.test ?? null, inner, site))) {
              first = false;
              if (++turns > MAX_TURNS)
                return yield* fail(site, `loops more than ${MAX_TURNS} times`);
              const returned = yield* turn(statement.body, { ...inner, scope: child(inner.scope) });
              if (returned === BREAK) break;
              if (returned) return returned;
              if (statement.update) yield* evaluate(statement.update, inner);
            }
            break;
          }
          case "EmptyStatement":
          case "TSTypeAliasDeclaration":
          case "TSInterfaceDeclaration":
            break;
          case "FunctionDeclaration":
            env.scope.variables.set(statement.id.name, {
              _tag: "Fn",
              node: statement,
              env,
              effectful: false,
            });
            break;
          default:
            return yield* fail(site, `uses a ${statement.type}, which the prover does not read`);
        }
      }
      return undefined;
    });

  return {
    current,
    evaluate,
    call,
    settle,
    branch,
    member,
    decide,
    truth: truthOf,
    moduleEnv,
    id: (value) => (value._tag === "Applied" ? textOf(value) : value),
    surface: {
      ...library.surface,
      arrays: [...Object.keys(arrayOwn), ...Object.keys(arrayMethods), "length"].sort(),
    },
    hooks,
  };
};
