import * as Layer from "effect/Layer";
import * as Provider from "../Provider.ts";
export declare const providers: () => Layer.Layer<Provider.Provider<import("./Build.ts").Build> | Provider.Provider<import("./Dev.ts").Dev> | Provider.Provider<import("./Exec.ts").Exec>, never, import("../AlchemyContext.ts").AlchemyContext | import("../Artifacts.ts").ArtifactStore | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("../Stack.ts").Stack>;
//# sourceMappingURL=Providers.d.ts.map