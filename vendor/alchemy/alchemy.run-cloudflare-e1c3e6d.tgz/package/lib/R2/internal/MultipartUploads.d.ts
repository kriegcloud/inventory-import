import * as accounts from "@distilled.cloud/cloudflare/accounts";
import * as Effect from "effect/Effect";
import type { Bucket } from "../Bucket.ts";
/**
 * The outcome of {@link abortMultipartUploads}: how many uploads were
 * aborted, or why they could not be.
 */
export type AbortMultipartUploadsResult = {
    aborted: number;
} | {
    skipped: string;
};
/**
 * Best-effort: abort every incomplete multipart upload in a bucket.
 *
 * R2 refuses to delete a bucket that holds incomplete multipart uploads, and
 * the Cloudflare REST API cannot list or abort them — only R2's S3 API can.
 * S3 credentials derive from an API token (access key id = token id, secret
 * = SHA-256 of the token value), so this only works when alchemy is
 * authenticated with an API token that may write the bucket's objects. It
 * never creates a token: with OAuth or a global API key, or when the token
 * lacks the permission, it reports why it skipped instead of failing.
 */
export declare const abortMultipartUploads: (accountId: string, bucketName: string, jurisdiction: Bucket.Jurisdiction) => Effect.Effect<AbortMultipartUploadsResult, never, accounts.CloudflareOpContext>;
//# sourceMappingURL=MultipartUploads.d.ts.map