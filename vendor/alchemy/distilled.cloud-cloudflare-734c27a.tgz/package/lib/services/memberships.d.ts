import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DeleteMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null | undefined;
}
export interface GetMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
}
export type GetResponseAccountType = "standard" | "enterprise";
export interface GetResponseAccountLegacyFlagsEnterpriseZoneQuota {
    /** Number of additional Enterprise zones available. Returns 0 if the quota is not allocated or is exhausted. */
    available?: number | null | undefined;
    /** Current number of Enterprise zones. */
    current?: number | null | undefined;
    /** Maximum number of Enterprise zones allowed. */
    maximum?: number | null | undefined;
}
export interface GetResponseAccountLegacyFlags {
    /** Enterprise zone quota for standard and enterprise accounts. Accounts without a quota have a maximum of 0. */
    enterpriseZoneQuota?: GetResponseAccountLegacyFlagsEnterpriseZoneQuota | null | undefined;
}
export interface GetResponseAccountManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string | null | undefined;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string | null | undefined;
    /** ID of the root Organization, if one exists */
    rootOrgId?: string | null | undefined;
    /** Indicates whether the parent Organization hierarchy should be displayed */
    shouldDisplayParentOrgs?: boolean | null | undefined;
}
export interface GetResponseAccountSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string | null | undefined;
    /** Indicates whether membership in this account requires that Two-Factor Authentication is enabled */
    enforceTwofactor?: boolean | null | undefined;
}
export interface GetResponseAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: GetResponseAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null | undefined;
    /** Legacy account flags. */
    legacyFlags?: GetResponseAccountLegacyFlags | null | undefined;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null | undefined;
    /** Account settings */
    settings?: GetResponseAccountSettings | null | undefined;
}
export interface GetResponsePermissionsAnalytics {
    read?: boolean | null | undefined;
    write?: boolean | null | undefined;
}
export type GetResponsePermissionsBilling = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsCachePurge = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsDns = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsDnsRecords = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsLb = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsLogs = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsOrganization = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsSsl = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsWaf = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsZoneSettings = GetResponsePermissionsAnalytics;
export type GetResponsePermissionsZones = GetResponsePermissionsAnalytics;
export interface GetResponsePermissions {
    analytics?: GetResponsePermissionsAnalytics | null | undefined;
    billing?: GetResponsePermissionsAnalytics | null | undefined;
    cachePurge?: GetResponsePermissionsAnalytics | null | undefined;
    dns?: GetResponsePermissionsAnalytics | null | undefined;
    dnsRecords?: GetResponsePermissionsAnalytics | null | undefined;
    lb?: GetResponsePermissionsAnalytics | null | undefined;
    logs?: GetResponsePermissionsAnalytics | null | undefined;
    organization?: GetResponsePermissionsAnalytics | null | undefined;
    ssl?: GetResponsePermissionsAnalytics | null | undefined;
    waf?: GetResponsePermissionsAnalytics | null | undefined;
    zoneSettings?: GetResponsePermissionsAnalytics | null | undefined;
    zones?: GetResponsePermissionsAnalytics | null | undefined;
}
export type GetResponsePoliciesItemAccess = "allow" | "deny";
export interface GetResponsePoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | null | undefined;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | null | undefined;
    /** Additional information about the permission group. */
    description?: string | null | undefined;
    /** Indicates whether the permission group can be edited. */
    editable?: string | null | undefined;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | null | undefined;
    /** A label identifying the permission group. */
    label?: string | null | undefined;
    /** The scope associated with the permission group. */
    scopes?: string | null | undefined;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | null | undefined;
}
export interface GetResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: GetResponsePoliciesItemPermissionGroupsItemMeta | null | undefined;
    /** Name of the permission group. */
    name?: string | null | undefined;
}
export type GetResponsePoliciesItemPermissionGroupsList = Array<GetResponsePoliciesItemPermissionGroupsItem>;
export interface GetResponsePoliciesItemResourceGroupsItemScopeObjectsItem {
    /** This is a combination of pre-defined resource name and identifier (like Zone ID etc.) */
    key: string;
}
export type GetResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<GetResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface GetResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: GetResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export interface GetResponsePoliciesItemResourceGroupsItemMeta {
    key?: string | null | undefined;
    value?: string | null | undefined;
}
export interface GetResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: GetResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: GetResponsePoliciesItemResourceGroupsItemMeta | null | undefined;
    /** Name of the resource group. */
    name?: string | null | undefined;
}
export type GetResponsePoliciesItemResourceGroupsList = Array<GetResponsePoliciesItemResourceGroupsItem>;
export interface GetResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null | undefined;
    /** Allow or deny operations against the resources. */
    access?: GetResponsePoliciesItemAccess | null | undefined;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: GetResponsePoliciesItemPermissionGroupsList | null | undefined;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: GetResponsePoliciesItemResourceGroupsList | null | undefined;
}
export type GetResponsePoliciesList = Array<GetResponsePoliciesItem>;
export type GetResponseRolesList = Array<string>;
export type GetResponseStatus = "accepted" | "pending" | "rejected";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null | undefined;
    account?: GetResponseAccount | null | undefined;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null | undefined;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null | undefined;
    /** Access policy for the membership */
    policies?: GetResponsePoliciesList | null | undefined;
    /** List of role names the membership has for this account. */
    roles?: GetResponseRolesList | null | undefined;
    /** Status of this membership. */
    status?: GetResponseStatus | null | undefined;
}
export interface ListRequestAccount {
    /** Account name */
    name?: string | undefined;
}
export type ListRequestDirection = "asc" | "desc";
export type ListRequestOrder = "id" | "account.name" | "status";
export type ListRequestStatus = "accepted" | "pending" | "rejected";
export interface ListMembershipsRequest {
    account?: ListRequestAccount | undefined;
    /** Direction to order memberships. */
    direction?: ListRequestDirection | (string & {}) | undefined;
    /** Account name */
    name?: string | undefined;
    /** Field to order memberships by. */
    order?: ListRequestOrder | (string & {}) | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of memberships per page. */
    perPage?: number | undefined;
    /** Status of this membership. */
    status?: ListRequestStatus | (string & {}) | undefined;
}
export type ListResultItemAccountType = "standard" | "enterprise";
export type ListResultItemAccountLegacyFlagsEnterpriseZoneQuota = GetResponseAccountLegacyFlagsEnterpriseZoneQuota;
export type ListResultItemAccountLegacyFlags = GetResponseAccountLegacyFlags;
export type ListResultItemAccountManagedBy = GetResponseAccountManagedBy;
export type ListResultItemAccountSettings = GetResponseAccountSettings;
export interface ListResultItemAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: ListResultItemAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null | undefined;
    /** Legacy account flags. */
    legacyFlags?: GetResponseAccountLegacyFlags | null | undefined;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null | undefined;
    /** Account settings */
    settings?: GetResponseAccountSettings | null | undefined;
}
export type ListResultItemPermissionsAnalytics = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsBilling = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsCachePurge = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsDns = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsDnsRecords = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsLb = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsLogs = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsOrganization = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsSsl = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsWaf = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsZoneSettings = GetResponsePermissionsAnalytics;
export type ListResultItemPermissionsZones = GetResponsePermissionsAnalytics;
export type ListResultItemPermissions = GetResponsePermissions;
export type ListResultItemRolesList = Array<string>;
export type ListResultItemStatus = "accepted" | "pending" | "rejected";
export interface ListResultItem {
    /** Membership identifier tag. */
    id?: string | null | undefined;
    account?: ListResultItemAccount | null | undefined;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null | undefined;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null | undefined;
    /** List of role names the membership has for this account. */
    roles?: ListResultItemRolesList | null | undefined;
    /** Status of this membership. */
    status?: ListResultItemStatus | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListMembershipsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type UpdateRequestStatus = "accepted" | "rejected";
export interface PutMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
    /** Whether to accept or reject this account invitation. */
    status: UpdateRequestStatus | (string & {});
}
export type UpdateResponseAccountType = "standard" | "enterprise";
export type UpdateResponseAccountLegacyFlagsEnterpriseZoneQuota = GetResponseAccountLegacyFlagsEnterpriseZoneQuota;
export type UpdateResponseAccountLegacyFlags = GetResponseAccountLegacyFlags;
export type UpdateResponseAccountManagedBy = GetResponseAccountManagedBy;
export type UpdateResponseAccountSettings = GetResponseAccountSettings;
export interface UpdateResponseAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: UpdateResponseAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null | undefined;
    /** Legacy account flags. */
    legacyFlags?: GetResponseAccountLegacyFlags | null | undefined;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null | undefined;
    /** Account settings */
    settings?: GetResponseAccountSettings | null | undefined;
}
export type UpdateResponsePermissionsAnalytics = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsBilling = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsCachePurge = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsDns = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsDnsRecords = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsLb = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsLogs = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsOrganization = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsSsl = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsWaf = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsZoneSettings = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissionsZones = GetResponsePermissionsAnalytics;
export type UpdateResponsePermissions = GetResponsePermissions;
export type UpdateResponsePoliciesItemAccess = "allow" | "deny";
export type UpdateResponsePoliciesItemPermissionGroupsItemMeta = GetResponsePoliciesItemPermissionGroupsItemMeta;
export type UpdateResponsePoliciesItemPermissionGroupsItem = GetResponsePoliciesItemPermissionGroupsItem;
export type UpdateResponsePoliciesItemPermissionGroupsList = Array<GetResponsePoliciesItemPermissionGroupsItem>;
export type UpdateResponsePoliciesItemResourceGroupsItemScopeObjectsItem = GetResponsePoliciesItemResourceGroupsItemScopeObjectsItem;
export type UpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<GetResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface UpdateResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type UpdateResponsePoliciesItemResourceGroupsItemMeta = GetResponsePoliciesItemResourceGroupsItemMeta;
export interface UpdateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: UpdateResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: GetResponsePoliciesItemResourceGroupsItemMeta | null | undefined;
    /** Name of the resource group. */
    name?: string | null | undefined;
}
export type UpdateResponsePoliciesItemResourceGroupsList = Array<UpdateResponsePoliciesItemResourceGroupsItem>;
export interface UpdateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null | undefined;
    /** Allow or deny operations against the resources. */
    access?: UpdateResponsePoliciesItemAccess | null | undefined;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UpdateResponsePoliciesItemPermissionGroupsList | null | undefined;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UpdateResponsePoliciesItemResourceGroupsList | null | undefined;
}
export type UpdateResponsePoliciesList = Array<UpdateResponsePoliciesItem>;
export type UpdateResponseRolesList = Array<string>;
export type UpdateResponseStatus = "accepted" | "pending" | "rejected";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null | undefined;
    account?: UpdateResponseAccount | null | undefined;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null | undefined;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null | undefined;
    /** Access policy for the membership */
    policies?: UpdateResponsePoliciesList | null | undefined;
    /** List of role names the membership has for this account. */
    roles?: UpdateResponseRolesList | null | undefined;
    /** Status of this membership. */
    status?: UpdateResponseStatus | null | undefined;
}
export type DeleteMembershipError = CloudflareOpError;
/** Remove the associated member from an account. */
export declare const deleteMembership: API.OperationMethod<DeleteMembershipRequest, DeleteMembershipResponse, DeleteMembershipError, CloudflareOpContext>;
export type GetMembershipError = CloudflareOpError;
/** Get a specific membership. */
export declare const getMembership: API.OperationMethod<GetMembershipRequest, GetMembershipResponse, GetMembershipError, CloudflareOpContext>;
export type ListMembershipsError = CloudflareOpError;
/** List memberships of accounts the user can access. */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest, ListMembershipsResponse, ListMembershipsError, CloudflareOpContext, ListResultItem>;
export type PutMembershipError = CloudflareOpError;
/** Accept or reject this account invitation. */
export declare const putMembership: API.OperationMethod<PutMembershipRequest, PutMembershipResponse, PutMembershipError, CloudflareOpContext>;
//# sourceMappingURL=memberships.d.ts.map