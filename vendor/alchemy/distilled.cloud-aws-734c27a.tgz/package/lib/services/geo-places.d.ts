import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SensitiveString = string | redacted.Redacted<string>;
export type Position = number[];
export type BoundingBox = number[];
export type DistanceMeters = number;
export interface FilterCircle {
    Center: number[];
    Radius: number;
}
export type CountryCode = string | redacted.Redacted<string>;
export type CountryCodeList = (string | redacted.Redacted<string>)[];
export type AutocompleteFilterPlaceType = "Locality" | "PostalCode" | "Street" | "Intersection" | "PointAddress" | "InterpolatedAddress" | "Country" | "Region" | (string & {});
export type AutocompleteFilterPlaceTypeList = AutocompleteFilterPlaceType[];
export interface AutocompleteFilter {
    BoundingBox?: number[] | undefined;
    Circle?: FilterCircle | undefined;
    IncludeCountries?: (string | redacted.Redacted<string>)[] | undefined;
    IncludePlaceTypes?: AutocompleteFilterPlaceType[] | undefined;
}
export type PostalCodeMode = "MergeAllSpannedLocalities" | "EnumerateSpannedLocalities" | "EnumerateSpannedDistricts" | (string & {});
export type AutocompleteAdditionalFeature = "Core" | (string & {});
export type AutocompleteAdditionalFeatureList = AutocompleteAdditionalFeature[];
export type LanguageTag = string;
export type AutocompleteIntendedUse = "SingleUse" | (string & {});
export type ApiKey = string | redacted.Redacted<string>;
export interface AutocompleteRequest {
    QueryText: string | redacted.Redacted<string>;
    MaxResults?: number | undefined;
    BiasPosition?: number[] | undefined;
    Filter?: AutocompleteFilter | undefined;
    PostalCodeMode?: PostalCodeMode | undefined;
    AdditionalFeatures?: AutocompleteAdditionalFeature[] | undefined;
    Language?: string | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    IntendedUse?: AutocompleteIntendedUse | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
}
export type PlaceType = "Country" | "Region" | "SubRegion" | "Locality" | "District" | "SubDistrict" | "PostalCode" | "Block" | "SubBlock" | "Intersection" | "Street" | "PointOfInterest" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "InferredSecondaryAddress" | (string & {});
export type CountryCode2 = string | redacted.Redacted<string>;
export type CountryCode3 = string | redacted.Redacted<string>;
export interface Country {
    Code2?: string | redacted.Redacted<string> | undefined;
    Code3?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export interface Region {
    Code?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export interface SubRegion {
    Code?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export type IntersectionStreet = string;
export type IntersectionStreetList = string[];
export type TypePlacement = "BeforeBaseName" | "AfterBaseName" | (string & {});
export type TypeSeparator = string;
export interface StreetComponents {
    BaseName?: string | redacted.Redacted<string> | undefined;
    Type?: string | redacted.Redacted<string> | undefined;
    TypePlacement?: TypePlacement | undefined;
    TypeSeparator?: string | undefined;
    Prefix?: string | redacted.Redacted<string> | undefined;
    Suffix?: string | redacted.Redacted<string> | undefined;
    Direction?: string | redacted.Redacted<string> | undefined;
    Language?: string | undefined;
}
export type StreetComponentsList = StreetComponents[];
export interface SecondaryAddressComponent {
    Number: string | redacted.Redacted<string>;
    Designator?: string | redacted.Redacted<string> | undefined;
}
export type SecondaryAddressComponentList = SecondaryAddressComponent[];
export interface Address {
    Label?: string | redacted.Redacted<string> | undefined;
    Country?: Country | undefined;
    Region?: Region | undefined;
    SubRegion?: SubRegion | undefined;
    Locality?: string | redacted.Redacted<string> | undefined;
    District?: string | redacted.Redacted<string> | undefined;
    SubDistrict?: string | redacted.Redacted<string> | undefined;
    PostalCode?: string | redacted.Redacted<string> | undefined;
    Block?: string | redacted.Redacted<string> | undefined;
    SubBlock?: string | redacted.Redacted<string> | undefined;
    Intersection?: string[] | undefined;
    Street?: string | redacted.Redacted<string> | undefined;
    StreetComponents?: StreetComponents[] | undefined;
    AddressNumber?: string | redacted.Redacted<string> | undefined;
    Building?: string | redacted.Redacted<string> | undefined;
    SecondaryAddressComponents?: SecondaryAddressComponent[] | undefined;
}
export interface Highlight {
    StartIndex?: number | undefined;
    EndIndex?: number | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
}
export type HighlightList = Highlight[];
export interface CountryHighlights {
    Code?: Highlight[] | undefined;
    Name?: Highlight[] | undefined;
}
export interface RegionHighlights {
    Code?: Highlight[] | undefined;
    Name?: Highlight[] | undefined;
}
export interface SubRegionHighlights {
    Code?: Highlight[] | undefined;
    Name?: Highlight[] | undefined;
}
export type IntersectionHighlightsList = Highlight[][];
export interface AutocompleteAddressHighlights {
    Label?: Highlight[] | undefined;
    Country?: CountryHighlights | undefined;
    Region?: RegionHighlights | undefined;
    SubRegion?: SubRegionHighlights | undefined;
    Locality?: Highlight[] | undefined;
    District?: Highlight[] | undefined;
    SubDistrict?: Highlight[] | undefined;
    Street?: Highlight[] | undefined;
    Block?: Highlight[] | undefined;
    SubBlock?: Highlight[] | undefined;
    Intersection?: Highlight[][] | undefined;
    PostalCode?: Highlight[] | undefined;
    AddressNumber?: Highlight[] | undefined;
    Building?: Highlight[] | undefined;
}
export interface AutocompleteHighlights {
    Title?: Highlight[] | undefined;
    Address?: AutocompleteAddressHighlights | undefined;
}
export type SensitiveBoolean = boolean;
export interface AutocompleteResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address | undefined;
    Distance?: number | undefined;
    Language?: string | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    Highlights?: AutocompleteHighlights | undefined;
    EstimatedPointAddress?: boolean | undefined;
}
export type AutocompleteResultItemList = AutocompleteResultItem[];
export interface AutocompleteResponse {
    PricingBucket: string;
    ResultItems?: AutocompleteResultItem[] | undefined;
}
export interface GeocodeQueryComponents {
    Country?: string | redacted.Redacted<string> | undefined;
    Region?: string | redacted.Redacted<string> | undefined;
    SubRegion?: string | redacted.Redacted<string> | undefined;
    Locality?: string | redacted.Redacted<string> | undefined;
    District?: string | redacted.Redacted<string> | undefined;
    Street?: string | redacted.Redacted<string> | undefined;
    AddressNumber?: string | redacted.Redacted<string> | undefined;
    PostalCode?: string | redacted.Redacted<string> | undefined;
}
export type GeocodeFilterPlaceType = "Locality" | "PostalCode" | "Intersection" | "Street" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "PointOfInterest" | "Country" | "Region" | (string & {});
export type GeocodeFilterPlaceTypeList = GeocodeFilterPlaceType[];
export interface GeocodeFilter {
    IncludeCountries?: (string | redacted.Redacted<string>)[] | undefined;
    IncludePlaceTypes?: GeocodeFilterPlaceType[] | undefined;
}
export type GeocodeAdditionalFeature = "TimeZone" | "Access" | "SecondaryAddresses" | "Intersections" | (string & {});
export type GeocodeAdditionalFeatureList = GeocodeAdditionalFeature[];
export type GeocodeIntendedUse = "SingleUse" | "Storage" | (string & {});
export type AddressTranslationComponent = "District" | "Locality" | "Region" | "SubRegion" | (string & {});
export type AddressTranslationComponentList = AddressTranslationComponent[];
export type GeocodeAddressNamesMode = "Matched" | "Administrative" | (string & {});
export interface GeocodeRequest {
    QueryText?: string | redacted.Redacted<string> | undefined;
    QueryComponents?: GeocodeQueryComponents | undefined;
    MaxResults?: number | undefined;
    BiasPosition?: number[] | undefined;
    Filter?: GeocodeFilter | undefined;
    AdditionalFeatures?: GeocodeAdditionalFeature[] | undefined;
    Language?: string | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    IntendedUse?: GeocodeIntendedUse | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
    PostalCodeMode?: PostalCodeMode | undefined;
    AddressTranslations?: AddressTranslationComponent[] | undefined;
    AddressNamesMode?: GeocodeAddressNamesMode | undefined;
}
export type PostalAuthority = "Usps" | (string & {});
export type PostalCodeType = "UspsZip" | "UspsZipPlus4" | (string & {});
export type ZipClassificationCode = "Military" | "PostOfficeBoxes" | "Unique" | (string & {});
export interface UspsZip {
    ZipClassificationCode?: ZipClassificationCode | undefined;
}
export type RecordTypeCode = "Firm" | "General" | "HighRise" | "PostOfficeBox" | "Rural" | "Street" | (string & {});
export interface UspsZipPlus4 {
    RecordTypeCode?: RecordTypeCode | undefined;
}
export interface PostalCodeDetails {
    PostalCode?: string | redacted.Redacted<string> | undefined;
    PostalAuthority?: PostalAuthority | undefined;
    PostalCodeType?: PostalCodeType | undefined;
    UspsZip?: UspsZip | undefined;
    UspsZipPlus4?: UspsZipPlus4 | undefined;
}
export type PostalCodeDetailsList = PostalCodeDetails[];
export interface Category {
    Id: string | redacted.Redacted<string>;
    Name: string | redacted.Redacted<string>;
    LocalizedName?: string | redacted.Redacted<string> | undefined;
    Primary?: boolean | undefined;
}
export type CategoryList = Category[];
export interface FoodType {
    LocalizedName: string | redacted.Redacted<string>;
    Id?: string | redacted.Redacted<string> | undefined;
    Primary?: boolean | undefined;
}
export type FoodTypeList = FoodType[];
export type AccessPointType = "Delivery" | "Emergency" | "Entrance" | "Loading" | "Other" | "Parking" | "Taxi" | (string & {});
export interface AccessPoint {
    Position?: number[] | undefined;
    Type?: AccessPointType | undefined;
    Primary?: boolean | undefined;
    Label?: string | redacted.Redacted<string> | undefined;
}
export type AccessPointList = AccessPoint[];
export type DurationSeconds = number;
export interface TimeZone {
    Name: string | redacted.Redacted<string>;
    Offset?: string | redacted.Redacted<string> | undefined;
    OffsetSeconds?: number | undefined;
}
export type MatchScore = number;
export type MatchScoreList = number[];
export interface SecondaryAddressComponentMatchScore {
    Number?: number | undefined;
}
export type SecondaryAddressComponentMatchScoreList = SecondaryAddressComponentMatchScore[];
export interface AddressComponentMatchScores {
    Country?: number | undefined;
    Region?: number | undefined;
    SubRegion?: number | undefined;
    Locality?: number | undefined;
    District?: number | undefined;
    SubDistrict?: number | undefined;
    PostalCode?: number | undefined;
    Block?: number | undefined;
    SubBlock?: number | undefined;
    Intersection?: number[] | undefined;
    AddressNumber?: number | undefined;
    Building?: number | undefined;
    SecondaryAddressComponents?: SecondaryAddressComponentMatchScore[] | undefined;
}
export interface ComponentMatchScores {
    Title?: number | undefined;
    Address?: AddressComponentMatchScores | undefined;
}
export interface MatchScoreDetails {
    Overall?: number | undefined;
    Components?: ComponentMatchScores | undefined;
}
export interface ParsedQueryComponent {
    StartIndex?: number | undefined;
    EndIndex?: number | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
    QueryComponent?: string | redacted.Redacted<string> | undefined;
}
export type ParsedQueryComponentList = ParsedQueryComponent[];
export interface ParsedQuerySecondaryAddressComponent {
    StartIndex: number;
    EndIndex: number;
    Value: string | redacted.Redacted<string>;
    Number: string | redacted.Redacted<string>;
    Designator: string | redacted.Redacted<string>;
}
export type ParsedQuerySecondaryAddressComponentList = ParsedQuerySecondaryAddressComponent[];
export interface GeocodeParsedQueryAddressComponents {
    Country?: ParsedQueryComponent[] | undefined;
    Region?: ParsedQueryComponent[] | undefined;
    SubRegion?: ParsedQueryComponent[] | undefined;
    Locality?: ParsedQueryComponent[] | undefined;
    District?: ParsedQueryComponent[] | undefined;
    SubDistrict?: ParsedQueryComponent[] | undefined;
    PostalCode?: ParsedQueryComponent[] | undefined;
    Block?: ParsedQueryComponent[] | undefined;
    SubBlock?: ParsedQueryComponent[] | undefined;
    Street?: ParsedQueryComponent[] | undefined;
    AddressNumber?: ParsedQueryComponent[] | undefined;
    Building?: ParsedQueryComponent[] | undefined;
    SecondaryAddressComponents?: ParsedQuerySecondaryAddressComponent[] | undefined;
    OtherComponents?: ParsedQueryComponent[] | undefined;
}
export interface GeocodeParsedQuery {
    Title?: ParsedQueryComponent[] | undefined;
    Address?: GeocodeParsedQueryAddressComponents | undefined;
}
export interface Intersection {
    PlaceId: string | redacted.Redacted<string>;
    Title: string | redacted.Redacted<string>;
    Address?: Address | undefined;
    Position?: number[] | undefined;
    Distance?: number | undefined;
    RouteDistance?: number | undefined;
    MapView?: number[] | undefined;
    AccessPoints?: AccessPoint[] | undefined;
}
export type IntersectionList = Intersection[];
export interface RelatedPlace {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address | undefined;
    Position?: number[] | undefined;
    AccessPoints?: AccessPoint[] | undefined;
}
export type RelatedPlaceList = RelatedPlace[];
export type TranslationNameType = "Abbreviation" | "AreaCode" | "BaseName" | "Exonym" | "Shortened" | "Synonym" | (string & {});
export interface TranslationName {
    Value: string | redacted.Redacted<string>;
    Language?: string | undefined;
    Type: TranslationNameType;
    Primary?: boolean | undefined;
    Transliterated?: boolean | undefined;
}
export type TranslationNameList = TranslationName[];
export type AdminNamesPreference = "Alternative" | "Primary" | (string & {});
export interface AdminNames {
    Names: TranslationName[];
    Preference?: AdminNamesPreference | undefined;
}
export type AdminNamesList = AdminNames[];
export interface TranslationDetails {
    Locality?: AdminNames[] | undefined;
    Region?: AdminNames[] | undefined;
    District?: AdminNames[] | undefined;
    SubRegion?: AdminNames[] | undefined;
}
export interface GeocodeResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address | undefined;
    AddressNumberCorrected?: boolean | undefined;
    PostalCodeDetails?: PostalCodeDetails[] | undefined;
    Position?: number[] | undefined;
    Distance?: number | undefined;
    MapView?: number[] | undefined;
    Categories?: Category[] | undefined;
    FoodTypes?: FoodType[] | undefined;
    AccessPoints?: AccessPoint[] | undefined;
    TimeZone?: TimeZone | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    MatchScores?: MatchScoreDetails | undefined;
    ParsedQuery?: GeocodeParsedQuery | undefined;
    Intersections?: Intersection[] | undefined;
    MainAddress?: RelatedPlace | undefined;
    SecondaryAddresses?: RelatedPlace[] | undefined;
    Translations?: TranslationDetails | undefined;
    EstimatedPointAddress?: boolean | undefined;
}
export type GeocodeResultItemList = GeocodeResultItem[];
export interface GeocodeResponse {
    PricingBucket: string;
    ResultItems?: GeocodeResultItem[] | undefined;
}
export type GetPlaceAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "SecondaryAddresses" | "CrossReferences" | (string & {});
export type GetPlaceAdditionalFeatureList = GetPlaceAdditionalFeature[];
export type GetPlaceIntendedUse = "SingleUse" | "Storage" | (string & {});
export type GetPlaceAddressNamesMode = "Administrative" | (string & {});
export interface GetPlaceRequest {
    PlaceId: string | redacted.Redacted<string>;
    AdditionalFeatures?: GetPlaceAdditionalFeature[] | undefined;
    Language?: string | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    IntendedUse?: GetPlaceIntendedUse | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
    AddressNamesMode?: GetPlaceAddressNamesMode | undefined;
}
export interface BusinessChain {
    Name?: string | redacted.Redacted<string> | undefined;
    Id?: string | redacted.Redacted<string> | undefined;
}
export type BusinessChainList = BusinessChain[];
export interface ContactDetails {
    Label?: string | redacted.Redacted<string> | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
    Categories?: Category[] | undefined;
}
export type ContactDetailsList = ContactDetails[];
export interface Contacts {
    Phones?: ContactDetails[] | undefined;
    Faxes?: ContactDetails[] | undefined;
    Websites?: ContactDetails[] | undefined;
    Emails?: ContactDetails[] | undefined;
}
export type OpeningHoursDisplay = string | redacted.Redacted<string>;
export type OpeningHoursDisplayList = (string | redacted.Redacted<string>)[];
export interface OpeningHoursComponents {
    OpenTime?: string | redacted.Redacted<string> | undefined;
    OpenDuration?: string | redacted.Redacted<string> | undefined;
    Recurrence?: string | redacted.Redacted<string> | undefined;
}
export type OpeningHoursComponentsList = OpeningHoursComponents[];
export interface OpeningHours {
    Display?: (string | redacted.Redacted<string>)[] | undefined;
    OpenNow?: boolean | undefined;
    Components?: OpeningHoursComponents[] | undefined;
    Categories?: Category[] | undefined;
}
export type OpeningHoursList = OpeningHours[];
export interface AccessRestriction {
    Restricted?: boolean | undefined;
    Categories?: Category[] | undefined;
}
export type AccessRestrictionList = AccessRestriction[];
export interface PhonemeTranscription {
    Value?: string | redacted.Redacted<string> | undefined;
    Language?: string | undefined;
    Preferred?: boolean | undefined;
}
export type PhonemeTranscriptionList = PhonemeTranscription[];
export interface AddressComponentPhonemes {
    Country?: PhonemeTranscription[] | undefined;
    Region?: PhonemeTranscription[] | undefined;
    SubRegion?: PhonemeTranscription[] | undefined;
    Locality?: PhonemeTranscription[] | undefined;
    District?: PhonemeTranscription[] | undefined;
    SubDistrict?: PhonemeTranscription[] | undefined;
    Block?: PhonemeTranscription[] | undefined;
    SubBlock?: PhonemeTranscription[] | undefined;
    Street?: PhonemeTranscription[] | undefined;
}
export interface PhonemeDetails {
    Title?: PhonemeTranscription[] | undefined;
    Address?: AddressComponentPhonemes | undefined;
}
export type PlaceAttribute = "DriveThrough" | (string & {});
export type PlaceAttributeList = PlaceAttribute[];
export interface CrossReference {
    Source: string | redacted.Redacted<string>;
    SourcePlaceId: string | redacted.Redacted<string>;
    SourceCategories?: Category[] | undefined;
}
export type CrossReferenceList = CrossReference[];
export interface GetPlaceResponse {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    PricingBucket: string;
    Address?: Address | undefined;
    AddressNumberCorrected?: boolean | undefined;
    PostalCodeDetails?: PostalCodeDetails[] | undefined;
    Position?: number[] | undefined;
    MapView?: number[] | undefined;
    Categories?: Category[] | undefined;
    FoodTypes?: FoodType[] | undefined;
    BusinessChains?: BusinessChain[] | undefined;
    Contacts?: Contacts | undefined;
    OpeningHours?: OpeningHours[] | undefined;
    AccessPoints?: AccessPoint[] | undefined;
    AccessRestrictions?: AccessRestriction[] | undefined;
    TimeZone?: TimeZone | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    Phonemes?: PhonemeDetails | undefined;
    MainAddress?: RelatedPlace | undefined;
    SecondaryAddresses?: RelatedPlace[] | undefined;
    PlaceAttributes?: PlaceAttribute[] | undefined;
    EstimatedPointAddress?: boolean | undefined;
    CrossReferences?: CrossReference[] | undefined;
}
export type ReverseGeocodeFilterPlaceType = "Locality" | "Intersection" | "Street" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "PointOfInterest" | (string & {});
export type ReverseGeocodeFilterPlaceTypeList = ReverseGeocodeFilterPlaceType[];
export interface ReverseGeocodeFilter {
    IncludePlaceTypes?: ReverseGeocodeFilterPlaceType[] | undefined;
}
export type ReverseGeocodeAdditionalFeature = "TimeZone" | "Access" | "Intersections" | (string & {});
export type ReverseGeocodeAdditionalFeatureList = ReverseGeocodeAdditionalFeature[];
export type ReverseGeocodeIntendedUse = "SingleUse" | "Storage" | (string & {});
export type Heading = number;
export type ReverseGeocodeAddressNamesMode = "Administrative" | (string & {});
export interface ReverseGeocodeRequest {
    QueryPosition: number[];
    QueryRadius?: number | undefined;
    MaxResults?: number | undefined;
    Filter?: ReverseGeocodeFilter | undefined;
    AdditionalFeatures?: ReverseGeocodeAdditionalFeature[] | undefined;
    Language?: string | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    IntendedUse?: ReverseGeocodeIntendedUse | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
    Heading?: number | undefined;
    AddressNamesMode?: ReverseGeocodeAddressNamesMode | undefined;
}
export interface ReverseGeocodeResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address | undefined;
    AddressNumberCorrected?: boolean | undefined;
    PostalCodeDetails?: PostalCodeDetails[] | undefined;
    Position?: number[] | undefined;
    Distance?: number | undefined;
    MapView?: number[] | undefined;
    Categories?: Category[] | undefined;
    FoodTypes?: FoodType[] | undefined;
    AccessPoints?: AccessPoint[] | undefined;
    TimeZone?: TimeZone | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    Intersections?: Intersection[] | undefined;
    MainAddress?: RelatedPlace | undefined;
    EstimatedPointAddress?: boolean | undefined;
}
export type ReverseGeocodeResultItemList = ReverseGeocodeResultItem[];
export interface ReverseGeocodeResponse {
    PricingBucket: string;
    ResultItems?: ReverseGeocodeResultItem[] | undefined;
}
export type FilterCategoryList = (string | redacted.Redacted<string>)[];
export type FilterBusinessChainList = (string | redacted.Redacted<string>)[];
export type FilterFoodTypeList = (string | redacted.Redacted<string>)[];
export interface SearchNearbyFilter {
    BoundingBox?: number[] | undefined;
    IncludeCountries?: (string | redacted.Redacted<string>)[] | undefined;
    IncludeCategories?: (string | redacted.Redacted<string>)[] | undefined;
    ExcludeCategories?: (string | redacted.Redacted<string>)[] | undefined;
    IncludeBusinessChains?: (string | redacted.Redacted<string>)[] | undefined;
    ExcludeBusinessChains?: (string | redacted.Redacted<string>)[] | undefined;
    IncludeFoodTypes?: (string | redacted.Redacted<string>)[] | undefined;
    ExcludeFoodTypes?: (string | redacted.Redacted<string>)[] | undefined;
}
export type SearchNearbyAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "CrossReferences" | (string & {});
export type SearchNearbyAdditionalFeatureList = SearchNearbyAdditionalFeature[];
export type SearchNearbyIntendedUse = "SingleUse" | "Storage" | (string & {});
export type Token = string;
export interface SearchNearbyRequest {
    QueryPosition: number[];
    QueryRadius?: number | undefined;
    MaxResults?: number | undefined;
    Filter?: SearchNearbyFilter | undefined;
    AdditionalFeatures?: SearchNearbyAdditionalFeature[] | undefined;
    Language?: string | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    IntendedUse?: SearchNearbyIntendedUse | undefined;
    NextToken?: string | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
}
export interface SearchNearbyResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address | undefined;
    AddressNumberCorrected?: boolean | undefined;
    Position?: number[] | undefined;
    Distance?: number | undefined;
    MapView?: number[] | undefined;
    Categories?: Category[] | undefined;
    FoodTypes?: FoodType[] | undefined;
    BusinessChains?: BusinessChain[] | undefined;
    Contacts?: Contacts | undefined;
    OpeningHours?: OpeningHours[] | undefined;
    AccessPoints?: AccessPoint[] | undefined;
    AccessRestrictions?: AccessRestriction[] | undefined;
    TimeZone?: TimeZone | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    Phonemes?: PhonemeDetails | undefined;
    PlaceAttributes?: PlaceAttribute[] | undefined;
    CrossReferences?: CrossReference[] | undefined;
}
export type SearchNearbyResultItemList = SearchNearbyResultItem[];
export interface SearchNearbyResponse {
    PricingBucket: string;
    ResultItems?: SearchNearbyResultItem[] | undefined;
    NextToken?: string | undefined;
}
export interface SearchTextFilter {
    BoundingBox?: number[] | undefined;
    Circle?: FilterCircle | undefined;
    IncludeCountries?: (string | redacted.Redacted<string>)[] | undefined;
}
export type SearchTextAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "CrossReferences" | (string & {});
export type SearchTextAdditionalFeatureList = SearchTextAdditionalFeature[];
export type SearchTextIntendedUse = "SingleUse" | "Storage" | (string & {});
export type SearchTextTravelMode = "Car" | "Scooter" | "Truck" | (string & {});
export interface SearchTextRequest {
    QueryText?: string | redacted.Redacted<string> | undefined;
    QueryId?: string | redacted.Redacted<string> | undefined;
    MaxResults?: number | undefined;
    BiasPosition?: number[] | undefined;
    Filter?: SearchTextFilter | undefined;
    AdditionalFeatures?: SearchTextAdditionalFeature[] | undefined;
    Language?: string | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    IntendedUse?: SearchTextIntendedUse | undefined;
    NextToken?: string | undefined;
    TravelMode?: SearchTextTravelMode | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
}
export interface SearchTextResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address | undefined;
    AddressNumberCorrected?: boolean | undefined;
    Position?: number[] | undefined;
    Distance?: number | undefined;
    MapView?: number[] | undefined;
    Categories?: Category[] | undefined;
    FoodTypes?: FoodType[] | undefined;
    BusinessChains?: BusinessChain[] | undefined;
    Contacts?: Contacts | undefined;
    OpeningHours?: OpeningHours[] | undefined;
    AccessPoints?: AccessPoint[] | undefined;
    AccessRestrictions?: AccessRestriction[] | undefined;
    TimeZone?: TimeZone | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    Phonemes?: PhonemeDetails | undefined;
    PlaceAttributes?: PlaceAttribute[] | undefined;
    CrossReferences?: CrossReference[] | undefined;
}
export type SearchTextResultItemList = SearchTextResultItem[];
export interface SearchTextResponse {
    PricingBucket: string;
    ResultItems?: SearchTextResultItem[] | undefined;
    NextToken?: string | undefined;
}
export interface SuggestFilter {
    BoundingBox?: number[] | undefined;
    Circle?: FilterCircle | undefined;
    IncludeCountries?: (string | redacted.Redacted<string>)[] | undefined;
}
export type SuggestAdditionalFeature = "Core" | "TimeZone" | "Phonemes" | "Access" | "CrossReferences" | (string & {});
export type SuggestAdditionalFeatureList = SuggestAdditionalFeature[];
export type SuggestIntendedUse = "SingleUse" | (string & {});
export type SuggestTravelMode = "Car" | "Scooter" | "Truck" | (string & {});
export interface SuggestRequest {
    QueryText: string | redacted.Redacted<string>;
    MaxResults?: number | undefined;
    MaxQueryRefinements?: number | undefined;
    BiasPosition?: number[] | undefined;
    Filter?: SuggestFilter | undefined;
    AdditionalFeatures?: SuggestAdditionalFeature[] | undefined;
    Language?: string | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    IntendedUse?: SuggestIntendedUse | undefined;
    TravelMode?: SuggestTravelMode | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
}
export type SuggestResultItemType = "Place" | "Query" | (string & {});
export interface SuggestPlaceResult {
    PlaceId?: string | redacted.Redacted<string> | undefined;
    PlaceType?: PlaceType | undefined;
    Address?: Address | undefined;
    Position?: number[] | undefined;
    Distance?: number | undefined;
    MapView?: number[] | undefined;
    Categories?: Category[] | undefined;
    FoodTypes?: FoodType[] | undefined;
    BusinessChains?: BusinessChain[] | undefined;
    AccessPoints?: AccessPoint[] | undefined;
    AccessRestrictions?: AccessRestriction[] | undefined;
    TimeZone?: TimeZone | undefined;
    PoliticalView?: string | redacted.Redacted<string> | undefined;
    Phonemes?: PhonemeDetails | undefined;
    PlaceAttributes?: PlaceAttribute[] | undefined;
    CrossReferences?: CrossReference[] | undefined;
}
export type QueryType = "Category" | "BusinessChain" | (string & {});
export interface SuggestQueryResult {
    QueryId?: string | redacted.Redacted<string> | undefined;
    QueryType?: QueryType | undefined;
}
export interface SuggestAddressHighlights {
    Label?: Highlight[] | undefined;
}
export interface SuggestHighlights {
    Title?: Highlight[] | undefined;
    Address?: SuggestAddressHighlights | undefined;
}
export interface SuggestResultItem {
    Title: string | redacted.Redacted<string>;
    SuggestResultItemType: SuggestResultItemType;
    Place?: SuggestPlaceResult | undefined;
    Query?: SuggestQueryResult | undefined;
    Highlights?: SuggestHighlights | undefined;
}
export type SuggestResultItemList = SuggestResultItem[];
export interface QueryRefinement {
    RefinedTerm: string | redacted.Redacted<string>;
    OriginalTerm: string | redacted.Redacted<string>;
    StartIndex: number;
    EndIndex: number;
}
export type QueryRefinementList = QueryRefinement[];
export interface SuggestResponse {
    PricingBucket: string;
    ResultItems?: SuggestResultItem[] | undefined;
    QueryRefinements?: QueryRefinement[] | undefined;
}
export type ValidationExceptionReason = "UnknownOperation" | "Missing" | "CannotParse" | "FieldValidationFailed" | "Other" | "UnknownField" | (string & {});
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AutocompleteError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Autocomplete` completes potential places and addresses as the user types, based on the partial input. The API enhances the efficiency and accuracy of address by completing query based on a few entered keystrokes. It helps you by completing partial queries with valid address completion. Also, the API supports the filtering of results based on geographic location, country, or specific place types, and can be tailored using optional parameters like language and political views. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Autocomplete in the *Amazon Location Service Developer Guide*.
 */
export declare const autocomplete: API.OperationMethod<AutocompleteRequest & RegionInput, AutocompleteResponse, AutocompleteError, Credentials | HttpClient.HttpClient>;
export type GeocodeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Geocode` converts a textual address or place into geographic coordinates. You can obtain geographic coordinates, address component, and other related information. It supports flexible queries, including free-form text or structured queries with components like street names, postal codes, and regions. The Geocode API can also provide additional features such as time zone information and the inclusion of political views. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Geocode in the *Amazon Location Service Developer Guide*.
 */
export declare const geocode: API.OperationMethod<GeocodeRequest & RegionInput, GeocodeResponse, GeocodeError, Credentials | HttpClient.HttpClient>;
export type GetPlaceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `GetPlace` finds a place by its unique ID. A `PlaceId` is returned by other place operations.
 *
 * For more information, see GetPlace in the *Amazon Location Service Developer Guide*.
 */
export declare const getPlace: API.OperationMethod<GetPlaceRequest & RegionInput, GetPlaceResponse, GetPlaceError, Credentials | HttpClient.HttpClient>;
export type ReverseGeocodeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `ReverseGeocode` converts geographic coordinates into a human-readable address or place. You can obtain address component, and other related information such as place type, category, street information. The Reverse Geocode API supports filtering to on place type so that you can refine result based on your need. Also, The Reverse Geocode API can also provide additional features such as time zone information and the inclusion of political views.
 *
 * For more information, see Reverse Geocode in the *Amazon Location Service Developer Guide*.
 */
export declare const reverseGeocode: API.OperationMethod<ReverseGeocodeRequest & RegionInput, ReverseGeocodeResponse, ReverseGeocodeError, Credentials | HttpClient.HttpClient>;
export type SearchNearbyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `SearchNearby` queries for points of interest within a radius from a central coordinates, returning place results with optional filters such as categories, business chains, food types and more. The API returns details such as a place name, address, phone, category, food type, contact, opening hours. Also, the API can return phonemes, time zones and more based on requested parameters. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Search Nearby in the *Amazon Location Service Developer Guide*.
 */
export declare const searchNearby: API.OperationMethod<SearchNearbyRequest & RegionInput, SearchNearbyResponse, SearchNearbyError, Credentials | HttpClient.HttpClient>;
export type SearchTextError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `SearchText` searches for geocode and place information. You can then complete a follow-up query suggested from the `Suggest` API via a query id.
 *
 * For more information, see Search Text in the *Amazon Location Service Developer Guide*.
 */
export declare const searchText: API.OperationMethod<SearchTextRequest & RegionInput, SearchTextResponse, SearchTextError, Credentials | HttpClient.HttpClient>;
export type SuggestError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Suggest` provides intelligent predictions or recommendations based on the user's input or context, such as relevant places, points of interest, query terms or search category. It is designed to help users find places or point of interests candidates or identify a follow on query based on incomplete or misspelled queries. It returns a list of possible matches or refinements that can be used to formulate a more accurate query. Users can select the most appropriate suggestion and use it for further searching. The API provides options for filtering results by location and other attributes, and allows for additional features like phonemes and timezones. The response includes refined query terms and detailed place information.
 *
 * For more information, see Suggest in the *Amazon Location Service Developer Guide*.
 */
export declare const suggest: API.OperationMethod<SuggestRequest & RegionInput, SuggestResponse, SuggestError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=geo-places.d.ts.map