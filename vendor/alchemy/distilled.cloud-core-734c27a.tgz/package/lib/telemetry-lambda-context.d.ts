/**
 * W3C trace context in a Lambda `Invoke`'s `ClientContext` (base64 JSON),
 * under `custom.traceparent`, as `@opentelemetry/instrumentation-aws-sdk`
 * writes it; the invoked function reads it from `context.clientContext`.
 * Generated code imports this only where an operation's `inject` has format
 * `lambdaClientContext`. See `packages/dev/src/codegen/telemetry-traits.md`.
 */
import type * as Tracer from "effect/Tracer";
/**
 * Add `custom.traceparent` to the input's `member` (a base64 JSON client
 * context). Kept as it was: a `traceparent` already there, a value that is
 * not base64 JSON, and a result over Lambda's size cap.
 */
export declare const injectLambdaClientContext: (place: {
    readonly member: string;
}) => (span: Tracer.Span, input: unknown) => unknown;
//# sourceMappingURL=telemetry-lambda-context.d.ts.map