import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const InvalidContentLocation_base: S.TaggedErrorClass<"InvalidContentLocation", {
    readonly message: any;
}>;
export declare class InvalidContentLocation extends /*@__PURE__*/ InvalidContentLocation_base {
}
declare const MessageFrozen_base: S.TaggedErrorClass<"MessageFrozen", {
    readonly message: any;
}>;
export declare class MessageFrozen extends /*@__PURE__*/ MessageFrozen_base {
}
declare const MessageRejected_base: S.TaggedErrorClass<"MessageRejected", {
    readonly message: any;
}>;
export declare class MessageRejected extends /*@__PURE__*/ MessageRejected_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type MessageIdType = string;
export interface GetRawMessageContentRequest {
    messageId: string;
}
export interface GetRawMessageContentResponse {
    messageContent: T.StreamingOutputBody;
}
export type S3BucketIdType = string;
export type S3KeyIdType = string;
export type S3VersionType = string;
export interface S3Reference {
    bucket: string;
    key: string;
    objectVersion?: string | undefined;
}
export interface RawMessageContent {
    s3Reference: S3Reference;
}
export interface PutRawMessageContentRequest {
    messageId: string;
    content: RawMessageContent;
}
export interface PutRawMessageContentResponse {
}
export type ErrorMessage = string;
export type GetRawMessageContentError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the raw content of an in-transit email message, in MIME format.
 */
export declare const getRawMessageContent: API.OperationMethod<GetRawMessageContentRequest & RegionInput, GetRawMessageContentResponse, GetRawMessageContentError, Credentials | HttpClient.HttpClient>;
export type PutRawMessageContentError = InvalidContentLocation | MessageFrozen | MessageRejected | ResourceNotFoundException | CommonErrors;
/**
 * Updates the raw content of an in-transit email message, in MIME format.
 *
 * This example describes how to update in-transit email message. For more information and examples for using this API, see
 *
 * Updating message content with AWS Lambda.
 *
 * Updates to an in-transit message only appear when you call `PutRawMessageContent` from an AWS Lambda function
 * configured with a synchronous
 * Run Lambda rule. If you call `PutRawMessageContent` on a delivered or sent message, the message remains unchanged,
 * even though GetRawMessageContent returns an updated
 * message.
 */
export declare const putRawMessageContent: API.OperationMethod<PutRawMessageContentRequest & RegionInput, PutRawMessageContentResponse, PutRawMessageContentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=workmailmessageflow.d.ts.map