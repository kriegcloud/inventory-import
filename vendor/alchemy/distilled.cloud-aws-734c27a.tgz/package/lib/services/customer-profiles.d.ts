import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type Uuid = string;
export type Name = string;
export type String1To255 = string;
export type RequestValueList = string[];
export interface AddProfileKeyRequest {
    ProfileId: string;
    KeyName: string;
    Values: string[];
    DomainName: string;
}
export interface AddProfileKeyResponse {
    KeyName?: string | undefined;
    Values?: string[] | undefined;
}
export type DestinationArnString = string;
export type DestinationRoleArn = string;
export interface AssociateStreamForSegmentsRequest {
    DomainName: string;
    DestinationArn: string;
    DestinationRoleArn: string;
}
export interface AssociateStreamForSegmentsResponse {
}
export type TypeName = string;
export type BatchGetCalculatedAttributeForProfileIdList = string[];
export type Start = number;
export type End = number;
export type RangeUnit = "DAYS" | (string & {});
export interface RangeOverride {
    Start: number;
    End?: number | undefined;
    Unit: RangeUnit;
}
export interface ConditionOverrides {
    Range?: RangeOverride | undefined;
}
export interface BatchGetCalculatedAttributeForProfileRequest {
    CalculatedAttributeName: string;
    DomainName: string;
    ProfileIds: string[];
    ConditionOverrides?: ConditionOverrides | undefined;
}
export type String1To1000 = string;
export interface BatchGetCalculatedAttributeForProfileError_ {
    Code: string;
    Message: string;
    ProfileId: string;
}
export type BatchGetCalculatedAttributeForProfileErrorList = BatchGetCalculatedAttributeForProfileError_[];
export type DisplayName = string;
export interface CalculatedAttributeValue {
    CalculatedAttributeName?: string | undefined;
    DisplayName?: string | undefined;
    IsDataPartial?: string | undefined;
    ProfileId?: string | undefined;
    Value?: string | undefined;
    LastObjectTimestamp?: Date | undefined;
}
export type CalculatedAttributeValueList = CalculatedAttributeValue[];
export interface BatchGetCalculatedAttributeForProfileResponse {
    Errors?: BatchGetCalculatedAttributeForProfileError_[] | undefined;
    CalculatedAttributeValues?: CalculatedAttributeValue[] | undefined;
    ConditionOverrides?: ConditionOverrides | undefined;
}
export type BatchGetProfileIdList = string[];
export interface BatchGetProfileRequest {
    DomainName: string;
    ProfileIds: string[];
}
export interface BatchGetProfileError_ {
    Code: string;
    Message: string;
    ProfileId: string;
}
export type BatchGetProfileErrorList = BatchGetProfileError_[];
export type SensitiveString1To255 = string | redacted.Redacted<string>;
export type SensitiveString1To1000 = string | redacted.Redacted<string>;
export type PartyType = "INDIVIDUAL" | "BUSINESS" | "OTHER" | (string & {});
export type Gender = "MALE" | "FEMALE" | "UNSPECIFIED" | (string & {});
export interface Address {
    Address1?: string | undefined;
    Address2?: string | undefined;
    Address3?: string | undefined;
    Address4?: string | undefined;
    City?: string | undefined;
    County?: string | undefined;
    State?: string | undefined;
    Province?: string | undefined;
    Country?: string | undefined;
    PostalCode?: string | undefined;
}
export type Attributes = {
    [key: string]: string | undefined;
};
export interface FoundByKeyValue {
    KeyName?: string | undefined;
    Values?: string[] | undefined;
}
export type FoundByList = FoundByKeyValue[];
export type ProfileType = "ACCOUNT_PROFILE" | "PROFILE" | (string & {});
export type ContactType = "PhoneNumber" | "MobilePhoneNumber" | "HomePhoneNumber" | "BusinessPhoneNumber" | "EmailAddress" | "PersonalEmailAddress" | "BusinessEmailAddress" | (string & {});
export interface ContactPreference {
    KeyName?: string | undefined;
    KeyValue?: string | undefined;
    ProfileId?: string | undefined;
    ContactType?: ContactType | undefined;
}
export type PhonePreferenceList = ContactPreference[];
export type EmailPreferenceList = ContactPreference[];
export interface EngagementPreferences {
    Phone?: ContactPreference[] | undefined;
    Email?: ContactPreference[] | undefined;
}
export interface Profile {
    ProfileId?: string | undefined;
    AccountNumber?: string | redacted.Redacted<string> | undefined;
    AdditionalInformation?: string | redacted.Redacted<string> | undefined;
    PartyType?: PartyType | undefined;
    BusinessName?: string | redacted.Redacted<string> | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    MiddleName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    BirthDate?: string | redacted.Redacted<string> | undefined;
    Gender?: Gender | undefined;
    PhoneNumber?: string | redacted.Redacted<string> | undefined;
    MobilePhoneNumber?: string | redacted.Redacted<string> | undefined;
    HomePhoneNumber?: string | redacted.Redacted<string> | undefined;
    BusinessPhoneNumber?: string | redacted.Redacted<string> | undefined;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    PersonalEmailAddress?: string | redacted.Redacted<string> | undefined;
    BusinessEmailAddress?: string | redacted.Redacted<string> | undefined;
    Address?: Address | undefined;
    ShippingAddress?: Address | undefined;
    MailingAddress?: Address | undefined;
    BillingAddress?: Address | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    FoundByItems?: FoundByKeyValue[] | undefined;
    PartyTypeString?: string | redacted.Redacted<string> | undefined;
    GenderString?: string | redacted.Redacted<string> | undefined;
    ProfileType?: ProfileType | undefined;
    EngagementPreferences?: EngagementPreferences | undefined;
}
export type ProfileList = Profile[];
export interface BatchGetProfileResponse {
    Errors?: BatchGetProfileError_[] | undefined;
    Profiles?: Profile[] | undefined;
}
export type StringifiedJson = string | redacted.Redacted<string>;
export interface BatchPutProfileObjectRequestItem {
    Id: string;
    Object: string | redacted.Redacted<string>;
}
export type BatchPutProfileObjectRequestItemList = BatchPutProfileObjectRequestItem[];
export interface BatchPutProfileObjectRequest {
    DomainName: string;
    ObjectTypeName: string;
    Items: BatchPutProfileObjectRequestItem[];
}
export interface BatchPutProfileObjectResponseItem {
    Id: string;
    ProfileObjectUniqueKey: string;
}
export type BatchPutProfileObjectResponseList = BatchPutProfileObjectResponseItem[];
export type ResponseCode = number;
export type Text = string;
export interface BatchPutProfileObjectErrorItem {
    Id: string;
    Code: number;
    Message?: string | undefined;
}
export type BatchPutProfileObjectErrorList = BatchPutProfileObjectErrorItem[];
export interface BatchPutProfileObjectResponse {
    Successful?: BatchPutProfileObjectResponseItem[] | undefined;
    Failed?: BatchPutProfileObjectErrorItem[] | undefined;
}
export type SensitiveText = string | redacted.Redacted<string>;
export type AttributeName = string;
export interface AttributeItem {
    Name: string;
}
export type AttributeList = AttributeItem[];
export interface AttributeDetails {
    Attributes: AttributeItem[];
    Expression: string;
}
export type Value = number;
export type Unit = "DAYS" | (string & {});
export type ValueRangeStart = number;
export type ValueRangeEnd = number;
export interface ValueRange {
    Start: number;
    End: number;
}
export interface Range {
    Value?: number | undefined;
    Unit?: Unit | undefined;
    ValueRange?: ValueRange | undefined;
    TimestampSource?: string | undefined;
    TimestampFormat?: string | undefined;
}
export type ObjectCount = number;
export type Operator = "EQUAL_TO" | "GREATER_THAN" | "LESS_THAN" | "NOT_EQUAL_TO" | (string & {});
export interface Threshold {
    Value: string;
    Operator: Operator;
}
export interface Conditions {
    Range?: Range | undefined;
    ObjectCount?: number | undefined;
    Threshold?: Threshold | undefined;
}
export type Include = "ALL" | "ANY" | "NONE" | (string & {});
export type Type = "ALL" | "ANY" | "NONE" | (string & {});
export type FilterDimensionType = "INCLUSIVE" | "EXCLUSIVE" | "CONTAINS" | "BEGINS_WITH" | "ENDS_WITH" | "BEFORE" | "AFTER" | "BETWEEN" | "NOT_BETWEEN" | "ON" | "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_OR_EQUAL" | "LESS_THAN_OR_EQUAL" | "EQUAL" | (string & {});
export type ValueList = string[];
export interface FilterAttributeDimension {
    DimensionType: FilterDimensionType;
    Values: string[];
}
export type AttributeMap = {
    [key: string]: FilterAttributeDimension | undefined;
};
export interface FilterDimension {
    Attributes: {
        [key: string]: FilterAttributeDimension | undefined;
    };
}
export type FilterDimensionList = FilterDimension[];
export interface FilterGroup {
    Type: Type;
    Dimensions: FilterDimension[];
}
export type GroupList = FilterGroup[];
export interface Filter {
    Include: Include;
    Groups: FilterGroup[];
}
export type Statistic = "FIRST_OCCURRENCE" | "LAST_OCCURRENCE" | "COUNT" | "SUM" | "MINIMUM" | "MAXIMUM" | "AVERAGE" | "MAX_OCCURRENCE" | "RECENT_OCCURRENCES" | (string & {});
export type OptionalBoolean = boolean;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateCalculatedAttributeDefinitionRequest {
    DomainName: string;
    CalculatedAttributeName: string;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    AttributeDetails: AttributeDetails;
    Conditions?: Conditions | undefined;
    Filter?: Filter | undefined;
    Statistic: Statistic;
    UseHistoricalData?: boolean | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ReadinessStatus = "PREPARING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type PercentageInteger = number;
export interface Readiness {
    ProgressPercentage?: number | undefined;
    Message?: string | undefined;
}
export interface CreateCalculatedAttributeDefinitionResponse {
    CalculatedAttributeName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    AttributeDetails?: AttributeDetails | undefined;
    Conditions?: Conditions | undefined;
    Filter?: Filter | undefined;
    Statistic?: Statistic | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    UseHistoricalData?: boolean | undefined;
    Status?: ReadinessStatus | undefined;
    Readiness?: Readiness | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ExpirationDaysInteger = number;
export type EncryptionKey = string;
export type SqsQueueUrl = string;
export type JobScheduleDayOfTheWeek = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export type JobScheduleTime = string;
export interface JobSchedule {
    DayOfTheWeek: JobScheduleDayOfTheWeek;
    Time: string;
}
export type MatchingAttributes = string[];
export type MatchingAttributesList = string[][];
export interface Consolidation {
    MatchingAttributesList: string[][];
}
export type ConflictResolvingModel = "RECENCY" | "SOURCE" | (string & {});
export interface ConflictResolution {
    ConflictResolvingModel: ConflictResolvingModel;
    SourceName?: string | undefined;
}
export type Double0To1 = number;
export interface AutoMerging {
    Enabled: boolean;
    Consolidation?: Consolidation | undefined;
    ConflictResolution?: ConflictResolution | undefined;
    MinAllowedConfidenceScoreForMerging?: number | undefined;
}
export type S3BucketName = string;
export type S3KeyNameCustomerOutputConfig = string;
export interface S3ExportingConfig {
    S3BucketName: string;
    S3KeyName?: string | undefined;
}
export interface ExportingConfig {
    S3Exporting?: S3ExportingConfig | undefined;
}
export interface MatchingRequest {
    Enabled: boolean;
    JobSchedule?: JobSchedule | undefined;
    AutoMerging?: AutoMerging | undefined;
    ExportingConfig?: ExportingConfig | undefined;
}
export type MatchingRuleAttributeList = string[];
export interface MatchingRule {
    Rule: string[];
}
export type MatchingRules = MatchingRule[];
export type MaxAllowedRuleLevelForMerging = number;
export type MaxAllowedRuleLevelForMatching = number;
export type AttributeMatchingModel = "ONE_TO_ONE" | "MANY_TO_MANY" | (string & {});
export type AddressList = string[];
export type PhoneNumberList = string[];
export type EmailList = string[];
export interface AttributeTypesSelector {
    AttributeMatchingModel: AttributeMatchingModel;
    Address?: string[] | undefined;
    PhoneNumber?: string[] | undefined;
    EmailAddress?: string[] | undefined;
}
export interface RuleBasedMatchingRequest {
    Enabled: boolean;
    MatchingRules?: MatchingRule[] | undefined;
    MaxAllowedRuleLevelForMerging?: number | undefined;
    MaxAllowedRuleLevelForMatching?: number | undefined;
    AttributeTypesSelector?: AttributeTypesSelector | undefined;
    ConflictResolution?: ConflictResolution | undefined;
    ExportingConfig?: ExportingConfig | undefined;
}
export interface DataStoreRequest {
    Enabled?: boolean | undefined;
}
export interface CreateDomainRequest {
    DomainName: string;
    DefaultExpirationDays: number;
    DefaultEncryptionKey?: string | undefined;
    DeadLetterQueueUrl?: string | undefined;
    Matching?: MatchingRequest | undefined;
    RuleBasedMatching?: RuleBasedMatchingRequest | undefined;
    DataStore?: DataStoreRequest | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface MatchingResponse {
    Enabled?: boolean | undefined;
    JobSchedule?: JobSchedule | undefined;
    AutoMerging?: AutoMerging | undefined;
    ExportingConfig?: ExportingConfig | undefined;
}
export type RuleBasedMatchingStatus = "PENDING" | "IN_PROGRESS" | "ACTIVE" | (string & {});
export interface RuleBasedMatchingResponse {
    Enabled?: boolean | undefined;
    MatchingRules?: MatchingRule[] | undefined;
    Status?: RuleBasedMatchingStatus | undefined;
    MaxAllowedRuleLevelForMerging?: number | undefined;
    MaxAllowedRuleLevelForMatching?: number | undefined;
    AttributeTypesSelector?: AttributeTypesSelector | undefined;
    ConflictResolution?: ConflictResolution | undefined;
    ExportingConfig?: ExportingConfig | undefined;
}
export interface DataStoreResponse {
    Enabled?: boolean | undefined;
    Readiness?: Readiness | undefined;
}
export interface CreateDomainResponse {
    DomainName: string;
    DefaultExpirationDays: number;
    DefaultEncryptionKey?: string | undefined;
    DeadLetterQueueUrl?: string | undefined;
    Matching?: MatchingResponse | undefined;
    RuleBasedMatching?: RuleBasedMatchingResponse | undefined;
    DataStore?: DataStoreResponse | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type LayoutType = "PROFILE_EXPLORER" | (string & {});
export type SensitiveString1To2000000 = string | redacted.Redacted<string>;
export interface CreateDomainLayoutRequest {
    DomainName: string;
    LayoutDefinitionName: string;
    Description: string | redacted.Redacted<string>;
    DisplayName: string;
    IsDefault?: boolean | undefined;
    LayoutType: LayoutType;
    Layout: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDomainLayoutResponse {
    LayoutDefinitionName: string;
    Description: string | redacted.Redacted<string>;
    DisplayName: string;
    IsDefault?: boolean | undefined;
    LayoutType: LayoutType;
    Layout: string | redacted.Redacted<string>;
    Version: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    CreatedAt: Date;
    LastUpdatedAt?: Date | undefined;
}
export interface CreateEventStreamRequest {
    DomainName: string;
    Uri: string;
    EventStreamName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateEventStreamResponse {
    EventStreamArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type FieldName = string;
export type ComparisonOperator = "INCLUSIVE" | "EXCLUSIVE" | "CONTAINS" | "BEGINS_WITH" | "ENDS_WITH" | "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_OR_EQUAL" | "LESS_THAN_OR_EQUAL" | "EQUAL" | "BEFORE" | "AFTER" | "ON" | "BETWEEN" | "NOT_BETWEEN" | (string & {});
export type EventTriggerValues = string[];
export interface ObjectAttribute {
    Source?: string | undefined;
    FieldName?: string | undefined;
    ComparisonOperator: ComparisonOperator;
    Values: string[];
}
export type ObjectAttributes = ObjectAttribute[];
export interface EventTriggerDimension {
    ObjectAttributes: ObjectAttribute[];
}
export type EventTriggerDimensions = EventTriggerDimension[];
export type EventTriggerLogicalOperator = "ANY" | "ALL" | "NONE" | (string & {});
export interface EventTriggerCondition {
    EventTriggerDimensions: EventTriggerDimension[];
    LogicalOperator: EventTriggerLogicalOperator;
}
export type EventTriggerConditions = EventTriggerCondition[];
export type OptionalLong = number;
export type PeriodUnit = "MINUTES" | "HOURS" | "DAYS" | "WEEKS" | "MONTHS" | (string & {});
export type MaxSize60 = number;
export type MaxSize1000 = number;
export interface Period {
    Unit: PeriodUnit;
    Value: number;
    MaxInvocationsPerProfile?: number | undefined;
    Unlimited?: boolean | undefined;
}
export type Periods = Period[];
export interface EventTriggerLimits {
    EventExpiration?: number | undefined;
    Periods?: Period[] | undefined;
}
export interface CreateEventTriggerRequest {
    DomainName: string;
    EventTriggerName: string;
    ObjectTypeName: string;
    Description?: string | redacted.Redacted<string> | undefined;
    EventTriggerConditions: EventTriggerCondition[];
    SegmentFilter?: string | undefined;
    EventTriggerLimits?: EventTriggerLimits | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateEventTriggerResponse {
    EventTriggerName?: string | undefined;
    ObjectTypeName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    EventTriggerConditions?: EventTriggerCondition[] | undefined;
    SegmentFilter?: string | undefined;
    EventTriggerLimits?: EventTriggerLimits | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type WorkflowType = "APPFLOW_INTEGRATION" | (string & {});
export type FlowDescription = string;
export type FlowName = string;
export type KmsArn = string;
export type ConnectorProfileName = string;
export type SourceConnectorType = "Salesforce" | "Marketo" | "Zendesk" | "Servicenow" | "S3" | (string & {});
export type DatetimeTypeFieldName = string;
export interface IncrementalPullConfig {
    DatetimeTypeFieldName?: string | undefined;
}
export interface MarketoSourceProperties {
    Object: string;
}
export type BucketName = string;
export type BucketPrefix = string;
export interface S3SourceProperties {
    BucketName: string;
    BucketPrefix?: string | undefined;
}
export interface SalesforceSourceProperties {
    Object: string;
    EnableDynamicFieldUpdate?: boolean | undefined;
    IncludeDeletedRecords?: boolean | undefined;
}
export interface ServiceNowSourceProperties {
    Object: string;
}
export interface ZendeskSourceProperties {
    Object: string;
}
export interface SourceConnectorProperties {
    Marketo?: MarketoSourceProperties | undefined;
    S3?: S3SourceProperties | undefined;
    Salesforce?: SalesforceSourceProperties | undefined;
    ServiceNow?: ServiceNowSourceProperties | undefined;
    Zendesk?: ZendeskSourceProperties | undefined;
}
export interface SourceFlowConfig {
    ConnectorProfileName?: string | undefined;
    ConnectorType: SourceConnectorType;
    IncrementalPullConfig?: IncrementalPullConfig | undefined;
    SourceConnectorProperties: SourceConnectorProperties;
}
export type MarketoConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type S3ConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SalesforceConnectorOperator = "PROJECTION" | "LESS_THAN" | "CONTAINS" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type ServiceNowConnectorOperator = "PROJECTION" | "CONTAINS" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type ZendeskConnectorOperator = "PROJECTION" | "GREATER_THAN" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export interface ConnectorOperator {
    Marketo?: MarketoConnectorOperator | undefined;
    S3?: S3ConnectorOperator | undefined;
    Salesforce?: SalesforceConnectorOperator | undefined;
    ServiceNow?: ServiceNowConnectorOperator | undefined;
    Zendesk?: ZendeskConnectorOperator | undefined;
}
export type DestinationField = string;
export type StringTo2048 = string;
export type SourceFields = string[];
export type OperatorPropertiesKeys = "VALUE" | "VALUES" | "DATA_TYPE" | "UPPER_BOUND" | "LOWER_BOUND" | "SOURCE_DATA_TYPE" | "DESTINATION_DATA_TYPE" | "VALIDATION_ACTION" | "MASK_VALUE" | "MASK_LENGTH" | "TRUNCATE_LENGTH" | "MATH_OPERATION_FIELDS_ORDER" | "CONCAT_FORMAT" | "SUBFIELD_CATEGORY_MAP" | (string & {});
export type Property = string;
export type TaskPropertiesMap = {
    [key in OperatorPropertiesKeys]?: string | undefined;
};
export type TaskType = "Arithmetic" | "Filter" | "Map" | "Mask" | "Merge" | "Truncate" | "Validate" | (string & {});
export interface Task {
    ConnectorOperator?: ConnectorOperator | undefined;
    DestinationField?: string | undefined;
    SourceFields: string[];
    TaskProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    TaskType: TaskType;
}
export type Tasks = Task[];
export type TriggerType = "Scheduled" | "Event" | "OnDemand" | (string & {});
export type ScheduleExpression = string;
export type DataPullMode = "Incremental" | "Complete" | (string & {});
export type Timezone = string;
export type ScheduleOffset = number;
export interface ScheduledTriggerProperties {
    ScheduleExpression: string;
    DataPullMode?: DataPullMode | undefined;
    ScheduleStartTime?: Date | undefined;
    ScheduleEndTime?: Date | undefined;
    Timezone?: string | undefined;
    ScheduleOffset?: number | undefined;
    FirstExecutionFrom?: Date | undefined;
}
export interface TriggerProperties {
    Scheduled?: ScheduledTriggerProperties | undefined;
}
export interface TriggerConfig {
    TriggerType: TriggerType;
    TriggerProperties?: TriggerProperties | undefined;
}
export interface FlowDefinition {
    Description?: string | undefined;
    FlowName: string;
    KmsArn: string;
    SourceFlowConfig: SourceFlowConfig;
    Tasks: Task[];
    TriggerConfig: TriggerConfig;
}
export interface Batch {
    StartTime: Date;
    EndTime: Date;
}
export type Batches = Batch[];
export interface AppflowIntegration {
    FlowDefinition: FlowDefinition;
    Batches?: Batch[] | undefined;
}
export interface IntegrationConfig {
    AppflowIntegration?: AppflowIntegration | undefined;
}
export type RoleArn = string;
export interface CreateIntegrationWorkflowRequest {
    DomainName: string;
    WorkflowType: WorkflowType;
    IntegrationConfig: IntegrationConfig;
    ObjectTypeName: string;
    RoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateIntegrationWorkflowResponse {
    WorkflowId: string;
    Message: string;
}
export interface CreateProfileRequest {
    DomainName: string;
    AccountNumber?: string | redacted.Redacted<string> | undefined;
    AdditionalInformation?: string | redacted.Redacted<string> | undefined;
    PartyType?: PartyType | undefined;
    BusinessName?: string | redacted.Redacted<string> | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    MiddleName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    BirthDate?: string | redacted.Redacted<string> | undefined;
    Gender?: Gender | undefined;
    PhoneNumber?: string | redacted.Redacted<string> | undefined;
    MobilePhoneNumber?: string | redacted.Redacted<string> | undefined;
    HomePhoneNumber?: string | redacted.Redacted<string> | undefined;
    BusinessPhoneNumber?: string | redacted.Redacted<string> | undefined;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    PersonalEmailAddress?: string | redacted.Redacted<string> | undefined;
    BusinessEmailAddress?: string | redacted.Redacted<string> | undefined;
    Address?: Address | undefined;
    ShippingAddress?: Address | undefined;
    MailingAddress?: Address | undefined;
    BillingAddress?: Address | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    PartyTypeString?: string | redacted.Redacted<string> | undefined;
    GenderString?: string | redacted.Redacted<string> | undefined;
    ProfileType?: ProfileType | undefined;
    EngagementPreferences?: EngagementPreferences | undefined;
}
export interface CreateProfileResponse {
    ProfileId: string;
}
export type RecommenderRecipeName = "recommended-for-you" | "similar-items" | "frequently-paired-items" | "popular-items" | "trending-now" | "personalized-ranking" | (string & {});
export type EventParametersEventTypeString = string;
export type EventParametersEventWeightDouble = number;
export interface EventParameters {
    EventType: string;
    EventValueThreshold?: number | undefined;
    EventWeight?: number | undefined;
}
export type EventParametersList = EventParameters[];
export interface EventsConfig {
    EventParametersList: EventParameters[];
}
export type RecommenderConfigTrainingFrequencyInteger = number;
export type InferenceConfigMinProvisionedTPSInteger = number;
export interface InferenceConfig {
    MinProvisionedTPS?: number | undefined;
}
export type ColumnNamesList = string[];
export type IncludedColumns = {
    [key: string]: string[] | undefined;
};
export type DiversityCapType = "PERCENTAGE" | "VALUE" | (string & {});
export type DiversityTargetExpression = string;
export interface DiversityColumn {
    Name: string;
    CapType: DiversityCapType;
    Target: string;
}
export type DiversityColumnsList = DiversityColumn[];
export interface DiversityConfig {
    DiversityColumns?: DiversityColumn[] | undefined;
}
export interface RecommenderConfig {
    EventsConfig?: EventsConfig | undefined;
    TrainingFrequency?: number | undefined;
    InferenceConfig?: InferenceConfig | undefined;
    IncludedColumns?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ExcludedColumns?: {
        [key: string]: string[] | undefined;
    } | undefined;
    DiversityConfig?: DiversityConfig | undefined;
}
export interface CreateRecommenderRequest {
    DomainName: string;
    RecommenderName: string;
    RecommenderRecipeName: RecommenderRecipeName;
    RecommenderConfig?: RecommenderConfig | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    RecommenderSchemaName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Arn = string;
export interface CreateRecommenderResponse {
    RecommenderArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RecommenderFilterName = string;
export type RecommenderFilterExpression = string | redacted.Redacted<string>;
export interface CreateRecommenderFilterRequest {
    DomainName: string;
    RecommenderFilterName: string;
    RecommenderFilterExpression: string | redacted.Redacted<string>;
    RecommenderSchemaName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateRecommenderFilterResponse {
    RecommenderFilterArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ContentType = "STRING" | "NUMBER" | (string & {});
export type FeatureType = "TEXTUAL" | "CATEGORICAL" | (string & {});
export interface RecommenderSchemaField {
    TargetFieldName: string;
    ContentType?: ContentType | undefined;
    FeatureType?: FeatureType | undefined;
}
export type RecommenderSchemaFieldList = RecommenderSchemaField[];
export type RecommenderSchemaFields = {
    [key: string]: RecommenderSchemaField[] | undefined;
};
export interface CreateRecommenderSchemaRequest {
    DomainName: string;
    RecommenderSchemaName: string;
    Fields: {
        [key: string]: RecommenderSchemaField[] | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RecommenderSchemaStatus = "ACTIVE" | "DELETING" | (string & {});
export interface CreateRecommenderSchemaResponse {
    RecommenderSchemaArn: string;
    RecommenderSchemaName: string;
    Fields: {
        [key: string]: RecommenderSchemaField[] | undefined;
    };
    CreatedAt: Date;
    Status: RecommenderSchemaStatus;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SensitiveString1To4000 = string | redacted.Redacted<string>;
export type StringDimensionType = "INCLUSIVE" | "EXCLUSIVE" | "CONTAINS" | "BEGINS_WITH" | "ENDS_WITH" | (string & {});
export type Values = string[];
export interface ProfileDimension {
    DimensionType: StringDimensionType;
    Values: string[];
}
export type ExtraLengthValues = string[];
export interface ExtraLengthValueProfileDimension {
    DimensionType: StringDimensionType;
    Values: string[];
}
export type DateDimensionType = "BEFORE" | "AFTER" | "BETWEEN" | "NOT_BETWEEN" | "ON" | (string & {});
export type DateValues = string[];
export interface DateDimension {
    DimensionType: DateDimensionType;
    Values: string[];
}
export interface AddressDimension {
    City?: ProfileDimension | undefined;
    Country?: ProfileDimension | undefined;
    County?: ProfileDimension | undefined;
    PostalCode?: ProfileDimension | undefined;
    Province?: ProfileDimension | undefined;
    State?: ProfileDimension | undefined;
}
export type AttributeDimensionType = "INCLUSIVE" | "EXCLUSIVE" | "CONTAINS" | "BEGINS_WITH" | "ENDS_WITH" | "BEFORE" | "AFTER" | "BETWEEN" | "NOT_BETWEEN" | "ON" | "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_OR_EQUAL" | "LESS_THAN_OR_EQUAL" | "EQUAL" | "LIST_CONTAINS" | "LIST_CONTAINS_ALL" | (string & {});
export interface AttributeDimension {
    DimensionType: AttributeDimensionType;
    Values: string[];
}
export type CustomAttributes = {
    [key: string]: AttributeDimension | undefined;
};
export type ProfileTypeDimensionType = "INCLUSIVE" | "EXCLUSIVE" | (string & {});
export type ProfileTypeValues = ProfileType[];
export interface ProfileTypeDimension {
    DimensionType: ProfileTypeDimensionType;
    Values: ProfileType[];
}
export interface ProfileAttributes {
    AccountNumber?: ProfileDimension | undefined;
    AdditionalInformation?: ExtraLengthValueProfileDimension | undefined;
    FirstName?: ProfileDimension | undefined;
    LastName?: ProfileDimension | undefined;
    MiddleName?: ProfileDimension | undefined;
    GenderString?: ProfileDimension | undefined;
    PartyTypeString?: ProfileDimension | undefined;
    BirthDate?: DateDimension | undefined;
    PhoneNumber?: ProfileDimension | undefined;
    BusinessName?: ProfileDimension | undefined;
    BusinessPhoneNumber?: ProfileDimension | undefined;
    HomePhoneNumber?: ProfileDimension | undefined;
    MobilePhoneNumber?: ProfileDimension | undefined;
    EmailAddress?: ProfileDimension | undefined;
    PersonalEmailAddress?: ProfileDimension | undefined;
    BusinessEmailAddress?: ProfileDimension | undefined;
    Address?: AddressDimension | undefined;
    ShippingAddress?: AddressDimension | undefined;
    MailingAddress?: AddressDimension | undefined;
    BillingAddress?: AddressDimension | undefined;
    Attributes?: {
        [key: string]: AttributeDimension | undefined;
    } | undefined;
    ProfileType?: ProfileTypeDimension | undefined;
}
export interface CalculatedAttributeDimension {
    DimensionType: AttributeDimensionType;
    Values: string[];
    ConditionOverrides?: ConditionOverrides | undefined;
}
export type CalculatedCustomAttributes = {
    [key: string]: CalculatedAttributeDimension | undefined;
};
export type Dimension = {
    ProfileAttributes: ProfileAttributes;
    CalculatedAttributes?: undefined;
} | {
    ProfileAttributes?: undefined;
    CalculatedAttributes: {
        [key: string]: CalculatedAttributeDimension | undefined;
    };
};
export type DimensionList = Dimension[];
export interface SourceSegment {
    SegmentDefinitionName?: string | undefined;
}
export type SourceSegmentList = SourceSegment[];
export type IncludeOptions = "ALL" | "ANY" | "NONE" | (string & {});
export interface Group {
    Dimensions?: Dimension[] | undefined;
    SourceSegments?: SourceSegment[] | undefined;
    SourceType?: IncludeOptions | undefined;
    Type?: IncludeOptions | undefined;
}
export type SegmentGroupList = Group[];
export interface SegmentGroup {
    Groups?: Group[] | undefined;
    Include?: IncludeOptions | undefined;
}
export type SensitiveString1To50000 = string | redacted.Redacted<string>;
export type SegmentSortDataType = "STRING" | "NUMBER" | "DATE" | (string & {});
export type SegmentSortOrder = "ASC" | "DESC" | (string & {});
export type SortAttributeType = "PROFILE" | "CALCULATED" | (string & {});
export interface SortAttribute {
    Name: string;
    DataType?: SegmentSortDataType | undefined;
    Order: SegmentSortOrder;
    Type?: SortAttributeType | undefined;
}
export type SortAttributeList = SortAttribute[];
export interface SegmentSort {
    Attributes: SortAttribute[];
}
export interface CreateSegmentDefinitionRequest {
    DomainName: string;
    SegmentDefinitionName: string;
    DisplayName: string;
    Description?: string | redacted.Redacted<string> | undefined;
    SegmentGroups?: SegmentGroup | undefined;
    SegmentSqlQuery?: string | redacted.Redacted<string> | undefined;
    SegmentSort?: SegmentSort | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SegmentDefinitionArn = string;
export interface CreateSegmentDefinitionResponse {
    SegmentDefinitionName: string;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    SegmentDefinitionArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface SegmentGroupStructure {
    Groups?: Group[] | undefined;
    Include?: IncludeOptions | undefined;
}
export interface CreateSegmentEstimateRequest {
    DomainName: string;
    SegmentQuery?: SegmentGroupStructure | undefined;
    SegmentSqlQuery?: string | redacted.Redacted<string> | undefined;
}
export type StatusCode = number;
export interface CreateSegmentEstimateResponse {
    DomainName?: string | undefined;
    EstimateId?: string | undefined;
    StatusCode?: number | undefined;
}
export type DataFormat = "CSV" | "JSONL" | "ORC" | (string & {});
export interface CreateSegmentSnapshotRequest {
    DomainName: string;
    SegmentDefinitionName: string;
    DataFormat: DataFormat;
    EncryptionKey?: string | undefined;
    RoleArn?: string | undefined;
    DestinationUri?: string | undefined;
}
export interface CreateSegmentSnapshotResponse {
    SnapshotId: string;
}
export type FieldContentType = "STRING" | "NUMBER" | "PHONE_NUMBER" | "EMAIL_ADDRESS" | "NAME" | (string & {});
export interface ObjectTypeField {
    Source?: string | undefined;
    Target?: string | undefined;
    ContentType?: FieldContentType | undefined;
}
export type FieldMap = {
    [key: string]: ObjectTypeField | undefined;
};
export interface CreateUploadJobRequest {
    DomainName: string;
    DisplayName: string;
    Fields: {
        [key: string]: ObjectTypeField | undefined;
    };
    UniqueKey: string;
    DataExpiry?: number | undefined;
}
export interface CreateUploadJobResponse {
    JobId: string;
}
export interface DeleteCalculatedAttributeDefinitionRequest {
    DomainName: string;
    CalculatedAttributeName: string;
}
export interface DeleteCalculatedAttributeDefinitionResponse {
}
export interface DeleteDomainRequest {
    DomainName: string;
}
export type Message = string;
export interface DeleteDomainResponse {
    Message: string;
}
export interface DeleteDomainLayoutRequest {
    DomainName: string;
    LayoutDefinitionName: string;
}
export interface DeleteDomainLayoutResponse {
    Message: string;
}
export interface DeleteDomainObjectTypeRequest {
    DomainName: string;
    ObjectTypeName: string;
}
export interface DeleteDomainObjectTypeResponse {
}
export interface DeleteEventStreamRequest {
    DomainName: string;
    EventStreamName: string;
}
export interface DeleteEventStreamResponse {
}
export interface DeleteEventTriggerRequest {
    DomainName: string;
    EventTriggerName: string;
}
export interface DeleteEventTriggerResponse {
    Message: string;
}
export interface DeleteIntegrationRequest {
    DomainName: string;
    Uri: string;
}
export interface DeleteIntegrationResponse {
    Message: string;
}
export interface DeleteProfileRequest {
    ProfileId: string;
    DomainName: string;
}
export interface DeleteProfileResponse {
    Message?: string | undefined;
}
export interface DeleteProfileKeyRequest {
    ProfileId: string;
    KeyName: string;
    Values: string[];
    DomainName: string;
}
export interface DeleteProfileKeyResponse {
    Message?: string | undefined;
}
export interface DeleteProfileObjectRequest {
    ProfileId: string;
    ProfileObjectUniqueKey: string;
    ObjectTypeName: string;
    DomainName: string;
}
export interface DeleteProfileObjectResponse {
    Message?: string | undefined;
}
export interface DeleteProfileObjectTypeRequest {
    DomainName: string;
    ObjectTypeName: string;
}
export interface DeleteProfileObjectTypeResponse {
    Message: string;
}
export interface DeleteRecommenderRequest {
    DomainName: string;
    RecommenderName: string;
}
export interface DeleteRecommenderResponse {
}
export interface DeleteRecommenderFilterRequest {
    DomainName: string;
    RecommenderFilterName: string;
}
export interface DeleteRecommenderFilterResponse {
    Message: string;
}
export interface DeleteRecommenderSchemaRequest {
    DomainName: string;
    RecommenderSchemaName: string;
}
export interface DeleteRecommenderSchemaResponse {
}
export interface DeleteSegmentDefinitionRequest {
    DomainName: string;
    SegmentDefinitionName: string;
}
export interface DeleteSegmentDefinitionResponse {
    Message?: string | undefined;
}
export interface DeleteSegmentSubscriptionRequest {
    DomainName: string;
    SegmentDefinitionName: string;
}
export interface DeleteSegmentSubscriptionResponse {
    Message?: string | undefined;
}
export interface DeleteWorkflowRequest {
    DomainName: string;
    WorkflowId: string;
}
export interface DeleteWorkflowResponse {
}
export type Objects = (string | redacted.Redacted<string>)[];
export interface DetectProfileObjectTypeRequest {
    Objects: (string | redacted.Redacted<string>)[];
    DomainName: string;
}
export type StandardIdentifier = "PROFILE" | "ASSET" | "CASE" | "DEVICE" | "WEB_ANALYTICS" | "ORDER" | "COMMUNICATION_RECORD" | "AIR_PREFERENCE" | "HOTEL_PREFERENCE" | "AIR_BOOKING" | "AIR_SEGMENT" | "HOTEL_RESERVATION" | "HOTEL_STAY_REVENUE" | "LOYALTY" | "LOYALTY_TRANSACTION" | "LOYALTY_PROMOTION" | "UNIQUE" | "SECONDARY" | "LOOKUP_ONLY" | "NEW_ONLY" | (string & {});
export type StandardIdentifierList = StandardIdentifier[];
export type FieldNameList = string[];
export interface ObjectTypeKey {
    StandardIdentifiers?: StandardIdentifier[] | undefined;
    FieldNames?: string[] | undefined;
}
export type ObjectTypeKeyList = ObjectTypeKey[];
export type KeyMap = {
    [key: string]: ObjectTypeKey[] | undefined;
};
export interface DetectedProfileObjectType {
    SourceLastUpdatedTimestampFormat?: string | undefined;
    Fields?: {
        [key: string]: ObjectTypeField | undefined;
    } | undefined;
    Keys?: {
        [key: string]: ObjectTypeKey[] | undefined;
    } | undefined;
}
export type DetectedProfileObjectTypes = DetectedProfileObjectType[];
export interface DetectProfileObjectTypeResponse {
    DetectedProfileObjectTypes?: DetectedProfileObjectType[] | undefined;
}
export interface DisassociateStreamForSegmentsRequest {
    DomainName: string;
}
export interface DisassociateStreamForSegmentsResponse {
    Message?: string | undefined;
}
export interface GetAutoMergingPreviewRequest {
    DomainName: string;
    Consolidation: Consolidation;
    ConflictResolution: ConflictResolution;
    MinAllowedConfidenceScoreForMerging?: number | undefined;
}
export interface GetAutoMergingPreviewResponse {
    DomainName: string;
    NumberOfMatchesInSample?: number | undefined;
    NumberOfProfilesInSample?: number | undefined;
    NumberOfProfilesWillBeMerged?: number | undefined;
}
export interface GetCalculatedAttributeDefinitionRequest {
    DomainName: string;
    CalculatedAttributeName: string;
}
export interface GetCalculatedAttributeDefinitionResponse {
    CalculatedAttributeName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Statistic?: Statistic | undefined;
    Filter?: Filter | undefined;
    Conditions?: Conditions | undefined;
    AttributeDetails?: AttributeDetails | undefined;
    UseHistoricalData?: boolean | undefined;
    Status?: ReadinessStatus | undefined;
    Readiness?: Readiness | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetCalculatedAttributeForProfileRequest {
    DomainName: string;
    ProfileId: string;
    CalculatedAttributeName: string;
}
export interface GetCalculatedAttributeForProfileResponse {
    CalculatedAttributeName?: string | undefined;
    DisplayName?: string | undefined;
    IsDataPartial?: string | undefined;
    Value?: string | undefined;
    LastObjectTimestamp?: Date | undefined;
}
export interface GetDomainRequest {
    DomainName: string;
}
export interface DomainStats {
    ProfileCount?: number | undefined;
    MeteringProfileCount?: number | undefined;
    ObjectCount?: number | undefined;
    TotalSize?: number | undefined;
}
export interface GetDomainResponse {
    DomainName: string;
    DefaultExpirationDays?: number | undefined;
    DefaultEncryptionKey?: string | undefined;
    DeadLetterQueueUrl?: string | undefined;
    Stats?: DomainStats | undefined;
    Matching?: MatchingResponse | undefined;
    RuleBasedMatching?: RuleBasedMatchingResponse | undefined;
    DataStore?: DataStoreResponse | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDomainLayoutRequest {
    DomainName: string;
    LayoutDefinitionName: string;
}
export interface GetDomainLayoutResponse {
    LayoutDefinitionName: string;
    Description: string | redacted.Redacted<string>;
    DisplayName: string;
    IsDefault?: boolean | undefined;
    LayoutType: LayoutType;
    Layout: string | redacted.Redacted<string>;
    Version: string;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDomainObjectTypeRequest {
    DomainName: string;
    ObjectTypeName: string;
}
export type SensitiveString1To10000 = string | redacted.Redacted<string>;
export type DomainObjectTypeFieldName = string;
export interface DomainObjectTypeField {
    Source: string;
    Target: string;
    ContentType?: ContentType | undefined;
    FeatureType?: FeatureType | undefined;
}
export type DomainObjectTypeFields = {
    [key: string]: DomainObjectTypeField | undefined;
};
export interface GetDomainObjectTypeResponse {
    ObjectTypeName: string;
    Description?: string | redacted.Redacted<string> | undefined;
    EncryptionKey?: string | undefined;
    Fields?: {
        [key: string]: DomainObjectTypeField | undefined;
    } | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetEventStreamRequest {
    DomainName: string;
    EventStreamName: string;
}
export type EventStreamState = "RUNNING" | "STOPPED" | (string & {});
export type EventStreamDestinationStatus = "HEALTHY" | "UNHEALTHY" | (string & {});
export interface EventStreamDestinationDetails {
    Uri: string;
    Status: EventStreamDestinationStatus;
    UnhealthySince?: Date | undefined;
    Message?: string | undefined;
}
export interface GetEventStreamResponse {
    DomainName: string;
    EventStreamArn: string;
    CreatedAt: Date;
    State: EventStreamState;
    StoppedSince?: Date | undefined;
    DestinationDetails: EventStreamDestinationDetails;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetEventTriggerRequest {
    DomainName: string;
    EventTriggerName: string;
}
export interface GetEventTriggerResponse {
    EventTriggerName?: string | undefined;
    ObjectTypeName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    EventTriggerConditions?: EventTriggerCondition[] | undefined;
    SegmentFilter?: string | undefined;
    EventTriggerLimits?: EventTriggerLimits | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetIdentityResolutionJobRequest {
    DomainName: string;
    JobId: string;
}
export type IdentityResolutionJobStatus = "PENDING" | "PREPROCESSING" | "FIND_MATCHING" | "MERGING" | "COMPLETED" | "PARTIAL_SUCCESS" | "FAILED" | (string & {});
export type S3KeyName = string;
export interface S3ExportingLocation {
    S3BucketName?: string | undefined;
    S3KeyName?: string | undefined;
}
export interface ExportingLocation {
    S3Exporting?: S3ExportingLocation | undefined;
}
export interface JobStats {
    NumberOfProfilesReviewed?: number | undefined;
    NumberOfMatchesFound?: number | undefined;
    NumberOfMergesDone?: number | undefined;
}
export interface GetIdentityResolutionJobResponse {
    DomainName?: string | undefined;
    JobId?: string | undefined;
    Status?: IdentityResolutionJobStatus | undefined;
    Message?: string | undefined;
    JobStartTime?: Date | undefined;
    JobEndTime?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    JobExpirationTime?: Date | undefined;
    AutoMerging?: AutoMerging | undefined;
    ExportingLocation?: ExportingLocation | undefined;
    JobStats?: JobStats | undefined;
}
export interface GetIntegrationRequest {
    DomainName: string;
    Uri: string;
}
export type ObjectTypeNames = {
    [key: string]: string | undefined;
};
export type EventTriggerNames = string[];
export type Scope = "PROFILE" | "DOMAIN" | (string & {});
export interface GetIntegrationResponse {
    DomainName: string;
    Uri: string;
    ObjectTypeName?: string | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ObjectTypeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    WorkflowId?: string | undefined;
    IsUnstructured?: boolean | undefined;
    RoleArn?: string | undefined;
    EventTriggerNames?: string[] | undefined;
    Scope?: Scope | undefined;
}
export type Token = string;
export type MaxSize100 = number;
export interface GetMatchesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DomainName: string;
}
export type MatchesNumber = number;
export type ProfileIdList = string[];
export interface MatchItem {
    MatchId?: string | undefined;
    ProfileIds?: string[] | undefined;
    ConfidenceScore?: number | undefined;
}
export type MatchesList = MatchItem[];
export interface GetMatchesResponse {
    NextToken?: string | undefined;
    MatchGenerationDate?: Date | undefined;
    PotentialMatches?: number | undefined;
    Matches?: MatchItem[] | undefined;
}
export interface GetObjectTypeAttributeStatisticsRequest {
    DomainName: string;
    ObjectTypeName: string;
    AttributeName: string;
}
export interface GetObjectTypeAttributeStatisticsPercentiles {
    P5: number;
    P25: number;
    P50: number;
    P75: number;
    P95: number;
}
export interface GetObjectTypeAttributeStatisticsStats {
    Maximum: number;
    Minimum: number;
    Average: number;
    StandardDeviation: number;
    Percentiles: GetObjectTypeAttributeStatisticsPercentiles;
}
export interface GetObjectTypeAttributeStatisticsResponse {
    Statistics: GetObjectTypeAttributeStatisticsStats;
    CalculatedAt: Date;
}
export interface GetProfileHistoryRecordRequest {
    DomainName: string;
    ProfileId: string;
    Id: string;
}
export type ActionType = "ADDED_PROFILE_KEY" | "DELETED_PROFILE_KEY" | "CREATED" | "UPDATED" | "INGESTED" | "DELETED_BY_CUSTOMER" | "EXPIRED" | "MERGED" | "DELETED_BY_MERGE" | (string & {});
export interface GetProfileHistoryRecordResponse {
    Id: string;
    ObjectTypeName: string;
    CreatedAt: Date;
    LastUpdatedAt?: Date | undefined;
    ActionType: ActionType;
    ProfileObjectUniqueKey?: string | undefined;
    Content?: string | redacted.Redacted<string> | undefined;
    PerformedBy?: string | undefined;
}
export interface GetProfileObjectTypeRequest {
    DomainName: string;
    ObjectTypeName: string;
}
export type MinSize0 = number;
export type MinSize1 = number;
export interface GetProfileObjectTypeResponse {
    ObjectTypeName: string;
    Description: string | redacted.Redacted<string>;
    TemplateId?: string | undefined;
    ExpirationDays?: number | undefined;
    EncryptionKey?: string | undefined;
    AllowProfileCreation?: boolean | undefined;
    SourceLastUpdatedTimestampFormat?: string | undefined;
    MaxAvailableProfileObjectCount?: number | undefined;
    MaxProfileObjectCount?: number | undefined;
    SourcePriority?: number | undefined;
    Fields?: {
        [key: string]: ObjectTypeField | undefined;
    } | undefined;
    Keys?: {
        [key: string]: ObjectTypeKey[] | undefined;
    } | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetProfileObjectTypeTemplateRequest {
    TemplateId: string;
}
export interface GetProfileObjectTypeTemplateResponse {
    TemplateId?: string | undefined;
    SourceName?: string | undefined;
    SourceObject?: string | undefined;
    DefaultMaxProfileObjectCount?: number | undefined;
    DefaultMaxProfileObjectCountEffectiveAfter?: Date | undefined;
    StoreOnly?: boolean | undefined;
    AllowProfileCreation?: boolean | undefined;
    SourceLastUpdatedTimestampFormat?: string | undefined;
    Fields?: {
        [key: string]: ObjectTypeField | undefined;
    } | undefined;
    Keys?: {
        [key: string]: ObjectTypeKey[] | undefined;
    } | undefined;
}
export type ContextKey = string;
export type RecommenderContext = {
    [key: string]: string | undefined;
};
export type RecommenderFilterAttributeName = string;
export type RecommenderFilterAttributeValue = string | redacted.Redacted<string>;
export type RecommenderFilterValues = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface RecommenderFilter {
    Name?: string | undefined;
    Values?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export type RecommenderFilters = RecommenderFilter[];
export type PercentPromotedItems = number;
export interface RecommenderPromotionalFilter {
    Name?: string | undefined;
    Values?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    PromotionName?: string | undefined;
    PercentPromotedItems?: number | undefined;
}
export type RecommenderPromotionalFilters = RecommenderPromotionalFilter[];
export type CandidateIdList = string[];
export type MaxSize500 = number;
export type MetadataColumnName = string;
export type MetadataColumnsList = string[];
export interface MetadataConfig {
    MetadataColumns?: string[] | undefined;
}
export type DiversityPlaceholderName = string;
export type DiversityCapValue = number;
export type DiversityValuesMap = {
    [key: string]: number | undefined;
};
export interface RecommendationDiversityConfig {
    Enabled: boolean;
    Values?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface GetProfileRecommendationsRequest {
    DomainName: string;
    ProfileId: string;
    RecommenderName: string;
    Context?: {
        [key: string]: string | undefined;
    } | undefined;
    RecommenderFilters?: RecommenderFilter[] | undefined;
    RecommenderPromotionalFilters?: RecommenderPromotionalFilter[] | undefined;
    CandidateIds?: string[] | undefined;
    MaxResults?: number | undefined;
    MetadataConfig?: MetadataConfig | undefined;
    DiversityConfig?: RecommendationDiversityConfig | undefined;
}
export interface CatalogItem {
    Id?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Code?: string | redacted.Redacted<string> | undefined;
    Type?: string | redacted.Redacted<string> | undefined;
    Category?: string | redacted.Redacted<string> | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    AdditionalInformation?: string | redacted.Redacted<string> | undefined;
    ImageLink?: string | redacted.Redacted<string> | undefined;
    Link?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    Price?: string | redacted.Redacted<string> | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Recommendation {
    CatalogItem?: CatalogItem | undefined;
    Score?: number | undefined;
}
export type Recommendations = Recommendation[];
export interface GetProfileRecommendationsResponse {
    Recommendations?: Recommendation[] | undefined;
}
export type GetRecommenderRequestTrainingMetricsCountInteger = number;
export interface GetRecommenderRequest {
    DomainName: string;
    RecommenderName: string;
    TrainingMetricsCount?: number | undefined;
}
export type RecommenderStatus = "PENDING" | "IN_PROGRESS" | "ACTIVE" | "FAILED" | "STOPPING" | "INACTIVE" | "STARTING" | "DELETING" | (string & {});
export type RecommenderVersionName = string;
export interface RecommenderUpdate {
    RecommenderConfig?: RecommenderConfig | undefined;
    Status?: RecommenderStatus | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    FailureReason?: string | undefined;
    RecommenderVersionName?: string | undefined;
}
export type TrainingMetricName = "hit" | "coverage" | "recall" | "popularity" | "freshness" | "similarity" | "mean_reciprocal_rank_at_25" | "normalized_discounted_cumulative_gain_at_5" | "normalized_discounted_cumulative_gain_at_10" | "normalized_discounted_cumulative_gain_at_25" | "precision_at_5" | "precision_at_10" | "precision_at_25" | (string & {});
export type Metrics = {
    [key in TrainingMetricName]?: number | undefined;
};
export interface TrainingMetrics {
    Time?: Date | undefined;
    Metrics?: {
        [key: string]: number | undefined;
    } | undefined;
    RecommenderVersionName?: string | undefined;
}
export type TrainingMetricsList = TrainingMetrics[];
export interface GetRecommenderResponse {
    RecommenderName: string;
    RecommenderRecipeName: RecommenderRecipeName;
    RecommenderSchemaName?: string | undefined;
    RecommenderConfig?: RecommenderConfig | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Status?: RecommenderStatus | undefined;
    LastUpdatedAt?: Date | undefined;
    CreatedAt?: Date | undefined;
    FailureReason?: string | undefined;
    LatestRecommenderUpdate?: RecommenderUpdate | undefined;
    ActiveRecommenderVersionName?: string | undefined;
    TrainingMetrics?: TrainingMetrics[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetRecommenderFilterRequest {
    DomainName: string;
    RecommenderFilterName: string;
}
export type RecommenderFilterStatus = "ACTIVE" | "PENDING" | "IN_PROGRESS" | "FAILED" | "DELETING" | (string & {});
export interface GetRecommenderFilterResponse {
    RecommenderFilterName: string;
    RecommenderFilterExpression: string | redacted.Redacted<string>;
    RecommenderSchemaName?: string | undefined;
    CreatedAt: Date;
    Status: RecommenderFilterStatus;
    Description?: string | redacted.Redacted<string> | undefined;
    FailureReason?: string | undefined;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface GetRecommenderSchemaRequest {
    DomainName: string;
    RecommenderSchemaName: string;
}
export interface GetRecommenderSchemaResponse {
    RecommenderSchemaName: string;
    Fields: {
        [key: string]: RecommenderSchemaField[] | undefined;
    };
    CreatedAt: Date;
    Status: RecommenderSchemaStatus;
}
export interface GetSegmentDefinitionRequest {
    DomainName: string;
    SegmentDefinitionName: string;
}
export type SegmentType = "CLASSIC" | "ENHANCED" | (string & {});
export interface GetSegmentDefinitionResponse {
    SegmentDefinitionName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    SegmentGroups?: SegmentGroup | undefined;
    SegmentSort?: SegmentSort | undefined;
    SegmentDefinitionArn: string;
    CreatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    SegmentSqlQuery?: string | redacted.Redacted<string> | undefined;
    SegmentType?: SegmentType | undefined;
}
export interface GetSegmentEstimateRequest {
    DomainName: string;
    EstimateId: string;
}
export type EstimateStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export interface GetSegmentEstimateResponse {
    DomainName?: string | undefined;
    EstimateId?: string | undefined;
    Status?: EstimateStatus | undefined;
    Estimate?: string | undefined;
    Message?: string | undefined;
    StatusCode?: number | undefined;
}
export type ProfileIds = string[];
export interface GetSegmentMembershipRequest {
    DomainName: string;
    SegmentDefinitionName: string;
    ProfileIds: string[];
}
export type ProfileId = string;
export type QueryResult = "PRESENT" | "ABSENT" | (string & {});
export interface ProfileQueryResult {
    ProfileId: string;
    QueryResult: QueryResult;
    Profile?: Profile | undefined;
}
export type Profiles = ProfileQueryResult[];
export type GetSegmentMembershipMessage = string;
export type GetSegmentMembershipStatus = number;
export interface ProfileQueryFailures {
    ProfileId: string;
    Message: string;
    Status?: number | undefined;
}
export type Failures = ProfileQueryFailures[];
export interface GetSegmentMembershipResponse {
    SegmentDefinitionName?: string | undefined;
    Profiles?: ProfileQueryResult[] | undefined;
    Failures?: ProfileQueryFailures[] | undefined;
    LastComputedAt?: Date | undefined;
}
export interface GetSegmentSnapshotRequest {
    DomainName: string;
    SegmentDefinitionName: string;
    SnapshotId: string;
}
export type SegmentSnapshotStatus = "COMPLETED" | "IN_PROGRESS" | "FAILED" | (string & {});
export interface GetSegmentSnapshotResponse {
    SnapshotId: string;
    Status: SegmentSnapshotStatus;
    StatusMessage?: string | undefined;
    DataFormat: DataFormat;
    EncryptionKey?: string | undefined;
    RoleArn?: string | undefined;
    DestinationUri?: string | undefined;
}
export interface GetSegmentSubscriptionRequest {
    DomainName: string;
    SegmentDefinitionName: string;
}
export type SegmentSubscriptionStatus = "STARTING" | "RUNNING" | "STOPPED" | "FAILED" | (string & {});
export type IntervalValue = number;
export type ScheduleConfigurationUnit = "HOURLY" | (string & {});
export interface ScheduleConfiguration {
    Interval: number;
    Unit?: ScheduleConfigurationUnit | undefined;
}
export interface ScheduledExecutions {
    NextExecutedAt?: Date | undefined;
    LastExecutedAt?: Date | undefined;
}
export interface GetSegmentSubscriptionResponse {
    Status?: SegmentSubscriptionStatus | undefined;
    Message?: string | undefined;
    ScheduleConfiguration?: ScheduleConfiguration | undefined;
    ScheduledExecutions?: ScheduledExecutions | undefined;
    StartedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
}
export type MatchType = "RULE_BASED_MATCHING" | "ML_BASED_MATCHING" | (string & {});
export interface GetSimilarProfilesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DomainName: string;
    MatchType: MatchType;
    SearchKey: string;
    SearchValue: string;
}
export type RuleLevel = number;
export interface GetSimilarProfilesResponse {
    ProfileIds?: string[] | undefined;
    MatchId?: string | undefined;
    MatchType?: MatchType | undefined;
    RuleLevel?: number | undefined;
    ConfidenceScore?: number | undefined;
    NextToken?: string | undefined;
}
export interface GetStreamForSegmentsRequest {
    DomainName: string;
}
export type EventSubscriptionSegmentStatus = "STARTING" | "RUNNING" | "STOPPED" | "FAILED" | (string & {});
export interface AssociatedSegment {
    SegmentName?: string | undefined;
    Status?: EventSubscriptionSegmentStatus | undefined;
    Message?: string | undefined;
}
export type AssociatedSegmentsList = AssociatedSegment[];
export type EventSubscriptionState = "RUNNING" | "UNHEALTHY" | "STOPPED" | (string & {});
export interface GetStreamForSegmentsResponse {
    AssociatedAt?: Date | undefined;
    AssociatedSegments?: AssociatedSegment[] | undefined;
    DomainName?: string | undefined;
    DestinationArn?: string | undefined;
    DestinationRoleArn?: string | undefined;
    State?: EventSubscriptionState | undefined;
    DisassociatedAt?: Date | undefined;
    FailureReason?: string | undefined;
}
export interface GetUploadJobRequest {
    DomainName: string;
    JobId: string;
}
export type UploadJobStatus = "CREATED" | "IN_PROGRESS" | "PARTIALLY_SUCCEEDED" | "SUCCEEDED" | "FAILED" | "STOPPED" | (string & {});
export type StatusReason = "VALIDATION_FAILURE" | "INTERNAL_FAILURE" | (string & {});
export interface ResultsSummary {
    UpdatedRecords?: number | undefined;
    CreatedRecords?: number | undefined;
    FailedRecords?: number | undefined;
}
export interface GetUploadJobResponse {
    JobId?: string | undefined;
    DisplayName?: string | undefined;
    Status?: UploadJobStatus | undefined;
    StatusReason?: StatusReason | undefined;
    CreatedAt?: Date | undefined;
    CompletedAt?: Date | undefined;
    Fields?: {
        [key: string]: ObjectTypeField | undefined;
    } | undefined;
    UniqueKey?: string | undefined;
    ResultsSummary?: ResultsSummary | undefined;
    DataExpiry?: number | undefined;
}
export interface GetUploadJobPathRequest {
    DomainName: string;
    JobId: string;
}
export interface GetUploadJobPathResponse {
    Url: string;
    ClientToken?: string | undefined;
    ValidUntil?: Date | undefined;
}
export interface GetWorkflowRequest {
    DomainName: string;
    WorkflowId: string;
}
export type Status = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETE" | "FAILED" | "SPLIT" | "RETRY" | "CANCELLED" | (string & {});
export interface AppflowIntegrationWorkflowAttributes {
    SourceConnectorType: SourceConnectorType;
    ConnectorProfileName: string;
    RoleArn?: string | undefined;
}
export interface WorkflowAttributes {
    AppflowIntegration?: AppflowIntegrationWorkflowAttributes | undefined;
}
export interface AppflowIntegrationWorkflowMetrics {
    RecordsProcessed: number;
    StepsCompleted: number;
    TotalSteps: number;
}
export interface WorkflowMetrics {
    AppflowIntegration?: AppflowIntegrationWorkflowMetrics | undefined;
}
export interface GetWorkflowResponse {
    WorkflowId?: string | undefined;
    WorkflowType?: WorkflowType | undefined;
    Status?: Status | undefined;
    ErrorDescription?: string | undefined;
    StartDate?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Attributes?: WorkflowAttributes | undefined;
    Metrics?: WorkflowMetrics | undefined;
}
export interface GetWorkflowStepsRequest {
    DomainName: string;
    WorkflowId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AppflowIntegrationWorkflowStep {
    FlowName: string;
    Status: Status;
    ExecutionMessage: string;
    RecordsProcessed: number;
    BatchRecordsStartTime: string;
    BatchRecordsEndTime: string;
    CreatedAt: Date;
    LastUpdatedAt: Date;
}
export interface WorkflowStepItem {
    AppflowIntegration?: AppflowIntegrationWorkflowStep | undefined;
}
export type WorkflowStepsList = WorkflowStepItem[];
export interface GetWorkflowStepsResponse {
    WorkflowId?: string | undefined;
    WorkflowType?: WorkflowType | undefined;
    Items?: WorkflowStepItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAccountIntegrationsRequest {
    Uri: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    IncludeHidden?: boolean | undefined;
}
export interface ListIntegrationItem {
    DomainName: string;
    Uri: string;
    ObjectTypeName?: string | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ObjectTypeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    WorkflowId?: string | undefined;
    IsUnstructured?: boolean | undefined;
    RoleArn?: string | undefined;
    EventTriggerNames?: string[] | undefined;
    Scope?: Scope | undefined;
}
export type IntegrationList = ListIntegrationItem[];
export interface ListAccountIntegrationsResponse {
    Items?: ListIntegrationItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCalculatedAttributeDefinitionsRequest {
    DomainName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListCalculatedAttributeDefinitionItem {
    CalculatedAttributeName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    UseHistoricalData?: boolean | undefined;
    Status?: ReadinessStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CalculatedAttributeDefinitionsList = ListCalculatedAttributeDefinitionItem[];
export interface ListCalculatedAttributeDefinitionsResponse {
    Items?: ListCalculatedAttributeDefinitionItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCalculatedAttributesForProfileRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DomainName: string;
    ProfileId: string;
}
export interface ListCalculatedAttributeForProfileItem {
    CalculatedAttributeName?: string | undefined;
    DisplayName?: string | undefined;
    IsDataPartial?: string | undefined;
    Value?: string | undefined;
    LastObjectTimestamp?: Date | undefined;
}
export type CalculatedAttributesForProfileList = ListCalculatedAttributeForProfileItem[];
export interface ListCalculatedAttributesForProfileResponse {
    Items?: ListCalculatedAttributeForProfileItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDomainLayoutsRequest {
    DomainName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface LayoutItem {
    LayoutDefinitionName: string;
    Description: string | redacted.Redacted<string>;
    DisplayName: string;
    IsDefault?: boolean | undefined;
    LayoutType: LayoutType;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
}
export type LayoutList = LayoutItem[];
export interface ListDomainLayoutsResponse {
    Items?: LayoutItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDomainObjectTypesRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DomainObjectTypesListItem {
    ObjectTypeName: string;
    Description?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DomainObjectTypesList = DomainObjectTypesListItem[];
export interface ListDomainObjectTypesResponse {
    Items?: DomainObjectTypesListItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDomainsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListDomainItem {
    DomainName: string;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DomainList = ListDomainItem[];
export interface ListDomainsResponse {
    Items?: ListDomainItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventStreamsRequest {
    DomainName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DestinationSummary {
    Uri: string;
    Status: EventStreamDestinationStatus;
    UnhealthySince?: Date | undefined;
}
export interface EventStreamSummary {
    DomainName: string;
    EventStreamName: string;
    EventStreamArn: string;
    State: EventStreamState;
    StoppedSince?: Date | undefined;
    DestinationSummary?: DestinationSummary | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EventStreamSummaryList = EventStreamSummary[];
export interface ListEventStreamsResponse {
    Items?: EventStreamSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventTriggersRequest {
    DomainName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface EventTriggerSummaryItem {
    ObjectTypeName?: string | undefined;
    EventTriggerName?: string | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EventTriggerSummaryList = EventTriggerSummaryItem[];
export interface ListEventTriggersResponse {
    Items?: EventTriggerSummaryItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListIdentityResolutionJobsRequest {
    DomainName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface IdentityResolutionJob {
    DomainName?: string | undefined;
    JobId?: string | undefined;
    Status?: IdentityResolutionJobStatus | undefined;
    JobStartTime?: Date | undefined;
    JobEndTime?: Date | undefined;
    JobStats?: JobStats | undefined;
    ExportingLocation?: ExportingLocation | undefined;
    Message?: string | undefined;
}
export type IdentityResolutionJobsList = IdentityResolutionJob[];
export interface ListIdentityResolutionJobsResponse {
    IdentityResolutionJobsList?: IdentityResolutionJob[] | undefined;
    NextToken?: string | undefined;
}
export interface ListIntegrationsRequest {
    DomainName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    IncludeHidden?: boolean | undefined;
}
export interface ListIntegrationsResponse {
    Items?: ListIntegrationItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListObjectTypeAttributesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DomainName: string;
    ObjectTypeName: string;
}
export interface ListObjectTypeAttributeItem {
    AttributeName: string;
    LastUpdatedAt: Date;
}
export type ListObjectTypeAttributesList = ListObjectTypeAttributeItem[];
export interface ListObjectTypeAttributesResponse {
    Items?: ListObjectTypeAttributeItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListObjectTypeAttributeValuesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DomainName: string;
    ObjectTypeName: string;
    AttributeName: string;
}
export interface ListObjectTypeAttributeValuesItem {
    Value: string | redacted.Redacted<string>;
    LastUpdatedAt: Date;
}
export type ListObjectTypeAttributeValuesList = ListObjectTypeAttributeValuesItem[];
export interface ListObjectTypeAttributeValuesResponse {
    Items?: ListObjectTypeAttributeValuesItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ProfileAttributeValuesRequest {
    DomainName: string;
    AttributeName: string;
}
export interface AttributeValueItem {
    Value?: string | undefined;
}
export type AttributeValueItemList = AttributeValueItem[];
export interface ProfileAttributeValuesResponse {
    DomainName?: string | undefined;
    AttributeName?: string | undefined;
    Items?: AttributeValueItem[] | undefined;
    StatusCode?: number | undefined;
}
export interface ListProfileHistoryRecordsRequest {
    DomainName: string;
    ProfileId: string;
    ObjectTypeName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ActionType?: ActionType | undefined;
    PerformedBy?: string | undefined;
}
export interface ProfileHistoryRecord {
    Id: string;
    ObjectTypeName: string;
    CreatedAt: Date;
    LastUpdatedAt?: Date | undefined;
    ActionType: ActionType;
    ProfileObjectUniqueKey?: string | undefined;
    PerformedBy?: string | undefined;
}
export type ProfileHistoryRecords = ProfileHistoryRecord[];
export interface ListProfileHistoryRecordsResponse {
    ProfileHistoryRecords?: ProfileHistoryRecord[] | undefined;
    NextToken?: string | undefined;
}
export interface ObjectFilter {
    KeyName: string;
    Values: string[];
}
export interface ListProfileObjectsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DomainName: string;
    ObjectTypeName: string;
    ProfileId: string;
    ObjectFilter?: ObjectFilter | undefined;
}
export interface ListProfileObjectsItem {
    ObjectTypeName?: string | undefined;
    ProfileObjectUniqueKey?: string | undefined;
    Object?: string | redacted.Redacted<string> | undefined;
}
export type ProfileObjectList = ListProfileObjectsItem[];
export interface ListProfileObjectsResponse {
    Items?: ListProfileObjectsItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProfileObjectTypesRequest {
    DomainName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListProfileObjectTypeItem {
    ObjectTypeName: string;
    Description: string;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    MaxProfileObjectCount?: number | undefined;
    MaxAvailableProfileObjectCount?: number | undefined;
    SourcePriority?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProfileObjectTypeList = ListProfileObjectTypeItem[];
export interface ListProfileObjectTypesResponse {
    Items?: ListProfileObjectTypeItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProfileObjectTypeTemplatesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListProfileObjectTypeTemplateItem {
    TemplateId?: string | undefined;
    SourceName?: string | undefined;
    SourceObject?: string | undefined;
}
export type ProfileObjectTypeTemplateList = ListProfileObjectTypeTemplateItem[];
export interface ListProfileObjectTypeTemplatesResponse {
    Items?: ListProfileObjectTypeTemplateItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRecommenderFiltersRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RecommenderFilterSummary {
    RecommenderFilterName?: string | undefined;
    RecommenderSchemaName?: string | undefined;
    RecommenderFilterExpression?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Status?: RecommenderFilterStatus | undefined;
    FailureReason?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RecommenderFilterSummaryList = RecommenderFilterSummary[];
export interface ListRecommenderFiltersResponse {
    NextToken?: string | undefined;
    RecommenderFilters?: RecommenderFilterSummary[] | undefined;
}
export type ListRecommenderRecipesRequestMaxResultsInteger = number;
export interface ListRecommenderRecipesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RecommenderRecipe {
    name?: RecommenderRecipeName | undefined;
    description?: string | undefined;
}
export type RecommenderRecipesList = RecommenderRecipe[];
export interface ListRecommenderRecipesResponse {
    NextToken?: string | undefined;
    RecommenderRecipes?: RecommenderRecipe[] | undefined;
}
export type ListRecommendersRequestMaxResultsInteger = number;
export interface ListRecommendersRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RecommenderSummary {
    RecommenderName?: string | undefined;
    RecipeName?: RecommenderRecipeName | undefined;
    RecommenderSchemaName?: string | undefined;
    RecommenderConfig?: RecommenderConfig | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Status?: RecommenderStatus | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    FailureReason?: string | undefined;
    LatestRecommenderUpdate?: RecommenderUpdate | undefined;
}
export type RecommenderSummaryList = RecommenderSummary[];
export interface ListRecommendersResponse {
    NextToken?: string | undefined;
    Recommenders?: RecommenderSummary[] | undefined;
}
export interface ListRecommenderSchemasRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RecommenderSchemaSummary {
    RecommenderSchemaName: string;
    Fields: {
        [key: string]: RecommenderSchemaField[] | undefined;
    };
    CreatedAt: Date;
    Status: RecommenderSchemaStatus;
}
export type RecommenderSchemaSummaryList = RecommenderSchemaSummary[];
export interface ListRecommenderSchemasResponse {
    NextToken?: string | undefined;
    RecommenderSchemas?: RecommenderSchemaSummary[] | undefined;
}
export interface ListRuleBasedMatchesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DomainName: string;
}
export type MatchIdList = string[];
export interface ListRuleBasedMatchesResponse {
    MatchIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSegmentDefinitionsRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SegmentDefinitionItem {
    SegmentDefinitionName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    SegmentDefinitionArn?: string | undefined;
    CreatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    SegmentType?: SegmentType | undefined;
}
export type SegmentDefinitionsList = SegmentDefinitionItem[];
export interface ListSegmentDefinitionsResponse {
    NextToken?: string | undefined;
    Items?: SegmentDefinitionItem[] | undefined;
}
export interface ListSegmentSubscriptionEventsRequest {
    DomainName: string;
    SegmentDefinitionName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SubscriptionEventType = "LIVE" | "SCHEDULE" | (string & {});
export type SubscriptionEvent = "JOINED" | "LEFT" | (string & {});
export interface SubscriptionEventItem {
    ProfileId?: string | undefined;
    UpdatedAt?: Date | undefined;
    EventType?: SubscriptionEventType | undefined;
    Event?: SubscriptionEvent | undefined;
}
export type SubscriptionEventsList = SubscriptionEventItem[];
export interface ListSegmentSubscriptionEventsResponse {
    Events?: SubscriptionEventItem[] | undefined;
    NextToken?: string | undefined;
}
export type TagArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListUploadJobsRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface UploadJobItem {
    JobId?: string | undefined;
    DisplayName?: string | undefined;
    Status?: UploadJobStatus | undefined;
    StatusReason?: StatusReason | undefined;
    CreatedAt?: Date | undefined;
    CompletedAt?: Date | undefined;
    DataExpiry?: number | undefined;
}
export type UploadJobsList = UploadJobItem[];
export interface ListUploadJobsResponse {
    NextToken?: string | undefined;
    Items?: UploadJobItem[] | undefined;
}
export interface ListWorkflowsRequest {
    DomainName: string;
    WorkflowType?: WorkflowType | undefined;
    Status?: Status | undefined;
    QueryStartDate?: Date | undefined;
    QueryEndDate?: Date | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListWorkflowsItem {
    WorkflowType: WorkflowType;
    WorkflowId: string;
    Status: Status;
    StatusDescription: string;
    CreatedAt: Date;
    LastUpdatedAt: Date;
}
export type WorkflowList = ListWorkflowsItem[];
export interface ListWorkflowsResponse {
    Items?: ListWorkflowsItem[] | undefined;
    NextToken?: string | undefined;
}
export type ProfileIdToBeMergedList = string[];
export type AttributeSourceIdMap = {
    [key: string]: string | undefined;
};
export interface FieldSourceProfileIds {
    AccountNumber?: string | undefined;
    AdditionalInformation?: string | undefined;
    PartyType?: string | undefined;
    BusinessName?: string | undefined;
    FirstName?: string | undefined;
    MiddleName?: string | undefined;
    LastName?: string | undefined;
    BirthDate?: string | undefined;
    Gender?: string | undefined;
    PhoneNumber?: string | undefined;
    MobilePhoneNumber?: string | undefined;
    HomePhoneNumber?: string | undefined;
    BusinessPhoneNumber?: string | undefined;
    EmailAddress?: string | undefined;
    PersonalEmailAddress?: string | undefined;
    BusinessEmailAddress?: string | undefined;
    Address?: string | undefined;
    ShippingAddress?: string | undefined;
    MailingAddress?: string | undefined;
    BillingAddress?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    ProfileType?: string | undefined;
    EngagementPreferences?: string | undefined;
}
export interface MergeProfilesRequest {
    DomainName: string;
    MainProfileId: string;
    ProfileIdsToBeMerged: string[];
    FieldSourceProfileIds?: FieldSourceProfileIds | undefined;
}
export interface MergeProfilesResponse {
    Message?: string | undefined;
}
export interface PutDomainObjectTypeRequest {
    DomainName: string;
    ObjectTypeName: string;
    Description?: string | redacted.Redacted<string> | undefined;
    EncryptionKey?: string | undefined;
    Fields: {
        [key: string]: DomainObjectTypeField | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutDomainObjectTypeResponse {
    ObjectTypeName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    EncryptionKey?: string | undefined;
    Fields?: {
        [key: string]: DomainObjectTypeField | undefined;
    } | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutIntegrationRequest {
    DomainName: string;
    Uri?: string | undefined;
    ObjectTypeName?: string | undefined;
    ObjectTypeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    FlowDefinition?: FlowDefinition | undefined;
    RoleArn?: string | undefined;
    EventTriggerNames?: string[] | undefined;
    Scope?: Scope | undefined;
}
export interface PutIntegrationResponse {
    DomainName: string;
    Uri: string;
    ObjectTypeName?: string | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ObjectTypeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    WorkflowId?: string | undefined;
    IsUnstructured?: boolean | undefined;
    RoleArn?: string | undefined;
    EventTriggerNames?: string[] | undefined;
    Scope?: Scope | undefined;
}
export interface PutProfileObjectRequest {
    ObjectTypeName: string;
    Object: string | redacted.Redacted<string>;
    DomainName: string;
}
export interface PutProfileObjectResponse {
    ProfileObjectUniqueKey?: string | undefined;
}
export interface PutProfileObjectTypeRequest {
    DomainName: string;
    ObjectTypeName: string;
    Description: string | redacted.Redacted<string>;
    TemplateId?: string | undefined;
    ExpirationDays?: number | undefined;
    EncryptionKey?: string | undefined;
    AllowProfileCreation?: boolean | undefined;
    SourceLastUpdatedTimestampFormat?: string | undefined;
    MaxProfileObjectCount?: number | undefined;
    SourcePriority?: number | undefined;
    Fields?: {
        [key: string]: ObjectTypeField | undefined;
    } | undefined;
    Keys?: {
        [key: string]: ObjectTypeKey[] | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutProfileObjectTypeResponse {
    ObjectTypeName: string;
    Description: string | redacted.Redacted<string>;
    TemplateId?: string | undefined;
    ExpirationDays?: number | undefined;
    EncryptionKey?: string | undefined;
    AllowProfileCreation?: boolean | undefined;
    SourceLastUpdatedTimestampFormat?: string | undefined;
    MaxProfileObjectCount?: number | undefined;
    MaxAvailableProfileObjectCount?: number | undefined;
    SourcePriority?: number | undefined;
    Fields?: {
        [key: string]: ObjectTypeField | undefined;
    } | undefined;
    Keys?: {
        [key: string]: ObjectTypeKey[] | undefined;
    } | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutSegmentSubscriptionRequest {
    DomainName: string;
    SegmentDefinitionName: string;
    ScheduleConfiguration?: ScheduleConfiguration | undefined;
}
export interface PutSegmentSubscriptionResponse {
    Status?: SegmentSubscriptionStatus | undefined;
    ScheduleConfiguration?: ScheduleConfiguration | undefined;
    StartedAt?: Date | undefined;
}
export interface AdditionalSearchKey {
    KeyName: string;
    Values: string[];
}
export type AdditionalSearchKeysList = AdditionalSearchKey[];
export type LogicalOperator = "AND" | "OR" | (string & {});
export interface SearchProfilesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DomainName: string;
    KeyName: string;
    Values: string[];
    AdditionalSearchKeys?: AdditionalSearchKey[] | undefined;
    LogicalOperator?: LogicalOperator | undefined;
}
export interface SearchProfilesResponse {
    Items?: Profile[] | undefined;
    NextToken?: string | undefined;
}
export type KeyValuesList = string[];
export interface Recommender {
    Name: string;
    Filters?: RecommenderFilter[] | undefined;
    PromotionalFilters?: RecommenderPromotionalFilter[] | undefined;
}
export interface RecommendationMetadata {
    Columns?: string[] | undefined;
}
export interface SearchRecommendationsRequest {
    DomainName: string;
    KeyName: string;
    KeyValues: string[];
    Recommender: Recommender;
    CandidateIds?: string[] | undefined;
    Context?: {
        [key: string]: string | undefined;
    } | undefined;
    Diversity?: RecommendationDiversityConfig | undefined;
    Metadata?: RecommendationMetadata | undefined;
    MaxRecommendations?: number | undefined;
}
export interface SearchRecommendationsResponse {
    ProfileId?: string | undefined;
    Recommendations?: Recommendation[] | undefined;
}
export interface StartRecommenderRequest {
    DomainName: string;
    RecommenderName: string;
}
export interface StartRecommenderResponse {
}
export interface StartUploadJobRequest {
    DomainName: string;
    JobId: string;
}
export interface StartUploadJobResponse {
}
export interface StopRecommenderRequest {
    DomainName: string;
    RecommenderName: string;
}
export interface StopRecommenderResponse {
}
export interface StopUploadJobRequest {
    DomainName: string;
    JobId: string;
}
export interface StopUploadJobResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCalculatedAttributeDefinitionRequest {
    DomainName: string;
    CalculatedAttributeName: string;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Conditions?: Conditions | undefined;
}
export interface UpdateCalculatedAttributeDefinitionResponse {
    CalculatedAttributeName?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Statistic?: Statistic | undefined;
    Conditions?: Conditions | undefined;
    AttributeDetails?: AttributeDetails | undefined;
    UseHistoricalData?: boolean | undefined;
    Status?: ReadinessStatus | undefined;
    Readiness?: Readiness | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateDomainRequest {
    DomainName: string;
    DefaultExpirationDays?: number | undefined;
    DefaultEncryptionKey?: string | undefined;
    DeadLetterQueueUrl?: string | undefined;
    Matching?: MatchingRequest | undefined;
    RuleBasedMatching?: RuleBasedMatchingRequest | undefined;
    DataStore?: DataStoreRequest | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateDomainResponse {
    DomainName: string;
    DefaultExpirationDays?: number | undefined;
    DefaultEncryptionKey?: string | undefined;
    DeadLetterQueueUrl?: string | undefined;
    Matching?: MatchingResponse | undefined;
    RuleBasedMatching?: RuleBasedMatchingResponse | undefined;
    DataStore?: DataStoreResponse | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateDomainLayoutRequest {
    DomainName: string;
    LayoutDefinitionName: string;
    Description?: string | redacted.Redacted<string> | undefined;
    DisplayName?: string | undefined;
    IsDefault?: boolean | undefined;
    LayoutType?: LayoutType | undefined;
    Layout?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateDomainLayoutResponse {
    LayoutDefinitionName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    DisplayName?: string | undefined;
    IsDefault?: boolean | undefined;
    LayoutType?: LayoutType | undefined;
    Layout?: string | redacted.Redacted<string> | undefined;
    Version?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateEventTriggerRequest {
    DomainName: string;
    EventTriggerName: string;
    ObjectTypeName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    EventTriggerConditions?: EventTriggerCondition[] | undefined;
    SegmentFilter?: string | undefined;
    EventTriggerLimits?: EventTriggerLimits | undefined;
}
export interface UpdateEventTriggerResponse {
    EventTriggerName?: string | undefined;
    ObjectTypeName?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    EventTriggerConditions?: EventTriggerCondition[] | undefined;
    SegmentFilter?: string | undefined;
    EventTriggerLimits?: EventTriggerLimits | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SensitiveString0To1000 = string | redacted.Redacted<string>;
export type SensitiveString0To255 = string | redacted.Redacted<string>;
export type String0To255 = string;
export interface UpdateAddress {
    Address1?: string | undefined;
    Address2?: string | undefined;
    Address3?: string | undefined;
    Address4?: string | undefined;
    City?: string | undefined;
    County?: string | undefined;
    State?: string | undefined;
    Province?: string | undefined;
    Country?: string | undefined;
    PostalCode?: string | undefined;
}
export type UpdateAttributes = {
    [key: string]: string | undefined;
};
export interface UpdateProfileRequest {
    DomainName: string;
    ProfileId: string;
    AdditionalInformation?: string | redacted.Redacted<string> | undefined;
    AccountNumber?: string | redacted.Redacted<string> | undefined;
    PartyType?: PartyType | undefined;
    BusinessName?: string | redacted.Redacted<string> | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    MiddleName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    BirthDate?: string | redacted.Redacted<string> | undefined;
    Gender?: Gender | undefined;
    PhoneNumber?: string | redacted.Redacted<string> | undefined;
    MobilePhoneNumber?: string | redacted.Redacted<string> | undefined;
    HomePhoneNumber?: string | redacted.Redacted<string> | undefined;
    BusinessPhoneNumber?: string | redacted.Redacted<string> | undefined;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    PersonalEmailAddress?: string | redacted.Redacted<string> | undefined;
    BusinessEmailAddress?: string | redacted.Redacted<string> | undefined;
    Address?: UpdateAddress | undefined;
    ShippingAddress?: UpdateAddress | undefined;
    MailingAddress?: UpdateAddress | undefined;
    BillingAddress?: UpdateAddress | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    PartyTypeString?: string | redacted.Redacted<string> | undefined;
    GenderString?: string | redacted.Redacted<string> | undefined;
    ProfileType?: ProfileType | undefined;
    EngagementPreferences?: EngagementPreferences | undefined;
}
export interface UpdateProfileResponse {
    ProfileId: string;
}
export interface UpdateRecommenderRequest {
    DomainName: string;
    RecommenderName: string;
    Description?: string | redacted.Redacted<string> | undefined;
    RecommenderConfig?: RecommenderConfig | undefined;
    RecommenderVersionName?: string | undefined;
}
export interface UpdateRecommenderResponse {
    RecommenderName: string;
}
export type AddProfileKeyError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a new key value with a specific profile, such as a Contact Record
 * ContactId.
 *
 * A profile object can have a single unique key and any number of additional keys that can
 * be used to identify the profile that it belongs to.
 */
export declare const addProfileKey: API.OperationMethod<AddProfileKeyRequest & RegionInput, AddProfileKeyResponse, AddProfileKeyError, Credentials | HttpClient.HttpClient>;
export type AssociateStreamForSegmentsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates an Amazon Kinesis data stream to receive segment membership events for a given
 * domain. This is a domain-level configuration that applies to all segment
 * subscriptions within the domain. A domain can have only one associated stream at a time.
 */
export declare const associateStreamForSegments: API.OperationMethod<AssociateStreamForSegmentsRequest & RegionInput, AssociateStreamForSegmentsResponse, AssociateStreamForSegmentsError, Credentials | HttpClient.HttpClient>;
export type BatchGetCalculatedAttributeForProfileError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Fetch the possible attribute values given the attribute name.
 */
export declare const batchGetCalculatedAttributeForProfile: API.OperationMethod<BatchGetCalculatedAttributeForProfileRequest & RegionInput, BatchGetCalculatedAttributeForProfileResponse, BatchGetCalculatedAttributeForProfileError, Credentials | HttpClient.HttpClient>;
export type BatchGetProfileError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get a batch of profiles.
 */
export declare const batchGetProfile: API.OperationMethod<BatchGetProfileRequest & RegionInput, BatchGetProfileResponse, BatchGetProfileError, Credentials | HttpClient.HttpClient>;
export type BatchPutProfileObjectError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds multiple profile objects to a domain of a given ObjectType in a single API call.
 *
 * When adding a specific profile object, like a Contact Record, an inferred profile can
 * get created if it is not mapped to an existing profile. The resulting profile will only
 * have a phone number populated in the standard ProfileObject. Any additional Contact Records
 * with the same phone number will be mapped to the same inferred profile.
 *
 * When a ProfileObject is created and if a ProfileObjectType already exists for the
 * ProfileObject, it will provide data to a standard profile depending on the
 * ProfileObjectType definition.
 *
 * BatchPutProfileObject needs an ObjectType, which can be created using
 * PutProfileObjectType.
 */
export declare const batchPutProfileObject: API.OperationMethod<BatchPutProfileObjectRequest & RegionInput, BatchPutProfileObjectResponse, BatchPutProfileObjectError, Credentials | HttpClient.HttpClient>;
export type CreateCalculatedAttributeDefinitionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new calculated attribute definition. After creation, new object data ingested
 * into Customer Profiles will be included in the calculated attribute, which can be retrieved
 * for a profile using the GetCalculatedAttributeForProfile API. Defining a calculated attribute makes it
 * available for all profiles within a domain. Each calculated attribute can only reference
 * one `ObjectType` and at most, two fields from that
 * `ObjectType`.
 */
export declare const createCalculatedAttributeDefinition: API.OperationMethod<CreateCalculatedAttributeDefinitionRequest & RegionInput, CreateCalculatedAttributeDefinitionResponse, CreateCalculatedAttributeDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a domain, which is a container for all customer data, such as customer profile
 * attributes, object types, profile keys, and encryption keys. You can create multiple
 * domains, and each domain can have multiple third-party integrations.
 *
 * Each Connect Customer instance can be associated with only one domain. Multiple
 * Connect Customer instances can be associated with one domain.
 *
 * Use this API or UpdateDomain to
 * enable identity
 * resolution: set `Matching` to true.
 *
 * To prevent cross-service impersonation when you call this API, see Cross-service confused deputy prevention for sample policies that you should
 * apply.
 *
 * It is not possible to associate a Customer Profiles domain with an Amazon Connect Instance directly from
 * the API. If you would like to create a domain and associate a Customer Profiles domain, use the Amazon Connect
 * admin website. For more information, see Enable Customer Profiles.
 *
 * Each Amazon Connect instance can be associated with only one domain. Multiple Amazon Connect instances
 * can be associated with one domain.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest & RegionInput, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateDomainLayoutError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates the layout to view data for a specific domain. This API can only be invoked from
 * the Amazon Connect admin website.
 */
export declare const createDomainLayout: API.OperationMethod<CreateDomainLayoutRequest & RegionInput, CreateDomainLayoutResponse, CreateDomainLayoutError, Credentials | HttpClient.HttpClient>;
export type CreateEventStreamError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an event stream, which is a subscription to real-time events, such as when
 * profiles are created and updated through Connect Customer Customer Profiles.
 *
 * Each event stream can be associated with only one Kinesis Data Stream destination in the
 * same region and Amazon Web Services account as the customer profiles domain
 */
export declare const createEventStream: API.OperationMethod<CreateEventStreamRequest & RegionInput, CreateEventStreamResponse, CreateEventStreamError, Credentials | HttpClient.HttpClient>;
export type CreateEventTriggerError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an event trigger, which specifies the rules when to perform action based on
 * customer's ingested data.
 *
 * Each event stream can be associated with only one integration in the same region and AWS
 * account as the event stream.
 */
export declare const createEventTrigger: API.OperationMethod<CreateEventTriggerRequest & RegionInput, CreateEventTriggerResponse, CreateEventTriggerError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationWorkflowError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an integration workflow. An integration workflow is an async process which
 * ingests historic data and sets up an integration for ongoing updates. The supported Amazon AppFlow sources are Salesforce, ServiceNow, and Marketo.
 */
export declare const createIntegrationWorkflow: API.OperationMethod<CreateIntegrationWorkflowRequest & RegionInput, CreateIntegrationWorkflowResponse, CreateIntegrationWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateProfileError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a standard profile.
 *
 * A standard profile represents the following attributes for a customer profile in a
 * domain.
 */
export declare const createProfile: API.OperationMethod<CreateProfileRequest & RegionInput, CreateProfileResponse, CreateProfileError, Credentials | HttpClient.HttpClient>;
export type CreateRecommenderError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a recommender
 */
export declare const createRecommender: API.OperationMethod<CreateRecommenderRequest & RegionInput, CreateRecommenderResponse, CreateRecommenderError, Credentials | HttpClient.HttpClient>;
export type CreateRecommenderFilterError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a recommender filter. A recommender filter specifies which items to include or exclude from recommendations.
 */
export declare const createRecommenderFilter: API.OperationMethod<CreateRecommenderFilterRequest & RegionInput, CreateRecommenderFilterResponse, CreateRecommenderFilterError, Credentials | HttpClient.HttpClient>;
export type CreateRecommenderSchemaError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a recommender schema. A recommender schema defines the set of data columns available for training recommenders and filters under a domain.
 */
export declare const createRecommenderSchema: API.OperationMethod<CreateRecommenderSchemaRequest & RegionInput, CreateRecommenderSchemaResponse, CreateRecommenderSchemaError, Credentials | HttpClient.HttpClient>;
export type CreateSegmentDefinitionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a segment definition associated to the given domain.
 */
export declare const createSegmentDefinition: API.OperationMethod<CreateSegmentDefinitionRequest & RegionInput, CreateSegmentDefinitionResponse, CreateSegmentDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateSegmentEstimateError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a segment estimate query.
 */
export declare const createSegmentEstimate: API.OperationMethod<CreateSegmentEstimateRequest & RegionInput, CreateSegmentEstimateResponse, CreateSegmentEstimateError, Credentials | HttpClient.HttpClient>;
export type CreateSegmentSnapshotError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Triggers a job to export a segment to a specified destination.
 */
export declare const createSegmentSnapshot: API.OperationMethod<CreateSegmentSnapshotRequest & RegionInput, CreateSegmentSnapshotResponse, CreateSegmentSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateUploadJobError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an Upload job to ingest data for segment imports. The metadata is created for
 * the job with the provided field mapping and unique key.
 */
export declare const createUploadJob: API.OperationMethod<CreateUploadJobRequest & RegionInput, CreateUploadJobResponse, CreateUploadJobError, Credentials | HttpClient.HttpClient>;
export type DeleteCalculatedAttributeDefinitionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an existing calculated attribute definition. Note that deleting a default
 * calculated attribute is possible, however once deleted, you will be unable to undo that
 * action and will need to recreate it on your own using the
 * CreateCalculatedAttributeDefinition API if you want it back.
 */
export declare const deleteCalculatedAttributeDefinition: API.OperationMethod<DeleteCalculatedAttributeDefinitionRequest & RegionInput, DeleteCalculatedAttributeDefinitionResponse, DeleteCalculatedAttributeDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a specific domain and all of its customer data, such as customer profile
 * attributes and their related objects.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest & RegionInput, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainLayoutError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the layout used to view data for a specific domain. This API can only be invoked
 * from the Amazon Connect admin website.
 */
export declare const deleteDomainLayout: API.OperationMethod<DeleteDomainLayoutRequest & RegionInput, DeleteDomainLayoutResponse, DeleteDomainLayoutError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainObjectTypeError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Delete a DomainObjectType for the given Domain and ObjectType name.
 */
export declare const deleteDomainObjectType: API.OperationMethod<DeleteDomainObjectTypeRequest & RegionInput, DeleteDomainObjectTypeResponse, DeleteDomainObjectTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteEventStreamError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disables and deletes the specified event stream.
 */
export declare const deleteEventStream: API.OperationMethod<DeleteEventStreamRequest & RegionInput, DeleteEventStreamResponse, DeleteEventStreamError, Credentials | HttpClient.HttpClient>;
export type DeleteEventTriggerError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disable and deletes the Event Trigger.
 *
 * You cannot delete an Event Trigger with an active Integration associated.
 */
export declare const deleteEventTrigger: API.OperationMethod<DeleteEventTriggerRequest & RegionInput, DeleteEventTriggerResponse, DeleteEventTriggerError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes an integration from a specific domain.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest & RegionInput, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the standard customer profile and all data pertaining to the profile.
 */
export declare const deleteProfile: API.OperationMethod<DeleteProfileRequest & RegionInput, DeleteProfileResponse, DeleteProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileKeyError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a searchable key from a customer profile.
 */
export declare const deleteProfileKey: API.OperationMethod<DeleteProfileKeyRequest & RegionInput, DeleteProfileKeyResponse, DeleteProfileKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileObjectError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes an object associated with a profile of a given ProfileObjectType.
 */
export declare const deleteProfileObject: API.OperationMethod<DeleteProfileObjectRequest & RegionInput, DeleteProfileObjectResponse, DeleteProfileObjectError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileObjectTypeError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a ProfileObjectType from a specific domain as well as removes all the
 * ProfileObjects of that type. It also disables integrations from this specific
 * ProfileObjectType. In addition, it scrubs all of the fields of the standard profile that
 * were populated from this ProfileObjectType.
 */
export declare const deleteProfileObjectType: API.OperationMethod<DeleteProfileObjectTypeRequest & RegionInput, DeleteProfileObjectTypeResponse, DeleteProfileObjectTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteRecommenderError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a recommender.
 */
export declare const deleteRecommender: API.OperationMethod<DeleteRecommenderRequest & RegionInput, DeleteRecommenderResponse, DeleteRecommenderError, Credentials | HttpClient.HttpClient>;
export type DeleteRecommenderFilterError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a recommender filter from a domain.
 */
export declare const deleteRecommenderFilter: API.OperationMethod<DeleteRecommenderFilterRequest & RegionInput, DeleteRecommenderFilterResponse, DeleteRecommenderFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteRecommenderSchemaError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a recommender schema from a domain.
 */
export declare const deleteRecommenderSchema: API.OperationMethod<DeleteRecommenderSchemaRequest & RegionInput, DeleteRecommenderSchemaResponse, DeleteRecommenderSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteSegmentDefinitionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a segment definition from the domain.
 */
export declare const deleteSegmentDefinition: API.OperationMethod<DeleteSegmentDefinitionRequest & RegionInput, DeleteSegmentDefinitionResponse, DeleteSegmentDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteSegmentSubscriptionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a segment subscription for membership events. All active event notifications for
 * this segment are stopped.
 */
export declare const deleteSegmentSubscription: API.OperationMethod<DeleteSegmentSubscriptionRequest & RegionInput, DeleteSegmentSubscriptionResponse, DeleteSegmentSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified workflow and all its corresponding resources. This is an async
 * process.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest & RegionInput, DeleteWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DetectProfileObjectTypeError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The process of detecting profile object type mapping by using given objects.
 */
export declare const detectProfileObjectType: API.OperationMethod<DetectProfileObjectTypeRequest & RegionInput, DetectProfileObjectTypeResponse, DetectProfileObjectTypeError, Credentials | HttpClient.HttpClient>;
export type DisassociateStreamForSegmentsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates the Amazon Kinesis data stream configured for segment membership events. All
 * active segment subscriptions delivering events to this stream are eventually stopped.
 */
export declare const disassociateStreamForSegments: API.OperationMethod<DisassociateStreamForSegmentsRequest & RegionInput, DisassociateStreamForSegmentsResponse, DisassociateStreamForSegmentsError, Credentials | HttpClient.HttpClient>;
export type GetAutoMergingPreviewError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Tests the auto-merging settings of your Identity Resolution Job without merging your data. It randomly
 * selects a sample of matching groups from the existing matching results, and applies the
 * automerging settings that you provided. You can then view the number of profiles in the
 * sample, the number of matches, and the number of profiles identified to be merged. This
 * enables you to evaluate the accuracy of the attributes in your matching list.
 *
 * You can't view which profiles are matched and would be merged.
 *
 * We strongly recommend you use this API to do a dry run of the automerging process
 * before running the Identity Resolution Job. Include **at least** two matching
 * attributes. If your matching list includes too few attributes (such as only
 * `FirstName` or only `LastName`), there may be a large number of
 * matches. This increases the chances of erroneous merges.
 */
export declare const getAutoMergingPreview: API.OperationMethod<GetAutoMergingPreviewRequest & RegionInput, GetAutoMergingPreviewResponse, GetAutoMergingPreviewError, Credentials | HttpClient.HttpClient>;
export type GetCalculatedAttributeDefinitionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides more information on a calculated attribute definition for Customer
 * Profiles.
 */
export declare const getCalculatedAttributeDefinition: API.OperationMethod<GetCalculatedAttributeDefinitionRequest & RegionInput, GetCalculatedAttributeDefinitionResponse, GetCalculatedAttributeDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetCalculatedAttributeForProfileError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieve a calculated attribute for a customer profile.
 */
export declare const getCalculatedAttributeForProfile: API.OperationMethod<GetCalculatedAttributeForProfileRequest & RegionInput, GetCalculatedAttributeForProfileResponse, GetCalculatedAttributeForProfileError, Credentials | HttpClient.HttpClient>;
export type GetDomainError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns information about a specific domain.
 */
export declare const getDomain: API.OperationMethod<GetDomainRequest & RegionInput, GetDomainResponse, GetDomainError, Credentials | HttpClient.HttpClient>;
export type GetDomainLayoutError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the layout to view data for a specific domain. This API can only be invoked from
 * the Amazon Connect admin website.
 */
export declare const getDomainLayout: API.OperationMethod<GetDomainLayoutRequest & RegionInput, GetDomainLayoutResponse, GetDomainLayoutError, Credentials | HttpClient.HttpClient>;
export type GetDomainObjectTypeError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Return a DomainObjectType for the input Domain and ObjectType names.
 */
export declare const getDomainObjectType: API.OperationMethod<GetDomainObjectTypeRequest & RegionInput, GetDomainObjectTypeResponse, GetDomainObjectTypeError, Credentials | HttpClient.HttpClient>;
export type GetEventStreamError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns information about the specified event stream in a specific domain.
 */
export declare const getEventStream: API.OperationMethod<GetEventStreamRequest & RegionInput, GetEventStreamResponse, GetEventStreamError, Credentials | HttpClient.HttpClient>;
export type GetEventTriggerError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get a specific Event Trigger from the domain.
 */
export declare const getEventTrigger: API.OperationMethod<GetEventTriggerRequest & RegionInput, GetEventTriggerResponse, GetEventTriggerError, Credentials | HttpClient.HttpClient>;
export type GetIdentityResolutionJobError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns information about an Identity Resolution Job in a specific domain.
 *
 * Identity Resolution Jobs are set up using the Amazon Connect admin console. For more information, see Use
 * Identity Resolution to consolidate similar profiles.
 */
export declare const getIdentityResolutionJob: API.OperationMethod<GetIdentityResolutionJobRequest & RegionInput, GetIdentityResolutionJobResponse, GetIdentityResolutionJobError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns an integration for a domain.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationRequest & RegionInput, GetIntegrationResponse, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetMatchesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Before calling this API, use CreateDomain or
 * UpdateDomain to
 * enable identity resolution: set `Matching` to true.
 *
 * GetMatches returns potentially matching profiles, based on the results of the latest run
 * of a machine learning process.
 *
 * The process of matching duplicate profiles. If `Matching` = `true`, Amazon Connect Customer Profiles starts a weekly
 * batch process called Identity Resolution Job. If you do not specify a date and time for Identity Resolution Job to run, by default it runs every
 * Saturday at 12AM UTC to detect duplicate profiles in your domains.
 *
 * After the Identity Resolution Job completes, use the
 * GetMatches
 * API to return and review the results. Or, if you have configured `ExportingConfig` in the `MatchingRequest`, you can download the results from
 * S3.
 *
 * Amazon Connect uses the following profile attributes to identify matches:
 *
 * - PhoneNumber
 *
 * - HomePhoneNumber
 *
 * - BusinessPhoneNumber
 *
 * - MobilePhoneNumber
 *
 * - EmailAddress
 *
 * - PersonalEmailAddress
 *
 * - BusinessEmailAddress
 *
 * - FullName
 *
 * For example, two or more profiles--with spelling mistakes such as **John Doe** and **Jhn Doe**, or different casing
 * email addresses such as **JOHN_DOE@ANYCOMPANY.COM** and
 * **johndoe@anycompany.com**, or different phone number
 * formats such as **555-010-0000** and **+1-555-010-0000**--can be detected as belonging to the same customer **John Doe** and merged into a unified profile.
 */
export declare const getMatches: API.OperationMethod<GetMatchesRequest & RegionInput, GetMatchesResponse, GetMatchesError, Credentials | HttpClient.HttpClient>;
export type GetObjectTypeAttributeStatisticsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The GetObjectTypeAttributeValues API delivers statistical insights about attributes within a specific object type, but is exclusively available for domains with data store enabled. This API performs daily calculations to provide statistical information about your attribute values, helping you understand patterns and trends in your data. The statistical calculations are performed once per day, providing a consistent snapshot of your attribute data characteristics.
 *
 * You'll receive null values in two scenarios:
 *
 * During the first period after enabling data vault (unless a calculation cycle occurs, which happens once daily).
 *
 * For attributes that don't contain numeric values.
 */
export declare const getObjectTypeAttributeStatistics: API.OperationMethod<GetObjectTypeAttributeStatisticsRequest & RegionInput, GetObjectTypeAttributeStatisticsResponse, GetObjectTypeAttributeStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetProfileHistoryRecordError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a history record for a specific profile, for a specific domain.
 */
export declare const getProfileHistoryRecord: API.OperationMethod<GetProfileHistoryRecordRequest & RegionInput, GetProfileHistoryRecordResponse, GetProfileHistoryRecordError, Credentials | HttpClient.HttpClient>;
export type GetProfileObjectTypeError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the object types for a specific domain.
 */
export declare const getProfileObjectType: API.OperationMethod<GetProfileObjectTypeRequest & RegionInput, GetProfileObjectTypeResponse, GetProfileObjectTypeError, Credentials | HttpClient.HttpClient>;
export type GetProfileObjectTypeTemplateError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the template information for a specific object type.
 *
 * A template is a predefined ProfileObjectType, such as "Salesforce-Account" or
 * "Salesforce-Contact." When a user sends a ProfileObject, using the PutProfileObject API,
 * with an ObjectTypeName that matches one of the TemplateIds, it uses the mappings from the
 * template.
 */
export declare const getProfileObjectTypeTemplate: API.OperationMethod<GetProfileObjectTypeTemplateRequest & RegionInput, GetProfileObjectTypeTemplateResponse, GetProfileObjectTypeTemplateError, Credentials | HttpClient.HttpClient>;
export type GetProfileRecommendationsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Fetches the recommendations for a profile in the input Customer Profiles domain. Fetches all the profile recommendations
 */
export declare const getProfileRecommendations: API.OperationMethod<GetProfileRecommendationsRequest & RegionInput, GetProfileRecommendationsResponse, GetProfileRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetRecommenderError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a recommender.
 */
export declare const getRecommender: API.OperationMethod<GetRecommenderRequest & RegionInput, GetRecommenderResponse, GetRecommenderError, Credentials | HttpClient.HttpClient>;
export type GetRecommenderFilterError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a specific recommender filter in a domain.
 */
export declare const getRecommenderFilter: API.OperationMethod<GetRecommenderFilterRequest & RegionInput, GetRecommenderFilterResponse, GetRecommenderFilterError, Credentials | HttpClient.HttpClient>;
export type GetRecommenderSchemaError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves information about a specific recommender schema in a domain.
 */
export declare const getRecommenderSchema: API.OperationMethod<GetRecommenderSchemaRequest & RegionInput, GetRecommenderSchemaResponse, GetRecommenderSchemaError, Credentials | HttpClient.HttpClient>;
export type GetSegmentDefinitionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets a segment definition from the domain.
 */
export declare const getSegmentDefinition: API.OperationMethod<GetSegmentDefinitionRequest & RegionInput, GetSegmentDefinitionResponse, GetSegmentDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetSegmentEstimateError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the result of a segment estimate query.
 */
export declare const getSegmentEstimate: API.OperationMethod<GetSegmentEstimateRequest & RegionInput, GetSegmentEstimateResponse, GetSegmentEstimateError, Credentials | HttpClient.HttpClient>;
export type GetSegmentMembershipError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Determines if the given profiles are within a segment.
 */
export declare const getSegmentMembership: API.OperationMethod<GetSegmentMembershipRequest & RegionInput, GetSegmentMembershipResponse, GetSegmentMembershipError, Credentials | HttpClient.HttpClient>;
export type GetSegmentSnapshotError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieve the latest status of a segment snapshot.
 */
export declare const getSegmentSnapshot: API.OperationMethod<GetSegmentSnapshotRequest & RegionInput, GetSegmentSnapshotResponse, GetSegmentSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetSegmentSubscriptionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the current subscription configuration, execution schedule, and status for
 * segment membership events.
 */
export declare const getSegmentSubscription: API.OperationMethod<GetSegmentSubscriptionRequest & RegionInput, GetSegmentSubscriptionResponse, GetSegmentSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetSimilarProfilesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a set of profiles that belong to the same matching group using the
 * `matchId` or `profileId`. You can also specify the type of
 * matching that you want for finding similar profiles using either
 * `RULE_BASED_MATCHING` or `ML_BASED_MATCHING`.
 */
export declare const getSimilarProfiles: API.PaginatedOperationMethod<GetSimilarProfilesRequest & RegionInput, GetSimilarProfilesResponse, GetSimilarProfilesError, Credentials | HttpClient.HttpClient, Uuid>;
export type GetStreamForSegmentsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns information about the segment membership event stream configured for a specific
 * domain, including the stream state and associated segments.
 */
export declare const getStreamForSegments: API.OperationMethod<GetStreamForSegmentsRequest & RegionInput, GetStreamForSegmentsResponse, GetStreamForSegmentsError, Credentials | HttpClient.HttpClient>;
export type GetUploadJobError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API retrieves the details of a specific upload job.
 */
export declare const getUploadJob: API.OperationMethod<GetUploadJobRequest & RegionInput, GetUploadJobResponse, GetUploadJobError, Credentials | HttpClient.HttpClient>;
export type GetUploadJobPathError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API retrieves the pre-signed URL and client token for uploading the file associated
 * with the upload job.
 */
export declare const getUploadJobPath: API.OperationMethod<GetUploadJobPathRequest & RegionInput, GetUploadJobPathResponse, GetUploadJobPathError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get details of specified workflow.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest & RegionInput, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowStepsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get granular list of steps in workflow.
 */
export declare const getWorkflowSteps: API.OperationMethod<GetWorkflowStepsRequest & RegionInput, GetWorkflowStepsResponse, GetWorkflowStepsError, Credentials | HttpClient.HttpClient>;
export type ListAccountIntegrationsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all of the integrations associated to a specific URI in the AWS account.
 */
export declare const listAccountIntegrations: API.OperationMethod<ListAccountIntegrationsRequest & RegionInput, ListAccountIntegrationsResponse, ListAccountIntegrationsError, Credentials | HttpClient.HttpClient>;
export type ListCalculatedAttributeDefinitionsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists calculated attribute definitions for Customer Profiles
 */
export declare const listCalculatedAttributeDefinitions: API.OperationMethod<ListCalculatedAttributeDefinitionsRequest & RegionInput, ListCalculatedAttributeDefinitionsResponse, ListCalculatedAttributeDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListCalculatedAttributesForProfileError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieve a list of calculated attributes for a customer profile.
 */
export declare const listCalculatedAttributesForProfile: API.OperationMethod<ListCalculatedAttributesForProfileRequest & RegionInput, ListCalculatedAttributesForProfileResponse, ListCalculatedAttributesForProfileError, Credentials | HttpClient.HttpClient>;
export type ListDomainLayoutsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the existing layouts that can be used to view data for a specific domain. This API
 * can only be invoked from the Amazon Connect admin website.
 */
export declare const listDomainLayouts: API.PaginatedOperationMethod<ListDomainLayoutsRequest & RegionInput, ListDomainLayoutsResponse, ListDomainLayoutsError, Credentials | HttpClient.HttpClient, LayoutItem>;
export type ListDomainObjectTypesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List all DomainObjectType(s) in a Customer Profiles domain.
 */
export declare const listDomainObjectTypes: API.PaginatedOperationMethod<ListDomainObjectTypesRequest & RegionInput, ListDomainObjectTypesResponse, ListDomainObjectTypesError, Credentials | HttpClient.HttpClient, DomainObjectTypesListItem>;
export type ListDomainsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all the domains for an AWS account that have been created.
 */
export declare const listDomains: API.OperationMethod<ListDomainsRequest & RegionInput, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient>;
export type ListEventStreamsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all the event streams in a specific domain.
 */
export declare const listEventStreams: API.PaginatedOperationMethod<ListEventStreamsRequest & RegionInput, ListEventStreamsResponse, ListEventStreamsError, Credentials | HttpClient.HttpClient, EventStreamSummary>;
export type ListEventTriggersError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List all Event Triggers under a domain.
 */
export declare const listEventTriggers: API.PaginatedOperationMethod<ListEventTriggersRequest & RegionInput, ListEventTriggersResponse, ListEventTriggersError, Credentials | HttpClient.HttpClient, EventTriggerSummaryItem>;
export type ListIdentityResolutionJobsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all of the Identity Resolution Jobs in your domain. The response sorts the list by
 * `JobStartTime`.
 */
export declare const listIdentityResolutionJobs: API.OperationMethod<ListIdentityResolutionJobsRequest & RegionInput, ListIdentityResolutionJobsResponse, ListIdentityResolutionJobsError, Credentials | HttpClient.HttpClient>;
export type ListIntegrationsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all of the integrations in your domain.
 */
export declare const listIntegrations: API.OperationMethod<ListIntegrationsRequest & RegionInput, ListIntegrationsResponse, ListIntegrationsError, Credentials | HttpClient.HttpClient>;
export type ListObjectTypeAttributesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Fetch the possible attribute values given the attribute name.
 */
export declare const listObjectTypeAttributes: API.PaginatedOperationMethod<ListObjectTypeAttributesRequest & RegionInput, ListObjectTypeAttributesResponse, ListObjectTypeAttributesError, Credentials | HttpClient.HttpClient, ListObjectTypeAttributeItem>;
export type ListObjectTypeAttributeValuesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The ListObjectTypeAttributeValues API provides access to the most recent distinct values for any specified attribute, making it valuable for real-time data validation and consistency checks within your object types. This API works across domain, supporting both custom and standard object types. The API accepts the object type name, attribute name, and domain name as input parameters and returns values up to the storage limit of approximately 350KB.
 */
export declare const listObjectTypeAttributeValues: API.OperationMethod<ListObjectTypeAttributeValuesRequest & RegionInput, ListObjectTypeAttributeValuesResponse, ListObjectTypeAttributeValuesError, Credentials | HttpClient.HttpClient>;
export type ListProfileAttributeValuesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Fetch the possible attribute values given the attribute name.
 */
export declare const listProfileAttributeValues: API.OperationMethod<ProfileAttributeValuesRequest & RegionInput, ProfileAttributeValuesResponse, ListProfileAttributeValuesError, Credentials | HttpClient.HttpClient>;
export type ListProfileHistoryRecordsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of history records for a specific profile, for a specific domain.
 */
export declare const listProfileHistoryRecords: API.OperationMethod<ListProfileHistoryRecordsRequest & RegionInput, ListProfileHistoryRecordsResponse, ListProfileHistoryRecordsError, Credentials | HttpClient.HttpClient>;
export type ListProfileObjectsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of objects associated with a profile of a given ProfileObjectType.
 */
export declare const listProfileObjects: API.OperationMethod<ListProfileObjectsRequest & RegionInput, ListProfileObjectsResponse, ListProfileObjectsError, Credentials | HttpClient.HttpClient>;
export type ListProfileObjectTypesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all of the templates available within the service.
 */
export declare const listProfileObjectTypes: API.OperationMethod<ListProfileObjectTypesRequest & RegionInput, ListProfileObjectTypesResponse, ListProfileObjectTypesError, Credentials | HttpClient.HttpClient>;
export type ListProfileObjectTypeTemplatesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all of the template information for object types.
 */
export declare const listProfileObjectTypeTemplates: API.OperationMethod<ListProfileObjectTypeTemplatesRequest & RegionInput, ListProfileObjectTypeTemplatesResponse, ListProfileObjectTypeTemplatesError, Credentials | HttpClient.HttpClient>;
export type ListRecommenderFiltersError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of recommender filters in the specified domain.
 */
export declare const listRecommenderFilters: API.PaginatedOperationMethod<ListRecommenderFiltersRequest & RegionInput, ListRecommenderFiltersResponse, ListRecommenderFiltersError, Credentials | HttpClient.HttpClient, RecommenderFilterSummary>;
export type ListRecommenderRecipesError = AccessDeniedException | BadRequestException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns a list of available recommender recipes that can be used to create recommenders.
 */
export declare const listRecommenderRecipes: API.PaginatedOperationMethod<ListRecommenderRecipesRequest & RegionInput, ListRecommenderRecipesResponse, ListRecommenderRecipesError, Credentials | HttpClient.HttpClient, RecommenderRecipe>;
export type ListRecommendersError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of recommenders in the specified domain.
 */
export declare const listRecommenders: API.PaginatedOperationMethod<ListRecommendersRequest & RegionInput, ListRecommendersResponse, ListRecommendersError, Credentials | HttpClient.HttpClient, RecommenderSummary>;
export type ListRecommenderSchemasError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of recommender schemas in the specified domain.
 */
export declare const listRecommenderSchemas: API.PaginatedOperationMethod<ListRecommenderSchemasRequest & RegionInput, ListRecommenderSchemasResponse, ListRecommenderSchemasError, Credentials | HttpClient.HttpClient, RecommenderSchemaSummary>;
export type ListRuleBasedMatchesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a set of `MatchIds` that belong to the given domain.
 */
export declare const listRuleBasedMatches: API.PaginatedOperationMethod<ListRuleBasedMatchesRequest & RegionInput, ListRuleBasedMatchesResponse, ListRuleBasedMatchesError, Credentials | HttpClient.HttpClient, String1To255>;
export type ListSegmentDefinitionsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all segment definitions under a domain.
 */
export declare const listSegmentDefinitions: API.PaginatedOperationMethod<ListSegmentDefinitionsRequest & RegionInput, ListSegmentDefinitionsResponse, ListSegmentDefinitionsError, Credentials | HttpClient.HttpClient, SegmentDefinitionItem>;
export type ListSegmentSubscriptionEventsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the most recent membership events for a segment. Each event represents a profile
 * that entered or exited the segment.
 *
 * This operation is paginated.
 */
export declare const listSegmentSubscriptionEvents: API.PaginatedOperationMethod<ListSegmentSubscriptionEventsRequest & RegionInput, ListSegmentSubscriptionEventsResponse, ListSegmentSubscriptionEventsError, Credentials | HttpClient.HttpClient, SubscriptionEventItem>;
export type ListTagsForResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Displays the tags associated with an Amazon Connect Customer Profiles resource. In Connect
 * Customer Profiles, domains, profile object types, and integrations can be tagged.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListUploadJobsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API retrieves a list of upload jobs for the specified domain.
 */
export declare const listUploadJobs: API.PaginatedOperationMethod<ListUploadJobsRequest & RegionInput, ListUploadJobsResponse, ListUploadJobsError, Credentials | HttpClient.HttpClient, UploadJobItem>;
export type ListWorkflowsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Query to list all workflows.
 */
export declare const listWorkflows: API.OperationMethod<ListWorkflowsRequest & RegionInput, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient>;
export type MergeProfilesError = BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Runs an AWS Lambda job that does the following:
 *
 * - All the profileKeys in the `ProfileToBeMerged` will be moved to the
 * main profile.
 *
 * - All the objects in the `ProfileToBeMerged` will be moved to the main
 * profile.
 *
 * - All the `ProfileToBeMerged` will be deleted at the end.
 *
 * - All the profileKeys in the `ProfileIdsToBeMerged` will be moved to the
 * main profile.
 *
 * - Standard fields are merged as follows:
 *
 * - Fields are always "union"-ed if there are no conflicts in standard fields or
 * attributeKeys.
 *
 * - When there are conflicting fields:
 *
 * - If no `SourceProfileIds` entry is specified, the main
 * Profile value is always taken.
 *
 * - If a `SourceProfileIds` entry is specified, the specified
 * profileId is always taken, even if it is a NULL value.
 *
 * You can use MergeProfiles together with GetMatches, which
 * returns potentially matching profiles, or use it with the results of another matching
 * system. After profiles have been merged, they cannot be separated (unmerged).
 */
export declare const mergeProfiles: API.OperationMethod<MergeProfilesRequest & RegionInput, MergeProfilesResponse, MergeProfilesError, Credentials | HttpClient.HttpClient>;
export type PutDomainObjectTypeError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Create/Update a DomainObjectType in a Customer Profiles domain. To create a new DomainObjectType, Data Store needs to be enabled on the Domain.
 */
export declare const putDomainObjectType: API.OperationMethod<PutDomainObjectTypeRequest & RegionInput, PutDomainObjectTypeResponse, PutDomainObjectTypeError, Credentials | HttpClient.HttpClient>;
export type PutIntegrationError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds an integration between the service and a third-party service, which includes
 * Amazon AppFlow and Amazon Connect.
 *
 * An integration can belong to only one domain.
 *
 * To add or remove tags on an existing Integration, see TagResource
 * /
 * UntagResource.
 */
export declare const putIntegration: API.OperationMethod<PutIntegrationRequest & RegionInput, PutIntegrationResponse, PutIntegrationError, Credentials | HttpClient.HttpClient>;
export type PutProfileObjectError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds additional objects to customer profiles of a given ObjectType.
 *
 * When adding a specific profile object, like a Contact Record, an inferred profile can
 * get created if it is not mapped to an existing profile. The resulting profile will only
 * have a phone number populated in the standard ProfileObject. Any additional Contact Records
 * with the same phone number will be mapped to the same inferred profile.
 *
 * When a ProfileObject is created and if a ProfileObjectType already exists for the
 * ProfileObject, it will provide data to a standard profile depending on the
 * ProfileObjectType definition.
 *
 * PutProfileObject needs an ObjectType, which can be created using
 * PutProfileObjectType.
 */
export declare const putProfileObject: API.OperationMethod<PutProfileObjectRequest & RegionInput, PutProfileObjectResponse, PutProfileObjectError, Credentials | HttpClient.HttpClient>;
export type PutProfileObjectTypeError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Defines a ProfileObjectType.
 *
 * To add or remove tags on an existing ObjectType, see
 * TagResource/UntagResource.
 */
export declare const putProfileObjectType: API.OperationMethod<PutProfileObjectTypeRequest & RegionInput, PutProfileObjectTypeResponse, PutProfileObjectTypeError, Credentials | HttpClient.HttpClient>;
export type PutSegmentSubscriptionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates or updates a segment subscription for membership events. When a subscription is
 * created, an initial snapshot is taken and the system begins monitoring for membership
 * changes.
 *
 * You can optionally set a schedule configuration interval to control how often membership
 * snapshots are run. The interval can be from 1 to 24 hours. If not set, the interval defaults
 * to 24 hours. Scheduled snapshots run on
 * a best-effort basis. If a scheduled snapshot takes longer than the configured interval, the
 * next scheduled run does not start until the in-progress snapshot completes, so a run might
 * be delayed or skipped and is not guaranteed to occur at exactly the requested time.
 *
 * For Classic segments, membership events are generated from these scheduled snapshots and
 * also in near real-time as profile attribute changes occur. For SQL segments, membership
 * events are generated only from the scheduled snapshots.
 */
export declare const putSegmentSubscription: API.OperationMethod<PutSegmentSubscriptionRequest & RegionInput, PutSegmentSubscriptionResponse, PutSegmentSubscriptionError, Credentials | HttpClient.HttpClient>;
export type SearchProfilesError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for profiles within a specific domain using one or more predefined search keys
 * (e.g., _fullName, _phone, _email, _account, etc.) and/or custom-defined search keys. A
 * search key is a data type pair that consists of a `KeyName` and
 * `Values` list.
 *
 * This operation supports searching for profiles with a minimum of 1 key-value(s) pair and
 * up to 5 key-value(s) pairs using either `AND` or `OR` logic.
 */
export declare const searchProfiles: API.OperationMethod<SearchProfilesRequest & RegionInput, SearchProfilesResponse, SearchProfilesError, Credentials | HttpClient.HttpClient>;
export type SearchRecommendationsError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves recommendations for a profile in a specific domain. The profile is identified
 * using a search key, which consists of a `KeyName` and a `KeyValues` list.
 * The `KeyName` can be a predefined key (for example, `_profileId`,
 * `_phone`, `_email`) or a custom-defined key.
 *
 * The search key must match exactly one profile. If no profile matches the search key, the
 * operation returns a `ResourceNotFoundException`. If more than one profile matches
 * the search key, the operation returns a `BadRequestException`. You can use the
 * SearchProfiles API to review the matching profiles.
 */
export declare const searchRecommendations: API.OperationMethod<SearchRecommendationsRequest & RegionInput, SearchRecommendationsResponse, SearchRecommendationsError, Credentials | HttpClient.HttpClient>;
export type StartRecommenderError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts a recommender that was previously stopped. Starting a recommender resumes its ability to generate recommendations.
 */
export declare const startRecommender: API.OperationMethod<StartRecommenderRequest & RegionInput, StartRecommenderResponse, StartRecommenderError, Credentials | HttpClient.HttpClient>;
export type StartUploadJobError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API starts the processing of an upload job to ingest profile data.
 */
export declare const startUploadJob: API.OperationMethod<StartUploadJobRequest & RegionInput, StartUploadJobResponse, StartUploadJobError, Credentials | HttpClient.HttpClient>;
export type StopRecommenderError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Stops a recommender, suspending its ability to generate recommendations. The recommender can be restarted later using StartRecommender.
 */
export declare const stopRecommender: API.OperationMethod<StopRecommenderRequest & RegionInput, StopRecommenderResponse, StopRecommenderError, Credentials | HttpClient.HttpClient>;
export type StopUploadJobError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API stops the processing of an upload job.
 */
export declare const stopUploadJob: API.OperationMethod<StopUploadJobRequest & RegionInput, StopUploadJobResponse, StopUploadJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified Amazon Connect Customer Profiles
 * resource. Tags can help you organize and categorize your resources. You can also use them
 * to scope user permissions by granting a user permission to access or change only resources
 * with certain tag values. In Connect Customer Profiles, domains, profile object types, and
 * integrations can be tagged.
 *
 * Tags don't have any semantic meaning to AWS and are interpreted strictly as strings of
 * characters.
 *
 * You can use the TagResource action with a resource that already has tags. If you specify
 * a new tag key, this tag is appended to the list of tags associated with the resource. If
 * you specify a tag key that is already associated with the resource, the new tag value that
 * you specify replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from the specified Amazon Connect Customer Profiles resource. In Connect
 * Customer Profiles, domains, profile object types, and integrations can be tagged.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCalculatedAttributeDefinitionError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing calculated attribute definition. When updating the Conditions, note
 * that increasing the date range of a calculated attribute will not trigger inclusion of
 * historical data greater than the current date range.
 */
export declare const updateCalculatedAttributeDefinition: API.OperationMethod<UpdateCalculatedAttributeDefinitionRequest & RegionInput, UpdateCalculatedAttributeDefinitionResponse, UpdateCalculatedAttributeDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties of a domain, including creating or selecting a dead letter queue
 * or an encryption key.
 *
 * After a domain is created, the name can't be changed.
 *
 * Use this API or CreateDomain to
 * enable identity
 * resolution: set `Matching` to true.
 *
 * To prevent cross-service impersonation when you call this API, see Cross-service confused deputy prevention for sample policies that you should
 * apply.
 *
 * To add or remove tags on an existing Domain, see TagResource/UntagResource.
 */
export declare const updateDomain: API.OperationMethod<UpdateDomainRequest & RegionInput, UpdateDomainResponse, UpdateDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainLayoutError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the layout used to view data for a specific domain. This API can only be invoked
 * from the Amazon Connect admin website.
 */
export declare const updateDomainLayout: API.OperationMethod<UpdateDomainLayoutRequest & RegionInput, UpdateDomainLayoutResponse, UpdateDomainLayoutError, Credentials | HttpClient.HttpClient>;
export type UpdateEventTriggerError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Update the properties of an Event Trigger.
 */
export declare const updateEventTrigger: API.OperationMethod<UpdateEventTriggerRequest & RegionInput, UpdateEventTriggerResponse, UpdateEventTriggerError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties of a profile. The ProfileId is required for updating a customer
 * profile.
 *
 * When calling the UpdateProfile API, specifying an empty string value means that any
 * existing value will be removed. Not specifying a string value means that any value already
 * there will be kept.
 */
export declare const updateProfile: API.OperationMethod<UpdateProfileRequest & RegionInput, UpdateProfileResponse, UpdateProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateRecommenderError = AccessDeniedException | BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties of an existing recommender, allowing you to modify its configuration and description.
 */
export declare const updateRecommender: API.OperationMethod<UpdateRecommenderRequest & RegionInput, UpdateRecommenderResponse, UpdateRecommenderError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=customer-profiles.d.ts.map