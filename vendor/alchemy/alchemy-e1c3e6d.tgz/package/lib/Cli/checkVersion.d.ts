import { AlchemyContext } from "alchemy/AlchemyContext";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as HttpClient from "effect/http/HttpClient";
import * as Path from "effect/Path";
declare const CheckVersionUnexpectedResponse_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CheckVersionUnexpectedResponse";
} & Readonly<A>;
export declare class CheckVersionUnexpectedResponse extends CheckVersionUnexpectedResponse_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
/**
 * Semver precedence: negative when a < b, positive when a > b. Versions that
 * don't parse compare equal, so they never trigger an upgrade notice.
 */
declare const compareVersions: (a: string, b: string) => number;
/**
 * Warn if a newer `alchemy` version is published on the `latest` dist-tag. Runs to completion before any interactive prompts so
 * the warning never interleaves with prompt rendering, and is bounded so it
 * can never stall the CLI: dist-tags are cached in
 * `.alchemy/version-check.json` for a day (failed attempts included), so at
 * most one run per day waits on the network, and only up to
 * {@link SYNC_WAIT}. Best-effort: every failure is swallowed silently.
 */
export declare const checkLatestVersion: Effect.Effect<void, never, AlchemyContext | FileSystem.FileSystem | HttpClient.HttpClient | Path.Path | import("effect/Scope").Scope>;
export declare const _internal: {
    compareVersions: typeof compareVersions;
};
export {};
//# sourceMappingURL=checkVersion.d.ts.map