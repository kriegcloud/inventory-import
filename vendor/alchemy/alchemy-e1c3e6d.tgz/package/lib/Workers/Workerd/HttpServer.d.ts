import type * as cf from "@cloudflare/workers-types";
import * as Effect from "effect/Effect";
import * as Http from "../../Http.ts";
/**
 * Run an Effect HTTP handler against a workerd `Request` and resolve the
 * web `Response` it produces. The handler sees the request both as Effect's
 * `HttpServerRequest` and as the raw web {@link Request}.
 */
export declare const makeRequestEffect: <Req = never>(webRequest: cf.Request, handler: Http.HttpEffect<Req> | Effect.Effect<Http.HttpEffect<Req>>, 
/** A Worker fetch's context. With it, a client abort interrupts the handler. */
ctx?: cf.ExecutionContext) => any;
//# sourceMappingURL=HttpServer.d.ts.map