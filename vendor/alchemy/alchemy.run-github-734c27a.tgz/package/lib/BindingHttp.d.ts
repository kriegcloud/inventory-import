import type { GithubOpContext } from "@distilled.cloud/github";
import { Self } from "alchemy/Self";
import * as Effect from "effect/Effect";
import type * as Redacted from "effect/Redacted";
import type { Repository } from "./Repository.ts";
/**
 * Shared scaffolding for the GitHub `*Http` and `*Local` binding layers.
 *
 * Each binding declares its distilled call once with {@link operation}.
 * `make` runs it with a {@link PersonalAccessToken} bound into the host (one
 * token resource per host, shared by every GitHub binding on it);
 * `BindingLocal.make` runs it with the provider's current credentials.
 *
 * NOT exported from `index.ts`.
 */
/** The bound repository, as an operation sees it. */
export interface BoundRepository {
    readonly owner: string;
    readonly repository: string;
}
/**
 * One distilled call, implemented by both the `*Http` and `*Local` layers.
 * `name` names the span (`GitHub.issues.get`).
 */
export interface Operation<Request extends ReadonlyArray<any>, Out, E> {
    readonly name: string;
    readonly call: (repo: BoundRepository) => (...request: Request) => Effect.Effect<Out, E, GithubOpContext>;
}
export declare const operation: <Request extends ReadonlyArray<any>, Out, E>(name: string, call: Operation<Request, Out, E>["call"]) => Operation<Request, Out, E>;
/** Where a client's calls authenticate: a token and the REST API base URL. */
export interface TokenSource {
    readonly token: Effect.Effect<Redacted.Redacted<string>>;
    readonly apiUrl: Effect.Effect<string | undefined>;
}
/**
 * Bind a repository and return the runtime client for `op`. The repository's
 * `fullName` is bound into the host, so the client resolves it at runtime.
 */
export declare const makeOperationClient: <Request extends ReadonlyArray<any>, Out, E>(op: Operation<Request, Out, E>, source: TokenSource) => (repo: Repository) => Effect.Effect<(...args: any[]) => Effect.Effect<Out, E, never>, never, never>;
/**
 * The token-backed implementation of a GitHub binding. Pass it to
 * `Layer.effect(Tag, BindingHttp.make(op))`.
 */
export declare const make: <Request extends ReadonlyArray<any>, Out, E>(op: Operation<Request, Out, E>) => Effect.Effect<(repo: Repository) => Effect.Effect<(...args: any[]) => Effect.Effect<Out, E, never>, never, never>, never, Self<{
    Type: string;
    LogicalId: string;
}>>;
//# sourceMappingURL=BindingHttp.d.ts.map